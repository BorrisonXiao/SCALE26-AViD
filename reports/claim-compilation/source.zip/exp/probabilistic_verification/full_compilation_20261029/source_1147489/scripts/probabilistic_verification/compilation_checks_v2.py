"""Conservative diagnostics, not an automatic semantic equivalence oracle."""
import re
from nltk.stem import SnowballStemmer
STEM=SnowballStemmer('english').stem
STOP={'be','have','do','s','re','there','here','also','very','just','now','then','still','more','most','some','many','much','such','other','same','own','ago','however','only','even','too','back','up','out','down','off','not','no','never'}
NUMBERS={'zero':'0','one':'1','two':'2','three':'3','four':'4','five':'5','six':'6','seven':'7','eight':'8','nine':'9','ten':'10','eleven':'11','twelve':'12'}

def words(text):
    return [NUMBERS.get(w,STEM(w)) for w in re.findall(r'[a-z]+|\d+(?:\.\d+)*',str(text).lower())]

def meaning_diagnostics(record,form,compilation):
    # Reading a value from the JSON is weaker evidence than checking its role.
    # This only detects some omissions; word coverage never proves equivalence.
    values=[]
    def visit(x,key=None):
        if isinstance(x,dict):
            for k,v in x.items():
                if k in {'id','ref','version','warnings'}:continue
                values.append(k);visit(v,k)
        elif isinstance(x,list):
            for v in x:visit(v,key)
        elif isinstance(x,(str,int,float)):values.append(str(x))
    visit(form)
    represented=set(words(' '.join(values)))
    omitted=[]
    for t in record.get('tokens',[]):
        if t.get('upos') not in {'PROPN','NOUN','ADJ','VERB','ADV','NUM'}:continue
        original=t.get('lemma') or t['text']
        ws=words(original)
        if original.lower() in STOP or not ws:continue
        if not set(ws)<=represented and not set(words(t['text']))<=represented:
            if t['text'] not in omitted:omitted.append(t['text'])
    flags=[]
    if omitted:flags.append(dict(code='possible_omission',details=omitted))
    if compilation.metadata['requires_context']:flags.append(dict(code='context_required',details=compilation.metadata['runtime_requirements']))
    if compilation.metadata['kind']=='mention':flags.append(dict(code='standalone_mention',details='No complete asserted clause.'))
    # Frame checks are restricted to the predicate senses actually tested here.
    for node in compilation.metadata['events'].values():
        p=node['predicate'];args=node.get('arguments',{})
        if p in {'land','collapse'} and 'ARG0' in args:
            flags.append(dict(code='role_frame',details=p+' uses ARG1 for the landing/collapsing theme; inspect ARG0.'))
        if p=='arrest' and 'ARG1' not in args:
            flags.append(dict(code='role_frame',details='Arrest lacks ARG1 for the arrested person.'))
    for data in form.get('entities',[]):
        surface=data['text'];start=record['text'].casefold().find(surface.casefold())
        ts=[t for t in record.get('tokens',[]) if start>=0 and start<=t.get('start_char',-1) and t.get('end_char',-1)<=start+len(surface)]
        if len(ts)>=4 and any(t.get('upos')=='VERB' and t.get('deprel') in {'acl','acl:relcl','ccomp','xcomp','root'} for t in ts):
            flags.append(dict(code='clause_in_entity',details=surface))
    for node in compilation.metadata['events'].values():
        if node['predicate'] in {'say','tell','state','report','claim','ask'} and not node.get('propositions'):
            literals=[a for a in node.get('arguments',{}).values() if isinstance(a,dict) and a.get('kind')=='verbatim_text']
            if not literals:flags.append(dict(code='source_content_missing',details=node['id']))
    return flags

def diagnostic_cost(diagnostics):
    """A fixed reparse selection heuristic; explicitly not an accuracy score."""
    return sum(len(d['details']) if d['code']=='possible_omission' else 20
               for d in diagnostics if d['code'] not in {'context_required','standalone_mention'})

def needs_reparse(diagnostics):
    return any(d['code'] in {'role_frame','clause_in_entity','source_content_missing'} or
               d['code']=='possible_omission' and len(d['details'])>=3 for d in diagnostics)
