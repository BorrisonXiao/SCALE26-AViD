#!/usr/bin/env python3
"""Replay frozen text-model proposals over every inventory claim on CPU."""
import argparse,hashlib,json,time
from collections import Counter
from pathlib import Path
from probabilistic_verification.logical_form_v2 import ScopedCompiler,parse_form
from probabilistic_verification.compilation_checks_v2 import meaning_diagnostics,diagnostic_cost
from probabilistic_verification.logic import Evidence,ground,prolog_program
from problog.program import PrologString
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'

def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def main():
    p=argparse.ArgumentParser();p.add_argument('--raw',type=Path,default=RUN/'neural_raw.jsonl');p.add_argument('--repairs',type=Path);p.add_argument('--output',type=Path,default=RUN/'results.jsonl');p.add_argument('--allow-incomplete',action='store_true');a=p.parse_args()
    records=read(RUN/'repaired_inputs.jsonl');raw={r['claim_id']:r for r in read(a.raw)}
    if not a.allow_incomplete:assert len(raw)==len(records)==2375,(len(raw),len(records))
    repairs={r['claim_id']:r for r in read(a.repairs)} if a.repairs else {}
    results=[];started=time.perf_counter();counts=Counter();flags=Counter();syntax=0;selection=Counter()
    for r in records:
        if r['claim_id'] not in raw:continue
        response=raw[r['claim_id']];selected='initial'
        if r['claim_id'] in repairs:
            candidates=[]
            for name,candidate in [('initial',response),('reparse',repairs[r['claim_id']])]:
                try:
                    form=parse_form(candidate['raw']);c=ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],form)
                    cost=diagnostic_cost(meaning_diagnostics(r,form,c))
                except Exception:cost=1000000
                candidates.append((cost,name,candidate))
            if candidates[1][0]<candidates[0][0]:_,selected,response=candidates[1]
        selection[selected]+=1
        row=dict(claim_id=r['claim_id'],text=r['text'],status='unsupported',request_hash=response['request_hash'],selected_attempt=selected)
        try:
            form=parse_form(response['raw']);row['proposed_form']=form
            c=ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],form)
            diagnostics=meaning_diagnostics(r,form,c)
            evidence=Evidence('compilation-check',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
            gp=ground(c,evidence,max_expansions=10000);source,_=prolog_program([gp],learned=False)
            assert list(PrologString(source));syntax+=1
            row.update(status='compiled',compilation=c.to_dict(),diagnostics=diagnostics,
                program_sha256=hashlib.sha256(source.encode()).hexdigest(),program=source)
            for d in diagnostics:flags[d['code']]+=1
            counts['compiled']+=1
            counts['mention' if c.metadata['kind']=='mention' else 'claim']+=1
            if c.metadata['requires_context']:counts['requires_context']+=1
            if not diagnostics:counts['no_diagnostic_flags']+=1
        except Exception as e:
            row.update(code=getattr(e,'code',type(e).__name__),reason=str(e));counts[row['code']]+=1
        results.append(row)
    a.output.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in results))
    summary=dict(total=len(records),attempted=len(results),counts=counts,diagnostics=flags,prolog_syntax_checked=syntax,selection=selection,
        cpu_seconds=time.perf_counter()-started,raw_sha256=hashlib.sha256(a.raw.read_bytes()).hexdigest(),
        interpretation='Full-corpus development census; syntactic acceptance and word-coverage diagnostics do not establish semantic accuracy.')
    summary['prompt_versions']=sorted({r['request']['config']['prompt_version'] for r in raw.values()})
    summary['compiler_sha256']=hashlib.sha256((ROOT/'scripts/probabilistic_verification/logical_form_v2.py').read_bytes()).hexdigest()
    summary['diagnostics_sha256']=hashlib.sha256((ROOT/'scripts/probabilistic_verification/compilation_checks_v2.py').read_bytes()).hexdigest()
    if a.repairs:summary['repair_raw_sha256']=hashlib.sha256(a.repairs.read_bytes()).hexdigest()
    a.output.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
