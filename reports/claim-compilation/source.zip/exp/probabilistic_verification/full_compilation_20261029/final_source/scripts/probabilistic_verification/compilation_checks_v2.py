"""Conservative diagnostics, not an automatic semantic equivalence oracle."""
import re
from nltk.stem import SnowballStemmer
STEM=SnowballStemmer('english').stem
STOP={'be','have','do','s','re','there','here','also','very','just','now','then','still','more','most','some','many','much','such','other','same','own','ago','however','only','even','too','back','up','out','down','off','not','no','never'}
NUMBERS={'zero':'0','one':'1','two':'2','three':'3','four':'4','five':'5','six':'6','seven':'7','eight':'8','nine':'9','ten':'10','eleven':'11','twelve':'12'}

def words(text):
    return [NUMBERS.get(w,STEM(w)) for w in re.findall(r'[a-z]+|\d+(?:\.\d+)*',str(text).lower())]

def meaning_diagnostics(record,form,compilation):
    # Reading a value from the JSON is weaker evidence than checking its role.
    # This only detects some omissions; word coverage never proves equivalence.
    form=compilation.metadata.get('logical_form',form)
    values=[]
    def visit(x,key=None):
        if isinstance(x,dict):
            for k,v in x.items():
                if k in {'id','ref','version','warnings'}:continue
                values.append(k);visit(v,k)
        elif isinstance(x,list):
            for v in x:visit(v,key)
        elif isinstance(x,(str,int,float)):values.append(str(x))
    visit(form)
    represented=set(words(' '.join(values)))
    omitted=[]
    for t in record.get('tokens',[]):
        if t.get('upos') not in {'PROPN','NOUN','ADJ','VERB','ADV','NUM'}:continue
        original=t.get('lemma') or t['text']
        ws=words(original)
        if original.lower() in STOP or not ws:continue
        if not set(ws)<=represented and not set(words(t['text']))<=represented:
            if t['text'] not in omitted:omitted.append(t['text'])
    flags=[];operators=[];verbatim=[]
    def structures(x):
        if isinstance(x,dict):
            if x.get('op'):operators.append(x['op'])
            if x.get('kind')=='verbatim_text':verbatim.append(str(x.get('value','')))
            for v in x.values():structures(v)
        elif isinstance(x,list):
            for v in x:structures(v)
    structures(form)
    quoted_words=set(words(' '.join(verbatim)))
    modal=[t['text'] for t in record.get('tokens',[]) if t.get('upos')=='AUX' and (t.get('lemma') or t['text']).lower() in {'will','shall','may','might','must','can','could','should','would'} and not set(words(t['text']))<=quoted_words]
    if modal and 'qualified' not in operators:flags.append(dict(code='qualification_missing',details=modal))
    negative=[t['text'] for t in record.get('tokens',[]) if t['text'].lower() in {'not',"n't",'never'} and not set(words(t['text']))<=quoted_words]
    if negative and 'not' not in operators and not re.search(r'\bnot only\b',record['text'],re.I):
        flags.append(dict(code='negation_missing',details=negative))
    if verbatim:
        quotes=re.findall(r'"([^"\n]+)"|“([^”\n]+)”',record['text'])
        for pair in quotes:
            quote=next(x for x in pair if x)
            if len(quote.split())>2 and quote not in verbatim:flags.append(dict(code='quote_omission',details=quote))
    if omitted:flags.append(dict(code='possible_omission',details=omitted))
    if compilation.metadata['requires_context']:flags.append(dict(code='context_required',details=compilation.metadata['runtime_requirements']))
    if compilation.metadata['kind']=='mention':flags.append(dict(code='standalone_mention',details='No complete asserted clause.'))
    # Frame checks are restricted to the predicate senses actually tested here.
    for node in compilation.metadata['events'].values():
        for role,arg in node.get('arguments',{}).items():
            if isinstance(arg,dict) and arg.get('kind') not in {'verbatim_text'} and len(str(arg.get('value','')).split())>=9:
                flags.append(dict(code='long_literal',details=dict(role=role,value=arg['value'])))
        p=node['predicate'];args=node.get('arguments',{})
        if p in {'land','collapse'} and 'ARG0' in args:
            flags.append(dict(code='role_frame',details=p+' uses ARG1 for the landing/collapsing theme; inspect ARG0.'))
        if p=='arrest' and 'ARG1' not in args:
            flags.append(dict(code='role_frame',details='Arrest lacks ARG1 for the arrested person.'))
    for data in form.get('entities',[]):
        surface=data['text'];start=record['text'].casefold().find(surface.casefold())
        ts=[t for t in record.get('tokens',[]) if start>=0 and start<=t.get('start_char',-1) and t.get('end_char',-1)<=start+len(surface)]
        if len(ts)>=4 and any(t.get('upos')=='VERB' and t.get('deprel') in {'acl','acl:relcl','ccomp','xcomp','root'} for t in ts):
            flags.append(dict(code='clause_in_entity',details=surface))
        ids={t['id'] for t in ts};roots=[t for t in ts if t['head'] not in ids]
        if len(ts)>=3 and len(roots)==1 and roots[0].get('upos')=='NOUN' and any(t.get('upos')=='ADP' for t in ts):
            flags.append(dict(code='phrase_argument',details=surface))
    for node in compilation.metadata['events'].values():
        if node['predicate'] in {'say','tell','state','report','claim','ask'} and not node.get('propositions'):
            literals=[a for a in node.get('arguments',{}).values() if isinstance(a,dict) and a.get('kind')=='verbatim_text']
            if not literals:flags.append(dict(code='source_content_missing',details=node['id']))
    return flags

def diagnostic_cost(diagnostics):
    """A fixed reparse selection heuristic; explicitly not an accuracy score."""
    return sum(len(d['details']) if d['code']=='possible_omission' else 20
               for d in diagnostics if d['code'] not in {'context_required','standalone_mention'})

def needs_reparse(diagnostics):
    return any(d['code'] in {'role_frame','clause_in_entity','phrase_argument','long_literal','source_content_missing','qualification_missing','negation_missing','quote_omission'} or
               d['code']=='possible_omission' and len(d['details'])>=3 for d in diagnostics)
