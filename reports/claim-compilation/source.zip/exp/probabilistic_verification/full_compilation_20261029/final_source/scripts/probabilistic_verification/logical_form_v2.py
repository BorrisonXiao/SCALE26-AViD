"""Compile structured semantic parses into scoped three-state predicates.

This module does not decide whether a parse is faithful, or whether a claim is
true. Scope is part of each predicate's input, not a request to assert an embedded
event in the world. New scope/quantity predicates require matching evidence
functions; the existing backend correctly returns unknown when these are absent.
Historical compilers are deliberately unchanged.
"""
from __future__ import annotations
import json
import re
from dataclasses import dataclass, field
from .representation import Atom, CompiledClaim, Expression as E, Variable
from .logical_form import LogicalFormError, bind_variables, lemma
from .semantic import temporal_features

VERSION='logical-form-v2'
ROUTES={'unspecified','speech_assertion','ocr_assertion','visual_depiction','audio_event'}
KINDS={'assertion','depiction','question','reason','purpose','belief','condition','temporal'}
QUALIFIERS={'possible','likely','future','obligation','ability','condition','uncertain'}
QUANTITIES={'exact','at_least','more_than','approx','all','multiple','at_most','less_than','most','some','no'}

def normalized(value):
    return ' '.join(re.findall(r"\w+|[^\w\s]", str(value).casefold().replace('’',"'").replace('“','"').replace('”','"')))

def contained(value,text):
    return bool(str(value).strip()) and (' '+normalized(value)+' ') in (' '+normalized(text)+' ')

def parse_form(raw):
    def object_hook(pairs):
        out={}
        for key,value in pairs:
            if key in out:raise LogicalFormError('duplicate_field','Repeated JSON field: '+key)
            out[key]=value
        return out
    return json.loads(raw,object_pairs_hook=object_hook)

@dataclass(frozen=True)
class ScopedClaim(CompiledClaim):
    version: str=VERSION
    metadata: dict=field(default_factory=dict)


class ScopedCompiler:
    def compile(self,claim_id,text,tokens,form):
        def fail(code,message):raise LogicalFormError(code,message)
        def fields(data,allowed):
            unknown=set(data)-set(allowed.split())
            if unknown:fail('unknown_field','Untranslated fields: '+','.join(sorted(unknown)))
        if not isinstance(form,dict) or form.get('version')!=VERSION:fail('schema','Expected logical-form-v2.')
        fields(form,'version kind status reason entities formula requires_context warnings')
        if form.get('status','ok')!='ok':fail('parser_refusal',str(form.get('reason','Parser declined.')))
        if not isinstance(form.get('entities',[]),list) or not isinstance(form.get('formula'),dict):fail('schema','Entities must be a list and formula must be an object.')
        from .normalize_form_v2 import normalize_form
        form,normalizations=normalize_form(text,tokens,form)
        from .source_checks_v2 import source_checks
        source_checks(text,tokens,form)
        if form.get('kind','claim') not in {'claim','mention'}:fail('schema','Unknown claim kind.')
        entities={}
        for data in form.get('entities',[]):
            if not isinstance(data,dict) or not isinstance(data.get('id'),str) or not isinstance(data.get('text'),str):fail('schema','Entity needs string id and text.')
            if data['id'] in entities:fail('duplicate_entity','Duplicate entity '+data['id'])
            fields(data,'id text type properties relations propositions quantity')
            if data.get('type','entity') not in {'entity','group','pronoun','context'}:fail('entity_type','Unsupported entity type.')
            if not contained(data['text'],text):fail('mention_alignment','Entity is not an exact source mention: '+data['text'])
            entities[data['id']]=data
        atoms=[];variables=[];cache={};refs={};events={};seen_events=set();used=set();first_scope={};entity_cache={}
        metadata=dict(logical_form=form,normalizations=normalizations,entities={},events={},scopes={},temporal={},allowed_routes={},
            kind=form.get('kind','claim'),requires_context=bool(form.get('requires_context')),runtime_requirements=[],
            uses_phrase_arguments=False,limitations=[
                'Executable structure is not a certificate of semantic equivalence.',
                'Scoped, group and reference predicates require evidence functions; missing functions return unknown.',
                'Group descriptions preserve quantifier conditions; no general first-order quantifier theorem prover is implemented.'])
        warnings=list(form.get('warnings',[]));by_id={t['id']:t for t in tokens}
        def new_scope(prefix):
            # Local c1/q1 labels can refer to different source/modal contexts in
            # different claims. They must not alias in a shared evidence cache.
            return prefix+str(len(metadata['scopes'])+1)+'::'+str(claim_id)
        def variable(key,kind,description):
            table=events if kind=='event' else refs
            if key not in table:
                name=('E' if kind=='event' else 'X')+str(len(table)+1)
                table[key]=name;variables.append(Variable(name,kind,description,()))
            return table[key]
        def add(predicate,args,scope,route,owner=None,kind='relation',trainable=True):
            args=[str(a) for a in args]+['scope',scope,'route',route]
            if owner:args+=['owner',owner]
            key=(predicate,tuple(args),kind,trainable)
            if key not in cache:
                a=Atom('a'+str(len(atoms)+1),predicate,tuple(args),kind,(),predicate,(),trainable)
                atoms.append(a);cache[key]=a.id
                metadata['allowed_routes'][a.id]=[route] if route!='unspecified' else ['visual_depiction','audio_event','speech_assertion','ocr_assertion']
            return E.atom(cache[key])
        def props(value,target,scope,route,owner):
            out=[]
            for p in value or []:
                if not isinstance(p,dict) or not {'role','value'}<=p.keys():fail('schema','Property needs role and value.')
                fields(p,'role value')
                if p['role'] in {'tense','aspect'}:continue # Read auxiliaries from source, not model guesses.
                out.append(add('property',[target,p['role'],p['value']],scope,route,owner,kind='property'))
            return out
        def entity(eid,scope,route,owner,trail=()):
            if eid not in entities:fail('unknown_entity','Undeclared entity '+str(eid))
            data=entities[eid];used.add(eid)
            name=variable(eid,'group' if data.get('type')=='group' or data.get('quantity') else 'entity',data['text'])
            metadata['entities'][name]=data
            if eid in trail:return name,[]
            if eid in first_scope and first_scope[eid]!=scope:
                # Re-use identity, not the earlier mention's modifiers, in a new source context.
                return name,[add('reference',[name,eid],scope,route,owner,kind='reference',trainable=False)]
            if (scope,eid) in entity_cache:return name,entity_cache[(scope,eid)]
            first_scope.setdefault(eid,scope)
            out=[add('referent',[name,data['text']],scope,route,owner,kind='entity',trainable=False)]
            out+=props(data.get('properties'),name,scope,route,owner)
            q=data.get('quantity')
            if q:
                if not isinstance(q,dict) or q.get('operator') not in QUANTITIES or 'value' not in q:fail('quantity','Quantity needs a supported operator and value.')
                fields(q,'operator value')
                out.append(add('group_quantity',[name,q['operator'],q['value']],scope,route,owner,kind='quantity',trainable=False))
                metadata['runtime_requirements'].append('group candidates and quantity conditions')
            if data.get('type') in {'pronoun','context'}:
                out.append(add('resolve_reference',[name,data['text']],scope,route,owner,kind='reference',trainable=False))
                metadata['requires_context']=True
                metadata['runtime_requirements'].append('reference resolution')
            for rel in data.get('relations',[]):
                if not isinstance(rel,dict) or not {'role','target'}<=rel.keys():fail('entity_relation','Entity relation needs role and target.')
                fields(rel,'role target')
                other,required=entity(rel['target'],scope,route,owner,trail+(eid,))
                out+=required+[add('entity_relation',[name,rel['role'],other],scope,route,owner)]
            for p in data.get('propositions',[]):
                if not isinstance(p,dict) or p.get('kind') not in KINDS or 'body' not in p or 'role' not in p:fail('proposition','Entity proposition needs role, kind and body.')
                fields(p,'role kind route body')
                child_scope=new_scope('c');child_route=p.get('route','unspecified')
                if child_route not in ROUTES:fail('source_route','Unknown route.')
                metadata['scopes'][child_scope]=dict(parent=scope,kind=p['kind'],role=p['role'],route=child_route,owner=name)
                out +=[add('proposition',[name,p['role'],p['kind'],child_scope],scope,route,owner,kind='scope'),
                    formula(p['body'],child_scope,child_route,name)]
            entity_cache[(scope,eid)]=out
            return name,out
        def anchor(node):
            word=node.get('anchor','')
            exact=[t for t in tokens if word and t['text'].casefold()==word.casefold()]
            if len(exact)==1:return exact[0]
            matching=[t for t in tokens if t.get('lemma','').casefold()==lemma(node['predicate'])]
            if len(matching)==1:return matching[0]
            if len(exact)>1:
                warnings.append('Repeated predicate anchor: '+word+'; tense/aspect left unassigned.')
            elif word and not contained(word,text):fail('anchor_alignment','Predicate anchor is absent from source: '+word)
            return None
        def formula(node,scope='world',route='unspecified',owner=None,depth=0,negative=False):
            if depth>50:fail('size','Formula nesting exceeds 50.')
            if not isinstance(node,dict):fail('schema','Formula nodes must be objects.')
            op=node.get('op')
            allowed={'event':'op id predicate anchor arguments properties propositions sense','and':'op children','or':'op children','not':'op child','qualified':'op operator body','entity':'op ref'}
            if op in allowed:fields(node,allowed[op])
            if op in {'and','or'}:
                children=node.get('children',[])
                if not isinstance(children,list) or len(children)<2:fail('schema','AND/OR need at least two children.')
                result=E.combine(op,[formula(c,scope,route,owner,depth+1) for c in children])
                return E.negate(result) if negative else result
            if op=='not':return formula(node['child'],scope,route,owner,depth+1,not negative)
            if op=='qualified':
                operator=node.get('operator')
                if operator not in QUALIFIERS:fail('qualifier','Unsupported qualifier '+str(operator))
                child_scope=new_scope('q')
                metadata['scopes'][child_scope]=dict(parent=scope,kind='qualified',operator=operator,route=route,owner=owner)
                result=E.combine('and',[add('qualification',[operator,child_scope],scope,route,owner,kind='scope'),
                    formula(node['body'],child_scope,route,owner,depth+1)])
                return E.negate(result) if negative else result
            if op=='entity':
                _,conditions=entity(node.get('ref'),scope,route,owner)
                result=E.combine('and',conditions)
                return E.negate(result) if negative else result
            if op!='event':fail('operator','Unsupported operator '+str(op))
            if not isinstance(node.get('id'),str) or not isinstance(node.get('predicate'),str):fail('schema','Event needs string id and predicate.')
            event_key=(scope,node['id'])
            if event_key in seen_events:fail('duplicate_event','Declare an event once within each clause context: '+node['id'])
            seen_events.add(event_key)
            if len(seen_events)>100:fail('size','More than 100 events.')
            event=variable(event_key,'event',node['predicate']);pred=lemma(node['predicate'])
            metadata['events'][event]=dict(node,scope=scope,route=route,owner=owner)
            args=[event];conditions=[];arguments=node.get('arguments',{});has_verbatim=False
            if not isinstance(arguments,dict):fail('schema','Arguments must be a role-to-value object.')
            for role,value in sorted(arguments.items()):
                if isinstance(value,str):
                    value,required=entity(value,scope,route,owner);conditions+=required
                elif isinstance(value,dict) and 'value' in value and 'kind' in value:
                    fields(value,'value unit kind')
                    if value['kind']=='verbatim_text' and not contained(value['value'],text):fail('quote_alignment','Verbatim text differs from the original quote.')
                    has_verbatim |= value['kind']=='verbatim_text'
                    value=json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'))
                else:fail('argument_format','Arguments must be entity IDs or typed literals.')
                args +=[role,value]
            body=[]
            for p in node.get('propositions',[]):
                if not isinstance(p,dict) or p.get('kind') not in KINDS or p.get('route','unspecified') not in ROUTES or 'body' not in p or 'role' not in p:fail('proposition','Proposition needs role, kind, route and body.')
                fields(p,'role kind route body')
                child_scope=new_scope('c');child_route=p.get('route','unspecified')
                metadata['scopes'][child_scope]=dict(parent=scope,kind=p['kind'],role=p['role'],route=child_route,owner=event)
                args +=[p['role'],child_scope]
                body +=[add('proposition',[event,p['role'],p['kind'],child_scope],scope,route,owner,kind='scope'),
                    formula(p['body'],child_scope,child_route,event,depth+1)]
            if node.get('sense'):args+=['sense',str(node['sense'])]
            event_route=route
            if has_verbatim:
                routes=[p['value'] for p in node.get('properties',[]) if p.get('role')=='source_route']
                if routes:
                    if len(set(routes))!=1 or routes[0] not in ROUTES:fail('source_route','Quoted content has an invalid or conflicting route.')
                    event_route=routes[0]
                elif pred in {'say','tell','shout','chant','ask'}:event_route='speech_assertion'
                else:
                    metadata['requires_context']=True
                    metadata['runtime_requirements'].append('evidence route for quoted content')
            metadata['events'][event]['route']=event_route
            properties=[p for p in node.get('properties',[]) if not (has_verbatim and p.get('role')=='source_route')]
            event_conditions=[add(pred,args,scope,event_route,owner)]+props(properties,event,scope,event_route,owner)+body
            head=anchor(node)
            if head:
                tf=dict(temporal_features(tokens,head['id']),completion='unspecified')
                if tf['tense']!='unspecified' or tf['aspect']!='simple':
                    if not any(v.name=='T0' for v in variables):variables.append(Variable('T0','context','Reference time supplied by the caller',()))
                    metadata['temporal'][event]=tf
                    event_conditions.append(add('temporal',[event,tf['tense'],tf['aspect'],'T0',tf['completion']],scope,event_route,owner,kind='temporal',trainable=False))
            result=E.combine('and',event_conditions)
            if negative:result=E.negate(E.exists([event],result))
            return E.combine('and',conditions+[result])
        expression=formula(form.get('formula'))
        unused=set(entities)-used
        if unused:fail('unused_entities','Declared but unused entities: '+','.join(sorted(unused)))
        if not atoms:fail('empty','No predicates.')
        if metadata['kind']=='mention':
            if form['formula'].get('op')!='entity':fail('mention','A mention must refer to an entity, without inventing an event.')
            metadata['requires_context']=True
            metadata['runtime_requirements'].append('interpretation of a standalone mention')
        metadata['runtime_requirements']=sorted(set(metadata['runtime_requirements']))
        expression=bind_variables(expression,atoms,variables)
        return ScopedClaim(str(claim_id),text,tuple(tokens),tuple(variables),tuple(atoms),expression,(),tuple(dict.fromkeys(warnings)),metadata=metadata)
