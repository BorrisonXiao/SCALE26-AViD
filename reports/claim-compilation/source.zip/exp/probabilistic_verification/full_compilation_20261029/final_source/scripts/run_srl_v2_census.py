#!/usr/bin/env python3
"""Run the trained SRL adapter and improved compiler on all original claims."""
import json,hashlib,time,argparse
from collections import Counter
from pathlib import Path
from probabilistic_verification.srl_form_v2 import srl_form_v2
from probabilistic_verification.logical_form_v2 import ScopedCompiler
from probabilistic_verification.compilation_checks_v2 import meaning_diagnostics
from probabilistic_verification.logic import Evidence,ground,prolog_program
from problog.program import PrologString
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=RUN/'srl_v2_results.jsonl');a=p.parse_args()
    records=[json.loads(s) for s in (RUN/'repaired_inputs.jsonl').read_text().splitlines()];rows=[];counts=Counter();flags=Counter();start=time.perf_counter()
    for r in records:
        row=dict(claim_id=r['claim_id'],text=r['text'],status='unsupported',method='srl_v2',selected_attempt='trained_srl',request_hash=hashlib.sha256(json.dumps(r['srl'],sort_keys=True).encode()).hexdigest())
        try:
            form=srl_form_v2(r);row['proposed_form']=form
            c=ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],form)
            diagnostics=meaning_diagnostics(r,form,c)
            evidence=Evidence('compilation-check',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
            source,_=prolog_program([ground(c,evidence,max_expansions=10000)],learned=False);assert list(PrologString(source))
            row.update(status='compiled',compilation=c.to_dict(),diagnostics=diagnostics,program=source,program_sha256=hashlib.sha256(source.encode()).hexdigest())
            counts['compiled']+=1
            for d in diagnostics:flags[d['code']]+=1
        except Exception as e:row.update(code=getattr(e,'code',type(e).__name__),reason=str(e));counts[row['code']]+=1
        rows.append(row)
    a.output.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    summary=dict(total=len(rows),counts=counts,diagnostics=flags,cpu_seconds=time.perf_counter()-start)
    target=RUN/'srl_v2_summary.json' if a.output==RUN/'srl_v2_results.jsonl' else a.output.with_suffix('.summary.json')
    target.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
