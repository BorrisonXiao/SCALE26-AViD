"""Adapt trained SRL to v2, retaining source spans and explicit limitations.

This reuses the frozen v1 extraction code, not its restricted compiler. Modals
removed from the extraction input are restored as scoped qualifiers. Event-valued
arguments outside its supported source frames are refused, never flattened into
world facts. Original claim text and cached SRL records are never changed.
"""
import copy,re
from .logical_form_adapters import srl_form
from .logical_form import LogicalFormError

PRONOUNS={'he','she','it','they','this','that','them','we','us','you','him','her','their','our','its'}
MODALS={'may':'possible','might':'possible','could':'possible','can':'ability','must':'obligation','should':'obligation','will':'future','shall':'future'}

def srl_form_v2(record):
    assisted=copy.deepcopy(record);modals={}
    for frame in (assisted.get('srl') or {}).get('frames',[]):
        if not isinstance(frame.get('verb_span'),list):
            raise LogicalFormError('missing_srl_span','Cached SRL frame lacks a predicate span: '+str(frame.get('verb')))
        removed=[a for a in frame.get('args',[]) if a['role']=='ARGM-MOD']
        if removed:
            surface=' '.join(a['text'] for a in removed).lower()
            if surface not in MODALS:raise LogicalFormError('modal_scope','SRL modal needs a defined interpretation: '+surface)
            modals['e'+str(frame['verb_span'][0])]=(surface,MODALS[surface])
            frame['args']=[a for a in frame['args'] if a['role']!='ARGM-MOD']
    old=srl_form(assisted);entities={};heads={};token_by_id={t['id']:t for t in record['tokens']}
    for e in old['entities']:
        source=e['text'];matches=list(re.finditer(re.escape(source),record['text'],re.I))
        ts=[]
        if len(matches)==1:
            lo,hi=matches[0].span();ts=[t for t in record['tokens'] if lo<=t['start_char'] and t['end_char']<=hi]
        # SRL alone does not define the logical scope of a clausal argument.
        if any(t.get('upos') in {'VERB','AUX'} for t in ts):
            raise LogicalFormError('event_argument','SRL argument contains an event/clause that needs semantic parsing: '+source)
        head=token_by_id.get(int(e['id'].split('_')[-1])) if e['id'].startswith('head_') else None
        heads[e['id']]=head
        kind='pronoun' if source.lower() in PRONOUNS and not (head and head.get('deprel')=='expl') else 'group' if head and 'Number=Plur' in (head.get('feats') or '') else 'entity'
        data=dict(id=e['id'],text=source,type=kind,properties=e.get('properties',[]))
        numerals=[t for t in record['tokens'] if head and t['head']==head['id'] and t.get('deprel')=='nummod' and t['id']<head['id']]
        if e.get('quantity') and numerals:
            value=e['quantity']
            if len(numerals)>1:raise LogicalFormError('quantity_range','Multiple numeric modifiers need a defined range/count interpretation.')
            position=numerals[0]['start_char'] if numerals else head['start_char'] if head else 0
            prefix=record['text'][max(0,position-24):position]
            operator='exact'
            if re.search(r'\b(at least|no fewer than)\s*$',prefix,re.I):operator='at_least'
            elif re.search(r'\b(over|more than)\s*$',prefix,re.I):operator='more_than'
            elif re.search(r'\b(at most|no more than)\s*$',prefix,re.I):operator='at_most'
            elif re.search(r'\b(under|less than)\s*$',prefix,re.I):operator='less_than'
            elif re.search(r'\b(about|around|approximately|almost|nearly)\s*$',prefix,re.I):operator='approx'
            data['quantity']=dict(operator=operator,value=value)
        elif head:
            qs=[t for t in record['tokens'] if t['head']==head['id'] and t['text'].lower() in {'all','every','each','many','multiple','several','some','both','few','no','numerous'}]
            if len(qs)==1:
                word=qs[0]['text'];low=word.lower()
                if low=='no':raise LogicalFormError('negative_quantifier','A negative existential needs joint entity/event scope; SRL alone does not provide it.')
                if low in {'all','every','each'} and kind!='group':
                    data['properties'].append(dict(role='extent',value=word))
                else:data['quantity']=dict(operator='all' if low in {'all','every','each'} else 'exact' if low=='both' else 'some' if low=='some' else 'multiple',value='2' if low=='both' else word)
        entities[e['id']]=data
    used=set()
    def literal(eid,role):
        e=entities[eid];value=e['text']
        if role=='ARGM-TMP':return dict(value=value,kind='time')
        head=heads.get(eid)
        if role=='ARGM-MNR' and head and head.get('upos') in {'ADV','ADJ'}:return dict(value=value,kind='manner')
        if head and head.get('upos')=='ADV' and role not in {'ARG0','ARG1'}:return dict(value=value,kind='direction' if role in {'ARG4','ARGM-DIR','ARGM-LOC'} else 'manner')
        if head and head.get('upos')=='ADJ' and role not in {'ARG0','ARG1'}:return dict(value=value,kind='text')
        m=re.fullmatch(r'([\d,.]+)\s*(mph|km/h|kmh|feet|ft|inches|inch|cm|meters?|metres?|miles?|hours?|days?|minutes?|seconds?)',value,re.I)
        if m:return dict(value=m[1],unit=m[2],kind='duration' if re.search('hour|day|minute|second',m[2],re.I) else 'measurement')
        used.add(eid);return eid
    def convert(n):
        op=n['op']
        if op in {'and','or'}:return dict(op=op,children=[convert(c) for c in n['children']])
        if op=='not':return dict(op='not',child=convert(n['child']))
        if op=='entity':used.add(n['ref']);return dict(n)
        result=dict(op='event',id=n['id'],predicate=n['predicate'],anchor=n.get('anchor',n['predicate']),
            arguments={role:literal(target,role) for role,target in n.get('arguments',{}).items()},properties=[p for p in n.get('properties',[]) if not p['role'].startswith('preposition:')])
        if n.get('content'):
            route=n['route'];result['propositions']=[dict(role='content',kind='depiction' if route=='visual_depiction' else 'assertion',route=route,body=convert(n['content']))]
        if n['id'] in modals:
            word,operator=modals[n['id']]
            result['properties'].append(dict(role='modal',value=word))
            return dict(op='qualified',operator=operator,body=result)
        return result
    formula=convert(old['formula'])
    return dict(version='logical-form-v2',kind='claim',entities=[e for eid,e in entities.items() if eid in used],formula=formula,
        warnings=['Trained SRL supplies predicate-specific ARG labels. This route refuses unsupported clausal arguments.'])
