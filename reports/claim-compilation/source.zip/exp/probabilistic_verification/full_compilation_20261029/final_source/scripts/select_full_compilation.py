#!/usr/bin/env python3
"""Fixed candidate selection before assistant semantic review.

Prefer trained SRL when its diagnostic cost is no greater than the neural parse;
otherwise use the executable candidate with lower diagnostic cost. Context needs
are retained, not treated as a parsing error. This is not a correctness oracle.
"""
import json,time,argparse
from collections import Counter
from pathlib import Path
from probabilistic_verification.compilation_checks_v2 import diagnostic_cost
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
def read(name):return [json.loads(s) for s in (RUN/name).read_text().splitlines() if s.strip()]
def main():
    p=argparse.ArgumentParser();p.add_argument('--srl',type=Path,default=RUN/'srl_v2_results.jsonl');p.add_argument('--neural',type=Path,default=RUN/'neural_results.jsonl');p.add_argument('--output',type=Path,default=RUN/'results.jsonl');a=p.parse_args()
    srl={r['claim_id']:r for r in map(json.loads,a.srl.read_text().splitlines())};neural={r['claim_id']:r for r in map(json.loads,a.neural.read_text().splitlines())}
    assert len(srl)==len(neural)==2375
    rows=[];counts=Counter();methods=Counter();flags=Counter();fail=Counter()
    for cid,s in srl.items():
        n=neural[cid]
        def cost(r):return diagnostic_cost(r.get('diagnostics',[])) if r['status']=='compiled' else 1000000
        method='srl_v2' if cost(s)<1000000 and cost(s)<=cost(n) else 'neural_v2';row=dict(s if method=='srl_v2' else n,selected_method=method)
        row['candidate_outcomes']={k:dict(status=r['status'],code=r.get('code'),diagnostic_cost=cost(r)) for k,r in [('srl_v2',s),('neural_v2',n)]}
        if row['status']!='compiled':
            row['code']='neural:'+str(n.get('code'));row['reason']='; '.join(k+': '+str(r.get('code'))+' — '+str(r.get('reason','')) for k,r in [('srl_v2',s),('neural_v2',n)])
            fail['srl:'+str(s.get('code'))]+=1;fail['neural:'+str(n.get('code'))]+=1
        else:
            counts['compiled']+=1;methods[method]+=1
            meta=row['compilation']['metadata'];counts[meta['kind']]+=1
            if meta['requires_context']:counts['requires_context']+=1
            if not row.get('diagnostics'):counts['no_diagnostic_flags']+=1
            for d in row.get('diagnostics',[]):flags[d['code']]+=1
        rows.append(row)
    counts['all_candidates_refused']=2375-counts['compiled']
    a.output.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    summary=dict(total=2375,attempted=2375,counts=counts,diagnostics=flags,selected_methods=methods,refused_candidate_reasons=fail,
        prolog_syntax_checked=counts['compiled'],interpretation='Within-corpus development census. Fixed diagnostic selection is not a semantic correctness certificate.')
    a.output.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
