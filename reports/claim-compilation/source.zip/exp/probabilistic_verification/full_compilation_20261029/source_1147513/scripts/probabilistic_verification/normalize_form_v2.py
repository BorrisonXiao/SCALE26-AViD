"""Small, source-aligned logical-form normalizations, without sentence rewriting.

Only complete simple dependency noun phrases are split. If any source token is
unaccounted for, the proposed phrase is left intact for diagnostics/review.
"""
import copy,re

MEDIA=re.compile(r'\b(footage|video|videos|clip|clips|photo|photos|photograph|photographs|picture|pictures|image|images|imagery|livestream)\b',re.I)

def normalize_form(text,tokens,proposal):
    form=copy.deepcopy(proposal);notes=[];entities=form.get('entities',[])
    if not all(isinstance(e,dict) and isinstance(e.get('id'),str) and isinstance(e.get('text'),str) for e in entities):return form,notes
    by_id={t['id']:t for t in tokens}
    def fresh(base):
        candidate=base
        while any(e.get('id')==candidate for e in entities):candidate+='x'
        return candidate
    # A phrase such as "eye of the typhoon" contains separate referents. Split
    # only noun/adjective/name/preposition structures with complete token coverage.
    def split_entity(e,depth=0):
        if depth>5 or not isinstance(e.get('text'),str):return
        phrase=e['text'];positions=[m.start() for m in re.finditer(re.escape(phrase),text,re.I)]
        if len(positions)!=1:return
        start=positions[0];end=start+len(phrase)
        ts=[t for t in tokens if start<=t['start_char'] and t['end_char']<=end]
        ids={t['id'] for t in ts};roots=[t for t in ts if t['head'] not in ids]
        if len(roots)!=1 or roots[0].get('upos')!='NOUN':return
        root=roots[0];relations=[t for t in ts if t['head']==root['id'] and t.get('deprel') in {'nmod','obl'}]
        if not relations:return
        if any(t.get('upos') not in {'NOUN','PROPN','ADJ','ADP','DET','PUNCT','NUM','PART'} for t in ts):return
        covered={root['id']};pending=[];properties=[]
        def subtree(tid):
            found={tid};changed=True
            while changed:
                old=len(found);found|={t['id'] for t in ts if t['head'] in found};changed=len(found)!=old
            return found
        for child in relations:
            branch=subtree(child['id']);case=[t for t in ts if t['head']==child['id'] and t.get('deprel')=='case']
            if not case:return
            marker=' '.join(t['text'] for t in case)
            content=[t for t in ts if t['id'] in branch and t['id'] not in {c['id'] for c in case}]
            while content and content[0].get('upos')=='DET':content=content[1:]
            if not content:return
            target_text=text[min(t['start_char'] for t in content):max(t['end_char'] for t in content)]
            existing=[x for x in entities if x is not e and x.get('text','').casefold()==target_text.casefold()]
            target=existing[0] if len(existing)==1 else dict(id=fresh(e['id']+'_n'+str(child['id'])),text=target_text,type='entity')
            pending.append((marker,target));covered|=branch
        for t in ts:
            if t['id'] in covered:continue
            if t.get('upos') in {'DET','PUNCT'}:covered.add(t['id']);continue
            if t['head']==root['id'] and t.get('deprel') in {'amod','compound'}:
                properties.append(dict(role='mod' if t['deprel']=='amod' else 'compound',value=t['text']));covered.add(t['id'])
        if covered!=ids:return
        original=e['text'];e['text']=root['text']
        for p in properties:
            if p not in e.setdefault('properties',[]):e['properties'].append(p)
        for marker,target in pending:
            if target not in entities:entities.append(target)
            relation=dict(role=marker,target=target['id'])
            if relation not in e.setdefault('relations',[]):e['relations'].append(relation)
            split_entity(target,depth+1)
        notes.append(dict(kind='noun_phrase',original=original,head=e['text'],relations=e.get('relations',[])))
    for e in list(entities):split_entity(e)
    # A nominal media complement is content of that source, not a world-level
    # physical participant. Retain its identity and the source's exact noun.
    for e in entities:
        if not MEDIA.search(e.get('text','')):continue
        retained=[]
        for rel in e.get('relations',[]):
            if rel.get('role') in {'of','about','content','depicts','depicting'}:
                e.setdefault('propositions',[]).append(dict(role='content',kind='depiction',route='visual_depiction',body=dict(op='entity',ref=rel['target'])))
                notes.append(dict(kind='nominal_media_content',source=e['id'],content=rel['target']))
            else:retained.append(rel)
        if e.get('relations') is not None:e['relations']=retained
    # Vague mass amounts are attributes, not cardinalities of object groups.
    for e in entities:
        q=e.get('quantity')
        if isinstance(q,dict) and re.search(r'\bamounts?\b',str(q.get('value','')),re.I) and not re.search(r'\d',str(q['value'])) and str(q['value']).casefold() in text.casefold():
            e.setdefault('properties',[]).append(dict(role='amount',value=q['value']));del e['quantity']
            notes.append(dict(kind='mass_amount',entity=e['id'],value=q['value']))
    def head(node):
        anchor=node.get('anchor','')
        found=[t for t in tokens if t['text'].casefold()==anchor.casefold()]
        if len(found)==1:return found[0]
        found=[t for t in tokens if t.get('lemma','').casefold()==node.get('predicate','').casefold()]
        return found[0] if len(found)==1 else None
    def event_body(node):
        while isinstance(node,dict) and node.get('op') in {'not','qualified'}:node=node.get('child',node.get('body'))
        return node if isinstance(node,dict) and node.get('op')=='event' else None
    def temporal(node):
        if not isinstance(node,dict):return
        if node.get('op')=='event':
            parent=head(node)
            for p in node.get('propositions',[]):
                child=event_body(p.get('body'));aligned=head(child) if child else None
                if parent and aligned and aligned.get('head')==parent['id'] and aligned.get('deprel')=='advcl':
                    markers=[t['text'].lower() for t in tokens if t['head']==aligned['id'] and t.get('deprel')=='mark' and t['text'].lower() in {'before','after','while','until','since','when'}]
                    if len(markers)==1:
                        old=(p.get('kind'),p.get('role'));p.update(kind='temporal',role=markers[0],route='unspecified')
                        if old!=('temporal',markers[0]):notes.append(dict(kind='temporal_clause',parent=node['id'],child=child['id'],relation=markers[0]))
                        for role,arg in list(node.get('arguments',{}).items()):
                            if role=='time' and isinstance(arg,dict) and arg.get('value','').casefold()==markers[0]:del node['arguments'][role]
        for value in list(node.values()):
            if isinstance(value,dict):temporal(value)
            elif isinstance(value,list):
                for child in value:temporal(child)
    temporal(form.get('formula'))
    return form,notes
