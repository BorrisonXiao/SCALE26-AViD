"""Targeted source checks motivated by inspected compiler-development failures.

These catch some added qualifiers and type errors. Passing is not a semantic
equivalence proof; lexical licensing is deliberately more limited than parsing.
"""
import re
from .logical_form import LogicalFormError

LICENSES={
 'possible':r'\b(may|might|could|can|possib\w*|potential\w*|perhaps|maybe|uncertain|unclear)\b',
 'likely':r'\b(likely|probably|expect\w*|presum\w*)\b',
 'future':r'\b(will|shall|soon|tomorrow|next|scheduled|expect\w*|plan\w*|intend\w*|before)\b|going to|about to',
 'obligation':r'\b(must|should|need\w*|require\w*|obligat\w*|ought)\b|ha(?:ve|s|d) to',
 'ability':r'\b(can|could|able|ability|capable)\b',
 'condition':r'\b(if|unless|provided|when|without)\b',
 'uncertain':r'\b(uncertain|unclear|unknown|unconfirmed|unverified|apparently|alleged\w*|reportedly|seem\w*|appear\w*)\b'}
CARDINAL=r'(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|trillion|and|[-\s\d,.])+'

def source_checks(text,tokens,form):
    def fail(code,message):raise LogicalFormError(code,message)
    for e in form.get('entities',[]):
        if not isinstance(e,dict):fail('schema','Entities must be objects.')
        q=e.get('quantity')
        if not q:continue
        if not isinstance(q,dict):fail('quantity','Quantity must contain an operator and value.')
        value=str(q.get('value',''))
        if e.get('type')=='context' or re.search(r'\d:\d|\bamounts?\b',value,re.I):
            fail('quantity_type','A time value or amount is not a counted group. Use a typed time/measurement literal or an amount property: '+e.get('text',''))
        if q.get('operator') in {'exact','at_least','more_than','at_most','less_than'} and not re.fullmatch(CARDINAL,value,re.I):
            fail('quantity_type','A numeric group operator needs a cardinal value, not '+value)
    def visit(node):
        if not isinstance(node,dict):return
        if node.get('op')=='qualified':
            op=node.get('operator')
            if op in LICENSES and not re.search(LICENSES[op],text,re.I):
                fail('unlicensed_qualification','The source does not license '+op+' qualification. Do not add a modal/future/conditional event.')
        if node.get('op')=='event':
            predicate=node.get('predicate','');anchor=node.get('anchor','')
            exact=[t for t in tokens if t['text'].casefold()==anchor.casefold()]
            if len(exact)==1 and exact[0].get('upos') in {'ADP','DET','CCONJ','SCONJ','PART'}:
                if predicate.replace('_','-') not in {anchor,'be-'+anchor,'located-'+anchor,'part-'+anchor}:
                    fail('predicate_alignment','A function word does not license this event predicate: '+anchor+' -> '+predicate)
            for role,arg in node.get('arguments',{}).items():
                if role=='agent' and isinstance(arg,dict):
                    fail('literal_role_type','An agent must refer to an entity, not a measurement/text literal.')
                if role=='location' and isinstance(arg,dict) and str(arg.get('value','')).lower() in {'missing','dead','dangerous','safe','closed','open','injured'}:
                    fail('literal_role_type','A state such as '+arg['value']+' is not a location. Keep it as a state/property of its participant.')
                if isinstance(arg,dict) and arg.get('kind')=='verbatim_text':
                    if not re.search('["“”]',text) and re.search(r'\b(that|whether)\b',text,re.I):
                        fail('indirect_verbatim','An indirect report does not certify exact spoken wording. Parse its content as a proposition, without a verbatim-text argument.')
        for value in node.values():
            if isinstance(value,dict):visit(value)
            elif isinstance(value,list):
                for child in value:visit(child)
    visit(form)
