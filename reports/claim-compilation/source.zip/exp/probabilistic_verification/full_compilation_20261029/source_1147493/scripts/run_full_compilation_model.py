#!/usr/bin/env python3
"""Batched local text-only semantic parsing. Never rewrites source sentences."""
import argparse,hashlib,importlib.metadata,json,os,time,shutil
from pathlib import Path
import prompts_phase2 as P
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'

def read(path):return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--input',type=Path,default=RUN/'repaired_inputs.jsonl')
    p.add_argument('--output',type=Path,default=RUN/'neural_raw.jsonl')
    p.add_argument('--limit',type=int)
    p.add_argument('--batch-size',type=int,default=24)
    p.add_argument('--tensor-parallel',type=int,default=1)
    p.add_argument('--max-tokens',type=int,default=2200)
    p.add_argument('--repair-rounds',type=int,choices=(0,1),default=1)
    p.add_argument('--condition',choices=('amr','original-constrained'),default='amr')
    p.add_argument('--pilot-size',type=int,default=0)
    p.add_argument('--continue-file',type=Path)
    a=p.parse_args()
    records=read(a.input);done={r['claim_id'] for r in read(a.output)} if a.output.exists() else set();records=[r for r in records if r['claim_id'] not in done]
    if a.limit:records=records[:a.limit]
    amrs={r['request']['task']['claim_id']:r['raw'] for i in range(4) for r in read(RUN/f'amr_{i}_raw.jsonl')}
    frozen=RUN/('source_'+str(os.getenv('SLURM_JOB_ID','local')));frozen.mkdir(exist_ok=True)
    sources=list((ROOT/'scripts/probabilistic_verification').glob('*.py'))+[Path(__file__),ROOT/'scripts/prompts_phase2.py']
    source_hashes={}
    for source in sources:
        relative=source.relative_to(ROOT);target=frozen/relative;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target);source_hashes[str(relative)]=hashlib.sha256(source.read_bytes()).hexdigest()
    (frozen/'manifest.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
    from vllm import LLM,SamplingParams
    from vllm.sampling_params import StructuredOutputsParams
    model='/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507'
    llm=LLM(model=model,dtype='float16',tensor_parallel_size=a.tensor_parallel,max_model_len=12288,
            gpu_memory_utilization=.90,max_num_seqs=a.batch_size,enable_prefix_caching=True,enforce_eager=True,
            disable_log_stats=False)
    tokenizer=llm.get_tokenizer()
    constrained=a.condition=='original-constrained'
    system=P.FULL_COMPILATION_CONSTRAINED_SYSTEM if constrained else P.FULL_COMPILATION_SYSTEM
    config=dict(model=model,vllm=importlib.metadata.version('vllm'),prompt_version=P.FULL_COMPILATION_CONSTRAINED_VERSION if constrained else P.FULL_COMPILATION_PROMPT_VERSION,
                dtype='float16',temperature=0.,max_tokens=a.max_tokens,slurm_job_id=os.getenv('SLURM_JOB_ID'),
                config_sha256=hashlib.sha256((Path(model)/'config.json').read_bytes()).hexdigest())
    config.update(source_hashes=source_hashes,input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest())
    if constrained:
        from probabilistic_verification.logical_form_schema_v2 import SCHEMA
        structure=StructuredOutputsParams(json=SCHEMA)
    else:structure=StructuredOutputsParams(json_object=True)
    params=SamplingParams(temperature=0,max_tokens=a.max_tokens,structured_outputs=structure)
    def generate(records,output,round_number):
        done={r['claim_id'] for r in read(output)} if output.exists() else set()
        records=[r for r in records if r['claim_id'] not in done]
        for i in range(0,len(records),a.batch_size):
            batch=records[i:i+a.batch_size];requests=[];prompts=[]
            for r in batch:
                messages=[{'role':'system','content':system},{'role':'user','content':P.full_compilation_user(r,None if constrained else amrs.get(r['claim_id']))}]
                prompt=tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
                requests.append(dict(claim_id=r['claim_id'],text=r['text'],messages=messages,config=dict(config,round=round_number)));prompts.append(prompt)
            started=time.perf_counter();outputs=llm.generate(prompts,params,use_tqdm=False);elapsed=time.perf_counter()-started
            with output.open('a') as f:
                for r,request,out in zip(batch,requests,outputs):
                    response=out.outputs[0]
                    f.write(json.dumps(dict(claim_id=r['claim_id'],request=request,request_hash=hashlib.sha256(json.dumps(request,sort_keys=True).encode()).hexdigest(),raw=response.text,
                        output_tokens=len(response.token_ids),finish_reason=response.finish_reason,batch_seconds=elapsed,batch_size=len(batch)),ensure_ascii=False)+'\n')
            print('ROUND',round_number,'BATCH',i+len(batch),len(records),'seconds',round(elapsed,2),'tokens',sum(len(o.outputs[0].token_ids) for o in outputs),flush=True)
    if a.pilot_size:
        generate(records[:a.pilot_size],a.output,0)
        print('PILOT_READY',a.output,'waiting for internal continuation file',a.continue_file,flush=True)
        if not a.continue_file:return
        deadline=time.monotonic()+1800
        while not a.continue_file.exists():
            if time.monotonic()>deadline:raise TimeoutError('No internal continuation instruction after 30 minutes.')
            time.sleep(5)
        if a.continue_file.read_text().strip()!='continue':return
    generate(records,a.output,0)
    if a.repair_rounds:
        from probabilistic_verification.logical_form_v2 import ScopedCompiler
        from probabilistic_verification.compilation_checks_v2 import meaning_diagnostics,needs_reparse
        inputs={r['claim_id']:r for r in read(a.input)};tasks=[]
        for response in read(a.output):
            r=inputs[response['claim_id']]
            try:
                form=json.loads(response['raw']);c=ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],form)
                diagnostics=meaning_diagnostics(r,form,c)
                repair=needs_reparse(diagnostics)
            except Exception as e:
                form=response['raw'];diagnostics=[dict(code=getattr(e,'code',type(e).__name__),details=str(e))];repair=True
            if repair:tasks.append(dict(r,repair_context=dict(previous_parse=form,diagnostics=diagnostics)))
        tasks_path=a.output.with_name(a.output.stem+'_repair_tasks.jsonl')
        tasks_path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in tasks))
        print('REPAIR_TASKS',len(tasks),'one bounded reparse of original text, no sentence rewrite',flush=True)
        generate(tasks,a.output.with_name(a.output.stem+'_repair.jsonl'),1)

if __name__=='__main__':main()
