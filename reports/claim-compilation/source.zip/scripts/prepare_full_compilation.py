#!/usr/bin/env python3
"""Freeze the complete current text inventory; never read evidence labels."""
from pathlib import Path
import json,hashlib,datetime
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
BASE=ROOT/'exp/probabilistic_verification/compilation_audit_20261028'

def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def main():
    inventory=read(BASE/'inventory.jsonl');parses={r['claim_id']:r for r in read(BASE/'current_results.jsonl')}
    srl={r['claim_id']:r for r in read(ROOT/'exp/phase3/srl_baseline/srl_frames.jsonl')}
    assert len(inventory)==len(parses)==len(srl)==2375
    records=[]
    for r in inventory:
        p=parses[r['claim_id']];assert p['text']==r['text']
        records.append(dict(claim_id=r['claim_id'],text=r['text'],tokens=p.get('tokens',[]),srl=srl[r['claim_id']],
                            source_videos=r['source_videos'],development_eligible=r['development_eligible']))
    path=RUN/'inputs.jsonl';content=''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records)
    if path.exists():assert path.read_text()==content
    else:path.write_text(content)
    cached={}
    for dirname,filenames in [('compilation_methods_20261028',['amr_raw.jsonl']),('logical_form_20261028',['holdout_amr_raw.jsonl','final_holdout_amr_raw.jsonl'])]:
        for filename in filenames:
            for r in read(ROOT/'exp/probabilistic_verification'/dirname/filename):
                task=r['request']['task'];cid=task['claim_id']
                if cid in parses and task['text']==parses[cid]['text']:cached[cid]=r
    for i in range(4):
        path=RUN/f'amr_{i}_raw.jsonl'
        if not path.exists():path.write_text(''.join(json.dumps(cached[r['claim_id']],ensure_ascii=False)+'\n' for r in records[i::4] if r['claim_id'] in cached))
    manifest=dict(date='2026-10-29',frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),claims=2375,
                  text_inventory_sha256=hashlib.sha256((BASE/'inventory.jsonl').read_bytes()).hexdigest(),
                  inputs_sha256=hashlib.sha256(content.encode()).hexdigest(),reused_amr_outputs=len(cached),
                  scope='Full-corpus compilation census; not held-out generalization. No media, evidence truth labels or gold_channels read. No LLM sentence rewriting.')
    (RUN/'inventory_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))

if __name__=='__main__':main()
