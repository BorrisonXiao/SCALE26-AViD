#!/usr/bin/env python3
"""Verify that the cache-key fix preserves every single-claim program."""
import hashlib,json,re
from dataclasses import replace
from pathlib import Path
from probabilistic_verification.logical_form_v2 import ScopedCompiler
from probabilistic_verification.logic import Evidence,ground,prolog_program

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
def load(name):return json.loads((RUN/name).read_text())
def read(name):return [json.loads(s) for s in (RUN/name).read_text().splitlines()]

def main():
    before=load('before_scope_namespace_census.json')
    fresh={r['claim_id']:r for r in load('before_scope_namespace.json')}
    inputs={r['claim_id']:r for r in read('repaired_inputs.jsonl')}
    checked=0;fresh_checked=0;changed_hashes=0
    for r in read('results.jsonl'):
        cid=r['claim_id'];old=before[cid]
        for key in ['status','code','diagnostics','selected_method','selected_attempt']:
            assert r.get(key)==old.get(key),(cid,key)
        if r['status']!='compiled':continue
        rec=inputs[cid]
        c=ScopedCompiler().compile(cid,rec['text'],rec['tokens'],r['proposed_form'])
        scopes={s:re.sub(r'::'+re.escape(cid)+r'$', '',s) for s in c.metadata['scopes']}
        renamed=replace(c,atoms=tuple(replace(a,arguments=tuple(scopes.get(arg,arg) for arg in a.arguments)) for a in c.atoms))
        evidence=Evidence('compilation-check',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
        source,_=prolog_program([ground(renamed,evidence,max_expansions=10000)],learned=False)
        assert hashlib.sha256(source.encode()).hexdigest()==old['program_sha256'],cid
        checked+=1;changed_hashes+=r['program_sha256']!=old['program_sha256']
        if cid in fresh:
            serialized=json.dumps(r['compilation'],sort_keys=True,ensure_ascii=False)
            for current,previous in scopes.items():serialized=serialized.replace(current,previous)
            assert serialized==json.dumps(fresh[cid]['compilation'],sort_keys=True,ensure_ascii=False),cid
            fresh_checked+=1
    frozen=load('fresh_review_manifest.json')['source_sha256']
    changed=sorted(p for p,h in frozen.items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h)
    result=dict(all_equal_after_scope_renaming=True,census_cases=len(before),compiled_programs_checked=checked,
        changed_raw_program_hashes=changed_hashes,fresh_cases=len(fresh),fresh_compiled_structures_checked=fresh_checked,
        changed_source_files=changed,reason='Scope IDs now include claim IDs to prevent different claim contexts sharing one evidence-cache entry. Removing only this namespace reproduces every prior single-claim program hash and every fresh compiled structure. Statuses, diagnostics and selections are unchanged. Cross-claim isolation is covered by a native DeepProbLog regression test. IDs are cache lookup identities, not neural input features.')
    (RUN/'scope_namespace_recheck.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
