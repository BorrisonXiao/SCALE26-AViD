#!/usr/bin/env python3
"""Readable review input, with no claims of automatic semantic accuracy."""
import json,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'

def main():
    p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=0);p.add_argument('--end',type=int,default=20);p.add_argument('--fresh',action='store_true');p.add_argument('--previous',action='store_true');a=p.parse_args()
    rows={r['claim_id']:r for r in map(json.loads,(RUN/'results.jsonl').read_text().splitlines())}
    ids=json.loads((RUN/('fresh_review_manifest.json' if a.fresh else 'quality_sample_manifest.json')).read_text())['claim_ids']
    previous={r['claim_id']:r for r in map(json.loads,(RUN/'baseline.jsonl').read_text().splitlines()) if r['method']=='selected'} if a.previous else {}
    for n,cid in enumerate(ids[a.start:a.end],a.start):
        r=rows[cid];print('\nCASE',n,cid,r['status']);print('ORIGINAL:',r['text'])
        print('METHOD:',r.get('selected_method'))
        form=r.get('compilation',{}).get('metadata',{}).get('logical_form',r.get('proposed_form'))
        print('FORM:',json.dumps(form,ensure_ascii=False,separators=(',',':')))
        if r.get('code'):print('REFUSAL:',r['code'],r.get('reason'))
        print('FLAGS:',json.dumps(r.get('diagnostics',[]),ensure_ascii=False))
        if a.previous:
            old=previous[cid];print('PREVIOUS:',old['status'],old.get('code'),json.dumps(old.get('compilation',{}).get('metadata',{}).get('logical_form'),ensure_ascii=False,separators=(',',':')))

if __name__=='__main__':main()
