#!/usr/bin/env python3
"""Keep every sentence in a claim; never replace or rewrite the original text."""
import json
from pathlib import Path
from probabilistic_verification.parsing import DependencyParser
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'

def main():
    records=[json.loads(s) for s in (RUN/'inputs.jsonl').read_text().splitlines()]
    parser=DependencyParser(); repairs=[]
    for r in records:
        if r['tokens']:continue
        doc=parser.pipeline(r['text']);tokens=[]
        for i,sentence in enumerate(doc.sentences):
            offset=len(tokens)
            tokens += [dict(id=w.id+offset,text=w.text,lemma=w.lemma,upos=w.upos,
                head=w.head+offset if w.head else 0,deprel=w.deprel,start_char=w.start_char,
                end_char=w.end_char,feats=w.feats,sentence=i) for w in sentence.words]
        r['tokens']=tokens
        repairs.append(dict(claim_id=r['claim_id'],sentences=len(doc.sentences),tokens=len(tokens)))
    (RUN/'repaired_inputs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records))
    (RUN/'dependency_repairs.json').write_text(json.dumps(dict(repairs=repairs,provenance=parser.provenance),indent=2)+'\n')
    print('Repaired',len(repairs),'claims; total',len(records),flush=True)

if __name__=='__main__':main()
