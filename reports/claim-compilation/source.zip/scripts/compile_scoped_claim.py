#!/usr/bin/env python3
"""Compile a supplied v2 logical form, without loading a language model.

Example: python scripts/compile_scoped_claim.py --record claim.json --form form.json
The record must contain claim_id, text and tokens (an empty token list is allowed
but cannot supply tense/aspect). Output includes predicates and executable ProbLog.
"""
import argparse,json
from pathlib import Path
from probabilistic_verification.logical_form_v2 import ScopedCompiler
from probabilistic_verification.compilation_checks_v2 import meaning_diagnostics
from probabilistic_verification.logic import Evidence,ground,prolog_program

def main():
    p=argparse.ArgumentParser();p.add_argument('--record',type=Path,required=True);p.add_argument('--form',type=Path,required=True);a=p.parse_args()
    r=json.loads(a.record.read_text());f=json.loads(a.form.read_text())
    c=ScopedCompiler().compile(r['claim_id'],r['text'],r.get('tokens',[]),f)
    evidence=Evidence('compilation-check',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
    source,_=prolog_program([ground(c,evidence,max_expansions=10000)],learned=False)
    print(json.dumps(dict(compilation=c.to_dict(),diagnostics=meaning_diagnostics(r,f,c),program=source),indent=2,ensure_ascii=False))

if __name__=='__main__':main()
