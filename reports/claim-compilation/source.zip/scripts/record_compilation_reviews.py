#!/usr/bin/env python3
"""Attach saved assistant judgments to final census rows; never generate labels."""
import hashlib,json
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
def load(name):return json.loads((RUN/name).read_text())
def main():
    records={r['claim_id']:r for r in map(json.loads,(RUN/'results.jsonl').read_text().splitlines())}
    cases=[]
    for cohort,manifest,annotations in [('development','quality_sample_manifest.json','development_review_annotations.json'),('fresh','fresh_review_manifest.json','fresh_review_annotations.json')]:
        m=load(manifest)
        if cohort=='fresh':
            changed=[p for p,h in m['source_sha256'].items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
            if changed:
                quote_check=load('fresh_recheck_after_quote_cleanup.json')
                check=load('scope_namespace_recheck.json')
                assert quote_check['all_equal']
                assert check['all_equal_after_scope_renaming'] and sorted(changed)==check['changed_source_files']
        for a in load(annotations):
            cid=m['claim_ids'][a['index']];r=records[cid]
            assert (r['status']=='compiled')==(a['judgment']!='refused'),(cid,r['status'],a['judgment'])
            cases.append(dict(a,claim_id=cid,text=r['text'],cohort=cohort,compiler_status=r['status'],selected_method=r['selected_method']))
    definitions=dict(faithful='The stated meaning and principal bindings are retained under the stated reading; this includes separately identified mentions. No media truth or independent gold annotation is implied.',
        partial='Some information survives, but a modifier, relation, type, event phase or internal binding is missing/opaque.',
        incorrect='The proposal changes roles, scope, polarity, quantities or asserted events.',
        ambiguous='The original wording admits readings that this text-only review cannot resolve.',
        refused='No selected program; this is separate from a claim being false or unsupported by media.')
    patterns=dict(source_scope='Source content is omitted, flattened or attached to an unsuitable source context.',
        proposition_scope='Purpose, condition, reason or asserted content is assigned the wrong status.',
        role_binding='Who did what to whom, or a source/destination/location, is changed.',
        noun_phrase_binding='A complex noun phrase hides relationships that should be explicit for binding verification.',
        literal_type='Numbers, durations, percentages or quoted words are treated as unsuitable entity/group candidates.',
        omission='A source component is absent from the selected output.',modality_scope='Possibility, ability, prediction, purpose or obligation is lost/added.',
        coordination='Coordinated participants or clauses are not connected with the intended interpretation.',
        temporal_binding='Time values, reference events or ordering relations are missing or misattached.',
        quote_integrity='Exact quoted content is shortened, absent or confused with an indirect report.',
        coreference='Pronouns, possessors or reflexive identities remain hidden or insufficiently linked.',
        quantifier_attachment='A quantifier is attached to the wrong object or loses its distribution.',
        quantifier_strength='A quantity word is weakened to an insufficient numeric/plural condition.',
        proper_name='A name or numeric identifier is treated as an ordinary modifier/count.',
        event_phase='An onset, repetition or phase distinction is omitted.',
        event_state='An event/state description is incompletely represented.',
        event_nominalization='A noun modifier is incorrectly treated as an event, or an event nominal is not resolved.',
        parser_reference_error='A parser-generated entity/event identifier is undeclared.',
        nested_clauses='Nested clauses, control or source complements exceed the current frontend interpretation.',
        missing_context='An omitted or context-dependent argument lacks an explicit interpretation requirement.',
        source_ambiguity='The source wording admits multiple plausible readings.',
        guard_overrefusal='A source guard is narrower than a legitimate construction.',
        modifier_attachment='A modifier is attached to the wrong participant/group.',
        credit_attachment='Image authorship/source credits are mixed with other roles.',
        tokenization='Spacing or tokenization errors corrupt a predicate or identifier.')
    data=dict(protocol='One hundred claim IDs were sampled uniformly from all 2,375 original texts. These became development diagnostics: their review informed late compiler fixes. After freezing the compiler, twenty additional claim IDs, disjoint from those 100 and the initial 24-claim pilot, were sampled and reviewed against both old and new outputs. Two bugfixes followed that review: dead-declaration cleanup motivated by a development quote (all twenty program hashes unchanged), and claim-specific scope IDs to prevent different contexts sharing an evidence-cache entry. The latter changes raw program hashes but preserves every single-claim program after renaming scope IDs; this was checked on all accepted programs and all fresh compiled structures. Fresh statuses, diagnostics, selections and judgments are unchanged. The same assistant judged all cases from text and logical forms, without media/truth labels or independent human gold. Source videos can overlap; this is not a held-out generalization study. Fresh-case counts are descriptive checks, not a full-corpus accuracy estimate.',
        definitions=definitions,pattern_definitions=patterns,cases=cases,
        development_counts=Counter(r['judgment'] for r in cases if r['cohort']=='development'),
        fresh_counts=Counter(r['judgment'] for r in cases if r['cohort']=='fresh'),
        previous_fresh_counts=Counter(r['previous_judgment'] for r in cases if r['cohort']=='fresh'))
    (RUN/'quality_review.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:data[k] for k in ['development_counts','fresh_counts','previous_fresh_counts']},indent=2))
if __name__=='__main__':main()
