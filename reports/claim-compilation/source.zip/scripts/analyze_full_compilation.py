#!/usr/bin/env python3
"""Full-corpus acceptance/error patterns; no estimate of semantic accuracy."""
from collections import Counter,defaultdict
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
def read(name):return [json.loads(s) for s in (RUN/name).read_text().splitlines() if s.strip()]
def main():
    rows=read('results.jsonl');inputs={r['claim_id']:r for r in read('repaired_inputs.jsonl')}
    old={r['claim_id']:r for r in read('baseline.jsonl') if r['method']=='selected'}
    length=defaultdict(Counter);features=defaultdict(Counter);transition=Counter();failures=defaultdict(list)
    for r in rows:
        cid=r['claim_id'];text=r['text'];tokens=inputs[cid]['tokens'];status=r['status'];n=len(text.split())
        bucket='1–10 words' if n<=10 else '11–20 words' if n<=20 else '21–40 words' if n<=40 else '41+ words'
        length[bucket]['total']+=1;length[bucket][status]+=1
        before=old[cid]['status']=='compiled';after=status=='compiled'
        transition[('both_compiled' if before and after else 'newly_compiled' if after else 'previous_only' if before else 'both_refused')]+=1
        flags={
            'Two or more verbal predicates':sum(t.get('upos')=='VERB' for t in tokens)>=2,
            'Coordination':any(t.get('deprel')=='cc' for t in tokens),
            'Numeral':any(t.get('upos')=='NUM' for t in tokens),
            'Pronoun':any(t.get('upos')=='PRON' and t.get('deprel')!='expl' for t in tokens),
            'Explicit quotation':bool(re.search('["“”]',text)),
            'Modal auxiliary':any(t.get('upos')=='AUX' and t.get('lemma') in {'may','might','must','could','should','would','can','will'} for t in tokens),
            'Negation word':bool(re.search(r"\bnot\b|n't\b|\bnever\b",text,re.I))}
        for feature,present in flags.items():
            if present:
                features[feature]['total']+=1;features[feature][status]+=1
                features[feature]['previous_compiled']+=before
        if status!='compiled':failures[r['code']].append(dict(claim_id=cid,text=text,reason=r.get('reason')))
    data=dict(transitions=transition,length_groups=length,overlapping_text_features=features,
              rejection_reasons={k:dict(count=len(v),examples=v[:5]) for k,v in sorted(failures.items(),key=lambda x:-len(x[1]))})
    (RUN/'analysis.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n');print(json.dumps(data['transitions'],indent=2))
if __name__=='__main__':main()
