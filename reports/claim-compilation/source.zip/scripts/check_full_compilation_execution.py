#!/usr/bin/env python3
"""Actual DeepProbLog checks on a deterministic sample, without media scores."""
import argparse,json,random,time,xml.etree.ElementTree as ET,subprocess,sys,tempfile
from pathlib import Path
from probabilistic_verification.logical_form_v2 import ScopedCompiler
from probabilistic_verification.logic import Evidence,ground
from probabilistic_verification.backend import DeepProbLogVerifier
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--single',type=Path);a=ap.parse_args()
    if a.single:
        data=json.loads(a.single.read_text());rec=data['record'];r=data['result']
        c=ScopedCompiler().compile(rec['claim_id'],rec['text'],rec['tokens'],r['proposed_form'])
        evidence=Evidence('no-media',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
        out=DeepProbLogVerifier([ground(c,evidence,max_expansions=10000)],learned=False).predict()[0]
        assert abs(out['distribution']['unknown']-1)<1e-9,out
        print(json.dumps(out));return
    rows=[r for r in read(RUN/'results.jsonl') if r['status']=='compiled']
    inputs={r['claim_id']:r for r in read(RUN/'repaired_inputs.jsonl')}
    small=[r for r in rows if len(r['compilation']['atoms'])<=14]
    sample=random.Random(292026).sample(small,min(16,len(small)))
    # Ensure nested scope, negation, quantities and mentions are executed too.
    chosen={r['claim_id']:r for r in sample}
    for feature in ['proposition','qualification','group_quantity','resolve_reference']:
        found=next((r for r in small if any(a['predicate']==feature for a in r['compilation']['atoms'])),None)
        if found:chosen[found['claim_id']]=found
    outcomes=[];failed=[];start=time.perf_counter()
    with tempfile.TemporaryDirectory(prefix='avid-backend-census-') as tmp:
        for i,r in enumerate(chosen.values()):
            case=Path(tmp)/'case.json';case.write_text(json.dumps(dict(record=inputs[r['claim_id']],result=r)))
            try:
                result=subprocess.run([sys.executable,__file__,'--single',str(case)],capture_output=True,text=True,timeout=15)
                if result.returncode:raise RuntimeError(result.stderr[-1000:])
                out=json.loads(result.stdout.splitlines()[-1]);outcomes.append(out)
            except Exception as e:failed.append(dict(claim_id=r['claim_id'],error=type(e).__name__,message=str(e)))
            print('Backend check',i+1,'/',len(chosen),flush=True)
    tests=ET.parse(RUN/'tests.xml').getroot().find('testsuite')
    data=dict(description='All accepted programs were serialized and parsed by ProbLog. A deterministic 16-case sample restricted to at most 14 predicates, plus uncovered small scope/quantity/reference categories, was attempted with the actual DeepProbLog ExactEngine and a 15-second subprocess limit. An initial unrestricted-size sample was interrupted after a slow case. Every observation is deliberately unknown; no media verdict or full-corpus backend throughput is measured.',
        counts=dict(regression_tests=int(tests.attrib['tests']),regression_failures=int(tests.attrib['failures']),
            all_corpus_claims=2375,accepted_program_syntax_checks=len(rows),actual_deepproblog_attempts=len(chosen),actual_deepproblog_queries=len(outcomes),
            backend_failures_or_timeouts=len(failed),unknown_as_expected=len(outcomes)),cpu_seconds=time.perf_counter()-start,outcomes=outcomes,failures=failed)
    (RUN/'execution_checks.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data['counts'],indent=2))

if __name__=='__main__':main()
