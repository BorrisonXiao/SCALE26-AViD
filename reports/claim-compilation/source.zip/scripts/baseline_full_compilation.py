#!/usr/bin/env python3
"""Full-corpus run of the previous compiler; no code or input changes."""
from pathlib import Path
from collections import Counter
import json,time,argparse,logging
from probabilistic_verification.logical_form import LogicalFormCompiler
from probabilistic_verification.logical_form_adapters import srl_form,amr_form
from probabilistic_verification.compilation_selection import select_attempt
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'

def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def main():
    p=argparse.ArgumentParser();p.add_argument('--srl-only',action='store_true');a=p.parse_args()
    records=read(RUN/'inputs.jsonl');amrs={r['request']['task']['claim_id']:r for i in range(4) for r in read(RUN/f'amr_{i}_raw.jsonl')}
    if not a.srl_only:assert len(amrs)==2375
    output=RUN/('baseline_srl.jsonl' if a.srl_only else 'baseline.jsonl');counts={};logging.getLogger('penman').setLevel(logging.ERROR)
    with output.open('w') as f:
        for n,r in enumerate(records):
            attempts={}
            for method in ['srl'] if a.srl_only else ['srl','amr']:
                row=dict(claim_id=r['claim_id'],text=r['text'],method=method,status='unsupported')
                try:
                    form=srl_form(r) if method=='srl' else amr_form(amrs[r['claim_id']]['raw'],r['text'])
                    c=LogicalFormCompiler().compile(r['claim_id'],r['text'],r['tokens'],form)
                    row.update(status='compiled',compilation=c.to_dict())
                except Exception as e:row.update(code=getattr(e,'code',type(e).__name__),message=str(e))
                attempts[method]=row;counts.setdefault(method,Counter())[row.get('code','compiled')]+=1
                f.write(json.dumps(row,ensure_ascii=False)+'\n')
            if not a.srl_only:
                m=select_attempt(attempts)
                selected=dict(attempts[m],method='selected',selected_method=m) if m else dict(claim_id=r['claim_id'],text=r['text'],method='selected',status='unsupported',code='all_parsers_refused')
                counts.setdefault('selected',Counter())[selected.get('code','compiled')]+=1;f.write(json.dumps(selected,ensure_ascii=False)+'\n')
            if n%100==0:print(n,flush=True)
    (RUN/(output.stem+'_summary.json')).write_text(json.dumps(counts,indent=2)+'\n');print(json.dumps(counts,indent=2))

if __name__=='__main__':main()
