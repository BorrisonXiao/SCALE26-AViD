#!/usr/bin/env python3
"""Reproduce every selected compilation from cached semantic parses on CPU."""
import json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/full_compilation_20261029'

def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def main():
    config=json.loads((RUN/'final_run_manifest.json').read_text())
    with tempfile.TemporaryDirectory(prefix='avid-full-compilation-') as tmp:
        tmp=Path(tmp);neural=tmp/'neural.jsonl';srl=tmp/'srl.jsonl';out=tmp/'replayed.jsonl'
        command=[sys.executable,str(ROOT/'scripts/run_compilation_census.py'),'--raw',str(RUN/config['raw_file']),'--output',str(neural)]
        if config.get('repair_file'):command+=['--repairs',str(RUN/config['repair_file'])]
        subprocess.run(command,cwd=ROOT,check=True)
        subprocess.run([sys.executable,str(ROOT/'scripts/run_srl_v2_census.py'),'--output',str(srl)],cwd=ROOT,check=True)
        subprocess.run([sys.executable,str(ROOT/'scripts/select_full_compilation.py'),'--srl',str(srl),'--neural',str(neural),'--output',str(out)],cwd=ROOT,check=True)
        expected=read(RUN/'results.jsonl');actual=read(out)
        def identity(r):return (r['claim_id'],r['status'],r.get('code'),r['selected_attempt'],r.get('program_sha256'),r.get('diagnostics'))
        assert [identity(r) for r in actual]==[identity(r) for r in expected]
        assert len(actual)==2375
        print('Exact CPU replay: all 2,375 selected outcomes, diagnostics and generated-program hashes match.')

if __name__=='__main__':main()
