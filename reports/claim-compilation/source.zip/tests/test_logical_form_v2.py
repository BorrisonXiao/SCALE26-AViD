"""Regression tests for scope and argument meaning, not just JSON acceptance."""
import copy
import pytest
from probabilistic_verification.logical_form_v2 import ScopedCompiler,parse_form
from probabilistic_verification.logical_form import LogicalFormError
from probabilistic_verification.logic import Evidence,ground,prolog_program

def entity(i,text,**kw):return dict(id=i,text=text,type='entity',**kw)
def event(i,p,args=None,**kw):return dict(op='event',id=i,predicate=p,anchor=p,arguments=args or {},**kw)
def compile(text,entities,node,**kw):
    return ScopedCompiler().compile('test',text,[],dict(version='logical-form-v2',entities=entities,formula=node,**kw))
def walk(e):return [e]+[n for c in e.children for n in walk(c)]
def scoped(a):return a.arguments[a.arguments.index('scope')+1]

def test_speaker_assertion_does_not_become_a_world_event():
    c=compile('narrator say ship arrive',[entity('n','narrator'),entity('s','ship')],
        event('s','say',{'ARG0':'n'},propositions=[dict(role='ARG1',kind='assertion',route='speech_assertion',body=event('a','arrive',{'ARG1':'s'}))]))
    say=next(a for a in c.atoms if a.predicate=='say');arrive=next(a for a in c.atoms if a.predicate=='arrive')
    assert scoped(say)=='world' and scoped(arrive)!='world'
    assert 'speech_assertion' in arrive.arguments and say.arguments[0] in arrive.arguments

def test_criticism_reason_and_controlled_subject_stay_together():
    c=compile('woman criticize students for not help',[entity('w','woman'),entity('s','students')],
        event('c','criticize',{'ARG0':'w','ARG1':'s'},propositions=[dict(role='reason',kind='reason',route='unspecified',body=dict(op='not',child=event('h','help',{'ARG0':'s'})))]))
    help_atom=next(a for a in c.atoms if a.predicate=='help');criticize=next(a for a in c.atoms if a.predicate=='criticize')
    assert scoped(help_atom)!='world'
    assert help_atom.arguments[help_atom.arguments.index('ARG0')+1]==criticize.arguments[criticize.arguments.index('ARG1')+1]
    neg=next(e for e in walk(c.expression) if e.op=='not')
    assert neg.children[0].op=='exists'
    assert help_atom.id in {e.atom_id for e in walk(neg)} and criticize.id not in {e.atom_id for e in walk(neg)}

@pytest.mark.parametrize('kind',['purpose','belief','condition','question','temporal'])
def test_other_proposition_arguments_are_scoped(kind):
    text='Ada plan if Ada leave' if kind=='condition' else 'Ada plan leave'
    c=compile(text,[entity('a','Ada')],event('p','plan',{'ARG0':'a'},propositions=[dict(role=kind,kind=kind,body=event('l','leave',{'ARG0':'a'}))]))
    assert scoped(next(a for a in c.atoms if a.predicate=='leave'))!='world'
    assert any(a.predicate=='proposition' and kind in a.arguments for a in c.atoms)

@pytest.mark.parametrize('operator',['possible','future','obligation','ability'])
def test_qualified_event_is_not_an_unqualified_current_event(operator):
    modal={'possible':'may','future':'will','obligation':'must','ability':'can'}[operator]
    c=compile('ship '+modal+' land',[entity('s','ship')],dict(op='qualified',operator=operator,body=event('l','land',{'ARG1':'s'})))
    assert scoped(next(a for a in c.atoms if a.predicate=='land'))!='world'
    assert any(a.predicate=='qualification' and operator in a.arguments for a in c.atoms)

def test_measurement_literal_is_not_an_entity_candidate():
    c=compile('ship travel at 45 mph',[entity('s','ship')],event('t','travel',{'ARG0':'s','speed':dict(value='45',unit='mph',kind='measurement')}))
    assert len([v for v in c.variables if v.kind=='entity'])==1
    assert 'measurement' in next(a for a in c.atoms if a.predicate=='travel').display()

def test_quantity_operator_and_value_are_executable():
    c=compile('at least two people leave',[entity('p','people',quantity=dict(operator='at_least',value='2'))],event('l','leave',{'ARG0':'p'}))
    assert any(v.kind=='group' for v in c.variables)
    assert any(a.predicate=='group_quantity' and 'at_least' in a.arguments and '2' in a.arguments for a in c.atoms)

def test_pronoun_retains_reference_requirement():
    e=entity('x','she');e['type']='pronoun'
    c=compile('she leave',[e],event('l','leave',{'ARG0':'x'}))
    assert c.metadata['requires_context'] and any(a.predicate=='resolve_reference' for a in c.atoms)

def test_standalone_label_is_a_mention_not_a_person_existence_claim():
    c=compile('FOX News',[entity('f','FOX News')],dict(op='entity',ref='f'),kind='mention')
    assert c.metadata['kind']=='mention' and c.metadata['requires_context']
    assert not [v for v in c.variables if v.kind=='event']

def test_modifiers_are_not_projected_into_a_second_source_scope():
    c=compile('blue boat drift and narrator say boat arrive',[entity('b','boat',properties=[dict(role='mod',value='blue')]),entity('n','narrator')],
        dict(op='and',children=[event('d','drift',{'ARG1':'b'}),event('s','say',{'ARG0':'n'},propositions=[dict(role='ARG1',kind='assertion',route='speech_assertion',body=event('a','arrive',{'ARG1':'b'}))])]))
    blue=[a for a in c.atoms if a.predicate=='property' and 'blue' in a.arguments]
    assert len(blue)==1 and scoped(blue[0])=='world'
    assert any(a.predicate=='reference' and scoped(a)!='world' for a in c.atoms)

def test_exact_quote_is_checked_and_not_asserted_as_a_world_event():
    c=compile('sign read "ship land"',[entity('s','sign')],event('r','read',{'source':'s','content':dict(value='ship land',kind='verbatim_text')}))
    assert not any(a.predicate=='land' for a in c.atoms)
    with pytest.raises(LogicalFormError,match='quote'):
        compile('sign read "ship land"',[entity('s','sign')],event('r','read',{'source':'s','content':dict(value='ship sank',kind='verbatim_text')}))

def test_quoted_words_use_the_declared_ocr_route_in_their_evidence_key():
    c=compile('sign read "ship land"',[entity('s','sign')],event('r','read',{'source':'s','content':dict(value='ship land',kind='verbatim_text')},properties=[dict(role='source_route',value='ocr_assertion')]))
    read_atom=next(a for a in c.atoms if a.predicate=='read')
    assert 'ocr_assertion' in read_atom.arguments
    assert c.metadata['allowed_routes'][read_atom.id]==['ocr_assertion']

def test_unused_entity_is_not_silently_dropped():
    with pytest.raises(LogicalFormError,match='unused'):
        compile('Ada Ben wave',[entity('a','Ada'),entity('b','Ben')],event('w','wave',{'ARG0':'a'}))

def test_noun_phrase_relation_retains_both_bound_participants():
    boat=entity('b','boat',relations=[dict(role='near',target='r')])
    c=compile('boat near bridge carry people',[boat,entity('r','bridge'),entity('p','people')],event('c','carry',{'ARG0':'b','ARG1':'p'}))
    relation=next(a for a in c.atoms if a.predicate=='entity_relation')
    carry=next(a for a in c.atoms if a.predicate=='carry')
    assert relation.arguments[1]=='near' and relation.arguments[0]==carry.arguments[carry.arguments.index('ARG0')+1]
    assert relation.arguments[2]!=relation.arguments[0]

def test_group_members_do_not_become_separate_events():
    group=entity('g','Ada and Ben',relations=[dict(role='member',target='a'),dict(role='member',target='b')])
    group['type']='group'
    c=compile('Ada and Ben meet',[group,entity('a','Ada'),entity('b','Ben')],event('m','meet',{'ARG0':'g'}))
    assert len([a for a in c.atoms if a.predicate=='meet'])==1
    assert len([a for a in c.atoms if a.predicate=='entity_relation'])==2

def test_untranslated_fields_are_rejected_instead_of_silently_dropped():
    n=event('w','wave',{'agent':'a'},unless='Ben arrives')
    with pytest.raises(LogicalFormError,match='Untranslated'):
        compile('Ada wave unless Ben arrives',[entity('a','Ada')],n)

def test_duplicate_json_formula_fields_are_rejected():
    with pytest.raises(LogicalFormError,match='Repeated JSON'):
        parse_form('{"formula":{"op":"not"},"formula":{"op":"event"}}')

def test_added_obligation_is_rejected_for_an_unqualified_death_claim():
    with pytest.raises(LogicalFormError,match='does not license'):
        compile('person die',[entity('p','person')],dict(op='qualified',operator='obligation',body=event('d','die',{'patient':'p'})))

def test_a_time_value_cannot_be_compiled_as_a_group_cardinality():
    t=entity('t','9:49',quantity=dict(operator='exact',value='9:49'));t['type']='context'
    with pytest.raises(LogicalFormError,match='not a counted group'):
        compile('ship hit around 9:49',[entity('s','ship'),t],event('h','hit',{'agent':'s','time':'t'}))

def test_indirect_report_does_not_certify_verbatim_spoken_words():
    with pytest.raises(LogicalFormError,match='indirect report'):
        compile('woman say that ship land',[entity('w','woman')],event('s','say',{'agent':'w','content':dict(kind='verbatim_text',value='ship land')}))

def normalization_case(number):
    import json
    from pathlib import Path
    rs=json.loads((Path(__file__).parent/'fixtures/scoped_normalization_cases.json').read_text())
    r=next(r for r in rs if r['claim_id'].endswith('_'+str(number)))
    return ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],r['form'])

def test_nominal_livestream_content_stays_inside_depiction_scope():
    c=normalization_case(8)
    typhoon=next(a for a in c.atoms if a.predicate=='referent' and 'typhoon' in a.arguments)
    assert scoped(typhoon)!='world' and 'visual_depiction' in typhoon.arguments
    assert any(a.predicate=='share' and scoped(a)=='world' for a in c.atoms)

def test_complete_simple_noun_phrases_are_split_and_off_is_retained():
    c=normalization_case(14)
    assert len([a for a in c.atoms if a.predicate=='entity_relation' and 'of' in a.arguments])==2
    assert any(a.predicate=='property' and 'preposition:location' in a.arguments and 'off' in a.arguments for a in c.atoms)
    assert any('Japan' in a.arguments for a in c.atoms)

def test_mass_amount_is_not_a_count_of_rain_objects():
    c=normalization_case(16)
    assert not any(a.predicate=='group_quantity' for a in c.atoms)
    assert any(a.predicate=='property' and 'amount' in a.arguments and 'large amounts' in a.arguments for a in c.atoms)

def test_source_marked_before_clause_is_temporal_and_not_a_speech_assertion():
    c=normalization_case(18)
    assert any(a.predicate=='proposition' and 'temporal' in a.arguments and 'before' in a.arguments for a in c.atoms)
    assert not any(a.predicate=='proposition' and 'assertion' in a.arguments for a in c.atoms)

def test_unlicensed_if_scope_is_refused_for_an_actual_connection_claim():
    with pytest.raises(LogicalFormError,match='conditional clause'):
        compile('wires connect box',[entity('w','wires'),entity('b','box')],event('i','include',{'theme':'w'},propositions=[dict(role='condition',kind='condition',route='unspecified',body=event('c','connect',{'agent':'w','theme':'b'}))]))

def test_measurement_range_retains_both_bounds_and_its_unit():
    c=compile('wind increase from 10-20 knots',[entity('w','wind'),entity('s','10-20 knots',quantity=dict(operator='exact',value='10'))],event('i','increase',{'theme':'w','source':'s'}))
    assert not any(a.predicate=='group_quantity' for a in c.atoms)
    assert not any(v.kind=='group' for v in c.variables)
    a=next(a for a in c.atoms if a.predicate=='increase')
    assert '10-20' in a.display() and 'knots' in a.display()

def test_inline_source_arguments_receive_types_without_fabricating_entities():
    import json
    from pathlib import Path
    from probabilistic_verification.normalize_form_v2 import normalize_form
    rs=json.loads((Path(__file__).parent/'fixtures/scoped_inline_cases.json').read_text())
    r=rs[0];f,notes=normalize_form(r['text'],r['tokens'],r['form'])
    args=f['formula']['arguments'].values()
    assert any(isinstance(a,dict) and a.get('kind')=='text' and a.get('value')=='emergency response organization' for a in args)
    r=rs[1];f,notes=normalize_form(r['text'],r['tokens'],r['form'])
    assert any(n['kind']=='inline_argument' and n['original']=='violently' and n['target'].get('kind')=='manner' for n in notes if isinstance(n.get('target'),dict))

def test_unused_entities_only_inside_an_exact_quote_are_not_world_assertions():
    c=compile('sign read "Alice smiles"',[entity('s','sign'),entity('a','Alice')],event('r','read',{'source':'s','content':dict(kind='verbatim_text',value='Alice smiles')},properties=[dict(role='source_route',value='ocr_assertion')]))
    assert not any(v.description=='Alice' for v in c.variables)
    assert not any(a.predicate=='smile' for a in c.atoms)
    with pytest.raises(LogicalFormError,match='unused'):
        compile('Alice say "Alice smiles"',[entity('a','Alice')],event('s','say',{'content':dict(kind='verbatim_text',value='Alice smiles')}))
    c=compile('sign read "Alice helps Bob"',[entity('s','sign'),entity('a','Alice',relations=[dict(role='knows',target='b')]),entity('b','Bob')],event('r','read',{'source':'s','content':dict(kind='verbatim_text',value='Alice helps Bob')},properties=[dict(role='source_route',value='ocr_assertion')]))
    assert not any(v.description in {'Alice','Bob'} for v in c.variables)

def test_numeric_identifiers_are_not_counts_and_no_np_is_not_positive():
    import json
    from pathlib import Path
    from probabilistic_verification.srl_form_v2 import srl_form_v2
    rs=json.loads((Path(__file__).parent/'fixtures/srl_v2_source_cases.json').read_text())
    for r in rs[:2]:
        f=srl_form_v2(r);c=ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],f)
        assert not any(a.predicate=='group_quantity' for a in c.atoms)
        assert any('Falcon 9' in v.description or 'Mission 1' in v.description for v in c.variables)
    r=rs[2]
    with pytest.raises(LogicalFormError,match='negation|negative|no-NP'):
        ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],srl_form_v2(r))

def test_different_claim_contexts_do_not_share_a_neural_observation():
    from probabilistic_verification.logic import Observation,canonical_key
    from probabilistic_verification.backend import DeepProbLogVerifier
    programs=[];keys=[]
    for cid,modal,operator,p in [('possible','may','possible',.7),('future','will','future',.2)]:
        form=dict(version='logical-form-v2',kind='claim',entities=[entity('s','ship')],formula=dict(op='qualified',operator=operator,body=event('l','land',{'theme':'s'})))
        c=ScopedCompiler().compile(cid,'ship '+modal+' land',[],form)
        assignment={v.name:v.name.lower() for v in c.variables};observations={}
        for a in c.atoms:
            key=canonical_key('same-media',a,assignment,'visual_depiction')
            distribution=(p,.1,1-p-.1) if a.predicate=='land' else (1.,0.,0.)
            observations[key]=Observation(key,distribution,False,a.text)
            if a.predicate=='land':keys.append(key)
        evidence=Evidence('same-media',{v:[value] for v,value in assignment.items()},{v:True for v in assignment},observations)
        programs.append(ground(c,evidence))
    assert keys[0]!=keys[1]
    out=DeepProbLogVerifier(programs,learned=False).predict()
    assert [r['distribution']['supported'] for r in out]==pytest.approx([.7,.2])

def test_or_has_branch_local_witnesses():
    c=compile('Ada wave or Ben leave',[entity('a','Ada'),entity('b','Ben')],dict(op='or',children=[event('w','wave',{'ARG0':'a'}),event('l','leave',{'ARG0':'b'})]))
    assert c.expression.op=='or' and all(n.op=='exists' for n in c.expression.children)

def test_missing_new_evidence_functions_return_unknown_and_prolog_parses():
    from problog.program import PrologString
    from probabilistic_verification.backend import DeepProbLogVerifier
    c=compile('ship may land',[entity('s','ship')],dict(op='qualified',operator='possible',body=event('l','land',{'ARG1':'s'})))
    evidence=Evidence('none',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
    program=ground(c,evidence);source,_=prolog_program([program],learned=False)
    assert list(PrologString(source))
    result=DeepProbLogVerifier([program],learned=False).predict()[0]
    assert result['distribution']['unknown']==pytest.approx(1.)
