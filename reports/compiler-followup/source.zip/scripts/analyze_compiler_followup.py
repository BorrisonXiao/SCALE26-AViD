#!/usr/bin/env python3
"""Aggregate acceptance, paired assistant reviews and separate model judgments."""
import hashlib,json
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_followup_20261030'
def read(name):return [json.loads(s) for s in (RUN/name).read_text().splitlines() if s.strip()]
def main():
 freeze=json.loads((RUN/'frozen_manifest.json').read_text())
 for p,h in freeze['source_sha256'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 assert hashlib.sha256((RUN/'sample_manifest.json').read_bytes()).hexdigest()==freeze['sample_sha256']
 manifest=json.loads((RUN/'sample_manifest.json').read_text());prior=json.loads((RUN/'prior_sample_manifest.json').read_text())
 rows={m:{r['claim_id']:r for r in read(n)} for m,n in [('baseline','baseline.jsonl'),('revised','results.jsonl')]}
 records={r['claim_id']:r for r in read('inputs.jsonl')}
 assert not set(manifest['previous_review_source_videos'])&set(manifest['evaluation_source_videos'])
 summary={}
 for method,data in rows.items():
  compiled=[r for r in data.values() if r['status']=='compiled'];summary[method]=dict(total=len(data),compiled=len(compiled),refused=len(data)-len(compiled),kinds=Counter(r['compilation']['metadata']['kind'] for r in compiled),failures=Counter(r['code'] for r in data.values() if r['status']!='compiled'))
 transitions=Counter()
 for cid in rows['baseline']:
  a=rows['baseline'][cid]['status']=='compiled';b=rows['revised'][cid]['status']=='compiled';transitions['both_compiled' if a and b else 'new_only' if b else 'previous_only' if a else 'both_refused']+=1
 previous=json.loads((ROOT/'exp/probabilistic_verification/srl_semantics_20261029/quality_review.json').read_text())['cases'];reviews=[]
 updates={
 'TjHepwuhkYFA_1007':('faithful','The definite damage nominal and depicted damage event share one executable variable; the image route and negated clarity are retained.',[]),
 'TFgw4IaR9R8s_1561':('faithful','The tariffs themselves receive the bad economic policy description inside the assertion, without a second policy candidate.',[]),
 'T2G_ACMxR_I4_1303':('faithful','The testing activity and vehicle survive, with an executable strict duration bound of more than one year.',[]),
 'T2G_ACMxR_I4_1245':('partial','The imagery is no longer the person studying. The implicit subject is left unspecified with a context requirement; the remaining descriptions are still complex.',['implicit_subject']),
 'T2G_ACMxR_I4_1243':('partial','The expected remaining duration is typed and scoped, but the sunset/power-loss endpoint remains a literal.',['temporal_endpoint'])}
 def sig(r):
  c=r.get('compilation',{});return r['status'],r.get('code'),{k:c.get(k) for k in ['variables','atoms','expression']}
 old={r['claim_id']:r for r in previous if r['method']=='revised'}
 for i,cid in enumerate(manifest['development_ids']):
  for method in ['baseline','revised']:
   rating=old[cid];judgment=rating['judgment'];note=rating['note'];patterns=rating.get('patterns',[])
   if method=='revised' and cid in updates:judgment,note,patterns=updates[cid]
   elif method=='revised':assert sig(rows['baseline'][cid])==sig(rows['revised'][cid]),cid
   reviews.append(dict(method=method,cohort='development',index=i,claim_id=cid,text=records[cid]['text'],judgment=judgment,note=note,patterns=patterns))
 reviews += [dict(r,text=records[r['claim_id']]['text']) for r in json.loads((RUN/'manual_new_source_review.json').read_text())['cases']]
 reviews += [dict(r,text=records[r['claim_id']]['text']) for r in json.loads((RUN/'newly_accepted_review.json').read_text())['cases']]
 for r in reviews:assert (rows[r['method']][r['claim_id']]['status']=='compiled')==(r['judgment']!='refused'),r
 review_counts={cohort:{method:Counter(r['judgment'] for r in reviews if r['cohort']==cohort and r['method']==method) for method in rows} for cohort in ['development','new_sources','newly_accepted']}
 patterns={method:Counter(p for r in reviews if r['method']==method and r['cohort']=='new_sources' and r['judgment']!='faithful' for p in r['patterns']) for method in rows}
 changes=Counter(n['kind'] for r in rows['revised'].values() for n in r.get('changes',[]))
 data=dict(conditions=summary,transitions=transitions,reviews=review_counts,new_source_failure_patterns=patterns,changes=changes,elapsed_seconds=json.loads((RUN/'results.summary.json').read_text())['elapsed_seconds'],protocol=manifest['protocol'],manual_review_sha256=hashlib.sha256((RUN/'manual_new_source_review.json').read_bytes()).hexdigest())
 (RUN/'quality_review.json').write_text(json.dumps(dict(protocol=manifest['protocol'],cases=reviews),indent=2,ensure_ascii=False)+'\n')
 if (RUN/'model_review_raw.jsonl').exists():
  blind={r['claim_id']:r['methods'] for r in json.loads((RUN/'review_blinding.json').read_text())};model=[];errors=[]
  for row in read('model_review_raw.jsonl'):
   try:
    answer=json.loads(row['raw'])
    for letter,method in blind[row['claim_id']].items():
     rating=answer[letter];assert rating['judgment'] in {'faithful','partial','incorrect','refused'}
     model.append(dict(claim_id=row['claim_id'],method=method,judgment=rating['judgment'],note=rating['reason']))
   except Exception as error:errors.append(dict(claim_id=row['claim_id'],reason=str(error)))
  manual={(r['claim_id'],r['method']):r for r in reviews if r['cohort']=='new_sources'}
  disagreements=[dict(m,manual_judgment=manual[m['claim_id'],m['method']]['judgment'],manual_note=manual[m['claim_id'],m['method']]['note']) for m in model if m['judgment']!=manual[m['claim_id'],m['method']]['judgment']]
  status_mismatches=[m for m in model if (rows[m['method']][m['claim_id']]['status']=='compiled')==(m['judgment']=='refused')]
  data['model_review']=dict(counts={method:Counter(m['judgment'] for m in model if m['method']==method) for method in rows},judgments=len(model),agreements=len(model)-len(disagreements),disagreements=disagreements,status_mismatches=status_mismatches,errors=errors,limitations='Separate frozen Qwen review with randomized anonymous A/B order and no assistant labels. Not human gold or an independent accuracy estimate; retain disagreements without replacing the prewritten assistant judgments.')
  (RUN/'model_review.json').write_text(json.dumps(dict(data['model_review'],cases=model),indent=2,ensure_ascii=False)+'\n')
 (RUN/'analysis.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({k:v for k,v in data.items() if k!='model_review'},indent=2))
if __name__=='__main__':main()
