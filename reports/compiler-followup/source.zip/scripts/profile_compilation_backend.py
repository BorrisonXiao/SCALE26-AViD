#!/usr/bin/env python3
"""Time separate backend stages in a bounded subprocess, preserving timeouts."""
import argparse,json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_followup_20261030'
def stage(name,started,**extra):
 print(json.dumps(dict(stage=name,elapsed_seconds=time.perf_counter()-started,**extra)),flush=True)
def worker(index,mode):
 start=time.perf_counter()
 from check_semantic_srl_logic import make_program
 stage('imports',start)
 start=time.perf_counter();program,expected=make_program(index,counter=True);stage('claim_and_ground',start,observations=len(program.observations),expected=expected)
 start=time.perf_counter()
 from probabilistic_verification.backend import DeepProbLogVerifier
 if mode=='direct':
  from probabilistic_verification.direct_backend import DirectVerifier
  cls=DirectVerifier
 else:cls=DeepProbLogVerifier
 verifier=cls([program],learned=False);stage('model_initialization',start,program_bytes=len(verifier.program))
 start=time.perf_counter();result=verifier.predict()[0];stage('inference',start,result=result)
 assert result['distribution'][expected]>1-1e-9

def main():
 p=argparse.ArgumentParser();p.add_argument('--worker',type=int);p.add_argument('--mode',choices=['previous','direct'],default='previous');p.add_argument('--timeout',type=int,default=35);a=p.parse_args()
 if a.worker is not None:worker(a.worker,a.mode);return
 rows=[]
 for i in [8,10,21]:
  start=time.perf_counter()
  try:
   out=subprocess.run([sys.executable,__file__,'--worker',str(i),'--mode',a.mode],capture_output=True,text=True,timeout=a.timeout)
   stdout=out.stdout;status='passed' if out.returncode==0 else 'error';stderr=out.stderr[-2000:]
  except subprocess.TimeoutExpired as e:stdout=(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else e.stdout or '';stderr='subprocess timeout';status='timeout'
  stages=[json.loads(s) for s in stdout.splitlines() if s.startswith('{')]
  rows.append(dict(index=i,mode=a.mode,status=status,limit_seconds=a.timeout,wall_seconds=time.perf_counter()-start,stages=stages,stderr=stderr))
  (RUN/f'backend_{a.mode}.json').write_text(json.dumps(rows,indent=2)+'\n');print(i,a.mode,status,flush=True)
if __name__=='__main__':main()
