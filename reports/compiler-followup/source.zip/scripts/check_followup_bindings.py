#!/usr/bin/env python3
"""Native inference on stipulated identity and duration counterexamples."""
import itertools,json
from pathlib import Path
from probabilistic_verification.compilation_followup import compile_followup,duration_value,duration_state
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground,combine_states
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_followup_20261030'
def main():
 records={r['claim_id']:r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())};outputs=[]
 for case in ['identity','duration']:
  cid='TjHepwuhkYFA_1007' if case=='identity' else 'T2G_ACMxR_I4_1303';claim,_=compile_followup(records[cid])
  for counter in [False,True]:
   domains={v.name:[v.name.lower()] for v in claim.variables}
   linked=claim.metadata['event_references'][0]['variable'] if case=='identity' else None
   if linked:domains[linked]=['depicted-event','another-event']
   media=f'constructed-{case}-{counter}';observations={}
   for values in itertools.product(*(domains[v.name] for v in claim.variables)):
    assignment=dict(zip([v.name for v in claim.variables],values))
    for atom in claim.atoms:
     state='supported'
     if case=='identity':
      if atom.predicate=='be':state='refuted'
      if atom.predicate=='damage':state='supported' if assignment[linked]=='depicted-event' else 'refuted'
      if atom.predicate=='referent' and atom.arguments[1]=='damage':state='supported' if assignment[linked]==('another-event' if counter else 'depicted-event') else 'refuted'
     elif atom.predicate=='duration':state=duration_state(1 if counter else 2,'year',duration_value('over a year'))
     key=canonical_key(media,atom,assignment,'visual_depiction');observations[key]=Observation(key,tuple(float(s==state) for s in ['supported','refuted','unknown']),False,atom.text,{'source':'stipulated compiler counterexample'})
   program=ground(claim,Evidence(media,domains,{v:True for v in domains},observations),max_expansions=10000)
   def evaluate(expr):
    if expr.op=='constant':return expr.state
    if expr.op=='atom':return ['supported','refuted','unknown'][program.observations[expr.atom_id].distribution.index(1.)]
    return combine_states(expr.op,[evaluate(c) for c in expr.children])
   expected='refuted' if counter else 'supported';assert evaluate(program.expression)==expected
   result=DirectVerifier([program],learned=False).predict()[0];assert result['distribution'][expected]>1-1e-9
   outputs.append(dict(case=case,counterexample=counter,expected=expected,result=result))
 (RUN/'binding_checks.json').write_text(json.dumps(outputs,indent=2)+'\n');print('Four native identity/duration checks match the independent logical calculation.')
if __name__=='__main__':main()
