#!/usr/bin/env python3
"""Exact CPU replay of all compilation results with frozen-source verification."""
import hashlib,json
from run_compiler_followup import ROOT,RUN,read,compile_one

def signature(r):return tuple(r.get(k) for k in ['claim_id','status','code','program_sha256','diagnostics','changes'])
def main():
 f=json.loads((RUN/'frozen_manifest.json').read_text())
 for p,h in f['source_sha256'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 assert hashlib.sha256((RUN/'sample_manifest.json').read_bytes()).hexdigest()==f['sample_sha256']
 expected=read('results.jsonl');actual=[compile_one(r) for r in read('inputs.jsonl')]
 assert [signature(r) for r in actual]==[signature(r) for r in expected]
 print('2375 outcomes, generated-program hashes, diagnostics and compiler changes match.')
 print('Compiler/backend source hashes and pre-reserved sample hashes match.')
if __name__=='__main__':main()
