#!/usr/bin/env python3
"""Independent frozen-model review, blinded to compiler identity and prior labels."""
import hashlib,importlib.metadata,json,os,time
from pathlib import Path
import prompts_phase2 as P
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_followup_20261030'

def main():
 import torch,xgrammar as xgr
 from transformers import AutoTokenizer,AutoModelForCausalLM
 from probabilistic_verification.schema_logits import SchemaLogitsProcessor
 torch.set_num_threads(4);path=Path('/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507')
 tokenizer=AutoTokenizer.from_pretrained(path,local_files_only=True,padding_side='left')
 if tokenizer.pad_token_id is None:tokenizer.pad_token=tokenizer.eos_token
 vocab=json.loads((path/'config.json').read_text())['vocab_size']
 compiler=xgr.GrammarCompiler(xgr.TokenizerInfo.from_huggingface(tokenizer,vocab_size=vocab))
 rating=dict(type='object',properties=dict(judgment=dict(type='string',enum=['faithful','partial','incorrect','refused']),reason=dict(type='string')),required=['judgment','reason'],additionalProperties=False)
 schema=dict(type='object',properties=dict(A=rating,B=rating),required=['A','B'],additionalProperties=False)
 grammar=compiler.compile_json_schema(schema,any_whitespace=False,separators=(',',':'))
 ids=torch.tensor([[0]],device='cuda');smoke=SchemaLogitsProcessor([grammar]);smoke(ids,torch.zeros((1,vocab),device='cuda'));print('GPU schema check passed',flush=True)
 begun=time.perf_counter();model=AutoModelForCausalLM.from_pretrained(path,local_files_only=True,dtype=torch.float16,attn_implementation='sdpa',device_map='auto',max_memory={i:str(int(torch.cuda.get_device_properties(i).total_memory/2**30)-5)+'GiB' for i in range(torch.cuda.device_count())}).eval();load_seconds=time.perf_counter()-begun
 inputs=[json.loads(s) for s in (RUN/'review_inputs.jsonl').read_text().splitlines()]
 config=dict(model=str(path),dtype='float16',temperature=0.,max_new_tokens=384,backend='transformers+xgrammar',transformers=importlib.metadata.version('transformers'),slurm_job_id=os.getenv('SLURM_JOB_ID'),gpu_names=[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())],input_sha256=hashlib.sha256((RUN/'review_inputs.jsonl').read_bytes()).hexdigest(),prompt_sha256=hashlib.sha256(P.COMPILATION_REVIEW_SYSTEM.encode()).hexdigest(),model_config_sha256=hashlib.sha256((path/'config.json').read_bytes()).hexdigest(),load_seconds=load_seconds)
 (RUN/'model_review_config.json').write_text(json.dumps(config,indent=2)+'\n')
 output=RUN/'model_review_raw.jsonl'
 for start in range(0,len(inputs),4):
  batch=inputs[start:start+4];requests=[dict(claim_id=r['claim_id'],messages=[dict(role='system',content=P.COMPILATION_REVIEW_SYSTEM),dict(role='user',content=P.compilation_review_user(r['task']))],config=config) for r in batch]
  prompts=[tokenizer.apply_chat_template(r['messages'],tokenize=False,add_generation_prompt=True) for r in requests]
  encoded=tokenizer(prompts,padding=True,return_tensors='pt').to(model.get_input_embeddings().weight.device);begun=time.perf_counter()
  with torch.inference_mode():outputs=model.generate(**encoded,do_sample=False,max_new_tokens=384,logits_processor=[SchemaLogitsProcessor([grammar]*len(batch))],pad_token_id=tokenizer.pad_token_id)
  elapsed=time.perf_counter()-begun
  with output.open('a') as f:
   for i,(r,request,ids) in enumerate(zip(batch,requests,outputs[:,encoded.input_ids.shape[1]:])):
    ids=ids.tolist()
    if tokenizer.eos_token_id in ids:ids=ids[:ids.index(tokenizer.eos_token_id)]
    text=tokenizer.decode(ids,skip_special_tokens=True)
    f.write(json.dumps(dict(claim_id=r['claim_id'],request=request,raw=text,input_tokens=int(encoded.attention_mask[i].sum()),output_tokens=len(ids),batch_seconds=elapsed,batch_size=len(batch),finish_reason='length' if len(ids)>=384 else 'stop'),ensure_ascii=False)+'\n')
  print('Reviewed',start+len(batch),'/',len(inputs),'seconds',round(elapsed,2),flush=True)
if __name__=='__main__':main()
