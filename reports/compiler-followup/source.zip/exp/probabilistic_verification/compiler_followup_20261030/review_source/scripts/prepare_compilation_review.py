#!/usr/bin/env python3
"""Freeze anonymous A/B review inputs without exposing method names or labels."""
import copy,hashlib,json,random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_followup_20261030'
def main():
 frozen=json.loads((RUN/'frozen_manifest.json').read_text())
 for p,h in frozen['source_sha256'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 rows={m:{r['claim_id']:r for r in map(json.loads,(RUN/n).read_text().splitlines())} for m,n in [('baseline','baseline.jsonl'),('revised','results.jsonl')]}
 sample=json.loads((RUN/'sample_manifest.json').read_text());rng=random.Random(202610305);mapping=[];requests=[]
 for cid in sample['evaluation_ids']:
  order=['baseline','revised'];rng.shuffle(order);task={'claim':rows['baseline'][cid]['text']};methods={}
  for letter,method in zip(['A','B'],order):
   methods[letter]=method;r=rows[method][cid];c=r.get('compilation',{});metadata=c.get('metadata',{})
   form=copy.deepcopy(metadata.get('logical_form'))
   if form:
    form.pop('version',None);form.pop('warnings',None)
   task[letter]=dict(status=r['status'],form=form)
   if r['status']!='compiled':task[letter]['reason']=r.get('reason')
   if metadata.get('event_references'):task[letter]['event_references']=[{k:v for k,v in e.items() if k!='variable'} for e in metadata['event_references']]
   durations=[a['arguments'][:6] for a in c.get('atoms',[]) if a['predicate']=='duration']
   if durations:task[letter]['duration_constraints']=durations
  requests.append(dict(claim_id=cid,task=task));mapping.append(dict(claim_id=cid,methods=methods))
 (RUN/'review_inputs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in requests))
 (RUN/'review_blinding.json').write_text(json.dumps(mapping,indent=2)+'\n')
 print('Prepared',len(requests),'blinded inputs; compiler/source freeze verified.')
if __name__=='__main__':main()
