"""Explicit argument recovery, nominal references and typed duration constraints.

This opt-in revision leaves earlier compilers and their replay artifacts unchanged.
Dependency labels are retained for recovered arguments; PropBank roles are not
guessed from word order. The original record is never modified.
"""
from __future__ import annotations

import copy
import re
from dataclasses import replace

from .logical_form import bind_variables
from .logical_form_v2 import ScopedCompiler
from .representation import Atom, Expression as E, Variable
from .semantic_srl import semantic_srl_form
from .srl_revision import TokenAlignment

TIME_UNITS = {'second', 'minute', 'hour', 'day', 'week', 'month', 'year'}
NUMBERS = dict(zip('zero one two three four five six seven eight nine ten eleven twelve'.split(), range(13)))
RESOURCE_NOUNS = {'image', 'imagery', 'data', 'evidence', 'information', 'tool', 'software', 'video', 'footage', 'recording'}


def walk_events(value):
    if isinstance(value, dict):
        if value.get('op') == 'event':
            yield value
        for item in value.values():
            yield from walk_events(item)
    elif isinstance(value, list):
        for item in value:
            yield from walk_events(item)


def duration_value(text):
    """Return a numeric bound and retain approximation and remaining-duration cues."""
    match = re.fullmatch(
        r'\s*(?P<bound>at least|at most|more than|less than|over|under|about|around|approximately)?\s*'
        r'(?P<number>\d+(?:\.\d+)?|a|an|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)'
        r'\s+(?P<remaining>more\s+)?(?P<unit>seconds?|minutes?|hours?|days?|weeks?|months?|years?)\s*', text, re.I)
    if not match:
        return None
    number = match['number'].lower()
    numeric = str(NUMBERS[number]) if number in NUMBERS else '1' if number in {'a', 'an'} else number
    operator = {'over': 'more_than', 'more than': 'more_than', 'under': 'less_than', 'less than': 'less_than',
                'at least': 'at_least', 'at most': 'at_most', 'about': 'approx', 'around': 'approx',
                'approximately': 'approx', None: 'exact'}[match['bound'].lower() if match['bound'] else None]
    return dict(operator=operator, value=numeric, unit=match['unit'].lower().rstrip('s'),
                reference='remaining' if match['remaining'] else 'total')


def duration_state(value, unit, constraint, *, reference='total', tolerance=None):
    """An optional fixed evidence function; approximation needs an explicit tolerance.

    Values are stipulated observations, not estimates extracted from this corpus.
    Calendar months/years are compared only in the same unit.
    """
    if reference != constraint['reference']:
        return 'unknown'
    unit = unit.lower().rstrip('s')
    target = constraint['unit']
    scales = dict(second=1, minute=60, hour=3600, day=86400, week=604800)
    if unit != target:
        if unit not in scales or target not in scales:
            return 'unknown'
        value *= scales[unit]/scales[target]
    bound = float(constraint['value'])
    operator = constraint['operator']
    if operator == 'approx' and tolerance is None:
        return 'unknown'
    result = {'exact': lambda: value == bound, 'more_than': lambda: value > bound,
              'less_than': lambda: value < bound, 'at_least': lambda: value >= bound,
              'at_most': lambda: value <= bound, 'approx': lambda: abs(value-bound) <= tolerance}[operator]()
    return 'supported' if result else 'refuted'


def followup_srl_form(record):
    r = copy.deepcopy(record)
    alignment = TokenAlignment(r)
    tokens = r['tokens']
    by_id = {t['id']: t for t in tokens}
    children = {t['id']: [u for u in tokens if u['head'] == t['id']] for t in tokens}
    notes = []

    def subtree(tid):
        found, todo = {tid}, [tid]
        while todo:
            for token in children[todo.pop()]:
                if token['id'] not in found:
                    found.add(token['id'])
                    todo.append(token['id'])
        return found

    def argument(role, selected):
        indices = [alignment.word_index(by_id[i]) for i in selected]
        return dict(role=role, start=min(indices), end=max(indices), text=alignment.surface(min(indices), max(indices)))

    def head_of(arg):
        selected = alignment.selected(arg['start'], arg['end'])
        ids = {t['id'] for t in selected}
        heads = [t for t in selected if t['head'] not in ids and t['upos'] not in {'ADP', 'DET', 'PART', 'PUNCT'}]
        return heads[0] if len(heads) == 1 else None

    frames = {}
    for frame in r['srl']['frames']:
        if frame.get('args') and frame.get('verb_span'):
            selected = alignment.selected(*frame['verb_span'])
            if len(selected) == 1:
                frames[selected[0]['id']] = frame

    # A missing finite/relative frame can be recovered only when a grammatical
    # participant is explicit, or when a verbal conjunct has one shared subject.
    for token in tokens:
        tid = token['id']
        if tid in frames or token['upos'] != 'VERB' or token['deprel'] == 'amod':
            continue
        participants = [u for u in children[tid] if u['deprel'].startswith('nsubj') or u['deprel'] in {'obj', 'iobj', 'obl:agent'}]
        if not any(u['deprel'].startswith('nsubj') for u in participants) and token['deprel'] == 'conj':
            participants += [u for u in children.get(token['head'], []) if u['deprel'].startswith('nsubj')]
        if not participants or token['deprel'] not in {'root', 'conj', 'ccomp', 'csubj', 'advcl', 'acl', 'acl:relcl'}:
            continue
        if any(u['deprel'] == 'cc' and u['lemma'].lower() == 'or'
               for participant in participants for u in tokens if u['id'] in subtree(participant['id'])):
            continue  # The current nominal-group translation would turn OR into AND.
        args = [argument(u['deprel'], subtree(u['id'])) for u in participants]
        if not args:
            continue
        for u in children[tid]:
            if u['deprel'].startswith('obl') and u not in participants:
                args.append(argument(u['deprel'], subtree(u['id'])))
            if u['text'].lower() in {'not', "n't", 'never'}:
                args.append(argument('ARGM-NEG', {u['id']}))
            if u['deprel'] == 'aux' and u['text'].lower() in {'may', 'might', 'can', 'could', 'will', 'shall', 'must', 'should', 'would'}:
                args.append(argument('ARGM-MOD', {u['id']}))
        frame = dict(verb=token['text'], verb_span=[alignment.word_index(token)] * 2, args=args)
        r['srl']['frames'].append(frame)
        frames[tid] = frame
        notes.append(dict(kind='recovered_frame', predicate=token['text'], roles=[a['role'] for a in args], basis='explicit dependency participants'))

    # In resource-subject "help study" clauses, SRL sometimes copies the resource
    # into the implicit human subject. Remove that unlicensed binding. This does
    # not invent a researcher or certify an otherwise missing subject identity.
    for tid, frame in frames.items():
        token = by_id[tid]
        parent = by_id.get(token['head'])
        if token['deprel'] != 'xcomp' or not parent or parent['lemma'].lower() != 'help':
            continue
        if any(u['deprel'].startswith('nsubj') for u in children[tid]):
            continue
        subjects = [u for u in children[parent['id']] if u['deprel'].startswith('nsubj') and u['lemma'].lower() in RESOURCE_NOUNS]
        bad = [arg for arg in frame['args'] if arg['role'] == 'ARG0' and head_of(arg) in subjects]
        if bad:
            frame['args'] = [arg for arg in frame['args'] if arg not in bad]
            notes.append(dict(kind='implicit_subject', predicate=token['text'], removed_resource=subjects[0]['text'],
                              basis='resource-subject help construction; embedded actor unspecified'))

    form, earlier = semantic_srl_form(r)
    notes = earlier + notes
    entities = {e['id']: e for e in form['entities']}
    events = list(walk_events(form))
    negative_events = set()
    def negated(value, negative=False):
        if isinstance(value, dict):
            if value.get('op') == 'not':
                negated(value['child'], not negative)
                return
            if negative and value.get('op') == 'event':
                negative_events.add(value['id'])
            for item in value.values():
                negated(item, negative)
        elif isinstance(value, list):
            for item in value:
                negated(item, negative)
    negated(form['formula'])

    def replace_ref(value, old, new):
        if isinstance(value, dict):
            for key, item in list(value.items()):
                if key in {'id', 'text', 'value', 'predicate', 'anchor'}:
                    continue
                if item == old:
                    value[key] = new
                else:
                    replace_ref(item, old, new)
        elif isinstance(value, list):
            for item in value:
                replace_ref(item, old, new)

    # Bare common-noun predicates with adjectives, e.g. "tariffs are bad policy".
    # Definite, proper-name, numeric and prepositional equatives are left intact.
    consumed = set()
    for event in events:
        if event['predicate'] != 'be' or event['id'] in negative_events:
            continue
        subject = event['arguments'].get('ARG1')
        complement = event['arguments'].get('ARG2')
        if not isinstance(subject, str) or not isinstance(complement, str) or subject == complement:
            continue
        nominal = entities.get(complement)
        tid = int(complement[1:]) if complement.startswith('x') and complement[1:].isdigit() else None
        token = by_id.get(tid)
        if not nominal or not token or token['upos'] != 'NOUN':
            continue
        dependents = children[tid]
        if any(u['deprel'] in {'det', 'case', 'nummod'} for u in dependents):
            continue
        if not any(u['upos'] == 'ADJ' and u['deprel'] == 'amod' for u in dependents):
            continue
        target = entities[subject]
        for key in ('properties', 'relations', 'propositions'):
            target.setdefault(key, []).extend(nominal.get(key, []))
        event['arguments']['ARG2'] = dict(kind='text', value=nominal['text'])
        replace_ref(form, complement, subject)
        form['entities'].remove(nominal)
        entities.pop(complement)
        notes.append(dict(kind='bare_predication', subject=subject, description=nominal['text']))

    for event in events:
        frame_id = int(event['id'][1:]) if event['id'].startswith('e') and event['id'][1:].isdigit() else None
        frame = frames.get(frame_id)
        for role, value in list(event['arguments'].items()):
            arg = next((a for a in frame['args'] if a['role'] == role), None) if frame else None
            raw = arg['text'] if arg else value.get('value', '') if isinstance(value, dict) else ''
            if arg:
                head = head_of(arg)
                if head and head['lemma'].lower() in TIME_UNITS:
                    selected = alignment.selected(arg['start'], arg['end'])
                    case = [u for u in children[head['id']] if u['deprel'] == 'case' and u not in selected]
                    if case:
                        raw = ' '.join(u['text'] for u in case) + ' ' + raw
            duration = duration_value(raw)
            if duration:
                if isinstance(value, str):
                    consumed.add(value)
                event['arguments'][role] = dict(kind='duration', value=raw, unit=duration['unit'])
                notes.append(dict(kind='duration', event=event['id'], role=role, source=raw, **duration))

    # A definite event noun can refer back only to one matching earlier event.
    # This deliberately does not solve cross-sentence or ambiguous event coreference.
    for eid, entity in entities.items():
        tid = int(eid[1:]) if eid.startswith('x') and eid[1:].isdigit() else None
        token = by_id.get(tid)
        if not token or token['upos'] != 'NOUN' or not any(u['deprel'] == 'det' and u['lemma'].lower() == 'the' for u in children[tid]):
            continue
        antecedents = [e for e in events if e['predicate'] == token['lemma'].lower() and e['id'][1:].isdigit() and int(e['id'][1:]) < tid]
        if len(antecedents) == 1:
            notes.append(dict(kind='event_reference', mention=eid, event=antecedents[0]['id'],
                              basis='unique earlier matching event and definite nominal'))

    # Remove declarations consumed as typed literals, retaining all reachable data.
    reachable = set()
    def references(value):
        if isinstance(value, dict):
            if value.get('op') == 'entity':
                reachable.add(value['ref'])
            if value.get('op') == 'event':
                reachable.update(v for v in value['arguments'].values() if isinstance(v, str))
            for item in value.values():
                references(item)
        elif isinstance(value, list):
            for item in value:
                references(item)
    references(form['formula'])
    visited = set()
    while reachable - visited:
        pending = reachable - visited
        visited |= pending
        for eid in pending:
            entity = entities[eid]
            reachable.update(rel['target'] for rel in entity.get('relations', []))
            references(entity.get('propositions', []))
    form['entities'] = [e for e in form['entities'] if e['id'] in reachable or e['id'] not in consumed]
    notes = [n for n in notes if n['kind'] != 'event_reference' or n['mention'] in reachable]
    if any(n['kind'] == 'implicit_subject' for n in notes):
        form['requires_context'] = True
    return form, notes


def compile_followup(record):
    form, notes = followup_srl_form(record)
    claim = ScopedCompiler().compile(record['claim_id'], record['text'], record['tokens'], form,
        additional_proposition_kinds={'relative', 'complement', 'prediction', 'concession'})
    atoms = list(claim.atoms)
    metadata = copy.deepcopy(claim.metadata)
    expression = claim.expression
    replacements = {}
    for note in notes:
        if note['kind'] != 'duration':
            continue
        for event_id, event in metadata['events'].items():
            if event['id'] != note['event']:
                continue
            atom = next(a for a in atoms if a.predicate == event['predicate'] and a.arguments[0] == event_id)
            args = (event_id, note['role'], note['operator'], note['value'], note['unit'], note['reference'])
            suffix = atom.arguments[atom.arguments.index('scope'):]
            extra = Atom('a'+str(len(atoms)+1), 'duration', args+suffix, 'duration', (), note['source'], (), False)
            atoms.append(extra)
            metadata['allowed_routes'][extra.id] = metadata['allowed_routes'][atom.id]
            replacements.setdefault(atom.id, []).append(E.atom(extra.id))
    def expand(expr):
        if expr.op == 'atom' and expr.atom_id in replacements:
            return E.combine('and', [expr, *replacements[expr.atom_id]])
        return replace(expr, children=tuple(expand(c) for c in expr.children))
    expression = expand(expression)
    aliases = {}
    links = []
    for note in notes:
        if note['kind'] != 'event_reference':
            continue
        nominal = next((v for v, e in metadata['entities'].items() if e['id'] == note['mention']), None)
        events = [v for v, e in metadata['events'].items() if e['id'] == note['event']]
        if nominal and len(events) == 1:
            aliases[nominal] = events[0]
            links.append(dict(mention=note['mention'], event=note['event'], variable=events[0]))
    variables = claim.variables
    if aliases:
        affected = set(aliases) | set(aliases.values())
        atoms = [replace(a, arguments=tuple(aliases.get(x, x) for x in a.arguments)) for a in atoms]
        def unbind(expr):
            children = tuple(unbind(c) for c in expr.children)
            remaining = tuple(v for v in expr.variables if v not in affected)
            if expr.op == 'exists' and not remaining:
                return children[0]
            return replace(expr, children=children, variables=remaining)
        variables = tuple(v for v in variables if v.name not in aliases)
        expression = bind_variables(unbind(expression), atoms, [v for v in variables if v.name in affected])
        for old, new in aliases.items():
            metadata['entities'][new] = metadata['entities'].pop(old)
    metadata['event_references'] = links
    metadata['compiler_changes'] = notes
    metadata['runtime_requirements'] += ['implicit embedded subject'] if any(n['kind'] == 'implicit_subject' for n in notes) else []
    return replace(claim, variables=variables, atoms=tuple(atoms), expression=expression, metadata=metadata), notes
