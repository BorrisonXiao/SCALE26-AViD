"""Meaning checks for the new opt-in compiler and equivalent state encoding."""
import copy
import json
from pathlib import Path

import pytest

from probabilistic_verification.compilation_followup import compile_followup, duration_value, duration_state
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import GroundProgram, Observation, enumerate_probability, ground, Evidence, combine_states
from probabilistic_verification.representation import Expression as E

RUN = Path(__file__).resolve().parents[1]/'exp/probabilistic_verification/compiler_followup_20261030'
RECORDS = {r['claim_id']: r for r in map(json.loads, (RUN/'inputs.jsonl').read_text().splitlines())}


def test_damage_nominal_and_depicted_event_share_a_variable():
    claim, _ = compile_followup(RECORDS['TjHepwuhkYFA_1007'])
    link = claim.metadata['event_references'][0]
    event = link['variable']
    referents = [a for a in claim.atoms if a.predicate == 'referent' and a.arguments[1] == 'damage']
    assert len(referents) == 1 and referents[0].arguments[0] == event
    damage = next(a for a in claim.atoms if a.predicate == 'damage')
    assert damage.arguments[0] == event
    evidence = Evidence('binding', {v.name: [v.name.lower()] for v in claim.variables}, {v.name: True for v in claim.variables}, {})
    program = ground(claim, evidence, max_expansions=10000)
    assert all(event not in occurrence['predicate'] or event in occurrence['assignment'] for occurrence in program.occurrences)


def test_duration_bound_and_prediction_scope_survive():
    claim, _ = compile_followup(RECORDS['T2G_ACMxR_I4_1303'])
    atom = next(a for a in claim.atoms if a.predicate == 'duration')
    assert atom.arguments[2:6] == ('more_than', '1', 'year', 'total')
    claim, _ = compile_followup(RECORDS['T2G_ACMxR_I4_1243'])
    atom = next(a for a in claim.atoms if a.predicate == 'duration')
    assert atom.arguments[2:6] == ('approx', '4', 'day', 'remaining')
    assert atom.arguments[atom.arguments.index('scope')+1] != 'world'
    assert 'until sunset and loss of power' in json.dumps(claim.metadata['logical_form'])


def test_bare_policy_predication_stays_in_the_assertion():
    claim, _ = compile_followup(RECORDS['TFgw4IaR9R8s_1561'])
    assert not any(v.description == 'policy' for v in claim.variables)
    bad = next(a for a in claim.atoms if a.predicate == 'property' and 'bad' in a.arguments)
    assert bad.arguments[bad.arguments.index('scope')+1] != 'world'
    assert any(v.description == 'tariffs' for v in claim.variables)


def test_resource_is_not_the_implicit_person_studying():
    claim, _ = compile_followup(RECORDS['T2G_ACMxR_I4_1245'])
    study = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'study')
    assert 'ARG0' not in study['arguments']
    assert claim.metadata['requires_context']
    assert 'implicit embedded subject' in claim.metadata['runtime_requirements']


def test_duration_parser_does_not_turn_dates_or_multiple_values_into_bounds():
    assert duration_value('March 14') is None
    assert duration_value('four days and five nights') is None
    assert duration_value('at most two hours')['operator'] == 'at_most'


def test_duration_bound_is_executable_without_assuming_calendar_or_approximation_rules():
    bound = duration_value('over a year')
    assert duration_state(1, 'year', bound) == 'refuted'
    assert duration_state(2, 'years', bound) == 'supported'
    assert duration_state(13, 'months', bound) == 'unknown'
    approximate = duration_value('about four more days')
    assert duration_state(4, 'day', approximate) == 'unknown'
    assert duration_state(4, 'day', approximate, reference='remaining') == 'unknown'
    assert duration_state(4, 'day', approximate, reference='remaining', tolerance=.5) == 'supported'


def test_original_records_unchanged():
    source = RECORDS['T2G_ACMxR_I4_1303']
    before = copy.deepcopy(source)
    compile_followup(source)
    assert source == before


@pytest.mark.parametrize('op', ['and', 'or', 'evidence'])
def test_native_probabilities_match_exhaustive_worlds_with_shared_observations(op):
    a, b = Observation('shared-a', (.3, .2, .5), False, 'a'), Observation('shared-b', (.6, .1, .3), False, 'b')
    left, right = E.atom(a.id), E.atom(b.id)
    paired = E(op, (left, right))
    # Repeated a occurs both outside and inside the composed expression.
    expression = E.combine('or', [E.combine('and', [paired, left]), E.negate(right)])
    program = GroundProgram('test-'+op, expression, {a.id: a, b.id: b}, [], [])
    expected = enumerate_probability(program)
    actual = DirectVerifier([program], learned=False).predict()[0]['distribution']
    assert actual == pytest.approx(expected, abs=1e-10)


def test_native_gradient_is_preserved():
    from probabilistic_verification.backend import DeepProbLogVerifier
    a = Observation('learned-gradient', (.4, .3, .3), True, 'a')
    p = GroundProgram('gradient', E.atom(a.id), {a.id: a}, [], [])
    gradients = []
    for cls in (DeepProbLogVerifier, DirectVerifier):
        v = cls([p], learned=True)
        query = v.query('gradient', 'supported')
        result = v.model.solve([query])[0].result[query.query]
        (-result.log()).backward()
        gradients.append(v.classifier.layers[-1].weight.grad.detach().clone())
    import torch
    assert torch.allclose(gradients[0], gradients[1], atol=1e-10)
    assert torch.isfinite(gradients[1]).all() and gradients[1].norm() > 0
