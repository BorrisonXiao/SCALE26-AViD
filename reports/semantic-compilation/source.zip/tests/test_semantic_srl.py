"""Meaning-based regression checks on real claims and manual reference graphs."""
import copy,json
from pathlib import Path
import pytest
from probabilistic_verification.semantic_srl import semantic_srl_form
from probabilistic_verification.logical_form_v2 import ScopedCompiler
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/srl_semantics_20261029'
RECORDS={r['claim_id']:r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())}
MANIFEST=json.loads((RUN/'sample_manifest.json').read_text())
def rec(index):return RECORDS[MANIFEST['development_ids'][index]]
def compiled(index):
 r=rec(index);form,_=semantic_srl_form(r)
 return ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],form,additional_proposition_kinds={'relative','complement','prediction','concession'})

def test_registration_is_bound_to_the_named_vessel():
 c=compiled(10);names={v.description:v.name for v in c.variables};target=names['Mississippi']
 be=next(e for e in c.metadata['events'].values() if e['predicate']=='be')
 reg=next(e for e in c.metadata['events'].values() if e['predicate']=='register')
 assert be['arguments']['ARG1']==reg['arguments']['ARG1']
 assert not any(v.description=='vessel' for v in c.variables)
 assert any(a.predicate=='property' and target in a.arguments and 'cargo' in a.arguments for a in c.atoms)

def test_depicted_damage_never_escapes_the_image():
 c=compiled(21);damage=next(e for e in c.metadata['events'].values() if e['predicate']=='damage')
 assert damage['scope']!='world' and damage['route']=='visual_depiction'
 scope=c.metadata['scopes'][damage['scope']]
 assert c.metadata['scopes'][scope['parent']]['kind']=='depiction'
 assert any(e['predicate']=='be' and e['scope']=='world' for e in c.metadata['events'].values())

def test_forecast_keeps_modifiers_and_time_inside_prediction():
 c=compiled(17);rain=next(v for v in c.variables if v.description=='rain')
 atoms=[a for a in c.atoms if rain.name in a.arguments]
 assert all('world' not in a.arguments[a.arguments.index('scope')+1:a.arguments.index('scope')+2] for a in atoms)
 assert not any(e['predicate'] in {'localize','follow'} for e in c.metadata['events'].values())
 assert any('following' in a.arguments for a in c.atoms)

def test_spatial_complement_is_a_graph_not_a_string():
 c=compiled(23);names={v.description for v in c.variables}
 assert {'Mare Crisium','quadrant','side','moon'}<=names
 assert any(a.predicate=='property' and 'northeast' in a.arguments for a in c.atoms)
 assert any(a.predicate=='property' and 'near' in a.arguments for a in c.atoms)
 assert sum(a.predicate=='entity_relation' for a in c.atoms)>=2

def test_robot_not_observers_is_embedded_subject():
 c=compiled(8);form=c.metadata['logical_form'];e=next(e for e in c.metadata['events'].values() if e['predicate']=='perform')
 robot=next(x['id'] for x in form['entities'] if x['text']=='robot')
 assert e['arguments']['nsubj']==robot and e['scope']!='world'
 assert e['route']=='visual_depiction'

def test_unknown_control_is_refused_instead_of_assuming_subject():
 r=copy.deepcopy(rec(8));r['text']=r['text'].replace('watching','wanting ')
 t=next(t for t in r['tokens'] if t['text']=='watching');t.update(text='wanting ',lemma='want')
 r['srl']['words'][2]='wanting '
 f=next(f for f in r['srl']['frames'] if f['verb']=='watching');f['verb']='wanting '
 from probabilistic_verification.logical_form import LogicalFormError
 with pytest.raises(LogicalFormError,match='controller'):semantic_srl_form(r)

def test_complete_reference_forms_serialize_without_frontend_parsing():
 from problog.program import PrologString
 from probabilistic_verification.logic import Evidence,ground,prolog_program
 refs=json.loads((RUN/'reference_forms.json').read_text())['references']
 assert len(refs)==24
 for r in refs:
  record=RECORDS[r['claim_id']]
  c=ScopedCompiler().compile(r['claim_id'],r['text'],record['tokens'],r['form'],additional_proposition_kinds={'relative','complement','prediction','concession'})
  e=Evidence('reference',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
  p,_=prolog_program([ground(c,e,max_expansions=10000)],learned=False);assert list(PrologString(p))

def test_reference_validation_does_not_mutate_original_claims():
 for i in [8,10,17,21,22,23]:
  r=rec(i);before=copy.deepcopy(r);semantic_srl_form(r);assert r==before
