#!/usr/bin/env python3
"""Compile every original claim using one revised semantic SRL pipeline."""
import argparse,hashlib,json,time
from pathlib import Path
from collections import Counter
from problog.program import PrologString
from probabilistic_verification.semantic_srl import semantic_srl_form
from probabilistic_verification.logical_form_v2 import ScopedCompiler
from probabilistic_verification.compilation_checks_v2 import meaning_diagnostics
from probabilistic_verification.logic import Evidence,ground,prolog_program
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/srl_semantics_20261029'
def read(name):return [json.loads(x) for x in (RUN/name).read_text().splitlines() if x.strip()]
def compile_one(r,form=None):
 row=dict(claim_id=r['claim_id'],text=r['text'],status='unsupported')
 try:
  notes=[]
  if form is None:form,notes=semantic_srl_form(r)
  row.update(proposed_form=form,changes=notes)
  c=ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],form,additional_proposition_kinds={'complement','relative','prediction','concession'})
  evidence=Evidence('compilation-check',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
  source,_=prolog_program([ground(c,evidence,max_expansions=10000)],learned=False);assert list(PrologString(source))
  row.update(status='compiled',compilation=c.to_dict(),program=source,program_sha256=hashlib.sha256(source.encode()).hexdigest(),diagnostics=meaning_diagnostics(r,form,c))
 except Exception as e:row.update(code=getattr(e,'code',type(e).__name__),reason=str(e))
 return row

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--development',action='store_true');ap.add_argument('--output',type=Path,default=RUN/'results.jsonl');a=ap.parse_args()
 records=read('inputs.jsonl')
 if a.development:
  ids=json.loads((RUN/'sample_manifest.json').read_text())['development_ids'];records=[r for r in records if r['claim_id'] in ids]
 start=time.perf_counter();rows=[compile_one(r) for r in records]
 a.output.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 s=dict(total=len(rows),counts=Counter('compiled' if r['status']=='compiled' else r['code'] for r in rows),kinds=Counter(r['compilation']['metadata']['kind'] for r in rows if r['status']=='compiled'),cpu_seconds=time.perf_counter()-start)
 a.output.with_suffix('.summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
if __name__=='__main__':main()
