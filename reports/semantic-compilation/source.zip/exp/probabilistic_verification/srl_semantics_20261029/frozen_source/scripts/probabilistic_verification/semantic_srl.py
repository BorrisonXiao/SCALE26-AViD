"""Semantic SRL compilation: source context, predication and explicit controllers.

Original text/records are never changed. A copied dependency analysis can resolve
an explicit control link; unlicensed missing arguments are refused, not guessed.
"""
import copy
from .logical_form import LogicalFormError
from .srl_revision import TokenAlignment
from .srl_graph import srl_graph_form

OBJECT_CONTROL={'watch','see','hear','observe','persuade','force','allow','tell','ask','enable','let'}
SUBJECT_CONTROL={'try','attempt','aim','plan','hope','promise','agree','refuse','intend','decide'}

def semantic_srl_form(record):
    r=copy.deepcopy(record);a=TokenAlignment(r);tokens=r['tokens'];by_id=a.by_id
    children={t['id']:[u for u in tokens if u['head']==t['id']] for t in tokens}
    notes=[]
    def head(ts):
        ids={t['id'] for t in ts};roots=[t for t in ts if t['head'] not in ids]
        content=[t for t in roots if t['upos'] not in {'DET','ADP','PART','PUNCT','SCONJ','CCONJ'}]
        return content[0] if len(content)==1 else roots[0] if len(roots)==1 else None
    def descendants(t):
        ids={t['id']};todo=[t]
        while todo:
            for c in children[todo.pop()['id']]:
                if c['id'] not in ids:ids.add(c['id']);todo.append(c)
        return [u for u in tokens if u['id'] in ids]
    frames={}
    for f in r['srl']['frames']:
        if f.get('args') and isinstance(f.get('verb_span'),list):
            ts=a.selected(*f['verb_span']);h=head(ts)
            if h:frames[h['id']]=f
    # Explicitly enhanced subjects, then a small declared set of lexical control
    # classes. Unknown verbs receive no universal subject-control assumption.
    for t in tokens:
        if t['deprel']!='xcomp' or t['upos']!='VERB':continue
        parent=by_id.get(t['head']);f=frames.get(t['id']);pf=frames.get(t['head'])
        if not parent or not pf:continue
        if f and any(x['role'] in {'ARG0','ARG1'} for x in f['args']):continue
        controllers=[];basis=''
        for u in tokens:
            deps=u.get('deps') or ''
            if isinstance(deps,str) and any(d.startswith(str(t['id'])+':nsubj') for d in deps.split('|')):controllers.append(u);basis='enhanced dependency'
        p=parent.get('lemma',parent['text']).lower()
        if not controllers and p in OBJECT_CONTROL:
            controllers=[u for u in children[parent['id']] if u['deprel'] in {'obj','iobj'}];basis='object-control frame'
        if not controllers and p in SUBJECT_CONTROL:
            controllers=[u for u in children[parent['id']] if u['deprel'].startswith('nsubj')];basis='subject-control frame'
        if len(controllers)!=1:
            if not f:raise LogicalFormError('unresolved_controller','Embedded predicate has no explicit or licensed controller: '+t['text'])
            continue
        controller=controllers[0];ts=[u for u in descendants(controller) if u['id']!=t['id'] and u['upos'] not in {'PUNCT'}]
        if not ts:ts=[controller]
        inds=[a.word_index(u) for u in ts];arg=dict(role='nsubj:pass' if 'Voice=Pass' in (t.get('feats') or '') or any(u['deprel']=='aux:pass' for u in children[t['id']]) else 'nsubj',start=min(inds),end=max(inds),text=a.surface(min(inds),max(inds)))
        if not f:
            f=dict(verb=t['text'],verb_span=[a.word_index(t)]*2,args=[]);r['srl']['frames'].append(f);frames[t['id']]=f
            for u in children[t['id']]:
                if u['deprel']=='obj':
                    us=descendants(u);ii=[a.word_index(v) for v in us];f['args'].append(dict(role='ARG1',start=min(ii),end=max(ii),text=a.surface(min(ii),max(ii))))
        f['args'].insert(0,arg);notes.append(dict(kind='controller',predicate=t['text'],participant=controller['text'],basis=basis))
    # Preserve productive possessives/near-side phrases when the tokenizer or
    # dependency parser labels their pieces as compounds/case markers.
    for t in tokens:
        if t['text'].endswith(("'s",'’s')) and t['deprel']=='compound':t['deprel']='nmod:poss'
        if t['text'].lower() in {'near','far'} and t['deprel']=='case' and by_id[t['head']]['lemma'].lower()=='side':t.update(deprel='amod',upos='ADJ')
    form=srl_graph_form(r,semantic_arguments=True)
    entities={e['id']:e for e in form['entities']}
    def replace_refs(x,old,new):
        if isinstance(x,dict):
            for key,value in list(x.items()):
                if key not in {'id','text','value','anchor','predicate'}:
                    if value==old:x[key]=new
                    else:replace_refs(value,old,new)
        elif isinstance(x,list):
            for item in x:replace_refs(item,old,new)
    def visit(n):
        if not isinstance(n,dict):return
        if n.get('op')=='event' and n['predicate']=='be':
            args=n['arguments'];s=args.get('ARG1');v=args.get('ARG2');comp=entities.get(v) if isinstance(v,str) else None
            fid=int(n['id'][1:]) if n['id'].startswith('e') and n['id'][1:].isdigit() else None
            f=frames.get(fid)
            c_arg=next((x for x in f['args'] if x['role']=='ARG2'),None) if f else None
            ts=a.selected(c_arg['start'],c_arg['end']) if c_arg else []
            h=head(ts) if ts else None
            if isinstance(s,str) and s!=v and comp and h and h['upos']=='NOUN' and not any(u['deprel']=='case' for u in children[h['id']]) and any(u['text'].lower() in {'a','an'} and u['deprel']=='det' for u in children[h['id']]):
                # Predicational is: the named subject has the nominal type and
                # all its modifiers. No second vessel/person candidate is made.
                target=entities[s]
                for key in ['properties','relations','propositions']:
                    target.setdefault(key,[]).extend(comp.get(key,[]))
                args['ARG2']=dict(kind='text',value=comp['text'])
                replace_refs(form,v,s);form['entities'].remove(comp);entities.pop(v)
                notes.append(dict(kind='predication',subject=s,description=comp['text']))
        for key,value in list(n.items()):
            if key not in {'entities'}:
                if isinstance(value,dict):visit(value)
                elif isinstance(value,list):
                    for item in value:visit(item)
    visit(form['formula'])
    inherit_routes(form)
    form.setdefault('warnings',[]).append('Semantic SRL pass: source arguments retain their context; nominal predication shares its subject; missing controllers require explicit or declared lexical evidence.')
    return form,notes

def inherit_routes(form):
    """An unspecified nested route inherits its containing evidence context."""
    entities={e['id']:e for e in form.get('entities',[])};seen=set()
    def walk(n,route='unspecified'):
        if not isinstance(n,dict):return
        if n.get('op')=='entity':entity(n['ref'],route)
        if n.get('op')=='event':
            for value in n.get('arguments',{}).values():
                if isinstance(value,str):entity(value,route)
        for p in n.get('propositions',[]):
            if p.get('route','unspecified')=='unspecified':p['route']=route
            walk(p['body'],p['route'])
        for key in ['child','body']:
            if key in n:walk(n[key],route)
        for child in n.get('children',[]):walk(child,route)
    def entity(eid,route):
        if eid not in entities or (eid,route) in seen:return
        seen.add((eid,route));e=entities[eid]
        for rel in e.get('relations',[]):entity(rel['target'],route)
        walk(e,route)
    walk(form.get('formula'))
    return form
