#!/usr/bin/env python3
"""Manually specified reference readings, not derived from compiler predictions."""
import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/srl_semantics_20261029'
def ent(i,text,mods=(),relations=(),**kwargs):
 e=dict(id=i,text=text,type='entity');e.update(kwargs)
 if mods:e['properties']=[dict(role='mod',value=m) for m in mods]
 if relations:e['relations']=[dict(x) if isinstance(x,dict) else dict(role=x[0],target=x[1]) for x in relations]
 return e

def ev(i,p,anchor,args=None,props=(),subs=()):
 n=dict(op='event',id=i,predicate=p,anchor=anchor,arguments=args or {})
 if props:n['properties']=[dict(role=r,value=v) for r,v in props]
 if subs:n['propositions']=[dict(role=r,kind=k,route=route,body=b) for r,k,route,b in subs]
 return n

def noun(i):return dict(op='entity',ref=i)
def both(*ns):return dict(op='and',children=list(ns))
def neg(n):return dict(op='not',child=n)
def qual(op,n):return dict(op='qualified',operator=op,body=n)
def val(v,kind='text'):return dict(value=v,kind=kind)

def main():
 m=json.loads((RUN/'sample_manifest.json').read_text());inputs={r['claim_id']:r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())};refs=[]
 def add(index,entities,formula,note='',ambiguous=False):
  cid=m['development_ids'][index];form=dict(version='logical-form-v2',kind='claim',entities=entities,formula=formula)
  if ambiguous:form.update(requires_context=True,warnings=[note])
  refs.append(dict(index=index,claim_id=cid,text=inputs[cid]['text'],form=form,reading_note=note,ambiguous=ambiguous))
 add(0,[ent('map','map',('2021',)),ent('seats','seats',('NDP','more','many'),type='group'),ent('lib','Liberal')],
     both(ev('show','show','shows',{'ARG0':'map'},subs=[('ARG1','depiction','visual_depiction',noun('seats'))]),ev('change','go','gone',{'ARG1':'seats','ARG2':'lib'},[('time','since')])),
     'Assumes the many seats changed party after the mapped result. The comparison baseline for more and the exact map/relative-clause scope need context.',True)
 add(1,[ent('f','Footage'),ent('w','The Weather Channel')],ev('r','rebroadcast','rebroadcast',{'ARG1':'f','ARG0':'w'}))
 add(2,[ent('i','image'),ent('c','Charles Tupper')],ev('s','show','Shows',subs=[('ARG1','depiction','visual_depiction',noun('i'))]),
     'The image depicts Charles Tupper and has the source credit Elliott and Fry/Library and Archives Canada. The slash does not uniquely identify authorship versus archive roles.',True)
 refs[-1]['form']['entities'][0].update(propositions=[dict(role='content',kind='depiction',route='visual_depiction',body=noun('c'))],properties=[dict(role='credit',value='Elliott and Fry/Library and Archives Canada')])
 add(3,[ent('t','thrusters',type='group'),ent('d','descent',('final',))],ev('b','burn','Burning',{'ARG1':'t','time':'d'},[('preposition:time','in')]))
 add(4,[ent('m','Music'),ent('s','ship')],ev('p','play','plays',{'ARG0':'m'},subs=[('as','temporal','unspecified',ev('sail','sail','sail',{'ARG0':'s'}))]),
     'Assumes ship sail means that a ship is sailing; the source is grammatically incomplete.',True)
 add(5,[ent('a','appeals',('Trump',),[('to','f')],type='group'),ent('f','International Trade Foundation'),ent('c','Supreme Court',relations=[('possessor','p')]),ent('p','their',type='pronoun')],
     qual('future',qual('likely',ev('g','go','go',{'ARG1':'a','ARG2':'c'},[('preposition:ARG2','to')]))))
 add(6,[ent('r','Referee'),ent('c','count'),ent('f','fight')],both(ev('stop','stop','stops',{'ARG0':'r','ARG1':'c'}),ev('start','start','starts',{'ARG0':'r','ARG1':'f','ARGM-TMP':val('again','time')})))
 add(7,[ent('i','image'),ent('c','Carney'),ent('p','podium'),ent('it','it',type='pronoun'),ent('l','leaf',('maple',),[('possessor','can')]),ent('can','Canada')],
     ev('show','show','Shows',subs=[('ARG1','depiction','visual_depiction',noun('i'))]))
 refs[-1]['form']['entities'][0]['propositions']=[dict(role='content',kind='depiction',route='visual_depiction',body=ev('stand','stand','standing',{'ARG0':'c','location':'p'},[('preposition:location','at')]))]
 refs[-1]['form']['entities'][2].update(relations=[dict(role='with',target='l')],propositions=[dict(role='acl:relcl',kind='relative',route='unspecified',body=ev('say','say','says',{'ARG0':'p','ARG1':val('Liberal','verbatim_text'),'location':'it'},[('source_route','ocr_assertion'),('preposition:location','on')]))])
 add(8,[ent('p','People',type='group'),ent('r','robot')],ev('watch','watch','watching',{'ARG0':'p'},subs=[('ARG1','depiction','visual_depiction',ev('perform','perform','perform',{'ARG0':'r'}))]))
 add(9,[ent('p','protest'),ent('f','front',relations=[('of','n')]),ent('n','National Palace')],ev('occur','take_place','taking',{'ARG1':'p','location':'f'},[('preposition:location','in')]))
 add(10,[ent('s','Mississippi',('cargo',)),ent('m','Madeira')],both(ev('be','be','is',{'ARG1':'s','ARG2':val('vessel')}),ev('reg','register','registered',{'ARG1':'s','ARG2':'m'})))
 add(11,[ent('s','sound',('helicopter',))],ev('be','be','is',{'ARG1':'s'}))
 add(12,[ent('r','routes',('multiple','possible'),type='group'),ent('s','spacecrafts',type='group'),ent('m','Moon')],ev('be','be','are',{'ARG1':'r'}))
 refs[-1]['form']['entities'][0]['propositions']=[dict(role='acl:relcl',kind='relative',route='unspecified',body=qual('ability',ev('take','take','take',{'ARG0':'s','ARG1':'r','ARGM-GOL':'m'},[('preposition:ARGM-GOL','to')])))]
 add(13,[ent('s','sound',('Combustion',)),ent('r','rocket')],ev('sound','sound','sound',{'theme':'s'},subs=[('as','temporal','unspecified',ev('d','descent','descents',{'theme':'r'}))]),'Assumes descents denotes the rocket descending and as indicates concurrency.',True)
 add(14,[ent('c','contestants',('Miss Tourism World',),type='group'),ent('t','Shaolin Temple'),ent('k','Kung Fu')],ev('v','visit','visited',{'ARG0':'c','ARG1':'t'},subs=[('ARGM-PRP','purpose','unspecified',ev('learn','learn','learn',{'ARG0':'c','ARG1':'k'}))]))
 add(15,[ent('e','eruptions',('geyser-like',),type='group'),ent('p','pressure',('high',),[('from','f')]),ent('f','flooding',relations=[('in','d')]),ent('d','Dongguan')],ev('cause','cause','caused',{'ARG1':'e','ARG0':'p'}))
 add(16,[ent('b','Blue Ghost'),ent('o','orbit',('low','lunar'))],ev('enter','enter','entered',{'ARG0':'b','ARG1':'o'},subs=[('Prior to','temporal','unspecified',ev('land','land','landing',{'ARG1':'b'}))]))
 add(17,[ent('r','rain',('heaviest','localized'),[('time','d')]),ent('d','day',('following',)),ent('regions','regions and mountain areas',type='group',relations=[dict(role='member',target='south'),dict(role='member',target='mount')]),ent('south','regions',('southern',),type='group'),ent('mount','areas',('mountain',),type='group')],ev('predict','predict','predicted',{'ARGM-GOL':'regions'},[('preposition:ARGM-GOL','for')],subs=[('ARG1','assertion','unspecified',noun('r'))]))
 # relations accepted by ent() above use pair tuples, so set the group explicitly.
 add(18,[ent('h','Haboob'),ent('o','operations',('airport',),type='group')],qual('possible',ev('impact','impact','impact',{'ARG0':'h','ARG1':'o'})))
 add(19,[ent('b','Blue Ghost'),ent('i','imagery',('high-definition',)),ent('e','eclipse',('total','Earth')),ent('earth','Earth'),ent('sun','Sun'),ent('moon','Moon')],
     ev('schedule','schedule','scheduled',{'ARG1':'b'},[('time','Before mission end')],subs=[('ARG2','purpose','unspecified',ev('capture','capture','capture',{'ARG0':'b','ARG1':'i','time':val('on March 14','date')}))]))
 refs[-1]['form']['entities'][1]['propositions']=[dict(role='content',kind='depiction',route='visual_depiction',body=noun('e'))]
 refs[-1]['form']['entities'][2]['propositions']=[dict(role='where',kind='relative',route='unspecified',body=ev('block','block','blocks',{'ARG0':'earth','ARG1':'sun'},subs=[('as viewed','depiction','visual_depiction',ev('view','view','viewed',{'ARG1':'earth','source':'moon'}))]))]
 add(20,[ent('b','building'),ent('f','floors',relations=[('including','bottom')],type='group',quantity=dict(operator='exact',value='6')),ent('bottom','floor',('bottom',))],ev('have','have','has',{'ARG0':'b','ARG1':'f'}))
 add(21,[ent('i','image',('satellite',)),ent('a','areas',('residential',),type='group'),ent('n','nature',relations=[('of','d')]),ent('d','damage')],both(
     ev('show','show','shows',{'ARG0':'i'},subs=[('ARG1','depiction','visual_depiction',noun('a'))]),
     neg(ev('clear','be','is',{'ARG1':'n','ARG2':val('very clear')}))))
 refs[-1]['form']['entities'][1]['propositions']=[dict(role='amod',kind='relative',route='unspecified',body=ev('damage','damage','damaged',{'ARG1':'a','state':'d'}))]
 add(22,[ent('l','landing',('moon',),[('possessor','im')]),ent('im','IM')],ev('be','be','was',{'ARG1':'l','ARG2':val('nailbiter')}))
 add(23,[ent('m','Mare Crisium'),ent('q','quadrant',('northeast',),[('of','side')]),ent('side','side',('near',),[('possessor','moon')]),ent('moon','moon')],ev('be','be','is',{'ARG1':'m','ARG2':'q'},[('preposition:ARG2','in')]))
 refs.sort(key=lambda r:r['index']);assert len(refs)==24
 (RUN/'reference_forms.json').write_text(json.dumps(dict(author='Assistant manual specification from original text, audited during development and frozen before fresh review. Not independent human gold.',references=refs),indent=2,ensure_ascii=False)+'\n')
 print('Wrote 24 manual reference readings.')
if __name__=='__main__':main()
