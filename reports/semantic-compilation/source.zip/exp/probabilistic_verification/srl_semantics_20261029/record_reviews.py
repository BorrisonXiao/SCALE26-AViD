"""Saved assistant judgments after inspecting original texts and both graphs."""
import json
from pathlib import Path
RUN=Path(__file__).resolve().parent;OLD=RUN.parent/'srl_revision_20261029'
base=[dict(r) for r in json.loads((OLD/'srl_review_annotations.json').read_text()) if r['method']=='trained_srl']
new=[]
fixes={8:('faithful','The robot is explicitly linked as the embedded subject, while the people remain watchers.'),10:('faithful','Vessel type, cargo modifier and registration all constrain the named Mississippi referent.'),14:('faithful','The complete Miss Tourism World name is preserved as one modifier; visit/learn share contestants in purpose scope.'),17:('faithful','Rain, degree/localization and following-day description remain inside prediction; regions retain their group/member structure.'),21:('partial','Depicted damage now remains inside the image, and the negated clarity concession is separate. The nominal damage being qualified is not explicitly equated to that depicted state.'),22:('faithful','IM is an explicit possessor of the moon-landing referent; nailbiter is a predicative value.'),23:('faithful','Location, northeast quadrant, near side and Moon possession are explicit linked conditions.')}
for r in base:
 a=dict(r,cohort='development',method='revised')
 if r['index'] in fixes:a['judgment'],a['note']=fixes[r['index']];a['patterns']=[] if a['judgment']=='faithful' else ['event_nominal_reference']
 new.append(a)
rows=[dict(r,cohort='development',method='baseline') for r in base]+new
old_fresh=[
('incorrect','The mast is treated as a location alongside the surface rather than another deployed object; the deck relationship is absent.',['role_binding','coordination','omission']),
('faithful','Promoter, promoted temple, success and perfect aspect are retained.',[]),
('faithful','Named speaker and complete exact utterance remain linked; quoted events are not world assertions.',[]),
('faithful','Recording of this video and its night-time condition survive.',[]),
('incorrect','The imagery is made the actor conducting the study, rather than a resource helping an unspecified researcher.',['role_binding','control']),
('refused','The crowd/cheering clauses remain unresolved.',['clause_attachment']),
('refused','No usable SRL frame or nominal root for the cloud/storm description.',['missing_srl']),
('partial','First occurrence and fourth mandate survive as text/modifiers without explicit event-history bindings.',['temporal_binding','ordinal']),
('incorrect','The named LISTER and the developed/powered drill are different referents, so their identity is not enforced.',['identity']),
('faithful','The protesting group and full exact chant are retained.',[]),
('refused','The credited predicate is missing from the linked SRL graph.',['missing_predicate']),
('faithful','The protesters are shared across the coordinated waving and blowing events.',[]),
('partial','The over-a-year duration is represented by a year entity/preposition, without a typed duration bound.',['literal_type']),
('refused','Nested podium, rally and sweatshirt clauses remain unlinked.',['clause_attachment']),
('incorrect','Bad economic policy is required outside Axelrod\'s asserted content; the actual tariffs need not be bad policy.',['source_scope']),
('refused','The blame/reason complement cannot be attached.',['clause_attachment']),
('faithful','The protesting group and three repeated Mexico tokens remain one exact utterance.',[]),
('faithful','Passive sharing retains this video and the complete ABC 7 name.',[]),
('partial','The deals/policy noun-phrase structure is missing although the main significance/reason relationship survives.',['noun_phrase_binding','omission']),
('partial','Expectation and shared mission survive, but four days is a counted group rather than a typed duration, and the ending condition stays opaque.',['literal_type','temporal_binding'])]
new_fresh=list(old_fresh)
new_fresh[8]=('faithful','LISTER is the single referent for drill classification, gas power and development; the university/company remain explicit group members.',[])
new_fresh[14]=('partial','Bad economic policy now stays within Axelrod\'s assertion, but the bare mass-noun copular complement still uses a separate policy referent.',['copular_identity'])
for method,labels in [('baseline',old_fresh),('revised',new_fresh)]:
 for index,(judgment,note,patterns) in enumerate(labels):rows.append(dict(method=method,cohort='fresh',index=index,judgment=judgment,note=note,patterns=patterns))
(RUN/'review_annotations.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
