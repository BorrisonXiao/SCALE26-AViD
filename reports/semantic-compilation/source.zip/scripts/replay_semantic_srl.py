#!/usr/bin/env python3
"""Reproduce the semantic SRL census and reference compilation on cached inputs."""
import hashlib
import json
from pathlib import Path

from run_semantic_srl_census import RUN, ROOT, compile_one, read


def identity(row):
    return tuple(row.get(k) for k in ('claim_id', 'status', 'code', 'program_sha256', 'diagnostics'))


def main():
    frozen = json.loads((RUN / 'frozen_manifest.json').read_text())
    for name, digest in frozen['source_sha256'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    assert hashlib.sha256((RUN / 'reference_forms.json').read_bytes()).hexdigest() == frozen['reference_sha256']
    inputs = read('inputs.jsonl')
    expected = read('results.jsonl')
    actual = [compile_one(row) for row in inputs]
    assert [identity(r) for r in actual] == [identity(r) for r in expected]
    print(f'{len(actual)} compilation outcomes, program hashes and diagnostics match.')
    by_id = {r['claim_id']: r for r in inputs}
    references = json.loads((RUN / 'reference_forms.json').read_text())['references']
    outputs = [compile_one(by_id[r['claim_id']], r['form']) for r in references]
    assert all(r['status'] == 'compiled' for r in outputs), [(r['claim_id'], r.get('reason')) for r in outputs if r['status'] != 'compiled']
    saved = json.loads((RUN / 'reference_compilation.json').read_text())
    assert [identity(r) for r in outputs] == [identity(r) for r in saved]
    print(f'{len(outputs)} manually specified reference forms compile independently of SRL.')
    from check_semantic_srl_logic import make_program
    for index in (8, 10, 17, 21):
        for reference in (False, True):
            for counter in (False, True):
                _, state = make_program(index, reference, counter)
                assert state == ('refuted' if counter else 'supported')
    for index in (10, 17, 21):
        assert make_program(index, counter=True, baseline=True)[1] == 'supported'
    print('16 constructed logical checks and 3 baseline counterexamples match. Native inference is separate.')


if __name__ == '__main__':
    main()
