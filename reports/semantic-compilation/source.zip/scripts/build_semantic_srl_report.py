#!/usr/bin/env python3
"""Publish the bounded semantic SRL revision without rewriting earlier archives."""
import hashlib
import json
import shutil
import zipfile
from html import escape
from pathlib import Path

from build_srl_compilation_report import STYLE
from probabilistic_verification.srl_revision import TokenAlignment

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/srl_semantics_20261029'
SITE = ROOT / 'site'
OUT = SITE / 'reports/semantic-compilation'
NAMES = {'baseline': 'Prior SRL compiler', 'revised': 'Revised SRL compiler',
         'reference': 'Manual reference reading (24 development cases)'}
STYLE += '.filters>label{min-width:0;max-width:100%}.filters select{width:100%}'


def load(name):
    return json.loads((RUN / name).read_text())


def read(name):
    return [json.loads(s) for s in (RUN / name).read_text().splitlines() if s.strip()]


def build_cases():
    reviews = {(r['method'], r['claim_id']): r for r in load('quality_review.json')['cases']}
    references = {r['claim_id']: r for r in load('reference_forms.json')['references']}
    rows = {m: {r['claim_id']: r for r in records} for m, records in [
        ('baseline', read('baseline.jsonl')), ('revised', read('results.jsonl')),
        ('reference', load('reference_compilation.json'))]}
    sample = load('sample_manifest.json')
    with_program = set(sample['development_ids'] + sample['fresh_ids'])
    cases = []
    for r in read('inputs.jsonl'):
        alignment = TokenAlignment(r)
        outputs = {}
        for method, records in rows.items():
            if r['claim_id'] not in records:
                continue
            row = records[r['claim_id']]
            compilation = row.get('compilation', {})
            outputs[method] = dict(status=row['status'], code=row.get('code'), reason=row.get('reason'),
                form=compilation.get('metadata', {}).get('logical_form', row.get('proposed_form')),
                diagnostics=row.get('diagnostics'), edits=row.get('changes'),
                predicates=[x['id']+' · '+x['predicate']+'('+', '.join(x['arguments'])+')' for x in compilation.get('atoms', [])],
                program=row.get('program') if r['claim_id'] in with_program else None,
                review=reviews.get((method, r['claim_id'])),
                reference_note=references.get(r['claim_id']) if method == 'reference' else None)
        cases.append(dict(claim_id=r['claim_id'], text=r['text'], srl=r['srl'], outputs=outputs,
            cohort='development' if r['claim_id'] in sample['development_ids'] else 'fresh' if r['claim_id'] in sample['fresh_ids'] else None,
            tokens=[dict(id=t['id'], text=t['text'], head=t['head'], deprel=t['deprel'], upos=t['upos'], index=alignment.word_index(t)) for t in r['tokens']]))
    (OUT / 'cases.json').write_text(json.dumps(cases, ensure_ascii=False, separators=(',', ':'))+'\n')


def archive():
    files = list((ROOT / 'scripts/probabilistic_verification').glob('*.py'))
    tests = ['semantic_srl', 'srl_graph', 'logical_form_v2', 'logical_form', 'predicate_compilation',
             'semantic_compiler', 'multimodal_verification', 'probabilistic_verification']
    files += [ROOT / f'tests/test_{name}.py' for name in tests]
    files += list((ROOT / 'tests/fixtures').glob('*.json'))
    files += [ROOT / 'scripts' / name for name in ['run_semantic_srl_census.py', 'create_semantic_references.py',
        'replay_semantic_srl.py', 'check_semantic_srl_logic.py', 'analyze_semantic_srl.py',
        'build_semantic_srl_report.py', 'build_srl_compilation_report.py', 'prompts_phase2.py',
        'compile_verification_claim.py', 'run_verification_pipeline.py']]
    files += [ROOT / 'scripts/report_assets/semantic_compilation.js', ROOT / 'docs/semantic_srl_compilation.md',
              ROOT / 'requirements-compilation.txt', ROOT / 'requirements-verification.txt']
    files += [p for p in RUN.rglob('*') if p.is_file() and p.suffix in {'.json', '.jsonl', '.xml', '.py'}
              and p.name not in {'publication.json', 'archive_verification.json', 'browser_checks.json'}]
    contents = {str(p.relative_to(ROOT)): p.read_bytes() for p in files}
    contents['README.md'] = (ROOT / 'docs/semantic_srl_compilation.md').read_bytes()
    contents['SHA256SUMS'] = ('\n'.join(hashlib.sha256(data).hexdigest()+'  '+name
                                      for name, data in sorted(contents.items()))+'\n').encode()
    with zipfile.ZipFile(OUT / 'source.zip', 'w', zipfile.ZIP_DEFLATED) as target:
        for name, data in sorted(contents.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 29, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            target.writestr(info, data)


def main():
    OUT.mkdir(exist_ok=True)
    s = load('analysis.json')
    refs = load('reference_forms.json')['references']
    sample = load('sample_manifest.json')
    number = 0

    def table(headers, rows, caption):
        nonlocal number
        number += 1
        return '<div class="table-wrap"><table><caption>Table '+str(number)+'. '+escape(caption)+'</caption><thead><tr>'+''.join('<th>'+escape(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'

    def example(index, label):
        return '<a href="#examples" data-claim="'+refs[index]['claim_id']+'">'+label+'</a>'

    b = '''<section id="findings"><h2>What improved, and what remains unresolved</h2>
<p>The revised compiler preserves more source contexts and shared references. On the <strong>20 fresh claims</strong> reserved before changes, faithful outputs rise from <strong>7 to 8</strong>, incorrect outputs fall from <strong>4 to 2</strong>, partial outputs rise from 4 to 5, and refusals remain 5. No previously faithful fresh output regressed. This is a modest descriptive gain on a small assistant review, not a semantic accuracy estimate.</p>
<p>The larger improvement on the 24 development cases—7 to 13 faithful outputs—reflects the cases used to design the changes. Across all 2,375 inputs, compilation rises from 1,997 to 2,042. <strong>Compilation acceptance is separate from meaning preservation.</strong> Accepted programs still contain wrong actors, unresolved references and untyped durations.</p>
<figure><div class="flow"><span>Unchanged<br>original claim</span><b>→</b><span>Cached pretrained SRL<br>+ dependency annotations</span><b>→</b><span>Deterministic<br>logical form</span><b>→</b><span>Scoped predicates<br>+ DeepProbLog program</span></div><figcaption>Figure 1. The evaluated compilation path. SRL means semantic role labeling: identifying predicates and their argument spans. A logical form explicitly records participants, relations and scope. This experiment uses no LLM calls, sentence rewriting, media inference or training.</figcaption></figure></section>'''
    b += '<section id="changes"><h2>Changes to the compilation rules</h2>'
    b += table(['Construction', 'Implemented change', 'Limit'], [
        ['Source and prediction scope', 'Keep nominal content and its modifiers inside the image, assertion or prediction; nested evidence routes inherit their context.', 'Event/nominal references inside these contexts remain incomplete.'],
        ['Predicational is/was', 'For “X is a/an NOUN,” put the noun description on the same referent as X.', 'Bare mass-noun predication and equative clauses are not fully covered.'],
        ['Location and noun phrases', 'Expose entity relations in spatial complements; preserve possessors, near/far-side modifiers and multiword names.', 'Upstream attachment errors can still make a mast part of a location.'],
        ['Embedded event subjects', 'Use an enhanced dependency subject link when available, then declared lexical classes for subject/object control.', 'This is limited rule-based completion. Existing incorrect SRL roles are retained.'],
        ['Participial and concessive clauses', 'Attach participial descriptions to their nominal owner; retain “although” as a concessive relation.', 'A malformed sentence or missing frame may still lose an event.']
    ], 'Bounded rule changes, with known limits. Neither the probabilistic backend nor the scoped compiler was replaced.')
    b += '<p>A <strong>controller</strong> is the participant understood as the subject of an embedded event. In “people watch a robot perform,” the robot performs. Added subject links are labeled <code>nsubj</code> or <code>nsubj:pass</code>; the code does not assume every subject is PropBank ARG0. ARG0 and ARG1 are predicate-specific role labels. A controller outside the declared classes can be refused rather than guessed.</p>'
    b += '<p>Inspectable examples: '+example(10, 'Mississippi and its vessel registration')+', '+example(8, 'a robot performing')+', '+example(17, 'predicted rain')+', and '+example(23, 'Mare Crisium’s location')+'. The '+example(21, 'damage shown in an image')+' now retains depiction scope, but remains partial because the nominal damage and damaged event do not share an explicit identity link.</p>'
    b += '''<figure><div class="walkthrough-grid"><div><h3>Identity binding</h3><pre>Mississippi: X1
  type: vessel
  registered: X1

The name and registration must match
the same evidence candidate.</pre></div><div><h3>Source scope</h3><pre>show: E1
  image: X1
  depicted content:
    damage: E2
      location: building

World damage alone does not certify
that the image depicts the damage.</pre></div></div><figcaption>Figure 2. Simplified readings of two real development cases. X1 identifies an entity and E1/E2 identify events. The viewer below contains the exact automatic graphs, reference readings and compiled predicates.</figcaption></figure></section>'''
    b += '<section id="counts"><h2>Full 2,375-input census</h2>'
    b += table(['Condition', 'Compiled claims', 'Nominal descriptions', 'Total compiled', 'Refused'],
        [[NAMES[m], v['kinds'].get('claim', 0), v['kinds'].get('mention', 0), v['compiled'], v['refused']] for m, v in s['conditions'].items()],
        'All original inputs using cached parser annotations. Nominal descriptions can require context; they are not all complete propositions.')
    b += table(['Paired outcome', 'Inputs'], [[k.replace('_', ' '), v] for k, v in s['transitions'].items()],
        '71 inputs newly compile and 26 previously compiled inputs are now refused. No paired transition is automatically a correctness improvement.')
    explanations = dict(unresolved_clause='A clause cannot be attached safely.', missing_predicate='A lexical predicate has no linked frame.',
        duplicate_role='Repeated roles have no supported composition.', missing_srl='No usable frame or unambiguous nominal root.',
        negative_quantifier='The required joint negation is unsupported.', modal_scope='The modal interpretation is unsupported.',
        mention_alignment='An entity does not align to an exact source mention.', predicate_type='An unsuitable word is used as a predicate.',
        quantity_type='The value requires another type.', polarity_omission='A source negation is missing.',
        unresolved_controller='No explicit or licensed embedded subject.')
    failures = s['conditions']['revised']['failures']
    b += table(['Refusal reason', 'Prior', 'Revised', 'Meaning'],
        [[k, s['conditions']['baseline']['failures'].get(k, 0), n, explanations[k]] for k, n in sorted(failures.items(), key=lambda x: -x[1])],
        'All 333 revised refusals. These are fired checks, not independently annotated semantic errors.')
    b += '</section><section id="review"><h2>Meaning preservation: development and fresh review</h2><p>'+escape(s['protocol'])+'</p>'
    b += table(['Sample / condition', 'Faithful', 'Partial', 'Incorrect', 'Refused'],
        [[cohort+' '+('24' if cohort=='development' else '20')+' / '+NAMES[m]]+[s['reviews'][cohort][m].get(j, 0) for j in ['faithful', 'partial', 'incorrect', 'refused']]
         for cohort in ['development', 'fresh'] for m in ['baseline', 'revised']],
        'Paired manual assistant judgments. Development cases influenced the rules; fresh IDs were reserved in advance. No error bars or population accuracy are estimated.')
    b += '<p><strong>Faithful</strong>: meaning and principal bindings survive under the stated reading. <strong>Partial</strong>: some detail or relationship is opaque or missing. <strong>Incorrect</strong>: an actor, identity, assertion or scope changes. <strong>Refused</strong>: no program is accepted; it does not mean the claim is false. The 24 manual reference readings are development specifications, with ambiguity notes, not independent human gold.</p>'
    fresh = sample['fresh_ids']
    def fresh_link(i, label):
        return '<a href="#examples" data-claim="'+fresh[i]+'">'+label+'</a>'
    b += table(['Fresh case', 'Prior → revised review', 'Remaining problem or improvement'], [
        ['LISTER drill', 'Incorrect → faithful', 'The named drill and its developed/type description share one referent.'],
        ['Axelrod / tariffs', 'Incorrect → partial', 'The policy description stays inside the assertion, but bare mass-noun identity is incomplete.'],
        ['Sunset imagery helps study dust', 'Incorrect → incorrect', 'Existing SRL treats imagery as the actor studying, rather than a resource.'],
        ['Electrodes and a mast', 'Incorrect → incorrect', 'The mast is attached as part of the surface location; a deck relation is missing.'],
        ['Mission duration', 'Partial → partial', 'Duration and endpoint conditions still lack adequate types/structure.']
    ], 'Concrete fresh-case outcomes, including accepted errors. All 44 paired reviews are downloadable and visible in the viewer.')
    b += '<p>Open '+fresh_link(8, 'the drill')+', '+fresh_link(14, 'the assertion')+', '+fresh_link(4, 'the imagery error')+', '+fresh_link(0, 'the mast error')+', or '+fresh_link(19, 'the duration case')+'.</p></section>'
    b += '''<section id="logic"><h2>Does the logical program enforce the corrected binding?</h2>
<p>We checked reference forms independently of automatic parsing. All 24 manually specified forms serialize as valid programs. For four development cases, constructed facts test both the parsed graph and the reference graph: matching facts should support the claim; misleading facts should refute it under the declared evidence policy. These are deterministic, point-mass checks, where each local distribution assigns probability one to a single state. They do not test learned or calibrated probabilities.</p>'''
    b += table(['Case', 'Misleading constructed facts', 'Revised and reference graph', 'Prior graph'], [
        ['Robot performance', 'Only people perform; the robot is present.', 'Refuted', 'Not tested in this counterexample comparison'],
        ['Vessel registration', 'Mississippi is present; another vessel is registered.', 'Refuted', 'Supported'],
        ['Forecast rain', 'Rain occurs in the world, but the forecast content is refuted.', 'Refuted', 'Supported'],
        ['Image damage', 'Damage occurs in the world, but the depicted damage is refuted.', 'Refuted', 'Supported']
    ], 'All 16 constructed checks pass: four cases × two graph sources × matching/misleading facts. The three tested prior graphs accept the misleading combination. This checks selected bindings, not full graph equivalence.')
    b += '<p><strong>Native DeepProbLog:</strong> the robot and vessel negative checks finish with refuted probability 1 (reported backend times about 0.26 and 1.93 seconds). The nested image/damage check exceeds a 30-second subprocess limit that includes Python startup. Its independent logical check passes, but its native inference is not a pass. Whole-corpus inference, scaling and training throughput remain unmeasured.</p></section>'
    b += '<section id="examples"><h2>Inspect original text, parses, graphs and programs</h2><p>Select each condition explicitly. “Reference” is available only for the 24 development cases; it is not an automatically corrected output. X variables identify entity/group candidates, E variables identify event candidates, T0 is a supplied reference time, and scope IDs identify source or modal contexts. No media verdict was produced.</p><div class="filters"><label>Search<input id="search" type="search" placeholder="Claim text or ID"></label><label>Show<select id="filter"><option value="all">All 2,375 inputs</option><option value="compiled">Revised compiled</option><option value="unsupported">Revised refused</option><option value="development">24 development cases</option><option value="fresh">20 fresh cases</option><option value="reviewed">All 44 reviewed cases</option></select></label><label>Condition<select id="method">'+''.join('<option value="'+m+'"'+(' selected' if m=='revised' else '')+'>'+escape(n)+'</option>' for m, n in NAMES.items())+'</select></label></div><p id="match-count" role="status">Loading cached outputs…</p><select id="claim-select" aria-label="Choose original claim"></select><h3 id="claim-title"></h3><blockquote id="claim-text"></blockquote><div id="outcome"></div>'
    b += '''<details><summary>Cached dependency tree</summary><figure><div id="syntax"></div><figcaption>Figure 3. Original dependency parser predictions. Token indices refer to the SRL word list. No source sentence is rewritten.</figcaption></figure></details>
<figure><h3>Original SRL</h3><pre id="original-srl"></pre><h3>Recorded compiler changes</h3><pre id="edits"></pre><figcaption>Figure 4. Cached predicate/argument spans and the revised pass’s recorded controller or predication changes. Other attachment rules are documented above; this is not an exhaustive edit trace.</figcaption></figure>
<figure><div id="form"></div><figcaption>Figure 5. The selected logical form, including shared referents and nested propositions. Automatic output may be partial or incorrect; consult its assistant judgment when available. A reference reading is manually specified.</figcaption></figure>
<figure><pre id="predicates"></pre><figcaption>Figure 6. The predicates emitted for the selected condition. Their context and shared variables determine which evidence assignments may support the claim.</figcaption></figure><details><summary>Exact saved DeepProbLog program (reviewed cases)</summary><pre id="program"></pre></details></section>'''
    b += '''<section id="checklist"><h2>Completed work and proposed next steps</h2><ul>
<li>☑ Write 24 manual reference readings and reserve 20 fresh IDs before changes — separate intended meaning from program validity.</li>
<li>☑ Revise source/prediction scope and modifier attachment — keep descriptions with their source context. Event/nominal identity remains incomplete.</li>
<li>☑ Revise predicational identity and structured locations — preserve shared referents and spatial relations. Bare mass nouns remain incomplete.</li>
<li>☑ Complete selected embedded subjects from explicit links or declared control classes — avoid a universal matrix-subject assumption. Existing wrong SRL roles remain open.</li>
<li>☑ Freeze, rerun all 2,375 inputs, review fresh cases, and test reference-to-logic separately — measure acceptance and meaning separately.</li></ul>
<h3>Proposed next steps and intended goals</h3><ol>
<li><strong>Fix event/nominal references, bare mass-noun predication and duration types</strong> — preserve remaining identity and value relationships in accepted programs.</li>
<li><strong>Audit missing or wrong SRL frames and recover explicit participants</strong> — address absent predicates and wrong actors that attachment rules cannot repair.</li>
<li><strong>Profile DeepProbLog startup, grounding, compilation and evaluation separately</strong> — locate the nested-case timeout before weak-label training.</li>
<li><strong>Freeze the next compiler and obtain an independent review on new source videos</strong> — measure meaning preservation beyond the development cases.</li></ol>
<p>The proposed steps are not completed. This bounded revision supports keeping one SRL/dependency compiler as the experimental frontend, with documented limits. It does not justify calling the compiler reliable yet. ADR-023 is unchanged; media verification and relation training remain deferred, and sentence rewriting remains unimplemented.</p></section>'''
    b += '<section id="downloads"><h2>Checks, resources and reproduction</h2><p>All <strong>156 tests pass</strong>. Cached CPU replay reproduces the 2,375 revised outcomes and program hashes, the 24 reference compilations, and the constructed logical checks. The legacy replay also reproduces all prior 2,375 SRL outputs plus both 48-case editor conditions. All eight earlier published source archives remain unchanged.</p><p>This revision uses <strong>zero GPUs and zero LLM requests</strong>. The cached census loop takes 15.3 seconds on CPU, excluding parser inference and loading. No model weights, media or truth labels are used.</p><div class="downloads">'+''.join('<a href="semantic-compilation/'+name+'">'+label+'</a>' for name, label in [
        ('source.zip', 'Source and cached CPU replay'), ('analysis.json', 'Full-corpus counts'), ('quality_review.json', '44 paired assistant reviews'),
        ('reference_forms.json', '24 manual reference readings'), ('logic_checks.json', 'Logical and native checks'),
        ('cases.json', 'All original claims and outputs'), ('tests.xml', '156 tests'), ('interface.md', 'Design and limits'),
        ('frozen_manifest.json', 'Frozen source/reference hashes'), ('sample_manifest.json', 'Sample IDs')])+'</div><p>After installing the requirements and NLTK WordNet, run <code>PYTHONPATH=scripts python scripts/replay_semantic_srl.py</code> from the extracted archive. No GPU or model download is needed for cached compilation. Native inference is a separate check, with the timeout retained in the saved results.</p></section>'
    head = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Semantic SRL compiler revision with full-corpus outcomes, development and fresh meaning reviews, reference logical forms and DeepProbLog checks."><title>Meaning preservation in claim compilation · AViD</title><link rel="stylesheet" href="../assets/site.css"><style>'+STYLE+'</style></head><body><nav class="site-nav" aria-label="Primary navigation"><div class="nav-inner"><a class="brand" href="../index.html">SCALE 2026 · AViD</a><div class="nav-links"><a href="../index.html">Home</a><a href="./" aria-current="page">Reports</a><a href="../proposals/">Proposals</a></div></div></nav><header class="hero"><div class="container"><p class="eyebrow">Compiler revision · 29 October 2026</p><h1>Meaning preservation in claim compilation</h1><p class="lede">One SRL/dependency compiler, explicit references and source contexts, with a separate check on 20 fresh claims.</p><nav class="subnav"><a href="#findings">Findings</a><a href="#changes">Changes</a><a href="#counts">Full census</a><a href="#review">Meaning review</a><a href="#logic">Logic checks</a><a href="#examples">Inspect claims</a><a href="#checklist">Next steps</a><a href="#downloads">Downloads</a></nav></div></header><main class="container prose">'
    script = (ROOT / 'scripts/report_assets/semantic_compilation.js').read_text()
    (SITE / 'reports/semantic-compilation.html').write_text(head+b+'<p><a href="./">All reports</a> · <a href="srl-compilation.html">Prior SRL experiment</a> · <a href="verification-pipeline.html#next-steps">Project checklist</a></p></main><footer class="site-footer"><div class="container">Generated from srl_semantics_20261029. All displayed outputs are cached.</div></footer><script>'+script+'</script></body></html>')
    build_cases()
    for name in ['analysis.json', 'quality_review.json', 'reference_forms.json', 'logic_checks.json', 'tests.xml', 'frozen_manifest.json', 'sample_manifest.json']:
        shutil.copyfile(RUN / name, OUT / name)
    shutil.copyfile(ROOT / 'docs/semantic_srl_compilation.md', OUT / 'interface.md')
    archive()
    print(f'Wrote semantic compilation report: {number} tables, 6 figures.')


if __name__ == '__main__':
    main()
