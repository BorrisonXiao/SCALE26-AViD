#!/usr/bin/env python3
import json,hashlib
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/srl_semantics_20261029'
def read(n):return [json.loads(s) for s in (RUN/n).read_text().splitlines() if s.strip()]
def main():
 m=json.loads((RUN/'sample_manifest.json').read_text());f=json.loads((RUN/'frozen_manifest.json').read_text())
 assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in f['source_sha256'].items())
 assert hashlib.sha256((RUN/'reference_forms.json').read_bytes()).hexdigest()==f['reference_sha256']
 rows={name:{r['claim_id']:r for r in read(file)} for name,file in [('baseline','baseline.jsonl'),('revised','results.jsonl')]}
 assert all(len(r)==2375 for r in rows.values())
 reviews=[]
 for a in json.loads((RUN/'review_annotations.json').read_text()):
  cid=m['development_ids' if a['cohort']=='development' else 'fresh_ids'][a['index']];r=rows[a['method']][cid]
  assert (r['status']=='compiled')==(a['judgment']!='refused'),(cid,a['method'])
  reviews.append(dict(a,claim_id=cid,text=r['text']))
 summaries={}
 for name,records in rows.items():
  accepted=[r for r in records.values() if r['status']=='compiled']
  summaries[name]=dict(total=len(records),compiled=len(accepted),refused=len(records)-len(accepted),kinds=Counter(r['compilation']['metadata']['kind'] for r in accepted),failures=Counter(r['code'] for r in records.values() if r['status']!='compiled'))
 counts={cohort:{method:Counter(r['judgment'] for r in reviews if r['cohort']==cohort and r['method']==method) for method in rows} for cohort in ['development','fresh']}
 transitions=Counter()
 for cid in rows['revised']:
  old=rows['baseline'][cid]['status']=='compiled';new=rows['revised'][cid]['status']=='compiled'
  transitions['both_compiled' if old and new else 'new_only' if new else 'previous_only' if old else 'both_refused']+=1
 data=dict(conditions=summaries,reviews=counts,transitions=transitions,protocol='Within-corpus development using cached trained SRL and dependency inputs. Twenty-four previously reviewed claims received manually specified complete reference readings and development inspection; ambiguous readings and a remaining event-nominal identity requirement are explicit. Twenty fresh IDs were sampled before changes, excluding earlier reviewed/pilot IDs. Compiler and reference hashes were frozen before fresh review and are checked. The same assistant judged original text and both graphs, without media/truth labels or independent human gold. This is not source-disjoint generalization or a corpus semantic accuracy estimate.')
 (RUN/'analysis.json').write_text(json.dumps(data,indent=2)+'\n');(RUN/'quality_review.json').write_text(json.dumps(dict(protocol=data['protocol'],counts=counts,cases=reviews),indent=2,ensure_ascii=False)+'\n')
 print(json.dumps(data,indent=2))
if __name__=='__main__':main()
