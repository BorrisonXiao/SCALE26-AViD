#!/usr/bin/env python3
"""Constructed counterexamples for reference and actual compiler outputs."""
import argparse,hashlib,itertools,json,subprocess,sys
from pathlib import Path
from probabilistic_verification.logical_form_v2 import ScopedCompiler
from probabilistic_verification.semantic_srl import semantic_srl_form,inherit_routes
from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground,combine_states
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/srl_semantics_20261029'
def load():
 records={r['claim_id']:r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())}
 refs={r['index']:r for r in json.loads((RUN/'reference_forms.json').read_text())['references']}
 return records,refs

def make_program(index,reference=False,counter=False,baseline=False):
 records,refs=load();r=records[refs[index]['claim_id']]
 form=refs[index]['form'] if reference else semantic_srl_form(r)[0]
 if baseline:form=next(json.loads(s)['proposed_form'] for s in (RUN/'baseline.jsonl').read_text().splitlines() if json.loads(s)['claim_id']==r['claim_id'])
 if not baseline:form=inherit_routes(form)
 c=ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],form,additional_proposition_kinds={'relative','complement','prediction','concession'})
 domains={v.name:[v.name.lower()] for v in c.variables}
 for v in c.variables:
  if index==10 and v.description=='Mississippi':domains[v.name]=['named-ship','other-ship']
  if index==10 and v.description=='vessel':domains[v.name]=['other-ship']
  if index==8 and v.description=='robot':domains[v.name]=['robot','people']
 observations={};media=str(index)+'-'+str(reference)+'-'+str(counter)
 for values in itertools.product(*(domains[v.name] for v in c.variables)):
  assignment=dict(zip([v.name for v in c.variables],values))
  for atom in c.atoms:
   args=atom.arguments;state='supported'
   if atom.predicate=='referent' and args[1]=='Mississippi':state='supported' if assignment[args[0]]=='named-ship' else 'refuted'
   if atom.predicate=='referent' and args[1]=='robot':state='supported' if assignment[args[0]]=='robot' else 'refuted'
   if atom.predicate=='register':
    target=assignment[args[args.index('ARG1')+1]];state='supported' if target==('other-ship' if counter else 'named-ship') else 'refuted'
   if atom.predicate=='perform':
    role='nsubj' if 'nsubj' in args else 'ARG0';target=assignment[args[args.index(role)+1]]
    state='supported' if target==('people' if counter else 'robot') else 'refuted'
   if index==21:
    if atom.predicate=='be':state='refuted' # The concession says not very clear.
    if atom.predicate=='damage':state='refuted' if counter and args[args.index('scope')+1]!='world' else 'supported'
   if index==17 and atom.predicate=='referent' and args[1]=='rain':state='refuted' if counter and args[args.index('scope')+1]!='world' else 'supported'
   key=canonical_key(media,atom,assignment,'visual_depiction');distribution=tuple(float(s==state) for s in ['supported','refuted','unknown'])
   observations[key]=Observation(key,distribution,False,atom.text,dict(source='constructed compiler counterexample'))
 evidence=Evidence(media,domains,{v:True for v in domains},observations)
 program=ground(c,evidence,max_expansions=10000)
 def evaluate(expr):
  if expr.op=='atom':return ['supported','refuted','unknown'][program.observations[expr.atom_id].distribution.index(1.)]
  if expr.op=='constant':return expr.state
  return combine_states(expr.op,[evaluate(child) for child in expr.children])
 return program,evaluate(program.expression)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--native-one',type=int);ap.add_argument('--structural-only',action='store_true');a=ap.parse_args()
 if a.native_one is not None:
  from probabilistic_verification.backend import DeepProbLogVerifier
  program,state=make_program(a.native_one,counter=True)
  out=DeepProbLogVerifier([program],learned=False).predict()[0]
  assert out['distribution']['refuted']>1-1e-9
  print(json.dumps(out));return
 rows=[]
 for index in [8,10,17,21]:
  for reference in [False,True]:
   for counter in [False,True]:
    _,state=make_program(index,reference,counter);expected='refuted' if counter else 'supported';assert state==expected,(index,reference,counter,state)
    rows.append(dict(index=index,reference=reference,counterexample=counter,expected=expected,actual=state))
 native=json.loads((RUN/'logic_checks.json').read_text())['native_checks'] if a.structural_only and (RUN/'logic_checks.json').exists() else []
 for index in ([] if a.structural_only else [8,10,21]):
  try:
   p=subprocess.run([sys.executable,__file__,'--native-one',str(index)],capture_output=True,text=True,timeout=30)
   assert p.returncode==0,p.stderr[-1000:]
   native.append(dict(index=index,status='passed',result=json.loads(p.stdout.splitlines()[-1])))
  except Exception as e:native.append(dict(index=index,status='failed_or_timeout',reason=str(e)))
 previous=[]
 for index in [10,17,21]:
  _,state=make_program(index,counter=True,baseline=True);assert state=='supported',(index,state)
  previous.append(dict(index=index,baseline_accepts_counterexample=True))
 data=dict(logical_checks=rows,baseline_counterexamples=previous,native_checks=native,reference_sha256=hashlib.sha256((RUN/'reference_forms.json').read_bytes()).hexdigest(),description='Only constructed point-mass evidence. Matching facts support; wrong performer, another registered vessel, world rain without forecast support, and world damage without depicted damage refute. Reference graphs and parsed graphs are checked independently. No media verification.')
 (RUN/'logic_checks.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2))
if __name__=='__main__':main()
