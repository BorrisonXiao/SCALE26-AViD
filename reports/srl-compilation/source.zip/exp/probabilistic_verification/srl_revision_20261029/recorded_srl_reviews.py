"""Saved assistant judgments from direct text/logical-form inspection."""
import json
from pathlib import Path
RUN=Path(__file__).resolve().parent
old=[
('refused','A relative clause exceeds the old clausal-argument restriction.',['clause_attachment']),
('faithful','Passive rebroadcast retains the footage and named broadcaster. ',[]),
('partial','Image, depicted person and credits remain one opaque noun phrase.',['noun_phrase_binding','credit_attachment']),
('partial','The final descent is retained but typed as a location rather than a phase/time.',['temporal_binding']),
('incorrect','Under the natural reading of this malformed source, sailing is an event; the output treats ship sail as a manner object and omits that event.',['clause_attachment','source_ambiguity']),
('partial','Likely is a manner literal; the source of the appeals and possessive reference are incompletely represented.',['modality_scope','coreference','noun_phrase_binding']),
('faithful','The referee is shared across stop/start, their count/fight targets are retained, and again is attached to start. Activity nouns remain referents, without invented participants.',[]),
('refused','The noun phrase contains multiple embedded predicates.',['clause_attachment']),
('refused','The perception complement is refused.',['clause_attachment']),
('partial','Take place remains take with a separate place participant; its idiomatic occurrence reading is unresolved.',['idiom']),
('refused','Registered inside the vessel description is refused.',['modifier_scope']),
('faithful','Existence of a helicopter sound is retained; actual helicopter existence is not asserted.',[]),
('refused','The relative clause and ability modal are refused.',['clause_attachment']),
('refused','No verbal SRL frame; the nominal sound/event description is refused.',['nominal_description']),
('refused','The purpose clause is refused.',['clause_attachment']),
('faithful','Causation, eruption description, pressure, flooding source and Dongguan relation survive. Flooding is a nominal referent; no additional actor was stated.',[]),
('partial','Prior to landing is preserved as a time string without explicitly binding the landing event to Blue Ghost.',['temporal_binding']),
('incorrect','Localization is asserted outside the prediction and the following-day time is omitted.',['source_scope','omission']),
('faithful','Could scopes over impact, with the haboob and airport operations in the intended roles.',[]),
('refused','Nested scheduled capture, eclipse and viewing clauses are refused.',['clause_attachment']),
('refused','The including clause inside the six-floor description is refused.',['clause_attachment']),
('refused','The concession with negation is refused.',['clause_attachment']),
('partial','The IM-to-landing relation stays an opaque possessive modifier; nailbiter is a separate referent rather than an explicit evaluative property.',['noun_phrase_binding','metaphor']),
('partial','Part of the spatial structure is exposed, but the moon/near-side relation stays opaque and the of near role is unclear.',['noun_phrase_binding','spatial_binding'])]
new=[
('refused','Repeated ARG1 on gone remains unresolved.',['duplicate_role']),
old[1],
('partial','Depicted person is explicit, but the photographer/library credit structure is incomplete and the output is unnecessarily classified as a mention.',['credit_attachment','nominal_description']),
old[3],old[4],
('partial','Possessive reference is explicit, but likely is a text adjunct and the organization name is split into a head and modifier.',['modality_scope','proper_name']),
old[6],
('refused','The podium/content phrase still has no usable attached clause frame.',['clause_attachment']),
('refused','The robot-perform complement still lacks a linked frame.',['clause_attachment']),
old[9],
('incorrect','Registered vessel and the named Mississippi are represented by different referents; their identity is not enforced.',['coreference','modifier_scope']),
old[11],
('faithful','Possible/multiple route modifiers, spacecraft ability, the route reference and Moon destination are retained in the relative description.',[]),
('partial','The source descents wording is retained as a nominal relation, but its temporal/event interpretation remains unresolved.',['temporal_binding','source_ambiguity']),
('partial','Visit and purpose learn are correctly nested with shared contestants, but the Miss Tourism World name is split into separate modifiers.',['proper_name']),
old[15],old[16],old[17],old[18],old[19],
('faithful','The building, exact six-floor group and inclusion of the bottom floor are linked; the same group/floor references are reused.',[]),
('incorrect','Damage is asserted outside the depicted image content. The unclear-damage concession is nested as generic content, with a duplicate opaque adjunct.',['source_scope','modifier_scope']),
('partial','Nailbiter is retained as a property value, but IM-to-landing identity remains hidden inside a modifier.',['noun_phrase_binding','metaphor']),
('partial','The whole spatial complement is a text literal; northeast, quadrant, near side and Moon have no explicit internal bindings.',['noun_phrase_binding','spatial_binding'])]
assert len(old)==len(new)==24
rows=[]
for method,labels in [('previous_srl',old),('trained_srl',new)]:
 for i,(judgment,note,patterns) in enumerate(labels):rows.append(dict(method=method,index=i,judgment=judgment,note=note,patterns=patterns))
(RUN/'srl_review_annotations.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
