"""Source-token alignment and the compact SRL revision interface.

The model can choose predicate positions, argument spans and PropBank roles.
It cannot generate participant names or predicate words outside the source.
This constrains references, not the correctness of a role or scope decision.
"""
import copy,re
from .logical_form import LogicalFormError

ROLES=[f'ARG{i}' for i in range(6)]+['ARGA']+[
    'ARGM-'+r for r in ['ADV','CAU','DIR','DIS','DSP','EXT','GOL','LOC','LVB','MNR','MOD','NEG','PNC','PRD','PRP','REC','TMP']]

def normalized(word):
    return re.sub(r'\s+','',word.lower().replace('’',"'"))

class TokenAlignment:
    def __init__(self,record):
        self.record=record;self.words=(record.get('srl') or {}).get('words',[])
        self.tokens=record.get('tokens',[]);self.by_id={t['id']:t for t in self.tokens}
        def offsets(words):
            result=[];p=0
            for w in words:
                result.append((p,p+len(normalized(w))));p=result[-1][1]
            return result
        self.word_offsets=offsets(self.words)
        self.token_offsets=dict(zip([t['id'] for t in self.tokens],offsets([t['text'] for t in self.tokens])))
        if ''.join(map(normalized,self.words))!=''.join(normalized(t['text']) for t in self.tokens):
            raise LogicalFormError('alignment','SRL and dependency words do not align.')

    def selected(self,start,end):
        if not 0<=start<=end<len(self.words):
            raise LogicalFormError('span','Argument/predicate span is outside the original tokens.')
        lo,hi=self.word_offsets[start][0],self.word_offsets[end][1]
        return [t for t in self.tokens if self.token_offsets[t['id']][0]<hi and self.token_offsets[t['id']][1]>lo]

    def word_index(self,token):
        lo,hi=self.token_offsets[token['id']]
        matches=[i for i,(a,b) in enumerate(self.word_offsets) if a<hi and b>lo]
        return matches[0]

    def surface(self,start,end):
        ts=self.selected(start,end)
        return self.record['text'][ts[0]['start_char']:ts[-1]['end_char']]

def revision_input(record,amr=None):
    alignment=TokenAlignment(record)
    syntax=[]
    for t in record['tokens']:
        syntax.append([alignment.word_index(t),t['upos'],
            alignment.word_index(alignment.by_id[t['head']]) if t['head'] else -1,t['deprel']])
    frames=[]
    for f in record['srl'].get('frames',[]):
        if not isinstance(f.get('verb_span'),list) or not f.get('args'):continue
        frames.append(dict(predicate=f['verb_span'][0],arguments=[dict(role=a['role'],span=[a['start'],a['end']]) for a in f['args']]))
    data=dict(sentence=record['text'],tokens=list(enumerate(alignment.words)),
        dependencies=syntax,srl=dict(frames=frames))
    if amr is not None:data['amr']=amr
    return data

def revision_schema(word_count):
    integer=dict(type='integer',minimum=0,maximum=word_count-1)
    def obj(properties,required):return dict(type='object',properties=properties,required=required,additionalProperties=False)
    argument=obj(dict(role=dict(type='string',enum=ROLES),span=dict(type='array',items=integer,minItems=2,maxItems=2)),['role','span'])
    frame=obj(dict(predicate=integer,arguments=dict(type='array',items=argument)),['predicate','arguments'])
    return obj(dict(frames=dict(type='array',items=frame)),['frames'])

def revised_record(record,proposal):
    """Rebuild ordinary SRL records exclusively from the unchanged source tokens."""
    alignment=TokenAlignment(record);out=copy.deepcopy(record);frames=[];seen=set()
    for f in proposal['frames']:
        p=f['predicate']
        if p in seen:raise LogicalFormError('duplicate_predicate','Repeated predicate position '+str(p))
        seen.add(p);alignment.selected(p,p)
        args=[]
        for a in f['arguments']:
            if a['role'] not in ROLES:raise LogicalFormError('role','Unknown PropBank role.')
            start,end=a['span'];surface=alignment.surface(start,end)
            args.append(dict(role=a['role'],start=start,end=end,text=surface))
        frames.append(dict(verb=alignment.words[p],verb_span=[p,p],args=args))
    out['srl']=dict(words=alignment.words,frames=frames)
    return out
