"""Compile an SRL frame graph using dependency edges for clause attachment.

There is one translation, with no candidate selection or LLM fallback. PropBank
argument labels come from SRL. Dependency relations connect clauses and expose
noun-phrase relations. Unknown complement semantics remain a complement of the
parent predicate; they are never promoted to independent world assertions.
"""
import re
from .logical_form import LogicalFormError
from .srl_revision import TokenAlignment
from .srl_form_v2 import MODALS

SPEECH={'say','tell','state','report','mention','claim','announce','explain','shout','chant','ask'}
MEDIA=re.compile(r'\b(video|footage|photo|image|clip|picture|screen|caption|text|sign|banner|graffiti)\w*\b',re.I)
INTENTION={'try','attempt','aim','plan','intend','hope','want','seek'}
BELIEF={'believe','think','suspect','assume','expect','know','understand'}
CLAUSAL={'ccomp','xcomp','advcl','acl','acl:relcl','csubj','csubj:pass'}
CORE=re.compile(r'^ARG[0-5A]$')

def srl_graph_form(record):
    a=TokenAlignment(record);tokens=a.tokens;by_id=a.by_id;children={t['id']:[] for t in tokens}
    for t in tokens:
        if t['head'] in children:children[t['head']].append(t)
    entities={};frames={};notes=[]
    def fail(code,message):raise LogicalFormError(code,message)
    def descendants(tid):
        out={tid};todo=[tid]
        while todo:
            for t in children[todo.pop()]:
                if t['id'] not in out:out.add(t['id']);todo.append(t['id'])
        return out
    def root(ts):
        ids={t['id'] for t in ts};rs=[t for t in ts if t['head'] not in ids]
        if len(rs)==1:return rs[0]
        content=[t for t in rs if t['upos'] not in {'DET','ADP','PART','PUNCT','SCONJ','CCONJ'}]
        if len(content)==1:return content[0]
        # The parse is uncertain; preserve the phrase rather than inventing an internal head.
        return None
    def surface(ts):return record['text'][min(t['start_char'] for t in ts):max(t['end_char'] for t in ts)]
    def span_arg(role,ts):
        indices=[a.word_index(t) for t in ts]
        return dict(role=role,start=min(indices),end=max(indices),text=surface(ts))
    for original in (record.get('srl') or {}).get('frames',[]):
        if not original.get('args'):continue
        span=original.get('verb_span')
        if not isinstance(span,list):
            matches=[i for i,w in enumerate(a.words) if w.casefold()==str(original.get('verb')).casefold()]
            if len(matches)!=1:fail('missing_srl_span','Predicate position cannot be uniquely recovered.')
            span=[matches[0],matches[0]];notes.append('Recovered one unambiguous missing predicate position.')
        ts=a.selected(*span);head=root(ts) or ts[0]
        if head['upos'] not in {'VERB','AUX','ADJ','NOUN','PROPN'}:
            fail('predicate_type','Predicate position is not a lexical/state predicate: '+head['text'])
        if head['id'] in frames:fail('duplicate_predicate','Multiple frames use the same source predicate.')
        frames[head['id']]=dict(token=head,args=original['args'],predicate=head.get('lemma') or head['text'])
    # This cached model is a verbal SRL model. A nominal object with no clausal
    # dependents is retained as a noun phrase, rather than a spurious verb frame.
    for fid,f in list(frames.items()):
        t=f['token']
        if t['upos'] in {'NOUN','PROPN'} and t['head'] and t['deprel'] not in CLAUSAL and not any(u['deprel'] in CLAUSAL for u in children[fid]):
            del frames[fid];notes.append('Retained nominal '+t['text']+' as a noun phrase, not a verbal SRL frame.')
    # SRL systems trained on verbal predicates omit many ordinary copular clauses.
    for t in tokens:
        cops=[u for u in children[t['id']] if u['deprel']=='cop']
        subjects=[u for u in children[t['id']] if u['deprel'].startswith('nsubj')]
        if not cops or not subjects or t['id'] in frames or any(u['id'] in frames for u in cops):continue
        cop=cops[0];args=[span_arg('ARG1',[by_id[x] for x in descendants(subjects[0]['id'])])]
        complement=[t]+[u for u in children[t['id']] if u['deprel'] in {'amod','compound','flat','nummod'}]
        args.append(span_arg('ARG2',complement))
        for u in children[t['id']]:
            if u['text'].lower() in {'not',"n't",'never'}:args.append(span_arg('ARGM-NEG',[u]))
            if u['deprel']=='aux' and u['text'].lower() in MODALS:args.append(span_arg('ARGM-MOD',[u]))
        frames[cop['id']]=dict(token=cop,args=args,predicate='be');notes.append('Completed a dependency-licensed copular frame omitted by SRL.')

    # An exact quotation is a string argument of a source predicate. Verbal SRL
    # inside the quotation must not become independent assertions by the author.
    quotes=[(m.start(1),m.end(1),m.group(1)) for pattern in [r'"([^"\n]+)"',r'“([^”\n]+)”',r"(?<!\w)'([^'\n]+)'(?!\w)"] for m in re.finditer(pattern,record['text'])]
    quote_context={};quoted_frames=set()
    for fid,f in frames.items():
        p=f['predicate'].lower()
        if p not in SPEECH|{'read'}:continue
        for arg in f['args']:
            if arg['role'] not in {'ARG1','ARG2','ARG3'}:continue
            ts=a.selected(arg['start'],arg['end']);lo=ts[0]['start_char'];hi=ts[-1]['end_char']
            candidates=[q for q in quotes if max(q[0],lo)<min(q[1],hi)]
            if len(candidates)!=1:continue
            q=candidates[0]
            # Use the full marked quote even when SRL omitted its final apposition.
            source=' '.join(x['text'] for x in f['args'] if x is not arg)
            route='ocr_assertion' if p=='read' or MEDIA.search(source) else 'speech_assertion'
            quote_context[fid]=(arg['role'],q,route)
            quoted_frames.update(cid for cid,g in frames.items() if q[0]<=g['token']['start_char']<q[1] and cid!=fid)
            break
    for fid in quoted_frames:del frames[fid]

    # The parent is the nearest predicate on the dependency path. An intervening
    # noun with acl/acl:relcl is retained as the owner of a relative description.
    links={};relative_owners={};syntactic_heads={fid:fid for fid in frames}
    for fid,f in frames.items():
        t=f['token']
        if t['deprel']=='cop' and t['head'] not in syntactic_heads:syntactic_heads[t['head']]=fid
    for fid,f in frames.items():
        t=f['token'];path=[];current=t;seen={fid}
        while current['head'] and current['head'] not in seen:
            path.append(current);parent=by_id[current['head']];seen.add(parent['id'])
            if parent['id'] in syntactic_heads and syntactic_heads[parent['id']]!=fid:
                # A lexical predicate attached to an auxiliary is not a subordinate clause.
                edge=next((u['deprel'] for u in path if u['deprel'] in CLAUSAL or u['deprel']=='conj'),None)
                if edge:links[fid]=(syntactic_heads[parent['id']],edge)
                break
            if current['deprel'] in {'acl','acl:relcl'} and parent['upos'] in {'NOUN','PROPN','PRON'}:
                relative_owners[fid]=parent['id'];break
            current=parent
    def phrase(head,allowed=None,allow_group=True):
        """One referent per source head, with explicit nominal relations."""
        hid=head['id'];key='x'+str(hid)
        if key in entities:return 'g'+str(hid) if allow_group and 'g'+str(hid) in entities else key
        allowed=set(allowed) if allowed is not None else descendants(hid)
        name_ids={hid}
        for u in children[hid]:
            if u['id'] in allowed and (u['deprel'] in {'flat','flat:name','fixed'} or head['upos']=='PROPN' and u['deprel'] in {'compound','nummod'}):
                name_ids.update(descendants(u['id'])&allowed)
        # Keep a tokenizer's split pieces of one source name (IM / - / 1)
        # together; token boundaries are not entity boundaries.
        if head['upos']=='PROPN':
            word=a.word_index(head)
            name_ids.update(t['id'] for t in a.selected(word,word) if t['id'] in allowed)
        name=[by_id[i] for i in sorted(name_ids)]
        data=dict(id=key,text=surface(name),type='pronoun' if head['upos']=='PRON' else 'group' if 'Number=Plur' in (head.get('feats') or '') else 'entity')
        entities[key]=data
        members=[u for u in children[hid] if allow_group and u['deprel']=='conj' and u['id'] in allowed and u['upos'] in {'NOUN','PROPN','PRON'}]
        if members:
            # A group is one event participant. Member modifiers remain local to members.
            member_ids={hid}|{u['id'] for u in members};group='g'+str(hid)
            if group not in entities:
                nominal=[by_id[x] for x in sorted(allowed) if by_id[x]['upos'] not in {'VERB','AUX','PUNCT'}]
                entities[group]=dict(id=group,text=surface(nominal),type='group',relations=[])
                entities[group]['relations']=[dict(role='member',target=phrase(by_id[i],descendants(i)-set().union(*(descendants(u['id']) for u in members if u['id']!=i)),allow_group=False)) for i in sorted(member_ids)]
            # Continue constructing the head member before returning its group.
        for u in children[hid]:
            if u['id'] not in allowed or u['id'] in name_ids or u['deprel']=='conj':continue
            relation=u['deprel']
            if relation in {'amod','compound'} and u['upos'] not in {'VERB','AUX'}:
                data.setdefault('properties',[]).append(dict(role='mod',value=surface([by_id[x] for x in sorted(descendants(u['id'])&allowed)])))
            elif relation=='nummod' and head['upos']!='PROPN' and u['id']<hid:
                prefix=record['text'][max(0,u['start_char']-24):u['start_char']]
                operator='exact'
                for pattern,op in [(r'(at least|no fewer than)','at_least'),(r'(more than|over)','more_than'),
                    (r'(at most|no more than)','at_most'),(r'(less than|under)','less_than'),(r'(about|around|approximately|nearly|almost)','approx')]:
                    if re.search(r'\b'+pattern+r'\s*$',prefix,re.I):operator=op;break
                data['quantity']=dict(operator=operator,value=u['text']);data['type']='group'
            elif relation=='det' and u['text'].lower() in {'many','few','several','all','every','each','both','most','some','multiple','numerous','no'}:
                data.setdefault('properties',[]).append(dict(role='quantifier',value=u['text']))
            elif relation.startswith('nmod') and u['upos'] in {'NOUN','PROPN','PRON'}:
                markers=' '.join(v['text'] for v in children[u['id']] if v['deprel']=='case')
                role='possessor' if relation=='nmod:poss' else markers or 'nmod'
                data.setdefault('relations',[]).append(dict(role=role,target=phrase(u,descendants(u['id'])&allowed)))
        relatives=[fid for fid,owner in relative_owners.items() if owner==hid]
        for fid in relatives:
            data.setdefault('propositions',[]).append(dict(role=frames[fid]['token']['deprel'],kind='relative',route='unspecified',body=build_group(fid)))
        return 'g'+str(hid) if members else key

    def argument(arg,predicate):
        ts=a.selected(arg['start'],arg['end']);head=root(ts);role=arg['role']
        if head and head['text'].lower() in {'who','which','that'}:
            owner=relative_owners.get(head['head'])
            if owner:return phrase(by_id[owner])
        value=surface(ts)
        measurement=re.fullmatch(r'((?:(?:over|under|about|around|approximately|nearly|at least|more than|less than)\s+)?(?:[\d,.]+|one|two|three|four|five|six|seven|eight|nine|ten))\s*(years?|months?|weeks?|days?|hours?|minutes?|seconds?|mph|knots?|km/h|meters?|metres?|feet|inches?|miles?|percent|%)',value,re.I)
        if measurement:
            unit=measurement[2];kind='duration' if re.fullmatch(r'years?|months?|weeks?|days?|hours?|minutes?|seconds?',unit,re.I) else 'measurement'
            return dict(kind=kind,value=measurement[1],unit=unit)
        if role=='ARGM-TMP':return dict(kind='time',value=value)
        if role in {'ARGM-MNR','ARGM-ADV','ARGM-DIS','ARGM-EXT'} and (not head or head['upos'] in {'ADV','ADJ','NUM'}):
            return dict(kind='manner' if role=='ARGM-MNR' else 'text',value=value)
        if predicate=='be' and role in {'ARG2','ARGM-PRD'}:return dict(kind='text',value=value)
        if head and head['upos'] in {'ADJ','ADV'}:return dict(kind='text',value=value)
        content=[t for t in ts if t['upos'] not in {'DET','ADP','PART','PUNCT','SCONJ','CCONJ'}]
        if not content:return dict(kind='text',value=value)
        if head and head['upos'] in {'NOUN','PROPN','PRON','NUM'}:return phrase(head,{t['id'] for t in ts})
        if any(t['upos'] in {'VERB','AUX'} for t in ts):
            fail('unresolved_clause','A clausal argument has no attached SRL frame: '+value)
        # An unresolved nominal attachment remains explicit and is flagged by diagnostics.
        key='span'+str(arg['start'])+'_'+str(arg['end'])
        entities.setdefault(key,dict(id=key,text=surface(content),type='entity'))
        return key

    building=set();emitted=set()
    def scope_kind(parent,child,role,edge):
        p=frames[parent]['predicate'].lower();t=frames[child]['token']
        markers=' '.join(u['text'] for u in children[t['id']] if u['deprel'] in {'mark','case'}).lower()
        parent_text=' '.join(x['text'] for x in frames[parent]['args'])
        if p in SPEECH and edge in {'ccomp','xcomp'}:return ('question' if p=='ask' else 'assertion','speech_assertion',markers)
        if p in {'read','show','depict','display'} and MEDIA.search(parent_text) and edge in {'ccomp','xcomp'}:
            return ('depiction','visual_depiction',markers) if p in {'show','depict','display'} else ('assertion','ocr_assertion',markers)
        if edge=='advcl':
            if markers in {'if','unless','provided'}:return 'condition','unspecified',markers
            if markers in {'before','after','when','while','once','until'}:return 'temporal','unspecified',markers
            if markers=='because' or role=='ARGM-CAU':return 'reason','unspecified',markers
            if markers in {'to','in order to'} or role in {'ARGM-PRP','ARGM-PNC'}:return 'purpose','unspecified',markers
        if p in INTENTION:return 'purpose','unspecified',markers
        if p in BELIEF:return 'belief','unspecified',markers
        return 'complement','unspecified',markers

    def build(fid):
        if fid in building:fail('clause_cycle','SRL/dependency clause attachment contains a cycle.')
        building.add(fid);emitted.add(fid);f=frames[fid];args={};props=[];propositions=[];negative=False;modal=None
        direct=[cid for cid,(parent,edge) in links.items() if parent==fid and edge!='conj']
        attached=set()
        for arg in f['args']:
            role=arg['role'];ts=a.selected(arg['start'],arg['end']);ids={t['id'] for t in ts};head=root(ts)
            if role.startswith('R-'):role=role[2:]
            if fid in quote_context:
                quote_role,(lo,hi,words),route=quote_context[fid]
                if role==quote_role:
                    args[role]=dict(kind='verbatim_text',value=words)
                    if not any(p['role']=='source_route' for p in props):props.append(dict(role='source_route',value=route))
                    continue
                if lo<=ts[0]['start_char'] and ts[-1]['end_char']<=hi:continue
            if role=='ARGM-NEG':negative=True;continue
            if role=='ARGM-MOD':
                word=surface(ts).lower()
                if word not in MODALS:fail('modal_scope','Unresolved modal interpretation: '+word)
                modal=(word,MODALS[word]);continue
            children_here=[cid for cid in direct if cid in ids]
            # Clausal coordination is represented by build_group, not duplicated
            # as an opaque adjunct of the first conjunct.
            conjuncts_here=[cid for cid,(parent,edge) in links.items() if parent==fid and edge=='conj' and cid in ids]
            if conjuncts_here and head and head['id'] in conjuncts_here:continue
            if children_here:
                for cid in children_here:
                    if cid in attached:continue
                    edge=links[cid][1];kind,route,marker=scope_kind(fid,cid,role,edge)
                    body=build_group(cid);propositions.append(dict(role=role,kind=kind,route=route,body=body));attached.add(cid)
                    if marker:props.append(dict(role='clause_marker:'+role,value=marker))
                # A clausal slot is replaced by its nested frame, not an opaque string.
                if head and (head['id'] in children_here or head['upos'] in {'VERB','AUX'}):continue
            value=argument(arg,f['predicate'])
            if role in args:
                if args[role]==value:continue
                if role.startswith('ARGM-') and isinstance(value,dict):
                    props.append(dict(role=role,value=str(value['value'])));continue
                fail('duplicate_role','SRL repeats '+role+' on '+f['token']['text'])
            args[role]=value
            if head:
                markers=' '.join(u['text'] for u in children[head['id']] if u['deprel']=='case' and u['id'] in ids)
                if markers and not (role=='ARG0' and markers.lower()=='by'):
                    props.append(dict(role='preposition:'+role,value=markers))
        for cid in direct:
            if cid in attached:continue
            edge=links[cid][1];kind,route,marker=scope_kind(fid,cid,edge,edge)
            propositions.append(dict(role=edge,kind=kind,route=route,body=build_group(cid)))
            if marker:props.append(dict(role='clause_marker:'+edge,value=marker))
        node=dict(op='event',id='e'+str(fid),predicate=f['predicate'],anchor=f['token']['text'],arguments=args)
        if props:node['properties']=props
        if propositions:node['propositions']=propositions
        if negative:node=dict(op='not',child=node)
        if modal:
            # The modal word is also retained for inspecting the original reading.
            node=dict(op='qualified',operator=modal[1],body=node)
        building.remove(fid);return node

    def build_group(fid):
        conjuncts=[cid for cid,(parent,edge) in links.items() if parent==fid and edge=='conj']
        base=build(fid)
        if not conjuncts:return base
        operators={'or' if any(u['deprel']=='cc' and u['text'].lower()=='or' for u in children[cid]) else 'and' for cid in conjuncts}
        if len(operators)>1:fail('coordination','Mixed clause coordination needs an explicit interpretation.')
        return dict(op=operators.pop(),children=[base]+[build_group(cid) for cid in conjuncts])

    roots=[fid for fid in frames if fid not in links and fid not in relative_owners]
    if not roots:
        nominal_roots=[t for t in tokens if t['head']==0 and t['upos'] in {'NOUN','PROPN','PRON'}]
        if len(nominal_roots)!=1:fail('missing_srl','No usable SRL frame or unambiguous nominal root.')
        formula=dict(op='entity',ref=phrase(nominal_roots[0]));kind='mention'
    else:
        nodes=[build_group(fid) for fid in roots]
        formula=nodes[0] if len(nodes)==1 else dict(op='and',children=nodes);kind='claim'
    # Every explicit lexical clause predicate must have a linked frame. This is
    # a check on source positions, not word overlap or candidate selection.
    retained_quotes=[q for _,q,_ in quote_context.values()]
    missing=[t['text'] for t in tokens if t['upos']=='VERB' and t['deprel'] in CLAUSAL|{'root','conj'}
        and t['id'] not in emitted and not any(lo<=t['start_char']<hi for lo,hi,_ in retained_quotes)]
    if missing:fail('missing_predicate','Explicit source clause predicates have no linked SRL frame: '+', '.join(missing))
    # Constructing a coordination group can reserve an unused head member. Keep
    # declarations reachable from the formula and nominal relationships only.
    used=set()
    def visit(x):
        if isinstance(x,str) and x in entities and x not in used:
            used.add(x);visit(entities[x])
        elif isinstance(x,dict):
            for key,value in x.items():
                if key not in {'id','text'}:visit(value)
        elif isinstance(x,list):
            for value in x:visit(value)
    visit(formula)
    return dict(version='logical-form-v2',kind=kind,entities=[e for k,e in entities.items() if k in used],formula=formula,
        warnings=notes+['SRL supplies PropBank roles; dependency edges supply clause attachment. Complement content is not projected to the world.'])
