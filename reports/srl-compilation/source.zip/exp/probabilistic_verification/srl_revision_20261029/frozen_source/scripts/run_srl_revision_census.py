#!/usr/bin/env python3
"""One deterministic SRL-graph compiler, optionally after model span revision."""
import argparse,hashlib,json,time
from collections import Counter
from pathlib import Path
from problog.program import PrologString
from probabilistic_verification.srl_revision import revised_record
from probabilistic_verification.srl_graph import srl_graph_form
from probabilistic_verification.logical_form_v2 import ScopedCompiler,parse_form
from probabilistic_verification.compilation_checks_v2 import meaning_diagnostics
from probabilistic_verification.logic import Evidence,ground,prolog_program
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/srl_revision_20261029'
def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def compile_record(record,raw=None):
    row=dict(claim_id=record['claim_id'],text=record['text'],status='unsupported')
    try:
        revised=record
        if raw:
            row['request_hash']=raw['request_hash']
            proposal=parse_form(raw['raw']);row['revised_srl']=proposal
            revised=revised_record(record,proposal)
        form=srl_graph_form(revised);row['proposed_form']=form
        c=ScopedCompiler().compile(record['claim_id'],record['text'],record['tokens'],form,additional_proposition_kinds={'complement','relative'})
        evidence=Evidence('compilation-check',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
        source,_=prolog_program([ground(c,evidence,max_expansions=10000)],learned=False)
        assert list(PrologString(source))
        row.update(status='compiled',compilation=c.to_dict(),diagnostics=meaning_diagnostics(record,form,c),
            program_sha256=hashlib.sha256(source.encode()).hexdigest(),program=source)
    except Exception as e:row.update(code=getattr(e,'code',type(e).__name__),reason=str(e))
    return row

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--raw',type=Path);ap.add_argument('--output',type=Path,default=RUN/'srl_graph_results.jsonl')
    ap.add_argument('--pilot',action='store_true');a=ap.parse_args()
    records=read(RUN/'inputs.jsonl');responses={r['claim_id']:r for r in read(a.raw)} if a.raw else {}
    if a.raw:records=[r for r in records if r['claim_id'] in responses]
    if a.pilot:records=records[:24]
    begun=time.perf_counter();rows=[compile_record(r,responses.get(r['claim_id'])) for r in records]
    a.output.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    counts=Counter('compiled' if r['status']=='compiled' else r['code'] for r in rows)
    categories=Counter(r['compilation']['metadata']['kind'] for r in rows if r['status']=='compiled')
    flags=Counter(d['code'] for r in rows for d in r.get('diagnostics',[]))
    summary=dict(total=len(rows),counts=counts,output_kinds=categories,diagnostics=flags,cpu_seconds=time.perf_counter()-begun,
        interpretation='One SRL graph and one compiler; no candidate selection. Acceptance does not establish meaning preservation.')
    a.output.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
