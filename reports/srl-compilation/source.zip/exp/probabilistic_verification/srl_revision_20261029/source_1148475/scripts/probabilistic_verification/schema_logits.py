"""Transformers/XGrammar adapter with explicit Python-int token conversion.

The installed upstream HF adapter passes a scalar torch.Tensor to a C++ method
that requires int. This local adapter follows the same masking algorithm and
does not modify either installed package. A new instance is used per generation.
"""
class SchemaLogitsProcessor:
    def __init__(self,grammars):
        import xgrammar as xgr
        self.grammars=grammars;self.matchers=[xgr.GrammarMatcher(g) for g in grammars]
        self.mask=xgr.allocate_token_bitmask(len(grammars),grammars[0].tokenizer_info.vocab_size)
        self.prefilled=False

    def __call__(self,input_ids,scores):
        import xgrammar as xgr
        if input_ids.shape[0]!=len(self.matchers):raise ValueError('Grammar and generation batch sizes differ.')
        if self.prefilled:
            # One CPU transfer per batch; no scalar tensor reaches the C++ FFI.
            for matcher,token in zip(self.matchers,input_ids[:,-1].tolist()):
                if not matcher.is_terminated() and not matcher.accept_token(int(token)):
                    raise ValueError('Generated token is outside the JSON grammar.')
        self.prefilled=True
        for i,matcher in enumerate(self.matchers):
            if not matcher.is_terminated():matcher.fill_next_token_bitmask(self.mask,i)
        xgr.apply_token_bitmask_inplace(scores,self.mask.to(scores.device))
        return scores
