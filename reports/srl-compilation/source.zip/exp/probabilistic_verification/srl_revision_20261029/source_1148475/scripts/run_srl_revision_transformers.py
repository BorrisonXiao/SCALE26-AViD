#!/usr/bin/env python3
"""Bounded same-model pilot on available V100s, with JSON-schema decoding."""
import argparse,hashlib,importlib.metadata,json,os,shutil,time
from pathlib import Path
import prompts_phase2 as P
from probabilistic_verification.srl_revision import revision_input,revision_schema
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/srl_revision_20261029'
OLD=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--batch-size',type=int,default=6);a=ap.parse_args()
    import torch,xgrammar as xgr
    from probabilistic_verification.schema_logits import SchemaLogitsProcessor
    from transformers import AutoTokenizer,AutoModelForCausalLM
    torch.set_num_threads(4);path=Path('/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507')
    tokenizer=AutoTokenizer.from_pretrained(path,local_files_only=True,padding_side='left')
    if tokenizer.pad_token_id is None:tokenizer.pad_token=tokenizer.eos_token
    vocab_size=json.loads((path/'config.json').read_text())['vocab_size']
    compiler=xgr.GrammarCompiler(xgr.TokenizerInfo.from_huggingface(tokenizer,vocab_size=vocab_size))
    # Check the adapter on the actual GPU before loading the 60-GB checkpoint.
    grammar=compiler.compile_json_schema(revision_schema(10),any_whitespace=False,separators=(',',':'))
    smoke=SchemaLogitsProcessor([grammar]);ids=torch.tensor([[0]],device='cuda')
    for _ in range(2):
        scores=smoke(ids,torch.zeros((1,vocab_size),device='cuda'));ids=torch.cat([ids,scores.argmax(-1,keepdim=True)],dim=1)
    print('GPU grammar smoke check passed',flush=True)
    model=AutoModelForCausalLM.from_pretrained(path,local_files_only=True,dtype=torch.float16,attn_implementation='sdpa',
        device_map='balanced',max_memory={i:'28GiB' for i in range(torch.cuda.device_count())}).eval()
    records=read(a.input);amrs={r['request']['task']['claim_id']:r['raw'] for i in range(4) for r in read(OLD/f'amr_{i}_raw.jsonl')}
    snapshot=RUN/('source_'+os.getenv('SLURM_JOB_ID','local'));hashes={}
    for source in [Path(__file__),ROOT/'scripts/prompts_phase2.py',ROOT/'scripts/probabilistic_verification/srl_revision.py',ROOT/'scripts/probabilistic_verification/schema_logits.py']:
        rel=source.relative_to(ROOT);target=snapshot/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);hashes[str(rel)]=hashlib.sha256(source.read_bytes()).hexdigest()
    (snapshot/'manifest.json').write_text(json.dumps(hashes,indent=2)+'\n')
    config=dict(model=str(path),dtype='float16',backend='transformers+xgrammar',prompt_version=P.SRL_REVISION_PROMPT_VERSION,
        transformers=importlib.metadata.version('transformers'),source_sha256=hashes,input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
        slurm_job_id=os.getenv('SLURM_JOB_ID'),gpu_names=[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())],
        max_new_tokens=1536,temperature=0.,model_config_sha256=hashlib.sha256((path/'config.json').read_bytes()).hexdigest())
    for condition in ['srl','amr']:
        output=RUN/(condition+'_raw.jsonl');done={r['claim_id'] for r in read(output)} if output.exists() else set()
        todo=[r for r in records if r['claim_id'] not in done]
        for start in range(0,len(todo),a.batch_size):
            batch=todo[start:start+a.batch_size];requests=[];prompts=[];grammars=[]
            for r in batch:
                data=revision_input(r,amrs[r['claim_id']] if condition=='amr' else None)
                messages=[dict(role='system',content=P.SRL_REVISION_SYSTEM),dict(role='user',content=P.srl_revision_user(data))]
                requests.append(dict(claim_id=r['claim_id'],condition=condition,messages=messages,config=config))
                prompts.append(tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True))
                grammars.append(compiler.compile_json_schema(revision_schema(len(data['tokens'])),any_whitespace=False,separators=(',',':')))
            inputs=tokenizer(prompts,padding=True,return_tensors='pt').to(model.get_input_embeddings().weight.device)
            begun=time.perf_counter()
            with torch.inference_mode():
                outputs=model.generate(**inputs,do_sample=False,num_beams=1,max_new_tokens=1536,
                    logits_processor=[SchemaLogitsProcessor(grammars)],pad_token_id=tokenizer.pad_token_id)
            elapsed=time.perf_counter()-begun
            with output.open('a') as f:
                for i,(r,request,ids) in enumerate(zip(batch,requests,outputs[:,inputs.input_ids.shape[1]:])):
                    ids=ids.tolist()
                    if tokenizer.eos_token_id in ids:ids=ids[:ids.index(tokenizer.eos_token_id)]
                    row=dict(claim_id=r['claim_id'],condition=condition,request=request,request_hash=hashlib.sha256(json.dumps(request,sort_keys=True).encode()).hexdigest(),
                        raw=tokenizer.decode(ids,skip_special_tokens=True),input_tokens=int(inputs.attention_mask[i].sum()),output_tokens=len(ids),
                        finish_reason='length' if len(ids)>=1536 else 'stop',batch_seconds=elapsed,batch_size=len(batch))
                    f.write(json.dumps(row,ensure_ascii=False)+'\n')
            print(condition,start+len(batch),'/',len(todo),'seconds',round(elapsed,2),flush=True)

if __name__=='__main__':main()
