import copy,json
from pathlib import Path
import pytest
from probabilistic_verification.logical_form import LogicalFormError
from probabilistic_verification.logical_form_v2 import ScopedCompiler
from probabilistic_verification.srl_graph import srl_graph_form
from probabilistic_verification.srl_revision import TokenAlignment,revision_input,revision_schema,revised_record

CASES=json.loads((Path(__file__).parent/'fixtures/srl_graph_cases.json').read_text())

def compile_case(index):
    r=CASES[index];f=srl_graph_form(r)
    return ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],f,additional_proposition_kinds={'relative','complement'})

def test_token_references_cannot_invent_source_words_or_version_fields():
    r=CASES[4];data=revision_input(r)
    assert 'version' not in json.dumps(data) and 'version' not in revision_schema(len(data['tokens']))['properties']
    p=dict(frames=[dict(predicate=3,arguments=[dict(role='ARG1',span=[0,0])])])
    updated=revised_record(r,p)
    assert updated['srl']['frames'][0]['args'][0]['text']=='IM-1'
    assert updated['text']==r['text']
    p['frames'][0]['arguments'][0]['span']=[0,999]
    with pytest.raises(LogicalFormError,match='outside'):revised_record(r,p)

def test_split_tokenizer_name_stays_complete():
    c=compile_case(4)
    assert any(v.description=='IM-1' for v in c.variables)
    assert any('Odysseus' in a.arguments for a in c.atoms)

def test_repeated_time_modifiers_are_both_required():
    c=compile_case(1);render=c.to_dict()['logical_form']
    assert 'second time' in render and '9:20:33am' in render

def test_seen_event_does_not_drop_the_other_clause_or_become_a_world_conjunct():
    c=compile_case(0);events=c.metadata['events'].values()
    assert any(e['predicate']=='get' and e['scope']=='world' for e in events)
    assert any(e['predicate']=='fight' and e['scope']!='world' for e in events)
    assert 'intense' in c.to_dict()['logical_form']

def test_group_members_keep_their_own_modifiers():
    c=compile_case(5);form=c.metadata['logical_form'];entities=form['entities']
    personnel=next(e for e in entities if e['text']=='personnel')
    civilians=next(e for e in entities if e['text']=='civilians')
    assert any(p['value']=='military' for p in personnel.get('properties',[]))
    assert not civilians.get('properties')
    assert sum(a.predicate=='entity_relation' and 'member' in a.arguments for a in c.atoms)==2

def test_full_written_quote_stays_in_the_sign_description():
    c=compile_case(6)
    read=next(e for e in c.metadata['events'].values() if e['predicate']=='say')
    assert read['route']=='ocr_assertion' and read['scope']!='world'
    assert any(isinstance(v,dict) and v.get('kind')=='verbatim_text' and v['value']=='Carlos Manzo, Mexican hero' for v in read['arguments'].values())
    assert not any(v.description.startswith('Carlos') for v in c.variables)

def test_a_noun_does_not_create_an_unstated_gloving_event():
    c=compile_case(3)
    assert not any(e['predicate']=='glove' for e in c.metadata['events'].values())
    assert any(v.description=='gloves' for v in c.variables)

def test_attempt_content_stays_under_the_attempt():
    c=compile_case(7)
    attempts=[e for e in c.metadata['events'].values() if e['predicate']=='try']
    assert attempts
    p=next(p for p in attempts[0].get('propositions',[]) if p['kind']=='purpose')
    assert p['body']['predicate']=='support'
    assert all(e['scope']!='world' for e in c.metadata['events'].values() if e['predicate']=='support')

def test_unsupported_negative_existential_is_not_accepted_as_positive():
    with pytest.raises(LogicalFormError,match='negative|negation'):compile_case(2)

def test_duplicate_model_predicates_are_explicit_errors():
    r=CASES[4];f=dict(predicate=3,arguments=[])
    with pytest.raises(LogicalFormError,match='Repeated'):revised_record(r,dict(frames=[f,f]))

def test_empty_edit_lists_preserve_the_exact_original_srl_including_reference_roles():
    from probabilistic_verification.srl_edits import patched_record
    for r in CASES:
        assert patched_record(r,dict(edits=[],remove_predicates=[],add_frames=[]))==r

def test_span_edit_keeps_its_role_and_does_not_mutate_the_source():
    from probabilistic_verification.srl_edits import patched_record
    r=CASES[4];before=copy.deepcopy(r)
    out=patched_record(r,dict(edits=[dict(predicate=3,argument=0,span=[0,0])],remove_predicates=[],add_frames=[]))
    f=next(f for f in out['srl']['frames'] if f.get('verb_span')==[3,3])
    assert f['args'][0]['role']=='ARG1' and f['args'][0]['text']=='IM-1'
    assert r==before

def test_invalid_edit_references_and_spans_are_refused():
    from probabilistic_verification.srl_edits import patched_record
    for edit in [dict(predicate=999,argument=0,span=[0,0]),dict(predicate=3,argument=999,span=[0,0]),dict(predicate=3,argument=0,span=[2,0])]:
        with pytest.raises(LogicalFormError):patched_record(CASES[4],dict(edits=[edit],remove_predicates=[],add_frames=[]))

def test_only_new_predicates_licensed_by_syntax_can_be_added():
    from probabilistic_verification.srl_edits import patched_record,edit_input
    r=CASES[4];existing=edit_input(r)['srl']['frames'][0]['predicate']
    with pytest.raises(LogicalFormError,match='syntactic'):
        patched_record(r,dict(edits=[],remove_predicates=[],add_frames=[dict(predicate=existing,arguments=[])]))
