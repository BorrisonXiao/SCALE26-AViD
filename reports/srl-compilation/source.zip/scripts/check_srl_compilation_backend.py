#!/usr/bin/env python3
"""Bounded native DeepProbLog checks with deliberately unknown evidence."""
import argparse,json,subprocess,sys,time
from pathlib import Path
from probabilistic_verification.logical_form_v2 import ScopedCompiler
from probabilistic_verification.logic import Evidence,ground
from probabilistic_verification.backend import DeepProbLogVerifier
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/srl_revision_20261029'
def read(name):return [json.loads(s) for s in (RUN/name).read_text().splitlines() if s.strip()]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--single');a=ap.parse_args()
    if a.single:
        rec=next(r for r in read('inputs.jsonl') if r['claim_id']==a.single)
        row=next(r for r in read('srl_graph_results.jsonl') if r['claim_id']==a.single)
        c=ScopedCompiler().compile(rec['claim_id'],rec['text'],rec['tokens'],row['proposed_form'],additional_proposition_kinds={'relative','complement'})
        evidence=Evidence('no-media',{v.name:[v.name.lower()] for v in c.variables},{v.name:True for v in c.variables},{})
        begun=time.perf_counter();out=DeepProbLogVerifier([ground(c,evidence,max_expansions=10000)],learned=False).predict()[0]
        assert abs(out['distribution']['unknown']-1)<1e-9
        print(json.dumps(dict(claim_id=rec['claim_id'],distribution=out['distribution'],seconds=time.perf_counter()-begun)));return
    results=[]
    for cid in ['TzF9M4kZ3Pys_281','TQEmEycTI0RQ_899']:
        try:
            p=subprocess.run([sys.executable,__file__,'--single',cid],capture_output=True,text=True,timeout=30)
            if p.returncode:raise RuntimeError(p.stderr[-1000:])
            results.append(dict(status='passed',**json.loads(p.stdout.splitlines()[-1])))
        except Exception as e:results.append(dict(claim_id=cid,status='failed_or_timeout',reason=str(e)))
    data=dict(description='Two actual DeepProbLog ExactEngine executions on new SRL graphs, including a qualified event and a relative-clause description. Every observation is deliberately unknown. This is neither media verification nor whole-corpus inference throughput.',cases=results)
    (RUN/'native_checks.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2))
if __name__=='__main__':main()
