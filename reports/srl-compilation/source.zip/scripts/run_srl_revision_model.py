#!/usr/bin/env python3
"""Compare concise UD/SRL revision with and without pretrained AMR context."""
import argparse,hashlib,importlib.metadata,json,os,shutil,time
from pathlib import Path
import prompts_phase2 as P
from probabilistic_verification.srl_revision import revision_input,revision_schema

ROOT=Path(__file__).resolve().parents[1]
PREVIOUS=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
RUN=ROOT/'exp/probabilistic_verification/srl_revision_20261029'
def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=PREVIOUS/'repaired_inputs.jsonl')
    ap.add_argument('--condition',choices=['srl','amr','both'],default='both')
    ap.add_argument('--tensor-parallel',type=int,default=1);ap.add_argument('--limit',type=int)
    ap.add_argument('--pilot-size',type=int,default=24);ap.add_argument('--continue-file',type=Path)
    a=ap.parse_args();RUN.mkdir(exist_ok=True)
    records=read(a.input)
    if a.limit:records=records[:a.limit]
    amrs={r['request']['task']['claim_id']:r['raw'] for i in range(4) for r in read(PREVIOUS/f'amr_{i}_raw.jsonl')}
    job=os.getenv('SLURM_JOB_ID','local');snapshot=RUN/('source_'+job);hashes={}
    for source in [Path(__file__),ROOT/'scripts/prompts_phase2.py',ROOT/'scripts/probabilistic_verification/srl_revision.py']:
        rel=source.relative_to(ROOT);target=snapshot/rel;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target);hashes[str(rel)]=hashlib.sha256(source.read_bytes()).hexdigest()
    (snapshot/'manifest.json').write_text(json.dumps(hashes,indent=2)+'\n')
    from vllm import LLM,SamplingParams
    from vllm.sampling_params import StructuredOutputsParams
    model='/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507'
    llm=LLM(model=model,dtype='float16',tensor_parallel_size=a.tensor_parallel,max_model_len=12288,
            max_num_seqs=32,gpu_memory_utilization=.90,enforce_eager=True,enable_prefix_caching=True)
    tokenizer=llm.get_tokenizer();conditions=['srl','amr'] if a.condition=='both' else [a.condition]
    config=dict(model=model,dtype='float16',temperature=0.,prompt_version=P.SRL_REVISION_PROMPT_VERSION,
        vllm=importlib.metadata.version('vllm'),slurm_job_id=job,source_sha256=hashes,
        input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
        model_config_sha256=hashlib.sha256((Path(model)/'config.json').read_bytes()).hexdigest())
    def generate(batch_records):
        for condition in conditions:
            output=RUN/(condition+'_raw.jsonl');done={r['claim_id'] for r in read(output)} if output.exists() else set()
            todo=[r for r in batch_records if r['claim_id'] not in done]
            for start in range(0,len(todo),128):
                batch=todo[start:start+128];requests=[];prompts=[];params=[]
                for r in batch:
                    data=revision_input(r,amrs[r['claim_id']] if condition=='amr' else None)
                    messages=[dict(role='system',content=P.SRL_REVISION_SYSTEM),dict(role='user',content=P.srl_revision_user(data))]
                    request=dict(claim_id=r['claim_id'],condition=condition,messages=messages,config=config)
                    requests.append(request);prompts.append(tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True))
                    budget=min(3072,max(512,45*len(data['tokens'])))
                    params.append(SamplingParams(temperature=0,max_tokens=budget,structured_outputs=StructuredOutputsParams(json=revision_schema(len(data['tokens'])))))
                begun=time.perf_counter();outputs=llm.generate(prompts,params,use_tqdm=False);elapsed=time.perf_counter()-begun
                with output.open('a') as f:
                    for request,out in zip(requests,outputs):
                        response=out.outputs[0]
                        f.write(json.dumps(dict(claim_id=request['claim_id'],condition=condition,request=request,
                            request_hash=hashlib.sha256(json.dumps(request,sort_keys=True).encode()).hexdigest(),raw=response.text,
                            input_tokens=len(out.prompt_token_ids),output_tokens=len(response.token_ids),finish_reason=response.finish_reason,
                            batch_seconds=elapsed,batch_size=len(batch)),ensure_ascii=False)+'\n')
                print(condition,start+len(batch),'/',len(todo),'seconds',round(elapsed,2),flush=True)
    if a.pilot_size:
        generate(records[:a.pilot_size]);print('PILOT_READY',flush=True)
        if not a.continue_file:return
        deadline=time.monotonic()+1800
        while not a.continue_file.exists():
            if time.monotonic()>deadline:raise TimeoutError('Internal pilot inspection did not complete.')
            time.sleep(5)
        if a.continue_file.read_text().strip()!='continue':return
    generate(records)

if __name__=='__main__':main()
