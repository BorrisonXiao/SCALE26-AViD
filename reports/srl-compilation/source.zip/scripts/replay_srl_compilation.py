#!/usr/bin/env python3
"""Reproduce all independently run SRL compilation conditions from cached input."""
import json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/srl_revision_20261029'
def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def identity(r):return r['claim_id'],r['status'],r.get('code'),r.get('program_sha256'),r.get('diagnostics')
def main():
    with tempfile.TemporaryDirectory(prefix='avid-srl-replay-') as tmp:
        for name,raw in [('srl_graph',None),('srl','srl_raw.jsonl'),('amr','amr_raw.jsonl')]:
            output=Path(tmp)/(name+'.jsonl')
            command=[sys.executable,str(ROOT/'scripts/run_srl_revision_census.py'),'--output',str(output)]
            if raw:command+=['--raw',str(RUN/raw)]
            subprocess.run(command,cwd=ROOT,check=True,capture_output=True)
            expected=read(RUN/(name+'_results.jsonl'));actual=read(output)
            assert [identity(r) for r in actual]==[identity(r) for r in expected],name
            print(name,':',len(actual),'outcomes and program hashes match.')
if __name__=='__main__':main()
