#!/usr/bin/env python3
"""Readable semantic structures for paired assistant inspection."""
import argparse,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/srl_revision_20261029'
def read(path):return [json.loads(s) for s in path.read_text().splitlines() if s.strip()]

def describe(form):
    entities={e['id']:e for e in form.get('entities',[])};shown=set()
    def entity(ref):
        e=entities.get(ref)
        if not e:return str(ref)
        value=ref+':'+e['text']
        if ref in shown:return value
        shown.add(ref)
        if e.get('properties'):value+=' '+str(e['properties'])
        if e.get('quantity'):value+=' QUANTITY '+str(e['quantity'])
        for r in e.get('relations',[]):value+=' ['+r['role']+'='+entity(r['target'])+']'
        for p in e.get('propositions',[]):value+=' ['+p['role']+'/'+p['kind']+'='+node(p['body'])+']'
        return value
    def node(n):
        op=n.get('op')
        if op=='entity':return entity(n['ref'])
        if op in {'and','or'}:return op.upper()+'('+ '; '.join(node(c) for c in n['children'])+')'
        if op=='not':return 'NOT('+node(n['child'])+')'
        if op=='qualified':return n['operator'].upper()+'('+node(n['body'])+')'
        if op=='event':
            args=[r+'='+ (entity(a) if isinstance(a,str) else str(a)) for r,a in n.get('arguments',{}).items()]
            for p in n.get('propositions',[]):args.append(p['role']+'/'+p['kind']+'/'+p.get('route','unspecified')+'={'+node(p['body'])+'}')
            if n.get('properties'):args.append('PROPERTIES='+str(n['properties']))
            return n['predicate']+'('+', '.join(args)+')'
        return str(n)
    return node(form.get('formula',{}))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--cohort',choices=['development_pilot','review_ids'],default='development_pilot');ap.add_argument('--start',type=int,default=0);ap.add_argument('--end',type=int,default=24);ap.add_argument('--method',default='all');a=ap.parse_args()
    ids=json.loads((RUN/'sample_manifest.json').read_text())[a.cohort]
    paths=[('previous_srl',ROOT/'exp/probabilistic_verification/full_compilation_20261029/srl_v2_results.jsonl'),('trained_srl',RUN/'srl_graph_results.jsonl'),('revised_ud_srl',RUN/'srl_results.jsonl'),('revised_ud_srl_amr',RUN/'amr_results.jsonl')]
    data={name:{r['claim_id']:r for r in read(path)} for name,path in paths if path.exists() and a.method in {'all',name}}
    for i,cid in enumerate(ids[a.start:a.end],a.start):
        r=next((records[cid] for records in data.values() if cid in records),None)
        if not r:continue
        print('\nCASE',i,cid,'TEXT:',r['text'])
        for name,records in data.items():
            if cid not in records:continue
            r=records[cid];print(name,r['status'],r.get('code',''),r.get('reason',''))
            if r.get('proposed_form'):print(describe(r.get('compilation',{}).get('metadata',{}).get('logical_form',r['proposed_form'])))
            if r.get('diagnostics'):print('FLAGS',r['diagnostics'])

if __name__=='__main__':main()
