"""Minimal SRL post-editing: source spans, removals and missing frames.

An existing argument keeps its PropBank role. This rules out blind role
renumbering; it also deliberately cannot repair a wrong existing role label.
"""
import copy
from .logical_form import LogicalFormError
from .srl_revision import TokenAlignment,revision_input,revision_schema,revised_record

def edit_input(record,amr=None):
    data=revision_input(record,amr);a=TokenAlignment(record)
    existing={f['predicate'] for f in data['srl']['frames']}
    children={t['id']:[] for t in record['tokens']}
    for t in record['tokens']:
        if t['head'] in children:children[t['head']].append(t)
    candidates=[]
    for t in record['tokens']:
        index=a.word_index(t)
        predicative=t['upos']=='VERB' or t['deprel']=='cop' or t['upos'] in {'ADJ','NOUN'} and any(u['deprel'].startswith('nsubj') or u['deprel']=='cop' for u in children[t['id']])
        if predicative and index not in existing and index not in candidates:candidates.append(index)
    data['new_predicate_candidates']=candidates
    return data

def edit_schema(record):
    data=edit_input(record);n=len(data['tokens']);base=revision_schema(n);frame=copy.deepcopy(base['properties']['frames']['items'])
    integer=dict(type='integer',minimum=0,maximum=n-1)
    def obj(props,required):return dict(type='object',properties=props,required=required,additionalProperties=False)
    existing=[f['predicate'] for f in data['srl']['frames']];candidates=data['new_predicate_candidates']
    predicate=dict(type='integer',enum=existing) if existing else integer
    edit=obj(dict(predicate=predicate,argument=dict(type='integer',minimum=0),span=dict(type='array',items=integer,minItems=2,maxItems=2)),['predicate','argument','span'])
    edits=dict(type='array',items=edit);drops=dict(type='array',items=predicate)
    additions=dict(type='array',items=frame)
    if not existing:edits['maxItems']=0;drops['maxItems']=0
    if candidates:frame['properties']['predicate']=dict(type='integer',enum=candidates)
    else:additions['maxItems']=0
    return obj(dict(edits=edits,remove_predicates=drops,add_frames=additions),['edits','remove_predicates','add_frames'])

def patched_record(record,proposal):
    data=edit_input(record);out=copy.deepcopy(record);alignment=TokenAlignment(record)
    frames=out['srl']['frames'];by_predicate={f['verb_span'][0]:f for f in frames if f.get('args') and isinstance(f.get('verb_span'),list)};seen=set()
    for edit in proposal['edits']:
        key=edit['predicate'],edit['argument']
        if key in seen:raise LogicalFormError('duplicate_edit','The same argument is edited more than once.')
        seen.add(key)
        if key[0] not in by_predicate or not 0<=key[1]<len(by_predicate[key[0]]['args']):
            raise LogicalFormError('edit_reference','Edit refers to an absent predicate/argument.')
        start,end=edit['span'];surface=alignment.surface(start,end)
        by_predicate[key[0]]['args'][key[1]].update(start=start,end=end,text=surface)
    dropped=set(proposal['remove_predicates'])
    if not dropped<=set(by_predicate):raise LogicalFormError('edit_reference','Removal refers to an absent frame.')
    additions=proposal['add_frames']
    if any(f['predicate'] not in data['new_predicate_candidates'] for f in additions):
        raise LogicalFormError('new_predicate','New predicate lacks a syntactic predicate candidate.')
    out['srl']['frames']=[f for f in frames if not isinstance(f.get('verb_span'),list) or f['verb_span'][0] not in dropped]
    out['srl']['frames']+=revised_record(record,dict(frames=additions))['srl']['frames']
    return out
