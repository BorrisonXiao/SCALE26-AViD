#!/usr/bin/env python3
"""Aggregate independently run compiler conditions and saved assistant reviews."""
import hashlib,json,statistics
from collections import Counter
from pathlib import Path
import jsonschema
import prompts_phase2 as P
from probabilistic_verification.srl_edits import edit_schema,patched_record
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/srl_revision_20261029'
OLD=ROOT/'exp/probabilistic_verification/full_compilation_20261029'
PATHS={'previous_srl':RUN/'previous_srl_results.jsonl','trained_srl':RUN/'srl_graph_results.jsonl',
    'revised_ud_srl':RUN/'srl_results.jsonl','revised_ud_srl_amr':RUN/'amr_results.jsonl'}
def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def load(name):return json.loads((RUN/name).read_text())

def main():
    inputs={r['claim_id']:r for r in read(RUN/'inputs.jsonl')};sample=load('sample_manifest.json')
    data={k:{r['claim_id']:r for r in read(p)} for k,p in PATHS.items() if p.exists()}
    selected=sample['development_pilot']+sample['review_ids']
    summary={}
    for method,records in data.items():
        rows=list(records.values());accepted=[r for r in rows if r['status']=='compiled']
        summary[method]=dict(total=len(rows),compiled=len(accepted),refused=len(rows)-len(accepted),
            kinds=Counter(r['compilation']['metadata']['kind'] for r in accepted),
            failures=Counter(r.get('code') for r in rows if r['status']!='compiled'),
            paired48_compiled=sum(records[c]['status']=='compiled' for c in selected if c in records),
            paired48_attempted=sum(c in records for c in selected),
            review24_compiled=sum(records[c]['status']=='compiled' for c in sample['review_ids'] if c in records),
            diagnostics=Counter(d['code'] for r in rows for d in r.get('diagnostics',[])))
    raw_summaries={}
    for condition in ['srl','amr']:
        path=RUN/(condition+'_raw.jsonl')
        if not path.exists():continue
        rows=read(path);valid=0;changed=0;nonempty=0;operations=Counter();effective=Counter();errors=Counter();references_valid=0
        for r in rows:
            rec=inputs[r['claim_id']]
            try:proposal=json.loads(r['raw']);jsonschema.validate(proposal,edit_schema(rec))
            except Exception as e:errors[type(e).__name__]+=1;continue
            valid+=1
            for k,v in proposal.items():operations[k]+=len(v)
            if any(proposal.values()):nonempty+=1
            try:revised=patched_record(rec,proposal)
            except Exception as e:errors[getattr(e,'code',type(e).__name__)]+=1;continue
            references_valid+=1
            if revised!=rec:changed+=1
            # Count actual span changes separately from repeated unchanged spans.
            old={f['verb_span'][0]:f for f in rec['srl']['frames'] if f.get('args') and isinstance(f.get('verb_span'),list)}
            for e in proposal['edits']:
                arg=old[e['predicate']]['args'][e['argument']]
                effective['changed_spans']+=e['span']!=[arg['start'],arg['end']]
                effective['unchanged_spans']+=e['span']==[arg['start'],arg['end']]
        raw_summaries[condition]=dict(requests=len(rows),schema_valid=valid,valid_edit_references=references_valid,edit_errors=errors,finish_reasons=Counter(r['finish_reason'] for r in rows),
            mean_input_tokens=statistics.mean(r['input_tokens'] for r in rows),mean_output_tokens=statistics.mean(r['output_tokens'] for r in rows),
            nonempty_edit_lists=nonempty,records_changed_including_source_spacing=changed,operations=operations,effective_span_edits=effective,
            core_role_renaming_supported=False,decoding='Greedy float16, Transformers 4.57.6 and XGrammar, same frozen 30B model. Existing roles inherited; additions have PropBank roles.')
    annotations=load('srl_review_annotations.json')
    if (RUN/'llm_review_annotations.json').exists():annotations+=load('llm_review_annotations.json')
    reviews=[]
    for r in annotations:
        cid=sample['review_ids'][r['index']];record=data[r['method']][cid]
        assert (record['status']=='compiled')==(r['judgment']!='refused'),(r['method'],cid,r['judgment'])
        reviews.append(dict(r,claim_id=cid,text=record['text']))
    review_counts={m:Counter(r['judgment'] for r in reviews if r['method']==m) for m in data}
    before=data['previous_srl'];after=data['trained_srl'];transitions=Counter()
    for cid in inputs:
        old=before[cid]['status']=='compiled';new=after[cid]['status']=='compiled'
        transitions['both_compiled' if old and new else 'new_only' if new else 'previous_only' if old else 'both_refused']+=1
    result=dict(conditions=summary,model_runs=raw_summaries,review_counts=review_counts,transitions=transitions,
        prompt_words=dict(previous_free_logical_form=len(P.FULL_COMPILATION_CONSTRAINED_SYSTEM.split()),
            first_srl_regeneration=len(P.SRL_REVISION_SYSTEM.split()),minimal_edits=len(P.SRL_EDIT_SYSTEM.split())),
        protocol='Within-corpus development. Full SRL conditions run on all 2,375 original claims. The two model conditions use the same 48 inputs: 24 known development-pilot cases and 24 additional IDs sampled uniformly before generation. The same assistant reviews the 24 random cases under all conditions. The SRL graph was frozen before that review; the restricted edit interface followed a separate 12-output regeneration pilot that changed correct roles. This is not human gold or a source-disjoint generalization study. Compilation counts do not establish semantic faithfulness.',
        source_sha256={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in PATHS.items() if p.exists()})
    (RUN/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    (RUN/'quality_review.json').write_text(json.dumps(dict(protocol=result['protocol'],counts=review_counts,cases=reviews),indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(dict(conditions=summary,review_counts=review_counts,prompt_words=result['prompt_words']),indent=2))

if __name__=='__main__':main()
