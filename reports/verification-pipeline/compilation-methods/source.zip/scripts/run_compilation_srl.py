#!/usr/bin/env python3
"""Fill only missing control-claim SRL frames using the existing cached model."""
import json
import time
from pathlib import Path

from run_srl_baseline import bio_to_spans

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compilation_methods_20261028'

if __name__=='__main__':
    from allennlp.predictors.predictor import Predictor
    import torch
    torch.set_num_threads(2)
    metadata=next(json.loads(p.read_text()) for p in Path('/home/hltcoe/cxiao/.allennlp/cache').glob('*.json')
        if 'structured-prediction-srl-bert' in p.read_text())
    predictor=Predictor.from_path(metadata['cached_path'],cuda_device=-1)
    rows=[json.loads(s) for s in (RUN/'inputs.jsonl').read_text().splitlines()]
    pending=[r for r in rows if r['srl'] is None];started=time.perf_counter()
    outputs=predictor.predict_batch_json([{'sentence':r['text']} for r in pending])
    for row,out in zip(pending,outputs):
        words=out['words'];frames=[]
        for v in out['verbs']:
            spans=bio_to_spans(v['tags'])
            verb=next(([s,e] for role,s,e in spans if role=='V'),None)
            frames.append(dict(verb=v['verb'],verb_span=verb,args=[dict(role=role,start=s,end=e,text=' '.join(words[s:e+1])) for role,s,e in spans if role!='V']))
        row['srl']=dict(claim_id=row['claim_id'],words=words,frames=frames)
    (RUN/'inputs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    (RUN/'control_srl_provenance.json').write_text(json.dumps(dict(model=metadata,device='cpu',claims=len(pending),prediction_seconds=time.perf_counter()-started),indent=2)+'\n')
    print('Filled',len(pending),'trained SRL control records')
