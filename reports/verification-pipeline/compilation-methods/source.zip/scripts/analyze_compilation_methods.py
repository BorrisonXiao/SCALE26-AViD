#!/usr/bin/env python3
"""Replay saved text parses, compile them, and check backend executability.

The backend receives artificial unknown observations. This checks generated
programs, not claims against media. No parser or relation model is trained.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import logging
from pathlib import Path
import time
import subprocess
import sys
import penman
from probabilistic_verification.compilation_frontends import srl_graph
from probabilistic_verification.predicate_compilation import PredicateCompiler, clean_graph
from probabilistic_verification.logic import Evidence, ground, prolog_program

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compilation_methods_20261028'
METHODS={'srl':'Trained SRL + dependency-assisted rules', 'amr':'Pretrained BART AMR + post-processing',
         'direct':'Frozen 8B text model → predicate graph','guided':'Dependency/SRL-assisted frozen 8B → predicate graph'}

def read(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]

def write(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def graph_valid(raw):
    graphs=list(penman.iterdecode(clean_graph(raw or '')))
    if len(graphs)!=1:return False
    g=graphs[0];instances=g.instances()
    return bool(instances) and len({t.source for t in instances})==len(instances)

def backend_check(claim):
    from probabilistic_verification.backend import DeepProbLogVerifier
    evidence=Evidence('compiler_syntax_control',{v.name:['placeholder:'+v.name] for v in claim.variables},
                      {v.name:True for v in claim.variables},{})
    p=ground(claim,evidence)
    started=time.perf_counter()
    verifier=DeepProbLogVerifier([p],learned=False)
    prediction=verifier.predict()[0]
    return dict(accepted=True,seconds=time.perf_counter()-started,
                query_states=list(prediction['distribution']),
                note='All observations are unknown placeholders. No media verification.'),verifier.program

def main():
    ap=argparse.ArgumentParser(__doc__);ap.add_argument('--run-dir',type=Path,default=RUN)
    ap.add_argument('--skip-backend',action='store_true');args=ap.parse_args();run=args.run_dir
    logging.getLogger('penman').setLevel(logging.ERROR)
    inputs=read(run/'inputs.jsonl');compiler=PredicateCompiler();rows=[]
    rawsets={m:read(run/(m+'_raw.jsonl')) if m=='amr' else [r for i in (0,1) for r in read(run/f'{m}_{i}_raw.jsonl')]
             for m in ('amr','direct','guided')}
    for m,raw in rawsets.items():
        assert len(raw)==len(inputs)==len({r['request']['task']['claim_id'] for r in raw}), (m,len(raw))
        write(run/(m+'_combined_raw.json'),raw)
    for method in METHODS:
        rawmap={r['request']['task']['claim_id']:r for r in rawsets.get(method,[])}
        for record in inputs:
            cid=record['claim_id'];raw=rawmap.get(cid)
            row=dict(method=method,claim_id=cid,text=record['text'],cohort=record['cohort'],
                     review_diagnostic=record['review_diagnostic'],graph_valid=False,status='unsupported')
            try:
                graph=srl_graph(record) if method=='srl' else raw['raw']
                row['graph']=graph;
                try:row['graph_valid']=graph_valid(graph)
                except Exception:row['graph_valid']=False
                claim=compiler.compile(cid,record['text'],graph or '',record['tokens'],provenance={'method':method})
                row.update(status='compiled',compilation=claim.to_dict())
                evidence=Evidence('compiler_syntax_control',{v.name:['placeholder:'+v.name] for v in claim.variables},
                                  {v.name:True for v in claim.variables},{})
                program=ground(claim,evidence)
                row['program']=prolog_program([program],learned=False)[0]
                from problog.program import PrologString
                list(PrologString(row['program']))
                row['program_syntax_valid']=True
                if not args.skip_backend and cid in {'contrast_06','contrast_09','contrast_10','contrast_13','T2G_ACMxR_I4_1396'}:
                    try:
                        result=subprocess.run([sys.executable,str(Path(__file__).with_name('check_compilation_backend.py'))],
                            input=json.dumps(dict(claim_id=cid,text=record['text'],graph=graph,tokens=record['tokens'])),
                            text=True,capture_output=True,timeout=10,check=True)
                        row['backend']=json.loads(result.stdout.strip().splitlines()[-1])
                    except subprocess.TimeoutExpired:
                        row['backend']=dict(accepted=False,error='Execution exceeded the 10-second subprocess limit.')
                    except Exception as error:row['backend']=dict(accepted=False,error=type(error).__name__+': '+str(error))
                print(method,cid,row['status'],flush=True)
            except Exception as error:
                row.update(code=getattr(error,'code',type(error).__name__),message=str(error))
            if raw:row['request_hash']=raw['request_hash']
            rows.append(row)
    (run/'results.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    summary={'date':'2026-10-28','task':'Claim compilation only','real_claims':79,'constructed_controls':21,
             'interpretation':'Coverage and backend acceptance are not semantic accuracy.', 'backend_policy':'Parse generated Prolog for every compiled input; execute five selected cases per method in isolated 10-second subprocesses. Artificial unknown observations only.', 'methods':{}}
    for method in METHODS:
        summary['methods'][method]={'name':METHODS[method]}
        for cohort,selected in [('real',[r for r in rows if r['method']==method and r['cohort'].startswith('real')]),
                                ('controls',[r for r in rows if r['method']==method and r['cohort']=='constructed_contrast'])]:
            summary['methods'][method][cohort]=dict(total=len(selected),graph_valid=sum(r['graph_valid'] for r in selected),
                compiled=sum(r['status']=='compiled' for r in selected),
                program_syntax_valid=sum(r.get('program_syntax_valid',False) for r in selected),
                backend_attempted=sum('backend' in r for r in selected),
                backend_accepted=sum(r.get('backend',{}).get('accepted',False) for r in selected),
                diagnostics=sum(bool(r.get('compilation',{}).get('warnings')) for r in selected),
                rejection_codes=dict(Counter(r['code'] for r in selected if r['status']!='compiled')))
    summary['input_sha256']=hashlib.sha256((run/'inputs.jsonl').read_bytes()).hexdigest()
    summary['legacy_reference']={'v1':20,'schema_heavy_8b_v2':11,'denominator':79,'note':'Historical compilers use stricter, different supported fragments. Counts alone do not establish improvement.'}
    summary['predpatt']={'available':sum(r['status']=='parsed' for r in read(run/'predpatt_raw.jsonl')),
                        'total':100,'note':'Extraction diagnostic only; no scope-aware PredPatt compiler is claimed.'}
    write(run/'summary.json',summary);print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
