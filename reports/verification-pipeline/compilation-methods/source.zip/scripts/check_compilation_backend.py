#!/usr/bin/env python3
"""Isolated, bounded-by-parent execution check; consumes one saved graph."""
import json
import sys
from analyze_compilation_methods import backend_check
from probabilistic_verification.predicate_compilation import PredicateCompiler
r=json.load(sys.stdin)
c=PredicateCompiler().compile(r['claim_id'],r['text'],r['graph'],r['tokens'])
result,program=backend_check(c)
print(json.dumps(result))
