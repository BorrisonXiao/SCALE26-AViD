#!/usr/bin/env python3
"""Replay all saved graphs without models and compare the frozen compilation."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compilation_methods_20261028'

def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

with tempfile.TemporaryDirectory(prefix='avid-compile-') as directory:
    out=Path(directory)
    for name in ['inputs.jsonl','amr_raw.jsonl','predpatt_raw.jsonl']+[f'{m}_{i}_raw.jsonl' for m in ['direct','guided'] for i in [0,1]]:
        shutil.copy2(RUN/name,out/name)
    subprocess.run([sys.executable,str(ROOT/'scripts/analyze_compilation_methods.py'),'--run-dir',str(out),'--skip-backend'],
                   check=True,stdout=subprocess.DEVNULL)
    old=read(RUN/'results.jsonl');new=read(out/'results.jsonl')
    assert len(old)==len(new)==400
    for a,b in zip(old,new):
        for key in ['method','claim_id','status','code','graph_valid','compilation','program','program_syntax_valid']:
            assert a.get(key)==b.get(key),(a['method'],a['claim_id'],key)
    print('Reproduced all 400 saved compilation outcomes and programs. No models, media, or training.')
