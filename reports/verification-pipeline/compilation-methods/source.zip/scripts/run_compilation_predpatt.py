#!/usr/bin/env python3
"""Reuse the installed PredPatt extractor on cached current UD analyses."""
import json
from pathlib import Path

from predpatt import PredPatt,PredPattOpts,load_conllu

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compilation_methods_20261028'

if __name__=='__main__':
    rows=[json.loads(s) for s in (RUN/'inputs.jsonl').read_text().splitlines()]
    with (RUN/'predpatt_raw.jsonl').open('w') as out:
        for row in rows:
            result=dict(claim_id=row['claim_id'],text=row['text'])
            try:
                conllu='\n'.join('\t'.join(map(str,[t['id'],t['text'],t.get('lemma','_'),t['upos'],'_',t.get('feats') or '_',t['head'],t['deprel'],'_','_'])) for t in row['tokens'])
                if not conllu:raise ValueError('No cached single-sentence dependency analysis')
                parse=next(load_conllu(conllu))[1]
                extraction=PredPatt(parse,opts=PredPattOpts(ud='2.0',resolve_conj=False,resolve_relcl=False,resolve_amod=False,resolve_poss=False))
                facts=[]
                for event in extraction.instances:
                    facts.append(dict(predicate=' '.join(t.text for t in event.tokens),root=event.root.position,
                        arguments=[dict(text=' '.join(t.text for t in a.tokens),root=a.root.position) for a in event.arguments]))
                result.update(status='parsed',frames=facts,pretty=extraction.pprint())
            except Exception as e:result.update(status='refused',message=str(e))
            out.write(json.dumps(result,ensure_ascii=False)+'\n')
    print('PredPatt records',len(rows))
