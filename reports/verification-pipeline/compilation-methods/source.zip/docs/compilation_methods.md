# Claim compilation: comparison and next plan

Updated 2026-10-28. Compilation is the current priority. Media verification and new relation-classifier training remain deferred.

The experiment is `exp/probabilistic_verification/compilation_methods_20261028/`.
It compares the same 79 previously reviewed development claims and 21 constructed
linguistic controls. These are development inputs, not an independent accuracy test.

## Separate the tasks

1. **Semantic parsing:** infer predicates, argument roles, shared referents and logical scope from the claim.
2. **Logical-form construction:** represent those choices with variables and operators such as AND, OR, NOT and EXISTS.
3. **Compilation:** turn that representation into the existing three-state DeepProbLog program. Candidate domains and evidence probabilities are supplied later.

DeepProbLog supplies probabilistic inference and learning over the program. It
does not tell us whether the program expresses the original English sentence.

## Implemented comparison

- Frozen dependency compiler: historical reference, unchanged.
- Trained BERT semantic role labeling (SRL), with dependency-assisted lemma,
  coordination and tense handling, followed by rules that construct a graph.
- Pretrained amrlib BART-large Abstract Meaning Representation (AMR) parser,
  followed by a restricted graph-to-logical-form compiler.
- Frozen Qwen3-VL-8B, used with text only, generating an AMR-style graph directly.
- The same frozen 8B model assisted by dependency and trained-SRL analyses.
- PredPatt extraction is an additional CPU diagnostic. It has not been connected
  to a complete scope-aware compiler.

The four new compiler routes share `PredicateCompiler`. PENMAN is a graph
serialization, not a new semantic formalism. The SRL-derived graphs are not full
AMRs. PropBank's ARG labels are predicate-specific: ARG0 does not always mean agent.
All authored model prompts remain in `scripts/prompts_phase2.py`.

## What the pilot compiler preserves

Relations have an event variable and explicit role/value arguments, so role changes
change evidence lookup keys. Shared graph nodes become shared variables. Graph AND
and OR determine clause combination; a word `and` inside a noun phrase does not
create clause conjunction. Negated event existence remains under NOT. Candidate
variables are bound where their uses meet, with local witnesses in OR branches.

Source complements are preserved as propositions with a route (depiction, speech
or OCR), an assertion/question/depiction distinction and exact content. Their
internal predicates are not asserted as world facts. Written content in read-01's
ARG3 is handled separately from the written source in ARG1.

Tense/aspect are added from the source dependency analysis because standard AMR
usually omits them. `E1` denotes an event candidate; `X1` denotes an entity candidate;
`T0` denotes the discourse reference context supplied by the caller. The new
four-argument `temporal` atoms are **compilation outputs only**: they have not been
connected to the older five-argument interval-checking interface. This experiment
makes no temporal-media inference claim.

## Limits that must remain visible

The compiler covers a restricted existential, conjunction/disjunction and local
negation fragment. It is not a general AMR-to-first-order-logic implementation.
Unresolved modality and some event-valued complements are refused. In particular,
asking for aid must not assert that aid occurred. The currently admitted event-valued
`cause` and `devastate` frames are provisional lexical rules, not a complete lexical
semantics. Word senses are retained in input graphs but currently merged in the
executable predicate name; this must be settled before a final representation.

SRL preserves complete argument phrases but does not separately expose their
internal attributes, genitives or quantity relationships. Source contents are
also preserved without recursive compilation. AMR can misclassify an entity,
miss temporal information or omit surface details. Some entity-graph edges remain
untranslated and are explicitly listed in metadata. A pronoun still needs discourse
context. The neural graph generator can choose incorrect roles or invent polarity.
Those are semantic errors even when a program is syntactically valid.

Do not interpret higher coverage as a measured improvement in semantic accuracy.
Do not treat an all-unknown placeholder execution as a media verdict.

## Reproduce without GPU inference

Use the project Python environment with `requirements-compilation.txt`.

```bash
PYTHONPATH=scripts python scripts/analyze_compilation_methods.py
PYTHONPATH=scripts python -m pytest tests/test_probabilistic_verification.py tests/test_multimodal_verification.py tests/test_semantic_compiler.py tests/test_predicate_compilation.py
```

The analyzer reuses saved graphs and SRL outputs; all compiled programs are parsed
with ProbLog. Five selected cases per method are submitted to actual DeepProbLog
in isolated subprocesses with 10-second limits, using one placeholder per variable
and unknown observations. This is an execution diagnostic, not a throughput study.
The initial unrestricted backend sweep was interrupted after a slow case; no
complete backend-coverage result is claimed from that sweep.

GPU regeneration additionally needs the local model paths in
`run_compilation_models.py`. The public source archive excludes model weights and
media. `models/download.json` records the official AMR checkpoint URL and hash.
The public report includes exact model requests/responses and source code.

## Proposed next steps

1. Write a small reference set of expected roles, modifiers, identity, scope and
   time. Complete review of the selected 25 real diagnostic claims and 21 controls.
   Define which cases require finer decomposition rather than accepting opaque
   phrases as completed binding analysis.
2. Freeze one common logical-form schema and predicate signatures. Preserve sense
   and argument semantics, represent source content recursively, connect temporal
   signatures consistently, and refuse unsupported scope explicitly.
3. Keep trained SRL as the inexpensive span/role baseline and pretrained AMR as the
   main structured alternative. Fix shared deterministic translation defects before
   judging either front end. Syntax remains useful for alignment and tense.
4. Run one bounded neural alternative: clause-level generation into a small logical
   abstract syntax tree (a structured representation of operators and predicates),
   with deterministic serialization. Compare text-only and SRL-assisted versions.
   If grammar-constrained generation is available, use it for format validity;
   assess meaning separately. This is planned, not implemented in the current run.
5. Freeze the selected parser/compiler, then evaluate compilation and meaning on
   unseen source videos. Report valid output, executable output, faithful output
   and explicit refusals separately. Review incorrect accepted outputs as carefully
   as refusals. Do not select a method by compilation count alone.

Proposed time limit: spend one or two focused working days on these compilation
choices, then choose the simplest adequate route and document the supported
fragment. This is a planning limit, not a measured completion estimate. Avoid a
new general-purpose semantic-parser training project. A larger model, Boxer/DRS
or a specialized NL-to-FOL checkpoint should be a bounded fallback transfer test,
not three open-ended implementation branches.

Research: `research/2026-10-28-compilation/LITERATURE.md` and `literature.json`.
Recent CLOVER, Code4Logic and NL2LOGIC are close precedents for structured
translation; parser/compiler separation alone is not the paper's novelty.
