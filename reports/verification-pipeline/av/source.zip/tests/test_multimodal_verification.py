"""Source separation, complementary evidence, conflicts, and candidate alignment."""
import pytest

from probabilistic_verification import ClaimCompiler, CompilationError
from probabilistic_verification.backend import DeepProbLogVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, combine_states, enumerate_probability
from probabilistic_verification.multimodal import ground_two_sources
from test_probabilistic_verification import ud


def claim():
    rows = ud([("Aircraft", "aircraft", "NOUN", 3, "nsubj"), ("is", "be", "AUX", 3, "cop"),
               ("gray", "gray", "ADJ", 0, "root"), ("and", "and", "CCONJ", 7, "cc"),
               ("music", "music", "NOUN", 7, "nsubj"), ("is", "be", "AUX", 7, "cop"),
               ("instrumental", "instrumental", "ADJ", 3, "conj")])
    return ClaimCompiler().compile("two", "Aircraft is gray and music is instrumental.", rows)


def evidence(c, route, values):
    assignment = {v.name: v.description.lower() for v in c.variables}
    obs = {}
    for atom in c.atoms:
        key = canonical_key("clip", atom, assignment, route)
        obs[key] = Observation(key, values[atom.id], False, atom.text)
    return Evidence("clip", {k:[v] for k,v in assignment.items()}, dict.fromkeys(assignment,True), obs, route)


def test_complementary_predicates_combine_before_claim_logic():
    c = claim()
    visual = {a.id: (1.,0.,0.) if a.arguments[0] == "X1" else (0.,0.,1.) for a in c.atoms}
    audio = {a.id: (0.,0.,1.) if a.arguments[0] == "X1" else (1.,0.,0.) for a in c.atoms}
    programs = ground_two_sources(c,evidence(c,"visual",visual),evidence(c,"audio",audio))[:3]
    distributions = [x["distribution"] for x in DeepProbLogVerifier(list(programs),learned=False).predict()]
    assert [d["unknown"] for d in distributions[:2]] == [1.,1.]
    assert distributions[2]["supported"] == 1.


def test_conflicts_are_unknown_and_diagnostic_matches_enumeration():
    c = claim()
    first = {a.id:(.8,.1,.1) for a in c.atoms}
    second = {a.id:(.2,.7,.1) for a in c.atoms}
    a,b,p,conflicts = ground_two_sources(c,evidence(c,"visual",first),evidence(c,"audio",second))
    assert all(x["probability"] == pytest.approx(.58) for x in conflicts)
    actual = DeepProbLogVerifier([p],learned=False).predict()[0]["distribution"]
    assert actual == pytest.approx(enumerate_probability(p),abs=1e-12)
    assert combine_states("evidence",["supported","refuted"]) == "unknown"
    assert combine_states("evidence",["unknown","refuted"]) == "refuted"


def test_ineligible_scores_cannot_supply_evidence():
    c = claim()
    all_support = {a.id:(1.,0.,0.) for a in c.atoms}
    allowed = {a.id:{"audio"} for a in c.atoms}
    v,a,p,conflicts = ground_two_sources(c,evidence(c,"visual",all_support),evidence(c,"audio",all_support),allowed=allowed)
    assert all(not o.available for o in v.observations.values())
    assert all(o.provenance["raw_distribution"] == [1.,0.,0.] for o in v.observations.values())
    predictions = DeepProbLogVerifier([v,a,p],learned=False).predict()
    assert [r["prediction"] for r in predictions] == ["unknown","supported","supported"]


def test_candidates_must_align_and_sources_must_differ():
    c = claim()
    values = {a.id:(0.,0.,1.) for a in c.atoms}
    a,b = evidence(c,"visual",values),evidence(c,"audio",values)
    b.domains["X1"] = ["another_aircraft"]
    with pytest.raises(ValueError,match="inventories"):
        ground_two_sources(c,a,b)
    with pytest.raises(ValueError,match="distinct"):
        ground_two_sources(c,a,a)


def test_mentioned_places_are_not_compiled_as_physically_present_objects():
    rows = ud([("Narrator", "narrator", "NOUN", 2, "nsubj"),
               ("mentions", "mention", "VERB", 0, "root"), ("Alaska", "Alaska", "PROPN", 2, "obj")])
    with pytest.raises(CompilationError,match="scope"):
        ClaimCompiler().compile("speech", "Narrator mentions Alaska.", rows)
