#!/usr/bin/env python3
"""Cache frozen, proposition-conditioned media representations and control scores.

This is a feature audit, not classifier training. Gold labels are never loaded.
The same prompt is used for matched, mismatched and blank media.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import time

import numpy as np
from PIL import Image
import soundfile as sf
import torch

from prompts_phase2 import (VERIFICATION_FEATURE_PROMPT_VERSION,
    VERIFICATION_FEATURE_SYSTEM, VERIFICATION_AUDIO_INSPECTION, verification_feature_user)

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "exp/probabilistic_verification/av_features_20261022"
MODELS = {
    "visual": "/exp/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct",
    "audio": "/exp/cxiao/calm/downloads/models/qwen3-omni/30B-A3B-Instruct",
}
MEDIA = {"vehicles": "zlD_zgNiYJkRV1PS_0000", "clothing": "eHObCbLbueu90y1g_0000"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("modality", choices=MODELS)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--devices", type=int, default=1)
    ap.add_argument("--chat-template", choices=("official","empty_thinking"), default="official")
    args = ap.parse_args()
    from transformers import AutoConfig, AutoProcessor, Qwen3VLForConditionalGeneration, Qwen3OmniMoeThinkerForConditionalGeneration
    started = time.perf_counter()
    torch.set_num_threads(4)
    processor = AutoProcessor.from_pretrained(MODELS[args.modality], local_files_only=True)
    cls = Qwen3VLForConditionalGeneration if args.modality == "visual" else Qwen3OmniMoeThinkerForConditionalGeneration
    config = AutoConfig.from_pretrained(MODELS[args.modality], local_files_only=True)
    if args.modality == "audio":
        config = config.thinker_config
    model = cls.from_pretrained(MODELS[args.modality], dtype=torch.bfloat16,
        config=config, device_map="auto" if args.devices > 1 else "cuda:0",
        max_memory={i: "36GiB" for i in range(args.devices)} if args.devices > 1 else None,
        attn_implementation="sdpa", local_files_only=True)
    model.eval().requires_grad_(False)
    template_options = {"enable_thinking": False} if args.chat_template == "empty_thinking" else {}
    if args.modality == "audio":
        inspections = []
        for name in MEDIA:
            wave, rate = sf.read(RUN / (name + ".wav"), dtype="float32")
            messages = [{"role": "user", "content": [{"type": "audio", "audio": "attached"},
                {"type": "text", "text": VERIFICATION_AUDIO_INSPECTION}]}]
            prompt = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, **template_options)
            inputs = processor(text=[prompt], audio=[wave], sampling_rate=rate, return_tensors="pt", padding=True).to(device="cuda:0", dtype=torch.bfloat16)
            with torch.inference_mode():
                ids = model.generate(**inputs, max_new_tokens=96, do_sample=False, repetition_penalty=1.05,
                    eos_token_id=processor.tokenizer.eos_token_id, pad_token_id=processor.tokenizer.pad_token_id)
            inspections.append(dict(media=name, prompt=prompt, audio_sha256=sha(RUN/(name+".wav")),
                response=processor.batch_decode(ids[:,inputs.input_ids.shape[1]:], skip_special_tokens=True)[0],
                source="frozen Qwen3-Omni audio-only inspection; not human gold", chat_template=args.chat_template,
                generation=dict(max_new_tokens=96,do_sample=False,repetition_penalty=1.05,eos_token_id=processor.tokenizer.eos_token_id)))
            (RUN / "audio_inspection.json").write_text(json.dumps(inspections, indent=2))
            print(json.dumps(inspections[-1]), flush=True)
    capture = {}
    if args.modality == "audio":
        # Keep the actual final decoder state; avoid allocating all-token logits.
        def capture_decoder(module, inputs, outputs):
            capture["joint"] = outputs.last_hidden_state[:, -1].detach().float().cpu()
        model.model.register_forward_hook(capture_decoder)
        model.lm_head.register_forward_pre_hook(lambda module, inputs: (inputs[0][:, -1:, :],))
        def capture_audio(module, inputs, outputs):
            capture["media"] = outputs.last_hidden_state.detach().float().cpu()
        model.audio_tower.register_forward_hook(capture_audio)

    propositions = json.loads((RUN / "propositions.json").read_text())
    if args.limit:
        propositions = propositions[:args.limit]
    rows, tensors = [], {}
    token_ids = [processor.tokenizer.encode(x, add_special_tokens=False) for x in "ABC"]
    if any(len(t) != 1 for t in token_ids):
        raise ValueError(f"Answer choices must be single tokens: {token_ids}")
    choice_ids = torch.tensor([t[0] for t in token_ids], device="cuda:0")
    for proposition in propositions:
        for mode in ("matched", "mismatched", "blank", "text_only"):
            rid = f'{args.modality}__{proposition["id"]}__{mode}'
            other = "clothing" if proposition["media"] == "vehicles" else "vehicles"
            media_name = other if mode == "mismatched" else proposition["media"]
            content, payload, sources = [], {}, []
            if mode != "text_only" and args.modality == "visual":
                paths = [ROOT / "exp/phase2/media_cache_1fps/frames" / MEDIA[media_name] / f"frame_{i:03d}.jpg" for i in (0, 5, 10)]
                images = [Image.open(p).convert("RGB") for p in paths]
                # Fix dimensions in all three media conditions.
                images = [im.resize((252, 448)) for im in images]
                if mode == "blank":
                    images = [Image.new("RGB", im.size, (0, 0, 0)) for im in images]
                content = [{"type": "image", "image": "attached"} for _ in images]
                payload = {"images": images}
                sources = [{"path": str(p.relative_to(ROOT)), "sha256": sha(p), "cache_second": i}
                           for p, i in zip(paths, (0, 5, 10))]
            elif mode != "text_only":
                path = RUN / (media_name + ".wav")
                wave, rate = sf.read(path, dtype="float32")
                if rate != 16000 or wave.ndim != 1:
                    raise ValueError("Expected mono 16 kHz audio.")
                if mode == "blank":
                    wave = np.zeros_like(wave)
                content = [{"type": "audio", "audio": "attached"}]
                payload = {"audio": [wave], "sampling_rate": rate}
                sources = [{"path": str(path.relative_to(ROOT)), "sha256": sha(path), "seconds": len(wave)/rate}]
            content.append({"type": "text", "text": verification_feature_user(proposition["text"], args.modality)})
            messages = [{"role": "system", "content": VERIFICATION_FEATURE_SYSTEM}, {"role": "user", "content": content}]
            prompt = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, **template_options)
            inputs = processor(text=[prompt], return_tensors="pt", padding=True, **payload).to(device="cuda:0", dtype=torch.bfloat16)
            tick = time.perf_counter()
            capture.clear()
            with torch.inference_mode():
                if args.modality == "visual":
                    output = model.model(**inputs, use_cache=False)
                    joint = output.last_hidden_state[:, -1].detach().float().cpu()
                    logits = model.lm_head(output.last_hidden_state[:, -1:, :])[0, -1].float()
                else:
                    output = model(**inputs, use_cache=False, output_router_logits=False)
                    logits, joint = output.logits[0, -1].float(), capture["joint"]
                choices = choice_ids.to(logits.device)
                values = logits.index_select(0, choices).double().softmax(-1).cpu().tolist()
                choice_mass = logits.softmax(-1).index_select(0, choices).sum().item()
            tensors[rid + "__joint"] = joint.squeeze(0).clone()
            if "media" in capture:
                tensors[rid + "__media_tokens"] = capture["media"].clone()
            rows.append(dict(id=rid, proposition_id=proposition["id"], proposition=proposition["text"],
                requested_media=proposition["media"], actual_media=media_name if mode != "text_only" else None,
                modality=args.modality, mode=mode, sources=sources, blanked=mode == "blank",
                prompt=prompt, prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                input_tokens=inputs.input_ids.shape[1], input_ids_sha256=hashlib.sha256(inputs.input_ids.cpu().numpy().tobytes()).hexdigest(),
                input_shapes={k: list(v.shape) for k,v in inputs.items() if isinstance(v,torch.Tensor)},
                visual_resize=[252,448] if args.modality=="visual" and mode!="text_only" else None,
                distribution=dict(zip(("supported", "refuted", "unknown"), values)), choice_probability_mass=choice_mass,
                feature_key=rid + "__joint", feature_dimension=joint.shape[-1], feature_norm=joint.norm().item(),
                seconds=time.perf_counter()-tick))
            print(json.dumps({k: rows[-1][k] for k in ("id", "distribution", "feature_dimension", "seconds")}), flush=True)
            # Save progress atomically after each condition, retaining CPU tensors.
            metadata = dict(model=MODELS[args.modality], modality=args.modality,
                prompt_version=VERIFICATION_FEATURE_PROMPT_VERSION, answer_token_ids=token_ids,
                chat_template=args.chat_template,
                feature="last prompt-token decoder state before answer generation; conditioned on proposition and supplied media",
                weights_frozen=all(not p.requires_grad for p in model.parameters()),
                versions={k: importlib.metadata.version(k) for k in ("torch", "transformers")},
                model_config_sha256=sha(Path(MODELS[args.modality])/"config.json"),
                elapsed_seconds=time.perf_counter()-started, cuda_peak_bytes=torch.cuda.max_memory_allocated(), records=rows)
            out = RUN / (args.modality + "_features.json")
            out.with_suffix(".tmp").write_text(json.dumps(metadata, indent=2))
            out.with_suffix(".tmp").replace(out)
            torch.save(tensors, RUN / (args.modality + "_features.pt"))


if __name__ == "__main__":
    main()
