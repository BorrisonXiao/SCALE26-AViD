#!/usr/bin/env python3
"""Independent ASR on the exact audio excerpts selected for feature inspection."""
import importlib.metadata
import json
from pathlib import Path
import time

import torch
from qwen_asr import Qwen3ASRModel

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/av_features_20261022'


def main():
    started = time.perf_counter()
    model = Qwen3ASRModel.from_pretrained('/exp/cxiao/calm/downloads/models/qwen3-asr/1.7B',
        dtype=torch.bfloat16, device_map='cuda:0', max_inference_batch_size=2, max_new_tokens=256)
    records = []
    for name in ('vehicles', 'clothing'):
        result = model.transcribe(audio=str(RUN / (name + '.wav')), language=None)[0]
        record = dict(media=name, language=result.language, text=result.text,
                      source='independent frozen Qwen3-ASR-1.7B; requires inspection, not human gold')
        print(json.dumps(record, ensure_ascii=False), flush=True)
        records.append(record)
    (RUN / 'asr.json').write_text(json.dumps(dict(records=records,
        version=importlib.metadata.version('qwen-asr'), elapsed_seconds=time.perf_counter()-started), indent=2))


if __name__ == '__main__':
    main()
