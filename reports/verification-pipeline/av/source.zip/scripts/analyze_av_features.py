#!/usr/bin/env python3
"""Produce auditable feature controls and actual dual-source logic traces."""
from __future__ import annotations

from dataclasses import asdict
import hashlib
import json
from pathlib import Path

import torch
import torch.nn.functional as F

from probabilistic_verification import ClaimCompiler
from probabilistic_verification.backend import DeepProbLogVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, enumerate_probability
from probabilistic_verification.multimodal import ground_two_sources
from probabilistic_verification.parsing import DependencyParser
from probabilistic_verification.representation import STATES

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "exp/probabilistic_verification/av_features_20261022"


def load(name):
    return json.loads((RUN/name).read_text())


def main():
    caches = {m:load(m+"_features.json") for m in ("visual","audio")}
    if any(len(c["records"]) != 48 for c in caches.values()):
        raise ValueError("Wait for all 12 propositions × 4 conditions in both modalities.")
    tensors = {m:torch.load(RUN/(m+"_features.pt"),map_location="cpu",weights_only=True) for m in caches}
    records = {m:{r["id"]:r for r in d["records"]} for m,d in caches.items()}
    diagnostics = []
    for modality, cache in caches.items():
        for prop in load("propositions.json"):
            base = records[modality][f'{modality}__{prop["id"]}__matched']
            feature = tensors[modality][base["feature_key"]]
            if feature.ndim != 1 or not torch.isfinite(feature).all() or feature.norm() == 0:
                raise ValueError("Cached features must be finite, nonzero vectors.")
            for mode in ("mismatched","blank","text_only"):
                row = records[modality][f'{modality}__{prop["id"]}__{mode}']
                other = tensors[modality][row["feature_key"]]
                if other.shape != feature.shape or not torch.isfinite(other).all():
                    raise ValueError("Control features must be finite vectors of the same size.")
                diagnostics.append(dict(modality=modality,proposition_id=prop["id"],condition=mode,
                    cosine=float(F.cosine_similarity(feature,other,dim=0)), l2=float((feature-other).norm()),
                    same_prompt=base["prompt_sha256"] == row["prompt_sha256"],
                    same_input_ids=base["input_ids_sha256"] == row["input_ids_sha256"],
                    same_input_shapes=base["input_shapes"] == row["input_shapes"]))
    relation_changes = []
    for modality in caches:
        for first,second in (("aircraft_gray","aircraft_yellow"),("bus_yellow","bus_gray"),("music_instrumental","music_vocal")):
            a,b=[records[modality][f'{modality}__{p}__matched'] for p in (first,second)]
            x,y=[tensors[modality][r["feature_key"]] for r in (a,b)]
            relation_changes.append(dict(modality=modality,first=first,second=second,
                cosine=float(F.cosine_similarity(x,y,dim=0)),l2=float((x-y).norm())))

    manifest = load("reviewed_claims.json")
    parse_file=RUN/"av_parses.json"
    parses=json.loads(parse_file.read_text()) if parse_file.exists() else {}
    parser=None
    traces,programs=[],[]
    for case in manifest["claims"]:
        if case["id"] not in parses:
            if parser is None:
                parser=DependencyParser()
                (RUN/"av_parser_provenance.json").write_text(json.dumps(parser.provenance,indent=2))
            parses[case["id"]]=parser.parse(case["text"])
            parse_file.write_text(json.dumps(parses,indent=2))
        c=ClaimCompiler().compile(case["id"],case["text"],parses[case["id"]])
        assignment={v.name: "selected_"+v.description.lower().replace(" ","_") for v in c.variables}
        var_names={v.name:v.description.lower() for v in c.variables}
        evidence=[]
        allowed={}
        atom_rows=[]
        media_id="vehicles_0_12__missing" if case.get("no_media") else "vehicles_0_12"
        for m in ("visual","audio"):
            route="visual_depiction" if m=="visual" else "non_speech_sound"
            observations={}
            for atom in c.atoms:
                subject=var_names[atom.arguments[0]]
                intended="non_speech_sound" if subject=="music" else "visual_depiction"
                allowed[atom.id]={intended}
                # Probe includes the complete property holder, not a detached color.
                pid=("bus" if subject=="school buses" else subject)+"_"+("entity" if atom.kind=="entity" else atom.arguments[1])
                record=records[m][f'{m}__{pid}__matched']
                values=[record["distribution"][s] for s in STATES]
                # Older first visual batch used float32 softmax. Normalize the
                # input categorical probabilities explicitly, never backend roots.
                total=sum(values)
                values=tuple(x/total for x in values)
                key=canonical_key(media_id,atom,assignment,route)
                observations[key]=Observation(key,values,False,record["proposition"],dict(
                    source="frozen native model",record_id=record["id"],feature_key=record["feature_key"],
                    eligible_route=intended,raw_probability_sum=total))
                atom_rows.append(dict(atom_id=atom.id,modality=m,record_id=record["id"],eligible=route==intended,
                    distribution=dict(zip(STATES,values)),feature_key=record["feature_key"]))
            evidence.append(Evidence(media_id,{k:[v] for k,v in assignment.items()},
                dict.fromkeys(assignment,True),observations,route,
                {v:var_names[k]+"; manually selected referent in this excerpt" for k,v in assignment.items()}))
        first,second,combined,conflicts=ground_two_sources(c,*evidence,allowed=allowed)
        if case.get("no_media"):
            # Missing evidence is a declared input condition, not a perception output.
            for e in evidence:
                e.observations={}
            first,second,combined,conflicts=ground_two_sources(c,*evidence,allowed=allowed)
            atom_rows=[]
        programs += [first,second,combined]
        traces.append(dict(case=case,compilation=c.to_dict(),assignment=assignment,allowed={k:sorted(v) for k,v in allowed.items()},
            raw_observations=atom_rows,branches=[dict(claim_id=p.claim_id,expression=asdict(p.expression),
                observations={k:o.to_dict() for k,o in p.observations.items()},occurrences=p.occurrences) for p in (first,second,combined)],
            local_conflicts=conflicts))
    verifier=DeepProbLogVerifier(programs,learned=False)
    predictions={r["claim_id"]:r for r in verifier.predict()}
    (RUN/"av_program.pl").write_text(verifier.program)
    for t in traces:
        t["predictions"]={r["claim_id"]:predictions[r["claim_id"]] for r in t["branches"]}
        for p in programs:
            if p.claim_id in t["predictions"]:
                oracle=enumerate_probability(p)
                actual=predictions[p.claim_id]["distribution"]
                if max(abs(oracle[s]-actual[s]) for s in STATES)>1e-10:
                    raise AssertionError("DeepProbLog disagrees with independent enumeration.")
    summary=dict(date="2026-10-22",scope="one development clip plus one mismatched-media control; no classifier training or held-out evaluation",
        requests={m:len(c["records"]) for m,c in caches.items()},models={m:dict(model=c["model"],feature=c["feature"],
            dimension=c["records"][0]["feature_dimension"],elapsed_seconds=c["elapsed_seconds"],cuda_peak_bytes=c["cuda_peak_bytes"],versions=c["versions"],
            weights_frozen=c["weights_frozen"]) for m,c in caches.items()},
        diagnostics=diagnostics,relation_feature_changes=relation_changes,
        all_backend_roots_normalized=all(abs(sum(r["distribution"].values())-1)<1e-9 for r in predictions.values()),
        all_backend_roots_match_enumeration=True,feature_heads_trained=0,claims=len(traces),branch_verdicts=len(predictions),
        all_features_finite=True,
        feature_sha256={m:hashlib.sha256(b"".join(k.encode()+v.numpy().tobytes() for k,v in sorted(t.items()) if k.endswith("__joint"))).hexdigest() for m,t in tensors.items()},
        feature_hash_definition="SHA-256 of sorted joint-feature keys and their float32 bytes; excludes unused media-token sequences")
    earlier=RUN/"initial_audio_template/audio_features.json"
    if earlier.exists():
        previous={r["id"]:r for r in json.loads(earlier.read_text())["records"]}
        summary["audio_template_check"]=[dict(proposition=p,condition=mode,
            initial_empty_thinking=previous[f"audio__{p}__{mode}"]["distribution"],
            official_default=records["audio"][f"audio__{p}__{mode}"]["distribution"])
            for p in ("music_entity","music_instrumental","music_vocal") for mode in ("matched","blank","text_only")]
    (RUN/"av_traces.json").write_text(json.dumps(traces,indent=2))
    (RUN/"feature_summary.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ("diagnostics","relation_feature_changes")},indent=2))


if __name__=="__main__":
    main()
