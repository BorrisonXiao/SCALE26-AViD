#!/usr/bin/env python3
"""Compile one claim to a source-linked logical form or an explicit diagnostic."""
import argparse
import json
from pathlib import Path

from probabilistic_verification import ClaimCompiler, CompilationError
from probabilistic_verification.parsing import DependencyParser


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--text', required=True)
    parser.add_argument('--claim-id', default='input')
    parser.add_argument('--ud-json', type=Path, help='Optional JSON list of Stanza-style UD word records; skips parser loading.')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    tokens = json.loads(args.ud_json.read_text()) if args.ud_json else DependencyParser().parse(args.text)
    try:
        result = ClaimCompiler().compile(args.claim_id, args.text, tokens).to_dict()
    except CompilationError as error:
        result = dict(error.to_dict(), claim_id=args.claim_id, text=args.text, tokens=tokens)
    content = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content)
    else:
        print(content, end='')
    return 0 if result['status'] == 'compiled' else 2


if __name__ == '__main__':
    raise SystemExit(main())
