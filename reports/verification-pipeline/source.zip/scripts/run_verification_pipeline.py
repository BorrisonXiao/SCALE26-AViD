#!/usr/bin/env python3
"""Run the restricted compiler, actual DeepProbLog inference, and sample training.

Uses saved frozen-model observations, not new GPU inference. The two real-media
training examples illustrate gradient flow only; no held-out accuracy is claimed.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import time
from pathlib import Path

from probabilistic_verification import ClaimCompiler, CompilationError
from probabilistic_verification.backend import DeepProbLogVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.parsing import DependencyParser
from probabilistic_verification.representation import STATES

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "exp/probabilistic_verification/compiler_20261022"
PILOT = ROOT / "exp/probabilistic_verification/pilot_20261015/guided_checked/v3"

REAL_CASES = [
    ("real_supported", "The aircraft is gray and the school buses are yellow.", "supported"),
    ("real_swapped", "The aircraft is yellow and the school buses are gray.", "refuted"),
    ("real_unknown", "The aircraft is gray and the school buses are yellow.", "unknown"),
]
CONTROL_CASES = [
    ("control_matching", "Alice hugs Bob.", "supported"),
    ("control_cross_event", "Alice hugs Dave.", "refuted"),
    ("control_reversed", "Bob hugs Alice.", "refuted"),
]
REGRESSION_CASES = [
    ("active", "Alice hugs Bob.", "compiled"),
    ("passive", "Bob is hugged by Alice.", "compiled"),
    ("shared_subject", "Alice hugs Bob and waves.", "compiled"),
    ("shared_name", "Alice hugs Bob and Alice waves.", "compiled"),
    ("negation", "Alice does not hug Bob.", "compiled"),
    ("property_negation", "The aircraft is not yellow.", "compiled"),
    ("two_clauses", "The aircraft is gray and the school buses are yellow.", "compiled"),
    ("verb_attributes", "The woman wears a white shirt and the man wears a red shirt.", "compiled"),
    ("disjunction", "Alice hugs Bob or Carol waves.", "compiled"),
    ("possessive", "The woman's shirt is white.", "compiled"),
    ("temporal", "Alice waves before Bob runs.", "unsupported"),
    ("quantifier", "Every woman wears a shirt.", "unsupported"),
    ("count", "Two women wear shirts.", "unsupported"),
    ("pronoun", "She hugs Bob.", "unsupported"),
    ("unhandled_adverb", "Alice quickly hugs Bob.", "unsupported"),
    ("assertion", "Alice says that Bob runs.", "unsupported"),
    ("modal", "Alice might hug Bob.", "unsupported"),
    ("negative_indefinite", "A woman does not wear a shirt.", "unsupported"),
]


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def source_cache(run):
    path = run / "perception_cache.json"
    if path.exists():
        return json.loads(path.read_text())
    raw = {r["request_id"]: r for r in read_jsonl(PILOT / "parts_raw.jsonl")}
    wanted = {"An aircraft is present.", "School buses are present.", "The aircraft is gray.",
              "The aircraft is yellow.", "The school buses are yellow.", "The school buses are gray."}
    selected = {}
    for entry in read_jsonl(PILOT / "part_mapping.jsonl"):
        if entry["text"] not in wanted:
            continue
        row = raw[entry["request_id"]]
        selected[entry["text"]] = dict(question=entry["text"], request_id=row["request_id"],
            request_hash=row["request_hash"], distribution=row["distribution"], raw_text=row["raw_text"],
            source_file=str((PILOT / "parts_raw.jsonl").relative_to(ROOT)),
            model_config=row["request"]["config"], frame_hashes=row["request"]["frame_hashes"],
            system_prompt=row["request"]["task"]["system"], user_prompt=row["request"]["task"]["user"])
    if selected.keys() != wanted:
        raise ValueError("The saved six-observation perception cache is incomplete.")
    cache = dict(media_id="zlD_zgNiYJkRV1PS", records=selected,
                 frame_paths=[r["path"] for r in next(iter(selected.values()))["frame_hashes"]],
                 display_frames=["zlD_zgNiYJkRV1PS_0000/frame_000.jpg", "zlD_zgNiYJkRV1PS_0000/frame_005.jpg"],
                 reference_scope="The depicted aircraft and school-bus group in the reviewed sampled frames.",
                 label_source="assistant inspection of source frames; development labels, not human gold",
                 claim_source="Shorter claims derived from the checked vehicle-color pair; the separate-shot clause is not asserted here.")
    save(path, cache)
    return cache


def parse_cases(run, cases):
    path = run / "parses.json"
    cached = json.loads(path.read_text()) if path.exists() else {"records": {}}
    needed = {text for _, text, _ in cases} - cached["records"].keys()
    if needed:
        parser = DependencyParser()
        cached["provenance"] = parser.provenance
        for text in sorted(needed):
            print("Parse:", text, flush=True)
            started = time.perf_counter()
            cached["records"][text] = dict(tokens=parser.parse(text), elapsed_seconds=time.perf_counter() - started)
        save(path, cached)
    return cached


def real_evidence(claim, cache, *, missing=False):
    media_id = cache["media_id"] + ("_no_media" if missing else "")
    entity_labels = {a.arguments[0]: a.arguments[1] for a in claim.atoms if a.kind == "entity"}
    domains = {v: ["depicted_" + label] for v, label in entity_labels.items()}
    assignment = {v: ids[0] for v, ids in domains.items()}
    descriptions = {ids[0]: label.replace("_", " ") for v, ids in domains.items() for label in [entity_labels[v]]}
    observations = {}
    for atom in claim.atoms:
        kind = entity_labels[atom.arguments[0]]
        if atom.kind == "entity":
            question = {"aircraft": "An aircraft is present.", "school_bus": "School buses are present."}[kind]
        else:
            holder = "aircraft" if kind == "aircraft" else "school buses"
            copula = "is" if kind == "aircraft" else "are"
            question = f"The {holder} {copula} {atom.arguments[1]}."
        source = cache["records"][question]
        probabilities = (0., 0., 1.) if missing else tuple(source["distribution"][s] for s in STATES)
        key = canonical_key(media_id, atom, assignment, "visual_depiction")
        observations[key] = Observation(key, probabilities, atom.trainable and not missing, question,
            dict(source="explicit unavailable-media control" if missing else "saved frozen Qwen3-VL-8B output",
                 request_id=source["request_id"] if not missing else None,
                 request_hash=source["request_hash"] if not missing else None,
                 original_distribution=source["distribution"] if not missing else None,
                 route="visual_depiction", candidate_origin="manually specified depicted referents; no tracker"), not missing)
    # Completeness is conditional on these two specific, reviewed referents. It
    # is not an assertion of complete event or object coverage throughout a video.
    return Evidence(media_id, domains, {v: True for v in domains}, observations,
                    candidate_descriptions=descriptions)


EVENTS = {"event_1": ("alice", "bob"), "event_2": ("carol", "dave")}


def controlled_evidence(claim):
    entity_labels = {a.arguments[0]: a.arguments[1] for a in claim.atoms if a.kind == "entity"}
    domains = {v.name: list(EVENTS) if v.kind == "event" else [entity_labels[v.name]] for v in claim.variables}
    observations = {}
    for values in itertools.product(*(domains[v.name] for v in claim.variables)):
        assignment = dict(zip([v.name for v in claim.variables], values))
        for atom in claim.atoms:
            args = [assignment.get(x, x) for x in atom.arguments]
            key = canonical_key("constructed_hug_scene", atom, assignment, "visual_depiction")
            if atom.kind == "relation":
                correct = tuple(args[1:]) == EVENTS[args[0]]
                probs = (.95, .02, .03) if correct else (.01, .96, .03)
            elif atom.kind == "entity":
                probs = (.99, .005, .005)
            else:
                probs = (1., 0., 0.)
            observations[key] = Observation(key, probs, False, atom.predicate + "(" + ", ".join(args) + ")",
                {"source": "constructed probability table for a logical diagnostic; not a model prediction", "route": "visual_depiction"})
    return Evidence("constructed_hug_scene", domains, {v: True for v in domains}, observations,
                    candidate_descriptions={"event_1": "Alice hugs Bob", "event_2": "Carol hugs Dave"})


def trace(claim, evidence, program):
    return dict(compilation=claim.to_dict(), domains=evidence.domains, complete=evidence.complete,
                candidate_descriptions=evidence.candidate_descriptions,
                observations={oid: o.to_dict() for oid, o in program.observations.items()},
                occurrences=program.occurrences, expansions=program.expansions)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-dir", type=Path, default=DEFAULT)
    ap.add_argument("--epochs", type=int, default=40)
    args = ap.parse_args()
    run = args.run_dir
    run.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    cache = source_cache(run)
    parses = parse_cases(run, REAL_CASES + CONTROL_CASES + REGRESSION_CASES)
    regressions = []
    for name, text, expected in REGRESSION_CASES:
        try:
            result = ClaimCompiler().compile(name, text, parses["records"][text]["tokens"]).to_dict()
        except CompilationError as e:
            result = e.to_dict()
        regressions.append(dict(name=name, text=text, expected=expected, passed=result["status"] == expected, result=result))
    save(run / "compiler_checks.json", regressions)
    unsafe = [r for r in regressions if r["expected"] == "unsupported" and r["result"]["status"] == "compiled"]
    if unsafe:
        raise AssertionError("Unsupported semantics were accepted: " + str([r["name"] for r in unsafe]))
    # Parser errors are measured separately from compiler semantic tests. Keep
    # rejected parses visible; do not repair them by guessing the intended verb.
    for r in regressions:
        if not r["passed"]:
            print("Needs parse review:", r["name"], r["result"], flush=True)
    real_programs, control_programs, traces = [], [], {}
    for cid, text, label in REAL_CASES + CONTROL_CASES:
        claim = ClaimCompiler().compile(cid, text, parses["records"][text]["tokens"])
        evidence = (real_evidence(claim, cache, missing=cid == "real_unknown") if cid.startswith("real_")
                    else controlled_evidence(claim))
        program = ground(claim, evidence)
        (real_programs if cid.startswith("real_") else control_programs).append(program)
        traces[cid] = dict(trace(claim, evidence, program), label=label,
                          label_source="availability control" if cid == "real_unknown" else cache["label_source"] if cid.startswith("real_") else "constructed event inventory")
    fixed = DeepProbLogVerifier(real_programs, learned=False)
    before = fixed.predict()
    learner = DeepProbLogVerifier(real_programs)
    initial = learner.predict()
    labels = {cid: label for cid, _, label in REAL_CASES if cid != "real_unknown"}
    training = learner.fit(labels, epochs=args.epochs)
    after = learner.predict()
    controls = DeepProbLogVerifier(control_programs, learned=False)
    control_predictions = controls.predict()
    for stage, rows in (("fixed", before), ("initialized", initial), ("trained", after), ("controlled", control_predictions)):
        for row in rows:
            traces[row["claim_id"]].setdefault("predictions", {})[stage] = row
    local = learner.local_predictions()
    for cid, entry in traces.items():
        if cid.startswith("real_"):
            entry["local_after_training"] = {oid: local[oid] for oid in entry["observations"]}
    save(run / "traces.json", traces)
    save(run / "training.json", training)
    (run / "fixed_program.pl").write_text(fixed.program)
    (run / "learned_program.pl").write_text(learner.program)
    (run / "controlled_program.pl").write_text(controls.program)
    import torch
    torch.save(learner.classifier.state_dict(), run / "relation_classifier.pt")
    summary = dict(date="2026-10-22", scope="implementation and training demonstration, not held-out evaluation",
        real_claims=len(REAL_CASES), training_claims=len(labels), independent_source_videos=1,
        controlled_claims=len(CONTROL_CASES), compiler_checks=len(regressions),
        compiler_checks_passed=sum(r["passed"] for r in regressions), new_gpu_requests=0,
        backend_versions=learner.versions(), parser_provenance=parses["provenance"],
        training_seconds=training["elapsed_seconds"], total_seconds=time.perf_counter() - started,
        source_sha256={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in (ROOT / "scripts/probabilistic_verification").glob("*.py")},
        caveats=["The real examples use manually specified depicted referents, not detected tracks.",
                 "Six saved perception observations come from the same frozen model and are modeled as independent categorical facts except for exact reuse.",
                 "The learned MLP is a score calibrator; this run does not establish improved perception or generalization.",
                 "Root-label training uses the same two development claims shown in the report.",
                 "Controlled event probabilities are constructed inputs, not real media-model outputs."])
    save(run / "summary.json", summary)
    print(json.dumps({k: v for k, v in summary.items() if k not in {"parser_provenance", "source_sha256"}}, indent=2), flush=True)


if __name__ == "__main__":
    main()
