"""Build a plain-language compiler guide from executable, source-linked examples."""
from __future__ import annotations

import json
from html import escape as esc
from pathlib import Path
from textwrap import dedent

from probabilistic_verification import ClaimCompiler, CompilationError
from probabilistic_verification.logic import (
    Evidence, canonical_key, combine_states, ground, prolog_program,
)
from probabilistic_verification.representation import STATES

ROOT = Path(__file__).resolve().parents[1]


def code(text):
    return '<pre><code>' + esc(dedent(text).strip()) + '</code></pre>'


def excerpt(filename, start, end):
    source = (ROOT / 'scripts/probabilistic_verification' / filename).read_text()
    return code(source[source.index(start):source.index(end, source.index(start))].rstrip())


def build_guide(run, table):
    checks = json.loads((run / 'compiler_checks.json').read_text())
    saved = {r['name']: r for r in checks}
    parses = json.loads((run / 'parses.json').read_text())['records']
    examples = []

    def compile_case(name, note, tokens=None, text=None):
        row = saved.get(name)
        if tokens is None:
            tokens, text = row['result']['tokens'], row['text']
        claim = ClaimCompiler().compile('guide_' + name, text, tokens)
        # Run the current compiler; do not silently render a stale saved logical form.
        if row and row['result'].get('status') == 'compiled':
            assert claim.to_dict()['logical_form'] == row['result']['logical_form']
        examples.append(dict(name=name, note=note, input_origin='saved automatic Stanza parse' if row else 'hand-specified UD example; compiler demonstration only',
                             **claim.to_dict()))
        return claim

    colors = compile_case('two_clauses', 'Each clause has its own entity variable. Both clauses must hold.')
    active = compile_case('active', 'The subject is the agent; the object is the theme (the participant receiving the action).')
    passive = compile_case('passive', 'The passive subject is the theme; the by-phrase supplies the agent. Variable numbers follow noun processing order, so compare roles rather than X1 alone.')
    negation = compile_case('negation', 'NOT surrounds the entire event search. It does not mean that one nonmatching event is enough to support the negative claim.')
    compile_case('property_negation', 'The aircraft must be present; only its yellow attribute is negated.')
    compile_case('possessive', 'Possession is a separate relation between owner and possession. The white attribute belongs to the shirt.')
    # A controlled parse avoids presenting the known waves-as-noun parser errors as successes.
    tokens = [dict(t) for t in saved['active']['result']['tokens'] if t['deprel'] != 'punct']
    tokens += [dict(id=4, text='or', lemma='or', upos='CCONJ', head=6, deprel='cc'),
               dict(id=5, text='Carol', lemma='Carol', upos='PROPN', head=6, deprel='nsubj'),
               dict(id=6, text='runs', lemma='run', upos='VERB', head=2, deprel='conj')]
    either = compile_case('branch_scope', 'Each OR branch binds its own participants. A supported Alice/Bob branch does not require any Carol candidate.', tokens, 'Alice hugs Bob or Carol runs.')
    shared_tokens = [dict(t) for t in tokens]
    shared_tokens[3]['text'] = shared_tokens[3]['lemma'] = 'and'
    shared_tokens[4]['text'] = shared_tokens[4]['lemma'] = 'Alice'
    shared = compile_case('shared_reference', 'Repeated proper name Alice reuses X1 across both clauses; the two actions still have different event variables.', shared_tokens, 'Alice hugs Bob and Alice runs.')
    assert either.expression.op == 'or'
    assert len([v for v in shared.variables if v.kind == 'entity']) == 2
    assert next(a for a in active.atoms if a.predicate == 'hug').roles == ('event', 'agent', 'theme')

    body = '''<section class="panel" role="tabpanel" id="compilation-guide" aria-labelledby="tab-compilation" hidden>
<h2>How a dependency tree becomes a logical program</h2>
<p class="callout"><strong>Beyond AND and OR:</strong> the claim compiler supports <code>NOT</code> and <code>EXISTS</code>. These are logical operations. Predicates describe what to check: <code>entity</code>, <code>attribute</code>, <code>event</code>, <code>possess</code>, and action relations such as <code>hug</code>. The separate visual/audio stage also uses <code>evidence</code> to combine two eligible observations of the same proposition.</p>
<p>Guide added 28 October 2026. The latest saved experiments are from 22 October: a restricted compiler, native DeepProbLog inference and sample score-calibrator training, followed by frozen visual/audio feature extraction and separate evidence trees. Feature-based classifier training, broader candidate discovery, and held-out evaluation remain pending. The examples below run the current compiler on cached or explicitly supplied parses; they add no perception experiment or accuracy claim.</p>
<h3>1. What is fixed, and what is learned?</h3>
<p>A Universal Dependencies (UD) tree records grammatical links between words: for example, which noun is the subject of a verb. The compiler applies fixed Python rules to these links. It creates variables for participants and events, predicates with ordered arguments, and a logical expression. No media score or reference label enters this step. A variable such as <code>X1</code> stands for a participant we will later match to evidence; <code>E1</code> stands for an event.</p>
'''
    body += code('''# Actual API; tokens is a list of Stanza-style UD word records.
from probabilistic_verification import ClaimCompiler
claim = ClaimCompiler().compile("example", text, tokens)
print(claim.to_dict()["logical_form"])
# Later, with a separately prepared evidence inventory:
from probabilistic_verification.logic import ground, prolog_program
program = ground(claim, evidence)
prolog, query_names = prolog_program([program], learned=False)''')
    body += '<p>The saved training demonstration adjusts relation-score probabilities with a small classifier. It does not learn these grammar rules, argument roles, or truth tables. The full code is in the <a href="verification-pipeline/source.zip">source ZIP</a>; the guide’s exact inputs, outputs, and grounding trace are in <a href="verification-pipeline/compilation_guide.json">compilation_guide.json</a>.</p>'
    body += table(['Layer', 'Supported form', 'Meaning'], [
        ['Claim logic', '<code>AND</code>, <code>OR</code>', 'Require all clauses, or at least one clause. OR is inclusive; both may hold.'],
        ['Claim logic', '<code>NOT</code>', 'Swap supported and refuted; preserve unknown. Restricted clause/property negation only.'],
        ['Candidate binding', '<code>EXISTS X1</code>, <code>EXISTS E1</code>', 'Search supplied candidates for a participant or event satisfying the body. No universal quantifier is implemented.'],
        ['Internal representation', '<code>atom</code>, <code>constant</code>', 'A predicate leaf, or an explicit supported/refuted/unknown state. These are internal expression nodes, not extra English constructions.'],
        ['Source combination', '<code>evidence</code>', 'Combine two eligible sources for the same grounded predicate before AND/OR. Added by multimodal.py, not read from a word in the sentence.'],
    ], 'Logical expression operations currently implemented, with candidate binding and source combination distinguished from sentence connectives.')
    body += table(['Predicate family', 'Example', 'How the compiler creates it / scorer flag'], [
        ['Entity presence/type', '<code>entity(X1, alice)</code>', 'A noun phrase creates an entity variable and a fixed-scoring observation. “Fixed” refers to training, not certain truth.'],
        ['Property', '<code>attribute(X1, gray)</code>', 'A copular property (is gray) or adjective modifier (gray aircraft); trainable relation-score interface.'],
        ['Event occurrence/type', '<code>event(E1, hug)</code>', 'An action verb introduces an event variable and fixed-scoring occurrence observation.'],
        ['Complete action relation', '<code>hug(E1, X1, X2)</code>', 'Verb lemma becomes the predicate name; argument roles are event, agent, theme, recipient, omitting absent roles. Trainable score interface.'],
        ['Possession', '<code>possess(X2, X1)</code>', 'A possessive noun modifier introduces owner then possession; trainable score interface.'],
    ], 'Predicate families emitted by compiler.py. A trainable flag enables scoring through a classifier; it does not establish that this relation has training data.')
    body += '<p>Action names are derived from the verb lemma rather than selected from a fixed verb list. That does not imply unrestricted verb understanding: the clause must fit the supported grammar, suitable evidence must be supplied, and assertion/intention verbs such as <code>say</code>, <code>mention</code>, and <code>want</code> are explicitly rejected. There are no dedicated temporal, spatial, equality, implication, XOR, or counting rules in this fragment.</p>'
    body += '<h3>2. Start with attributes and AND</h3><blockquote>' + esc(colors.text) + '</blockquote>'
    body += '<p>For “aircraft is gray,” UD makes <code>gray</code> the head, <code>aircraft</code> its <code>nsubj</code> (subject), and <code>is</code> its <code>cop</code> (copula). The noun becomes <code>entity(X1, aircraft)</code>; the property becomes <code>attribute(X1, gray)</code>. “School buses” becomes one compound noun label, <code>school_bus</code>. The plural does not introduce a count or universal quantification.</p>'
    body += table(['Word', 'Lemma', 'Head word ID', 'UD relation'], [[str(t['id']) + ': ' + esc(t['text']), esc(t.get('lemma','')), t['head'], esc(t['deprel'])] for t in colors.tokens], 'Cached automatic parse for the aircraft/bus example; head 0 marks the sentence root.')
    body += '<p>The compiler recognizes <code>conj</code> plus the explicit <code>cc</code> word “and,” compiles each clause, and combines them. “The,” copulas, and punctuation receive explicit coverage records rather than independent evidence predicates.</p>' + code(colors.to_dict()['logical_form'])
    body += '<p>Actual copular-property rule from <code>compiler.py</code>:</p>' + excerpt('compiler.py', '        if copular and root["upos"]', '        elif root["upos"] == "VERB":')
    body += '<h3>3. Preserve who did what to whom</h3><p>In “Alice hugs Bob,” <code>nsubj</code> maps to agent and <code>obj</code> to theme. A complete tuple checks one event with both participants; separate checks that Alice exists, Bob exists, and hugging occurs cannot establish this relation. In the passive “Bob is hugged by Alice,” <code>nsubj:pass</code> supplies the theme and <code>obl:agent</code> supplies the agent.</p>'
    for claim in (active, passive):
        body += '<h4>' + esc(claim.text) + '</h4>' + code(claim.to_dict()['logical_form'])
    body += '<p>These have equivalent roles even though X1 and X2 are allocated in a different order. The action argument order is determined by this actual loop:</p>' + excerpt('compiler.py', '            for role in ("agent", "theme", "recipient"):', '            if negators:')
    body += '<p><code>iobj</code> adds a recipient when supplied by the parse. This is a limited dependency-to-role mapping, not a general semantic-role labeling model. Ordinary locative and temporal adjuncts are not handled. See the <a href="#controlled">Same-event test</a> for the constructed Alice/Bob versus Alice/Dave candidate example.</p>'
    body += '<h3>4. Negation, possession, OR, and shared names</h3><p>Expand an example to see its exact generated logical form and input UD records. The first three use saved automatic parses. The OR/shared-name examples use hand-specified parses to isolate compiler behavior: the existing automatic parser misreads “waves” in three saved regression cases.</p>'
    for item in examples[3:]:
        body += '<details><summary>' + esc(item['text']) + '</summary><p>' + esc(item['note']) + '</p><p>Input: ' + esc(item['input_origin']) + '.</p>' + code(item['logical_form']) + '<details><summary>Exact input UD records</summary>' + code(json.dumps(item['tokens'], indent=2)) + '</details></details>'
    body += '<p>For event negation, entity-presence checks remain outside NOT, while event occurrence and the complete relation stay inside <code>NOT(EXISTS E1: ...)</code>. For “not yellow,” only the attribute is negated. Negation of an unknown observation remains unknown; missing evidence cannot prove the negative claim. The code rejects negative indefinite arguments such as “A woman does not wear a shirt,” whose quantifier scope needs richer analysis.</p>'
    body += '<p><code>bind_references()</code> puts an entity’s EXISTS where its uses meet. Branch-only participants stay within their OR branch. Repeated proper names share a variable; repeated common nouns are not automatically resolved as the same object. Coordinated noun arguments such as “Alice and Bob hug Carol” are rejected because collective versus separate actions are unresolved.</p>'
    body += '<h3>5. Replace variables with supplied evidence candidates</h3><p>This step is called grounding: substitute concrete candidate IDs for variables. EXISTS is expanded into OR over assignments. Candidates are supplied separately; the prototype does not detect or track them automatically. The following trace uses Alice/Bob and two candidate hugging events, with <strong>no perception observations supplied</strong>.</p>'
    evidence = Evidence('guide_clip', {'X1':['alice_candidate'], 'X2':['bob_candidate'], 'E1':['hug_one','hug_two']}, {'X1':True,'X2':True,'E1':False}, {})
    program = ground(active, evidence)
    rendered, queries = prolog_program([program], learned=False)
    body += code('''evidence = Evidence(
    media_id="guide_clip",
    domains={"X1": ["alice_candidate"], "X2": ["bob_candidate"],
             "E1": ["hug_one", "hug_two"]},
    complete={"X1": True, "X2": True, "E1": False},
    observations={},
)
program = ground(claim, evidence)  # claim is the active Alice/Bob example''')
    body += '<p>For each event, the body checks <code>event(hug_one, hug)</code> and <code>hug(hug_one, alice_candidate, bob_candidate)</code>, then repeats for <code>hug_two</code>. One event variable ties all roles together. An incomplete event inventory adds an unknown alternative: no matching event among the listed candidates is insufficient for refutation. A declared complete inventory permits refutation when every assignment is refuted. Candidate expansion has a default limit of 256; exceeding it raises an error.</p>'
    body += '<p>Actual EXISTS expansion in <code>logic.py</code>:</p>' + excerpt('logic.py', '            domains = [evidence.domains.get(v, [])', '        if expr.op == "atom":')
    body += '<p>An observation’s identity contains media ID, evidence route, predicate name, and all substituted arguments. Exact reuse shares one categorical random variable, including across different proof paths; duplicated evidence does not become an independent second observation.</p>'
    body += code(canonical_key('guide_clip', next(a for a in active.atoms if a.predicate == 'hug'), {'E1':'hug_one','X1':'alice_candidate','X2':'bob_candidate'}, 'visual_depiction'))
    body += '<h3>6. Emit explicit three-state rules for DeepProbLog</h3><p>Each observation has probabilities for supported, refuted, and unknown. The program defines deterministic truth tables for composing those states. These rules run on categorical outcomes; the backend sums probabilities over possible outcomes while preserving shared observations.</p>'
    body += table(['A', 'B', 'AND(A,B)', 'OR(A,B)', 'evidence(A,B)'], [[a,b,combine_states('and',[a,b]),combine_states('or',[a,b]),combine_states('evidence',[a,b])] for a in STATES for b in STATES], 'Complete two-input state rules from combine_states(). Source combination applies only to two eligible observations of the same proposition, after source policy checks.')
    body += '<p>NOT maps supported to refuted, refuted to supported, and unknown to unknown. For source combination, unknown adds no evidence; agreement preserves the informative state, and support/refutation disagreement becomes unknown with a conflict diagnostic. This operation is neither AND nor OR. Speech assertions and depicted events cannot be combined as the same proposition without explicit semantics.</p>'
    body += '<p>The compiler does not emit direct Prolog calls such as <code>hug(E1,X1,X2)</code> for inference. It first grounds them into observation IDs, then emits <code>status</code>, <code>node</code>, and <code>verdict</code> rules. Here is the exact generated fixed-scoring program for the no-observation inventory above; all missing observations are explicitly unknown.</p><details><summary>Executable generated ProbLog program</summary>' + code(rendered) + '</details>'
    body += '<p>When enabled for an available trainable observation, the actual neural declaration is:</p>' + code('nn(relation_net,[tensor(features(O))],Z,[supported,refuted,unknown]) :: learned_status(O,Z).')
    body += '<p>The earlier score classifier uses frozen S/R/U scores and their logarithms. The later cached visual/audio representations are separate inputs for proposed feature classifiers; those classifiers have not been trained. Different model questions are treated as independent unless their canonical identity is identical, so exact inference does not establish calibrated probabilities.</p>'
    body += '<h3>7. Reject content the rules cannot preserve</h3><p>Every input word must be linked to predicates or explicitly accounted for as functional material. Otherwise compilation returns a diagnostic and accepts no partial logical form. Counts/universal quantifiers, unresolved pronouns, modals, temporal/causal/conditional clauses, reporting/intention scope, “never,” and unhandled modifiers remain outside this fragment.</p>'
    rejected = []
    for name in ('temporal','quantifier','count','pronoun','unhandled_adverb','assertion','modal','negative_indefinite'):
        row = saved[name]
        try:
            ClaimCompiler().compile('guide_' + name, row['text'], parses[row['text']]['tokens'])
        except CompilationError as error:
            rejected.append(dict(text=row['text'], tokens=parses[row['text']]['tokens'], **error.to_dict()))
        else:
            raise AssertionError('Expected rejection: ' + name)
    body += table(['Input', 'Diagnostic code', 'Explanation'], [[esc(r['text']), '<code>'+esc(r['code'])+'</code>', esc(r['message'])] for r in rejected], 'Current compiler diagnostics rerun on the saved automatic parses; these are regression examples, not an estimate of general parser coverage.')
    body += '<p>To compile another sentence from the project directory:</p>' + code('''envs/probabilistic-verification/bin/python scripts/compile_verification_claim.py \
    --text "The aircraft is not yellow." --output /tmp/claim.json
# Add --ud-json /path/to/words.json to supply a parse without loading Stanza.
# Exit status 2 and status="unsupported" indicate an out-of-fragment claim.''')
    body += '<p>Implementation map: <code>parsing.py</code> supplies UD records; <code>compiler.py</code> constructs predicates, roles, scope, and coverage; <code>representation.py</code> stores the logical form; <code>logic.py</code> grounds candidates and emits ProbLog; <code>multimodal.py</code> applies source eligibility and combines aligned observations; <code>backend.py</code> performs inference/training.</p></section>'
    artifact = dict(examples=examples, rejected=rejected, grounding=dict(input=dict(media_id=evidence.media_id,domains=evidence.domains,complete=evidence.complete,observations={}), expansions=program.expansions, occurrences=program.occurrences, program=rendered, queries=queries))
    return body, artifact
