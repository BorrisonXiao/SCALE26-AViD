#!/usr/bin/env python3
"""Build an inspectable report from saved compiler/inference/training artifacts."""
from __future__ import annotations

import argparse
import base64
import hashlib
from html import escape as esc
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "exp/probabilistic_verification/compiler_20261022"
FIGURES = TABLES = 0


def load(path):
    return json.loads(Path(path).read_text())


def figure(content, caption):
    global FIGURES
    FIGURES += 1
    return f'<figure><div class="figure-content">{content}</div><figcaption>Figure {FIGURES}. {caption}</figcaption></figure>'


def table(headers, rows, caption):
    global TABLES
    TABLES += 1
    return '<div class="table-wrap"><table><caption>Table ' + str(TABLES) + '. ' + caption + '</caption><thead><tr>' + ''.join('<th scope="col">' + x + '</th>' for x in headers) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join('<td>' + str(x) + '</td>' for x in row) + '</tr>' for row in rows) + '</tbody></table></div>'


def distribution(values):
    if isinstance(values, dict):
        values = [values[s] for s in ("supported", "refuted", "unknown")]
    return '<span class="scores">' + ' · '.join('<span class="' + state + '">' + initial + ' ' + f'{value:.9g}' + '</span>' for initial, state, value in zip('SRU', ("supported", "refuted", "unknown"), values)) + '</span>'


def svg_dot(lines, label):
    dot = 'digraph G { graph [rankdir=TB,bgcolor="transparent",pad="0.25",nodesep="0.25",ranksep="0.5"]; node [shape=box,style="rounded,filled",fillcolor="#fffefa",fontcolor="#1c211d",color="#5d665f",fontname="Arial",fontsize=13,margin="0.16,0.1"]; edge [color="#5d665f",fontcolor="#5d665f",fontname="Arial",fontsize=11];\n' + '\n'.join(lines) + '\n}'
    result = subprocess.run(["dot", "-Tsvg"], input=dot, text=True, capture_output=True, check=True).stdout
    result = result[result.index('<svg'):]
    prefix = 'figure' + str(FIGURES + 1) + '_'
    result = re.sub(r'id="([^"]+)"', lambda m: 'id="' + prefix + m.group(1) + '"', result)
    result = result.replace('<svg ', '<svg role="img" aria-label="' + esc(label, quote=True) + '" ')
    for original, replacement in {'#fffefa': 'var(--surface)', '#1c211d': 'var(--text)', '#5d665f': 'var(--muted)', '#dcece4': 'var(--accent-soft)', '#f4e9cc': 'var(--amber-soft)', '#176b4d': 'var(--accent)', '#8a5a00': 'var(--amber)'}.items():
        result = result.replace(original, replacement)
    return '<div class="diagram-scroll">' + result + '</div>'


def q(text):
    return json.dumps(text, ensure_ascii=False)


def dependency_diagram(compilation):
    lines = []
    for t in compilation['tokens']:
        lines.append(f't{t["id"]} [label={q(str(t["id"]) + ": " + t["text"] + chr(10) + t["upos"])}];')
        if t['head']:
            lines.append(f't{t["head"]} -> t{t["id"]} [label={q(t["deprel"])}];')
    return figure(svg_dot(lines, 'Automatic dependency parse'), 'Automatic dependency parse from the cached English Stanza model. Each edge is a grammatical relation; the compiler maps these to semantic roles.')


def factor_diagram(trace):
    compilation = trace['compilation']
    atoms = {a['id']: a for a in compilation['atoms']}
    lines, index = [], 0
    controlled = compilation['claim_id'].startswith('control_')
    def visit(expr):
        nonlocal index
        name = 'f' + str(index)
        index += 1
        op = expr['op']
        if op == 'atom':
            atom = atoms[expr['atom_id']]
            label = atom['predicate'] + '(' + ', '.join(atom['arguments']) + ')'
            role = 'constructed relation score' if controlled and atom['trainable'] else 'small learned classifier' if atom['trainable'] else 'fixed perception score' if not controlled else 'constructed fixed score'
            color = '#f4e9cc' if atom['trainable'] else '#fffefa'
            label += '\n' + role
            if atom['kind'] == 'relation':
                label += '\n' + ', '.join(r + '=' + a for r, a in zip(atom['roles'], atom['arguments']))
            lines.append(f'{name} [label={q(label)},fillcolor="{color}"];')
        elif op == 'exists':
            label = 'Candidate assignment: ' + ', '.join(expr['variables'])
            options = [v + ' → ' + ' / '.join(trace['domains'].get(v, [])) for v in expr['variables']]
            lines.append(f'{name} [label={q(label + chr(10) + chr(10).join(options))},fillcolor="#dcece4"];')
        else:
            lines.append(f'{name} [label={q(op.upper() + chr(10) + "fixed logical rule")},shape=diamond];')
        for child in expr['children']:
            lines.append(f'{name} -> {visit(child)};')
        return name
    visit(compilation['expression'])
    return figure(svg_dot(lines, 'Factorized claim with shared variables and relation classifiers'), 'Factorized logical form. Repeated variable names refer to the same participant or event. Yellow boxes mark relation functions that can be learned; green boxes show candidate assignments. In the controlled example, the relation probabilities are stipulated rather than trained.')


def media_figure(cache):
    frames = []
    for rel in cache['display_frames']:
        path = ROOT / 'exp/phase2/media_cache_1fps/frames' / rel
        data = base64.b64encode(path.read_bytes()).decode()
        frames.append('<img src="data:image/jpeg;base64,' + data + '" alt="' + esc('Source frame ' + path.name) + '">')
    return figure('<div class="media-pair">' + ''.join(frames) + '</div>', 'Source frames: gray aircraft and yellow school bus, in different shots. The frozen verifier saw eight sampled frames. These examples verify depiction; on-screen text and audio are not used as evidence for the colors.')


def example(trace, run):
    compilation = trace['compilation']
    cid = compilation['claim_id']
    real = cid.startswith('real_')
    rows = []
    seen = set()
    atom_by_id = {a['id']: a for a in compilation['atoms']}
    for occurrence in trace['occurrences']:
        oid = occurrence['observation_id']
        if oid in seen:
            continue
        seen.add(oid)
        obs = trace['observations'][oid]
        atom = atom_by_id[occurrence['atom_id']]
        args = [occurrence['assignment'].get(x, x) for x in atom['arguments']]
        after = trace.get('local_after_training', {}).get(oid)
        role = 'learned relation classifier' if obs['trainable'] else 'fixed perception' if real and obs['available'] else 'unavailable → unknown' if not obs['available'] else 'constructed fixed input'
        rows.append([esc(atom['predicate'] + '(' + ', '.join(args) + ')') + '<br><code>' + esc(oid) + '</code>', esc(role),
                     distribution(obs['distribution']), distribution(after) if after is not None else 'Not trained'])
    predicates = [[esc(a['id']), '<code>' + esc(a['predicate'] + '(' + ', '.join(a['arguments']) + ')') + '</code>',
                   esc(', '.join(r + '=' + x for r, x in zip(a['roles'], a['arguments']))),
                   'learnable' if a['trainable'] else 'fixed'] for a in compilation['atoms']]
    source_rows = [[esc(obs['text']), esc(obs['provenance']['source']),
                    '<code>' + esc(str(obs['provenance'].get('request_hash') or 'constructed / unavailable')) + '</code>']
                   for obs in trace['observations'].values()]
    native = (run / ('learned_program.pl' if real else 'controlled_program.pl')).read_text()
    title = {'real_supported': 'Original color assignments', 'real_swapped': 'Swapped color assignments',
             'real_unknown': 'Same claim, no media supplied', 'control_matching': 'One event supports the complete relation',
             'control_cross_event': 'The two participants belong to different events', 'control_reversed': 'The agent and object are reversed'}[cid]
    verdict_rows = []
    for stage in ('fixed', 'trained', 'controlled'):
        if stage in trace['predictions']:
            p = trace['predictions'][stage]
            verdict_rows.append([{'fixed': 'Frozen scores + fixed logic', 'trained': 'After sample training', 'controlled': 'DeepProbLog on constructed inputs'}[stage],
                                 esc(p['prediction']), distribution(p['distribution'])])
    html = '<article class="pipeline-example" id="' + cid.replace('_', '-') + '" data-case="' + cid + '"' + ('' if cid in {'real_supported', 'control_matching'} else ' hidden') + '>'
    html += '<h3>' + title + '</h3><div class="stage"><span class="step">1</span><h4>Input claim and reference label</h4><blockquote>' + esc(compilation['text']) + '</blockquote><p>Reference label: <strong>' + esc(trace['label']) + '</strong>. ' + esc(trace['label_source']) + '.</p></div>'
    if cid == 'real_unknown':
        html += '<p class="callout">This is an explicit unavailable-media control. No frozen-model prediction is invented for the missing input, and this case is not used for training.</p>'
    html += '<div class="stage"><span class="step">2</span><h4>Parse and semantic structure</h4>' + dependency_diagram(compilation) + factor_diagram(trace) + '</div>'
    html += '<div class="stage"><span class="step">3</span><h4>Compiled predicates</h4><p><code>X1</code> and <code>X2</code> are claim participant variables; <code>E1</code> is an event variable when present. A repeated variable must keep the same evidence assignment. Candidate IDs are lookup keys, not classifier features.</p><pre><code>' + esc(compilation['logical_form']) + '</code></pre>'
    html += table(['ID', 'Predicate', 'Argument roles', 'Function'], predicates, 'Predicates compiled automatically from this claim. A relation is scored as a complete ordered tuple.') + '</div>'
    html += '<div class="stage"><span class="step">4</span><h4>Fixed observations and relation probabilities</h4><p><strong>S</strong> = supported, <strong>R</strong> = refuted, <strong>U</strong> = insufficient evidence. Each row is one categorical distribution. Exact reuse of a row shares one random variable.</p>'
    html += table(['Ground predicate', 'How it is scored', 'Input S / R / U', 'After training S / R / U'], rows, 'Actual cached probabilities for real media; explicitly constructed probabilities in the event diagnostic. Fixed entity probabilities do not change during training.')
    html += '<details><summary>Observation text and source hashes</summary>' + table(['Observation', 'Source', 'Request hash'], source_rows, 'Observation provenance. A hash identifies the saved frozen-model request; it is not an evidence label.') + '</details></div>'
    query_name = 'c_' + hashlib.sha256(cid.encode()).hexdigest()[:16]
    html += '<div class="stage"><span class="step">5</span><h4>Run the compiled DeepProbLog program</h4><p>The compiler substitutes candidate IDs into the predicates before emitting the bounded program. <code>status(O,Z)</code> gives observation <code>O</code> its categorical state <code>Z</code>. Observation IDs in the table above connect each predicate to that program.</p><p>For this input, query <code>verdict(' + query_name + ', Z)</code> for each of <code>supported</code>, <code>refuted</code>, and <code>unknown</code>.</p><details><summary>Actual executable program used in this run</summary><pre><code>' + esc(native) + '</code></pre></details>'
    html += table(['Configuration', 'Predicted label', 'Claim S / R / U'], verdict_rows, 'Measured DeepProbLog outputs. The trained values reuse the two training claims and do not estimate test performance.')
    html += '<p>The program combines probabilities under its stated model assumptions. Different queries to the same perception model are treated as independent here unless they reuse the exact same canonical observation. This assumption does not guarantee calibrated probabilities.</p></div></article>'
    return html


def training_section(training, traces):
    h = training['history']
    maximum = max(x['mean_nll'] for x in h) * 1.05
    points = ' '.join(f'{70 + (r["epoch"] - 1) / max(1,len(h)-1) * 700:.2f},{270 - r["mean_nll"] / maximum * 210:.2f}' for r in h)
    chart = '<svg viewBox="0 0 840 330" role="img" aria-label="Training loss over forty epochs"><path d="M70 50V270H785" fill="none" stroke="var(--muted)"/><polyline points="' + points + '" fill="none" stroke="var(--accent)" stroke-width="3"/><text x="70" y="305" fill="var(--text)">Epoch 1</text><text x="700" y="305" fill="var(--text)">Epoch ' + str(len(h)) + '</text><text x="12" y="275" fill="var(--text)">0</text><text x="8" y="65" fill="var(--text)">' + f'{maximum:.2f}' + '</text><text x="70" y="26" fill="var(--text)">Mean training loss (lower is better)</text></svg>'
    body = '<h2>Sample training through DeepProbLog</h2><p><strong>This is a training demonstration on two development claims from one video.</strong> One has the supported aircraft/bus colors; the other swaps the colors. Both labels come from assistant inspection. The same claims are shown before and after training. There is no held-out accuracy result.</p>'
    body += '<p>The entity observations and logical rules are fixed. A 64-hidden-unit multilayer perceptron adjusts each attribute relation’s three probabilities. Its six inputs are the three frozen scores and their logarithms; it receives no claim IDs, candidate IDs, or target labels. It therefore acts mainly as a learned score calibrator in this first run.</p>'
    body += '<p>For one claim, the loss is:</p><div class="equation">\\[\\mathcal{L}(\\theta)=-\\log p_{\\theta}(y)\\]</div><p>Here \\(y\\) is the reference claim label, \\(p_{\\theta}(y)\\) is its probability returned by DeepProbLog, and \\(\\theta\\) denotes the small classifier’s weights. Training averages this loss across claims. The reference labels supervise the final verdict; no local attribute labels are supplied to the training loop.</p>'
    body += table(['Setting', 'Measured value'], [
        ['Backend', 'DeepProbLog native Python training loop; exact inference; cached logical circuits'],
        ['Trainable model', str(training['trainable_parameters']) + ' parameters; 6 inputs → 64 hidden units → 3 outputs'],
        ['Training data', '2 claims, 1 development video; no independent test split'],
        ['Optimization', str(training['epochs']) + ' epochs; Adam, learning rate 0.01; CPU; seed ' + str(training['seed'])],
        ['First / last epoch mean loss', f'{h[0]["mean_nll"]:.9g} / {h[-1]["mean_nll"]:.9g}'],
        ['Measured training time', f'{training["elapsed_seconds"]:.3f} seconds; excludes parser loading and first circuit compilation'],
        ['Gradient check', str(len(training['gradient_checks'])) + ' classifier gradient calls; all finite; nonzero gradients observed'],
        ['Weight change', f'{training["parameter_change_l2"]:.6g} Euclidean distance from initialization'],
        ['New perception inference', '0 requests; reused 6 saved frozen-model observations']
    ], 'The small training run verifies gradient flow and parameter updates. It does not establish useful generalization.')
    body += figure('<div class="diagram-scroll">' + chart + '</div>', 'Measured mean training loss over the native DeepProbLog training loop. The reduction on these same examples is expected for a small overfitting demonstration.')
    body += '<details><summary>Exact epoch losses</summary>' + table(['Epoch', 'Mean training loss', 'Weight change'], [[r['epoch'], f'{r["mean_nll"]:.12g}', f'{r["parameter_change_l2"]:.9g}'] for r in h], 'Exact values corresponding to the training-loss figure.') + '</details>'
    body += '<p class="callout">Learning to map an uncertain frozen-model score to “refuted” on this pair does not mean the model learned visual binding from scratch. A separate, video-disjoint dataset is needed to test that claim. Full event-role classifiers and automatic candidate detection remain later work.</p>'
    return body


def checks_section(run, summary):
    checks = load(run / 'compiler_checks.json')
    tests = ET.parse(run / 'tests.xml').getroot()
    suites = tests.findall('testsuite')
    counts = {k: sum(int(s.get(k, 0)) for s in suites) for k in ('tests', 'failures', 'errors', 'skipped')}
    body = '<h2>Compiler and inference checks</h2><p>' + str(counts['tests']) + ' automated semantic, probability, and training tests; ' + str(counts['failures'] + counts['errors']) + ' failures. Tests include active/passive role equivalence, shared subjects, negation scope, branch-local references, duplicated evidence, overlapping proofs, unavailable evidence, bounded candidates, and actual gradient updates.</p>'
    body += '<p>We also sent 18 sentences through the automatic dependency parser: 7 compiled as expected, 8 unsupported constructions were rejected, and 3 intended supported constructions were rejected because the parser read “waves” as a noun. These are hand-selected regression sentences, not a representative parser benchmark.</p>'
    body += table(['Input', 'Expected', 'Observed', 'Diagnostic'], [[esc(r['text']), esc(r['expected']),
        esc(r['result']['status']) + (' — needs review' if not r['passed'] else ''),
        esc(r['result'].get('message', 'All input tokens accounted for'))] for r in checks], 'Automatic parsing and compilation checks. Rejected content is retained as a diagnostic rather than silently omitted.')
    body += '<h3>Corrections made during implementation</h3><ul><li>Event existence stays inside the scope of clause negation.</li><li>Participant variables are bound where their uses meet. A disjunction does not require candidates for an unused branch.</li><li>DeepProbLog 2.0.6’s near-zero/near-one simplification is overridden locally: only exact constants are identities. Double precision preserves very small probability outcomes and gradients.</li><li>Canonical observations are shared across duplicate predicates and alternative proofs.</li><li>Missing observations and incomplete candidate coverage yield explicit unknown states.</li></ul>'
    body += '<p>The probability tests compare DeepProbLog with an independent enumeration of categorical outcomes. Every displayed verdict distribution is checked to sum to one within one billionth, without renormalizing the backend output.</p>'
    body += '<h3>Current limits</h3><ul><li>Restricted English claims only. Quantified counts, unresolved pronouns, temporal/causal clauses, and source-assertion scope are rejected.</li><li>Real-media candidates are manually specified depicted referents; there is no automatic tracker in this demonstration.</li><li>The color relations are learned; the controlled event table only tests shared-event reasoning.</li><li>Perception scores are uncalibrated, and dependence between different model questions is not estimated.</li><li>No audio inference, multimodal-model fine-tuning, or held-out evaluation was run.</li></ul>'
    body += '<details><summary>Exact package versions and run summary</summary><pre>' + esc(json.dumps(summary, indent=2)) + '</pre></details>'
    return body


def write_downloads(run, output):
    folder = output.parent / 'verification-pipeline'
    folder.mkdir(exist_ok=True)
    for name in ('summary.json', 'traces.json', 'training.json', 'compiler_checks.json', 'tests.xml', 'fixed_program.pl', 'learned_program.pl', 'controlled_program.pl'):
        (folder / name).write_bytes((run / name).read_bytes())
    source = list((ROOT / 'scripts/probabilistic_verification').glob('*.py')) + [
        ROOT / 'scripts/run_verification_pipeline.py', ROOT / 'scripts/build_verification_pipeline_report.py',
        ROOT / 'scripts/compile_verification_claim.py',
        ROOT / 'tests/test_probabilistic_verification.py', ROOT / 'requirements-verification.txt',
        ROOT / 'docs/probabilistic_verification_implementation.md']
    files = {str(p.relative_to(ROOT)): p.read_bytes() for p in source}
    for name in ('perception_cache.json', 'parses.json'):
        files['demo/' + name] = (run / name).read_bytes()
    files['README.md'] = b'Install requirements-verification.txt in an isolated environment. Run PYTHONPATH=scripts python scripts/run_verification_pipeline.py --run-dir demo. Cached parses and frozen observations are included, so this rerun needs no model download or GPU. See docs/probabilistic_verification_implementation.md.\n'
    with zipfile.ZipFile(folder / 'source.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 22, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)


STYLE = '''
.container{max-width:1080px}.hero{padding:44px 0 28px}.hero h1{font-size:clamp(32px,5vw,52px)}
.subnav{display:flex;gap:10px;flex-wrap:wrap;margin:22px 0}.subnav a{padding:9px 14px;border:1px solid var(--border);border-radius:8px;text-decoration:none}.subnav [aria-current=page]{background:var(--accent-soft);font-weight:700}
.tabs{display:flex;gap:8px;flex-wrap:wrap;padding:12px 0;border-bottom:1px solid var(--border);margin-bottom:24px}.tabs button{font:inherit;padding:10px 14px;border:1px solid var(--border);border-radius:8px;color:var(--text);background:var(--surface);cursor:pointer}.tabs button[aria-selected=true]{border-color:var(--accent);background:var(--accent-soft);font-weight:700}
[hidden]{display:none!important}.panel h2{font-size:30px}.panel{padding:0 0 40px}select{font:inherit;color:var(--text);background:var(--surface);padding:10px;max-width:100%;border:1px solid var(--border);border-radius:6px}
.stage{padding:20px 0 28px;border-top:1px solid var(--border);margin-top:24px}.stage h4{font-size:23px;margin:0 0 15px}.step{display:inline-block;font-weight:800;color:var(--accent);margin-bottom:8px}
blockquote{font-size:23px;margin:0;padding:18px;border-left:3px solid var(--accent);background:var(--surface-2)}
.callout{border-left:3px solid var(--amber);background:var(--amber-soft);padding:16px 20px;margin:20px 0}
figure{margin:24px 0}.figure-content{padding:18px;background:var(--surface);border:1px solid var(--border);border-radius:10px}figcaption{font-size:14px;color:var(--muted);margin-top:10px}
.diagram-scroll{overflow-x:auto;max-width:100%}.diagram-scroll svg{display:block;height:auto;min-width:580px;max-width:100%;margin:auto}.media-pair{display:flex;gap:20px;justify-content:center}.media-pair img{max-height:360px;max-width:45%;object-fit:contain}
.table-wrap{overflow-x:auto;max-width:100%;margin:22px 0}table{width:100%;border-collapse:collapse;font-size:14px}caption{text-align:left;padding:12px 0;color:var(--muted)}th,td{padding:11px;border:1px solid var(--border);vertical-align:top}td code{white-space:normal;overflow-wrap:anywhere}.scores{display:block;min-width:260px;font-size:13px;font-variant-numeric:tabular-nums}.supported{color:var(--accent)}.refuted{color:var(--red)}.unknown{color:var(--amber)}
pre{white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.6 ui-monospace,monospace;padding:16px;background:var(--surface-2);border-radius:8px;max-height:650px;overflow:auto}details{margin:20px 0}summary{cursor:pointer;font-weight:600}.equation{overflow:auto;padding:18px;background:var(--surface-2)}.figure-content>svg{width:100%;height:auto}.download-row{display:flex;gap:15px;flex-wrap:wrap;margin:22px 0}.prose p{max-width:90ch}
@media(max-width:640px){.nav-inner{flex-wrap:wrap;gap:6px;padding:10px 0}.nav-links{gap:12px}.tabs button{font-size:14px;padding:9px}.container{width:calc(100% - 28px)}blockquote{font-size:20px}.figure-content{padding:8px}.media-pair{gap:10px}.stage h4{font-size:21px}}
'''

SCRIPT = '''
const tabs=[...document.querySelectorAll('[role=tab]')];
function activate(id,focus=false){for(const t of tabs){const active=t.getAttribute('aria-controls')===id;t.setAttribute('aria-selected',String(active));t.tabIndex=active?0:-1;document.getElementById(t.getAttribute('aria-controls')).hidden=!active;if(active&&focus)t.focus();}}
tabs.forEach((tab,index)=>{tab.addEventListener('click',()=>{activate(tab.getAttribute('aria-controls'));history.replaceState(null,'','#'+tab.getAttribute('aria-controls'));});tab.addEventListener('keydown',event=>{if(event.key==='ArrowRight'||event.key==='ArrowLeft'){event.preventDefault();const step=event.key==='ArrowRight'?1:-1;activate(tabs[(index+step+tabs.length)%tabs.length].getAttribute('aria-controls'),true);}});});
document.querySelectorAll('[data-case-select]').forEach(select=>select.addEventListener('change',()=>{document.querySelectorAll('#'+select.dataset.caseSelect+' .pipeline-example').forEach(example=>example.hidden=example.dataset.case!==select.value);history.replaceState(null,'','#'+select.value.replaceAll('_','-'));}));
function openHash(){const hash=location.hash.slice(1);if(document.querySelector('[role=tabpanel][id="'+CSS.escape(hash)+'"]'))activate(hash);else{const example=document.getElementById(hash);if(example&&example.classList.contains('pipeline-example')){const panel=example.closest('[role=tabpanel]');activate(panel.id);const select=panel.querySelector('select');select.value=example.dataset.case;select.dispatchEvent(new Event('change'));}}}openHash();window.addEventListener('hashchange',openHash);
'''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-dir', type=Path, default=RUN)
    ap.add_argument('--output', type=Path, default=ROOT / 'site/reports/verification-pipeline.html')
    args = ap.parse_args()
    run, output = args.run_dir, args.output
    traces, summary, training, cache = [load(run / name) for name in ('traces.json', 'summary.json', 'training.json', 'perception_cache.json')]
    real = '<section class="panel" role="tabpanel" id="real-media" aria-labelledby="tab-real"><h2>Real video: attribute binding</h2><p>These shorter claims come from the inspected aircraft/bus color pair. The input sentence is parsed automatically. Six frozen Qwen3-VL-8B observations are reused from 15 October; no new GPU calls were needed. The aircraft and bus-group references are specified manually.</p>' + media_figure(cache)
    real += '<label>Choose a claim <select data-case-select="real-media"><option value="real_supported">Original colors — supported</option><option value="real_swapped">Swapped colors — refuted reference label</option><option value="real_unknown">No media — unknown</option></select></label>'
    real += ''.join(example(t, run) for cid, t in traces.items() if cid.startswith('real_')) + '</section>'
    control = '<section class="panel" role="tabpanel" id="controlled" aria-labelledby="tab-controlled" hidden><h2>Controlled test: keep both roles in the same event</h2><p class="callout"><strong>Constructed evidence, not video predictions.</strong> This inventory contains two events: Alice hugs Bob; Carol hugs Dave. It tests the compiler and inference separately from perception.</p><p>All four people are present and hugging occurs. Alice hugging Dave still lacks a matching event. The complete relation is evaluated separately for each candidate event; agent and object cannot select different events.</p><label>Choose a claim <select data-case-select="controlled"><option value="control_matching">Alice hugs Bob — matching event</option><option value="control_cross_event">Alice hugs Dave — different events</option><option value="control_reversed">Bob hugs Alice — reversed roles</option></select></label>'
    control += ''.join(example(t, run) for cid, t in traces.items() if cid.startswith('control_')) + '</section>'
    training_html = '<section class="panel" role="tabpanel" id="training" aria-labelledby="tab-training" hidden>' + training_section(training, traces) + '</section>'
    checks = '<section class="panel" role="tabpanel" id="compiler-checks" aria-labelledby="tab-checks" hidden>' + checks_section(run, summary) + '</section>'
    document = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Executed claim compiler, frozen perception observations, DeepProbLog exact inference and sample training, with full example traces."><title>Claim compilation and DeepProbLog pipeline · AViD</title><link rel="stylesheet" href="../assets/site.css"><style>''' + STYLE + r'''</style><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},svg:{fontCache:'global'}};</script><script async id="MathJax-script" src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script></head><body><nav class="site-nav" aria-label="Primary navigation"><div class="nav-inner"><a class="brand" href="../index.html">SCALE 2026 · AViD</a><div class="nav-links"><a href="../index.html">Home</a><a href="tree-crf.html">Tree-CRF verifier</a><a href="../proposals/">Proposals</a></div></div></nav><header class="hero"><div class="container"><p class="eyebrow">Tentative implementation · 22 October 2026</p><h1>From a claim to a DeepProbLog verdict</h1><p class="lede">Inspect the input claim, automatic parse, shared arguments, frozen-model scores, compiled program, and an actual training update.</p><nav class="subnav" aria-label="Verification project"><a href="../proposals/probabilistic-verification.html">Paper design</a><a href="../proposals/probabilistic-verification.html#generated-examples">Generated examples</a><a href="verification-pipeline.html" aria-current="page">Implementation</a></nav><p>This is an executed prototype with two training examples, not a paper result. The perception model stays frozen. Only a 643-parameter relation classifier is trained.</p><div class="download-row"><a href="verification-pipeline/source.zip">Download source and cached inputs</a><a href="verification-pipeline/traces.json">Full traces (JSON)</a><a href="verification-pipeline/learned_program.pl">Executed learned program</a><a href="verification-pipeline/tests.xml">Automated test results</a></div></div></header><main class="container prose"><div class="tabs" role="tablist" aria-label="Pipeline views"><button role="tab" id="tab-real" aria-controls="real-media" aria-selected="true">Real media</button><button role="tab" id="tab-controlled" aria-controls="controlled" aria-selected="false" tabindex="-1">Same-event test</button><button role="tab" id="tab-training" aria-controls="training" aria-selected="false" tabindex="-1">Sample training</button><button role="tab" id="tab-checks" aria-controls="compiler-checks" aria-selected="false" tabindex="-1">Compiler checks</button></div>''' + real + control + training_html + checks + '''<p>Primary references: <a href="https://papers.nips.cc/paper/7632-deepproblog-neural-probabilistic-logic-programming.pdf">DeepProbLog paper</a>, <a href="https://github.com/ML-KULeuven/deepproblog">official implementation</a>, and <a href="https://stanfordnlp.github.io/stanza/">Stanza documentation</a>. The compiler and demonstrations here are our project implementation.</p></main><footer class="site-footer"><div class="container">Generated from saved artifacts by scripts/build_verification_pipeline_report.py. No model inference is performed while building this page. Equations use MathJax from a CDN.</div></footer><script>''' + SCRIPT + '</script></body></html>'
    output.parent.mkdir(parents=True, exist_ok=True)
    write_downloads(run, output)
    output.write_text(document)
    print(f'Wrote {output}: {FIGURES} figures, {TABLES} tables, {len(document.encode()):,} bytes')


if __name__ == '__main__':
    main()
