"""Two evidence trees with shared candidates and explicit source policies.

Combine observations for the same grounded predicate, then apply claim logic.
Unknown contributes no evidence; a support/refutation conflict becomes unknown
and remains visible in the diagnostic record. Different source meanings must
not be combined as though they expressed the same proposition.
"""
from __future__ import annotations

from dataclasses import replace

from .logic import Evidence, GroundProgram, Observation, ground
from .representation import Expression as E


def eligible_evidence(claim, evidence: Evidence, allowed: dict[str, set[str]]) -> Evidence:
    """Apply a declared per-atom policy, without reading reference labels.

    `allowed` maps compiler atom IDs to eligible route names. Raw observations
    remain in the original Evidence object and in the saved feature audit.
    """
    unfiltered = ground(claim, evidence)
    observations = dict(evidence.observations)
    for occurrence in unfiltered.occurrences:
        if evidence.route not in allowed.get(occurrence["atom_id"], set()):
            obs = unfiltered.observations[occurrence["observation_id"]]
            observations[obs.key] = Observation(obs.key, (0., 0., 1.), False, obs.text,
                dict(obs.provenance, excluded_by_policy=True, raw_distribution=list(obs.distribution)), False)
    return replace(evidence, observations=observations)


def ground_two_sources(claim, first: Evidence, second: Evidence, *, allowed=None):
    """Return both independent trees, their predicate-level combination, conflicts.

    Candidate IDs have a common meaning across sources. We refuse to merge
    independently enumerated inventories: that could bind different referents.
    """
    if first.media_id != second.media_id or first.route == second.route:
        raise ValueError("Two distinct evidence routes from the same clip are required.")
    if first.domains != second.domains or first.complete != second.complete:
        raise ValueError("Align candidate inventories before combining evidence trees.")
    if allowed is not None:
        first, second = (eligible_evidence(claim, e, allowed) for e in (first, second))
    a, b = ground(claim, first), ground(claim, second)
    if [(o["atom_id"], o["assignment"]) for o in a.occurrences] != [(o["atom_id"], o["assignment"]) for o in b.occurrences]:
        raise ValueError("Grounded predicates and candidate assignments must align.")
    conflicts = []
    def merge(x, y):
        if x.op != y.op or x.variables != y.variables or x.state != y.state or len(x.children) != len(y.children):
            raise ValueError("Evidence trees must have the same logical structure.")
        if x.op == "atom":
            left, right = a.observations[x.atom_id], b.observations[y.atom_id]
            conflicts.append(dict(first_observation=left.id, second_observation=right.id,
                probability=left.distribution[0]*right.distribution[1]+left.distribution[1]*right.distribution[0],
                assumption="independent source observations of the same proposition"))
            return E("evidence", (x, y))
        return E(x.op, tuple(merge(c,d) for c,d in zip(x.children,y.children)), state=x.state, variables=x.variables)
    combined = GroundProgram(claim.claim_id + "__combined", merge(a.expression,b.expression),
        dict(a.observations, **b.observations), a.occurrences + b.occurrences, a.expansions)
    a.claim_id += "__" + first.route
    b.claim_id += "__" + second.route
    return a, b, combined, conflicts
