"""Compile a deliberately restricted Universal Dependencies analysis.

The input is a single sentence's Stanza-style, 1-based UD word records. No
perception scores or verification labels enter compilation. Unsupported content
raises a diagnostic rather than disappearing from the logical form.
"""
from __future__ import annotations

import re
from .representation import Atom, CompiledClaim, Expression as E, Variable


class CompilationError(ValueError):
    def __init__(self, code: str, message: str, token_ids=()):
        super().__init__(message)
        self.code, self.token_ids = code, tuple(token_ids)

    def to_dict(self) -> dict:
        return {"status": "unsupported", "code": self.code,
                "message": str(self), "token_ids": list(self.token_ids)}


def symbol(text: str) -> str:
    text = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return text if text and text[0].isalpha() else "value_" + text


class ClaimCompiler:
    """A compiler object has no learned weights; instantiate once per sentence."""

    def compile(self, claim_id: str, text: str, tokens: list[dict]) -> CompiledClaim:
        self.text = text
        self.tokens = {int(t["id"]): dict(t) for t in tokens}
        self.children = {i: [] for i in self.tokens}
        self.used: dict[int, list[str]] = {}
        self.variables: list[Variable] = []
        self.atoms: list[Atom] = []
        self.entities: dict[int, tuple[str, E]] = {}
        self.names: dict[str, tuple[str, E]] = {}
        for t in self.tokens.values():
            if t["head"]:
                if t["head"] not in self.children:
                    raise CompilationError("invalid_dependency", "Dependency head is missing.", [t["id"]])
                self.children[t["head"]].append(t)
            seen, current = set(), t
            while current["head"]:
                if current["id"] in seen:
                    raise CompilationError("dependency_cycle", "Dependency heads contain a cycle.", [t["id"]])
                seen.add(current["id"])
                current = self.tokens.get(current["head"], {"id": 0, "head": 0})
        roots = [t for t in self.tokens.values() if t["head"] == 0]
        if len(roots) != 1:
            raise CompilationError("sentence_count", "Compile one sentence with one dependency root at a time.")
        for t in self.tokens.values():
            lemma, dep = self.lemma(t), t["deprel"]
            if dep.startswith("nummod") or lemma in {"all", "every", "each", "both", "exactly", "neither", "nor", "no"}:
                raise CompilationError("quantification", "Counting and quantified noun phrases are outside the initial fragment.", [t["id"]])
            if lemma in {"if", "unless", "before", "after", "while", "because", "until"}:
                raise CompilationError("scope", "Temporal, conditional, and causal clauses need an explicit extension.", [t["id"]])
            if t.get("upos") == "AUX" and lemma not in {"be", "do", "have"}:
                raise CompilationError("modality", "Modal auxiliaries are outside the initial fragment.", [t["id"]])
            if dep == "punct":
                self.mark(t, "punctuation")
        expr = self.bind_references(self.clause(roots[0]))
        unseen = [t for i, t in self.tokens.items() if i not in self.used]
        if unseen:
            raise CompilationError("unhandled_content", "The compiler cannot yet preserve: " + ", ".join(t["text"] for t in unseen), [t["id"] for t in unseen])
        if sum(v.kind == "event" for v in self.variables) > 3:
            raise CompilationError("clause_limit", "The initial fragment permits at most three event clauses.")
        coverage = tuple({"token_id": i, "text": t["text"], "represented_by": self.used[i]}
                         for i, t in self.tokens.items())
        return CompiledClaim(claim_id, text, tuple(tokens), tuple(self.variables),
                             tuple(self.atoms), expr, coverage)

    @staticmethod
    def lemma(t: dict) -> str:
        return t.get("lemma", t["text"]).lower()

    def mark(self, token: dict, reason: str):
        self.used.setdefault(token["id"], []).append(reason)

    def bind_references(self, expression: E) -> E:
        """Bind a referent where its uses meet, retaining branch-local scope.

        Hoisting every referent above OR would incorrectly require candidates
        for an irrelevant branch. Shared referents still bind above both uses.
        """
        entities = {v.name for v in self.variables if v.kind == "entity"}
        atoms = {a.id: a for a in self.atoms}
        def free(expr):
            if expr.op == "atom":
                return set(atoms[expr.atom_id].arguments) & entities
            return set().union(*(free(c) for c in expr.children)) - set(expr.variables)
        def visit(expr, bound):
            if expr.op == "atom":
                here = free(expr) - bound
            else:
                child_sets = [free(c) - bound for c in expr.children]
                here = {v for v in entities if sum(v in s for s in child_sets) > 1}
            children = tuple(visit(c, bound | here | set(expr.variables)) for c in expr.children)
            rebuilt = E(expr.op, children, expr.atom_id, expr.variables, expr.state)
            return E.exists(sorted(here), rebuilt)
        return visit(expression, set())

    def add_atom(self, predicate, arguments, kind, roles, text, tokens, trainable):
        atom = Atom(f"a{len(self.atoms)}", symbol(predicate), tuple(arguments), kind,
                    tuple(roles), text, tuple(sorted({t["id"] for t in tokens})), trainable)
        for old in self.atoms:
            if (old.predicate, old.arguments, old.kind) == (atom.predicate, atom.arguments, atom.kind):
                for t in tokens:
                    self.mark(t, old.id)
                return E.atom(old.id)
        self.atoms.append(atom)
        for t in tokens:
            self.mark(t, atom.id)
        return E.atom(atom.id)

    def noun(self, head: dict) -> tuple[str, E]:
        if head["id"] in self.entities:
            return self.entities[head["id"]]
        if head.get("upos") not in {"NOUN", "PROPN"}:
            raise CompilationError("reference", "An explicit noun phrase is required; pronoun resolution is not implemented.", [head["id"]])
        children = self.children[head["id"]]
        if any(c["deprel"] == "conj" for c in children):
            raise CompilationError("coordinated_arguments", "Collective versus distributive argument conjunction is not yet resolved.", [head["id"]])
        name_tokens = [head] + [c for c in children if c["deprel"] in {"compound", "flat", "flat:name"}]
        name_tokens.sort(key=lambda t: t["id"])
        label = " ".join(self.lemma(t) for t in name_tokens)
        surface = " ".join(t["text"] for t in name_tokens)
        name_key = label if head["upos"] == "PROPN" else ""
        if name_key and name_key in self.names:
            var, expr = self.names[name_key]
            for t in name_tokens:
                self.mark(t, "shared named participant " + var)
            self.entities[head["id"]] = (var, expr)
            return var, expr
        var = "X" + str(sum(v.kind == "entity" for v in self.variables) + 1)
        self.variables.append(Variable(var, "entity", surface, tuple(t["id"] for t in name_tokens)))
        expressions = [self.add_atom("entity", [var, symbol(label)], "entity", ["referent", "type"],
                                     f"{surface} is present.", name_tokens, False)]
        for c in children:
            dep = c["deprel"]
            if dep == "det" and self.lemma(c) in {"a", "an", "the"}:
                self.mark(c, "noun phrase determiner")
            elif dep == "amod":
                expressions.append(self.add_atom("attribute", [var, symbol(self.lemma(c))], "attribute",
                                                 ["holder", "property"], f"The {surface} is {c['text']}.", [c], True))
            elif dep == "nmod:poss":
                owner, owner_expr = self.noun(c)
                expressions.append(owner_expr)
                expressions.append(self.add_atom("possess", [owner, var], "relation", ["owner", "possession"],
                                                 f"The {surface} belongs to {c['text']}.", [head, c], True))
            elif dep == "case" and self.lemma(c) in {"'s", "’s"}:
                self.mark(c, "possessive marker")
        expr = E.combine("and", expressions)
        self.entities[head["id"]] = (var, expr)
        if name_key:
            self.names[name_key] = (var, expr)
        return var, expr

    def clause(self, root: dict, inherited_subject: dict | None = None) -> E:
        children = self.children[root["id"]]
        subjects = [t for t in children if t["deprel"] in {"nsubj", "nsubj:pass"}]
        if len(subjects) > 1 or (not subjects and inherited_subject is None):
            raise CompilationError("subject", "A clause needs one explicit or inherited subject.", [root["id"]])
        subject = subjects[0] if subjects else inherited_subject
        subject_var, subject_expr = self.noun(subject)
        for c in children:
            if c["deprel"] in {"aux", "aux:pass", "cop"}:
                self.mark(c, "auxiliary or copula")
        negators = [t for t in children if self.lemma(t) in {"not", "n't", "never"}]
        if any(self.lemma(t) == "never" for t in negators):
            raise CompilationError("temporal_negation", "Never requires temporal coverage beyond the initial fragment.", [t["id"] for t in negators])
        for t in negators:
            self.mark(t, "scoped negation")
        copular = any(t["deprel"] == "cop" for t in children)
        if copular and root["upos"] in {"ADJ", "NOUN", "PROPN"}:
            body = self.add_atom("attribute", [subject_var, symbol(self.lemma(root))], "attribute",
                                 ["holder", "property"], f"{subject['text']} is {root['text']}.", [root], True)
            if negators:
                body = E.negate(body)
            current = E.combine("and", [subject_expr, body])
        elif root["upos"] == "VERB":
            if self.lemma(root) in {"say", "tell", "claim", "report", "believe", "think", "want", "try", "begin", "seem"}:
                raise CompilationError("intensional_predicate", "Assertion, intention, and aspect need explicit scope and evidence policies.", [root["id"]])
            event = "E" + str(sum(v.kind == "event" for v in self.variables) + 1)
            self.variables.append(Variable(event, "event", self.lemma(root), (root["id"],)))
            role_tokens: dict[str, dict] = {}
            passive = subject["deprel"] == "nsubj:pass" or any(t["deprel"] == "aux:pass" for t in children)
            role_tokens["theme" if passive else "agent"] = subject
            for c in children:
                if c["deprel"] in {"obj", "iobj", "obl:agent"}:
                    role = {"obj": "theme", "iobj": "recipient", "obl:agent": "agent"}[c["deprel"]]
                    if role in role_tokens:
                        raise CompilationError("duplicate_role", "More than one argument occupies the same role.", [c["id"]])
                    role_tokens[role] = c
                    if role == "agent":
                        for marker in self.children[c["id"]]:
                            if marker["deprel"] == "case" and self.lemma(marker) == "by":
                                self.mark(marker, "passive agent marker")
            argument_exprs = [subject_expr]
            arguments, roles = [event], ["event"]
            for role in ("agent", "theme", "recipient"):
                if role in role_tokens:
                    var, noun_expr = self.noun(role_tokens[role])
                    arguments.append(var)
                    roles.append(role)
                    argument_exprs.append(noun_expr)
            if negators:
                for token in role_tokens.values():
                    if any(self.lemma(d) in {"a", "an"} for d in self.children[token["id"]] if d["deprel"] == "det"):
                        raise CompilationError("negative_indefinite", "Negation with indefinite arguments needs a richer quantifier analysis.", [token["id"]])
            event_expr = self.add_atom("event", [event, symbol(self.lemma(root))], "event", ["event", "action"],
                                       f"An instance of {self.lemma(root)} occurs.", [root], False)
            relation = self.add_atom(self.lemma(root), arguments, "relation", roles,
                                     " ".join([subject["text"], root["text"]] +
                                              [role_tokens[r]["text"] for r in ("theme", "recipient") if r in role_tokens]) + ".",
                                     [root] + list(role_tokens.values()), True)
            event_body = E.exists([event], E.combine("and", [event_expr, relation]))
            if negators:
                event_body = E.negate(event_body)
            current = E.combine("and", argument_exprs + [event_body])
        else:
            raise CompilationError("predicate", "Expected an action verb or a copular property.", [root["id"]])
        conjuncts = [c for c in children if c["deprel"] == "conj"]
        if conjuncts:
            operations = []
            branches = [current]
            for c in conjuncts:
                markers = [m for m in self.children[c["id"]] if m["deprel"] == "cc"]
                if len(markers) != 1 or self.lemma(markers[0]) not in {"and", "or"}:
                    raise CompilationError("coordination", "Use explicit and/or coordination; other coordination is not yet supported.", [c["id"]])
                operations.append(self.lemma(markers[0]))
                self.mark(markers[0], "logical " + operations[-1])
                branches.append(self.clause(c, subject))
            if len(set(operations)) != 1:
                raise CompilationError("coordination_scope", "Mixed conjunction and disjunction need explicit scope.")
            current = E.combine(operations[0], branches)
        return current
