"""CPU dependency parsing with the project's cached English Stanza models."""
from __future__ import annotations

import hashlib
import importlib.metadata
from pathlib import Path


class DependencyParser:
    def __init__(self, model_dir="/exp/cxiao/.cache/stanza"):
        import stanza
        import torch

        torch.set_num_threads(2)
        model_dir = Path(model_dir)
        # These are trusted, existing project model files predating the PyTorch
        # weights_only default. Limit the compatibility override to model loading.
        original_load = torch.load
        def load_cached(*args, **kwargs):
            kwargs.setdefault("weights_only", False)
            return original_load(*args, **kwargs)
        torch.load = load_cached
        try:
            self.pipeline = stanza.Pipeline(
                "en", dir=str(model_dir), use_gpu=False, download_method=None,
                processors={"tokenize": "combined", "pos": "combined_charlm",
                            "lemma": "combined_nocharlm", "depparse": "combined_charlm"},
                package=None, verbose=False)
        finally:
            torch.load = original_load
        paths = [p for folder in ("tokenize", "pos", "lemma", "depparse")
                 for p in (model_dir / "en" / folder).glob("*.pt")]
        self.provenance = {"library": "stanza", "version": importlib.metadata.version("stanza"),
                           "device": "cpu", "model_dir": str(model_dir),
                           "model_sha256": {str(p.relative_to(model_dir)): hashlib.sha256(p.read_bytes()).hexdigest()
                                            for p in paths}}

    def parse(self, text: str) -> list[dict]:
        doc = self.pipeline(text)
        if len(doc.sentences) != 1:
            raise ValueError("Supply exactly one sentence.")
        return [{"id": w.id, "text": w.text, "lemma": w.lemma, "upos": w.upos,
                 "head": w.head, "deprel": w.deprel, "start_char": w.start_char,
                 "end_char": w.end_char, "feats": w.feats}
                for w in doc.sentences[0].words]
