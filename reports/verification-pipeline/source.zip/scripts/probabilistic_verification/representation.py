"""Small, serializable logical forms independent of the inference library."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable

STATES = ("supported", "refuted", "unknown")


@dataclass(frozen=True)
class Variable:
    name: str
    kind: str
    description: str
    token_ids: tuple[int, ...]


@dataclass(frozen=True)
class Atom:
    id: str
    predicate: str
    arguments: tuple[str, ...]
    kind: str
    roles: tuple[str, ...]
    text: str
    token_ids: tuple[int, ...]
    trainable: bool

    def display(self) -> str:
        return f"{self.predicate}({', '.join(self.arguments)})"


@dataclass(frozen=True)
class Expression:
    op: str
    children: tuple[Expression, ...] = ()
    atom_id: str = ""
    variables: tuple[str, ...] = ()
    state: str = ""

    @classmethod
    def atom(cls, atom_id: str) -> Expression:
        return cls("atom", atom_id=atom_id)

    @classmethod
    def constant(cls, state: str) -> Expression:
        if state not in STATES:
            raise ValueError(state)
        return cls("constant", state=state)

    @classmethod
    def combine(cls, op: str, children: Iterable[Expression]) -> Expression:
        if op not in {"and", "or"}:
            raise ValueError(op)
        unique = tuple(dict.fromkeys(children))
        if not unique:
            return cls.constant("supported" if op == "and" else "refuted")
        return unique[0] if len(unique) == 1 else cls(op, unique)

    @classmethod
    def negate(cls, child: Expression) -> Expression:
        return child.children[0] if child.op == "not" else cls("not", (child,))

    @classmethod
    def exists(cls, variables: Iterable[str], child: Expression) -> Expression:
        variables = tuple(variables)
        return cls("exists", (child,), variables=variables) if variables else child

    def display(self, atoms: dict[str, Atom]) -> str:
        if self.op == "atom":
            return atoms[self.atom_id].display()
        if self.op == "constant":
            return self.state
        body = [x.display(atoms) for x in self.children]
        if self.op == "not":
            return f"NOT ({body[0]})"
        if self.op == "exists":
            return f"EXISTS {', '.join(self.variables)}: ({body[0]})"
        return "(" + f" {self.op.upper()} ".join(body) + ")"


@dataclass(frozen=True)
class CompiledClaim:
    claim_id: str
    text: str
    tokens: tuple[dict, ...]
    variables: tuple[Variable, ...]
    atoms: tuple[Atom, ...]
    expression: Expression
    coverage: tuple[dict, ...]
    warnings: tuple[str, ...] = ()
    version: str = "claim-compiler-v1"

    def to_dict(self) -> dict:
        out = asdict(self)
        out["status"] = "compiled"
        out["logical_form"] = self.expression.display({a.id: a for a in self.atoms})
        return out
