"""Bound candidate assignments and emit three-state probabilistic logic.

Unknown is an explicit outcome. Failing to find a witness in an incomplete
candidate inventory never establishes refutation. Repeated observations share
one categorical random variable, including across different proof paths.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
from dataclasses import asdict, dataclass, field

from .representation import Atom, CompiledClaim, Expression as E, STATES


def canonical_key(media_id: str, atom: Atom, assignment: dict[str, str], route: str) -> str:
    return json.dumps([media_id, route, atom.predicate,
                       [assignment.get(x, x) for x in atom.arguments]], separators=(",", ":"))


def combine_states(op: str, states) -> str:
    states = tuple(states)
    if op == "not":
        return {"supported": "refuted", "refuted": "supported", "unknown": "unknown"}[states[0]]
    if op == "and":
        return "refuted" if "refuted" in states else "supported" if all(s == "supported" for s in states) else "unknown"
    if op == "or":
        return "supported" if "supported" in states else "refuted" if all(s == "refuted" for s in states) else "unknown"
    if op == "evidence":
        if len(states) != 2:
            raise ValueError("Evidence combination currently takes exactly two sources.")
        informative = set(states) - {"unknown"}
        return next(iter(informative)) if len(informative) == 1 else "unknown"
    raise ValueError(op)


@dataclass(frozen=True)
class Observation:
    key: str
    distribution: tuple[float, float, float]
    trainable: bool
    text: str
    provenance: dict = field(default_factory=dict)
    available: bool = True

    def __post_init__(self):
        if len(self.distribution) != 3 or any(not math.isfinite(p) or p < 0 or p > 1 for p in self.distribution):
            raise ValueError("Expected three finite probabilities in [0, 1].")
        if not math.isclose(sum(self.distribution), 1.0, abs_tol=1e-6):
            raise ValueError("Observation probabilities must sum to one.")
        if not self.available and self.distribution != (0., 0., 1.):
            raise ValueError("Unavailable observations must be explicitly unknown.")

    @property
    def id(self):
        return "o_" + hashlib.sha256(self.key.encode()).hexdigest()[:20]

    def to_dict(self):
        return dict(asdict(self), id=self.id)


@dataclass
class Evidence:
    media_id: str
    domains: dict[str, list[str]]
    complete: dict[str, bool]
    observations: dict[str, Observation]
    route: str = "visual_depiction"
    candidate_descriptions: dict[str, str] = field(default_factory=dict)


@dataclass
class GroundProgram:
    claim_id: str
    expression: E
    observations: dict[str, Observation]
    occurrences: list[dict]
    expansions: list[dict]


def ground(claim: CompiledClaim, evidence: Evidence, *, max_expansions=256) -> GroundProgram:
    atom_by_id = {a.id: a for a in claim.atoms}
    observations, occurrences, expansions = {}, [], []
    budget = 0

    def visit(expr, assignment):
        nonlocal budget
        if expr.op == "exists":
            domains = [evidence.domains.get(v, []) for v in expr.variables]
            if any(len(d) != len(set(d)) for d in domains):
                raise ValueError("Candidate domains must not contain duplicate IDs.")
            count = math.prod(map(len, domains))
            if budget + count > max_expansions:
                raise ValueError(f"Candidate expansion exceeds the explicit limit of {max_expansions}.")
            complete = all(evidence.complete.get(v, False) for v in expr.variables)
            expansions.append(dict(variables=list(expr.variables), candidate_combinations=count,
                                   complete=complete, outer_assignment=dict(assignment)))
            branches = []
            for values in itertools.product(*domains):
                budget += 1
                branches.append(visit(expr.children[0], dict(assignment, **dict(zip(expr.variables, values)))))
            if not complete:
                branches.append(E.constant("unknown"))
            return E.combine("or", branches)
        if expr.op == "atom":
            atom = atom_by_id[expr.atom_id]
            key = canonical_key(evidence.media_id, atom, assignment, evidence.route)
            obs = evidence.observations.get(key)
            if obs is None:
                obs = Observation(key, (0., 0., 1.), False, atom.text,
                                  {"source": "missing observation", "route": evidence.route}, False)
            if obs.key != key:
                raise ValueError("Observation lookup key does not match its recorded identity.")
            observations[obs.id] = obs
            occurrences.append(dict(atom_id=atom.id, observation_id=obs.id,
                                    predicate=atom.display(), assignment=dict(assignment)))
            return E.atom(obs.id)
        return E(expr.op, tuple(visit(x, assignment) for x in expr.children),
                 atom_id=expr.atom_id, variables=expr.variables, state=expr.state)

    return GroundProgram(claim.claim_id, visit(claim.expression, {}), observations, occurrences, expansions)


def enumerate_probability(program: GroundProgram, *, max_worlds=100_000) -> dict[str, float]:
    """Independent small-case oracle, deliberately not used as the backend."""
    obs = list(program.observations.values())
    if 3 ** len(obs) > max_worlds:
        raise ValueError("Exhaustive reference calculation is restricted to small tests.")
    def evaluate(expr, world):
        if expr.op == "constant":
            return expr.state
        if expr.op == "atom":
            return world[expr.atom_id]
        return combine_states(expr.op, (evaluate(c, world) for c in expr.children))
    result = dict.fromkeys(STATES, 0.)
    for values in itertools.product(range(3), repeat=len(obs)):
        weight = math.prod(o.distribution[i] for o, i in zip(obs, values))
        if weight:
            result[evaluate(program.expression, {o.id: STATES[i] for o, i in zip(obs, values)})] += weight
    return result


def prolog_program(programs: list[GroundProgram], *, learned=True) -> tuple[str, dict[str, str]]:
    lines = ["% Generated categorical evidence and explicit supported/refuted/unknown composition."]
    observations = {}
    for p in programs:
        for oid, obs in p.observations.items():
            if oid in observations and observations[oid] != obs:
                raise ValueError("A shared observation has conflicting values or provenance.")
            observations[oid] = obs
    if learned and any(o.trainable and o.available for o in observations.values()):
        lines.append("nn(relation_net,[tensor(features(O))],Z,[supported,refuted,unknown]) :: learned_status(O,Z).")
    for oid, obs in sorted(observations.items()):
        if learned and obs.trainable and obs.available:
            lines.append(f"status({oid},Z) :- learned_status({oid},Z).")
        else:
            lines.append("; ".join(f"{p:.17g}::status({oid},{s})" for p, s in zip(obs.distribution, STATES)) + ".")
    for op in ("and", "or", "evidence"):
        for a, b in itertools.product(STATES, repeat=2):
            lines.append(f"{op}_state({a},{b},{combine_states(op, [a,b])}).")
    for a in STATES:
        lines.append(f"not_state({a},{combine_states('not', [a])}).")
    names, nodes = {}, {}

    def emit(expr):
        if expr in nodes:
            return nodes[expr]
        name = "n" + str(len(nodes))
        nodes[expr] = name
        if expr.op == "atom":
            lines.append(f"node({name},Z) :- status({expr.atom_id},Z).")
        elif expr.op == "constant":
            lines.append(f"node({name},{expr.state}).")
        elif expr.op == "not":
            child = emit(expr.children[0])
            lines.append(f"node({name},Z) :- node({child},A), not_state(A,Z).")
        elif expr.op in {"and", "or", "evidence"}:
            children = [emit(x) for x in expr.children]
            current = children[0]
            for i, right in enumerate(children[1:]):
                target = name if i == len(children) - 2 else f"{name}_fold{i}"
                lines.append(f"node({target},Z) :- node({current},A), node({right},B), {expr.op}_state(A,B,Z).")
                current = target
        else:
            raise ValueError("Ground expressions cannot contain quantifiers.")
        return name

    for p in programs:
        if p.claim_id in names:
            raise ValueError("Claim identifiers must be unique within a program.")
        claim_name = "c_" + hashlib.sha256(p.claim_id.encode()).hexdigest()[:16]
        names[p.claim_id] = claim_name
        root = emit(p.expression)
        lines.append(f"verdict({claim_name},Z) :- node({root},Z).")
        for state in STATES:
            lines.append(f"query(verdict({claim_name},{state})).")
    return "\n".join(lines) + "\n", names
