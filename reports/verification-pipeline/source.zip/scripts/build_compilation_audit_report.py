"""Render the real-claim compiler census and source-linked assistant review."""
from __future__ import annotations

from collections import Counter
from html import escape as esc
import json
from pathlib import Path
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compilation_audit_20261028'


def load(name):return json.loads((RUN/name).read_text())
def read(name):return [json.loads(l) for l in (RUN/name).read_text().splitlines() if l.strip()]
def pre(value):return '<pre><code>'+esc(value if isinstance(value,str) else json.dumps(value,indent=2,ensure_ascii=False))+'</code></pre>'


CORE={'adequate_in_restricted_core':'Core structure adequate in the restricted fragment',
      'incorrect_core':'Core meaning error', 'ambiguous_semantic_contract':'Semantic interpretation needs a defined contract',
      'not_emitted':'No program emitted'}


def build_audit(table):
    summary,analysis,manifest=load('census_summary.json'),load('analysis.json'),load('manifest.json')
    findings=load('findings.json')
    reviews=read('semantic_reviews.jsonl')
    outputs={r['claim_id']:r for r in read('current_results.jsonl')}
    by_index={r['review_index']:r for r in reviews}
    count=manifest['inventory_claims'];current=summary['conditions']['current']
    body='<section class="panel" role="tabpanel" id="compilation-audit" aria-labelledby="tab-audit" hidden><h2>Audit compilation on real claims</h2><p><strong>Baseline audit completed · 28 October 2026.</strong> The current compiler pipeline accepts '+str(current['statuses']['compiled'])+' of '+f'{count:,}'+' claims ('+f'{100*current["statuses"]["compiled"]/count:.2f}'+'%). Ordinary locations, complements, fragments and quantities are outside its effective coverage. Accepted programs also need semantic review. The compiler was frozen throughout this audit; no parser/model training or compiler fix was introduced.</p>'
    body+='<div class="download-row"><a href="verification-pipeline/audit/census_summary.json">Census counts</a><a href="verification-pipeline/audit/current_index.json">All 2,375 outcomes</a><a href="verification-pipeline/audit/semantic_reviews.jsonl">All assistant reviews</a><a href="verification-pipeline/audit/review_records.json">Reviews with exact compiler outputs</a><a href="verification-pipeline/audit/findings.json">Findings and recommendations</a><a href="verification-pipeline/audit/source.zip">Frozen source, inputs and replay</a><a href="#next-steps">Updated checklist</a></div>'
    body+='<p class="callout"><strong>Coverage is not correctness.</strong> “Compiled” means a logical form was emitted. “Unsupported” is a compiler/input diagnostic, not a claim verdict of refuted or insufficient evidence. This experiment uses claim text and dependency parses; it does not assess whether the media supports a claim.</p>'
    body+='<h3>1. What was frozen and checked</h3>'
    body+=table(['Item','Audit scope'],[
        ['Claim inventory',f'{count:,} distinct claim IDs from {manifest["annotation_rows"]:,} current annotation rows; exact claim text and SHA-256 stored per ID. The older 761-claim file is not used.'],
        ['Stored-parse condition','Exact-text-matched phase-1 UD tokens. Convert zero-based IDs/heads to one-based IDs and root head 0. Omit 7 SpaCy whitespace-only records, preserving original records and lexical IDs. No lexical or dependency repairs.'],
        ['Current-parser condition','Frozen CPU Stanza '+esc(manifest['versions']['stanza'])+' with the current project parser wrapper. Parse the same original texts; decline multi-sentence inputs as the existing wrapper requires.'],
        ['Baseline source','All compiler-package Python files copied before execution; SHA-256 fingerprints checked. The original runtime/model version of the stored parse artifact is unavailable; the new parser’s exact model hashes are saved.'],
        ['Review population',str(manifest['development_eligible'])+' claims with exact-text-linked source videos outside all '+str(manifest['reserved_video_count'])+' reserved evaluation videos. Automatic census covers the whole inventory; qualitative development review excludes reserved sources.'],
        ['Review sample','50 uniformly sampled development claims (seed 20261028), 20 purposive diagnostic cases, plus 9 additional accepted cases. The resulting 79 reviews include every one of the 20 accepted development programs.'],
        ['Review provenance','Assistant inspection of original text, parse, diagnostic and program. No independent human gold, media verification or representative held-out semantic-accuracy estimate. Source videos overlap between claims.']
    ],'Frozen inputs, parser conditions and review protocol. Original annotations, reserved-source packages and compiler code are preserved.')
    body+='<h3>2. Mechanical coverage across the full inventory</h3>'
    body+=table(['Input condition','Compiled','Compiler rejected','Parser declined','Unexpected errors','Acceptance coverage'],[
        [label,d['statuses'].get('compiled',0),d['statuses'].get('unsupported',0),d['statuses'].get('parser_rejected',0),d['statuses'].get('unexpected_error',0),f'{100*d["statuses"].get("compiled",0)/d["n"]:.2f}%']
        for c,label in (('cached','Stored dataset parses'),('current','Current parser wrapper')) for d in [summary['conditions'][c]]
    ],'Measured execution outcomes for the same 2,375 original claims. Coverage measures emission of a program, not its semantic accuracy.')
    body+=table(['Stored parse accepted?','Current parse accepted?','Claims'],[
        ['Yes' if r['cached_compiled'] else 'No','Yes' if r['current_compiled'] else 'No',r['count']] for r in analysis['acceptance_matrix']
    ],'Paired acceptance comparison. All 76 claims accepted in both conditions have identical literal logical-form strings. This is not an evaluation of an LLM semantic parser.')
    body+='<p><strong>Interpretation — inferred:</strong> these two UD input conditions barely change acceptance. The evidence points toward a restricted semantic representation and rule coverage as the main problem in this comparison. It does not establish that a different semantic parser would be ineffective.</p>'
    body+='<h3>3. First diagnostics and common coverage gaps</h3>'
    diagnoses=current['first_diagnostics']
    body+=table(['First diagnostic','Claims','Share of all claims'],[
        [esc(code),n,f'{100*n/count:.2f}%'] for code,n in sorted(diagnoses.items(),key=lambda x:(-x[1],x[0])) if code!='compiled'
    ],'First recorded rejection guard under the current parser. These categories are mutually exclusive execution outcomes, not a complete linguistic taxonomy: one claim can contain several unsupported constructions.')
    body+='<p>For example, “Commenters ask if anyone is missing, it’s unclear if there are” receives the generic temporal/conditional/causal scope diagnostic. Here “if” introduces a question rather than a conditional. The rejection is conservative, but its diagnostic must not be treated as semantic gold.</p>'
    body+=table(['Additional structural measurement','Observed count','Limit'],[
        ['Unhandled ADP tokens',analysis['unhandled_token_pos'].get('ADP',0),'Token count across unhandled-content cases, not a count of independent location errors.'],
        ['Quantity-guard cases with NUM attached to a PROPN head',analysis['numeric_modifiers_of_proper_names']['count'],'Structural heuristic only. These are not 91 individually confirmed name errors. IM-1 illustrates a verified example in the review.'],
        ['Accepted clauses with a finite tense feature in input',analysis['accepted_finite_tense']['count'],'The current predicate families add no explicit tense/aspect condition. This checks representation, not the media’s temporal understanding.']
    ],'Derived measurements from the saved current outputs. Token counts, structural heuristics and semantic judgments have different meanings.')
    body+='<h3>4. Assistant semantic review</h3><p>Each review compares the claim with its actual output. Core structure means the predicate/argument/modifier reading within the restricted, tense-agnostic fragment. An adequate core does not certify full claim meaning: tense/aspect remain unencoded, and some group/context conventions need definition.</p>'
    body+=table(['Review cohort','Cases','Compiled','Not compiled','Use'],[
        [name,d['n'],d['compiler_statuses'].get('compiled',0),d['n']-d['compiler_statuses'].get('compiled',0),meaning]
        for name,meaning in (('random','Uniform claim sample from the 494 eligible development claims'),('diagnostic','Purposive failure/structure examples; not representative'),('accepted_development','Supplement to cover all remaining accepted development programs'))
        for d in [analysis['semantic_review'][name]]
    ],'Sample cohorts are reported separately. The random sample has one accepted claim and 49 rejections; pooling the cohorts would distort population estimates.')
    accepted=analysis['accepted_development_review']
    body+=table(['Core-structure assessment','Accepted development programs'],[
        [CORE[key],accepted['core_assessments'].get(key,0)] for key in ('adequate_in_restricted_core','incorrect_core','ambiguous_semantic_contract')
    ],'Assistant judgments for all 20 accepted development programs: 11 adequate restricted cores, 2 core errors, 7 unresolved semantic contracts. These are not independent human accuracy labels.')
    flags=analysis['semantic_review']['random']['flags']
    body+=table(['Review flag','Random claims containing flag'],[
        [label,flags.get(key,0)] for key,label in (('location','Location'),('source_content','Source/content relationship'),('quantity','Quantity or measurement'),('temporal','Temporal condition'),('fragment','Sentence fragment'))
    ],'Nonexclusive assistant review flags in the 50-case random sample. These indicate constructions to inspect, not automated gold error classes.')
    body+='<h3>5. Concrete examples</h3><p>Compiler outputs below are measured artifacts. Expected meanings and failure interpretations are assistant judgments, labeled <strong>inferred</strong>. The complete review set and original parses are downloadable.</p>'
    for i in findings['qualitative_review_indices']:
        review=by_index[i];row=outputs[review['claim_id']]
        body+='<div class="stage"><h4>'+esc(review['claim_id'])+'</h4><blockquote>'+esc(review['text'])+'</blockquote>'
        trigger={t['id']:t for t in row['tokens']}
        parse_note='; '.join(trigger[t]['text']+' → '+trigger[t]['deprel'] for t in row.get('token_ids',[]))
        if not parse_note:
            parse_note='; '.join(a['predicate']+' roles: '+', '.join(a['roles']) for a in row.get('atoms',[]) if a['kind'] in {'relation','attribute'})
        body+='<p><strong>Parse/roles:</strong> '+esc(parse_note)+'</p><p><strong>Measured compiler output:</strong> '+esc(row['status'])+'</p>'
        body+=pre(row.get('logical_form',row.get('message','')))
        body+='<p><strong>Expected meaning — inferred:</strong> '+esc(review['expected_meaning'])+'</p><p><strong>Review — inferred:</strong> '+esc(review['judgment'])+'</p></div>'
    body+='<h3>6. Browse all 79 reviews</h3><p>Start with accepted programs to inspect their meaning. The filters also expose rejected and ambiguous input cases.</p><div class="download-row"><label>Compiler result <select data-audit-filter="status"><option value="compiled">Accepted programs (20)</option><option value="all">All cases (79)</option><option value="unsupported">Compiler rejected (58)</option><option value="parser_rejected">Parser declined (1)</option></select></label><label>Review cohort <select data-audit-filter="cohort"><option value="all">All cohorts</option><option value="random">Random sample (50)</option><option value="diagnostic">Diagnostic sample (20)</option><option value="accepted_development">Additional accepted cases (9)</option></select></label></div><p id="audit-review-count" aria-live="polite"></p>'
    for r in reviews:
        row=outputs[r['claim_id']]
        body+='<details class="audit-review" data-audit-status="'+esc(r['observed_status'],quote=True)+'" data-audit-cohort="'+esc(r['sample'],quote=True)+'"><summary>'+str(r['review_index'])+'. '+esc(r['text'])+'</summary><p><strong>'+esc(r['claim_id'])+'</strong> · '+esc(r['sample'])+' · '+esc(row['status'])+'</p><p><strong>Core assessment — inferred:</strong> '+esc(CORE[r['core_assessment']])+'</p><p><strong>Expected meaning:</strong> '+esc(r['expected_meaning'])+'</p><p>'+esc(r['judgment'])+'</p>'
        body+=pre(row.get('logical_form',row.get('message','')))
        body+='<p>Review flags: '+esc(', '.join(r['flags']))+'. These are assistant semantic judgments, not media support labels.</p><details><summary>Exact current parser tokens</summary>'+pre(row['tokens'])+'</details></details>'
    body+='<h3>7. What to change next</h3><p><strong>Failure pattern — inferred:</strong> the main limit is how claim meaning is represented and preserved. Ordinary oblique arguments and fragments are rejected, while a few accepted structures overgeneralize possessives or compound modifiers. Other accepted programs depend on undefined source/content, abstract-entity or idiomatic interpretations. A successful Python call and complete word coverage do not establish a faithful semantic parse.</p>'
    body+=table(['Priority','Recommendation','Success criterion','Evidence'],[
        [r['priority'],esc(r['action']),esc(r['success_criterion']),esc(', '.join(r['addresses']))] for r in findings['recommendations']
    ],'Recommendations for the next semantic-parsing stage. This audit changes no compiler rule and does not claim an improved model result.')
    body+='<details><summary>Evidence tiers and source references</summary>'
    body+=table(['Finding','Evidence status','Statement','Primary evidence'],[
        [r['id'],r['evidence_status'],esc(r['finding']),'<code>'+esc('; '.join(r['evidence']))+'</code>'] for r in findings['findings']
    ],'Measured outcomes, interpretations and unresolved questions are distinguished explicitly.')+'</details>'
    v=analysis['verification']
    body+='<h3>8. Validation and limits</h3><p>The replay checks '+f'{v["compiler_replays"]:,}'+' compiler outcomes against the frozen source and validates '+str(v['recorded_parser_rejections'])+' recorded parser refusals separately. It verifies inventory hashes, unique IDs, exact texts, cached-token conversion, code fingerprints, and exclusion of reserved sources from review. The archived inputs permit compiler replay with Python alone; a fresh Stanza pass is not required.</p><p>No GPU, media inference, factual verification label or classifier training was used. The semantic reviews are authored by the assistant that also worked on the prototype and require independent adjudication before use as a benchmark. The accepted-program review covers development sources only. The two parser conditions have different recorded work: cached timing is compilation only; current timing includes parsing. No training-efficiency comparison is made.</p><p><a href="#next-steps">The audit stage is checked off in the TODO list; semantic parsing and temporal implementation remain next.</a></p></section>'
    return body


AUDIT_SCRIPT='''
const auditFilters=[...document.querySelectorAll('[data-audit-filter]')];
function filterAuditReviews(){if(!auditFilters.length)return;const status=document.querySelector('[data-audit-filter="status"]').value;const cohort=document.querySelector('[data-audit-filter="cohort"]').value;let count=0;document.querySelectorAll('.audit-review').forEach(row=>{const show=(status==='all'||row.dataset.auditStatus===status)&&(cohort==='all'||row.dataset.auditCohort===cohort);row.hidden=!show;if(show)count++;});document.getElementById('audit-review-count').textContent=count+' reviews shown';}
auditFilters.forEach(select=>select.addEventListener('change',filterAuditReviews));filterAuditReviews();
'''


def write_downloads(output):
    target=output.parent/'verification-pipeline/audit';target.mkdir(parents=True,exist_ok=True)
    names=('manifest.json','census_summary.json','analysis.json','findings.json','semantic_reviews.jsonl','review_sample.jsonl','supplemental_sample.jsonl','progress.json','current_parser.json')
    for name in names:shutil.copyfile(RUN/name,target/name)
    reviews=read('semantic_reviews.jsonl');rows={r['claim_id']:r for r in read('current_results.jsonl')}
    (target/'review_records.json').write_text(json.dumps([dict(review=r,compiler_output=rows[r['claim_id']]) for r in reviews],ensure_ascii=False,indent=2)+'\n')
    (target/'current_index.json').write_text(json.dumps([dict(claim_id=r['claim_id'],text=r['text'],status=r['status'],code=r.get('code'),logical_form=r.get('logical_form')) for r in rows.values()],ensure_ascii=False,indent=2)+'\n')
    data_names=names+('inventory.jsonl','cached_parses.jsonl','cached_results.jsonl','current_results.jsonl')
    prefix=RUN.relative_to(ROOT)
    files={str(prefix/name):(RUN/name).read_bytes() for name in data_names}
    for path in (RUN/'frozen_source').rglob('*.py'):files[str(path.relative_to(ROOT))]=path.read_bytes()
    for name in ('run_compilation_audit.py','analyze_compilation_audit.py','build_compilation_audit_report.py'):
        files['scripts/'+name]=(ROOT/'scripts'/name).read_bytes()
    for path in (RUN/'frozen_source/scripts/probabilistic_verification').glob('*.py'):
        files['scripts/probabilistic_verification/'+path.name]=path.read_bytes()
    checklist=ROOT/'exp/probabilistic_verification/av_features_20261022/checklist.json'
    files[str(checklist.relative_to(ROOT))]=checklist.read_bytes()
    files['README.md']=b'Extract into a fresh directory. Run python scripts/analyze_compilation_audit.py to replay the recorded compiler outcomes using frozen input parses and source. This replay needs Python 3.10+ and no model, GPU, Torch, or Stanza installation. It validates recorded parser refusals without rerunning the parser. It also recomputes review counts, which does not independently validate the assistant semantic labels. The original census can be run with scripts/run_compilation_audit.py when the project data and cached Stanza models are available. Reserved-source claims are excluded from qualitative review.\n'
    with zipfile.ZipFile(target/'source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for name,content in sorted(files.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,content)
