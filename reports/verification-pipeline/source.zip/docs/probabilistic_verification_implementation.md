# Tentative claim compiler and DeepProbLog implementation

Implemented 2026-10-22 under ADR-023. This is a runnable prototype and sample
training demonstration, not a validated paper result.

**Update, 2026-10-28:** This document describes the original v1 prototype and
its historical limitations. The new opt-in semantic compiler, explicit
source/content scope and limited executable temporal extension are documented
in [semantic_compiler.md](semantic_compiler.md). The broad frozen 8B parser is
not ready to replace v1; distinguish compiler capability from parser quality.

## Components

- `scripts/probabilistic_verification/representation.py`: typed variables,
  predicates, and logical expressions, with links to source words.
- `compiler.py`: compile a single-sentence Universal Dependencies analysis.
  Semantic roles are explicit ordered arguments. Complete event/participant
  tuples are learned together rather than multiplying separate role scores.
- `parsing.py`: frozen CPU Stanza parser using existing project model files.
- `logic.py`: bounded candidate assignment, canonical observation identity,
  explicit supported/refuted/unknown rules, and executable ProbLog generation.
- `backend.py`: actual DeepProbLog 2.0.6 exact inference and native training loop;
  the original score-calibration demonstration uses a 64-hidden-unit residual MLP
  with six score features and three outputs. New media-conditioned features are
  extracted separately; no new feature classifier is trained yet.
- `scripts/run_verification_pipeline.py`: reproducible real-media and controlled
  examples, automatic parsing checks, inference, and sample claim-label training.
- `scripts/build_verification_pipeline_report.py`: diagrams, tables, exact
  programs, training results, and downloadable source/cached inputs.

## Run

The isolated project environment is `envs/probabilistic-verification`; it reuses
the existing PyTorch installation. Dependencies are pinned in
`requirements-verification.txt`. No GPU is required.

```bash
envs/probabilistic-verification/bin/python scripts/compile_verification_claim.py --text "The aircraft is gray." --output /tmp/claim.json
PYTHONPATH=scripts envs/probabilistic-verification/bin/python -m pytest tests/test_probabilistic_verification.py -q --junitxml=exp/probabilistic_verification/compiler_20261022/tests.xml
PYTHONPATH=scripts envs/probabilistic-verification/bin/python scripts/run_verification_pipeline.py
envs/probabilistic-verification/bin/python scripts/build_verification_pipeline_report.py
```

The first run extracts six actual saved observations from the October 15 pilot
and parses the demonstration sentences with cached Stanza models. Later runs
reuse `perception_cache.json` and `parses.json`. In the downloadable source ZIP,
these inputs are in `demo/`; run `PYTHONPATH=scripts python
scripts/run_verification_pipeline.py --run-dir demo` to replay without model
downloads or a GPU.

The standalone compiler accepts `--ud-json` with an existing list of UD word
records, so another parser can supply its input without importing Stanza. It emits
the full logical form, predicates, typed variables, source-word coverage, and
original parse. Unsupported claims produce JSON diagnostics and exit status 2.

## Semantics and boundaries

The compiler covers simple active/passive clauses, local attributes, explicit
and/or coordination, repeated named participants, possessives, and restricted
negation. Every input word is recorded as represented or an explicit functional
word. Unhandled constructions return a diagnostic; no partial claim is accepted.
Quantifiers/counts, unresolved pronouns, temporal/causal clauses, reporting and
intention scope, and negative indefinite arguments are outside the initial fragment.

This first compiler consumes the raw UD analysis and keeps word spans. It derives
basic participant roles using dependency rules, as the earlier semantic compiler
does. The old LLM adjunct-role pass is not called for this small fragment; richer
adjuncts remain unsupported. Earlier temporal-to-na filters and fixed tree-CRF
composition are not copied into the new logical representation.

Entity variables are bound where their uses meet, preserving branch-local
references in disjunctions. Event existence remains inside clause negation.
Complete relation tuples share one event argument; the controlled example tests
that Alice and Dave cannot select participants from different hugging events.

Each canonical observation has one categorical S/R/U state. Required conjunction
is refuted if any child is refuted, supported if all are supported, and unknown
otherwise. Negation exchanges supported/refuted and preserves unknown. An
existential assignment is supported if one candidate supports it; all candidates
being refuted establishes refutation only when the declared inventory is complete.
Missing observations are unknown. Candidate expansion is explicitly bounded.

The real-media example declares complete reference resolution only for its two
manually specified depicted referents. This is not complete coverage of all events
or objects in the source video. The controlled inventory is explicitly complete.

Canonical duplicates share one random variable. Other cached questions are
modeled as independent categorical observations; dependence between different
questions to the same backbone is not estimated. Normalization is not calibration.

## Learning and numerical handling

The initial MLP mainly learns score calibration: its inputs are frozen S/R/U scores
and their logarithms, with no example IDs or target labels. Its output is a residual
adjustment to the frozen log probabilities. Entity observations and logic remain
fixed. DeepProbLog's native loop optimizes the negative log probability of the
reference root state. Two real-media development claims provide the training
labels; no local labels are passed to the learner, and no held-out accuracy is claimed.

DeepProbLog 2.0.6 uses tolerant `is_zero`/`is_one` checks, which can discard small
probability outcomes near 0 or 1. The backend supplies a local graph-semiring
subclass whose only simplification identities are exact float constants. Tensors
remain connected to autograd. Double precision and a high-confidence regression
case verify probability conservation without output renormalization.

The current automatic Stanza pass rejects three intended supported regression
sentences because it parses "waves" as a noun. These remain visible failures of
the automatic pipeline. Hand-specified UD semantic tests separately verify shared
subjects and reference scope; these tests are not claims of automatic parser accuracy.

## Artifacts

`exp/probabilistic_verification/compiler_20261022/` contains raw cached
observations and request hashes, dependency parses, compiler checks, all inference
traces, fixed/learned/controlled Prolog programs, classifier weights, training
history and gradient checks, test XML, exact package versions, and code hashes.

`site/reports/verification-pipeline.html` is the report. Its downloadable source
bundle includes the compiler, runner, tests, requirements, and cached inputs.


## Frozen visual/audio feature pilot and two evidence trees

The second October 22 pilot lives in
`exp/probabilistic_verification/av_features_20261022/`. It checks frozen neural
representations and source separation before preparing larger training data.
`run_av_features.py` extracts the final prompt-token decoder representation from
Qwen3-VL-8B and the Qwen3-Omni-30B thinker. Each representation is conditioned on
one complete proposition and its actual media, before any answer is generated.
The model parameters stay frozen. No paired claim or reference label is supplied.
All prompts live in `scripts/prompts_phase2.py`.

The four conditions are matched media, another clip, blank media of identical
shape/duration, and text alone. Matched/blank keep the exact prompt and token IDs;
text alone removes placeholders and therefore is a less closely matched control.
These checks can show media sensitivity but cannot establish that a classifier
will generalize. Features are global clip/proposition representations, not object
boxes or speaker tracks. Alternative real candidate assignments remain later work.

`multimodal.py` creates separate visual and audio copies of the compiled claim.
They must share the same candidate IDs and inventory completeness declarations.
An explicit per-predicate policy excludes ineligible sources as unknown, retaining
raw scores for inspection. Evidence for the same grounded predicate combines
before claim logic: unknown contributes no evidence, agreement keeps that state,
and support/refutation disagreement becomes unknown with a conflict diagnostic.
This rule applies only to observations of the same proposition; it does not turn
speech assertions into depicted events. The current demonstration routes color
properties to depiction and music properties to non-speech sound.

The `evidence` expression is a fixed two-input operation compiled into an explicit
three-state truth table in ProbLog. `tests/test_multimodal_verification.py` checks
complementary evidence, conflicts, source exclusion, and shared candidate identity.
Claims involving “mention” are now rejected with the other source/content scope
constructions: the earlier generic event rule would incorrectly introduce a
physical-presence requirement for the mentioned place. Exact spoken-content and
assertion-scope semantics need an explicit extension.

`analyze_av_features.py` checks feature shapes and finite values, computes feature
control diagnostics, compiles the reviewed claims, and runs actual DeepProbLog
inference. It checks every root against independent enumeration. Reference labels
are stored separately in `reviewed_claims.json`; they are used for review, never
in feature extraction, source policy selection, or inference. Audio annotations
are model-assisted and provisional because the available assistant interface
cannot directly listen to the waveform. The exact WAV is published for review.

The report adds **Visual and audio** and **Next steps** tabs. Its new source archive
includes cached parses, scores, joint vectors, and the analysis script, allowing
CPU replay without model downloads. Full audio encoder token sequences stay in
the project run directory; they are not needed for this replay.

## Plain-language compilation walkthrough — 2026-10-28

The implementation report's **Compilation walkthrough** tab (`#compilation-guide`)
explains the fixed UD rules, predicate families, ordered roles, entity/event scope,
three-state logic, bounded candidate expansion, canonical observation reuse, and
source combination. `scripts/build_compilation_guide.py` builds this tab through
the main report generator, rerunning eight compiler examples and eight rejection
cases. Automatic cached parses and hand-specified OR/shared-name parses are labeled
separately. The guide includes source excerpts, a complete generated ProbLog program,
and `site/reports/verification-pipeline/compilation_guide.json` with exact inputs and
outputs. Its generator is included in the report's source ZIP. This documentation
update changes no compiler semantics and adds no measured accuracy result.


## Current priorities and temporal limitation — 2026-10-28

The user accepted compiler fidelity as the next priority, before feature expansion
or classifier training. The Next steps checklist now starts with a real-claim
baseline audit, a semantic parsing comparison including tense/aspect, and contrastive
compiler tests. The earlier visual/audio feature and tree pilot remains completed
preliminary work; its outstanding checks are retained.

The unchanged compiler was run on six new sentences using the cached Stanza models.
Exact inputs and outputs are in
`exp/probabilistic_verification/temporal_audit_20261028/current_behavior.json`.
“The spacecraft landed,” “is landing,” “was landing,” and “has landed” all compile
to the same entity/event/land predicates. Word-level morphology remains in the
saved parse, but it does not affect logical inference or canonical observation
identity. Both exact Apollo 11/on-the-moon examples are rejected because the numeral
in the name triggers the generic nummod/counting guard. Location support also
requires an extension. No compiler behavior changed during this diagnostic.

A planned extension must preserve tense, aspect and a context-dependent reference
time, use the full auxiliary sequence, and propagate those distinctions into
executable conditions and evidence scoring. Simple past is not a general completion
operator; completion of the affirmative landing example also depends on event
meaning. Progressive landing evidence does not establish touchdown. Historical
footage can supply a narrative reference time distinct from the present date.
These requirements are not implemented. They are separate from selecting a media
window for a candidate event. The report labels measured behavior and proposed
requirements separately and provides the exact diagnostic JSON for review.


## Real-claim baseline audit — 2026-10-28

`run_compilation_audit.py` freezes the current 2,375-claim inventory and unchanged
compiler source. It runs both exact-text-matched stored UD records and fresh parses
from the current Stanza wrapper. Legacy conversion changes ID conventions and
omits seven whitespace-only SpaCy records without changing lexical dependencies.
The primary current pipeline compiles 78 claims, rejects 2,268 at compilation, and
declines 29 multi-sentence inputs at parsing. The stored parse condition compiles
79. These are program-emission counts, not semantic or media-verification accuracy.

`analyze_compilation_audit.py` replays the frozen compiler outputs, checks source
and inventory fingerprints and sample invariants, and summarizes independently
stored assistant reviews. A 50-case random development sample, 20 diagnostics and
9 supplemental accepted cases give 79 reviewed cases and cover all 20 accepted
development programs. Core judgments remain separate from temporal completeness
and unresolved source/type contracts. They are not independent human gold.

The report's Real-claim audit tab includes measured census/diagnostics, qualitative
traces, filters over all reviews, explicit evidence tiers and recommendations.
The Next steps checklist records the audit as complete; semantic parsing and
contrastive testing remain pending. The downloadable audit archive can replay
compiler outcomes with Python alone from saved parses. It validates recorded
parser refusals without rerunning the parser. New semantic parsers and compiler
fixes must use a new run/version so this baseline remains available.
