"""Semantic regression cases and an independent probability/gradient check."""
import itertools
import math

import pytest

from probabilistic_verification import ClaimCompiler, CompilationError
from probabilistic_verification.logic import (Evidence, GroundProgram, Observation, canonical_key,
                                             combine_states, enumerate_probability, ground)
from probabilistic_verification.representation import Expression as E, STATES


def ud(rows):
    return [dict(id=i, text=text, lemma=lemma, upos=upos, head=head, deprel=dep,
                 start_char=0, end_char=len(text))
            for i, (text, lemma, upos, head, dep) in enumerate(rows, 1)]


ACTIVE = ud([("Alice", "Alice", "PROPN", 2, "nsubj"), ("hugs", "hug", "VERB", 0, "root"),
             ("Bob", "Bob", "PROPN", 2, "obj")])
PASSIVE = ud([("Bob", "Bob", "PROPN", 3, "nsubj:pass"), ("is", "be", "AUX", 3, "aux:pass"),
              ("hugged", "hug", "VERB", 0, "root"), ("by", "by", "ADP", 5, "case"),
              ("Alice", "Alice", "PROPN", 3, "obl:agent")])


def semantic_signature(claim):
    names = {v.name: v.description.lower() for v in claim.variables}
    return sorted((a.predicate, tuple(names.get(x, x) if not x.startswith("E") else "event" for x in a.arguments), a.roles)
                  for a in claim.atoms)


def test_active_and_passive_preserve_roles():
    a = ClaimCompiler().compile("active", "Alice hugs Bob.", ACTIVE)
    b = ClaimCompiler().compile("passive", "Bob is hugged by Alice.", PASSIVE)
    assert semantic_signature(a) == semantic_signature(b)
    relation = next(x for x in a.atoms if x.kind == "relation")
    assert relation.roles == ("event", "agent", "theme")


def test_shared_subject_across_coordinated_events():
    rows = ACTIVE + ud([])
    rows += [dict(id=4, text="and", lemma="and", upos="CCONJ", head=5, deprel="cc"),
             dict(id=5, text="waves", lemma="wave", upos="VERB", head=2, deprel="conj")]
    c = ClaimCompiler().compile("shared", "Alice hugs Bob and waves.", rows)
    assert len([v for v in c.variables if v.kind == "entity"]) == 2
    relations = [a for a in c.atoms if a.kind == "relation"]
    assert relations[0].arguments[1] == relations[1].arguments[1]
    assert len({a.arguments[0] for a in relations}) == 2


def test_negation_has_scope_over_event_existence():
    rows = [dict(t) for t in ACTIVE]
    rows.append(dict(id=4, text="not", lemma="not", upos="PART", head=2, deprel="advmod"))
    claim = ClaimCompiler().compile("negative", "Alice does not hug Bob.", rows)
    def find(expr):
        return [expr] + [n for c in expr.children for n in find(c)]
    neg = next(n for n in find(claim.expression) if n.op == "not")
    assert neg.children[0].op == "exists"
    assert neg.children[0].variables == ("E1",)


@pytest.mark.parametrize("word,upos,dep", [("all", "DET", "det"), ("two", "NUM", "nummod"),
                                        ("before", "SCONJ", "mark"), ("quickly", "ADV", "advmod")])
def test_unhandled_semantics_are_rejected(word, upos, dep):
    rows = [dict(t) for t in ACTIVE] + [dict(id=4, text=word, lemma=word, upos=upos, head=2, deprel=dep)]
    with pytest.raises(CompilationError):
        ClaimCompiler().compile("unsupported", "Alice hugs Bob " + word, rows)


def test_pronouns_do_not_get_independent_invented_referents():
    rows = [dict(t) for t in ACTIVE]
    rows[0].update(text="She", lemma="she", upos="PRON")
    with pytest.raises(CompilationError, match="pronoun"):
        ClaimCompiler().compile("pronoun", "She hugs Bob.", rows)


def toy(expr, observations):
    return GroundProgram("toy", expr, {o.id: o for o in observations}, [], [])


@pytest.mark.parametrize("op", ["and", "or", "not"])
def test_exact_backend_matches_independent_world_enumeration(op):
    from probabilistic_verification.backend import DeepProbLogVerifier
    a = Observation("a", (0.7, 0.2, 0.1), False, "a")
    b = Observation("b", (0.2, 0.5, 0.3), False, "b")
    expr = E.negate(E.atom(a.id)) if op == "not" else E.combine(op, [E.atom(a.id), E.atom(b.id)])
    p = toy(expr, [a] if op == "not" else [a, b])
    actual = DeepProbLogVerifier([p], learned=False).predict()[0]["distribution"]
    assert actual == pytest.approx(enumerate_probability(p), abs=1e-7)


def test_duplicate_fact_does_not_square_its_probability():
    from probabilistic_verification.backend import DeepProbLogVerifier
    a = Observation("a", (0.7, 0.2, 0.1), False, "a")
    # Keep a duplicate in the expression deliberately, bypassing simplification.
    p = toy(E("and", (E.atom(a.id), E.atom(a.id))), [a])
    assert DeepProbLogVerifier([p], learned=False).predict()[0]["distribution"]["supported"] == pytest.approx(0.7)


def test_shared_facts_across_alternative_proofs_are_not_independent():
    from probabilistic_verification.backend import DeepProbLogVerifier
    a = Observation("a", (0.7, 0.2, 0.1), False, "shared participant")
    b = Observation("b", (0.2, 0.5, 0.3), False, "event one")
    c = Observation("c", (0.4, 0.4, 0.2), False, "event two")
    expr = E.combine("or", [E.combine("and", [E.atom(a.id), E.atom(b.id)]),
                            E.combine("and", [E.atom(a.id), E.atom(c.id)])])
    p = toy(expr, [a, b, c])
    actual = DeepProbLogVerifier([p], learned=False).predict()[0]["distribution"]
    assert actual == pytest.approx(enumerate_probability(p), abs=1e-7)
    assert actual["supported"] == pytest.approx(.7 * (.2 + .4 - .2 * .4))


def test_high_confidence_scores_preserve_small_outcomes_and_total_mass():
    from probabilistic_verification.backend import DeepProbLogVerifier
    a = Observation("confident_a", (.999997, .00000002, .00000298), False, "a")
    b = Observation("confident_b", (.9999998, .00000003, .00000017), False, "b")
    p = toy(E.combine("and", [E.atom(a.id), E.atom(b.id)]), [a, b])
    actual = DeepProbLogVerifier([p], learned=False).predict()[0]["distribution"]
    expected = enumerate_probability(p)
    for state in STATES:
        assert actual[state] == pytest.approx(expected[state], abs=1e-12)
    assert sum(actual.values()) == pytest.approx(1., abs=1e-12)


def test_disjunction_does_not_require_a_referent_for_the_other_branch():
    rows = [dict(t) for t in ACTIVE]
    rows += [dict(id=4, text="or", lemma="or", upos="CCONJ", head=6, deprel="cc"),
             dict(id=5, text="Carol", lemma="Carol", upos="PROPN", head=6, deprel="nsubj"),
             dict(id=6, text="runs", lemma="run", upos="VERB", head=2, deprel="conj")]
    claim = ClaimCompiler().compile("or", "Alice hugs Bob or Carol runs.", rows)
    assert claim.expression.op == "or"
    assert all(c.op == "exists" for c in claim.expression.children)


def test_candidate_expansion_limit_is_explicit():
    claim = ClaimCompiler().compile("bounded", "Alice hugs Bob.", ACTIVE)
    evidence = Evidence("clip", {v.name: ["one", "two"] for v in claim.variables}, {}, {})
    with pytest.raises(ValueError, match="limit"):
        ground(claim, evidence, max_expansions=1)


def test_complete_relation_candidates_cannot_mix_two_events():
    from probabilistic_verification.backend import DeepProbLogVerifier
    from run_verification_pipeline import controlled_evidence
    tokens = [dict(t) for t in ACTIVE]
    tokens[2].update(text="Dave", lemma="Dave")
    claim = ClaimCompiler().compile("cross_event", "Alice hugs Dave.", tokens)
    program = ground(claim, controlled_evidence(claim))
    expected = enumerate_probability(program)
    actual = DeepProbLogVerifier([program], learned=False).predict()[0]["distribution"]
    assert actual == pytest.approx(expected, abs=1e-12)
    assert actual["refuted"] > .9
    assert actual["supported"] < .02


def test_negative_event_query_requires_no_matching_witness():
    from probabilistic_verification.backend import DeepProbLogVerifier
    from run_verification_pipeline import controlled_evidence
    tokens = [dict(t) for t in ACTIVE]
    tokens.append(dict(id=4, text="not", lemma="not", upos="PART", head=2, deprel="advmod"))
    claim = ClaimCompiler().compile("negative_witness", "Alice does not hug Bob.", tokens)
    program = ground(claim, controlled_evidence(claim))
    actual = DeepProbLogVerifier([program], learned=False).predict()[0]["distribution"]
    # The unrelated second hug does not provide a witness for this negated claim.
    assert actual == pytest.approx(enumerate_probability(program), abs=1e-12)
    assert actual["refuted"] > .93


@pytest.mark.parametrize("state", STATES)
def test_empty_incomplete_inventory_is_unknown(state):
    claim = ClaimCompiler().compile("missing", "Alice hugs Bob.", ACTIVE)
    p = ground(claim, Evidence("missing", {}, {}, {}))
    assert enumerate_probability(p)[state] == (1. if state == "unknown" else 0.)


def test_incomplete_inventory_does_not_turn_no_witness_into_refutation():
    from probabilistic_verification.representation import Atom, CompiledClaim, Variable
    a = Atom("a", "hug", ("E1",), "relation", ("event",), "hug", (1,), True)
    claim = CompiledClaim("coverage", "hug", (), (Variable("E1", "event", "hug", (1,)),),
                          (a,), E.exists(["E1"], E.atom("a")), ())
    assignment = {"E1": "event_one"}
    key = canonical_key("clip", a, assignment, "visual_depiction")
    obs = Observation(key, (0., 1., 0.), False, "not this event")
    evidence = Evidence("clip", {"E1": ["event_one"]}, {"E1": False}, {key: obs})
    assert enumerate_probability(ground(claim, evidence)) == {"supported": 0., "refuted": 0., "unknown": 1.}
    evidence.complete["E1"] = True
    assert enumerate_probability(ground(claim, evidence))["refuted"] == 1.


def test_native_training_reaches_classifier_and_leaves_fixed_evidence_unchanged():
    from probabilistic_verification.backend import DeepProbLogVerifier
    obs = Observation("train", (0.55, 0.1, 0.35), True, "relation")
    fixed = Observation("fixed", (0.95, 0.02, 0.03), False, "entity")
    p = toy(E.combine("and", [E.atom(obs.id), E.atom(fixed.id)]), [obs, fixed])
    verifier = DeepProbLogVerifier([p])
    before = verifier.predict()[0]["distribution"]["refuted"]
    training = verifier.fit({"toy": "refuted"}, epochs=3)
    after = verifier.predict()[0]["distribution"]["refuted"]
    assert after > before
    assert training["parameter_change_l2"] > 0
    assert all(g["finite"] for g in training["gradient_checks"])
    assert any(g["norm"] > 0 for g in training["gradient_checks"])
    assert verifier.local_predictions()[fixed.id] == list(fixed.distribution)
