#!/usr/bin/env python3
"""Compile an original claim from a supplied logical form, AMR or SRL record."""
import argparse
import json
from pathlib import Path
from probabilistic_verification.logical_form import LogicalFormCompiler
from probabilistic_verification.logical_form_adapters import amr_form,srl_form


def main():
    p=argparse.ArgumentParser(__doc__);p.add_argument('--record',type=Path,required=True)
    group=p.add_mutually_exclusive_group();group.add_argument('--logical-form',type=Path);group.add_argument('--amr',type=Path)
    p.add_argument('--output',type=Path);args=p.parse_args();record=json.loads(args.record.read_text())
    try:
        form=json.loads(args.logical_form.read_text()) if args.logical_form else amr_form(args.amr.read_text(),record['text']) if args.amr else srl_form(record)
        result=LogicalFormCompiler().compile(record['claim_id'],record['text'],record['tokens'],form).to_dict()
    except Exception as error:
        result=dict(status='unsupported',code=getattr(error,'code',type(error).__name__),message=str(error),claim_id=record.get('claim_id'))
    output=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.output:args.output.write_text(output)
    else:print(output,end='')

if __name__=='__main__':main()
