"""Current logical-form implementation, definitions and frozen evaluation."""
from html import escape as esc
import json
from pathlib import Path
import shutil
import zipfile
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/logical_form_20261028'
PREFIX='verification-pipeline/logical-form/'


def load(name):return json.loads((RUN/name).read_text())
def read(name):return [json.loads(s) for s in (RUN/name).read_text().splitlines()]
def pre(x):return '<pre>'+esc(x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,indent=2))+'</pre>'


def build_update(table,figure,svg_dot,q):
    s=load('summary_with_selection.json');final=load('final_holdout_summary.json');quality=load('final_quality_review.json')
    body='<div id="logical-form-update"><h3>Current implementation: logical forms and compiler interfaces</h3>'
    body+='<p><strong>Decision:</strong> proceed with the accepted compilation choices. LLM sentence rewriting is reserved as a last resort and <strong>has not been implemented</strong>. All experiments below parse the original claim. Further media verification and relation-model training remain deferred.</p>'
    body+='<p><strong>Current assessment:</strong> keep this compiler opt-in. The shared representation, recursive source content and new structural checks are implemented. Development requirements improve, but the fresh source check still exposes incorrect accepted translations and underspecified fragments. Executable output is not a certificate of preserved meaning.</p>'
    body+='<h4>What representation and interface mean</h4><p>A <strong>representation</strong> here is the claim’s structured meaning, usually called a <strong>logical form</strong>: predicates, their arguments, shared referents, operators and source scopes. It is not a neural feature vector. For “Alice hugs Bob and waves,” it records two events joined by AND, the same Alice in both events, and Bob in the hug. JSON and PENMAN are ways to write a structure; the notation alone does not define its meaning.</p>'
    body+='<p>An <strong>interface</strong> specifies a component’s inputs, outputs and their meanings. Every parser can supply the same logical-form format; the compiler turns it into variables, predicates and a DeepProbLog program. The later evidence-scoring interface will specify the relation, candidate evidence, route and features given to a scorer, and the meanings of its supported/refuted/unknown probabilities. Fixed rules and learned classifiers can use that same interface.</p>'
    body+='<div class="download-row">'+''.join('<a href="'+PREFIX+n+'">'+label+'</a>' for n,label in [('source.zip','Source and CPU replay'),('interface.md','Logical-form interface'),('summary_with_selection.json','Development counts'),('reference_requirements.json','46 reference cases'),('results.jsonl','All development outputs'),('final_holdout_results.jsonl','Fresh source outputs'),('final_quality_review.json','Fresh source quality review'),('tests.xml','Regression checks')])+'</div>'
    body+=table(['Implemented component','What it does','Limit'],[
        ['Common JSON logical form','Entities, predicate arguments, AND/OR/NOT, nested source content, anchors and known senses','The format is fixed; the parser can still assign the wrong meaning.'],
        ['Source-content compilation','Every content condition carries its source-event variable and route','Cross-scope reference interpretations and some reporting verbs remain unsupported.'],
        ['SRL adapter','Reads trained predicate/argument spans, exposes simple modifiers and aligns shared noun-phrase heads','Complex phrases remain explicitly partial; SRL is not a full claim parser.'],
        ['AMR adapter','Preserves known senses, entity relations and nominal parents with attached event/state modifiers','Lexical errors, nonveridical scope and nominal media descriptions remain difficult.'],
        ['Neural logical-form generation','The frozen 8B model emits a recursive clause tree in JSON, with or without trained SRL','One generation per claim, not an implementation of the multi-call CLOVER or NL2LOGIC systems.'],
        ['Temporal fields','One event/tense/aspect/context/completion structure, with scope/route information','No video time localization; source-relative temporal semantics remain limited.'],
        ['Parser selection','Prefer SRL without opaque phrases, then AMR, then partial SRL','This fixed policy uses no reference judgments, but does not establish faithful complete-claim coverage.']
    ],'Current implementation and explicit limits. An opaque phrase preserves words without separately representing all of their internal relationships.')
    body+='<h4>One original claim through the interface</h4>'
    example=next(r for r in read('results.jsonl') if r['method']=='srl' and r['claim_id']=='contrast_16')
    body+='<blockquote>'+esc(example['text'])+'</blockquote><p>The source’s saying event stays outside negation. Landing and its negation are inside speech-content scope. The full auxiliary sequence supplies present/perfect for “has not landed.”</p>'
    body+='<details><summary>Logical-form JSON</summary>'+pre(example['proposal'])+'</details>'
    body+=figure(svg_dot([
        'a [label="Original claim\nThe narrator says the spacecraft has not landed."];',
        'b [label="Source event: say\nsource participant: narrator",fillcolor="#dcece4"];',
        'c [label="Speech content\nNOT (landing event with spacecraft)",fillcolor="#f4e9cc"];',
        'd [label="Source-aligned tense/aspect\nsay: present/simple\nland: present/perfect"];',
        'e [label="Deterministic compiler\nshared source identity + explicit negation scope"];',
        'f [label="Generated DeepProbLog predicates\ncompilation check, no media verdict"];',
        'a -> b; b -> c [label="speech_assertion"]; a -> d; c -> e; d -> e; e -> f;'
    ],'Source scope and temporal fields in the current logical-form compiler'),
        'E1 in the full program denotes the saying event; E2 denotes the landing event; X variables denote participants; T0 identifies a caller-supplied reference context. These are logical variables, not probabilities.')
    body+='<details><summary>Compiled logical form and generated program</summary>'+pre(example['compilation']['logical_form'])+pre(example['program'])+'</details>'
    body+='<h4>Development results: stated requirements, not semantic accuracy</h4><p>The assistant-authored references cover 25 real diagnostic claims and 21 controls. Five uncertain lexical/noun-phrase readings are excluded from definite diagnostic counts, leaving 21 real cases and 20 controls. Checks cover specified roles, attachment, polarity, source scope and time; they do not prove full semantic equivalence. The 20 controls include three intended refusals for counting, modality and unresolved reference.</p>'
    names={'srl':'Trained SRL + rules','amr':'Pretrained AMR + post-processing','direct':'Frozen 8B → JSON logical form','assisted':'SRL-assisted frozen 8B → JSON logical form','selected':'Fixed SRL/AMR selection policy'}
    body+=table(['Route','Compiled / 79 real','Compiled / 21 controls','Specified checks: real','Specified checks: controls'],[
        [names[m],str(v['real']['compiled'])+'/79',str(v['controls']['compiled'])+'/21',str(v['real']['diagnostic_requirements_pass'])+'/21',str(v['controls']['diagnostic_requirements_pass'])+'/20'] for m,v in s['methods'].items()
    ],'Compilation and assistant-authored diagnostic requirements are different measurements. The selection policy reuses existing parses; it makes no extra model call.')
    body+='<h4>Frozen checks on new source videos</h4><p>The first 20 source-disjoint cases exposed overlapping-mention identity and omitted-parent bugs. Their frozen results remain archived. After those cases informed fixes, they became development diagnostics. The revised compiler and prompts were frozen again before a fresh ten-source check. All sources are disjoint from the original 79 claims and from each other across these sets; reserved evaluation videos were not used.</p>'
    body+=table(['Route','First frozen 20-source check','Fresh frozen ten-source check'],[
        [names[m],str(load('first_iteration/holdout_summary.json')['methods'][m]['compiled'])+'/20',str(final['methods'][m]['compiled'])+'/10'] for m in ['srl','amr','direct','selected']
    ],'Compiled programs only. The first set informed fixes and is no longer independent of the revised compiler. No compiler/prompt tuning followed the fresh check.')
    body+='<p><strong>Eight compiled out of ten is not 80% semantic accuracy.</strong> The qualitative review below found a preserved basic shared-participant example, partial translations, incorrect scope, context-dependent fragments and refusals. These are assistant judgments, not independent human gold labels.</p>'
    body+=table(['Original claim','Review judgment','What the output preserves or misses'],[[esc(r['text']),esc(r['judgment'].replace('_',' ')),esc(r['note'])] for r in quality['cases']],
                'Review of all ten fresh cases under the fixed selection policy. Incorrect accepted translations remain visible.')
    body+='<details><summary>Inspect every fresh selected logical form</summary>'
    for row in read('final_holdout_results.jsonl'):
        if row['method']!='selected':continue
        body+='<h5>'+esc(row['text'])+'</h5>'+pre(row.get('compilation',{}).get('logical_form',row.get('code','unsupported')))
    body+='</details><h4>What remains before default use</h4><ul><li>Require complete coverage of the original claim, including nominal media/source descriptions.</li><li>Preserve criticism, purpose and other embedded scopes without independently asserting their contents.</li><li>Define how bare names, labels, omitted subjects and unspecified measurements obtain their intended claim context.</li><li>Extend noun-phrase, shared-reference and lexical interpretation checks; then run another frozen source evaluation.</li></ul>'
    body+='<p>The rewrite fallback remains reserved. A later rewrite would need to preserve roles, names, quantities, modifiers, negation, modality, tense, reference and source scope. Rephrasing cannot supply missing context without adding information. No rewriting function, prompt or fallback call is implemented.</p>'
    body+='<p>Validation: '+str(s['tests']['tests'])+' regression checks pass, including actual DeepProbLog execution with artificial unknown inputs for local negation and nested source content. All development outputs can be replayed on CPU. No media verification or new relation model was trained. See the <a href="#next-steps">updated checklist</a>.</p></div>'
    return body


def write_downloads(output):
    folder=output.parent/'verification-pipeline/logical-form';folder.mkdir(exist_ok=True,parents=True)
    data=['inputs.jsonl','reference_requirements.json','summary_with_selection.json','results.jsonl','selected_results.jsonl','tests.xml',
          'frozen_manifest.json','resource_usage.json','holdout_inputs.jsonl','holdout_requirements.json','holdout_selection.json',
          'final_holdout_inputs.jsonl','final_holdout_selection.json','final_holdout_results.jsonl','final_holdout_summary.json','final_quality_review.json',
          'reviewed_source_results.jsonl','reviewed_source_summary.json']
    data += [f'{m}_{i}_raw.jsonl' for m in ['direct','assisted'] for i in [0,1]]
    data += [f'{p}_{m}_raw.jsonl' for p in ['holdout','final_holdout'] for m in ['amr','direct']]
    data += ['first_iteration/holdout_summary.json','first_iteration/holdout_results.jsonl','first_iteration/frozen_manifest.json']
    for name in data:
        target=folder/name;target.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(RUN/name,target)
    shutil.copyfile(ROOT/'docs/logical_form_interface.md',folder/'interface.md')
    files=list((ROOT/'scripts/probabilistic_verification').glob('*.py'))
    files += [ROOT/'scripts'/n for n in ['prompts_phase2.py','analyze_logical_forms.py','summarize_logical_form_iteration.py','evaluate_logical_form_holdout.py',
        'run_logical_form_models.py','run_logical_form_models.slurm','run_compilation_models.py','build_logical_form_references.py',
        'compile_logical_form.py','compile_verification_claim.py','run_verification_pipeline.py','replay_logical_form_iteration.py','build_logical_form_update.py']]
    files += list((ROOT/'tests/fixtures').glob('*.json'))
    files += [ROOT/'tests'/n for n in ['test_logical_form.py','test_probabilistic_verification.py','test_multimodal_verification.py','test_semantic_compiler.py','test_predicate_compilation.py']]
    files += [ROOT/'requirements-compilation.txt',ROOT/'requirements-verification.txt',ROOT/'docs/logical_form_interface.md',ROOT/'docs/compilation_methods.md']
    files += [RUN/n for n in data]
    files += list((RUN/'frozen_source').rglob('*.py'))+list((RUN/'first_iteration/frozen_source').rglob('*.py'))
    baseline=ROOT/'exp/probabilistic_verification/compilation_methods_20261028/amr_raw.jsonl';files.append(baseline)
    contents={str(p.relative_to(ROOT)):p.read_bytes() for p in files}
    contents['README.md']=b'Install requirements-compilation.txt and the NLTK wordnet corpus (python -m nltk.downloader wordnet). Run PYTHONPATH=scripts python scripts/replay_logical_form_iteration.py to reproduce cached compilation without model loading, media, or training. See docs/logical_form_interface.md. LLM sentence rewriting is not implemented.\n'
    with zipfile.ZipFile(folder/'source.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,content in sorted(contents.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,content)
