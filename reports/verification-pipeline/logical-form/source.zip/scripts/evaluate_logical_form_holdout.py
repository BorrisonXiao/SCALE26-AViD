#!/usr/bin/env python3
"""Compilation-only check on source-disjoint original claims after code freeze."""
import argparse
from collections import Counter
import hashlib
import json
import logging
from pathlib import Path
from probabilistic_verification.logical_form import LogicalFormCompiler
from probabilistic_verification.logical_form_adapters import amr_form,srl_form
from probabilistic_verification.compilation_selection import select_attempt
from analyze_logical_forms import strict_json,read
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/logical_form_20261028'


def main():
    parser=argparse.ArgumentParser(__doc__);parser.add_argument('--sample',choices=['reviewed','final'],default='final');args=parser.parse_args()
    prefix='final_holdout' if args.sample=='final' else 'holdout'
    output_prefix='final_holdout' if args.sample=='final' else 'reviewed_source'
    logging.getLogger('penman').setLevel(logging.ERROR)
    manifest=json.loads((RUN/'frozen_manifest.json').read_text())
    for path,sha in manifest['files'].items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==sha,path
    records=read(RUN/(prefix+'_inputs.jsonl'))
    raw={m:{r['request']['task']['claim_id']:r for r in read(RUN/f'{prefix}_{m}_raw.jsonl')} for m in ['amr','direct']}
    assert all(len(d)==len(records) for d in raw.values())
    result=[]
    for record in records:
        attempts={}
        for method in ['srl','amr','direct']:
            row=dict(claim_id=record['claim_id'],text=record['text'],source_videos=record['source_videos'],method=method,status='unsupported')
            try:
                form=srl_form(record) if method=='srl' else amr_form(raw[method][record['claim_id']]['raw'],record['text']) if method=='amr' else strict_json(raw[method][record['claim_id']]['raw'])
                c=LogicalFormCompiler().compile(record['claim_id'],record['text'],record['tokens'],form)
                row.update(status='compiled',compilation=c.to_dict())
            except Exception as error:row.update(code=getattr(error,'code',type(error).__name__),message=str(error))
            attempts[method]=row;result.append(row)
        chosen=select_attempt(attempts)
        result.append(dict(attempts[chosen],method='selected',selected_method=chosen) if chosen else dict(claim_id=record['claim_id'],text=record['text'],method='selected',status='unsupported',code='all_parsers_refused'))
    (RUN/(output_prefix+'_results.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in result))
    summary=dict(claims=len(records),source_disjoint=True,used_for_fixes=args.sample=='reviewed',independent_after_freeze=args.sample=='final',reserved_sources_used=False,compiler_and_prompts_frozen=True,
                 media_verification=False,rewriting=False,methods={})
    for method in ['srl','amr','direct','selected']:
        rr=[r for r in result if r['method']==method]
        summary['methods'][method]=dict(compiled=sum(r['status']=='compiled' for r in rr),total=len(records),
            refusals=dict(Counter(r['code'] for r in rr if r['status']!='compiled')))
    (RUN/(output_prefix+'_summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))

if __name__=='__main__':main()
