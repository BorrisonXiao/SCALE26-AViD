#!/usr/bin/env python3
"""Replay saved original-claim compilation without models or media."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/logical_form_20261028'


def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def main():
    with tempfile.TemporaryDirectory(prefix='avid-logical-form-') as name:
        out=Path(name)
        for filename in ['inputs.jsonl','reference_requirements.json']+[f'{m}_{i}_raw.jsonl' for m in ['direct','assisted'] for i in [0,1]]:
            shutil.copyfile(RUN/filename,out/filename)
        subprocess.run([sys.executable,str(ROOT/'scripts/analyze_logical_forms.py'),'--run-dir',str(out)],check=True,stdout=subprocess.DEVNULL)
        a,b=read(RUN/'results.jsonl'),read(out/'results.jsonl');assert len(a)==len(b)==400
        for x,y in zip(a,b):assert x==y,(x['method'],x['claim_id'])
    for sample,prefix in [('reviewed','reviewed_source'),('final','final_holdout')]:
        previous=read(RUN/(prefix+'_results.jsonl'))
        subprocess.run([sys.executable,str(ROOT/'scripts/evaluate_logical_form_holdout.py'),'--sample',sample],check=True,stdout=subprocess.DEVNULL)
        assert previous==read(RUN/(prefix+'_results.jsonl'))
    print('Reproduced 400 development outcomes and 90 source-check attempts, plus their 30 selection outputs. No model loading, media, or training.')

if __name__=='__main__':main()
