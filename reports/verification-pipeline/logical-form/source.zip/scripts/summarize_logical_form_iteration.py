#!/usr/bin/env python3
"""Summarize frozen parse outputs without model calls or new semantic judgments."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from probabilistic_verification.compilation_selection import select_attempt
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/logical_form_20261028'


def main():
    rows=[json.loads(s) for s in (RUN/'results.jsonl').read_text().splitlines()]
    refs={r['claim_id']:r for r in json.loads((RUN/'reference_requirements.json').read_text())['requirements']}
    grouped={}
    for r in rows:grouped.setdefault(r['claim_id'],{})[r['method']]=r
    selected=[]
    for cid,attempts in grouped.items():
        method=select_attempt(attempts)
        if method:r=dict(attempts[method],method='selected',selected_method=method)
        else:
            first=next(iter(attempts.values()));ref=refs.get(cid,{})
            r=dict(claim_id=cid,text=first['text'],cohort=first['cohort'],method='selected',status='unsupported',
                   requirements_pass=bool(ref.get('expected_refusal') and all(x.get('code')==ref['expected_refusal'] for k,x in attempts.items() if k in {'srl','amr'})))
        selected.append(r)
    (RUN/'selected_results.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in selected))
    summary=json.loads((RUN/'summary.json').read_text())
    summary['methods']['selected']={}
    for cohort,rr in [('real',[r for r in selected if r['cohort'].startswith('real')]),('controls',[r for r in selected if r['cohort']=='constructed_contrast'])]:
        diagnostic=[r for r in rr if r['claim_id'] in refs and not refs[r['claim_id']]['uncertain']]
        summary['methods']['selected'][cohort]=dict(total=len(rr),compiled=sum(r['status']=='compiled' for r in rr),
            diagnostic_cases=len(diagnostic),diagnostic_requirements_pass=sum(r.get('requirements_pass',False) for r in diagnostic))
    suites=ET.parse(RUN/'tests.xml').getroot().findall('.//testsuite')
    summary['tests']={k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','failures','errors']}
    summary['rewrite_implemented']=False
    (RUN/'summary_with_selection.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary['methods']['selected']))

if __name__=='__main__':main()
