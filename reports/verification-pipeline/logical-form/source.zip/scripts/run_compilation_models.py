#!/usr/bin/env python3
"""Text-only graph generation for the compilation comparison. No verification."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import time

import prompts_phase2 as P

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compilation_methods_20261028'


def read(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def append(path,row):
    with Path(path).open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')


def amr(args,tasks):
    import torch
    from amrlib.models.parse_xfm.inference import Inference
    torch.set_num_threads(4)
    model_dir=RUN/'models/model_parse_xfm_bart_large-v0_1_0'
    model=Inference(model_dir=str(model_dir),tok_name_or_path=str(RUN/'models/bart-tokenizer'),
        device='cuda' if torch.cuda.is_available() else 'cpu',batch_size=8,num_beams=4)
    config=dict(frontend='amrlib-BART-large',amrlib=importlib.metadata.version('amrlib'),
        transformers=importlib.metadata.version('transformers'),torch=torch.__version__,beam_size=4,
        model_download=json.loads((RUN/'models/download.json').read_text()),
        model_config_sha256=hashlib.sha256((model_dir/'config.json').read_bytes()).hexdigest())
    for i in range(0,len(tasks),8):
        batch=tasks[i:i+8];started=time.perf_counter()
        graphs=model.parse_sents([t['text'] for t in batch],add_metadata=False)
        elapsed=time.perf_counter()-started
        for task,graph in zip(batch,graphs):
            request=dict(task=task,config=config)
            append(args.output,dict(request=request,request_hash=digest(request),raw=graph,
                batch_wall_seconds=elapsed,batch_size=len(batch),slurm_job_id=os.getenv('SLURM_JOB_ID')))
        print('AMR',min(i+8,len(tasks)),len(tasks),f'{elapsed:.1f}s',flush=True)


def language_model(args,tasks):
    import torch
    from transformers import AutoTokenizer,Qwen3VLForConditionalGeneration
    torch.set_num_threads(4)
    path=Path('/exp/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct')
    tokenizer=AutoTokenizer.from_pretrained(path,local_files_only=True)
    model=Qwen3VLForConditionalGeneration.from_pretrained(path,local_files_only=True,dtype=torch.float16,
        attn_implementation='sdpa').to('cuda').eval()
    config=dict(frontend=args.method,model=str(path),modality='text_only',dtype='float16',
        transformers=importlib.metadata.version('transformers'),torch=torch.__version__,
        prompt_version=P.PREDICATE_GRAPH_PROMPT_VERSION,decoding=dict(do_sample=False,max_new_tokens=1000),
        config_sha256={n:hashlib.sha256((path/n).read_bytes()).hexdigest() for n in ('config.json','tokenizer_config.json')})
    for task in tasks:
        messages=[dict(role='system',content=P.PREDICATE_GRAPH_SYSTEM),
                  dict(role='user',content=P.predicate_graph_user(task,assisted=args.method=='guided'))]
        prompt=tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
        request=dict(task=task,config=config,messages=messages,prompt=prompt)
        inputs=tokenizer(prompt,return_tensors='pt').to('cuda');started=time.perf_counter()
        with torch.inference_mode():output=model.generate(**inputs,do_sample=False,max_new_tokens=1000)
        ids=output[0,inputs.input_ids.shape[1]:]
        append(args.output,dict(request=request,request_hash=digest(request),raw=tokenizer.decode(ids,skip_special_tokens=True),
            output_tokens=len(ids),finish_reason='length' if len(ids)==1000 else 'stop',
            wall_seconds=time.perf_counter()-started,slurm_job_id=os.getenv('SLURM_JOB_ID')))
        print(args.method,task['claim_id'],len(ids),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(__doc__)
    p.add_argument('--method',choices=['amr','direct','guided'],required=True)
    p.add_argument('--input',type=Path,default=RUN/'inputs.jsonl')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--shard',type=int,default=0);p.add_argument('--shards',type=int,default=1)
    p.add_argument('--limit',type=int)
    args=p.parse_args();tasks=read(args.input)[args.shard::args.shards]
    if args.limit:tasks=tasks[:args.limit]
    if args.output.exists():
        done={r['request']['task']['claim_id'] for r in read(args.output)}
        tasks=[t for t in tasks if t['claim_id'] not in done]
    args.output.parent.mkdir(parents=True,exist_ok=True)
    if tasks:(amr if args.method=='amr' else language_model)(args,tasks)
