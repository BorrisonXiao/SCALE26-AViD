#!/usr/bin/env python3
"""Assistant-authored semantic requirements, independent of generated parses.

These are diagnostic references, not independent human accuracy annotations.
Uncertain lexical readings are explicitly excluded from definitive pass rates.
"""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/logical_form_20261028'


def main():
    records={r['claim_id']:r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())}
    output=[]
    def add(cid,predicate=None,roles=None,scope='world',temporal=None,properties=None,refusal=None,uncertain=False,notes=''):
        output.append(dict(claim_id=cid,text=records[cid]['text'],predicate=predicate,roles=roles or {},scope=scope,
                           temporal=temporal,properties=properties or [],expected_refusal=refusal,
                           uncertain=uncertain,notes=notes))
    add('TjHepwuhkYFA_1001','occur',{'ARG1':['earthquake'],'location':['Myanmar']},temporal=['past','simple'])
    add('T2G_ACMxR_I4_1396','land',{'ARG1':['IM-1'],'location':['moon']},temporal=['past','simple'])
    add('TKCfkoNUssZI_715','storm',{'ARG0':['troop'],'ARG1':['parliament','building']},temporal=['pres','simple'],notes='Martial law modifies troops; storm is the assault reading, not a weather event.')
    for cid,word in [('TjHepwuhkYFA_1087','damaged'),('TjHepwuhkYFA_1088','collapsed')]:
        add(cid,'show',{'ARG0':['photo']},properties=[['building',word,'visual_depiction']],notes='Compile building and its state inside depiction scope, without requiring a filmed damage/collapse event.')
    add('TjHepwuhkYFA_1080','be',{'ARG1':['earthquake','impact'],'ARG2':['devastating']},uncertain=True,notes='The genitive relationship needs interpretation; do not infer ownership. A state predication of impact is an alternative acceptable form.')
    add('TLO3smKI67PM_588','receive',{'ARG0':['Phillies','fan','son'],'ARG1':['bat']},temporal=['past','simple'],uncertain=True,notes='Nested noun phrase is ambiguous. Retain all lexical content; no definitive full-meaning score.')
    add('T2EE72iNELEs_198','whistle',{'ARG0':['person']},temporal=['unspecified','progressive'])
    add('TKCfkoNUssZI_700','shout',{'ARG0':['person']},temporal=['pres','progressive'])
    add('TzzhcBIczf_M_2073','arrest',{'ARG1':['Shi','Yongxin']},temporal=['pres','perfect'],notes='No agent or negation is supplied by the original claim.')
    add('TInVWzp25aIM_13','cause',{'ARG0':['typhoon'],'ARG1':['flood']},temporal=['pres','progressive'],properties=[['flood','massive','world']])
    add('TInVWzp25aIM_76','bring',{'ARG0':['storm'],'ARG1':['wind']},temporal=['pres','progressive'],properties=[['wind','heavy','world']])
    add('TInVWzp25aIM_90','impact',{'ARG0':['storm'],'ARG1':['coast']},temporal=['past','simple'],properties=[['coast','Alaskan','world']])
    add('T2G_ACMxR_I4_1403','congratulate',{'ARG0':['Stephen','Altemus'],'ARG1':['IM','team']},temporal=['pres','simple'])
    add('TKCfkoNUssZI_720','hold',{'ARG0':['protest'],'ARG1':['flag']},temporal=['pres','progressive'])
    add('TjHepwuhkYFA_1000','read',{'ARG1':['text']},properties=[['toll','1600','ocr_assertion']],notes='The OCR content must include Myanmar, earthquake, death toll, reach and 1600 inside source scope; exact noun-phrase decomposition is reviewed separately.')
    add('TzF9M4kZ3Pys_289','come',{'ARG1':['Haboob'],'destination':['airport']},temporal=['unspecified','progressive'],notes='Haboob is not a city-name reading; preserve approach direction.')
    add('Tsuk2uoYj-kc_635','walk',{'ARG0':['person'],'location':['background']},temporal=['unspecified','progressive'])
    add('Tsuk2uoYj-kc_633','gather',{'participant':['person'],'location':['Mecca']},temporal=['past','simple'],notes='Retain together as an event property; do not require a direct-object Mecca.')
    add('TjHepwuhkYFA_1086','show',{'ARG0':['photo']},properties=[['flood','','visual_depiction']])
    add('TjHepwuhkYFA_1089','show',{'ARG0':['photo']},properties=[['rubble','','visual_depiction']])
    for cid,person,tense in [('TInVWzp25aIM_81',['Matthew','Morgan'],'pres'),('TInVWzp25aIM_84',['Seth','LaCount'],'past')]:
        add(cid,'share',{'ARG0':person,'ARG1':['footage']},temporal=[tense,'simple'],properties=[['footage','initial','world']])
    add('Txf2EdqOg1SQ_2313','depict',{'ARG0':['infrared','satellite','imagery']},properties=[['temperature','cloud','visual_depiction']],uncertain=True,notes='Cloud-top temperature and instrument/source relationships need fuller noun-phrase analysis.')
    add('TLO3smKI67PM_591','hit',{'ARG0':['Harrison','Bader'],'ARG1':['home','run']},temporal=['past','simple'],uncertain=True,notes='Idiomatic home-run reading needs lexical review; do not certify a literal physical-object interpretation.')
    for i in range(6):
        add(f'contrast_{i:02d}','land',{'ARG1':['Apollo','11'] if i<2 else ['spacecraft'],'location':['moon']},temporal=[['past','simple'],['pres','progressive'],['past','simple'],['pres','progressive'],['past','progressive'],['pres','perfect']][i])
    for i in [6,7,8,9,10]:
        roles={'ARG0':['Bob' if i==8 else 'Alice'],'ARG1':['Alice' if i==8 else 'Bob']}
        add(f'contrast_{i:02d}','hug',roles,temporal=['pres','simple'],notes='Negated hug only.' if i==9 else 'Hug and wave must share Alice.' if i==10 else 'Positive hug; passive wording preserves roles.')
    for i,color1,color2 in [(11,'gray','red'),(12,'red','gray')]:
        add(f'contrast_{i:02d}','pass',{'ARG0':['car'],'ARG1':['truck']},properties=[['car',color1,'world'],['truck',color2,'world']])
    add('contrast_13','show',{'ARG0':['photo']},properties=[['building','collapsed','visual_depiction']])
    add('contrast_14','collapse',{'ARG1':['building']},temporal=['pres','perfect'])
    for i in [15,16]:add(f'contrast_{i:02d}','land',{'ARG1':['spacecraft']},scope='speech_assertion',temporal=['pres','perfect'],notes='The narrator says this proposition; negation belongs inside speech content.' if i==16 else 'Landing belongs inside speech content.')
    add('contrast_17','be',{'ARG1':['earthquake','impact'],'ARG2':['devastating']},uncertain=True,notes='Genitive interpretation is not uniquely specified; no ownership assumption.')
    add('contrast_18',refusal='quantity',notes='Counting is not implemented; refusal is the intended behavior for this iteration.')
    add('contrast_19',refusal='scope',notes='Do not assert the possible landing as an actual event.')
    add('contrast_20',refusal='reference',notes='Resolve She from discourse before compiling a grounded claim.')
    assert len(output)==46 and len({r['claim_id'] for r in output})==46
    (RUN/'reference_requirements.json').write_text(json.dumps(dict(author='Codex assistant',independent_human_gold=False,
        purpose='Specified semantic diagnostic requirements, not complete truth-conditional equivalence judgments.',
        uncertain_readings_excluded=True,requirements=output),ensure_ascii=False,indent=2)+'\n')

if __name__=='__main__':main()
