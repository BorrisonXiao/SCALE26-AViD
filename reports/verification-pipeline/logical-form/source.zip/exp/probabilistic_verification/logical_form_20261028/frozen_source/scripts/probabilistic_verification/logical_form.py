"""Explicit claim logical forms and deterministic compilation.

This interface carries meaning, not embeddings or generated code. Source
content is compiled recursively under a source-event variable. Historical
PENMAN compilers and their saved experiments are intentionally unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import re
from .representation import Atom, CompiledClaim, Expression as E, Variable
from .semantic import temporal_features

VERSION = 'logical-form-v1'


class LogicalFormError(ValueError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


@dataclass(frozen=True)
class LogicalClaim(CompiledClaim):
    version: str = VERSION
    metadata: dict = field(default_factory=dict)


def lemma(predicate):
    return re.sub(r'-\d\d$', '', predicate).lower().replace('_', '-')


def bind_variables(expression, atoms, variables):
    """Introduce shared witnesses at their lowest common logical ancestor."""
    by_id = {a.id: a for a in atoms}
    names = {v.name for v in variables}
    def free(e, bound=frozenset()):
        if e.op == 'atom':
            return set(by_id[e.atom_id].arguments) & (names - bound)
        return set().union(*(free(c, bound | set(e.variables)) for c in e.children))
    def visit(e, remaining):
        if not e.children:
            return E.exists(sorted(remaining & free(e)), e)
        uses = [free(c) for c in e.children]
        delegated = [set() for _ in e.children]
        local = []
        for name in sorted(remaining):
            locations = [i for i, used in enumerate(uses) if name in used]
            if len(locations) == 1:
                delegated[locations[0]].add(name)
            elif len(locations) > 1:
                local.append(name)
        result = E(e.op, tuple(visit(c, delegated[i] - set(e.variables)) for i, c in enumerate(e.children)),
                   atom_id=e.atom_id, variables=e.variables, state=e.state)
        return E.exists(local, result)
    return visit(expression, free(expression))


class LogicalFormCompiler:
    """Compile one documented JSON logical form to the existing backend objects."""
    def compile(self, claim_id, text, tokens, form):
        if not isinstance(form, dict) or form.get('version') != VERSION:
            raise LogicalFormError('schema', 'Expected version=logical-form-v1.')
        if form.get('status', 'ok') != 'ok':
            raise LogicalFormError('parser_refusal', form.get('reason', 'The parser declined the claim.'))
        entities = {e['id']: e for e in form.get('entities', [])}
        if len(entities) != len(form.get('entities', [])):
            raise LogicalFormError('duplicate_entity', 'Entity IDs must be unique.')
        if re.search(r'\b(might|could|would|should|must|unless|every|all|never|neither)\b', text, re.I):
            raise LogicalFormError('scope', 'Modal or quantified meaning is outside the current fragment.')
        if any(t.get('upos') == 'PRON' and t.get('deprel') != 'expl' and t.get('lemma', t['text']).lower() in {'he','she','they','it','this','that'} for t in tokens):
            raise LogicalFormError('reference', 'A pronoun requires discourse resolution.')
        by_token_id = {t['id']: t for t in tokens}
        counted = any(t.get('upos') == 'NUM' and t.get('deprel') == 'nummod' and by_token_id.get(t['head'], {}).get('upos') != 'PROPN' for t in tokens)
        counted |= any(t.get('upos') != 'PROPN' and t['text'].lower() in {'hundreds','thousands','millions','billions'} for t in tokens)
        if counted or any(e.get('quantity') is not None for e in entities.values()):
            raise LogicalFormError('quantity', 'A counted group needs an explicit counting interpretation.')
        roots=[t for t in tokens if t.get('head')==0]
        if any(t.get('upos')=='VERB' and 'Tense=' not in (t.get('feats') or '') and any(u.get('head')==t['id'] and u.get('deprel')=='ccomp' for u in tokens) and not any(u.get('head')==t['id'] and u.get('deprel')=='nsubj' for u in tokens) for t in roots):
            raise LogicalFormError('clause_type', 'An imperative/directive with embedded content needs a defined claim interpretation.')
        atoms, variables, warnings = [], [], list(form.get('warnings', []))
        atom_cache = {}
        metadata = dict(logical_form=form, temporal={}, allowed_routes={}, scopes={},
                        reference_variable='T0', entities={}, events={}, uses_phrase_arguments=False)
        refs, events, event_nodes, emitted = {}, {}, {}, set()
        def variable(key, kind, description):
            table = events if kind == 'event' else refs
            if key not in table:
                name = ('E' if kind == 'event' else 'X') + str(len(table) + 1)
                table[key] = name
                variables.append(Variable(name, kind, description, ()))
            return table[key]
        def add(predicate, args, scope, route, *, kind='relation', trainable=True, label=''):
            suffix = ['scope', scope]
            if route != 'world': suffix += ['route', route]
            signature = (predicate, tuple(args + suffix), kind, trainable)
            if signature in atom_cache: return E.atom(atom_cache[signature])
            a = Atom('a' + str(len(atoms) + 1), predicate, tuple(args + suffix), kind,
                     (), label or predicate, (), trainable)
            atoms.append(a)
            atom_cache[signature] = a.id
            metadata['allowed_routes'][a.id] = [route] if route != 'world' else ['visual_depiction', 'audio_event']
            return E.atom(a.id)
        def entity(eid, scope, route, trail=()):
            if eid not in entities:
                raise LogicalFormError('unknown_entity', 'Undeclared entity: ' + str(eid))
            data = entities[eid]
            if eid in trail:
                # Reentrancy is an identity link; do not recurse indefinitely.
                return refs[(scope, eid)], []
            name = variable((scope, eid), 'entity', data['text'])
            metadata['entities'][name] = dict(data, scope=scope, route=route)
            if data.get('detail') == 'phrase':
                metadata['uses_phrase_arguments'] = True
            conditions = [add('referent', [name, data['text']], scope, route, kind='entity', trainable=False)]
            if data.get('concept') and data['concept'] != 'entity':
                conditions.append(add('concept', [name, data['concept']], scope, route, kind='entity', trainable=False))
            for prop in data.get('properties', []):
                conditions.append(add('property', [name, prop['role'], str(prop['value'])], scope, route, kind='property'))
            for rel in data.get('relations', []):
                if rel['target'].startswith('event:'):
                    event_key=(scope,rel['target'][6:])
                    if event_key not in events:raise LogicalFormError('event_reference','An entity relation crosses an undeclared event scope.')
                    other,nested=events[event_key],[]
                else:
                    other, nested = entity(rel['target'], scope, route, trail + (eid,))
                role = rel['role']
                relation = [other, role[:-3], name] if role.endswith('-of') else [name, role, other]
                conditions += nested + [add('entity_relation', relation, scope, route)]
            return name, conditions
        def register(node, scope):
            if not isinstance(node, dict):
                raise LogicalFormError('schema', 'Each formula node must be an object.')
            op = node.get('op')
            if op == 'event':
                key = (scope, node['id'])
                if key in event_nodes:
                    raise LogicalFormError('duplicate_event', 'Declare each event once; use its ID for references.')
                event_nodes[key] = node
                variable(key, 'event', node['predicate'])
                # Source contents have their own evidence context.
                if node.get('content'):
                    register(node['content'], events[key])
            elif op in {'and', 'or'}:
                if len(node.get('children', [])) < 2:
                    raise LogicalFormError('schema', 'AND/OR need at least two children.')
                for child in node['children']: register(child, scope)
            elif op == 'not': register(node['child'], scope)
            elif op != 'entity': raise LogicalFormError('operator', 'Unsupported operator: ' + str(op))
        register(form['formula'], 'world')
        def anchor(node):
            word = node.get('anchor', '')
            exact = [t for t in tokens if word and t['text'].lower() == word.lower()]
            if len(exact) == 1: return exact[0]
            target = lemma(node['predicate'])
            matching = [t for t in tokens if t.get('lemma', '').lower() == target]
            if len(matching) == 1: return matching[0]
            from nltk.stem import SnowballStemmer
            stem = SnowballStemmer('english').stem
            matching = [t for t in tokens if stem(t.get('lemma', t['text']).lower()) == stem(target) or stem(t['text'].lower()) == stem(target)]
            return matching[0] if len(matching) == 1 else None
        def formula(node, scope='world', route='world', negative=False):
            op = node['op']
            if op in {'and', 'or'}:
                return E.combine(op, [formula(c, scope, route) for c in node['children']])
            if op == 'not':
                if node['child'].get('op') != 'event':
                    raise LogicalFormError('negation_scope', 'This fragment supports local event negation only.')
                return formula(node['child'], scope, route, negative=True)
            if op == 'entity':
                _, conditions = entity(node['ref'], scope, route)
                return E.combine('and', conditions)
            key = (scope, node['id']); event = events[key]; pred = lemma(node['predicate'])
            metadata['events'][event] = dict(node, scope=scope, route=route)
            args, conditions, roles = [event], [], set()
            for role, target in sorted(node.get('arguments', {}).items()):
                if role in roles: raise LogicalFormError('roles', 'Duplicate argument role.')
                roles.add(role)
                if isinstance(target, dict) and set(target) == {'op','ref'} and target.get('op') == 'entity':
                    target = target['ref']
                if not isinstance(target, str):
                    raise LogicalFormError('argument_format', 'An argument must name an entity or event reference.')
                if target not in entities and not target.startswith('event:'):
                    matched = re.search(r'(?<!\w)'+re.escape(target)+r'(?!\w)', text, re.I)
                    if not matched:
                        raise LogicalFormError('unknown_entity', 'Undeclared argument is not an exact source mention: '+target)
                    mention = text[matched.start():matched.end()]
                    entities[target] = dict(id=target,text=mention,concept='entity',detail='phrase')
                    warnings.append('Inline argument linked to its exact original mention: '+mention)
                if target.startswith('event:'):
                    child_key = (scope, target[6:])
                    if child_key not in events:
                        raise LogicalFormError('event_reference', 'An event argument is not declared in this scope.')
                    value = events[child_key]
                    if pred not in {'cause', 'devastate'}:
                        raise LogicalFormError('event_scope', 'This event complement needs a frame-specific scope interpretation.')
                else:
                    value, required = entity(target, scope, route)
                    conditions += required
                args += [role, value]
            # A few established frames catch the observed role reversals. This is
            # a declared supported subset, not a full PropBank frame validator.
            if pred in {'land', 'arrest', 'collapse'}:
                if 'ARG0' in roles and pred in {'land', 'collapse'}:
                    raise LogicalFormError('role_frame', pred + ' uses ARG1 for its theme in this fragment.')
                if 'ARG1' not in roles:
                    raise LogicalFormError('role_frame', pred + ' requires ARG1 in this fragment.')
            sense = node.get('sense') or (re.search(r'-(\d\d)$',node['predicate']).group(1) if re.search(r'-(\d\d)$',node['predicate']) else None)
            if sense:
                args += ['sense', str(sense)]
            head = anchor(node)
            if head:
                local_neg = any(t['head'] == head['id'] and t.get('lemma', t['text']).lower() in {"not", "n't"} for t in tokens)
                if local_neg != negative:
                    raise LogicalFormError('polarity', 'Graph polarity differs from the aligned source predicate.')
            elif negative and not re.search(r"\bnot\b|n't\b|\bno\b|\bwithout\b", text, re.I):
                raise LogicalFormError('polarity', 'Negation has no source support.')
            if node.get('content'):
                if pred not in {'say','tell','state','report','mention','ask','claim','read','show','depict','display'}:
                    raise LogicalFormError('source_frame', 'An ordinary event cannot be hidden inside an evidence-source frame.')
                child_route = node.get('route')
                if child_route not in {'speech_assertion', 'ocr_assertion', 'visual_depiction'}:
                    raise LogicalFormError('source_route', 'A source needs a defined evidence route.')
                metadata['scopes'][event] = dict(parent=scope, route=child_route, source_arguments=dict(node.get('arguments', {})))
                args += ['content_scope', event, 'content_route', child_route]
            if pred in {'say','tell','state','report','mention','ask','claim'} and not node.get('content'):
                raise LogicalFormError('source_content', 'A speech/report predicate requires its structured content.')
            entity_conditions = conditions
            conditions = [add(pred, args, scope, route)]
            for prop in node.get('properties', []):
                if prop['role'] in {'tense','aspect'}:
                    observed = dict(temporal_features(tokens, head['id'])) if head else {}
                    expected = {'present':'pres'}.get(str(prop['value']),str(prop['value']))
                    if observed.get(prop['role']) != expected:
                        raise LogicalFormError('temporal', 'Generated temporal annotation conflicts with the source auxiliary sequence.')
                    warnings.append('Redundant generated '+prop['role']+' checked against source auxiliaries and omitted.')
                    continue
                conditions += [add('property', [event, prop['role'], str(prop['value'])], scope, route, kind='property')]
            if head:
                tf = dict(temporal_features(tokens, head['id']), completion='unspecified')
                if tf['tense'] != 'unspecified' or tf['aspect'] != 'simple':
                    metadata['temporal'][event] = tf
                    conditions += [add('temporal', [event, tf['tense'], tf['aspect'], 'T0', tf['completion']],
                                       scope, route, kind='temporal', trainable=False)]
            elif node.get('anchor'):
                warnings.append('No unique source alignment for ' + node['id'] + '. Tense/aspect remains unassigned.')
            if node.get('content'):
                conditions.append(formula(node['content'], event, node['route']))
            result = E.combine('and', conditions)
            # Event existence is part of the proposition being negated. Entity
            # conditions also remain in that source/clause, never the world root.
            if negative:
                return E.combine('and', entity_conditions + [E.negate(E.exists([event], result))])
            return E.combine('and', entity_conditions + [result])
        expression = formula(form['formula'])
        usage = {}
        for entity_data in metadata['entities'].values():
            usage.setdefault(entity_data['id'], set()).add(entity_data['scope'])
        if any(len(scopes)>1 for scopes in usage.values()):
            raise LogicalFormError('cross_scope_reference', 'A referent shared across source scopes needs an explicit mention/reference interpretation.')
        unused = set(entities) - {e['id'] for e in metadata['entities'].values()}
        if unused:
            raise LogicalFormError('unused_entities', 'Declared entities are absent from the formula: ' + ', '.join(sorted(unused)))
        if metadata['temporal']:
            variables.append(Variable('T0', 'context', 'Discourse reference context supplied by the caller', ()))
        expression = bind_variables(expression, atoms, variables)
        if not atoms: raise LogicalFormError('empty', 'The formula has no conditions.')
        metadata['limitations'] = ['Restricted scope fragment; no general modality, counting or discourse resolution.',
                                   'Validity does not certify a correct semantic parse.']
        return LogicalClaim(claim_id, text, tuple(tokens), tuple(variables), tuple(atoms), expression,
                            (), tuple(dict.fromkeys(warnings)), metadata=metadata)
