"""Compile predicate/argument graphs to the existing three-state logic backend.

PENMAN is only a graph serialization here. Trained AMR, SRL and neural front
ends share this compiler; SRL-derived graphs are not claimed to be full AMRs.
Source complements are reified propositions, never automatically world facts.
This is a restricted compiler, not a complete AMR-to-first-order-logic system.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import re

from .representation import Atom, CompiledClaim, Expression as E, Variable
from .semantic import temporal_features


class PredicateError(ValueError):
    def __init__(self, code, message):
        self.code=code
        super().__init__(message)


@dataclass(frozen=True)
class PredicateClaim(CompiledClaim):
    version: str="predicate-graph-compiler-v1"
    metadata: dict=field(default_factory=dict)


def base_name(concept):
    return re.sub(r'-\d\d$', '', concept).lower().replace('_','-')


def literal(value):
    if isinstance(value,str) and value.startswith('"'):
        try:return json.loads(value)
        except json.JSONDecodeError:pass
    return str(value)


def clean_graph(text):
    """Remove presentation fences only; never repair semantic graph edges."""
    text=text.strip()
    if text.startswith('```'):
        text=text.split('\n',1)[1].rsplit('```',1)[0].strip()
    if not text.startswith(('(', '#')):
        raise PredicateError('graph_format','Expected a PENMAN graph without explanatory prose.')
    return text


class PredicateCompiler:
    def compile(self, claim_id, text, graph_text, tokens=(), *, provenance=None):
        import penman
        from penman.models.amr import model as amr_model
        from nltk.stem import SnowballStemmer

        graph_text=clean_graph(graph_text)
        try:
            trees=list(penman.iterparse(graph_text))
            if len(trees)!=1:raise PredicateError('graph_count','Expected exactly one complete graph.')
            tree=trees[0]
            graph=penman.decode(graph_text,model=amr_model)
        except Exception as error:
            raise PredicateError('graph_syntax',str(error)) from error
        instances={t.source:t.target for t in graph.instances()}
        if not instances or len(instances)!=len(graph.instances()):
            raise PredicateError('graph_nodes','Each node needs exactly one concept.')
        edges={x:[] for x in instances}
        for source,role,target in graph.triples:
            if role!=':instance':edges[source].append((role.lstrip(':'),target))
        for node in edges:
            core=[role for role,_ in edges[node] if re.fullmatch(r'ARG\d',role)]
            if len(core)!=len(set(core)):
                raise PredicateError('duplicate_roles','A predicate has duplicate core argument roles.')
        declarations={}
        parents={}
        def index(node,parent=None):
            variable,branches=node
            declarations[variable]=node
            if parent:parents[variable]=parent
            for role,target in branches:
                if isinstance(target,tuple):index(target,(variable,role.lstrip(':')))
        index(tree.node)
        def declared_below(node):
            if not isinstance(node,tuple):return set()
            return {node[0]}|set().union(*(declared_below(t) for _,t in node[1]))
        def role_target(node,role):
            found=[t for r,t in declarations.get(node,('',[]))[1] if r.lstrip(':')==role]
            return found[0] if len(found)==1 else None
        def target_var(target):
            return target[0] if isinstance(target,tuple) else target if target in instances else None
        def description(node,seen=()):
            if node not in instances:return literal(node)
            if node in seen:return instances[node]
            roles=dict(edges[node]);concept=instances[node]
            if 'surface' in roles:return literal(roles['surface'])
            name=next((t for r,t in edges[node] if r=='name'),None)
            if name in instances:
                ops=sorted(((r,literal(t)) for r,t in edges[name] if re.fullmatch(r'op\d+',r)),key=lambda x:int(x[0][2:]))
                if ops:return ' '.join(v for _,v in ops)
            if concept=='name':
                return ' '.join(literal(t) for r,t in sorted(edges[node]) if r.startswith('op'))
            modifiers=[description(t,seen+(node,)) for r,t in edges[node] if r in {'mod','degree','quant','poss','part-of'}]
            return ' '.join(modifiers+[base_name(concept)])
        def is_event(node):
            return (bool(re.search(r'-\d\d$',instances[node])) or
                    any(re.fullmatch(r'ARG\d|ARGM-.+',r) or r=='domain' for r,_ in edges[node])) and base_name(instances[node]) not in {'and','or'}
        events={x for x in instances if is_event(x)}
        # SRL copular frames are elementary states; AMR :domain is handled below.
        source_frames={};embedded=set();source_texts=[]
        report={'say','tell','state','report','mention','ask','claim'}
        depict={'show','depict','display'}
        for node in events:
            verb=base_name(instances[node]);roles=dict(edges[node])
            actor=roles.get('ARG0',roles.get('source'))
            content_role='ARG1'
            # PropBank read-01 can put the written source in ARG1 and content
            # in ARG3. This is frame-specific, not ARG0=agent by convention.
            if verb=='read' and 'ARG3' in roles:
                actor=roles.get('ARG1',actor);content_role='ARG3'
            actor_text=description(actor).lower() if actor else ''
            media=bool(re.search(r'\b(photo|photograph|image|imagery|video|footage|screen|text|caption|logo)\w*\b',actor_text))
            if verb in report or verb=='read' and media or verb in depict and media:
                child=role_target(node,content_role)
                if child is None:
                    raise PredicateError('source_scope','A reporting/depiction frame needs one embedded content argument.')
                child_ids=declared_below(child)
                if isinstance(child,tuple):
                    content=penman.format(penman.Tree(child))
                else:content=description(child)
                embedded.update(child_ids);source_texts.append(content)
                route='visual_depiction' if verb in depict else 'ocr_assertion' if re.search(r'\b(text|caption|screen|sign)\b',actor_text) else 'speech_assertion'
                act='depiction' if route=='visual_depiction' else 'question' if verb=='ask' else 'assertion'
                source_frames[node]=dict(content=content,nodes=sorted(child_ids),route=route,act=act,content_role=content_role)
        world=events-embedded
        if not world and base_name(instances[graph.top]) in {'and','or'}:
            raise PredicateError('empty_graph','No complete world/source predicate was retained.')
        for node in world:
            if base_name(instances[node]) in {'want','try','believe','think','seem','appear','hope','plan','possible','recommend'}:
                raise PredicateError('unhandled_scope','Modal/intensional scope needs an explicit translation; no inner event is asserted.')
            if any(r in {'condition','concession'} for r,_ in edges[node]):
                raise PredicateError('unhandled_scope','Conditional/concessive scope is outside this first compiler comparison.')
        # Preserve opaque source content, but decline unresolved world operators.
        outer_text=text
        if source_frames and world<=source_frames.keys():outer_text=' '.join(description(dict(edges[n]).get('ARG0',''))+' '+base_name(instances[n]) for n in world)
        if re.search(r'\b(might|could|would|should|must|unless|every|all|never|neither)\b',outer_text,re.I):
            raise PredicateError('unhandled_scope','A world modal, universal or temporal quantifier has no defined logical translation yet.')
        atoms=[];variables=[];references={};temporal={};source_metadata={};diagnostics=[]
        untranslated=[]
        for n in instances:
            if n in embedded:continue
            for role,target in edges[n]:
                event_roles={'domain','location','direction','source','destination','instrument','manner','cause','purpose','time','beneficiary','topic'}
                descriptive={'mod','quant','degree','poss','part-of','name','surface','wiki'}
                if role in descriptive or role.startswith('op') or role in {'polarity','tense','aspect','mode'}:continue
                if re.fullmatch(r'ARG\d|ARGM-.+',role) or n in world and role in event_roles:continue
                untranslated.append([n,role,target])
        if untranslated:diagnostics.append('Some graph edges are retained in the record but have no executable translation; inspect untranslated_edges.')
        def atom(predicate,args,kind='relation',trainable=True,description=''):
            a=Atom('a'+str(len(atoms)+1),predicate,tuple(args),kind,tuple('argument' for _ in args),description or predicate,(),trainable)
            atoms.append(a);return E.atom(a.id)
        def ref(node):
            if node not in instances:return 'literal:'+literal(node)
            if node not in references:
                name='X'+str(len(references)+1);references[node]=name
                variables.append(Variable(name,'entity',description(node),()))
            return references[node]
        stemmer=SnowballStemmer('english')
        finite_alignments=[]
        for t in tokens:
            if t.get('upos') in {'VERB','AUX','ADJ','NOUN'}:
                finite_alignments.append(t)
        event_names={n:'E'+str(i+1) for i,n in enumerate(sorted(world))}
        negative={n for n in world if ('polarity','-') in edges[n]}
        units={}
        event_texts={}
        for node in sorted(world):
            e=event_names[node];predicate=base_name(instances[node]);roles=[]
            variables.append(Variable(e,'event',predicate,()))
            for role,target in edges[node]:
                if role in {'polarity','tense','aspect','surface','mode','wiki'}:continue
                if not (re.fullmatch(r'ARG\d|ARGM-.+',role) or role in {'domain','location','direction','source','destination','instrument','manner','cause','purpose','time','beneficiary','topic'}):continue
                if node in source_frames and (role==source_frames[node]['content_role']):continue
                if target in world:
                    if re.fullmatch(r'ARG\d',role) and predicate not in {'cause','devastate'}:
                        raise PredicateError('event_complement','An event-valued argument needs a frame-specific scope rule; it is not automatically asserted.')
                    if target in negative:
                        raise PredicateError('cross_scope_reference','A negated event cannot be used as a positive event witness.')
                    roles.extend([role,event_names[target]])
                elif target in embedded:
                    raise PredicateError('cross_scope_reference','An embedded event/entity is also referenced outside its source scope.')
                else:roles.extend([role,ref(target)])
            if not roles:raise PredicateError('missing_arguments','An event/state must preserve at least one participant or condition.')
            args=[e]+roles
            if node in source_frames:
                scope=source_frames[node];cid='content:'+hashlib.sha256(scope['content'].encode()).hexdigest()[:20]
                args += ['route',scope['route'],'act',scope['act'],'content',cid]
                source_metadata[cid]={**scope, 'source_text':text,
                    'embedded_temporal':[temporal_features(tokens,t['id']) for t in tokens
                      if t.get('upos')=='VERB' and base_name(instances[node])!=t.get('lemma','').lower()]}
                diagnostics.append('Source content is preserved as a proposition; its internal relations are not yet separately compiled.')
            unit=atom(predicate,args)
            event_properties=[atom('property',[e,role,description(target)],'property',True)
                              for role,target in edges[node] if role in {'mod','quant','degree'}]
            if event_properties:unit=E.combine('and',[unit]+event_properties)
            match=[t for t in finite_alignments if stemmer.stem(t.get('lemma',t['text']).lower())==stemmer.stem(predicate) or stemmer.stem(t['text'].lower())==stemmer.stem(predicate)]
            if match:
                tf=temporal_features(tokens,match[0]['id'])
                if tf['tense']!='unspecified' or tf['aspect']!='simple':
                    temporal[e]=tf
                    unit=E.combine('and',[unit,atom('temporal',[e,tf['tense'],tf['aspect'],'T0'],'temporal',False)])
            elif any('Tense=' in (t.get('feats') or '') for t in tokens):
                diagnostics.append('No reliable tense/aspect alignment for '+node+'; source text remains in the record.')
            negated=any(r=='polarity' and t=='-' for r,t in edges[node])
            units[node]=E.negate(E.exists([e],unit)) if negated else unit
        presences={}
        for node,name in references.items():
            items=[atom('referent',[name,description(node)],'entity',False),
                   atom('concept',[name,base_name(instances[node])],'entity',False)]
            for role,target in edges[node]:
                if role in {'mod','quant','degree','poss','part-of'}:
                    items.append(atom('property',[name,role,description(target)],'property',True))
            presences[name]=items
        atom_map={a.id:a for a in atoms}
        def arguments(expr):
            return set(atom_map[expr.atom_id].arguments) if expr.op=='atom' else set().union(*(arguments(c) for c in expr.children))
        for node,unit in units.items():
            entity_names=arguments(unit)&presences.keys()
            units[node]=E.combine('and',[p for name in sorted(entity_names) for p in presences[name]]+[unit])
        # The original graph operators determine clause combination, never word
        # order or the mere presence of 'and' inside a noun phrase.
        used=set()
        def formula(node):
            if node in units:used.add(node);return units[node]
            concept=base_name(instances.get(node,''))
            if concept in {'and','or'}:
                children=[t for r,t in sorted(edges[node]) if re.fullmatch(r'op\d+',r)]
                return E.combine(concept,[formula(t) for t in children])
            candidates=[n for n in world if n not in used]
            if len(candidates)==1:return formula(candidates[0])
            if not candidates:raise PredicateError('non_propositional','No event, state or scoped source statement was identified.')
            return E.combine('and',[formula(n) for n in sorted(candidates)])
        expression=formula(graph.top)
        remaining=[n for n in sorted(world-used)]
        if remaining:expression=E.combine('and',[expression]+[formula(n) for n in remaining])
        if any(c in {'she','he','it','they','this','that'} for c in instances.values()):
            diagnostics.append('An unresolved pronoun requires discourse context before grounding.')
        if temporal:
            variables.append(Variable('T0','context','Discourse reference time; supplied later by the application',()))
        # Bind each shared variable where all its uses meet, with branch-local
        # witnesses for disjunction. Already bound negative event variables stay
        # under NOT. This operates on logic, independent of a syntactic tree.
        all_names={v.name for v in variables}
        def free(expr,bound=frozenset()):
            if expr.op=='atom':return set(atom_map[expr.atom_id].arguments)&(all_names-set(bound))
            return set().union(*(free(c,bound|set(expr.variables)) for c in expr.children))
        def bind(expr,remaining):
            if not expr.children:return E.exists(sorted(remaining&free(expr)),expr)
            child_uses=[free(c) for c in expr.children]
            delegated=[set() for _ in expr.children];local=[]
            for name in sorted(remaining):
                locations=[i for i,u in enumerate(child_uses) if name in u]
                if len(locations)==1:delegated[locations[0]].add(name)
                elif len(locations)>1:local.append(name)
            rebuilt=E(expr.op,tuple(bind(c,delegated[i]-set(expr.variables)) for i,c in enumerate(expr.children)),
                atom_id=expr.atom_id,variables=expr.variables,state=expr.state)
            return E.exists(local,rebuilt)
        expression=bind(expression,free(expression))
        if not atoms:raise PredicateError('empty_graph','An empty formula is not a compiled claim.')
        return PredicateClaim(claim_id,text,tuple(tokens),tuple(variables),tuple(atoms),expression,(),tuple(diagnostics),
            metadata=dict(input_graph=graph_text,graph_top=graph.top,concepts=instances,source_contents=source_metadata,
                          temporal=temporal,untranslated_edges=untranslated,source_frontend=provenance or {},
                          limitations=['Restricted existential/conjunction/disjunction/local-negation fragment.',
                                       'Source content is reified and not asserted in the world.',
                                       'Phrase-level referent conditions are not full noun-phrase logical analysis.',
                                       'No media verification or classifier training is performed.']))
