#!/usr/bin/env python3
"""Compile original claims and check explicit semantic requirements, offline."""
import argparse
from collections import Counter
import hashlib
import json
import logging
from pathlib import Path
from probabilistic_verification.logical_form import LogicalFormCompiler
from probabilistic_verification.logical_form_adapters import amr_form,srl_form
from probabilistic_verification.logical_form_review import checks
from probabilistic_verification.logic import Evidence,ground,prolog_program
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/logical_form_20261028'
BASE=ROOT/'exp/probabilistic_verification/compilation_methods_20261028'


def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]

def strict_json(raw):
    def unique(pairs):
        d={}
        for k,v in pairs:
            if k in d:raise ValueError('Duplicate JSON key: '+k)
            d[k]=v
        return d
    raw=raw.strip()
    if raw.startswith('```'):raw=raw.split('\n',1)[1].rsplit('```',1)[0].strip()
    return json.loads(raw,object_pairs_hook=unique)


def main():
    parser=argparse.ArgumentParser(__doc__);parser.add_argument('--run-dir',type=Path,default=RUN)
    parser.add_argument('--baselines-only',action='store_true');args=parser.parse_args();run=args.run_dir
    logging.getLogger('penman').setLevel(logging.ERROR)
    inputs=read(run/'inputs.jsonl');refs={r['claim_id']:r for r in json.loads((run/'reference_requirements.json').read_text())['requirements']}
    amrs={r['request']['task']['claim_id']:r for r in read(BASE/'amr_raw.jsonl')}
    methods=['srl','amr'] if args.baselines_only else ['srl','amr','direct','assisted']
    raw={m:{r['request']['task']['claim_id']:r for i in [0,1] for r in read(run/f'{m}_{i}_raw.jsonl')} for m in methods if m in {'direct','assisted'}}
    rows=[]
    for method in methods:
        for record in inputs:
            cid=record['claim_id'];ref=refs.get(cid)
            row=dict(method=method,claim_id=cid,text=record['text'],cohort=record['cohort'],status='unsupported')
            try:
                if method=='srl':form=srl_form(record)
                elif method=='amr':form=amr_form(amrs[cid]['raw'],record['text'])
                else:form=strict_json(raw[method][cid]['raw'])
                row['proposal']=form
                claim=LogicalFormCompiler().compile(cid,record['text'],record['tokens'],form)
                e=Evidence('compilation_control',{v.name:['placeholder:'+v.name] for v in claim.variables},dict.fromkeys([v.name for v in claim.variables],True),{})
                p=ground(claim,e);program=prolog_program([p],learned=False)[0]
                from problog.program import PrologString
                list(PrologString(program))
                row.update(status='compiled',compilation=claim.to_dict(),program=program,program_syntax_valid=True)
                if ref:
                    row['semantic_checks']=checks(claim,ref)
                    row['requirements_pass']=all(x['passed'] for x in row['semantic_checks']) and not ref.get('expected_refusal')
                    row['uncertain_reference']=ref['uncertain']
            except Exception as error:
                row.update(code=getattr(error,'code',type(error).__name__),message=str(error))
                if ref:row['requirements_pass']=bool(ref.get('expected_refusal') and row['code'] in {ref['expected_refusal'],'parser_refusal'})
            rows.append(row)
    (run/'results.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    summary=dict(task='Original-claim compilation only; no rewriting or media verification',reference_cases=46,
                 reference_author='Codex assistant; not independent human gold',methods={},
                 input_sha256=hashlib.sha256((run/'inputs.jsonl').read_bytes()).hexdigest())
    for method in methods:
        selected=[r for r in rows if r['method']==method]
        summary['methods'][method]={}
        for group,ss in [('real',[r for r in selected if r['cohort'].startswith('real')]),('controls',[r for r in selected if r['cohort']=='constructed_contrast'])]:
            review=[r for r in ss if r['claim_id'] in refs and not refs[r['claim_id']]['uncertain']]
            summary['methods'][method][group]=dict(total=len(ss),compiled=sum(r['status']=='compiled' for r in ss),
                without_phrase_arguments=sum(r['status']=='compiled' and not r['compilation']['metadata']['uses_phrase_arguments'] for r in ss),
                diagnostic_cases=len(review),diagnostic_requirements_pass=sum(r.get('requirements_pass',False) for r in review),
                refusals=dict(Counter(r['code'] for r in ss if r['status']!='compiled')))
    (run/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
