"""A fixed parser-selection policy, independent of reference requirements."""

def select_attempt(attempts):
    """Prefer SRL without phrase arguments, then AMR, then partial SRL.

    This is a practical parsing policy, not a guarantee of semantic correctness.
    Neural logical-form generation stays a comparison, not an automatic fallback.
    """
    srl=attempts.get('srl',{})
    amr=attempts.get('amr',{})
    if srl.get('status')=='compiled' and not srl['compilation']['metadata']['uses_phrase_arguments']:
        return 'srl'
    if amr.get('status')=='compiled':return 'amr'
    return 'srl' if srl.get('status')=='compiled' else None
