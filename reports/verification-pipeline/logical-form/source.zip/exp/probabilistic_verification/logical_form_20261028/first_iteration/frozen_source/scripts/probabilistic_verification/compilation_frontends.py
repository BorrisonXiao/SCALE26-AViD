"""Small adapters from existing analyses to predicate/argument graphs."""
from __future__ import annotations
import json
import re


def srl_graph(record):
    """Use trained SRL spans/roles; syntax assists tense, polarity and coordination.

    No ARG0=agent convention is imposed. Argument phrases retain their content;
    source complements are propositions rather than independently asserted events.
    """
    import penman
    from .predicate_compilation import PredicateError
    data=record.get('srl')
    if not data:raise PredicateError('missing_srl','No cached trained-SRL output is available.')
    frames=[f for f in data['frames'] if f.get('args') and f.get('verb_span')]
    if not frames:raise PredicateError('missing_predicate','The trained SRL model returns no predicate with arguments.')
    words=data['words'];tokens=record.get('tokens',[])
    triples=[];entities={};event_ids={id(f):'e'+str(i+1) for i,f in enumerate(frames)}
    def concept(f):
        verb=f['verb'].lower()
        # Align by occurrence text rather than requiring equal tokenization.
        matches=[t for t in tokens if t['text'].lower()==verb]
        lemma=matches[0].get('lemma',verb) if matches else verb
        if lemma==verb and verb.endswith('ing'):
            from nltk.stem import SnowballStemmer
            stem=SnowballStemmer('english').stem(verb)
            if stem in {'shout','whistl','walk','hold','come','bring','cause'}:
                lemma={'whistl':'whistle'}.get(stem,stem)
        return re.sub(r'[^a-z0-9_-]','_',lemma.lower()) or 'predicate'
    embedded=set();source_ids=set()
    for f in frames:
        pred=concept(f);arg0=next((a['text'] for a in f['args'] if a['role']=='ARG0'),'')
        arg1=next((a['text'] for a in f['args'] if a['role']=='ARG1'),'')
        if pred=='read' and any(a['role']=='ARG3' for a in f['args']):arg0=arg1
        media=bool(re.search(r'\b(photo|photograph|image|imagery|video|footage|text|caption|screen)\w*\b',arg0,re.I))
        if pred in {'say','tell','state','report','mention','ask','claim'} or pred in {'show','depict','display','read'} and media:
            source_ids.add(id(f))
            for a in f['args']:
                if a['role']==('ARG3' if pred=='read' and any(x['role']=='ARG3' for x in f['args']) else 'ARG1'):
                    for child in frames:
                        if child is not f and a['start']<=child['verb_span'][0]<=a['end']:embedded.add(id(child))
    active=[f for f in frames if id(f) not in embedded]
    if not active:raise PredicateError('missing_predicate','No outer predicate remains after source scope.')
    for f in active:
        event=event_ids[id(f)];pred=concept(f);triples.append((event,':instance',pred))
        for a in f['args']:
            role=a['role'];phrase=a['text']
            if role=='ARGM-NEG':
                triples.append((event,':polarity','-'));continue
            if role in {'ARGM-MOD','ARGM-DIS'}:
                if role=='ARGM-MOD':raise PredicateError('unhandled_scope','A modal SRL frame requires an explicit scoped translation.')
                continue
            content_role='ARG3' if pred=='read' and any(x['role']=='ARG3' for x in f['args']) else 'ARG1'
            if id(f) in source_ids and role==content_role:
                triples.append((event,':'+content_role,json.dumps(phrase,ensure_ascii=False)));continue
            if pred=='be' and role in {'ARG2','ARG3'}:
                triples.append((event,':'+role,json.dumps(phrase,ensure_ascii=False)));continue
            if role in {'ARGM-MNR','ARGM-TMP','ARGM-ADV','ARGM-CAU','ARGM-PRP','ARGM-EXT'}:
                triples.append((event,':'+role,json.dumps(phrase,ensure_ascii=False)));continue
            if role=='ARG0' and phrase.lower().startswith('by '):phrase=phrase[3:]
            key=(a['start'],a['end'])
            if key not in entities:
                node='x'+str(len(entities)+1);entities[key]=node
                triples.extend([(node,':instance','entity'),(node,':surface',json.dumps(phrase,ensure_ascii=False))])
            triples.append((event,':'+role,entities[key]))
    if len(active)==1:top=event_ids[id(active[0])]
    else:
        anchors={f['verb_span'][0] for f in active}
        # Only clause-level coordination matters; argument-internal 'or' is not
        # promoted into a disjunction of assertions.
        operators={t['text'].lower() for t in tokens if t.get('deprel')=='cc' and
                   any(t.get('head')==u.get('id') and u['text'].lower() in {f['verb'].lower() for f in active} for u in tokens)}
        if len(operators&{'and','or'})>1:raise PredicateError('unhandled_scope','Mixed coordination needs a nested logical form.')
        top='root';triples.append((top,':instance','or' if 'or' in operators else 'and'))
        for i,f in enumerate(active,1):triples.append((top,':op'+str(i),event_ids[id(f)]))
    return penman.encode(penman.Graph(triples,top=top))
