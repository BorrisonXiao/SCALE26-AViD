#!/usr/bin/env python3
"""Frozen text-only generation of logical trees. No rewriting or verification."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
import importlib.metadata
from run_compilation_models import read, digest, append
import prompts_phase2 as P

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/logical_form_20261028'


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--method',choices=['direct','assisted'],required=True)
    parser.add_argument('--input',type=Path,default=RUN/'inputs.jsonl')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--shard',type=int,default=0);parser.add_argument('--shards',type=int,default=1)
    args=parser.parse_args();records=read(args.input)[args.shard::args.shards]
    done={r['request']['task']['claim_id'] for r in read(args.output)} if args.output.exists() else set()
    records=[r for r in records if r['claim_id'] not in done]
    if not records:return
    import torch
    from transformers import AutoTokenizer,Qwen3VLForConditionalGeneration
    torch.set_num_threads(4)
    path=Path('/exp/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct')
    tokenizer=AutoTokenizer.from_pretrained(path,local_files_only=True)
    model=Qwen3VLForConditionalGeneration.from_pretrained(path,local_files_only=True,dtype=torch.float16,
        attn_implementation='sdpa').to('cuda').eval()
    config=dict(method=args.method,model=str(path),modality='text_only',dtype='float16',
                transformers=importlib.metadata.version('transformers'),torch=torch.__version__,
                prompt_version=P.LOGICAL_FORM_PROMPT_VERSION,do_sample=False,max_new_tokens=1400,
                config_sha256=hashlib.sha256((path/'config.json').read_bytes()).hexdigest())
    args.output.parent.mkdir(exist_ok=True,parents=True)
    for record in records:
        messages=[dict(role='system',content=P.LOGICAL_FORM_SYSTEM),
                  dict(role='user',content=P.logical_form_user(record,args.method=='assisted'))]
        prompt=tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
        inputs=tokenizer(prompt,return_tensors='pt').to('cuda');started=time.perf_counter()
        with torch.inference_mode():output=model.generate(**inputs,do_sample=False,max_new_tokens=1400)
        ids=output[0,inputs.input_ids.shape[1]:];request=dict(task=record,config=config,messages=messages,prompt=prompt)
        append(args.output,dict(request=request,request_hash=digest(request),raw=tokenizer.decode(ids,skip_special_tokens=True),
                               output_tokens=len(ids),wall_seconds=time.perf_counter()-started,slurm_job_id=os.getenv('SLURM_JOB_ID')))
        print(args.method,record['claim_id'],len(ids),flush=True)

if __name__=='__main__':main()
