"""Check specified semantic requirements; not a complete semantic-equivalence test."""
import re
from .logical_form import lemma


def checks(claim, reference):
    from nltk.stem import SnowballStemmer
    stem=SnowballStemmer('english').stem
    def words(value):
        value=re.sub(r'protest(?:or|er)s?', 'protest', str(value).lower())
        return {stem(x) for x in re.findall(r'[a-z0-9]+',value)}
    md=claim.metadata;entities=md['entities'];events=md['events']
    def descriptor(name,seen=()):
        if name in seen:return ''
        if name in entities:
            e=entities[name];value=e['text']+' '+e.get('concept','')+' '+' '.join(str(p['value']) for p in e.get('properties',[]))
            for rel in e.get('relations',[]):
                target=next((k for k,v in entities.items() if v['id']==rel['target'] and v['scope']==e['scope']),None)
                if target:value+=' '+descriptor(target,seen+(name,))
            for a in claim.atoms:
                if a.kind=='relation' and name in a.arguments:value+=' '+a.predicate
            return value
        if name in events:return events[name]['predicate']+' '+' '.join(str(p['value']) for p in events[name].get('properties',[]))
        return name
    def contains(name,terms):return all(words(t)<=words(descriptor(name)) for t in terms)
    negated=set()
    def visit(e,negative=False):
        if e.op=='not':negative=not negative
        if e.op=='atom' and negative:negated.add(e.atom_id)
        for c in e.children:visit(c,negative)
    visit(claim.expression)
    candidates=[]
    for a in claim.atoms:
        if a.kind!='relation' or a.predicate!=reference['predicate']:continue
        event=a.arguments[0];data=events.get(event,{})
        route=data.get('route','world')
        if route!=reference['scope']:continue
        roles={};args=a.arguments[1:]
        for i in range(0,len(args)-1,2):
            if args[i] in {'sense','scope','content_scope','content_route','route'}:break
            roles[args[i]]=args[i+1]
        candidates.append((a,event,data,roles))
    result=[dict(check='predicate and evidence scope',passed=bool(candidates))]
    if not candidates:return result
    aliases={'location':['location','ARGM-LOC'],'destination':['destination','ARG4','ARGM-DIR','direction'],
             'participant':['ARG0','ARG1']}
    def role_score(candidate):
        _,_,_,rs=candidate
        return sum(any(r in rs and contains(rs[r],terms) for r in aliases.get(role,[role])) for role,terms in reference['roles'].items())
    a,event,data,roles=max(candidates,key=role_score)
    for role,terms in reference['roles'].items():
        passed=any(r in roles and contains(roles[r],terms) for r in aliases.get(role,[role]))
        result.append(dict(check='role '+role+' = '+' '.join(terms),passed=passed))
    if reference.get('temporal'):
        tf=md['temporal'].get(event,{})
        result.append(dict(check='tense/aspect '+str(reference['temporal']),passed=[tf.get('tense'),tf.get('aspect')]==reference['temporal']))
    expected_negative=reference['claim_id'] in {'contrast_09','contrast_16'}
    result.append(dict(check='polarity of target predicate',passed=(a.id in negated)==expected_negative))
    for holder,value,scope in reference.get('properties',[]):
        found=False
        for name,e in {**entities,**events}.items():
            if e.get('route')!=scope or not contains(name,[holder]):continue
            if not value:found=True;break
            # A modifier must be attached to the matching holder, rather than
            # appearing somewhere else in the whole sentence.
            values=[p['value'] for p in e.get('properties',[])]
            if any(words(value)<=words(v) for v in values):found=True;break
            if name in entities and any(words(value)<=words(descriptor(k)) for k,v in entities.items()
                   if k!=name and v['scope']==e['scope'] and any(r['target']==v['id'] for r in e.get('relations',[]))):
                found=True;break
            for atom in claim.atoms:
                if words(atom.predicate) <= words(value) and name in atom.arguments and atom.arguments[-1]==scope:
                    found=True;break
            if value.isdigit():
                for atom in claim.atoms:
                    if atom.kind=='relation' and name in atom.arguments and any(contains(x,[value]) for x in atom.arguments if x in entities):found=True
        result.append(dict(check='attached property: '+holder+' / '+value+' / '+scope,passed=found))
    if reference['claim_id']=='contrast_10':
        hugs=[x for x in claim.atoms if x.predicate=='hug'];waves=[x for x in claim.atoms if x.predicate=='wave']
        result.append(dict(check='same Alice in hug and wave',passed=bool(hugs and waves and hugs[0].arguments[2]==waves[0].arguments[2] and hugs[0].arguments[0]!=waves[0].arguments[0])))
    if reference['claim_id']=='TzF9M4kZ3Pys_289':
        result.append(dict(check='Haboob is not typed as a city',passed=not any(v.get('concept')=='city' and words('Haboob')<=words(v['text']) for v in entities.values())))
    return result
