"""Adapters to the common logical form. They never rewrite the input sentence."""
from __future__ import annotations
import json
import re
from .logical_form import VERSION, LogicalFormError, lemma


def amr_form(graph_text, text):
    import penman
    from penman.models.amr import model
    from .predicate_compilation import clean_graph, literal
    graphs=list(penman.iterdecode(clean_graph(graph_text or ''),model=model))
    if len(graphs)!=1:raise LogicalFormError('graph','Expected exactly one graph.')
    graph=graphs[0];concepts={x.source:x.target for x in graph.instances()}
    if len(concepts)!=len(graph.instances()):raise LogicalFormError('graph','Repeated concept declarations.')
    edges={x:[] for x in concepts}
    for s,r,t in graph.triples:
        if r!=':instance':edges[s].append((r[1:],t))
    tree=penman.parse(clean_graph(graph_text));decl={}
    def index(n):
        decl[n[0]]=n
        for _,t in n[1]:
            if isinstance(t,tuple):index(t)
    index(tree.node)
    def subtree(n,role):
        values=[t for r,t in decl.get(n,('',[]))[1] if r==':'+role]
        if len(values)!=1:return None
        return values[0][0] if isinstance(values[0],tuple) else values[0] if values[0] in concepts else None
    def descendants(n):
        if n not in decl:return set()
        return {n}|set().union(*(descendants(t[0]) for _,t in decl[n][1] if isinstance(t,tuple)))
    def name(n):
        if n not in concepts:return literal(n)
        roles=dict(edges[n]);name_id=roles.get('name')
        if name_id in concepts:
            return ' '.join(literal(t) for r,t in sorted(edges[name_id]) if re.fullmatch(r'op\d+',r))
        return literal(roles['surface']) if 'surface' in roles else lemma(concepts[n])
    events={n for n,c in concepts.items() if (re.search(r'-\d\d$',c) or any(re.fullmatch(r'ARG\d|ARGM-.+',r) or r=='domain' for r,_ in edges[n])) and lemma(c) not in {'and','or'}}
    sources={};embedded=set()
    for n in events:
        p=lemma(concepts[n]);roles=dict(edges[n]);actor=roles.get('ARG0',roles.get('source'));cr='ARG1'
        if p=='read' and 'ARG3' in roles:actor=roles.get('ARG1');cr='ARG3'
        media=bool(re.search(r'\b(photo|photograph|image|imagery|footage|video|text|caption|screen)\w*\b',name(actor),re.I)) if actor else False
        if p in {'say','tell','state','report','mention','ask','claim'} or media and p in {'show','depict','display','read'}:
            child=subtree(n,cr)
            if not child:raise LogicalFormError('source_content','Source content is not a structured graph.')
            route='visual_depiction' if p in {'show','depict','display'} else 'ocr_assertion' if p=='read' or actor and re.search(r'\b(text|caption|screen)\b',name(actor),re.I) else 'speech_assertion'
            sources[n]=(child,cr,route);embedded|=descendants(child)
    entities={};warnings=[]
    def entity(n):
        if n in entities:return n
        if n not in concepts:
            if not (str(n).startswith('"') or re.fullmatch(r'-?\d+(\.\d+)?',str(n))):
                raise LogicalFormError('unresolved_graph_reference','Undeclared graph argument: '+str(n))
            entities[n]={'id':n,'text':literal(n),'concept':'literal','detail':'decomposed'};return n
        roles=dict(edges[n]);data={'id':n,'text':name(n),'concept':lemma(concepts[n]),'detail':'decomposed','properties':[],'relations':[]};entities[n]=data
        if 'quant' in roles and roles['quant'] not in concepts:data['quantity']=literal(roles['quant'])
        if 'name' in roles:
            compact=lambda s:re.sub(r'[^a-z0-9]','',s.lower())
            if compact(data['text']) not in compact(text):
                raise LogicalFormError('name','A generated name is absent from the original sentence: '+data['text'])
        for role,target in edges[n]:
            if role in {'name','surface','wiki'} or role=='quant' and target not in concepts:continue
            if target in events:continue # Event relations are emitted as event conditions.
            if role in {'mod','degree'} and target in concepts and not edges[target]:
                data['properties'].append({'role':role,'value':name(target)})
            elif role.startswith('op'):
                raise LogicalFormError('entity_coordination','A coordinated/group referent needs a defined group interpretation.')
            elif target in concepts:
                data['relations'].append({'role':role,'target':entity(target)})
            else:data['properties'].append({'role':role,'value':literal(target)})
        # PENMAN normalizes :part-of to an incoming :part edge. Retain it.
        for source,relations in edges.items():
            for role,target in relations:
                if target==n and source not in events and role not in {'name','mod','wiki'} and not role.startswith('op'):
                    other=entity(source)
                    edge={'role':role+'-of','target':other}
                    if edge not in data['relations']:data['relations'].append(edge)
        return n
    def event(n,allowed):
        p=lemma(concepts[n]);roles={};properties=[]
        if p in {'want','try','believe','think','seem','appear','hope','plan','possible','recommend'}:
            raise LogicalFormError('scope','An intensional/modal frame needs a defined scoped translation.')
        for r,t in edges[n]:
            if r in {'polarity','wiki','mode','tense','aspect','surface'}:continue
            if n in sources and r==sources[n][1]:continue
            if r in {'mod','degree'}:
                properties.append({'role':r,'value':name(t)});continue
            if r in roles:raise LogicalFormError('roles','Duplicate predicate argument role.')
            if t in events:
                if t not in allowed or p not in {'cause','devastate'}:
                    raise LogicalFormError('event_scope','An event complement is not automatically asserted.')
                roles[r]='event:'+t
            else:roles[r]=entity(t)
        m=re.search(r'-(\d\d)$',concepts[n])
        node={'op':'event','id':n,'predicate':p,'arguments':roles,'properties':properties}
        if m:node['sense']=m[1]
        if n in sources:
            child,_,route=sources[n];node.update(content=scope(child),route=route)
        return {'op':'not','child':node} if ('polarity','-') in edges[n] else node
    def scope(root):
        members=descendants(root);local_embedded=set().union(*(descendants(sources[n][0]) for n in members if n in sources))
        allowed=(events & members)-local_embedded
        if not allowed:
            # Nominal event/location AMRs are valid occurrence descriptions.
            if lemma(concepts[root]) in {'earthquake','storm','flood','flooding','typhoon'} and any(r=='location' for r,_ in edges[root]):
                node={'op':'event','id':'occurrence_'+root,'predicate':'occur','anchor':'occurred',
                      'arguments':{'ARG1':entity(root)}}
                for r,t in edges[root]:
                    if r=='location':node['arguments']['location']=entity(t)
                return node
            return {'op':'entity','ref':entity(root)}
        consumed=set()
        def visit(n):
            if n in allowed:consumed.add(n);return event(n,allowed)
            if lemma(concepts.get(n,'')) in {'and','or'}:
                return {'op':lemma(concepts[n]),'children':[visit(t) for r,t in sorted(edges[n]) if re.fullmatch(r'op\d+',r)]}
            children=[event(x,allowed) for x in sorted(allowed)];consumed.update(allowed)
            return children[0] if len(children)==1 else {'op':'and','children':children}
        formula=visit(root);remaining=allowed-consumed
        if remaining:formula={'op':'and','children':[formula]+[event(x,allowed) for x in sorted(remaining)]}
        return formula
    formula=scope(graph.top)
    return {'version':VERSION,'entities':list(entities.values()),'formula':formula,'warnings':warnings}



def srl_form(record):
    """Translate trained SRL frames, recursively retaining source complements.

    Simple noun phrases expose their modifiers. Complex phrases remain marked
    partial, so a complete phrase is not scored as full binding decomposition.
    """
    data=record.get('srl') or {};words=data.get('words',[])
    frames=[f for f in data.get('frames',[]) if f.get('args')]
    if not frames:raise LogicalFormError('missing_srl','The trained SRL model returned no complete frame.')
    tokens=record.get('tokens',[]);entities={};warnings=[]
    normalize=lambda x:re.sub(r"\s+",'',x.lower().replace('’',"'"))
    offsets=[];position=0
    for word in words:
        offsets.append((position,position+len(normalize(word))));position=offsets[-1][1]
    token_offsets={};position=0
    for t in tokens:
        token_offsets[t['id']]=(position,position+len(normalize(t['text'])));position=token_offsets[t['id']][1]
    if ''.join(normalize(w) for w in words)!=''.join(normalize(t['text']) for t in tokens):
        raise LogicalFormError('alignment','SRL and source tokens do not align after whitespace normalization.')
    def selected(a):
        lo=offsets[a['start']][0];hi=offsets[a['end']][1]
        return [t for t in tokens if token_offsets[t['id']][0]<hi and token_offsets[t['id']][1]>lo]
    def entity(a):
        key='x'+str(a['start'])+'_'+str(a['end'])
        if key in entities:return key
        ts=[t for t in selected(a) if t['upos'] not in {'DET','ADP','PART','PUNCT'}]
        if not ts:raise LogicalFormError('argument','No content remains in the SRL argument.')
        ids={t['id'] for t in ts};roots=[t for t in ts if t['head'] not in ids]
        named=all(t['upos'] in {'PROPN','NUM'} for t in ts)
        head=roots[0] if len(roots)==1 else ts[-1]
        modifiers=[t for t in ts if t['head']==head['id'] and t['deprel'] in {'amod','acl'}]
        simple=len(ts)==len(modifiers)+1 or named
        surface=record['text'][min(t['start_char'] for t in ts):max(t['end_char'] for t in ts)]
        e={'id':key,'text':surface if named or not simple else head['text'],
           'concept':'entity' if named else head['lemma'],
           'detail':'decomposed' if simple else 'phrase',
           'properties':[{'role':'mod','value':t['text']} for t in modifiers]}
        if any(t['deprel']=='nummod' for t in ts) and not named:
            e['quantity']=' '.join(t['text'] for t in ts if t['deprel']=='nummod')
        entities[key]=e;return key
    def predicate(f):
        matched=[t for t in tokens if t['text'].lower()==f['verb'].lower()]
        candidate=matched[0].get('lemma',f['verb']) if len(matched)==1 else f['verb'].lower()
        from nltk.stem import WordNetLemmatizer
        return WordNetLemmatizer().lemmatize(candidate.lower(),'v')
    def scope(begin,end):
        active=[f for f in frames if begin<=f['verb_span'][0]<=end]
        nested=set();source_info={}
        for f in active:
            p=predicate(f);args={a['role']:a for a in f['args']}
            content_role='ARG3' if p=='read' and 'ARG3' in args else 'ARG1'
            actor=args.get('ARG1' if p=='read' and 'ARG3' in args else 'ARG0',{})
            media=bool(re.search(r'\b(photo|photograph|image|imagery|footage|video|text|caption|screen)\w*\b',actor.get('text',''),re.I))
            if p in {'say','tell','state','report','mention','ask','claim'} or media and p in {'show','depict','display','read'}:
                content=args.get(content_role)
                if not content:raise LogicalFormError('source','The source complement is missing.')
                route='visual_depiction' if p in {'show','depict','display'} else 'ocr_assertion' if p=='read' else 'speech_assertion'
                source_info[id(f)]=(content,route,content_role)
                nested.update(id(g) for g in active if g is not f and content['start']<=g['verb_span'][0]<=content['end'])
        outer=[f for f in active if id(f) not in nested]
        if not outer:
            return {'op':'entity','ref':entity({'start':begin,'end':end,'text':' '.join(words[begin:end+1])})}
        result=[]
        for f in outer:
            p=predicate(f);args={};props=[];negative=False
            for a in f['args']:
                role=a['role']
                if role=='ARGM-NEG':negative=True;continue
                if role=='ARGM-MOD':raise LogicalFormError('scope','A modal frame needs a scoped interpretation.')
                if role=='ARGM-DIS':continue
                if id(f) in source_info and role==source_info[id(f)][2]:continue
                args[role]=entity(a)
                markers=[t['text'] for t in selected(a) if t['upos']=='ADP']
                if markers and not (role=='ARG0' and [m.lower() for m in markers]==['by']):props.append({'role':'preposition:'+role,'value':' '.join(markers)})
            node={'op':'event','id':'e'+str(f['verb_span'][0]),'predicate':p,'anchor':f['verb'],
                  'arguments':args,'properties':props}
            if id(f) in source_info:
                content,route,_=source_info[id(f)];node.update(route=route,content=scope(content['start'],content['end']))
            result.append({'op':'not','child':node} if negative else node)
        if len(result)==1:return result[0]
        verbs={f['verb'].lower() for f in outer}
        operators={t['text'].lower() for t in tokens if t.get('deprel')=='cc' and any(t['head']==u['id'] and u['text'].lower() in verbs for u in tokens)}
        if len(operators & {'and','or'})>1:raise LogicalFormError('coordination','Mixed coordination needs an explicit nested scope.')
        return {'op':'or' if 'or' in operators else 'and','children':result}
    formula=scope(0,len(words)-1)
    return {'version':VERSION,'entities':list(entities.values()),'formula':formula,'warnings':warnings}
