"""Semantic invariants of the alternative graph front ends and compiler."""
import json
from pathlib import Path
import pytest
from probabilistic_verification.predicate_compilation import PredicateCompiler, PredicateError
from probabilistic_verification.logic import Evidence, canonical_key, ground

C=PredicateCompiler()

def compile(graph,text='Alice hugs Bob.'):
    return C.compile('example',text,graph)

def signature(c):
    names={v.name:v.description for v in c.variables}
    return sorted((a.predicate,tuple(names.get(x,x) for x in a.arguments)) for a in c.atoms)

def walk(e):
    return [e]+[x for c in e.children for x in walk(c)]

def test_inverse_role_and_shared_referent():
    a=compile('(h / hug-01 :ARG0 (a / Alice) :ARG1 (b / Bob))')
    b=compile('(a / Alice :ARG0-of (h / hug-01 :ARG1 (b / Bob)))')
    assert signature(a)==signature(b)
    c=compile('(r / and :op1 (h / hug-01 :ARG0 (a / Alice) :ARG1 (b / Bob)) :op2 (w / wave-01 :ARG0 a))')
    first=next(x for x in c.atoms if x.predicate=='hug').arguments
    second=next(x for x in c.atoms if x.predicate=='wave').arguments
    assert first[2]==second[2]
    assert len([v for v in c.variables if v.description=='alice'])==1


def test_negated_event_existence_stays_under_negation():
    c=compile('(h / hug-01 :polarity - :ARG0 (a / Alice) :ARG1 (b / Bob))')
    n=next(e for e in walk(c.expression) if e.op=='not')
    assert n.children[0].op=='exists' and n.children[0].variables==('E1',)


@pytest.mark.parametrize('g',[
    '(r / say-01 :ARG0 (n / narrator) :ARG1 (l / land-01 :ARG1 (s / spacecraft)))',
    '(r / read-01 :ARG1 (t / text) :ARG3 (l / land-01 :ARG1 (s / spacecraft)))',
    '(s / show-01 :ARG0 (p / photo) :ARG1 (b / building :ARG1-of (c / collapse-01)))'])
def test_source_content_not_asserted_in_world(g):
    c=compile(g)
    assert not any(a.predicate in {'land','collapse'} for a in c.atoms)
    assert c.metadata['source_contents']
    assert any('content:' in x for a in c.atoms for x in a.arguments)


@pytest.mark.parametrize('g',[
    '(a / Alice) (b / Bob)',
    '(h / hug-01 :ARG0 (h / Alice))',
    '(w / want-01 :ARG0 (a / Alice) :ARG1 (l / land-01 :ARG1 (s / spacecraft)))',
    '(a / appeal-02 :ARG0 (c / country) :ARG2 (a2 / aid-01 :ARG2 c))'])
def test_malformed_or_untranslated_scope_refused(g):
    with pytest.raises(PredicateError):compile(g)


def test_roles_enter_executable_evidence_identity():
    a=next(a for a in compile('(h / hug-01 :ARG0 (a / Alice) :ARG1 (b / Bob))').atoms if a.predicate=='hug')
    b=next(a for a in compile('(h / hug-01 :ARG1 (a / Alice) :ARG0 (b / Bob))').atoms if a.predicate=='hug')
    assert canonical_key('m',a,{},'visual')!=canonical_key('m',b,{},'visual')


def test_or_has_branch_local_witnesses():
    c=compile('(r / or :op1 (w / wave-01 :ARG0 (a / Alice)) :op2 (h / hug-01 :ARG0 (b / Bob)))')
    assert c.expression.op=='or'
    domains={v.name:['v:'+v.name] for v in c.variables if v.description!='alice'}
    p=ground(c,Evidence('m',domains,{v:True for v in domains},{}))
    assert any(x['predicate'].startswith('hug') for x in p.occurrences)
    assert not any(x['predicate'].startswith('wave') for x in p.occurrences)


def test_cached_trained_srl_written_content_scope():
    from probabilistic_verification.compilation_frontends import srl_graph
    r=json.loads((Path(__file__).parent/'fixtures/srl_read_scope.json').read_text())
    c=C.compile(r['claim_id'],r['text'],srl_graph(r),r['tokens'])
    assert [a.predicate for a in c.atoms if a.kind=='relation']==['read']
    scope=next(iter(c.metadata['source_contents'].values()))
    assert scope['route']=='ocr_assertion' and '1600' in scope['content']
    assert not any(a.predicate in {'reach','die','cause'} for a in c.atoms)


def test_duplicate_argument_role_is_not_silently_overwritten():
    with pytest.raises(PredicateError,match='duplicate core'):
        compile('(h / hug-01 :ARG0 (a / Alice) :ARG0 (b / Bob))')
