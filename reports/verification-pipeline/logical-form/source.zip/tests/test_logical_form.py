"""Meaning/scoping checks for the common explicit logical-form interface."""
import copy
import json
from pathlib import Path
import pytest
from probabilistic_verification.logical_form import LogicalFormCompiler, LogicalFormError
from probabilistic_verification.logical_form_adapters import amr_form,srl_form
from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground

COMPILER=LogicalFormCompiler()
FIXTURES={r['claim_id']:r for r in json.loads((Path(__file__).parent/'fixtures/semantic_compiler_cases.json').read_text())}


def compile_amr(graph,index=6,text=None):
    r=FIXTURES[f'contrast_{index:02d}']
    return COMPILER.compile('case',text or r['text'],([] if text else r['tokens']),amr_form(graph,text or r['text']))


def walk(e):return [e]+[n for c in e.children for n in walk(c)]


def test_recursive_source_content_has_a_source_event_in_its_evidence_key():
    c=compile_amr('(s / say-01 :ARG0 (n / narrator) :ARG1 (l / land-01 :ARG1 (v / spacecraft)))',15)
    say=next(a for a in c.atoms if a.predicate=='say')
    land=next(a for a in c.atoms if a.predicate=='land')
    assert 'speech_assertion' in land.arguments and say.arguments[0] in land.arguments
    assert 'world' not in land.arguments
    e=Evidence('m',{v.name:[v.name.lower()] for v in c.variables},dict.fromkeys([v.name for v in c.variables],True),{})
    p=ground(c,e)
    assert any('speech_assertion' in o.key and say.arguments[0].lower() in o.key for o in p.observations.values())


def test_embedded_negation_is_not_speaker_negation():
    c=compile_amr('(s / say-01 :ARG0 (n / narrator) :ARG1 (l / land-01 :polarity - :ARG1 (v / spacecraft)))',16)
    neg=next(e for e in walk(c.expression) if e.op=='not')
    assert neg.children[0].op=='exists'
    ids={e.atom_id for e in walk(neg) if e.op=='atom'}
    assert next(a for a in c.atoms if a.predicate=='land').id in ids
    assert next(a for a in c.atoms if a.predicate=='say').id not in ids
    assert next(a for a in c.atoms if a.predicate=='referent' and 'spacecraft' in a.arguments).id not in ids


def test_unlicensed_polarity_and_reversed_landing_roles_are_refused():
    with pytest.raises(LogicalFormError,match='polarity'):
        compile_amr('(h / hug-01 :polarity - :ARG0 (a / Alice) :ARG1 (b / Bob))')
    with pytest.raises(LogicalFormError,match='ARG1'):
        compile_amr('(l / land-01 :ARG0 (s / spacecraft) :ARG1 (m / moon))',2)


def test_canonical_inverse_entity_relation_is_not_an_independent_duplicate():
    c=compile_amr('(i / impact-01 :ARG0 (s / storm) :ARG1 (c / coast :part-of (p / state :name (n / name :op1 "Alaskan"))))',text='The storm impacted the Alaskan coast.')
    relations=[a for a in c.atoms if a.predicate=='entity_relation']
    assert len(relations)==1 and 'part' in relations[0].arguments
    assert any('Alaskan' in a.arguments for a in c.atoms)


def test_nominal_occurrence_and_location_compile():
    c=compile_amr('(e / earthquake :location (c / country :name (n / name :op1 "Myanmar")))',text='The earthquake occurred in Myanmar.')
    assert any(a.predicate=='occur' for a in c.atoms)
    assert any('Myanmar' in a.arguments for a in c.atoms)


def test_predicate_sense_is_executable_not_only_metadata():
    a=compile_amr('(h / hug-01 :ARG0 (a / Alice) :ARG1 (b / Bob))')
    b=compile_amr('(h / hug-02 :ARG0 (a / Alice) :ARG1 (b / Bob))')
    aa=next(x for x in a.atoms if x.predicate=='hug');bb=next(x for x in b.atoms if x.predicate=='hug')
    assert canonical_key('m',aa,{},'visual')!=canonical_key('m',bb,{},'visual')


def test_source_scopes_keep_reference_time_consistent():
    c=compile_amr('(s / say-01 :ARG0 (n / narrator) :ARG1 (l / land-01 :ARG1 (v / spacecraft)))',15)
    assert len([v for v in c.variables if v.kind=='context'])==1
    time=[a for a in c.atoms if a.kind=='temporal']
    assert len(time)==2 and {a.arguments[3] for a in time}=={'T0'}
    assert all(a.arguments[4]=='unspecified' for a in time)
    assert {x['aspect'] for x in c.metadata['temporal'].values()}=={'simple','perfect'}


def test_name_substitution_is_rejected():
    with pytest.raises(LogicalFormError,match='absent'):
        compile_amr('(h / hug-01 :ARG0 (a / person :name (n / name :op1 "Ada")) :ARG1 (b / Bob))')


def test_source_entity_content_is_decomposed_under_depiction():
    c=compile_amr('(s / show-01 :ARG0 (p / photo) :ARG1 (b / building :mod (c / collapsed)))',13)
    prop=next(a for a in c.atoms if a.predicate=='property')
    assert 'visual_depiction' in prop.arguments and 'world' not in prop.arguments


def test_trained_srl_ocr_scope_reaches_inner_predicate():
    r=json.loads((Path(__file__).parent/'fixtures/srl_read_scope.json').read_text())
    c=COMPILER.compile(r['claim_id'],r['text'],r['tokens'],srl_form(r))
    reach=next(a for a in c.atoms if a.predicate=='reach')
    assert 'ocr_assertion' in reach.arguments and 'world' not in reach.arguments


def test_branch_local_source_and_event_variables():
    c=compile_amr('(r / or :op1 (w / wave-01 :ARG0 (a / Alice)) :op2 (h / hug-01 :ARG0 (b / Bob) :ARG1 (c / Charlie)))',text='Alice waves or Bob hugs Charlie.')
    assert c.expression.op=='or'
    assert all(n.op=='exists' for n in c.expression.children)


def test_a_number_inside_a_name_is_not_a_count_but_dropped_two_is_rejected():
    c=compile_amr('(l / land-01 :ARG1 (s / spaceship :name (n / name :op1 "Apollo" :op2 11)) :location (m / moon))',0)
    assert any('Apollo 11' in a.arguments for a in c.atoms)
    with pytest.raises(LogicalFormError,match='counted group'):
        compile_amr('(l / land-01 :ARG1 (s / spacecraft) :location (m / moon))',18)


def test_inline_source_mention_is_logged_but_missing_name_is_not_invented():
    r=FIXTURES['contrast_02']
    form={'version':'logical-form-v1','entities':[{'id':'s','text':'spacecraft'}],
          'formula':{'op':'event','id':'l','predicate':'land','anchor':'landed','arguments':{'ARG1':'s','location':'moon'}}}
    c=COMPILER.compile('inline',r['text'],r['tokens'],form)
    assert c.metadata['uses_phrase_arguments'] and any('Inline argument' in w for w in c.warnings)
    form['formula']['arguments']['location']='unknown_person'
    with pytest.raises(LogicalFormError,match='not an exact source mention'):
        COMPILER.compile('bad',r['text'],r['tokens'],form)


def test_parser_selection_uses_only_compilation_and_phrase_flags():
    from probabilistic_verification.compilation_selection import select_attempt
    def row(phrase=False):return {'status':'compiled','compilation':{'metadata':{'uses_phrase_arguments':phrase}}}
    assert select_attempt({'srl':row(),'amr':row()})=='srl'
    assert select_attempt({'srl':row(True),'amr':row()})=='amr'
    assert select_attempt({'srl':row(True),'amr':{'status':'unsupported'}})=='srl'
    assert select_attempt({'srl':{'status':'unsupported'},'amr':{'status':'unsupported'}}) is None


def test_overlapping_srl_subject_mentions_share_the_noun_phrase_head():
    r=json.loads((Path(__file__).parent/'fixtures/srl_relative_participant.json').read_text())
    c=COMPILER.compile(r['claim_id'],r['text'],r['tokens'],srl_form(r))
    wear=next(a for a in c.atoms if a.predicate=='wear')
    walking=next(a for a in c.atoms if a.predicate=='walk')
    assert wear.arguments[2]==walking.arguments[2]


def test_nominal_parent_and_its_modifier_are_both_executable():
    c=compile_amr('(f / firework :location (d / distant-02))',text='Fireworks in the distance.')
    assert any(a.predicate=='referent' and 'firework' in a.arguments for a in c.atoms)
    distance=next(a for a in c.atoms if a.predicate=='distant')
    assert any(a.predicate=='entity_relation' and distance.arguments[0] in a.arguments and 'location' in a.arguments for a in c.atoms)


def test_attributive_source_cycle_is_refused_instead_of_asserting_its_content():
    with pytest.raises(LogicalFormError) as error:
        compile_amr('(v / victim :ARG1-of (c / claim-01))',text='An alleged victim.')
    assert error.value.code in {'source_content','source_scope_reference'}


@pytest.mark.parametrize('index,graph',[
    (9,'(h / hug-01 :polarity - :ARG0 (a / Alice) :ARG1 (b / Bob))'),
    (16,'(s / say-01 :ARG0 (n / narrator) :ARG1 (l / land-01 :polarity - :ARG1 (v / spacecraft)))')])
def test_scoped_program_executes_in_deepproblog_without_media(index,graph):
    from probabilistic_verification.backend import DeepProbLogVerifier
    c=compile_amr(graph,index)
    domains={v.name:['placeholder:'+v.name] for v in c.variables}
    p=ground(c,Evidence('syntax_check',domains,dict.fromkeys(domains,True),{}))
    result=DeepProbLogVerifier([p],learned=False).predict()[0]['distribution']
    assert result==pytest.approx({'supported':0.,'refuted':0.,'unknown':1.})
