#!/usr/bin/env python3
"""Frozen local text model -> constrained JSON; save every raw response.

Preparation/replay run on CPU. Generation requires the existing Qwen checkpoint.
No media, labels, review judgments or paired examples enter the parser input.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import time
from pathlib import Path

import prompts_phase2 as P
from probabilistic_verification.semantic import SCHEMA, SemanticCompiler, SemanticError

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "exp/probabilistic_verification/compilation_audit_20261028"
RUN = ROOT / "exp/probabilistic_verification/semantic_compiler_20261028"
MODEL = "/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507"


def read(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]


def write(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def prepare():
    reviews = read(AUDIT / "semantic_reviews.jsonl")
    current = {r["claim_id"]: r for r in read(AUDIT / "current_results.jsonl")}
    # The 79 already-reviewed development claims; parser refusals stay refusals.
    requests = [dict(claim_id=r["claim_id"], text=r["text"], tokens=current[r["claim_id"]].get("tokens", []),
                     sample=r["sample"], baseline_status=current[r["claim_id"]]["status"],
                     baseline_code=current[r["claim_id"]].get("code", "")) for r in reviews]
    write(RUN / "requests.jsonl", requests)
    from probabilistic_verification.parsing import DependencyParser
    parser = DependencyParser()
    texts = [
        "Apollo 11 landed on the moon.", "Apollo 11 is landing on the moon.",
        "The spacecraft landed on the moon.", "The spacecraft is landing on the moon.",
        "The spacecraft was landing on the moon.", "The spacecraft has landed on the moon.",
        "Alice hugs Bob.", "Bob is hugged by Alice.", "Bob hugs Alice.",
        "Alice does not hug Bob.", "Alice hugs Bob and waves.",
        "A gray car passes a red truck.", "A red car passes a gray truck.",
        "Photos show collapsed buildings.", "Buildings have collapsed.",
        "The narrator says the spacecraft has landed.", "The narrator says the spacecraft has not landed.",
        "The earthquake's impact was devastating.", "Two spacecraft landed on the moon.",
        "The spacecraft might land on the moon.", "She hugs Bob.",
    ]
    rows = [dict(claim_id=f"contrast_{i:02d}", text=text, tokens=parser.parse(text), sample="constructed_contrast") for i, text in enumerate(texts)]
    write(RUN / "contrasts.jsonl", rows)
    (RUN / "contrast_parser.json").write_text(json.dumps(parser.provenance, indent=2))


def generate(args):
    if args.backend == "transformers":
        return generate_transformers(args)
    from transformers import AutoTokenizer
    from vllm import LLM, SamplingParams
    from vllm.sampling_params import StructuredOutputsParams
    tasks = read(args.input)
    if args.shards > 1:
        tasks = tasks[args.shard::args.shards]
    if args.ids:
        wanted = set(args.ids.split(","))
        tasks = [r for r in tasks if r["claim_id"] in wanted]
    if args.limit:
        tasks = tasks[:args.limit]
    tokenizer = AutoTokenizer.from_pretrained(MODEL, local_files_only=True)
    config = dict(model_path=str(Path(MODEL).resolve()), tensor_parallel_size=args.tp,
                  max_model_len=12288, dtype="bfloat16", seed=42, enforce_eager=True,
                  vllm=importlib.metadata.version("vllm"), transformers=importlib.metadata.version("transformers"),
                  config_hashes={n: hashlib.sha256((Path(MODEL)/n).read_bytes()).hexdigest()
                                 for n in ("config.json", "tokenizer_config.json", "generation_config.json")},
                  prompt_version=P.SEMANTIC_PARSE_VERSION, schema=SCHEMA,
                  decoding=dict(temperature=0, max_tokens=6000, structured_outputs="json_schema"))
    pending = []
    old = {r["request_hash"]: r for r in read(args.output)} if Path(args.output).exists() else {}
    for task in tasks:
        if not task["tokens"]:
            continue
        messages = [dict(role="system", content=P.SEMANTIC_PARSE_SYSTEM),
                    dict(role="user", content=P.semantic_parse_user(task["text"], task["tokens"]))]
        prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        request = dict(task=task, config=config, messages=messages, prompt=prompt)
        request_hash = digest(request)
        if request_hash not in old:
            pending.append((request_hash, request))
    if not pending:
        print("No uncached requests.", flush=True)
        return
    llm = LLM(model=MODEL, tensor_parallel_size=args.tp, dtype="bfloat16", seed=42,
              max_model_len=12288, gpu_memory_utilization=.9, enforce_eager=True)
    params = SamplingParams(temperature=0, max_tokens=6000, structured_outputs=StructuredOutputsParams(json=SCHEMA))
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    for offset in range(0, len(pending), 8):
        batch = pending[offset:offset+8]
        started = time.time()
        outputs = llm.generate([r[1]["prompt"] for r in batch], params)
        elapsed = time.time() - started
        with Path(args.output).open("a") as f:
            for (key, request), response in zip(batch, outputs):
                completion = response.outputs[0]
                row = dict(request_hash=key, request=request, raw=completion.text,
                           finish_reason=completion.finish_reason, output_tokens=len(completion.token_ids),
                           batch_wall_seconds=elapsed, batch_size=len(batch), slurm_job_id=os.getenv("SLURM_JOB_ID"))
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        print(f"Saved {min(offset+8,len(pending))}/{len(pending)} new requests; batch {elapsed:.1f}s", flush=True)


def generate_transformers(args):
    """Existing 8B checkpoint, text only; works on available Volta GPUs.

    JSON is prompt-constrained, then checked strictly on CPU. No claim is
    credited as compiled merely because the model returned well-formed JSON.
    """
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM, Qwen3VLForConditionalGeneration
    model_path = MODEL if args.model=="text30b" else "/exp/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct"
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    config = dict(model_path=model_path, backend="transformers", modality="text_only", dtype="float16",
                  transformers=importlib.metadata.version("transformers"), torch=torch.__version__,
                  prompt_version=P.SEMANTIC_PARSE_VERSION,
                  config_hashes={n: hashlib.sha256((Path(model_path)/n).read_bytes()).hexdigest() for n in
                                 ("config.json", "generation_config.json", "tokenizer_config.json")},
                  decoding=dict(do_sample=False,max_new_tokens=4000,json_constraint="prompt_only; checked after generation"))
    tasks = read(args.input)
    if args.shards > 1:
        tasks = tasks[args.shard::args.shards]
    if args.ids:
        tasks = [r for r in tasks if r["claim_id"] in set(args.ids.split(","))]
    if args.limit:
        tasks = tasks[:args.limit]
    old = {r["request_hash"] for r in read(args.output)} if Path(args.output).exists() else set()
    torch.set_num_threads(4)
    if args.model=="text30b":
        config["device_map"]="balanced across allocated GPUs"
        config["allocated_gpus"]=torch.cuda.device_count()
        model=AutoModelForCausalLM.from_pretrained(model_path,local_files_only=True,dtype=torch.float16,
            attn_implementation="sdpa",device_map="balanced",max_memory={i:"28GiB" for i in range(torch.cuda.device_count())}).eval()
    else:
        model = Qwen3VLForConditionalGeneration.from_pretrained(model_path, local_files_only=True,
            dtype=torch.float16, attn_implementation="sdpa").to("cuda").eval()
    config['gpu_names']=[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
    for t in tasks:
        if not t["tokens"]:
            continue
        messages = [dict(role="system",content=P.SEMANTIC_PARSE_SYSTEM),
                    dict(role="user",content=P.semantic_parse_user(t["text"],t["tokens"]))]
        prompt = tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
        request = dict(task=t, config=config,messages=messages,prompt=prompt)
        key = digest(request)
        if key in old:
            continue
        inputs = tokenizer(prompt,return_tensors="pt").to("cuda")
        started=time.time()
        with torch.inference_mode():
            output=model.generate(**inputs,do_sample=False,max_new_tokens=4000)
        ids=output[0,inputs.input_ids.shape[1]:]
        row=dict(request_hash=key,request=request,raw=tokenizer.decode(ids,skip_special_tokens=True),
            finish_reason="length" if len(ids)>=4000 else "stop",output_tokens=len(ids),
            wall_seconds=time.time()-started,slurm_job_id=os.getenv("SLURM_JOB_ID"))
        Path(args.output).parent.mkdir(parents=True,exist_ok=True)
        with Path(args.output).open("a") as f:
            f.write(json.dumps(row,ensure_ascii=False)+"\n")
        print(t["claim_id"],len(ids),f"{row['wall_seconds']:.1f}s",flush=True)


def replay(args):
    rows = []
    for r in read(args.input):
        t = r["request"]["task"]
        out = dict(claim_id=t["claim_id"], text=t["text"], sample=t["sample"], request_hash=r["request_hash"])
        started=time.perf_counter()
        try:
            proposal = json.loads(r["raw"])
            claim = SemanticCompiler().compile(t["claim_id"], t["text"], t["tokens"], proposal)
            out.update(status="compiled", compilation=claim.to_dict())
        except (SemanticError, json.JSONDecodeError) as e:
            out.update(status="unsupported", code=getattr(e, "code", "invalid_json"), message=str(e))
        except Exception as e:
            import jsonschema
            if not isinstance(e, jsonschema.ValidationError):
                raise
            out.update(status="unsupported", code="schema", message=e.message)
        out["compile_seconds"]=time.perf_counter()-started
        rows.append(out)
    write(args.output, rows)
    from collections import Counter
    print(dict(Counter(r["status"] for r in rows)))
    print(dict(Counter(r.get("code", "compiled") for r in rows)))


if __name__ == "__main__":
    p = argparse.ArgumentParser(__doc__)
    p.add_argument("stage", choices=["prepare", "generate", "replay"])
    p.add_argument("--input", type=Path, default=RUN/"requests.jsonl")
    p.add_argument("--output", type=Path, default=RUN/"raw_v1.jsonl")
    p.add_argument("--limit", type=int)
    p.add_argument("--ids")
    p.add_argument("--tp", type=int, default=1)
    p.add_argument("--backend", choices=["vllm","transformers"],default="vllm")
    p.add_argument("--shard",type=int,default=0)
    p.add_argument("--shards",type=int,default=1)
    p.add_argument("--model",choices=["8b","text30b"],default="8b")
    args = p.parse_args()
    {"prepare": lambda: prepare(), "generate": lambda: generate(args), "replay": lambda: replay(args)}[args.stage]()
