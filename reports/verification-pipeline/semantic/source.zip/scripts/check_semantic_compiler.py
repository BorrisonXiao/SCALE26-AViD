#!/usr/bin/env python3
"""Replay hand-authored semantic fixtures and real DeepProbLog temporal tests.

This is a compiler/inference diagnostic. All media scores and event intervals
below are constructed controls. No perception model prediction is fabricated.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path

from probabilistic_verification.backend import DeepProbLogVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground, prolog_program
from probabilistic_verification.semantic import SemanticCompiler, SemanticError
from probabilistic_verification.temporal import temporal_evidence

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "exp/probabilistic_verification/semantic_compiler_20261028"


def run(output=RUN):
    fixtures=json.loads((ROOT/"tests/fixtures/semantic_compiler_cases.json").read_text())
    compiled,results={},[]
    for row in fixtures:
        try:
            c=SemanticCompiler().compile(row["claim_id"],row["text"],row["tokens"],row["proposal"])
            compiled[row["claim_id"]]=c
            results.append(dict(claim_id=c.claim_id,text=c.text,status="compiled",compilation=c.to_dict(),
                provenance="assistant-authored semantic representation; real cached Stanza parse; no LLM generation"))
        except SemanticError as e:
            results.append(dict(claim_id=row["claim_id"],text=row["text"],status="unsupported",code=e.code,message=str(e)))
    scenarios={
        "completed":dict(reading="episodic",start=0,end=5,reference=10,past_reference=2,completed=True,perfect_licensed=True),
        "ongoing":dict(reading="episodic",start=0,end=15,reference=10,past_reference=2,completed=False),
        "interrupted":dict(reading="episodic",start=0,end=5,reference=10,past_reference=2,completed=False),
        "unannotated":{},
    }
    programs,traces=[],[]
    for scenario,annotation in scenarios.items():
        for i in range(2,6):
            c=compiled[f"contrast_{i:02d}"]
            assignment={v.name: "narrative_context" if v.kind=="context" else v.name.lower() for v in c.variables}
            evidence=Evidence("constructed_"+scenario,{v:[value] for v,value in assignment.items()},dict.fromkeys(assignment,True),{},"visual_depiction")
            for a in c.atoms:
                if a.kind!="temporal":
                    key=canonical_key(evidence.media_id,a,assignment,evidence.route)
                    evidence.observations[key]=Observation(key,(1.,0.,0.),False,a.display(),dict(source="constructed control; not a media prediction"))
            augmented=temporal_evidence(c,evidence,{"narrative_context":{"e1":annotation}} if annotation else {})
            p=ground(c,augmented)
            p.claim_id+="_"+scenario
            programs.append(p)
            traces.append(dict(claim_id=p.claim_id,text=c.text,scenario=scenario,annotation=annotation,
                compilation=c.to_dict(),observations=[o.to_dict() for o in p.observations.values()],
                evidence=asdict(augmented),ground_program=asdict(p),
                evidence_status="constructed event times and non-temporal scores; actual CPU DeepProbLog inference"))
    predictions=DeepProbLogVerifier(programs,learned=False).predict()
    by_id={p["claim_id"]:p for p in predictions}
    for trace in traces:
        trace["prediction"]=by_id[trace["claim_id"]]
    code,names=prolog_program(programs,learned=False)
    output.mkdir(parents=True,exist_ok=True)
    (output/"fixture_results.json").write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n")
    (output/"temporal_traces.json").write_text(json.dumps(traces,ensure_ascii=False,indent=2)+"\n")
    (output/"temporal_program.pl").write_text(code)
    fingerprint={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
        sorted((ROOT/"scripts/probabilistic_verification").glob("*.py"))+[ROOT/name for name in
            ("tests/fixtures/semantic_compiler_cases.json","tests/fixtures/semantic_model_errors.json",
             "scripts/prompts_phase2.py","scripts/run_semantic_parser.py","scripts/analyze_semantic_compiler.py",
             "scripts/check_semantic_compiler.py","scripts/compile_verification_claim.py","tests/test_semantic_compiler.py",
             "requirements-verification.txt")]}
    (output/"implementation_fingerprints.json").write_text(json.dumps(fingerprint,indent=2)+"\n")
    print(f"Replayed {len(results)} fixtures; inferred {len(traces)} constructed temporal conditions")


if __name__=="__main__":
    p=argparse.ArgumentParser(__doc__)
    p.add_argument("--output",type=Path,default=RUN)
    run(p.parse_args().output)
