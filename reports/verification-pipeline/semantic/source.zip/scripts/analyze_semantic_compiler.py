#!/usr/bin/env python3
"""Recompute development compilation coverage from saved text-model outputs.

This measures checked compilation, not semantic accuracy or media verification.
Frozen audit sources and the reserved-source boundary are verified independently.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import time
import xml.etree.ElementTree as ET

from run_semantic_parser import ROOT, RUN, AUDIT, digest, read, write
from probabilistic_verification.semantic import SemanticCompiler, SemanticError


def compile_saved(task, record):
    import jsonschema
    started=time.perf_counter()
    try:
        c=SemanticCompiler().compile(task['claim_id'],task['text'],task['tokens'],json.loads(record['raw']))
        result=dict(status='compiled',compilation=c.to_dict(),
            representation='source content retained as text' if c.metadata['contents'] else 'decomposed world claim',
            normalizations=len(c.metadata['normalizations']))
    except (SemanticError,json.JSONDecodeError,jsonschema.ValidationError) as e:
        result=dict(status='unsupported',code=getattr(e,'code','invalid_json' if isinstance(e,json.JSONDecodeError) else 'schema'),message=str(e).split('\n')[0])
    return dict(result,compile_seconds=time.perf_counter()-started,request_hash=record['request_hash'])


def analyze(partial=False):
    import jsonschema
    input_hashes=RUN/'input_fingerprints.json'
    if input_hashes.exists():
        for name,expected in json.loads(input_hashes.read_text()).items():
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected, f"Experiment input changed: {name}"
    fingerprint=RUN/'implementation_fingerprints.json'
    if fingerprint.exists():
        for name,expected in json.loads(fingerprint.read_text()).items():
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected, f"Implementation fingerprint changed: {name}"
    shards=sorted(RUN.glob('raw_8b_v2_shard_*.jsonl'))
    # The distribution archive stores the canonical combined records rather
    # than redundant worker files. During generation, keep collecting workers.
    files=([RUN/'raw_v2_combined.jsonl'] if not shards and (RUN/'raw_v2_combined.jsonl').exists()
           else [RUN/'raw_8b_pilot_v2.jsonl']+shards)
    raw={}
    for path in files:
        if not path.exists():
            continue
        for r in read(path):
            assert digest(r["request"])==r["request_hash"], "Raw request hash changed"
            key=r["request"]["task"]["claim_id"]
            assert key not in raw, f"Duplicate generated claim {key}"
            assert r["request"]["config"]["prompt_version"]=="semantic-parse-v2"
            raw[key]=r
    tasks=read(RUN/"requests.jsonl")+read(RUN/"contrasts.jsonl")
    assert {r['claim_id'] for r in read(RUN/'requests.jsonl')}=={r['claim_id'] for r in read(AUDIT/'semantic_reviews.jsonl')}
    inventory={r["claim_id"]:r for r in read(AUDIT/"inventory.jsonl")}
    reserved=set(json.loads((ROOT/'exp/probabilistic_verification/pilot_20261015/reserved_videos.json').read_text()))
    baseline={r["claim_id"]:r for r in read(AUDIT/"current_results.jsonl")}
    outputs=[]
    for task in tasks:
        key=task["claim_id"]
        if key in inventory:
            assert inventory[key]["development_eligible"]
            assert not (set(inventory[key]['source_videos']) & reserved)
            assert hashlib.sha256(task["text"].encode()).hexdigest()==inventory[key]["text_sha256"]
            assert task["tokens"]==baseline[key].get("tokens",[])
        row=dict(claim_id=key,text=task["text"],sample=task["sample"],
                 baseline_status=task.get("baseline_status"),baseline_code=task.get("baseline_code"))
        if not task["tokens"]:
            row.update(status="parser_refusal",code="sentence_count",message="Unchanged Stanza wrapper declines multi-sentence input; no LLM call.")
        elif key not in raw:
            row.update(status="pending")
        else:
            r=raw[key]
            assert r["request"]["task"]["text"]==task["text"] and r["request"]["task"]["tokens"]==task["tokens"]
            row.update(compile_saved(task,r))
        outputs.append(row)
    assert set(raw)<=set(r["claim_id"] for r in tasks)
    if not partial:
        assert not any(r["status"]=="pending" for r in outputs), "Generation is not finished"
    summary=dict(scope="development comparison; compilation coverage is not semantic accuracy", selected_development=79,
        reserved_source_overlap=0, model="Qwen3-VL-8B-Instruct, frozen, text-only, float16, Transformers",
        cohorts={}, contrast_status=dict(Counter(r["status"] for r in outputs if r["sample"]=="constructed_contrast")),
        diagnostics=dict(Counter(r.get("code","compiled") for r in outputs if r["status"] not in {"pending","parser_refusal"})),
        requests_generated=len(raw),prompt_demonstration_claim="TInVWzp25aIM_13",
        generation_seconds=sum(r["wall_seconds"] for r in raw.values()),
        output_tokens=sum(r["output_tokens"] for r in raw.values()),
        compiler_seconds=sum(r.get("compile_seconds",0) for r in outputs),
        provenance="Exact raw prompts/outputs retained; text and parser inputs match frozen audit; no media/fact labels supplied.")
    for cohort in ("random","diagnostic","accepted_development"):
        rows=[r for r in outputs if r["sample"]==cohort]
        if not rows:  # Preserve actual cohort naming in the existing review file.
            continue
        summary["cohorts"][cohort]=dict(n=len(rows),baseline_compiled=sum(r["baseline_status"]=="compiled" for r in rows),
            status=dict(Counter(r["status"] for r in rows)),
            representation=dict(Counter(r.get("representation") for r in rows if r["status"]=="compiled")))
    dev=[r for r in outputs if r["sample"]!="constructed_contrast"]
    summary["development"]=dict(n=len(dev),baseline_compiled=sum(r["baseline_status"]=="compiled" for r in dev),
        status=dict(Counter(r["status"] for r in dev)),
        representation=dict(Counter(r.get("representation") for r in dev if r["status"]=="compiled")),
        accepted_with_normalization=sum(bool(r.get("normalizations")) for r in dev if r["status"]=="compiled"))
    summary["all_cohort_names"]=dict(Counter(r["sample"] for r in outputs))
    summary["pilot"]={}
    for version in ("v1","v2"):
        accepted=0
        for record in read(RUN/f"raw_8b_pilot_{version}.jsonl"):
            task=record["request"]["task"]
            try:
                SemanticCompiler().compile(task["claim_id"],task["text"],task["tokens"],json.loads(record["raw"]))
                accepted+=1
            except (SemanticError,json.JSONDecodeError,jsonschema.ValidationError):
                pass
        summary["pilot"][version+"_compiled"]=accepted
    xml=ET.parse(RUN/"tests.xml").getroot()
    suites=list(xml.iter("testsuite"))
    summary["tests"]={key:sum(int(e.attrib.get(key,0)) for e in suites) for key in ("tests","failures","errors","skipped")}
    diagnostic_path=RUN/'raw_30b_diagnostic_v2.jsonl'
    if diagnostic_path.exists():
        diagnostic_raw=read(diagnostic_path)
        diagnostic=[]
        for record in diagnostic_raw:
            assert digest(record['request'])==record['request_hash']
            task=record['request']['task']
            assert task['text']==baseline[task['claim_id']]['text'] and task['tokens']==baseline[task['claim_id']]['tokens']
            assert inventory[task['claim_id']]['development_eligible']
            diagnostic.append(dict(claim_id=task['claim_id'],text=task['text'],sample=task['sample'],**compile_saved(task,record)))
        if not partial:
            assert len(diagnostic)==7 and len({r['claim_id'] for r in diagnostic})==7
        write(RUN/'results_30b.jsonl',diagnostic)
        summary['diagnostic30b']=dict(n=len(diagnostic),status=dict(Counter(r['status'] for r in diagnostic)),
            representation=dict(Counter(r.get('representation') for r in diagnostic if r['status']=='compiled')),
            model='Qwen3-30B-A3B-Instruct-2507, frozen text model, float16, layers split across four V100s',
            generation_seconds=sum(r['wall_seconds'] for r in diagnostic_raw),
            scope='Seven purposively selected development diagnostics, same prompt and compiler; not comparable to the 79-claim coverage denominator.')
    source_path=RUN/'raw_8b_source_v3.jsonl'
    if source_path.exists():
        source_raw=read(source_path);source_results=[];without_cleanup=0
        for record in source_raw:
            assert digest(record['request'])==record['request_hash']
            task=record['request']['task']
            assert record['request']['config']['prompt_version']=='semantic-parse-v3'
            assert task['text']==baseline[task['claim_id']]['text'] and task['tokens']==baseline[task['claim_id']]['tokens']
            assert inventory[task['claim_id']]['development_eligible']
            source_results.append(dict(claim_id=task['claim_id'],text=task['text'],sample=task['sample'],**compile_saved(task,record)))
            try:
                SemanticCompiler(remove_unused_content_annotations=False).compile(task['claim_id'],task['text'],task['tokens'],json.loads(record['raw']))
                without_cleanup+=1
            except (SemanticError,json.JSONDecodeError,jsonschema.ValidationError):
                pass
        if not partial:
            assert {r['claim_id'] for r in source_results}=={'TjHepwuhkYFA_1000','TjHepwuhkYFA_1087','TjHepwuhkYFA_1088'}
        write(RUN/'results_source_v3.jsonl',source_results)
        summary['source_prompt_v3']=dict(n=len(source_results),status=dict(Counter(r['status'] for r in source_results)),
            compiled_without_unused_annotation_removal=without_cleanup,
            representation=dict(Counter(r.get('representation') for r in source_results if r['status']=='compiled')),
            generation_seconds=sum(r['wall_seconds'] for r in source_raw),
            scope='Three known development failures after adding synthetic source-scope examples; not an independent evaluation or new 79-claim coverage estimate.')
    write(RUN/"results.jsonl",outputs)
    write(RUN/"raw_v2_combined.jsonl",[raw[r["claim_id"]] for r in tasks if r["claim_id"] in raw])
    (RUN/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    p=argparse.ArgumentParser(__doc__);p.add_argument("--partial",action="store_true")
    analyze(p.parse_args().partial)
