"""Render the semantic compiler comparison from saved development artifacts."""
from __future__ import annotations

from collections import Counter
from html import escape as esc
import json
from pathlib import Path
import shutil
import textwrap
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/"exp/probabilistic_verification/semantic_compiler_20261028"
AUDIT=ROOT/"exp/probabilistic_verification/compilation_audit_20261028"
PREFIX="verification-pipeline/semantic/"


def load(name):
    return json.loads((RUN/name).read_text())


def read(name):
    return [json.loads(s) for s in (RUN/name).read_text().splitlines() if s.strip()]


def pre(value):
    return '<pre>'+esc(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2))+'</pre>'


def graph(compilation,figure,svg_dot,q):
    lines=[];index=0
    atoms={a['id']:a for a in compilation['atoms']}
    def visit(e):
        nonlocal index
        name='s'+str(index);index+=1
        if e['op']=='atom':
            a=atoms[e['atom_id']]
            label=textwrap.fill(a['predicate']+'('+', '.join(a['arguments'])+')',width=36,break_long_words=False)
            description='fixed temporal check' if a['kind']=='temporal' else 'frozen perception input (not run here)' if a['kind']=='entity' else 'relation-classifier input (not trained here)'
            label+='\n'+textwrap.fill(description,width=34)
            color='#f4e9cc' if a['trainable'] else '#fffefa'
        else:
            label=e['op'].upper()+(' '+', '.join(e['variables']) if e['variables'] else '')
            color='#dcece4'
        lines.append(name+' [label='+q(label)+',fillcolor='+q(color)+'];')
        for child in e['children']:
            c=visit(child);lines.append(name+' -> '+c+';')
        return name
    visit(compilation['expression'])
    return figure(svg_dot(lines,'Compiled semantic representation and verification factors'),
                  'New compiled structure. EXISTS binds a candidate referent/event; AND requires all children. Role labels, prepositions and the reference context are executable arguments. No real-media scores were obtained in this run. Scroll horizontally on a small screen.')


def build_semantic(table,figure,svg_dot,q,distribution):
    s=load('summary.json');rows=read('results.jsonl');reviews=load('reviews.json')
    by_id={r['claim_id']:r for r in rows}
    diagnostic=read('results_30b.jsonl') if (RUN/'results_30b.jsonl').exists() else []
    by_id_30b={r['claim_id']:r for r in diagnostic}
    source_v3=read('results_source_v3.jsonl') if (RUN/'results_source_v3.jsonl').exists() else []
    by_id_v3={r['claim_id']:r for r in source_v3}
    baseline={r['claim_id']:r for r in [json.loads(x) for x in (AUDIT/'current_results.jsonl').read_text().splitlines()]}
    d=s['development'];status=d['status'];compiled=status.get('compiled',0)
    body='<section class="panel" role="tabpanel" id="semantic-compiler" aria-labelledby="tab-semantic" hidden><h2>Compiler improvements: semantic roles, source scope and tense</h2>'
    body+='<p><strong>Development result:</strong> '+str(compiled)+' of 79 previously reviewed development claims now produce checked programs, compared with 20 for the original dependency compiler on these same claims. This is compilation coverage, <strong>not semantic accuracy</strong>. The model outputs and remaining meaning errors are shown below. The original 2,375-claim baseline and its source snapshot remain unchanged.</p>'
    body+='<p><strong>Recommendation:</strong> keep this compiler opt-in. The 8B parser is not ready to replace the baseline; improved representation and executable checks do not by themselves solve semantic parsing.</p>'
    body+='<p>Here, <code>compiled</code> and <code>unsupported</code> are compiler statuses. Unsupported means the representation was declined; it does not mean the media refute the claim. No factual verdict is assigned to these real claims.</p>'
    body+='<div class="download-row">'+''.join('<a href="'+PREFIX+name+'">'+label+'</a>' for name,label in [('source.zip','Source and CPU replay'),('summary.json','Counts and provenance'),('results.jsonl','All compiled/rejected outputs'),('raw_v2_combined.jsonl','Exact model prompts and responses'),('reviews.json','Assistant semantic reviews'),('temporal_traces.json','Temporal inference traces'),('temporal_program.pl','Executed DeepProbLog program'),('tests.xml','Regression checks')])+'</div>'
    body+='<h3>1. What changed</h3><p>A frozen language model proposes a semantic representation: referents, elementary events or states, semantic roles, source content, and logical operators. Deterministic Python code checks and compiles it. The text model does not decide factual support. It receives the claim and its existing dependency analysis, with no media or fact-check labels.</p>'
    body+=figure(svg_dot([
        'a [label="Original claim + cached dependency analysis"];',
        'b [label="Frozen text model → semantic representation"];',
        'c [label="Deterministic checks + logged grammatical repairs"];',
        'd [label="Predicates with complete role tuples + temporal conditions"];',
        'e [label="Candidate evidence assignments + typed observations"];',
        'f [label="Existing DeepProbLog backend → supported / refuted / unknown"];',
        'a -> b; b -> c; c -> d; d -> e; e -> f;'
    ],'Semantic analysis, compilation and evidence inference'),
    'The new work is semantic analysis and compilation. Real-media perception and feature-classifier training are not rerun. The temporal demonstration below supplies constructed observations to the existing backend.')
    body+=table(['Component','Implemented behavior','Limit'],[
        ['Semantic roles','A complete event tuple keeps the actor, affected entity and location together. Roles and prepositions enter evidence keys.','A small set of common frames is checked; arbitrary lexical semantics still requires review.'],
        ['Shared references and negation','Repeated mentions share a referent. Local negation contains event existence.','Quantification, unresolved pronouns, complex scope and some disjunctions are refused.'],
        ['Names and compounds','Numeric names can be retained; lexical compounds such as martial law troops stay together.','The model can still choose a wrong type or description.'],
        ['Source/content scope','A source binds to exact embedded text, evidence route and assertion/question/depiction act.','Embedded content is retained as text, not recursively decomposed. These cases are counted separately.'],
        ['Normalization','Recover attached auxiliaries/prepositions and punctuation. Remove unused inner annotations only after checking the complete source-content boundary. Every change is logged.','Referenced inner world predicates still cause rejection. Roles, predicates and content boundaries are not rewritten. Token coverage is not a meaning certificate.'],
        ['Temporal conditions','Read the complete auxiliary chain and emit an executable tense/aspect condition with an explicit reference-context candidate.','The fixed checker needs supplied episodic event-time annotations; real-video interval extraction is pending.']
    ],'Scope of the new compiler. “Checked” means that these structural conditions pass, not that the proposed meaning is correct.')
    body+='<h3>2. Coverage on the audited development claims</h3><p>The same 50 random, 20 diagnostic and 9 additional accepted claims are used. All exclude reserved source videos. The diagnostic and additional accepted sets are selected for analysis; pooling them does not estimate corpus accuracy. One random claim, the typhoon example, is a prompt demonstration and is explicitly not an independent check.</p>'
    body+=table(['Development cohort','Claims','Original compiler','New checked programs','Decomposed world claims','Source content retained as text','Rejected / parser refusal'],[
        [esc({'random':'Random sample','diagnostic':'Diagnostic sample','accepted_development':'Additional accepted baseline claims'}[name]),v['n'],v['baseline_compiled'],v['status'].get('compiled',0),v['representation'].get('decomposed world claim',0),v['representation'].get('source content retained as text',0),str(v['status'].get('unsupported',0))+' / '+str(v['status'].get('parser_refusal',0))] for name,v in s['cohorts'].items()
    ],'Measured compilation coverage on development claims only. No new pass over all 2,375 claims or held-out evaluation is claimed.')
    body+='<p>The practical fallback uses the existing <strong>Qwen3-VL-8B-Instruct checkpoint in text-only mode</strong>, float16, greedy decoding with Transformers. JSON is requested in the prompt and validated afterwards. It is not grammar-constrained decoding. The A100 request for the 30B text model was cancelled because its queue estimate was the next day; available V100s ran this comparison, at most four concurrently.</p>'
    resources=load('resource_usage.json')
    body+='<p>Measured allocation: peak '+str(resources['peak_concurrent_gpus'])+' V100 GPUs, '+f"{resources['allocated_gpu_hours']:.2f}"+' total GPU hours including loading and generation. All started jobs completed and none remain running or queued. <a href="'+PREFIX+'resource_usage.json">Resource records</a>.</p>'
    body+=table(['Prompt pilot','Checked programs / same four claims','Observed issue or change'],[
        ['Initial prompt',str(s['pilot']['v1_compiled'])+' / 4','Omitted modifiers and prepositions; wrong landing roles. Rejected proposals remain in the archive.'],
        ['Revised prompt',str(s['pilot']['v2_compiled'])+' / 4','Worked examples clarify role tuples, modifiers and word spans. Logged marker recovery retains missing auxiliaries/prepositions. The typhoon example is in the prompt.']
    ],'Development prompt iteration, replayed with the final deterministic compiler. Four examples do not establish generalization.')
    if diagnostic:
        ds=s['diagnostic30b']
        body+='<h4>Small comparison with the 30B text model</h4><p>The existing Qwen3-30B-A3B-Instruct-2507 model runs frozen in float16 with layers split across four V100s. It uses the <strong>same prompt and deterministic compiler</strong>. These seven claims were selected for known diagnostic issues, so their outcome cannot be compared with the 79-claim denominator as a coverage estimate.</p>'
        body+=table(['Diagnostic claim','8B output','30B output','Representation if compiled'],[
            [esc(r['text']),esc(by_id[r['claim_id']]['status']+' / '+by_id[r['claim_id']].get('code','checked')),esc(r['status']+' / '+r.get('code','checked')),esc(r.get('representation','—'))] for r in diagnostic
        ],'Paired development diagnostics using two frozen models and one compiler; no fact-checking or classifier training.')
        body+='<p><a href="'+PREFIX+'raw_30b_diagnostic_v2.jsonl">Exact 30B prompts and responses</a> · <a href="'+PREFIX+'results_30b.jsonl">All 30B compiled/rejected outputs</a>. '+str(ds['status'].get('compiled',0))+' of these '+str(ds['n'])+' proposals pass structural checks; the source/content and genitive examples still need semantic review as shown below.</p>'
    if source_v3:
        body+='<h4>Source-scope prompt revision</h4><p>Both models confused ordinary world predicates with source statements. A third prompt adds two synthetic worked examples: a photograph depicting a blue boat and a narrator saying that a ship landed. The model then produces source units, but still lists unused inner referents. The compiler removes these redundant annotations only after checking that the exact content covers the complete dependency complement. A referenced inner world predicate is still rejected. This combines a prompt revision and deterministic normalization; it is not a new evaluation set.</p>'
        body+=table(['Known source claim','8B, prompt 2','30B, prompt 2','8B, prompt 3'],[
            [esc(r['text']),esc(by_id[r['claim_id']]['status']),esc(by_id_30b.get(r['claim_id'],{}).get('status','not run')),esc(r['status']+' / '+r.get('code','checked'))] for r in source_v3
        ],'Targeted source-scope prompt revision. These three outcomes do not update the 79-claim coverage estimate.')
        body+='<p><a href="'+PREFIX+'raw_8b_source_v3.jsonl">Exact third-prompt requests and outputs</a> · <a href="'+PREFIX+'results_source_v3.jsonl">Checked source programs</a>. Without removal of unused inner annotations, '+str(s['source_prompt_v3']['compiled_without_unused_annotation_removal'])+' of these three proposals compile. The detailed examples below identify each prompt and every normalization.</p>'
    body+='<h3>3. Inspect the changed programs</h3><p>The following judgments compare text and logical forms. They are assistant reviews, not independent human annotations or media-support labels. Each example retains the raw model proposal and records any grammatical repair.</p>'
    for review in reviews['examples']:
        row=({'30b':by_id_30b,'8b-v3':by_id_v3}.get(review.get('model'),by_id))[review['claim_id']];old=baseline.get(row['claim_id'],{})
        model_label={'8b':'8B / prompt 2','30b':'30B / prompt 2','8b-v3':'8B / prompt 3'}.get(review.get('model'),'8B / prompt 2')
        body+='<details class="semantic-example"><summary>'+esc(row['text'])+' · '+model_label+' · '+esc(row['status'])+'</summary><p><strong>Review — '+esc(review['assessment'])+':</strong> '+esc(review['judgment'])+'</p>'
        body+='<p>Original compiler: '+esc(old.get('status','constructed contrast'))+'</p>'+pre(old.get('logical_form',old.get('message','')))
        if row['status']=='compiled':
            c=row['compilation'];body+='<p>New logical form:</p>'+pre(c['logical_form'])
            if review.get('draw'):
                body+=graph(c,figure,svg_dot,q)
            if c['metadata']['contents']:
                body+='<p><strong>Embedded content is not asserted as a world fact.</strong> A <code>content:</code> identifier refers to the exact text listed here:</p>'+pre(c['metadata']['contents'])
            if c['metadata']['normalizations']:
                body+='<p>Logged normalizations:</p>'+pre(c['metadata']['normalizations'])
            body+='<details><summary>Original semantic proposal and checked word spans</summary>'+pre(c['metadata']['original_proposal'])+pre(c['coverage'])+'</details>'
        else:
            body+=pre(row.get('code','')+': '+row.get('message',''))
        body+='</details>'
    body+='<h3>4. What the temporal predicates mean</h3><p><code>land(E1, theme, X1, location, X2, preposition, on)</code> asks about one event with one spacecraft and one location. <code>temporal(E1, past, simple, T0, required)</code> adds a past/simple condition and a completion requirement for this landing reading. <code>E1</code> is an event candidate, <code>X1</code>/<code>X2</code> are referent candidates, and <code>T0</code> is a caller-supplied discourse reference context. These are variables, not model probabilities. In the executable records, pres means present tense; simple, progressive and perfect name the aspect. A context ID enters the evidence key, so changing the reference time cannot silently reuse a score.</p><p>The four spacecraft forms produce distinct temporal predicates. The fixed checker covers a narrow episodic interval interpretation, with explicit start/end/reference times. An interval can end through interruption without completion. Perfect aspect also needs an explicit relevance/result-state annotation; past tense alone does not certify completion. Missing annotations yield unknown. This is separate from finding video time windows.</p>'
    traces=load('temporal_traces.json')
    body+='<p class="callout"><strong>Constructed control:</strong> all non-temporal observations below are fixed to support, and all event times are supplied by us. The probabilities are actual CPU DeepProbLog outputs. They are not predictions from real video or audio.</p>'
    body+=table(['Constructed event condition','Claim','Reference / past reference','DeepProbLog S / R / U'],[
        [esc(t['scenario']),esc(t['text']),str(t['annotation'].get('reference','missing'))+' / '+str(t['annotation'].get('past_reference','missing')),distribution(t['prediction']['distribution'])] for t in traces
    ],'Executable temporal checks for four claim forms under completed, ongoing, interrupted and unannotated evidence. S = supported, R = refuted, U = unknown.')
    body+='<p>A completed landing supports “landed” and can also support “was landing” at an earlier reference time. A tense swap therefore does not automatically define a false example. The same event identity and the intended reference context must be reviewed.</p>'
    body+='<h3>5. Checks, remaining failures and next actions</h3>'
    body+='<p>The word-coverage, semantic-role and temporal checks test the deterministic compiler with hand-authored semantic representations. That is separate from testing the text parser: in the generated 8B contrasts, the passive paraphrase, perfect landing clause and source statement can still be refused. Relation atoms declare an interface for small learned classifiers; no such classifier is trained in this run.</p>'
    body+=table(['Check','Measured result'],[
        ['Automated regression checks',str(s['tests']['tests'])+' passed, '+str(s['tests']['failures'])+' failures; includes original tests, active/passive equivalence, role/attribute changes, negation, source scope, numeric names and actual temporal DeepProbLog inference.'],
        ['Frozen baseline replay','4,721 original compiler outcomes replayed; 29 recorded parser refusals validated; original source hashes still match.'],
        ['Generated constructed contrasts',str(s['contrast_status'])+'; these are development diagnostics, not an independent benchmark.'],
        ['Generation work',str(s['requests_generated'])+' revised-prompt requests; '+str(s['output_tokens'])+' generated tokens; '+f"{s['generation_seconds']:.1f}"+' summed generation seconds across workers, excluding loading. This is not end-to-end wall time.'],
        ['Semantic correctness',esc(reviews['scope'])]
    ],'Validation and its limits. Compilation coverage, semantic correctness and factual support are separate outcomes.')
    body+='<ul>'+''.join('<li>'+esc(x)+'</li>' for x in reviews['remaining'])+'</ul>'
    body+='<p><a href="#next-steps">The checklist records completed compiler work and the remaining semantic review, parser repairs and held-out evaluation.</a> Feature-classifier training stays after these checks.</p>'
    body+='<h3>6. All 100 primary comparison cases</h3><p>These are 99 prompt-2 outputs and one recorded parser refusal. Alternative model/prompt conditions are linked separately above.</p><label>Find a claim <input id="semantic-search" type="search" placeholder="Claim text or ID"></label><p id="semantic-count" aria-live="polite"></p>'
    for r in rows:
        body+='<details class="semantic-case" data-semantic-search="'+esc((r['claim_id']+' '+r['text']).lower(),quote=True)+'"><summary>'+esc(r['claim_id'])+' · '+esc(r['status'])+' · '+esc(r['text'])+'</summary>'
        body+=pre(r['compilation']['logical_form'] if r['status']=='compiled' else r.get('code','')+': '+r.get('message',''))
        body+='</details>'
    return body+'</section>'


SEMANTIC_SCRIPT='''
const semanticSearch=document.getElementById('semantic-search');
function filterSemantic(){let n=0;const q=semanticSearch.value.toLowerCase();document.querySelectorAll('.semantic-case').forEach(e=>{e.hidden=!e.dataset.semanticSearch.includes(q);if(!e.hidden)n++;});document.getElementById('semantic-count').textContent=n+' cases shown';}
if(semanticSearch){semanticSearch.addEventListener('input',filterSemantic);filterSemantic();}
function centerSemanticDiagrams(){document.querySelectorAll('#semantic-compiler .diagram-scroll').forEach(e=>{if(e.clientWidth)e.scrollLeft=Math.max(0,(e.scrollWidth-e.clientWidth)/2);});}
document.querySelectorAll('.semantic-example').forEach(e=>e.addEventListener('toggle',()=>{if(e.open)centerSemanticDiagrams();}));
window.addEventListener('resize',centerSemanticDiagrams);
document.getElementById('tab-semantic')?.addEventListener('click',()=>setTimeout(centerSemanticDiagrams,0));
centerSemanticDiagrams();
'''


def write_downloads(output):
    target=output.parent/'verification-pipeline/semantic';target.mkdir(parents=True,exist_ok=True)
    names=['summary.json','results.jsonl','raw_v2_combined.jsonl','reviews.json','temporal_traces.json','temporal_program.pl','tests.xml','resource_usage.json']
    for name in names:
        shutil.copyfile(RUN/name,target/name)
    for name in ('raw_30b_diagnostic_v2.jsonl','results_30b.jsonl','raw_8b_source_v3.jsonl','results_source_v3.jsonl'):
        if (RUN/name).exists():
            shutil.copyfile(RUN/name,target/name)
    paths=list((ROOT/'scripts/probabilistic_verification').glob('*.py'))+[ROOT/'scripts'/name for name in
        ('run_semantic_parser.py','run_semantic_parser.slurm','check_semantic_compiler.py','analyze_semantic_compiler.py','build_semantic_compiler_report.py','compile_verification_claim.py','run_verification_pipeline.py','prompts_phase2.py')]
    paths += [ROOT/'requirements-verification.txt',ROOT/'docs/semantic_compiler.md',ROOT/'tests/fixtures/semantic_compiler_cases.json']
    paths += [ROOT/'tests/fixtures/semantic_model_errors.json']
    paths += [ROOT/'tests'/name for name in ('test_probabilistic_verification.py','test_multimodal_verification.py','test_semantic_compiler.py')]
    artifact_names=(
        'requests.jsonl','contrasts.jsonl','requests_30b_diagnostic.jsonl','contrast_parser.json',
        'raw_8b_pilot_v1.jsonl','raw_8b_pilot_v2.jsonl','raw_v2_combined.jsonl','raw_30b_diagnostic_v2.jsonl','raw_8b_source_v3.jsonl',
        'summary.json','results.jsonl','results_30b.jsonl','results_source_v3.jsonl','reviews.json','fixture_results.json',
        'temporal_traces.json','temporal_program.pl','tests.xml','implementation_fingerprints.json',
        'input_fingerprints.json','resource_usage.json','browser_checks.json')
    paths += [RUN/name for name in artifact_names if (RUN/name).exists()]
    paths += [AUDIT/'inventory.jsonl',AUDIT/'current_results.jsonl',AUDIT/'semantic_reviews.jsonl']
    paths += [ROOT/'exp/probabilistic_verification/pilot_20261015/reserved_videos.json']
    files={str(p.relative_to(ROOT)):p.read_bytes() for p in paths}
    files['README.md']=b'Install requirements-verification.txt. From the extracted root run python scripts/analyze_semantic_compiler.py (CPU compiler replay; no model or GPU required), python scripts/check_semantic_compiler.py (CPU DeepProbLog controls), and PYTHONPATH=scripts python -m pytest tests/test_semantic_compiler.py. Raw model outputs, exact prompts, parser inputs, code, constructed annotations and semantic reviews are included. This is a development comparison, not an independently annotated benchmark. See docs/semantic_compiler.md.\n'
    with zipfile.ZipFile(target/'source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for name,content in sorted(files.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,content)
