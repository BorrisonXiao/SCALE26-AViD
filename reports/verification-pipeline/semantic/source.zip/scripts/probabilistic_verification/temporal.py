"""Conservative temporal checks for explicitly supplied event-time annotations.

Times use one common, caller-defined coordinate system (for example seconds in
an annotated narrative). A reference is supplied by the caller, never the clock.
No video interval extraction is implemented here. Missing boundaries, habitual
readings and perfect relevance stay unknown rather than being guessed.
"""
from __future__ import annotations

from dataclasses import replace
import math

from .logic import Evidence, Observation, canonical_key, ground
from .multimodal import eligible_evidence


def temporal_status(condition, annotation):
    """Return S/R/U for this narrow interval interpretation, not all English tense."""
    if not annotation or annotation.get("reading") != "episodic":
        return "unknown"
    start, end = annotation.get("start"), annotation.get("end")
    reference = annotation.get("reference")
    for value in (start, end, reference, annotation.get("past_reference")):
        if value is not None and (not isinstance(value, (int, float)) or not math.isfinite(value)):
            raise ValueError("Temporal coordinates must be finite numbers or absent.")
    if start is not None and end is not None and end < start:
        raise ValueError("Event end precedes event start.")
    if reference is None:
        return "unknown"
    tense, aspect = condition["tense"], condition["aspect"]
    state = "unknown"
    if aspect in {"progressive", "perfect_progressive"}:
        point = annotation.get("past_reference") if tense == "past" else reference if tense == "pres" else None
        if point is not None:
            if tense == "past" and point >= reference:
                return "unknown"  # An invalid context is not contrary event evidence.
            if start is not None and point < start or end is not None and point >= end:
                state = "refuted"
            elif start is not None and start <= point and (end is not None and point < end or annotation.get("ongoing_at_reference") is True):
                state = "supported"
    elif tense == "past" and aspect == "simple":
        if end is not None and end <= reference:
            state = "supported"
        elif start is not None and start >= reference:
            state = "refuted"
    elif aspect == "perfect":
        # Perfect is not synonymous with completed: 'has lived here for years'.
        # Its relevance/result-state reading needs an explicit annotation.
        if start is not None and start >= reference:
            state = "refuted"
        elif start is not None and start < reference and annotation.get("perfect_licensed") is True:
            state = "supported"
    elif tense == "pres" and aspect == "simple" and annotation.get("state_at_reference") is not None:
        state = "supported" if annotation["state_at_reference"] is True else "refuted"
    if aspect == "perfect_progressive" and state == "supported" and annotation.get("perfect_licensed") is not True:
        state = "unknown"
    if condition["completion"] == "required":
        if annotation.get("completed") is False:
            return "refuted"
        if annotation.get("completed") is not True:
            return "unknown" if state != "refuted" else state
    return state


def temporal_evidence(claim, evidence: Evidence, annotations: dict) -> Evidence:
    """Attach fixed scores by grounded event ID and enforce declared route policy.

    Annotations are indexed by context candidate ID, then event candidate ID.
    Context IDs enter observation keys, so changing reference time cannot reuse
    the same temporal observation accidentally.
    Annotations are explicit metadata, not outputs inferred from the claim. Raw
neural scores cannot override temporal conditions. No annotations -> unknown.
The resulting Evidence can be passed to existing single/two-source grounding.
"""
    reference_variable=claim.metadata['reference_variable']
    contexts=evidence.domains.get(reference_variable,[])
    if len(contexts)>1:
        raise ValueError('Supply one interpretation of the discourse reference context per verification run.')
    if not contexts:
        # No reference interpretation is missing information, even if a caller
        # mistakenly labels the empty context inventory as exhaustively searched.
        evidence=replace(evidence,complete=dict(evidence.complete,**{reference_variable:False}))
    initial = ground(claim, evidence)
    observations = dict(evidence.observations)
    for occurrence in initial.occurrences:
        atom = next(a for a in claim.atoms if a.id == occurrence["atom_id"])
        if atom.kind != "temporal":
            continue
        event = atom.arguments[0]
        event_id = occurrence["assignment"].get(event)
        context_id = occurrence["assignment"].get(claim.metadata["reference_variable"])
        annotation = annotations.get(context_id, {}).get(event_id, {})
        condition = claim.metadata["temporal"][event]
        state = temporal_status(condition, annotation)
        distribution = tuple(float(s == state) for s in ("supported", "refuted", "unknown"))
        key = canonical_key(evidence.media_id, atom, occurrence["assignment"], evidence.route)
        observations[key] = Observation(key, distribution, False, atom.text,
            dict(source="explicit temporal metadata", annotation=annotation, condition=condition), bool(annotation))
    augmented = replace(evidence, observations=observations)
    return eligible_evidence(claim, augmented, {a: set(routes) for a, routes in claim.metadata["allowed_routes"].items()})
