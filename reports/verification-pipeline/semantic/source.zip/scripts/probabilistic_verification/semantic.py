"""A checked semantic representation and a deterministic compiler.

The frozen text model proposes a representation; it does not decide support.
This deliberately small fragment refuses unsupported scope and never falls back
to a whole-claim verification predicate. Structural checks are not a semantic
correctness certificate. The original dependency compiler remains unchanged.
"""
from __future__ import annotations

import hashlib
import json
import re
import copy
from dataclasses import dataclass, field

from .representation import Atom, CompiledClaim, Expression as E, Variable


def obj(properties):
    return dict(type="object", properties=properties, required=list(properties), additionalProperties=False)


def array(items):
    return dict(type="array", items=items)


def enum(*values):
    return dict(type="string", enum=list(values))


STRING = dict(type="string")
IDS = array(dict(type="integer", minimum=1))
ROLES = ("agent", "theme", "recipient", "experiencer", "location", "source", "goal",
         "instrument", "cause", "effect", "holder", "value", "part", "whole", "owner", "possession")
SCHEMA = obj({
    "status": enum("ok", "abstain"), "reason": STRING,
    "entities": array(obj({"id": STRING, "description": STRING,
        "kind": enum("person", "organization", "object", "place", "group", "event", "concept", "media"),
        "named": dict(type="boolean"), "mentions": array(IDS)})),
    "units": array(obj({"id": STRING, "kind": enum("event", "state", "relation", "source"),
        "predicate": STRING, "head": dict(type="integer", minimum=1), "token_ids": IDS,
        "roles": array(obj({"role": enum(*ROLES), "referent": STRING})),
        "negated": dict(type="boolean"), "completion": enum("required", "unspecified"),
        "content": obj({"route": enum("none", "visual_depiction", "speech_assertion", "ocr_assertion"),
            "act": enum("none", "depiction", "assertion", "question", "mention"), "token_ids": IDS})})),
    "operations": array(obj({"id": STRING, "op": enum("and", "or"), "inputs": array(STRING)})),
    "root": STRING, "function_words": IDS,
})


class SemanticError(ValueError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


@dataclass(frozen=True)
class SemanticClaim(CompiledClaim):
    version: str = "semantic-compiler-v2"
    metadata: dict = field(default_factory=dict)


def span_text(text, tokens, ids):
    selected = [t for t in tokens if t["id"] in ids]
    if not selected:
        return ""
    return text[min(t["start_char"] for t in selected):max(t["end_char"] for t in selected)]


def temporal_features(tokens, head):
    """Read the finite verb and its auxiliaries, not participial Tense alone."""
    by_id = {t["id"]: t for t in tokens}
    chain = [by_id[head]] + [t for t in tokens if t["head"] == head and t["deprel"].split(":")[0] in {"aux", "cop"}]
    feats = lambda t: dict(p.split("=", 1) for p in (t.get("feats") or "").split("|") if "=" in p)
    finite = [t for t in chain if feats(t).get("VerbForm") == "Fin"]
    tense = "unspecified"
    if finite:
        values = {feats(t).get("Tense", "unspecified").lower() for t in finite}
        if len(values) != 1:
            raise SemanticError("temporal", "Conflicting finite tenses in an auxiliary chain.")
        tense = values.pop()
    perfect = any(t["lemma"].lower() == "have" and t["id"] != head for t in chain)
    progressive = (any(feats(t).get("VerbForm") == "Part" and feats(t).get("Tense") == "Pres"
                       for t in chain) and any(t["lemma"].lower() == "be" for t in chain))
    # Non-finite caption fragments such as 'people walking'.
    progressive |= not finite and (feats(by_id[head]).get("VerbForm") == "Ger" or
                                  feats(by_id[head]).get("VerbForm") == "Part" and feats(by_id[head]).get("Tense") == "Pres")
    aspect = "perfect_progressive" if perfect and progressive else "perfect" if perfect else "progressive" if progressive else "simple"
    return dict(tense=tense, aspect=aspect, reference="context", token_ids=sorted(t["id"] for t in chain),
                finite=bool(finite))


class SemanticCompiler:
    def __init__(self, *, remove_unused_content_annotations=True):
        self.remove_unused_content_annotations=remove_unused_content_annotations

    def compile(self, claim_id, text, tokens, proposal):
        import jsonschema
        jsonschema.validate(proposal, SCHEMA)
        if proposal["status"] != "ok":
            raise SemanticError("parser_abstention", proposal["reason"])
        by_id = {t["id"]: t for t in tokens}
        original_proposal = proposal
        proposal = copy.deepcopy(proposal)
        # Recover only grammatical markers with an already declared semantic
        # attachment. Never repair roles, references, predicates or source scope.
        repairs, prepositions = [], {}
        entity_by_id = {e["id"]: e for e in proposal["entities"]}
        for u in proposal["units"]:
            added = set()
            for t in tokens:
                if t["head"] == u["head"] and t["deprel"].split(":")[0] in {"aux", "cop"}:
                    added.add(t["id"])
            for r in u["roles"]:
                if r["role"] not in {"location", "source", "goal", "instrument"} or r["referent"] not in entity_by_id:
                    continue
                mentions = {i for m in entity_by_id[r["referent"]]["mentions"] for i in m}
                markers = [t for t in tokens if t["upos"] == "ADP" and t["deprel"] == "case"
                           and t["head"] in mentions and by_id[t["head"]]["head"] == u["head"]]
                if markers:
                    prepositions.setdefault(u["id"], {})[r["role"]] = [t["text"].lower() for t in markers]
                    added.update(t["id"] for t in markers)
            for i in sorted(added):
                if i not in u["token_ids"] or i in proposal["function_words"]:
                    repairs.append(dict(unit=u["id"], token_id=i, word=by_id[i]["text"],
                        reason="Recover an auxiliary or an attached preposition; preserve it in temporal/role arguments."))
                if i not in u["token_ids"]:
                    u["token_ids"].append(i)
                if i in proposal["function_words"]:
                    proposal["function_words"].remove(i)
            u["token_ids"].sort()
        declared = set(proposal['function_words'])
        declared.update(i for e in proposal['entities'] for m in e['mentions'] for i in m)
        declared.update(i for u in proposal['units'] for i in u['token_ids']+u['content']['token_ids'])
        for token in tokens:
            if token['upos']=='PUNCT' and token['id'] not in declared:
                proposal['function_words'].append(token['id'])
                repairs.append(dict(unit=None,token_id=token['id'],word=token['text'],
                    reason='Account for unassigned punctuation; retain the exact source text and named-entity spelling.'))
        source_content=set()
        for unit in proposal['units']:
            if unit['kind']!='source':
                continue
            heads=[t['id'] for t in tokens if t['head']==unit['head'] and t['deprel'].split(':')[0] in {'obj','ccomp','xcomp'}]
            if len(heads)!=1:
                raise SemanticError('source_analysis','A source statement needs one checked content complement.')
            descendants={heads[0]}
            while True:
                expanded=descendants|{t['id'] for t in tokens if t['head'] in descendants}
                if expanded==descendants:
                    break
                descendants=expanded
            lexical={i for i in descendants if by_id[i]['upos']!='PUNCT'}
            proposed={i for i in unit['content']['token_ids'] if i in by_id and by_id[i]['upos']!='PUNCT'}
            if lexical!=proposed:
                raise SemanticError('source_scope','Source content must preserve its complete dependency complement, without outer words.')
            source_content.update(unit['content']['token_ids'])
        used={r['referent'] for u in proposal['units'] for r in u['roles']}
        retained=[]
        for entity in proposal['entities']:
            mention_ids={i for mention in entity['mentions'] for i in mention}
            if self.remove_unused_content_annotations and entity['id'] not in used and mention_ids and mention_ids<=source_content:
                repairs.append(dict(unit=None,entity=entity['id'],
                    reason='Remove an unused annotation inside retained source content; it introduces no world referent.'))
            else:
                retained.append(entity)
        proposal['entities']=retained
        entities = {e["id"]: e for e in proposal["entities"]}
        units = {u["id"]: u for u in proposal["units"]}
        operations = {o["id"]: o for o in proposal["operations"]}
        ids = [e["id"] for e in proposal["entities"]] + [u["id"] for u in proposal["units"]] + [o["id"] for o in proposal["operations"]]
        if not units or len(ids) != len(set(ids)) or any(not re.fullmatch(r"[A-Za-z0-9_-]+", x) for x in ids):
            raise SemanticError("identifiers", "Use unique IDs without spaces and at least one semantic unit.")
        coverage = {i: [] for i in by_id}
        content_ids = set()
        def mark(token_ids, label):
            if not token_ids or len(token_ids) != len(set(token_ids)) or not set(token_ids) <= by_id.keys():
                raise SemanticError("span", f"Invalid or empty token span: {label}")
            for i in token_ids:
                coverage[i].append(label)
        for u in units.values():
            mark(u["token_ids"], u["id"])
            if u["head"] not in u["token_ids"]:
                raise SemanticError("head", "A predicate head must occur in its word span.")
            content = u["content"]
            if u["kind"] == "source":
                if content["route"] == "none" or content["act"] == "none":
                    raise SemanticError("source", "A source statement needs a route and speech/depiction act.")
                mark(content["token_ids"], u["id"] + ":content")
                content_ids.update(content["token_ids"])
            elif content != dict(route="none", act="none", token_ids=[]):
                raise SemanticError("source", "Only source statements can contain embedded content.")
        for e in entities.values():
            if not e["mentions"] or not e["description"].strip():
                raise SemanticError("entity", "Each referent needs source mentions and a description.")
            mention_ids = set()
            for mention in e["mentions"]:
                mark(mention, e["id"])
                if any(by_id[i]['upos']!='PUNCT' and i not in mention for i in range(min(mention),max(mention)+1)):
                    raise SemanticError('span','A mention cannot skip lexical words inside its span.')
                mention_ids.update(mention)
            if mention_ids & content_ids:
                raise SemanticError("source_scope", "Embedded content cannot introduce unqualified world referents.")
            if all(by_id[i]["upos"] == "PRON" for i in mention_ids):
                raise SemanticError("reference", "A pronoun needs a claim-internal explicit antecedent.")
            if any(by_id[i]["upos"] == "NUM" for i in mention_ids):
                numeric_identifier = any(re.fullmatch(r"[A-Za-z][A-Za-z0-9]*-\d+", span_text(text, tokens, mention)) for mention in e["mentions"])
                if not e["named"] or not (any(by_id[i]["upos"] == "PROPN" for i in mention_ids) or numeric_identifier):
                    raise SemanticError("quantity", "Only numeric names are supported outside source content.")
            attributes = {"red", "blue", "gray", "grey", "green", "yellow", "black", "white", "massive", "damaged", "collapsed"}
            for i in mention_ids:
                if not e["named"] and by_id[i]["upos"] == "ADJ" and by_id[i]["lemma"].lower() in attributes:
                    if not any(u["kind"] == "state" and u["head"] == i and
                               any(r == {"role":"holder", "referent":e["id"]} for r in u["roles"]) for u in units.values()):
                        raise SemanticError("modifier_attachment", "An ordinary intersective attribute needs an explicit holder relation.")
        for u in units.values():
            if set(u["token_ids"]) & content_ids:
                raise SemanticError("source_scope", "A world predicate cannot lift words from embedded source content.")
            if u["kind"] == "source" and u["predicate"] not in {"show", "depict", "say", "tell", "read", "state", "ask", "mention", "report", "display"}:
                raise SemanticError("source", "Unsupported source predicate; ordinary claims cannot be hidden as content.")
            if u["kind"] != "source" and u["predicate"] in {"say", "tell", "claim", "report", "mention", "believe", "think", "want", "try", "begin", "seem", "appear"}:
                raise SemanticError("scope", "Reporting and intensional predicates require explicit scope.")
            if u["kind"] != "source" and u["predicate"] in {"show", "depict", "display", "read", "state", "ask"}:
                media_words = {"photo", "image", "imagery", "video", "footage", "text", "caption", "transcript"}
                for r in u["roles"]:
                    entity = entities.get(r["referent"])
                    if entity and (entity["kind"] == "media" or any(by_id[i]["lemma"].lower() in media_words for m in entity["mentions"] for i in m)):
                        raise SemanticError("source_scope", "A media source must bind to scoped content, not an unqualified world predicate.")
            if u["kind"] == "event" and by_id[u["head"]]["upos"] not in {"VERB", "AUX"}:
                raise SemanticError("predicate_analysis", "Event head is not analyzed as a verb; a checked parse repair is needed.")
            if u["kind"] == "event" and u["predicate"].split("_")[0] != by_id[u["head"]]["lemma"].lower():
                raise SemanticError("predicate_anchor", "An event predicate must retain its source verb lemma.")
        for i in proposal["function_words"]:
            if i not in by_id or not (by_id[i]["upos"] == "PUNCT" or by_id[i]["text"].lower() in {"a", "an", "the"}):
                raise SemanticError("function_word", "Only articles and punctuation may be ignored.")
            coverage[i].append("function")
        if any(not labels for labels in coverage.values()):
            missing = [by_id[i]["text"] for i, labels in coverage.items() if not labels]
            raise SemanticError("coverage", "Unaccounted words: " + ", ".join(missing))
        # These operators cannot be buried in a referent description or unit span.
        forbidden = {"all", "every", "each", "most", "some", "any", "no", "nothing", "nobody", "none", "neither", "without", "if", "unless", "before", "after", "during",
                     "while", "may", "might", "could", "would", "should", "must", "will", "can", "only", "potentially"}
        for t in tokens:
            if t["id"] not in content_ids and t["text"].lower() in forbidden:
                raise SemanticError("scope", f"Unsupported scope operator: {t['text']}")
            if t["id"] not in content_ids and t["lemma"].lower() == "not" and not any(t["id"] in u["token_ids"] and u["negated"] for u in units.values()):
                raise SemanticError("negation", "Negation cannot be hidden in a referent or an unrelated unit.")
        atoms, variables, temporal, contents, policies = [], [], {}, {}, {}
        names = {key: f"X{i}" for i, key in enumerate(entities, 1)}
        for key, e in entities.items():
            if e["kind"] == "concept":
                # Abstract values are literal predicate arguments, not physical candidates.
                names[key] = "concept:" + e["description"].lower()
            else:
                variables.append(Variable(names[key], "entity", e["description"], tuple(sorted({i for m in e["mentions"] for i in m}))))
        def atom(predicate, arguments, kind, roles, description, token_ids, trainable, routes):
            a = Atom("a" + str(len(atoms) + 1), predicate, tuple(arguments), kind, tuple(roles), description, tuple(token_ids), trainable)
            atoms.append(a)
            policies[a.id] = sorted(routes)
            return E.atom(a.id)
        exprs, refs = {}, {}
        for index, (key, u) in enumerate(units.items(), 1):
            roles = sorted(u["roles"], key=lambda r: ROLES.index(r["role"]))
            if not roles or len({r["role"] for r in roles}) != len(roles) or any(r["referent"] not in entities for r in roles):
                raise SemanticError("roles", "Roles must be unique and refer to declared entities.")
            if not re.fullmatch(r"[a-z][a-z0-9_]*", u["predicate"]):
                raise SemanticError("predicate", "Use a lowercase predicate lemma.")
            role_map = {r["role"]: entities[r["referent"]] for r in roles}
            if u["kind"] == "state" and by_id[u["head"]]["upos"] == "ADJ":
                if set(role_map) != {"holder"}:
                    raise SemanticError("property_roles", "An adjectival property needs exactly one holder.")
                token = by_id[u["head"]]
                if token["deprel"] == "amod":
                    attached = [e["id"] for e in entities.values() if any(token["head"] in mention for mention in e["mentions"])]
                    if attached and roles[0]["referent"] not in attached:
                        raise SemanticError("modifier_attachment", "Property holder conflicts with its explicit noun attachment.")
            if u["predicate"] in {"in", "on", "at", "under", "behind", "near", "beside", "above", "below"}:
                if "location" not in role_map or not ({"holder", "theme"} & role_map.keys()) or len(roles)<2:
                    raise SemanticError("relation_arguments", "A location relation needs both the located referent and the location.")
            frames = {"land": ({"theme"}, {"theme", "location"}),
                      "occur": ({"theme"}, {"theme", "location"}),
                      "receive": ({"recipient", "theme"}, {"recipient", "theme", "source"}),
                      "cause": ({"cause", "effect"}, {"cause", "effect"}),
                      "effect_of": ({"cause", "effect"}, {"cause", "effect"})}
            if u["predicate"] in frames:
                required, allowed = frames[u["predicate"]]
                if not required <= role_map.keys() or not role_map.keys() <= allowed:
                    raise SemanticError("role_frame", f"Unsupported role frame for {u['predicate']}; required={sorted(required)}, allowed={sorted(allowed)}")
            if u["predicate"] == "possess" and role_map.get("owner", {}).get("kind") not in {"person", "organization", "group"}:
                raise SemanticError("genitive", "An arbitrary genitive does not establish literal ownership.")
            negation = [t for t in tokens if t["id"] in u["token_ids"] and t["lemma"].lower() in {"not", "never"}]
            if bool(negation) != u["negated"] or any(t["lemma"].lower() == "never" for t in negation):
                raise SemanticError("negation", "Preserve explicit local 'not'; 'never' requires unsupported temporal quantification.")
            event = "E" + str(index)
            variables.append(Variable(event, "event", u["predicate"], tuple(u["token_ids"])))
            arguments = [event]
            argument_roles = ["event"]
            # Role labels are executable arguments: agent-only and theme-only
            # tuples cannot collide in the existing observation-key function.
            for r in roles:
                arguments.extend([r["role"], names[r["referent"]]])
                argument_roles.extend(["role", r["role"]])
                for preposition in prepositions.get(key, {}).get(r["role"], []):
                    arguments.extend(["preposition", preposition])
                    argument_roles.extend(["marker", "preposition"])
            routes = {"visual_depiction", "non_speech_sound"}
            description = span_text(text, tokens, u["token_ids"])
            if u["kind"] == "source":
                if len(roles) != 1 or roles[0]["role"] != "source":
                    raise SemanticError("source", "Source statements bind exactly one source to their complete content.")
                content = u["content"]
                if (content["route"] == "visual_depiction") != (content["act"] == "depiction"):
                    raise SemanticError("source_act", "Depiction and assertion/question routes have different meanings.")
                if u["predicate"] == "ask" and content["act"] != "question":
                    raise SemanticError("source_act", "Asking a question does not assert its content.")
                content_text = span_text(text, tokens, content["token_ids"])
                # Require a contiguous content region: no dropping inconvenient words.
                if sorted(content["token_ids"]) != list(range(min(content["token_ids"]), max(content["token_ids"]) + 1)):
                    raise SemanticError("source_scope", "Embedded content must retain a contiguous exact word span.")
                cid = "content:" + hashlib.sha256(content_text.encode()).hexdigest()[:20]
                contents[cid] = dict(text=content_text, **content)
                arguments.extend(["route", content["route"], "act", content["act"], "content", cid])
                argument_roles.extend(["marker", "route", "marker", "act", "marker", "content"])
                routes = {content["route"]}
                description += ": " + content_text
            unit_expr = atom(u["predicate"], arguments, "relation", argument_roles,
                             description, u["token_ids"], True, routes)
            tf = temporal_features(tokens, u["head"])
            if set(tf["token_ids"]) - set(u["token_ids"]):
                raise SemanticError("temporal", "Predicate span must include its full auxiliary chain.")
            if u["completion"] == "required" and (tf["aspect"] in {"progressive", "perfect_progressive"} or u["negated"]):
                raise SemanticError("completion", "Progressive/negative claims cannot require a completed positive event.")
            tf["completion"] = u["completion"]
            temporal[event] = tf
            if tf["tense"] != "unspecified" or tf["aspect"] != "simple" or u["completion"] == "required":
                args = [event, tf["tense"], tf["aspect"], "T0", u["completion"]]
                time_expr = atom("temporal", args, "temporal", ["event", "tense", "aspect", "reference", "completion"],
                                 json.dumps(tf, sort_keys=True), tf["token_ids"], False, routes)
                unit_expr = E.combine("and", [unit_expr, time_expr])
            unit_expr = E.exists([event], unit_expr)
            exprs[key] = E.negate(unit_expr) if u["negated"] else unit_expr
            refs[key] = {r["referent"] for r in roles}
        used = set()
        def build(key, visiting=()):
            if key in visiting or key in used:
                raise SemanticError("formula", "The formula must be an acyclic tree without reused subexpressions.")
            used.add(key)
            if key in units:
                return exprs[key], refs[key], key
            if key not in operations or len(operations[key]["inputs"]) < 2:
                raise SemanticError("formula", "Unknown formula node or fewer than two children.")
            o = operations[key]
            children = [build(x, visiting + (key,)) for x in o["inputs"]]
            return E.combine(o["op"], [c[0] for c in children]), set.union(*(c[1] for c in children)), key
        root, _, _ = build(proposal["root"])
        if used != set(units) | set(operations):
            raise SemanticError("formula", "Every unit and operation must contribute to the root.")
        entity_uses = {e: set(k for k in units if e in refs[k]) for e in entities}
        if any(not values for values in entity_uses.values()):
            raise SemanticError("reference", "Unused referents are not allowed.")
        # Bind a shared referent at the lowest formula node containing all uses.
        # Referents presupposed by a locally negated event stay outside its NOT.
        def bind(key, remaining):
            o = operations.get(key)
            child_sets = [] if o is None else [descendants(c) for c in o["inputs"]]
            local, delegated = [], [set() for _ in child_sets]
            for e in remaining:
                targets = [i for i, s in enumerate(child_sets) if entity_uses[e] <= s]
                if len(targets) == 1:
                    delegated[targets[0]].add(e)
                else:
                    local.append(e)
            expression = exprs[key] if o is None else E.combine(o["op"], [bind(c, delegated[i]) for i, c in enumerate(o["inputs"])])
            presence, bound = [], []
            for e in sorted(local, key=lambda x: list(entities).index(x)):
                item = entities[e]
                if item["kind"] == "concept":
                    continue
                bound.append(names[e])
                routes = set().union(*(set(policies[a.id]) for a in atoms if any(names[e] == arg for arg in a.arguments)))
                presence.append(atom("referent", [names[e], item["kind"], item["description"].lower()], "entity",
                    ["referent", "type", "description"], item["description"], sorted({i for m in item["mentions"] for i in m}), False, routes))
            return E.exists(bound, E.combine("and", presence + [expression]))
        def descendants(key):
            return {key} if key in units else set.union(*(descendants(c) for c in operations[key]["inputs"]))
        for o in operations.values():
            if o["op"] == "or":
                branches = [descendants(c) for c in o["inputs"]]
                for uses in entity_uses.values():
                    n = sum(bool(uses & branch) for branch in branches)
                    if 1 < n < len(branches):
                        raise SemanticError("disjunction_scope", "A partially shared referent needs branch-specific existential scope.")
        expression = bind(proposal["root"], set(entities))
        if any(a.kind == "temporal" for a in atoms):
            variables.append(Variable("T0", "context", "Caller-supplied discourse reference time", ()))
            expression = E.exists(["T0"], expression)
        return SemanticClaim(claim_id, text, tuple(tokens), tuple(variables), tuple(atoms), expression,
            tuple(dict(token_id=i, text=by_id[i]["text"], uses=labels) for i, labels in coverage.items()),
            warnings=("Semantic proposals require review; token coverage alone does not establish meaning preservation.",),
            metadata=dict(proposal=proposal, original_proposal=original_proposal, normalizations=repairs,
                          prepositions=prepositions, temporal=temporal, reference_variable="T0", contents=contents, allowed_routes=policies,
                          temporal_reference="Discourse context; never the machine clock.",
                          embedded_content="Exact source content is retained as a proposition argument, not recursively compiled."))
