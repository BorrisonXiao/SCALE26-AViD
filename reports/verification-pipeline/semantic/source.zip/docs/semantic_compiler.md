# Semantic compiler development — 28 October 2026

The original `ClaimCompiler` and its 2,375-claim audit remain frozen. The new
`SemanticCompiler` consumes a semantic representation proposed by a frozen text
model. This is a development comparison, not a factual verification benchmark.

## Inputs and compilation

The representation contains explicit referents with word spans, elementary
events/states/relations with complete semantic role tuples, and conjunction or
disjunction over these units. Repeated references use the same referent ID.
The deterministic compiler validates IDs, spans, word coverage, role references,
formula structure, local negation and a few common predicate frames. Unsupported
quantities, modality, unresolved pronouns and temporal connectives are refused.
Coverage is a structural check; an incorrect relation can still pass it.
The compiler records narrow grammatical repairs: a missing auxiliary or an
attached preposition can be recovered only when the declared semantic attachment
is already present. Unassigned punctuation can be accounted for without changing
the source spelling. Prepositions enter the complete tuple, so on/in do not
collapse. These repairs do not change roles, references or source-content scope.
For source statements, the content must cover one complete dependency complement.
Unused entity annotations entirely inside that content can be removed from the
outer entity list, with a recorded normalization. If an inner entity participates
in a world predicate, it is not removable and the proposal is refused. The raw
proposal and exact content remain available. A diagnostic ablation disables this
unused-annotation removal; it is not a way to permit inner facts outside scope.

Roles are executable arguments, e.g. `land(E1, theme, X1, location, X2)`.
`E1` denotes one event candidate, `X1` the spacecraft and `X2` the location. The
complete tuple is one relation-classifier input. The compiler does not train
that classifier or generate media scores. Abstract concepts such as visibility
are literal predicate arguments rather than physical object candidates.

Source statements bind a source to the exact embedded content, its evidence
route and its speech/depiction act. A photo showing collapsed buildings does not
compile into an unqualified assertion that the buildings collapsed in the world.
Embedded content is not recursively decomposed in this version. This limitation
is reported separately from fully decomposed world claims. The evidence policy
filters incompatible routes to unknown. Use `temporal_evidence` before ordinary
grounding or two-source grounding to apply both temporal and route checks.

Shared referents are bound at their lowest common formula node. Each event is
bound inside its local negation. Complex quantification, ambiguous scope and
partially shared referents across a three-way disjunction are refused. This
fragment does not claim to implement all English semantics or presupposition.

## Temporal meaning and evidence

The full auxiliary/verb chain determines finite tense and simple/progressive/
perfect aspect. Participial morphology alone does not determine clause tense.
`landed`, `is landing`, `was landing` and `has landed` therefore emit different
`temporal` predicates. Completion is a separate lexical-reading condition,
not a universal consequence of past tense. The parser proposes it and it still
requires review. `T0` is the caller's reference context, not the computer clock.
It is an explicit candidate variable in temporal predicates and evidence keys.

The optional fixed temporal checker consumes explicit annotations indexed by
context ID and event candidate ID. Coordinates must share a declared time axis.
`start`/`end` are the relevant event-phase boundaries (start included, end excluded); `reference` is discourse
reference time; `past_reference` is an earlier reference for past progressive.
An interval ending can be interrupted: it does not imply `completed=true`.
`perfect_licensed` explicitly supplies the perfect reading/relevance condition.
The interval checker covers a narrow episodic reading. Habitual readings,
missing boundaries/reference, and unannotated perfect relevance return unknown.
It is not a general tense calculus or an automatic event-time extractor.
Supply one reference-context interpretation per verification run. Its absence
is unknown, even when a caller mistakenly marks the empty context inventory as
complete. Alternative entity/event assignments still use the existing inference.

No real-video temporal annotation is inferred from sentence tense. Source/content
inner tense is retained in the exact text rather than evaluated by this checker.
Video-window localization and neural temporal observations remain later work.

## Reproduction

All authored prompts are in `scripts/prompts_phase2.py`. Raw requests retain
exact prompts, dependency inputs, schema, model config hashes and responses.
The smaller existing Qwen3-VL-8B checkpoint is used in text-only mode when the
A100 queue is unavailable; no frames/audio or fact-check labels enter its prompt.
Prompted JSON is checked after generation; it is not grammar-constrained decoding
in the Transformers fallback. The optional 30B vLLM runner uses a JSON schema.
The same 30B text checkpoint can also run through Transformers with its layers
split across four V100s; this fallback uses prompted JSON, not schema-constrained
decoding. Results from its small diagnostic set are kept separate from the broad
8B comparison. The representation is proposed, then checked in both conditions.

From the project root, with requirements-verification.txt installed:

```bash
PYTHONPATH=scripts python -m pytest tests/test_semantic_compiler.py
python scripts/run_semantic_parser.py replay --input <raw.jsonl> --output <results.jsonl>
python scripts/check_semantic_compiler.py
python scripts/compile_verification_claim.py --text '<claim>' --ud-json <tokens.json> --semantic-json <proposal.json>
```

Compiler replay needs jsonschema and cached inputs, not a GPU/model. The temporal
demonstration additionally uses CPU DeepProbLog. Its event times and non-temporal
scores are explicitly constructed controls, not perception predictions. The
original compiler and its audit source snapshots are left unchanged.

## Measured development comparison

The frozen 8B model with the second prompt yields 11 checked programs out of 79
reviewed development claims, versus 20 for v1 on this selected set. All 11 were
inspected; some lexical/type contracts remain unresolved. It is not ready as a
replacement or a semantic-accuracy result. The 21 generated contrasts yield
8 checked programs and 13 refusals, whereas hand-authored semantic fixtures
exercise compiler capabilities independently of parser generation.

The same second prompt with the frozen 30B text model passes 3 of 7 selected
diagnostics. Source scope and the genitive example still fail. A third prompt,
with synthetic source-scope examples, plus checked removal of unused inner
annotations makes 3 known source failures compile. None of those 3 compile when
that removal is disabled. This is prompt/compiler development, not an independent
evaluation or an updated 79-claim coverage estimate. Inner content remains text.

There are 64 passing regression checks and 16 actual CPU DeepProbLog temporal
controls. Their event intervals and non-temporal scores are constructed. No new
feature-based relation classifier or media temporal extractor was trained.
