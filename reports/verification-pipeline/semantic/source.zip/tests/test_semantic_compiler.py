"""Meaning-level contrasts and executable inference checks for the new fragment."""
import copy
import json
from pathlib import Path

import pytest

from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.semantic import SemanticCompiler, SemanticError
from probabilistic_verification.temporal import temporal_evidence, temporal_status

FIXTURES = {r["claim_id"]: r for r in json.loads((Path(__file__).parent / "fixtures/semantic_compiler_cases.json").read_text())}


def compile_case(index, proposal=None):
    r = FIXTURES[f"contrast_{index:02d}"]
    return SemanticCompiler().compile(r["claim_id"], r["text"], r["tokens"], proposal or r["proposal"])


def signature(claim):
    names = {v.name: "event" if v.kind == "event" else v.description.lower() for v in claim.variables}
    return sorted((a.predicate, tuple(names.get(x, x) for x in a.arguments)) for a in claim.atoms)


def test_active_passive_equivalence_and_role_swap():
    assert signature(compile_case(6)) == signature(compile_case(7))
    assert signature(compile_case(6)) != signature(compile_case(8))


def test_numeric_name_location_and_temporal_distinctions():
    claims = [compile_case(i) for i in range(6)]
    assert claims[0].variables[0].description == "Apollo 11"
    assert "location" in next(a for a in claims[0].atoms if a.predicate == "land").arguments
    times = [next(a for a in c.atoms if a.kind == "temporal").arguments for c in claims]
    assert len(set(times[2:6])) == 4
    assert [c.metadata["temporal"]["E1"]["tense"] for c in claims[2:6]] == ["past", "pres", "past", "pres"]
    assert [c.metadata["temporal"]["E1"]["aspect"] for c in claims[2:6]] == ["simple", "progressive", "progressive", "perfect"]


def test_attribute_attachment_changes_the_program():
    a, b = compile_case(11), compile_case(12)
    assert signature(a) != signature(b)
    assert len([v for v in a.variables if v.kind == "entity"]) == 2
    gray_a = next(x for x in a.atoms if x.predicate == "gray")
    gray_b = next(x for x in b.atoms if x.predicate == "gray")
    assert gray_a.arguments[-1] == "X1" and gray_b.arguments[-1] == "X2"


def test_negation_keeps_event_existential_inside_not():
    def nodes(e):
        return [e] + [n for c in e.children for n in nodes(c)]
    c = compile_case(9)
    neg = next(n for n in nodes(c.expression) if n.op == "not")
    assert neg.children[0].op == "exists" and neg.children[0].variables == ("E1",)
    referents = next(n for n in nodes(c.expression) if n.op == "exists" and "X1" in n.variables)
    assert set(referents.variables) == {"X1", "X2"}


def test_source_content_does_not_assert_world_events():
    c, world = compile_case(13), compile_case(14)
    assert not any(a.predicate == "collapse" for a in c.atoms)
    assert any(a.predicate == "collapse" for a in world.atoms)
    assert [v.description for v in c.variables if v.kind == "entity"] == ["Photos"]
    assert next(iter(c.metadata["contents"].values()))["text"] == "collapsed buildings"
    positive, negative = compile_case(15), compile_case(16)
    assert signature(positive) != signature(negative)
    assert "NOT" not in negative.to_dict()["logical_form"]  # negation stays inside quoted content


def test_genitive_is_not_ownership():
    c = compile_case(17)
    assert any(a.predicate == "effect_of" for a in c.atoms)
    assert not any(a.predicate == "possess" for a in c.atoms)
    p = copy.deepcopy(FIXTURES["contrast_17"]["proposal"])
    p["units"][0].update(predicate="possess", roles=[dict(role="owner",referent="quake"),dict(role="possession",referent="impact")])
    with pytest.raises(SemanticError, match="ownership"):
        compile_case(17, p)


@pytest.mark.parametrize("index,code", [(18,"quantity"),(19,"scope"),(20,"reference")])
def test_unsupported_scope_and_unresolved_reference_stay_rejections(index, code):
    with pytest.raises(SemanticError) as e:
        compile_case(index)
    assert e.value.code == code


def test_missing_words_hidden_negation_and_lifted_content_rejected():
    p = copy.deepcopy(FIXTURES["contrast_11"]["proposal"])
    p["units"].pop(1)  # omit the gray property, not a recoverable grammatical marker
    p["operations"][0]["inputs"].remove("car_color")
    with pytest.raises(SemanticError, match="Unaccounted"):
        compile_case(11,p)
    p = copy.deepcopy(FIXTURES["contrast_09"]["proposal"])
    p["units"][0]["negated"] = False
    with pytest.raises(SemanticError, match="Negation|negation"):
        compile_case(9,p)
    p = copy.deepcopy(FIXTURES["contrast_13"]["proposal"])
    p["entities"][0]["mentions"].append([4])
    with pytest.raises(SemanticError, match="Embedded"):
        compile_case(13,p)


def test_role_labels_and_tense_enter_actual_evidence_keys():
    from dataclasses import replace
    a = next(a for a in compile_case(6).atoms if a.predicate=="hug")
    b = replace(a, arguments=tuple("theme" if x=="agent" else x for x in a.arguments))
    assert canonical_key("clip",a,{},"visual_depiction") != canonical_key("clip",b,{},"visual_depiction")
    a, b = (next(a for a in compile_case(i).atoms if a.kind=="temporal") for i in (2,3))
    assert canonical_key("clip",a,{},"visual_depiction") != canonical_key("clip",b,{},"visual_depiction")


def evidence_for(claim, route="visual_depiction", annotation=None):
    assignment = {v.name: v.name.lower() for v in claim.variables}
    evidence = Evidence("constructed_fixture",{v:[x] for v,x in assignment.items()},dict.fromkeys(assignment,True),{},route)
    for atom in claim.atoms:
        if atom.kind != "temporal":
            key=canonical_key(evidence.media_id,atom,assignment,route)
            evidence.observations[key]=Observation(key,(1.,0.,0.),False,atom.text,{"source":"constructed fixture; not a media prediction"})
    return ground(claim,temporal_evidence(claim,evidence,{"t0":{"e1":annotation}} if annotation else {}))


@pytest.mark.parametrize("index,annotation,expected", [
    (2,dict(reading="episodic",start=0,end=5,reference=10,completed=True),"supported"),
    (3,dict(reading="episodic",start=0,end=5,reference=10,completed=True),"refuted"),
    (3,dict(reading="episodic",start=0,end=15,reference=10,completed=False),"supported"),
    (2,dict(reading="episodic",start=0,end=15,reference=10,completed=False),"refuted"),
    (4,dict(reading="episodic",start=0,end=5,reference=10,past_reference=2,completed=True),"supported"),
    (5,dict(reading="episodic",start=0,end=5,reference=10,completed=True,perfect_licensed=True),"supported"),
    (5,dict(reading="episodic",start=0,end=5,reference=10,completed=True),"unknown"),
    (2,None,"unknown"),
])
def test_temporal_conditions_reach_actual_deepproblog(index,annotation,expected):
    from probabilistic_verification.backend import DeepProbLogVerifier
    p=evidence_for(compile_case(index),annotation=annotation)
    distribution=DeepProbLogVerifier([p],learned=False).predict()[0]["distribution"]
    assert distribution[expected] == pytest.approx(1.)


def test_wrong_source_route_is_unknown_even_if_raw_score_supports():
    from probabilistic_verification.logic import enumerate_probability
    p=evidence_for(compile_case(15),route="visual_depiction",annotation=dict(reading="episodic",reference=1,state_at_reference=True))
    assert enumerate_probability(p)["unknown"] == 1.


def test_interruption_and_missing_context_do_not_certify_completion():
    c=compile_case(2).metadata["temporal"]["E1"]
    assert temporal_status(c,dict(reading="episodic",start=0,end=5,reference=10,completed=False)) == "refuted"
    assert temporal_status(c,dict(reading="episodic",start=0,end=5,completed=True)) == "unknown"


def test_invalid_formula_cycle_and_duplicate_roles_rejected():
    p=copy.deepcopy(FIXTURES["contrast_11"]["proposal"])
    p["operations"][0]["inputs"][0]="both"
    with pytest.raises(SemanticError,match="acyclic"):
        compile_case(11,p)
    p=copy.deepcopy(FIXTURES["contrast_06"]["proposal"])
    p["units"][0]["roles"].append(p["units"][0]["roles"][0])
    with pytest.raises(SemanticError,match="Roles"):
        compile_case(6,p)


def test_conjunction_and_disjunction_share_referents_without_merging_events():
    p=copy.deepcopy(FIXTURES["contrast_06"]["proposal"])
    r=copy.deepcopy(FIXTURES["contrast_06"])
    r["text"]="Alice hugs Bob and greets Bob."
    r["tokens"]=r["tokens"][:3]+[
        dict(id=4,text="and",lemma="and",upos="CCONJ",head=5,deprel="cc",start_char=15,end_char=18,feats=None),
        dict(id=5,text="greets",lemma="greet",upos="VERB",head=2,deprel="conj",start_char=19,end_char=25,feats="Tense=Pres|VerbForm=Fin"),
        dict(id=6,text="Bob",lemma="Bob",upos="PROPN",head=5,deprel="obj",start_char=26,end_char=29,feats=None),
        dict(id=7,text=".",lemma=".",upos="PUNCT",head=2,deprel="punct",start_char=29,end_char=30,feats=None)]
    p["entities"][1]["mentions"].append([6]); p["function_words"]=[7]
    other=copy.deepcopy(p["units"][0]); other.update(id="greeting",predicate="greet",head=5,token_ids=[4,5])
    p["units"].append(other)
    p["operations"]=[dict(id="both",op="and",inputs=["hugging","greeting"])]
    p["root"]="both"
    c=SemanticCompiler().compile("conjunction",r["text"],r["tokens"],p)
    assert len([v for v in c.variables if v.kind=="entity"])==2
    assert len([v for v in c.variables if v.kind=="event"])==2
    p["operations"][0]["op"]="or"
    r["tokens"][3].update(text="or",lemma="or")
    d=SemanticCompiler().compile("disjunction",r["text"].replace("and","or"),r["tokens"],p)
    assert c.to_dict()["logical_form"]!=d.to_dict()["logical_form"]


def test_context_identity_prevents_reusing_a_temporal_score():
    from probabilistic_verification.backend import DeepProbLogVerifier
    from probabilistic_verification.logic import GroundProgram
    c=compile_case(3)
    programs=[]
    for context_id,reference in [("during",2),("later",10)]:
        assignment={v.name:context_id if v.kind=="context" else v.name.lower() for v in c.variables}
        e=Evidence("same_clip",{v:[x] for v,x in assignment.items()},dict.fromkeys(assignment,True),{},"visual_depiction")
        for atom in c.atoms:
            if atom.kind!="temporal":
                key=canonical_key(e.media_id,atom,assignment,e.route)
                e.observations[key]=Observation(key,(1.,0.,0.),False,atom.display())
        e=temporal_evidence(c,e,{context_id:{"e1":dict(reading="episodic",start=0,end=5,reference=reference)}})
        p=ground(c,e); p.claim_id+="_"+context_id; programs.append(p)
    predictions=DeepProbLogVerifier(programs,learned=False).predict()
    assert predictions[0]["distribution"]["supported"]==1.
    assert predictions[1]["distribution"]["refuted"]==1.
    times=[next(o for o in p.observations.values() if o.provenance.get("source")=="explicit temporal metadata") for p in programs]
    assert times[0].key!=times[1].key


def test_marker_recovery_preserves_preposition_meaning_and_records_the_repair():
    r=copy.deepcopy(FIXTURES["contrast_00"])
    p=r["proposal"]; p["units"][0]["token_ids"].remove(4); p["function_words"].append(4)
    c=SemanticCompiler().compile("on",r["text"],r["tokens"],p)
    assert c.metadata["normalizations"][0]["word"]=="on"
    assert "on" in next(a for a in c.atoms if a.predicate=="land").arguments
    r["tokens"][3].update(text="in",lemma="in")
    d=SemanticCompiler().compile("in",r["text"].replace("on the","in the"),r["tokens"],p)
    assert signature(c)!=signature(d)


@pytest.mark.parametrize("row",json.loads((Path(__file__).parent/"fixtures/semantic_model_errors.json").read_text()))
def test_observed_model_errors_are_rejected(row):
    with pytest.raises(SemanticError) as e:
        SemanticCompiler().compile(row['claim_id'],row['text'],row['tokens'],row['proposal'])
    assert e.value.code==row['expected_diagnostic']


def test_nonfinite_gerund_fragment_preserves_aspect_without_inventing_present_tense():
    from probabilistic_verification.semantic import temporal_features
    tokens=[dict(id=1,text='coming',lemma='come',upos='VERB',head=0,deprel='root',feats='VerbForm=Ger')]
    result=temporal_features(tokens,1)
    assert result['aspect']=='progressive' and result['tense']=='unspecified'


def test_landing_frame_rejects_agent_spacecraft_and_theme_moon():
    p=copy.deepcopy(FIXTURES['contrast_00']['proposal'])
    p['units'][0]['roles']=[dict(role='agent',referent='ship'),dict(role='theme',referent='moon')]
    with pytest.raises(SemanticError) as e:
        compile_case(0,p)
    assert e.value.code=='role_frame'


def test_opt_in_command_line_compilation_uses_cached_inputs(tmp_path):
    import subprocess
    import sys
    r=FIXTURES['contrast_00']
    (tmp_path/'tokens.json').write_text(json.dumps(r['tokens']))
    (tmp_path/'proposal.json').write_text(json.dumps(r['proposal']))
    root=Path(__file__).resolve().parents[1]
    result=subprocess.run([sys.executable,str(root/'scripts/compile_verification_claim.py'),'--text',r['text'],
        '--ud-json',str(tmp_path/'tokens.json'),'--semantic-json',str(tmp_path/'proposal.json')],text=True,capture_output=True)
    assert result.returncode==0, result.stderr
    assert json.loads(result.stdout)['version']=='semantic-compiler-v2'


def test_missing_reference_context_is_unknown_and_multiple_interpretations_are_refused():
    from probabilistic_verification.logic import enumerate_probability
    c=compile_case(2)
    e=Evidence('missing_context',{'T0':[]},{'T0':True},{},'visual_depiction')
    p=ground(c,temporal_evidence(c,e,{}))
    assert enumerate_probability(p)['unknown']==1.
    e.domains['T0']=['one','two']
    with pytest.raises(ValueError,match='one interpretation'):
        temporal_evidence(c,e,{})


def test_unassigned_punctuation_is_logged_without_changing_name_or_meaning():
    p=copy.deepcopy(FIXTURES['contrast_00']['proposal'])
    p['function_words'].remove(7)
    c=compile_case(0,p)
    assert signature(c)==signature(compile_case(0))
    assert c.metadata['normalizations'][-1]['word']=='.'


def test_numeric_json_identifiers_do_not_change_semantics():
    p=copy.deepcopy(FIXTURES['contrast_00']['proposal'])
    p['entities'][0]['id']='11'
    p['units'][0]['roles'][0]['referent']='11'
    assert signature(compile_case(0,p))==signature(compile_case(0))


def test_unused_content_annotation_can_be_removed_but_referenced_world_facts_cannot():
    p=copy.deepcopy(FIXTURES['contrast_13']['proposal'])
    p['entities'].append(dict(id='buildings',description='buildings',kind='group',named=False,mentions=[[4]]))
    c=compile_case(13,p)
    assert signature(c)==signature(compile_case(13))
    assert c.metadata['normalizations'][-1]['entity']=='buildings'
    r=FIXTURES['contrast_13']
    with pytest.raises(SemanticError,match='Embedded content'):
        SemanticCompiler(remove_unused_content_annotations=False).compile(r['claim_id'],r['text'],r['tokens'],p)
    extra=copy.deepcopy(p['units'][0]);extra.update(id='world_damage',kind='state',predicate='collapsed',head=3,token_ids=[3],
        roles=[dict(role='holder',referent='buildings')],content=dict(route='none',act='none',token_ids=[]))
    p['units'].append(extra);p['operations']=[dict(id='both',op='and',inputs=['showing','world_damage'])];p['root']='both'
    with pytest.raises(SemanticError,match='Embedded content|world predicate'):
        compile_case(13,p)


def test_source_content_must_include_all_words_in_its_dependency_complement():
    p=copy.deepcopy(FIXTURES['contrast_13']['proposal'])
    p['units'][0]['content']['token_ids']=[4]  # omit 'collapsed' from source content
    with pytest.raises(SemanticError,match='complete dependency complement'):
        compile_case(13,p)
