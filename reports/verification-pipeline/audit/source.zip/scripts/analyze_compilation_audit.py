#!/usr/bin/env python3
"""Independently replay frozen outputs and summarize the text-only compiler audit."""
from __future__ import annotations

from collections import Counter,defaultdict
import hashlib
import json
from pathlib import Path
import random
import sys

from run_compilation_audit import DEFAULT,read,write,sha,sync


def main():
    run=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else DEFAULT
    manifest=json.loads((run/'manifest.json').read_text())
    inventory={r['claim_id']:r for r in read(run/'inventory.jsonl')}
    if len(inventory)!=manifest['inventory_claims']:raise AssertionError('Inventory count mismatch.')
    for r in inventory.values():
        assert hashlib.sha256(r['text'].encode()).hexdigest()==r['text_sha256']
    sys.path.insert(0,str(run/'frozen_source/scripts'))
    from probabilistic_verification import ClaimCompiler,CompilationError
    for path,digest in manifest['baseline_code_sha256'].items():
        assert sha(run/'frozen_source'/path)==digest
    indexed={}
    checked=Counter()
    for condition in ('cached','current'):
        rows=read(run/(condition+'_results.jsonl'))
        assert len(rows)==len(inventory) and len({r['claim_id'] for r in rows})==len(inventory)
        indexed[condition]={r['claim_id']:r for r in rows}
        for r in rows:
            assert r['text']==inventory[r['claim_id']]['text']
            assert r['text_sha256']==inventory[r['claim_id']]['text_sha256']
            if r['status']=='parser_rejected':
                assert condition=='current' and r['code']=='sentence_count' and not r['tokens']
                checked['recorded_parser_rejections']+=1
                continue
            try:
                actual=ClaimCompiler().compile(r['claim_id'],r['text'],r['tokens']).to_dict()
            except CompilationError as e:actual=e.to_dict()
            actual=json.loads(json.dumps(actual))
            for key,value in actual.items():assert r[key]==value,(r['claim_id'],key)
            checked['compiler_replays']+=1
    cached_inputs=read(run/'cached_parses.jsonl')
    for r in cached_inputs:
        assert all(t['text'].strip() for t in r['tokens'])
        by_id={t['id']:t for t in r['tokens']}
        assert len(by_id)==len(r['tokens'])
        assert all(t['head']==0 or t['head'] in by_id for t in r['tokens'])
        for token in r['original_tokens']:
            if token['i'] in r['excluded_whitespace_token_ids']:
                assert token['upos']=='SPACE' and not token['text'].strip()
            else:
                t=by_id[token['i']+1]
                assert t['head']==(0 if token['deprel']=='root' else token['head']+1)
                assert all(t[k]==token[k] for k in ('text','lemma','upos','deprel'))
    current=indexed['current']
    counts={c:Counter(r['status'] for r in rows.values()) for c,rows in indexed.items()}
    prior=json.loads((run/'census_summary.json').read_text())
    assert all(dict(counts[c])==prior['conditions'][c]['statuses'] for c in indexed)
    acceptance=Counter((indexed['cached'][cid]['status']=='compiled',current[cid]['status']=='compiled') for cid in inventory)
    # Frequencies below are structural descriptions, not automatically scored
    # semantic errors. Multiple unhandled tokens can contribute to one claim.
    unhandled_pos=Counter();unhandled_deps=Counter();proper_numeric=[];finite_accepted=[]
    by_topic=defaultdict(Counter)
    for cid,r in current.items():
        by_topic[inventory[cid]['topic_id']][r['status']]+=1
        tokens={t['id']:t for t in r['tokens']}
        if r.get('code')=='unhandled_content':
            for tid in r['token_ids']:
                unhandled_pos[tokens[tid]['upos']]+=1
                unhandled_deps[tokens[tid]['deprel']]+=1
        if r.get('code')=='quantification':
            if any(tokens[t].get('upos')=='NUM' and tokens.get(tokens[t]['head'],{}).get('upos')=='PROPN' for t in r['token_ids']):
                proper_numeric.append(cid)
        if r['status']=='compiled' and any('VerbForm=Fin' in (t.get('feats') or '') and 'Tense=' in (t.get('feats') or '') for t in r['tokens']):
            finite_accepted.append(cid)
    sampled=read(run/'review_sample.jsonl')
    random_ids=[r['claim_id'] for r in sampled if r['sample']=='random']
    eligible=sorted(cid for cid,r in inventory.items() if r['development_eligible'])
    assert random_ids==random.Random(manifest['sampling_seed']).sample(eligible,50)
    assert Counter(r['sample'] for r in sampled)==dict(random=50,diagnostic=20)
    used={r['claim_id'] for r in sampled}
    supplement=[dict(sample='accepted_development',claim_id=cid,text=inventory[cid]['text'],
        source_videos=inventory[cid]['source_videos'],status='compiled',
        selection_reason='Supplement: review every remaining accepted development program')
        for cid in sorted(current) if cid not in used and current[cid]['status']=='compiled' and inventory[cid]['development_eligible']]
    write(run/'supplemental_sample.jsonl',supplement)
    combined=sampled+supplement
    assert all(inventory[r['claim_id']]['development_eligible'] and not inventory[r['claim_id']]['reserved_source_overlap'] for r in combined)
    verification=dict(compiler_replays=checked['compiler_replays'],recorded_parser_rejections=checked['recorded_parser_rejections'],
        inventory_claims=len(inventory),both_conditions_cover_inventory=True,adapter_lexical_tokens_preserved=True,
        excluded_cached_whitespace_records=sum(len(r['excluded_whitespace_token_ids']) for r in cached_inputs),
        code_hashes_match_frozen_snapshot=True,review_sample_has_no_reserved_sources=True)
    verification['random_sample_matches_frozen_seed']=True
    analysis=dict(date='2026-10-28',verification=verification,
        acceptance_matrix=[dict(cached_compiled=a,current_compiled=b,count=n) for (a,b),n in sorted(acceptance.items())],
        unhandled_token_pos=dict(unhandled_pos.most_common()),unhandled_token_dependencies=dict(unhandled_deps.most_common()),
        numeric_modifiers_of_proper_names=dict(count=len(proper_numeric),claim_ids=proper_numeric,
            interpretation='Structural heuristic only: not all such numbers have been semantically adjudicated.'),
        accepted_finite_tense=dict(count=len(finite_accepted),claim_ids=finite_accepted,
            interpretation='Finite tense is present in the input; current predicate families provide no explicit tense/aspect constraints.'),
        by_topic={k:dict(v) for k,v in sorted(by_topic.items())},
        review_sample_counts=dict(Counter(r['sample'] for r in combined)))
    review_path=run/'semantic_reviews.jsonl'
    if review_path.exists():
        reviews=read(review_path);reviewed={r['claim_id']:r for r in reviews}
        assert len(reviewed)==len(reviews)==len(combined)
        assert set(reviewed)=={r['claim_id'] for r in combined}
        for r in reviews:
            assert r['text_sha256']==inventory[r['claim_id']]['text_sha256']
            assert r['observed_status']==current[r['claim_id']]['status']
            assert r['expected_meaning'] and r['judgment'] and r['flags']
        cohorts={name:[reviewed[s['claim_id']] for s in combined if s['sample']==name]
                 for name in ('random','diagnostic','accepted_development')}
        analysis['semantic_review']={name:dict(n=len(rr),compiler_statuses=dict(Counter(r['observed_status'] for r in rr)),
            core_assessments=dict(Counter(r['core_assessment'] for r in rr)),flags=dict(Counter(f for r in rr for f in r['flags']))) for name,rr in cohorts.items()}
        accepted=[r for r in reviews if r['observed_status']=='compiled']
        assert {r['claim_id'] for r in accepted}=={cid for cid,r in current.items() if r['status']=='compiled' and inventory[cid]['development_eligible']}
        analysis['accepted_development_review']=dict(n=len(accepted),
            core_assessments=dict(Counter(r['core_assessment'] for r in accepted)),
            flags=dict(Counter(f for r in accepted for f in r['flags'])),
            label_source='assistant text review, not independent human gold')
        sync(run,'reviewed')
    (run/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
    print(json.dumps(analysis,indent=2))


if __name__=='__main__':main()
