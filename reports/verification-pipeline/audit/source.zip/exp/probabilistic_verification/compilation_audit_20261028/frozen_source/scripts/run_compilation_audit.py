#!/usr/bin/env python3
"""Freeze a real-claim inventory and audit the unchanged compiler on two parses.

No verification labels, media models or compiler fixes are used. The stored
hypergraph supplies an exact-text-matched legacy UD parse. A second pass uses
the current frozen Stanza wrapper, so parser and compiler effects stay distinct.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import random
import shutil
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
DEFAULT=ROOT/'exp/probabilistic_verification/compilation_audit_20261028'
CHECKLIST=ROOT/'exp/probabilistic_verification/av_features_20261022/checklist.json'


def read(path):
    return [json.loads(l) for l in Path(path).read_text().splitlines() if l.strip()]


def write(path,rows):
    Path(path).write_text(''.join(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n' for r in rows))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def text_sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def sync(run,stage):
    progress_path=run/'progress.json'
    progress=json.loads(progress_path.read_text()) if progress_path.exists() else {}
    progress[stage]=dict(completed_at=datetime.now(timezone.utc).isoformat())
    progress_path.write_text(json.dumps(progress,indent=2)+'\n')
    data=json.loads(CHECKLIST.read_text())
    step=next(s for s in data['steps'] if s['id']==6)
    for item,key in zip(step['items'],('frozen','census','reviewed','analyzed')):
        item['done']=key in progress
    step['status']=('audit completed; compiler fixes remain separate' if 'analyzed' in progress else
        'in progress: semantic review' if 'census' in progress else 'in progress: compilation census')
    step['note']='Frozen baseline and current audit artifacts: compilation_audit_20261028. Compiler code is unchanged. Census outcomes and assistant semantic judgments are reported separately; reserved-source claims are excluded from the semantic review.'
    data['audit_run']=dict(source_path=str(run.relative_to(ROOT)),completed_stages=list(progress),
        report_anchor='compilation-audit')
    CHECKLIST.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')


def freeze(run):
    source_paths=dict(annotation=ROOT/'exp/phase1/reports/annotation_units.tsv',
        hypergraph=ROOT/'exp/phase1/hypergraph.jsonl',manifest=ROOT/'exp/phase2/manifest_avid.jsonl',
        reserved=ROOT/'exp/probabilistic_verification/pilot_20261015/reserved_videos.json')
    with source_paths['annotation'].open() as f:annotations=list(csv.DictReader(f,delimiter='\t'))
    texts={}
    for r in annotations:
        if r['claim_id'] in texts and texts[r['claim_id']]!=r['claim_text']:
            raise ValueError('A claim ID has multiple texts.')
        texts[r['claim_id']]=r['claim_text']
    cached={r['claim_id']:r for r in read(source_paths['hypergraph'])}
    if set(texts)!=set(cached) or any(texts[c]!=cached[c]['claim_text'] for c in texts):
        raise ValueError('The cached parser inventory must match current IDs and exact texts.')
    sources=defaultdict(set)
    for r in read(source_paths['manifest']):
        sources[(r['topic_id'],r['claim_text'])].add(r['video_id'])
    reserved=set(json.loads(source_paths['reserved'].read_text()))
    inventory,parses=[],[]
    for cid,text in texts.items():
        r=cached[cid];videos=sorted(sources.get((r['topic_id'],text),set()))
        inventory.append(dict(claim_id=cid,topic_id=r['topic_id'],text=text,text_sha256=text_sha(text),
            source_videos=videos,development_eligible=bool(videos) and not bool(set(videos)&reserved),
            reserved_source_overlap=sorted(set(videos)&reserved)))
        tokens=[]
        whitespace_ids={t['i'] for t in r['parse'] if t['upos']=='SPACE' and not t['text'].strip()}
        for t in r['parse']:
            if t['i'] in whitespace_ids:continue
            if t['head']==t['i'] and t['deprel']!='root':
                raise ValueError('Unexpected self-headed non-root token in stored parse.')
            if t['head'] in whitespace_ids:raise ValueError('Lexical token depends on a whitespace token.')
            tokens.append(dict(id=t['i']+1,text=t['text'],lemma=t['lemma'],upos=t['upos'],
                head=0 if t['deprel']=='root' else t['head']+1,deprel=t['deprel']))
        parses.append(dict(claim_id=cid,text_sha256=text_sha(text),n_sentences=r['n_sentences'],
            original_tokens=r['parse'],excluded_whitespace_token_ids=sorted(whitespace_ids),tokens=tokens))
    source=ROOT/'scripts/probabilistic_verification'
    hashes={str(p.relative_to(ROOT)):sha(p) for p in sorted(source.glob('*.py'))}
    meta=dict(date='2026-10-28',inventory_claims=len(inventory),annotation_rows=len(annotations),
        development_eligible=sum(x['development_eligible'] for x in inventory),reserved_video_count=len(reserved),
        input_files={k:dict(path=str(p.relative_to(ROOT)),sha256=sha(p)) for k,p in source_paths.items()},
        baseline_code_sha256=hashes,python=sys.version,
        versions={n:importlib.metadata.version(n) for n in ('stanza','torch')},
        cached_parser_provenance='Existing phase1 hypergraph UD records; original runtime/model version is not recorded in that artifact.',
        cached_conversion='Zero-based token/head indices become one-based; self-headed root becomes head 0. SpaCy SPACE-only records are omitted (retained in original_tokens), with original lexical IDs preserved. No lexical/dependency edits. Stored cache has no morphology or word offsets.',
        review_scope='Text-only assistant semantic review on development-eligible sources, not independent human gold; reserved source labels/media are not read.',
        sampling_seed=20261028)
    if (run/'manifest.json').exists():
        previous=json.loads((run/'manifest.json').read_text())
        for key in ('input_files','baseline_code_sha256'):
            if previous[key]!=meta[key]:raise ValueError('Frozen inputs or code changed; use a new run directory.')
        return
    run.mkdir(parents=True,exist_ok=True)
    snapshot=run/'frozen_source/scripts/probabilistic_verification'
    snapshot.mkdir(parents=True,exist_ok=True)
    for p in source.glob('*.py'):shutil.copyfile(p,snapshot/p.name)
    shutil.copyfile(Path(__file__),run/'frozen_source/scripts/run_compilation_audit.py')
    write(run/'inventory.jsonl',inventory);write(run/'cached_parses.jsonl',parses)
    (run/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
    sync(run,'frozen')
    print(json.dumps({k:meta[k] for k in ('inventory_claims','annotation_rows','development_eligible')}),flush=True)


def census(run,condition):
    sys.path.insert(0,str(run/'frozen_source/scripts'))
    from probabilistic_verification import ClaimCompiler,CompilationError
    inventory=read(run/'inventory.jsonl')
    cached={r['claim_id']:r for r in read(run/'cached_parses.jsonl')}
    output=run/(condition+'_results.jsonl')
    existing=read(output) if output.exists() else []
    done={r['claim_id'] for r in existing}
    if len(done)!=len(existing):raise ValueError('Duplicate result IDs.')
    parser=None
    if condition=='current' and len(done)<len(inventory):
        from probabilistic_verification.parsing import DependencyParser
        parser=DependencyParser()
        (run/'current_parser.json').write_text(json.dumps(parser.provenance,indent=2)+'\n')
    started=time.perf_counter()
    with output.open('a') as stream:
        for claim in inventory:
            if claim['claim_id'] in done:continue
            tick=time.perf_counter();tokens=[]
            result=dict(claim_id=claim['claim_id'],text=claim['text'],text_sha256=claim['text_sha256'],condition=condition)
            try:
                if condition=='cached':tokens=cached[claim['claim_id']]['tokens']
                else:tokens=parser.parse(claim['text'])
                result.update(ClaimCompiler().compile(claim['claim_id'],claim['text'],tokens).to_dict())
            except CompilationError as e:
                result.update(e.to_dict(),tokens=tokens)
            except ValueError as e:
                if str(e)=='Supply exactly one sentence.':
                    result.update(status='parser_rejected',code='sentence_count',message=str(e),tokens=tokens)
                else:result.update(status='unexpected_error',code=type(e).__name__,message=str(e),tokens=tokens)
            except Exception as e:
                result.update(status='unexpected_error',code=type(e).__name__,message=str(e),tokens=tokens)
            result['seconds']=time.perf_counter()-tick
            stream.write(json.dumps(result,ensure_ascii=False,allow_nan=False)+'\n');stream.flush()
            done.add(claim['claim_id'])
            if len(done)%100==0 or len(done)==len(inventory):
                print(json.dumps(dict(condition=condition,processed=len(done),total=len(inventory),elapsed_seconds=time.perf_counter()-started)),flush=True)
    meta=json.loads((run/'manifest.json').read_text())
    for path,digest in meta['baseline_code_sha256'].items():
        if sha(ROOT/path)!=digest:raise ValueError('Working compiler changed during baseline census.')
    if all((run/(c+'_results.jsonl')).exists() and len(read(run/(c+'_results.jsonl')))==len(inventory) for c in ('cached','current')):
        sync(run,'census')


def summarize(run):
    inventory={r['claim_id']:r for r in read(run/'inventory.jsonl')}
    rows={c:read(run/(c+'_results.jsonl')) for c in ('cached','current')}
    def statistics(records):
        return dict(n=len(records),statuses=dict(Counter(r['status'] for r in records)),
            first_diagnostics=dict(Counter(r.get('code','compiled') for r in records)),
            total_record_seconds=sum(r['seconds'] for r in records))
    indexed={c:{r['claim_id']:r for r in rr} for c,rr in rows.items()}
    transitions=Counter((indexed['cached'][cid]['status'],indexed['current'][cid]['status']) for cid in inventory)
    summary=dict(date='2026-10-28',scope='Mechanical compilation coverage; not semantic accuracy.',
        conditions={c:statistics(rr) for c,rr in rows.items()},
        development={c:statistics([r for r in rr if inventory[r['claim_id']]['development_eligible']]) for c,rr in rows.items()},
        status_transitions=[dict(cached=a,current=b,count=n) for (a,b),n in sorted(transitions.items())],
        changed_compiled_forms=sum(indexed['cached'][cid].get('logical_form')!=indexed['current'][cid].get('logical_form')
            for cid in inventory if indexed['cached'][cid]['status']==indexed['current'][cid]['status']=='compiled'))
    (run/'census_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)


def sample(run):
    inventory={r['claim_id']:r for r in read(run/'inventory.jsonl')}
    rows={r['claim_id']:r for r in read(run/'current_results.jsonl')}
    eligible=sorted(cid for cid,c in inventory.items() if c['development_eligible'])
    rng=random.Random(20261028)
    random_ids=rng.sample(eligible,50)
    remaining=[cid for cid in eligible if cid not in random_ids]
    accepted=[cid for cid in remaining if rows[cid]['status']=='compiled']
    # Select accepted cases with more structure, then cover rejection diagnoses.
    accepted.sort(key=lambda cid:(-len(rows[cid].get('atoms',[])),cid))
    selected=accepted[:10]
    groups=defaultdict(list)
    for cid in remaining:
        if rows[cid]['status']!='compiled':groups[rows[cid].get('code','error')].append(cid)
    for code in sorted(groups,key=lambda c:(-len(groups[c]),c)):
        if len(selected)>=20:break
        choices=groups[code];choices.sort(key=lambda cid:(-len(rows[cid].get('tokens',[])),cid))
        selected.append(choices[0])
    used=set(random_ids+selected)
    extras=[cid for cid in remaining if cid not in used]
    extras.sort(key=lambda cid:(-len(rows[cid].get('tokens',[])),cid))
    selected+=extras[:20-len(selected)]
    samples=[dict(sample='random' if cid in random_ids else 'diagnostic',claim_id=cid,
        text=inventory[cid]['text'],source_videos=inventory[cid]['source_videos'],status=rows[cid]['status'],
        selection_reason='Uniform sample without replacement from development-eligible claim IDs' if cid in random_ids else
            'Purposive diagnostic: accepted structure complexity, then first-diagnostic diversity and long claims') for cid in random_ids+selected]
    if len(set(r['claim_id'] for r in samples))!=70:raise ValueError('Expected 70 distinct review cases.')
    if any(inventory[r['claim_id']]['reserved_source_overlap'] for r in samples):raise ValueError('Reserved source in review set.')
    write(run/'review_sample.jsonl',samples)
    print(json.dumps(dict(random=50,diagnostic=20,accepted_in_sample=sum(r['status']=='compiled' for r in samples))),flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=('freeze','cached','current','summary','sample','all'))
    ap.add_argument('--run-dir',type=Path,default=DEFAULT);args=ap.parse_args();run=args.run_dir.resolve()
    if args.stage in ('freeze','all'):freeze(run)
    if args.stage in ('cached','all'):census(run,'cached')
    if args.stage in ('current','all'):census(run,'current')
    if args.stage in ('summary','all'):summarize(run)
    if args.stage in ('sample','all'):sample(run)


if __name__=='__main__':main()
