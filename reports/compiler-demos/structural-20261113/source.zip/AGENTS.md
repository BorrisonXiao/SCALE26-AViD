# AViD project guidance

## Partial parses and neural alternatives — 13 November 2026

Compiler priority and ADR-023 remain unchanged. Read docs/compiler_structural_20261113.md, exp/probabilistic_verification/compiler_structural_20261113/summary.json and research/compiler_alternatives_20261113/RECOMMENDATIONS.md. Full 2,375 original/449 cached outputs remain byte-identical: 1,983 direct passes and 114 cached programs. Retained pool stays 1,981/2,375 (83.41%), with 394 excluded; every old retained program is unchanged. No new training/media inference/SRL retraining.

Partial capture preserves actual compiler state for 189 of 218 no-draft failures, leaving 29; these are not new passes. Among current exclusions, 367 strict failures include 149 existing drafts + 189 newly captured partial forms; 27 automatic direct passes receive no request. A fixed 40-case diagnostic (20 existing/20 partial) permits at most four typed edits and subtree replacement. Permissive development first4/generic6/feedback8 complete; strict literal types first5/generic5/feedback7. All 13 unique complete outputs inspected; none retained. The robot/during-race near-case is withheld for temporal/location typing, not declared an unambiguously unrelated reading. Do not extrapolate 189 draft captures or seven programs to faithful recoveries. No per-claim method pooling.

Both new branches explicitly retain the original error. Corrected an earlier report statement: saved generic messages in the preceding typed-edit trial did not explicitly retain it. Its numerical results are unchanged; historical ZIPs remain immutable. New controls share their first attempt and allow two retries; meaning review never triggers requests.

A local frozen Qwen meaning check on 63 prior programs gives 6 matching approvals/4 disputed approvals/3 missed retained/50 matching rejections (60% precision, 66.7% recall relative to compiler-author development judgments). No labels enter model messages, no confidence model is trained, and these are not independent gold/accuracy/calibration. Native DeepProbLog tests implement categorical parse choices and separate parser abstention from evidence unknown; all supplied probabilities are constructed, not learned. 484 tests pass. Jobs1230471/1230713 completed sequentially on one H100 (8m05s/5m15s);359 compiler +63 local neural requests, peak one GPU, no resources left allocated.

Research verifies 17 primary works and records 11 alternatives. Cached AMR already supplies wind-speed causality and Sheinbaum attribution, but robot/charger AMRs still contain errors. Proposed next: checked reference meanings; one fixed neural semantic-parser frontend with compositional logic conversion; then source-conditioned ranking/candidate coverage before calibrated parse mixtures. P3/NL2Logic already cover key parser/probabilistic-program infrastructure, so frontend design alone is not the paper novelty. External GPT-5.5 idea review was rejected by automatic approval for unpublished payload disclosure and never ran; local assessment is explicitly not independent. Keep work in existing compiler-demos views/history, preserving 30 historical ZIPs and 26 original viewer files.


## Typed field edits and compiler feedback — 13 November 2026

Compiler correctness remains the priority; ADR-023 unchanged. Read docs/compiler_feedback_20261113.md and exp/probabilistic_verification/compiler_feedback_20261112/summary.json. All2375 original/449cached outputs remain byte-identical to compiler_repairs_20261112:1983direct passes/114cached programs. Of403exclusions,376strictly fail;158have drafts(all tested),218lack drafts(no edit request);27direct passes receive no request.

Final fixed method: frozen text-only Qwen3-30B-A3B-Instruct-2507, dependency/SRL/draft input, typed JSON Patch add/replace/remove, max8operations/1536tokens, greedy, shared first attempt then at most2 feedback or generic retries. No whole-form replacement, AMR/model ensemble, per-claim branch selection or meaning-review-triggered retry. Finaljob1228934 completed19m36s on1H100;605unique requests; allresources released.

Sharedfirst41complete/5approved; generic46/8; feedback61/9. Before-model2passes both rejected. All63unique complete final programs inspected by compiler author; not independent gold. Onlyfeedback9 additions enter pool:1981/2375=83.41%,394excluded; all1972oldretained exact. One addition is context-dependent mention Beijing recently, not a complete event/training example. Most old passes not re-reviewed. Feedback improves automatic passes far more than faithful outputs; don't claim20faithful recoveries or merge older whole-form trials.

466tests pass. Frozen158-case CPU replay exact, including all retry files. Typed values prevent malformed shapes, not incorrect roles/scope/numbers. Source grammar checks can reinforce wrong parses(sweep as Robot-kick subject); local edits cannot easily repair root structure. Wind-speed case still fails; authored3-addition fixture is not a model recovery. All earlier trial snapshots/outputs preserved. Existing five report views/two Reports cards/29historical ZIPs/26original viewers preserved. Next proposed: partial forms for218no-draft failures; joint participant/scope/noun checks; bounded structural correction and source-disjoint review. Training/media/SRL retraining remain deferred.


## Compiler repairs and bounded feedback — 12 November 2026

Compiler correctness remains the priority; no empirical training/media inference/SRL retraining. Read docs/compiler_repairs_20261112.md and exp/probabilistic_verification/compiler_repairs_20261112/summary.json. Existing Stanza/AMR already preserve the motivating adjective/reflexive; conversion was defective. Repairs add source-attached missing adjectives, local reflexive identity, unique derivational event references, explicit nested AND/OR, simple likelihood scope, qualified absence and bound speech/OCR quotes. Ambiguous references/missing events still refuse. Rewrite only after strict direct failure.

Completed corpus rerun:1983 direct automatic passes vs1978, no lost statuses. Cached449 yield114 programs (63direct/51composed),13 changed programs inspected:9accepted/4rejected;101exact reviews reused. Seven previously retained changes receive targeted repair review. Retained pool1972/2375=83.03%,403excluded; most older passes not fully re-reviewed. First stops178components/143alignment/65meaning/13composition/1modelrefusal/3uncached. These are development compilation judgments, not accuracy/media labels.438tests pass; historical2375defaultoutputs exact.

Model pilots separate:24 fixed strict failures, maxone compiler-error retry; conservativeQwen30B first0/final1, none faithful; revisedQwenVL8B text-only first3/final3, shotsORexplosions accepted, implication/logo attachments rejected. Model+prompt+compiler snapshots differ, not causal prompt evidence.30Bjob1228116 timed out after completed rewrite rounds, before direct responses.8Bdirect initial prompt lacked format explanation and returned12refusals; separate guided comparison supplies format/example:2/12 pass existing checks, both rejected for purpose/argument representation. Exact prompts/configs/errors and snapshots preserved. Do not pool pilots into full-corpus coverage.

Keep latest results in compiler-demos Overview/Examples/Allclaims/Dailylog, earlier experiments in History; preserve all28 oldZIPs/original26viewers. Next proposed: improve event/mention/source composition; evaluate one fixed guided model condition on remaining failures; review changed programs/source-disjoint claims before relation learning.

## Current priority — compiler correctness, confirmed 12 November 2026

The user does not accept moving forward to training yet: resolve compiler failures first. This supersedes the earlier proposed compiler freeze/training transition; ADR-023 is unchanged. The latest discussion inspects actual saved outputs and code, with no new compiler/model experiment. Ordinary claims expose systematic defects: flat rewrite composition defaults to AND; event nominalizations fail noun-only alignment; local reflexives lack shared referents; likelihood/negation and quoted content lose scope or identity. The 412 first-stop counts remain unchanged and are not a linguistic error taxonomy. Some fragments genuinely lack enough information. Next proposed work: define correct structures and contrasting examples, repair scope and entity/event references in the compiler/composer, then rerun all2,375 claims and review both recoveries and false passes before training.


## Latest compiler stopping-point experiment — 12 November 2026

Read docs/compiler_readiness_20261112.md and exp/probabilistic_verification/compiler_readiness_20261112/summary.json. ADR-023 and failure-only rewriting remain unchanged. Proposed stopping point: freeze broad compiler optimization and begin a small, audited relation-learning experiment. Universal parsing and empirical training readiness are not established.

Completed: all 2,375 originals rerun. Direct automatic passes improve from 1,953 to 1,978 (83.28%); auxiliary filtering alone gives 1,960. Replaying the entire cached 449-case cohort gives 108 complete programs versus 87 (58 direct, 50 composed). All 25 changed complete programs were inspected: 12 retained, including two replacements of already accepted splits. Ten additions result; 83 exact program/form judgments are reused. The retained combined pool is 1,963/2,375 (82.65%), with 412 excluded. Most old passes were not re-reviewed. These are development judgments, not semantic accuracy, media labels or training eligibility.

General repairs filter duplicate auxiliary frames only with an existing lexical-head frame, retain attached adverbs as explicit conditions, and resolve a unique parent interval on an existing event. Scope-sensitive adverbs are excluded from the repair; missing events still cause refusal, including the whole focal terrain claim. Same-day omitted end dates are supported; midnight rollover is refused. Nominal event variables/event_type work on authored collapse checks, but WordNet typing confuses electoral riding and camera shot. Therefore nominals=False by default, excluded from the corpus gains; this is not a trained nominal SRL parser.

First stopping stages among 412 exclusions: component compilation 179, alignment 148 (including 126 noun-head failures), meaning review 68, composition 13, model refusal 1, uncached legacy cases 3. A concise new prompt is proposed but untested. H100 job1227635 and A100 job1227636 were cancelled while pending; the latter was estimated to start the next day. No new model or media requests ran. All 419 earlier responses were replayed with one fixed condition, without per-claim prompt selection.

Native DeepProbLog training was checked on four assistant-inspected color clauses from one development clip, using actual 4,096-dimensional frozen visual features and a 270,595-parameter MLP with 64 hidden units. Thirty CPU epochs use claim labels only; features and old eligibility flags remain unchanged. This is an engineering check that fits four examples, not held-out evidence. Referents, non-color conditions and time are stipulated; no audio or evidence-alignment learning. Initial fixture-sharing errors are preserved in development/ and excluded. All 411 tests pass; the 2,375 historical default outputs remain JSON-identical.

Keep work in the existing compiler-demos Overview, Examples, All claims, Daily log and History. The All claims viewer now shows the updated pool; historical archives/viewer JSONs remain unchanged. Proposed next: audit source-disjoint claims and evidence labels; create checked binding edits and cache features; then compare small classifiers against frozen-model and simple aggregation baselines on held-out videos. Do not wait for 100% parsing. Reopen compiler work for demonstrated experiment blockers, and continue to list concrete next steps and goals in completion reports.

## Latest shared-component experiment — 12 November 2026

User authorized a bounded test of general temporal/quantity normalization, phrase relations, source alignments and checks, then cached replay. Read docs/semantic_components_20261112.md and exp/probabilistic_verification/semantic_components_20261112/summary.json. No new model requests/media inference/empirical training. ADR-023 and direct-failure-only rewriting remain unchanged.

Completed:36 author-written construction probes (2motivating/34variants, not independent heldout) improve targeted checks10/36→34/36. Fixed1437cachedclauses1140→1147pass;87completeprograms on449(previous84). Nine changed/newprograms inspected;78exactprogram/form judgments reused. Thirtycohortoutputs approved(previous27),57notapproved. Three newdate/time recoveries are balanced by three newly reviewed legacy exclusions with opaque temporal/event content: TgR_u37mCoQ4_1831,_1908,_1924. Revised combined pool remains1953/2375=82.23%,422remaining. Do not claim1956 or that allprevious1926acceptedrows remain valid/unchanged.

Automatic DIRECT counts on2375originals also1953before/after, but membership/acceptance differs from reviewedcombinedpool;3newpasses/3newrefusals,123changedprograms. Neither is semanticaccuracy. Shared normalization is opt-in;385tests pass incl25new/2controllednativebindingchecks; default2375outputs exact. Three core files have compatible extensions, including phrase-marker deduplication. Baretimecodes retain unspecifiedscale; explicitT+ elapsed; timezone labels preserved without guessedoffsets. Repeatedtypedtimes keep their types. Bounded motion-reference/spatialphrase inventory, not generalprepositionunderstanding. Focalterrainclaim date/relative repairedlocally, wholeclaimstillfails Duringthis time/shift event reference. Nominalcollapse and ambiguous inrelationto remainprobelimitations.

Current report staysexistingOverview/Examples/fiveviews/twoReportscards. Old449model inspector/sourcebundles remain historical. Proposed next: event/interval coreference, bounded nominal-event analysis, then freeze components and evaluate newclaims before further expansion/training. Detailed provenance/development corrections in newRUN; do not rerun old packagers or overwrite historical proofs.


## Earlier full failure-cohort result — 12 November 2026

The user authorized the bounded role/identifier and measurement/absence repairs, plus rewrite+compilation on ALL449 previous rejects. This supersedes earlier restrictions against expanding the31-case experiment. Read docs/rewrite_all_20261112.md and exp/probabilistic_verification/rewrite_all_20261112/summary.json. ADR-023 and failure-only generation remain unchanged; no new empirical relation training or media inference is authorized by this compilation experiment.

Completed:30 direct automatic passes bypass the model;419 final frozen Qwen requests produce1,437 clauses.207 cases stop at component compilation,142 at alignment,14 at composition,2 at model refusal;54 composed programs plus30 direct programs receive hash-bound compiler-author meaning review.27 additions approved (14direct/13rewrite),57 not approved. Previous1,926 passes retained exactly:1,953/2,375=82.23%;422 remain. This is development compilation coverage with27 newly reviewed additions, NOT semantic accuracy; prior1,926 were not all re-reviewed. Automatic checks alone would retain2,010=84.63%, including unfaithful programs.

Current code adds opt-in repeated adjuncts, measurements/ranges/scalar magnitude, bounded NOT EXISTS absence, explicit participant IDs and source-use alignment. Five original core files have backward-compatible extensions; the historical default exactly reproduces all2,375 saved outputs. The old38-file snapshot is preserved in baseline_source; do not claim current files remain frozen.360 tests pass. Actual native absence checks use constructed inventories, not media. Final H100 job1226791 completed419 requests; initial1226788 completed418 and is entirely excluded. Resources released. One fixed final prompt; no per-claim attempt/prompt selection.

Keep current results and all449 examples in compiler-demos.html Overview/Examples (five views; two Reports cards). Earlier inspectors/URLs/25 archives/26 original viewer files remain. Proposed next: preserve OR/while/modality/source scope in composition; improve class-description/original-span/group reference resolution; replay cached419 responses and review any new programs before another model run or relation training. Keep completion next steps and goals explicit.


## Report organization and communication — confirmed12 November2026

Keep current compiler/rewrite work in the existing compiler-demos.html; do not create a new report page for every iteration. Reports/index.html has two main entries, with old reports under the compiler report History. Main report views: Overview, Examples, All claims, Daily log, History. Preserve old URLs, source bundles and case inspectors. The user also requested fewer interim progress updates: keep them brief and meaningful, and avoid repeating full experiment reports. Required tool/progress communication still applies.

Before the full-cohort experiment, the449 failures included29 tested unrecovered and420 never rewritten. Do not claim the rewrite failed on all19% or infer corpus recovery from the deliberately selected31-case pilot. First checks group227 parser/compiler predicate formation,173 omitted content,43 unsupported operators/types,6 explicit alignment/controller/media checks; these are not a full semantic taxonomy. No new model/compiler experiment in this consolidation. See docs/compiler_report_consolidation_20261112.md.


## Earlier alignment and full-corpus result —12 November2026

Read docs/split_alignment_20261112.md. The user authorized sentences-only generation plus separate original-mention alignment and a fixed evaluation/full-corpus rate. This completed experiment does not authorize unrestricted automatic fallback or new learning. One frozen Qwen prompt on the same31 direct failures returns only action/sentences; a separate module aligns unique original noun/event mentions and refuses ambiguous/unsupported cases. The38 direct-compiler files stay frozen.

Fresh2375 originals exactly reproduce1924 content-check passes (81.01%) and2103 candidates (88.55%). Two reviewed automatic outputs (Trump/image and police officers) in the fixed sentences-only condition yield1926/2375 passes (81.09%),2105 candidates (88.63%),449 failures. These are development compilation counts, not whole-corpus semantic accuracy. No manual clauses counted. The earlier1927 is a separate single-sentence diagnostic, not a cumulative production count.

Old sentences+new alignment recover2 (officers/robot); new sentences-only+alignment recover2 (Trump/officers), with different membership. Do not union best outputs across prompts. The new prompt still invents narration/construction and expands quotes; quantity/source/reference limitations remain. All62 comparisons are assistant reviewed, not independent gold.42 focused tests; source/browser/publication evidence logged separately. Next proposals: bounded participant-ID/source-frame handling, then typed measurement/absence contracts and another full census before expanded evaluation or DeepProbLog training.


## Sentence splitting fallback — user clarification12 November2026

The intended rewrite is split-and-rephrase: break a difficult claim into simpler subclaims while retaining meaning, shared entities/events and depiction/speech/OCR or other context links. The earlier one-sentence restriction was too narrow and is historical. Keep direct compilation first and never rewrite a passing original. No automatic scale-up is enabled.

Read docs/claim_split_20261112.md and the report Sentence splitting tab. One frozen Qwen prompt on31 previously inspected failures produces65/77 passing clauses and20 all-component passes, but0 approved complete automatic results. Seven selected assistant-written splits give18/18 component passes and4 faithful linked compositions; an eighth no-audio guard is refused. These are compiler-author diagnostics, not model gains, independent gold or corpus accuracy. Frozen38 direct-compiler files stay unchanged. New adapter preserves context and shared mentions; original corpus counts stay2103/1924. No new media/native inference/training. Proposed next: simplify generation/reference alignment, then repeat a fixed fidelity evaluation before scale-up.


## Current paper direction — accepted 2026-10-14

Follow ADR-023 in docs/project_notes/decisions.md: probabilistic parsing for multimodal claim verification. Compile claims into probabilistic logic, keep media models frozen, and learn small relation classifiers. Predefined and learned functions are interchangeable; inference considers alternative evidence assignments. An existing DeepProbLog-like backend is a valid implementation choice.

The user selected this as the paper direction, likely finalized. Earlier tree-CRF and temporal-only proposals are historical comparisons. Experimental results can refine the design; do not automatically reopen the paper direction from old notes.

Read site/proposals/probabilistic-verification.html or its generator scripts/build_probabilistic_verification_proposal.py for the current design. Logistic regression and a small MLP are the initial classifiers; frozen BERT-style features are optional. Decoder-only models remain frozen evidence/parsing modules or baselines.

## Terminology and memory

- Read docs/project_notes/terminology.md and CLAUDE.md before writing documentation or implementation.
- Use standard NLP terms and plain language. Define semantic roles, logical forms, neural predicates, and calibration when needed. Do not invent labels or acronyms for familiar components.
- Check decisions.md before architecture changes, key_facts.md before experiments, and bugs.md when diagnosing known failures. Log significant work in issues.md.
- Keep supported/refuted/insufficient evidence distinct, preserve evidence-route meaning, and distinguish source assertions from direct event evidence.
- Keep proposed methods and resource estimates separate from completed experiments. Never infer new accuracy results from this design page.
- Preserve existing evaluation annotations and artifacts. Use separate training/calibration data and split by source video.

## Rewrite fallback — confirmed12 November2026

Compile the original claim first. Only a strict unsupported result may trigger rewriting; this includes a diagnostic candidate rejected by content checks. A compiled original must be returned unchanged, without loading/querying the rewriter. A separate semantic concern is not a trigger when direct compilation passes. Historical passing-control/guard model probes are diagnostic records, not exceptions to this policy. Keep exact prompts, model settings, raw responses and failure reasons inspectable.
