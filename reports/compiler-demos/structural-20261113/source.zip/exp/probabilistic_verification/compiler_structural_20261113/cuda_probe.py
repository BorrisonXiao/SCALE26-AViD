import json,torch
from pathlib import Path
torch.cuda.set_device(0);x=torch.ones((256,256),device='cuda');y=x@x;torch.cuda.synchronize();assert y[0,0].item()==256
p=Path(__file__).resolve().parent/'cuda_probe.json';p.write_text(json.dumps(dict(passed=True,gpu=torch.cuda.get_device_name(0),torch=torch.__version__),indent=2)+'\n');print(p.read_text())
