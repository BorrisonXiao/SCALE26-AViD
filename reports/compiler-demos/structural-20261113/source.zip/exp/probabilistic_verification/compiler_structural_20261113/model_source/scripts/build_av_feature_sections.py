"""Report tabs for the frozen-feature audit and next-step checklist."""
from __future__ import annotations

import base64
from datetime import date
from html import escape as esc
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/"exp/probabilistic_verification/av_features_20261022"


def load(name):
    return json.loads((RUN/name).read_text())


def build_checklist(table):
    data=load("checklist.json")
    updated=date.fromisoformat(data['updated']).strftime('%d %B %Y')
    body='<section class="panel" role="tabpanel" id="next-steps" aria-labelledby="tab-next" hidden><h2>Next steps</h2><p>Updated '+esc(updated)+'. '+esc(data['intro'])+'</p>'
    if data.get('audit_run'):
        body+='<p><a href="#compilation-audit">Open the real-claim compiler audit, measured census and semantic reviews</a>.</p>'
    if data.get('semantic_run'):
        body+='<p><a href="#semantic-compiler">Open compiler improvements, model outputs and temporal inference controls</a>.</p>'
    if data.get('full_compilation_run'):
        body+='<p><a href="claim-compilation.html">Open the 2,375-claim compilation census, per-claim outputs and failure analysis</a>.</p>'
    if data.get('srl_revision_run'):
        body+='<p><a href="srl-compilation.html">Open the SRL-only compiler and separate LLM parse-editing experiments</a>.</p>'
    if data.get("srl_semantics_run"):
        body+='<p><a href="semantic-compilation.html">Open the semantic SRL revision, 24 reference readings and fresh 20-case review</a>.</p>'
    if data.get("compiler_followup_run"):
        body+='<p><a href="compiler-followup.html">Open the compiler follow-up, inference timings and new-source/model reviews</a>.</p>'
    if data.get("scope_compilation_run"):
        body+='<p><a href="scope-compilation.html">Open the source-scope and claim-condition revision</a> · <a href="claim-review.html">Start the human reference review</a>.</p>'
    if data.get("agent_review_run"):
        body+='<p><a href="claim-review-draft.html">Open the review form to download your answers</a>.</p>'
    if data.get("compiler_feedback_run"):
        body+='<p><a href="compiler-demos.html#remaining-failures">Typed field edits and compiler feedback</a>:1,981/2,375 retained (83.41%);394 excluded. On158 failed drafts, feedback61 complete/9 retained versus generic46/8. All1,972 older retained programs unchanged;466 tests pass. <a href="compiler-demos.html#feedback-example">Inspect original parses, edits, prompts and errors</a>. No-draft failures and empirical training remain unresolved.</p>'
    elif data.get("compiler_repairs_run"):
        body+='<p><a href="compiler-demos.html#remaining-failures">Compiler repairs and feedback</a>:1,972/2,375 retained (83.03%);403 excluded. Nine reviewed additions;1,983 direct automatic passes. Nested AND/OR, shared event references and scope repairs are tested. See exact prompts, replies and errors in <a href="compiler-demos.html#repair-model">the model inspector</a>. Empirical training remains deferred.</p>'
    elif data.get("compiler_readiness_run"):
        body+='<p><a href="compiler-demos.html#remaining-failures">Compiler stopping point</a>:1,963/2,375 retained compilations (82.65%);412 excluded. Ten new outputs passed development review. A four-example native DeepProbLog check now trains a small classifier on actual frozen visual features; it is an engineering check, not a held-out method result.</p>'
    elif data.get("semantic_components_run"):
        body+='<p><a href="compiler-demos.html#semantic-components">Shared values and phrase-relation experiment</a>:34/36 targeted construction checks; three reviewed recoveries and three old passes withdrawn. Retained count remains1,953/2,375(82.23%). See the current report for membership and limitations.</p>'
    elif data.get("full_rewrite_run"):
        body+='<p><a href="compiler-demos.html#remaining-failures">Open the complete449-case experiment and current bottlenecks</a> · <a href="compiler-demos.html#full-rewrite-example">Inspect all449 outputs and exact prompts</a>. The previous1,926 passes plus27 reviewed additions give1,953/2,375 (82.23%);422 remain. All84 generated programs were inspected and57 were not approved. These are compiler-author development judgments, not independent semantic accuracy. New empirical relation training remains deferred.</p>'
    elif data.get("claim_rewrite_run"):
        rewrite=json.loads((ROOT/data["claim_rewrite_run"]/"summary.json").read_text())
        body+='<p><a href="compiler-demos.html#rewrite-pilot">Open all 40 rewrite comparisons and the pilot decision</a>. Reviewed faithful recoveries: '+str(rewrite["faithful_target_recoveries"])+'/24 failed development targets. The underlying compiler is unchanged; original corpus counts remain 2,103 programs generated and 1,924 passing content checks. These are not semantic-accuracy estimates.</p>'
    elif data.get("compiler_alert_review_run"):
        body+='<p><a href="compiler-demos.html#alert-review">Open the 11 November alert review</a> · <a href="compiler-demos.html#metric-history">Metric definitions</a> · <a href="compiler-demos.html#stopping-point">Rewrite readiness</a>. Compiler unchanged: 2,103 programs generated, 1,924 pass current content checks. No new semantic-accuracy or rewrite-success result.</p>'
    elif data.get("content_relations_run"):
        body+='<p><a href="compiler-demos.html#current-work">Open the 41 compiler demos and latest changes</a> · <a href="compiler-demos.html#daily-progress">Daily log</a>. All 2,375 original claims were rerun: 1,924 pass checks, 2,103 executable candidates remain, and 291 tests pass. References, profiling and rewriting remain deferred.</p>'
    elif data.get("content_recovery_run"):
        body+='<p><a href="compiler-demos.html">Open the 28 simple compiler demos and current results</a>. All 2,375 original claims were rerun: 1,866 pass checks, 2,103 have executable candidates, and 259 tests pass. Pronoun resolution, larger-program profiling and rewriting remain deferred.</p>'
    elif data.get("scope_coverage_run"):
        body+='<p><a href="scope-coverage.html">Open the scope and missing-content fixes</a>. All 2,375 claims were rerun: 2,099 executable candidates, 1,839 passing the new coverage check, 260 requiring review, and 276 earlier refusals. Eleven programs change; 228 regression checks pass.</p>'
    elif data.get("reviewed_compilation_run"):
        body+='<p><a href="reviewed-compilation.html">Open the returned human review and compiler revision</a>. All twenty reviews are imported. The full run compiles2,099 claims; fresh outputs are unchanged and retain important scope/omission failures.</p>'
    elif data.get("review_followup_run"):
        body+='<p>The user reports completing all twenty cases. The JSON export is awaited; answers are stored in the user’s browser. Twenty fresh cases are reserved before fixes. <a href="verification-pipeline/review-followup/README.md">Read the next-round protocol</a> · <a href="verification-pipeline/review-followup/source.zip">Analysis tools and frozen reservation</a>.</p>'
    for priority,step in enumerate(data["steps"],1):
        body+=f'<h3>{priority}. {esc(step["title"])}</h3><p><strong>{esc(step["status"].replace("_"," "))}</strong></p><ul class="checklist">'
        for item in step["items"]:
            item={"text":item,"done":False} if isinstance(item,str) else item
            body+='<li><span aria-label="'+('completed' if item["done"] else 'pending')+'">'+('☑' if item["done"] else '☐')+'</span> '+esc(item["text"])+"</li>"
        body+='</ul>'
        if step.get("note"):
            body+='<p>'+esc(step["note"])+'</p>'
        if step['id']==7:
            body+=temporal_note(data,table)
    return body+'<p><a href="#audiovisual">Inspect the feature audit and separate evidence trees</a>.</p></section>'


def temporal_note(data,table):
    diagnostic=json.loads((ROOT/data['temporal_diagnostic']['source_path']).read_text())
    body='<h4>Tense and aspect: baseline gap and new prototype</h4><p><strong>The frozen v1 compiler drops these distinctions.</strong> The six-sentence diagnostic below records the unchanged baseline. The new <a href="#semantic-compiler">semantic compiler</a> now emits distinct temporal predicates and tests them with supplied event-time annotations. It does not yet infer temporal observations from real media.</p>'
    body+=table(['Claim','Observed compiler result'],[
        [esc(r['text']),('<code>'+esc(r['logical_form'])+'</code>') if r['status']=='compiled' else 'Rejected: '+esc(r['message'])] for r in diagnostic['records']
    ],'Executed diagnostic on the unchanged compiler. All four spacecraft clauses produce the same predicates. Both Apollo 11 clauses hit the generic counting guard on the numeral in the name; their locations are not yet compiled either.')
    body+='<p><a href="verification-pipeline/'+esc(data['temporal_diagnostic']['artifact'],quote=True)+'">Download exact parses, compiler outputs, versions and hashes</a>.</p>'
    body+='<p><strong>Interpretation and implementation scope:</strong> tense locates an event relative to a context-dependent reference time; aspect describes how the event unfolds. The reference time may come from the narration or the depicted scene, rather than today’s date. Extract English tense/aspect from the auxiliary sequence as well as the main verb: “was landing” is past progressive even though “landing” itself has a present-participle tag.</p>'
    body+=table(['Claim','Tense / aspect to preserve','Evidence condition to represent'],[
        ['Apollo 11 landed on the moon.','Past / simple, non-progressive','Under the ordinary affirmative reading of this landing event: a completed landing before the contextual reference time. Completion depends on the event meaning, not a universal past-tense rule.'],
        ['Apollo 11 is landing on the moon.','Present / progressive','The landing is in progress at the contextual reference time. This does not by itself establish a completed landing.'],
        ['The spacecraft was landing.','Past / progressive','The landing was in progress at a past reference time; its completion is not guaranteed.'],
        ['The spacecraft has landed.','Present / perfect','An earlier landing is presented as completed and relevant at the current contextual reference time.']
    ],'Intended distinctions. The new prototype exercises a narrow episodic interpretation with constructed intervals; it is not a general tense calculus or a real-media temporal model.')
    body+='<p>The new temporal predicates affect executable checks and evidence keys. Temporal questions/features from frozen media models remain to implement and evaluate. A clip showing descent may support an ongoing landing while leaving touchdown unknown. Captions or speech remain typed source evidence; an assertion is not automatically proof of world truth. Historical footage can use a present-tense narrative viewpoint, so present progressive does not automatically mean “happening now in 2026.”</p>'
    body+='<p>A tense edit is not automatically a negative example. One clip may contain both an ongoing landing and its completion; check the intended reference time, event identity and evidence before assigning opposite labels. Window selection locates candidate evidence; tense and aspect specify what the claim requires that evidence to establish. Background definitions: <a href="https://universaldependencies.org/u/feat/Tense.html">UD tense</a>, <a href="https://universaldependencies.org/u/feat/Aspect.html">UD aspect</a>, and the <a href="https://timeml.github.io/site/publications/timeMLdocs/timeml_1.2.1.html">TimeML event/time specification</a>.</p>'
    return body


def tree_figure(trace,figure,svg_dot,q,distribution):
    comp=trace['compilation']
    figures=''
    for ri,(route,label) in enumerate((("visual_depiction","Visual evidence tree"),("non_speech_sound","Audio evidence tree"),("combined","Combined evidence"))):
        lines=['graph [rankdir=LR];']
        branch=next(b for b in trace['branches'] if b['claim_id'].endswith('__'+route))
        prediction=trace['predictions'][branch['claim_id']]['distribution']
        text=label+'\n'+' / '.join(s[0].upper()+': '+f'{prediction[s]:.4f}' for s in ('supported','refuted','unknown'))
        lines.append(f'r{ri} [label={q(text + chr(10) + "AND over required predicates")},fillcolor="#dcece4"];')
        for atom in comp['atoms']:
            entries=[r for r in trace['raw_observations'] if r['atom_id']==atom['id']]
            selected=entries if route=='combined' else [r for r in entries if r['modality']==('visual' if ri==0 else 'audio')]
            eligible=[r for r in selected if r['eligible']]
            detail='unknown: source excluded' if not eligible else ('visual' if eligible[0]['modality']=='visual' else 'audio')+' observation'
            probabilities=eligible[0]['distribution'] if eligible else dict(supported=0.,refuted=0.,unknown=1.)
            detail+='\n'+' / '.join(s[0].upper()+': '+f'{probabilities[s]:.3g}' for s in ('supported','refuted','unknown'))
            shape='entity: fixed perception' if atom['kind']=='entity' else 'attribute: future learned classifier'
            node=f'n{ri}_{atom["id"]}'
            lines.append(node+' [label='+q(atom['predicate']+'('+', '.join(atom['arguments'])+')\n'+detail+'\n'+shape)+'];')
            lines.append(f'r{ri} -> {node} [label="AND"];')
        figures+=figure(svg_dot(lines,label+' for the mixed claim'),
            label+' for “'+esc(trace['case']['text'])+'” Each tree uses the same arguments and AND structure. S, R and U mean supported, refuted and unknown. The current run uses frozen-model probabilities; the feature-based attribute classifiers are not trained yet.')
    return figures


def build_results(figure,table,svg_dot,q,distribution):
    summary=load('feature_summary.json')
    traces=load('av_traces.json')
    reviewed=load('reviewed_claims.json')
    raw={m:load(m+'_features.json') for m in ('visual','audio')}
    records={r['id']:r for d in raw.values() for r in d['records']}
    body='<section class="panel" role="tabpanel" id="audiovisual" aria-labelledby="tab-av" hidden><h2>Frozen features and separate visual/audio trees</h2><p><strong>Executed development pilot.</strong> We extracted real neural representations for 12 propositions under four input conditions in each modality: 96 forward passes in the final audit. The main clip and one unrelated clip are development examples. Features are cached for later learning; the tree inference below still uses frozen-model A/B/C scores. No new classifier was trained and no held-out accuracy is reported.</p>'
    body+='<p class="callout"><strong>Main limitation found:</strong> the audio verifier gives high music support even to silence and text alone. The default chat template fixes the unusable description but does not fix this control failure. The extracted vectors need further checks before training, and the audio model’s proposed labels must not be treated as gold.</p>'
    body+='<div class="download-row"><a href="verification-pipeline/av/feature_summary.json">Feature measurements</a><a href="verification-pipeline/av/av_traces.json">Complete tree traces</a><a href="verification-pipeline/av/av_program.pl">Executed DeepProbLog program</a><a href="verification-pipeline/av/reviewed_claims.json">Edit review and reference labels</a><a href="verification-pipeline/av/source.zip">Source and cached feature replay</a><a href="verification-pipeline/av/tests.xml">Current test results</a></div>'
    body+='<h3>1. Inspect the evidence before choosing an edit</h3><p>The main excerpt is the first 12 seconds of the existing aircraft/bus clip. The visual model receives three cached frames at indices 0, 5 and 10; the audio model receives the 12-second waveform and no frames or transcript. Cached frame indices are nominal sampling times, not independently certified event boundaries. The same window is used for both modalities.</p>'
    images=[]
    for i in (0,5,10):
        p=ROOT/'exp/phase2/media_cache_1fps/frames/zlD_zgNiYJkRV1PS_0000'/f'frame_{i:03d}.jpg'
        images.append('<img alt="Aircraft/bus clip, frame '+str(i)+'" src="data:image/jpeg;base64,'+base64.b64encode(p.read_bytes()).decode()+'">')
    body+=figure('<div class="media-pair av-frames">'+''.join(images)+'</div>',
        'The actual three input frames, before the model’s resize to 252 × 448 pixels. The aircraft is gray and the school buses are yellow. The Alaska text is a printed caption; it is not evidence that anyone says that word.')
    body+='<p><strong>Listen to the exact audio input:</strong></p><audio controls preload="none" src="verification-pipeline/av/vehicles.wav">Your browser does not support WAV playback.</audio><p><a href="verification-pipeline/av/vehicles.wav">Download the 12-second WAV</a>. The assistant could inspect images directly, but the available interface did not permit direct listening. Audio judgments below are model-assisted and remain provisional for your review.</p>'
    body+=table(['Check','Observed output','How it is used'],[
        ['Independent speech recognizer',esc(load('asr.json')['records'][0]['text'])+' (language: '+esc(load('asr.json')['records'][0]['language'])+')','No usable sentence transcript; not a certified speech annotation.'],
        ['Audio-language model inspection',esc(load('audio_inspection.json')[0]['response']),'Audio-only description. Used to propose sound labels, not as independent gold.'],
        ['Assistant review',esc(reviewed['review_note']),'Visual labels are checked from the shown frames. Audio labels need human confirmation.']
    ],'Evidence checks performed before finalizing the displayed edits. The recognizer and audio model receive the waveform, not the captions.')
    body+='<p class="callout">No intelligible speech does not prove there are no sung or hummed vocals. Instrumental/vocal labels below are proposed audio labels, informed by model readouts, and require listening before training. They are not an independently verified test set.</p>'
    body+='<h3>2. Keep the effect of each edit separate by modality</h3><p>S = supported, R = refuted, U = insufficient evidence. These are development reference labels, separate from the model predictions. An audio-only color claim stays U; a silent-frame music claim stays U. The mixed claims require both clauses, but do not require them to occur at the same instant.</p>'
    body+=table(['Claim / edit','Visual reference','Audio reference','Combined reference','Reason and review status'],[
        [esc(t['case']['text'])+'<br><small>'+esc(t['case']['edit'])+'</small>',t['case']['reference']['visual'],t['case']['reference']['audio'],t['case']['reference']['combined'],esc(t['case']['reason'])+'<br><small>'+esc(t['case']['review_status'])+'</small>'] for t in traces
    ],'Edits reviewed under separate evidence policies. All audio-dependent reference labels are provisional; no pair-level label is copied to both branches.')
    body+='<h3>3. Extract media-conditioned features, before an answer</h3><p>The new feature is the final decoder representation at the last prompt token. It is a vector computed from the complete proposition and the attached frames or waveform, before generating an answer. For example, “aircraft is gray” and “school buses are gray” specify different property holders. The target label and paired claim are never included. This is a standard frozen neural representation, rather than the earlier six inputs made from three scores and their logarithms.</p>'
    body+=table(['Branch','Frozen model','Input and selected representation','Measured size'],[
        [m.capitalize(),esc(d['model'].split('/models/')[-1]),'Three resized frames + proposition' if m=='visual' else '12-second waveform + proposition',str(d['dimension'])+' floating-point values per proposition'] for m,d in summary['models'].items()
    ],'Actual models and feature dimensions, read from the saved tensors. The models remain frozen.')
    body+='<p><strong>What is ready:</strong> cached proposition-conditioned vectors, complete prompts, input shapes, media hashes, and control measurements. <strong>Still to do:</strong> implement and train a linear classifier and a small MLP on source-video-disjoint data. These vectors summarize the supplied clip; they are not object-box or speaker-track features. Alternative real entity/event assignments and candidate-localized features still need a larger pilot.</p>'
    body+='<p>Each proposition was run with matched media, an unrelated clothing/stadium clip, blank media of the same shape and duration, and text alone. Matched versus blank retains the exact prompt and token sequence, changing only media content. Text alone removes the media placeholders, so it is a useful diagnostic but not a perfectly matched intervention. An unrelated clip is not automatically a negative example: it may contain the same sound.</p>'
    if summary.get('audio_template_check'):
        body+='<details open><summary>Audio template check and failed controls</summary><p>The initial audio run inserted an empty thinking block. Its main-clip description was whitespace only, and several blank/text-only music questions received high support. We repeated the readouts with the checkpoint’s documented default chat template. The free-text inspection also received an explicit stop token and repetition penalty; its improvement cannot be attributed to the template alone. The table compares classification readouts, which do not use generation settings. The initial outputs are retained, rather than counted as valid audio review.</p>'
        body+=table(['Proposition','Input condition','Initial empty-thinking prefix S / R / U','Official default S / R / U'],[
            [esc(r['proposition']),r['condition'],distribution(r['initial_empty_thinking']),distribution(r['official_default'])] for r in summary['audio_template_check']
        ],'Observed sensitivity to the audio chat template. This is a development control check, not prompt selection on a held-out benchmark.')+'</details>'
    selected={'aircraft_gray','aircraft_yellow','music_instrumental','music_vocal'}
    body+=table(['Branch / proposition','Control','Cosine similarity','Euclidean distance','Same prompt / token IDs'],[
        [esc(r['modality']+' / '+r['proposition_id']),esc(r['condition']),f'{r["cosine"]:.6f}',f'{r["l2"]:.3f}',str(r['same_prompt'])+' / '+str(r['same_input_ids'])] for r in summary['diagnostics'] if r['proposition_id'] in selected and r['condition'] in {'blank','mismatched'}
    ],'Feature sensitivity to media changes. Cosine similarity is 1 for identical vector direction; Euclidean distance is 0 for identical vectors. These changes establish media sensitivity, not label usefulness or generalization.')
    body+='<details><summary>Raw frozen-model predictions for all propositions and controls</summary>'
    body+=table(['Branch','Proposition','Input condition','Raw S / R / U','A/B/C probability mass'],[
        [r['modality'],esc(r['proposition']),r['mode'],distribution(r['distribution']),f'{r["choice_probability_mass"]:.6g}'] for d in raw.values() for r in d['records']
    ],'Uncalibrated next-token scores normalized over A/B/C. The last column is their mass in the full vocabulary; low mass means the three-choice readout is especially questionable. These scores are separate from the hidden feature vectors.')+'</details>'
    alaska=records['visual__alaska_mention__matched']
    body+='<p class="callout"><strong>Observed source error:</strong> the silent-frame model assigns '+f'{100*alaska["distribution"]["supported"]:.2f}'+'% support to “The narrator mentions Alaska,” despite a prompt that excludes captions as speech evidence. That probability remains visible above. This prediction is ineligible under the declared evidence policy: silent frames cannot certify exact spoken words. The claim compiler now rejects “mention” until source/content scope is represented correctly, rather than requiring Alaska to be physically present. Full speech-assertion compilation remains future work.</p>'
    body+='<h3>4. Compile two evidence trees and combine corresponding predicates</h3><p>The compiler supplies one logical form and semantic roles. The visual and audio trees reuse that structure but have distinct observations and verdicts. This pilot uses manually selected referents: the depicted aircraft, the bus group, and the music track. The candidate domain is explicitly limited to those selected referents; this is not automatic tracking or a complete inventory of every possible event.</p><p>The fixed policy assigns depicted color predicates to visual evidence and music predicates to sound evidence. Ineligible sources contribute U, while their raw outputs are retained in the audit. We combine evidence for each predicate with the same candidate assignment, then run the claim’s AND/OR/NOT rules. We do not take the maximum of the two whole-claim scores.</p>'
    body+=table(['First source','Second source','Combined state','Meaning'],[
        ['S','U','S','One eligible source supplies support'],['R','U','R','One eligible source supplies refutation'],
        ['S','S','S','Agreement'],['R','R','R','Agreement'],['S','R','U + conflict diagnostic','Do not silently choose a source'],['U','U','U','No sufficient evidence']
    ],'Fixed, symmetric evidence-combination rule for sources that mean the same proposition. A source assertion and direct event evidence are not interchangeable. Source disagreements remain visible in the diagnostic trace.')
    mixed=next(t for t in traces if t['case']['id']=='mixed_original')
    body+='<p>In these diagrams, <code>X1</code> is the selected aircraft and <code>X2</code> is the selected music track. <code>entity</code> checks presence/type under the declared source policy; <code>attribute</code> checks a property attached to that same referent. The two clauses concern different referents. This example does not test whether a visible person is the source of a particular voice; automatic audio-visual identity matching remains open.</p>'
    body+=tree_figure(mixed,figure,svg_dot,q,distribution)
    body+=table(['Claim','Visual tree S / R / U','Audio tree S / R / U','Combined tree S / R / U'],[
        [esc(t['case']['text'])]+[distribution(next(p['distribution'] for cid,p in t['predictions'].items() if cid.endswith('__'+route))) for route in ('visual_depiction','non_speech_sound','combined')] for t in traces
    ],'Actual DeepProbLog verdicts using the frozen scores and declared source policy. No feature classifier or gold label is used to produce these probabilities.')
    body+='<details><summary>Inspect the mixed claim: parse, predicates, selected features, and exact source-specific observations</summary>'
    body+='<pre>'+esc(mixed['compilation']['logical_form'])+'</pre>'
    body+=table(['Compiled predicate','Semantic roles','Selected source','Frozen prediction used','Feature key for later training'],[
        ['<code>'+esc(a['predicate']+'('+', '.join(a['arguments'])+')')+'</code>',esc(', '.join(a['roles'])),esc(r['modality']),distribution(r['distribution']),'<code>'+esc(r['feature_key'])+'</code>'] for a in mixed['compilation']['atoms'] for r in mixed['raw_observations'] if r['atom_id']==a['id'] and r['eligible']
    ],'The complete proposition is used when extracting each relation feature. Entity observations stay fixed. Attribute feature vectors are cached for the later learned classifier.')
    body+='<pre>'+esc(json.dumps(mixed,indent=2))+'</pre></details>'
    suites=ET.parse(RUN/'tests.xml').getroot().findall('testsuite')
    count=sum(int(s.get('tests',0)) for s in suites)
    body+='<h3>5. Checks and limits</h3><p>'+str(count)+' automated tests pass. The new tests cover complementary evidence when both separate roots are unknown, support/refutation conflicts, ineligible-source exclusion with raw scores retained, and candidate-identity alignment. Every displayed root agrees with independent categorical-world enumeration within one ten-billionth and sums to one within one billionth.</p><p>Probability aggregation still assumes independent local observations except where canonical keys explicitly share them. Repeated questions to the same frozen model can be correlated; these probabilities are not calibrated confidence guarantees. The conflict examples in the automated tests use stipulated inputs, not observed cross-modal contradictions in this clip.</p>'
    execution=load('execution.json')
    body+='<details><summary>Measured resource use, including revisions</summary>'
    body+=table(['Run','GPU allocation','Slurm wall time','Status'],[
        [esc(j['purpose'])+' ('+str(j['job'])+')',str(j['gpus'])+' × '+esc(j['gpu']),str(j['elapsed_seconds'])+' seconds',j['state']] for j in execution['jobs']
    ],'Actual job accounting. Includes failed setup and cold loading, not only successful feature passes. This is not a training-efficiency benchmark.')
    body+='<p>Total allocated GPU time across these jobs: '+f'{execution["total_allocated_gpu_hours"]:.3f}'+' GPU-hours, computed as allocated GPU count times job wall time. The final feature runs took 26 seconds on one A100-40GB and 157 seconds on two A100-40GB GPUs. The source archive includes CPU replay of all displayed tree probabilities and feature diagnostics.</p></details>'
    body+=table(['Completed now','Still needed'],[
        ['Real visual/audio representations and media controls','Verify their label usefulness on multiple source videos'],
        ['Separate source trees and actual exact inference','Automatic candidate detection and alternative real assignments'],
        ['Per-modality edit review with explicit label provenance','Human audio confirmation and a larger independently reviewed pilot'],
        ['Caption-to-speech failure exposed; unsupported scope rejected','Represent quoted/mentioned content and source assertions explicitly'],
        ['Frozen model scores as a baseline','Train feature-based relation classifiers, then evaluate held-out claims']
    ],'The boundary between the executed pilot and the remaining method experiments.')
    body+='<p><a href="#next-steps">Open the project checklist</a>.</p></section>'
    return body


def write_downloads(output):
    import torch
    target=output.parent/'verification-pipeline/av'
    target.mkdir(parents=True,exist_ok=True)
    names=['feature_summary.json','av_traces.json','av_program.pl','reviewed_claims.json','checklist.json','asr.json','audio_inspection.json','visual_features.json','audio_features.json','propositions.json','av_parses.json','av_parser_provenance.json','tests.xml','vehicles.wav','clothing.wav','execution.json']
    for name in names:
        shutil.copyfile(RUN/name,target/name)
    files={str(Path('exp/probabilistic_verification/av_features_20261022')/name):(RUN/name).read_bytes() for name in names}
    temporal=load('checklist.json')['temporal_diagnostic']
    source_path=ROOT/temporal['source_path']
    shutil.copyfile(source_path,output.parent/'verification-pipeline'/temporal['artifact'])
    files[temporal['source_path']]=source_path.read_bytes()
    for name in ('audio_features.json','audio_inspection.json'):
        p=RUN/'initial_audio_template'/name
        files[str(Path('exp/probabilistic_verification/av_features_20261022/initial_audio_template')/name)]=p.read_bytes()
        (target/'initial_audio_template').mkdir(exist_ok=True)
        shutil.copyfile(p,target/'initial_audio_template'/name)
    for m in ('visual','audio'):
        values=torch.load(RUN/(m+'_features.pt'),map_location='cpu',weights_only=True)
        values={k:v for k,v in values.items() if k.endswith('__joint')}
        path=RUN/(m+'_joint_features.pt')
        torch.save(values,path)
        files[str(Path('exp/probabilistic_verification/av_features_20261022')/(m+'_features.pt'))]=path.read_bytes()
    source=list((ROOT/'scripts/probabilistic_verification').glob('*.py'))+[ROOT/'scripts'/n for n in ('run_av_features.py','run_av_features.slurm','run_av_audio_review.py','run_av_audio_review.slurm','analyze_av_features.py','build_av_feature_sections.py','prompts_phase2.py')]+[ROOT/'tests'/n for n in ('test_probabilistic_verification.py','test_multimodal_verification.py')]+[ROOT/'scripts/run_verification_pipeline.py',ROOT/'requirements-verification.txt']
    files.update({str(p.relative_to(ROOT)):p.read_bytes() for p in source})
    files['README.md']=b'Cached replay: install requirements-verification.txt in an isolated environment, then run PYTHONPATH=scripts python scripts/analyze_av_features.py. Saved parses, raw scores, reviewed labels, and joint feature tensors are included; no GPU or model download is needed for replay. The full audio encoder token sequences remain in the project run directory; this archive includes only the joint vectors used by the diagnostics. GPU extraction scripts require the named local model checkpoints and media cache. Audio labels are model-assisted and provisional, not human-certified test annotations.\n'
    with zipfile.ZipFile(target/'source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for name,content in sorted(files.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,10,22,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,content)
