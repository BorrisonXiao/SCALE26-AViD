"""Small JSON Patch edits to an existing failed logical form."""
import copy,json
from .compiler_feedback import inspect,schema as form_schema
SYSTEM='''Correct the existing failed parse using a short list of field edits. Preserve the original claim and every correct part of the current form. Do not regenerate the whole form. Do not add redundant entities or invent events to cover words. Keep subjects/objects, modifiers, counts, time, uncertainty, negation and source context attached correctly. A purpose is not an independent event that happened. The parser annotations may be wrong; the original claim controls meaning.
Return {"action":"edit","edits":[{"op":"add/replace/remove","path":"/field/...","value":...}]} with at most8 edits. Paths use JSON Pointer: /entities/0 is the first entity; /entities/- appends one. Remove omits value. Add can create a missing field; replace changes an existing field. Apply edits in order. Add overwrites an existing object field: use /- to append to an existing array and preserve its current items. Use the provided allowed_paths. Never replace /formula or /entities wholesale. A string argument is a declared entity ID; ordinary values use typed objects. Omit optional fields that do not apply. Return action=refuse, edits=[] if no faithful small correction is possible.
Example: when a boats entity already has a wooden modifier and lacks Narrow, append {"role":"mod","value":"Narrow"} at /entities/0/properties/-. For "Small boats float", if the boats entity lacks Small, add /entities/0/properties with value [{"role":"mod","value":"Small"}]. For a missing subject, add its source noun entity if necessary, then add its ID in the proper core argument of the existing event. Use one shared entity ID throughout. Inspect every compiler diagnostic and correct the indicated binding or scope; do not merely paste omitted words into a string.'''

def clean(form):
 out=copy.deepcopy(form)
 for key in ['version','warnings','status','reason','requires_context']:out.pop(key,None)
 return out

def pointer(parts):return '/'+('/'.join(str(x).replace('~','~0').replace('/','~1')for x in parts))
def allowed_paths(form):
 paths=set()
 def visit(v,p=()):
  if isinstance(v,dict):
   for k,x in v.items():paths.add(pointer(p+(k,)));visit(x,p+(k,))
   extras=[]
   if p==():return
   if 'id'in v and 'text'in v:extras=['properties','relations','quantity','propositions','type']
   if v.get('op')=='event':extras=['properties','propositions','adjuncts','arguments']
   if p[-1:] ==('arguments',):extras=['ARG0','ARG1','ARG2','ARG3','ARG4','ARG5','ARGM-LOC','ARGM-TMP','ARGM-MNR','ARGM-DIR','ARGM-CAU','ARGM-PRP','nsubj','obj','iobj']
   for k in extras:paths.add(pointer(p+(k,)))
  elif isinstance(v,list):
   paths.add(pointer(p+('-',)))
   for i,x in enumerate(v):paths.add(pointer(p+(i,)));visit(x,p+(i,))
 visit(form);return sorted(paths-{'/formula','/entities','/kind'})

def generic_edit_schema(form):
 ref={'$ref':'#/$defs/value'};value=dict(anyOf=[dict(type='string'),dict(type='number'),dict(type='boolean'),dict(type='null'),dict(type='array',items=ref),dict(type='object',additionalProperties=ref)])
 operation=dict(anyOf=[dict(type='object',properties=dict(op=dict(type='string',enum=['add','replace']),path=dict(type='string',enum=allowed_paths(form)),value=ref),required=['op','path','value'],additionalProperties=False),dict(type='object',properties=dict(op=dict(type='string',enum=['remove']),path=dict(type='string',enum=allowed_paths(form))),required=['op','path'],additionalProperties=False)])
 return dict(type='object',properties=dict(action=dict(type='string',enum=['edit','refuse']),edits=dict(type='array',items=operation,maxItems=8)),required=['action','edits'],additionalProperties=False,**{'$defs':dict(value=value)})

def edit_schema(form,base_schema=None):
    if base_schema is None:return generic_edit_schema(form)
    definitions=copy.deepcopy(base_schema.get('$defs',{}));groups={}
    def resolve(spec,data):
        for _ in range(20):
            if '$ref'in spec:spec=definitions[spec['$ref'].split('/')[-1]];continue
            if 'anyOf'not in spec:return spec
            options=spec['anyOf'];selected=None
            for option in options:
                choice=resolve(option,data)if '$ref'in option else option
                if isinstance(data,dict)and 'op'in data and data['op']in choice.get('properties',{}).get('op',{}).get('enum',[]):selected=option;break
                if isinstance(data,str)and(choice.get('type')=='string'or data in choice.get('enum',[])):selected=option;break
                if isinstance(data,dict)and choice.get('type')=='object':selected=option
                if isinstance(data,list)and choice.get('type')=='array':selected=option
            spec=selected or options[0]
        raise ValueError('Schema reference depth exceeds20.')
    def expected(parts):
        spec=base_schema;data=form
        for part in parts:
            spec=resolve(spec,data)
            if isinstance(data,list)or spec.get('type')=='array':
                spec=spec['items'];data=None if part=='-'or int(part)>=len(data or[])else data[int(part)]
            else:
                props=spec.get('properties',{})
                if part in props:spec=props[part]
                elif isinstance(spec.get('additionalProperties'),dict):spec=spec['additionalProperties']
                else:return None
                data=data.get(part)if isinstance(data,dict)else None
        return copy.deepcopy(spec)
    paths=allowed_paths(form)
    for p in paths:
        parts=[x.replace('~1','/').replace('~0','~')for x in p[1:].split('/')]
        spec=expected(parts)
        if not spec:continue
        key=json.dumps(spec,sort_keys=True);groups.setdefault(key,dict(spec=spec,paths=[]))['paths'].append(p)
    operations=[];removable=[]
    def location(p):
        parts=[x.replace('~1','/').replace('~0','~')for x in p[1:].split('/')];parent=form
        try:
            for part in parts[:-1]:parent=parent[int(part)]if isinstance(parent,list)else parent[part]
        except (KeyError,IndexError,TypeError):return None,parts[-1],False,[]
        key=parts[-1];exists=(key!='-'and int(key)<len(parent))if isinstance(parent,list)else key in parent
        parent_schema=expected(parts[:-1]);required=resolve(parent_schema,parent).get('required',[])if parent_schema else[]
        return parent,key,exists,required
    for p in paths:
        parent,key,exists,required=location(p)
        if exists and key not in required:removable.append(p)
    for i,g in enumerate(groups.values()):
        name='edit_value_'+str(i);definitions[name]=g['spec']
        for op in ['add','replace']:
            available=[]
            for p in g['paths']:
                parent,key,exists,required=location(p)
                if parent is None:continue
                if op=='replace'and exists or op=='add'and(isinstance(parent,dict)or key=='-'):available.append(p)
            if available:operations.append(dict(type='object',properties=dict(op=dict(type='string',enum=[op]),path=dict(type='string',enum=available),value={'$ref':'#/$defs/'+name}),required=['op','path','value'],additionalProperties=False))
    if removable:operations.append(dict(type='object',properties=dict(op=dict(type='string',enum=['remove']),path=dict(type='string',enum=removable)),required=['op','path'],additionalProperties=False))
    return dict(type='object',properties=dict(action=dict(type='string',enum=['edit','refuse']),edits=dict(type='array',items=dict(anyOf=operations),maxItems=8)),required=['action','edits'],additionalProperties=False,**{'$defs':definitions})


def apply(form,edits):
 out=copy.deepcopy(form)
 for i,e in enumerate(edits):
  p=e['path']
  if p in{'/formula','/entities','/kind'}or not p.startswith('/'):raise ValueError('A whole form cannot be replaced.')
  parts=[x.replace('~1','/').replace('~0','~')for x in p[1:].split('/')];target=out
  for k in parts[:-1]:target=target[int(k)]if isinstance(target,list)else target[k]
  key=parts[-1]
  if isinstance(target,list):
   index=len(target)if key=='-'else int(key)
   if e['op']=='add':
    if index<0 or index>len(target):raise IndexError('Array insertion index out of bounds.')
    target.insert(index,copy.deepcopy(e['value']))
   elif e['op']=='remove':target.pop(index)
   else:target[index]=copy.deepcopy(e['value'])
  elif e['op']=='remove':del target[key]
  else:
   if e['op']=='replace'and key not in target:raise KeyError('Replace needs an existing field: '+p)
   target[key]=copy.deepcopy(e['value'])
 return out

def evaluate(record,current,data,base_schema):
 import jsonschema
 from .logical_form_v2 import parse_form
 try:
  data=parse_form(data)if isinstance(data,str)else data;jsonschema.validate(data,edit_schema(current,base_schema))
  if data['action']=='refuse':return current,dict(status='unsupported',code='model_refuse',reason='Model declined a small faithful correction.'),[]
  if not data['edits']:raise ValueError('An edit response needs at least one change.')
  result=apply(current,data['edits']);output,feedback=inspect(record,dict(result,action='repair'),base_schema,detailed=True,semantic_checks=True)
  return result,output,feedback
 except Exception as e:return current,dict(status='unsupported',code='edit_error',reason=str(e)),[dict(code='edit_error',path='$',message=str(e))]

def make_request(record,previous,base_schema,guided=True):
 from .compiler_feedback import OUTPUT_FORMAT
 form=previous['current_form'];data=dict(claim=record['text'],syntax=[{k:t.get(k)for k in['id','text','lemma','upos','head','deprel','feats']}for t in record['tokens']],srl=record.get('srl',{}).get('frames',[]),current_form=form,allowed_paths=allowed_paths(form),logical_form_format=OUTPUT_FORMAT)
 if guided:data['compiler_feedback']=previous['feedback']
 else:data['instruction']='The current correction failed a compiler check. Revise it carefully without changing the original meaning.'
 if previous.get('raw'):data['previous_edits']=previous['raw']
 return data,edit_schema(form,base_schema)
