"""One fixed structural-correction condition, with a shared-first-attempt control."""
import argparse,copy,importlib.metadata,json,os,time
from pathlib import Path
from probabilistic_verification.compiler_feedback import current_form,schema
from probabilistic_verification.logical_form_edits import clean
from probabilistic_verification.structural_edits import SYSTEM,request,evaluate,validate

def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def prepare(run):
 records={r['claim_id']:r for r in read(run/'inputs.jsonl')};initial={};schemas={}
 for d in read(run/'selected_drafts.jsonl'):
  cid=d['claim_id'];f=clean(current_form(d)or d['partial_form']);base=schema(records[cid],f);schemas[cid]=base
  out,feedback=validate(records[cid],f,base)
  # A partial AST is never promoted by the adapter before an actual correction.
  native=out
  if out['status']=='compiled':out=dict(status='unsupported',code='requires_correction',reason='The original failed. This adapter draft still requires an explicit model correction and meaning review.')
  feedback=[dict(code=d.get('code'),path='$',message=d.get('reason'))]+feedback
  initial[cid]=dict(claim_id=cid,text=d['text'],draft_source=d['draft_source'],current_form=f,output=out,precheck_output=native,feedback=feedback,direct_compiler_error={k:d.get(k)for k in['code','reason']},partial_details=d.get('partial_details'))
 write(run/'before.jsonl',list(initial.values()));return records,initial,schemas

def main():
 os.environ.setdefault('VLLM_WORKER_MULTIPROC_METHOD','spawn')
 parser=argparse.ArgumentParser();parser.add_argument('--run',type=Path,required=True);parser.add_argument('--prepare-only',action='store_true');args=parser.parse_args();run=args.run.resolve();records,initial,schemas=prepare(run)
 if args.prepare_only:
  import jsonschema
  for cid,previous in initial.items():
   data,output_schema=request(records[cid],previous,schemas[cid]);jsonschema.Draft202012Validator.check_schema(output_schema);json.dumps(data)
  print('Validated',len(initial),'requests; no model loaded.');return
 import torch
 from transformers import AutoTokenizer
 from vllm import LLM,SamplingParams
 from vllm.sampling_params import StructuredOutputsParams
 path='/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507';tokenizer=AutoTokenizer.from_pretrained(path,local_files_only=True);torch.set_num_threads(4);model=LLM(model=path,tokenizer=path,dtype='float16',tensor_parallel_size=1,gpu_memory_utilization=0.90,max_model_len=32768,max_num_seqs=4,enable_prefix_caching=True,seed=0)
 config=dict(model=path,backend='vllm+xgrammar',dtype='float16',temperature=0,max_new_tokens=2048,batch_size=4,max_edits=4,max_retries=2,shared_first=True,original_error_in_both_branches=True,job_id=os.getenv('SLURM_JOB_ID'),vllm=importlib.metadata.version('vllm'),torch=torch.__version__,source=str(Path(__file__).resolve()),gpus=[torch.cuda.get_device_name(i)for i in range(torch.cuda.device_count())]);(run/'config.json').write_text(json.dumps(config,indent=2)+'\n')
 def generate(previous,folder,guided):
  folder.mkdir(exist_ok=True);saved=read(folder/'responses.jsonl')if(folder/'responses.jsonl').exists()else[];done={r['claim_id']for r in saved};pending=[r for r in previous.values()if r['output']['status']!='compiled'and r['output'].get('code')!='model_refuse'and r['claim_id']not in done]
  for start in range(0,len(pending),4):
   batch=pending[start:start+4];messages=[];parameters=[]
   for old in batch:
    cid=old['claim_id'];data,output_schema=request(records[cid],old,schemas[cid],guided);messages.append([dict(role='system',content=SYSTEM),dict(role='user',content=json.dumps(data,ensure_ascii=False,separators=(',',':')))]);parameters.append(SamplingParams(temperature=0,max_tokens=2048,structured_outputs=StructuredOutputsParams(json=output_schema,disable_any_whitespace=True)))
   prompts=[tokenizer.apply_chat_template(m,tokenize=False,add_generation_prompt=True)for m in messages];started=time.perf_counter();outputs=model.generate(prompts,parameters,use_tqdm=False);elapsed=time.perf_counter()-started
   for old,m,result in zip(batch,messages,outputs):
    cid=old['claim_id'];q=result.outputs[0];f,out,feedback=evaluate(records[cid],old['current_form'],q.text,schemas[cid]);saved.append(dict(old,messages=m,raw=q.text,current_form=f,output=out,feedback=feedback,finish_reason=q.finish_reason,output_tokens=len(q.token_ids),batch_seconds=elapsed))
   write(folder/'responses.jsonl',saved);print(folder.name,len(saved),'compiled',sum(r['output']['status']=='compiled'for r in saved),flush=True)
  return{r['claim_id']:r for r in saved}
 first=copy.deepcopy(initial);first.update(generate(first,run/'first',True));write(run/'first_final.jsonl',list(first.values()))
 for branch in['feedback','generic']:
  final=copy.deepcopy(first)
  for i in[1,2]:final.update(generate(final,run/(branch+'_'+str(i)),branch=='feedback'))
  write(run/(branch+'_final.jsonl'),list(final.values()))
 print('Completed structural correction and retry control.',flush=True)
if __name__=='__main__':main()
