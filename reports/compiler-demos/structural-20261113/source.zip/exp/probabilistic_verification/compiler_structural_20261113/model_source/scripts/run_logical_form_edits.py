"""Failure-only field edits, with a shared first attempt and bounded retry control."""
import argparse,copy,hashlib,importlib.metadata,json,os,time
from pathlib import Path
import torch
from transformers import AutoTokenizer
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.compiler_feedback import current_form,schema,inspect,OUTPUT_FORMAT
from probabilistic_verification.logical_form_edits import SYSTEM,clean,edit_schema,evaluate,allowed_paths,make_request

def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def main():
 os.environ.setdefault('VLLM_WORKER_MULTIPROC_METHOD','spawn')
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--prepare-only',action='store_true');p.add_argument('--control',action='store_true');a=p.parse_args();run=a.run.resolve();run.mkdir(exist_ok=True,parents=True);records=read(a.input);by={r['claim_id']:r for r in records};routes=[];current={};base_schemas={};initial={}
 for r in records:
  cid=r['claim_id'];d=compile_one(r);draft=current_form(d);routes.append(dict(claim_id=cid,direct_status=d['status'],direct_code=d.get('code'),has_draft=bool(draft)))
  if d['status']=='compiled'or not draft:continue
  f=clean(draft);base_schemas[cid]=schema(r,draft);out,feedback=inspect(r,dict(f,action='repair'),base_schemas[cid],detailed=True,semantic_checks=True);current[cid]=f;initial[cid]=dict(claim_id=cid,text=r['text'],current_form=f,output=out,feedback=feedback)
 write(run/'routing.jsonl',routes);write(run/'before.jsonl',list(initial.values()))
 if a.prepare_only:
  import jsonschema
  for cid,old in initial.items():
   data,proposal_schema=make_request(by[cid],old,base_schemas[cid]);jsonschema.Draft202012Validator.check_schema(proposal_schema);json.dumps(data)
  print('Validated',len(initial),'complete model requests without loading weights.');return
 from vllm import LLM,SamplingParams
 from vllm.sampling_params import StructuredOutputsParams
 path='/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507';tok=AutoTokenizer.from_pretrained(path,local_files_only=True);torch.set_num_threads(4);model=LLM(model=path,tokenizer=path,dtype='float16',tensor_parallel_size=1,gpu_memory_utilization=0.90,max_model_len=32768,max_num_seqs=4,enable_prefix_caching=True,seed=0)
 config=dict(model=path,backend='vllm+xgrammar',dtype='float16',temperature=0,max_new_tokens=1536,batch_size=4,max_edits=8,max_retries=2,typed_values=True,control=a.control,job_id=os.getenv('SLURM_JOB_ID'),vllm=importlib.metadata.version('vllm'),torch=torch.__version__,source=str(Path(__file__).resolve()),gpus=[torch.cuda.get_device_name(i)for i in range(torch.cuda.device_count())]);(run/'config.json').write_text(json.dumps(config,indent=2)+'\n')
 def generate(previous,folder,guided):
  folder.mkdir(exist_ok=True);saved=read(folder/'responses.jsonl')if(folder/'responses.jsonl').exists()else[];done={r['claim_id']for r in saved};rows=[r for r in previous.values()if r['output']['status']!='compiled'and r['output'].get('code')!='model_refuse'and r['claim_id']not in done]
  for start in range(0,len(rows),4):
   batch=rows[start:start+4];messages=[];schemas=[]
   for old in batch:
    cid=old['claim_id'];data,proposal_schema=make_request(by[cid],old,base_schemas[cid],guided)
    messages.append([dict(role='system',content=SYSTEM),dict(role='user',content=json.dumps(data,ensure_ascii=False,separators=(',',':')))]);schemas.append(proposal_schema)
   prompts=[tok.apply_chat_template(m,tokenize=False,add_generation_prompt=True)for m in messages];params=[SamplingParams(temperature=0,max_tokens=1536,structured_outputs=StructuredOutputsParams(json=s,disable_any_whitespace=True))for s in schemas];started=time.perf_counter();outputs=model.generate(prompts,params,use_tqdm=False);elapsed=time.perf_counter()-started
   for old,m,out in zip(batch,messages,outputs):
    q=out.outputs[0];cid=old['claim_id'];form,result,feedback=evaluate(by[cid],old['current_form'],q.text,base_schemas[cid]);saved.append(dict(claim_id=cid,text=old['text'],messages=m,raw=q.text,current_form=form,output=result,feedback=feedback,finish_reason=q.finish_reason,output_tokens=len(q.token_ids),batch_seconds=elapsed))
   write(folder/'responses.jsonl',saved);print(folder.name,len(saved),'compiled',sum(r['output']['status']=='compiled'for r in saved),flush=True)
  return {r['claim_id']:r for r in saved}
 first=copy.deepcopy(initial);first.update(generate(first,run/'first',True));write(run/'first_final.jsonl',list(first.values()))
 for branch in ['feedback','generic']if a.control else['feedback']:
  final=copy.deepcopy(first)
  for attempt in[1,2]:final.update(generate(final,run/(branch+'_'+str(attempt)),branch=='feedback'))
  write(run/(branch+'_final.jsonl'),list(final.values()))
 print('Completed field-edit conditions.',flush=True)
if __name__=='__main__':main()
