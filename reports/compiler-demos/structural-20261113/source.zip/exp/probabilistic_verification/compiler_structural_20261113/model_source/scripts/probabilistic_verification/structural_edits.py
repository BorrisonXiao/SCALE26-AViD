"""Typed field edits plus replacement of an existing logical subtree."""
import copy,json,re
import jsonschema
from .logical_form_edits import clean,edit_schema,apply,pointer
from .compiler_feedback import inspect,OUTPUT_FORMAT
from .feedback_semantics import issues as source_issues
from .scoped_srl import SourceSyntax
from .srl_revision import TokenAlignment

SYSTEM='''Repair the existing logical form to preserve the original claim. Syntax and SRL are fallible evidence. Return action=edit with at most4 JSON Patch add/replace/remove operations, or action=refuse with edits=[]. Use field edits when enough; replace one logical subtree when its root, roles or scope is wrong. Keep correct parts, original names, modifiers, numbers, uncertainty and source context. A quoted statement is not an independently asserted world event. Share the same entity ID for a participant across its related clauses. Do not paste clauses into properties or text literals to bypass structure. A partial draft is unfinished: detached fragments are not independent assertions. Complete its missing relationships using the original sentence. Values must match the supplied field types.
Examples: in "The car drives onto the curb in order to get around traffic", get-around is a purpose of drive and both events have the car as participant. In "A says that B left", left is inside A's assertion; the sentence does not independently assert B left. Return compact JSON edits only.'''

def subtree_paths(form):
 paths=[]
 def visit(v,p=()):
  if isinstance(v,dict):
   if 'op'in v:paths.append(pointer(p))
   for k,x in v.items():visit(x,p+(k,))
  elif isinstance(v,list):
   for i,x in enumerate(v):visit(x,p+(i,))
 visit(form)
 return paths

def proposal_schema(form,base):
 out=edit_schema(form,base)
 out['properties']['edits']['maxItems']=4
 operations=out['properties']['edits']['items']['anyOf']
 operations.append(dict(type='object',properties=dict(op=dict(type='string',enum=['replace']),path=dict(type='string',enum=subtree_paths(form)),value={'$ref':'#/$defs/node'}),required=['op','path','value'],additionalProperties=False))
 operations.append(dict(type='object',properties=dict(op=dict(type='string',enum=['replace']),path=dict(type='string',enum=['/kind']),value=dict(type='string',enum=['claim','mention'])),required=['op','path','value'],additionalProperties=False))
 return out

def apply_edits(form,edits):
 out=copy.deepcopy(form)
 for edit in edits:
  if edit['path']in{'/formula','/kind'}:
   if edit['op']!='replace':raise ValueError('The root can only be replaced by a typed value.')
   out[edit['path'][1:]]=copy.deepcopy(edit['value'])
  else:out=apply(out,[edit])
 return out

def additional_issues(record,form):
 """Joint source checks use agreement; a dependency-only subject is advisory."""
 alignment=TokenAlignment(record);s=SourceSyntax(record);entities={e['id']:e for e in form['entities']};hard=[];advice=[];events=[]
 def visit(v):
  if isinstance(v,dict):
   if v.get('op')=='event':events.append(v)
   for x in v.values():visit(x)
  elif isinstance(v,list):
   for x in v:visit(x)
 visit(form['formula'])
 frames={}
 for f in(record.get('srl')or{}).get('frames',[]):
  if isinstance(f.get('verb_span'),list):
   selected=alignment.selected(*f['verb_span'])
   for token in selected:frames[token['id']]=f
 for issue in source_issues(record,form):
  if issue['code']=='subject_binding':
   subject=issue['source_subject'];frame=frames.get(subject['head']);agree=False
   for arg in(frame or{}).get('args',[]):
    if re.fullmatch(r'ARG[0-5A]',arg['role']):agree |= any(t['id']==subject['id']for t in alignment.selected(arg['start'],arg['end']))
   if not agree:advice.append(dict(issue,severity='warning',message=issue['message']+' SRL does not independently confirm this dependency subject; check the original wording.'));continue
  hard.append(issue)
 # A numeric-modifier edge needs a numeral, not another object referent.
 numeric_words={'one','two','three','four','five','six','seven','eight','nine','ten','first','second','third'}
 for i,e in enumerate(form['entities']):
  for j,edge in enumerate(e.get('relations',[])):
   if edge['role']!='nummod'or edge['target']not in entities:continue
   target=entities[edge['target']]['text']
   if not any(t['upos']=='NUM'for t in s.tokens if t['text'].lower()in target.lower().split())and target.lower()not in numeric_words:
    hard.append(dict(code='numeric_modifier_type',path=f'$.entities[{i}].relations[{j}]',message='A numeric-modifier relationship must point to a numeral or use a quantity/property; it cannot point to another object such as '+target+'.'))
 # An infinitival purpose with a subject agreed by SRL and dependencies shares
 # that participant. Object control is handled by the existing parser instead.
 for event in events:
  anchors=[t for t in s.tokens if t['text'].lower()==event.get('anchor','').lower()]
  if len(anchors)!=1:continue
  token=anchors[0]
  if token['deprel']!='advcl'or not any(t['deprel']=='mark'and t['text'].lower()=='to'for t in s.children[token['id']]):continue
  if any(t['deprel'].startswith('nsubj')for t in s.children[token['id']]):continue
  child_frame=frames.get(token['id'],{})
  if any(a['role']=='ARG0'for a in child_frame.get('args',[])):continue
  if 'Voice=Pass'in(token.get('feats')or'')and any(a['role']=='ARG1'for a in child_frame.get('args',[])):continue
  parent=s.by_id.get(token['head']);frame=frames.get(token['head'])
  if not parent or not frame:continue
  subjects=[t for t in s.children[parent['id']]if t['deprel'].startswith('nsubj')]
  if len(subjects)!=1:continue
  subject=subjects[0];agreed=any(a['role']=='ARG0'and any(t['id']==subject['id']for t in alignment.selected(a['start'],a['end']))for a in frame.get('args',[]))
  if not agreed:continue
  expected='x'+str(subject['id'])
  candidates={expected}if expected in entities else{eid for eid,e in entities.items()if e['text'].casefold()==subject['text'].casefold()}
  if len(candidates)!=1:continue
  participants={v for k,v in event['arguments'].items()if re.fullmatch(r'ARG[0-5A]|nsubj|obj|iobj',k)and isinstance(v,str)}
  if not participants&candidates:hard.append(dict(code='shared_subject',path='event:'+event['id'],message='The infinitival purpose must share the parent subject '+subject['text']+'; ownership by a parent event does not bind that participant.'))
 return hard,advice

def validate(record,form,base):
 hard,advice=additional_issues(record,form)
 if hard:return dict(status='unsupported',code=hard[0]['code'],reason=hard[0]['message'],proposed_form=form),hard+advice
 out,feedback=inspect(record,dict(form,action='repair'),base,detailed=True,semantic_checks=False)
 return out,feedback+advice

def evaluate(record,form,raw,base):
 from .logical_form_v2 import parse_form
 try:
  data=parse_form(raw)if isinstance(raw,str)else raw
  jsonschema.Draft202012Validator(proposal_schema(form,base)).validate(data)
  if data['action']=='refuse':return form,dict(status='unsupported',code='model_refuse',reason='Model declined a faithful structural correction.'),[]
  if not data['edits']:raise ValueError('A correction needs at least one edit.')
  result=apply_edits(form,data['edits']);out,feedback=validate(record,result,base)
  return result,out,feedback
 except Exception as exc:return form,dict(status='unsupported',code='edit_error',reason=str(exc)),[dict(code='edit_error',path='$',message=str(exc))]

def request(record,previous,base,guided=True):
 form=previous['current_form'];data=dict(claim=record['text'],syntax=[{k:t.get(k)for k in['id','text','lemma','upos','head','deprel','feats']}for t in record['tokens']],srl=(record.get('srl')or{}).get('frames',[]),current_form=form,replaceable_subtrees=subtree_paths(form),logical_form_format={k:v for k,v in OUTPUT_FORMAT.items()if k!='root'},direct_compiler_error=previous['direct_compiler_error'])
 if previous.get('partial_details'):data['partial_parse']=previous['partial_details']
 if guided:data['compiler_feedback']=previous['feedback']
 else:data['instruction']='The current correction failed a check. Revise it without changing the original meaning.'
 if previous.get('raw'):data['previous_edits']=previous['raw']
 return data,proposal_schema(form,base)
