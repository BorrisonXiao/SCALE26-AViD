#!/bin/bash
#SBATCH --job-name=avid-structure
#SBATCH --partition=gpu
#SBATCH --gres=gpu:h100:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=100G
#SBATCH --time=00:40:00
#SBATCH --output=/exp/cxiao/scale26/avid/exp/probabilistic_verification/compiler_structural_20261113/model_%j.out
#SBATCH --error=/exp/cxiao/scale26/avid/exp/probabilistic_verification/compiler_structural_20261113/model_%j.err
set -euo pipefail
cd /exp/cxiao/scale26/avid
export PYTHONPATH=/exp/cxiao/scale26/avid/exp/probabilistic_verification/compiler_structural_20261113/model_source/scripts
export VLLM_WORKER_MULTIPROC_METHOD=spawn
export OMP_NUM_THREADS=4
envs/probabilistic-verification/bin/python exp/probabilistic_verification/compiler_structural_20261113/cuda_probe.py
envs/probabilistic-verification/bin/python exp/probabilistic_verification/compiler_structural_20261113/model_source/scripts/run_structural_compiler.py --run exp/probabilistic_verification/compiler_structural_20261113
