# Architectural Decisions — AViD Phase 1

**Current paper direction:** ADR-023 (2026-10-14), probabilistic parsing for
multimodal claim verification with frozen perception models and small learned
relation classifiers. Earlier positioning and topology decisions remain historical
except where ADR-023 explicitly preserves them.
_Terminology follows docs/project_notes/terminology.md._

## ADR-001: Use Qwen3-30B-A3B-Instruct via vLLM for Text-Only Modality-Prior Inference (2026-06-17)

**Context:**
- Need soft priors over each annotation unit's *modality need* — which evidence channel a claim part would need, judged from text alone (the text-only modality prior) — as probability distributions, not hard labels
- Must run on cluster GPUs without external API calls
- Qwen3-30B-A3B is a MoE model fitting in ~60 GB bf16 on one H100/H200

**Decision:**
- Use Qwen3-30B-A3B-Instruct with vLLM (`vllm-omni` env) in non-thinking mode
- Extract first-token logprobs over option letters (A/B/C/D/...) and renormalize to a soft distribution
- `temperature=0.0`, `max_tokens=1`, `logprobs=20`

**Alternatives Considered:**
- GPT-4 / Claude API → Rejected: no logprob access for soft distributions; external API dependency
- Smaller local models (7B/14B) → Rejected: early pilots showed poor label calibration on this task
- Hard labels only → Rejected: soft distributions enable downstream uncertainty modeling

**Consequences:**
- ✅ Full logprob access → calibrated soft distributions per unit
- ✅ Runs fully offline on cluster
- ✅ Resumable via per-(claim_id, unit_id) cache
- ❌ Requires H100/H200 GPU (≥80 GB VRAM) — H200 at rack3n05 is the reliable target
- ❌ ~30–45 min per 4,919 units on a single H200

---

## ADR-002: 2-Pass Coarse→Fine Architecture for v2 (2026-06-18)

**Context:**
- Flat 6-class MCQ (v0) concentrates probability mass poorly: model must distinguish visual_other vs visual_ocr simultaneously with audio vs visual decision
- Want to separate the coarse channel decision from the fine-grained subtype

**Decision:**
- Pass 1: 4-class MCQ (visual / audio / unverifiable / na)
- Pass 2: 2-class MCQ only for visual units (visual_other vs visual_ocr) and audio units (audio_speech vs audio_other)
- unverifiable and na (not a checkable unit) units skip pass 2

**Alternatives Considered:**
- Single 6-class MCQ (v0 approach) → Retained as baseline but deprecated for production
- Chain-of-thought reasoning → Rejected: logprob extraction on CoT outputs is unreliable; non-thinking mode required
- Hierarchical: 2-class (AV vs non-AV) then 3-class → Rejected: unnecessary extra step; 4-class coarse is already clean

**Consequences:**
- ✅ Pass-1 confidence is cleaner — model isn't split between 6 options
- ✅ Pass-2 is near-instant for v2 re-runs (all pass-1 hits from v1 cache)
- ✅ `na` labeling is done once in pass 1, not duplicated in pass 2
- ❌ Two inference passes → two separate output files; `build_affordance_annotation.py` merges them
- ❌ visual_ocr rate (26.1%) appears inflated vs v0 (8.3%) due to protest-sign claim cluster; investigate before annotation

---

## ADR-003: Broad `na` Definition with Pointability Test (2026-06-21)

**Context:**
- v0 `na` prompt was ambiguous → 11.1% over-prediction on concrete entities
- v1-narrow prompt ("never a noun or noun phrase") → 0.1% under-prediction; missed vague referents like "the conditions", "anyone"
- Need a definition that catches relational words AND vague referents WITHOUT catching concrete named entities

**Decision:**
- Two explicit na criteria:
  1. Relational/functional words: "is", "are", "caused", "affecting", "involving", "resulting in", expletive "there", pleonastic "it"
  2. Vague/underspecified referents: indefinite pronouns ("anyone", "someone", "everyone", "something", "those" without antecedent), vague nouns ("the conditions", "the situation", "the matter", "a role", "things", "circumstances", "what happened")
- Explicit pointability TEST: "can an annotator point to a specific object, person, sound, or moment in the video to verify this unit? If not → na."
- Explicit NEVER-na guard for concrete named entities and objects

**Consequences:**
- ✅ v1-revised: 2.2% `na` (104 units) — plausible rate; spot-check confirms correct catches
- ✅ Concrete entities ("the typhoon", "Alaska", "the protesters") correctly preserved
- ❌ Some relational words in sign-claim context (e.g. relative "that" in "sign **that** says X") still slip through as `visual_ocr`; not corrected in v1/v2

---

## ADR-005: 1fps / 672×378 Frame Sampling for Phase 2 v2 Visual Verification (2026-06-22)

**Context:**
- Phase 2 v1 (job 359197) extracts 12 frames at native resolution per video chunk.
- Our 122 chunks range from 5.8s to 237s (median 33s, P90 129s, max 237s).
- At 30fps native, Qwen3-VL tokenizes each 1920×1080 frame as ~2,028 tokens
  (patch_size=16, merge_size=2 → effective 32px/token; 60×34 = 2,040 patches).
- 12 native-res frames exhausts the context window (24,683 tokens), forcing
  max_model_len=32768. Temporal coverage: one frame per 19.75s for the max clip.

**Token budget analysis:**
- Qwen3-VL preprocessor: `min_pixels=65,536`, `max_pixels=16,777,216`, effective patch stride 32px.
- At 672×378: smart_resize snaps height to `round(378/32)×32 = 384` → 672×384 → 21×12 = **252 tokens/frame**.
  - 672×378 = 254,016 px ≥ 65,536 min_pixels → no processor upscaling.
- At 128 frames (safe cap): 128 × 252 + 400 text = 32,656 tokens < 32,768 ✓.
- ~90% of clips are <128s → full 1fps coverage; longer clips (P90 129s, max 237s) capped at 128 frames (0.99fps and 0.54fps respectively).

**Decision:**
- **Frame extraction**: 1fps dynamic sampling (`n_frames = min(128, max(1, int(duration_sec)))`).
  Frames resized to fit within 672×378 box at extraction time (cv2.INTER_AREA).
- **Model input**: frames also resized with PIL thumbnail on load as safety net (`--frame-size 672x378`).
- **Context**: max_model_len=32768 (unchanged from v1 fix).
- **Audio**: unchanged — audio verification reuses v1 cache (content is resolution-independent).
- **Output**: `exp/phase2_v2/`; media in `exp/phase2/media_cache_1fps/`.

**Alternatives Considered:**
- Keep 12 full-res frames (v1 baseline) → poor temporal coverage; one frame per 19.75s on the max clip.
- Resize to 448×252 (112 tokens/frame) → allows 250 frames, full 1fps for all clips; but 672×378
  preserves more spatial detail (better for visual_ocr text reading) and is tried first.
- Increase `max_model_len` beyond 32768 to fit more full-res frames → KV cache blocks fixed at 512;
  doubling max_model_len halves throughput without memory savings. Cheaper to shrink images.

**Consequences:**
- ✅ Temporal coverage: 1fps for ~90% of clips (under 128s); max clip gets 0.54fps (128 frames).
- ✅ Token efficiency: 252 tokens/frame vs 2,028 native → 8× reduction.
- ✅ Higher spatial resolution than 448×252 → better for visual_ocr tasks.
- ✅ Two runs (v1 baseline + v2 1fps) allow direct comparison of temporal coverage effect.
- ❌ The 10% of clips >128s get slightly under 1fps. If needed, fall back to 448×252 (112 tokens/frame, 250-frame cap, full 1fps for all clips).
- ❌ Re-extraction needed: ~122 chunks × avg 70 frames × ~30 KB = ~250 MB extra disk.

---

## ADR-004: Parallel Experiment Version Directories (2026-06-18)

**Context:**
- Early work landed in `exp/phase1/` flat — mixing phase-1 stable artifacts with experiment outputs
- Need to compare v0 (flat 6-class), v1 (coarse 4-class), v2 (2-pass fine-grained) side by side

**Decision:**
- `exp/phase1/` — stable shared artifacts only: `hypergraph.jsonl`, `annotation_units.tsv`, `reports/`; never overwrite
- `exp/v0/`, `exp/v1/`, `exp/v2/` — parallel, self-contained experiment directories; each has README, consistent file layout, `cache/`, `logs/`
- `exp/v1/archive/` — frozen outputs from superseded v1 run (job 357515, narrow na); preserved for reference

**Consequences:**
- ✅ Each version is reproducible independently from its README
- ✅ `build_affordance_annotation.py` unambiguously consumes a single version's files
- ❌ Cache reuse between versions requires explicit `cp` (see `run_affordance_v2.slurm` step A)

---

## ADR-006: Binary (mutually-exclusive) pass-2 for signal verification (2026-06-24)

**Context:**
- Phase-2 v2 pass-2 used **two independent yes/no/unknown probes** per modality
  (`visual_ocr?` AND `visual_other?`; `audio_speech?` AND `audio_other?`), intended as
  multi-label per proposal §3.2 (`supporting_channels` is a set).
- Empirically the probes over-fire "both": among pass-1=yes units, **38.9% visual** and
  **50.9% audio** received yes on *both* subtypes (anchoring — once pass-1 says "supported",
  the model says yes to both sub-probes). This inflated `audio_other` to Gold=835 (support=yes)
  vs modality-prior Pred=106 (R=0.066), making the modality-prior×support comparison meaningless.

**Decision:**
- Pass-2 is a **single symmetric forced-choice MCQ** (A/B) run only when pass-1 = yes:
  visual → A=`visual_ocr` | B=`visual_other`; audio → A=`audio_speech` | B=`audio_other`.
  The two within-modality subtypes are now **mutually exclusive**. Cross-modality multi-label
  (visual *and* audio) is unchanged (separate model runs).
- Routing: pass-1=no → both subtypes no; pass-1=unknown → both unknown; pass-1=yes → exactly
  one subtype yes (argmax of A/B; the A/B logprob margin is retained as the §8 uncertainty signal).

**Alternatives considered:**
- Keep two independent probes but de-anchor → rejected: the over-firing is the measurement, not
  trustworthy multi-label.
- Add a 3rd option `C=both` to preserve genuine within-modality multi-label (e.g. sign=object+text)
  → deferred: reintroduces over-firing; revisit only if the gold pilot shows real "both" cases.
- Asymmetric "is it speech? else other" (matches the user's literal phrasing) → rejected in favor
  of symmetric MCQ for a cleaner, comparable A-vs-B logprob margin.

**Consequences:**
- ✅ Within-modality support is single-label, directly comparable to the text-only modality prior's argmax.
- ✅ Kills the `audio_other` / `visual_ocr` over-count; restores meaningful per-channel P/R/F1.
- ✅ One fewer model call per pass-1=yes unit.
- ❌ Departs from proposal §3.2's allowance of within-modality multi-label support (accepted;
  the two-probe implementation never delivered trustworthy multi-label anyway).

---

## ADR-007: Prompt-stem variant ablation (base / r1 / r2 / r3) (2026-06-24)

**Context:**
- v2 prompts feed the verifier the **raw parser fragment** + a generic stem ("Is this unit
  supported by anything VISIBLE…"). Many units are weak targets in isolation (bare events
  "occurred"/"counting", relative-clause fragments, UUID artifacts). Proposal §7 specifies
  verbalizing each unit into a natural verification prompt — **not implemented** in v2.
- With no gold pilot yet, the right prompt framing cannot be selected by inspection alone, so we
  run a controlled ablation and let the comparison (and later, gold) decide.

**Decision:**
- One `--prompt-variant {base,r1,r2,r3}` switch (model loaded once, all arms in sequence):
  - **base** — v2 union stem (control).
  - **r1** — de-jargoned ("Does the video show visual evidence for the marked part …").
  - **r2** — node_type-aware stem (entity / event / situation).
  - **r3** — LLM-verbalized referent (proposal §7): a text-only Qwen3-30B pre-pass
    (`verbalize_units.py`) rewrites each unit into a self-contained, modality-neutral statement,
    substituted for the raw fragment.
- All arms share the ADR-006 binary pass-2. Compared by `compare_prompt_variants.py`.

**Consequences:**
- ✅ Isolates the effect of unit framing on the support measurement; r3 realizes proposal §7.
- ✅ base is the control to attribute any shift to the stem.
- ❌ Variant selection is not licensed by this comparison alone (no gold) — it shows *how* framing
  shifts the measurement; the gold pilot (HANDOFF TODO-5) is still required to pick a winner.

---

## ADR-008: Deprecate r3; introduce r4 (no-context type-aware) and r5 (LLM-formulated question) (2026-06-24)

**Context:**
- r3 (LLM-verbalized referent, ADR-007) was designed to realize proposal §7 by rewriting each unit
  into a self-contained, modality-neutral statement before verification.
- Empirically, for atomic/single-word units, the Qwen3-30B verbalizer has no information beyond
  the unit token itself, so it reconstructs the full claim sentence:
  - unit "Emmonak" → *"Emmonak, Alaska is experiencing effects from a typhoon."*
  - unit "affected" → *"Emmonak, Alaska is experiencing impacts from a typhoon."*
- The r3 verifier then sees: (a) Statement to verify = full-claim paraphrase; (b) Context = full
  claim with the unit bolded. Both fields carry essentially the same full-claim information.
  r3 is therefore **full-claim verification in disguise** for the majority of the unit inventory
  (atomic nodes), not the unit-level probing the proposal intends.
- r3 results (exp/phase2/prompt_ablation/r3/) show reduced support rate (54% vs 65% base), which
  reflects a harder bar set by the full-claim specificity, not better unit-level discrimination.

**Decision:**
- **Deprecate r3.** Do not re-run. Results archived in `exp/phase2/prompt_ablation/r3/`.
- Introduce **r4**: node_type-aware routing (same as r2) but **no context line** — only the unit
  text is shown. Tests how much the verifier relies on the full claim for disambiguation.
- Introduce **r5**: **LLM-formulated yes/no question per unit per modality**, no context line.
  A Qwen3-30B text pre-pass (`formulate_questions.py`) reads the full claim to understand what
  the unit refers to (entity type, event, etc.) and writes a concrete, unit-focused question:
  - "Emmonak" (entity) → Visual: "Is the name 'Emmonak' displayed on screen (chyron/map/caption)?"
  - "laying" (event)   → Visual: "Is a person visible lying down near railway tracks?"
  The generated question replaces the generic stem in pass-1; the context line is omitted.
  This realizes proposal §7 correctly: the LLM resolves the unit's referent using the claim but
  writes a unit-focused question, not a full-claim paraphrase.
- Prompt templates for the r5 pre-pass (`FORMULATE_SYSTEM`, `FORMULATE_USER_TMPL`) live in
  `scripts/prompts_phase2.py` alongside all other phase-2 prompts.

**Alternatives considered:**
- Fix r3's verbalizer to output noun-phrase or event-phrase descriptions instead of full sentences
  → The prompt is already constrained (15 words, no modality words), but the model fills missing
  context with the full claim. Fundamental to the verbalizer's task. Redesigning as "formulate a
  question" (r5) is structurally different and avoids the collapse.
- Keep r3 alongside r4/r5 → Excluded from the active comparison (default `--variants` in
  `compare_prompt_variants.py`); results preserved for reference.

**Consequences:**
- ✅ r4 isolates the context-vs-no-context effect cleanly (same routing as r2).
- ✅ r5 provides the genuine per-unit, modality-specific question that proposal §7 describes.
- ✅ All LLM pre-pass prompts centralized in `scripts/prompts_phase2.py`.
- ❌ r5 requires a GPU pre-pass (`formulate_questions.py`) — same cost as r3's verbalization.
- ❌ Active comparison is now 5 variants (base/r1/r2/r4/r5); r3 results remain for reference only.

---

## ADR-009: De-news genericization + split r5 formulation; r5 design = "existence-first" (2026-06-24)

**Context:**
- The phase-2 prompts framed the task around **news** content: `FORMULATE_SYSTEM` said "a
  highlighted semantic unit from a *news claim*", and the pass-2 option blocks used broadcast-TV
  vocabulary (`titles`, `banners` for OCR; `announcements`, `quoted statements`, `narration` for
  speech). But MicroVENT is **arbitrary user/social video** (protests, typhoons, military footage,
  "3 robots in a boxing ring"), not broadcast packages — the news framing mis-primes the verifier.
- r5 (ADR-008) originally formulated **both** the visual and audio question in **one** LLM call
  (two output lines). With this design the second line anchors on the first, and the model — seeing
  both channels at once — can pre-decide a unit is "audio-only" and write a degenerate visual
  question, leaking a text-only modality prior into a measurement that is supposed to be
  **blind to the modality prior and probe every channel** (phase-2 impl plan).

**Decision:**
1. **Genericize (de-news) all phase-2 prompt wording.** Pass-2 option examples are now
   channel-neutral and more complete (OCR adds phone/screen displays, documents, handwriting;
   speech adds conversation/shouting; other-audio adds machine/animal noise). The `base` stem is
   **left unchanged** (it is the ablation control, ADR-007). Pass-2 options are **shared and held
   constant across all variants**, so genericizing them uniformly does not confound the stem
   comparison (the stem remains the only varied factor).
2. **Split r5 formulation into two independent single-modality calls** —
   `FORMULATE_VIS_SYSTEM` and `FORMULATE_AUD_SYSTEM` (shared `FORMULATE_USER_TMPL`), each emitting
   one labeled line. Both modalities run in a single vLLM `generate` sweep (no extra model load).
   Cache key becomes `claim|unit|modality`; the output schema
   (`visual_question`/`audio_question`) and `verify_support.py` are unchanged.
3. **r5 question style = "existence-first" (R5-A)**, grounded in proposal §7's unit→prompt table,
   with 5 few-shot examples per modality. Questions ask whether the thing is present / the event is
   shown-or-heard / the relation holds — concrete, yes/no, answerable from the clip alone, no
   whole-claim truth. The weaker-modality question still asks for the unit's best trace in that
   channel (e.g. visual question for "honks" → "Is a car shown sounding its horn, or someone
   reacting to a horn?").

**Alternatives considered:**
- Keep the single-call formulation → rejected: within-call anchoring + modality-fit leakage; the
  same anchoring failure mode this pipeline has fought since v1.
- Let the formulator emit "n/a" for an impossible modality → rejected: the verifier probes every
  channel blind by design; suppressing a channel is the text-only modality prior's job, not the verifier's.
- r5 style "evidence-enumerating" (R5-B, disjunctive signature lists) → not chosen: richer for
  vague/relational units but risks longer, leading questions that inflate "yes". Kept as a documented
  alternative in the design discussion.
- Cost of 2× calls → non-issue: text-only Qwen3-30B, ~one line per call, batched in one sweep.

**Consequences:**
- ✅ Prompts no longer assume broadcast conventions → better-calibrated on raw UGC.
- ✅ r5 visual/audio questions are independent and modality-blind, consistent with the blind,
  every-channel verifier.
- ✅ `verify_support.py` and downstream (`build_support_annotation.py`) untouched.
- ❌ r5 cache schema changed (`claim|unit` → `claim|unit|modality`); no migration needed — no
  `formulated_questions.jsonl` had been generated yet.
- ❌ Prompt wording for base/r1/r2/r4 pass-2 options changed vs the (not-yet-finalized) ablation
  jobs 361354–361357, which ran base/r1/r2/r3 on the old options. Re-run the ablation on v4 prompts
  before drawing variant conclusions.

---

## ADR-010: r5e — answer-first explanation variant (2026-06-25)

**Context:**
- The probing pipeline (`probing/scripts/step2_run_inference_qwen3vl.py`) asks the model for a
  free-text justification (`"Yes: <reason> [visible: ...]"`, `max_tokens=128`, verdict recovered by
  regex). Useful for human inspection, but it yields **no calibrated probabilities**.
- The AViD verifier (`verify_support.py`) instead reads **first-token logprobs** (`max_tokens=1`,
  non-thinking) → calibrated soft distributions, which the whole of phase 2 depends on
  (modality-prior-vs-support, the A/B subtype margin = §8 uncertainty signal, variant comparison).
  ADR-001/ADR-002 chose this and **rejected chain-of-thought** ("logprob extraction on CoT outputs
  is unreliable; non-thinking mode required").
- Open question (user, 2026-06-25): can r5 also produce a short justification like probing did?

**Decision:**
- Add **r5e**, an opt-in sibling of r5 that asks for the verdict **letter FIRST, then a ≤15-word
  reason**, in a single `generate` call (`--explain-max-tokens`, default 48; `logprobs` unchanged).
- The verdict/distribution are still taken from `logprobs[0]` — i.e. **unchanged from r5** — because
  the first generated token is the letter. The reason is captured as free text
  (`pass1_explanation` / `pass2_explanation`) for human analysis **only**; it never feeds verdicts.
- r5e is a **new variant**, not an overwrite of r5, and is **excluded from the standard 5-way grid**
  (`ACTIVE_VARIANTS` unchanged). Prompts live in `prompts_phase2.py` (`*_SYSTEM_EXPLAIN`,
  `_EXPLAIN_TAIL`, `EXPLAIN_VARIANTS`, `explain=` on `pass1_user`/`pass2_user`).
- `make_readable_support.py` joins the reasons into `visual_why`/`audio_why` columns.

**Why this does NOT conflict with ADR-001/002:** those reject **reason-FIRST** (CoT), where the
answer is buried after self-generated reasoning so its logprob is no longer a clean calibrated read.
**Answer-first** keeps the answer at token 0 — identical extraction mechanism to `max_tokens=1` —
so calibration is preserved. (Probing's prompt was itself answer-first.)

**Alternatives considered:**
- Switch r5 to reason-then-answer → rejected: breaks logprob calibration (ADR-001/002).
- Separate second free-text-only pass keyed to the cached verdict → rejected for now: doubles
  inference cost for no calibration benefit; answer-first gets both in one pass.
- Parse the verdict from the generated text (probing-style) instead of logprobs → rejected:
  discards the soft distribution the rest of phase 2 is built on.

**Consequences:**
- ✅ One pass yields both the calibrated distribution and a human-readable reason.
- ✅ r5 numbers stay frozen; r5e is additive and opt-in.
- ⚠️ The explain instruction slightly perturbs the first-token distribution vs the pure 1-token
  prompt, so r5e is **not** byte-identical to r5 — treat as its own variant, not a drop-in for r5's
  reported numbers.
- ⚠️ Requires a re-run to populate (existing r5 data has no reasons). Cost ≈ the original r5 pass
  (multimodal prefill dominates; ~48 decode tokens add little). Submit:
  `run_phase2_r5e_{visual,audio}.slurm` then `run_phase2_r5e_aggregate.slurm` (afterok).

---

## ADR-011: r5 formulation — context-leak fix + unit-level `na` triage (2026-06-25)

**Context:**
- r5 formulated questions **leaked claim context into atomic-unit questions** — e.g. unit `a man`
  in "A man is laying near the tracks" → *"Is a man's voice audible **near the tracks**?"*. This
  drifts the unit-level measurement back toward full-claim verification — the same anchoring failure
  the project fought with the claim_text anchor (the claim-anchor collapse, in key_facts) and r3
  (ADR-008). Proposal §7 is explicit: **atomic** units get unit-only prompts (`car` → "Is a car
  visible?"); only **factor** units carry their arguments (`pushing(man,cart)`). Some few-shot
  examples in the formulation prompt actually *taught* the leak (`Unit: "pushing"` → "…pushing **a
  cart**", where `cart` is a separate unit).
- The formulator also wrote a degenerate question for units that are **not meaningful to probe** —
  e.g. `leaves` in "Rocket **leaves** a cloud of smoke" (here `leaves` = "produces"), instead of
  rejecting it. The deterministic `light_verb` filter (`unit_filters.py`) is lexicon-based
  (`be/do/go/have/…`) and subsumption-guarded, so it **structurally cannot** catch a context-
  dependent *light use* of a contentful verb.

**Decision:**
1. **Anti-leak (prompt).** Rewrote `_FORMULATE_RULES` + the visual/audio few-shot examples: ask only
   about the unit's own content; an **atom** → the unit + at most a generic participant
   ("someone/something"); a **factor/phrase** → its parts; never import other actions, locations,
   times, manner, purpose, or co-participants. Added a `pushing` (atom, generic) vs `pushing a cart`
   (factor, args kept) contrast and the `a man` no-location example.
2. **`na` triage (new).** Added `TRIAGE_SYSTEM` / `TRIAGE_USER_TMPL` — ONE **modality-agnostic** call
   per unit (pointability test, ADR-003), run BEFORE the two question calls in
   `formulate_questions.py` (model loaded once; two sweeps: triage → formulate). na is **unit-level**
   and must be kept separate from the question calls: conflating it with "weak in this channel" would
   violate ADR-009 (the formulator writes a genuine question even for the weak channel). Selective
   criterion: na for light/abstract/relational/copular uses (`leaves`=produces, `is`, expletive
   `there`); **keep** concrete perceptible actions/entities (`jumps`, `honks`, `a man`) even if weak
   in one channel. The contentful meaning of an na atom is still verified at the enclosing factor.
3. **Surfacing = minimal (user choice, 2026-06-25).** na + reason recorded in
   `formulated_questions.{jsonl,tsv}` (`na`/`na_reason` columns) plus a `na_units_r5.{txt,tsv}`
   report; na units carry empty questions and `verify_support.py` **skips empty-formulated units for
   r5/r5e** (filtered like the modality-prior pass's na). Not propagated to support_annotation/readable.

**Alternatives considered:**
- Per-modality na (each question call may emit na) → rejected: collides with ADR-009; na is unit-level.
- Expand the deterministic light_verb lexicon (add "leave", …) → rejected: light-vs-contentful is
  context-dependent ("leaves a cloud" = produces vs "leaves the building" = departs); needs the LLM.
- `status=na` propagated end-to-end through support_annotation + readable → not chosen now (user
  picked the minimal record-and-filter option; can be promoted later).

**Consequences:**
- ✅ Atomic-unit questions stay unit-scoped → they measure unit support, not the full claim.
- ✅ Context-dependent non-pointable units are rejected *with a reason*, complementing (not replacing)
  the modality-prior pass's na and the deterministic filter.
- ⚠️ Requires regenerating `formulated_questions.*` (GPU) → re-running r5/r5e; +1 short triage call
  per unit (text-only Qwen3-30B, negligible). Existing r5 questions change, so prior r5 numbers are
  superseded once regenerated.
- ⚠️ r5/r5e then verify a slightly smaller unit set than base/r1/r2/r4 (triage-na removed);
  `compare_prompt_variants.py` tolerates per-variant unit differences. Propagating triage-na to the
  other variants for a fully common unit set is deferred.

**Update (2026-06-25, post-audit — prompt v3):** the first triage run (v2) over-fired badly —
**2112/4369 (48%) na**: 77% of FACTORS and 28% of atoms, rejecting compositional units
(`predicate_argument`, `prepositional_relation`, `full_claim`) and perceptible atoms (`flooding`,
`evacuation`, `washed`, place names) as "relational/abstract". Two corrections (v3):
1. **Triage runs on ATOMIC nodes only** (`unit_id` not `f*`); composition factors are AViD's
   support targets and are now ALWAYS probed (`is_factor()` in `formulate_questions.py`).
2. **Conservative criterion** (`TRIAGE_SYSTEM` rewrite): default strongly to PROBE; na only for
   function/copular words, light-verb *senses* (`leaves`=produces, `affected`, `causing`), and pure
   abstractions/vague referents (`safety`, `hope`, `the situation`). Concrete events/places
   (`flooding`, `Emmonak`, `evacuation`) explicitly probed; the audio speech-route means anything
   nameable is probably PROBE. Result: **301/4369 (6.9%) na** (atoms only; events 222, entities 79),
   spot-checked correct. Lesson: a context-aware LLM triage will happily over-generalize "abstract" —
   restrict its scope structurally and bias hard toward keep. `FORMULATE_PROMPT_VERSION` bumped v2→v3.

---

## ADR-012: r5 audio formulation — sound | speech dual-route (2026-06-25)

**Context:**
- The r5 audio question only asked about a unit's characteristic SOUND (e.g. `a man` → "Is a man's
  voice audible?"). But the audio channel's pass-2 split is `audio_speech` vs `audio_other`, and
  `audio_speech` explicitly includes narration / a voice talking — i.e. a unit can be audibly
  supported by being **spoken about**, not only by making a sound.
- Consequence of the sound-only question: units with no characteristic sound (places, signs, abstract
  entities like `Emmonak`, `Alaska`) could only ever be `no` in audio, even when a narrator names
  them — under-measuring audio support and starving the `audio_speech` subtype.

**Decision:**
- Every formulated AUDIO question must cover BOTH routes, joined with "or": (1) a characteristic
  SOUND of the unit, AND (2) the unit being NAMED / talked about in SPEECH (the unit's words appear
  in the speech route, e.g. "… or does anyone mention a man in speech?"). The speech route is never
  optional. Implemented in `FORMULATE_AUD_SYSTEM` (rule + examples, incl. a no-sound `Emmonak` case).
- VISUAL formulation is unchanged (its second route — readable on-screen text — is already handled by
  the `visual_ocr` pass-2 subtype, not the question stem).
- Folded into `FORMULATE_PROMPT_VERSION = "v2"` (v2 not yet run, so no version bump needed).

**Alternatives considered:**
- Add the speech route to the shared `_FORMULATE_RULES` → rejected: it would wrongly inject a speech
  route into VISUAL questions; the rule is audio-specific.
- Leave it to pass-2 to recover speech → rejected: pass-2 only runs when pass-1 = yes, so a sound-only
  pass-1 question gates out speech-only support before pass-2 can see it.

**Consequences:**
- ✅ Entities/places with no sound can be audibly supported via mention → `audio_speech` is no longer
  starved; aligns the r5 stem with the `audio_speech` channel definition.
- ⚠️ Expected to RAISE the audio pass-1 yes-rate (more units supported via the speech route); this is
  intended. The pass-2 `speech` vs `other` split then attributes which route fired.
- ⚠️ Two-clause questions are slightly more leading; mitigated by the pass-2 subtype check and by
  naming only the unit (not claim context) in the speech route (ADR-011 anti-leak still holds).

---

## ADR-013: Sharpen pass-1 no/unknown verdict-space wording + version-scope the verify cache (2026-06-26)

**Status:** PROPOSED — prompt + cache-path edits applied to `prompts_phase2.py` /
`verify_support.py`; **not yet launched** (awaiting review per user). No results regenerated.

**Context:**
- Post-hoc analysis of the r5e run (`exp/phase2/prompt_ablation/r5e/`, exp-r5e) found the visual
  `unknown` bucket is **26%** of units, and **91%** (737/812) of those `unknown` reasons contain a
  negation ("no luggage visible", "not clearly wearing…", "no clear group"). I.e. Qwen3-VL-8B is
  logging true ABSENCE — *the scene is visible and the thing simply is not in it* — as C=unknown
  rather than B=no. **49 hard contradictions** had the logprob verdict = `unknown` while the model's
  own generated reason began with "no".
- Status is `unsupported` only when ALL channels = no, and `unknown` when no yes but ≥1 unknown. So
  every visual-unknown+audio-no unit (e.g. "The Department of Homeland Security", "a large group of
  people", "wearing") is pushed **unsupported → unknown**. The reported split
  (supported 64.9% / unknown 20.1% / unsupported 15.0%) therefore **understates unsupported and
  inflates unknown**.
- Cross-modal artifact: audio `unknown` is only **6%** (Qwen3-Omni-30B commits) vs visual 26% — the
  4× gap is a model-idiosyncrasy of the option reading, not a property of the data, and confounds any
  visual-vs-audio support comparison.
- Root cause is option wording: pass-1 C said "cannot determine from the available frames", which the
  8B visual model reads as "I'm not confident" rather than "the frames don't show the needed view." B said
  "the video does not show visual evidence for this" — ambiguous between *absent* and *no evidence*.
- The verifier IS capable of "no" for absence when the mismatch is obvious (e.g. "helicopters at a
  soccer field" → "no — video shows indoor military personnel"); the over-use of `unknown` is
  concentrated in the *ambiguous-absence* zone (plausibly-present-but-not-clearly-seen).

**Decision:**
1. **Reword pass-1 options** (`_P1_OPTS_VIS` / `_P1_OPTS_AUD`), both modalities in parallel:
   - **A=yes** — "the frames clearly show this" / "the audio clearly contains this".
   - **B=no** — "the relevant scene is visible, but this is absent from it" / "the audio is clear,
     but this is absent from it".
   - **C=unknown** — reserved for an UNAVAILABLE channel: "the needed view is off-screen, occluded,
     too blurry, or not captured" / "missing, silent, or too noisy or garbled to judge".
   - A one-line tie-breaker after the options: "If you can see the scene and simply do not find this
     in it, answer B (no), not C." Has no letter prefix → not parsed as an option; A/B/C positional
     mapping (yes/no/unknown) and the first-token logprob read are unchanged.
   - Options held constant across all variants (like pass-2 options, ADR-009) → does not confound the
     stem ablation.
2. **Version-scope the verify cache** by `PROMPT_VERSION` (bumped v4→v5). The verify cache key is only
   `{claim_id}|{unit_id}|{pass}` — it does NOT encode the prompt — so without this a reworded prompt
   would be silently served stale verdicts on resume. `cache_path` now routes through
   `…/<variant>/cache/<PROMPT_VERSION>/`; v5 recomputes from scratch, v4 caches preserved. Mirrors the
   existing `FORMULATE_PROMPT_VERSION` cache-invalidation pattern for the formulate pre-pass.

**Alternatives considered:**
- Reword only visual (the channel with the problem) → rejected: breaks the parallel verdict-space and
  worsens cross-modal comparability; rewording audio should barely move its already-6% unknown rate
  (a useful sanity check that the change doesn't manufacture support).
- Post-hoc reassign verdict=unknown→no when the reason starts with "no" → rejected: a band-aid on the
  generated text that doesn't fix the calibrated distribution the rest of phase 2 relies on; explain
  mode also won't exist for a future non-explain canonical run.
- Add the prompt hash to the cache key at all 5 build/read sites → rejected in favor of the one-line
  cache-dir path scope (lower risk of key-format drift; same effect).

**Consequences:**
- ✅ Expected to move a large share of the 817 `unknown`-status units into `unsupported`; honest
  supported/unknown/unsupported split.
- ✅ Tighter, shared definition of `unknown` improves visual↔audio comparability.
- ✅ Cache-versioning prevents this whole class of silent stale-verdict bugs on future prompt edits.
- ⚠️ Requires re-running r5e visual + audio (fresh v5 cache) then aggregate; numbers will shift, so
  exp-r5e is superseded once regenerated. Validation gate: re-measure negation-in-`unknown` (target
  ≪ 91%) and the verdict↔reason contradiction count.
- ⚠️ A genuine gray zone remains (plausibly-present-but-unclear, e.g. "is the crowd *large*?"); the
  wording nudges these toward a committed yes/no rather than a hedge, which is the intended behavior
  but is a judgment call, not a clean partition.

---

## ADR-015: Phase-3 positioning (training-free "new-formalism" method, BTProp lane), frozen annotation contract, and `na` as check-worthiness validation (2026-07-04)

**Status:** ACCEPTED — governs the Phase-3 paper framing, the gold-annotation contract, and the eval/baseline set. Supersedes the legacy gold-pilot plan (HANDOFF TODO-1). Numbering note: ADR-014 (binary pass-1 v6) is referenced in HANDOFF/CHANGELOG but was never recorded here; this is ADR-015.

**Context:**
- Phase-3 tree-CRF is designed + M0/M1 built (HANDOFF). Open questions before the gold pass: (a) is the contribution enough for ICLR/ACL; (b) should the `na` designation itself be annotated/evaluated; (c) does the project need full-tree annotation to enable a future learning component. Freezing this now avoids re-annotation.
- A web-verified 2024–2026 literature re-scan (`research/LITERATURE.md`, 2024–2026 extension) found:
  - The **mechanism** (tree + exact belief propagation over per-node LLM scores) is now published for text — **BTProp, NAACL 2025** (arXiv:2406.06950). "Structured probabilistic verification" is no longer novel on its own; BTProp is the new mechanism-level nearest competitor (supersedes DSG).
  - **Accept-bar:** training-free clears main conferences when it is a *new inference formalism* (BTProp, training-free) or adds a *small learned module* (Lu et al., ACL 2025, learned decomposition). Prompting-only trends to Findings.
  - The one **empty** axis is per-node source-modality attribution over 4 channels. **Check-worthiness** ("which spans are verifiable") is an occupied, evaluated task (ClaimBuster; CLEF CheckThat!).
  - **GroundMM (ACM MM 2025)** is a candidate external eval home (video+speech+text misinfo grounding), but ASR-only audio and region/time grounding — not per-claim-node.

**Decision:**
1. **Positioning:** frame Phase-3 as a **training-free method paper** whose contribution is the *model/formalism* — parser-grounded, factor-typed **AV tree-CRF + exact belief propagation (BP) + per-node modality posterior** — in the **BTProp lane** (new inference formalism), not "per-node prompting of the multimodal model." **Headline = the per-node source-modality posterior** (the empty axis); it must be shown to *matter* (vs a channel-ablation oracle / on cross-modal cases), not merely to exist.
2. **Baselines** (impl plan §8) add **BTProp-style tree+BP** (text-logic tree) and a **DEFAME-style agentic multimodal model**, alongside flat-r5e, flat-atomic-fact, and DSG-style QA-graph.
3. **Eval home:** perturbation set + gold pilot for the controlled/real numbers; **GroundMM** for external validity, with AViD's deltas = raw non-speech-audio channel + per-claim-node modality attribution.
4. **Annotation contract — FROZEN (annotate once); full spec in impl plan §8.1.** Gold is for **evaluation, not training**. Annotate on the **span-anchored tree-node surface** (`exp/phase3/nodes/tree_units_ud.tsv`), NOT the legacy r5e pilot template, at three densities: **(a)** root/claim verdict + claim grounding-modality (1/claim, full pilot); **(b)** per-node support × per-channel modality at **probed content nodes only** (existence leaves + binding/composed interior spans), video-grounded, **sample** scale (~150–300 claims); **(c)** node-role (probeable / na / structural), **text-only, dense OK**. The perturbation set supplies node-level compositional gold **programmatically**. **No full-tree video-grounded modality gold, ever.** Char-span anchoring makes gold **backbone-agnostic** (reused across the UD-vs-constituency ablation).
5. **`na`:** evaluate as **validation + robustness**, never featured as a contribution. Node role is read from the **parse** (deprel/UPOS), not the 7 heuristics (uuid/empty/duplicate = data hygiene). Report na-detection P/R vs the node-role gold, framed as **check-worthiness adapted to tree nodes** (cite ClaimBuster/CheckThat!); run the **CRF-insensitivity-to-na-errors** ablation (uniform emission ⇒ na errors can't veto/rescue).
6. **Learning (in reserve, no new gold):** if a learned component is demanded, distil the flat verifier from the CRF's consistent marginals using **distant + programmatic-perturbation labels** (TrueTeacher paradigm) — a second contribution at ~zero annotation cost.

**Alternatives considered:**
- **Full-tree supervised CRF training** (gold tag at every node) → **rejected**: nothing consumes full-tree gold (emissions frozen; transitions = 2 scalars fit to root-level labels); per the design doc transitions are ~90% of value already (low ROI); gold is expensive (13,771 nodes × video).
- **Resource/benchmark paper** with dense per-node gold as the primary contribution → **rejected as primary**: GroundMM occupies much of the AV-misinfo-grounding space; the method framing is cheaper and stronger. Kept only as a possible pivot.
- **Featuring an na/verifiability classifier as a contribution** → **rejected**: check-worthiness (ClaimBuster/CheckThat!) owns it; claiming novelty invites a "this is CheckThat! Task 1" desk reject.
- **Annotating the legacy 25-claim r5e gold-pilot template** → **rejected**: it is the flat-unit surface (pu_/f/n), not the tree-node surface; annotating it forces a re-do.
- **Keeping DSG as the sole nearest competitor** → **rejected**: BTProp is the mechanism-level nearest competitor and must be engaged + baselined.

**Consequences:**
- ✅ Annotation frozen and minimal — root verdict + sampled per-node modality + dense-but-cheap node-role; reusable across backbones; **annotate once**.
- ✅ Defensible positioning in the BTProp lane; modality posterior is the headline (empty axis).
- ✅ `na` heuristics reframed as parser-derived role + check-worthiness validation → neat; the insensitivity ablation turns the liability into a robustness result.
- ✅ Learning door open at ~zero annotation cost (TrueTeacher distillation).
- ⚠️ Must implement **BTProp + DEFAME baselines** or the novelty claim is exposed.
- ⚠️ Modality posterior must be shown to *matter*, not just exist.
- ⚠️ Distant-label validity (natural ≈ supported) still needs pilot validation; **emission calibration (de-saturation) remains the real bottleneck** (impl plan §6).

**Cross-refs:** `research/LITERATURE.md` (2024–2026 extension); impl plan §8 + §8.1; design doc §1b.5 (na handling); feasibility §7 (novelty).

**Refinement (2026-07-06) — gold schema is PER-CHANNEL, matching the two per-modality CRFs.** The merged
`claim_verdict_gold` + `claim_modality_gold` and the node `support_gold` + per-channel flags are replaced
by: **claim** = `verdict_visual` + `verdict_audio` (each supported/partially_supported/unsupported);
**node** (probeable only) = `visual_gold ∈ {no,other,ocr}` + `audio_gold ∈ {no,speech,other}` +
`unverifiable` — i.e. the CRF unary target {no, A, B} per modality, support(M) := gold_M≠no. Rationale:
the single merged verdict mismatched the model (v1 = two *independent* per-modality CRFs); per-channel
gold is the direct calibration/eval target and eliminates contradictory support-vs-channel combos. The
viewer also adds a per-clip **audio-only** player (original mp4 audio track, since gold must use original
media not the 1fps/16 kHz cache). Free to change — **no annotation had started**. Schema owned by
`scripts/build_gold_pilot.py`; UI by `scripts/build_gold_viewer.py`; contract table in impl-plan §8.1.
(The perturbation gold and `eval_phase3.py`, both unbuilt/programmatic, must adopt the same per-channel
schema.) Further simplifications (same day): **dropped `unverifiable`** (redundant with
visual_gold=audio_gold=`no`; unverifiable-in-principle is a text-only property already predicted by the
Phase-1 text-only modality-prior layer, not re-annotated per-node against video); **`role_gold` reduced to
{probeable, na}**, asked only on **content nodes** — structural operators are parser-determined by
deprel (`case`/`cc`/`det`/`cop`/`punct`, near-zero error, not a judgment) and excluded from the
annotation surface (now content-only, 1,160 rows vs 1,474). Viewer adds a collapsible **ASR transcript**
(hidden by default, whisperx→qwen fallback; 51/200 clips have speech) + a per-clip audio-only player.
**Sub-channel co-occurrence (2026-07-06):** `visual_gold`/`audio_gold` gain a **`both`** value — a unit
can be grounded by ocr+other (captioned sign) or speech+other (chant). So node gold is a *superset* of
the CRF's exclusive 3-state emission {no,A,B}; support(M) := gold_M≠no is unchanged, and eval scores the
model's single (forced-choice, ADR-006) subtype by **membership in the gold set**. A 4-state/multi-label
CRF subtype is a possible future extension; ADR-006's forced-choice pass-2 stays.

---

## ADR-016: Phase-3 parse-normalization layer — resolve-once det→SRL→LLM; verifiable manner adjuncts promoted+probed (2026-07-13)

**Status:** ACCEPTED (design). Inserts a parse-normalization map `PN` — the step that rewrites the raw parse into checkable units — between the UD parse and the tree-CRF.
Formal spec: `docs/project_notes/parse_normalization_design.md`. Supersedes impl-plan §2.2's uniform
"obl/advcl → ψ=1" (its transition factor ψ — the pairwise compatibility table on an edge — held flat, so those edges add no compositional constraint); **pauses** the ADR-015 frozen pilot (units change).

**Context:**
- Raw UD tokens are poor verification units: manner "by hand" splits into the vacuous atom "hand"; light
  verbs become tree roots; a main-content purpose clause is filed as an adverbial adjunct (`advcl`→ψ=1),
  so the main action's support never reaches the claim verdict (the "advcl/light-verb-root" misfire).
  Root cause: the syntactic parse ≠ semantic checkability/importance.
- Lit (`research/LITERATURE.md` 2026-07-13): the fix is established — SRL/AMR promote manner as one typed
  unit (`ARGM-MNR`/`:manner`) and drop light verbs/function words; PredPatt (UD→predicate-argument) and
  Direct Semantic Splitting are conversion templates; a constrained LLM parse-editor (ProoFVer-style
  typed edits) is auditable; learned MWE detectors generalize poorly (PARSEME ~70/38 F1 seen/unseen).
- User direction: co-evolve method + annotation + framing; `obl` must NOT be uniformly ignored — a
  checkable manner ("operated by hand vs automated") should be *verified*.

**Decision:**
1. Insert **`PN: T_UD ↦ T*`** — the map from the raw UD parse tree to a tree of checkable units — a **resolve-once, precision-ordered** pipeline `PN_llm ∘ PN_srl ∘ PN_det` over
   a **closed edit algebra** (`MERGE/REATTACH/TYPE/ROLE/DROP`). Each stage edits only sites its info level
   (`F₀..F₃`) *determines*; **no later stage overrides** an earlier decision (LLM disagreements logged, not
   applied).
2. **Combine SRL with UD** by span-alignment → an edge-role map `ρ` on the UD tree (enriched `T⁺`); SRL
   augments, never replaces, the backbone.
3. **Composition types gain `verif-mod`** (soft-gate): a checkable manner/instrument adjunct is promoted to
   one **probeable** unit, **probed as a relation**, and soft-gates (violation → partial, not veto).
   `inert-mod` (ψ=1) is reserved for genuinely optional/unverifiable adjuncts; main-content purpose clauses
   (`advcl:purpose`/SRL `ARGM-PRP`) become **core** (binding) + re-root off light verbs.
4. **Reproducibility:** frozen SRL + LLM snapshots (temp 0), LLM emits validated JSON edits only, per-claim
   `T*` + edit logs released as a static artifact → no learned component on the reproducibility-critical path.
5. **Eval upgrade:** per-node label correctness on the *verifiable* subset (`na` excluded) + faithfulness
   (drop/corrupt sensitivity), reported separately from claim-verdict accuracy.

**Alternatives considered:**
- Keep raw UD + patch downstream (`na` labels, ψ tweaks) → **rejected**: patches the symptom, leaves
  locally ill-defined units (undermines the interpretability contribution).
- Switch backbone wholesale to an SRL/AMR/UCCA parser → **rejected**: heavier, more brittle, discards the
  clean UD tree the CRF uses; use SRL as a *signal over* UD instead.
- Free-LLM decomposition (FactScore/DSG-style) → **rejected**: no external referent, erodes the
  parser-grounded/reproducible framing; constrain the LLM to typed edits over the parse.
- Allow-override (later stage revises earlier) → **rejected for v1**: less auditable; use resolve-once,
  log disagreements.
- Learned MWE/light-verb detector for promote/demote → **rejected**: PARSEME poor OOD generalization; use
  deterministic rules over UD + lexicon + SRL roles.

**Consequences:**
- ✅ Fixes "by hand", the advcl/light-verb misfire, and vacuous atoms at the **structure** level (one layer,
  not downstream patches) → good units + local interpretability.
- ✅ Citable contribution (parse-normalization into checkable units inside a compositional AV tree-CRF;
  positioned between pure-rule and pure-LLM).
- ✅ Reproducibility preserved (released static `T*`).
- ⚠️ Units change → ADR-015 frozen 200-claim pilot **paused/superseded**; regenerate from `T*` after `PN`
  (still free — no annotation started).
- ⚠️ New component to build + validate (`normalize_parse.py`, SRL model choice, LLM edit schema, `λ_soft`).
- ⚠️ Two frozen models now in the pipeline (SRL, LLM) → "deterministic" = reproducible-given-frozen-artifacts.

**Implementation (2026-07-15):** dedicated build plan
`docs/plans/avid_phase3_parse_normalization_implementation_v1.md` (staged **PN-1** deterministic →
**PN-2** LLM-SRL role → **PN-3** deferred). Role-signal decision: **LLM-SRL with Qwen3-30B** — no SRL
library is installed (`allennlp`/`spacy`/`stanza` absent); reuse the r5 formulation model (frozen
snapshot, temp 0, validated JSON → reproducible), no new dependency. PN-2 role prompt FROZEN in
`prompts_phase2.py` (`SRL_ROLE_SYSTEM`/`srl_role_user`/`SRL_ROLE_LABELS`). Parse-surface note: the parser
emits **no** `advcl:purpose` or manner subtype, so the headline fixes ("by hand", purpose re-root) are
PN-2 (`φ₂`), not deterministic. Handle renamed **Φ→PN** (2026-07-15, ASCII/typeable).

**Cross-refs:** `docs/project_notes/parse_normalization_design.md`;
`docs/plans/avid_phase3_parse_normalization_implementation_v1.md`; `research/LITERATURE.md` (2026-07-13);
impl-plan §2.2/§4/§8/§8.1; `compositional_verification_design.md`; issues.md (2026-07-13, 2026-07-15).

---

## ADR-017: 3-way pass-1 verdict (yes / no / can't-tell) — reintroduce NEI, reversing ADR-014 (2026-07-15)

**Status:** ACCEPTED (design), **gated** by the REF/NEI-separation study (issues.md 2026-07-15) as go/no-go.
Prompt in `prompts_phase2.py` (v7, `pass1_user(three_way=True)`). Reverses **ADR-014** (binary pass-1).

**Context:**
- The per-node support emission is binary {yes, no}, but there are **three** outcomes: **supported**;
  **refuted** (verifiably absent — scene/audio available, thing not there); **not-enough-info / can't
  tell** (off-screen/occluded/silent). Binary forces "can't tell" to masquerade as "no/absent", so an
  unverifiable unit looks like evidence-*against* and wrongly drags the claim down.
- REF and NEI must aggregate **oppositely**: a refuted required arg → **veto**; an NEI unit → **abstain**
  (→ partial). Binary can't express this, forcing the CRF to guess via confidence thresholds
  (design-doc §5) — fragile, calibration-dependent.
- It is the fact-verification standard label space (FEVER S/R/NEI; NLI 3-way; SNLI-VE; Audio-Entailment;
  natural-logic independence). Binary was the outlier.
- ADR-014 removed "unknown" because the 8B visual model over-used it AND it corrupted the verdict. Both are now
  addressed: (a) in the new aggregation NEI → abstain (harmless, not verdict-corrupting); (b) FOLIO shows
  models *under*-pick "false"/"unknown", so the risk is under-use not over-use → word B strongly, fence C.

**Decision:**
1. Pass-1 → **3-way {A=yes/supported, B=no/refuted, C=can't-tell/NEI}** → CRF emission {SUP, REF, NEI}.
2. **Plain wording** ("yes / no / can't tell"), not technical ("supported/refuted/NEI") — the visual and audio language models
   read plain tokens more reliably (Audio-Entailment prompts "yes/no/maybe"). **B worded strongly** (fire
   on clear absence; FOLIO); **C fenced** to genuine view/audio unavailability (Reliable-VQA "abstain iff
   you don't know"). Separate visual/audio glosses (label-description effect). Refs: SNLI-VE, VizWiz,
   Audio-Entailment, FEVER, ADR-013.
3. **Aggregation becomes label-driven** (design-doc update): REF → necessity/veto edge; NEI → abstain
   (no penalty → partial). Replaces the confidence-gated veto of §5 — cleaner, less calibration-dependent.
4. **Calibration becomes 3-way** (multi-class Dirichlet/vector scaling, not binary temperature);
   supersedes the binary-calibration plan — calibrate *after* the 3-way re-probe.
5. **Gated by a study** (issues.md 2026-07-15): re-probe a small sample with **input ablations** —
   blacked frames / muted audio → expect **C**; removal-decoys → expect **B**; normal-present → **A**.
   Commit only if **C fires under ablation** and **B (not C) fires for clear absence** (REF/NEI separate);
   else fall back to binary + upstream abstain.

**Alternatives considered:**
- Binary + upstream abstain only (mark unverifiable via role/PN) → handles unverifiable-*in-principle* but
  NOT clip-specific can't-tell (occlusion); the probe still needs NEI.
- System-level abstention instruction (no explicit option) → no first-token distribution for the logprob
  read → rejected.
- 4-way (split NEI into off-screen vs degraded, VizWiz-style) → deferred as a diagnostic-only extension.
- Technical labels (supported/refuted/NEI) → rejected: too abstract for the visual model (user concern +
  Audio-Entailment evidence that models are prompted with plain "yes/no/maybe").

**Consequences:**
- ✅ REF vs NEI separated → veto-vs-abstain is label-driven (robust, calibration-independent for that
  decision); unverifiable units stop masquerading as evidence-against.
- ✅ Field-standard label space; likely de-saturates (uncertainty has a home).
- ⚠️ Needs a re-probe (binary data can't be un-collapsed) — fold into the M2 (per-node probing) / PN re-probe; gated by the study.
- ⚠️ CRF emission + composition + calibration all become 3-way (modest `tree_crf.py` extension; multi-class calibration).
- ⚠️ Over/under-use is empirical → the study + calibration must confirm C is used meaningfully.

**Cross-refs:** `prompts_phase2.py` (v7); ADR-013 (wording lineage), ADR-014 (reversed);
`compositional_verification_design.md` (emission/veto — superseded here); issues.md 2026-07-15 (study);
`research/LITERATURE.md` (FEVER/SNLI-VE/Audio-Entailment/VizWiz/FOLIO/Reliable-VQA).

**Refinement (2026-07-15) — Stage-A ladder PASSES both modalities; E2 gate designed as a ready hedge +
calibration emission; two corrections.** A focused, web-verified literature scan on the REF-vs-NEI
question (`research/LITERATURE.md` 2026-07-15) + the completed Stage-A ablation ladder reframe the gate:
1. **Stage A PASSED for both modalities under the proper ladder** (audio mute S=0.70; **visual
   blur/pixelate → 97.5% can't-tell, S=0.80; cropaway 75%; R=0.60, U=0.175** — job 400314, landed 14:38).
   The earlier black-frame "fail" (97% "no", C 0.17→0.03) was a **confounded, viewable-but-empty stimulus**
   (a clear black frame legitimately has no X → "no" is defensible), **not** a general visual-blindness
   failure. **Single-call 3-way (W0) is the provisional default for both modalities.** W1 (fence C harder)
   stays deprioritized — can't fix the confound, depresses the already-high blur-C.
2. **E2 decomposed availability gate = the literature-backed HEDGE, designed + frozen, not an emergency
   fix.** Call 1 asks availability, Call 2 (only if judgeable) asks presence, so REF/NEI come from
   *different* questions — the structural fix for the one residual risk (viewable-but-target-absent / real
   occlusion, where a single call can misread NEI→REF). Answerability ⟂ veracity is well-anchored (Kadavath
   P(IK); Kamath 2020; Read+Verify; AVeriTeC keeps NEI=evidence-not-found separate from refuted); it also
   yields a cleaner chain-rule 3-way emission for calibration [P(yes)=P(judge)·P(present|judge),
   P(no)=P(judge)·P(absent|judge), P(cant_tell)=P(¬judge)]. **Run head-to-head with W0 on the Stage-D
   real-NEI slice; commit the simpler W0 if it holds there, E2 where it wins.** Prompts FROZEN in
   `prompts_phase2.py` (`gate_user`/`get_gate_system`/`GATE_VERDICTS`).
3. **Rationale correction:** the ADR's "the visual and audio language models read plain tokens more reliably than technical
   labels" is **not** an established result (Audio-Entailment uses plain "yes/no/maybe" pragmatically, no
   comparison; Surface Form Competition explains only *why* wording matters). Treat plain-vs-technical as an
   empirical W-sweep question, not rationale.
4. **Fallback + eval:** if even the gate fails the §6 rule for a modality → binary {yes,no} + an **external
   availability detector** (blur/blank/occlusion for visual; energy/VAD for audio) supplying a
   model-independent NEI, or binary + upstream abstain. Add **abstention-aware scoring** (Reliable-VQA
   Effective Reliability + risk–coverage) alongside S/R/U. Asymmetric per-modality outcome stays allowed
   (audio already passes single-call). Full protocol: `docs/plans/avid_phase3_nei_elicitation_v1.md`
   Revision v1.1.

The go/no-go gate itself (S≥0.5 ∧ R>0 ∧ U≤0.2 ∧ real-NEI≥0.5, per modality) is **unchanged**; only the
elicitation being gated and the staging order change.

**Status (2026-07-15, later) — COMMITTED W0 (single-call 3-way), both modalities; NEI validation closed.**
Stage A met the S/R/U gate for both channels, so W0 is committed. The real-NEI slice (Stage D) and the E2
head-to-head are **DEFERRED (not dropped)**: the dataset's claims are ~100% verifiable, so genuine
node-level NEI is rare and validating transfer to a near-empty class is low-value right now. E2 remains
designed + frozen in `prompts_phase2.py` as the documented fallback. **Open checkpoint at M2:** confirm the
3-way abstention rate isn't excessive on the full re-probe (Stage A: ~17.5% visual C on *normal* clips —
part legitimate node-level occlusion, part spurious hedging); if excessive, fall back to binary v6 (ADR-014).
Effort redirected to parse-normalization PN (ADR-016).

## ADR-018: PN completion — F₃ checkability pass (PN_llm), tight-unit surface, re-root rejected (2026-07-16)

**Status:** ACCEPTED — completes the ADR-016 PN pipeline and unblocks the gold pilot. Governs the T* unit surface and the `na` split.

**Context.** Regenerating the paused pilot (ADR-015/016) to review units surfaced three defects:
1. Units still showed bare `"hand"` (not `"by hand"`): the PN MERGE lived only in the sidecar `pn_unit_text`, but the build scripts read the pre-PN `content_subtree_text` (bugs.md 2026-07-16).
2. `"correct"` stayed probeable: the design's **F₃ residue stage `PN_llm`** (`parse_normalization_design.md` §3/§6) was **specified but never built** — the only PN LLM pass was PN-2 SRL role typing over `{obl,nmod,advcl}`; `amod` and general checkability were never judged.
3. ~1,334 non-event units were clause-length (a copular root swallowed its subject; PN-1 MERGE used the full `subtree_text`).

**Decision.**
1. **Built `PN_llm` = PN-3 F₃ checkability** (`run_pn3_check.py`; prompt `CHECKABLE_*` in `prompts_phase2.py`; `run_pn3_check.slurm`, A100-80gb Qwen3-30B, temp 0, cached). Resolve-once: touches only PN-1-provisional probeable content (`pn_stage==pn1 ∧ role==probeable`); `NA → role=na, probed=False`; never overrides a confident PN-1/PN-2 decision; malformed reply → CHECKABLE (safe default). Prompt is **principle-first + domain-neutral** (v2 strengthened CHECKABLE for concrete phenomena/events + named entities after v1 over-flipped `Typhoon Halong`/`storm`/`home floats away`), and passes the **full claim with the unit marked `« »`** (checkability is context-dependent — the reason it is F₃, not a lexicon).
2. **Tight-unit surface** (`build_tree.py` `UNIT_BOUNDARY_DEPRELS`): a non-event node's unit = its head phrase (det/case/amod/compound/nummod/flat fold in), **excluding boundary children** (nsubj/obj/obl/nmod/acl/appos/ccomp/…) which are their own rows. **Events are EXEMPT** — they keep the full proposition. PN-1 MERGE now folds **only the case marker** into the tight span (not the full subtree).
3. **Light-verb re-root (ADR-016 §6 / design §6): REJECTED.** Reviewing all 13 `advcl:PRP` candidates, re-root demotes checkable motion/appearance matrix events (`gets out of tram`, `comes in from the side`, `appeared in luxurious robes`) and promotes consequence/conditional clauses. The design §6 tram example is itself a mis-analysis ("get out of X" is perceptible motion, not an empty light verb). The *inverse* issue (motion/appearance light-verb roots wrongly `na` by `build_tree`) is logged as a separate open item, not fixed here.
4. Build scripts read `pn_unit_text`/`pn_unit_span`/`role`/`comp` from `trees_ud_star.jsonl`; **`gold_pilot_v3`** regenerated from the final T*.

**Consequences.**
- Gold units correct: `by hand` ✓, `correct → na` ✓; clause-units 1,334 → 147; F₃ 13.5% na (293 v1 over-flips rescued in v2). Reproducible DAG: **`scripts/run_pn_regen.slurm`** (build_tree → PN-1 → PN-2 → PN-3 → gold_pilot_v3). Jobs: PN-3 v1 402236, full regen 402377.
- `na` stays **annotator-validated** (ADR-015 §5: na = check-worthiness validation, not ground truth); F₃ imprecision is recoverable and is exactly what na-detection P/R measures.
- **Downstream M2/M3 outputs are now STALE** for the changed units (tight surface + F₃ na) — re-run before using M3 (tree-CRF inference) verdicts against the new T*; the gold pilot is independent (human-annotated).
- Residual tail: ~64 abstract-noun/parse-grouping entity `na`s and ~147 long-PP units remain; defensible / annotator-correctable, not frozen-blocking.

## ADR-019: PN unit-surface refinement — proposition roots, bare-modifier suppression, role-conditioned case-merge, temporal-clause na (2026-07-20)

**Status:** ACCEPTED — refines ADR-018 after a corpus-wide review of the regenerated pilot. Governs the final T* unit surface.

**Context.** Reviewing the ADR-018 surface across all 2,375 claims (not just seed examples) exposed four issues:
1. **Truncated propositions (1,375 event/root nodes).** ADR-018's *gated* content-subtree propagated upward: an event/root built its unit from tightened children, dropping their modifiers (root `broadcast includes clips` lost `of heavy rain…`; `Successful liftoff of rocket` → `Successful liftoff`). Only 48% of claims had any unit covering the full claim.
2. **Bare adjective/adverb/number probes are vacuous + redundant.** 1,512/1,788 attribute units were strictly nested in their head noun's unit (`High` ⊂ `High winds`); `1` in `Blue Ghost Mission 1` (nummod) probed standalone. A bare modifier has no AV truth value alone and its content is already in the head unit.
3. **Case-marker over-merge (2,146/2,425 obl/nmod entities).** `with clear skies`, `in Western Alaska`, `of rocket` — the preposition is attachment noise; only manner/instrument (`by hand`) wants it.
4. **TMP→na over-aggressive.** `with clear skies` mislabeled `TMP`; temporal *clauses* with visible events (`as rocket lands`) na'd whole. ~76 na'd units contained a suppressed verb.

**Decision (four fixes).**
1. **Events + root use the FULL subtree** as their unit (`build_tree`: `cssp = ssp` for event/root); only **non-root non-event** nodes use the tight content span. Restores the claim proposition for every claim.
2. **Suppress non-root `amod`/`advmod`/`nummod`** (`build_tree.MODIFIER_NOPROBE_DEPRELS`): `probed=False → role=na`. Content still lives in the head unit. Predicate-adjective ROOTS (deprel `root`) are unaffected → surface as the full claim.
3. **Case marker kept ONLY for MNR/INS** (`run_pn2_srl`): non-MNR/INS obl/nmod revert to the bare content NP (`clear skies`, `Blue Ghost Mission 1`); `by hand` kept. SRL prompt **v2** — weather/attendant conditions are not `TMP`.
4. **`TMP→na` only for non-clausal temporals** (`run_pn2_srl._subtree_has_verb`): a temporal clause with an embedded event stays probeable.

**Consequences.**
- Probed rows 11,628 → **9,774**; F₃ na 1,391 → **828 (10.6%)**; root-covers-full-claim **48% → 96%**; event truncation **1,375 → 0**; non-root clause-like units 1,334 → **66** (residual: quotes/appositives/long names). **`by hand` preserved**; `clear skies`/`1`/`Successful liftoff of rocket` all correct.
- **GPU:** ran on **2× A100-40gb tensor-parallel (tp=2)**, job 413160 (~16 min), after H100/H200 were QoS-capped at 0 (`cxiao_8gpu_tier`, no `normal` QoS) and A100-80gb was full. `run_pn_regen.slurm` now uses `--tp 0` (auto GPU count).
- **Limitation (Fix 4):** mis-grouped temporal clauses (verb absorbed into a noun node, e.g. `rocket lands`) aren't detected as clausal → still na; *mitigated* because Fix 1 captures them in the probeable root. A parse-layer grouping issue, out of scope for PN.
- `na` stays annotator-validated (ADR-015). **M2/M3 remain STALE** vs this T* — re-run before using M3 verdicts.

---

## ADR-020: Gold Schema v2 — multi-granularity compositional-tree annotation (amends ADR-015) (2026-07-23)

**Status:** ACCEPTED. Amends ADR-015's flat post-PN annotation surface. Plan:
`docs/plans/avid_phase3_gold_schema_v2_v1.md`.

**Context:** ADR-015 froze annotation on the **flat post-PN** tree-node surface (`tree_units_ud.tsv`). That
surface only validates *modality-given-the-units*; it **cannot audit or optimize PN's own unit construction**
(merge / na / which-level decisions) — you see `by hand` but not that PN dropped `hand`, nor that
`by @ACCUWEATHER` was wrongly kept. The trained-SRL validation (2026-07-23) + the passive-agent-as-INS finding
exposed exactly this: we need human ground truth for *which nodes at which level are checkable*.

**Decision:** Annotate the **multi-granularity compositional tree** (content lexical nodes + composition
factors, every level) from `hypergraph.jsonl`, span-anchored. **Content nodes only** (function words /
structural operators stay parser-derived `na`, not annotated). Per node: `role ∈ {probeable, na}` —
**checkable-in-composition allowed** (na alone / probeable composed, e.g. `by hand` na / `changed by hand`
probeable) — plus `visual_gold`/`audio_gold` on probeable nodes. **Guideline:** probe pointable **entities** +
**meaningful compositions** (event-with-args, bindings, proposition); `na` the relational glue, bare
predicates, and manner-alone. **Single annotator (cxiao), no IAA** — disclosed as a limitation; the IAA-free
primary metric is **PN-vs-gold unit-selection agreement**. **Relational-probe formulation deferred** — decided
*by* the gold, not before.

**Consequences:**
- ✅ PN unit construction becomes directly evaluable + gives a **data-driven optimization target** for PN.
- ✅ Human agreement on **our own scheme** = the defensible **primary** PN validation; trained-SRL → secondary
  cross-check; the CRF-insensitivity ablation (key_facts 2026-07-23) → the robustness result.
- ⚠️ Larger per-claim annotation than the flat surface → **start with a ~30–50 claim subset** to set the
  PN-optimization direction; scale later on the improved surface.
- ⚠️ Single-annotator gold (no IAA) — limitation to disclose.
- Supersedes ADR-015 §4 (annotation contract only); ADR-015 positioning + na-as-check-worthiness unchanged.

**Cross-refs:** plan `avid_phase3_gold_schema_v2_v1.md`; `key_facts.md` CRF-insensitivity ablation (2026-07-23); ADR-015; the trained-SRL validation (`research/LITERATURE.md` 2026-07-23).

---

## ADR-021: Conjunct-local semantic factor tree replaces contextualized subtree probes (2026-08-13)

**Status:** ACCEPTED for the gold-v3 annotation pilot. Final paper-model adoption remains gated on gold agreement and binding-decoy experiments. Supersedes ADR-020's deferral of relational-probe formulation; preserves gold-v2 unchanged for comparison.

**Context.** The interior-emission review showed that the gold-v2/current CRF surface mixes three objects: the UD dependency scaffold, normalized probe units, and a span-containment visualization with semantic factor boxes (`attr`, `prep-rel`). Event/root emissions copy descendant text, so observations overlap. The proposed fix is one probe per semantic conjunct, but it must retain binding, exact inference, a meaningful parse role, and a precise normalization/`na` contract.

**Decision.**

1. Keep three explicit representations: parser output `T_UD`; normalized, parser-traceable units `T*`; and executable bipartite semantic factor tree `G*`. `attr`/`prep-rel` are factor types in `G*`, not dependency labels or invented UD nodes.
2. Retain entity/event/state nodes as local truth variables with **independent unary probes**. Do not contextualize a child probe with its parent and never skip a child because a parent probe fails.
3. Contract attributes/cardinalities into **local observed factors** on their nearest retained host. Contract function words/operators while preserving their surface form as relation markers.
4. Replace every retained semantic parent-child connection with exactly one typed edge factor. Reliable core UD roles use deterministic mappings; ambiguous `acl/advcl/obl/nmod/xcomp/ccomp/parataxis` connections go to a closed-label text-model residual classifier.
5. Scope a relation observation to its **immediate semantic endpoints only**. Subtree evidence reaches the factor through belief-propagation messages; it is never copied into the edge question.
6. Add a latent, unprobed `y:claim` output and one root-composition factor. If the UD root survives, composition is fixed; if a copular/property root is contracted, the root predicate is observed. There is no whole-claim MLLM emission.
7. Redefine normalization roles as `{unary_probe, observed_factor, fixed_factor, contract, abstain}`. `abstain` is the precise successor of `na`: a local target lacks a stable AV truth value. Parent failure, difficulty, or low visibility are not `abstain` reasons.
8. Separate text-model stages and caches: local-unit normalization (`sfu-*`), ambiguous-edge typing (`sf-*`), then question generation (`sfq-*`). Graph structure is frozen before question wording. All targets/endpoint IDs are parser-fixed; malformed outputs fall back without mutating topology.
9. Select prompts by a frozen synthetic audit (80% behavior + 20% policy coverage, shorter exact tie), with domain-neutral fixtures and zero AViD claims sent to the external judge. Selected versions: `sfu-v3`, `sf-v3`, `sfq-v4`. The v4 wording pass may restore only minimal grammatical context (possessive, particle, preposition, or required generic event argument); it cannot change graph structure or absorb sibling conjuncts.
10. Keep the machine graph and human form deliberately different. Annotators see only natural target phrases, binary `{not_na, na}`, and visual/audio evidence for `not_na`. Hide latent output, root composition, fixed grammatical operators, internal relation labels, and all question-quality taxonomy from the human surface.
11. Normalize literal hyphen chains before semantic compilation. Parser-split forms such as `close-up` and `before-and-after` are one lexical modifier, not separate truth units. The rule is surface-driven and corpus-general; no claim-ID exceptions are permitted.

**Consequences.**

- `scripts/semantic_factor_tree.py` compiles 2,375 claims into 11,741 local variables, 9,356 edge factors, and 2,714 local factors. Every graph is structurally connected/acyclic; four upstream overspanned parser nodes are surfaced as coverage/locality warnings instead of receiving claim-ID repairs.
- Exact sum-product inference remains available because factors replace dependency connections rather than duplicating them.
- `exp/phase3/gold_v3/` contains the still-unannotated gold-v2 claim sample rendered under the simplified schema: 43 claims and 507 human-visible targets. It captures only binary `na`/`not_na`, per-channel evidence, optional notes, and claim verdicts; internal factor metadata remains machine-readable but is not annotated.
- At build time the Slurm controller was unreachable. A cached local Qwen3-0.6B wording trial was too slow on the CPU-only host, and external AViD transmission was not authorized. Gold-v3 therefore uses validated natural-language fallbacks while the `sfq-v4` rewrite cache remains pending a local GPU or explicit external-processing permission.
- Public proposal: `site/proposals/semantic-factor-tree.html`. Canonical prompts remain in `scripts/prompts_phase2.py`.

---

## ADR-022: Dual-route visual questions — add the on-screen-text (OCR) route to the pass-1 stem (reverses ADR-012's visual clause) (2026-08-26)

**Status:** ACCEPTED — templates + formulate prompt edited, canonical trees + gold_v3 regenerated, visual re-probe launched.

**Context:**
- ADR-012 gave the AUDIO pass-1 question two routes joined with "or": (1) a characteristic SOUND, (2) the unit NAMED in SPEECH — because `audio_speech` support (narration) was being starved: a sound-only question scored no-sound units `no` at pass-1, and pass-2 (`audio_speech` vs `audio_other`) only runs on pass-1 = yes, so the speech route was gated out before pass-2 could attribute it.
- ADR-012 then left the VISUAL question unchanged, asserting the on-screen-text route "is already handled by the `visual_ocr` pass-2 subtype, not the question stem." This **contradicts ADR-012's own rejected alternative** ("leave it to pass-2"): pass-2 `visual_ocr` cannot recover a fact that a depiction-only pass-1 question already scored `no`.
- Audit (2026-08-26): **99.7% of visual pass-1 questions were depiction-only** ("visible", "show the action of", "Is X the one V-ing"). The pass-1 system prompt is generic, so the question string is the operative definition of "support." An OCR-asserted fact — e.g. claim `T2G_ACMxR_I4_1111` "Apollo 11 landed on the moon", where on-screen text states it but the imagery does not depict Apollo 11 landing — scored `no` at pass-1 and never reached the `visual_ocr` source pass. The `visual_ocr` subtype was structurally starved: the exact visual twin of the ADR-012 audio bug.

**Decision:**
- Every VISUAL pass-1 question must cover BOTH routes, joined with "or": (1) the unit SHOWN in the imagery (→ `visual_other`), AND (2) the unit written as ON-SCREEN TEXT — caption, sign, title, chyron, or numerals (→ `visual_ocr`). The on-screen-text route is never optional. This reverses the "VISUAL formulation is unchanged" clause of ADR-012; the audio treatment is unchanged.
- Implemented in the ACTIVE deterministic generator `scripts/semantic_factor_tree.py` (`_node_questions` + every `_factor_questions` branch; audio strings untouched) and mirrored in `FORMULATE_VIS_SYSTEM` (`scripts/prompts_phase2.py`) for the r5 path. `SOURCE_PROMPT_VERSION` bumped `-r5-v2 → -r5-v3` so the visual source pass recomputes with the new question.
- Support semantics under the 3-way space {SUP, REF, NEI}: support = shown OR stated; mere non-depiction is NEI, not `no`; only a positive on-screen contradiction is REF — refutation detection is preserved.

**Alternatives considered:**
- Fix only the pass-1 system prompt ("OCR counts as support") → rejected: the human annotator still reads a depiction-only question, and a depiction-framed stem can still bias the model toward a false REF; ADR-012's design deliberately keeps the route in the stem.
- Leave it to pass-2 `visual_ocr` (ADR-012's original visual stance) → rejected for the reason above (pass-2 runs only on pass-1 = yes).

**Consequences:**
- ✅ Facts stated only on screen (signs, captions, chyrons, titles, numerals) are now visually supportable via the OCR route; `visual_ocr` is no longer starved. Resolves the Apollo 11 agent-binding class.
- ⚠️ Expected to RAISE the visual pass-1 yes-rate — intended, mirrors ADR-012's audio note. The pass-2 `visual_ocr` vs `visual_other` split then attributes which route fired.
- **id-preserving:** only question text changed (node/factor ids and structure identical across all 2,375 claims; verified 0 node-set changes), so gold-v3 human annotations stay aligned. The pass-1 cache is question-hashed, so it auto-invalidates only the visual targets while audio stays cached.
- Coverage: 22,927/22,939 visual questions (99.9%) now carry the on-screen-text route.

**Empirical result (2026-08-26, gold_v3 43-claim visual re-probe — jobs 549701/551771):** contrary to the predicted yes-rate rise, the dual-route stem **LOWERED** the visual pass-1 yes-rate (246→223 of 439 nodes; 56.0%→50.8%). Per-node vs the depiction-only baseline: OCR recovered **12 no→yes**, but the compound two-clause question cost **31 yes→no + 12 cant_tell→no**. This is not the agent/theme rewording — a strict **append-only** rerun (route-1 clause verbatim + appended OCR route) reproduced the drop, so the VL model (Qwen3-VL-8B) simply becomes MORE conservative when asked a two-clause "or" question. On the **24 human-annotated** visual nodes, accuracy was **unchanged (19/24 = 79% both old and new**; the single annotated node that changed got slightly worse: cant_tell→no, gold=yes). On the motivating example `T2G_ACMxR_I4_1111`, the model's `no` on the Apollo agent-binding is **expected**: per the annotator the relevant on-screen text is simply **not captured by the model's OCR** (a Qwen3-VL OCR-capability limit), not a data problem. This is the likely root cause of the neutral aggregate — the dual-route question correctly *invites* the OCR route, but the model's unreliable on-screen-text reading is the bottleneck, so admitting OCR in the stem cannot move results. (The `Apollo 11` entity=yes is a separate model false positive.)

**Tense-aware refinement (2026-08-27):** the OCR/text route was further corrected to carry the claim's actual tense (finite **surface form**) instead of the depiction gerund — depiction stays present-continuous ("…the one **landing**"), the text route uses the claim tense ("…state that Apollo 11 **landed**"; theme "…was **affected**"; event "…it **landed**"). Applied to event/agent/theme/manner/eventive-loc-dir templates via a surface-form helper `_ps` (no irregular-verb table — the parse `node_text` carries tense; jobs 567607/567608). This is the linguistically-correct fix (a completed past event is recoverable mainly from text, and text states it in past tense) and it fixes the **human-facing** question, but it did **not** move the model: gold-v3 visual yes-rate **49.9%** (vs 50.8% present-dual / 56.0% baseline), accuracy on the 24 annotated nodes **unchanged at 79%** (0 flips among them), Apollo agent still `no`. This **confirms the annotator's diagnosis** that the model's OCR *capture* — not question tense/phrasing — is the binding constraint. Net for the whole ADR-022 line: questions are now semantically + tensewise correct (helps human gold and the method's story) at a ~6pt recall cost and no measured accuracy change; kept live in gold_v3 as applied. **Conclusion:** the question-stem mechanism does not achieve OCR-support recovery on this model/data and mildly hurts recall. Keep / revert / pivot-to-system-prompt decision is PENDING user input; dual-route questions + predictions are currently live in gold_v3 as applied.

---

## ADR-023: Probabilistic parsing for multimodal claim verification (2026-10-14)

**Status:** ACCEPTED by the user as the paper direction, likely finalized. Model sizes and implementation details below are initial design choices, not validated results. Do not reopen the paper direction because an older note recommends a different framing.

**Context:**
- The user selected a methods paper that compiles NLP-derived claim structure into probabilistic logic, with interchangeable predefined or learned binding functions and inference over alternative evidence assignments.
- Existing systems such as DeepProbLog can supply inference and learning. Reusing them is valid; the paper contribution can be the claim compiler, evidence representation, relation parameterization, or learning procedure.
- The user requires familiar NLP terminology and plain explanations. Do not invent component names or acronyms to suggest novelty.

**Decision:**
1. Compile dependency/SRL analyses into a restricted logical form preserving predicates, arguments, shared variables, and scope. Start with one to three event clauses, local attributes, conjunction, and scoped negation; abstain on unsupported constructions.
2. Retain typed support from depiction, non-speech sound, speech, and OCR. Keep source assertion and direct event evidence distinguishable. Use supported/refuted/insufficient-evidence states; failure to find support is not automatically refutation.
3. Keep visual/audio models frozen. Reuse cached complete-relation scores and candidate-specific observations. A relation means how the participants/events are connected, such as who did what to whom.
4. Parameterize relation probabilities with a small classifier: logistic regression control and a one-hidden-layer MLP (initially 64 hidden units). Add frozen BERT-style text representations only when justified. Decoder-only models remain frozen parsing/evidence modules or baselines; no multimodal LLM fine-tuning is planned.
5. Infer alternative candidate evidence assignments with shared entity/event variables. A small categorical candidate scorer may be learned for ambiguous references, including an unavailable option. Actual distinct events are not mutually exclusive simply because they are candidates.
6. Use an existing DeepProbLog-like backend initially. Learn relation classifiers and selected probabilistic parameters from claim-level labels, with optional limited local supervision. Fixed rules are point-mass conditional distributions; learned distributions use the same declared interface.
7. Keep logical composition fixed in the first implementation; compare learned composition later when identifiable. Preserve canonical observations and model dependencies explicitly; normalization does not guarantee calibration.
8. Temporal constraints are an extension. Parent/child interval union is a proposal baseline, not a binding certificate. Count localization cost and compare the same windows for whole-claim verification.
9. Use real media plus validated synthetic claim edits and supported paraphrases. Split by source video; keep training/calibration labels separate from the existing evaluation gold. Do not build a large synthetic-media corpus or exhaustively annotate every parser node.
10. Begin with 40–60 verified pairs and controls, then a small independent test. Compare simple full-tuple QA, fixed versus learned functions, candidate assignments, and one perception-module replacement under controlled budgets. Empirical failures refine the implementation and claims within the chosen direction.

**Amends / supersedes:**
- ADR-015: preserves the methods-paper goal, but replaces the mandatory training-free AV tree-CRF and modality-posterior headline. Small supervised relation models are now in scope. Existing gold remains evaluation data; create separate training annotations.
- ADR-021: preserves useful parser normalization and existing artifacts, but removes the requirement that the paper model use only immediate-endpoint observations on a fixed tree. Shared groundings and complete relation tuples may require a different program/graph.
- ADR-022: preserves typed depiction/OCR/speech/sound support. No existing prompts or annotations are changed by this decision.
- The October 8 temporal-only recommendation and the October 14 conditional framing audit are historical inputs, not the current default direction.

**Consequences:**
- Existing inference machinery can be reused; a new general inference engine is not a contribution requirement.
- Correct claim compilation, candidate coverage, binding-sensitive inputs, calibration, and evidence dependence remain research risks.
- No new training, inference experiment, data download, or accuracy result is recorded here.

**Canonical design:** [HTML proposal](../../site/proposals/probabilistic-verification.html).
**Generator:** scripts/build_probabilistic_verification_proposal.py.
**Background:** research/2026-10-14/METHOD_FORMULATION.md and REVIEW_QUESTIONS.md.


### ADR-023 implementation priority update — 2026-10-28

- **Accepted priority change:** The user agreed to audit compilation on real
  claims before further feature expansion or relation-classifier training. Run
  the unchanged baseline, inspect accepted programs as well as rejections, and
  compare semantic parsing alternatives before extending frequent constructions.
- **Temporal requirement:** The user highlighted “Apollo 11 landed on the moon”
  versus “Apollo 11 is landing on the moon.” Preserve tense and aspect as part of
  claim meaning. The current compiler does not do so; the planned extension must
  be distinguished from the earlier time-window localization proposal.
- **Working proposal, not implemented:** Infer tense/aspect from the complete
  auxiliary/verb sequence and preserve a context-dependent reference time. Carry
  conditions into executable predicates, evidence identities and scoring inputs.
  Event completion is not a universal consequence of past tense. Exact predicate
  schemas and temporal evidence rules remain to be evaluated during the audit.
- **Scope:** ADR-023's methods direction, frozen media models and DeepProbLog-like
  backend remain unchanged. No temporal compiler or new classifier was implemented.


### ADR-023 implementation priority clarification — 2026-10-28

- **User instruction:** Do not move to media verification yet. Prioritize getting
  claim-to-DeepProbLog compilation working; research and compare syntax plus role
  labeling with rule/neural transformation, direct semantic parsing with
  post-processing, and practical alternatives.
- **Completed comparison:** See `docs/compilation_methods.md` and the
  `compilation_methods_20261028` key-facts entry. Historical compilers remain
  unchanged. This does not select a replacement parser or revise the paper direction.
- **Recommendation, not a user-finalized architecture:** Use one logical form and
  deterministic backend compiler; compare trained SRL and pretrained AMR, then one
  small clause-level logical-form generator. Syntax can assist alignment and tense
  without fixing the inference graph. Complete reference judgments before selecting
  a parser. Do not count opaque argument/source phrases as completed internal
  binding decomposition.
- **Planning proposal:** One or two focused working days for the remaining
  compilation choices, then document a supported fragment. Media verification and
  new relation-model training remain deferred.


### ADR-023 compilation choices accepted; rewrite fallback reserved — 2026-10-28

- **User accepted:** Proceed with the reference review, common logical form and
  deterministic compiler, trained SRL and pretrained AMR baselines, one bounded
  clause-level neural alternative, then frozen compilation evaluation. Compilation
  remains ahead of media verification and relation training.
- **Explicit constraint:** Do NOT implement LLM sentence rewriting now. First
  develop the best practical compiler on the original claims. Rewriting may later
  be used only as a last resort for difficult edge cases or unseen patterns, while
  retaining the original information. A future rewrite must be checked for changes
  to roles, names, quantities, modifiers, negation, modality, tense, reference and
  source scope; it is not assumed meaning-preserving by construction.
- **Vocabulary:** Representation here means the explicit claim logical form,
  not neural embeddings. Interface means the specified inputs, outputs and their
  meanings between parser, compiler, evidence scorer and probabilistic backend.

### ADR-023 full-corpus compilation work — 2026-10-29

- The user authorized optimizing compilation on all 2,375 original claims and required a final full-corpus run with statistics and failure reasons. All text is now compiler-development input, including previously reserved source groups; media/truth/evidence labels remain unused. This is not a held-out source evaluation.
- Implemented an opt-in v2 logical form and compiler with trained SRL and frozen 30B text parsing, typed values, source/proposition contexts, source-matched post-processing and bounded reparsing. Parser selection uses fixed diagnostics, not assistant reference judgments. Earlier code paths and published source archives remain preserved.
- Keep the compiler opt-in. More constructed programs do not establish correct meaning. The fresh twenty-case paired review remains poor; prioritize complete logical-form references and semantic parsing before verifier training. ADR-023's paper direction is unchanged. Sentence rewriting is still prohibited and unimplemented.

### ADR-023 compilation preference — SRL follow-up, 2026-10-29

- **User preference:** Per-claim SRL/neural selection looks like ensemble engineering and should not define the paper's method. Improve trained SRL compilation or test an LLM that revises a supplied syntactic/SRL/AMR parse. Prompts should be concise; protocol version fields need not be generated by the model.
- **Implemented experiments:** One SRL/dependency clause-graph compiler, plus separately evaluated minimal SRL edits with syntax alone or syntax plus AMR. Existing roles are inherited rather than regenerated. Version metadata stays in Python, outside model messages. No per-claim condition selector is used.
- **Measured limitation:** On 24 paired assistant-reviewed cases, the new SRL graph and both editor conditions have seven faithful outputs each. Editors were tested on a fixed 48 inputs each, not all 2,375. This does not establish semantic accuracy or generalization.
- **Recommendation, not a user-finalized replacement:** Use one SRL/dependency compiler as the main baseline; keep post-editing experimental. Fix nominal source/participial scope, structured copular/location complements and controllers next. The probabilistic binding-verification paper direction and frozen perception/small learned relation models remain unchanged. Sentence rewriting remains reserved and unimplemented.


### ADR-023 accepted bounded compiler revision — 2026-10-29

- **User authorization:** Proceed with 24 complete reference readings, a pre-reserved fresh 20-case review, nominal source/modifier scope, structured copular/spatial complements, explicit/lexically licensed embedded controllers, and a full 2,375-input rerun. The global completion-report preference now requires concrete next steps with intended goals, clearly separate from completed work.
- **Implemented:** One opt-in semantic SRL pass, retaining the prior default code path. No per-claim selection, LLM call or sentence rewrite. Original texts and cached parses are preserved; only copied annotations receive normalization. The scoped compiler/backend are unchanged.
- **Measured:** 2,042 compiled; fresh 20 have 8 faithful, 5 partial, 2 incorrect, 5 refused. This is a modest gain over prior 7/4/4/5, not an independent accuracy estimate. Keep the frontend experimental rather than declaring reliability from acceptance.
- **Proposed next work:** Event/nominal references, mass-noun predication and duration types; missing/wrong SRL roles; backend cost profiling; independent review after the next freeze. These are proposals, not implemented changes. Media verification/training remain deferred; ADR-023 is unchanged.


### ADR-023 compiler follow-up experiments — 2026-10-30

- **Authorization:** The user accepted and requested experiments on remaining identity/duration structure, missing/wrong SRL frames, DeepProbLog profiling and frozen independent source review. Implemented as an opt-in extension; historical modules and archives remain unchanged.
- **Completed evidence:** Acceptance2,108/2,375; assistant new-source faithful11→12, separate frozen model18→17;10 additions include only2 fully faithful. Direct state rules finish the previous native timeout;167 tests pass. The separate model misses visible omissions and is not gold.
- **Interpretation, not a new paper direction:** Keep compiler reliability open. Do not select per-claim parsers or replace human references with model judgments. Next proposals address media/label scope, threshold/OR/time omissions and bounded human evaluation. No media verification, relation-training experiment or LLM sentence rewriting is authorized by these results alone; ADR-023 remains unchanged.


### ADR-023 source/condition fixes and actual human review — 2026-11-01

- **User authorization:** After examples/explanation, the user requested implementation of media-description/quoted-label scope, threshold/conjunction/shared-time handling and bounded human reference judgments. Reserve the review set before changes; develop on separate previously inspected examples.
- **Implemented:** One opt-in scoped SRL compiler; narrow explicit structures or refusals; equivalent balanced/observation-ordered AND/OR for native feasibility. Historical modules and original claims remain unchanged. No parser ensemble, sentence rewriting or new model calls.
- **Measured:**2,095/2,375 compile,15 earlier accepts now refused and2 earlier refusals compile.187 tests pass. Reduced acceptance must not be called a semantic gain without references. Keep every changed status/reason reviewable.
- **Human stage open:** Twenty new-review source groups reserved (7 targeted cases +13 random). Intended-reading and anonymous comparison form prepared; zero actual human readings or comparisons received. An asynchronously requested reviewer assignment remains pending. Assistant tests and blank fields are not human gold. The importer validates returned reviews but does not create missing answers or automatically publish reviewer data.
- **Proposed follow-up:** Collect the reserved reviews, audit the15 lost accepts and resolve supported failures while preserving fresh evaluation. Media verification/training remain deferred; ADR-023 unchanged and rewriting still unimplemented.


### ADR-023 review assistance — user requested 2026-11-01

- **Authorization:** The user requested a strong independent agent to draft the reserved review answers for their review, to save time. This authorizes agent assistance; it does not create human judgments.
- **Completed:** Fresh-context GPT-6 Astra/xhigh wrote twenty claim-only intended readings; those were frozen before anonymous A/B outputs were supplied. No previous ratings, method mapping, compiler code or project notes were supplied. Original responses and a later reading concern are preserved.
- **Recording rule:** The editable page starts with zero user confirmations. Returned confirmed answers are recorded as human review assisted by an agent draft. Keep raw suggestions, user edits and unaided reviews distinguishable. Raw agent files and unconfirmed suggestions must not count as received human references.
- **Next:** User reviews/corrects the draft, returns an export, then confirmed errors guide compiler work. No compiler changes, media verification, relation training or sentence rewriting are part of this task.


### ADR-023 accepted review-driven compiler cycle — 2026-11-04

- **User authorization:** Proceed with analyzing the completed twenty-case review, tracing failure causes, fixing two or three recurring patterns, rerunning all2,375 claims and evaluating a fresh sample reserved before changes.
- **Dependency:** The user reports finishing the review; its browser export has not reached the project. This authorizes the work, not an assumption about the user's answers. Import the actual export before selecting fixes from confirmed errors. Do not substitute model ratings or ask the user to repeat the review.
- **Preparation completed:**20 fresh cases across21 source videos reserved, disjoint from129 recorded review sources and from each other;273 eligible claims after ID/source/text exclusions. Current baseline outputs/source hashes frozen. Paired analyzer tested for per-case randomization, uncertainty, refusals, identical-output disagreements and unconfirmed drafts. This is not a new semantic evaluation.
- **Next:** Use the returned export, preserve user/model disagreements, conduct one bounded revision and fresh review, then decide whether the compiler is ready for a small binding experiment. No rewriting or new media/training experiment starts from preparation alone.


### ADR-023 review-driven compiler cycle completed — 2026-11-05

- **User authorization fulfilled:** Move/import the returned20-case review, use actual human edits, revise at most3 recurring families, rerun all2,375 and inspect the pre-reserved20 fresh cases. Original review bytes, historical compiler modules, source archives and annotations are preserved.
- **Implemented:** One opt-in deterministic SRL/dependency revision for argument retention, participant links and selected nominal constructions. Generic typed arguments express reciprocal and coarse phrase meanings, with explicit verifier requirements. No per-claim ensemble, LLM rewrite or new media/training experiment.
- **Measured:**2,099 compiled;4 additions,0 old accepts lost,29 changed programs;207 passing tests. Three human-identified unnecessary refusals now compile. Fresh outputs remain unchanged with13/4/3 assistant judgments, so general semantic improvement is not established. Native inference still has a25-second timeout on the large protest example.
- **Proposed follow-up, not a new paper decision:** Address nonveridical nominal/question content and missing predicate/identifier coverage; bound inference cost before media expansion. The compiler remains experimental and ADR-023 remains unchanged. Preserve the first freeze and disclose later safety restrictions.


### ADR-023 scope/content follow-up — 2026-11-05

- **User authorization:** Proceed with the explained scope fixes and original-text coverage checks; explain how both are implemented. Broader paper direction stays unchanged.
- **Completed:** One opt-in SRL/dependency extension transforms copied logical forms before compilation, restores selected content and refuses unaccounted lexical content with diagnostic candidates preserved. No LLM rewrite, model selector or new media/training experiment. The optional callback keeps earlier default records identical.
- **Measured:**2,099 executable candidates remain;1,839 pass the new check,260 require review,276 earlier refusals remain;11 changed programs and228 passing checks. Fresh20 unchanged with9/5/2/4 assistant judgments. This is targeted repair and an omission audit, not general semantic improvement or an accuracy increase from refusal.
- **Next proposals/goals:** Recover useful coverage from recurrent alerts, handle structural failures missed by lexical coverage, and resolve references/profile cost. The compiler remains experimental; sentence rewriting remains reserved and unimplemented.


### ADR-023 content recovery priorities and demonstrations — 2026-11-05

- **User authorization:** Focus on recovering recurring omissions and repairing clause/source-label structure. Provide a page with simple demonstrations including earlier difficult cases. Defer reference resolution and larger-program profiling; a rewrite layer is only a possible future option. No rewriting authorized/implemented in this round.
- **Completed:** One deterministic SRL/dependency extension for declared patterns, explicit residual alerts and28 source-backed demos. Source word spans, original text, user ratings, historical snapshots and published ZIPs remain preserved. Optional hooks share existing compilation; no per-claim parser selection or new neural model.
- **Measured:**1,866/2,375 pass checks,2,103 executable candidates,35 newly pass/8 newly flagged,80 changed programs;259 checks. Fresh20 unchanged; no general semantic gain claimed. Printed rows certify OCR text without guessed column meanings; grammatical apposition is not hard-coded identity.
- **Next:** Keep next work bounded to the first two priorities; review residual alerts/structures. A future rewrite needs information-preservation and recompilation checks and is not presumed to solve inference complexity or every reference. ADR-023 remains unchanged.


### 2026-11-05 — Keep compiler progress on the demo page and maintain a daily log

- User authorized the next two steps: further omission recovery and explicit list/clause structure. Reference resolution, larger-program profiling and the possible LLM rewrite stay deferred. ADR-023 is unchanged.
- Keep updates on compiler-demos.html. Maintain its Daily log tab after future completed work: recent dates first, concise factual entries, and links opening the step, tab or example. Earlier backfilled entries are selected milestones from saved records, not invented daily activity. Keep proposals separate from completed results.
- Implemented one deterministic compiler extension with declared label/quantity/apposition/list and selected content-clause repairs; matching evidence functions remain required. No parser selector, new model/media inference, relation training or rewrite was introduced.


### 2026-11-11 — Metric definitions and proposed compiler-to-rewrite transition

- User authorized historical metric clarification, residual-alert review and an assessment of when to start rewriting before new DeepProbLog work. ADR-023 remains unchanged. This audit does not implement rewriting.
- Recommendation: freeze current broad grammar development as the comparison baseline now; make a small checked rewrite pilot the next implementation. Basic source/quote/type bug fixes remain separately measured maintenance. Remaining451 strict refusals are19.0%, and some automatic passes hide missing bindings. Do not call all remaining cases harmless outliers.
- The40-case pilot and its proposed fidelity/recovery gates are a reviewable plan, not measured results. Preserve false claims and source scope. Do not treat quantified absence, ambiguous antecedents or exact quotes as disposable wording. Training should follow reviewed original/rewrite/predicate triples.
- Maintain canonical daily entries in docs/project_notes/daily_log.json; old experiment log snapshots stay unchanged. A future go-ahead for the proposed pilot authorizes its implementation without asking the same question again.


###2026-11-11 —Authorized rewrite pilot completed; gates not met

- User's latest go-ahead authorizes implementation of the40-case checked rewrite pilot. ADR-023 remains unchanged. One model and one compiler; no sentence-specific parser/prompt selector. One prompt revision after inspecting initial proposals adds compiler diagnostics only; no truth labels/media or semantic reference judgments.
- Both prompts fail the agreed recovery/fidelity gates (1/24 then2/24 faithful targets; revised guard1; proposed control regressions2). Do not silently loosen gates or mix prompt successes to claim a stronger system. Freeze broad grammar rules and both prompts; automatic corpus-wide rewriting and relation training are not enabled.
- Recommendation, not a new finalized paper direction: review the three retained revised-prompt triples; consider bounded quantity/negation contracts or a separate stronger-rewriter evaluation. Preserve exact quotes/names, uncertain/false facts, scope and participant identity. Equivalent English negation still requires a correct logical quantifier scope.


###2026-11-12 —Rewrite only failed direct compilations

- Explicit user requirement: compile first and rewrite only strict unsupported results; a rejected diagnostic candidate is still a failure. Every compiled original bypasses the rewriter, including cases with separate semantic concerns. Historical passing probes do not authorize future exceptions.
- Enforced before model loading in the generation runner; the full-corpus replacement path already excluded direct passes. Exact requests, model/settings, raw responses and failure reasons must be inspectable. No new compilation grammar, prompt/model experiment or learning is authorized by this inspection task.


###2026-11-12 —Sentence splitting instead of single-sentence paraphrasing

- User clarified that the rewrite fallback should decompose difficult sentences into simpler meaning-preserving subclaims, for example image/Trump and Trump/holding, rather than return a single paraphrase. Accepted as the intended fallback formulation; ADR-023 remains unchanged. Passing originals still bypass rewriting.
- A separate adapter composes shared participants and context links using existing logical-form operators. The direct38-file compiler is frozen. Text splitting is established NLP prior work, not the paper's novelty.
- Bounded experiment completed: automatic Qwen65/77 clause passes,20/31 all-component passes,0 reviewed complete recoveries. Seven selected assistant-written splits give4 faithful linked results and18/18 passing clauses; one additional absence guard is refused. No automatic scale-up/new relation training. Proposed next: separate sentence generation from reference alignment and repeat a fixed fidelity review.


###2026-11-12 —Sentence generation and reference alignment evaluated separately

- User authorized the proposed separation and fixed evaluation, plus a full2300+ claim pass rate. One sentences-only Qwen prompt generates no logical IDs/links; a separate module uses original unique noun/event mentions. Passing originals bypass the model. ADR-023 unchanged.
- Fixed31-case automatic comparisons: old sentences/new alignment and new sentences/new alignment each recover2, with different cases. Corpus substitution uses only the new fixed condition's exact reviewed2 outputs; no manual clauses or per-claim prompt selector.
- Full2375 original census remains1924 checks/2103 candidates; including the2 reviewed automatic splits gives1926 checks/2105 candidates. Compilation coverage is not semantic accuracy; automatic scale-up/new learning remains deferred.


###2026-11-12 —Consolidate current reports and qualify rewrite coverage

- Explicit user preference: fewer report pages/tabs and fewer interim progress updates. Current report stays compiler-demos.html with five views; earlier URLs/inspectors/archives remain valid under History. Reports index reduced to two main entries. No new HTML report page.
- Explain449 failures using full-corpus first-check diagnostics while separating29 tested failures from420 untested claims. The31-case rewrite pilot is deliberately selected, not a recovery-rate estimate for the whole19%. No model/compiler change or new experiment.


### ADR-023 follow-up: Full rejected-cohort compilation —2026-11-12

- User authorized repair of role/identifier restrictions, measurement/absence semantics and all449 previous rejects. Earlier31-case scale restrictions are superseded for this completed experiment; failure-only rewriting, frozen perception and ADR-023 are unchanged.
- Opt-in functions extend five core files while exact2375 default-output equality protects earlier behavior. Preserve the old source snapshot, not a false claim of unchanged current hashes. Bounded NOT EXISTS with completeness-sensitive unknown is the absence contract; arbitrary negation/propositional holders stay refused.
- Retain previous1926rows and only27 hash-bound reviewed additions (1953/2375=82.23%). Do not promote all84automatic programs or mix excluded attempt/prompts. Compiler-author development review is not independent gold.
- Proposed next work prioritizes original operator/source scope and participant reference resolution using cached419responses. New empirical relation training/media evaluation remains deferred. Report continues in existing Overview/Examples; prior URLs and archives preserved.
