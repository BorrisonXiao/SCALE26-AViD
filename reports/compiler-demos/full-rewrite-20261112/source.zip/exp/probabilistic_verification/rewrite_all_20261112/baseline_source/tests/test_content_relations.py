"""Meaning requirements for the new repairs, including adverse controls."""
import copy,json
from pathlib import Path
import pytest
from probabilistic_verification.content_relations import compile_content_relations, recover_identifiers, recover_quantities, recover_locative_clause, recover_nominal_descriptions
from probabilistic_verification.content_recovery import compile_content_recovery
from probabilistic_verification.scoped_srl import SourceSyntax
from probabilistic_verification.balanced_logic import BalancedVerifier
from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground
from test_scoped_srl import constructed_record

ROOT=Path(__file__).resolve().parents[1]
RECORDS={r['claim_id']:r for r in map(json.loads,(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl').read_text().splitlines())}
def case(suffix):return compile_content_relations(next(r for c,r in RECORDS.items() if c.endswith(suffix)))[0]

@pytest.mark.parametrize('suffix,expected',[('_315',{'2'}),('_385',{'1','2'}),('_1124',{'1'}),('_1396',{'1'})])
def test_labels_retain_identifiers_instead_of_turning_them_into_counts(suffix,expected):
    c=case(suffix);es=c.metadata['entities'].values()
    assert expected<={p['value']for e in es for p in e.get('properties',[])if p['role']=='identifier'}
    assert not any(e.get('quantity') for e in es)

def test_wrongly_attached_number_does_not_become_a_robot_identifier():
    c,_=compile_content_relations(RECORDS['Tg0UxWYuPeJ0_378'],strict=False)
    assert any(t['text']=='three' for t in c.metadata['content_coverage']['missing'])
    assert not any(p==dict(role='identifier',value='three') for e in c.metadata['entities'].values() for p in e.get('properties',[]))

@pytest.mark.parametrize('suffix',['_482','_974'])
def test_a_date_or_party_tally_does_not_gain_an_identifier(suffix):
    c=case(suffix)
    assert not any(p['role']=='identifier'for e in c.metadata['entities'].values()for p in e.get('properties',[]))

def test_count_before_a_noun_does_not_become_an_identifier():
    r=constructed_record('Two robots walk.',[('Two','two','NUM',2,'nummod'),('robots','robot','NOUN',3,'nsubj'),('walk','walk','VERB',0,'root'),('.','.','PUNCT',3,'punct')],[(2,[('ARG0',0,1)])])
    c,_=compile_content_relations(r)
    assert any(e.get('quantity',{}).get('value')=='Two'for e in c.metadata['entities'].values())
    assert not any(p['role']=='identifier'for e in c.metadata['entities'].values()for p in e.get('properties',[]))

def test_compound_cardinality_keeps_multiplier_and_scale():
    c=case('_1042')
    assert any(e.get('quantity')==dict(operator='exact',value='1.2 million')for e in c.metadata['entities'].values())

def test_approximate_scaled_distance_is_a_measurement():
    c=case('_1145');e=next(e for e in c.metadata['events'].values()if e['predicate']=='travel')
    assert e['arguments']['ARG1']==dict(kind='measurement',value='roughly 2.8 million',unit='miles')
    assert not any(e.get('quantity')for e in c.metadata['entities'].values())

def test_money_is_an_amount_rather_than_a_group_of_currency_objects():
    c=case('_2040');e=next(e for e in c.metadata['entities'].values()if e['text']=='RMB')
    assert not e.get('quantity') and dict(role='amount',value='100 million')in e['properties']

@pytest.mark.parametrize('suffix,lower,upper',[('_165','67','75'),('_2369','2','3')])
def test_explicit_count_range_has_both_bounds(suffix,lower,upper):
    c=case(suffix);e=next(e for e in c.metadata['entities'].values()if any(p['role']=='minimum_count'for p in e.get('properties',[])))
    assert dict(role='minimum_count',value=lower)in e['properties'] and dict(role='maximum_count',value=upper)in e['properties']
    assert not e.get('quantity')

def test_duration_range_stays_under_prediction_scope():
    c=case('_2346');e=next(e for e in c.metadata['events'].values()if e['predicate']=='last')
    assert e['arguments']['ARG2']==dict(kind='duration',value='two to three',unit='days')
    assert c.metadata['scopes'][e['scope']]['kind']=='prediction'

def test_simple_and_is_not_reinterpreted_as_a_range():
    r=constructed_record('Two and three boxes spill.',[('Two','two','NUM',4,'nummod'),('and','and','CCONJ',3,'cc'),('three','three','NUM',1,'conj'),('boxes','box','NOUN',5,'nsubj'),('spill','spill','VERB',0,'root'),('.','.','PUNCT',5,'punct')],[])
    form=dict(entities=[dict(id='x4',text='boxes',quantity=dict(operator='exact',value='Two'))],formula=dict(op='entity',ref='x4'))
    recover_quantities(r,form,[])
    assert form['entities'][0]['quantity']['value']=='Two'

def test_an_appositive_alternative_does_not_become_an_and_group():
    r=constructed_record('Alice, a cat or dog, sleeps.',[('Alice','Alice','PROPN',8,'nsubj'),(',',',','PUNCT',4,'punct'),
        ('a','a','DET',4,'det'),('cat','cat','NOUN',1,'appos'),('or','or','CCONJ',6,'cc'),
        ('dog','dog','NOUN',4,'conj'),(',',',','PUNCT',1,'punct'),('sleeps','sleep','VERB',0,'root'),('.','.','PUNCT',8,'punct')],[])
    form=dict(entities=[dict(id='x1',text='Alice',type='entity')],formula=dict(op='entity',ref='x1'))
    recover_nominal_descriptions(r,form,[])
    assert form['entities']==[dict(id='x1',text='Alice',type='entity')]

@pytest.mark.parametrize('suffix,phrase',[('_1220','cone'),('_851','leader'),('_1416','LISTER'),('_1769','publisher')])
def test_apposition_keeps_a_separate_description_with_its_local_modifiers(suffix,phrase):
    c=case(suffix);es={e['id']:e for e in c.metadata['entities'].values()}
    assert any(r['role']=='appos'and phrase in es[r['target']]['text']for e in es.values()for r in e.get('relations',[]))

@pytest.mark.parametrize('suffix',['_863','_1722'])
def test_lists_have_six_named_people_with_local_parties_and_a_shared_title(suffix):
    c=case(suffix);es={e['id']:e for e in c.metadata['entities'].values()}
    expected={'Mark Carney','Pierre Poilievre','Jagmeet Singh','Yves-François Blanchet','Elizabeth May','Jonathan Pedneault'}
    assert expected<={e['text']for e in es.values()}
    for person,party in [('Mark Carney','Liberals'),('Pierre Poilievre','Conservatives'),('Jagmeet Singh','NDP'),('Yves-François Blanchet','Bloc Québécois')]:
        e=next(e for e in es.values()if e['text']==person)
        assert any(r['role']=='of'and es[r['target']]['text']==party for r in e['relations'])
    title=next(e for e in es.values()if e['text']=='co-leaders')
    assert {es[r['target']]['text']for r in title['relations']if r['role']=='member'}=={'Elizabeth May','Jonathan Pedneault'}
    assert dict(role='mod',value='Green Party')in title['properties']
    assert c.metadata['requires_context'] # "They/them" still need reference resolution.

def test_where_clause_binds_explicit_meeting_participants_to_the_fault():
    c=case('_1053');e=next(e for e in c.metadata['events'].values()if e['predicate']=='meet');es={e['id']:e for e in c.metadata['entities'].values()}
    assert es[e['arguments']['obl:at']]['text']=='Sagaing Fault'
    assert len([r for r in es[e['arguments']['nsubj']]['relations']if r['role']=='member'])==2
    assert not any(isinstance(v,dict)and 'meet'in v.get('value','')for v in e['arguments'].values())

def test_how_content_is_not_projected_to_the_world():
    c=case('_1868');e=next(e for e in c.metadata['events'].values()if e['predicate']=='change')
    assert e['scope']!='world' and c.metadata['scopes'][e['scope']]['kind']=='complement'
    assert not c.metadata['structural_alerts']

@pytest.mark.parametrize('suffix',['_496','_1230','_1676','_2068'])
def test_uncertain_clause_or_conditional_remains_explicitly_flagged(suffix):
    r=next(r for cid,r in RECORDS.items()if cid.endswith(suffix));c,_=compile_content_relations(r,strict=False)
    assert c.metadata['structural_alerts']

def test_input_is_unchanged_and_historical_default_keeps_its_output():
    r=copy.deepcopy(RECORDS['TQEmEycTI0RQ_863']);original=copy.deepcopy(r)
    before,_=compile_content_recovery(r,strict=False);compile_content_relations(r)
    after,_=compile_content_recovery(r,strict=False)
    assert r==original and before.to_dict()==after.to_dict()

@pytest.mark.parametrize('count,expected',[(70,'supported'),(80,'refuted'),(None,'unknown')])
def test_native_inference_requires_both_count_bounds(count,expected):
    c=case('_165');domains={v.name:[v.name.lower()]for v in c.variables};assignment={v:xs[0]for v,xs in domains.items()};obs={}
    for a in c.atoms:
        state='supported'
        if a.predicate=='property' and a.arguments[1] in {'minimum_count','maximum_count'}:
            role,value=a.arguments[1],int(a.arguments[2])
            state='unknown'if count is None else 'supported'if (count>=value if role=='minimum_count'else count<=value)else 'refuted'
        key=canonical_key('range-test',a,assignment,'visual_depiction')
        obs[key]=Observation(key,tuple(float(s==state)for s in ('supported','refuted','unknown')),False,a.text,{'source':'constructed group count'})
    evidence=Evidence('range-test',domains,{v:True for v in domains},obs,route='visual_depiction')
    result=BalancedVerifier([ground(c,evidence)],learned=False).predict()[0]['distribution']
    assert result[expected]>1-1e-9
