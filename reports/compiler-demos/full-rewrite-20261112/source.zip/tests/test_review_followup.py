"""Protect paired review statistics and the fresh sample's independence."""
import copy
import unittest

from analyze_claim_review import analyze
from prepare_review_followup import select_cases


def fixture():
    cases, answers, mapping = [], [], []
    for i in range(2):
        cid = f'synthetic-{i}'
        cases.append(dict(claim_id=cid, text='Synthetic test claim.', claim_sha256='test', outputs={
            l: dict(status='compiled', form=dict(kind='claim', formula=dict(op='event', predicate=l)), predicates=[l])
            for l in ('A', 'B')}))
        conditions = dict(A='baseline', B='revised') if i == 0 else dict(A='revised', B='baseline')
        mapping.append(dict(claim_id=cid, conditions=conditions))
        answers.append(dict(claim_id=cid, claim_sha256='test', readings_complete=True,
            intended_meaning='Synthetic test reading.', outputs={l: dict(
                judgment='partial' if conditions[l] == 'baseline' else 'faithful', reason='Synthetic test reason.', refusal_appropriate='')
                for l in ('A', 'B')}))
    packet = dict(packet_id='test', compiler_freeze='test', cases=cases)
    review = dict(packet_id='test', compiler_freeze='test', cases=answers)
    return review, packet, mapping


class ReviewAnalysisTests(unittest.TestCase):
    def test_per_case_randomization_is_unblinded(self):
        report = analyze(*fixture())
        self.assertEqual(report['paired_outcomes']['improved'], 2)
        self.assertEqual(report['counts_by_condition']['revised']['compiled']['faithful'], 2)

    def test_uncertainty_and_refusals_do_not_become_semantic_improvements(self):
        review, packet, mapping = fixture()
        review['cases'][0]['outputs']['A']['judgment'] = 'uncertain'
        packet['cases'][1]['outputs']['B'] = dict(status='unsupported', code='test', reason='Synthetic refusal.')
        review['cases'][1]['outputs']['B'].update(judgment='', refusal_appropriate='no')
        report = analyze(review, packet, mapping)
        self.assertEqual(report['definite_both_compiled_comparisons'], 0)
        self.assertEqual(report['paired_outcomes']['uncertain'], 1)
        self.assertEqual(report['paired_outcomes']['newly_compiled'], 1)
        self.assertEqual(report['counts_by_condition']['baseline']['refusal']['no'], 1)

    def test_conflicting_ratings_of_identical_outputs_need_resolution(self):
        review, packet, mapping = fixture()
        packet['cases'][0]['outputs']['B'] = copy.deepcopy(packet['cases'][0]['outputs']['A'])
        report = analyze(review, packet, mapping)
        self.assertEqual(report['paired_outcomes']['identical_outputs_disagreement'], 1)
        self.assertEqual(report['paired_outcomes']['improved'], 1)

    def test_unconfirmed_working_draft_is_not_counted(self):
        review, packet, mapping = fixture()
        for answer in review['cases']:
            answer['working_draft'] = copy.deepcopy(answer)
            answer['readings_complete'] = False
            answer['intended_meaning'] = ''
            answer['outputs'] = {l: dict(judgment='', refusal_appropriate='') for l in ('A', 'B')}
        report = analyze(review, packet, mapping)
        self.assertEqual(report['received_readings'], 0)
        self.assertEqual(report['complete_comparisons'], 0)
        self.assertEqual(report['failure_ledger'], [])

    def test_agent_draft_cannot_be_submitted_as_human_review(self):
        review, packet, mapping = fixture()
        review['reviewer_type'] = 'independent_agent_draft'
        with self.assertRaisesRegex(ValueError, 'not human reviews'):
            analyze(review, packet, mapping)


class FreshSampleTests(unittest.TestCase):
    def test_source_and_text_exclusions_are_deterministic(self):
        def record(cid, text, source):
            return dict(claim_id=cid, text=text, source_videos=[source])
        records = [record('old', 'Existing claim', 'old-source'),
                   record('old-copy', ' existing CLAIM ', 'different-source'),
                   record('old-source-copy', 'Other claim', 'old-source'),
                   record('a', 'New claim A', 'new-a'), record('a-copy', 'New claim A', 'new-a'),
                   record('b', 'New claim B', 'new-b'), record('c', 'New claim C', 'new-c')]
        selected, eligible = select_cases(records, {'old'}, {'old-source'}, count=2)
        again, _ = select_cases(list(reversed(records)), {'old'}, {'old-source'}, count=2)
        self.assertEqual([r['claim_id'] for r in selected], [r['claim_id'] for r in again])
        self.assertEqual(eligible, 4)
        self.assertEqual(len({r['source_videos'][0] for r in selected}), 2)
        self.assertFalse({r['claim_id'] for r in selected} & {'old', 'old-copy', 'old-source-copy'})
        with self.assertRaisesRegex(ValueError, 'requested 5'):
            select_cases(records, {'old'}, {'old-source'}, count=5)


if __name__ == '__main__':
    unittest.main()
