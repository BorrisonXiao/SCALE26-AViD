"""Semantic contracts for bounded role, measurement and absence extensions."""
import copy,json
from pathlib import Path
import pytest
from probabilistic_verification.compiler_extensions import compile_one,compile_extended_relations
from probabilistic_verification.typed_literals import measurement_literal
from probabilistic_verification.logic import Evidence,ground
from probabilistic_verification.direct_backend import DirectVerifier

ROOT=Path(__file__).resolve().parents[1]
RECORDS={r['claim_id']:r for r in map(json.loads,(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl').read_text().splitlines())}


@pytest.mark.parametrize('text,unit,operator',[('20-25 km/h','km/h','range'),('20 to 25 kilometers per hour','km/h','range'),('at a speed of 20-25 km/h','km/h','range'),('149.0 mm','mm','exact'),('about 40 meters/second','m/s','approx'),('a magnitude of 7.7','','exact')])
def test_complete_measurement_phrases(text,unit,operator):
    value=measurement_literal(text)
    assert value['unit']==unit and value['operator']==operator


@pytest.mark.parametrize('text',['four robots','20 km and a robot','25-20 km/h','approximately 20-25 km/h','a building housing a publisher'])
def test_counts_and_unresolved_measurements_are_not_silently_coerced(text):
    assert measurement_literal(text)is None


def test_two_direction_entities_remain_on_one_driving_event():
    row=compile_one(RECORDS['TbJqMFkNxARY_132']);assert row['status']=='compiled'
    claim=row['compilation'];event=next(e for e in claim['metadata']['events'].values()if e['predicate']=='drive')
    assert len(event['adjuncts'])==1 and event['adjuncts'][0]['preposition']=='towards'
    assert any(a['predicate']=='adjunct'for a in claim['atoms'])
    assert sum(e['predicate']=='drive'for e in claim['metadata']['events'].values())==1


def test_storm_range_is_a_measurement_not_a_kilometer_group():
    row=compile_one(RECORDS['Txf2EdqOg1SQ_2350']);assert row['status']=='compiled'
    event=next(e for e in row['compilation']['metadata']['events'].values()if e['predicate']=='move')
    value=event['arguments']['ARGM-MNR'];assert(value['lower'],value['upper'],value['unit'])==('20','25','km/h')
    assert not any(a['predicate']=='group_quantity'for a in row['compilation']['atoms'])


def test_four_robots_and_100m_dash_keep_different_quantities():
    row=compile_one(RECORDS['Tg0UxWYuPeJ0_417']);assert row['status']=='compiled'
    entities=list(row['compilation']['metadata']['entities'].values())
    robots=next(e for e in entities if e['text']=='robots');dash=next(e for e in entities if e['text']=='dash')
    assert robots['quantity']['value']=='Four' and not dash.get('quantity')
    assert any(p['role']=='measurement'for p in dash['properties'])


def test_audio_entity_and_event_are_both_inside_negative_existential():
    claim,_=compile_extended_relations(RECORDS['TgR_u37mCoQ4_1901'])
    neg=claim.metadata['negative_existentials'][0]
    audio=next(k for k,e in claim.metadata['entities'].items()if e['text']=='audio')
    video=next(k for k,e in claim.metadata['entities'].items()if e['text']=='video')
    assert audio in neg['variables'] and video not in neg['variables']
    assert any(v.startswith('E')for v in neg['variables'])
    assert 'NOT (EXISTS'in claim.expression.display({a.id:a for a in claim.atoms})


@pytest.mark.parametrize('empty,complete,expected',[(True,True,'supported'),(True,False,'unknown'),(False,True,'refuted')])
def test_audio_inventory_controls_negative_existential(empty,complete,expected):
    claim,_=compile_extended_relations(RECORDS['TgR_u37mCoQ4_1901'])
    audio=next(k for k,e in claim.metadata['entities'].items()if e['text']=='audio')
    domains={v.name:[v.name.lower()]for v in claim.variables}
    if empty:domains[audio]=[]
    evidence=Evidence('absence-test',domains,{v.name:(complete if v.name==audio else True)for v in claim.variables},{})
    # The positive video referent is unknown without an observation. Supply all
    # non-audio observations as supported, then inspect exact inference.
    from probabilistic_verification.logic import Observation,canonical_key
    import itertools
    for atom in claim.atoms:
        names=[v.name for v in claim.variables if v.name in atom.arguments]
        for values in itertools.product(*(domains[n]for n in names)):
            assignment=dict(zip(names,values));key=canonical_key(evidence.media_id,atom,assignment,evidence.route)
            evidence.observations[key]=Observation(key,(1.,0.,0.),False,'controlled')
    result=DirectVerifier([ground(claim,evidence)],learned=False).predict()[0]['distribution']
    assert max(result,key=result.get)==expected


def test_extension_does_not_mutate_cached_annotations():
    record=copy.deepcopy(RECORDS['TbJqMFkNxARY_132']);before=copy.deepcopy(record)
    compile_one(record);assert record==before


def test_negative_antecedent_does_not_negate_the_whole_implication():
    row=compile_one(RECORDS['TbJqMFkNxARY_161'])
    assert row['status']=='unsupported' and row['code']=='negative_quantifier'


def test_identifiers_disambiguate_two_robots_without_merging_them():
    from test_scoped_srl import constructed_record
    from probabilistic_verification.logical_form_v2 import ScopedCompiler
    from probabilistic_verification.split_alignment import compose_aligned
    rows={};clauses=[]
    for cid,number in [('c1','1'),('c2','2')]:
        text='Robot '+number+' moves.'
        r=constructed_record(text,[('Robot','robot','NOUN',3,'nsubj'),(number,number,'NUM',1,'nummod'),('moves','move','VERB',0,'root'),('.','.','PUNCT',3,'punct')],[])
        form=dict(version='logical-form-v2',kind='claim',entities=[dict(id='x1',text='Robot '+number,properties=[dict(role='identifier',value=number)])],formula=dict(op='event',id='e3',predicate='move',anchor='moves',arguments=dict(ARG0='x1')))
        c=ScopedCompiler().compile(cid,text,r['tokens'],form);rows[cid]=dict(status='compiled',compilation=c.to_dict());clauses.append(dict(id=cid,text=text))
    text='Robot 1 moves and Robot 2 moves.'
    original=constructed_record(text,[('Robot','robot','NOUN',3,'nsubj'),('1','1','NUM',1,'nummod'),('moves','move','VERB',0,'root'),('and','and','CCONJ',7,'cc'),('Robot','robot','NOUN',7,'nsubj'),('2','2','NUM',5,'nummod'),('moves','move','VERB',3,'conj'),('.','.','PUNCT',3,'punct')],[])
    original['compiler_options']=dict(participant_identifiers=True)
    claim,_,trace=compose_aligned('id-test',original,clauses,rows)
    assert len(trace['entities'])==2 and len(claim.metadata['entities'])==2
    assert {p['value']for e in claim.metadata['entities'].values()for p in e.get('properties',[])if p['role']=='identifier'}=={'1','2'}


def test_longer_split_limit_is_explicit_and_default_is_preserved():
    from test_claim_split import proposal
    from probabilistic_verification.claim_split import validate_split
    p=proposal()
    for i in range(3,10):p['clauses'].append(dict(id=f'c{i}',text='Alice holds a cup.',parent='c1',relation='and',target=''))
    with pytest.raises(Exception):validate_split(p)
    validate_split(p,max_clauses=12)


def test_atomic_rewrite_is_allowed_without_forcing_duplicate_subclaims():
    from probabilistic_verification.full_rewrite import proposal
    p=proposal(dict(action='rewrite',sentences=['A robot runs.']))
    assert p['action']=='rewrite' and len(p['clauses'])==1


@pytest.mark.parametrize('data',[dict(action='rewrite',sentences=[]),dict(action='keep',sentences=['A robot runs.']),dict(action='refuse',sentences=['A robot runs.'])])
def test_model_actions_cannot_silently_add_or_remove_claims(data):
    from probabilistic_verification.full_rewrite import proposal
    with pytest.raises(ValueError):proposal(data)


def test_clip_and_map_are_sources_but_broadcast_livestream_is_an_object():
    from probabilistic_verification.split_alignment import is_source_mention
    tokens=[dict(id=1,text='clip',lemma='clip',upos='NOUN',head=2,deprel='nsubj'),dict(id=2,text='shows',lemma='show',upos='VERB',head=0,deprel='root')]
    assert is_source_mention(tokens[0],tokens)
    tokens[0].update(text='map',lemma='map');assert is_source_mention(tokens[0],tokens)
    tokens[0].update(text='livestream',lemma='livestream',deprel='obj');tokens[1].update(text='broadcasting',lemma='broadcast')
    assert not is_source_mention(tokens[0],tokens)
