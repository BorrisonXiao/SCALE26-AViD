"""Original-mention alignment invariants, independent of the 31-case outputs."""
import copy
import pytest
from probabilistic_verification.split_alignment import align,compose_aligned,head_for
from probabilistic_verification.split_composition import CompositionError
from probabilistic_verification.sentence_simplification import to_proposal
from test_claim_split import components,proposal


def original():
    rows=components()
    # Use a single original photo / Alice / cup with distinct token positions.
    tokens=list(copy.deepcopy(rows['c1']['compilation']['tokens']))
    tokens.extend(dict(t,id=t['id']+5,head=t['head']+5 if t['head']else 0)for t in rows['c2']['compilation']['tokens']if t['text']!='Alice')
    return dict(text='A photo depicts Alice holding a blue cup.',tokens=tokens)


def test_original_unique_mentions_replace_model_identity_groups():
    p,_,trace,_=align(original(),proposal()['clauses'],components())
    assert len(p['shared'])==1
    assert all(m['text']=='Alice'for m in p['shared'][0]['mentions'])
    assert len({e['original_token']for e in trace['entities']})==3


def test_aligned_content_keeps_photo_context():
    c,_,_=compose_aligned('test',original(),proposal()['clauses'],components())
    assert next(e for e in c.metadata['events'].values()if e['predicate']=='hold')['route']=='visual_depiction'


def test_ambiguous_same_name_is_not_guessed():
    r=original();r['tokens'].append(dict(r['tokens'][3],id=100))
    with pytest.raises(CompositionError,match='ambiguous'):align(r,proposal()['clauses'],components())


def test_absent_noun_is_not_mapped_to_nearest_entity():
    r=original();r['tokens']=[t for t in r['tokens']if t['text']!='cup']
    with pytest.raises(CompositionError,match='absent'):align(r,proposal()['clauses'],components())


def test_source_cannot_be_discarded():
    rows=components();rows['c1']['compilation']['metadata']['logical_form']['formula']['predicate']='hold'
    with pytest.raises(CompositionError,match='source sentence'):align(original(),proposal()['clauses'],rows)


def test_generation_has_no_identity_or_context_fields():
    data=dict(action='split',sentences=['A photo depicts Alice.','Alice holds a blue cup.'])
    assert to_proposal(data)['shared']==[]
    data['shared']=[]
    with pytest.raises(Exception):to_proposal(data)


def test_one_sentence_cannot_be_labeled_split():
    with pytest.raises(ValueError):to_proposal(dict(action='split',sentences=['Alice holds a cup.']))


def test_name_span_uses_dependency_head():
    tokens=[dict(id=1,text='New',upos='PROPN',head=2),dict(id=2,text='York',upos='PROPN',head=3),dict(id=3,text='City',upos='PROPN',head=4)]
    assert head_for(dict(id='place',text='New York City'),tokens)['id']==3


def test_repeated_event_conditions_share_original_event():
    part=components()['c2'];rows={'c1':copy.deepcopy(part),'c2':copy.deepcopy(part)}
    clauses=[dict(id=c,text=part['compilation']['text'])for c in rows]
    source=dict(text=part['compilation']['text'],tokens=part['compilation']['tokens'])
    claim,_,trace=compose_aligned('test',source,clauses,rows)
    assert len(claim.metadata['events'])==1
    assert len(trace['event_merges'])==1


def test_repeated_event_does_not_drop_original_tense():
    part=components()['c2'];rows={'c1':copy.deepcopy(part),'c2':copy.deepcopy(part)}
    clauses=[dict(id=c,text=part['compilation']['text'])for c in rows]
    tokens=list(copy.deepcopy(part['compilation']['tokens']))
    next(t for t in tokens if t['text']=='holds')['feats']='Tense=Pres|VerbForm=Fin'
    with pytest.raises(CompositionError,match='tense'):
        compose_aligned('test',dict(text=part['compilation']['text'],tokens=tokens),clauses,rows)
