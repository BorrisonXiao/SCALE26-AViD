/* Render only the saved logical form and compiler metadata, never the claim or review. */
window.ClaimOutputView = (() => {
  const esc = value => String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
  const roles = {nsubj:'Subject',obj:'Object',iobj:'Indirect object',obl:'Oblique complement',
    'ARGM-LOC':'Location','ARGM-TMP':'Time','ARGM-MNR':'Manner','ARGM-CAU':'Cause',
    'ARGM-PRP':'Purpose','ARGM-DIR':'Direction','ARGM-EXT':'Extent',
    mod:'Modifier',member:'Group member',of:'of',in:'in',about:'about',particle:'Verb particle',
    quantifier:'Quantifier',source_route:'Evidence source',acl:'Attached clause',amod:'Adjectival modifier',content:'Content'};
  const routes = {visual_depiction:'Visual depiction',audio_event:'Sound',speech_assertion:'Speech',
    ocr_assertion:'On-screen text (OCR)',unspecified:'Source not specified'};
  const kinds = {complement:'Complement clause',relative:'Attached description',depiction:'Depicted content',
    assertion:'Source assertion',question:'Question content',reason:'Reason',purpose:'Purpose',
    belief:'Belief content',condition:'Condition',temporal:'Time condition',sufficiency:'Sufficient for the following goal'};
  const human = value => String(value ?? '').replaceAll('_',' ');
  function role(value){
    const name = roles[value] || (/^ARG\d+$/.test(value) ? 'Participant '+value.slice(3) : human(value));
    return esc(name) + (name !== value ? ' <small class="cv-code">'+esc(value)+'</small>' : '');
  }
  function valueText(value){
    if(value === null || value === undefined)return 'Not specified';
    if(typeof value !== 'object')return String(value);
    if(Array.isArray(value))return value.map(valueText).join(', ');
    return Object.entries(value).map(([k,v])=>human(k)+': '+valueText(v)).join('; ');
  }
  function literal(value){
    if(typeof value !== 'object' || value === null)return esc(value);
    if(value.kind==='measurement'){
      const amount=value.operator==='range'?valueText(value.lower)+'–'+valueText(value.upper):valueText(value.value);
      const qualifier=value.operator&&!['range','exact'].includes(value.operator)?human(value.operator)+' ':'';
      return '<span class="cv-literal"><small>Measurement'+(value.attribute?' · '+esc(value.attribute):'')+'</small>'+esc(qualifier+amount+(value.unit?' '+value.unit:''))+'</span>';
    }
    const labels={verbatim_text:'Exact text',text:'Text',time:'Time expression',measurement:'Measurement'};
    const content=value.kind==='verbatim_text'?'“'+valueText(value.value)+'”':valueText(value.value);
    const extras=Object.entries(value).filter(([k])=>!['kind','value'].includes(k)).map(([k,v])=>human(k)+': '+valueText(v));
    return '<span class="cv-literal"><small>'+esc(labels[value.kind]||human(value.kind||'Value'))+'</small> '+esc(content)+(extras.length?' <span>'+esc(extras.join('; '))+'</span>':'')+'</span>';
  }
  function row(label,body){return '<div class="cv-row"><div class="cv-edge">'+label+'</div><div class="cv-target">'+body+'</div></div>';}
  function timeDescription(t){
    if(!t)return '';
    const tense={pres:'present tense',past:'past tense',fut:'future tense',unspecified:'tense not specified'}[t.tense]||human(t.tense);
    const aspect={simple:'simple aspect',progressive:'progressive aspect (ongoing)',perfect:'perfect aspect',perfect_progressive:'perfect progressive aspect',unspecified:'aspect not specified'}[t.aspect]||human(t.aspect);
    return [tense,aspect,t.completion && t.completion!=='unspecified'?'completion: '+human(t.completion):''].filter(Boolean).join(' · ');
  }
  function render(output,metadata={},number=1){
    if(output.status!=='compiled')return '<figure class="cv-figure"><div class="cv-refusal"><b>No compiled output</b><p>'+esc(output.reason||output.code||'No reason recorded.')+'</p></div><figcaption>Figure '+number+'. This version refused compilation.</figcaption></figure>';
    const form=output.form, entities=Object.fromEntries((form?.entities||[]).map(e=>[e.id,e]));
    const seen=new Set();
    const metaEvents=Object.entries(metadata.events||{});
    const eventInfo=node=>metaEvents.filter(([,e])=>e.id===node.id&&e.predicate===node.predicate);
    function properties(items){
      return (items||[]).map(p=>{if(p.role==='measurement'){try{return row('Measurement',literal(JSON.parse(p.value)));}catch(e){}}return row(role(p.role),esc(p.role==='source_route'?(routes[p.value]||human(p.value)):valueText(p.value)));}).join('');
    }
    function entity(id){
      const e=entities[id];
      if(!e)return '<span class="cv-unresolved">Unresolved reference: '+esc(id)+'</span>';
      const repeated=seen.has(id);seen.add(id);
      let html='<div class="cv-node cv-entity" data-entity="'+esc(id)+'"><div class="cv-node-title"><span class="cv-kind">'+(e.type==='group'?'Group':'Entity')+'</span> <b>'+esc(e.text)+'</b> <small class="cv-code">'+esc(id)+'</small></div>';
      if(repeated)return html+'<p class="cv-repeated">Same participant as above.</p></div>';
      html+=properties(e.properties);
      if(e.quantity)html+=row('Quantity',esc(human(e.quantity.operator)+' '+valueText(e.quantity.value)));
      for(const r of e.relations||[])html+=row(role(r.role),entity(r.target));
      for(const p of e.propositions||[])html+=proposition(p);
      return html+'</div>';
    }
    function proposition(p){
      return '<div class="cv-scope"><div class="cv-scope-title"><b>'+esc(kinds[p.kind]||human(p.kind))+'</b> <small>'+role(p.role)+'</small></div><p class="cv-source">'+esc(routes[p.route]||human(p.route||'unspecified'))+'</p>'+node(p.body)+'</div>';
    }
    function node(n){
      if(!n)return '<p>No formula saved.</p>';
      if(n.op==='entity')return entity(n.ref);
      if(n.op==='and'||n.op==='or')return '<div class="cv-scope"><b>'+(n.op==='and'?'All of the following (AND)':'At least one alternative (OR)')+'</b>'+n.children.map(node).join('')+'</div>';
      if(n.op==='not')return '<div class="cv-scope"><b>Negation (NOT)</b>'+node(n.child)+'</div>';
      if(n.op==='not_exists')return '<div class="cv-scope"><b>No matching entity/event exists (NOT EXISTS)</b><p class="cv-source">'+esc(routes[n.route]||human(n.route||'unspecified'))+'</p>'+node(n.body)+'</div>';
      if(n.op==='qualified')return '<div class="cv-scope"><b>Condition: '+esc(human(n.operator))+'</b>'+node(n.body)+'</div>';
      if(n.op!=='event')return '<p>Unrecognized node: '+esc(valueText(n))+'</p>';
      const infos=eventInfo(n), info=infos.length===1?infos[0]:null;
      const particles=(n.properties||[]).filter(p=>p.role==='particle').map(p=>p.value);
      let html='<div class="cv-node cv-event" data-event="'+esc(n.id)+'"><div class="cv-node-title"><span class="cv-kind">Event / state</span> <b>'+esc([n.predicate,...particles].join(' '))+'</b> <small class="cv-code">'+esc(n.id)+'</small></div>';
      if(info){
        const [compiledId,data]=info;
        const time=timeDescription(metadata.temporal?.[compiledId]);
        if(time)html+='<p class="cv-time">'+esc(time)+'</p>';
        html+='<p class="cv-source">'+esc(routes[data.route]||human(data.route))+(data.scope==='world'?' · Main assertion':' · Nested content')+'</p>';
      }
      if(infos.length>1)html+='<div class="cv-context">This event appears in several compiled contexts.'+infos.map(([id,data])=>'<p>'+esc(id)+': '+esc(timeDescription(metadata.temporal?.[id]))+' · '+esc(routes[data.route]||human(data.route))+'</p>').join('')+'</div>';
      for(const [r,v] of Object.entries(n.arguments||{}))html+=row(role(r),typeof v==='string'?entity(v):literal(v));
      for(const a of n.adjuncts||[])html+=row(role(a.role)+(a.preposition?' · '+esc(a.preposition):''),typeof a.target==='string'?entity(a.target):literal(a.target));
      html+=properties(n.properties);
      for(const p of n.propositions||[])html+=proposition(p);
      return html+'</div>';
    }
    let graph=node(form?.formula);
    const unused=Object.keys(entities).filter(id=>!seen.has(id));
    if(unused.length)graph+='<details><summary>Declared entities outside this structure ('+unused.length+')</summary><p>These declarations have no link from the formula shown above.</p>'+unused.map(entity).join('')+'</details>';
    let html='<figure class="cv-figure"><p class="cv-output-kind">'+(form?.kind==='mention'?'Noun phrase description':'Claim structure')+'</p>'+graph;
    if(output.event_references?.length)html+='<div class="cv-context"><b>Shared event references</b>'+output.event_references.map(r=>'<p>'+esc(r.mention)+' and '+esc(r.event)+' refer to the same event ('+esc(r.variable)+').</p>').join('')+'</div>';
    if(output.runtime_requirements?.length)html+='<div class="cv-context"><b>Context still required</b><ul>'+output.runtime_requirements.map(r=>'<li>'+esc(human(r))+'</li>').join('')+'</ul></div>';
    return html+'<figcaption>Figure '+number+'. Saved compiler output. Indented boxes show attachment and source scope; repeated IDs identify the same participant or event.</figcaption></figure>';
  }
  function sameOutputs(a,b){
    if(a.status!==b.status)return false;
    if(a.status!=='compiled')return a.code===b.code&&a.reason===b.reason;
    const structure=o=>({kind:o.form?.kind,entities:o.form?.entities,formula:o.form?.formula,predicates:o.predicates,runtime:o.runtime_requirements});
    return JSON.stringify(structure(a))===JSON.stringify(structure(b));
  }
  return {render,sameOutputs,timeDescription};
})();
