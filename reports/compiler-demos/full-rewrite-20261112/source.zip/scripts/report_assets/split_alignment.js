(()=>{
 const $=id=>document.getElementById(id),esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
 const params=new URLSearchParams(location.search);let cases=[],current=params.get('alignment')||'TFgw4IaR9R8s_1587';
 function show(cid){
  const condition=$('alignment-condition').value,r=cases.find(x=>x.condition===condition&&x.claim_id===cid);if(!r)return;current=cid;$('alignment-case').value=cid;
  $('alignment-original').textContent=r.original;
  $('alignment-clauses').innerHTML=r.clauses.map(c=>{const p=r.component_statuses.find(x=>x.id===c.id);return '<li><b>'+esc(c.id)+':</b> '+esc(c.text)+'<p class="muted">'+esc(p?.status==='compiled'?'Passes component checks':p?.reason||'Not compiled')+'</p></li>';}).join('');
  let links='';
  if(r.alignment){
   links='<ul>'+r.alignment.entities.map(e=>'<li>Original token '+esc(e.original_token)+' (“'+esc(e.original_text)+'”): '+e.mentions.map(m=>esc(m.clause+'/'+m.entity+' “'+m.text+'”')).join(' = ')+'</li>').join('')+'</ul>';
   links+='<p>Event matches: '+r.alignment.events.map(e=>esc(e.clause+'/'+e.event+' '+e.predicate+' → '+(e.original_token?'original token '+e.original_token:'no unique original event'))).join('; ')+'</p>';
   links+='<ul>'+r.proposal.clauses.map(c=>'<li>'+esc(c.id+': '+c.relation+(c.parent?' under '+c.parent:'')+(c.target?' through '+c.target:''))+'</li>').join('')+'</ul>';
  }else links='<p>'+esc(r.output.reason||'Alignment did not produce a complete program.')+'</p>';
  $('alignment-links').innerHTML=links;
  $('alignment-review').textContent=(r.review.faithful?'Approved as a faithful development recovery. ':'Not approved as a complete recovery. ')+r.review.reason;
  $('alignment-graph').innerHTML=ClaimOutputView.render(r.output,r.output.metadata,8)+(r.output.status==='compiled'?'<details><summary>Exact predicates and logical form</summary><pre>'+esc(r.output.predicates.join('\n'))+'</pre><pre>'+esc(JSON.stringify(r.output.form,null,2))+'</pre></details>':'');
  $('alignment-system').textContent=r.request.messages[0].content;$('alignment-user').textContent=r.request.messages[1].content;$('alignment-response').textContent=r.request.raw;
  const u=new URL(location.href);u.searchParams.set('alignment',cid);u.searchParams.set('alignment_condition',condition);u.hash='alignment-example';$('alignment-share').href=u.pathname+u.search+u.hash;
 }
 function condition(){const rows=cases.filter(x=>x.condition===$('alignment-condition').value);$('alignment-case').innerHTML=rows.map(r=>'<option value="'+esc(r.claim_id)+'">'+esc(r.claim_id+' · '+r.original.slice(0,100))+'</option>').join('');show(rows.some(r=>r.claim_id===current)?current:rows[0].claim_id);}
 $('alignment-condition').addEventListener('change',()=>{condition();history.replaceState(null,'',new URL($('alignment-share').href));});$('alignment-case').addEventListener('change',e=>{show(e.target.value);history.replaceState(null,'',new URL($('alignment-share').href));});
 fetch('compiler-demos/alignment-20261112/cases.json').then(r=>r.json()).then(data=>{cases=data;$('alignment-condition').value=params.get('alignment_condition')==='old_sentences'?'old_sentences':'sentences';condition();}).catch(e=>{$('alignment-review').textContent=e.message;});
})();
