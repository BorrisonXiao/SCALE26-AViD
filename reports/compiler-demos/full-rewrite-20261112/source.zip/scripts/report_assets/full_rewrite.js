/* Show saved artifacts only; no inference or language-model requests in the browser. */
(()=>{
 const $=id=>document.getElementById(id),esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
 let cases=[],current=new URLSearchParams(location.search).get('rewrite_all')||'TbJqMFkNxARY_132';
 function graph(r,n){return ClaimOutputView.render(r,r.metadata||{},n);}
 function show(cid){
  const r=cases.find(x=>x.claim_id===cid);if(!r)return;current=cid;$('full-case').value=cid;
  $('full-id').textContent=cid+' · '+r.stage.replaceAll('_',' ');$('full-original').textContent=r.original;
  $('full-direct').textContent='Previous rejection: '+(r.previous_reason||r.previous_code)+'. Improved direct compiler: '+(r.direct.status==='compiled'?'passes automatic checks; model skipped.':(r.direct.reason||r.direct.code)+'. Fallback requested.');
  $('full-direct-graph').innerHTML=graph(r.direct,101);
  $('full-generation').textContent=r.request?(r.stage==='model_refuse'?'The model returned refuse and no sentences. The output schema does not request a refusal explanation; the exact response is below.':'Actual model response; '+r.components.length+' proposed sentence(s).'): 'No model request. The original passed direct compilation; it is never rewritten.';
  $('full-components').innerHTML=r.components.map(c=>'<article><p><b>'+esc(c.id)+'.</b> '+esc(c.text)+'</p><p>'+esc(c.output.status==='compiled'?'Passes component checks':c.output.reason||c.output.code)+'</p><details><summary>Saved component structure</summary>'+graph(c.output,102)+'</details></article>').join('');
  let links='';
  if(r.alignment){links='<ul>'+r.alignment.entities.map(e=>'<li>Original token '+esc(e.original_token)+' (“'+esc(e.original_text)+'”): '+e.mentions.map(m=>esc(m.clause+'/'+m.entity+' “'+m.text+'”')).join(' = ')+'</li>').join('')+'</ul>';
   links+='<p>Event matches: '+r.alignment.events.map(e=>esc(e.clause+'/'+e.event+' '+e.predicate+' → '+(e.original_token?'original token '+e.original_token:'no unique original event'))).join('; ')+'</p>';
   links+='<ul>'+(r.proposal?.clauses||[]).map(c=>'<li>'+esc(c.id+': '+c.relation+(c.parent?' under '+c.parent:'')+(c.target?' through '+c.target:''))+'</li>').join('')+'</ul>';
  }else links='<p>'+esc(r.stage==='direct_pass'?'No subclaim alignment needed.':r.output.reason||'No complete alignment was produced.')+'</p>';
  $('full-links').innerHTML=links;
  $('full-review').textContent=(r.review.faithful?'Approved addition. ':r.review.reviewed?'Program generated but not approved. ':'No complete program; first pipeline failure. ')+r.review.reason+(r.review.reviewed?' Compiler-author assistant judgment, not independent gold.':'');
  $('full-graph').innerHTML=graph(r.output,103);
  $('full-predicates').textContent=(r.output.predicates||[]).join('\n')||'No final predicates.';
  $('full-form').textContent=r.output.form?JSON.stringify(r.output.form,null,2):'No final logical form.';
  $('full-program').textContent=r.program||'No final program.';
  $('full-request').hidden=!r.request;
  $('full-model').textContent=r.request?'Frozen Qwen3-30B-A3B-Instruct-2507; temperature 0; seed 42; float16; maximum 3,072 output tokens.':'Skipped before model loading. No prompt or response exists for this case.';
  if(r.request){$('full-system').textContent=r.request.messages[0].content;$('full-user').textContent=r.request.messages[1].content;$('full-response').textContent=r.request.raw;}
  const u=new URL(location.href);u.searchParams.set('rewrite_all',cid);u.hash='full-rewrite-example';$('full-share').href=u.pathname+u.search+u.hash;
 }
 function filter(){
  const f=$('full-filter').value,q=$('full-search').value.toLowerCase();
  const rows=cases.filter(r=>(f==='all'||f==='faithful'&&r.review.faithful||f==='review_rejected'&&r.review.reviewed&&!r.review.faithful||r.stage===f)&&(r.claim_id+' '+r.original).toLowerCase().includes(q));
  $('full-count').textContent=rows.length+' of 449 cases';$('full-case').innerHTML=rows.map(r=>'<option value="'+esc(r.claim_id)+'">'+esc(r.claim_id+' · '+r.original.slice(0,115))+'</option>').join('');
  $('full-case').disabled=!rows.length;
  if(rows.length)show(rows.some(r=>r.claim_id===current)?current:rows[0].claim_id);
 }
 $('full-filter').addEventListener('change',filter);$('full-search').addEventListener('input',filter);
 $('full-case').addEventListener('change',e=>{show(e.target.value);history.replaceState(null,'',new URL($('full-share').href));});
 fetch('compiler-demos/full-rewrite-20261112/cases.json').then(r=>{if(!r.ok)throw Error('Could not load the 449 case records.');return r.json();}).then(data=>{cases=data;filter();}).catch(e=>{$('full-count').textContent=e.message;});
})();
