(()=>{
 const $=id=>document.getElementById(id);
 if(!$('review-case'))return;
 const labels={real_gap:'Apparent content or structure gap',overstrict_alert:'Likely overstrict word check',needs_context:'Needs context',
  faithful:'Faithful structure in this review',partial:'Partial structure in this review',rewrite_candidate:'Potential rewrite target',
  core_contract:'Basic source, quotation or typing issue',manual_or_unsupported:'Reference decision or unsupported meaning',
  binding_gap:'Identified binding or scope gap',needs_review:'Needs further review',not_clause_failure:'Not a hidden-clause failure'};
 let sets={},group='alerts',visible=[],current='';
 const verdict=r=>r.verdict||r.rating||r.recommendation;
 function show(id,save=false){
  const r=(sets[group]||[]).find(v=>v.claim_id===id);if(!r)return;current=id;$('review-case').value=id;
  $('review-id').textContent=id;$('review-claim').textContent=r.text;$('review-label').textContent=labels[verdict(r)]||verdict(r);
  $('review-missing').hidden=!r.missing;$('review-missing').textContent=r.missing?.length?'Flagged words: '+r.missing.join(', '):r.code==='opaque_clause'?'Flagged by the clause-structure check.':'';
  $('review-reason').textContent=r.review_reason||r.reason;$('review-other').hidden=!r.other_limit;$('review-other').textContent=r.other_limit||'';
  $('review-output-link').href='compiler-demos.html?claim='+encodeURIComponent(id)+'#outputs';
  if(save){const url=new URL(location.href);url.searchParams.delete('claim');url.searchParams.set('review',id);url.searchParams.set('review_group',group);url.hash='alert-review';history.replaceState(null,'',url);}
 }
 function filter(save=false){
  const set=sets[group]||[],v=$('review-verdict').value,q=$('review-search').value.toLowerCase();
  visible=set.filter(r=>(v==='all'||verdict(r)===v)&&(!q||(r.claim_id+' '+r.text+' '+(r.reason||'')+' '+(r.review_reason||'')).toLowerCase().includes(q)));
  $('review-count').textContent=visible.length+' of '+set.length+' reviewed cases';$('review-case').replaceChildren(...visible.map(r=>{const o=document.createElement('option');o.value=r.claim_id;o.textContent=r.claim_id+' · '+r.text.slice(0,110);return o;}));
  $('review-output-link').hidden=!visible.length;
  if(visible.length)show(visible.some(r=>r.claim_id===current)?current:visible[0].claim_id,save);
  else{$('review-claim').textContent='No matching cases';$('review-id').textContent='';$('review-label').textContent='';$('review-reason').textContent='';$('review-missing').textContent='';$('review-other').hidden=true;}
 }
 function chooseGroup(key,save=false){group=key;$('review-group').value=key;$('review-search').value='';const values=[...new Set((sets[key]||[]).map(verdict))].sort();$('review-verdict').replaceChildren(...['all',...values].map(v=>{const o=document.createElement('option');o.value=v;o.textContent=v==='all'?'All judgments':labels[v]||v;return o;}));filter(save);}
 Promise.all([fetch('compiler-demos/alert-review-20261111/review_annotations.json').then(r=>r.json()),fetch('compiler-demos/alert-review-20261111/passing_clause_review.json').then(r=>r.json())]).then(([a,c])=>{
  sets={alerts:a.alerts,refusals:a.refusals,passing_controls:a.passing_controls,clause_followup:c.cases};
  const query=new URLSearchParams(location.search),requested=query.get('review');current=requested||'TjHepwuhkYFA_1035';chooseGroup(query.get('review_group')in sets?query.get('review_group'):'alerts');
 }).catch(e=>{$('review-reason').textContent='Could not load the saved review: '+e.message;});
 $('review-group').addEventListener('change',e=>chooseGroup(e.target.value,true));$('review-verdict').addEventListener('change',()=>filter(true));
 let timer;$('review-search').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>filter(true),150);});$('review-case').addEventListener('change',e=>show(e.target.value,true));
})();
