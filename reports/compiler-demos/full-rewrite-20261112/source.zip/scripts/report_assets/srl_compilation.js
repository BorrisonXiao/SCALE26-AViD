const $ = id => document.getElementById(id);
const escapeHTML = value => String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const pretty = value => escapeHTML(JSON.stringify(value,null,2));
let cases = [], lookup = {}, shown = new Set(), initializing = true;

function sourceTree(tokens) {
  const children = new Map();
  for (const t of tokens) {
    if (!children.has(t.head)) children.set(t.head,[]);
    children.get(t.head).push(t);
  }
  const visited = new Set();
  function branch(t) {
    if (visited.has(t.id)) return '';
    visited.add(t.id);
    return '<li><b>'+escapeHTML(t.text)+'</b> <small>'+escapeHTML(t.upos+' · '+t.deprel+' · token '+t.index)+'</small>'+
      ((children.get(t.id)||[]).length ? '<ul>'+children.get(t.id).map(branch).join('')+'</ul>' : '')+'</li>';
  }
  return '<ul class="parse-tree">'+(children.get(0)||[]).map(branch).join('')+'</ul>';
}
function entity(ref) {
  const e = lookup[ref];
  if (!e) return escapeHTML(ref);
  let out = '<b>'+escapeHTML(e.text)+'</b> <small>'+escapeHTML(ref+' · '+(e.type||'entity'))+'</small>';
  if (shown.has(ref)) return out+' <small>(shared reference)</small>';
  shown.add(ref);
  for (const p of e.properties||[]) out += '<div>'+escapeHTML(p.role)+': '+escapeHTML(p.value)+'</div>';
  if (e.quantity) out += '<div>Quantity: '+escapeHTML(e.quantity.operator+' '+e.quantity.value)+'</div>';
  for (const r of e.relations||[]) out += '<div class="tree"><span class="role">'+escapeHTML(r.role)+'</span> '+entity(r.target)+'</div>';
  for (const p of e.propositions||[]) out += proposition(p);
  return out;
}
function proposition(p) {
  return '<div class="tree"><span class="role">'+escapeHTML(p.role+' · '+p.kind+' · '+p.route)+'</span>'+node(p.body)+'</div>';
}
function node(n) {
  if (!n) return 'No logical form.';
  if (n.op==='entity') return '<div>'+entity(n.ref)+'</div>';
  if (n.op==='and'||n.op==='or') return '<b>'+n.op.toUpperCase()+'</b>'+n.children.map(c=>'<div class="tree">'+node(c)+'</div>').join('');
  if (n.op==='not') return '<b>NOT</b><div class="tree">'+node(n.child)+'</div>';
  if (n.op==='qualified') return '<b>'+escapeHTML(n.operator)+'</b><div class="tree">'+node(n.body)+'</div>';
  let out = '<p><b>'+escapeHTML(n.predicate)+'</b> <small>'+escapeHTML(n.id+' · '+n.anchor)+'</small></p>';
  for (const [role,arg] of Object.entries(n.arguments||{})) out += '<div class="tree"><span class="role">'+escapeHTML(role)+'</span> '+(typeof arg==='string'?entity(arg):escapeHTML(JSON.stringify(arg)))+'</div>';
  for (const p of n.properties||[]) out += '<div>'+escapeHTML(p.role)+': '+escapeHTML(p.value)+'</div>';
  for (const p of n.propositions||[]) out += proposition(p);
  return out;
}
function srlText(frames,words) {
  return frames.map(f=>{
    const span=f.verb_span;
    return (span?span[0]:'?')+' · '+f.verb+'\n'+(f.args||[]).map((a,i)=>'  argument '+i+' · '+a.role+' ['+a.start+','+a.end+']: '+a.text).join('\n');
  }).join('\n\n');
}
function show() {
  const c=cases.find(r=>r.claim_id===$('claim-select').value);
  if (!c) return;
  const method=$('method').value, r=c.outputs[method];
  $('claim-title').textContent=c.claim_id;
  $('claim-text').textContent=c.text;
  $('syntax').innerHTML=sourceTree(c.tokens);
  $('original-srl').textContent=srlText(c.srl.frames||[],c.srl.words);
  if (!r) {
    $('outcome').innerHTML='<p>This condition was not run on this claim. Model conditions were tested on the fixed 48-claim set only.</p>';
    $('edits').textContent='Not run.'; $('form').innerHTML='Not run.'; $('predicates').textContent='Not run.'; $('program').textContent='Not run.';
    return;
  }
  let outcome='<p><b>'+escapeHTML(r.status==='compiled'?'Compiled':'Refused')+'</b> · '+escapeHTML(method.replaceAll('_',' '))+'</p>';
  if (r.review) outcome+='<div class="callout"><b>Assistant review: '+escapeHTML(r.review.judgment)+'</b><p>'+escapeHTML(r.review.note)+'</p></div>';
  if (r.reason) outcome+='<p>'+escapeHTML(r.code)+': '+escapeHTML(r.reason)+'</p>';
  if (r.diagnostics?.length) outcome+='<details><summary>Automatic diagnostics</summary><pre>'+pretty(r.diagnostics)+'</pre></details>';
  $('outcome').innerHTML=outcome;
  $('edits').textContent=r.edits?JSON.stringify(r.edits,null,2):'No LLM used in this condition.';
  lookup=Object.fromEntries((r.form?.entities||[]).map(e=>[e.id,e]));shown=new Set();
  $('form').innerHTML=node(r.form?.formula);
  $('predicates').textContent=(r.predicates||[]).join('\n')||'No program accepted.';
  $('program').textContent=r.program||'Full programs are included in the source archive. No media inference was run in this study.';
  if (!initializing) history.replaceState(null,'','#claim='+encodeURIComponent(c.claim_id));
}
function filter() {
  const query=$('search').value.toLowerCase(), f=$('filter').value, current=$('claim-select').value;
  const matches=cases.filter(c=>(c.claim_id+' '+c.text).toLowerCase().includes(query)&&
    (f==='all'||f==='model'&&c.outputs.revised_ud_srl||f==='reviewed'&&c.outputs.trained_srl?.review||c.outputs.trained_srl?.status===f));
  $('claim-select').innerHTML=matches.map(c=>'<option value="'+escapeHTML(c.claim_id)+'">'+escapeHTML(c.claim_id+' · '+c.text)+'</option>').join('');
  if (matches.some(c=>c.claim_id===current)) $('claim-select').value=current;
  $('match-count').textContent=matches.length+' of '+cases.length+' original claims shown';
  if (matches.length) show();
}
fetch('srl-compilation/cases.json').then(r=>{if(!r.ok)throw Error(r.status);return r.json();}).then(data=>{
  cases=data;
  const wanted=location.hash.startsWith('#claim=')?decodeURIComponent(location.hash.slice(7)):'TKCfkoNUssZI_717';
  filter();
  if(cases.some(c=>c.claim_id===wanted)){$('claim-select').value=wanted;show();}
  initializing = false;
}).catch(e=>$('match-count').textContent='Could not load the cached examples: '+e.message);
$('search').addEventListener('input',filter);$('filter').addEventListener('change',filter);
$('claim-select').addEventListener('change',show);$('method').addEventListener('change',show);
function openClaim(wanted) {
  if (!cases.some(c=>c.claim_id===wanted)) return;
  $('filter').value='all';$('search').value='';filter();
  $('claim-select').value=wanted;show();$('examples').scrollIntoView({block:'start'});
}
window.addEventListener('hashchange',()=>{
  if (location.hash.startsWith('#claim=')) openClaim(decodeURIComponent(location.hash.slice(7)));
});
document.querySelectorAll('[data-claim]').forEach(link=>link.addEventListener('click',event=>{
  event.preventDefault();openClaim(link.dataset.claim);
}));
