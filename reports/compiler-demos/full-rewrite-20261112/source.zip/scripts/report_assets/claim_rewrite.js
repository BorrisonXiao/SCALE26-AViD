(()=>{
 const $=id=>document.getElementById(id);
 const esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
 const params=new URLSearchParams(location.search);
 let cases=[],configs={},current=params.get('rewrite');
 function graph(label,out,n){
  let h='<section class="output"><h3>'+label+'</h3><p>'+esc(out.status==='compiled'?'Passes automatic content checks':(out.reason||out.code))+'</p>'+ClaimOutputView.render(out.view,out.view.metadata,n);
  if(out.view.status==='compiled')h+='<details><summary>Exact predicates and logical form</summary><pre>'+esc(out.view.predicates.join('\n'))+'</pre><pre>'+esc(JSON.stringify(out.view.form,null,2))+'</pre></details>';
  return h+'</section>';
 }
 function request(){
  const row=cases.find(c=>c.claim_id===current);if(!row)return;
  const key=$('rewrite-prompt-condition').value,raw=row.inspection.conditions[key],config=configs[key];
  const name=config.model.split('/').slice(-2);const modelName=name[0]==='qwen3'?'Qwen3-'+name[1]:name.join('/');
  $('rewrite-model-config').textContent='Model: '+modelName+' (frozen, text only). Temperature '+config.temperature+'; seed '+config.seed+'; '+config.dtype+'; maximum '+config.max_tokens+' generated tokens; vLLM '+config.vllm+'; JSON-schema decoding.';
  $('rewrite-system-prompt').textContent=raw.messages.find(m=>m.role==='system').content;
  $('rewrite-user-prompt').textContent=raw.messages.find(m=>m.role==='user').content;
  $('rewrite-raw-response').textContent=raw.raw_response;
  $('rewrite-prompt-stage').textContent=raw.failure_stage;
  $('rewrite-prompt-review').textContent=raw.review_reason;
  const url=new URL(location.href);url.searchParams.set('rewrite',current);url.searchParams.set('rewrite_prompt',key);url.hash='rewrite-case-inspector';
  $('rewrite-share-case').href=url.pathname+url.search+url.hash;
 }
 function show(cid){
  const r=cases.find(c=>c.claim_id===cid);if(!r)return;current=cid;
  const route=r.inspection.route;
  $('rewrite-case').value=cid;$('rewrite-id').textContent=cid+' · '+r.group;
  $('rewrite-route').textContent=route.rewrite_eligible?'Direct compilation failed ('+route.direct_code+'): '+route.direct_reason+' This claim is eligible for the rewrite fallback.':'Direct compilation passed. Keep the direct result; do not call the rewriter. The outputs below are historical diagnostic probes, outside the fallback path.';
  $('rewrite-original').textContent=r.text;$('rewrite-reading').textContent=r.reading;
  $('rewrite-initial-text').textContent=r.initial_proposal.text===r.text?'Kept the original text unchanged.':r.initial_proposal.text;
  $('rewrite-initial-review').textContent=r.initial_review.reason;
  $('rewrite-initial-predicates').textContent=(r.initial_output.predicates||[]).join('\n')+'\n'+JSON.stringify(r.initial_output.form,null,2);
  $('rewrite-text').textContent=r.proposal.text;
  $('rewrite-model-reason').textContent='Model action: '+r.proposal.action+'. Model reason: '+r.proposal.reason;
  $('rewrite-judgment').textContent=r.review.accepted?'Accepted after review: faithful rewrite and compiled relationships.':'Retained original result; rewrite not accepted. '+r.review.outcome;
  $('rewrite-review').textContent=r.review.reason;
  $('rewrite-checks').textContent='Surface checks: '+(r.surface_issues.length?r.surface_issues.join('; '):'no flagged change; semantic equivalence still requires review.');
  $('rewrite-graphs').innerHTML=graph('Original compilation',r.outputs.original,5)+graph('Rewritten diagnostic compilation',r.outputs.rewritten,6);
  request();
 }
 function filter(){
  const g=$('rewrite-group').value;
  const rows=cases.filter(r=>g==='all'||(g==='eligible'?r.inspection.route.rewrite_eligible:g==='rejected'?r.inspection.route.rewrite_eligible&&!r.review.accepted:g==='diagnostic'?!r.inspection.route.rewrite_eligible:g==='accepted'?r.review.accepted:r.group===g));
  $('rewrite-count').textContent=rows.length+' of '+cases.length+' historical cases';
  $('rewrite-case').innerHTML=rows.map(r=>'<option value="'+esc(r.claim_id)+'">'+esc(r.claim_id+' · '+r.text.slice(0,105))+'</option>').join('');
  if(rows.length)show(rows.some(r=>r.claim_id===current)?current:rows[0].claim_id);else $('rewrite-graphs').innerHTML='';
 }
 $('rewrite-group').addEventListener('change',filter);
 $('rewrite-case').addEventListener('change',e=>{show(e.target.value);history.replaceState(null,'',new URL($('rewrite-share-case').href));});
 $('rewrite-prompt-condition').addEventListener('change',()=>{request();history.replaceState(null,'',new URL($('rewrite-share-case').href));});
 Promise.all([
  fetch('compiler-demos/rewrite-20261111/pilot_cases.json').then(r=>{if(!r.ok)throw Error('Could not load rewrite comparisons.');return r.json();}),
  fetch('compiler-demos/rewrite-inspection-20261112/inspection.json').then(r=>{if(!r.ok)throw Error('Could not load exact rewrite requests.');return r.json();})
 ]).then(([rows,data])=>{
  cases=rows.map(r=>({...r,inspection:data.cases[r.claim_id]}));configs=data.model_configs;
  if(!cases.some(r=>r.claim_id===current))current='TFgw4IaR9R8s_1587';
  if(!cases.find(r=>r.claim_id===current).inspection.route.rewrite_eligible)$('rewrite-group').value='diagnostic';
  $('rewrite-prompt-condition').value=params.get('rewrite_prompt')==='initial'?'initial':'revised';filter();
 }).catch(e=>{$('rewrite-count').textContent=e.message;});
})();
