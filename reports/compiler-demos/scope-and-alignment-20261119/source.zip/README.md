# Negative scope and automatic speaker windows

## Compiler

The examples cover 22 authored controls, nine new AVeriTeC claims, and two prior false passes. The texts and reference readings were frozen before reviewing the new outputs. The authored and dataset readings were reviewed by the implementing assistant. The official AVeriTeC verdicts are excluded. The checks concern predicate structure and scope. Both compiler versions receive the same Stanza, BERT-SRL, and BART-AMR annotations. Neither uses a rewrite in the 33-case comparison. [AVeriTeC](https://fever.ai/dataset/averitec.html)

For a shared “without,” the compiler binds the positive event once and tests the absence of a matching item for every alternative. A separate positive preposition keeps its own branch. For subordinate actions, negation covers both within the manner of the positive event. The example about discomfort and coughing now requires both absences during the same breath-holding event.

For “must do A or face B,” an explicit consequence cue puts B in the scope of noncompliance with the obligation. The compiler keeps temporal limits, any earlier condition, and the distinction between reported or written content and events asserted to occur. Ordinary choices have no consequence added. If “or else” ends a quotation without naming a consequence, the literal warning can survive and there is no invented sanction predicate.

All 22 authored inputs compile, up from 21. The target scope is preserved in 21, and the modifier inside “a camera without a lens” remains opaque. Two earlier false passes now preserve their tested scope. Four of nine new dataset claims compile, down from six. Two preserve the target scope. Two still have issues concerning an unmatched quote or exceptions. Two earlier passes now abstain. One kept both missing items in an opaque phrase and the other treated “else” as an alternative to Iran. A scope match does not certify every role in a long claim.

The cached corpus rerun retains 2,179 byte-identical programs and the same 196 abstentions. Exact DeepProbLog with the existing ordered solver matches all 15 controls. The controls use supplied evidence, including an incomplete item inventory and a case where only the consequence is supported. All 703 project tests pass.

## Speaker and time alignment

The test uses eight distant-microphone excerpts from eight AMI meetings outside the previous speech pilot. The reported content is taken from the corpus’s independently annotated utterance. We chose the excerpts and generated wrong-speaker and earlier-time queries before diarization. The reference speaker, original words, and word timings come from AMI. This setup checks whether the supplied content can be recovered and attributed when the speaker windows are estimated. [AMI corpus and manual annotations](https://groups.inf.ed.ac.uk/ami/download/)

We downloaded up to 75 seconds per example from a single array microphone, at 16 kHz. We ran sherpa-onnx 2.0.2 on CPU with the pyannote 3.0 segmentation model and the 3D-Speaker CAM++ VoxCeleb embedding checkpoint. There are two conditions, free clustering with the example threshold of 0.5 and clustering with the participant count found in AMI metadata. The models still estimate the boundaries and assign anonymous speaker clusters in both conditions. [Sherpa diarization documentation](https://k2-fsa.github.io/sherpa/onnx/speaker-diarization/index.html)

The target query searches a broad 35-second slot. We match anonymous labels to participant IDs using annotated speech before the target slot, with a five-second gap. We assign transcribed words to the unique active proposed window at each word’s midpoint. Words falling in overlapping or silent windows are left out. In the target interval, the automatic assignments receive word times and text without the corresponding annotated speaker label. We compare the same reported-content check under manual annotated windows, automatic windows with speaker ignored, and automatic windows filtered by speaker. This isolates alignment with supplied text. It includes no automatic transcription. The earlier-time control searches actual candidate words in an earlier interval of the same audio.

Annotated windows support 8 of 8 correct-speaker queries. The proposed windows ignoring speaker support 2 of 8, but those same two windows also support the corresponding wrong-speaker queries. With speaker filtering, 1 of 8 correct-speaker queries receives support and all wrong-speaker and earlier-time controls stay unknown. Providing the participant count reduces the number of anonymous clusters and leaves the verdict counts unchanged. The eight cases are a small diagnostic. Decisions use two entailment spans and the existing frozen MiniLM scores. No model was trained.

AMI audio and transcript excerpts are attributed to the University of Edinburgh and partners, under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The data bundle includes selected words, reference timings, predicted speaker windows, model hashes, audio-range hashes, and cached text scores. The audio and model checkpoints stay outside the report archive.

## Replay

Use Python 3.12 and the attached compilation requirements. Run from the bundle root. The archive includes cached model outputs. The two corpus files contain the selected program hashes and routing decisions.

```sh
export PYTHONHASHSEED=0
export PYTHONPATH=scripts
run=exp/probabilistic_verification/scope_and_alignment_20261119
python scripts/evaluate_or_followup_compilation.py "$run/compiler" "$run/compiler/amr.jsonl" "$run/after.json"
python scripts/evaluate_ami_alignment.py prepare
python scripts/evaluate_ami_alignment.py prepare --roster
python scripts/evaluate_ami_alignment.py evaluate
python scripts/evaluate_ami_alignment.py evaluate --roster
python scripts/check_scoped_coordination_inference.py
python scripts/scope_alignment_report.py
python -m pytest -q tests/test_negative_coordination.py
```

Compare the generated files to `REPLAY_SHA256.json`. The previous report archive has the baseline compiler if recompilation of the old forms is needed. The audio downloader and diarizer can regenerate the evidence windows from the linked AMI recordings and the pinned checkpoints. Use `sherpa-onnx==2.0.2` and its matching CPU runtime. Segmentation and embedding files come from the official [segmentation releases](https://github.com/k2-fsa/sherpa-onnx/releases/tag/speaker-segmentation-models) and [speaker embedding releases](https://github.com/k2-fsa/sherpa-onnx/releases/tag/speaker-recongition-models). Their exact file hashes are recorded in the archive.

## Next work

1. Run the binding pilot with annotated speech windows and record parsing abstentions separately. This measures the relation model before introducing the observed alignment errors.
2. Compare the diarizer with an overlap-aware alternative and retain multiple candidate windows. Measure recovery of the correct speaker before increasing the scope of the audio study.
