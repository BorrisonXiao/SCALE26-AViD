"""Compare reference and audio-proposed speaker windows with the same text scorer."""
import argparse
from collections import Counter, defaultdict
from hashlib import sha256
from itertools import chain, product

import numpy as np
from scipy.optimize import linear_sum_assignment

from collect_ami_or_candidates import detokenize
from evaluate_reported_or_transcripts import score_pairs
from prepare_compiler_fallback import dump
from prepare_scope_alignment import PRIOR, RUN
from prepare_or_source_evaluation import read
from probabilistic_verification.transcript_or import implicit_splits, judge, normalize, splits


def overlap(a,b,c,d):
    return max(0,min(b,d)-max(a,c))


def match_speakers(example, turns):
    """Name anonymous clusters using earlier manual speaker labels only."""
    cutoff = example['query_start']-5
    enrollment = [w for w in example['clip_words'] if w['end'] < cutoff and w['end'] > w['start']]
    speakers = sorted({w['speaker'] for w in enrollment})
    clusters = sorted({t['cluster'] for t in turns})
    evidence = np.array([[sum(overlap(w['start'],w['end'],t['start'],min(t['end'],cutoff))
                              for w in enrollment if w['speaker']==s
                              for t in turns if t['cluster']==c) for s in speakers] for c in clusters],
                        dtype=float).reshape((len(clusters),len(speakers)))
    assigned = {}
    if evidence.size:
        for i,j in zip(*linear_sum_assignment(evidence,maximize=True)):
            if evidence[i,j] >= 1 and evidence[i,j] >= 0.55*evidence[i].sum():
                assigned[clusters[i]]=speakers[j]
    return assigned,dict(annotated_speakers=speakers,clusters=clusters,match_seconds=evidence.tolist(),cutoff=cutoff)


def proposed_windows(example, turns, names, start, end):
    possible = [t for t in turns if t['end']>start and t['start']<end]
    placed = defaultdict(list)
    for token in example['clip_words']:
        mid = (token['start']+token['end'])/2
        if not start<=mid<end:
            continue
        contenders = [i for i,t in enumerate(possible) if t['start']<=mid<t['end']]
        if len(contenders)==1:
            placed[contenders[0]].append(token)
    candidates = []
    for index,words in placed.items():
        segment=possible[index]
        current=[]
        for token in words:
            current.append(token)
            if token['text'] in {'.','?','!'}:
                candidates.append((segment,current))
                current=[]
        if current:
            candidates.append((segment,current))
    return [dict(text=detokenize(words),start=max(start,words[0]['start']),end=min(end,words[-1]['end']),
                 speaker=names.get(segment['cluster']),cluster=segment['cluster'],complete=False,
                 word_ids=[w['word_id'] for w in words])
            for segment,words in candidates if len(words)>=3 and
            (list(splits(detokenize(words),'or')) or list(implicit_splits(detokenize(words))))]


def prepare(suffix):
    source = RUN/'speech_cases.json'
    assert sha256(source.read_bytes()).hexdigest()==(RUN/'speech_cases.sha256').read_text().strip()
    diar = read(RUN/f'diarization{suffix}.json')
    turns = {r['meeting']:r['turns'] for r in diar['meetings']}
    data = []
    for e in read(source):
        detected = turns[e['meeting']]
        assigned,enrollment = match_speakers(e,detected)
        candidates = proposed_windows(e,detected,assigned,e['query_start'],e['query_end'])
        earlier = proposed_windows(e,detected,assigned,e['clip_start'],e['query_start']-5)
        gold = dict(text=e['text'],start=e['start'],end=e['end'],speaker=e['speaker'],complete=True)
        others = Counter(w['speaker'] for w in e['clip_words'] if
                         e['query_start']<=w['start']<e['query_end'] and w['speaker']!=e['speaker'])
        assert others
        query = dict(start=e['query_start'],end=e['query_end'],speaker=e['speaker'])
        variants = [
            dict(variant='correct_speaker',query=query,expected='supported'),
            dict(variant='different_speaker',query=dict(query,speaker=others.most_common(1)[0][0]),expected='unknown'),
            dict(variant='disjoint_query',query=dict(query,start=e['clip_start'],end=e['query_start']-5),expected='unknown'),
        ]
        audio_words = {w['word_id'] for w in e['words'] if w['text'] not in {',','.','?','!'}}
        coverage = lambda rows: max((len(set(c['word_ids'])&audio_words)/len(audio_words) for c in rows),default=0)
        data.append(dict(meeting=e['meeting'],segment_id=e['segment_id'],target=e['text'],
                         gold=gold, turns=detected, names=assigned, enrollment=enrollment,
                         proposals=candidates+earlier, variants=variants,
                         max_word_coverage=coverage(candidates),
                         named_word_coverage=coverage(c for c in candidates if c['speaker']==e['speaker'])))
    dump(RUN/f'speech_inputs{suffix}.json',data)
    print('Prepared',len(data),'comparisons of annotated and estimated windows.')


def score(suffix):
    pairs=set()
    for row in read(RUN/f'speech_inputs{suffix}.json'):
        target=list(splits(row['target'],'or'))
        assert len(target)==1
        for c in row['proposals']:
            candidates = {c['text']}
            for pair in chain(splits(c['text'],'or'), splits(c['text'],'and'),implicit_splits(c['text'])):
                candidates.update(pair)
            for a,b in product(candidates,target[0]):
                if normalize(a)!=normalize(b):
                    pairs.update(((a,b),(b,a)))
    scores=score_pairs(pairs,PRIOR/'source/minilm-nli')
    dump(RUN/f'speech_scores{suffix}.json',scores)
    print('Scored',len(scores['scores']),'text pairs.')


def evaluate(suffix):
    rows=read(RUN/f'speech_inputs{suffix}.json')
    stored={(r['premise'],r['hypothesis']):r['probabilities'] for r in read(RUN/f'speech_scores{suffix}.json')['scores']}
    def entailment(a,b):
        return stored[a,b]['entailment']
    def contradiction(a,b):
        return stored[a,b]['contradiction']

    totals=defaultdict(Counter)
    for row in rows:
        for control in row['variants']:
            query=control['query']
            target=row['target']
            reference=judge(query,dict(row['gold'],target=target))
            windows_only=[]
            with_speakers=[]
            for candidate in row['proposals']:
                if judge(query,dict(candidate,target=target,speaker=query['speaker']),entailment,
                         allow_implicit=True,contradiction=contradiction)=='supported':
                    windows_only.append(candidate)
                    if candidate['speaker']==query['speaker']:
                        with_speakers.append(candidate)
            expected=control['expected']
            control['predictions']=dict(reference=reference, windows='supported' if windows_only else 'unknown',
                                        speakers='supported' if with_speakers else 'unknown')
            control['matched_windows']=windows_only
            control['matched_speaker_windows']=with_speakers
            v=totals[control['variant']]
            v['total']+=1
            for method,label in control['predictions'].items():
                v[method]+=label==expected
    dump(RUN/f'speech_evaluation{suffix}.json',dict(counts=totals,rows=rows))
    print({k:dict(v) for k,v in totals.items()})


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('stage',choices=('prepare','score','evaluate'))
    p.add_argument('--roster',action='store_true')
    a = p.parse_args()
    {'prepare':prepare,'score':score,'evaluate':evaluate}[a.stage]('_roster' if a.roster else '')
