"""Propose speaker windows from a single distant microphone per AMI excerpt."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest, sha256
import re
import struct
import urllib.request
import wave

from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from prepare_scope_alignment import RUN


def audio_range(url, first, last):
    request = urllib.request.Request(url, headers={'Range': f'bytes={first}-{last}', 'User-Agent': 'AViD research pilot'})
    with urllib.request.urlopen(request, timeout=35) as response:
        header = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range',''))
        if response.status != 206 or not header or tuple(map(int,header.groups()[:2])) != (first,last):
            raise ValueError(f'Unexpected range response for {url}: {response.status}')
        result = response.read(last-first+2)
        assert len(result) == last-first+1
    return result


def format_info(header):
    if header[:4] != b'RIFF' or header[8:12] != b'WAVE':
        raise ValueError('Expected a WAV header.')
    spec = None
    cursor = 12
    while cursor+8 <= len(header):
        name, size = struct.unpack_from('<4sI',header,cursor)
        cursor += 8
        if name == b'fmt ':
            method,channels,rate,_,width,bits = struct.unpack_from('<HHIIHH',header,cursor)
            if (method,channels,rate,width,bits) != (1,1,16000,2,16):
                raise ValueError('Expected 16 kHz mono signed 16-bit PCM audio.')
            spec = rate,width,size
        if name == b'data':
            if spec is None:
                raise ValueError('Data follows missing format.')
            return spec[0],spec[1],cursor,size
        cursor += size+(size % 2)
    raise ValueError('Could not locate the data chunk.')


def download(case):
    url = case['audio_url']
    rate,width,start,nbytes = format_info(audio_range(url,0,4095))
    first = start + int(case['clip_start'] * rate) * width
    stop = min(start+nbytes,start + int(case['clip_end'] * rate) * width)
    pcm = audio_range(url,first,stop-1)
    path = RUN/'audio'/f'{case["meeting"]}.wav'
    with wave.open(str(path),'wb') as result:
        result.setparams((1,width,rate,0,'NONE','not compressed'))
        result.writeframes(pcm)
    return dict(meeting=case['meeting'], url=url, sha256=sha256(path.read_bytes()).hexdigest(),
                source_range=[first,stop-1], start=case['clip_start'], end=case['clip_start']+len(pcm)/width/rate)


def download_audio(cases):
    with ThreadPoolExecutor(max_workers=4) as pool:
        manifest = list(pool.map(download,cases))
    dump(RUN/'audio/manifest.json',manifest)
    print(f'Downloaded {len(manifest)} array microphone excerpts.')


def diarize(cases, speaker_counts=None):
    import importlib.metadata
    import sherpa_onnx
    import soundfile

    model = RUN/'models'
    segmenter = model/'segmentation.onnx'
    embedder = model/'speaker.onnx'
    def create(count):
        config = sherpa_onnx.OfflineSpeakerDiarizationConfig(
            segmentation=sherpa_onnx.OfflineSpeakerSegmentationModelConfig(
                pyannote=sherpa_onnx.OfflineSpeakerSegmentationPyannoteModelConfig(
                    model=str(segmenter), window_shift_ratio=0.1),
                num_threads=2,provider='cpu'),
            embedding=sherpa_onnx.SpeakerEmbeddingExtractorConfig(
                model=str(embedder),num_threads=2,provider='cpu'),
            clustering=sherpa_onnx.FastClusteringConfig(num_clusters=count,threshold=0.5),
            min_duration_on=0.3,min_duration_off=0.5)
        assert config.validate()
        return sherpa_onnx.OfflineSpeakerDiarization(config)
    outputs = []
    audio = {a['meeting']:a for a in read(RUN/'audio/manifest.json')}
    predictors = {}
    for case in cases:
        meeting = case['meeting']
        count = speaker_counts[meeting] if speaker_counts else -1
        if count not in predictors:
            predictors[count] = create(count)
        predictor = predictors[count]
        start = case['clip_start']
        recording = RUN/'audio'/f'{meeting}.wav'
        assert sha256(recording.read_bytes()).hexdigest()==audio[meeting]['sha256']
        signal,rate = soundfile.read(recording,dtype='float32')
        assert rate == predictor.sample_rate and signal.ndim==1
        raw = predictor.process(signal).sort_by_start_time()
        outputs.append(dict(meeting=meeting,
                            turns=[dict(start=float(r.start)+start,end=float(r.end)+start,cluster=int(r.speaker))
                                   for r in raw]))
        print(meeting,len(raw),'turns',flush=True)
    digests = {}
    for path in (segmenter,embedder):
        with path.open('rb') as file:
            digests[path.name]=file_digest(file,'sha256').hexdigest()
    filename = 'diarization_roster.json' if speaker_counts else 'diarization.json'
    dump(RUN/filename,dict(config=dict(sherpa_onnx=importlib.metadata.version('sherpa-onnx'),
         numpy=importlib.metadata.version('numpy'), model_hashes=digests, cluster_threshold=0.5,
         speaker_count=speaker_counts or 'estimated', gap_seconds=0.5, minimum_duration=0.3, window_shift_ratio=0.1),
         meetings=outputs))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage',choices=('download','diarize'))
    cases=read(RUN/'speech_cases.json')
    p.add_argument('--roster',action='store_true')
    a = p.parse_args()
    if a.stage=='download':
        download_audio(cases)
    else:
        diarize(cases,read(RUN/'roster.json') if a.roster else None)
