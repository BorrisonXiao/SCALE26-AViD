import json
from pathlib import Path

import pytest

from probabilistic_verification.compiler_fallback import check_output, restore
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.split_composition import nodes

FOLDER = Path(__file__).resolve().parents[1] / 'exp/probabilistic_verification/scope_and_alignment_20261119/compiler'


@pytest.fixture(scope='module')
def compile_case():
    inputs = {r['claim_id']:r['clauses'][0]['record']
              for r in map(json.loads,(FOLDER/'parsed.jsonl').read_text().splitlines())
              if 'record' in r['clauses'][0]}
    def compare(cid):
        record=inputs[cid]
        return check_output(record,compile_one(record))
    return compare


@pytest.mark.parametrize('cid,count',[('absence_1',2),('absence_5',3),('averitec_train_1197',2)])
def test_absent_items_attach_to_one_affirmed_event(compile_case,cid,count):
    result=compile_case(cid)
    assert result['status']=='compiled'
    claim=restore(result['compilation'])
    choices=[a for a in claim.atoms if a.predicate=='adjunct' and a.arguments[3]=='with']
    assert len(choices)==count
    assert len({a.arguments[0] for a in choices})==1
    assert len({a.arguments[2] for a in choices})==count
    assert claim.to_dict()['logical_form'].count('NOT (EXISTS')>=count


def test_local_prepositions_keep_different_polarity(compile_case):
    result=compile_case('absence_8')
    assert result['status']=='compiled'
    root=result['proposed_form']['formula']
    assert root['op']=='or'
    absent,present=root['children']
    assert absent['adjuncts'][0]['preposition']=='without'
    assert any(p['value']=='with' for p in present['properties'])
    assert 'adjuncts' not in present


def test_coordination_following_without_is_not_a_world_assertion(compile_case):
    result=compile_case('absence_6')
    assert result['status']=='compiled'
    manner=result['proposed_form']['formula']['propositions'][0]
    assert manner['kind']=='manner'
    assert manner['body']['op']=='not'
    assert manner['body']['child']['op']=='or'


@pytest.mark.parametrize('cid',['rule_1','rule_3','rule_4','rule_6','averitec_train_2288'])
def test_sanction_remains_a_consequence_in_the_required_scope(compile_case,cid):
    result=compile_case(cid)
    assert result['status']=='compiled'
    claim=restore(result['compilation'])
    entry=[s for s in claim.metadata['scopes'].values() if s.get('kind')=='consequence']
    assert len(entry)==1
    assert entry[0]['role']=='noncompliance'
    assert claim.metadata['scopes'][entry[0]['parent']]['operator']=='obligation'
    if cid in {'rule_6','averitec_train_2288'}:
        assert any(s.get('kind')=='assertion' and s.get('route')=='ocr_assertion'
                   for s in claim.metadata['scopes'].values())


def test_choice_without_a_sanction_stays_an_or(compile_case):
    result=compile_case('rule_8')
    assert result['status']=='compiled'
    assert result['proposed_form']['formula']['op']=='or'
    assert not any(n.get('kind')=='consequence' for n in nodes(result['proposed_form']['formula']))


def test_opaque_without_does_not_pass_coverage_as_semantics(compile_case):
    result=compile_case('averitec_train_597')
    assert result['status']=='unsupported' and result['code']=='without_scope'


def test_unspecified_consequence_is_preserved_in_verbatim_speech(compile_case):
    result=compile_case('rule_12')
    assert result['status']=='compiled'
    assert any('or else' in str(a['arguments']).casefold() for a in result['compilation']['atoms'])
