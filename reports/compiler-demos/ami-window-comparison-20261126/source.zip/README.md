# Speaker-turn windows and speech score calibration

## Data

We selected one naturally spoken disjunction from each of 24 previously unused AMI meeting series. A series includes all sessions with the same meeting number. The selection uses the manual 1.6.2 transcript and favors excerpts with two interpretable alternatives. It excludes 21 series used in the earlier speech studies. The `source.json` file records these exclusions, the annotation archive hash, and the two splits. A fixed hash of the series ID puts 12 series in calibration and 12 in testing. We use the same evidence for the original report, a faithful paraphrase, a changed alternative, and a change to the surrounding context. The expected support labels are written by the implementing assistant. The evidence consists of the original excerpt, its speaker, and word times. [AMI corpus](https://groups.inf.ed.ac.uk/ami/download/)

We saved the initial wording and results before doing a separate wording audit. Four revisions preserve the source’s time, uncertainty, or speech act more closely. A fifth corrects a grammatical error in a changed report about remotes that was noticed while reviewing the test decisions. The source bundle preserves both versions, and the first test pass is the main comparison. We did not change the splits or choose a threshold using the test decisions.

## Calibration on annotated windows

The frozen DeBERTa score is the probability assigned to entailment. We fit a logistic function with two parameters to the log-odds of this score, with a nonnegative slope and an L2 penalty on the slope. Log-odds turn the ratio of entailment probability to its complement into a value on the real line. The output is a probability of support on the sampled claims. We use a fixed 0.5 threshold on the output. DeBERTa's default decision is the most probable of entailment, contradiction, or neither. It agrees with applying 0.5 to the raw score on this set. The test contains 24 supported and 24 edited claims from the 12 held-out series. [DeBERTa model](https://huggingface.co/cross-encoder/nli-deberta-v3-small)

On the initial test wording, correct decisions rise from 37 to 41 of 48. False support drops from 11 to seven of 24, with all 24 supported claims still accepted. The Brier score, or mean squared probability error, falls from 0.189 to 0.102. On the audited wording, correct decisions rise from 37 to 42 and the Brier score falls from 0.186 to 0.095. The remaining edited claims include a changed number of remotes and a reversed preference. DeBERTa ranks the faithful paraphrase above its paired edits in all 24 test pairs. The logistic map keeps that ordering and improves absolute scores on this sampled task. This study uses manual transcripts and annotated speaker windows. No encoder parameters are fitted.

## Automatic speaker windows

We ran the same CPU Pyannote 3.0 segmentation and CAM++ speaker embedding configuration on 75-second excerpts from one AMI array microphone. Each query searches a 35-second slot. One-to-one matching names the anonymous clusters from earlier annotated speech, with a five-second gap. The query uses the corresponding lightly cleaned original report and the manually transcribed word times. The wrong-speaker query names a different participant in the same slot, or a different participant in the earlier clip when none are annotated in the slot.

The previous method looks for an explicit or implicit disjunction in potential windows. The new methods take consecutive 12-second intervals, starting four seconds apart within a single estimated speaker turn. One includes words only when a single turn is active at the word midpoint, and the other retains words that overlap other turns. Every method ranks the same way, using token overlap with the reported text, and submits at most three windows to frozen DeBERTa. This experiment compares window generation using a common scorer. The previous audio pilot used MiniLM with the alternative comparison. We audit the words and speakers using AMI labels after making the decisions.

Nineteen of 24 utterances have one estimated turn spanning all target words. Before assigning speaker names, the earlier window method retains all target words in one window for four utterances, the new method that drops overlaps for five, and the one that keeps overlaps for 18. Naming clusters with target-interval annotations for diagnosis recovers three, three, and eight complete utterances among the top three, respectively. When naming uses only earlier speech, none of the methods yields a complete utterance window for the requested speaker. They each support one correct-speaker query on a partial window. Only the method that drops overlap has a supported window containing words from the requested speaker alone.

The two turn-based methods each support two wrong-speaker queries. The earlier method produces no candidates for those queries. In IN1002, an exclusive turn window from the other speaker discusses one or two days. The scorer supports a claim about one or two weeks. The overlap method incorporates some of the target speaker’s words into the other speaker’s window. Both errors matter even when candidate retrieval improves.

AMI transcript excerpts are © University of Edinburgh and partners, under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). [Pyannote and sherpa-onnx models](https://k2-fsa.github.io/sherpa/onnx/speaker-diarization/models.html)

## Replay

Use Python 3.12 with the bundled requirements, NumPy 2.2.6, and SciPy 1.17.1. The replay uses cached turns and checkpoint scores. Checkpoint hashes and raw audio byte ranges are recorded, with the models and audio available from their sources. The included `speech_cases.json` is the frozen extract of the manual annotation archive. `report_edits.json` records the final claim text. The initial-label directory contains the first wording and results.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
python scripts/calibrate_ami_speech_scores.py evaluate
python scripts/evaluate_ami_window_comparison.py prepare
python scripts/evaluate_ami_window_comparison.py evaluate
python scripts/ami_window_comparison_report.py
python -m pytest -q tests/test_ami_window_comparison.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/ami_window_comparison_20261126')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```

## Next steps

- Run the speech relation comparison in DeepProbLog with annotated speaker windows and reviewed logical forms. This measures what the calibrated score adds to the same-speaker, same-utterance constraint. Keep the new claims as a diagnostic and use a fresh, independently checked test set for a paper result.
- Keep automatic speaker alignment as a separate comparison. Measure whether a longer labeled enrollment span improves speaker naming on the saved turns before changing the window generator again.
