"""Keep word assignment and score calibration behavior explicit."""
from calibrate_ami_speech_scores import calibrated, fit
from evaluate_ami_window_comparison import direct_windows


def test_direct_windows_keep_complete_phrases_without_a_disjunction():
    words = [dict(text=text, start=t, end=t+0.1, word_id=text)
             for t,text in [(1,'The'),(2,'blue'),(3,'light'),(5,'is'),(7,'on'),(17,'today')]]
    case = dict(query_start=0,query_end=20,clip_words=words)
    turns = [dict(start=0,end=18,cluster=0),dict(start=4,end=6,cluster=1)]
    strict = list(direct_windows(case,turns,{0:'A',1:'B'},include_overlap=False))
    inclusive = list(direct_windows(case,turns,{0:'A',1:'B'},include_overlap=True))

    assert strict[0]['text']=='The blue light on'
    assert inclusive[0]['text']=='The blue light is on'
    assert all(w['end']-w['start']<=12 and w['speaker']=='A' for w in strict+inclusive)
    assert all(not {'The','today'} <= set(w['word_ids']) for w in inclusive)


def test_calibration_preserves_order_and_handles_extreme_scores():
    examples = [dict(scores={'entailment':p},expected_support=y)
                for p,y in [(0,False),(0.4,False),(0.6,True),(1,True)]]
    model = fit(examples)
    scores = [calibrated(c['scores']['entailment'],model) for c in examples]
    assert 0 < scores[0] < scores[1] < 0.5 < scores[2] < scores[3] < 1
