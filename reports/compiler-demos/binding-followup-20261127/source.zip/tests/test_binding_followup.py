"""The same region observation contributes to every pair that uses it."""
from math import prod

import pytest

from evaluate_binding_followup import pair_count_program
from probabilistic_verification.logic import enumerate_probability


def test_pairs_with_a_shared_region_do_not_supply_independent_proofs():
    program,pairs = pair_count_program('scene:0',[(.6,0.,.4)]*3,0)
    probability = enumerate_probability(program)['supported']
    assert probability==pytest.approx(.648)
    assert max(p['score'] for p in pairs)==.36
    assert 1-prod(1-p['score'] for p in pairs)>probability
