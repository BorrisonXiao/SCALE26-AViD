"""Score speech relations and visual regions with frozen model checkpoints."""
import argparse
from hashlib import sha256
import importlib.metadata

from evaluate_ami_speech_scoring import MODELS
from evaluate_reported_or_transcripts import score_pairs
from prepare_binding_followup import ROOT, RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from score_visual_assignments import MODEL

NLI_RELATION = 'The speaker presents at least two choices as alternatives to one another.'
QUESTION = ('How are the described items or actions related? A preferred replacement counts as an alternative. '
            'A plan can contain several additions without treating them as choices.')
CHOICES = ('The speaker contrasts alternatives or proposes one in place of another.',
           'The speaker lists items, additions, or steps that go together.',
           'Only one possibility is mentioned, or the relationship is unclear.')


def nli():
    rows=read(RUN/'speech_inputs.json')['rows']
    pairs={(w['text'],target) for row in rows for c in row['cases'] for w in c['windows']
           for target in (c['content'],NLI_RELATION)}
    dump(RUN/'nli_scores.json',score_pairs(pairs,MODELS['deberta']))
    print('DeBERTa text pairs',len(pairs),flush=True)


def qwen():
    import torch
    from PIL import Image
    from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

    torch.set_num_threads(4)
    processor=AutoProcessor.from_pretrained(MODEL,local_files_only=True)
    model=Qwen3VLForConditionalGeneration.from_pretrained(MODEL,dtype=torch.bfloat16,device_map='cuda:0',
             attn_implementation='sdpa',local_files_only=True).eval().requires_grad_(False)
    tokens=[processor.tokenizer.encode(letter,add_special_tokens=False) for letter in 'ABC']
    assert all(len(t)==1 for t in tokens),tokens
    token_ids=torch.tensor([t[0] for t in tokens],device='cuda:0')

    def score(question,choices,*,text=None,image=None):
        orderings=[]
        for a,b in ((0,1),(1,0)):
            request=(f'{question}\nA. {choices[a]}\nB. {choices[b]}\nC. {choices[2]}\n'
                     'Answer with exactly one letter.')
            content=[{'type':'image','image':'attached'}] if image is not None else []
            if text is not None:
                request=f'Speaker’s words:\n{text}\n\n{request}'
            content.append({'type':'text','text':request})
            prompt=processor.apply_chat_template([{'role':'user','content':content}],tokenize=False,add_generation_prompt=True)
            payload={'images':[image]} if image is not None else {}
            batch=processor(text=[prompt],return_tensors='pt',**payload).to('cuda:0',dtype=torch.bfloat16)
            with torch.inference_mode():
                hidden=model.model(**batch,use_cache=False).last_hidden_state
                logits=model.lm_head(hidden[:,-1:,:])[0,-1].double()
                p=logits.index_select(0,token_ids).softmax(-1).tolist()
                mass=float(logits.softmax(-1).index_select(0,token_ids).sum())
            orderings.append(dict(probabilities=p if a==0 else [p[1],p[0],p[2]],choice_mass=mass))
        return dict(probabilities=[sum(r['probabilities'][i] for r in orderings)/2 for i in range(3)],orderings=orderings)

    provenance=dict(model='Qwen3-VL-8B-Instruct',config_sha256=sha256((MODEL/'config.json').read_bytes()).hexdigest(),
                    versions={p:importlib.metadata.version(p) for p in ('torch','transformers')})
    speech=read(RUN/'speech_inputs.json')['rows']
    texts=sorted({w['text'] for row in speech for c in row['cases'] for w in c['windows']})
    records=[dict(text=text,**score(QUESTION,CHOICES,text=text)) for text in texts]
    dump(RUN/'qwen_speech.json',dict(provenance,question=QUESTION,choices=CHOICES,records=records))
    print('Scored speech spans',len(records),flush=True)
    visual=[]
    for scene in read(RUN/'visual_inputs.json'):
        path=ROOT/scene['frame']['path']
        assert sha256(path.read_bytes()).hexdigest()==scene['frame']['sha256']
        with Image.open(path) as raw:
            image=raw.convert('RGB')
        w,h=image.size
        results={}
        for quality in ('original','reduced_resolution'):
            rows=[]
            for region in scene['regions']:
                l,t,r,b=region['box']
                crop=image.crop((round(l*w),round(t*h),round(r*w),round(b*h)))
                if quality=='reduced_resolution':
                    small=crop.copy()
                    small.thumbnail((28,24),Image.Resampling.LANCZOS)
                    crop=small.resize(crop.size,Image.Resampling.BILINEAR)
                rows.append(score('Which category fits the main object at the center of this crop?',
                                  [*scene['labels'],'Neither or unclear.'],image=crop))
            results[quality]=rows
        visual.append(dict(id=scene['id'],results=results))
        print(scene['id'],'scored',flush=True)
    dump(RUN/'qwen_visual.json',dict(provenance,records=visual))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('stage',choices=('nli','qwen'))
    {'nli':nli,'qwen':qwen}[p.parse_args().stage]()
