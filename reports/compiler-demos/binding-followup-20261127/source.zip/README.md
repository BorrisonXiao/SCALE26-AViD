# Speech alternatives and overlapping visual assignments

## Speech alternatives

We froze 24 excerpts from 21 AMI recordings outside the earlier tests before running either model. The 12 positives present alternatives without “or.” The 12 natural controls present additions or a single possibility. Each positive also has a changed option and a query about a different speaker, with a real nearby utterance from that speaker when one is available. This gives 48 queries, with 12 valid reports and 36 controls. The implementing assistant reviewed the labels, speaker spans, and edits before scoring. This is a development set with annotated speakers and report spans. [AMI corpus](https://groups.inf.ed.ac.uk/ami/download/)

The frozen DeBERTa encoder supplies the content score in every condition. We compare no additional relation score, the previous wording rules, a separate DeBERTa entailment query about whether the speaker offers alternatives, and text-only multiple-choice scoring with Qwen3-VL-8B-Instruct. Qwen’s three choices are alternatives, things that go together, and a single possibility or unclear. We normalize over the three answers, swap the first two answer positions, and average the two runs. DeepProbLog requires the speaker, time, content, and alternatives to match within one candidate report span. We multiply content and alternatives scores within a span, which treats the two observations as independent. We keep the raw scores and a decision threshold of 0.5 for every model. [DeBERTa checkpoint](https://huggingface.co/cross-encoder/nli-deberta-v3-small) · [Qwen checkpoint](https://huggingface.co/Qwen/Qwen3-VL-8B-Instruct)

Qwen correctly classifies 22 of 24 focal spans. Wording rules reject all 24 and the DeBERTa alternatives query accepts all 24, so each gets 12 correct. Adding Qwen’s relation score to grounded verification raises accuracy from 39/48 to 44/48 at the same threshold. Both keep 11/12 valid reports. False support falls from 8/36 to 3/36, with four fewer additions treated as alternatives and one fewer attribution error. The remaining errors are two changed options, a remark about which direction a cat faces scored as a choice, and the valid XHTML/XML contrast with a low content score. Qwen’s span score also misses a negated replacement where the separate content score rejects the claim. Both results support testing whether the specific proposed options appear in the same span. All 192 native speech distributions agree with the direct support calculation. Transcript excerpts are © University of Edinburgh and partners under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

## Overlapping visual assignments

We selected five real frames and marked three or four distinct regions per frame before seeing any model predictions. A positive claim requires two regions in a category that occurs at least twice. A control requires two regions in a category marked only once. Each claim concerns the marked regions. We score original crops and crops downsampled to fit within 28 by 24 pixels, then enlarged to the original crop dimensions. These are 20 decisions on five frames. The frames and model weights are available separately. Crop coordinates, frame timestamps, model prompts, scores, and source hashes are preserved in the archive.

Frozen Qwen provides one distribution per crop over the two candidate categories and neither or unclear. The best-pair baseline uses the largest product of two distinct regions’ scores for the claimed category. The second baseline treats pair successes as independent. Exact inference shares each region observation across all pairs that use it, assumes independence across different crops, and computes the probability that at least one pair succeeds. We independently enumerate possible crop labels and check the complete native distribution for each claim.

The second-best pair has a score of at least 0.1 in 8 of 20 queries. On the dark-shirt claim, the best pair scores 0.659, exact support is 0.902, and treating pairs as independent gives 0.962. Several candidate pairs reuse the same high-scoring region, and one of them uses a crop reviewed as a white shirt. All three methods get 10/10 original and 10/10 reduced-resolution decisions. This comparison demonstrates the effect of handling shared region observations on the scores. It gives no measured decision gain on this small set. Perception used manually selected regions and predefined category options. The scoring job used one L40S for 24 seconds. All 712 project tests pass.

## Next steps

- Score each proposed speech option against the same report span, with changed-option and negated-replacement controls. The goal is to verify which alternatives were offered and protect valid paraphrases.
- Add real frames with natural occlusion, small objects, and closely matched negative candidates, selected without using model scores. The goal is to measure whether exact inference changes supported and unsupported decisions when individual crops give weaker evidence.

## Replay

Use Python 3.12 with the bundled requirements, NumPy 2.2.6, and SciPy 1.17.1. Replay reads cached model outputs and verifies the reported probabilities and generated programs. `tests.xml` records the project test run. The included focused test checks reuse of the same region across candidate pairs.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
python scripts/evaluate_binding_followup.py speech
python scripts/evaluate_binding_followup.py visual
python scripts/binding_followup_report.py
python -m pytest -q tests/test_binding_followup.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/binding_followup_20261127')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```
