% Exact categorical evidence; internal unknown = neither supported nor refuted.
0.99999877444058705::status(o_03a22d3dacedcdcbee0b,supported); 6.1601218832190393e-07::status(o_03a22d3dacedcdcbee0b,refuted); 6.0954722453614225e-07::status(o_03a22d3dacedcdcbee0b,unknown).
0.99637758768481166::status(o_09a801cfa5f6d6f37256,supported); 1.0052351932296389e-06::status(o_09a801cfa5f6d6f37256,refuted); 0.0036214070799951087::status(o_09a801cfa5f6d6f37256,unknown).
0.99999849511775751::status(o_0df064a2292ba0f8c73b,supported); 8.9272586531720628e-07::status(o_0df064a2292ba0f8c73b,refuted); 6.1215637714740966e-07::status(o_0df064a2292ba0f8c73b,unknown).
0.99967367476226887::status(o_189a1840b83a8fd30600,supported); 1.8857432074857632e-06::status(o_189a1840b83a8fd30600,refuted); 0.00032443949452366235::status(o_189a1840b83a8fd30600,unknown).
0.99996193309193482::status(o_1cf643d8879406bdec7b,supported); 9.6847338337312783e-06::status(o_1cf643d8879406bdec7b,refuted); 2.8382174231467409e-05::status(o_1cf643d8879406bdec7b,unknown).
0.99999647206395881::status(o_1d1da26461190033f921,supported); 1.4718514436034733e-06::status(o_1d1da26461190033f921,refuted); 2.05608459763024e-06::status(o_1d1da26461190033f921,unknown).
0.65916867825140013::status(o_26b9bc69919ce1ecf279,supported); 1.7525644671254187e-05::status(o_26b9bc69919ce1ecf279,refuted); 0.3408137961039287::status(o_26b9bc69919ce1ecf279,unknown).
0.99568621644704369::status(o_2fd66add24a54f237483,supported); 7.4253944528983867e-06::status(o_2fd66add24a54f237483,refuted); 0.004306358158503506::status(o_2fd66add24a54f237483,unknown).
1.1088574312813753e-05::status(o_38c098bc63ade68e3d63,supported); 0.99994076664806641::status(o_38c098bc63ade68e3d63,refuted); 4.814477762087613e-05::status(o_38c098bc63ade68e3d63,unknown).
0.9999949259836467::status(o_4f4c2582919b01b27e2c,supported); 2.8892324102388641e-07::status(o_4f4c2582919b01b27e2c,refuted); 4.785093112365109e-06::status(o_4f4c2582919b01b27e2c,unknown).
0.86447583121569993::status(o_53ceee71b35a9940eb0c,supported); 0.00012306156588892678::status(o_53ceee71b35a9940eb0c,refuted); 0.13540110721841128::status(o_53ceee71b35a9940eb0c,unknown).
0.88827226192313913::status(o_60b2475da44c32077ec4,supported); 2.9311850591856767e-05::status(o_60b2475da44c32077ec4,refuted); 0.11169842622626892::status(o_60b2475da44c32077ec4,unknown).
0.99999458698831423::status(o_61f87349d5a082354134,supported); 6.9655409993713308e-07::status(o_61f87349d5a082354134,refuted); 4.7164575857248792e-06::status(o_61f87349d5a082354134,unknown).
0.999986560306935::status(o_65ceaffe0176c4bd8825,supported); 1.1443698350818043e-06::status(o_65ceaffe0176c4bd8825,refuted); 1.2295323229933467e-05::status(o_65ceaffe0176c4bd8825,unknown).
0.98516832700812207::status(o_690c671ef419a0898801,supported); 8.1201588295369302e-06::status(o_690c671ef419a0898801,refuted); 0.014823552833048427::status(o_690c671ef419a0898801,unknown).
0.99998994861335344::status(o_6a72317091db536fd70a,supported); 4.7573806701061806e-07::status(o_6a72317091db536fd70a,refuted); 9.5756485796299431e-06::status(o_6a72317091db536fd70a,unknown).
0.99999082237357972::status(o_6a7440c5567322095f19,supported); 6.3150728568633488e-07::status(o_6a7440c5567322095f19,refuted); 8.5461191345964674e-06::status(o_6a7440c5567322095f19,unknown).
0.51222269276004173::status(o_797b98dc61c720440025,supported); 2.4907531552374776e-05::status(o_797b98dc61c720440025,refuted); 0.48775239970840595::status(o_797b98dc61c720440025,unknown).
0.54264428982049762::status(o_835d6a9da939c611fb82,supported); 0.31237424322594354::status(o_835d6a9da939c611fb82,refuted); 0.14498146695355893::status(o_835d6a9da939c611fb82,unknown).
5.4516871376396289e-05::status(o_8b9cb8eb18c2cc6d8593,supported); 0.94024878657854694::status(o_8b9cb8eb18c2cc6d8593,refuted); 0.059696696550076651::status(o_8b9cb8eb18c2cc6d8593,unknown).
0.99999724677061574::status(o_a1cc247ca1828464a0a8,supported); 4.2337762580624628e-07::status(o_a1cc247ca1828464a0a8,refuted); 2.3298517583803449e-06::status(o_a1cc247ca1828464a0a8,unknown).
0.9810093838296805::status(o_a37eeab5656b9f0fc863,supported); 5.2739895138642569e-05::status(o_a37eeab5656b9f0fc863,refuted); 0.018937876275180773::status(o_a37eeab5656b9f0fc863,unknown).
0.99999876781964359::status(o_a39144e0a53acae24beb,supported); 1.5612536554276723e-07::status(o_a39144e0a53acae24beb,refuted); 1.0760549907594601e-06::status(o_a39144e0a53acae24beb,unknown).
0.99959348448199492::status(o_a57740ee64cfcf484795,supported); 3.6315941031669231e-06::status(o_a57740ee64cfcf484795,refuted); 0.00040288392390208194::status(o_a57740ee64cfcf484795,unknown).
6.8865124341307809e-07::status(o_a974e704566c8242257a,supported); 0.99999734523080785::status(o_a974e704566c8242257a,refuted); 1.9661179487566423e-06::status(o_a974e704566c8242257a,unknown).
0.47817423786930774::status(o_b7c2e66d58b7ffd4ba5c,supported); 0.001893399805267291::status(o_b7c2e66d58b7ffd4ba5c,refuted); 0.51993236232542506::status(o_b7c2e66d58b7ffd4ba5c,unknown).
0.99999771226876555::status(o_beac6773ac4622d9953e,supported); 9.3643825931306901e-07::status(o_beac6773ac4622d9953e,refuted); 1.3512929752385744e-06::status(o_beac6773ac4622d9953e,unknown).
0.99993918581632824::status(o_bef6975ad4cf0654ed8d,supported); 6.9216718610721478e-07::status(o_bef6975ad4cf0654ed8d,refuted); 6.0122016485723585e-05::status(o_bef6975ad4cf0654ed8d,unknown).
0.99803498942207414::status(o_c4ca93e0a86a2929a21e,supported); 2.3906653365303708e-05::status(o_c4ca93e0a86a2929a21e,refuted); 0.0019411039245604521::status(o_c4ca93e0a86a2929a21e,unknown).
1.0696116355509874e-06::status(o_c72cd2ce3128f4c363ad,supported); 0.99999628865119816::status(o_c72cd2ce3128f4c363ad,refuted); 2.641737166416359e-06::status(o_c72cd2ce3128f4c363ad,unknown).
0.3714682074272308::status(o_cd9a64089dd515ac8082,supported); 0.0045213810475063275::status(o_cd9a64089dd515ac8082,refuted); 0.62401041152526282::status(o_cd9a64089dd515ac8082,unknown).
0.00017371993954768645::status(o_dc3aee049066733f931f,supported); 0.94513614886114494::status(o_dc3aee049066733f931f,refuted); 0.054690131199307407::status(o_dc3aee049066733f931f,unknown).
4.2665641001221759e-05::status(o_e40a43a953578f983705,supported); 0.99916938370396891::status(o_e40a43a953578f983705,refuted); 0.00078795065502988747::status(o_e40a43a953578f983705,unknown).
2.6540017072484021e-05::status(o_eb718573e7279ac6bee1,supported); 0.95213356658259241::status(o_eb718573e7279ac6bee1,refuted); 0.047839893400335155::status(o_eb718573e7279ac6bee1,unknown).
2.7125131082779488e-06::status(o_ec6fe35511f3bba7f88a,supported); 0.99997861209251437::status(o_ec6fe35511f3bba7f88a,refuted); 1.8675394377366938e-05::status(o_ec6fe35511f3bba7f88a,unknown).
0.99961616105367923::status(o_eede0b65cb7f19efbc62,supported); 8.8572121441131033e-07::status(o_eede0b65cb7f19efbc62,refuted); 0.00038295322510644683::status(o_eede0b65cb7f19efbc62,unknown).
0.32588512530269809::status(o_ef6e918a09cc0ae7b90e,supported); 9.8060295939399312e-06::status(o_ef6e918a09cc0ae7b90e,refuted); 0.67410506866770792::status(o_ef6e918a09cc0ae7b90e,unknown).
0.65779705458799764::status(o_fb5b9995d8d6911b5e75,supported); 1.073021714623144e-05::status(o_fb5b9995d8d6911b5e75,refuted); 0.3421922151948561::status(o_fb5b9995d8d6911b5e75,unknown).
node(n2,supported) :- status(o_4f4c2582919b01b27e2c,supported).
node(n2,refuted) :- status(o_4f4c2582919b01b27e2c,refuted).
node(n2,unknown) :- status(o_4f4c2582919b01b27e2c,unknown).
node(n3,supported) :- status(o_bef6975ad4cf0654ed8d,supported).
node(n3,refuted) :- status(o_bef6975ad4cf0654ed8d,refuted).
node(n3,unknown) :- status(o_bef6975ad4cf0654ed8d,unknown).
node(n1,supported) :- node(n2,supported), node(n3,supported).
node(n1,refuted) :- node(n2,refuted).
node(n1,refuted) :- node(n3,refuted).
node(n1,unknown) :- \+ node(n1,supported), \+ node(n1,refuted).
node(n5,supported) :- status(o_a39144e0a53acae24beb,supported).
node(n5,refuted) :- status(o_a39144e0a53acae24beb,refuted).
node(n5,unknown) :- status(o_a39144e0a53acae24beb,unknown).
node(n4,supported) :- node(n2,supported), node(n5,supported).
node(n4,refuted) :- node(n2,refuted).
node(n4,refuted) :- node(n5,refuted).
node(n4,unknown) :- \+ node(n4,supported), \+ node(n4,refuted).
node(n7,supported) :- status(o_a974e704566c8242257a,supported).
node(n7,refuted) :- status(o_a974e704566c8242257a,refuted).
node(n7,unknown) :- status(o_a974e704566c8242257a,unknown).
node(n6,supported) :- node(n2,supported), node(n7,supported).
node(n6,refuted) :- node(n2,refuted).
node(n6,refuted) :- node(n7,refuted).
node(n6,unknown) :- \+ node(n6,supported), \+ node(n6,refuted).
node(n8,supported) :- node(n3,supported), node(n5,supported).
node(n8,refuted) :- node(n3,refuted).
node(n8,refuted) :- node(n5,refuted).
node(n8,unknown) :- \+ node(n8,supported), \+ node(n8,refuted).
node(n9,supported) :- node(n3,supported), node(n7,supported).
node(n9,refuted) :- node(n3,refuted).
node(n9,refuted) :- node(n7,refuted).
node(n9,unknown) :- \+ node(n9,supported), \+ node(n9,refuted).
node(n10,supported) :- node(n5,supported), node(n7,supported).
node(n10,refuted) :- node(n5,refuted).
node(n10,refuted) :- node(n7,refuted).
node(n10,unknown) :- \+ node(n10,supported), \+ node(n10,refuted).
node(n0,refuted) :- node(n1,refuted), node(n4,refuted), node(n6,refuted), node(n8,refuted), node(n9,refuted), node(n10,refuted).
node(n0,supported) :- node(n1,supported).
node(n0,supported) :- node(n4,supported).
node(n0,supported) :- node(n6,supported).
node(n0,supported) :- node(n8,supported).
node(n0,supported) :- node(n9,supported).
node(n0,supported) :- node(n10,supported).
node(n0,unknown) :- \+ node(n0,supported), \+ node(n0,refuted).
verdict(c_4f4c2582919b01b2,supported) :- node(n0,supported).
query(verdict(c_4f4c2582919b01b2,supported)).
verdict(c_4f4c2582919b01b2,refuted) :- node(n0,refuted).
query(verdict(c_4f4c2582919b01b2,refuted)).
verdict(c_4f4c2582919b01b2,unknown) :- node(n0,unknown).
query(verdict(c_4f4c2582919b01b2,unknown)).
node(n13,supported) :- node(n2,refuted).
node(n13,refuted) :- node(n2,supported).
node(n13,unknown) :- \+ node(n13,supported), \+ node(n13,refuted).
node(n14,supported) :- node(n3,refuted).
node(n14,refuted) :- node(n3,supported).
node(n14,unknown) :- \+ node(n14,supported), \+ node(n14,refuted).
node(n12,supported) :- node(n13,supported), node(n14,supported).
node(n12,refuted) :- node(n13,refuted).
node(n12,refuted) :- node(n14,refuted).
node(n12,unknown) :- \+ node(n12,supported), \+ node(n12,refuted).
node(n16,supported) :- node(n5,refuted).
node(n16,refuted) :- node(n5,supported).
node(n16,unknown) :- \+ node(n16,supported), \+ node(n16,refuted).
node(n15,supported) :- node(n13,supported), node(n16,supported).
node(n15,refuted) :- node(n13,refuted).
node(n15,refuted) :- node(n16,refuted).
node(n15,unknown) :- \+ node(n15,supported), \+ node(n15,refuted).
node(n18,supported) :- node(n7,refuted).
node(n18,refuted) :- node(n7,supported).
node(n18,unknown) :- \+ node(n18,supported), \+ node(n18,refuted).
node(n17,supported) :- node(n13,supported), node(n18,supported).
node(n17,refuted) :- node(n13,refuted).
node(n17,refuted) :- node(n18,refuted).
node(n17,unknown) :- \+ node(n17,supported), \+ node(n17,refuted).
node(n19,supported) :- node(n14,supported), node(n16,supported).
node(n19,refuted) :- node(n14,refuted).
node(n19,refuted) :- node(n16,refuted).
node(n19,unknown) :- \+ node(n19,supported), \+ node(n19,refuted).
node(n20,supported) :- node(n14,supported), node(n18,supported).
node(n20,refuted) :- node(n14,refuted).
node(n20,refuted) :- node(n18,refuted).
node(n20,unknown) :- \+ node(n20,supported), \+ node(n20,refuted).
node(n21,supported) :- node(n16,supported), node(n18,supported).
node(n21,refuted) :- node(n16,refuted).
node(n21,refuted) :- node(n18,refuted).
node(n21,unknown) :- \+ node(n21,supported), \+ node(n21,refuted).
node(n11,refuted) :- node(n12,refuted), node(n15,refuted), node(n17,refuted), node(n19,refuted), node(n20,refuted), node(n21,refuted).
node(n11,supported) :- node(n12,supported).
node(n11,supported) :- node(n15,supported).
node(n11,supported) :- node(n17,supported).
node(n11,supported) :- node(n19,supported).
node(n11,supported) :- node(n20,supported).
node(n11,supported) :- node(n21,supported).
node(n11,unknown) :- \+ node(n11,supported), \+ node(n11,refuted).
verdict(c_bef6975ad4cf0654,supported) :- node(n11,supported).
query(verdict(c_bef6975ad4cf0654,supported)).
verdict(c_bef6975ad4cf0654,refuted) :- node(n11,refuted).
query(verdict(c_bef6975ad4cf0654,refuted)).
verdict(c_bef6975ad4cf0654,unknown) :- node(n11,unknown).
query(verdict(c_bef6975ad4cf0654,unknown)).
node(n24,supported) :- status(o_eede0b65cb7f19efbc62,supported).
node(n24,refuted) :- status(o_eede0b65cb7f19efbc62,refuted).
node(n24,unknown) :- status(o_eede0b65cb7f19efbc62,unknown).
node(n25,supported) :- status(o_09a801cfa5f6d6f37256,supported).
node(n25,refuted) :- status(o_09a801cfa5f6d6f37256,refuted).
node(n25,unknown) :- status(o_09a801cfa5f6d6f37256,unknown).
node(n23,supported) :- node(n24,supported), node(n25,supported).
node(n23,refuted) :- node(n24,refuted).
node(n23,refuted) :- node(n25,refuted).
node(n23,unknown) :- \+ node(n23,supported), \+ node(n23,refuted).
node(n27,supported) :- status(o_6a72317091db536fd70a,supported).
node(n27,refuted) :- status(o_6a72317091db536fd70a,refuted).
node(n27,unknown) :- status(o_6a72317091db536fd70a,unknown).
node(n26,supported) :- node(n24,supported), node(n27,supported).
node(n26,refuted) :- node(n24,refuted).
node(n26,refuted) :- node(n27,refuted).
node(n26,unknown) :- \+ node(n26,supported), \+ node(n26,refuted).
node(n29,supported) :- status(o_ec6fe35511f3bba7f88a,supported).
node(n29,refuted) :- status(o_ec6fe35511f3bba7f88a,refuted).
node(n29,unknown) :- status(o_ec6fe35511f3bba7f88a,unknown).
node(n28,supported) :- node(n24,supported), node(n29,supported).
node(n28,refuted) :- node(n24,refuted).
node(n28,refuted) :- node(n29,refuted).
node(n28,unknown) :- \+ node(n28,supported), \+ node(n28,refuted).
node(n30,supported) :- node(n25,supported), node(n27,supported).
node(n30,refuted) :- node(n25,refuted).
node(n30,refuted) :- node(n27,refuted).
node(n30,unknown) :- \+ node(n30,supported), \+ node(n30,refuted).
node(n31,supported) :- node(n25,supported), node(n29,supported).
node(n31,refuted) :- node(n25,refuted).
node(n31,refuted) :- node(n29,refuted).
node(n31,unknown) :- \+ node(n31,supported), \+ node(n31,refuted).
node(n32,supported) :- node(n27,supported), node(n29,supported).
node(n32,refuted) :- node(n27,refuted).
node(n32,refuted) :- node(n29,refuted).
node(n32,unknown) :- \+ node(n32,supported), \+ node(n32,refuted).
node(n22,refuted) :- node(n23,refuted), node(n26,refuted), node(n28,refuted), node(n30,refuted), node(n31,refuted), node(n32,refuted).
node(n22,supported) :- node(n23,supported).
node(n22,supported) :- node(n26,supported).
node(n22,supported) :- node(n28,supported).
node(n22,supported) :- node(n30,supported).
node(n22,supported) :- node(n31,supported).
node(n22,supported) :- node(n32,supported).
node(n22,unknown) :- \+ node(n22,supported), \+ node(n22,refuted).
verdict(c_eede0b65cb7f19ef,supported) :- node(n22,supported).
query(verdict(c_eede0b65cb7f19ef,supported)).
verdict(c_eede0b65cb7f19ef,refuted) :- node(n22,refuted).
query(verdict(c_eede0b65cb7f19ef,refuted)).
verdict(c_eede0b65cb7f19ef,unknown) :- node(n22,unknown).
query(verdict(c_eede0b65cb7f19ef,unknown)).
node(n35,supported) :- node(n24,refuted).
node(n35,refuted) :- node(n24,supported).
node(n35,unknown) :- \+ node(n35,supported), \+ node(n35,refuted).
node(n36,supported) :- node(n25,refuted).
node(n36,refuted) :- node(n25,supported).
node(n36,unknown) :- \+ node(n36,supported), \+ node(n36,refuted).
node(n34,supported) :- node(n35,supported), node(n36,supported).
node(n34,refuted) :- node(n35,refuted).
node(n34,refuted) :- node(n36,refuted).
node(n34,unknown) :- \+ node(n34,supported), \+ node(n34,refuted).
node(n38,supported) :- node(n27,refuted).
node(n38,refuted) :- node(n27,supported).
node(n38,unknown) :- \+ node(n38,supported), \+ node(n38,refuted).
node(n37,supported) :- node(n35,supported), node(n38,supported).
node(n37,refuted) :- node(n35,refuted).
node(n37,refuted) :- node(n38,refuted).
node(n37,unknown) :- \+ node(n37,supported), \+ node(n37,refuted).
node(n40,supported) :- node(n29,refuted).
node(n40,refuted) :- node(n29,supported).
node(n40,unknown) :- \+ node(n40,supported), \+ node(n40,refuted).
node(n39,supported) :- node(n35,supported), node(n40,supported).
node(n39,refuted) :- node(n35,refuted).
node(n39,refuted) :- node(n40,refuted).
node(n39,unknown) :- \+ node(n39,supported), \+ node(n39,refuted).
node(n41,supported) :- node(n36,supported), node(n38,supported).
node(n41,refuted) :- node(n36,refuted).
node(n41,refuted) :- node(n38,refuted).
node(n41,unknown) :- \+ node(n41,supported), \+ node(n41,refuted).
node(n42,supported) :- node(n36,supported), node(n40,supported).
node(n42,refuted) :- node(n36,refuted).
node(n42,refuted) :- node(n40,refuted).
node(n42,unknown) :- \+ node(n42,supported), \+ node(n42,refuted).
node(n43,supported) :- node(n38,supported), node(n40,supported).
node(n43,refuted) :- node(n38,refuted).
node(n43,refuted) :- node(n40,refuted).
node(n43,unknown) :- \+ node(n43,supported), \+ node(n43,refuted).
node(n33,refuted) :- node(n34,refuted), node(n37,refuted), node(n39,refuted), node(n41,refuted), node(n42,refuted), node(n43,refuted).
node(n33,supported) :- node(n34,supported).
node(n33,supported) :- node(n37,supported).
node(n33,supported) :- node(n39,supported).
node(n33,supported) :- node(n41,supported).
node(n33,supported) :- node(n42,supported).
node(n33,supported) :- node(n43,supported).
node(n33,unknown) :- \+ node(n33,supported), \+ node(n33,refuted).
verdict(c_09a801cfa5f6d6f3,supported) :- node(n33,supported).
query(verdict(c_09a801cfa5f6d6f3,supported)).
verdict(c_09a801cfa5f6d6f3,refuted) :- node(n33,refuted).
query(verdict(c_09a801cfa5f6d6f3,refuted)).
verdict(c_09a801cfa5f6d6f3,unknown) :- node(n33,unknown).
query(verdict(c_09a801cfa5f6d6f3,unknown)).
node(n46,supported) :- status(o_0df064a2292ba0f8c73b,supported).
node(n46,refuted) :- status(o_0df064a2292ba0f8c73b,refuted).
node(n46,unknown) :- status(o_0df064a2292ba0f8c73b,unknown).
node(n47,supported) :- status(o_2fd66add24a54f237483,supported).
node(n47,refuted) :- status(o_2fd66add24a54f237483,refuted).
node(n47,unknown) :- status(o_2fd66add24a54f237483,unknown).
node(n45,supported) :- node(n46,supported), node(n47,supported).
node(n45,refuted) :- node(n46,refuted).
node(n45,refuted) :- node(n47,refuted).
node(n45,unknown) :- \+ node(n45,supported), \+ node(n45,refuted).
node(n49,supported) :- status(o_a1cc247ca1828464a0a8,supported).
node(n49,refuted) :- status(o_a1cc247ca1828464a0a8,refuted).
node(n49,unknown) :- status(o_a1cc247ca1828464a0a8,unknown).
node(n48,supported) :- node(n46,supported), node(n49,supported).
node(n48,refuted) :- node(n46,refuted).
node(n48,refuted) :- node(n49,refuted).
node(n48,unknown) :- \+ node(n48,supported), \+ node(n48,refuted).
node(n51,supported) :- status(o_38c098bc63ade68e3d63,supported).
node(n51,refuted) :- status(o_38c098bc63ade68e3d63,refuted).
node(n51,unknown) :- status(o_38c098bc63ade68e3d63,unknown).
node(n50,supported) :- node(n46,supported), node(n51,supported).
node(n50,refuted) :- node(n46,refuted).
node(n50,refuted) :- node(n51,refuted).
node(n50,unknown) :- \+ node(n50,supported), \+ node(n50,refuted).
node(n52,supported) :- node(n47,supported), node(n49,supported).
node(n52,refuted) :- node(n47,refuted).
node(n52,refuted) :- node(n49,refuted).
node(n52,unknown) :- \+ node(n52,supported), \+ node(n52,refuted).
node(n53,supported) :- node(n47,supported), node(n51,supported).
node(n53,refuted) :- node(n47,refuted).
node(n53,refuted) :- node(n51,refuted).
node(n53,unknown) :- \+ node(n53,supported), \+ node(n53,refuted).
node(n54,supported) :- node(n49,supported), node(n51,supported).
node(n54,refuted) :- node(n49,refuted).
node(n54,refuted) :- node(n51,refuted).
node(n54,unknown) :- \+ node(n54,supported), \+ node(n54,refuted).
node(n44,refuted) :- node(n45,refuted), node(n48,refuted), node(n50,refuted), node(n52,refuted), node(n53,refuted), node(n54,refuted).
node(n44,supported) :- node(n45,supported).
node(n44,supported) :- node(n48,supported).
node(n44,supported) :- node(n50,supported).
node(n44,supported) :- node(n52,supported).
node(n44,supported) :- node(n53,supported).
node(n44,supported) :- node(n54,supported).
node(n44,unknown) :- \+ node(n44,supported), \+ node(n44,refuted).
verdict(c_0df064a2292ba0f8,supported) :- node(n44,supported).
query(verdict(c_0df064a2292ba0f8,supported)).
verdict(c_0df064a2292ba0f8,refuted) :- node(n44,refuted).
query(verdict(c_0df064a2292ba0f8,refuted)).
verdict(c_0df064a2292ba0f8,unknown) :- node(n44,unknown).
query(verdict(c_0df064a2292ba0f8,unknown)).
node(n57,supported) :- node(n46,refuted).
node(n57,refuted) :- node(n46,supported).
node(n57,unknown) :- \+ node(n57,supported), \+ node(n57,refuted).
node(n58,supported) :- node(n47,refuted).
node(n58,refuted) :- node(n47,supported).
node(n58,unknown) :- \+ node(n58,supported), \+ node(n58,refuted).
node(n56,supported) :- node(n57,supported), node(n58,supported).
node(n56,refuted) :- node(n57,refuted).
node(n56,refuted) :- node(n58,refuted).
node(n56,unknown) :- \+ node(n56,supported), \+ node(n56,refuted).
node(n60,supported) :- node(n49,refuted).
node(n60,refuted) :- node(n49,supported).
node(n60,unknown) :- \+ node(n60,supported), \+ node(n60,refuted).
node(n59,supported) :- node(n57,supported), node(n60,supported).
node(n59,refuted) :- node(n57,refuted).
node(n59,refuted) :- node(n60,refuted).
node(n59,unknown) :- \+ node(n59,supported), \+ node(n59,refuted).
node(n62,supported) :- node(n51,refuted).
node(n62,refuted) :- node(n51,supported).
node(n62,unknown) :- \+ node(n62,supported), \+ node(n62,refuted).
node(n61,supported) :- node(n57,supported), node(n62,supported).
node(n61,refuted) :- node(n57,refuted).
node(n61,refuted) :- node(n62,refuted).
node(n61,unknown) :- \+ node(n61,supported), \+ node(n61,refuted).
node(n63,supported) :- node(n58,supported), node(n60,supported).
node(n63,refuted) :- node(n58,refuted).
node(n63,refuted) :- node(n60,refuted).
node(n63,unknown) :- \+ node(n63,supported), \+ node(n63,refuted).
node(n64,supported) :- node(n58,supported), node(n62,supported).
node(n64,refuted) :- node(n58,refuted).
node(n64,refuted) :- node(n62,refuted).
node(n64,unknown) :- \+ node(n64,supported), \+ node(n64,refuted).
node(n65,supported) :- node(n60,supported), node(n62,supported).
node(n65,refuted) :- node(n60,refuted).
node(n65,refuted) :- node(n62,refuted).
node(n65,unknown) :- \+ node(n65,supported), \+ node(n65,refuted).
node(n55,refuted) :- node(n56,refuted), node(n59,refuted), node(n61,refuted), node(n63,refuted), node(n64,refuted), node(n65,refuted).
node(n55,supported) :- node(n56,supported).
node(n55,supported) :- node(n59,supported).
node(n55,supported) :- node(n61,supported).
node(n55,supported) :- node(n63,supported).
node(n55,supported) :- node(n64,supported).
node(n55,supported) :- node(n65,supported).
node(n55,unknown) :- \+ node(n55,supported), \+ node(n55,refuted).
verdict(c_2fd66add24a54f23,supported) :- node(n55,supported).
query(verdict(c_2fd66add24a54f23,supported)).
verdict(c_2fd66add24a54f23,refuted) :- node(n55,refuted).
query(verdict(c_2fd66add24a54f23,refuted)).
verdict(c_2fd66add24a54f23,unknown) :- node(n55,unknown).
query(verdict(c_2fd66add24a54f23,unknown)).
node(n68,supported) :- status(o_1d1da26461190033f921,supported).
node(n68,refuted) :- status(o_1d1da26461190033f921,refuted).
node(n68,unknown) :- status(o_1d1da26461190033f921,unknown).
node(n69,supported) :- status(o_ef6e918a09cc0ae7b90e,supported).
node(n69,refuted) :- status(o_ef6e918a09cc0ae7b90e,refuted).
node(n69,unknown) :- status(o_ef6e918a09cc0ae7b90e,unknown).
node(n67,supported) :- node(n68,supported), node(n69,supported).
node(n67,refuted) :- node(n68,refuted).
node(n67,refuted) :- node(n69,refuted).
node(n67,unknown) :- \+ node(n67,supported), \+ node(n67,refuted).
node(n71,supported) :- status(o_61f87349d5a082354134,supported).
node(n71,refuted) :- status(o_61f87349d5a082354134,refuted).
node(n71,unknown) :- status(o_61f87349d5a082354134,unknown).
node(n70,supported) :- node(n68,supported), node(n71,supported).
node(n70,refuted) :- node(n68,refuted).
node(n70,refuted) :- node(n71,refuted).
node(n70,unknown) :- \+ node(n70,supported), \+ node(n70,refuted).
node(n73,supported) :- status(o_e40a43a953578f983705,supported).
node(n73,refuted) :- status(o_e40a43a953578f983705,refuted).
node(n73,unknown) :- status(o_e40a43a953578f983705,unknown).
node(n72,supported) :- node(n68,supported), node(n73,supported).
node(n72,refuted) :- node(n68,refuted).
node(n72,refuted) :- node(n73,refuted).
node(n72,unknown) :- \+ node(n72,supported), \+ node(n72,refuted).
node(n74,supported) :- node(n69,supported), node(n71,supported).
node(n74,refuted) :- node(n69,refuted).
node(n74,refuted) :- node(n71,refuted).
node(n74,unknown) :- \+ node(n74,supported), \+ node(n74,refuted).
node(n75,supported) :- node(n69,supported), node(n73,supported).
node(n75,refuted) :- node(n69,refuted).
node(n75,refuted) :- node(n73,refuted).
node(n75,unknown) :- \+ node(n75,supported), \+ node(n75,refuted).
node(n76,supported) :- node(n71,supported), node(n73,supported).
node(n76,refuted) :- node(n71,refuted).
node(n76,refuted) :- node(n73,refuted).
node(n76,unknown) :- \+ node(n76,supported), \+ node(n76,refuted).
node(n66,refuted) :- node(n67,refuted), node(n70,refuted), node(n72,refuted), node(n74,refuted), node(n75,refuted), node(n76,refuted).
node(n66,supported) :- node(n67,supported).
node(n66,supported) :- node(n70,supported).
node(n66,supported) :- node(n72,supported).
node(n66,supported) :- node(n74,supported).
node(n66,supported) :- node(n75,supported).
node(n66,supported) :- node(n76,supported).
node(n66,unknown) :- \+ node(n66,supported), \+ node(n66,refuted).
verdict(c_1d1da26461190033,supported) :- node(n66,supported).
query(verdict(c_1d1da26461190033,supported)).
verdict(c_1d1da26461190033,refuted) :- node(n66,refuted).
query(verdict(c_1d1da26461190033,refuted)).
verdict(c_1d1da26461190033,unknown) :- node(n66,unknown).
query(verdict(c_1d1da26461190033,unknown)).
node(n79,supported) :- node(n68,refuted).
node(n79,refuted) :- node(n68,supported).
node(n79,unknown) :- \+ node(n79,supported), \+ node(n79,refuted).
node(n80,supported) :- node(n69,refuted).
node(n80,refuted) :- node(n69,supported).
node(n80,unknown) :- \+ node(n80,supported), \+ node(n80,refuted).
node(n78,supported) :- node(n79,supported), node(n80,supported).
node(n78,refuted) :- node(n79,refuted).
node(n78,refuted) :- node(n80,refuted).
node(n78,unknown) :- \+ node(n78,supported), \+ node(n78,refuted).
node(n82,supported) :- node(n71,refuted).
node(n82,refuted) :- node(n71,supported).
node(n82,unknown) :- \+ node(n82,supported), \+ node(n82,refuted).
node(n81,supported) :- node(n79,supported), node(n82,supported).
node(n81,refuted) :- node(n79,refuted).
node(n81,refuted) :- node(n82,refuted).
node(n81,unknown) :- \+ node(n81,supported), \+ node(n81,refuted).
node(n84,supported) :- node(n73,refuted).
node(n84,refuted) :- node(n73,supported).
node(n84,unknown) :- \+ node(n84,supported), \+ node(n84,refuted).
node(n83,supported) :- node(n79,supported), node(n84,supported).
node(n83,refuted) :- node(n79,refuted).
node(n83,refuted) :- node(n84,refuted).
node(n83,unknown) :- \+ node(n83,supported), \+ node(n83,refuted).
node(n85,supported) :- node(n80,supported), node(n82,supported).
node(n85,refuted) :- node(n80,refuted).
node(n85,refuted) :- node(n82,refuted).
node(n85,unknown) :- \+ node(n85,supported), \+ node(n85,refuted).
node(n86,supported) :- node(n80,supported), node(n84,supported).
node(n86,refuted) :- node(n80,refuted).
node(n86,refuted) :- node(n84,refuted).
node(n86,unknown) :- \+ node(n86,supported), \+ node(n86,refuted).
node(n87,supported) :- node(n82,supported), node(n84,supported).
node(n87,refuted) :- node(n82,refuted).
node(n87,refuted) :- node(n84,refuted).
node(n87,unknown) :- \+ node(n87,supported), \+ node(n87,refuted).
node(n77,refuted) :- node(n78,refuted), node(n81,refuted), node(n83,refuted), node(n85,refuted), node(n86,refuted), node(n87,refuted).
node(n77,supported) :- node(n78,supported).
node(n77,supported) :- node(n81,supported).
node(n77,supported) :- node(n83,supported).
node(n77,supported) :- node(n85,supported).
node(n77,supported) :- node(n86,supported).
node(n77,supported) :- node(n87,supported).
node(n77,unknown) :- \+ node(n77,supported), \+ node(n77,refuted).
verdict(c_ef6e918a09cc0ae7,supported) :- node(n77,supported).
query(verdict(c_ef6e918a09cc0ae7,supported)).
verdict(c_ef6e918a09cc0ae7,refuted) :- node(n77,refuted).
query(verdict(c_ef6e918a09cc0ae7,refuted)).
verdict(c_ef6e918a09cc0ae7,unknown) :- node(n77,unknown).
query(verdict(c_ef6e918a09cc0ae7,unknown)).
node(n90,supported) :- status(o_03a22d3dacedcdcbee0b,supported).
node(n90,refuted) :- status(o_03a22d3dacedcdcbee0b,refuted).
node(n90,unknown) :- status(o_03a22d3dacedcdcbee0b,unknown).
node(n91,supported) :- status(o_26b9bc69919ce1ecf279,supported).
node(n91,refuted) :- status(o_26b9bc69919ce1ecf279,refuted).
node(n91,unknown) :- status(o_26b9bc69919ce1ecf279,unknown).
node(n89,supported) :- node(n90,supported), node(n91,supported).
node(n89,refuted) :- node(n90,refuted).
node(n89,refuted) :- node(n91,refuted).
node(n89,unknown) :- \+ node(n89,supported), \+ node(n89,refuted).
node(n93,supported) :- status(o_cd9a64089dd515ac8082,supported).
node(n93,refuted) :- status(o_cd9a64089dd515ac8082,refuted).
node(n93,unknown) :- status(o_cd9a64089dd515ac8082,unknown).
node(n92,supported) :- node(n90,supported), node(n93,supported).
node(n92,refuted) :- node(n90,refuted).
node(n92,refuted) :- node(n93,refuted).
node(n92,unknown) :- \+ node(n92,supported), \+ node(n92,refuted).
node(n95,supported) :- status(o_835d6a9da939c611fb82,supported).
node(n95,refuted) :- status(o_835d6a9da939c611fb82,refuted).
node(n95,unknown) :- status(o_835d6a9da939c611fb82,unknown).
node(n94,supported) :- node(n90,supported), node(n95,supported).
node(n94,refuted) :- node(n90,refuted).
node(n94,refuted) :- node(n95,refuted).
node(n94,unknown) :- \+ node(n94,supported), \+ node(n94,refuted).
node(n96,supported) :- node(n91,supported), node(n93,supported).
node(n96,refuted) :- node(n91,refuted).
node(n96,refuted) :- node(n93,refuted).
node(n96,unknown) :- \+ node(n96,supported), \+ node(n96,refuted).
node(n97,supported) :- node(n91,supported), node(n95,supported).
node(n97,refuted) :- node(n91,refuted).
node(n97,refuted) :- node(n95,refuted).
node(n97,unknown) :- \+ node(n97,supported), \+ node(n97,refuted).
node(n98,supported) :- node(n93,supported), node(n95,supported).
node(n98,refuted) :- node(n93,refuted).
node(n98,refuted) :- node(n95,refuted).
node(n98,unknown) :- \+ node(n98,supported), \+ node(n98,refuted).
node(n88,refuted) :- node(n89,refuted), node(n92,refuted), node(n94,refuted), node(n96,refuted), node(n97,refuted), node(n98,refuted).
node(n88,supported) :- node(n89,supported).
node(n88,supported) :- node(n92,supported).
node(n88,supported) :- node(n94,supported).
node(n88,supported) :- node(n96,supported).
node(n88,supported) :- node(n97,supported).
node(n88,supported) :- node(n98,supported).
node(n88,unknown) :- \+ node(n88,supported), \+ node(n88,refuted).
verdict(c_03a22d3dacedcdcb,supported) :- node(n88,supported).
query(verdict(c_03a22d3dacedcdcb,supported)).
verdict(c_03a22d3dacedcdcb,refuted) :- node(n88,refuted).
query(verdict(c_03a22d3dacedcdcb,refuted)).
verdict(c_03a22d3dacedcdcb,unknown) :- node(n88,unknown).
query(verdict(c_03a22d3dacedcdcb,unknown)).
node(n101,supported) :- node(n90,refuted).
node(n101,refuted) :- node(n90,supported).
node(n101,unknown) :- \+ node(n101,supported), \+ node(n101,refuted).
node(n102,supported) :- node(n91,refuted).
node(n102,refuted) :- node(n91,supported).
node(n102,unknown) :- \+ node(n102,supported), \+ node(n102,refuted).
node(n100,supported) :- node(n101,supported), node(n102,supported).
node(n100,refuted) :- node(n101,refuted).
node(n100,refuted) :- node(n102,refuted).
node(n100,unknown) :- \+ node(n100,supported), \+ node(n100,refuted).
node(n104,supported) :- node(n93,refuted).
node(n104,refuted) :- node(n93,supported).
node(n104,unknown) :- \+ node(n104,supported), \+ node(n104,refuted).
node(n103,supported) :- node(n101,supported), node(n104,supported).
node(n103,refuted) :- node(n101,refuted).
node(n103,refuted) :- node(n104,refuted).
node(n103,unknown) :- \+ node(n103,supported), \+ node(n103,refuted).
node(n106,supported) :- node(n95,refuted).
node(n106,refuted) :- node(n95,supported).
node(n106,unknown) :- \+ node(n106,supported), \+ node(n106,refuted).
node(n105,supported) :- node(n101,supported), node(n106,supported).
node(n105,refuted) :- node(n101,refuted).
node(n105,refuted) :- node(n106,refuted).
node(n105,unknown) :- \+ node(n105,supported), \+ node(n105,refuted).
node(n107,supported) :- node(n102,supported), node(n104,supported).
node(n107,refuted) :- node(n102,refuted).
node(n107,refuted) :- node(n104,refuted).
node(n107,unknown) :- \+ node(n107,supported), \+ node(n107,refuted).
node(n108,supported) :- node(n102,supported), node(n106,supported).
node(n108,refuted) :- node(n102,refuted).
node(n108,refuted) :- node(n106,refuted).
node(n108,unknown) :- \+ node(n108,supported), \+ node(n108,refuted).
node(n109,supported) :- node(n104,supported), node(n106,supported).
node(n109,refuted) :- node(n104,refuted).
node(n109,refuted) :- node(n106,refuted).
node(n109,unknown) :- \+ node(n109,supported), \+ node(n109,refuted).
node(n99,refuted) :- node(n100,refuted), node(n103,refuted), node(n105,refuted), node(n107,refuted), node(n108,refuted), node(n109,refuted).
node(n99,supported) :- node(n100,supported).
node(n99,supported) :- node(n103,supported).
node(n99,supported) :- node(n105,supported).
node(n99,supported) :- node(n107,supported).
node(n99,supported) :- node(n108,supported).
node(n99,supported) :- node(n109,supported).
node(n99,unknown) :- \+ node(n99,supported), \+ node(n99,refuted).
verdict(c_26b9bc69919ce1ec,supported) :- node(n99,supported).
query(verdict(c_26b9bc69919ce1ec,supported)).
verdict(c_26b9bc69919ce1ec,refuted) :- node(n99,refuted).
query(verdict(c_26b9bc69919ce1ec,refuted)).
verdict(c_26b9bc69919ce1ec,unknown) :- node(n99,unknown).
query(verdict(c_26b9bc69919ce1ec,unknown)).
node(n112,supported) :- status(o_65ceaffe0176c4bd8825,supported).
node(n112,refuted) :- status(o_65ceaffe0176c4bd8825,refuted).
node(n112,unknown) :- status(o_65ceaffe0176c4bd8825,unknown).
node(n113,supported) :- status(o_690c671ef419a0898801,supported).
node(n113,refuted) :- status(o_690c671ef419a0898801,refuted).
node(n113,unknown) :- status(o_690c671ef419a0898801,unknown).
node(n111,supported) :- node(n112,supported), node(n113,supported).
node(n111,refuted) :- node(n112,refuted).
node(n111,refuted) :- node(n113,refuted).
node(n111,unknown) :- \+ node(n111,supported), \+ node(n111,refuted).
node(n115,supported) :- status(o_b7c2e66d58b7ffd4ba5c,supported).
node(n115,refuted) :- status(o_b7c2e66d58b7ffd4ba5c,refuted).
node(n115,unknown) :- status(o_b7c2e66d58b7ffd4ba5c,unknown).
node(n114,supported) :- node(n112,supported), node(n115,supported).
node(n114,refuted) :- node(n112,refuted).
node(n114,refuted) :- node(n115,refuted).
node(n114,unknown) :- \+ node(n114,supported), \+ node(n114,refuted).
node(n117,supported) :- status(o_a37eeab5656b9f0fc863,supported).
node(n117,refuted) :- status(o_a37eeab5656b9f0fc863,refuted).
node(n117,unknown) :- status(o_a37eeab5656b9f0fc863,unknown).
node(n116,supported) :- node(n112,supported), node(n117,supported).
node(n116,refuted) :- node(n112,refuted).
node(n116,refuted) :- node(n117,refuted).
node(n116,unknown) :- \+ node(n116,supported), \+ node(n116,refuted).
node(n118,supported) :- node(n113,supported), node(n115,supported).
node(n118,refuted) :- node(n113,refuted).
node(n118,refuted) :- node(n115,refuted).
node(n118,unknown) :- \+ node(n118,supported), \+ node(n118,refuted).
node(n119,supported) :- node(n113,supported), node(n117,supported).
node(n119,refuted) :- node(n113,refuted).
node(n119,refuted) :- node(n117,refuted).
node(n119,unknown) :- \+ node(n119,supported), \+ node(n119,refuted).
node(n120,supported) :- node(n115,supported), node(n117,supported).
node(n120,refuted) :- node(n115,refuted).
node(n120,refuted) :- node(n117,refuted).
node(n120,unknown) :- \+ node(n120,supported), \+ node(n120,refuted).
node(n110,refuted) :- node(n111,refuted), node(n114,refuted), node(n116,refuted), node(n118,refuted), node(n119,refuted), node(n120,refuted).
node(n110,supported) :- node(n111,supported).
node(n110,supported) :- node(n114,supported).
node(n110,supported) :- node(n116,supported).
node(n110,supported) :- node(n118,supported).
node(n110,supported) :- node(n119,supported).
node(n110,supported) :- node(n120,supported).
node(n110,unknown) :- \+ node(n110,supported), \+ node(n110,refuted).
verdict(c_65ceaffe0176c4bd,supported) :- node(n110,supported).
query(verdict(c_65ceaffe0176c4bd,supported)).
verdict(c_65ceaffe0176c4bd,refuted) :- node(n110,refuted).
query(verdict(c_65ceaffe0176c4bd,refuted)).
verdict(c_65ceaffe0176c4bd,unknown) :- node(n110,unknown).
query(verdict(c_65ceaffe0176c4bd,unknown)).
node(n123,supported) :- node(n112,refuted).
node(n123,refuted) :- node(n112,supported).
node(n123,unknown) :- \+ node(n123,supported), \+ node(n123,refuted).
node(n124,supported) :- node(n113,refuted).
node(n124,refuted) :- node(n113,supported).
node(n124,unknown) :- \+ node(n124,supported), \+ node(n124,refuted).
node(n122,supported) :- node(n123,supported), node(n124,supported).
node(n122,refuted) :- node(n123,refuted).
node(n122,refuted) :- node(n124,refuted).
node(n122,unknown) :- \+ node(n122,supported), \+ node(n122,refuted).
node(n126,supported) :- node(n115,refuted).
node(n126,refuted) :- node(n115,supported).
node(n126,unknown) :- \+ node(n126,supported), \+ node(n126,refuted).
node(n125,supported) :- node(n123,supported), node(n126,supported).
node(n125,refuted) :- node(n123,refuted).
node(n125,refuted) :- node(n126,refuted).
node(n125,unknown) :- \+ node(n125,supported), \+ node(n125,refuted).
node(n128,supported) :- node(n117,refuted).
node(n128,refuted) :- node(n117,supported).
node(n128,unknown) :- \+ node(n128,supported), \+ node(n128,refuted).
node(n127,supported) :- node(n123,supported), node(n128,supported).
node(n127,refuted) :- node(n123,refuted).
node(n127,refuted) :- node(n128,refuted).
node(n127,unknown) :- \+ node(n127,supported), \+ node(n127,refuted).
node(n129,supported) :- node(n124,supported), node(n126,supported).
node(n129,refuted) :- node(n124,refuted).
node(n129,refuted) :- node(n126,refuted).
node(n129,unknown) :- \+ node(n129,supported), \+ node(n129,refuted).
node(n130,supported) :- node(n124,supported), node(n128,supported).
node(n130,refuted) :- node(n124,refuted).
node(n130,refuted) :- node(n128,refuted).
node(n130,unknown) :- \+ node(n130,supported), \+ node(n130,refuted).
node(n131,supported) :- node(n126,supported), node(n128,supported).
node(n131,refuted) :- node(n126,refuted).
node(n131,refuted) :- node(n128,refuted).
node(n131,unknown) :- \+ node(n131,supported), \+ node(n131,refuted).
node(n121,refuted) :- node(n122,refuted), node(n125,refuted), node(n127,refuted), node(n129,refuted), node(n130,refuted), node(n131,refuted).
node(n121,supported) :- node(n122,supported).
node(n121,supported) :- node(n125,supported).
node(n121,supported) :- node(n127,supported).
node(n121,supported) :- node(n129,supported).
node(n121,supported) :- node(n130,supported).
node(n121,supported) :- node(n131,supported).
node(n121,unknown) :- \+ node(n121,supported), \+ node(n121,refuted).
verdict(c_690c671ef419a089,supported) :- node(n121,supported).
query(verdict(c_690c671ef419a089,supported)).
verdict(c_690c671ef419a089,refuted) :- node(n121,refuted).
query(verdict(c_690c671ef419a089,refuted)).
verdict(c_690c671ef419a089,unknown) :- node(n121,unknown).
query(verdict(c_690c671ef419a089,unknown)).
node(n134,supported) :- status(o_fb5b9995d8d6911b5e75,supported).
node(n134,refuted) :- status(o_fb5b9995d8d6911b5e75,refuted).
node(n134,unknown) :- status(o_fb5b9995d8d6911b5e75,unknown).
node(n135,supported) :- status(o_60b2475da44c32077ec4,supported).
node(n135,refuted) :- status(o_60b2475da44c32077ec4,refuted).
node(n135,unknown) :- status(o_60b2475da44c32077ec4,unknown).
node(n133,supported) :- node(n134,supported), node(n135,supported).
node(n133,refuted) :- node(n134,refuted).
node(n133,refuted) :- node(n135,refuted).
node(n133,unknown) :- \+ node(n133,supported), \+ node(n133,refuted).
node(n137,supported) :- status(o_a57740ee64cfcf484795,supported).
node(n137,refuted) :- status(o_a57740ee64cfcf484795,refuted).
node(n137,unknown) :- status(o_a57740ee64cfcf484795,unknown).
node(n136,supported) :- node(n134,supported), node(n137,supported).
node(n136,refuted) :- node(n134,refuted).
node(n136,refuted) :- node(n137,refuted).
node(n136,unknown) :- \+ node(n136,supported), \+ node(n136,refuted).
node(n139,supported) :- status(o_eb718573e7279ac6bee1,supported).
node(n139,refuted) :- status(o_eb718573e7279ac6bee1,refuted).
node(n139,unknown) :- status(o_eb718573e7279ac6bee1,unknown).
node(n138,supported) :- node(n134,supported), node(n139,supported).
node(n138,refuted) :- node(n134,refuted).
node(n138,refuted) :- node(n139,refuted).
node(n138,unknown) :- \+ node(n138,supported), \+ node(n138,refuted).
node(n140,supported) :- node(n135,supported), node(n137,supported).
node(n140,refuted) :- node(n135,refuted).
node(n140,refuted) :- node(n137,refuted).
node(n140,unknown) :- \+ node(n140,supported), \+ node(n140,refuted).
node(n141,supported) :- node(n135,supported), node(n139,supported).
node(n141,refuted) :- node(n135,refuted).
node(n141,refuted) :- node(n139,refuted).
node(n141,unknown) :- \+ node(n141,supported), \+ node(n141,refuted).
node(n142,supported) :- node(n137,supported), node(n139,supported).
node(n142,refuted) :- node(n137,refuted).
node(n142,refuted) :- node(n139,refuted).
node(n142,unknown) :- \+ node(n142,supported), \+ node(n142,refuted).
node(n132,refuted) :- node(n133,refuted), node(n136,refuted), node(n138,refuted), node(n140,refuted), node(n141,refuted), node(n142,refuted).
node(n132,supported) :- node(n133,supported).
node(n132,supported) :- node(n136,supported).
node(n132,supported) :- node(n138,supported).
node(n132,supported) :- node(n140,supported).
node(n132,supported) :- node(n141,supported).
node(n132,supported) :- node(n142,supported).
node(n132,unknown) :- \+ node(n132,supported), \+ node(n132,refuted).
verdict(c_fb5b9995d8d6911b,supported) :- node(n132,supported).
query(verdict(c_fb5b9995d8d6911b,supported)).
verdict(c_fb5b9995d8d6911b,refuted) :- node(n132,refuted).
query(verdict(c_fb5b9995d8d6911b,refuted)).
verdict(c_fb5b9995d8d6911b,unknown) :- node(n132,unknown).
query(verdict(c_fb5b9995d8d6911b,unknown)).
node(n145,supported) :- node(n134,refuted).
node(n145,refuted) :- node(n134,supported).
node(n145,unknown) :- \+ node(n145,supported), \+ node(n145,refuted).
node(n146,supported) :- node(n135,refuted).
node(n146,refuted) :- node(n135,supported).
node(n146,unknown) :- \+ node(n146,supported), \+ node(n146,refuted).
node(n144,supported) :- node(n145,supported), node(n146,supported).
node(n144,refuted) :- node(n145,refuted).
node(n144,refuted) :- node(n146,refuted).
node(n144,unknown) :- \+ node(n144,supported), \+ node(n144,refuted).
node(n148,supported) :- node(n137,refuted).
node(n148,refuted) :- node(n137,supported).
node(n148,unknown) :- \+ node(n148,supported), \+ node(n148,refuted).
node(n147,supported) :- node(n145,supported), node(n148,supported).
node(n147,refuted) :- node(n145,refuted).
node(n147,refuted) :- node(n148,refuted).
node(n147,unknown) :- \+ node(n147,supported), \+ node(n147,refuted).
node(n150,supported) :- node(n139,refuted).
node(n150,refuted) :- node(n139,supported).
node(n150,unknown) :- \+ node(n150,supported), \+ node(n150,refuted).
node(n149,supported) :- node(n145,supported), node(n150,supported).
node(n149,refuted) :- node(n145,refuted).
node(n149,refuted) :- node(n150,refuted).
node(n149,unknown) :- \+ node(n149,supported), \+ node(n149,refuted).
node(n151,supported) :- node(n146,supported), node(n148,supported).
node(n151,refuted) :- node(n146,refuted).
node(n151,refuted) :- node(n148,refuted).
node(n151,unknown) :- \+ node(n151,supported), \+ node(n151,refuted).
node(n152,supported) :- node(n146,supported), node(n150,supported).
node(n152,refuted) :- node(n146,refuted).
node(n152,refuted) :- node(n150,refuted).
node(n152,unknown) :- \+ node(n152,supported), \+ node(n152,refuted).
node(n153,supported) :- node(n148,supported), node(n150,supported).
node(n153,refuted) :- node(n148,refuted).
node(n153,refuted) :- node(n150,refuted).
node(n153,unknown) :- \+ node(n153,supported), \+ node(n153,refuted).
node(n143,refuted) :- node(n144,refuted), node(n147,refuted), node(n149,refuted), node(n151,refuted), node(n152,refuted), node(n153,refuted).
node(n143,supported) :- node(n144,supported).
node(n143,supported) :- node(n147,supported).
node(n143,supported) :- node(n149,supported).
node(n143,supported) :- node(n151,supported).
node(n143,supported) :- node(n152,supported).
node(n143,supported) :- node(n153,supported).
node(n143,unknown) :- \+ node(n143,supported), \+ node(n143,refuted).
verdict(c_60b2475da44c3207,supported) :- node(n143,supported).
query(verdict(c_60b2475da44c3207,supported)).
verdict(c_60b2475da44c3207,refuted) :- node(n143,refuted).
query(verdict(c_60b2475da44c3207,refuted)).
verdict(c_60b2475da44c3207,unknown) :- node(n143,unknown).
query(verdict(c_60b2475da44c3207,unknown)).
node(n156,supported) :- status(o_797b98dc61c720440025,supported).
node(n156,refuted) :- status(o_797b98dc61c720440025,refuted).
node(n156,unknown) :- status(o_797b98dc61c720440025,unknown).
node(n157,supported) :- status(o_53ceee71b35a9940eb0c,supported).
node(n157,refuted) :- status(o_53ceee71b35a9940eb0c,refuted).
node(n157,unknown) :- status(o_53ceee71b35a9940eb0c,unknown).
node(n155,supported) :- node(n156,supported), node(n157,supported).
node(n155,refuted) :- node(n156,refuted).
node(n155,refuted) :- node(n157,refuted).
node(n155,unknown) :- \+ node(n155,supported), \+ node(n155,refuted).
node(n159,supported) :- status(o_c4ca93e0a86a2929a21e,supported).
node(n159,refuted) :- status(o_c4ca93e0a86a2929a21e,refuted).
node(n159,unknown) :- status(o_c4ca93e0a86a2929a21e,unknown).
node(n158,supported) :- node(n156,supported), node(n159,supported).
node(n158,refuted) :- node(n156,refuted).
node(n158,refuted) :- node(n159,refuted).
node(n158,unknown) :- \+ node(n158,supported), \+ node(n158,refuted).
node(n161,supported) :- status(o_8b9cb8eb18c2cc6d8593,supported).
node(n161,refuted) :- status(o_8b9cb8eb18c2cc6d8593,refuted).
node(n161,unknown) :- status(o_8b9cb8eb18c2cc6d8593,unknown).
node(n160,supported) :- node(n156,supported), node(n161,supported).
node(n160,refuted) :- node(n156,refuted).
node(n160,refuted) :- node(n161,refuted).
node(n160,unknown) :- \+ node(n160,supported), \+ node(n160,refuted).
node(n162,supported) :- node(n157,supported), node(n159,supported).
node(n162,refuted) :- node(n157,refuted).
node(n162,refuted) :- node(n159,refuted).
node(n162,unknown) :- \+ node(n162,supported), \+ node(n162,refuted).
node(n163,supported) :- node(n157,supported), node(n161,supported).
node(n163,refuted) :- node(n157,refuted).
node(n163,refuted) :- node(n161,refuted).
node(n163,unknown) :- \+ node(n163,supported), \+ node(n163,refuted).
node(n164,supported) :- node(n159,supported), node(n161,supported).
node(n164,refuted) :- node(n159,refuted).
node(n164,refuted) :- node(n161,refuted).
node(n164,unknown) :- \+ node(n164,supported), \+ node(n164,refuted).
node(n154,refuted) :- node(n155,refuted), node(n158,refuted), node(n160,refuted), node(n162,refuted), node(n163,refuted), node(n164,refuted).
node(n154,supported) :- node(n155,supported).
node(n154,supported) :- node(n158,supported).
node(n154,supported) :- node(n160,supported).
node(n154,supported) :- node(n162,supported).
node(n154,supported) :- node(n163,supported).
node(n154,supported) :- node(n164,supported).
node(n154,unknown) :- \+ node(n154,supported), \+ node(n154,refuted).
verdict(c_797b98dc61c72044,supported) :- node(n154,supported).
query(verdict(c_797b98dc61c72044,supported)).
verdict(c_797b98dc61c72044,refuted) :- node(n154,refuted).
query(verdict(c_797b98dc61c72044,refuted)).
verdict(c_797b98dc61c72044,unknown) :- node(n154,unknown).
query(verdict(c_797b98dc61c72044,unknown)).
node(n167,supported) :- node(n156,refuted).
node(n167,refuted) :- node(n156,supported).
node(n167,unknown) :- \+ node(n167,supported), \+ node(n167,refuted).
node(n168,supported) :- node(n157,refuted).
node(n168,refuted) :- node(n157,supported).
node(n168,unknown) :- \+ node(n168,supported), \+ node(n168,refuted).
node(n166,supported) :- node(n167,supported), node(n168,supported).
node(n166,refuted) :- node(n167,refuted).
node(n166,refuted) :- node(n168,refuted).
node(n166,unknown) :- \+ node(n166,supported), \+ node(n166,refuted).
node(n170,supported) :- node(n159,refuted).
node(n170,refuted) :- node(n159,supported).
node(n170,unknown) :- \+ node(n170,supported), \+ node(n170,refuted).
node(n169,supported) :- node(n167,supported), node(n170,supported).
node(n169,refuted) :- node(n167,refuted).
node(n169,refuted) :- node(n170,refuted).
node(n169,unknown) :- \+ node(n169,supported), \+ node(n169,refuted).
node(n172,supported) :- node(n161,refuted).
node(n172,refuted) :- node(n161,supported).
node(n172,unknown) :- \+ node(n172,supported), \+ node(n172,refuted).
node(n171,supported) :- node(n167,supported), node(n172,supported).
node(n171,refuted) :- node(n167,refuted).
node(n171,refuted) :- node(n172,refuted).
node(n171,unknown) :- \+ node(n171,supported), \+ node(n171,refuted).
node(n173,supported) :- node(n168,supported), node(n170,supported).
node(n173,refuted) :- node(n168,refuted).
node(n173,refuted) :- node(n170,refuted).
node(n173,unknown) :- \+ node(n173,supported), \+ node(n173,refuted).
node(n174,supported) :- node(n168,supported), node(n172,supported).
node(n174,refuted) :- node(n168,refuted).
node(n174,refuted) :- node(n172,refuted).
node(n174,unknown) :- \+ node(n174,supported), \+ node(n174,refuted).
node(n175,supported) :- node(n170,supported), node(n172,supported).
node(n175,refuted) :- node(n170,refuted).
node(n175,refuted) :- node(n172,refuted).
node(n175,unknown) :- \+ node(n175,supported), \+ node(n175,refuted).
node(n165,refuted) :- node(n166,refuted), node(n169,refuted), node(n171,refuted), node(n173,refuted), node(n174,refuted), node(n175,refuted).
node(n165,supported) :- node(n166,supported).
node(n165,supported) :- node(n169,supported).
node(n165,supported) :- node(n171,supported).
node(n165,supported) :- node(n173,supported).
node(n165,supported) :- node(n174,supported).
node(n165,supported) :- node(n175,supported).
node(n165,unknown) :- \+ node(n165,supported), \+ node(n165,refuted).
verdict(c_53ceee71b35a9940,supported) :- node(n165,supported).
query(verdict(c_53ceee71b35a9940,supported)).
verdict(c_53ceee71b35a9940,refuted) :- node(n165,refuted).
query(verdict(c_53ceee71b35a9940,refuted)).
verdict(c_53ceee71b35a9940,unknown) :- node(n165,unknown).
query(verdict(c_53ceee71b35a9940,unknown)).
node(n178,supported) :- status(o_1cf643d8879406bdec7b,supported).
node(n178,refuted) :- status(o_1cf643d8879406bdec7b,refuted).
node(n178,unknown) :- status(o_1cf643d8879406bdec7b,unknown).
node(n179,supported) :- status(o_c72cd2ce3128f4c363ad,supported).
node(n179,refuted) :- status(o_c72cd2ce3128f4c363ad,refuted).
node(n179,unknown) :- status(o_c72cd2ce3128f4c363ad,unknown).
node(n177,supported) :- node(n178,supported), node(n179,supported).
node(n177,refuted) :- node(n178,refuted).
node(n177,refuted) :- node(n179,refuted).
node(n177,unknown) :- \+ node(n177,supported), \+ node(n177,refuted).
node(n181,supported) :- status(o_beac6773ac4622d9953e,supported).
node(n181,refuted) :- status(o_beac6773ac4622d9953e,refuted).
node(n181,unknown) :- status(o_beac6773ac4622d9953e,unknown).
node(n180,supported) :- node(n178,supported), node(n181,supported).
node(n180,refuted) :- node(n178,refuted).
node(n180,refuted) :- node(n181,refuted).
node(n180,unknown) :- \+ node(n180,supported), \+ node(n180,refuted).
node(n182,supported) :- node(n179,supported), node(n181,supported).
node(n182,refuted) :- node(n179,refuted).
node(n182,refuted) :- node(n181,refuted).
node(n182,unknown) :- \+ node(n182,supported), \+ node(n182,refuted).
node(n176,refuted) :- node(n177,refuted), node(n180,refuted), node(n182,refuted).
node(n176,supported) :- node(n177,supported).
node(n176,supported) :- node(n180,supported).
node(n176,supported) :- node(n182,supported).
node(n176,unknown) :- \+ node(n176,supported), \+ node(n176,refuted).
verdict(c_1cf643d8879406bd,supported) :- node(n176,supported).
query(verdict(c_1cf643d8879406bd,supported)).
verdict(c_1cf643d8879406bd,refuted) :- node(n176,refuted).
query(verdict(c_1cf643d8879406bd,refuted)).
verdict(c_1cf643d8879406bd,unknown) :- node(n176,unknown).
query(verdict(c_1cf643d8879406bd,unknown)).
node(n185,supported) :- node(n178,refuted).
node(n185,refuted) :- node(n178,supported).
node(n185,unknown) :- \+ node(n185,supported), \+ node(n185,refuted).
node(n186,supported) :- node(n179,refuted).
node(n186,refuted) :- node(n179,supported).
node(n186,unknown) :- \+ node(n186,supported), \+ node(n186,refuted).
node(n184,supported) :- node(n185,supported), node(n186,supported).
node(n184,refuted) :- node(n185,refuted).
node(n184,refuted) :- node(n186,refuted).
node(n184,unknown) :- \+ node(n184,supported), \+ node(n184,refuted).
node(n188,supported) :- node(n181,refuted).
node(n188,refuted) :- node(n181,supported).
node(n188,unknown) :- \+ node(n188,supported), \+ node(n188,refuted).
node(n187,supported) :- node(n185,supported), node(n188,supported).
node(n187,refuted) :- node(n185,refuted).
node(n187,refuted) :- node(n188,refuted).
node(n187,unknown) :- \+ node(n187,supported), \+ node(n187,refuted).
node(n189,supported) :- node(n186,supported), node(n188,supported).
node(n189,refuted) :- node(n186,refuted).
node(n189,refuted) :- node(n188,refuted).
node(n189,unknown) :- \+ node(n189,supported), \+ node(n189,refuted).
node(n183,refuted) :- node(n184,refuted), node(n187,refuted), node(n189,refuted).
node(n183,supported) :- node(n184,supported).
node(n183,supported) :- node(n187,supported).
node(n183,supported) :- node(n189,supported).
node(n183,unknown) :- \+ node(n183,supported), \+ node(n183,refuted).
verdict(c_c72cd2ce3128f4c3,supported) :- node(n183,supported).
query(verdict(c_c72cd2ce3128f4c3,supported)).
verdict(c_c72cd2ce3128f4c3,refuted) :- node(n183,refuted).
query(verdict(c_c72cd2ce3128f4c3,refuted)).
verdict(c_c72cd2ce3128f4c3,unknown) :- node(n183,unknown).
query(verdict(c_c72cd2ce3128f4c3,unknown)).
node(n192,supported) :- status(o_6a7440c5567322095f19,supported).
node(n192,refuted) :- status(o_6a7440c5567322095f19,refuted).
node(n192,unknown) :- status(o_6a7440c5567322095f19,unknown).
node(n193,supported) :- status(o_dc3aee049066733f931f,supported).
node(n193,refuted) :- status(o_dc3aee049066733f931f,refuted).
node(n193,unknown) :- status(o_dc3aee049066733f931f,unknown).
node(n191,supported) :- node(n192,supported), node(n193,supported).
node(n191,refuted) :- node(n192,refuted).
node(n191,refuted) :- node(n193,refuted).
node(n191,unknown) :- \+ node(n191,supported), \+ node(n191,refuted).
node(n195,supported) :- status(o_189a1840b83a8fd30600,supported).
node(n195,refuted) :- status(o_189a1840b83a8fd30600,refuted).
node(n195,unknown) :- status(o_189a1840b83a8fd30600,unknown).
node(n194,supported) :- node(n192,supported), node(n195,supported).
node(n194,refuted) :- node(n192,refuted).
node(n194,refuted) :- node(n195,refuted).
node(n194,unknown) :- \+ node(n194,supported), \+ node(n194,refuted).
node(n196,supported) :- node(n193,supported), node(n195,supported).
node(n196,refuted) :- node(n193,refuted).
node(n196,refuted) :- node(n195,refuted).
node(n196,unknown) :- \+ node(n196,supported), \+ node(n196,refuted).
node(n190,refuted) :- node(n191,refuted), node(n194,refuted), node(n196,refuted).
node(n190,supported) :- node(n191,supported).
node(n190,supported) :- node(n194,supported).
node(n190,supported) :- node(n196,supported).
node(n190,unknown) :- \+ node(n190,supported), \+ node(n190,refuted).
verdict(c_6a7440c556732209,supported) :- node(n190,supported).
query(verdict(c_6a7440c556732209,supported)).
verdict(c_6a7440c556732209,refuted) :- node(n190,refuted).
query(verdict(c_6a7440c556732209,refuted)).
verdict(c_6a7440c556732209,unknown) :- node(n190,unknown).
query(verdict(c_6a7440c556732209,unknown)).
node(n199,supported) :- node(n192,refuted).
node(n199,refuted) :- node(n192,supported).
node(n199,unknown) :- \+ node(n199,supported), \+ node(n199,refuted).
node(n200,supported) :- node(n193,refuted).
node(n200,refuted) :- node(n193,supported).
node(n200,unknown) :- \+ node(n200,supported), \+ node(n200,refuted).
node(n198,supported) :- node(n199,supported), node(n200,supported).
node(n198,refuted) :- node(n199,refuted).
node(n198,refuted) :- node(n200,refuted).
node(n198,unknown) :- \+ node(n198,supported), \+ node(n198,refuted).
node(n202,supported) :- node(n195,refuted).
node(n202,refuted) :- node(n195,supported).
node(n202,unknown) :- \+ node(n202,supported), \+ node(n202,refuted).
node(n201,supported) :- node(n199,supported), node(n202,supported).
node(n201,refuted) :- node(n199,refuted).
node(n201,refuted) :- node(n202,refuted).
node(n201,unknown) :- \+ node(n201,supported), \+ node(n201,refuted).
node(n203,supported) :- node(n200,supported), node(n202,supported).
node(n203,refuted) :- node(n200,refuted).
node(n203,refuted) :- node(n202,refuted).
node(n203,unknown) :- \+ node(n203,supported), \+ node(n203,refuted).
node(n197,refuted) :- node(n198,refuted), node(n201,refuted), node(n203,refuted).
node(n197,supported) :- node(n198,supported).
node(n197,supported) :- node(n201,supported).
node(n197,supported) :- node(n203,supported).
node(n197,unknown) :- \+ node(n197,supported), \+ node(n197,refuted).
verdict(c_dc3aee049066733f,supported) :- node(n197,supported).
query(verdict(c_dc3aee049066733f,supported)).
verdict(c_dc3aee049066733f,refuted) :- node(n197,refuted).
query(verdict(c_dc3aee049066733f,refuted)).
verdict(c_dc3aee049066733f,unknown) :- node(n197,unknown).
query(verdict(c_dc3aee049066733f,unknown)).
