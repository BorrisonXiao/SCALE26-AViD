% Exact categorical evidence; internal unknown = neither supported nor refuted.
1::status(o_009d49cbadd2fcfab008,supported); 0::status(o_009d49cbadd2fcfab008,refuted); 0::status(o_009d49cbadd2fcfab008,unknown).
0.9814574122428894::status(o_00a289a3cedd0ca402bf,supported); 0::status(o_00a289a3cedd0ca402bf,refuted); 0.018542587757110596::status(o_00a289a3cedd0ca402bf,unknown).
1::status(o_00a49d6062a2c3a315c7,supported); 0::status(o_00a49d6062a2c3a315c7,refuted); 0::status(o_00a49d6062a2c3a315c7,unknown).
1::status(o_00b90b65f56cb6d43ce2,supported); 0::status(o_00b90b65f56cb6d43ce2,refuted); 0::status(o_00b90b65f56cb6d43ce2,unknown).
1::status(o_00e84f3386f7981d363a,supported); 0::status(o_00e84f3386f7981d363a,refuted); 0::status(o_00e84f3386f7981d363a,unknown).
0.001097465050406754::status(o_0120afb530917478f5b4,supported); 0::status(o_0120afb530917478f5b4,refuted); 0.99890253494959325::status(o_0120afb530917478f5b4,unknown).
0.99447786808013916::status(o_01764e82499f5cd52ea4,supported); 0::status(o_01764e82499f5cd52ea4,refuted); 0.0055221319198608398::status(o_01764e82499f5cd52ea4,unknown).
0.28751092054261485::status(o_020f591c4e6a62bcd58d,supported); 0::status(o_020f591c4e6a62bcd58d,refuted); 0.71248907945738515::status(o_020f591c4e6a62bcd58d,unknown).
1::status(o_02a368cb5b9b36ce5fc1,supported); 0::status(o_02a368cb5b9b36ce5fc1,refuted); 0::status(o_02a368cb5b9b36ce5fc1,unknown).
1::status(o_02f8a48ab6b74937c9d3,supported); 0::status(o_02f8a48ab6b74937c9d3,refuted); 0::status(o_02f8a48ab6b74937c9d3,unknown).
1::status(o_03017c3ce36bb07ecc71,supported); 0::status(o_03017c3ce36bb07ecc71,refuted); 0::status(o_03017c3ce36bb07ecc71,unknown).
1::status(o_03056a50380814f9afc3,supported); 0::status(o_03056a50380814f9afc3,refuted); 0::status(o_03056a50380814f9afc3,unknown).
1::status(o_032d682d1b49d19d74da,supported); 0::status(o_032d682d1b49d19d74da,refuted); 0::status(o_032d682d1b49d19d74da,unknown).
1::status(o_0359969dc6f1835db0e0,supported); 0::status(o_0359969dc6f1835db0e0,refuted); 0::status(o_0359969dc6f1835db0e0,unknown).
0::status(o_038ecd395bdd41c1d344,supported); 0::status(o_038ecd395bdd41c1d344,refuted); 1::status(o_038ecd395bdd41c1d344,unknown).
0.037853103131055832::status(o_039c1d10356f1e16e83b,supported); 0::status(o_039c1d10356f1e16e83b,refuted); 0.96214689686894417::status(o_039c1d10356f1e16e83b,unknown).
5.6390664903726097e-08::status(o_03aec88a8a8cdf6c9150,supported); 0::status(o_03aec88a8a8cdf6c9150,refuted); 0.99999994360933508::status(o_03aec88a8a8cdf6c9150,unknown).
1::status(o_0422afe210a6634a74b7,supported); 0::status(o_0422afe210a6634a74b7,refuted); 0::status(o_0422afe210a6634a74b7,unknown).
0.99213320016860962::status(o_045aaf59e47a1322b521,supported); 0::status(o_045aaf59e47a1322b521,refuted); 0.0078667998313903809::status(o_045aaf59e47a1322b521,unknown).
0::status(o_046299b5b9dc9d6173fc,supported); 1::status(o_046299b5b9dc9d6173fc,refuted); 0::status(o_046299b5b9dc9d6173fc,unknown).
0::status(o_0463a4e8b051fb3bcd88,supported); 1::status(o_0463a4e8b051fb3bcd88,refuted); 0::status(o_0463a4e8b051fb3bcd88,unknown).
1::status(o_049a81424d015bb5f479,supported); 0::status(o_049a81424d015bb5f479,refuted); 0::status(o_049a81424d015bb5f479,unknown).
1::status(o_04a3f7e0d8b23dfaae7c,supported); 0::status(o_04a3f7e0d8b23dfaae7c,refuted); 0::status(o_04a3f7e0d8b23dfaae7c,unknown).
0.99738341569900513::status(o_04d9a716b3f3eef7ef6a,supported); 0::status(o_04d9a716b3f3eef7ef6a,refuted); 0.002616584300994873::status(o_04d9a716b3f3eef7ef6a,unknown).
1::status(o_04ec26e4efdcab4c47ff,supported); 0::status(o_04ec26e4efdcab4c47ff,refuted); 0::status(o_04ec26e4efdcab4c47ff,unknown).
0.002940004225820303::status(o_05163a2a5ac9f6ca2f69,supported); 0::status(o_05163a2a5ac9f6ca2f69,refuted); 0.9970599957741797::status(o_05163a2a5ac9f6ca2f69,unknown).
1::status(o_052f6eec21cba5fac7b3,supported); 0::status(o_052f6eec21cba5fac7b3,refuted); 0::status(o_052f6eec21cba5fac7b3,unknown).
0::status(o_055e122bc274eb1317e4,supported); 1::status(o_055e122bc274eb1317e4,refuted); 0::status(o_055e122bc274eb1317e4,unknown).
1::status(o_0576e51cb53cf034be80,supported); 0::status(o_0576e51cb53cf034be80,refuted); 0::status(o_0576e51cb53cf034be80,unknown).
0.99737107753753662::status(o_06058e0e09d07f718e88,supported); 0::status(o_06058e0e09d07f718e88,refuted); 0.0026289224624633789::status(o_06058e0e09d07f718e88,unknown).
5.7750552951804822e-05::status(o_060bf76258d0a00c3a21,supported); 0::status(o_060bf76258d0a00c3a21,refuted); 0.99994224944704824::status(o_060bf76258d0a00c3a21,unknown).
0.98212242126464844::status(o_0617943eb68e06303c49,supported); 0::status(o_0617943eb68e06303c49,refuted); 0.017877578735351562::status(o_0617943eb68e06303c49,unknown).
1::status(o_067b95cdf0df9fb8f0d6,supported); 0::status(o_067b95cdf0df9fb8f0d6,refuted); 0::status(o_067b95cdf0df9fb8f0d6,unknown).
1::status(o_069180ef500cda84f7a2,supported); 0::status(o_069180ef500cda84f7a2,refuted); 0::status(o_069180ef500cda84f7a2,unknown).
0::status(o_06a51d14cf9be6e26c38,supported); 1::status(o_06a51d14cf9be6e26c38,refuted); 0::status(o_06a51d14cf9be6e26c38,unknown).
1::status(o_06ad9a6e83639f2d964d,supported); 0::status(o_06ad9a6e83639f2d964d,refuted); 0::status(o_06ad9a6e83639f2d964d,unknown).
0.9814574122428894::status(o_06b8e795c32eb0920560,supported); 0::status(o_06b8e795c32eb0920560,refuted); 0.018542587757110596::status(o_06b8e795c32eb0920560,unknown).
1::status(o_06d0d73af4ce63709ebc,supported); 0::status(o_06d0d73af4ce63709ebc,refuted); 0::status(o_06d0d73af4ce63709ebc,unknown).
1::status(o_06d138357f91f3d2e7dd,supported); 0::status(o_06d138357f91f3d2e7dd,refuted); 0::status(o_06d138357f91f3d2e7dd,unknown).
0.99680787324905396::status(o_06f4c3c63d089185df2e,supported); 0::status(o_06f4c3c63d089185df2e,refuted); 0.0031921267509460449::status(o_06f4c3c63d089185df2e,unknown).
0.976348876953125::status(o_072c0accf387c3fb5a40,supported); 0::status(o_072c0accf387c3fb5a40,refuted); 0.023651123046875::status(o_072c0accf387c3fb5a40,unknown).
0.00011525061563588679::status(o_075ed942a82e2b7cd60a,supported); 0::status(o_075ed942a82e2b7cd60a,refuted); 0.99988474938436411::status(o_075ed942a82e2b7cd60a,unknown).
0::status(o_077bf51dc0af9b66c63c,supported); 0::status(o_077bf51dc0af9b66c63c,refuted); 1::status(o_077bf51dc0af9b66c63c,unknown).
1::status(o_07b2ea52aa9594bb1712,supported); 0::status(o_07b2ea52aa9594bb1712,refuted); 0::status(o_07b2ea52aa9594bb1712,unknown).
0.99577623605728149::status(o_0811959c9dfe24d15a88,supported); 0::status(o_0811959c9dfe24d15a88,refuted); 0.0042237639427185059::status(o_0811959c9dfe24d15a88,unknown).
1::status(o_085560713cb1a8b43154,supported); 0::status(o_085560713cb1a8b43154,refuted); 0::status(o_085560713cb1a8b43154,unknown).
0::status(o_08cded7ba7857446182b,supported); 1::status(o_08cded7ba7857446182b,refuted); 0::status(o_08cded7ba7857446182b,unknown).
0.00085279322229325771::status(o_090484686e13eacb0b74,supported); 0::status(o_090484686e13eacb0b74,refuted); 0.99914720677770674::status(o_090484686e13eacb0b74,unknown).
0.00011525061563588679::status(o_091dfef35f2ba6af6b62,supported); 0::status(o_091dfef35f2ba6af6b62,refuted); 0.99988474938436411::status(o_091dfef35f2ba6af6b62,unknown).
0.002940004225820303::status(o_0949e4af098b9e5ef9e3,supported); 0::status(o_0949e4af098b9e5ef9e3,refuted); 0.9970599957741797::status(o_0949e4af098b9e5ef9e3,unknown).
0::status(o_094b461de82acccc01fa,supported); 1::status(o_094b461de82acccc01fa,refuted); 0::status(o_094b461de82acccc01fa,unknown).
0.002940004225820303::status(o_0967bea190ae32f9ef6b,supported); 0::status(o_0967bea190ae32f9ef6b,refuted); 0.9970599957741797::status(o_0967bea190ae32f9ef6b,unknown).
1::status(o_0996f82f7930e7004422,supported); 0::status(o_0996f82f7930e7004422,refuted); 0::status(o_0996f82f7930e7004422,unknown).
1::status(o_0a027f17307007525801,supported); 0::status(o_0a027f17307007525801,refuted); 0::status(o_0a027f17307007525801,unknown).
1::status(o_0a2580a433b8d0ef3b0c,supported); 0::status(o_0a2580a433b8d0ef3b0c,refuted); 0::status(o_0a2580a433b8d0ef3b0c,unknown).
1::status(o_0a320a39b6c45586701d,supported); 0::status(o_0a320a39b6c45586701d,refuted); 0::status(o_0a320a39b6c45586701d,unknown).
1::status(o_0a90630f8ae8493f2e41,supported); 0::status(o_0a90630f8ae8493f2e41,refuted); 0::status(o_0a90630f8ae8493f2e41,unknown).
1::status(o_0abb8855c2588967d11c,supported); 0::status(o_0abb8855c2588967d11c,refuted); 0::status(o_0abb8855c2588967d11c,unknown).
0.976348876953125::status(o_0ae358e24eb201d4d42f,supported); 0::status(o_0ae358e24eb201d4d42f,refuted); 0.023651123046875::status(o_0ae358e24eb201d4d42f,unknown).
0::status(o_0b3484ac141e66dd06f4,supported); 1::status(o_0b3484ac141e66dd06f4,refuted); 0::status(o_0b3484ac141e66dd06f4,unknown).
0.99999939047324271::status(o_0b546e874d9b2546b21f,supported); 0::status(o_0b546e874d9b2546b21f,refuted); 6.0952675728920269e-07::status(o_0b546e874d9b2546b21f,unknown).
1::status(o_0b581073e8b6ed33e96c,supported); 0::status(o_0b581073e8b6ed33e96c,refuted); 0::status(o_0b581073e8b6ed33e96c,unknown).
1::status(o_0b73b9c8b9d80db7b645,supported); 0::status(o_0b73b9c8b9d80db7b645,refuted); 0::status(o_0b73b9c8b9d80db7b645,unknown).
0.99213320016860962::status(o_0b8a594e2384acef8925,supported); 0::status(o_0b8a594e2384acef8925,refuted); 0.0078667998313903809::status(o_0b8a594e2384acef8925,unknown).
1::status(o_0bf50896b2537f2f80ed,supported); 0::status(o_0bf50896b2537f2f80ed,refuted); 0::status(o_0bf50896b2537f2f80ed,unknown).
1::status(o_0c5a452ab1ce4be48585,supported); 0::status(o_0c5a452ab1ce4be48585,refuted); 0::status(o_0c5a452ab1ce4be48585,unknown).
0.99447786808013916::status(o_0ccc8cbdd5c7ab1cf9f1,supported); 0::status(o_0ccc8cbdd5c7ab1cf9f1,refuted); 0.0055221319198608398::status(o_0ccc8cbdd5c7ab1cf9f1,unknown).
0::status(o_0cf0db8bf43a64f73a20,supported); 1::status(o_0cf0db8bf43a64f73a20,refuted); 0::status(o_0cf0db8bf43a64f73a20,unknown).
1::status(o_0d8984f9ba9ba9247e34,supported); 0::status(o_0d8984f9ba9ba9247e34,refuted); 0::status(o_0d8984f9ba9ba9247e34,unknown).
1::status(o_0dc24c3f760494fb2fb7,supported); 0::status(o_0dc24c3f760494fb2fb7,refuted); 0::status(o_0dc24c3f760494fb2fb7,unknown).
1::status(o_0dee611c29be95170142,supported); 0::status(o_0dee611c29be95170142,refuted); 0::status(o_0dee611c29be95170142,unknown).
1::status(o_0e0f03537c26da468806,supported); 0::status(o_0e0f03537c26da468806,refuted); 0::status(o_0e0f03537c26da468806,unknown).
1::status(o_0e54fb7b33e084854261,supported); 0::status(o_0e54fb7b33e084854261,refuted); 0::status(o_0e54fb7b33e084854261,unknown).
1::status(o_0e93c7cbc4607f03cdb8,supported); 0::status(o_0e93c7cbc4607f03cdb8,refuted); 0::status(o_0e93c7cbc4607f03cdb8,unknown).
1::status(o_0ee395ddf83ac9b9f901,supported); 0::status(o_0ee395ddf83ac9b9f901,refuted); 0::status(o_0ee395ddf83ac9b9f901,unknown).
1::status(o_0ef255dcd24b4d1f7d48,supported); 0::status(o_0ef255dcd24b4d1f7d48,refuted); 0::status(o_0ef255dcd24b4d1f7d48,unknown).
1::status(o_0ef8926f1071064c5e2b,supported); 0::status(o_0ef8926f1071064c5e2b,refuted); 0::status(o_0ef8926f1071064c5e2b,unknown).
1::status(o_0f4bf2f9a6f872685f8a,supported); 0::status(o_0f4bf2f9a6f872685f8a,refuted); 0::status(o_0f4bf2f9a6f872685f8a,unknown).
0::status(o_0f63a1ff8cd74af06bb0,supported); 0::status(o_0f63a1ff8cd74af06bb0,refuted); 1::status(o_0f63a1ff8cd74af06bb0,unknown).
0.98928332328796387::status(o_0fb3afbed6a16d0c028e,supported); 0::status(o_0fb3afbed6a16d0c028e,refuted); 0.010716676712036133::status(o_0fb3afbed6a16d0c028e,unknown).
1::status(o_0fddd8517a5e66afab4a,supported); 0::status(o_0fddd8517a5e66afab4a,refuted); 0::status(o_0fddd8517a5e66afab4a,unknown).
1::status(o_0ffac10cdd3422dc5139,supported); 0::status(o_0ffac10cdd3422dc5139,refuted); 0::status(o_0ffac10cdd3422dc5139,unknown).
1::status(o_101eaa5b25466317589b,supported); 0::status(o_101eaa5b25466317589b,refuted); 0::status(o_101eaa5b25466317589b,unknown).
0.99172943830490112::status(o_103c13e684d1509163ce,supported); 0::status(o_103c13e684d1509163ce,refuted); 0.008270561695098877::status(o_103c13e684d1509163ce,unknown).
1::status(o_1066fcea5c37414e3c57,supported); 0::status(o_1066fcea5c37414e3c57,refuted); 0::status(o_1066fcea5c37414e3c57,unknown).
0.00011525061563588679::status(o_10941fe54afdc04955f5,supported); 0::status(o_10941fe54afdc04955f5,refuted); 0.99988474938436411::status(o_10941fe54afdc04955f5,unknown).
0.9888228178024292::status(o_10cd29128fa9024e07cf,supported); 0::status(o_10cd29128fa9024e07cf,refuted); 0.011177182197570801::status(o_10cd29128fa9024e07cf,unknown).
0.00085279322229325771::status(o_10f6423084d140b6851a,supported); 0::status(o_10f6423084d140b6851a,refuted); 0.99914720677770674::status(o_10f6423084d140b6851a,unknown).
0.00027316782507114112::status(o_1115de17296796d6eda5,supported); 0::status(o_1115de17296796d6eda5,refuted); 0.99972683217492886::status(o_1115de17296796d6eda5,unknown).
0.99213320016860962::status(o_112e2a0d652ec3539bda,supported); 0::status(o_112e2a0d652ec3539bda,refuted); 0.0078667998313903809::status(o_112e2a0d652ec3539bda,unknown).
0::status(o_11470391c022fda6ef9e,supported); 1::status(o_11470391c022fda6ef9e,refuted); 0::status(o_11470391c022fda6ef9e,unknown).
0.9888228178024292::status(o_114b6fee83ab718a4c3e,supported); 0::status(o_114b6fee83ab718a4c3e,refuted); 0.011177182197570801::status(o_114b6fee83ab718a4c3e,unknown).
0.0001668355253059417::status(o_115d8c60f2e94f47a1e8,supported); 0::status(o_115d8c60f2e94f47a1e8,refuted); 0.99983316447469406::status(o_115d8c60f2e94f47a1e8,unknown).
1::status(o_115e911fb1b8436b7821,supported); 0::status(o_115e911fb1b8436b7821,refuted); 0::status(o_115e911fb1b8436b7821,unknown).
1::status(o_12096bdf1014ffd4077d,supported); 0::status(o_12096bdf1014ffd4077d,refuted); 0::status(o_12096bdf1014ffd4077d,unknown).
1::status(o_1224741dccf4df4fc0dd,supported); 0::status(o_1224741dccf4df4fc0dd,refuted); 0::status(o_1224741dccf4df4fc0dd,unknown).
1::status(o_123b645049041f11345d,supported); 0::status(o_123b645049041f11345d,refuted); 0::status(o_123b645049041f11345d,unknown).
1::status(o_12ea7062cfa833ba3c85,supported); 0::status(o_12ea7062cfa833ba3c85,refuted); 0::status(o_12ea7062cfa833ba3c85,unknown).
1::status(o_12f2bae4a8a458df64ed,supported); 0::status(o_12f2bae4a8a458df64ed,refuted); 0::status(o_12f2bae4a8a458df64ed,unknown).
0::status(o_1322ae48ea8a05a3baa6,supported); 1::status(o_1322ae48ea8a05a3baa6,refuted); 0::status(o_1322ae48ea8a05a3baa6,unknown).
1::status(o_136a8d00ed287c269195,supported); 0::status(o_136a8d00ed287c269195,refuted); 0::status(o_136a8d00ed287c269195,unknown).
1::status(o_13b21106dd45753657d8,supported); 0::status(o_13b21106dd45753657d8,refuted); 0::status(o_13b21106dd45753657d8,unknown).
1::status(o_13b966bcfccc11a88483,supported); 0::status(o_13b966bcfccc11a88483,refuted); 0::status(o_13b966bcfccc11a88483,unknown).
1::status(o_140108997bc4d4f0bc72,supported); 0::status(o_140108997bc4d4f0bc72,refuted); 0::status(o_140108997bc4d4f0bc72,unknown).
0.999999966881435::status(o_140c44e3c3bc1d78de4b,supported); 0::status(o_140c44e3c3bc1d78de4b,refuted); 3.3118565001544198e-08::status(o_140c44e3c3bc1d78de4b,unknown).
0.0023976406082510948::status(o_148ea4c38a3b4751c91d,supported); 0::status(o_148ea4c38a3b4751c91d,refuted); 0.99760235939174891::status(o_148ea4c38a3b4751c91d,unknown).
1::status(o_14af9463427e5ae1beea,supported); 0::status(o_14af9463427e5ae1beea,refuted); 0::status(o_14af9463427e5ae1beea,unknown).
0.98997622728347778::status(o_14c8bac5d590172949bb,supported); 0::status(o_14c8bac5d590172949bb,refuted); 0.010023772716522217::status(o_14c8bac5d590172949bb,unknown).
0.99185353517532349::status(o_14e0e73a59cb6610f98c,supported); 0::status(o_14e0e73a59cb6610f98c,refuted); 0.0081464648246765137::status(o_14e0e73a59cb6610f98c,unknown).
1::status(o_15488ab1a7cec7f44a95,supported); 0::status(o_15488ab1a7cec7f44a95,refuted); 0::status(o_15488ab1a7cec7f44a95,unknown).
1::status(o_155eff17059105cd37fe,supported); 0::status(o_155eff17059105cd37fe,refuted); 0::status(o_155eff17059105cd37fe,unknown).
0.99999996709064987::status(o_157f7f5e4c01bbaa6ce8,supported); 0::status(o_157f7f5e4c01bbaa6ce8,refuted); 3.2909350133891735e-08::status(o_157f7f5e4c01bbaa6ce8,unknown).
0::status(o_1582d31449aad38a0ceb,supported); 1::status(o_1582d31449aad38a0ceb,refuted); 0::status(o_1582d31449aad38a0ceb,unknown).
1::status(o_15a0e9413475ec5d02f5,supported); 0::status(o_15a0e9413475ec5d02f5,refuted); 0::status(o_15a0e9413475ec5d02f5,unknown).
0.0023976406082510948::status(o_15a8dfa19cf7b1f1c856,supported); 0::status(o_15a8dfa19cf7b1f1c856,refuted); 0.99760235939174891::status(o_15a8dfa19cf7b1f1c856,unknown).
0.99185353517532349::status(o_15c1e274791c21dc484c,supported); 0::status(o_15c1e274791c21dc484c,refuted); 0.0081464648246765137::status(o_15c1e274791c21dc484c,unknown).
0.039551112800836563::status(o_15eaf91babc7eaba92b2,supported); 0::status(o_15eaf91babc7eaba92b2,refuted); 0.96044888719916344::status(o_15eaf91babc7eaba92b2,unknown).
0.002940004225820303::status(o_1626d63b45f5b4234a7e,supported); 0::status(o_1626d63b45f5b4234a7e,refuted); 0.9970599957741797::status(o_1626d63b45f5b4234a7e,unknown).
0::status(o_16618e7be493465642a4,supported); 1::status(o_16618e7be493465642a4,refuted); 0::status(o_16618e7be493465642a4,unknown).
1::status(o_1664bb1b29db19185da0,supported); 0::status(o_1664bb1b29db19185da0,refuted); 0::status(o_1664bb1b29db19185da0,unknown).
0.0041071532961066259::status(o_16880d75a3a7b9799823,supported); 0::status(o_16880d75a3a7b9799823,refuted); 0.99589284670389333::status(o_16880d75a3a7b9799823,unknown).
0::status(o_1695e57a2440e2a079e4,supported); 1::status(o_1695e57a2440e2a079e4,refuted); 0::status(o_1695e57a2440e2a079e4,unknown).
1::status(o_169d8defe6d6ea549462,supported); 0::status(o_169d8defe6d6ea549462,refuted); 0::status(o_169d8defe6d6ea549462,unknown).
1::status(o_16d196355fcc35ded997,supported); 0::status(o_16d196355fcc35ded997,refuted); 0::status(o_16d196355fcc35ded997,unknown).
0.99981849066906681::status(o_17d1744f7d1b60deb409,supported); 0::status(o_17d1744f7d1b60deb409,refuted); 0.00018150933093319388::status(o_17d1744f7d1b60deb409,unknown).
0.0070033296942710876::status(o_1866200c7746e3f97de8,supported); 0::status(o_1866200c7746e3f97de8,refuted); 0.99299667030572891::status(o_1866200c7746e3f97de8,unknown).
0.99093681573867798::status(o_1866b1ec2beadfe3fcfe,supported); 0::status(o_1866b1ec2beadfe3fcfe,refuted); 0.0090631842613220215::status(o_1866b1ec2beadfe3fcfe,unknown).
0.001097465050406754::status(o_18d9999d11ac1d090f84,supported); 0::status(o_18d9999d11ac1d090f84,refuted); 0.99890253494959325::status(o_18d9999d11ac1d090f84,unknown).
1::status(o_197e960d7be26ccea89f,supported); 0::status(o_197e960d7be26ccea89f,refuted); 0::status(o_197e960d7be26ccea89f,unknown).
0.9814574122428894::status(o_19ea84cfc61d9ad96c7d,supported); 0::status(o_19ea84cfc61d9ad96c7d,refuted); 0.018542587757110596::status(o_19ea84cfc61d9ad96c7d,unknown).
0::status(o_19f36f5b09e9ab099ea4,supported); 1::status(o_19f36f5b09e9ab099ea4,refuted); 0::status(o_19f36f5b09e9ab099ea4,unknown).
0::status(o_1a04a8b325d1d98f1eac,supported); 0::status(o_1a04a8b325d1d98f1eac,refuted); 1::status(o_1a04a8b325d1d98f1eac,unknown).
1::status(o_1a54aa9ccf831515f3e7,supported); 0::status(o_1a54aa9ccf831515f3e7,refuted); 0::status(o_1a54aa9ccf831515f3e7,unknown).
1::status(o_1acc58b760821bed93fa,supported); 0::status(o_1acc58b760821bed93fa,refuted); 0::status(o_1acc58b760821bed93fa,unknown).
0::status(o_1ae70ed557b31fd76040,supported); 1::status(o_1ae70ed557b31fd76040,refuted); 0::status(o_1ae70ed557b31fd76040,unknown).
0.99964323617997897::status(o_1b1d1b1988830aebfadf,supported); 0::status(o_1b1d1b1988830aebfadf,refuted); 0.00035676382002103324::status(o_1b1d1b1988830aebfadf,unknown).
1::status(o_1b3f0defcf3f665388d3,supported); 0::status(o_1b3f0defcf3f665388d3,refuted); 0::status(o_1b3f0defcf3f665388d3,unknown).
0.00011422050738474354::status(o_1b5a0146b5194e923661,supported); 0::status(o_1b5a0146b5194e923661,refuted); 0.99988577949261526::status(o_1b5a0146b5194e923661,unknown).
0.99999882968458842::status(o_1b6372b3d5e324e108ce,supported); 0::status(o_1b6372b3d5e324e108ce,refuted); 1.1703154115805248e-06::status(o_1b6372b3d5e324e108ce,unknown).
0.98913842439651489::status(o_1bfe67fc072ab79c8012,supported); 0::status(o_1bfe67fc072ab79c8012,refuted); 0.010861575603485107::status(o_1bfe67fc072ab79c8012,unknown).
0::status(o_1c85d9248b48db909bd8,supported); 1::status(o_1c85d9248b48db909bd8,refuted); 0::status(o_1c85d9248b48db909bd8,unknown).
0::status(o_1ceb53b4a10a944203e2,supported); 1::status(o_1ceb53b4a10a944203e2,refuted); 0::status(o_1ceb53b4a10a944203e2,unknown).
0.96754372119903564::status(o_1d378b9fe764c3a2032c,supported); 0::status(o_1d378b9fe764c3a2032c,refuted); 0.032456278800964355::status(o_1d378b9fe764c3a2032c,unknown).
0.001097465050406754::status(o_1d7ae98b073e697469bb,supported); 0::status(o_1d7ae98b073e697469bb,refuted); 0.99890253494959325::status(o_1d7ae98b073e697469bb,unknown).
0.0041071532961066259::status(o_1da06c2c709b91e03edb,supported); 0::status(o_1da06c2c709b91e03edb,refuted); 0.99589284670389333::status(o_1da06c2c709b91e03edb,unknown).
0.00027316782507114112::status(o_1da4d5282dc93a6627f9,supported); 0::status(o_1da4d5282dc93a6627f9,refuted); 0.99972683217492886::status(o_1da4d5282dc93a6627f9,unknown).
1::status(o_1dccba490d4ea65f9a73,supported); 0::status(o_1dccba490d4ea65f9a73,refuted); 0::status(o_1dccba490d4ea65f9a73,unknown).
1::status(o_1de2423fdb744b02201e,supported); 0::status(o_1de2423fdb744b02201e,refuted); 0::status(o_1de2423fdb744b02201e,unknown).
1::status(o_1e4b920985a85de66dc4,supported); 0::status(o_1e4b920985a85de66dc4,refuted); 0::status(o_1e4b920985a85de66dc4,unknown).
0.0010018589673563838::status(o_1e8c00031d3e0af749a1,supported); 0::status(o_1e8c00031d3e0af749a1,refuted); 0.99899814103264362::status(o_1e8c00031d3e0af749a1,unknown).
1::status(o_1e945f32d6b761c7acc9,supported); 0::status(o_1e945f32d6b761c7acc9,refuted); 0::status(o_1e945f32d6b761c7acc9,unknown).
7.9832112533040345e-05::status(o_1ec64f2af1c6804f1204,supported); 0::status(o_1ec64f2af1c6804f1204,refuted); 0.99992016788746696::status(o_1ec64f2af1c6804f1204,unknown).
0::status(o_1ed920b9990565a06668,supported); 1::status(o_1ed920b9990565a06668,refuted); 0::status(o_1ed920b9990565a06668,unknown).
0.091254428029060364::status(o_1f3340a2a91c8822faca,supported); 0::status(o_1f3340a2a91c8822faca,refuted); 0.90874557197093964::status(o_1f3340a2a91c8822faca,unknown).
0.0018518617143854499::status(o_1f55d18774f13f1fe42e,supported); 0::status(o_1f55d18774f13f1fe42e,refuted); 0.99814813828561455::status(o_1f55d18774f13f1fe42e,unknown).
0.99310886859893799::status(o_1faf9c1d9f85fc16afe1,supported); 0::status(o_1faf9c1d9f85fc16afe1,refuted); 0.0068911314010620117::status(o_1faf9c1d9f85fc16afe1,unknown).
0.9814574122428894::status(o_1fbb141553d2890483ca,supported); 0::status(o_1fbb141553d2890483ca,refuted); 0.018542587757110596::status(o_1fbb141553d2890483ca,unknown).
1::status(o_1fc9d78bb914f21a623c,supported); 0::status(o_1fc9d78bb914f21a623c,refuted); 0::status(o_1fc9d78bb914f21a623c,unknown).
0.0001668355253059417::status(o_1fe5cb13c72d709036a5,supported); 0::status(o_1fe5cb13c72d709036a5,refuted); 0.99983316447469406::status(o_1fe5cb13c72d709036a5,unknown).
0.98598873615264893::status(o_200fabbddc546e015aab,supported); 0::status(o_200fabbddc546e015aab,refuted); 0.014011263847351074::status(o_200fabbddc546e015aab,unknown).
1::status(o_204725cf9d532d2ddcee,supported); 0::status(o_204725cf9d532d2ddcee,refuted); 0::status(o_204725cf9d532d2ddcee,unknown).
0::status(o_209ec5a3f83e29ead293,supported); 1::status(o_209ec5a3f83e29ead293,refuted); 0::status(o_209ec5a3f83e29ead293,unknown).
0::status(o_20d430102235f54cfd79,supported); 0::status(o_20d430102235f54cfd79,refuted); 1::status(o_20d430102235f54cfd79,unknown).
0.0070033296942710876::status(o_20f35a758df5b34100cd,supported); 0::status(o_20f35a758df5b34100cd,refuted); 0.99299667030572891::status(o_20f35a758df5b34100cd,unknown).
0.00066984596196562052::status(o_21043c93e62d1b9e278b,supported); 0::status(o_21043c93e62d1b9e278b,refuted); 0.99933015403803438::status(o_21043c93e62d1b9e278b,unknown).
1::status(o_21319c52721bd786cbe1,supported); 0::status(o_21319c52721bd786cbe1,refuted); 0::status(o_21319c52721bd786cbe1,unknown).
0.99810886383056641::status(o_215640e2f741040bbbc9,supported); 0::status(o_215640e2f741040bbbc9,refuted); 0.0018911361694335938::status(o_215640e2f741040bbbc9,unknown).
1::status(o_21b74d969b09ec042152,supported); 0::status(o_21b74d969b09ec042152,refuted); 0::status(o_21b74d969b09ec042152,unknown).
1::status(o_21d3ae04a9290c7b986d,supported); 0::status(o_21d3ae04a9290c7b986d,refuted); 0::status(o_21d3ae04a9290c7b986d,unknown).
1::status(o_21e4d2170e4690d207d7,supported); 0::status(o_21e4d2170e4690d207d7,refuted); 0::status(o_21e4d2170e4690d207d7,unknown).
0.0018518617143854499::status(o_21ebb3057eeee6b30925,supported); 0::status(o_21ebb3057eeee6b30925,refuted); 0.99814813828561455::status(o_21ebb3057eeee6b30925,unknown).
0.0044489046558737755::status(o_2282e43241a3234d63ba,supported); 0::status(o_2282e43241a3234d63ba,refuted); 0.99555109534412622::status(o_2282e43241a3234d63ba,unknown).
0.976348876953125::status(o_22c4d86550342e09bbd6,supported); 0::status(o_22c4d86550342e09bbd6,refuted); 0.023651123046875::status(o_22c4d86550342e09bbd6,unknown).
0::status(o_22d40b8c8143d112c6d6,supported); 1::status(o_22d40b8c8143d112c6d6,refuted); 0::status(o_22d40b8c8143d112c6d6,unknown).
0::status(o_22d43944e691a7530a58,supported); 1::status(o_22d43944e691a7530a58,refuted); 0::status(o_22d43944e691a7530a58,unknown).
1::status(o_2333c00626ab9fee3a69,supported); 0::status(o_2333c00626ab9fee3a69,refuted); 0::status(o_2333c00626ab9fee3a69,unknown).
1::status(o_233dde696d2e9c5de735,supported); 0::status(o_233dde696d2e9c5de735,refuted); 0::status(o_233dde696d2e9c5de735,unknown).
9.2399274103717775e-07::status(o_239e69f63afaf0e3db63,supported); 0::status(o_239e69f63afaf0e3db63,refuted); 0.99999907600725901::status(o_239e69f63afaf0e3db63,unknown).
1::status(o_2417422dca3a36503b0c,supported); 0::status(o_2417422dca3a36503b0c,refuted); 0::status(o_2417422dca3a36503b0c,unknown).
0::status(o_247a4509331cccaac1d6,supported); 1::status(o_247a4509331cccaac1d6,refuted); 0::status(o_247a4509331cccaac1d6,unknown).
1::status(o_2537bc81fa60825e48ef,supported); 0::status(o_2537bc81fa60825e48ef,refuted); 0::status(o_2537bc81fa60825e48ef,unknown).
0.0007167395087890327::status(o_253da40d97157a06620e,supported); 0::status(o_253da40d97157a06620e,refuted); 0.99928326049121097::status(o_253da40d97157a06620e,unknown).
1::status(o_256ce0d1d6a9ea21492c,supported); 0::status(o_256ce0d1d6a9ea21492c,refuted); 0::status(o_256ce0d1d6a9ea21492c,unknown).
0::status(o_25ceb9fa4f69c4dc6ef2,supported); 1::status(o_25ceb9fa4f69c4dc6ef2,refuted); 0::status(o_25ceb9fa4f69c4dc6ef2,unknown).
0.0044489046558737755::status(o_25f456ed0d6fc97ec5f8,supported); 0::status(o_25f456ed0d6fc97ec5f8,refuted); 0.99555109534412622::status(o_25f456ed0d6fc97ec5f8,unknown).
1::status(o_260047d9904d3b10c1e0,supported); 0::status(o_260047d9904d3b10c1e0,refuted); 0::status(o_260047d9904d3b10c1e0,unknown).
0.99470680952072144::status(o_262ea7c3c423c81fd329,supported); 0::status(o_262ea7c3c423c81fd329,refuted); 0.0052931904792785645::status(o_262ea7c3c423c81fd329,unknown).
1::status(o_262ec9084b304255ff79,supported); 0::status(o_262ec9084b304255ff79,refuted); 0::status(o_262ec9084b304255ff79,unknown).
0.00044824578799307346::status(o_267c83da7744704da392,supported); 0::status(o_267c83da7744704da392,refuted); 0.99955175421200693::status(o_267c83da7744704da392,unknown).
0.98626255989074707::status(o_274385c16b8d1cdbfd94,supported); 0::status(o_274385c16b8d1cdbfd94,refuted); 0.01373744010925293::status(o_274385c16b8d1cdbfd94,unknown).
0.039551112800836563::status(o_275697c6bcd0f2c823e2,supported); 0::status(o_275697c6bcd0f2c823e2,refuted); 0.96044888719916344::status(o_275697c6bcd0f2c823e2,unknown).
0.99524873495101929::status(o_2765580ee0ba46fdda13,supported); 0::status(o_2765580ee0ba46fdda13,refuted); 0.0047512650489807129::status(o_2765580ee0ba46fdda13,unknown).
0::status(o_27c9900c15218fad0686,supported); 1::status(o_27c9900c15218fad0686,refuted); 0::status(o_27c9900c15218fad0686,unknown).
1::status(o_27f4960c8a24f9e1d103,supported); 0::status(o_27f4960c8a24f9e1d103,refuted); 0::status(o_27f4960c8a24f9e1d103,unknown).
0::status(o_280e74e244449b3cfd77,supported); 0::status(o_280e74e244449b3cfd77,refuted); 1::status(o_280e74e244449b3cfd77,unknown).
0::status(o_2814fe74183fa7c91cd1,supported); 0::status(o_2814fe74183fa7c91cd1,refuted); 1::status(o_2814fe74183fa7c91cd1,unknown).
1::status(o_2835776e8debb4d2072c,supported); 0::status(o_2835776e8debb4d2072c,refuted); 0::status(o_2835776e8debb4d2072c,unknown).
0.99609535932540894::status(o_28714fa6c04163a4bb7d,supported); 0::status(o_28714fa6c04163a4bb7d,refuted); 0.0039046406745910645::status(o_28714fa6c04163a4bb7d,unknown).
1::status(o_289c97c4d92308d2e3f5,supported); 0::status(o_289c97c4d92308d2e3f5,refuted); 0::status(o_289c97c4d92308d2e3f5,unknown).
1::status(o_28a1de3558c4b531f8d9,supported); 0::status(o_28a1de3558c4b531f8d9,refuted); 0::status(o_28a1de3558c4b531f8d9,unknown).
1::status(o_28cc0864bf8f1d29c69d,supported); 0::status(o_28cc0864bf8f1d29c69d,refuted); 0::status(o_28cc0864bf8f1d29c69d,unknown).
0::status(o_28e89dadd482246f9120,supported); 1::status(o_28e89dadd482246f9120,refuted); 0::status(o_28e89dadd482246f9120,unknown).
0::status(o_29679e9a353ec2751421,supported); 1::status(o_29679e9a353ec2751421,refuted); 0::status(o_29679e9a353ec2751421,unknown).
0.97427183389663696::status(o_296feb38668a8f05eb7b,supported); 0::status(o_296feb38668a8f05eb7b,refuted); 0.025728166103363037::status(o_296feb38668a8f05eb7b,unknown).
1::status(o_297745845b2758937d7e,supported); 0::status(o_297745845b2758937d7e,refuted); 0::status(o_297745845b2758937d7e,unknown).
1::status(o_29fd0428224f8f56e425,supported); 0::status(o_29fd0428224f8f56e425,refuted); 0::status(o_29fd0428224f8f56e425,unknown).
1::status(o_2a06088b54f04f5b4d88,supported); 0::status(o_2a06088b54f04f5b4d88,refuted); 0::status(o_2a06088b54f04f5b4d88,unknown).
0.99188774824142456::status(o_2a81113b58599e53f050,supported); 0::status(o_2a81113b58599e53f050,refuted); 0.0081122517585754395::status(o_2a81113b58599e53f050,unknown).
1::status(o_2bdc05e1ba42a0665159,supported); 0::status(o_2bdc05e1ba42a0665159,refuted); 0::status(o_2bdc05e1ba42a0665159,unknown).
0::status(o_2beff14e0797e2a4132a,supported); 0::status(o_2beff14e0797e2a4132a,refuted); 1::status(o_2beff14e0797e2a4132a,unknown).
0.56174170970916748::status(o_2bffda20ec8fe75b07eb,supported); 0::status(o_2bffda20ec8fe75b07eb,refuted); 0.43825829029083252::status(o_2bffda20ec8fe75b07eb,unknown).
0.091254428029060364::status(o_2c256cd7c4dd049745fb,supported); 0::status(o_2c256cd7c4dd049745fb,refuted); 0.90874557197093964::status(o_2c256cd7c4dd049745fb,unknown).
0::status(o_2c5b4501c1d1d534c8bf,supported); 1::status(o_2c5b4501c1d1d534c8bf,refuted); 0::status(o_2c5b4501c1d1d534c8bf,unknown).
0.99999999306661269::status(o_2c907980377dc80dd271,supported); 0::status(o_2c907980377dc80dd271,refuted); 6.9333873087273901e-09::status(o_2c907980377dc80dd271,unknown).
0::status(o_2cca762e9694a9c6d4f5,supported); 0::status(o_2cca762e9694a9c6d4f5,refuted); 1::status(o_2cca762e9694a9c6d4f5,unknown).
1::status(o_2cf63e93e52f6e82c61f,supported); 0::status(o_2cf63e93e52f6e82c61f,refuted); 0::status(o_2cf63e93e52f6e82c61f,unknown).
0::status(o_2d1ce8e2ab8aca3740fb,supported); 1::status(o_2d1ce8e2ab8aca3740fb,refuted); 0::status(o_2d1ce8e2ab8aca3740fb,unknown).
1::status(o_2d49d0889550ad05c77e,supported); 0::status(o_2d49d0889550ad05c77e,refuted); 0::status(o_2d49d0889550ad05c77e,unknown).
1::status(o_2d8880eb0bd80eaf99cd,supported); 0::status(o_2d8880eb0bd80eaf99cd,refuted); 0::status(o_2d8880eb0bd80eaf99cd,unknown).
1::status(o_2dca12888dd0535bfcd2,supported); 0::status(o_2dca12888dd0535bfcd2,refuted); 0::status(o_2dca12888dd0535bfcd2,unknown).
1::status(o_2de261beb9c15da6586f,supported); 0::status(o_2de261beb9c15da6586f,refuted); 0::status(o_2de261beb9c15da6586f,unknown).
1::status(o_2df3db888eee5a6f8521,supported); 0::status(o_2df3db888eee5a6f8521,refuted); 0::status(o_2df3db888eee5a6f8521,unknown).
0::status(o_2e854d90869d8a95bb63,supported); 1::status(o_2e854d90869d8a95bb63,refuted); 0::status(o_2e854d90869d8a95bb63,unknown).
0::status(o_2e8bf76007ae8f4a0465,supported); 1::status(o_2e8bf76007ae8f4a0465,refuted); 0::status(o_2e8bf76007ae8f4a0465,unknown).
0.99470680952072144::status(o_2e9ecf9b054bec36530e,supported); 0::status(o_2e9ecf9b054bec36530e,refuted); 0.0052931904792785645::status(o_2e9ecf9b054bec36530e,unknown).
0.002602787222713232::status(o_2ee3c8d25bc591228859,supported); 0::status(o_2ee3c8d25bc591228859,refuted); 0.99739721277728677::status(o_2ee3c8d25bc591228859,unknown).
0.10388609021902084::status(o_2f37bf0fbb432d94a4ee,supported); 0::status(o_2f37bf0fbb432d94a4ee,refuted); 0.89611390978097916::status(o_2f37bf0fbb432d94a4ee,unknown).
1::status(o_2f9d3dcefeeee0f67afe,supported); 0::status(o_2f9d3dcefeeee0f67afe,refuted); 0::status(o_2f9d3dcefeeee0f67afe,unknown).
0.091254428029060364::status(o_2f9e0f463bb3f8951f80,supported); 0::status(o_2f9e0f463bb3f8951f80,refuted); 0.90874557197093964::status(o_2f9e0f463bb3f8951f80,unknown).
1::status(o_2fbeee8bbdf0b1866b34,supported); 0::status(o_2fbeee8bbdf0b1866b34,refuted); 0::status(o_2fbeee8bbdf0b1866b34,unknown).
0.99810886383056641::status(o_2fc5c14e7925da5ed922,supported); 0::status(o_2fc5c14e7925da5ed922,refuted); 0.0018911361694335938::status(o_2fc5c14e7925da5ed922,unknown).
0.00076209998223930597::status(o_301abc32044c718c7118,supported); 0::status(o_301abc32044c718c7118,refuted); 0.99923790001776069::status(o_301abc32044c718c7118,unknown).
1::status(o_3068351bd4071d37339b,supported); 0::status(o_3068351bd4071d37339b,refuted); 0::status(o_3068351bd4071d37339b,unknown).
1::status(o_306a85c7bf0c3b1fb134,supported); 0::status(o_306a85c7bf0c3b1fb134,refuted); 0::status(o_306a85c7bf0c3b1fb134,unknown).
1::status(o_3073fcc4b82dfe413b16,supported); 0::status(o_3073fcc4b82dfe413b16,refuted); 0::status(o_3073fcc4b82dfe413b16,unknown).
0.0004814279091078788::status(o_30b73e196cde223bfc12,supported); 0::status(o_30b73e196cde223bfc12,refuted); 0.99951857209089212::status(o_30b73e196cde223bfc12,unknown).
0.99609535932540894::status(o_30e774446b55977f5196,supported); 0::status(o_30e774446b55977f5196,refuted); 0.0039046406745910645::status(o_30e774446b55977f5196,unknown).
0.99470680952072144::status(o_3128cf40030e2666d0b6,supported); 0::status(o_3128cf40030e2666d0b6,refuted); 0.0052931904792785645::status(o_3128cf40030e2666d0b6,unknown).
1::status(o_312a1b5d49b5c7ea650b,supported); 0::status(o_312a1b5d49b5c7ea650b,refuted); 0::status(o_312a1b5d49b5c7ea650b,unknown).
1::status(o_31567d4ac1d16c2acbcc,supported); 0::status(o_31567d4ac1d16c2acbcc,refuted); 0::status(o_31567d4ac1d16c2acbcc,unknown).
0.96227091550827026::status(o_31662048fc25bb8d3885,supported); 0::status(o_31662048fc25bb8d3885,refuted); 0.037729084491729736::status(o_31662048fc25bb8d3885,unknown).
0.61694091558456421::status(o_3176c768a8c28b372d0b,supported); 0::status(o_3176c768a8c28b372d0b,refuted); 0.38305908441543579::status(o_3176c768a8c28b372d0b,unknown).
0.95537519454956055::status(o_3184f696640c5db5a20c,supported); 0::status(o_3184f696640c5db5a20c,refuted); 0.044624805450439453::status(o_3184f696640c5db5a20c,unknown).
0.018792862408150444::status(o_31a379e156078cfe5b5e,supported); 0::status(o_31a379e156078cfe5b5e,refuted); 0.98120713759184952::status(o_31a379e156078cfe5b5e,unknown).
1::status(o_31a3cb021e7a9c1fdac8,supported); 0::status(o_31a3cb021e7a9c1fdac8,refuted); 0::status(o_31a3cb021e7a9c1fdac8,unknown).
0.00063768832478672266::status(o_31c4bdbedf8bce6bf47b,supported); 0::status(o_31c4bdbedf8bce6bf47b,refuted); 0.99936231167521328::status(o_31c4bdbedf8bce6bf47b,unknown).
1::status(o_31d2fef1b5854d6750a9,supported); 0::status(o_31d2fef1b5854d6750a9,refuted); 0::status(o_31d2fef1b5854d6750a9,unknown).
1::status(o_31f9d5cea7290e38c58a,supported); 0::status(o_31f9d5cea7290e38c58a,refuted); 0::status(o_31f9d5cea7290e38c58a,unknown).
1::status(o_32532f61be18153e97ef,supported); 0::status(o_32532f61be18153e97ef,refuted); 0::status(o_32532f61be18153e97ef,unknown).
1.3523938199314318e-07::status(o_327000ad80abbdb40ff2,supported); 0::status(o_327000ad80abbdb40ff2,refuted); 0.99999986476061797::status(o_327000ad80abbdb40ff2,unknown).
0.97402024269104004::status(o_3270f00b704af3711907,supported); 0::status(o_3270f00b704af3711907,refuted); 0.025979757308959961::status(o_3270f00b704af3711907,unknown).
0::status(o_32716e84ac91136e718b,supported); 1::status(o_32716e84ac91136e718b,refuted); 0::status(o_32716e84ac91136e718b,unknown).
0::status(o_33c84e23086d3d1c4d71,supported); 0::status(o_33c84e23086d3d1c4d71,refuted); 1::status(o_33c84e23086d3d1c4d71,unknown).
1::status(o_33dc779f414a59de7e73,supported); 0::status(o_33dc779f414a59de7e73,refuted); 0::status(o_33dc779f414a59de7e73,unknown).
0.99007987976074219::status(o_33e54bde119619a502be,supported); 0::status(o_33e54bde119619a502be,refuted); 0.0099201202392578125::status(o_33e54bde119619a502be,unknown).
0::status(o_33ec28b58faf21051d06,supported); 0::status(o_33ec28b58faf21051d06,refuted); 1::status(o_33ec28b58faf21051d06,unknown).
0.99737107753753662::status(o_34054f0aa8dc823c7e2b,supported); 0::status(o_34054f0aa8dc823c7e2b,refuted); 0.0026289224624633789::status(o_34054f0aa8dc823c7e2b,unknown).
0.0018071738304570317::status(o_34a13fe03d9f258c5bf4,supported); 0::status(o_34a13fe03d9f258c5bf4,refuted); 0.99819282616954297::status(o_34a13fe03d9f258c5bf4,unknown).
0::status(o_34ac3c891c24d2b4b3f2,supported); 1::status(o_34ac3c891c24d2b4b3f2,refuted); 0::status(o_34ac3c891c24d2b4b3f2,unknown).
1::status(o_3500eb1666ae680f2659,supported); 0::status(o_3500eb1666ae680f2659,refuted); 0::status(o_3500eb1666ae680f2659,unknown).
1::status(o_35212e85fa94812329d6,supported); 0::status(o_35212e85fa94812329d6,refuted); 0::status(o_35212e85fa94812329d6,unknown).
1::status(o_352c664881c4b3221822,supported); 0::status(o_352c664881c4b3221822,refuted); 0::status(o_352c664881c4b3221822,unknown).
0::status(o_355a19fba1ac50c245ba,supported); 1::status(o_355a19fba1ac50c245ba,refuted); 0::status(o_355a19fba1ac50c245ba,unknown).
1::status(o_355b9ea7abbd746d1146,supported); 0::status(o_355b9ea7abbd746d1146,refuted); 0::status(o_355b9ea7abbd746d1146,unknown).
0.99999996500192156::status(o_35679d94ec7f78269939,supported); 0::status(o_35679d94ec7f78269939,refuted); 3.49980784353221e-08::status(o_35679d94ec7f78269939,unknown).
0.99981849066906681::status(o_35bdd255c7d8e6493ebc,supported); 0::status(o_35bdd255c7d8e6493ebc,refuted); 0.00018150933093319388::status(o_35bdd255c7d8e6493ebc,unknown).
0.00066984596196562052::status(o_35c3fff1897937b5f4e1,supported); 0::status(o_35c3fff1897937b5f4e1,refuted); 0.99933015403803438::status(o_35c3fff1897937b5f4e1,unknown).
0.0013008691603317857::status(o_35ef4484df9ca4d2274d,supported); 0::status(o_35ef4484df9ca4d2274d,refuted); 0.99869913083966821::status(o_35ef4484df9ca4d2274d,unknown).
1::status(o_3600ff54c76bc02eac4c,supported); 0::status(o_3600ff54c76bc02eac4c,refuted); 0::status(o_3600ff54c76bc02eac4c,unknown).
0.96754372119903564::status(o_3650361b8fdf51669fa0,supported); 0::status(o_3650361b8fdf51669fa0,refuted); 0.032456278800964355::status(o_3650361b8fdf51669fa0,unknown).
0.99365460872650146::status(o_3708e936abdea4e529a6,supported); 0::status(o_3708e936abdea4e529a6,refuted); 0.0063453912734985352::status(o_3708e936abdea4e529a6,unknown).
1::status(o_370d3ca55a3582cead47,supported); 0::status(o_370d3ca55a3582cead47,refuted); 0::status(o_370d3ca55a3582cead47,unknown).
0::status(o_373b79041d1e02c789e5,supported); 1::status(o_373b79041d1e02c789e5,refuted); 0::status(o_373b79041d1e02c789e5,unknown).
1::status(o_373f3bb1437902c9b0d8,supported); 0::status(o_373f3bb1437902c9b0d8,refuted); 0::status(o_373f3bb1437902c9b0d8,unknown).
1::status(o_3772b49a57dc0741b5f2,supported); 0::status(o_3772b49a57dc0741b5f2,refuted); 0::status(o_3772b49a57dc0741b5f2,unknown).
1::status(o_37c145cbf544cf442107,supported); 0::status(o_37c145cbf544cf442107,refuted); 0::status(o_37c145cbf544cf442107,unknown).
0.95537519454956055::status(o_37c6cab1af8f2a20dec8,supported); 0::status(o_37c6cab1af8f2a20dec8,refuted); 0.044624805450439453::status(o_37c6cab1af8f2a20dec8,unknown).
0.98997622728347778::status(o_37ce9b247bf80a40a21c,supported); 0::status(o_37ce9b247bf80a40a21c,refuted); 0.010023772716522217::status(o_37ce9b247bf80a40a21c,unknown).
0.99999992580897223::status(o_37f395cdc7913ab4d4b9,supported); 0::status(o_37f395cdc7913ab4d4b9,refuted); 7.4191027765735384e-08::status(o_37f395cdc7913ab4d4b9,unknown).
0.99045181274414062::status(o_3801bb65f9b835721eb1,supported); 0::status(o_3801bb65f9b835721eb1,refuted); 0.009548187255859375::status(o_3801bb65f9b835721eb1,unknown).
0::status(o_380735a74fad3aaee04e,supported); 0::status(o_380735a74fad3aaee04e,refuted); 1::status(o_380735a74fad3aaee04e,unknown).
1::status(o_38225b5263fab48c5e08,supported); 0::status(o_38225b5263fab48c5e08,refuted); 0::status(o_38225b5263fab48c5e08,unknown).
0::status(o_384f76bed80b6a497a4a,supported); 1::status(o_384f76bed80b6a497a4a,refuted); 0::status(o_384f76bed80b6a497a4a,unknown).
1::status(o_38b1b2c5afb1433acd2a,supported); 0::status(o_38b1b2c5afb1433acd2a,refuted); 0::status(o_38b1b2c5afb1433acd2a,unknown).
1::status(o_38f040d734b29475c9db,supported); 0::status(o_38f040d734b29475c9db,refuted); 0::status(o_38f040d734b29475c9db,unknown).
0.0001668355253059417::status(o_3928173bdac8b7b74a8f,supported); 0::status(o_3928173bdac8b7b74a8f,refuted); 0.99983316447469406::status(o_3928173bdac8b7b74a8f,unknown).
1::status(o_393d37c0b1e34f922acf,supported); 0::status(o_393d37c0b1e34f922acf,refuted); 0::status(o_393d37c0b1e34f922acf,unknown).
1::status(o_397651ef7644dff0b15c,supported); 0::status(o_397651ef7644dff0b15c,refuted); 0::status(o_397651ef7644dff0b15c,unknown).
0.99999996500192156::status(o_39778b09351a3148af76,supported); 0::status(o_39778b09351a3148af76,refuted); 3.49980784353221e-08::status(o_39778b09351a3148af76,unknown).
0.98626255989074707::status(o_397e9df95f4d5e8244a3,supported); 0::status(o_397e9df95f4d5e8244a3,refuted); 0.01373744010925293::status(o_397e9df95f4d5e8244a3,unknown).
0.0005490043549798429::status(o_39888368b9bc4929a1ad,supported); 0::status(o_39888368b9bc4929a1ad,refuted); 0.99945099564502016::status(o_39888368b9bc4929a1ad,unknown).
0.002602787222713232::status(o_39916c4551d7bd5f856e,supported); 0::status(o_39916c4551d7bd5f856e,refuted); 0.99739721277728677::status(o_39916c4551d7bd5f856e,unknown).
0.96227091550827026::status(o_39919b5deae80da4fe1e,supported); 0::status(o_39919b5deae80da4fe1e,refuted); 0.037729084491729736::status(o_39919b5deae80da4fe1e,unknown).
1::status(o_39d3caffdc4883b2e5e1,supported); 0::status(o_39d3caffdc4883b2e5e1,refuted); 0::status(o_39d3caffdc4883b2e5e1,unknown).
0::status(o_39ddd8f48aab0945d3ef,supported); 1::status(o_39ddd8f48aab0945d3ef,refuted); 0::status(o_39ddd8f48aab0945d3ef,unknown).
1::status(o_3a2132a595dfe5dfb343,supported); 0::status(o_3a2132a595dfe5dfb343,refuted); 0::status(o_3a2132a595dfe5dfb343,unknown).
1::status(o_3a991123a9cf0247c302,supported); 0::status(o_3a991123a9cf0247c302,refuted); 0::status(o_3a991123a9cf0247c302,unknown).
1::status(o_3acc44b2c3cb265048e1,supported); 0::status(o_3acc44b2c3cb265048e1,refuted); 0::status(o_3acc44b2c3cb265048e1,unknown).
1::status(o_3aef72adaa350abe3058,supported); 0::status(o_3aef72adaa350abe3058,refuted); 0::status(o_3aef72adaa350abe3058,unknown).
0::status(o_3af916ad7d95a2a2de3c,supported); 0::status(o_3af916ad7d95a2a2de3c,refuted); 1::status(o_3af916ad7d95a2a2de3c,unknown).
0::status(o_3b070c64f3c2dbd4b295,supported); 0::status(o_3b070c64f3c2dbd4b295,refuted); 1::status(o_3b070c64f3c2dbd4b295,unknown).
1::status(o_3b167a0aef257de9c568,supported); 0::status(o_3b167a0aef257de9c568,refuted); 0::status(o_3b167a0aef257de9c568,unknown).
1::status(o_3b38e704d7cfde274828,supported); 0::status(o_3b38e704d7cfde274828,refuted); 0::status(o_3b38e704d7cfde274828,unknown).
0.99346327781677246::status(o_3b407c1a58f5da1df839,supported); 0::status(o_3b407c1a58f5da1df839,refuted); 0.0065367221832275391::status(o_3b407c1a58f5da1df839,unknown).
0.99524873495101929::status(o_3b4991f7ba55b501a774,supported); 0::status(o_3b4991f7ba55b501a774,refuted); 0.0047512650489807129::status(o_3b4991f7ba55b501a774,unknown).
1::status(o_3b5844f19691a227b6d7,supported); 0::status(o_3b5844f19691a227b6d7,refuted); 0::status(o_3b5844f19691a227b6d7,unknown).
1::status(o_3baa72ecbf70e6fd9d13,supported); 0::status(o_3baa72ecbf70e6fd9d13,refuted); 0::status(o_3baa72ecbf70e6fd9d13,unknown).
1::status(o_3bb89da5cba85a4a649c,supported); 0::status(o_3bb89da5cba85a4a649c,refuted); 0::status(o_3bb89da5cba85a4a649c,unknown).
1::status(o_3bccf11b36ee58a44a73,supported); 0::status(o_3bccf11b36ee58a44a73,refuted); 0::status(o_3bccf11b36ee58a44a73,unknown).
1::status(o_3bd3676a2fdf6682d156,supported); 0::status(o_3bd3676a2fdf6682d156,refuted); 0::status(o_3bd3676a2fdf6682d156,unknown).
0::status(o_3c0091074de4af8a45ed,supported); 0::status(o_3c0091074de4af8a45ed,refuted); 1::status(o_3c0091074de4af8a45ed,unknown).
1::status(o_3c819739f8d7586923cd,supported); 0::status(o_3c819739f8d7586923cd,refuted); 0::status(o_3c819739f8d7586923cd,unknown).
0::status(o_3cb1c0d6bd359a20bea9,supported); 0::status(o_3cb1c0d6bd359a20bea9,refuted); 1::status(o_3cb1c0d6bd359a20bea9,unknown).
1::status(o_3cfc88c982d6f719b1eb,supported); 0::status(o_3cfc88c982d6f719b1eb,refuted); 0::status(o_3cfc88c982d6f719b1eb,unknown).
0::status(o_3d1614558427c82424f2,supported); 1::status(o_3d1614558427c82424f2,refuted); 0::status(o_3d1614558427c82424f2,unknown).
1::status(o_3d369f995ab971c6c2e6,supported); 0::status(o_3d369f995ab971c6c2e6,refuted); 0::status(o_3d369f995ab971c6c2e6,unknown).
0.59074564597745061::status(o_3d5223e94b62df0ed33f,supported); 0::status(o_3d5223e94b62df0ed33f,refuted); 0.40925435402254939::status(o_3d5223e94b62df0ed33f,unknown).
0.0018071738304570317::status(o_3d702ce4ee606e6d27c3,supported); 0::status(o_3d702ce4ee606e6d27c3,refuted); 0.99819282616954297::status(o_3d702ce4ee606e6d27c3,unknown).
1::status(o_3d7d93c54ec1b38702d5,supported); 0::status(o_3d7d93c54ec1b38702d5,refuted); 0::status(o_3d7d93c54ec1b38702d5,unknown).
0.99213320016860962::status(o_3d872477d0fafd2e69d0,supported); 0::status(o_3d872477d0fafd2e69d0,refuted); 0.0078667998313903809::status(o_3d872477d0fafd2e69d0,unknown).
0.99810886383056641::status(o_3da2a2e97f3135d39036,supported); 0::status(o_3da2a2e97f3135d39036,refuted); 0.0018911361694335938::status(o_3da2a2e97f3135d39036,unknown).
0.00048713211435824633::status(o_3dc4f5d3b04099c86248,supported); 0::status(o_3dc4f5d3b04099c86248,refuted); 0.99951286788564175::status(o_3dc4f5d3b04099c86248,unknown).
0::status(o_3dd31675e35a06e080d1,supported); 1::status(o_3dd31675e35a06e080d1,refuted); 0::status(o_3dd31675e35a06e080d1,unknown).
1::status(o_3dfc7c3b00c967610382,supported); 0::status(o_3dfc7c3b00c967610382,refuted); 0::status(o_3dfc7c3b00c967610382,unknown).
0.10388609021902084::status(o_3e01a6f18f5e5edaac0b,supported); 0::status(o_3e01a6f18f5e5edaac0b,refuted); 0.89611390978097916::status(o_3e01a6f18f5e5edaac0b,unknown).
0::status(o_3e199d5fdb8d466fb70d,supported); 1::status(o_3e199d5fdb8d466fb70d,refuted); 0::status(o_3e199d5fdb8d466fb70d,unknown).
0.99999882968458842::status(o_3e3c4f6693d28b9ec014,supported); 0::status(o_3e3c4f6693d28b9ec014,refuted); 1.1703154115805248e-06::status(o_3e3c4f6693d28b9ec014,unknown).
0.96227091550827026::status(o_3ed5364270d4c98f8111,supported); 0::status(o_3ed5364270d4c98f8111,refuted); 0.037729084491729736::status(o_3ed5364270d4c98f8111,unknown).
0::status(o_3ee4ba0812fa24956733,supported); 1::status(o_3ee4ba0812fa24956733,refuted); 0::status(o_3ee4ba0812fa24956733,unknown).
0.00048713211435824633::status(o_3f1c1dc38318ed0c1db3,supported); 0::status(o_3f1c1dc38318ed0c1db3,refuted); 0.99951286788564175::status(o_3f1c1dc38318ed0c1db3,unknown).
0::status(o_3f3388d354110fdbf3f4,supported); 1::status(o_3f3388d354110fdbf3f4,refuted); 0::status(o_3f3388d354110fdbf3f4,unknown).
0.00038813083665445447::status(o_3f702530c791396ba344,supported); 0::status(o_3f702530c791396ba344,refuted); 0.99961186916334555::status(o_3f702530c791396ba344,unknown).
1::status(o_3f897f04aea540c47168,supported); 0::status(o_3f897f04aea540c47168,refuted); 0::status(o_3f897f04aea540c47168,unknown).
1::status(o_3fe547b68488f0f3c153,supported); 0::status(o_3fe547b68488f0f3c153,refuted); 0::status(o_3fe547b68488f0f3c153,unknown).
0::status(o_402164050b3a66f31e31,supported); 1::status(o_402164050b3a66f31e31,refuted); 0::status(o_402164050b3a66f31e31,unknown).
1::status(o_406fd817f27182764a11,supported); 0::status(o_406fd817f27182764a11,refuted); 0::status(o_406fd817f27182764a11,unknown).
1::status(o_40856c6b0763d40ea7f1,supported); 0::status(o_40856c6b0763d40ea7f1,refuted); 0::status(o_40856c6b0763d40ea7f1,unknown).
0.00027939380379393697::status(o_40ef598178534c9f3e41,supported); 0::status(o_40ef598178534c9f3e41,refuted); 0.99972060619620606::status(o_40ef598178534c9f3e41,unknown).
1::status(o_40f23e2c84922125bdcd,supported); 0::status(o_40f23e2c84922125bdcd,refuted); 0::status(o_40f23e2c84922125bdcd,unknown).
1::status(o_418f2289dae2c6527e6a,supported); 0::status(o_418f2289dae2c6527e6a,refuted); 0::status(o_418f2289dae2c6527e6a,unknown).
0.0070033296942710876::status(o_41a643ad64732cc58cb1,supported); 0::status(o_41a643ad64732cc58cb1,refuted); 0.99299667030572891::status(o_41a643ad64732cc58cb1,unknown).
1::status(o_41c1d74249a12b566e87,supported); 0::status(o_41c1d74249a12b566e87,refuted); 0::status(o_41c1d74249a12b566e87,unknown).
0.99346327781677246::status(o_41dcd0301333256f9c17,supported); 0::status(o_41dcd0301333256f9c17,refuted); 0.0065367221832275391::status(o_41dcd0301333256f9c17,unknown).
0.00044824578799307346::status(o_41f8e5bd8d3c88b4aa1e,supported); 0::status(o_41f8e5bd8d3c88b4aa1e,refuted); 0.99955175421200693::status(o_41f8e5bd8d3c88b4aa1e,unknown).
1::status(o_41fb82ecbc37247ea18b,supported); 0::status(o_41fb82ecbc37247ea18b,refuted); 0::status(o_41fb82ecbc37247ea18b,unknown).
0::status(o_427e112beaab682e2bef,supported); 0::status(o_427e112beaab682e2bef,refuted); 1::status(o_427e112beaab682e2bef,unknown).
1::status(o_42b6d2f613311f7ce846,supported); 0::status(o_42b6d2f613311f7ce846,refuted); 0::status(o_42b6d2f613311f7ce846,unknown).
0.00045137316919863224::status(o_42cef371c4962d3b8ee7,supported); 0::status(o_42cef371c4962d3b8ee7,refuted); 0.99954862683080137::status(o_42cef371c4962d3b8ee7,unknown).
1::status(o_4321a34bfd7f8b93de5b,supported); 0::status(o_4321a34bfd7f8b93de5b,refuted); 0::status(o_4321a34bfd7f8b93de5b,unknown).
0.99999108955419413::status(o_433714aff04c1b243428,supported); 0::status(o_433714aff04c1b243428,refuted); 8.910445805865308e-06::status(o_433714aff04c1b243428,unknown).
1::status(o_43fa5664f0de7c837ada,supported); 0::status(o_43fa5664f0de7c837ada,refuted); 0::status(o_43fa5664f0de7c837ada,unknown).
0::status(o_4463ce10bc8db87c448d,supported); 1::status(o_4463ce10bc8db87c448d,refuted); 0::status(o_4463ce10bc8db87c448d,unknown).
1::status(o_44ead850c31571c1064d,supported); 0::status(o_44ead850c31571c1064d,refuted); 0::status(o_44ead850c31571c1064d,unknown).
1::status(o_45099dd24a330a357a53,supported); 0::status(o_45099dd24a330a357a53,refuted); 0::status(o_45099dd24a330a357a53,unknown).
1::status(o_45efc7de7edea09f2ab2,supported); 0::status(o_45efc7de7edea09f2ab2,refuted); 0::status(o_45efc7de7edea09f2ab2,unknown).
1::status(o_4679e86d8b4651b720f4,supported); 0::status(o_4679e86d8b4651b720f4,refuted); 0::status(o_4679e86d8b4651b720f4,unknown).
0.99385096469335199::status(o_46bb713f6a111fe28fde,supported); 0::status(o_46bb713f6a111fe28fde,refuted); 0.0061490353066480097::status(o_46bb713f6a111fe28fde,unknown).
0::status(o_46e2dd63b322c5dfaba0,supported); 1::status(o_46e2dd63b322c5dfaba0,refuted); 0::status(o_46e2dd63b322c5dfaba0,unknown).
0::status(o_4731064fb1cbec098856,supported); 0::status(o_4731064fb1cbec098856,refuted); 1::status(o_4731064fb1cbec098856,unknown).
0::status(o_4749c8d705310bba3b46,supported); 1::status(o_4749c8d705310bba3b46,refuted); 0::status(o_4749c8d705310bba3b46,unknown).
0.00044824578799307346::status(o_477adf5909e07fbf041c,supported); 0::status(o_477adf5909e07fbf041c,refuted); 0.99955175421200693::status(o_477adf5909e07fbf041c,unknown).
0.00044824578799307346::status(o_47910096ce2bb41c2b1e,supported); 0::status(o_47910096ce2bb41c2b1e,refuted); 0.99955175421200693::status(o_47910096ce2bb41c2b1e,unknown).
0.0013008691603317857::status(o_47e0163c92f9d9af95b6,supported); 0::status(o_47e0163c92f9d9af95b6,refuted); 0.99869913083966821::status(o_47e0163c92f9d9af95b6,unknown).
0.0018071738304570317::status(o_480a8d666ac3e7e389a1,supported); 0::status(o_480a8d666ac3e7e389a1,refuted); 0.99819282616954297::status(o_480a8d666ac3e7e389a1,unknown).
1::status(o_482217f933d93a8510f1,supported); 0::status(o_482217f933d93a8510f1,refuted); 0::status(o_482217f933d93a8510f1,unknown).
1::status(o_482a1c312f6236103139,supported); 0::status(o_482a1c312f6236103139,refuted); 0::status(o_482a1c312f6236103139,unknown).
0.61694091558456421::status(o_4865d8b53913358047ac,supported); 0::status(o_4865d8b53913358047ac,refuted); 0.38305908441543579::status(o_4865d8b53913358047ac,unknown).
1::status(o_48667ac47f7a76a5df66,supported); 0::status(o_48667ac47f7a76a5df66,refuted); 0::status(o_48667ac47f7a76a5df66,unknown).
0::status(o_48a35ab5a30246f980f4,supported); 1::status(o_48a35ab5a30246f980f4,refuted); 0::status(o_48a35ab5a30246f980f4,unknown).
0::status(o_48f4f942b589f04cfc01,supported); 0::status(o_48f4f942b589f04cfc01,refuted); 1::status(o_48f4f942b589f04cfc01,unknown).
1::status(o_490ef53280d58f2d6da2,supported); 0::status(o_490ef53280d58f2d6da2,refuted); 0::status(o_490ef53280d58f2d6da2,unknown).
0::status(o_4956ebd7841f4b2dbbfa,supported); 1::status(o_4956ebd7841f4b2dbbfa,refuted); 0::status(o_4956ebd7841f4b2dbbfa,unknown).
0.0070033296942710876::status(o_496d24d30051c7a4036d,supported); 0::status(o_496d24d30051c7a4036d,refuted); 0.99299667030572891::status(o_496d24d30051c7a4036d,unknown).
0::status(o_4978d2879076a93ffb7a,supported); 0::status(o_4978d2879076a93ffb7a,refuted); 1::status(o_4978d2879076a93ffb7a,unknown).
0.99998772104878231::status(o_49854d2bc6f3a059d6ff,supported); 0::status(o_49854d2bc6f3a059d6ff,refuted); 1.2278951217692402e-05::status(o_49854d2bc6f3a059d6ff,unknown).
0.56174170970916748::status(o_4996dcb197a72903202c,supported); 0::status(o_4996dcb197a72903202c,refuted); 0.43825829029083252::status(o_4996dcb197a72903202c,unknown).
1::status(o_49b7b3906b0bc487e9c7,supported); 0::status(o_49b7b3906b0bc487e9c7,refuted); 0::status(o_49b7b3906b0bc487e9c7,unknown).
0::status(o_49d63036c03f2ea9c01d,supported); 1::status(o_49d63036c03f2ea9c01d,refuted); 0::status(o_49d63036c03f2ea9c01d,unknown).
1::status(o_4a0d0b4b4ef89d5b53df,supported); 0::status(o_4a0d0b4b4ef89d5b53df,refuted); 0::status(o_4a0d0b4b4ef89d5b53df,unknown).
1::status(o_4a1698b1b8925f4af31b,supported); 0::status(o_4a1698b1b8925f4af31b,refuted); 0::status(o_4a1698b1b8925f4af31b,unknown).
1::status(o_4a67461753c49f4d9e3a,supported); 0::status(o_4a67461753c49f4d9e3a,refuted); 0::status(o_4a67461753c49f4d9e3a,unknown).
0::status(o_4aee3cdb481ed904433b,supported); 1::status(o_4aee3cdb481ed904433b,refuted); 0::status(o_4aee3cdb481ed904433b,unknown).
1::status(o_4b56d6c8843b75424c71,supported); 0::status(o_4b56d6c8843b75424c71,refuted); 0::status(o_4b56d6c8843b75424c71,unknown).
0.99667513370513916::status(o_4b83f0a887414c79c4db,supported); 0::status(o_4b83f0a887414c79c4db,refuted); 0.0033248662948608398::status(o_4b83f0a887414c79c4db,unknown).
1::status(o_4bd72714916b558d7957,supported); 0::status(o_4bd72714916b558d7957,refuted); 0::status(o_4bd72714916b558d7957,unknown).
0::status(o_4c943b721a042ecfdab0,supported); 0::status(o_4c943b721a042ecfdab0,refuted); 1::status(o_4c943b721a042ecfdab0,unknown).
0::status(o_4cf18a5cd3a678b16eb8,supported); 0::status(o_4cf18a5cd3a678b16eb8,refuted); 1::status(o_4cf18a5cd3a678b16eb8,unknown).
0::status(o_4d0c7c6265b3089b07e0,supported); 0::status(o_4d0c7c6265b3089b07e0,refuted); 1::status(o_4d0c7c6265b3089b07e0,unknown).
1::status(o_4d1e186ffb4ca961fe68,supported); 0::status(o_4d1e186ffb4ca961fe68,refuted); 0::status(o_4d1e186ffb4ca961fe68,unknown).
1::status(o_4d321f78e9a2e0469624,supported); 0::status(o_4d321f78e9a2e0469624,refuted); 0::status(o_4d321f78e9a2e0469624,unknown).
0.98928332328796387::status(o_4d5ec9c610fd9c336ad4,supported); 0::status(o_4d5ec9c610fd9c336ad4,refuted); 0.010716676712036133::status(o_4d5ec9c610fd9c336ad4,unknown).
0.31135774259586463::status(o_4d79be2e37d070251c9c,supported); 0::status(o_4d79be2e37d070251c9c,refuted); 0.68864225740413532::status(o_4d79be2e37d070251c9c,unknown).
1::status(o_4dc83d88b988e80eb113,supported); 0::status(o_4dc83d88b988e80eb113,refuted); 0::status(o_4dc83d88b988e80eb113,unknown).
1::status(o_4ddffbf6933ad269c7b3,supported); 0::status(o_4ddffbf6933ad269c7b3,refuted); 0::status(o_4ddffbf6933ad269c7b3,unknown).
0::status(o_4e084109631d589b69de,supported); 0::status(o_4e084109631d589b69de,refuted); 1::status(o_4e084109631d589b69de,unknown).
1::status(o_4e15353745e93cd230e9,supported); 0::status(o_4e15353745e93cd230e9,refuted); 0::status(o_4e15353745e93cd230e9,unknown).
0::status(o_4e1a48420355c6079a38,supported); 0::status(o_4e1a48420355c6079a38,refuted); 1::status(o_4e1a48420355c6079a38,unknown).
0::status(o_4e42c010934f2f36c5e4,supported); 1::status(o_4e42c010934f2f36c5e4,refuted); 0::status(o_4e42c010934f2f36c5e4,unknown).
1::status(o_4e58de7c0652d9253c6a,supported); 0::status(o_4e58de7c0652d9253c6a,refuted); 0::status(o_4e58de7c0652d9253c6a,unknown).
0.99185353517532349::status(o_4e59e16fcf14adef2198,supported); 0::status(o_4e59e16fcf14adef2198,refuted); 0.0081464648246765137::status(o_4e59e16fcf14adef2198,unknown).
1::status(o_4efd3e167ab266ff6597,supported); 0::status(o_4efd3e167ab266ff6597,refuted); 0::status(o_4efd3e167ab266ff6597,unknown).
0.99007987976074219::status(o_4f168cd3692d67e50979,supported); 0::status(o_4f168cd3692d67e50979,refuted); 0.0099201202392578125::status(o_4f168cd3692d67e50979,unknown).
0::status(o_4f2104f4ddc40b6525b3,supported); 0::status(o_4f2104f4ddc40b6525b3,refuted); 1::status(o_4f2104f4ddc40b6525b3,unknown).
1::status(o_4f9c60bd23ab7f0a6910,supported); 0::status(o_4f9c60bd23ab7f0a6910,refuted); 0::status(o_4f9c60bd23ab7f0a6910,unknown).
0::status(o_4fb64114ee390cffc479,supported); 0::status(o_4fb64114ee390cffc479,refuted); 1::status(o_4fb64114ee390cffc479,unknown).
0.9814574122428894::status(o_4fec84417a868a565920,supported); 0::status(o_4fec84417a868a565920,refuted); 0.018542587757110596::status(o_4fec84417a868a565920,unknown).
1::status(o_5015f864a859a41e97fd,supported); 0::status(o_5015f864a859a41e97fd,refuted); 0::status(o_5015f864a859a41e97fd,unknown).
0::status(o_505ac6a684a885ca2dc1,supported); 1::status(o_505ac6a684a885ca2dc1,refuted); 0::status(o_505ac6a684a885ca2dc1,unknown).
0::status(o_508e6ade2d95e9d7412b,supported); 0::status(o_508e6ade2d95e9d7412b,refuted); 1::status(o_508e6ade2d95e9d7412b,unknown).
0.99092429876327515::status(o_50ab1da0f8742a99d023,supported); 0::status(o_50ab1da0f8742a99d023,refuted); 0.0090757012367248535::status(o_50ab1da0f8742a99d023,unknown).
0.003883931552991271::status(o_50bf9ed44022bea1d7fc,supported); 0::status(o_50bf9ed44022bea1d7fc,refuted); 0.99611606844700873::status(o_50bf9ed44022bea1d7fc,unknown).
0.9814574122428894::status(o_5126e9d04183de4b0317,supported); 0::status(o_5126e9d04183de4b0317,refuted); 0.018542587757110596::status(o_5126e9d04183de4b0317,unknown).
0.98598873615264893::status(o_51a10900bea196e24acf,supported); 0::status(o_51a10900bea196e24acf,refuted); 0.014011263847351074::status(o_51a10900bea196e24acf,unknown).
0::status(o_521b485086d57d954475,supported); 1::status(o_521b485086d57d954475,refuted); 0::status(o_521b485086d57d954475,unknown).
1::status(o_533294e01e7077b17ee5,supported); 0::status(o_533294e01e7077b17ee5,refuted); 0::status(o_533294e01e7077b17ee5,unknown).
0::status(o_533dd9b9efbfe17e57e8,supported); 1::status(o_533dd9b9efbfe17e57e8,refuted); 0::status(o_533dd9b9efbfe17e57e8,unknown).
0.99361503124237061::status(o_5347d3e42ba2bc53d991,supported); 0::status(o_5347d3e42ba2bc53d991,refuted); 0.0063849687576293945::status(o_5347d3e42ba2bc53d991,unknown).
0.99981849066906681::status(o_5385944e773eb4e7db98,supported); 0::status(o_5385944e773eb4e7db98,refuted); 0.00018150933093319388::status(o_5385944e773eb4e7db98,unknown).
1::status(o_5387994c83094efca66a,supported); 0::status(o_5387994c83094efca66a,refuted); 0::status(o_5387994c83094efca66a,unknown).
1::status(o_539c15ca1e91d38bd253,supported); 0::status(o_539c15ca1e91d38bd253,refuted); 0::status(o_539c15ca1e91d38bd253,unknown).
1::status(o_53d0c0bb94fdabc73b99,supported); 0::status(o_53d0c0bb94fdabc73b99,refuted); 0::status(o_53d0c0bb94fdabc73b99,unknown).
0.96754372119903564::status(o_53e72aba9c4e4d16ce2b,supported); 0::status(o_53e72aba9c4e4d16ce2b,refuted); 0.032456278800964355::status(o_53e72aba9c4e4d16ce2b,unknown).
0::status(o_5497ee0beb54cc3cc70f,supported); 1::status(o_5497ee0beb54cc3cc70f,refuted); 0::status(o_5497ee0beb54cc3cc70f,unknown).
0::status(o_54e3178f782c9b6e55ef,supported); 1::status(o_54e3178f782c9b6e55ef,refuted); 0::status(o_54e3178f782c9b6e55ef,unknown).
0.0018518617143854499::status(o_54ff6cad6b6f0a38cfb4,supported); 0::status(o_54ff6cad6b6f0a38cfb4,refuted); 0.99814813828561455::status(o_54ff6cad6b6f0a38cfb4,unknown).
0::status(o_5543b48f93b41c665066,supported); 1::status(o_5543b48f93b41c665066,refuted); 0::status(o_5543b48f93b41c665066,unknown).
1::status(o_554d583c1ad401f6371e,supported); 0::status(o_554d583c1ad401f6371e,refuted); 0::status(o_554d583c1ad401f6371e,unknown).
0.014709697338768809::status(o_558732b29fada72af7d5,supported); 0::status(o_558732b29fada72af7d5,refuted); 0.98529030266123119::status(o_558732b29fada72af7d5,unknown).
0::status(o_55920f4a9a5758d9c921,supported); 1::status(o_55920f4a9a5758d9c921,refuted); 0::status(o_55920f4a9a5758d9c921,unknown).
0::status(o_55c1c67b835c754e8999,supported); 1::status(o_55c1c67b835c754e8999,refuted); 0::status(o_55c1c67b835c754e8999,unknown).
0.067158885300159454::status(o_55f08a6b10ce56e7685c,supported); 0::status(o_55f08a6b10ce56e7685c,refuted); 0.93284111469984055::status(o_55f08a6b10ce56e7685c,unknown).
0.98997622728347778::status(o_5656525bbdb4a0a237c1,supported); 0::status(o_5656525bbdb4a0a237c1,refuted); 0.010023772716522217::status(o_5656525bbdb4a0a237c1,unknown).
1::status(o_56dcde9618fa955ea7bd,supported); 0::status(o_56dcde9618fa955ea7bd,refuted); 0::status(o_56dcde9618fa955ea7bd,unknown).
0.99093681573867798::status(o_56f9d2b6ce3c962e5814,supported); 0::status(o_56f9d2b6ce3c962e5814,refuted); 0.0090631842613220215::status(o_56f9d2b6ce3c962e5814,unknown).
1::status(o_5779b732736080e32dbc,supported); 0::status(o_5779b732736080e32dbc,refuted); 0::status(o_5779b732736080e32dbc,unknown).
1::status(o_57c9cd4cf12f4c81b2ea,supported); 0::status(o_57c9cd4cf12f4c81b2ea,refuted); 0::status(o_57c9cd4cf12f4c81b2ea,unknown).
1::status(o_583f8ca9ee00bec03a60,supported); 0::status(o_583f8ca9ee00bec03a60,refuted); 0::status(o_583f8ca9ee00bec03a60,unknown).
1::status(o_5840ba7170ffe7bea33f,supported); 0::status(o_5840ba7170ffe7bea33f,refuted); 0::status(o_5840ba7170ffe7bea33f,unknown).
9.0030916908290237e-05::status(o_585e4db6437c600548a6,supported); 0::status(o_585e4db6437c600548a6,refuted); 0.99990996908309171::status(o_585e4db6437c600548a6,unknown).
0.0044489046558737755::status(o_586e0f67a5819b654d78,supported); 0::status(o_586e0f67a5819b654d78,refuted); 0.99555109534412622::status(o_586e0f67a5819b654d78,unknown).
1::status(o_58918967d74c99963a40,supported); 0::status(o_58918967d74c99963a40,refuted); 0::status(o_58918967d74c99963a40,unknown).
1::status(o_58fd681106e9badb688d,supported); 0::status(o_58fd681106e9badb688d,refuted); 0::status(o_58fd681106e9badb688d,unknown).
1::status(o_5934e747983b9894f72c,supported); 0::status(o_5934e747983b9894f72c,refuted); 0::status(o_5934e747983b9894f72c,unknown).
0.0013882720377296209::status(o_5945df731764dc88f23b,supported); 0::status(o_5945df731764dc88f23b,refuted); 0.99861172796227038::status(o_5945df731764dc88f23b,unknown).
0::status(o_5973feba43e4e18ad24d,supported); 1::status(o_5973feba43e4e18ad24d,refuted); 0::status(o_5973feba43e4e18ad24d,unknown).
1::status(o_59a3c08799dec2ed7724,supported); 0::status(o_59a3c08799dec2ed7724,refuted); 0::status(o_59a3c08799dec2ed7724,unknown).
0.99810886383056641::status(o_59f0b8dea2d24c1878c1,supported); 0::status(o_59f0b8dea2d24c1878c1,refuted); 0.0018911361694335938::status(o_59f0b8dea2d24c1878c1,unknown).
0::status(o_5a1236fe6f12752db1c2,supported); 0::status(o_5a1236fe6f12752db1c2,refuted); 1::status(o_5a1236fe6f12752db1c2,unknown).
0::status(o_5a798042e42cbfdc3ba5,supported); 1::status(o_5a798042e42cbfdc3ba5,refuted); 0::status(o_5a798042e42cbfdc3ba5,unknown).
0::status(o_5aad0b6f464c90daf2c4,supported); 1::status(o_5aad0b6f464c90daf2c4,refuted); 0::status(o_5aad0b6f464c90daf2c4,unknown).
0::status(o_5ab6bb3d30ef057d6d27,supported); 0::status(o_5ab6bb3d30ef057d6d27,refuted); 1::status(o_5ab6bb3d30ef057d6d27,unknown).
1::status(o_5ab76e66f3f29048017d,supported); 0::status(o_5ab76e66f3f29048017d,refuted); 0::status(o_5ab76e66f3f29048017d,unknown).
0.98928332328796387::status(o_5ab9eb70f3d28560ef45,supported); 0::status(o_5ab9eb70f3d28560ef45,refuted); 0.010716676712036133::status(o_5ab9eb70f3d28560ef45,unknown).
0.00012811402848456055::status(o_5ae8854efccdf6eb4ab4,supported); 0::status(o_5ae8854efccdf6eb4ab4,refuted); 0.99987188597151544::status(o_5ae8854efccdf6eb4ab4,unknown).
1::status(o_5b1c5ead063a9de38e81,supported); 0::status(o_5b1c5ead063a9de38e81,refuted); 0::status(o_5b1c5ead063a9de38e81,unknown).
5.5101139844798569e-05::status(o_5c2e28dc4cd76446cd2b,supported); 0::status(o_5c2e28dc4cd76446cd2b,refuted); 0.99994489886015525::status(o_5c2e28dc4cd76446cd2b,unknown).
1::status(o_5c6781a2c4b0fc630d1e,supported); 0::status(o_5c6781a2c4b0fc630d1e,refuted); 0::status(o_5c6781a2c4b0fc630d1e,unknown).
0::status(o_5d3ce3fcd246fd7b8c9b,supported); 1::status(o_5d3ce3fcd246fd7b8c9b,refuted); 0::status(o_5d3ce3fcd246fd7b8c9b,unknown).
1::status(o_5d4723ed329abc964615,supported); 0::status(o_5d4723ed329abc964615,refuted); 0::status(o_5d4723ed329abc964615,unknown).
0::status(o_5d51183e02d7b4f935fe,supported); 0::status(o_5d51183e02d7b4f935fe,refuted); 1::status(o_5d51183e02d7b4f935fe,unknown).
0.003883931552991271::status(o_5d67cc778d6f1485b3c6,supported); 0::status(o_5d67cc778d6f1485b3c6,refuted); 0.99611606844700873::status(o_5d67cc778d6f1485b3c6,unknown).
0::status(o_5d8a9b39d28dbd858578,supported); 1::status(o_5d8a9b39d28dbd858578,refuted); 0::status(o_5d8a9b39d28dbd858578,unknown).
1::status(o_5dc59784e1a5d69b0bd5,supported); 0::status(o_5dc59784e1a5d69b0bd5,refuted); 0::status(o_5dc59784e1a5d69b0bd5,unknown).
1::status(o_5e2cb7807c23ddfbfbaa,supported); 0::status(o_5e2cb7807c23ddfbfbaa,refuted); 0::status(o_5e2cb7807c23ddfbfbaa,unknown).
1::status(o_5e2fe45a61f243b7abac,supported); 0::status(o_5e2fe45a61f243b7abac,refuted); 0::status(o_5e2fe45a61f243b7abac,unknown).
0.98928332328796387::status(o_5e94c2e8eadcfc77dac6,supported); 0::status(o_5e94c2e8eadcfc77dac6,refuted); 0.010716676712036133::status(o_5e94c2e8eadcfc77dac6,unknown).
1::status(o_5e95ebe9d48d81287a2d,supported); 0::status(o_5e95ebe9d48d81287a2d,refuted); 0::status(o_5e95ebe9d48d81287a2d,unknown).
0.99969756536284771::status(o_5eb7f94bf064e829d366,supported); 0::status(o_5eb7f94bf064e829d366,refuted); 0.00030243463715229346::status(o_5eb7f94bf064e829d366,unknown).
1::status(o_5ed1283dceb9c6ec2527,supported); 0::status(o_5ed1283dceb9c6ec2527,refuted); 0::status(o_5ed1283dceb9c6ec2527,unknown).
1::status(o_5edd5fc6af2188a87f56,supported); 0::status(o_5edd5fc6af2188a87f56,refuted); 0::status(o_5edd5fc6af2188a87f56,unknown).
1::status(o_5f66facde37ec916d828,supported); 0::status(o_5f66facde37ec916d828,refuted); 0::status(o_5f66facde37ec916d828,unknown).
1::status(o_5f6d56185294e478ff16,supported); 0::status(o_5f6d56185294e478ff16,refuted); 0::status(o_5f6d56185294e478ff16,unknown).
0::status(o_5fcc5fe1d91e74d46e5c,supported); 1::status(o_5fcc5fe1d91e74d46e5c,refuted); 0::status(o_5fcc5fe1d91e74d46e5c,unknown).
1::status(o_603df3755828951766b4,supported); 0::status(o_603df3755828951766b4,refuted); 0::status(o_603df3755828951766b4,unknown).
1::status(o_606e7fdaf9cfb4b21781,supported); 0::status(o_606e7fdaf9cfb4b21781,refuted); 0::status(o_606e7fdaf9cfb4b21781,unknown).
0::status(o_608b8120a4b046460cbf,supported); 1::status(o_608b8120a4b046460cbf,refuted); 0::status(o_608b8120a4b046460cbf,unknown).
0.0093486057594418526::status(o_609a6b132446b56ef3c7,supported); 0::status(o_609a6b132446b56ef3c7,refuted); 0.99065139424055815::status(o_609a6b132446b56ef3c7,unknown).
0.039551112800836563::status(o_60ac771ebfecf1e51df8,supported); 0::status(o_60ac771ebfecf1e51df8,refuted); 0.96044888719916344::status(o_60ac771ebfecf1e51df8,unknown).
0::status(o_614663ad6093ec558f06,supported); 0::status(o_614663ad6093ec558f06,refuted); 1::status(o_614663ad6093ec558f06,unknown).
0.96754372119903564::status(o_614a2e4050aa71f8b651,supported); 0::status(o_614a2e4050aa71f8b651,refuted); 0.032456278800964355::status(o_614a2e4050aa71f8b651,unknown).
0.00063768832478672266::status(o_614d3a3ac5f5ea694117,supported); 0::status(o_614d3a3ac5f5ea694117,refuted); 0.99936231167521328::status(o_614d3a3ac5f5ea694117,unknown).
1::status(o_61bdaed29aab200b1e07,supported); 0::status(o_61bdaed29aab200b1e07,refuted); 0::status(o_61bdaed29aab200b1e07,unknown).
1::status(o_61eeb6034cdd70d1d66b,supported); 0::status(o_61eeb6034cdd70d1d66b,refuted); 0::status(o_61eeb6034cdd70d1d66b,unknown).
0::status(o_6263a2412b8c3cbaaab6,supported); 1::status(o_6263a2412b8c3cbaaab6,refuted); 0::status(o_6263a2412b8c3cbaaab6,unknown).
1::status(o_62afbbc79e74e4b46314,supported); 0::status(o_62afbbc79e74e4b46314,refuted); 0::status(o_62afbbc79e74e4b46314,unknown).
0.95374792814254761::status(o_630684c7fc1162ca5530,supported); 0::status(o_630684c7fc1162ca5530,refuted); 0.046252071857452393::status(o_630684c7fc1162ca5530,unknown).
0::status(o_631faac8fffc60050255,supported); 1::status(o_631faac8fffc60050255,refuted); 0::status(o_631faac8fffc60050255,unknown).
0.99734755297201794::status(o_63783cca1b37f7d0cbb9,supported); 0::status(o_63783cca1b37f7d0cbb9,refuted); 0.0026524470279820633::status(o_63783cca1b37f7d0cbb9,unknown).
7.9832112533040345e-05::status(o_6397aa38a20d30c1219e,supported); 0::status(o_6397aa38a20d30c1219e,refuted); 0.99992016788746696::status(o_6397aa38a20d30c1219e,unknown).
0.002602787222713232::status(o_63b7b2b44ada3858a4fa,supported); 0::status(o_63b7b2b44ada3858a4fa,refuted); 0.99739721277728677::status(o_63b7b2b44ada3858a4fa,unknown).
0.99609535932540894::status(o_63d05163b1f8612837cf,supported); 0::status(o_63d05163b1f8612837cf,refuted); 0.0039046406745910645::status(o_63d05163b1f8612837cf,unknown).
1::status(o_63e4d40fec225bbdd7f6,supported); 0::status(o_63e4d40fec225bbdd7f6,refuted); 0::status(o_63e4d40fec225bbdd7f6,unknown).
0.00063768832478672266::status(o_640d4c3e579ac8985a2c,supported); 0::status(o_640d4c3e579ac8985a2c,refuted); 0.99936231167521328::status(o_640d4c3e579ac8985a2c,unknown).
1::status(o_6438813fac3b0c62753f,supported); 0::status(o_6438813fac3b0c62753f,refuted); 0::status(o_6438813fac3b0c62753f,unknown).
1::status(o_646e6906b144f9ea616a,supported); 0::status(o_646e6906b144f9ea616a,refuted); 0::status(o_646e6906b144f9ea616a,unknown).
0.99737107753753662::status(o_64b7d3f7e8fe33c867b7,supported); 0::status(o_64b7d3f7e8fe33c867b7,refuted); 0.0026289224624633789::status(o_64b7d3f7e8fe33c867b7,unknown).
1::status(o_64fa6ff1e96d1458920f,supported); 0::status(o_64fa6ff1e96d1458920f,refuted); 0::status(o_64fa6ff1e96d1458920f,unknown).
0::status(o_650319a47b9b5a3e96b4,supported); 1::status(o_650319a47b9b5a3e96b4,refuted); 0::status(o_650319a47b9b5a3e96b4,unknown).
0::status(o_655c4da19cf1de846d19,supported); 0::status(o_655c4da19cf1de846d19,refuted); 1::status(o_655c4da19cf1de846d19,unknown).
0.99738341569900513::status(o_66757b15f877295bf6e6,supported); 0::status(o_66757b15f877295bf6e6,refuted); 0.002616584300994873::status(o_66757b15f877295bf6e6,unknown).
0::status(o_668a3fff57a960a01dec,supported); 1::status(o_668a3fff57a960a01dec,refuted); 0::status(o_668a3fff57a960a01dec,unknown).
1::status(o_6693bc2edd43f7265d16,supported); 0::status(o_6693bc2edd43f7265d16,refuted); 0::status(o_6693bc2edd43f7265d16,unknown).
0::status(o_66c45649dc481cdc23a5,supported); 1::status(o_66c45649dc481cdc23a5,refuted); 0::status(o_66c45649dc481cdc23a5,unknown).
0.98626255989074707::status(o_66c995d383d9681601d1,supported); 0::status(o_66c995d383d9681601d1,refuted); 0.01373744010925293::status(o_66c995d383d9681601d1,unknown).
0.99660646915435791::status(o_671660fdf2b92841942f,supported); 0::status(o_671660fdf2b92841942f,refuted); 0.0033935308456420898::status(o_671660fdf2b92841942f,unknown).
0.003883931552991271::status(o_6761df32008c0a2e8123,supported); 0::status(o_6761df32008c0a2e8123,refuted); 0.99611606844700873::status(o_6761df32008c0a2e8123,unknown).
1::status(o_678e2847974edbda881a,supported); 0::status(o_678e2847974edbda881a,refuted); 0::status(o_678e2847974edbda881a,unknown).
1::status(o_67af35a0ea8c2de1d4b2,supported); 0::status(o_67af35a0ea8c2de1d4b2,refuted); 0::status(o_67af35a0ea8c2de1d4b2,unknown).
0::status(o_67c198908a696f1a1378,supported); 0::status(o_67c198908a696f1a1378,refuted); 1::status(o_67c198908a696f1a1378,unknown).
0.0093486057594418526::status(o_67e00e9927c65ccb062b,supported); 0::status(o_67e00e9927c65ccb062b,refuted); 0.99065139424055815::status(o_67e00e9927c65ccb062b,unknown).
1::status(o_67e4e5e22a0947cc8b02,supported); 0::status(o_67e4e5e22a0947cc8b02,refuted); 0::status(o_67e4e5e22a0947cc8b02,unknown).
1::status(o_67f362038ae07dc6785f,supported); 0::status(o_67f362038ae07dc6785f,refuted); 0::status(o_67f362038ae07dc6785f,unknown).
0.99810886383056641::status(o_67f6959423b876ea7a6b,supported); 0::status(o_67f6959423b876ea7a6b,refuted); 0.0018911361694335938::status(o_67f6959423b876ea7a6b,unknown).
1::status(o_680dd57c03543389cb1c,supported); 0::status(o_680dd57c03543389cb1c,refuted); 0::status(o_680dd57c03543389cb1c,unknown).
1::status(o_68112609dc8f2f51964d,supported); 0::status(o_68112609dc8f2f51964d,refuted); 0::status(o_68112609dc8f2f51964d,unknown).
0.00027939380379393697::status(o_682e57e3d8673e74c97e,supported); 0::status(o_682e57e3d8673e74c97e,refuted); 0.99972060619620606::status(o_682e57e3d8673e74c97e,unknown).
1::status(o_68dc25f61199658be1a7,supported); 0::status(o_68dc25f61199658be1a7,refuted); 0::status(o_68dc25f61199658be1a7,unknown).
1::status(o_69048f56fe5f7d10a2a1,supported); 0::status(o_69048f56fe5f7d10a2a1,refuted); 0::status(o_69048f56fe5f7d10a2a1,unknown).
0.0010018589673563838::status(o_69487d3048788c389fd8,supported); 0::status(o_69487d3048788c389fd8,refuted); 0.99899814103264362::status(o_69487d3048788c389fd8,unknown).
1::status(o_69fcd8a3890e230153ac,supported); 0::status(o_69fcd8a3890e230153ac,refuted); 0::status(o_69fcd8a3890e230153ac,unknown).
1::status(o_69fffe22a82f2b8f8d91,supported); 0::status(o_69fffe22a82f2b8f8d91,refuted); 0::status(o_69fffe22a82f2b8f8d91,unknown).
0.97427183389663696::status(o_6a144a3090d472dff4da,supported); 0::status(o_6a144a3090d472dff4da,refuted); 0.025728166103363037::status(o_6a144a3090d472dff4da,unknown).
0::status(o_6a3dbb3224d50fbd0399,supported); 1::status(o_6a3dbb3224d50fbd0399,refuted); 0::status(o_6a3dbb3224d50fbd0399,unknown).
1::status(o_6a7cd51126352371c072,supported); 0::status(o_6a7cd51126352371c072,refuted); 0::status(o_6a7cd51126352371c072,unknown).
1::status(o_6a8df846d961108514e0,supported); 0::status(o_6a8df846d961108514e0,refuted); 0::status(o_6a8df846d961108514e0,unknown).
1::status(o_6b00adb6ed8e1192ea8f,supported); 0::status(o_6b00adb6ed8e1192ea8f,refuted); 0::status(o_6b00adb6ed8e1192ea8f,unknown).
0::status(o_6b0abad21eaff72b5c60,supported); 1::status(o_6b0abad21eaff72b5c60,refuted); 0::status(o_6b0abad21eaff72b5c60,unknown).
0.28751092054261485::status(o_6b40e9cdc337a99ac6fa,supported); 0::status(o_6b40e9cdc337a99ac6fa,refuted); 0.71248907945738515::status(o_6b40e9cdc337a99ac6fa,unknown).
0.99999999306661269::status(o_6b6d387a88501cabedd1,supported); 0::status(o_6b6d387a88501cabedd1,refuted); 6.9333873087273901e-09::status(o_6b6d387a88501cabedd1,unknown).
0.99999108955419413::status(o_6b9f73acfcaa60eaad63,supported); 0::status(o_6b9f73acfcaa60eaad63,refuted); 8.910445805865308e-06::status(o_6b9f73acfcaa60eaad63,unknown).
1::status(o_6bc523b6b1836c14590f,supported); 0::status(o_6bc523b6b1836c14590f,refuted); 0::status(o_6bc523b6b1836c14590f,unknown).
1::status(o_6bf12afc5c27f7e06131,supported); 0::status(o_6bf12afc5c27f7e06131,refuted); 0::status(o_6bf12afc5c27f7e06131,unknown).
1::status(o_6bfbe84ab2ffcf25c7df,supported); 0::status(o_6bfbe84ab2ffcf25c7df,refuted); 0::status(o_6bfbe84ab2ffcf25c7df,unknown).
5.7750552951804822e-05::status(o_6c014c5dca7fa9f17f52,supported); 0::status(o_6c014c5dca7fa9f17f52,refuted); 0.99994224944704824::status(o_6c014c5dca7fa9f17f52,unknown).
0.00085279322229325771::status(o_6c3c0334d533d77d12e7,supported); 0::status(o_6c3c0334d533d77d12e7,refuted); 0.99914720677770674::status(o_6c3c0334d533d77d12e7,unknown).
1::status(o_6c62f248a5208cb56091,supported); 0::status(o_6c62f248a5208cb56091,refuted); 0::status(o_6c62f248a5208cb56091,unknown).
1::status(o_6c9b7cdfd35e6570bb4d,supported); 0::status(o_6c9b7cdfd35e6570bb4d,refuted); 0::status(o_6c9b7cdfd35e6570bb4d,unknown).
0.99999939047324271::status(o_6cab4b6260d998f96f1a,supported); 0::status(o_6cab4b6260d998f96f1a,refuted); 6.0952675728920269e-07::status(o_6cab4b6260d998f96f1a,unknown).
1::status(o_6cb206aac10d9ea041ee,supported); 0::status(o_6cb206aac10d9ea041ee,refuted); 0::status(o_6cb206aac10d9ea041ee,unknown).
0::status(o_6cccf5218521a4fc3551,supported); 1::status(o_6cccf5218521a4fc3551,refuted); 0::status(o_6cccf5218521a4fc3551,unknown).
0.98913842439651489::status(o_6ced51da0dc7498976d3,supported); 0::status(o_6ced51da0dc7498976d3,refuted); 0.010861575603485107::status(o_6ced51da0dc7498976d3,unknown).
1::status(o_6d126d89ae968db9970e,supported); 0::status(o_6d126d89ae968db9970e,refuted); 0::status(o_6d126d89ae968db9970e,unknown).
1::status(o_6d568bef0acc52bfcaac,supported); 0::status(o_6d568bef0acc52bfcaac,refuted); 0::status(o_6d568bef0acc52bfcaac,unknown).
0::status(o_6d74fd641a4e40c96bf1,supported); 0::status(o_6d74fd641a4e40c96bf1,refuted); 1::status(o_6d74fd641a4e40c96bf1,unknown).
0::status(o_6d93f26475345fc6f68d,supported); 1::status(o_6d93f26475345fc6f68d,refuted); 0::status(o_6d93f26475345fc6f68d,unknown).
1::status(o_6df5b84179eb7c51f630,supported); 0::status(o_6df5b84179eb7c51f630,refuted); 0::status(o_6df5b84179eb7c51f630,unknown).
0.00076209998223930597::status(o_6e0576a3ed266675bc4c,supported); 0::status(o_6e0576a3ed266675bc4c,refuted); 0.99923790001776069::status(o_6e0576a3ed266675bc4c,unknown).
0.96227091550827026::status(o_6e1aab03e377642dd091,supported); 0::status(o_6e1aab03e377642dd091,refuted); 0.037729084491729736::status(o_6e1aab03e377642dd091,unknown).
1::status(o_6e4647d4b43561d1fdbc,supported); 0::status(o_6e4647d4b43561d1fdbc,refuted); 0::status(o_6e4647d4b43561d1fdbc,unknown).
1::status(o_6e707e0fab928955adf3,supported); 0::status(o_6e707e0fab928955adf3,refuted); 0::status(o_6e707e0fab928955adf3,unknown).
1::status(o_6e7b495fecfad560cc92,supported); 0::status(o_6e7b495fecfad560cc92,refuted); 0::status(o_6e7b495fecfad560cc92,unknown).
1::status(o_6e870bc4d9ee09ca1db0,supported); 0::status(o_6e870bc4d9ee09ca1db0,refuted); 0::status(o_6e870bc4d9ee09ca1db0,unknown).
0.0004814279091078788::status(o_6f08aa4295b14eeb4332,supported); 0::status(o_6f08aa4295b14eeb4332,refuted); 0.99951857209089212::status(o_6f08aa4295b14eeb4332,unknown).
0.99213320016860962::status(o_6f21d3231fd831ede60f,supported); 0::status(o_6f21d3231fd831ede60f,refuted); 0.0078667998313903809::status(o_6f21d3231fd831ede60f,unknown).
5.6871512399229536e-07::status(o_6f61965829a9667777de,supported); 0::status(o_6f61965829a9667777de,refuted); 0.99999943128487601::status(o_6f61965829a9667777de,unknown).
0::status(o_6f675db72fdf5e519f4a,supported); 0::status(o_6f675db72fdf5e519f4a,refuted); 1::status(o_6f675db72fdf5e519f4a,unknown).
0.00044824578799307346::status(o_6f9dcec3ea86b6cecd1c,supported); 0::status(o_6f9dcec3ea86b6cecd1c,refuted); 0.99955175421200693::status(o_6f9dcec3ea86b6cecd1c,unknown).
0.039551112800836563::status(o_6f9e13cf909a274e058b,supported); 0::status(o_6f9e13cf909a274e058b,refuted); 0.96044888719916344::status(o_6f9e13cf909a274e058b,unknown).
0::status(o_6fa88d6304069b08e4f9,supported); 1::status(o_6fa88d6304069b08e4f9,refuted); 0::status(o_6fa88d6304069b08e4f9,unknown).
0.99007987976074219::status(o_6fb4744fe4db4d3ff6c7,supported); 0::status(o_6fb4744fe4db4d3ff6c7,refuted); 0.0099201202392578125::status(o_6fb4744fe4db4d3ff6c7,unknown).
0::status(o_6fbfe6aebfefe18b81ce,supported); 1::status(o_6fbfe6aebfefe18b81ce,refuted); 0::status(o_6fbfe6aebfefe18b81ce,unknown).
1::status(o_700c7a349a050fb0d69b,supported); 0::status(o_700c7a349a050fb0d69b,refuted); 0::status(o_700c7a349a050fb0d69b,unknown).
0::status(o_70155044e137fa0d8a20,supported); 1::status(o_70155044e137fa0d8a20,refuted); 0::status(o_70155044e137fa0d8a20,unknown).
1::status(o_70aa97afad1db9495b33,supported); 0::status(o_70aa97afad1db9495b33,refuted); 0::status(o_70aa97afad1db9495b33,unknown).
0::status(o_71223479fab934fa8f1e,supported); 1::status(o_71223479fab934fa8f1e,refuted); 0::status(o_71223479fab934fa8f1e,unknown).
0.0013122661039233208::status(o_7251e3df35df8c8d83db,supported); 0::status(o_7251e3df35df8c8d83db,refuted); 0.99868773389607668::status(o_7251e3df35df8c8d83db,unknown).
1::status(o_725373ebd0ba4c63d2ef,supported); 0::status(o_725373ebd0ba4c63d2ef,refuted); 0::status(o_725373ebd0ba4c63d2ef,unknown).
1::status(o_728b376e763b595b04d1,supported); 0::status(o_728b376e763b595b04d1,refuted); 0::status(o_728b376e763b595b04d1,unknown).
0.99964323617997897::status(o_72ce21eba031bac85280,supported); 0::status(o_72ce21eba031bac85280,refuted); 0.00035676382002103324::status(o_72ce21eba031bac85280,unknown).
0.99495738744735718::status(o_72e743c5aef0c7a0e1ae,supported); 0::status(o_72e743c5aef0c7a0e1ae,refuted); 0.0050426125526428223::status(o_72e743c5aef0c7a0e1ae,unknown).
0.97427183389663696::status(o_72f168e9aca5bd4cb4ae,supported); 0::status(o_72f168e9aca5bd4cb4ae,refuted); 0.025728166103363037::status(o_72f168e9aca5bd4cb4ae,unknown).
0::status(o_732b9023d461a41d03c6,supported); 1::status(o_732b9023d461a41d03c6,refuted); 0::status(o_732b9023d461a41d03c6,unknown).
0.99660646915435791::status(o_7345bcb2241390fb2eb6,supported); 0::status(o_7345bcb2241390fb2eb6,refuted); 0.0033935308456420898::status(o_7345bcb2241390fb2eb6,unknown).
1::status(o_738ccd3eda1589953570,supported); 0::status(o_738ccd3eda1589953570,refuted); 0::status(o_738ccd3eda1589953570,unknown).
0::status(o_7393d396786bb9131215,supported); 0::status(o_7393d396786bb9131215,refuted); 1::status(o_7393d396786bb9131215,unknown).
0::status(o_73ef785df814b2d1b8bf,supported); 1::status(o_73ef785df814b2d1b8bf,refuted); 0::status(o_73ef785df814b2d1b8bf,unknown).
0::status(o_73f953214a253dd8f68c,supported); 1::status(o_73f953214a253dd8f68c,refuted); 0::status(o_73f953214a253dd8f68c,unknown).
0.00012811402848456055::status(o_73fb4e0ab6c90e240c97,supported); 0::status(o_73fb4e0ab6c90e240c97,refuted); 0.99987188597151544::status(o_73fb4e0ab6c90e240c97,unknown).
1::status(o_7442a3d19f20279f7334,supported); 0::status(o_7442a3d19f20279f7334,refuted); 0::status(o_7442a3d19f20279f7334,unknown).
1::status(o_74696ff4131f29c347e6,supported); 0::status(o_74696ff4131f29c347e6,refuted); 0::status(o_74696ff4131f29c347e6,unknown).
0.2129049152135849::status(o_74bf1320a9a15aeb2302,supported); 0::status(o_74bf1320a9a15aeb2302,refuted); 0.7870950847864151::status(o_74bf1320a9a15aeb2302,unknown).
0.2129049152135849::status(o_75291eec3196fa4db1c1,supported); 0::status(o_75291eec3196fa4db1c1,refuted); 0.7870950847864151::status(o_75291eec3196fa4db1c1,unknown).
1::status(o_753c75f6072cd83064a5,supported); 0::status(o_753c75f6072cd83064a5,refuted); 0::status(o_753c75f6072cd83064a5,unknown).
0.002602787222713232::status(o_754a5e62f9895b9429c2,supported); 0::status(o_754a5e62f9895b9429c2,refuted); 0.99739721277728677::status(o_754a5e62f9895b9429c2,unknown).
0.00011422050738474354::status(o_7588601aaef449314c79,supported); 0::status(o_7588601aaef449314c79,refuted); 0.99988577949261526::status(o_7588601aaef449314c79,unknown).
1::status(o_759dfb04f470479d57f9,supported); 0::status(o_759dfb04f470479d57f9,refuted); 0::status(o_759dfb04f470479d57f9,unknown).
1::status(o_75c2dd35d4bf1bc9ee0b,supported); 0::status(o_75c2dd35d4bf1bc9ee0b,refuted); 0::status(o_75c2dd35d4bf1bc9ee0b,unknown).
0.99810886383056641::status(o_75d51a00c3ba36a2d6fe,supported); 0::status(o_75d51a00c3ba36a2d6fe,refuted); 0.0018911361694335938::status(o_75d51a00c3ba36a2d6fe,unknown).
0.091254428029060364::status(o_765d2d8205b705db09fa,supported); 0::status(o_765d2d8205b705db09fa,refuted); 0.90874557197093964::status(o_765d2d8205b705db09fa,unknown).
1::status(o_76a760aa6e85790bd89a,supported); 0::status(o_76a760aa6e85790bd89a,refuted); 0::status(o_76a760aa6e85790bd89a,unknown).
1::status(o_76b35bcadc9ef6ef8e20,supported); 0::status(o_76b35bcadc9ef6ef8e20,refuted); 0::status(o_76b35bcadc9ef6ef8e20,unknown).
0.00011422050738474354::status(o_76b8758c6ed9da6ba25f,supported); 0::status(o_76b8758c6ed9da6ba25f,refuted); 0.99988577949261526::status(o_76b8758c6ed9da6ba25f,unknown).
0::status(o_770951911732ba83ee3f,supported); 0::status(o_770951911732ba83ee3f,refuted); 1::status(o_770951911732ba83ee3f,unknown).
0.039551112800836563::status(o_773e2a3f088021a77906,supported); 0::status(o_773e2a3f088021a77906,refuted); 0.96044888719916344::status(o_773e2a3f088021a77906,unknown).
1::status(o_7750c71126a1910ffb8c,supported); 0::status(o_7750c71126a1910ffb8c,refuted); 0::status(o_7750c71126a1910ffb8c,unknown).
0.037853103131055832::status(o_775aa410741fa388d325,supported); 0::status(o_775aa410741fa388d325,refuted); 0.96214689686894417::status(o_775aa410741fa388d325,unknown).
1::status(o_77635d914d8ad7bc185b,supported); 0::status(o_77635d914d8ad7bc185b,refuted); 0::status(o_77635d914d8ad7bc185b,unknown).
0.067158885300159454::status(o_7784360eebc16e5aa8c0,supported); 0::status(o_7784360eebc16e5aa8c0,refuted); 0.93284111469984055::status(o_7784360eebc16e5aa8c0,unknown).
0.99999999827831965::status(o_77b4fc96785ec067eae5,supported); 0::status(o_77b4fc96785ec067eae5,refuted); 1.7216803538389058e-09::status(o_77b4fc96785ec067eae5,unknown).
1::status(o_78abaa31c67da556aff2,supported); 0::status(o_78abaa31c67da556aff2,refuted); 0::status(o_78abaa31c67da556aff2,unknown).
1::status(o_78bb8b1145b13fbcf8ed,supported); 0::status(o_78bb8b1145b13fbcf8ed,refuted); 0::status(o_78bb8b1145b13fbcf8ed,unknown).
0.61694091558456421::status(o_78be6857d601b49cd1d8,supported); 0::status(o_78be6857d601b49cd1d8,refuted); 0.38305908441543579::status(o_78be6857d601b49cd1d8,unknown).
1::status(o_78c675799fca887a4d17,supported); 0::status(o_78c675799fca887a4d17,refuted); 0::status(o_78c675799fca887a4d17,unknown).
0.002940004225820303::status(o_78d7b93461dbaf4c7d9b,supported); 0::status(o_78d7b93461dbaf4c7d9b,refuted); 0.9970599957741797::status(o_78d7b93461dbaf4c7d9b,unknown).
1::status(o_78dcb7a3edbf856a2873,supported); 0::status(o_78dcb7a3edbf856a2873,refuted); 0::status(o_78dcb7a3edbf856a2873,unknown).
1::status(o_78f1772efe2839a0bdda,supported); 0::status(o_78f1772efe2839a0bdda,refuted); 0::status(o_78f1772efe2839a0bdda,unknown).
0.0070033296942710876::status(o_792b2cf8b6e91f400b6f,supported); 0::status(o_792b2cf8b6e91f400b6f,refuted); 0.99299667030572891::status(o_792b2cf8b6e91f400b6f,unknown).
1::status(o_794b5356e84051037fd5,supported); 0::status(o_794b5356e84051037fd5,refuted); 0::status(o_794b5356e84051037fd5,unknown).
1::status(o_7982ce2458f272ecd188,supported); 0::status(o_7982ce2458f272ecd188,refuted); 0::status(o_7982ce2458f272ecd188,unknown).
0.99172943830490112::status(o_79b5f8dbc92b30527023,supported); 0::status(o_79b5f8dbc92b30527023,refuted); 0.008270561695098877::status(o_79b5f8dbc92b30527023,unknown).
1::status(o_79fcb94bd0a0ded259bb,supported); 0::status(o_79fcb94bd0a0ded259bb,refuted); 0::status(o_79fcb94bd0a0ded259bb,unknown).
0::status(o_7a05d5fe78e69743d0a9,supported); 0::status(o_7a05d5fe78e69743d0a9,refuted); 1::status(o_7a05d5fe78e69743d0a9,unknown).
1::status(o_7a08cfce0dfa729f9a0b,supported); 0::status(o_7a08cfce0dfa729f9a0b,refuted); 0::status(o_7a08cfce0dfa729f9a0b,unknown).
1::status(o_7a4de60d11afc861ceb1,supported); 0::status(o_7a4de60d11afc861ceb1,refuted); 0::status(o_7a4de60d11afc861ceb1,unknown).
0::status(o_7a7a868f60a336ea91d8,supported); 1::status(o_7a7a868f60a336ea91d8,refuted); 0::status(o_7a7a868f60a336ea91d8,unknown).
0.037853103131055832::status(o_7a824cce4f4d39be73b1,supported); 0::status(o_7a824cce4f4d39be73b1,refuted); 0.96214689686894417::status(o_7a824cce4f4d39be73b1,unknown).
0.0060226605273783207::status(o_7a8defbec8463a8c7f01,supported); 0::status(o_7a8defbec8463a8c7f01,refuted); 0.99397733947262168::status(o_7a8defbec8463a8c7f01,unknown).
0.00062835169956088066::status(o_7abaed82962380f70415,supported); 0::status(o_7abaed82962380f70415,refuted); 0.99937164830043912::status(o_7abaed82962380f70415,unknown).
1::status(o_7abb67f7350c48b3824d,supported); 0::status(o_7abb67f7350c48b3824d,refuted); 0::status(o_7abb67f7350c48b3824d,unknown).
1::status(o_7add1d1135ffa4da8996,supported); 0::status(o_7add1d1135ffa4da8996,refuted); 0::status(o_7add1d1135ffa4da8996,unknown).
0.00074594078844149683::status(o_7b507422892e7e993156,supported); 0::status(o_7b507422892e7e993156,refuted); 0.99925405921155852::status(o_7b507422892e7e993156,unknown).
0.003883931552991271::status(o_7b53b358a5e413184821,supported); 0::status(o_7b53b358a5e413184821,refuted); 0.99611606844700873::status(o_7b53b358a5e413184821,unknown).
1::status(o_7b643ec98a8a72f40e1f,supported); 0::status(o_7b643ec98a8a72f40e1f,refuted); 0::status(o_7b643ec98a8a72f40e1f,unknown).
0.98880964517593384::status(o_7b73227cb18f3be107b9,supported); 0::status(o_7b73227cb18f3be107b9,refuted); 0.011190354824066162::status(o_7b73227cb18f3be107b9,unknown).
0::status(o_7b960b5d721fd46bc3f3,supported); 1::status(o_7b960b5d721fd46bc3f3,refuted); 0::status(o_7b960b5d721fd46bc3f3,unknown).
0.99361503124237061::status(o_7bbae0e47ef3c8aa5dbe,supported); 0::status(o_7bbae0e47ef3c8aa5dbe,refuted); 0.0063849687576293945::status(o_7bbae0e47ef3c8aa5dbe,unknown).
1::status(o_7bc5750ddcaacc9f2db8,supported); 0::status(o_7bc5750ddcaacc9f2db8,refuted); 0::status(o_7bc5750ddcaacc9f2db8,unknown).
1::status(o_7bea8e26deec4b36c459,supported); 0::status(o_7bea8e26deec4b36c459,refuted); 0::status(o_7bea8e26deec4b36c459,unknown).
0.99495762586593628::status(o_7bfb86addd2f29ddfad6,supported); 0::status(o_7bfb86addd2f29ddfad6,refuted); 0.0050423741340637207::status(o_7bfb86addd2f29ddfad6,unknown).
0.0004814279091078788::status(o_7ca35e073d20292b0cb0,supported); 0::status(o_7ca35e073d20292b0cb0,refuted); 0.99951857209089212::status(o_7ca35e073d20292b0cb0,unknown).
1::status(o_7d18a7ab20b944a82b6e,supported); 0::status(o_7d18a7ab20b944a82b6e,refuted); 0::status(o_7d18a7ab20b944a82b6e,unknown).
0.99660646915435791::status(o_7d374a4c88e047a22d0e,supported); 0::status(o_7d374a4c88e047a22d0e,refuted); 0.0033935308456420898::status(o_7d374a4c88e047a22d0e,unknown).
0.98913842439651489::status(o_7d6476da18525cf61888,supported); 0::status(o_7d6476da18525cf61888,refuted); 0.010861575603485107::status(o_7d6476da18525cf61888,unknown).
1::status(o_7df28a6a6df1f9389720,supported); 0::status(o_7df28a6a6df1f9389720,refuted); 0::status(o_7df28a6a6df1f9389720,unknown).
0.99185353517532349::status(o_7e11955a4bef5f562a66,supported); 0::status(o_7e11955a4bef5f562a66,refuted); 0.0081464648246765137::status(o_7e11955a4bef5f562a66,unknown).
1::status(o_7e2fa1dcf7021591212f,supported); 0::status(o_7e2fa1dcf7021591212f,refuted); 0::status(o_7e2fa1dcf7021591212f,unknown).
0.99876297288292504::status(o_7e81a84526ba5f2ed35b,supported); 0::status(o_7e81a84526ba5f2ed35b,refuted); 0.0012370271170749625::status(o_7e81a84526ba5f2ed35b,unknown).
1::status(o_7e8c9cc0f7fa86251719,supported); 0::status(o_7e8c9cc0f7fa86251719,refuted); 0::status(o_7e8c9cc0f7fa86251719,unknown).
0.99660646915435791::status(o_7eb5eef41233f4ff4705,supported); 0::status(o_7eb5eef41233f4ff4705,refuted); 0.0033935308456420898::status(o_7eb5eef41233f4ff4705,unknown).
1::status(o_7ebfdfdda6cd43210235,supported); 0::status(o_7ebfdfdda6cd43210235,refuted); 0::status(o_7ebfdfdda6cd43210235,unknown).
0::status(o_7ec5ef68f99b8c9eee80,supported); 1::status(o_7ec5ef68f99b8c9eee80,refuted); 0::status(o_7ec5ef68f99b8c9eee80,unknown).
0.99999999827831965::status(o_7f2cb7d398f60b1f2295,supported); 0::status(o_7f2cb7d398f60b1f2295,refuted); 1.7216803538389058e-09::status(o_7f2cb7d398f60b1f2295,unknown).
1::status(o_7f4bd77ddfcff7c6fe16,supported); 0::status(o_7f4bd77ddfcff7c6fe16,refuted); 0::status(o_7f4bd77ddfcff7c6fe16,unknown).
0.98949754238128662::status(o_7f5068cc07034ce53972,supported); 0::status(o_7f5068cc07034ce53972,refuted); 0.010502457618713379::status(o_7f5068cc07034ce53972,unknown).
1::status(o_7f5741e6d7632eb6a1a4,supported); 0::status(o_7f5741e6d7632eb6a1a4,refuted); 0::status(o_7f5741e6d7632eb6a1a4,unknown).
1::status(o_7fbfd2423099a0b8b1d3,supported); 0::status(o_7fbfd2423099a0b8b1d3,refuted); 0::status(o_7fbfd2423099a0b8b1d3,unknown).
0.99361503124237061::status(o_7fe99231c72cd79dd2af,supported); 0::status(o_7fe99231c72cd79dd2af,refuted); 0.0063849687576293945::status(o_7fe99231c72cd79dd2af,unknown).
0::status(o_8023677404c9057ac91d,supported); 0::status(o_8023677404c9057ac91d,refuted); 1::status(o_8023677404c9057ac91d,unknown).
0::status(o_80357a5d20213527abba,supported); 1::status(o_80357a5d20213527abba,refuted); 0::status(o_80357a5d20213527abba,unknown).
0::status(o_80997c68d9bff581855b,supported); 1::status(o_80997c68d9bff581855b,refuted); 0::status(o_80997c68d9bff581855b,unknown).
1::status(o_80cebdaf44c01eca00f4,supported); 0::status(o_80cebdaf44c01eca00f4,refuted); 0::status(o_80cebdaf44c01eca00f4,unknown).
0::status(o_814499a0b2d441249e2f,supported); 1::status(o_814499a0b2d441249e2f,refuted); 0::status(o_814499a0b2d441249e2f,unknown).
1::status(o_81493205849ce356b11a,supported); 0::status(o_81493205849ce356b11a,refuted); 0::status(o_81493205849ce356b11a,unknown).
0.9941440224647522::status(o_81a173ea8b53518399f3,supported); 0::status(o_81a173ea8b53518399f3,refuted); 0.0058559775352478027::status(o_81a173ea8b53518399f3,unknown).
0.99007987976074219::status(o_81c42e465ef204b6b0da,supported); 0::status(o_81c42e465ef204b6b0da,refuted); 0.0099201202392578125::status(o_81c42e465ef204b6b0da,unknown).
0::status(o_81e6f94978c079f4646b,supported); 0::status(o_81e6f94978c079f4646b,refuted); 1::status(o_81e6f94978c079f4646b,unknown).
0::status(o_8261c27e16dac47860f4,supported); 0::status(o_8261c27e16dac47860f4,refuted); 1::status(o_8261c27e16dac47860f4,unknown).
0::status(o_829a3aa169c0dc7fb256,supported); 1::status(o_829a3aa169c0dc7fb256,refuted); 0::status(o_829a3aa169c0dc7fb256,unknown).
0.61694091558456421::status(o_82b2b1c5e3eccec268b9,supported); 0::status(o_82b2b1c5e3eccec268b9,refuted); 0.38305908441543579::status(o_82b2b1c5e3eccec268b9,unknown).
0.99999996709064987::status(o_82bb8cef1faefbf090f8,supported); 0::status(o_82bb8cef1faefbf090f8,refuted); 3.2909350133891735e-08::status(o_82bb8cef1faefbf090f8,unknown).
0.99998772104878231::status(o_830a7c0ad7e79d53229f,supported); 0::status(o_830a7c0ad7e79d53229f,refuted); 1.2278951217692402e-05::status(o_830a7c0ad7e79d53229f,unknown).
0.99185353517532349::status(o_830f61633eba3e009470,supported); 0::status(o_830f61633eba3e009470,refuted); 0.0081464648246765137::status(o_830f61633eba3e009470,unknown).
0.999999966881435::status(o_831fef9d5f43f38a7214,supported); 0::status(o_831fef9d5f43f38a7214,refuted); 3.3118565001544198e-08::status(o_831fef9d5f43f38a7214,unknown).
1::status(o_832d4281f5d9f7d6a0e7,supported); 0::status(o_832d4281f5d9f7d6a0e7,refuted); 0::status(o_832d4281f5d9f7d6a0e7,unknown).
0.98212242126464844::status(o_8361cfecb97ec523e45d,supported); 0::status(o_8361cfecb97ec523e45d,refuted); 0.017877578735351562::status(o_8361cfecb97ec523e45d,unknown).
1::status(o_8369477e5f47ddd0ec63,supported); 0::status(o_8369477e5f47ddd0ec63,refuted); 0::status(o_8369477e5f47ddd0ec63,unknown).
0.61694091558456421::status(o_836fb12b9690bc498e14,supported); 0::status(o_836fb12b9690bc498e14,refuted); 0.38305908441543579::status(o_836fb12b9690bc498e14,unknown).
1::status(o_83ba879525ebe62f7a7c,supported); 0::status(o_83ba879525ebe62f7a7c,refuted); 0::status(o_83ba879525ebe62f7a7c,unknown).
1::status(o_842e4269a090dd2b5512,supported); 0::status(o_842e4269a090dd2b5512,refuted); 0::status(o_842e4269a090dd2b5512,unknown).
0.0010018589673563838::status(o_843ab1dfc5fa898aae39,supported); 0::status(o_843ab1dfc5fa898aae39,refuted); 0.99899814103264362::status(o_843ab1dfc5fa898aae39,unknown).
1::status(o_84641b5d925bc52c2f8e,supported); 0::status(o_84641b5d925bc52c2f8e,refuted); 0::status(o_84641b5d925bc52c2f8e,unknown).
0.0016452829586341977::status(o_8485da62a489ee004499,supported); 0::status(o_8485da62a489ee004499,refuted); 0.9983547170413658::status(o_8485da62a489ee004499,unknown).
0.00038813083665445447::status(o_84bb915a197998ce35c6,supported); 0::status(o_84bb915a197998ce35c6,refuted); 0.99961186916334555::status(o_84bb915a197998ce35c6,unknown).
1::status(o_84e16fa617233a4d72ab,supported); 0::status(o_84e16fa617233a4d72ab,refuted); 0::status(o_84e16fa617233a4d72ab,unknown).
1::status(o_854b3e417e9d92ae5f68,supported); 0::status(o_854b3e417e9d92ae5f68,refuted); 0::status(o_854b3e417e9d92ae5f68,unknown).
1::status(o_85b42e9a172552eb6a8b,supported); 0::status(o_85b42e9a172552eb6a8b,refuted); 0::status(o_85b42e9a172552eb6a8b,unknown).
0.9888228178024292::status(o_8648c9f38f6dee565588,supported); 0::status(o_8648c9f38f6dee565588,refuted); 0.011177182197570801::status(o_8648c9f38f6dee565588,unknown).
1::status(o_866ca77c94e5bd29d8b9,supported); 0::status(o_866ca77c94e5bd29d8b9,refuted); 0::status(o_866ca77c94e5bd29d8b9,unknown).
1::status(o_868c1d305ce07819bf7b,supported); 0::status(o_868c1d305ce07819bf7b,refuted); 0::status(o_868c1d305ce07819bf7b,unknown).
0.0093486057594418526::status(o_86aaec6a802035dd76e9,supported); 0::status(o_86aaec6a802035dd76e9,refuted); 0.99065139424055815::status(o_86aaec6a802035dd76e9,unknown).
0.99738341569900513::status(o_86d282e11ab1fe970e48,supported); 0::status(o_86d282e11ab1fe970e48,refuted); 0.002616584300994873::status(o_86d282e11ab1fe970e48,unknown).
0.99660646915435791::status(o_86e2e8087fd9ca3ac6bd,supported); 0::status(o_86e2e8087fd9ca3ac6bd,refuted); 0.0033935308456420898::status(o_86e2e8087fd9ca3ac6bd,unknown).
1::status(o_8706dc1df63bd2d65aae,supported); 0::status(o_8706dc1df63bd2d65aae,refuted); 0::status(o_8706dc1df63bd2d65aae,unknown).
0.99680787324905396::status(o_87364f7431758d00c7dc,supported); 0::status(o_87364f7431758d00c7dc,refuted); 0.0031921267509460449::status(o_87364f7431758d00c7dc,unknown).
1::status(o_873d74cfad30944f2f40,supported); 0::status(o_873d74cfad30944f2f40,refuted); 0::status(o_873d74cfad30944f2f40,unknown).
0.003689546836540103::status(o_87423769375bdb526643,supported); 0::status(o_87423769375bdb526643,refuted); 0.9963104531634599::status(o_87423769375bdb526643,unknown).
1::status(o_876c693751b04872860e,supported); 0::status(o_876c693751b04872860e,refuted); 0::status(o_876c693751b04872860e,unknown).
1::status(o_8796ccec6b5d882b08bc,supported); 0::status(o_8796ccec6b5d882b08bc,refuted); 0::status(o_8796ccec6b5d882b08bc,unknown).
0.2129049152135849::status(o_87ce9c08bd12f3797657,supported); 0::status(o_87ce9c08bd12f3797657,refuted); 0.7870950847864151::status(o_87ce9c08bd12f3797657,unknown).
0.0004814279091078788::status(o_87e58d94156aaabaac31,supported); 0::status(o_87e58d94156aaabaac31,refuted); 0.99951857209089212::status(o_87e58d94156aaabaac31,unknown).
0::status(o_87edf482a57349db5a1c,supported); 0::status(o_87edf482a57349db5a1c,refuted); 1::status(o_87edf482a57349db5a1c,unknown).
1::status(o_880ba8c5e2ad75cbd3ac,supported); 0::status(o_880ba8c5e2ad75cbd3ac,refuted); 0::status(o_880ba8c5e2ad75cbd3ac,unknown).
0::status(o_880d3171f85379b20948,supported); 1::status(o_880d3171f85379b20948,refuted); 0::status(o_880d3171f85379b20948,unknown).
1::status(o_881863e337dd650b51f1,supported); 0::status(o_881863e337dd650b51f1,refuted); 0::status(o_881863e337dd650b51f1,unknown).
1::status(o_888009261ebdea9b886b,supported); 0::status(o_888009261ebdea9b886b,refuted); 0::status(o_888009261ebdea9b886b,unknown).
0::status(o_889291a73b03266f4686,supported); 1::status(o_889291a73b03266f4686,refuted); 0::status(o_889291a73b03266f4686,unknown).
1::status(o_889f7e7ec2ff2d666ebc,supported); 0::status(o_889f7e7ec2ff2d666ebc,refuted); 0::status(o_889f7e7ec2ff2d666ebc,unknown).
1::status(o_88c50fb5059f8212051c,supported); 0::status(o_88c50fb5059f8212051c,refuted); 0::status(o_88c50fb5059f8212051c,unknown).
1::status(o_88c7c6c35ac4aa90e4c7,supported); 0::status(o_88c7c6c35ac4aa90e4c7,refuted); 0::status(o_88c7c6c35ac4aa90e4c7,unknown).
1::status(o_88ef2e2b3898c05617c3,supported); 0::status(o_88ef2e2b3898c05617c3,refuted); 0::status(o_88ef2e2b3898c05617c3,unknown).
0.0018518617143854499::status(o_890b148b53aa96dbdea7,supported); 0::status(o_890b148b53aa96dbdea7,refuted); 0.99814813828561455::status(o_890b148b53aa96dbdea7,unknown).
1::status(o_893a10a134dba7b21d76,supported); 0::status(o_893a10a134dba7b21d76,refuted); 0::status(o_893a10a134dba7b21d76,unknown).
0.99660646915435791::status(o_896b375682b147e647e0,supported); 0::status(o_896b375682b147e647e0,refuted); 0.0033935308456420898::status(o_896b375682b147e647e0,unknown).
1::status(o_897b6b848b85c5f8074f,supported); 0::status(o_897b6b848b85c5f8074f,refuted); 0::status(o_897b6b848b85c5f8074f,unknown).
0::status(o_8a176bec2fab30e5db7c,supported); 0::status(o_8a176bec2fab30e5db7c,refuted); 1::status(o_8a176bec2fab30e5db7c,unknown).
0.28751092054261485::status(o_8a1d8391f0b57f1b5e87,supported); 0::status(o_8a1d8391f0b57f1b5e87,refuted); 0.71248907945738515::status(o_8a1d8391f0b57f1b5e87,unknown).
0.00027939380379393697::status(o_8af3fdf7d35af4575479,supported); 0::status(o_8af3fdf7d35af4575479,refuted); 0.99972060619620606::status(o_8af3fdf7d35af4575479,unknown).
0::status(o_8bb40208e05c741de57c,supported); 1::status(o_8bb40208e05c741de57c,refuted); 0::status(o_8bb40208e05c741de57c,unknown).
0.99007987976074219::status(o_8c10222f138ba19bf5f2,supported); 0::status(o_8c10222f138ba19bf5f2,refuted); 0.0099201202392578125::status(o_8c10222f138ba19bf5f2,unknown).
1::status(o_8c4c6c3af076cebc089a,supported); 0::status(o_8c4c6c3af076cebc089a,refuted); 0::status(o_8c4c6c3af076cebc089a,unknown).
1::status(o_8c7804258e0f125c4c1e,supported); 0::status(o_8c7804258e0f125c4c1e,refuted); 0::status(o_8c7804258e0f125c4c1e,unknown).
7.2544266787091473e-08::status(o_8d01c3acf241794c1041,supported); 0::status(o_8d01c3acf241794c1041,refuted); 0.99999992745573318::status(o_8d01c3acf241794c1041,unknown).
1::status(o_8d12f7876d1d2c230dfc,supported); 0::status(o_8d12f7876d1d2c230dfc,refuted); 0::status(o_8d12f7876d1d2c230dfc,unknown).
1::status(o_8d7194f1159c22291b34,supported); 0::status(o_8d7194f1159c22291b34,refuted); 0::status(o_8d7194f1159c22291b34,unknown).
1::status(o_8d7a44af42a2224631a7,supported); 0::status(o_8d7a44af42a2224631a7,refuted); 0::status(o_8d7a44af42a2224631a7,unknown).
1::status(o_8da2ec05cff0a0ace46e,supported); 0::status(o_8da2ec05cff0a0ace46e,refuted); 0::status(o_8da2ec05cff0a0ace46e,unknown).
1::status(o_8dda71046579a5984946,supported); 0::status(o_8dda71046579a5984946,refuted); 0::status(o_8dda71046579a5984946,unknown).
1::status(o_8e90bb945df5d8f95add,supported); 0::status(o_8e90bb945df5d8f95add,refuted); 0::status(o_8e90bb945df5d8f95add,unknown).
0.002940004225820303::status(o_8ec6851e742b74d587e2,supported); 0::status(o_8ec6851e742b74d587e2,refuted); 0.9970599957741797::status(o_8ec6851e742b74d587e2,unknown).
1::status(o_8ed05054839e75f77de0,supported); 0::status(o_8ed05054839e75f77de0,refuted); 0::status(o_8ed05054839e75f77de0,unknown).
1.3034778761802781e-06::status(o_8eed4906f485e3836619,supported); 0::status(o_8eed4906f485e3836619,refuted); 0.99999869652212381::status(o_8eed4906f485e3836619,unknown).
0.98598873615264893::status(o_8f0c953629a53c8f8fa0,supported); 0::status(o_8f0c953629a53c8f8fa0,refuted); 0.014011263847351074::status(o_8f0c953629a53c8f8fa0,unknown).
0.0016452829586341977::status(o_8f362de248675a5de157,supported); 0::status(o_8f362de248675a5de157,refuted); 0.9983547170413658::status(o_8f362de248675a5de157,unknown).
0.59074564597745061::status(o_8f3ee2f3ec0690291f56,supported); 0::status(o_8f3ee2f3ec0690291f56,refuted); 0.40925435402254939::status(o_8f3ee2f3ec0690291f56,unknown).
2.5679240045586824e-07::status(o_8fa48f5d98d50afef031,supported); 0::status(o_8fa48f5d98d50afef031,refuted); 0.99999974320759955::status(o_8fa48f5d98d50afef031,unknown).
0.976348876953125::status(o_8fae2584a07d960bda4a,supported); 0::status(o_8fae2584a07d960bda4a,refuted); 0.023651123046875::status(o_8fae2584a07d960bda4a,unknown).
1::status(o_8fc0b3338cc2f2aae517,supported); 0::status(o_8fc0b3338cc2f2aae517,refuted); 0::status(o_8fc0b3338cc2f2aae517,unknown).
0.99185353517532349::status(o_8feabcb2fcd7e5961dd1,supported); 0::status(o_8feabcb2fcd7e5961dd1,refuted); 0.0081464648246765137::status(o_8feabcb2fcd7e5961dd1,unknown).
1::status(o_908a0b3b8aeefa482357,supported); 0::status(o_908a0b3b8aeefa482357,refuted); 0::status(o_908a0b3b8aeefa482357,unknown).
1::status(o_90980f81af9431f9601b,supported); 0::status(o_90980f81af9431f9601b,refuted); 0::status(o_90980f81af9431f9601b,unknown).
0::status(o_90bd208550715c463043,supported); 0::status(o_90bd208550715c463043,refuted); 1::status(o_90bd208550715c463043,unknown).
0.96754372119903564::status(o_90e29416513134f09009,supported); 0::status(o_90e29416513134f09009,refuted); 0.032456278800964355::status(o_90e29416513134f09009,unknown).
0::status(o_91268a74137a26ca6d45,supported); 1::status(o_91268a74137a26ca6d45,refuted); 0::status(o_91268a74137a26ca6d45,unknown).
1::status(o_91584bd492b37beb31a1,supported); 0::status(o_91584bd492b37beb31a1,refuted); 0::status(o_91584bd492b37beb31a1,unknown).
1::status(o_91d87a0d0f5d48d1add0,supported); 0::status(o_91d87a0d0f5d48d1add0,refuted); 0::status(o_91d87a0d0f5d48d1add0,unknown).
0.0024758365470916033::status(o_9257b71f618ea745c27b,supported); 0::status(o_9257b71f618ea745c27b,refuted); 0.9975241634529084::status(o_9257b71f618ea745c27b,unknown).
1::status(o_92c4f7bce0a3c6cbd00a,supported); 0::status(o_92c4f7bce0a3c6cbd00a,refuted); 0::status(o_92c4f7bce0a3c6cbd00a,unknown).
0.001097465050406754::status(o_92d732613a61e1358729,supported); 0::status(o_92d732613a61e1358729,refuted); 0.99890253494959325::status(o_92d732613a61e1358729,unknown).
0::status(o_9308c92fbe649babffc9,supported); 1::status(o_9308c92fbe649babffc9,refuted); 0::status(o_9308c92fbe649babffc9,unknown).
0.99447786808013916::status(o_934983b633e5a697e28d,supported); 0::status(o_934983b633e5a697e28d,refuted); 0.0055221319198608398::status(o_934983b633e5a697e28d,unknown).
0.002940004225820303::status(o_934b2eb567bb70b51afc,supported); 0::status(o_934b2eb567bb70b51afc,refuted); 0.9970599957741797::status(o_934b2eb567bb70b51afc,unknown).
1::status(o_938dae433ba7a991ddfb,supported); 0::status(o_938dae433ba7a991ddfb,refuted); 0::status(o_938dae433ba7a991ddfb,unknown).
1::status(o_93aec2bf909c2b85cc0e,supported); 0::status(o_93aec2bf909c2b85cc0e,refuted); 0::status(o_93aec2bf909c2b85cc0e,unknown).
0.96754372119903564::status(o_9426a03f39fe6c4cc08c,supported); 0::status(o_9426a03f39fe6c4cc08c,refuted); 0.032456278800964355::status(o_9426a03f39fe6c4cc08c,unknown).
0.00012811402848456055::status(o_9435e5f81ea0db193068,supported); 0::status(o_9435e5f81ea0db193068,refuted); 0.99987188597151544::status(o_9435e5f81ea0db193068,unknown).
1::status(o_948b7714da06d37906f0,supported); 0::status(o_948b7714da06d37906f0,refuted); 0::status(o_948b7714da06d37906f0,unknown).
0::status(o_94fd15241717d9faf933,supported); 0::status(o_94fd15241717d9faf933,refuted); 1::status(o_94fd15241717d9faf933,unknown).
0::status(o_950ab3db52d5ef775b24,supported); 1::status(o_950ab3db52d5ef775b24,refuted); 0::status(o_950ab3db52d5ef775b24,unknown).
1::status(o_951cdefdee3dda8af591,supported); 0::status(o_951cdefdee3dda8af591,refuted); 0::status(o_951cdefdee3dda8af591,unknown).
0.99007987976074219::status(o_95b12e4d0e6a3c22b8d0,supported); 0::status(o_95b12e4d0e6a3c22b8d0,refuted); 0.0099201202392578125::status(o_95b12e4d0e6a3c22b8d0,unknown).
0.0023976406082510948::status(o_9636879589e48d6fc359,supported); 0::status(o_9636879589e48d6fc359,refuted); 0.99760235939174891::status(o_9636879589e48d6fc359,unknown).
1::status(o_96610ad10ccd7cab58fa,supported); 0::status(o_96610ad10ccd7cab58fa,refuted); 0::status(o_96610ad10ccd7cab58fa,unknown).
1::status(o_969cf8b9bff80c807f3c,supported); 0::status(o_969cf8b9bff80c807f3c,refuted); 0::status(o_969cf8b9bff80c807f3c,unknown).
0.00045137316919863224::status(o_96ce62cf8febb6cd537b,supported); 0::status(o_96ce62cf8febb6cd537b,refuted); 0.99954862683080137::status(o_96ce62cf8febb6cd537b,unknown).
1::status(o_96d6b33fa67bbb65801d,supported); 0::status(o_96d6b33fa67bbb65801d,refuted); 0::status(o_96d6b33fa67bbb65801d,unknown).
1::status(o_9731d806c4443dbd04e4,supported); 0::status(o_9731d806c4443dbd04e4,refuted); 0::status(o_9731d806c4443dbd04e4,unknown).
1::status(o_981bf9c2fe6e80a1796f,supported); 0::status(o_981bf9c2fe6e80a1796f,refuted); 0::status(o_981bf9c2fe6e80a1796f,unknown).
0.0042693153955042362::status(o_9832c0c8da6e4d701a2d,supported); 0::status(o_9832c0c8da6e4d701a2d,refuted); 0.99573068460449576::status(o_9832c0c8da6e4d701a2d,unknown).
1::status(o_985ca8c01a917014aa0b,supported); 0::status(o_985ca8c01a917014aa0b,refuted); 0::status(o_985ca8c01a917014aa0b,unknown).
1::status(o_985cf8525b26d0d7eaa8,supported); 0::status(o_985cf8525b26d0d7eaa8,refuted); 0::status(o_985cf8525b26d0d7eaa8,unknown).
0.0013008691603317857::status(o_9861ae06cef22b234378,supported); 0::status(o_9861ae06cef22b234378,refuted); 0.99869913083966821::status(o_9861ae06cef22b234378,unknown).
0.99660646915435791::status(o_988b62899546d0024e81,supported); 0::status(o_988b62899546d0024e81,refuted); 0.0033935308456420898::status(o_988b62899546d0024e81,unknown).
1::status(o_98e7f06c6336c9cc3707,supported); 0::status(o_98e7f06c6336c9cc3707,refuted); 0::status(o_98e7f06c6336c9cc3707,unknown).
0.99738341569900513::status(o_98ea1b9e3abe7a34709c,supported); 0::status(o_98ea1b9e3abe7a34709c,refuted); 0.002616584300994873::status(o_98ea1b9e3abe7a34709c,unknown).
0.99738341569900513::status(o_995297a727509b361992,supported); 0::status(o_995297a727509b361992,refuted); 0.002616584300994873::status(o_995297a727509b361992,unknown).
1::status(o_99686f78ba054fa8919c,supported); 0::status(o_99686f78ba054fa8919c,refuted); 0::status(o_99686f78ba054fa8919c,unknown).
0::status(o_998f75ee08cac164c587,supported); 1::status(o_998f75ee08cac164c587,refuted); 0::status(o_998f75ee08cac164c587,unknown).
0::status(o_99c3fb3979eef5f0942f,supported); 1::status(o_99c3fb3979eef5f0942f,refuted); 0::status(o_99c3fb3979eef5f0942f,unknown).
1::status(o_99d5df8fc7c0e35a3115,supported); 0::status(o_99d5df8fc7c0e35a3115,refuted); 0::status(o_99d5df8fc7c0e35a3115,unknown).
1::status(o_99ff1c47e1ca2b5812bc,supported); 0::status(o_99ff1c47e1ca2b5812bc,refuted); 0::status(o_99ff1c47e1ca2b5812bc,unknown).
1::status(o_9a2d2617f98ba516101a,supported); 0::status(o_9a2d2617f98ba516101a,refuted); 0::status(o_9a2d2617f98ba516101a,unknown).
0.0018071738304570317::status(o_9a9256001c14fd1c907b,supported); 0::status(o_9a9256001c14fd1c907b,refuted); 0.99819282616954297::status(o_9a9256001c14fd1c907b,unknown).
0::status(o_9aa9398419b8720c2904,supported); 1::status(o_9aa9398419b8720c2904,refuted); 0::status(o_9aa9398419b8720c2904,unknown).
0::status(o_9ae23e961b8d07503b18,supported); 1::status(o_9ae23e961b8d07503b18,refuted); 0::status(o_9ae23e961b8d07503b18,unknown).
1::status(o_9af73b546cdd58da29c9,supported); 0::status(o_9af73b546cdd58da29c9,refuted); 0::status(o_9af73b546cdd58da29c9,unknown).
0::status(o_9b2931c638b19a8db62d,supported); 0::status(o_9b2931c638b19a8db62d,refuted); 1::status(o_9b2931c638b19a8db62d,unknown).
0.61694091558456421::status(o_9b630a8dcb7cdd733d01,supported); 0::status(o_9b630a8dcb7cdd733d01,refuted); 0.38305908441543579::status(o_9b630a8dcb7cdd733d01,unknown).
1::status(o_9b634c4c1840f2b99d83,supported); 0::status(o_9b634c4c1840f2b99d83,refuted); 0::status(o_9b634c4c1840f2b99d83,unknown).
0.97067016363143921::status(o_9bb58f92d89902da3fd9,supported); 0::status(o_9bb58f92d89902da3fd9,refuted); 0.029329836368560791::status(o_9bb58f92d89902da3fd9,unknown).
1::status(o_9bcd39cf8d67db3f73e5,supported); 0::status(o_9bcd39cf8d67db3f73e5,refuted); 0::status(o_9bcd39cf8d67db3f73e5,unknown).
1::status(o_9bdd877535a38def7dfe,supported); 0::status(o_9bdd877535a38def7dfe,refuted); 0::status(o_9bdd877535a38def7dfe,unknown).
0.003883931552991271::status(o_9bf4dca6964a628a50cc,supported); 0::status(o_9bf4dca6964a628a50cc,refuted); 0.99611606844700873::status(o_9bf4dca6964a628a50cc,unknown).
0.97435927391052246::status(o_9c15940fea77f229744f,supported); 0::status(o_9c15940fea77f229744f,refuted); 0.025640726089477539::status(o_9c15940fea77f229744f,unknown).
0.0007167395087890327::status(o_9c5a86fe03fc4efb7e24,supported); 0::status(o_9c5a86fe03fc4efb7e24,refuted); 0.99928326049121097::status(o_9c5a86fe03fc4efb7e24,unknown).
1::status(o_9c612041f7dcbfdd3a91,supported); 0::status(o_9c612041f7dcbfdd3a91,refuted); 0::status(o_9c612041f7dcbfdd3a91,unknown).
0.99524873495101929::status(o_9ce0cc5e6a772f28b4f7,supported); 0::status(o_9ce0cc5e6a772f28b4f7,refuted); 0.0047512650489807129::status(o_9ce0cc5e6a772f28b4f7,unknown).
0.98314672708511353::status(o_9d4779f493d34cfffc84,supported); 0::status(o_9d4779f493d34cfffc84,refuted); 0.016853272914886475::status(o_9d4779f493d34cfffc84,unknown).
0::status(o_9d6fc4c759caefac4372,supported); 0::status(o_9d6fc4c759caefac4372,refuted); 1::status(o_9d6fc4c759caefac4372,unknown).
0.0070033296942710876::status(o_9dc24887afc5e3fbdb5a,supported); 0::status(o_9dc24887afc5e3fbdb5a,refuted); 0.99299667030572891::status(o_9dc24887afc5e3fbdb5a,unknown).
1::status(o_9deb5d47f7de742b093f,supported); 0::status(o_9deb5d47f7de742b093f,refuted); 0::status(o_9deb5d47f7de742b093f,unknown).
1::status(o_9e152ec50f2e5029e159,supported); 0::status(o_9e152ec50f2e5029e159,refuted); 0::status(o_9e152ec50f2e5029e159,unknown).
1::status(o_9eb7fa37ac31842fb854,supported); 0::status(o_9eb7fa37ac31842fb854,refuted); 0::status(o_9eb7fa37ac31842fb854,unknown).
0.99188774824142456::status(o_9f2102c3b6a6669e62b2,supported); 0::status(o_9f2102c3b6a6669e62b2,refuted); 0.0081122517585754395::status(o_9f2102c3b6a6669e62b2,unknown).
0.99310886859893799::status(o_9f753c9c0d6118e3e852,supported); 0::status(o_9f753c9c0d6118e3e852,refuted); 0.0068911314010620117::status(o_9f753c9c0d6118e3e852,unknown).
1::status(o_9f9ccc87bfb7a5ce1444,supported); 0::status(o_9f9ccc87bfb7a5ce1444,refuted); 0::status(o_9f9ccc87bfb7a5ce1444,unknown).
7.9832112533040345e-05::status(o_9fa6303f729eba60fa01,supported); 0::status(o_9fa6303f729eba60fa01,refuted); 0.99992016788746696::status(o_9fa6303f729eba60fa01,unknown).
1::status(o_9fd52518407235077303,supported); 0::status(o_9fd52518407235077303,refuted); 0::status(o_9fd52518407235077303,unknown).
1::status(o_a04da6c69390f0d4bbcb,supported); 0::status(o_a04da6c69390f0d4bbcb,refuted); 0::status(o_a04da6c69390f0d4bbcb,unknown).
1::status(o_a086747c0bca31f63072,supported); 0::status(o_a086747c0bca31f63072,refuted); 0::status(o_a086747c0bca31f63072,unknown).
1::status(o_a0a14b68747d20b3ca71,supported); 0::status(o_a0a14b68747d20b3ca71,refuted); 0::status(o_a0a14b68747d20b3ca71,unknown).
0.00038813083665445447::status(o_a0e633d67f9b887141cf,supported); 0::status(o_a0e633d67f9b887141cf,refuted); 0.99961186916334555::status(o_a0e633d67f9b887141cf,unknown).
1::status(o_a1aae904be2f928304d6,supported); 0::status(o_a1aae904be2f928304d6,refuted); 0::status(o_a1aae904be2f928304d6,unknown).
0.99985496538327623::status(o_a1afcfce81052abf7af0,supported); 0::status(o_a1afcfce81052abf7af0,refuted); 0.00014503461672377149::status(o_a1afcfce81052abf7af0,unknown).
0.99213320016860962::status(o_a1df8b1b0a191b840f64,supported); 0::status(o_a1df8b1b0a191b840f64,refuted); 0.0078667998313903809::status(o_a1df8b1b0a191b840f64,unknown).
1::status(o_a24f6920764e14c87cb7,supported); 0::status(o_a24f6920764e14c87cb7,refuted); 0::status(o_a24f6920764e14c87cb7,unknown).
0::status(o_a28cf40d91c2185d7b0a,supported); 0::status(o_a28cf40d91c2185d7b0a,refuted); 1::status(o_a28cf40d91c2185d7b0a,unknown).
0::status(o_a2916f5585776c6bf91c,supported); 0::status(o_a2916f5585776c6bf91c,refuted); 1::status(o_a2916f5585776c6bf91c,unknown).
1::status(o_a29a41ef3b14dc3b7d73,supported); 0::status(o_a29a41ef3b14dc3b7d73,refuted); 0::status(o_a29a41ef3b14dc3b7d73,unknown).
0.99385096469335199::status(o_a29d0262e5507f6a6b0b,supported); 0::status(o_a29d0262e5507f6a6b0b,refuted); 0.0061490353066480097::status(o_a29d0262e5507f6a6b0b,unknown).
0.003689546836540103::status(o_a2b443e44c3b9d1c0bca,supported); 0::status(o_a2b443e44c3b9d1c0bca,refuted); 0.9963104531634599::status(o_a2b443e44c3b9d1c0bca,unknown).
1::status(o_a2b5ca456b8fa7f00966,supported); 0::status(o_a2b5ca456b8fa7f00966,refuted); 0::status(o_a2b5ca456b8fa7f00966,unknown).
0.99045181274414062::status(o_a2f451743f4b973e9a8d,supported); 0::status(o_a2f451743f4b973e9a8d,refuted); 0.009548187255859375::status(o_a2f451743f4b973e9a8d,unknown).
1::status(o_a3a1df1fbf749dfa5ff2,supported); 0::status(o_a3a1df1fbf749dfa5ff2,refuted); 0::status(o_a3a1df1fbf749dfa5ff2,unknown).
0.97427183389663696::status(o_a40a693968ee9aa1312d,supported); 0::status(o_a40a693968ee9aa1312d,refuted); 0.025728166103363037::status(o_a40a693968ee9aa1312d,unknown).
0.99019777774810791::status(o_a41848fa24a0b54038fa,supported); 0::status(o_a41848fa24a0b54038fa,refuted); 0.0098022222518920898::status(o_a41848fa24a0b54038fa,unknown).
0.99998772104878231::status(o_a4691cddd84829f0d2ff,supported); 0::status(o_a4691cddd84829f0d2ff,refuted); 1.2278951217692402e-05::status(o_a4691cddd84829f0d2ff,unknown).
0.0013882720377296209::status(o_a4acc59cec322d8f0d07,supported); 0::status(o_a4acc59cec322d8f0d07,refuted); 0.99861172796227038::status(o_a4acc59cec322d8f0d07,unknown).
0.0018518617143854499::status(o_a4c439420ab00051c2a0,supported); 0::status(o_a4c439420ab00051c2a0,refuted); 0.99814813828561455::status(o_a4c439420ab00051c2a0,unknown).
0.002602787222713232::status(o_a4c4c8ab5215e5374d10,supported); 0::status(o_a4c4c8ab5215e5374d10,refuted); 0.99739721277728677::status(o_a4c4c8ab5215e5374d10,unknown).
0::status(o_a4f45f48e4dd5e847513,supported); 0::status(o_a4f45f48e4dd5e847513,refuted); 1::status(o_a4f45f48e4dd5e847513,unknown).
1::status(o_a50df53d4aa8b2234a6b,supported); 0::status(o_a50df53d4aa8b2234a6b,refuted); 0::status(o_a50df53d4aa8b2234a6b,unknown).
0.0016452829586341977::status(o_a52d7d14f94ee7919241,supported); 0::status(o_a52d7d14f94ee7919241,refuted); 0.9983547170413658::status(o_a52d7d14f94ee7919241,unknown).
0::status(o_a56a2b891053a730ab9a,supported); 1::status(o_a56a2b891053a730ab9a,refuted); 0::status(o_a56a2b891053a730ab9a,unknown).
0::status(o_a56a8583cafdbc06b4d3,supported); 1::status(o_a56a8583cafdbc06b4d3,refuted); 0::status(o_a56a8583cafdbc06b4d3,unknown).
1::status(o_a5a0799fbcc3cd119876,supported); 0::status(o_a5a0799fbcc3cd119876,refuted); 0::status(o_a5a0799fbcc3cd119876,unknown).
1::status(o_a5bd26d7c53cb46b62a5,supported); 0::status(o_a5bd26d7c53cb46b62a5,refuted); 0::status(o_a5bd26d7c53cb46b62a5,unknown).
0.067158885300159454::status(o_a5c9ad57179f673941da,supported); 0::status(o_a5c9ad57179f673941da,refuted); 0.93284111469984055::status(o_a5c9ad57179f673941da,unknown).
0::status(o_a5db06aca7558d5d87ff,supported); 1::status(o_a5db06aca7558d5d87ff,refuted); 0::status(o_a5db06aca7558d5d87ff,unknown).
0.003689546836540103::status(o_a5f0f740368e040d23ab,supported); 0::status(o_a5f0f740368e040d23ab,refuted); 0.9963104531634599::status(o_a5f0f740368e040d23ab,unknown).
1::status(o_a63396895046639d305d,supported); 0::status(o_a63396895046639d305d,refuted); 0::status(o_a63396895046639d305d,unknown).
0.976348876953125::status(o_a68f1505fbb7d6c2354a,supported); 0::status(o_a68f1505fbb7d6c2354a,refuted); 0.023651123046875::status(o_a68f1505fbb7d6c2354a,unknown).
1::status(o_a69e181fe997e4a6cd46,supported); 0::status(o_a69e181fe997e4a6cd46,refuted); 0::status(o_a69e181fe997e4a6cd46,unknown).
1::status(o_a6b32541d3280bedcd62,supported); 0::status(o_a6b32541d3280bedcd62,refuted); 0::status(o_a6b32541d3280bedcd62,unknown).
1::status(o_a6d81e0706884f706a19,supported); 0::status(o_a6d81e0706884f706a19,refuted); 0::status(o_a6d81e0706884f706a19,unknown).
1::status(o_a6dc7ac72a260132cd67,supported); 0::status(o_a6dc7ac72a260132cd67,refuted); 0::status(o_a6dc7ac72a260132cd67,unknown).
0::status(o_a6e1a6ecd88770463656,supported); 1::status(o_a6e1a6ecd88770463656,refuted); 0::status(o_a6e1a6ecd88770463656,unknown).
0.067158885300159454::status(o_a6ee0b4fdcea28e94244,supported); 0::status(o_a6ee0b4fdcea28e94244,refuted); 0.93284111469984055::status(o_a6ee0b4fdcea28e94244,unknown).
0.56174170970916748::status(o_a70793afe41b708425ea,supported); 0::status(o_a70793afe41b708425ea,refuted); 0.43825829029083252::status(o_a70793afe41b708425ea,unknown).
0.61694091558456421::status(o_a74f939b3f2a0845ede0,supported); 0::status(o_a74f939b3f2a0845ede0,refuted); 0.38305908441543579::status(o_a74f939b3f2a0845ede0,unknown).
0.00076209998223930597::status(o_a798113d7da25921886d,supported); 0::status(o_a798113d7da25921886d,refuted); 0.99923790001776069::status(o_a798113d7da25921886d,unknown).
0.976348876953125::status(o_a7c0efca4fea2b72e333,supported); 0::status(o_a7c0efca4fea2b72e333,refuted); 0.023651123046875::status(o_a7c0efca4fea2b72e333,unknown).
0::status(o_a81e63bffa39e5bebe59,supported); 1::status(o_a81e63bffa39e5bebe59,refuted); 0::status(o_a81e63bffa39e5bebe59,unknown).
0.0042693153955042362::status(o_a820966ae1f6a7409351,supported); 0::status(o_a820966ae1f6a7409351,refuted); 0.99573068460449576::status(o_a820966ae1f6a7409351,unknown).
0.0018518617143854499::status(o_a8211898c6351603939e,supported); 0::status(o_a8211898c6351603939e,refuted); 0.99814813828561455::status(o_a8211898c6351603939e,unknown).
1::status(o_a82280ddc960ec34a3d0,supported); 0::status(o_a82280ddc960ec34a3d0,refuted); 0::status(o_a82280ddc960ec34a3d0,unknown).
1::status(o_a82e2eefccb305e0a50c,supported); 0::status(o_a82e2eefccb305e0a50c,refuted); 0::status(o_a82e2eefccb305e0a50c,unknown).
1::status(o_a88d121d4fa3d9baa042,supported); 0::status(o_a88d121d4fa3d9baa042,refuted); 0::status(o_a88d121d4fa3d9baa042,unknown).
1::status(o_a8909c887b879deddb42,supported); 0::status(o_a8909c887b879deddb42,refuted); 0::status(o_a8909c887b879deddb42,unknown).
0::status(o_a8a59d8daf7cd1d501d5,supported); 1::status(o_a8a59d8daf7cd1d501d5,refuted); 0::status(o_a8a59d8daf7cd1d501d5,unknown).
0.0023976406082510948::status(o_a8a95ff2b2bac94b19c7,supported); 0::status(o_a8a95ff2b2bac94b19c7,refuted); 0.99760235939174891::status(o_a8a95ff2b2bac94b19c7,unknown).
0.59074564597745061::status(o_a8b99355a4444259bb21,supported); 0::status(o_a8b99355a4444259bb21,refuted); 0.40925435402254939::status(o_a8b99355a4444259bb21,unknown).
1::status(o_a8dd249e67dbcda4f802,supported); 0::status(o_a8dd249e67dbcda4f802,refuted); 0::status(o_a8dd249e67dbcda4f802,unknown).
0::status(o_a8f3cdfb2b4a0501a6eb,supported); 1::status(o_a8f3cdfb2b4a0501a6eb,refuted); 0::status(o_a8f3cdfb2b4a0501a6eb,unknown).
0.999999966881435::status(o_a948353aa15f40e41192,supported); 0::status(o_a948353aa15f40e41192,refuted); 3.3118565001544198e-08::status(o_a948353aa15f40e41192,unknown).
1::status(o_a9867d1ffb9e349e0ec1,supported); 0::status(o_a9867d1ffb9e349e0ec1,refuted); 0::status(o_a9867d1ffb9e349e0ec1,unknown).
0.0018518617143854499::status(o_a9be3a590ca349db95da,supported); 0::status(o_a9be3a590ca349db95da,refuted); 0.99814813828561455::status(o_a9be3a590ca349db95da,unknown).
0.976348876953125::status(o_aa0d83e780731937639d,supported); 0::status(o_aa0d83e780731937639d,refuted); 0.023651123046875::status(o_aa0d83e780731937639d,unknown).
0::status(o_aa163fefe6b532c2d074,supported); 1::status(o_aa163fefe6b532c2d074,refuted); 0::status(o_aa163fefe6b532c2d074,unknown).
0.00044824578799307346::status(o_aa3c4ebc6b2466fcd72c,supported); 0::status(o_aa3c4ebc6b2466fcd72c,refuted); 0.99955175421200693::status(o_aa3c4ebc6b2466fcd72c,unknown).
1::status(o_aa4013957de23f08775d,supported); 0::status(o_aa4013957de23f08775d,refuted); 0::status(o_aa4013957de23f08775d,unknown).
0.00062835169956088066::status(o_aa643bf9a601d7ba55a5,supported); 0::status(o_aa643bf9a601d7ba55a5,refuted); 0.99937164830043912::status(o_aa643bf9a601d7ba55a5,unknown).
0::status(o_aa9d4bd1c17850ec1241,supported); 1::status(o_aa9d4bd1c17850ec1241,refuted); 0::status(o_aa9d4bd1c17850ec1241,unknown).
1::status(o_aac77d26c05752344272,supported); 0::status(o_aac77d26c05752344272,refuted); 0::status(o_aac77d26c05752344272,unknown).
0.00066984596196562052::status(o_aae5f133f63271ada841,supported); 0::status(o_aae5f133f63271ada841,refuted); 0.99933015403803438::status(o_aae5f133f63271ada841,unknown).
0::status(o_ab71f9e6c64c37308cbb,supported); 1::status(o_ab71f9e6c64c37308cbb,refuted); 0::status(o_ab71f9e6c64c37308cbb,unknown).
0.99999996500192156::status(o_abe9f9d1122f5b93172a,supported); 0::status(o_abe9f9d1122f5b93172a,refuted); 3.49980784353221e-08::status(o_abe9f9d1122f5b93172a,unknown).
0::status(o_ac62d38d74013d52ecc1,supported); 1::status(o_ac62d38d74013d52ecc1,refuted); 0::status(o_ac62d38d74013d52ecc1,unknown).
0.79551464319229126::status(o_ac6dff7b5be32257e072,supported); 0::status(o_ac6dff7b5be32257e072,refuted); 0.20448535680770874::status(o_ac6dff7b5be32257e072,unknown).
0.0016452829586341977::status(o_accf334d108e9206b015,supported); 0::status(o_accf334d108e9206b015,refuted); 0.9983547170413658::status(o_accf334d108e9206b015,unknown).
0::status(o_acdf642e5d06dc114def,supported); 1::status(o_acdf642e5d06dc114def,refuted); 0::status(o_acdf642e5d06dc114def,unknown).
1::status(o_ace36b8ce48038e09470,supported); 0::status(o_ace36b8ce48038e09470,refuted); 0::status(o_ace36b8ce48038e09470,unknown).
5.0035413667122327e-06::status(o_aced07fa4d11a2a2a8c6,supported); 0::status(o_aced07fa4d11a2a2a8c6,refuted); 0.99999499645863332::status(o_aced07fa4d11a2a2a8c6,unknown).
0::status(o_acf6d635d18126c401ff,supported); 0::status(o_acf6d635d18126c401ff,refuted); 1::status(o_acf6d635d18126c401ff,unknown).
1::status(o_ad085c3429fdd3eb2559,supported); 0::status(o_ad085c3429fdd3eb2559,refuted); 0::status(o_ad085c3429fdd3eb2559,unknown).
1::status(o_ad7c14d104cabccf23f6,supported); 0::status(o_ad7c14d104cabccf23f6,refuted); 0::status(o_ad7c14d104cabccf23f6,unknown).
1::status(o_ad9bf51d5e582ea8e6d6,supported); 0::status(o_ad9bf51d5e582ea8e6d6,refuted); 0::status(o_ad9bf51d5e582ea8e6d6,unknown).
0::status(o_ade077e5436a9a77c478,supported); 0::status(o_ade077e5436a9a77c478,refuted); 1::status(o_ade077e5436a9a77c478,unknown).
1::status(o_ae21a5f05f2a2376b95c,supported); 0::status(o_ae21a5f05f2a2376b95c,refuted); 0::status(o_ae21a5f05f2a2376b95c,unknown).
1::status(o_aea4ccc8f3c98224500e,supported); 0::status(o_aea4ccc8f3c98224500e,refuted); 0::status(o_aea4ccc8f3c98224500e,unknown).
1::status(o_aea6f7d8f854ee7d47f8,supported); 0::status(o_aea6f7d8f854ee7d47f8,refuted); 0::status(o_aea6f7d8f854ee7d47f8,unknown).
0.0018071738304570317::status(o_aeeac1560ce333f98c30,supported); 0::status(o_aeeac1560ce333f98c30,refuted); 0.99819282616954297::status(o_aeeac1560ce333f98c30,unknown).
0::status(o_af1b6361179d0b1dc51d,supported); 1::status(o_af1b6361179d0b1dc51d,refuted); 0::status(o_af1b6361179d0b1dc51d,unknown).
1::status(o_af570ab68034254e62ed,supported); 0::status(o_af570ab68034254e62ed,refuted); 0::status(o_af570ab68034254e62ed,unknown).
0.002940004225820303::status(o_af6f3f13d2b02740a0b4,supported); 0::status(o_af6f3f13d2b02740a0b4,refuted); 0.9970599957741797::status(o_af6f3f13d2b02740a0b4,unknown).
1::status(o_af720b627e3797e31111,supported); 0::status(o_af720b627e3797e31111,refuted); 0::status(o_af720b627e3797e31111,unknown).
0::status(o_afd1ae869eb5580bd720,supported); 1::status(o_afd1ae869eb5580bd720,refuted); 0::status(o_afd1ae869eb5580bd720,unknown).
0.998406055936786::status(o_b0028b0b240491ae2768,supported); 0::status(o_b0028b0b240491ae2768,refuted); 0.0015939440632140034::status(o_b0028b0b240491ae2768,unknown).
0::status(o_b0408d356564d7e2c71c,supported); 0::status(o_b0408d356564d7e2c71c,refuted); 1::status(o_b0408d356564d7e2c71c,unknown).
0.00085279322229325771::status(o_b07cdf0907c2424c4b9d,supported); 0::status(o_b07cdf0907c2424c4b9d,refuted); 0.99914720677770674::status(o_b07cdf0907c2424c4b9d,unknown).
1::status(o_b0b6f945a91527326e8d,supported); 0::status(o_b0b6f945a91527326e8d,refuted); 0::status(o_b0b6f945a91527326e8d,unknown).
1::status(o_b0ddc318951fde3452d6,supported); 0::status(o_b0ddc318951fde3452d6,refuted); 0::status(o_b0ddc318951fde3452d6,unknown).
9.0030916908290237e-05::status(o_b0fc9653ee27181cba71,supported); 0::status(o_b0fc9653ee27181cba71,refuted); 0.99990996908309171::status(o_b0fc9653ee27181cba71,unknown).
0::status(o_b10a9f96609b04c63224,supported); 1::status(o_b10a9f96609b04c63224,refuted); 0::status(o_b10a9f96609b04c63224,unknown).
0.97427183389663696::status(o_b1214eb33abb28f31731,supported); 0::status(o_b1214eb33abb28f31731,refuted); 0.025728166103363037::status(o_b1214eb33abb28f31731,unknown).
9.0030916908290237e-05::status(o_b16806619732d4412a92,supported); 0::status(o_b16806619732d4412a92,refuted); 0.99990996908309171::status(o_b16806619732d4412a92,unknown).
0.99667513370513916::status(o_b177efe5d73ef7370d34,supported); 0::status(o_b177efe5d73ef7370d34,refuted); 0.0033248662948608398::status(o_b177efe5d73ef7370d34,unknown).
0.99185353517532349::status(o_b18fcc7a6299a36075f9,supported); 0::status(o_b18fcc7a6299a36075f9,refuted); 0.0081464648246765137::status(o_b18fcc7a6299a36075f9,unknown).
1::status(o_b1e3ac763f76abbe2f30,supported); 0::status(o_b1e3ac763f76abbe2f30,refuted); 0::status(o_b1e3ac763f76abbe2f30,unknown).
0::status(o_b2dfa516891c521461db,supported); 1::status(o_b2dfa516891c521461db,refuted); 0::status(o_b2dfa516891c521461db,unknown).
0::status(o_b2e33da3a0bcd63b7d0c,supported); 1::status(o_b2e33da3a0bcd63b7d0c,refuted); 0::status(o_b2e33da3a0bcd63b7d0c,unknown).
1::status(o_b2ec04d30f8dee6517bc,supported); 0::status(o_b2ec04d30f8dee6517bc,refuted); 0::status(o_b2ec04d30f8dee6517bc,unknown).
1::status(o_b2f2f3f9c8e76389f265,supported); 0::status(o_b2f2f3f9c8e76389f265,refuted); 0::status(o_b2f2f3f9c8e76389f265,unknown).
0::status(o_b347f73065f2a2687f9c,supported); 0::status(o_b347f73065f2a2687f9c,refuted); 1::status(o_b347f73065f2a2687f9c,unknown).
0::status(o_b3f2bb1bde0a2f3c6cbb,supported); 1::status(o_b3f2bb1bde0a2f3c6cbb,refuted); 0::status(o_b3f2bb1bde0a2f3c6cbb,unknown).
0.003689546836540103::status(o_b42b949add243fc960da,supported); 0::status(o_b42b949add243fc960da,refuted); 0.9963104531634599::status(o_b42b949add243fc960da,unknown).
0::status(o_b42bfb8b0357ba394852,supported); 1::status(o_b42bfb8b0357ba394852,refuted); 0::status(o_b42bfb8b0357ba394852,unknown).
1::status(o_b431455d88ce64a88865,supported); 0::status(o_b431455d88ce64a88865,refuted); 0::status(o_b431455d88ce64a88865,unknown).
1::status(o_b4608152dc8e13efdeb8,supported); 0::status(o_b4608152dc8e13efdeb8,refuted); 0::status(o_b4608152dc8e13efdeb8,unknown).
1::status(o_b47e3edafb3d4f0c29de,supported); 0::status(o_b47e3edafb3d4f0c29de,refuted); 0::status(o_b47e3edafb3d4f0c29de,unknown).
1::status(o_b4fbdf06364a8f7aaf8e,supported); 0::status(o_b4fbdf06364a8f7aaf8e,refuted); 0::status(o_b4fbdf06364a8f7aaf8e,unknown).
4.1273197200221173e-09::status(o_b53cb4ba50efdc299010,supported); 0::status(o_b53cb4ba50efdc299010,refuted); 0.99999999587268029::status(o_b53cb4ba50efdc299010,unknown).
0.99999992580897223::status(o_b57558fca6fb9aacb2ea,supported); 0::status(o_b57558fca6fb9aacb2ea,refuted); 7.4191027765735384e-08::status(o_b57558fca6fb9aacb2ea,unknown).
0::status(o_b575f12ec9102d6fbe20,supported); 1::status(o_b575f12ec9102d6fbe20,refuted); 0::status(o_b575f12ec9102d6fbe20,unknown).
0.99213320016860962::status(o_b5d515d69a4982d63ccc,supported); 0::status(o_b5d515d69a4982d63ccc,refuted); 0.0078667998313903809::status(o_b5d515d69a4982d63ccc,unknown).
1::status(o_b5e0e5a466530334d0a2,supported); 0::status(o_b5e0e5a466530334d0a2,refuted); 0::status(o_b5e0e5a466530334d0a2,unknown).
1::status(o_b603883e777bf32b3162,supported); 0::status(o_b603883e777bf32b3162,refuted); 0::status(o_b603883e777bf32b3162,unknown).
0.74738532304763794::status(o_b60c07d71b60273cd421,supported); 0::status(o_b60c07d71b60273cd421,refuted); 0.25261467695236206::status(o_b60c07d71b60273cd421,unknown).
0.99999939047324271::status(o_b68547b46c469ee64c5a,supported); 0::status(o_b68547b46c469ee64c5a,refuted); 6.0952675728920269e-07::status(o_b68547b46c469ee64c5a,unknown).
0.00045137316919863224::status(o_b6973c9b52c5e191fb7d,supported); 0::status(o_b6973c9b52c5e191fb7d,refuted); 0.99954862683080137::status(o_b6973c9b52c5e191fb7d,unknown).
0::status(o_b699ae805ed9c6f04db9,supported); 1::status(o_b699ae805ed9c6f04db9,refuted); 0::status(o_b699ae805ed9c6f04db9,unknown).
1::status(o_b6e1bcc617624bdc684a,supported); 0::status(o_b6e1bcc617624bdc684a,refuted); 0::status(o_b6e1bcc617624bdc684a,unknown).
0.99876297288292504::status(o_b787c366b41256f7e1c4,supported); 0::status(o_b787c366b41256f7e1c4,refuted); 0.0012370271170749625::status(o_b787c366b41256f7e1c4,unknown).
0::status(o_b79fbbc26fd03c457204,supported); 1::status(o_b79fbbc26fd03c457204,refuted); 0::status(o_b79fbbc26fd03c457204,unknown).
0.0007167395087890327::status(o_b7b5d85d4ebe728c13f5,supported); 0::status(o_b7b5d85d4ebe728c13f5,refuted); 0.99928326049121097::status(o_b7b5d85d4ebe728c13f5,unknown).
1::status(o_b7e9de59802fa88fe245,supported); 0::status(o_b7e9de59802fa88fe245,refuted); 0::status(o_b7e9de59802fa88fe245,unknown).
0::status(o_b84b811cd140173317f4,supported); 0::status(o_b84b811cd140173317f4,refuted); 1::status(o_b84b811cd140173317f4,unknown).
1::status(o_b8b2e8834f01a5cc1ace,supported); 0::status(o_b8b2e8834f01a5cc1ace,refuted); 0::status(o_b8b2e8834f01a5cc1ace,unknown).
0.0042693153955042362::status(o_b8bd1cc9f993f0188714,supported); 0::status(o_b8bd1cc9f993f0188714,refuted); 0.99573068460449576::status(o_b8bd1cc9f993f0188714,unknown).
0.0018071738304570317::status(o_b904668ab147a52228e4,supported); 0::status(o_b904668ab147a52228e4,refuted); 0.99819282616954297::status(o_b904668ab147a52228e4,unknown).
1::status(o_b91e0467309db80f5f8a,supported); 0::status(o_b91e0467309db80f5f8a,refuted); 0::status(o_b91e0467309db80f5f8a,unknown).
0.0024758365470916033::status(o_b94cede733619fbe38bb,supported); 0::status(o_b94cede733619fbe38bb,refuted); 0.9975241634529084::status(o_b94cede733619fbe38bb,unknown).
1::status(o_b963e89c439122675439,supported); 0::status(o_b963e89c439122675439,refuted); 0::status(o_b963e89c439122675439,unknown).
1::status(o_b971486640a7ca37c1c0,supported); 0::status(o_b971486640a7ca37c1c0,refuted); 0::status(o_b971486640a7ca37c1c0,unknown).
1::status(o_b97461d759167ce5ea2a,supported); 0::status(o_b97461d759167ce5ea2a,refuted); 0::status(o_b97461d759167ce5ea2a,unknown).
1::status(o_b9b023505965c4338381,supported); 0::status(o_b9b023505965c4338381,refuted); 0::status(o_b9b023505965c4338381,unknown).
1::status(o_b9e6d81aca0b40b4612d,supported); 0::status(o_b9e6d81aca0b40b4612d,refuted); 0::status(o_b9e6d81aca0b40b4612d,unknown).
0.0024758365470916033::status(o_ba0f81438545a3e268a2,supported); 0::status(o_ba0f81438545a3e268a2,refuted); 0.9975241634529084::status(o_ba0f81438545a3e268a2,unknown).
0::status(o_ba4d56fa3e47aa437932,supported); 0::status(o_ba4d56fa3e47aa437932,refuted); 1::status(o_ba4d56fa3e47aa437932,unknown).
0.00038813083665445447::status(o_ba7cb1c84f04bd7fd4e0,supported); 0::status(o_ba7cb1c84f04bd7fd4e0,refuted); 0.99961186916334555::status(o_ba7cb1c84f04bd7fd4e0,unknown).
1::status(o_bad38350e3de0467dfd3,supported); 0::status(o_bad38350e3de0467dfd3,refuted); 0::status(o_bad38350e3de0467dfd3,unknown).
0.99185353517532349::status(o_bae505cc4e849e95360b,supported); 0::status(o_bae505cc4e849e95360b,refuted); 0.0081464648246765137::status(o_bae505cc4e849e95360b,unknown).
0.002602787222713232::status(o_bb177b76e82955afd892,supported); 0::status(o_bb177b76e82955afd892,refuted); 0.99739721277728677::status(o_bb177b76e82955afd892,unknown).
1::status(o_bb18c9d9fec4a5067da7,supported); 0::status(o_bb18c9d9fec4a5067da7,refuted); 0::status(o_bb18c9d9fec4a5067da7,unknown).
0::status(o_bb9d1af8e22f45a29407,supported); 1::status(o_bb9d1af8e22f45a29407,refuted); 0::status(o_bb9d1af8e22f45a29407,unknown).
0::status(o_bba2254c9c18166b0fa4,supported); 0::status(o_bba2254c9c18166b0fa4,refuted); 1::status(o_bba2254c9c18166b0fa4,unknown).
0.9937167763710022::status(o_bba7840921cde4ed5cf5,supported); 0::status(o_bba7840921cde4ed5cf5,refuted); 0.0062832236289978027::status(o_bba7840921cde4ed5cf5,unknown).
1::status(o_bbab2a4bf6ca397c7399,supported); 0::status(o_bbab2a4bf6ca397c7399,refuted); 0::status(o_bbab2a4bf6ca397c7399,unknown).
0::status(o_bbca57fe6fc9400ee7da,supported); 1::status(o_bbca57fe6fc9400ee7da,refuted); 0::status(o_bbca57fe6fc9400ee7da,unknown).
0::status(o_bbdbce4079c22878551c,supported); 1::status(o_bbdbce4079c22878551c,refuted); 0::status(o_bbdbce4079c22878551c,unknown).
0.00044824578799307346::status(o_bbdc1bedf1bbde6367b3,supported); 0::status(o_bbdc1bedf1bbde6367b3,refuted); 0.99955175421200693::status(o_bbdc1bedf1bbde6367b3,unknown).
1::status(o_bbe56d8dd9cf078e6d9a,supported); 0::status(o_bbe56d8dd9cf078e6d9a,refuted); 0::status(o_bbe56d8dd9cf078e6d9a,unknown).
1::status(o_bc11f2b89b2f201e88d0,supported); 0::status(o_bc11f2b89b2f201e88d0,refuted); 0::status(o_bc11f2b89b2f201e88d0,unknown).
0.00062835169956088066::status(o_bc1b954f980f0ad61568,supported); 0::status(o_bc1b954f980f0ad61568,refuted); 0.99937164830043912::status(o_bc1b954f980f0ad61568,unknown).
0.00030347461329718059::status(o_bc27d5e1602669d5e933,supported); 0::status(o_bc27d5e1602669d5e933,refuted); 0.99969652538670284::status(o_bc27d5e1602669d5e933,unknown).
0::status(o_bc4a52f0398ccfe67c0e,supported); 1::status(o_bc4a52f0398ccfe67c0e,refuted); 0::status(o_bc4a52f0398ccfe67c0e,unknown).
0::status(o_bc52b1e05adc6df4fc37,supported); 1::status(o_bc52b1e05adc6df4fc37,refuted); 0::status(o_bc52b1e05adc6df4fc37,unknown).
0::status(o_bcb953009455804af474,supported); 1::status(o_bcb953009455804af474,refuted); 0::status(o_bcb953009455804af474,unknown).
1::status(o_bccf58b45c839f9d8af6,supported); 0::status(o_bccf58b45c839f9d8af6,refuted); 0::status(o_bccf58b45c839f9d8af6,unknown).
0::status(o_bd41b1fce932bcd0db43,supported); 1::status(o_bd41b1fce932bcd0db43,refuted); 0::status(o_bd41b1fce932bcd0db43,unknown).
1::status(o_bd7125dfcf8e194c945d,supported); 0::status(o_bd7125dfcf8e194c945d,refuted); 0::status(o_bd7125dfcf8e194c945d,unknown).
1::status(o_bdaa56e3a17668d27ff0,supported); 0::status(o_bdaa56e3a17668d27ff0,refuted); 0::status(o_bdaa56e3a17668d27ff0,unknown).
1::status(o_bdbfb324f758561b2103,supported); 0::status(o_bdbfb324f758561b2103,refuted); 0::status(o_bdbfb324f758561b2103,unknown).
0::status(o_bdca5d32ba0923f5461c,supported); 1::status(o_bdca5d32ba0923f5461c,refuted); 0::status(o_bdca5d32ba0923f5461c,unknown).
0::status(o_bdecc11e1fd3eb264b89,supported); 1::status(o_bdecc11e1fd3eb264b89,refuted); 0::status(o_bdecc11e1fd3eb264b89,unknown).
0.10388609021902084::status(o_bdf03b5c0638bb84d5a2,supported); 0::status(o_bdf03b5c0638bb84d5a2,refuted); 0.89611390978097916::status(o_bdf03b5c0638bb84d5a2,unknown).
0.037853103131055832::status(o_be134f62dc32b7c452fc,supported); 0::status(o_be134f62dc32b7c452fc,refuted); 0.96214689686894417::status(o_be134f62dc32b7c452fc,unknown).
1::status(o_be198c5a38ac69282199,supported); 0::status(o_be198c5a38ac69282199,refuted); 0::status(o_be198c5a38ac69282199,unknown).
1::status(o_be5cd74f6a1a6a57b5c3,supported); 0::status(o_be5cd74f6a1a6a57b5c3,refuted); 0::status(o_be5cd74f6a1a6a57b5c3,unknown).
1::status(o_be920165638086f9696e,supported); 0::status(o_be920165638086f9696e,refuted); 0::status(o_be920165638086f9696e,unknown).
0.31135774259586463::status(o_bf20867ceeb6de9ec404,supported); 0::status(o_bf20867ceeb6de9ec404,refuted); 0.68864225740413532::status(o_bf20867ceeb6de9ec404,unknown).
0.0013882720377296209::status(o_bfaccc34b94dc00bdbd0,supported); 0::status(o_bfaccc34b94dc00bdbd0,refuted); 0.99861172796227038::status(o_bfaccc34b94dc00bdbd0,unknown).
1::status(o_bfe16197617115d3e200,supported); 0::status(o_bfe16197617115d3e200,refuted); 0::status(o_bfe16197617115d3e200,unknown).
1::status(o_c0f3d0d377de91d95907,supported); 0::status(o_c0f3d0d377de91d95907,refuted); 0::status(o_c0f3d0d377de91d95907,unknown).
0.99213320016860962::status(o_c0fac4d93351ceaf8277,supported); 0::status(o_c0fac4d93351ceaf8277,refuted); 0.0078667998313903809::status(o_c0fac4d93351ceaf8277,unknown).
0::status(o_c1296bcacb89119419e1,supported); 1::status(o_c1296bcacb89119419e1,refuted); 0::status(o_c1296bcacb89119419e1,unknown).
1::status(o_c132fed578dee4d371ed,supported); 0::status(o_c132fed578dee4d371ed,refuted); 0::status(o_c132fed578dee4d371ed,unknown).
0::status(o_c18e5e743c22e59082f3,supported); 0::status(o_c18e5e743c22e59082f3,refuted); 1::status(o_c18e5e743c22e59082f3,unknown).
0::status(o_c22f2390e67774f3b296,supported); 0::status(o_c22f2390e67774f3b296,refuted); 1::status(o_c22f2390e67774f3b296,unknown).
0.61694091558456421::status(o_c27f27c89a11a0c4245b,supported); 0::status(o_c27f27c89a11a0c4245b,refuted); 0.38305908441543579::status(o_c27f27c89a11a0c4245b,unknown).
1::status(o_c2b59cde7f58169d5785,supported); 0::status(o_c2b59cde7f58169d5785,refuted); 0::status(o_c2b59cde7f58169d5785,unknown).
0.96313387155532837::status(o_c2e9ea5043f377c76ea9,supported); 0::status(o_c2e9ea5043f377c76ea9,refuted); 0.036866128444671631::status(o_c2e9ea5043f377c76ea9,unknown).
0.0001668355253059417::status(o_c315f437f02f6ab89eb9,supported); 0::status(o_c315f437f02f6ab89eb9,refuted); 0.99983316447469406::status(o_c315f437f02f6ab89eb9,unknown).
0.98880964517593384::status(o_c33542d0176b31519e79,supported); 0::status(o_c33542d0176b31519e79,refuted); 0.011190354824066162::status(o_c33542d0176b31519e79,unknown).
0::status(o_c3e44b697f7e7c60f7da,supported); 1::status(o_c3e44b697f7e7c60f7da,refuted); 0::status(o_c3e44b697f7e7c60f7da,unknown).
1::status(o_c3e947989ba8236f9df8,supported); 0::status(o_c3e947989ba8236f9df8,refuted); 0::status(o_c3e947989ba8236f9df8,unknown).
1::status(o_c3f6726984127c4a8fcc,supported); 0::status(o_c3f6726984127c4a8fcc,refuted); 0::status(o_c3f6726984127c4a8fcc,unknown).
1::status(o_c40bbae46800aa87e8d6,supported); 0::status(o_c40bbae46800aa87e8d6,refuted); 0::status(o_c40bbae46800aa87e8d6,unknown).
0.00044824578799307346::status(o_c414304f1ad9f6d96be1,supported); 0::status(o_c414304f1ad9f6d96be1,refuted); 0.99955175421200693::status(o_c414304f1ad9f6d96be1,unknown).
0.99660646915435791::status(o_c4316e32d93f6e5c7633,supported); 0::status(o_c4316e32d93f6e5c7633,refuted); 0.0033935308456420898::status(o_c4316e32d93f6e5c7633,unknown).
1::status(o_c43b6953570faf335dd3,supported); 0::status(o_c43b6953570faf335dd3,refuted); 0::status(o_c43b6953570faf335dd3,unknown).
0.99301612377166748::status(o_c43b9b4129d98c8de6d9,supported); 0::status(o_c43b9b4129d98c8de6d9,refuted); 0.0069838762283325195::status(o_c43b9b4129d98c8de6d9,unknown).
0.98997622728347778::status(o_c46bb9220bf685fad680,supported); 0::status(o_c46bb9220bf685fad680,refuted); 0.010023772716522217::status(o_c46bb9220bf685fad680,unknown).
5.7750552951804822e-05::status(o_c4ba84a0918378e21f7d,supported); 0::status(o_c4ba84a0918378e21f7d,refuted); 0.99994224944704824::status(o_c4ba84a0918378e21f7d,unknown).
0.9814574122428894::status(o_c4d5a8f637398dbe56ab,supported); 0::status(o_c4d5a8f637398dbe56ab,refuted); 0.018542587757110596::status(o_c4d5a8f637398dbe56ab,unknown).
0::status(o_c4f5fd73bec2f7321198,supported); 1::status(o_c4f5fd73bec2f7321198,refuted); 0::status(o_c4f5fd73bec2f7321198,unknown).
1::status(o_c4fae8eeade7f381cf3d,supported); 0::status(o_c4fae8eeade7f381cf3d,refuted); 0::status(o_c4fae8eeade7f381cf3d,unknown).
1::status(o_c57419beb55216697801,supported); 0::status(o_c57419beb55216697801,refuted); 0::status(o_c57419beb55216697801,unknown).
0.74738532304763794::status(o_c619d06b6de0b8136b1d,supported); 0::status(o_c619d06b6de0b8136b1d,refuted); 0.25261467695236206::status(o_c619d06b6de0b8136b1d,unknown).
1::status(o_c6332f069ed47da63689,supported); 0::status(o_c6332f069ed47da63689,refuted); 0::status(o_c6332f069ed47da63689,unknown).
1::status(o_c6a4f5ff2be5c2a22c2c,supported); 0::status(o_c6a4f5ff2be5c2a22c2c,refuted); 0::status(o_c6a4f5ff2be5c2a22c2c,unknown).
0.99188774824142456::status(o_c6ba6fb61720f9af4a62,supported); 0::status(o_c6ba6fb61720f9af4a62,refuted); 0.0081122517585754395::status(o_c6ba6fb61720f9af4a62,unknown).
0.00027939380379393697::status(o_c6bd231419704666718a,supported); 0::status(o_c6bd231419704666718a,refuted); 0.99972060619620606::status(o_c6bd231419704666718a,unknown).
1::status(o_c6ca1955471e568f2bf6,supported); 0::status(o_c6ca1955471e568f2bf6,refuted); 0::status(o_c6ca1955471e568f2bf6,unknown).
1::status(o_c756e29a21507f001213,supported); 0::status(o_c756e29a21507f001213,refuted); 0::status(o_c756e29a21507f001213,unknown).
1::status(o_c785fad72da6e6e289a2,supported); 0::status(o_c785fad72da6e6e289a2,refuted); 0::status(o_c785fad72da6e6e289a2,unknown).
1::status(o_c850ae13ce86802cba39,supported); 0::status(o_c850ae13ce86802cba39,refuted); 0::status(o_c850ae13ce86802cba39,unknown).
1::status(o_c854dccb8bffecafac3d,supported); 0::status(o_c854dccb8bffecafac3d,refuted); 0::status(o_c854dccb8bffecafac3d,unknown).
1::status(o_c857d2bf04558f48b742,supported); 0::status(o_c857d2bf04558f48b742,refuted); 0::status(o_c857d2bf04558f48b742,unknown).
1::status(o_c8cb944fac2f307b4212,supported); 0::status(o_c8cb944fac2f307b4212,refuted); 0::status(o_c8cb944fac2f307b4212,unknown).
0::status(o_c8da05b6d96bbc7a4573,supported); 1::status(o_c8da05b6d96bbc7a4573,refuted); 0::status(o_c8da05b6d96bbc7a4573,unknown).
1::status(o_c8dbd7186fc89ca3848e,supported); 0::status(o_c8dbd7186fc89ca3848e,refuted); 0::status(o_c8dbd7186fc89ca3848e,unknown).
0.99810886383056641::status(o_c8ee7ccaaabaee2b82c7,supported); 0::status(o_c8ee7ccaaabaee2b82c7,refuted); 0.0018911361694335938::status(o_c8ee7ccaaabaee2b82c7,unknown).
0.99810886383056641::status(o_c8fcdc4e29b717ea8f13,supported); 0::status(o_c8fcdc4e29b717ea8f13,refuted); 0.0018911361694335938::status(o_c8fcdc4e29b717ea8f13,unknown).
1::status(o_c9216a24ec3c1b90138d,supported); 0::status(o_c9216a24ec3c1b90138d,refuted); 0::status(o_c9216a24ec3c1b90138d,unknown).
0::status(o_c930e2dffe090a2ddd39,supported); 1::status(o_c930e2dffe090a2ddd39,refuted); 0::status(o_c930e2dffe090a2ddd39,unknown).
0::status(o_c98f4a373f3d46187e36,supported); 0::status(o_c98f4a373f3d46187e36,refuted); 1::status(o_c98f4a373f3d46187e36,unknown).
0.99093681573867798::status(o_c9f8dffccbf2118f33f8,supported); 0::status(o_c9f8dffccbf2118f33f8,refuted); 0.0090631842613220215::status(o_c9f8dffccbf2118f33f8,unknown).
0.00012811402848456055::status(o_ca81a3788866570be8a1,supported); 0::status(o_ca81a3788866570be8a1,refuted); 0.99987188597151544::status(o_ca81a3788866570be8a1,unknown).
1::status(o_cade8b480e74d438fcc7,supported); 0::status(o_cade8b480e74d438fcc7,refuted); 0::status(o_cade8b480e74d438fcc7,unknown).
1::status(o_cb76d2e819ced06dc6c4,supported); 0::status(o_cb76d2e819ced06dc6c4,refuted); 0::status(o_cb76d2e819ced06dc6c4,unknown).
0.99738341569900513::status(o_cbcfe2831bbaeb029e50,supported); 0::status(o_cbcfe2831bbaeb029e50,refuted); 0.002616584300994873::status(o_cbcfe2831bbaeb029e50,unknown).
0.99738341569900513::status(o_cc08480e8dd5fcb35cb9,supported); 0::status(o_cc08480e8dd5fcb35cb9,refuted); 0.002616584300994873::status(o_cc08480e8dd5fcb35cb9,unknown).
1::status(o_cc2405f43ecd7cf0f296,supported); 0::status(o_cc2405f43ecd7cf0f296,refuted); 0::status(o_cc2405f43ecd7cf0f296,unknown).
0::status(o_cc66678bdf98844bc9fb,supported); 1::status(o_cc66678bdf98844bc9fb,refuted); 0::status(o_cc66678bdf98844bc9fb,unknown).
1::status(o_cca21f815b2cedd78f60,supported); 0::status(o_cca21f815b2cedd78f60,refuted); 0::status(o_cca21f815b2cedd78f60,unknown).
0::status(o_cd414cb687321f1be59d,supported); 0::status(o_cd414cb687321f1be59d,refuted); 1::status(o_cd414cb687321f1be59d,unknown).
0.00066984596196562052::status(o_cd573afdba4e02fae6e0,supported); 0::status(o_cd573afdba4e02fae6e0,refuted); 0.99933015403803438::status(o_cd573afdba4e02fae6e0,unknown).
1::status(o_cd6a608cf0d21ad05b58,supported); 0::status(o_cd6a608cf0d21ad05b58,refuted); 0::status(o_cd6a608cf0d21ad05b58,unknown).
0.0013122661039233208::status(o_cd814323bb9f5a9fb831,supported); 0::status(o_cd814323bb9f5a9fb831,refuted); 0.99868773389607668::status(o_cd814323bb9f5a9fb831,unknown).
1::status(o_cd8747bff95cfe88b027,supported); 0::status(o_cd8747bff95cfe88b027,refuted); 0::status(o_cd8747bff95cfe88b027,unknown).
1::status(o_cda019e8d0fad21ba51d,supported); 0::status(o_cda019e8d0fad21ba51d,refuted); 0::status(o_cda019e8d0fad21ba51d,unknown).
0.99738341569900513::status(o_cde41612a89d28849a62,supported); 0::status(o_cde41612a89d28849a62,refuted); 0.002616584300994873::status(o_cde41612a89d28849a62,unknown).
1::status(o_ce133ee13628fc406642,supported); 0::status(o_ce133ee13628fc406642,refuted); 0::status(o_ce133ee13628fc406642,unknown).
1::status(o_cee82e4b161b918581f3,supported); 0::status(o_cee82e4b161b918581f3,refuted); 0::status(o_cee82e4b161b918581f3,unknown).
0.99495762586593628::status(o_cf195a4fd6271292c835,supported); 0::status(o_cf195a4fd6271292c835,refuted); 0.0050423741340637207::status(o_cf195a4fd6271292c835,unknown).
0.00012811402848456055::status(o_cf1c46bd18b65e02e905,supported); 0::status(o_cf1c46bd18b65e02e905,refuted); 0.99987188597151544::status(o_cf1c46bd18b65e02e905,unknown).
1::status(o_cf2bfd8e5c5b4458c88e,supported); 0::status(o_cf2bfd8e5c5b4458c88e,refuted); 0::status(o_cf2bfd8e5c5b4458c88e,unknown).
1::status(o_cf34ec0f2ad55fd34d42,supported); 0::status(o_cf34ec0f2ad55fd34d42,refuted); 0::status(o_cf34ec0f2ad55fd34d42,unknown).
0::status(o_cf5703ec66abd9abb42c,supported); 0::status(o_cf5703ec66abd9abb42c,refuted); 1::status(o_cf5703ec66abd9abb42c,unknown).
0::status(o_cf7be680b6e981bfd1b7,supported); 1::status(o_cf7be680b6e981bfd1b7,refuted); 0::status(o_cf7be680b6e981bfd1b7,unknown).
0::status(o_cf8da1392540c00750e8,supported); 0::status(o_cf8da1392540c00750e8,refuted); 1::status(o_cf8da1392540c00750e8,unknown).
0.99495738744735718::status(o_cf9a5e3b8d14a71db84a,supported); 0::status(o_cf9a5e3b8d14a71db84a,refuted); 0.0050426125526428223::status(o_cf9a5e3b8d14a71db84a,unknown).
0::status(o_d00e00d25b5fc9e8b8ef,supported); 0::status(o_d00e00d25b5fc9e8b8ef,refuted); 1::status(o_d00e00d25b5fc9e8b8ef,unknown).
1.3034778761802781e-06::status(o_d063b069e64888cc1804,supported); 0::status(o_d063b069e64888cc1804,refuted); 0.99999869652212381::status(o_d063b069e64888cc1804,unknown).
4.6348650727496434e-05::status(o_d087113568f0ecd777a7,supported); 0::status(o_d087113568f0ecd777a7,refuted); 0.9999536513492725::status(o_d087113568f0ecd777a7,unknown).
1::status(o_d0e0cc6e0f93d3c26e2f,supported); 0::status(o_d0e0cc6e0f93d3c26e2f,refuted); 0::status(o_d0e0cc6e0f93d3c26e2f,unknown).
0.99999882968458842::status(o_d0fd28b19816f6286015,supported); 0::status(o_d0fd28b19816f6286015,refuted); 1.1703154115805248e-06::status(o_d0fd28b19816f6286015,unknown).
0.97427183389663696::status(o_d1273b84354d867e095a,supported); 0::status(o_d1273b84354d867e095a,refuted); 0.025728166103363037::status(o_d1273b84354d867e095a,unknown).
0::status(o_d131f92fd425cdb10771,supported); 1::status(o_d131f92fd425cdb10771,refuted); 0::status(o_d131f92fd425cdb10771,unknown).
0.98102275343556544::status(o_d15c27632971b3e29246,supported); 0::status(o_d15c27632971b3e29246,refuted); 0.018977246564434558::status(o_d15c27632971b3e29246,unknown).
1::status(o_d16129ee96d26d0d8811,supported); 0::status(o_d16129ee96d26d0d8811,refuted); 0::status(o_d16129ee96d26d0d8811,unknown).
0.00063768832478672266::status(o_d1f5d53fc68f5414b81a,supported); 0::status(o_d1f5d53fc68f5414b81a,refuted); 0.99936231167521328::status(o_d1f5d53fc68f5414b81a,unknown).
1::status(o_d208daf792bb4b4b31f1,supported); 0::status(o_d208daf792bb4b4b31f1,refuted); 0::status(o_d208daf792bb4b4b31f1,unknown).
0.0013122661039233208::status(o_d2127065c3ff98ba98b1,supported); 0::status(o_d2127065c3ff98ba98b1,refuted); 0.99868773389607668::status(o_d2127065c3ff98ba98b1,unknown).
0.998406055936786::status(o_d2edda89bf3f3411b7d9,supported); 0::status(o_d2edda89bf3f3411b7d9,refuted); 0.0015939440632140034::status(o_d2edda89bf3f3411b7d9,unknown).
0.98598873615264893::status(o_d2f231da2ffba9e122ec,supported); 0::status(o_d2f231da2ffba9e122ec,refuted); 0.014011263847351074::status(o_d2f231da2ffba9e122ec,unknown).
0::status(o_d32f52ee0e593de63183,supported); 1::status(o_d32f52ee0e593de63183,refuted); 0::status(o_d32f52ee0e593de63183,unknown).
0.00076209998223930597::status(o_d34fb6f9b4b26cbf1270,supported); 0::status(o_d34fb6f9b4b26cbf1270,refuted); 0.99923790001776069::status(o_d34fb6f9b4b26cbf1270,unknown).
1::status(o_d38d47c62950ba62ba0f,supported); 0::status(o_d38d47c62950ba62ba0f,refuted); 0::status(o_d38d47c62950ba62ba0f,unknown).
0::status(o_d3ccd8b2b7fbcc59448a,supported); 0::status(o_d3ccd8b2b7fbcc59448a,refuted); 1::status(o_d3ccd8b2b7fbcc59448a,unknown).
1::status(o_d3d8cc3011e619564d68,supported); 0::status(o_d3d8cc3011e619564d68,refuted); 0::status(o_d3d8cc3011e619564d68,unknown).
1::status(o_d3e4c9c731b5111421a5,supported); 0::status(o_d3e4c9c731b5111421a5,refuted); 0::status(o_d3e4c9c731b5111421a5,unknown).
0.98314672708511353::status(o_d3e8bddcf3fbf581b29b,supported); 0::status(o_d3e8bddcf3fbf581b29b,refuted); 0.016853272914886475::status(o_d3e8bddcf3fbf581b29b,unknown).
1::status(o_d3f35ad4c9e04cc15610,supported); 0::status(o_d3f35ad4c9e04cc15610,refuted); 0::status(o_d3f35ad4c9e04cc15610,unknown).
0::status(o_d43ce407bdf5929c3ac0,supported); 0::status(o_d43ce407bdf5929c3ac0,refuted); 1::status(o_d43ce407bdf5929c3ac0,unknown).
0::status(o_d43f8fdfc0005afea177,supported); 1::status(o_d43f8fdfc0005afea177,refuted); 0::status(o_d43f8fdfc0005afea177,unknown).
0.99007987976074219::status(o_d465bfa16a2bd1e73e4f,supported); 0::status(o_d465bfa16a2bd1e73e4f,refuted); 0.0099201202392578125::status(o_d465bfa16a2bd1e73e4f,unknown).
1::status(o_d4b61e9af99e88b16127,supported); 0::status(o_d4b61e9af99e88b16127,refuted); 0::status(o_d4b61e9af99e88b16127,unknown).
1::status(o_d4cbd03a461d5a4f56a5,supported); 0::status(o_d4cbd03a461d5a4f56a5,refuted); 0::status(o_d4cbd03a461d5a4f56a5,unknown).
0.003883931552991271::status(o_d4e16cdcc124d804fb79,supported); 0::status(o_d4e16cdcc124d804fb79,refuted); 0.99611606844700873::status(o_d4e16cdcc124d804fb79,unknown).
1::status(o_d4eb0291b8f20fb4c3ac,supported); 0::status(o_d4eb0291b8f20fb4c3ac,refuted); 0::status(o_d4eb0291b8f20fb4c3ac,unknown).
0::status(o_d4f367e7b28843fc41ac,supported); 1::status(o_d4f367e7b28843fc41ac,refuted); 0::status(o_d4f367e7b28843fc41ac,unknown).
1::status(o_d559a78cd9a76269c3c8,supported); 0::status(o_d559a78cd9a76269c3c8,refuted); 0::status(o_d559a78cd9a76269c3c8,unknown).
0.0042693153955042362::status(o_d58522cf484d985ed585,supported); 0::status(o_d58522cf484d985ed585,refuted); 0.99573068460449576::status(o_d58522cf484d985ed585,unknown).
0.31135774259586463::status(o_d586da97b57850fbb805,supported); 0::status(o_d586da97b57850fbb805,refuted); 0.68864225740413532::status(o_d586da97b57850fbb805,unknown).
1::status(o_d5a5640ffb152cae68c0,supported); 0::status(o_d5a5640ffb152cae68c0,refuted); 0::status(o_d5a5640ffb152cae68c0,unknown).
1::status(o_d62e779d0ce15d43083c,supported); 0::status(o_d62e779d0ce15d43083c,refuted); 0::status(o_d62e779d0ce15d43083c,unknown).
0.99346327781677246::status(o_d6365bc28b33fd46d85a,supported); 0::status(o_d6365bc28b33fd46d85a,refuted); 0.0065367221832275391::status(o_d6365bc28b33fd46d85a,unknown).
0.98928332328796387::status(o_d67f1c8773933c90285a,supported); 0::status(o_d67f1c8773933c90285a,refuted); 0.010716676712036133::status(o_d67f1c8773933c90285a,unknown).
0.99999999306661269::status(o_d6a53790183477eec59a,supported); 0::status(o_d6a53790183477eec59a,refuted); 6.9333873087273901e-09::status(o_d6a53790183477eec59a,unknown).
0::status(o_d6cb23e45e4607f37c7a,supported); 0::status(o_d6cb23e45e4607f37c7a,refuted); 1::status(o_d6cb23e45e4607f37c7a,unknown).
1::status(o_d6e9070ccb5ac0abf8a5,supported); 0::status(o_d6e9070ccb5ac0abf8a5,refuted); 0::status(o_d6e9070ccb5ac0abf8a5,unknown).
0.0044489046558737755::status(o_d6fa0a0ae270bcfd8a6c,supported); 0::status(o_d6fa0a0ae270bcfd8a6c,refuted); 0.99555109534412622::status(o_d6fa0a0ae270bcfd8a6c,unknown).
0.00027939380379393697::status(o_d72e1fe86f761463c965,supported); 0::status(o_d72e1fe86f761463c965,refuted); 0.99972060619620606::status(o_d72e1fe86f761463c965,unknown).
1::status(o_d7ac5035eded8e971761,supported); 0::status(o_d7ac5035eded8e971761,refuted); 0::status(o_d7ac5035eded8e971761,unknown).
1::status(o_d7b4ca64409317efac7c,supported); 0::status(o_d7b4ca64409317efac7c,refuted); 0::status(o_d7b4ca64409317efac7c,unknown).
1::status(o_d7ee36f90df34760f3bc,supported); 0::status(o_d7ee36f90df34760f3bc,refuted); 0::status(o_d7ee36f90df34760f3bc,unknown).
1::status(o_d7ee50d8db99f78050ee,supported); 0::status(o_d7ee50d8db99f78050ee,refuted); 0::status(o_d7ee50d8db99f78050ee,unknown).
0.99172943830490112::status(o_d8014b3822777dc37c7c,supported); 0::status(o_d8014b3822777dc37c7c,refuted); 0.008270561695098877::status(o_d8014b3822777dc37c7c,unknown).
0.065258555114269257::status(o_d87baee3f3f4b211234b,supported); 0::status(o_d87baee3f3f4b211234b,refuted); 0.93474144488573074::status(o_d87baee3f3f4b211234b,unknown).
2.7902980907204649e-05::status(o_d8973fe006c2fd358813,supported); 0::status(o_d8973fe006c2fd358813,refuted); 0.99997209701909284::status(o_d8973fe006c2fd358813,unknown).
0.00062835169956088066::status(o_d8e83dca38374d95e217,supported); 0::status(o_d8e83dca38374d95e217,refuted); 0.99937164830043912::status(o_d8e83dca38374d95e217,unknown).
0.99365460872650146::status(o_d953fc8a78bccc0529c1,supported); 0::status(o_d953fc8a78bccc0529c1,refuted); 0.0063453912734985352::status(o_d953fc8a78bccc0529c1,unknown).
1::status(o_d97c7c2712413bd5d595,supported); 0::status(o_d97c7c2712413bd5d595,refuted); 0::status(o_d97c7c2712413bd5d595,unknown).
0::status(o_d9aedf24173c22d880d2,supported); 1::status(o_d9aedf24173c22d880d2,refuted); 0::status(o_d9aedf24173c22d880d2,unknown).
0::status(o_d9da9dc0d7bf3b63e40c,supported); 0::status(o_d9da9dc0d7bf3b63e40c,refuted); 1::status(o_d9da9dc0d7bf3b63e40c,unknown).
1::status(o_da44656b3ad7f5998173,supported); 0::status(o_da44656b3ad7f5998173,refuted); 0::status(o_da44656b3ad7f5998173,unknown).
1::status(o_da519866cb1c60a54815,supported); 0::status(o_da519866cb1c60a54815,refuted); 0::status(o_da519866cb1c60a54815,unknown).
0.99524873495101929::status(o_daa75a381ecbcfa88369,supported); 0::status(o_daa75a381ecbcfa88369,refuted); 0.0047512650489807129::status(o_daa75a381ecbcfa88369,unknown).
0::status(o_dab5ed08a19c05060028,supported); 0::status(o_dab5ed08a19c05060028,refuted); 1::status(o_dab5ed08a19c05060028,unknown).
0::status(o_db36a470810ed3dda20a,supported); 0::status(o_db36a470810ed3dda20a,refuted); 1::status(o_db36a470810ed3dda20a,unknown).
0.00012811402848456055::status(o_db78ccc20e830be93917,supported); 0::status(o_db78ccc20e830be93917,refuted); 0.99987188597151544::status(o_db78ccc20e830be93917,unknown).
0::status(o_db82a82c3b7af847537d,supported); 0::status(o_db82a82c3b7af847537d,refuted); 1::status(o_db82a82c3b7af847537d,unknown).
0::status(o_db998042cb35b6e7bb68,supported); 1::status(o_db998042cb35b6e7bb68,refuted); 0::status(o_db998042cb35b6e7bb68,unknown).
0::status(o_db998b28f25a13f0a5b0,supported); 1::status(o_db998b28f25a13f0a5b0,refuted); 0::status(o_db998b28f25a13f0a5b0,unknown).
1::status(o_dbc69557e04af9f4e9d8,supported); 0::status(o_dbc69557e04af9f4e9d8,refuted); 0::status(o_dbc69557e04af9f4e9d8,unknown).
1::status(o_dbdc828e10bb2cb4941d,supported); 0::status(o_dbdc828e10bb2cb4941d,refuted); 0::status(o_dbdc828e10bb2cb4941d,unknown).
0.0010018589673563838::status(o_dc231652ba17847959d8,supported); 0::status(o_dc231652ba17847959d8,refuted); 0.99899814103264362::status(o_dc231652ba17847959d8,unknown).
1::status(o_dc2465ef366877b97935,supported); 0::status(o_dc2465ef366877b97935,refuted); 0::status(o_dc2465ef366877b97935,unknown).
1::status(o_dc7672bba93bc777db3a,supported); 0::status(o_dc7672bba93bc777db3a,refuted); 0::status(o_dc7672bba93bc777db3a,unknown).
0.0060226605273783207::status(o_dcb2ed7a46df89f934be,supported); 0::status(o_dcb2ed7a46df89f934be,refuted); 0.99397733947262168::status(o_dcb2ed7a46df89f934be,unknown).
0.99007987976074219::status(o_dcc47511502e7c6c6127,supported); 0::status(o_dcc47511502e7c6c6127,refuted); 0.0099201202392578125::status(o_dcc47511502e7c6c6127,unknown).
0.95537519454956055::status(o_dd362728f3ef147cc7ec,supported); 0::status(o_dd362728f3ef147cc7ec,refuted); 0.044624805450439453::status(o_dd362728f3ef147cc7ec,unknown).
1::status(o_dd57d8628d17932bb36c,supported); 0::status(o_dd57d8628d17932bb36c,refuted); 0::status(o_dd57d8628d17932bb36c,unknown).
0.00011422050738474354::status(o_dd7dcd0a0be0a7d36d06,supported); 0::status(o_dd7dcd0a0be0a7d36d06,refuted); 0.99988577949261526::status(o_dd7dcd0a0be0a7d36d06,unknown).
1::status(o_dd894d97034bfc415849,supported); 0::status(o_dd894d97034bfc415849,refuted); 0::status(o_dd894d97034bfc415849,unknown).
0.00011525061563588679::status(o_ddaad6b3c53e25ce0d18,supported); 0::status(o_ddaad6b3c53e25ce0d18,refuted); 0.99988474938436411::status(o_ddaad6b3c53e25ce0d18,unknown).
0.99999983246230739::status(o_ddb00a01159bbae30aae,supported); 0::status(o_ddb00a01159bbae30aae,refuted); 1.6753769260802187e-07::status(o_ddb00a01159bbae30aae,unknown).
0.0005490043549798429::status(o_de438038c7925581809c,supported); 0::status(o_de438038c7925581809c,refuted); 0.99945099564502016::status(o_de438038c7925581809c,unknown).
0.0018071738304570317::status(o_deb5c9d493cc179a2442,supported); 0::status(o_deb5c9d493cc179a2442,refuted); 0.99819282616954297::status(o_deb5c9d493cc179a2442,unknown).
1.3019815249289163e-07::status(o_dee43e88572cb215de78,supported); 0::status(o_dee43e88572cb215de78,refuted); 0.99999986980184752::status(o_dee43e88572cb215de78,unknown).
0::status(o_deec84bed219694e2e98,supported); 0::status(o_deec84bed219694e2e98,refuted); 1::status(o_deec84bed219694e2e98,unknown).
0::status(o_def7f101e71a79c773f6,supported); 0::status(o_def7f101e71a79c773f6,refuted); 1::status(o_def7f101e71a79c773f6,unknown).
0.10388609021902084::status(o_dfd8f6bf8fe912583eb1,supported); 0::status(o_dfd8f6bf8fe912583eb1,refuted); 0.89611390978097916::status(o_dfd8f6bf8fe912583eb1,unknown).
1::status(o_e02ade9aa00b7050031d,supported); 0::status(o_e02ade9aa00b7050031d,refuted); 0::status(o_e02ade9aa00b7050031d,unknown).
0.99680787324905396::status(o_e0559db81481b41187ce,supported); 0::status(o_e0559db81481b41187ce,refuted); 0.0031921267509460449::status(o_e0559db81481b41187ce,unknown).
0.99999996709064987::status(o_e0723e2d87499700ac65,supported); 0::status(o_e0723e2d87499700ac65,refuted); 3.2909350133891735e-08::status(o_e0723e2d87499700ac65,unknown).
0.99310886859893799::status(o_e0817f737b36fd62f919,supported); 0::status(o_e0817f737b36fd62f919,refuted); 0.0068911314010620117::status(o_e0817f737b36fd62f919,unknown).
0.00027316782507114112::status(o_e0c102a3ef5c5d5f74fd,supported); 0::status(o_e0c102a3ef5c5d5f74fd,refuted); 0.99972683217492886::status(o_e0c102a3ef5c5d5f74fd,unknown).
0.00048713211435824633::status(o_e0ec382b413e8f48ebfb,supported); 0::status(o_e0ec382b413e8f48ebfb,refuted); 0.99951286788564175::status(o_e0ec382b413e8f48ebfb,unknown).
0::status(o_e10a4621e1cffa26f637,supported); 1::status(o_e10a4621e1cffa26f637,refuted); 0::status(o_e10a4621e1cffa26f637,unknown).
1::status(o_e129b08123df2e6898b5,supported); 0::status(o_e129b08123df2e6898b5,refuted); 0::status(o_e129b08123df2e6898b5,unknown).
1::status(o_e12caca490a37561e3f8,supported); 0::status(o_e12caca490a37561e3f8,refuted); 0::status(o_e12caca490a37561e3f8,unknown).
1::status(o_e14682bd6f638efbaa7f,supported); 0::status(o_e14682bd6f638efbaa7f,refuted); 0::status(o_e14682bd6f638efbaa7f,unknown).
0.99999983246230739::status(o_e197d1dcb927026dcb44,supported); 0::status(o_e197d1dcb927026dcb44,refuted); 1.6753769260802187e-07::status(o_e197d1dcb927026dcb44,unknown).
1::status(o_e23d226dd55413e5e2ac,supported); 0::status(o_e23d226dd55413e5e2ac,refuted); 0::status(o_e23d226dd55413e5e2ac,unknown).
1::status(o_e23f55433d4c1e7b5354,supported); 0::status(o_e23f55433d4c1e7b5354,refuted); 0::status(o_e23f55433d4c1e7b5354,unknown).
0.0013008691603317857::status(o_e26d5de6bcec9f254da2,supported); 0::status(o_e26d5de6bcec9f254da2,refuted); 0.99869913083966821::status(o_e26d5de6bcec9f254da2,unknown).
1::status(o_e28207a28515ef85a3e8,supported); 0::status(o_e28207a28515ef85a3e8,refuted); 0::status(o_e28207a28515ef85a3e8,unknown).
0::status(o_e29ed797926b66159c3d,supported); 1::status(o_e29ed797926b66159c3d,refuted); 0::status(o_e29ed797926b66159c3d,unknown).
1::status(o_e2c5bc0c2d4b1267c059,supported); 0::status(o_e2c5bc0c2d4b1267c059,refuted); 0::status(o_e2c5bc0c2d4b1267c059,unknown).
0.0018071738304570317::status(o_e2f997f7bf8deaa1bbaa,supported); 0::status(o_e2f997f7bf8deaa1bbaa,refuted); 0.99819282616954297::status(o_e2f997f7bf8deaa1bbaa,unknown).
0.976348876953125::status(o_e311180f4cb4245f367c,supported); 0::status(o_e311180f4cb4245f367c,refuted); 0.023651123046875::status(o_e311180f4cb4245f367c,unknown).
1::status(o_e34806bde7575dd22e67,supported); 0::status(o_e34806bde7575dd22e67,refuted); 0::status(o_e34806bde7575dd22e67,unknown).
1::status(o_e377df09da0eae980bfc,supported); 0::status(o_e377df09da0eae980bfc,refuted); 0::status(o_e377df09da0eae980bfc,unknown).
1::status(o_e3cb3a441c534a595f7a,supported); 0::status(o_e3cb3a441c534a595f7a,refuted); 0::status(o_e3cb3a441c534a595f7a,unknown).
0.99999999827831965::status(o_e3feadf276d8fc2c5bfb,supported); 0::status(o_e3feadf276d8fc2c5bfb,refuted); 1.7216803538389058e-09::status(o_e3feadf276d8fc2c5bfb,unknown).
0::status(o_e401cb98da497c54b540,supported); 1::status(o_e401cb98da497c54b540,refuted); 0::status(o_e401cb98da497c54b540,unknown).
1::status(o_e420dddc066851ac89e2,supported); 0::status(o_e420dddc066851ac89e2,refuted); 0::status(o_e420dddc066851ac89e2,unknown).
0.98880964517593384::status(o_e4708847e48f06ef8504,supported); 0::status(o_e4708847e48f06ef8504,refuted); 0.011190354824066162::status(o_e4708847e48f06ef8504,unknown).
1::status(o_e47a4d6f4c19369cc520,supported); 0::status(o_e47a4d6f4c19369cc520,refuted); 0::status(o_e47a4d6f4c19369cc520,unknown).
0.99495762586593628::status(o_e4ae752067d6a94b6865,supported); 0::status(o_e4ae752067d6a94b6865,refuted); 0.0050423741340637207::status(o_e4ae752067d6a94b6865,unknown).
1::status(o_e4b35d9d8d6d46c264c4,supported); 0::status(o_e4b35d9d8d6d46c264c4,refuted); 0::status(o_e4b35d9d8d6d46c264c4,unknown).
0.0013882720377296209::status(o_e534007adfa10727b692,supported); 0::status(o_e534007adfa10727b692,refuted); 0.99861172796227038::status(o_e534007adfa10727b692,unknown).
0::status(o_e56ed5a5002e1b38f364,supported); 1::status(o_e56ed5a5002e1b38f364,refuted); 0::status(o_e56ed5a5002e1b38f364,unknown).
0::status(o_e581d252866b4d8b2106,supported); 1::status(o_e581d252866b4d8b2106,refuted); 0::status(o_e581d252866b4d8b2106,unknown).
1::status(o_e5e05449de764f4e05ff,supported); 0::status(o_e5e05449de764f4e05ff,refuted); 0::status(o_e5e05449de764f4e05ff,unknown).
0.98844796419143677::status(o_e61d6019545240e21512,supported); 0::status(o_e61d6019545240e21512,refuted); 0.011552035808563232::status(o_e61d6019545240e21512,unknown).
1::status(o_e6686e4cb2652f37c92a,supported); 0::status(o_e6686e4cb2652f37c92a,refuted); 0::status(o_e6686e4cb2652f37c92a,unknown).
0.99139624834060669::status(o_e6fbbe996a5ac3572aff,supported); 0::status(o_e6fbbe996a5ac3572aff,refuted); 0.0086037516593933105::status(o_e6fbbe996a5ac3572aff,unknown).
9.0030916908290237e-05::status(o_e6fd7d39987113209bbc,supported); 0::status(o_e6fd7d39987113209bbc,refuted); 0.99990996908309171::status(o_e6fd7d39987113209bbc,unknown).
1::status(o_e7178f8dafa28fe4c533,supported); 0::status(o_e7178f8dafa28fe4c533,refuted); 0::status(o_e7178f8dafa28fe4c533,unknown).
0.0070033296942710876::status(o_e7d80049e03a284c7b52,supported); 0::status(o_e7d80049e03a284c7b52,refuted); 0.99299667030572891::status(o_e7d80049e03a284c7b52,unknown).
0::status(o_e817cd45ae8ffb6075ef,supported); 0::status(o_e817cd45ae8ffb6075ef,refuted); 1::status(o_e817cd45ae8ffb6075ef,unknown).
0.96754372119903564::status(o_e8253b9dedd8fe6f07a7,supported); 0::status(o_e8253b9dedd8fe6f07a7,refuted); 0.032456278800964355::status(o_e8253b9dedd8fe6f07a7,unknown).
0.00048713211435824633::status(o_e83fedbe6cf8292b8c5e,supported); 0::status(o_e83fedbe6cf8292b8c5e,refuted); 0.99951286788564175::status(o_e83fedbe6cf8292b8c5e,unknown).
0.0005490043549798429::status(o_e85177531c234eda872d,supported); 0::status(o_e85177531c234eda872d,refuted); 0.99945099564502016::status(o_e85177531c234eda872d,unknown).
0.99999108955419413::status(o_e8a174bfdf465539ca5c,supported); 0::status(o_e8a174bfdf465539ca5c,refuted); 8.910445805865308e-06::status(o_e8a174bfdf465539ca5c,unknown).
0::status(o_e96e6d602b3170911c18,supported); 1::status(o_e96e6d602b3170911c18,refuted); 0::status(o_e96e6d602b3170911c18,unknown).
1::status(o_e98136905fa99407c995,supported); 0::status(o_e98136905fa99407c995,refuted); 0::status(o_e98136905fa99407c995,unknown).
0::status(o_e99d4fb0ee9312c90292,supported); 0::status(o_e99d4fb0ee9312c90292,refuted); 1::status(o_e99d4fb0ee9312c90292,unknown).
0.00012811402848456055::status(o_ea04e2592f38d3108d5f,supported); 0::status(o_ea04e2592f38d3108d5f,refuted); 0.99987188597151544::status(o_ea04e2592f38d3108d5f,unknown).
1::status(o_ea21f852150cc0b24217,supported); 0::status(o_ea21f852150cc0b24217,refuted); 0::status(o_ea21f852150cc0b24217,unknown).
1::status(o_ea7d1a0cda684657a6cb,supported); 0::status(o_ea7d1a0cda684657a6cb,refuted); 0::status(o_ea7d1a0cda684657a6cb,unknown).
1::status(o_ea9ac559ff0b60cd70aa,supported); 0::status(o_ea9ac559ff0b60cd70aa,refuted); 0::status(o_ea9ac559ff0b60cd70aa,unknown).
0.9803808331489563::status(o_ead7fa18e7e347b42e7a,supported); 0::status(o_ead7fa18e7e347b42e7a,refuted); 0.019619166851043701::status(o_ead7fa18e7e347b42e7a,unknown).
0.96754372119903564::status(o_eadb337b974322e3e19c,supported); 0::status(o_eadb337b974322e3e19c,refuted); 0.032456278800964355::status(o_eadb337b974322e3e19c,unknown).
1::status(o_eb09ac1f2d6009f160f1,supported); 0::status(o_eb09ac1f2d6009f160f1,refuted); 0::status(o_eb09ac1f2d6009f160f1,unknown).
0::status(o_eb5abd4780782cd0239c,supported); 0::status(o_eb5abd4780782cd0239c,refuted); 1::status(o_eb5abd4780782cd0239c,unknown).
0.74738532304763794::status(o_eb7d5a9f888f58bb8732,supported); 0::status(o_eb7d5a9f888f58bb8732,refuted); 0.25261467695236206::status(o_eb7d5a9f888f58bb8732,unknown).
1::status(o_ebdea209f5dc0c12c7cf,supported); 0::status(o_ebdea209f5dc0c12c7cf,refuted); 0::status(o_ebdea209f5dc0c12c7cf,unknown).
1::status(o_ebe611f1c8762619764a,supported); 0::status(o_ebe611f1c8762619764a,refuted); 0::status(o_ebe611f1c8762619764a,unknown).
1::status(o_ec4310698b6582d7f82f,supported); 0::status(o_ec4310698b6582d7f82f,refuted); 0::status(o_ec4310698b6582d7f82f,unknown).
0.97427183389663696::status(o_ec5429a7b34c929fb83d,supported); 0::status(o_ec5429a7b34c929fb83d,refuted); 0.025728166103363037::status(o_ec5429a7b34c929fb83d,unknown).
0.00027939380379393697::status(o_ec58f92678b8a1512fb2,supported); 0::status(o_ec58f92678b8a1512fb2,refuted); 0.99972060619620606::status(o_ec58f92678b8a1512fb2,unknown).
1::status(o_ec892c70930bb46d69ba,supported); 0::status(o_ec892c70930bb46d69ba,refuted); 0::status(o_ec892c70930bb46d69ba,unknown).
0.039551112800836563::status(o_ece6022cec0b402b6acf,supported); 0::status(o_ece6022cec0b402b6acf,refuted); 0.96044888719916344::status(o_ece6022cec0b402b6acf,unknown).
0::status(o_ecf730f1f458f2341348,supported); 1::status(o_ecf730f1f458f2341348,refuted); 0::status(o_ecf730f1f458f2341348,unknown).
1::status(o_ed3c7ef8383df4a317f2,supported); 0::status(o_ed3c7ef8383df4a317f2,refuted); 0::status(o_ed3c7ef8383df4a317f2,unknown).
0.98928332328796387::status(o_ed9c79182c7bda9ed78b,supported); 0::status(o_ed9c79182c7bda9ed78b,refuted); 0.010716676712036133::status(o_ed9c79182c7bda9ed78b,unknown).
0.0060226605273783207::status(o_eda88ddfb64a1312e49e,supported); 0::status(o_eda88ddfb64a1312e49e,refuted); 0.99397733947262168::status(o_eda88ddfb64a1312e49e,unknown).
1::status(o_edb7c6e9f6d749181047,supported); 0::status(o_edb7c6e9f6d749181047,refuted); 0::status(o_edb7c6e9f6d749181047,unknown).
1::status(o_edd12c32aa138aab04ad,supported); 0::status(o_edd12c32aa138aab04ad,refuted); 0::status(o_edd12c32aa138aab04ad,unknown).
0.99667513370513916::status(o_ee02416d60c830d0ed3b,supported); 0::status(o_ee02416d60c830d0ed3b,refuted); 0.0033248662948608398::status(o_ee02416d60c830d0ed3b,unknown).
1::status(o_ee035c7b7bdb3cf7252c,supported); 0::status(o_ee035c7b7bdb3cf7252c,refuted); 0::status(o_ee035c7b7bdb3cf7252c,unknown).
1::status(o_ee16e8e7f9a44f1f4df7,supported); 0::status(o_ee16e8e7f9a44f1f4df7,refuted); 0::status(o_ee16e8e7f9a44f1f4df7,unknown).
0.99999983246230739::status(o_ee1f4875a1b4a92601cc,supported); 0::status(o_ee1f4875a1b4a92601cc,refuted); 1.6753769260802187e-07::status(o_ee1f4875a1b4a92601cc,unknown).
0.99876297288292504::status(o_ee475014315fb305c192,supported); 0::status(o_ee475014315fb305c192,refuted); 0.0012370271170749625::status(o_ee475014315fb305c192,unknown).
1::status(o_eebc051d240182f0288d,supported); 0::status(o_eebc051d240182f0288d,refuted); 0::status(o_eebc051d240182f0288d,unknown).
1::status(o_eed2867752b2c39965ac,supported); 0::status(o_eed2867752b2c39965ac,refuted); 0::status(o_eed2867752b2c39965ac,unknown).
1::status(o_eef3b9a0209ba9e874b8,supported); 0::status(o_eef3b9a0209ba9e874b8,refuted); 0::status(o_eef3b9a0209ba9e874b8,unknown).
0.99045181274414062::status(o_ef0900d9fd1cf13abdf9,supported); 0::status(o_ef0900d9fd1cf13abdf9,refuted); 0.009548187255859375::status(o_ef0900d9fd1cf13abdf9,unknown).
0.99964323617997897::status(o_ef3293d74a9d10dc4fbd,supported); 0::status(o_ef3293d74a9d10dc4fbd,refuted); 0.00035676382002103324::status(o_ef3293d74a9d10dc4fbd,unknown).
1::status(o_ef342d81bcc2832ab377,supported); 0::status(o_ef342d81bcc2832ab377,refuted); 0::status(o_ef342d81bcc2832ab377,unknown).
0.039551112800836563::status(o_ef4e548f0ae2eaf0b516,supported); 0::status(o_ef4e548f0ae2eaf0b516,refuted); 0.96044888719916344::status(o_ef4e548f0ae2eaf0b516,unknown).
1::status(o_ef91b59276c35a3edfc5,supported); 0::status(o_ef91b59276c35a3edfc5,refuted); 0::status(o_ef91b59276c35a3edfc5,unknown).
1::status(o_efa78458c5243af85e21,supported); 0::status(o_efa78458c5243af85e21,refuted); 0::status(o_efa78458c5243af85e21,unknown).
0.00027939380379393697::status(o_efd29a5eabe112b90c9a,supported); 0::status(o_efd29a5eabe112b90c9a,refuted); 0.99972060619620606::status(o_efd29a5eabe112b90c9a,unknown).
0.98928332328796387::status(o_efda2be13d76625cd3be,supported); 0::status(o_efda2be13d76625cd3be,refuted); 0.010716676712036133::status(o_efda2be13d76625cd3be,unknown).
0.98314672708511353::status(o_effc920ba2ff17c3f981,supported); 0::status(o_effc920ba2ff17c3f981,refuted); 0.016853272914886475::status(o_effc920ba2ff17c3f981,unknown).
0.0005490043549798429::status(o_f02b6fcd3df6ee126f00,supported); 0::status(o_f02b6fcd3df6ee126f00,refuted); 0.99945099564502016::status(o_f02b6fcd3df6ee126f00,unknown).
1::status(o_f06fe9592fa0a515d469,supported); 0::status(o_f06fe9592fa0a515d469,refuted); 0::status(o_f06fe9592fa0a515d469,unknown).
0.002602787222713232::status(o_f085f77fa801f9a88b1b,supported); 0::status(o_f085f77fa801f9a88b1b,refuted); 0.99739721277728677::status(o_f085f77fa801f9a88b1b,unknown).
1::status(o_f08f989014d89432acd9,supported); 0::status(o_f08f989014d89432acd9,refuted); 0::status(o_f08f989014d89432acd9,unknown).
0::status(o_f0dd83e4ed4c79ef195d,supported); 1::status(o_f0dd83e4ed4c79ef195d,refuted); 0::status(o_f0dd83e4ed4c79ef195d,unknown).
1::status(o_f0ef7908a7bb43d41792,supported); 0::status(o_f0ef7908a7bb43d41792,refuted); 0::status(o_f0ef7908a7bb43d41792,unknown).
0.2129049152135849::status(o_f1184516bdb3309cd8b9,supported); 0::status(o_f1184516bdb3309cd8b9,refuted); 0.7870950847864151::status(o_f1184516bdb3309cd8b9,unknown).
1::status(o_f173a5d7b9e1fefdf9cd,supported); 0::status(o_f173a5d7b9e1fefdf9cd,refuted); 0::status(o_f173a5d7b9e1fefdf9cd,unknown).
1::status(o_f1787eb4c84a0ee42b1d,supported); 0::status(o_f1787eb4c84a0ee42b1d,refuted); 0::status(o_f1787eb4c84a0ee42b1d,unknown).
0.00027316782507114112::status(o_f1c9d070086d48972e4c,supported); 0::status(o_f1c9d070086d48972e4c,refuted); 0.99972683217492886::status(o_f1c9d070086d48972e4c,unknown).
1::status(o_f1d171b673d93c68898f,supported); 0::status(o_f1d171b673d93c68898f,refuted); 0::status(o_f1d171b673d93c68898f,unknown).
0.002602787222713232::status(o_f1e74a26f62316ca208a,supported); 0::status(o_f1e74a26f62316ca208a,refuted); 0.99739721277728677::status(o_f1e74a26f62316ca208a,unknown).
0.0007167395087890327::status(o_f2345f54d8791dcdad77,supported); 0::status(o_f2345f54d8791dcdad77,refuted); 0.99928326049121097::status(o_f2345f54d8791dcdad77,unknown).
1::status(o_f2755e5816ad799ba222,supported); 0::status(o_f2755e5816ad799ba222,refuted); 0::status(o_f2755e5816ad799ba222,unknown).
0::status(o_f294dcaf38a20c58bae0,supported); 1::status(o_f294dcaf38a20c58bae0,refuted); 0::status(o_f294dcaf38a20c58bae0,unknown).
0.98212242126464844::status(o_f2a642294ec7f3c60b72,supported); 0::status(o_f2a642294ec7f3c60b72,refuted); 0.017877578735351562::status(o_f2a642294ec7f3c60b72,unknown).
0.0093486057594418526::status(o_f2b6a31921f12896229f,supported); 0::status(o_f2b6a31921f12896229f,refuted); 0.99065139424055815::status(o_f2b6a31921f12896229f,unknown).
0.0041071532961066259::status(o_f2c4afd91e85998ffc96,supported); 0::status(o_f2c4afd91e85998ffc96,refuted); 0.99589284670389333::status(o_f2c4afd91e85998ffc96,unknown).
0.97475135326385498::status(o_f2f00087cb3df5057797,supported); 0::status(o_f2f00087cb3df5057797,refuted); 0.02524864673614502::status(o_f2f00087cb3df5057797,unknown).
1::status(o_f35e2d21782b6ef9e33d,supported); 0::status(o_f35e2d21782b6ef9e33d,refuted); 0::status(o_f35e2d21782b6ef9e33d,unknown).
1::status(o_f36f01403ef85188afcd,supported); 0::status(o_f36f01403ef85188afcd,refuted); 0::status(o_f36f01403ef85188afcd,unknown).
0::status(o_f37751e793e8f59a1a7e,supported); 0::status(o_f37751e793e8f59a1a7e,refuted); 1::status(o_f37751e793e8f59a1a7e,unknown).
0.0024758365470916033::status(o_f3a4e6277b2299dcfb64,supported); 0::status(o_f3a4e6277b2299dcfb64,refuted); 0.9975241634529084::status(o_f3a4e6277b2299dcfb64,unknown).
1::status(o_f3bbbd2224fcc2109168,supported); 0::status(o_f3bbbd2224fcc2109168,refuted); 0::status(o_f3bbbd2224fcc2109168,unknown).
1::status(o_f3db2c09fcd0e8303ce0,supported); 0::status(o_f3db2c09fcd0e8303ce0,refuted); 0::status(o_f3db2c09fcd0e8303ce0,unknown).
0.56174170970916748::status(o_f40b63cfcd6f2a36a7d3,supported); 0::status(o_f40b63cfcd6f2a36a7d3,refuted); 0.43825829029083252::status(o_f40b63cfcd6f2a36a7d3,unknown).
0::status(o_f40c9e181ee09d46085b,supported); 0::status(o_f40c9e181ee09d46085b,refuted); 1::status(o_f40c9e181ee09d46085b,unknown).
1::status(o_f4258f347ef8cc01a8cf,supported); 0::status(o_f4258f347ef8cc01a8cf,refuted); 0::status(o_f4258f347ef8cc01a8cf,unknown).
1::status(o_f4372f91ef04d28b664e,supported); 0::status(o_f4372f91ef04d28b664e,refuted); 0::status(o_f4372f91ef04d28b664e,unknown).
1.3034778761802781e-06::status(o_f4595235c4e01725f985,supported); 0::status(o_f4595235c4e01725f985,refuted); 0.99999869652212381::status(o_f4595235c4e01725f985,unknown).
0.97427183389663696::status(o_f45d9b14edc801ef3ca4,supported); 0::status(o_f45d9b14edc801ef3ca4,refuted); 0.025728166103363037::status(o_f45d9b14edc801ef3ca4,unknown).
1::status(o_f505abe27a16db3da67f,supported); 0::status(o_f505abe27a16db3da67f,refuted); 0::status(o_f505abe27a16db3da67f,unknown).
0.9814574122428894::status(o_f5347cbd038d23b745cc,supported); 0::status(o_f5347cbd038d23b745cc,refuted); 0.018542587757110596::status(o_f5347cbd038d23b745cc,unknown).
0::status(o_f55894965878e5ba23a0,supported); 0::status(o_f55894965878e5ba23a0,refuted); 1::status(o_f55894965878e5ba23a0,unknown).
0::status(o_f55a72155d860008d9e3,supported); 0::status(o_f55a72155d860008d9e3,refuted); 1::status(o_f55a72155d860008d9e3,unknown).
0::status(o_f5865b8c291700bb1849,supported); 1::status(o_f5865b8c291700bb1849,refuted); 0::status(o_f5865b8c291700bb1849,unknown).
0::status(o_f5a73b432826c391814b,supported); 0::status(o_f5a73b432826c391814b,refuted); 1::status(o_f5a73b432826c391814b,unknown).
1::status(o_f5ba74b7bbe1b31403f3,supported); 0::status(o_f5ba74b7bbe1b31403f3,refuted); 0::status(o_f5ba74b7bbe1b31403f3,unknown).
0::status(o_f5bb319e4baf66ce7931,supported); 1::status(o_f5bb319e4baf66ce7931,refuted); 0::status(o_f5bb319e4baf66ce7931,unknown).
0.0013122661039233208::status(o_f5c2b5754d86991f607d,supported); 0::status(o_f5c2b5754d86991f607d,refuted); 0.99868773389607668::status(o_f5c2b5754d86991f607d,unknown).
0::status(o_f5c891b41d8568660adc,supported); 1::status(o_f5c891b41d8568660adc,refuted); 0::status(o_f5c891b41d8568660adc,unknown).
0.74738532304763794::status(o_f60785b734a97af131f2,supported); 0::status(o_f60785b734a97af131f2,refuted); 0.25261467695236206::status(o_f60785b734a97af131f2,unknown).
1::status(o_f6578062d2347187aae2,supported); 0::status(o_f6578062d2347187aae2,refuted); 0::status(o_f6578062d2347187aae2,unknown).
1::status(o_f66b9bd7b2b5a1bed6da,supported); 0::status(o_f66b9bd7b2b5a1bed6da,refuted); 0::status(o_f66b9bd7b2b5a1bed6da,unknown).
0::status(o_f674d81c34370fc67445,supported); 1::status(o_f674d81c34370fc67445,refuted); 0::status(o_f674d81c34370fc67445,unknown).
0::status(o_f6b5680713d14f00d54b,supported); 1::status(o_f6b5680713d14f00d54b,refuted); 0::status(o_f6b5680713d14f00d54b,unknown).
1::status(o_f6cfbe131fbec241597c,supported); 0::status(o_f6cfbe131fbec241597c,refuted); 0::status(o_f6cfbe131fbec241597c,unknown).
1::status(o_f70988638752e3595b50,supported); 0::status(o_f70988638752e3595b50,refuted); 0::status(o_f70988638752e3595b50,unknown).
0.039551112800836563::status(o_f70b5956a5f24c4664a8,supported); 0::status(o_f70b5956a5f24c4664a8,refuted); 0.96044888719916344::status(o_f70b5956a5f24c4664a8,unknown).
0.0070033296942710876::status(o_f76c195f89af502c7871,supported); 0::status(o_f76c195f89af502c7871,refuted); 0.99299667030572891::status(o_f76c195f89af502c7871,unknown).
0.003883931552991271::status(o_f801481b50e0479853d0,supported); 0::status(o_f801481b50e0479853d0,refuted); 0.99611606844700873::status(o_f801481b50e0479853d0,unknown).
0::status(o_f84156a5d5a8f66c3c3e,supported); 1::status(o_f84156a5d5a8f66c3c3e,refuted); 0::status(o_f84156a5d5a8f66c3c3e,unknown).
0.99365460872650146::status(o_f93c7f0cd7f4abb7e873,supported); 0::status(o_f93c7f0cd7f4abb7e873,refuted); 0.0063453912734985352::status(o_f93c7f0cd7f4abb7e873,unknown).
0.00012811402848456055::status(o_fa1f7b8264a7c9dcd4af,supported); 0::status(o_fa1f7b8264a7c9dcd4af,refuted); 0.99987188597151544::status(o_fa1f7b8264a7c9dcd4af,unknown).
0::status(o_fa3ee0f59b89e93ad1fd,supported); 1::status(o_fa3ee0f59b89e93ad1fd,refuted); 0::status(o_fa3ee0f59b89e93ad1fd,unknown).
0.0018518617143854499::status(o_fa5811094579865e8074,supported); 0::status(o_fa5811094579865e8074,refuted); 0.99814813828561455::status(o_fa5811094579865e8074,unknown).
1::status(o_fa6111fc74cec94a85c5,supported); 0::status(o_fa6111fc74cec94a85c5,refuted); 0::status(o_fa6111fc74cec94a85c5,unknown).
0.003883931552991271::status(o_fab4f075c7f1b8226c11,supported); 0::status(o_fab4f075c7f1b8226c11,refuted); 0.99611606844700873::status(o_fab4f075c7f1b8226c11,unknown).
1::status(o_faf3e5edd3f305743bed,supported); 0::status(o_faf3e5edd3f305743bed,refuted); 0::status(o_faf3e5edd3f305743bed,unknown).
1::status(o_fb44bcf672d083c1c8a4,supported); 0::status(o_fb44bcf672d083c1c8a4,refuted); 0::status(o_fb44bcf672d083c1c8a4,unknown).
0.99470680952072144::status(o_fb62507e37eaa7a827a2,supported); 0::status(o_fb62507e37eaa7a827a2,refuted); 0.0052931904792785645::status(o_fb62507e37eaa7a827a2,unknown).
0.00027939380379393697::status(o_fb6f996261eb642f0e77,supported); 0::status(o_fb6f996261eb642f0e77,refuted); 0.99972060619620606::status(o_fb6f996261eb642f0e77,unknown).
0.00045137316919863224::status(o_fb839559a9ab3ce039a8,supported); 0::status(o_fb839559a9ab3ce039a8,refuted); 0.99954862683080137::status(o_fb839559a9ab3ce039a8,unknown).
7.9832112533040345e-05::status(o_fb87b37ebbb68166c26b,supported); 0::status(o_fb87b37ebbb68166c26b,refuted); 0.99992016788746696::status(o_fb87b37ebbb68166c26b,unknown).
1::status(o_fc2e3b03d27948185b9f,supported); 0::status(o_fc2e3b03d27948185b9f,refuted); 0::status(o_fc2e3b03d27948185b9f,unknown).
0.0060226605273783207::status(o_fc46fe5ed0ad4cac09da,supported); 0::status(o_fc46fe5ed0ad4cac09da,refuted); 0.99397733947262168::status(o_fc46fe5ed0ad4cac09da,unknown).
0.96478104591369629::status(o_fc6ce820061694a002dd,supported); 0::status(o_fc6ce820061694a002dd,refuted); 0.035218954086303711::status(o_fc6ce820061694a002dd,unknown).
1::status(o_fce1fba09a2f21ebfc31,supported); 0::status(o_fce1fba09a2f21ebfc31,refuted); 0::status(o_fce1fba09a2f21ebfc31,unknown).
0.94892531633377075::status(o_fcedf07f04919f51cf20,supported); 0::status(o_fcedf07f04919f51cf20,refuted); 0.051074683666229248::status(o_fcedf07f04919f51cf20,unknown).
0.99385096469335199::status(o_fd04cd794a93d5dc4a3a,supported); 0::status(o_fd04cd794a93d5dc4a3a,refuted); 0.0061490353066480097::status(o_fd04cd794a93d5dc4a3a,unknown).
1::status(o_fd05fe030c73478a4d3f,supported); 0::status(o_fd05fe030c73478a4d3f,refuted); 0::status(o_fd05fe030c73478a4d3f,unknown).
0.98928332328796387::status(o_fd349301f9d4df886c6a,supported); 0::status(o_fd349301f9d4df886c6a,refuted); 0.010716676712036133::status(o_fd349301f9d4df886c6a,unknown).
1::status(o_fd4269e5df22ea945f46,supported); 0::status(o_fd4269e5df22ea945f46,refuted); 0::status(o_fd4269e5df22ea945f46,unknown).
0::status(o_fd8503a220d41cfe89a8,supported); 0::status(o_fd8503a220d41cfe89a8,refuted); 1::status(o_fd8503a220d41cfe89a8,unknown).
0::status(o_fd961e4c997836c7b542,supported); 1::status(o_fd961e4c997836c7b542,refuted); 0::status(o_fd961e4c997836c7b542,unknown).
1::status(o_fe0ecb7e9a367df1c2fc,supported); 0::status(o_fe0ecb7e9a367df1c2fc,refuted); 0::status(o_fe0ecb7e9a367df1c2fc,unknown).
0.99999992580897223::status(o_fe283af840cc2256477d,supported); 0::status(o_fe283af840cc2256477d,refuted); 7.4191027765735384e-08::status(o_fe283af840cc2256477d,unknown).
1::status(o_feb580e2df21a4c31f94,supported); 0::status(o_feb580e2df21a4c31f94,refuted); 0::status(o_feb580e2df21a4c31f94,unknown).
0.998406055936786::status(o_febb76dc35c42a1a2edc,supported); 0::status(o_febb76dc35c42a1a2edc,refuted); 0.0015939440632140034::status(o_febb76dc35c42a1a2edc,unknown).
0.99495738744735718::status(o_ff615e2386f9d54bd884,supported); 0::status(o_ff615e2386f9d54bd884,refuted); 0.0050426125526428223::status(o_ff615e2386f9d54bd884,unknown).
node(n2,supported) :- status(o_490ef53280d58f2d6da2,supported).
node(n2,refuted) :- status(o_490ef53280d58f2d6da2,refuted).
node(n2,unknown) :- status(o_490ef53280d58f2d6da2,unknown).
node(n3,supported) :- status(o_5f66facde37ec916d828,supported).
node(n3,refuted) :- status(o_5f66facde37ec916d828,refuted).
node(n3,unknown) :- status(o_5f66facde37ec916d828,unknown).
node(n4,supported) :- status(o_7d374a4c88e047a22d0e,supported).
node(n4,refuted) :- status(o_7d374a4c88e047a22d0e,refuted).
node(n4,unknown) :- status(o_7d374a4c88e047a22d0e,unknown).
node(n1,supported) :- node(n2,supported), node(n3,supported), node(n4,supported).
node(n1,refuted) :- node(n2,refuted).
node(n1,refuted) :- node(n3,refuted).
node(n1,refuted) :- node(n4,refuted).
node(n1,unknown) :- \+ node(n1,supported), \+ node(n1,refuted).
node(n6,supported) :- status(o_80997c68d9bff581855b,supported).
node(n6,refuted) :- status(o_80997c68d9bff581855b,refuted).
node(n6,unknown) :- status(o_80997c68d9bff581855b,unknown).
node(n7,supported) :- status(o_d16129ee96d26d0d8811,supported).
node(n7,refuted) :- status(o_d16129ee96d26d0d8811,refuted).
node(n7,unknown) :- status(o_d16129ee96d26d0d8811,unknown).
node(n8,supported) :- status(o_f76c195f89af502c7871,supported).
node(n8,refuted) :- status(o_f76c195f89af502c7871,refuted).
node(n8,unknown) :- status(o_f76c195f89af502c7871,unknown).
node(n5,supported) :- node(n6,supported), node(n7,supported), node(n8,supported).
node(n5,refuted) :- node(n6,refuted).
node(n5,refuted) :- node(n7,refuted).
node(n5,refuted) :- node(n8,refuted).
node(n5,unknown) :- \+ node(n5,supported), \+ node(n5,refuted).
node(n9,unknown).
node(n0,refuted) :- node(n1,refuted), node(n5,refuted), node(n9,refuted).
node(n0,supported) :- node(n1,supported).
node(n0,supported) :- node(n5,supported).
node(n0,supported) :- node(n9,supported).
node(n0,unknown) :- \+ node(n0,supported), \+ node(n0,refuted).
verdict(c_9d84cffab500cf08,supported) :- node(n0,supported).
query(verdict(c_9d84cffab500cf08,supported)).
verdict(c_9d84cffab500cf08,refuted) :- node(n0,refuted).
query(verdict(c_9d84cffab500cf08,refuted)).
verdict(c_9d84cffab500cf08,unknown) :- node(n0,unknown).
query(verdict(c_9d84cffab500cf08,unknown)).
node(n12,supported) :- status(o_866ca77c94e5bd29d8b9,supported).
node(n12,refuted) :- status(o_866ca77c94e5bd29d8b9,refuted).
node(n12,unknown) :- status(o_866ca77c94e5bd29d8b9,unknown).
node(n13,supported) :- status(o_27f4960c8a24f9e1d103,supported).
node(n13,refuted) :- status(o_27f4960c8a24f9e1d103,refuted).
node(n13,unknown) :- status(o_27f4960c8a24f9e1d103,unknown).
node(n14,supported) :- status(o_b0408d356564d7e2c71c,supported).
node(n14,refuted) :- status(o_b0408d356564d7e2c71c,refuted).
node(n14,unknown) :- status(o_b0408d356564d7e2c71c,unknown).
node(n15,supported) :- status(o_c4316e32d93f6e5c7633,supported).
node(n15,refuted) :- status(o_c4316e32d93f6e5c7633,refuted).
node(n15,unknown) :- status(o_c4316e32d93f6e5c7633,unknown).
node(n11,supported) :- node(n12,supported), node(n13,supported), node(n14,supported), node(n15,supported).
node(n11,refuted) :- node(n12,refuted).
node(n11,refuted) :- node(n13,refuted).
node(n11,refuted) :- node(n14,refuted).
node(n11,refuted) :- node(n15,refuted).
node(n11,unknown) :- \+ node(n11,supported), \+ node(n11,refuted).
node(n17,supported) :- status(o_5973feba43e4e18ad24d,supported).
node(n17,refuted) :- status(o_5973feba43e4e18ad24d,refuted).
node(n17,unknown) :- status(o_5973feba43e4e18ad24d,unknown).
node(n18,supported) :- status(o_07b2ea52aa9594bb1712,supported).
node(n18,refuted) :- status(o_07b2ea52aa9594bb1712,refuted).
node(n18,unknown) :- status(o_07b2ea52aa9594bb1712,unknown).
node(n19,supported) :- status(o_1a04a8b325d1d98f1eac,supported).
node(n19,refuted) :- status(o_1a04a8b325d1d98f1eac,refuted).
node(n19,unknown) :- status(o_1a04a8b325d1d98f1eac,unknown).
node(n20,supported) :- status(o_1866200c7746e3f97de8,supported).
node(n20,refuted) :- status(o_1866200c7746e3f97de8,refuted).
node(n20,unknown) :- status(o_1866200c7746e3f97de8,unknown).
node(n16,supported) :- node(n17,supported), node(n18,supported), node(n19,supported), node(n20,supported).
node(n16,refuted) :- node(n17,refuted).
node(n16,refuted) :- node(n18,refuted).
node(n16,refuted) :- node(n19,refuted).
node(n16,refuted) :- node(n20,refuted).
node(n16,unknown) :- \+ node(n16,supported), \+ node(n16,refuted).
node(n10,refuted) :- node(n11,refuted), node(n16,refuted), node(n9,refuted).
node(n10,supported) :- node(n11,supported).
node(n10,supported) :- node(n16,supported).
node(n10,supported) :- node(n9,supported).
node(n10,unknown) :- \+ node(n10,supported), \+ node(n10,refuted).
verdict(c_f776f005a61717cc,supported) :- node(n10,supported).
query(verdict(c_f776f005a61717cc,supported)).
verdict(c_f776f005a61717cc,refuted) :- node(n10,refuted).
query(verdict(c_f776f005a61717cc,refuted)).
verdict(c_f776f005a61717cc,unknown) :- node(n10,unknown).
query(verdict(c_f776f005a61717cc,unknown)).
node(n23,supported) :- status(o_bccf58b45c839f9d8af6,supported).
node(n23,refuted) :- status(o_bccf58b45c839f9d8af6,refuted).
node(n23,unknown) :- status(o_bccf58b45c839f9d8af6,unknown).
node(n24,supported) :- status(o_a82e2eefccb305e0a50c,supported).
node(n24,refuted) :- status(o_a82e2eefccb305e0a50c,refuted).
node(n24,unknown) :- status(o_a82e2eefccb305e0a50c,unknown).
node(n25,supported) :- status(o_87364f7431758d00c7dc,supported).
node(n25,refuted) :- status(o_87364f7431758d00c7dc,refuted).
node(n25,unknown) :- status(o_87364f7431758d00c7dc,unknown).
node(n26,supported) :- status(o_7345bcb2241390fb2eb6,supported).
node(n26,refuted) :- status(o_7345bcb2241390fb2eb6,refuted).
node(n26,unknown) :- status(o_7345bcb2241390fb2eb6,unknown).
node(n22,supported) :- node(n23,supported), node(n24,supported), node(n25,supported), node(n26,supported).
node(n22,refuted) :- node(n23,refuted).
node(n22,refuted) :- node(n24,refuted).
node(n22,refuted) :- node(n25,refuted).
node(n22,refuted) :- node(n26,refuted).
node(n22,unknown) :- \+ node(n22,supported), \+ node(n22,refuted).
node(n28,supported) :- status(o_c3e44b697f7e7c60f7da,supported).
node(n28,refuted) :- status(o_c3e44b697f7e7c60f7da,refuted).
node(n28,unknown) :- status(o_c3e44b697f7e7c60f7da,unknown).
node(n29,supported) :- status(o_bd7125dfcf8e194c945d,supported).
node(n29,refuted) :- status(o_bd7125dfcf8e194c945d,refuted).
node(n29,unknown) :- status(o_bd7125dfcf8e194c945d,unknown).
node(n30,supported) :- status(o_397e9df95f4d5e8244a3,supported).
node(n30,refuted) :- status(o_397e9df95f4d5e8244a3,refuted).
node(n30,unknown) :- status(o_397e9df95f4d5e8244a3,unknown).
node(n31,supported) :- status(o_20f35a758df5b34100cd,supported).
node(n31,refuted) :- status(o_20f35a758df5b34100cd,refuted).
node(n31,unknown) :- status(o_20f35a758df5b34100cd,unknown).
node(n27,supported) :- node(n28,supported), node(n29,supported), node(n30,supported), node(n31,supported).
node(n27,refuted) :- node(n28,refuted).
node(n27,refuted) :- node(n29,refuted).
node(n27,refuted) :- node(n30,refuted).
node(n27,refuted) :- node(n31,refuted).
node(n27,unknown) :- \+ node(n27,supported), \+ node(n27,refuted).
node(n21,refuted) :- node(n22,refuted), node(n27,refuted), node(n9,refuted).
node(n21,supported) :- node(n22,supported).
node(n21,supported) :- node(n27,supported).
node(n21,supported) :- node(n9,supported).
node(n21,unknown) :- \+ node(n21,supported), \+ node(n21,refuted).
verdict(c_201cc156361ce470,supported) :- node(n21,supported).
query(verdict(c_201cc156361ce470,supported)).
verdict(c_201cc156361ce470,refuted) :- node(n21,refuted).
query(verdict(c_201cc156361ce470,refuted)).
verdict(c_201cc156361ce470,unknown) :- node(n21,unknown).
query(verdict(c_201cc156361ce470,unknown)).
node(n34,supported) :- status(o_a04da6c69390f0d4bbcb,supported).
node(n34,refuted) :- status(o_a04da6c69390f0d4bbcb,refuted).
node(n34,unknown) :- status(o_a04da6c69390f0d4bbcb,unknown).
node(n35,supported) :- status(o_854b3e417e9d92ae5f68,supported).
node(n35,refuted) :- status(o_854b3e417e9d92ae5f68,refuted).
node(n35,unknown) :- status(o_854b3e417e9d92ae5f68,unknown).
node(n36,supported) :- status(o_0b546e874d9b2546b21f,supported).
node(n36,refuted) :- status(o_0b546e874d9b2546b21f,refuted).
node(n36,unknown) :- status(o_0b546e874d9b2546b21f,unknown).
node(n37,supported) :- status(o_671660fdf2b92841942f,supported).
node(n37,refuted) :- status(o_671660fdf2b92841942f,refuted).
node(n37,unknown) :- status(o_671660fdf2b92841942f,unknown).
node(n33,supported) :- node(n34,supported), node(n35,supported), node(n36,supported), node(n37,supported).
node(n33,refuted) :- node(n34,refuted).
node(n33,refuted) :- node(n35,refuted).
node(n33,refuted) :- node(n36,refuted).
node(n33,refuted) :- node(n37,refuted).
node(n33,unknown) :- \+ node(n33,supported), \+ node(n33,refuted).
node(n39,supported) :- status(o_732b9023d461a41d03c6,supported).
node(n39,refuted) :- status(o_732b9023d461a41d03c6,refuted).
node(n39,unknown) :- status(o_732b9023d461a41d03c6,unknown).
node(n40,supported) :- status(o_7982ce2458f272ecd188,supported).
node(n40,refuted) :- status(o_7982ce2458f272ecd188,refuted).
node(n40,unknown) :- status(o_7982ce2458f272ecd188,unknown).
node(n41,supported) :- status(o_d586da97b57850fbb805,supported).
node(n41,refuted) :- status(o_d586da97b57850fbb805,refuted).
node(n41,unknown) :- status(o_d586da97b57850fbb805,unknown).
node(n42,supported) :- status(o_496d24d30051c7a4036d,supported).
node(n42,refuted) :- status(o_496d24d30051c7a4036d,refuted).
node(n42,unknown) :- status(o_496d24d30051c7a4036d,unknown).
node(n38,supported) :- node(n39,supported), node(n40,supported), node(n41,supported), node(n42,supported).
node(n38,refuted) :- node(n39,refuted).
node(n38,refuted) :- node(n40,refuted).
node(n38,refuted) :- node(n41,refuted).
node(n38,refuted) :- node(n42,refuted).
node(n38,unknown) :- \+ node(n38,supported), \+ node(n38,refuted).
node(n32,refuted) :- node(n33,refuted), node(n38,refuted), node(n9,refuted).
node(n32,supported) :- node(n33,supported).
node(n32,supported) :- node(n38,supported).
node(n32,supported) :- node(n9,supported).
node(n32,unknown) :- \+ node(n32,supported), \+ node(n32,refuted).
verdict(c_19fa5ad0fe6265e5,supported) :- node(n32,supported).
query(verdict(c_19fa5ad0fe6265e5,supported)).
verdict(c_19fa5ad0fe6265e5,refuted) :- node(n32,refuted).
query(verdict(c_19fa5ad0fe6265e5,refuted)).
verdict(c_19fa5ad0fe6265e5,unknown) :- node(n32,unknown).
query(verdict(c_19fa5ad0fe6265e5,unknown)).
node(n45,supported) :- status(o_e02ade9aa00b7050031d,supported).
node(n45,refuted) :- status(o_e02ade9aa00b7050031d,refuted).
node(n45,unknown) :- status(o_e02ade9aa00b7050031d,unknown).
node(n46,supported) :- status(o_069180ef500cda84f7a2,supported).
node(n46,refuted) :- status(o_069180ef500cda84f7a2,refuted).
node(n46,unknown) :- status(o_069180ef500cda84f7a2,unknown).
node(n47,supported) :- status(o_ba0f81438545a3e268a2,supported).
node(n47,refuted) :- status(o_ba0f81438545a3e268a2,refuted).
node(n47,unknown) :- status(o_ba0f81438545a3e268a2,unknown).
node(n44,supported) :- node(n45,supported), node(n46,supported), node(n47,supported).
node(n44,refuted) :- node(n45,refuted).
node(n44,refuted) :- node(n46,refuted).
node(n44,refuted) :- node(n47,refuted).
node(n44,unknown) :- \+ node(n44,supported), \+ node(n44,refuted).
node(n49,supported) :- status(o_b2e33da3a0bcd63b7d0c,supported).
node(n49,refuted) :- status(o_b2e33da3a0bcd63b7d0c,refuted).
node(n49,unknown) :- status(o_b2e33da3a0bcd63b7d0c,unknown).
node(n50,supported) :- status(o_b4fbdf06364a8f7aaf8e,supported).
node(n50,refuted) :- status(o_b4fbdf06364a8f7aaf8e,refuted).
node(n50,unknown) :- status(o_b4fbdf06364a8f7aaf8e,unknown).
node(n51,supported) :- status(o_bc1b954f980f0ad61568,supported).
node(n51,refuted) :- status(o_bc1b954f980f0ad61568,refuted).
node(n51,unknown) :- status(o_bc1b954f980f0ad61568,unknown).
node(n48,supported) :- node(n49,supported), node(n50,supported), node(n51,supported).
node(n48,refuted) :- node(n49,refuted).
node(n48,refuted) :- node(n50,refuted).
node(n48,refuted) :- node(n51,refuted).
node(n48,unknown) :- \+ node(n48,supported), \+ node(n48,refuted).
node(n43,refuted) :- node(n44,refuted), node(n48,refuted), node(n9,refuted).
node(n43,supported) :- node(n44,supported).
node(n43,supported) :- node(n48,supported).
node(n43,supported) :- node(n9,supported).
node(n43,unknown) :- \+ node(n43,supported), \+ node(n43,refuted).
verdict(c_0a3e75ee1c8fc165,supported) :- node(n43,supported).
query(verdict(c_0a3e75ee1c8fc165,supported)).
verdict(c_0a3e75ee1c8fc165,refuted) :- node(n43,refuted).
query(verdict(c_0a3e75ee1c8fc165,refuted)).
verdict(c_0a3e75ee1c8fc165,unknown) :- node(n43,unknown).
query(verdict(c_0a3e75ee1c8fc165,unknown)).
node(n54,supported) :- status(o_832d4281f5d9f7d6a0e7,supported).
node(n54,refuted) :- status(o_832d4281f5d9f7d6a0e7,refuted).
node(n54,unknown) :- status(o_832d4281f5d9f7d6a0e7,unknown).
node(n55,supported) :- status(o_41c1d74249a12b566e87,supported).
node(n55,refuted) :- status(o_41c1d74249a12b566e87,refuted).
node(n55,unknown) :- status(o_41c1d74249a12b566e87,unknown).
node(n56,supported) :- status(o_deec84bed219694e2e98,supported).
node(n56,refuted) :- status(o_deec84bed219694e2e98,refuted).
node(n56,unknown) :- status(o_deec84bed219694e2e98,unknown).
node(n57,supported) :- status(o_b94cede733619fbe38bb,supported).
node(n57,refuted) :- status(o_b94cede733619fbe38bb,refuted).
node(n57,unknown) :- status(o_b94cede733619fbe38bb,unknown).
node(n53,supported) :- node(n54,supported), node(n55,supported), node(n56,supported), node(n57,supported).
node(n53,refuted) :- node(n54,refuted).
node(n53,refuted) :- node(n55,refuted).
node(n53,refuted) :- node(n56,refuted).
node(n53,refuted) :- node(n57,refuted).
node(n53,unknown) :- \+ node(n53,supported), \+ node(n53,refuted).
node(n59,supported) :- status(o_bb9d1af8e22f45a29407,supported).
node(n59,refuted) :- status(o_bb9d1af8e22f45a29407,refuted).
node(n59,unknown) :- status(o_bb9d1af8e22f45a29407,unknown).
node(n60,supported) :- status(o_ace36b8ce48038e09470,supported).
node(n60,refuted) :- status(o_ace36b8ce48038e09470,refuted).
node(n60,unknown) :- status(o_ace36b8ce48038e09470,unknown).
node(n61,supported) :- status(o_5a1236fe6f12752db1c2,supported).
node(n61,refuted) :- status(o_5a1236fe6f12752db1c2,refuted).
node(n61,unknown) :- status(o_5a1236fe6f12752db1c2,unknown).
node(n62,supported) :- status(o_d8e83dca38374d95e217,supported).
node(n62,refuted) :- status(o_d8e83dca38374d95e217,refuted).
node(n62,unknown) :- status(o_d8e83dca38374d95e217,unknown).
node(n58,supported) :- node(n59,supported), node(n60,supported), node(n61,supported), node(n62,supported).
node(n58,refuted) :- node(n59,refuted).
node(n58,refuted) :- node(n60,refuted).
node(n58,refuted) :- node(n61,refuted).
node(n58,refuted) :- node(n62,refuted).
node(n58,unknown) :- \+ node(n58,supported), \+ node(n58,refuted).
node(n52,refuted) :- node(n53,refuted), node(n58,refuted), node(n9,refuted).
node(n52,supported) :- node(n53,supported).
node(n52,supported) :- node(n58,supported).
node(n52,supported) :- node(n9,supported).
node(n52,unknown) :- \+ node(n52,supported), \+ node(n52,refuted).
verdict(c_b10fba717321c32b,supported) :- node(n52,supported).
query(verdict(c_b10fba717321c32b,supported)).
verdict(c_b10fba717321c32b,refuted) :- node(n52,refuted).
query(verdict(c_b10fba717321c32b,refuted)).
verdict(c_b10fba717321c32b,unknown) :- node(n52,unknown).
query(verdict(c_b10fba717321c32b,unknown)).
node(n65,supported) :- status(o_0e54fb7b33e084854261,supported).
node(n65,refuted) :- status(o_0e54fb7b33e084854261,refuted).
node(n65,unknown) :- status(o_0e54fb7b33e084854261,unknown).
node(n66,supported) :- status(o_be5cd74f6a1a6a57b5c3,supported).
node(n66,refuted) :- status(o_be5cd74f6a1a6a57b5c3,refuted).
node(n66,unknown) :- status(o_be5cd74f6a1a6a57b5c3,unknown).
node(n67,supported) :- status(o_06f4c3c63d089185df2e,supported).
node(n67,refuted) :- status(o_06f4c3c63d089185df2e,refuted).
node(n67,unknown) :- status(o_06f4c3c63d089185df2e,unknown).
node(n68,supported) :- status(o_9257b71f618ea745c27b,supported).
node(n68,refuted) :- status(o_9257b71f618ea745c27b,refuted).
node(n68,unknown) :- status(o_9257b71f618ea745c27b,unknown).
node(n64,supported) :- node(n65,supported), node(n66,supported), node(n67,supported), node(n68,supported).
node(n64,refuted) :- node(n65,refuted).
node(n64,refuted) :- node(n66,refuted).
node(n64,refuted) :- node(n67,refuted).
node(n64,refuted) :- node(n68,refuted).
node(n64,unknown) :- \+ node(n64,supported), \+ node(n64,refuted).
node(n70,supported) :- status(o_f6b5680713d14f00d54b,supported).
node(n70,refuted) :- status(o_f6b5680713d14f00d54b,refuted).
node(n70,unknown) :- status(o_f6b5680713d14f00d54b,unknown).
node(n71,supported) :- status(o_b8b2e8834f01a5cc1ace,supported).
node(n71,refuted) :- status(o_b8b2e8834f01a5cc1ace,refuted).
node(n71,unknown) :- status(o_b8b2e8834f01a5cc1ace,unknown).
node(n72,supported) :- status(o_66c995d383d9681601d1,supported).
node(n72,refuted) :- status(o_66c995d383d9681601d1,refuted).
node(n72,unknown) :- status(o_66c995d383d9681601d1,unknown).
node(n73,supported) :- status(o_7abaed82962380f70415,supported).
node(n73,refuted) :- status(o_7abaed82962380f70415,refuted).
node(n73,unknown) :- status(o_7abaed82962380f70415,unknown).
node(n69,supported) :- node(n70,supported), node(n71,supported), node(n72,supported), node(n73,supported).
node(n69,refuted) :- node(n70,refuted).
node(n69,refuted) :- node(n71,refuted).
node(n69,refuted) :- node(n72,refuted).
node(n69,refuted) :- node(n73,refuted).
node(n69,unknown) :- \+ node(n69,supported), \+ node(n69,refuted).
node(n63,refuted) :- node(n64,refuted), node(n69,refuted), node(n9,refuted).
node(n63,supported) :- node(n64,supported).
node(n63,supported) :- node(n69,supported).
node(n63,supported) :- node(n9,supported).
node(n63,unknown) :- \+ node(n63,supported), \+ node(n63,refuted).
verdict(c_f7c381335c7087d1,supported) :- node(n63,supported).
query(verdict(c_f7c381335c7087d1,supported)).
verdict(c_f7c381335c7087d1,refuted) :- node(n63,refuted).
query(verdict(c_f7c381335c7087d1,refuted)).
verdict(c_f7c381335c7087d1,unknown) :- node(n63,unknown).
query(verdict(c_f7c381335c7087d1,unknown)).
node(n76,supported) :- status(o_260047d9904d3b10c1e0,supported).
node(n76,refuted) :- status(o_260047d9904d3b10c1e0,refuted).
node(n76,unknown) :- status(o_260047d9904d3b10c1e0,unknown).
node(n77,supported) :- status(o_9fd52518407235077303,supported).
node(n77,refuted) :- status(o_9fd52518407235077303,refuted).
node(n77,unknown) :- status(o_9fd52518407235077303,unknown).
node(n78,supported) :- status(o_6cab4b6260d998f96f1a,supported).
node(n78,refuted) :- status(o_6cab4b6260d998f96f1a,refuted).
node(n78,unknown) :- status(o_6cab4b6260d998f96f1a,unknown).
node(n79,supported) :- status(o_f3a4e6277b2299dcfb64,supported).
node(n79,refuted) :- status(o_f3a4e6277b2299dcfb64,refuted).
node(n79,unknown) :- status(o_f3a4e6277b2299dcfb64,unknown).
node(n75,supported) :- node(n76,supported), node(n77,supported), node(n78,supported), node(n79,supported).
node(n75,refuted) :- node(n76,refuted).
node(n75,refuted) :- node(n77,refuted).
node(n75,refuted) :- node(n78,refuted).
node(n75,refuted) :- node(n79,refuted).
node(n75,unknown) :- \+ node(n75,supported), \+ node(n75,refuted).
node(n81,supported) :- status(o_d4f367e7b28843fc41ac,supported).
node(n81,refuted) :- status(o_d4f367e7b28843fc41ac,refuted).
node(n81,unknown) :- status(o_d4f367e7b28843fc41ac,unknown).
node(n82,supported) :- status(o_2333c00626ab9fee3a69,supported).
node(n82,refuted) :- status(o_2333c00626ab9fee3a69,refuted).
node(n82,unknown) :- status(o_2333c00626ab9fee3a69,unknown).
node(n83,supported) :- status(o_bf20867ceeb6de9ec404,supported).
node(n83,refuted) :- status(o_bf20867ceeb6de9ec404,refuted).
node(n83,unknown) :- status(o_bf20867ceeb6de9ec404,unknown).
node(n84,supported) :- status(o_aa643bf9a601d7ba55a5,supported).
node(n84,refuted) :- status(o_aa643bf9a601d7ba55a5,refuted).
node(n84,unknown) :- status(o_aa643bf9a601d7ba55a5,unknown).
node(n80,supported) :- node(n81,supported), node(n82,supported), node(n83,supported), node(n84,supported).
node(n80,refuted) :- node(n81,refuted).
node(n80,refuted) :- node(n82,refuted).
node(n80,refuted) :- node(n83,refuted).
node(n80,refuted) :- node(n84,refuted).
node(n80,unknown) :- \+ node(n80,supported), \+ node(n80,refuted).
node(n74,refuted) :- node(n75,refuted), node(n80,refuted), node(n9,refuted).
node(n74,supported) :- node(n75,supported).
node(n74,supported) :- node(n80,supported).
node(n74,supported) :- node(n9,supported).
node(n74,unknown) :- \+ node(n74,supported), \+ node(n74,refuted).
verdict(c_100805cb8366486d,supported) :- node(n74,supported).
query(verdict(c_100805cb8366486d,supported)).
verdict(c_100805cb8366486d,refuted) :- node(n74,refuted).
query(verdict(c_100805cb8366486d,refuted)).
verdict(c_100805cb8366486d,unknown) :- node(n74,unknown).
query(verdict(c_100805cb8366486d,unknown)).
node(n87,supported) :- status(o_a6e1a6ecd88770463656,supported).
node(n87,refuted) :- status(o_a6e1a6ecd88770463656,refuted).
node(n87,unknown) :- status(o_a6e1a6ecd88770463656,unknown).
node(n88,supported) :- status(o_76a760aa6e85790bd89a,supported).
node(n88,refuted) :- status(o_76a760aa6e85790bd89a,refuted).
node(n88,unknown) :- status(o_76a760aa6e85790bd89a,unknown).
node(n89,supported) :- status(o_86e2e8087fd9ca3ac6bd,supported).
node(n89,refuted) :- status(o_86e2e8087fd9ca3ac6bd,refuted).
node(n89,unknown) :- status(o_86e2e8087fd9ca3ac6bd,unknown).
node(n86,supported) :- node(n87,supported), node(n88,supported), node(n89,supported).
node(n86,refuted) :- node(n87,refuted).
node(n86,refuted) :- node(n88,refuted).
node(n86,refuted) :- node(n89,refuted).
node(n86,unknown) :- \+ node(n86,supported), \+ node(n86,refuted).
node(n91,supported) :- status(o_00b90b65f56cb6d43ce2,supported).
node(n91,refuted) :- status(o_00b90b65f56cb6d43ce2,refuted).
node(n91,unknown) :- status(o_00b90b65f56cb6d43ce2,unknown).
node(n92,supported) :- status(o_d7ee36f90df34760f3bc,supported).
node(n92,refuted) :- status(o_d7ee36f90df34760f3bc,refuted).
node(n92,unknown) :- status(o_d7ee36f90df34760f3bc,unknown).
node(n93,supported) :- status(o_792b2cf8b6e91f400b6f,supported).
node(n93,refuted) :- status(o_792b2cf8b6e91f400b6f,refuted).
node(n93,unknown) :- status(o_792b2cf8b6e91f400b6f,unknown).
node(n90,supported) :- node(n91,supported), node(n92,supported), node(n93,supported).
node(n90,refuted) :- node(n91,refuted).
node(n90,refuted) :- node(n92,refuted).
node(n90,refuted) :- node(n93,refuted).
node(n90,unknown) :- \+ node(n90,supported), \+ node(n90,refuted).
node(n85,refuted) :- node(n86,refuted), node(n90,refuted), node(n9,refuted).
node(n85,supported) :- node(n86,supported).
node(n85,supported) :- node(n90,supported).
node(n85,supported) :- node(n9,supported).
node(n85,unknown) :- \+ node(n85,supported), \+ node(n85,refuted).
verdict(c_29d37091acac2055,supported) :- node(n85,supported).
query(verdict(c_29d37091acac2055,supported)).
verdict(c_29d37091acac2055,refuted) :- node(n85,refuted).
query(verdict(c_29d37091acac2055,refuted)).
verdict(c_29d37091acac2055,unknown) :- node(n85,unknown).
query(verdict(c_29d37091acac2055,unknown)).
node(n96,supported) :- status(o_aa163fefe6b532c2d074,supported).
node(n96,refuted) :- status(o_aa163fefe6b532c2d074,refuted).
node(n96,unknown) :- status(o_aa163fefe6b532c2d074,unknown).
node(n97,supported) :- status(o_0f4bf2f9a6f872685f8a,supported).
node(n97,refuted) :- status(o_0f4bf2f9a6f872685f8a,refuted).
node(n97,unknown) :- status(o_0f4bf2f9a6f872685f8a,unknown).
node(n98,supported) :- status(o_d43ce407bdf5929c3ac0,supported).
node(n98,refuted) :- status(o_d43ce407bdf5929c3ac0,refuted).
node(n98,unknown) :- status(o_d43ce407bdf5929c3ac0,unknown).
node(n99,supported) :- status(o_896b375682b147e647e0,supported).
node(n99,refuted) :- status(o_896b375682b147e647e0,refuted).
node(n99,unknown) :- status(o_896b375682b147e647e0,unknown).
node(n95,supported) :- node(n96,supported), node(n97,supported), node(n98,supported), node(n99,supported).
node(n95,refuted) :- node(n96,refuted).
node(n95,refuted) :- node(n97,refuted).
node(n95,refuted) :- node(n98,refuted).
node(n95,refuted) :- node(n99,refuted).
node(n95,unknown) :- \+ node(n95,supported), \+ node(n95,refuted).
node(n101,supported) :- status(o_136a8d00ed287c269195,supported).
node(n101,refuted) :- status(o_136a8d00ed287c269195,refuted).
node(n101,unknown) :- status(o_136a8d00ed287c269195,unknown).
node(n102,supported) :- status(o_262ec9084b304255ff79,supported).
node(n102,refuted) :- status(o_262ec9084b304255ff79,refuted).
node(n102,unknown) :- status(o_262ec9084b304255ff79,unknown).
node(n103,supported) :- status(o_508e6ade2d95e9d7412b,supported).
node(n103,refuted) :- status(o_508e6ade2d95e9d7412b,refuted).
node(n103,unknown) :- status(o_508e6ade2d95e9d7412b,unknown).
node(n104,supported) :- status(o_9dc24887afc5e3fbdb5a,supported).
node(n104,refuted) :- status(o_9dc24887afc5e3fbdb5a,refuted).
node(n104,unknown) :- status(o_9dc24887afc5e3fbdb5a,unknown).
node(n100,supported) :- node(n101,supported), node(n102,supported), node(n103,supported), node(n104,supported).
node(n100,refuted) :- node(n101,refuted).
node(n100,refuted) :- node(n102,refuted).
node(n100,refuted) :- node(n103,refuted).
node(n100,refuted) :- node(n104,refuted).
node(n100,unknown) :- \+ node(n100,supported), \+ node(n100,refuted).
node(n94,refuted) :- node(n95,refuted), node(n100,refuted), node(n9,refuted).
node(n94,supported) :- node(n95,supported).
node(n94,supported) :- node(n100,supported).
node(n94,supported) :- node(n9,supported).
node(n94,unknown) :- \+ node(n94,supported), \+ node(n94,refuted).
verdict(c_a425e029397e3904,supported) :- node(n94,supported).
query(verdict(c_a425e029397e3904,supported)).
verdict(c_a425e029397e3904,refuted) :- node(n94,refuted).
query(verdict(c_a425e029397e3904,refuted)).
verdict(c_a425e029397e3904,unknown) :- node(n94,unknown).
query(verdict(c_a425e029397e3904,unknown)).
node(n107,supported) :- status(o_e10a4621e1cffa26f637,supported).
node(n107,refuted) :- status(o_e10a4621e1cffa26f637,refuted).
node(n107,unknown) :- status(o_e10a4621e1cffa26f637,unknown).
node(n108,supported) :- status(o_75c2dd35d4bf1bc9ee0b,supported).
node(n108,refuted) :- status(o_75c2dd35d4bf1bc9ee0b,refuted).
node(n108,unknown) :- status(o_75c2dd35d4bf1bc9ee0b,unknown).
node(n109,supported) :- status(o_e0559db81481b41187ce,supported).
node(n109,refuted) :- status(o_e0559db81481b41187ce,refuted).
node(n109,unknown) :- status(o_e0559db81481b41187ce,unknown).
node(n110,supported) :- status(o_7eb5eef41233f4ff4705,supported).
node(n110,refuted) :- status(o_7eb5eef41233f4ff4705,refuted).
node(n110,unknown) :- status(o_7eb5eef41233f4ff4705,unknown).
node(n106,supported) :- node(n107,supported), node(n108,supported), node(n109,supported), node(n110,supported).
node(n106,refuted) :- node(n107,refuted).
node(n106,refuted) :- node(n108,refuted).
node(n106,refuted) :- node(n109,refuted).
node(n106,refuted) :- node(n110,refuted).
node(n106,unknown) :- \+ node(n106,supported), \+ node(n106,refuted).
node(n112,supported) :- status(o_06ad9a6e83639f2d964d,supported).
node(n112,refuted) :- status(o_06ad9a6e83639f2d964d,refuted).
node(n112,unknown) :- status(o_06ad9a6e83639f2d964d,unknown).
node(n113,supported) :- status(o_f4258f347ef8cc01a8cf,supported).
node(n113,refuted) :- status(o_f4258f347ef8cc01a8cf,refuted).
node(n113,unknown) :- status(o_f4258f347ef8cc01a8cf,unknown).
node(n114,supported) :- status(o_274385c16b8d1cdbfd94,supported).
node(n114,refuted) :- status(o_274385c16b8d1cdbfd94,refuted).
node(n114,unknown) :- status(o_274385c16b8d1cdbfd94,unknown).
node(n115,supported) :- status(o_41a643ad64732cc58cb1,supported).
node(n115,refuted) :- status(o_41a643ad64732cc58cb1,refuted).
node(n115,unknown) :- status(o_41a643ad64732cc58cb1,unknown).
node(n111,supported) :- node(n112,supported), node(n113,supported), node(n114,supported), node(n115,supported).
node(n111,refuted) :- node(n112,refuted).
node(n111,refuted) :- node(n113,refuted).
node(n111,refuted) :- node(n114,refuted).
node(n111,refuted) :- node(n115,refuted).
node(n111,unknown) :- \+ node(n111,supported), \+ node(n111,refuted).
node(n105,refuted) :- node(n106,refuted), node(n111,refuted), node(n9,refuted).
node(n105,supported) :- node(n106,supported).
node(n105,supported) :- node(n111,supported).
node(n105,supported) :- node(n9,supported).
node(n105,unknown) :- \+ node(n105,supported), \+ node(n105,refuted).
verdict(c_79010ece092eca52,supported) :- node(n105,supported).
query(verdict(c_79010ece092eca52,supported)).
verdict(c_79010ece092eca52,refuted) :- node(n105,refuted).
query(verdict(c_79010ece092eca52,refuted)).
verdict(c_79010ece092eca52,unknown) :- node(n105,unknown).
query(verdict(c_79010ece092eca52,unknown)).
node(n118,supported) :- status(o_fa3ee0f59b89e93ad1fd,supported).
node(n118,refuted) :- status(o_fa3ee0f59b89e93ad1fd,refuted).
node(n118,unknown) :- status(o_fa3ee0f59b89e93ad1fd,unknown).
node(n119,supported) :- status(o_5840ba7170ffe7bea33f,supported).
node(n119,refuted) :- status(o_5840ba7170ffe7bea33f,refuted).
node(n119,unknown) :- status(o_5840ba7170ffe7bea33f,unknown).
node(n120,supported) :- status(o_b68547b46c469ee64c5a,supported).
node(n120,refuted) :- status(o_b68547b46c469ee64c5a,refuted).
node(n120,unknown) :- status(o_b68547b46c469ee64c5a,unknown).
node(n121,supported) :- status(o_988b62899546d0024e81,supported).
node(n121,refuted) :- status(o_988b62899546d0024e81,refuted).
node(n121,unknown) :- status(o_988b62899546d0024e81,unknown).
node(n117,supported) :- node(n118,supported), node(n119,supported), node(n120,supported), node(n121,supported).
node(n117,refuted) :- node(n118,refuted).
node(n117,refuted) :- node(n119,refuted).
node(n117,refuted) :- node(n120,refuted).
node(n117,refuted) :- node(n121,refuted).
node(n117,unknown) :- \+ node(n117,supported), \+ node(n117,refuted).
node(n123,supported) :- status(o_2bdc05e1ba42a0665159,supported).
node(n123,refuted) :- status(o_2bdc05e1ba42a0665159,refuted).
node(n123,unknown) :- status(o_2bdc05e1ba42a0665159,unknown).
node(n124,supported) :- status(o_b971486640a7ca37c1c0,supported).
node(n124,refuted) :- status(o_b971486640a7ca37c1c0,refuted).
node(n124,unknown) :- status(o_b971486640a7ca37c1c0,unknown).
node(n125,supported) :- status(o_4d79be2e37d070251c9c,supported).
node(n125,refuted) :- status(o_4d79be2e37d070251c9c,refuted).
node(n125,unknown) :- status(o_4d79be2e37d070251c9c,unknown).
node(n126,supported) :- status(o_e7d80049e03a284c7b52,supported).
node(n126,refuted) :- status(o_e7d80049e03a284c7b52,refuted).
node(n126,unknown) :- status(o_e7d80049e03a284c7b52,unknown).
node(n122,supported) :- node(n123,supported), node(n124,supported), node(n125,supported), node(n126,supported).
node(n122,refuted) :- node(n123,refuted).
node(n122,refuted) :- node(n124,refuted).
node(n122,refuted) :- node(n125,refuted).
node(n122,refuted) :- node(n126,refuted).
node(n122,unknown) :- \+ node(n122,supported), \+ node(n122,refuted).
node(n116,refuted) :- node(n117,refuted), node(n122,refuted), node(n9,refuted).
node(n116,supported) :- node(n117,supported).
node(n116,supported) :- node(n122,supported).
node(n116,supported) :- node(n9,supported).
node(n116,unknown) :- \+ node(n116,supported), \+ node(n116,refuted).
verdict(c_a64831fccb5518e2,supported) :- node(n116,supported).
query(verdict(c_a64831fccb5518e2,supported)).
verdict(c_a64831fccb5518e2,refuted) :- node(n116,refuted).
query(verdict(c_a64831fccb5518e2,refuted)).
verdict(c_a64831fccb5518e2,unknown) :- node(n116,unknown).
query(verdict(c_a64831fccb5518e2,unknown)).
node(n129,supported) :- status(o_6a3dbb3224d50fbd0399,supported).
node(n129,refuted) :- status(o_6a3dbb3224d50fbd0399,refuted).
node(n129,unknown) :- status(o_6a3dbb3224d50fbd0399,unknown).
node(n130,supported) :- status(o_3f897f04aea540c47168,supported).
node(n130,refuted) :- status(o_3f897f04aea540c47168,refuted).
node(n130,unknown) :- status(o_3f897f04aea540c47168,unknown).
node(n131,supported) :- status(o_af6f3f13d2b02740a0b4,supported).
node(n131,refuted) :- status(o_af6f3f13d2b02740a0b4,refuted).
node(n131,unknown) :- status(o_af6f3f13d2b02740a0b4,unknown).
node(n128,supported) :- node(n129,supported), node(n130,supported), node(n131,supported).
node(n128,refuted) :- node(n129,refuted).
node(n128,refuted) :- node(n130,refuted).
node(n128,refuted) :- node(n131,refuted).
node(n128,unknown) :- \+ node(n128,supported), \+ node(n128,refuted).
node(n133,supported) :- status(o_0ffac10cdd3422dc5139,supported).
node(n133,refuted) :- status(o_0ffac10cdd3422dc5139,refuted).
node(n133,unknown) :- status(o_0ffac10cdd3422dc5139,unknown).
node(n134,supported) :- status(o_6c9b7cdfd35e6570bb4d,supported).
node(n134,refuted) :- status(o_6c9b7cdfd35e6570bb4d,refuted).
node(n134,unknown) :- status(o_6c9b7cdfd35e6570bb4d,unknown).
node(n135,supported) :- status(o_aa0d83e780731937639d,supported).
node(n135,refuted) :- status(o_aa0d83e780731937639d,refuted).
node(n135,unknown) :- status(o_aa0d83e780731937639d,unknown).
node(n132,supported) :- node(n133,supported), node(n134,supported), node(n135,supported).
node(n132,refuted) :- node(n133,refuted).
node(n132,refuted) :- node(n134,refuted).
node(n132,refuted) :- node(n135,refuted).
node(n132,unknown) :- \+ node(n132,supported), \+ node(n132,refuted).
node(n127,refuted) :- node(n128,refuted), node(n132,refuted), node(n9,refuted).
node(n127,supported) :- node(n128,supported).
node(n127,supported) :- node(n132,supported).
node(n127,supported) :- node(n9,supported).
node(n127,unknown) :- \+ node(n127,supported), \+ node(n127,refuted).
verdict(c_4efbc66d92029fe1,supported) :- node(n127,supported).
query(verdict(c_4efbc66d92029fe1,supported)).
verdict(c_4efbc66d92029fe1,refuted) :- node(n127,refuted).
query(verdict(c_4efbc66d92029fe1,refuted)).
verdict(c_4efbc66d92029fe1,unknown) :- node(n127,unknown).
query(verdict(c_4efbc66d92029fe1,unknown)).
node(n138,supported) :- status(o_48a35ab5a30246f980f4,supported).
node(n138,refuted) :- status(o_48a35ab5a30246f980f4,refuted).
node(n138,unknown) :- status(o_48a35ab5a30246f980f4,unknown).
node(n139,supported) :- status(o_8d7a44af42a2224631a7,supported).
node(n139,refuted) :- status(o_8d7a44af42a2224631a7,refuted).
node(n139,unknown) :- status(o_8d7a44af42a2224631a7,unknown).
node(n140,supported) :- status(o_fd8503a220d41cfe89a8,supported).
node(n140,refuted) :- status(o_fd8503a220d41cfe89a8,refuted).
node(n140,unknown) :- status(o_fd8503a220d41cfe89a8,unknown).
node(n141,supported) :- status(o_8ec6851e742b74d587e2,supported).
node(n141,refuted) :- status(o_8ec6851e742b74d587e2,refuted).
node(n141,unknown) :- status(o_8ec6851e742b74d587e2,unknown).
node(n137,supported) :- node(n138,supported), node(n139,supported), node(n140,supported), node(n141,supported).
node(n137,refuted) :- node(n138,refuted).
node(n137,refuted) :- node(n139,refuted).
node(n137,refuted) :- node(n140,refuted).
node(n137,refuted) :- node(n141,refuted).
node(n137,unknown) :- \+ node(n137,supported), \+ node(n137,refuted).
node(n143,supported) :- status(o_b0b6f945a91527326e8d,supported).
node(n143,refuted) :- status(o_b0b6f945a91527326e8d,refuted).
node(n143,unknown) :- status(o_b0b6f945a91527326e8d,unknown).
node(n144,supported) :- status(o_7a08cfce0dfa729f9a0b,supported).
node(n144,refuted) :- status(o_7a08cfce0dfa729f9a0b,refuted).
node(n144,unknown) :- status(o_7a08cfce0dfa729f9a0b,unknown).
node(n145,supported) :- status(o_a2916f5585776c6bf91c,supported).
node(n145,refuted) :- status(o_a2916f5585776c6bf91c,refuted).
node(n145,unknown) :- status(o_a2916f5585776c6bf91c,unknown).
node(n146,supported) :- status(o_072c0accf387c3fb5a40,supported).
node(n146,refuted) :- status(o_072c0accf387c3fb5a40,refuted).
node(n146,unknown) :- status(o_072c0accf387c3fb5a40,unknown).
node(n142,supported) :- node(n143,supported), node(n144,supported), node(n145,supported), node(n146,supported).
node(n142,refuted) :- node(n143,refuted).
node(n142,refuted) :- node(n144,refuted).
node(n142,refuted) :- node(n145,refuted).
node(n142,refuted) :- node(n146,refuted).
node(n142,unknown) :- \+ node(n142,supported), \+ node(n142,refuted).
node(n136,refuted) :- node(n137,refuted), node(n142,refuted), node(n9,refuted).
node(n136,supported) :- node(n137,supported).
node(n136,supported) :- node(n142,supported).
node(n136,supported) :- node(n9,supported).
node(n136,unknown) :- \+ node(n136,supported), \+ node(n136,refuted).
verdict(c_6d138550b32297bd,supported) :- node(n136,supported).
query(verdict(c_6d138550b32297bd,supported)).
verdict(c_6d138550b32297bd,refuted) :- node(n136,refuted).
query(verdict(c_6d138550b32297bd,refuted)).
verdict(c_6d138550b32297bd,unknown) :- node(n136,unknown).
query(verdict(c_6d138550b32297bd,unknown)).
node(n149,supported) :- status(o_11470391c022fda6ef9e,supported).
node(n149,refuted) :- status(o_11470391c022fda6ef9e,refuted).
node(n149,unknown) :- status(o_11470391c022fda6ef9e,unknown).
node(n150,supported) :- status(o_dbdc828e10bb2cb4941d,supported).
node(n150,refuted) :- status(o_dbdc828e10bb2cb4941d,refuted).
node(n150,unknown) :- status(o_dbdc828e10bb2cb4941d,unknown).
node(n151,supported) :- status(o_7bfb86addd2f29ddfad6,supported).
node(n151,refuted) :- status(o_7bfb86addd2f29ddfad6,refuted).
node(n151,unknown) :- status(o_7bfb86addd2f29ddfad6,unknown).
node(n152,supported) :- status(o_0967bea190ae32f9ef6b,supported).
node(n152,refuted) :- status(o_0967bea190ae32f9ef6b,refuted).
node(n152,unknown) :- status(o_0967bea190ae32f9ef6b,unknown).
node(n148,supported) :- node(n149,supported), node(n150,supported), node(n151,supported), node(n152,supported).
node(n148,refuted) :- node(n149,refuted).
node(n148,refuted) :- node(n150,refuted).
node(n148,refuted) :- node(n151,refuted).
node(n148,refuted) :- node(n152,refuted).
node(n148,unknown) :- \+ node(n148,supported), \+ node(n148,refuted).
node(n154,supported) :- status(o_5ab76e66f3f29048017d,supported).
node(n154,refuted) :- status(o_5ab76e66f3f29048017d,refuted).
node(n154,unknown) :- status(o_5ab76e66f3f29048017d,unknown).
node(n155,supported) :- status(o_c43b6953570faf335dd3,supported).
node(n155,refuted) :- status(o_c43b6953570faf335dd3,refuted).
node(n155,unknown) :- status(o_c43b6953570faf335dd3,unknown).
node(n156,supported) :- status(o_30e774446b55977f5196,supported).
node(n156,refuted) :- status(o_30e774446b55977f5196,refuted).
node(n156,unknown) :- status(o_30e774446b55977f5196,unknown).
node(n157,supported) :- status(o_0ae358e24eb201d4d42f,supported).
node(n157,refuted) :- status(o_0ae358e24eb201d4d42f,refuted).
node(n157,unknown) :- status(o_0ae358e24eb201d4d42f,unknown).
node(n153,supported) :- node(n154,supported), node(n155,supported), node(n156,supported), node(n157,supported).
node(n153,refuted) :- node(n154,refuted).
node(n153,refuted) :- node(n155,refuted).
node(n153,refuted) :- node(n156,refuted).
node(n153,refuted) :- node(n157,refuted).
node(n153,unknown) :- \+ node(n153,supported), \+ node(n153,refuted).
node(n147,refuted) :- node(n148,refuted), node(n153,refuted), node(n9,refuted).
node(n147,supported) :- node(n148,supported).
node(n147,supported) :- node(n153,supported).
node(n147,supported) :- node(n9,supported).
node(n147,unknown) :- \+ node(n147,supported), \+ node(n147,refuted).
verdict(c_c896dedd907eba00,supported) :- node(n147,supported).
query(verdict(c_c896dedd907eba00,supported)).
verdict(c_c896dedd907eba00,refuted) :- node(n147,refuted).
query(verdict(c_c896dedd907eba00,refuted)).
verdict(c_c896dedd907eba00,unknown) :- node(n147,unknown).
query(verdict(c_c896dedd907eba00,unknown)).
node(n160,supported) :- status(o_b79fbbc26fd03c457204,supported).
node(n160,refuted) :- status(o_b79fbbc26fd03c457204,refuted).
node(n160,unknown) :- status(o_b79fbbc26fd03c457204,unknown).
node(n161,supported) :- status(o_539c15ca1e91d38bd253,supported).
node(n161,refuted) :- status(o_539c15ca1e91d38bd253,refuted).
node(n161,unknown) :- status(o_539c15ca1e91d38bd253,unknown).
node(n162,supported) :- status(o_e8a174bfdf465539ca5c,supported).
node(n162,refuted) :- status(o_e8a174bfdf465539ca5c,refuted).
node(n162,unknown) :- status(o_e8a174bfdf465539ca5c,unknown).
node(n163,supported) :- status(o_1626d63b45f5b4234a7e,supported).
node(n163,refuted) :- status(o_1626d63b45f5b4234a7e,refuted).
node(n163,unknown) :- status(o_1626d63b45f5b4234a7e,unknown).
node(n159,supported) :- node(n160,supported), node(n161,supported), node(n162,supported), node(n163,supported).
node(n159,refuted) :- node(n160,refuted).
node(n159,refuted) :- node(n161,refuted).
node(n159,refuted) :- node(n162,refuted).
node(n159,refuted) :- node(n163,refuted).
node(n159,unknown) :- \+ node(n159,supported), \+ node(n159,refuted).
node(n165,supported) :- status(o_009d49cbadd2fcfab008,supported).
node(n165,refuted) :- status(o_009d49cbadd2fcfab008,refuted).
node(n165,unknown) :- status(o_009d49cbadd2fcfab008,unknown).
node(n166,supported) :- status(o_13b21106dd45753657d8,supported).
node(n166,refuted) :- status(o_13b21106dd45753657d8,refuted).
node(n166,unknown) :- status(o_13b21106dd45753657d8,unknown).
node(n167,supported) :- status(o_e0723e2d87499700ac65,supported).
node(n167,refuted) :- status(o_e0723e2d87499700ac65,refuted).
node(n167,unknown) :- status(o_e0723e2d87499700ac65,unknown).
node(n168,supported) :- status(o_a68f1505fbb7d6c2354a,supported).
node(n168,refuted) :- status(o_a68f1505fbb7d6c2354a,refuted).
node(n168,unknown) :- status(o_a68f1505fbb7d6c2354a,unknown).
node(n164,supported) :- node(n165,supported), node(n166,supported), node(n167,supported), node(n168,supported).
node(n164,refuted) :- node(n165,refuted).
node(n164,refuted) :- node(n166,refuted).
node(n164,refuted) :- node(n167,refuted).
node(n164,refuted) :- node(n168,refuted).
node(n164,unknown) :- \+ node(n164,supported), \+ node(n164,refuted).
node(n158,refuted) :- node(n159,refuted), node(n164,refuted), node(n9,refuted).
node(n158,supported) :- node(n159,supported).
node(n158,supported) :- node(n164,supported).
node(n158,supported) :- node(n9,supported).
node(n158,unknown) :- \+ node(n158,supported), \+ node(n158,refuted).
verdict(c_8ad3909eb7df87b2,supported) :- node(n158,supported).
query(verdict(c_8ad3909eb7df87b2,supported)).
verdict(c_8ad3909eb7df87b2,refuted) :- node(n158,refuted).
query(verdict(c_8ad3909eb7df87b2,refuted)).
verdict(c_8ad3909eb7df87b2,unknown) :- node(n158,unknown).
query(verdict(c_8ad3909eb7df87b2,unknown)).
node(n171,supported) :- status(o_bbca57fe6fc9400ee7da,supported).
node(n171,refuted) :- status(o_bbca57fe6fc9400ee7da,refuted).
node(n171,unknown) :- status(o_bbca57fe6fc9400ee7da,unknown).
node(n172,supported) :- status(o_4f9c60bd23ab7f0a6910,supported).
node(n172,refuted) :- status(o_4f9c60bd23ab7f0a6910,refuted).
node(n172,unknown) :- status(o_4f9c60bd23ab7f0a6910,unknown).
node(n173,supported) :- status(o_10f6423084d140b6851a,supported).
node(n173,refuted) :- status(o_10f6423084d140b6851a,refuted).
node(n173,unknown) :- status(o_10f6423084d140b6851a,unknown).
node(n170,supported) :- node(n171,supported), node(n172,supported), node(n173,supported).
node(n170,refuted) :- node(n171,refuted).
node(n170,refuted) :- node(n172,refuted).
node(n170,refuted) :- node(n173,refuted).
node(n170,unknown) :- \+ node(n170,supported), \+ node(n170,refuted).
node(n175,supported) :- status(o_d3f35ad4c9e04cc15610,supported).
node(n175,refuted) :- status(o_d3f35ad4c9e04cc15610,refuted).
node(n175,unknown) :- status(o_d3f35ad4c9e04cc15610,unknown).
node(n176,supported) :- status(o_759dfb04f470479d57f9,supported).
node(n176,refuted) :- status(o_759dfb04f470479d57f9,refuted).
node(n176,unknown) :- status(o_759dfb04f470479d57f9,unknown).
node(n177,supported) :- status(o_e83fedbe6cf8292b8c5e,supported).
node(n177,refuted) :- status(o_e83fedbe6cf8292b8c5e,refuted).
node(n177,unknown) :- status(o_e83fedbe6cf8292b8c5e,unknown).
node(n174,supported) :- node(n175,supported), node(n176,supported), node(n177,supported).
node(n174,refuted) :- node(n175,refuted).
node(n174,refuted) :- node(n176,refuted).
node(n174,refuted) :- node(n177,refuted).
node(n174,unknown) :- \+ node(n174,supported), \+ node(n174,refuted).
node(n169,refuted) :- node(n170,refuted), node(n174,refuted), node(n9,refuted).
node(n169,supported) :- node(n170,supported).
node(n169,supported) :- node(n174,supported).
node(n169,supported) :- node(n9,supported).
node(n169,unknown) :- \+ node(n169,supported), \+ node(n169,refuted).
verdict(c_db6de95fb80c21fd,supported) :- node(n169,supported).
query(verdict(c_db6de95fb80c21fd,supported)).
verdict(c_db6de95fb80c21fd,refuted) :- node(n169,refuted).
query(verdict(c_db6de95fb80c21fd,refuted)).
verdict(c_db6de95fb80c21fd,unknown) :- node(n169,unknown).
query(verdict(c_db6de95fb80c21fd,unknown)).
node(n180,supported) :- status(o_f84156a5d5a8f66c3c3e,supported).
node(n180,refuted) :- status(o_f84156a5d5a8f66c3c3e,refuted).
node(n180,unknown) :- status(o_f84156a5d5a8f66c3c3e,unknown).
node(n181,supported) :- status(o_e12caca490a37561e3f8,supported).
node(n181,refuted) :- status(o_e12caca490a37561e3f8,refuted).
node(n181,unknown) :- status(o_e12caca490a37561e3f8,unknown).
node(n182,supported) :- status(o_b84b811cd140173317f4,supported).
node(n182,refuted) :- status(o_b84b811cd140173317f4,refuted).
node(n182,unknown) :- status(o_b84b811cd140173317f4,unknown).
node(n183,supported) :- status(o_b07cdf0907c2424c4b9d,supported).
node(n183,refuted) :- status(o_b07cdf0907c2424c4b9d,refuted).
node(n183,unknown) :- status(o_b07cdf0907c2424c4b9d,unknown).
node(n179,supported) :- node(n180,supported), node(n181,supported), node(n182,supported), node(n183,supported).
node(n179,refuted) :- node(n180,refuted).
node(n179,refuted) :- node(n181,refuted).
node(n179,refuted) :- node(n182,refuted).
node(n179,refuted) :- node(n183,refuted).
node(n179,unknown) :- \+ node(n179,supported), \+ node(n179,refuted).
node(n185,supported) :- status(o_169d8defe6d6ea549462,supported).
node(n185,refuted) :- status(o_169d8defe6d6ea549462,refuted).
node(n185,unknown) :- status(o_169d8defe6d6ea549462,unknown).
node(n186,supported) :- status(o_197e960d7be26ccea89f,supported).
node(n186,refuted) :- status(o_197e960d7be26ccea89f,refuted).
node(n186,unknown) :- status(o_197e960d7be26ccea89f,unknown).
node(n187,supported) :- status(o_9b2931c638b19a8db62d,supported).
node(n187,refuted) :- status(o_9b2931c638b19a8db62d,refuted).
node(n187,unknown) :- status(o_9b2931c638b19a8db62d,unknown).
node(n188,supported) :- status(o_3f1c1dc38318ed0c1db3,supported).
node(n188,refuted) :- status(o_3f1c1dc38318ed0c1db3,refuted).
node(n188,unknown) :- status(o_3f1c1dc38318ed0c1db3,unknown).
node(n184,supported) :- node(n185,supported), node(n186,supported), node(n187,supported), node(n188,supported).
node(n184,refuted) :- node(n185,refuted).
node(n184,refuted) :- node(n186,refuted).
node(n184,refuted) :- node(n187,refuted).
node(n184,refuted) :- node(n188,refuted).
node(n184,unknown) :- \+ node(n184,supported), \+ node(n184,refuted).
node(n178,refuted) :- node(n179,refuted), node(n184,refuted), node(n9,refuted).
node(n178,supported) :- node(n179,supported).
node(n178,supported) :- node(n184,supported).
node(n178,supported) :- node(n9,supported).
node(n178,unknown) :- \+ node(n178,supported), \+ node(n178,refuted).
verdict(c_eb647f5dce01e4a6,supported) :- node(n178,supported).
query(verdict(c_eb647f5dce01e4a6,supported)).
verdict(c_eb647f5dce01e4a6,refuted) :- node(n178,refuted).
query(verdict(c_eb647f5dce01e4a6,refuted)).
verdict(c_eb647f5dce01e4a6,unknown) :- node(n178,unknown).
query(verdict(c_eb647f5dce01e4a6,unknown)).
node(n191,supported) :- status(o_373b79041d1e02c789e5,supported).
node(n191,refuted) :- status(o_373b79041d1e02c789e5,refuted).
node(n191,unknown) :- status(o_373b79041d1e02c789e5,unknown).
node(n192,supported) :- status(o_2fbeee8bbdf0b1866b34,supported).
node(n192,refuted) :- status(o_2fbeee8bbdf0b1866b34,refuted).
node(n192,unknown) :- status(o_2fbeee8bbdf0b1866b34,unknown).
node(n193,supported) :- status(o_cf195a4fd6271292c835,supported).
node(n193,refuted) :- status(o_cf195a4fd6271292c835,refuted).
node(n193,unknown) :- status(o_cf195a4fd6271292c835,unknown).
node(n194,supported) :- status(o_6c3c0334d533d77d12e7,supported).
node(n194,refuted) :- status(o_6c3c0334d533d77d12e7,refuted).
node(n194,unknown) :- status(o_6c3c0334d533d77d12e7,unknown).
node(n190,supported) :- node(n191,supported), node(n192,supported), node(n193,supported), node(n194,supported).
node(n190,refuted) :- node(n191,refuted).
node(n190,refuted) :- node(n192,refuted).
node(n190,refuted) :- node(n193,refuted).
node(n190,refuted) :- node(n194,refuted).
node(n190,unknown) :- \+ node(n190,supported), \+ node(n190,refuted).
node(n196,supported) :- status(o_908a0b3b8aeefa482357,supported).
node(n196,refuted) :- status(o_908a0b3b8aeefa482357,refuted).
node(n196,unknown) :- status(o_908a0b3b8aeefa482357,unknown).
node(n197,supported) :- status(o_c3f6726984127c4a8fcc,supported).
node(n197,refuted) :- status(o_c3f6726984127c4a8fcc,refuted).
node(n197,unknown) :- status(o_c3f6726984127c4a8fcc,unknown).
node(n198,supported) :- status(o_28714fa6c04163a4bb7d,supported).
node(n198,refuted) :- status(o_28714fa6c04163a4bb7d,refuted).
node(n198,unknown) :- status(o_28714fa6c04163a4bb7d,unknown).
node(n199,supported) :- status(o_3dc4f5d3b04099c86248,supported).
node(n199,refuted) :- status(o_3dc4f5d3b04099c86248,refuted).
node(n199,unknown) :- status(o_3dc4f5d3b04099c86248,unknown).
node(n195,supported) :- node(n196,supported), node(n197,supported), node(n198,supported), node(n199,supported).
node(n195,refuted) :- node(n196,refuted).
node(n195,refuted) :- node(n197,refuted).
node(n195,refuted) :- node(n198,refuted).
node(n195,refuted) :- node(n199,refuted).
node(n195,unknown) :- \+ node(n195,supported), \+ node(n195,refuted).
node(n189,refuted) :- node(n190,refuted), node(n195,refuted), node(n9,refuted).
node(n189,supported) :- node(n190,supported).
node(n189,supported) :- node(n195,supported).
node(n189,supported) :- node(n9,supported).
node(n189,unknown) :- \+ node(n189,supported), \+ node(n189,refuted).
verdict(c_24213cc3bd23d861,supported) :- node(n189,supported).
query(verdict(c_24213cc3bd23d861,supported)).
verdict(c_24213cc3bd23d861,refuted) :- node(n189,refuted).
query(verdict(c_24213cc3bd23d861,refuted)).
verdict(c_24213cc3bd23d861,unknown) :- node(n189,unknown).
query(verdict(c_24213cc3bd23d861,unknown)).
node(n202,supported) :- status(o_c1296bcacb89119419e1,supported).
node(n202,refuted) :- status(o_c1296bcacb89119419e1,refuted).
node(n202,unknown) :- status(o_c1296bcacb89119419e1,unknown).
node(n203,supported) :- status(o_406fd817f27182764a11,supported).
node(n203,refuted) :- status(o_406fd817f27182764a11,refuted).
node(n203,unknown) :- status(o_406fd817f27182764a11,unknown).
node(n204,supported) :- status(o_433714aff04c1b243428,supported).
node(n204,refuted) :- status(o_433714aff04c1b243428,refuted).
node(n204,unknown) :- status(o_433714aff04c1b243428,unknown).
node(n205,supported) :- status(o_090484686e13eacb0b74,supported).
node(n205,refuted) :- status(o_090484686e13eacb0b74,refuted).
node(n205,unknown) :- status(o_090484686e13eacb0b74,unknown).
node(n201,supported) :- node(n202,supported), node(n203,supported), node(n204,supported), node(n205,supported).
node(n201,refuted) :- node(n202,refuted).
node(n201,refuted) :- node(n203,refuted).
node(n201,refuted) :- node(n204,refuted).
node(n201,refuted) :- node(n205,refuted).
node(n201,unknown) :- \+ node(n201,supported), \+ node(n201,refuted).
node(n207,supported) :- status(o_3bb89da5cba85a4a649c,supported).
node(n207,refuted) :- status(o_3bb89da5cba85a4a649c,refuted).
node(n207,unknown) :- status(o_3bb89da5cba85a4a649c,unknown).
node(n208,supported) :- status(o_8c4c6c3af076cebc089a,supported).
node(n208,refuted) :- status(o_8c4c6c3af076cebc089a,refuted).
node(n208,unknown) :- status(o_8c4c6c3af076cebc089a,unknown).
node(n209,supported) :- status(o_82bb8cef1faefbf090f8,supported).
node(n209,refuted) :- status(o_82bb8cef1faefbf090f8,refuted).
node(n209,unknown) :- status(o_82bb8cef1faefbf090f8,unknown).
node(n210,supported) :- status(o_e0ec382b413e8f48ebfb,supported).
node(n210,refuted) :- status(o_e0ec382b413e8f48ebfb,refuted).
node(n210,unknown) :- status(o_e0ec382b413e8f48ebfb,unknown).
node(n206,supported) :- node(n207,supported), node(n208,supported), node(n209,supported), node(n210,supported).
node(n206,refuted) :- node(n207,refuted).
node(n206,refuted) :- node(n208,refuted).
node(n206,refuted) :- node(n209,refuted).
node(n206,refuted) :- node(n210,refuted).
node(n206,unknown) :- \+ node(n206,supported), \+ node(n206,refuted).
node(n200,refuted) :- node(n201,refuted), node(n206,refuted), node(n9,refuted).
node(n200,supported) :- node(n201,supported).
node(n200,supported) :- node(n206,supported).
node(n200,supported) :- node(n9,supported).
node(n200,unknown) :- \+ node(n200,supported), \+ node(n200,refuted).
verdict(c_41aaff3a8d92661f,supported) :- node(n200,supported).
query(verdict(c_41aaff3a8d92661f,supported)).
verdict(c_41aaff3a8d92661f,refuted) :- node(n200,refuted).
query(verdict(c_41aaff3a8d92661f,refuted)).
verdict(c_41aaff3a8d92661f,unknown) :- node(n200,unknown).
query(verdict(c_41aaff3a8d92661f,unknown)).
node(n213,supported) :- status(o_2537bc81fa60825e48ef,supported).
node(n213,refuted) :- status(o_2537bc81fa60825e48ef,refuted).
node(n213,unknown) :- status(o_2537bc81fa60825e48ef,unknown).
node(n214,supported) :- status(o_8c7804258e0f125c4c1e,supported).
node(n214,refuted) :- status(o_8c7804258e0f125c4c1e,refuted).
node(n214,unknown) :- status(o_8c7804258e0f125c4c1e,unknown).
node(n215,supported) :- status(o_78d7b93461dbaf4c7d9b,supported).
node(n215,refuted) :- status(o_78d7b93461dbaf4c7d9b,refuted).
node(n215,unknown) :- status(o_78d7b93461dbaf4c7d9b,unknown).
node(n212,supported) :- node(n213,supported), node(n214,supported), node(n215,supported).
node(n212,refuted) :- node(n213,refuted).
node(n212,refuted) :- node(n214,refuted).
node(n212,refuted) :- node(n215,refuted).
node(n212,unknown) :- \+ node(n212,supported), \+ node(n212,refuted).
node(n217,supported) :- status(o_bc52b1e05adc6df4fc37,supported).
node(n217,refuted) :- status(o_bc52b1e05adc6df4fc37,refuted).
node(n217,unknown) :- status(o_bc52b1e05adc6df4fc37,unknown).
node(n218,supported) :- status(o_ae21a5f05f2a2376b95c,supported).
node(n218,refuted) :- status(o_ae21a5f05f2a2376b95c,refuted).
node(n218,unknown) :- status(o_ae21a5f05f2a2376b95c,unknown).
node(n219,supported) :- status(o_e311180f4cb4245f367c,supported).
node(n219,refuted) :- status(o_e311180f4cb4245f367c,refuted).
node(n219,unknown) :- status(o_e311180f4cb4245f367c,unknown).
node(n216,supported) :- node(n217,supported), node(n218,supported), node(n219,supported).
node(n216,refuted) :- node(n217,refuted).
node(n216,refuted) :- node(n218,refuted).
node(n216,refuted) :- node(n219,refuted).
node(n216,unknown) :- \+ node(n216,supported), \+ node(n216,refuted).
node(n211,refuted) :- node(n212,refuted), node(n216,refuted), node(n9,refuted).
node(n211,supported) :- node(n212,supported).
node(n211,supported) :- node(n216,supported).
node(n211,supported) :- node(n9,supported).
node(n211,unknown) :- \+ node(n211,supported), \+ node(n211,refuted).
verdict(c_6de3c14a519d75c9,supported) :- node(n211,supported).
query(verdict(c_6de3c14a519d75c9,supported)).
verdict(c_6de3c14a519d75c9,refuted) :- node(n211,refuted).
query(verdict(c_6de3c14a519d75c9,refuted)).
verdict(c_6de3c14a519d75c9,unknown) :- node(n211,unknown).
query(verdict(c_6de3c14a519d75c9,unknown)).
node(n222,supported) :- status(o_43fa5664f0de7c837ada,supported).
node(n222,refuted) :- status(o_43fa5664f0de7c837ada,refuted).
node(n222,unknown) :- status(o_43fa5664f0de7c837ada,unknown).
node(n223,supported) :- status(o_48667ac47f7a76a5df66,supported).
node(n223,refuted) :- status(o_48667ac47f7a76a5df66,refuted).
node(n223,unknown) :- status(o_48667ac47f7a76a5df66,unknown).
node(n224,supported) :- status(o_f37751e793e8f59a1a7e,supported).
node(n224,refuted) :- status(o_f37751e793e8f59a1a7e,refuted).
node(n224,unknown) :- status(o_f37751e793e8f59a1a7e,unknown).
node(n225,supported) :- status(o_05163a2a5ac9f6ca2f69,supported).
node(n225,refuted) :- status(o_05163a2a5ac9f6ca2f69,refuted).
node(n225,unknown) :- status(o_05163a2a5ac9f6ca2f69,unknown).
node(n221,supported) :- node(n222,supported), node(n223,supported), node(n224,supported), node(n225,supported).
node(n221,refuted) :- node(n222,refuted).
node(n221,refuted) :- node(n223,refuted).
node(n221,refuted) :- node(n224,refuted).
node(n221,refuted) :- node(n225,refuted).
node(n221,unknown) :- \+ node(n221,supported), \+ node(n221,refuted).
node(n227,supported) :- status(o_71223479fab934fa8f1e,supported).
node(n227,refuted) :- status(o_71223479fab934fa8f1e,refuted).
node(n227,unknown) :- status(o_71223479fab934fa8f1e,unknown).
node(n228,supported) :- status(o_fa6111fc74cec94a85c5,supported).
node(n228,refuted) :- status(o_fa6111fc74cec94a85c5,refuted).
node(n228,unknown) :- status(o_fa6111fc74cec94a85c5,unknown).
node(n229,supported) :- status(o_3b070c64f3c2dbd4b295,supported).
node(n229,refuted) :- status(o_3b070c64f3c2dbd4b295,refuted).
node(n229,unknown) :- status(o_3b070c64f3c2dbd4b295,unknown).
node(n230,supported) :- status(o_a7c0efca4fea2b72e333,supported).
node(n230,refuted) :- status(o_a7c0efca4fea2b72e333,refuted).
node(n230,unknown) :- status(o_a7c0efca4fea2b72e333,unknown).
node(n226,supported) :- node(n227,supported), node(n228,supported), node(n229,supported), node(n230,supported).
node(n226,refuted) :- node(n227,refuted).
node(n226,refuted) :- node(n228,refuted).
node(n226,refuted) :- node(n229,refuted).
node(n226,refuted) :- node(n230,refuted).
node(n226,unknown) :- \+ node(n226,supported), \+ node(n226,refuted).
node(n220,refuted) :- node(n221,refuted), node(n226,refuted), node(n9,refuted).
node(n220,supported) :- node(n221,supported).
node(n220,supported) :- node(n226,supported).
node(n220,supported) :- node(n9,supported).
node(n220,unknown) :- \+ node(n220,supported), \+ node(n220,refuted).
verdict(c_abd390b60b5ba0f0,supported) :- node(n220,supported).
query(verdict(c_abd390b60b5ba0f0,supported)).
verdict(c_abd390b60b5ba0f0,refuted) :- node(n220,refuted).
query(verdict(c_abd390b60b5ba0f0,refuted)).
verdict(c_abd390b60b5ba0f0,unknown) :- node(n220,unknown).
query(verdict(c_abd390b60b5ba0f0,unknown)).
node(n233,supported) :- status(o_5015f864a859a41e97fd,supported).
node(n233,refuted) :- status(o_5015f864a859a41e97fd,refuted).
node(n233,unknown) :- status(o_5015f864a859a41e97fd,unknown).
node(n234,supported) :- status(o_b0ddc318951fde3452d6,supported).
node(n234,refuted) :- status(o_b0ddc318951fde3452d6,refuted).
node(n234,unknown) :- status(o_b0ddc318951fde3452d6,unknown).
node(n235,supported) :- status(o_e4ae752067d6a94b6865,supported).
node(n235,refuted) :- status(o_e4ae752067d6a94b6865,refuted).
node(n235,unknown) :- status(o_e4ae752067d6a94b6865,unknown).
node(n236,supported) :- status(o_0949e4af098b9e5ef9e3,supported).
node(n236,refuted) :- status(o_0949e4af098b9e5ef9e3,refuted).
node(n236,unknown) :- status(o_0949e4af098b9e5ef9e3,unknown).
node(n232,supported) :- node(n233,supported), node(n234,supported), node(n235,supported), node(n236,supported).
node(n232,refuted) :- node(n233,refuted).
node(n232,refuted) :- node(n234,refuted).
node(n232,refuted) :- node(n235,refuted).
node(n232,refuted) :- node(n236,refuted).
node(n232,unknown) :- \+ node(n232,supported), \+ node(n232,refuted).
node(n238,supported) :- status(o_2c5b4501c1d1d534c8bf,supported).
node(n238,refuted) :- status(o_2c5b4501c1d1d534c8bf,refuted).
node(n238,unknown) :- status(o_2c5b4501c1d1d534c8bf,unknown).
node(n239,supported) :- status(o_938dae433ba7a991ddfb,supported).
node(n239,refuted) :- status(o_938dae433ba7a991ddfb,refuted).
node(n239,unknown) :- status(o_938dae433ba7a991ddfb,unknown).
node(n240,supported) :- status(o_63d05163b1f8612837cf,supported).
node(n240,refuted) :- status(o_63d05163b1f8612837cf,refuted).
node(n240,unknown) :- status(o_63d05163b1f8612837cf,unknown).
node(n241,supported) :- status(o_22c4d86550342e09bbd6,supported).
node(n241,refuted) :- status(o_22c4d86550342e09bbd6,refuted).
node(n241,unknown) :- status(o_22c4d86550342e09bbd6,unknown).
node(n237,supported) :- node(n238,supported), node(n239,supported), node(n240,supported), node(n241,supported).
node(n237,refuted) :- node(n238,refuted).
node(n237,refuted) :- node(n239,refuted).
node(n237,refuted) :- node(n240,refuted).
node(n237,refuted) :- node(n241,refuted).
node(n237,unknown) :- \+ node(n237,supported), \+ node(n237,refuted).
node(n231,refuted) :- node(n232,refuted), node(n237,refuted), node(n9,refuted).
node(n231,supported) :- node(n232,supported).
node(n231,supported) :- node(n237,supported).
node(n231,supported) :- node(n9,supported).
node(n231,unknown) :- \+ node(n231,supported), \+ node(n231,refuted).
verdict(c_f18ebe40462295d5,supported) :- node(n231,supported).
query(verdict(c_f18ebe40462295d5,supported)).
verdict(c_f18ebe40462295d5,refuted) :- node(n231,refuted).
query(verdict(c_f18ebe40462295d5,refuted)).
verdict(c_f18ebe40462295d5,unknown) :- node(n231,unknown).
query(verdict(c_f18ebe40462295d5,unknown)).
node(n244,supported) :- status(o_3acc44b2c3cb265048e1,supported).
node(n244,refuted) :- status(o_3acc44b2c3cb265048e1,refuted).
node(n244,unknown) :- status(o_3acc44b2c3cb265048e1,unknown).
node(n245,supported) :- status(o_fb44bcf672d083c1c8a4,supported).
node(n245,refuted) :- status(o_fb44bcf672d083c1c8a4,refuted).
node(n245,unknown) :- status(o_fb44bcf672d083c1c8a4,unknown).
node(n246,supported) :- status(o_6b9f73acfcaa60eaad63,supported).
node(n246,refuted) :- status(o_6b9f73acfcaa60eaad63,refuted).
node(n246,unknown) :- status(o_6b9f73acfcaa60eaad63,unknown).
node(n247,supported) :- status(o_934b2eb567bb70b51afc,supported).
node(n247,refuted) :- status(o_934b2eb567bb70b51afc,refuted).
node(n247,unknown) :- status(o_934b2eb567bb70b51afc,unknown).
node(n243,supported) :- node(n244,supported), node(n245,supported), node(n246,supported), node(n247,supported).
node(n243,refuted) :- node(n244,refuted).
node(n243,refuted) :- node(n245,refuted).
node(n243,refuted) :- node(n246,refuted).
node(n243,refuted) :- node(n247,refuted).
node(n243,unknown) :- \+ node(n243,supported), \+ node(n243,refuted).
node(n249,supported) :- status(o_6fa88d6304069b08e4f9,supported).
node(n249,refuted) :- status(o_6fa88d6304069b08e4f9,refuted).
node(n249,unknown) :- status(o_6fa88d6304069b08e4f9,unknown).
node(n250,supported) :- status(o_b9b023505965c4338381,supported).
node(n250,refuted) :- status(o_b9b023505965c4338381,refuted).
node(n250,unknown) :- status(o_b9b023505965c4338381,unknown).
node(n251,supported) :- status(o_157f7f5e4c01bbaa6ce8,supported).
node(n251,refuted) :- status(o_157f7f5e4c01bbaa6ce8,refuted).
node(n251,unknown) :- status(o_157f7f5e4c01bbaa6ce8,unknown).
node(n252,supported) :- status(o_8fae2584a07d960bda4a,supported).
node(n252,refuted) :- status(o_8fae2584a07d960bda4a,refuted).
node(n252,unknown) :- status(o_8fae2584a07d960bda4a,unknown).
node(n248,supported) :- node(n249,supported), node(n250,supported), node(n251,supported), node(n252,supported).
node(n248,refuted) :- node(n249,refuted).
node(n248,refuted) :- node(n250,refuted).
node(n248,refuted) :- node(n251,refuted).
node(n248,refuted) :- node(n252,refuted).
node(n248,unknown) :- \+ node(n248,supported), \+ node(n248,refuted).
node(n242,refuted) :- node(n243,refuted), node(n248,refuted), node(n9,refuted).
node(n242,supported) :- node(n243,supported).
node(n242,supported) :- node(n248,supported).
node(n242,supported) :- node(n9,supported).
node(n242,unknown) :- \+ node(n242,supported), \+ node(n242,refuted).
verdict(c_dbaf25f92c8385ab,supported) :- node(n242,supported).
query(verdict(c_dbaf25f92c8385ab,supported)).
verdict(c_dbaf25f92c8385ab,refuted) :- node(n242,refuted).
query(verdict(c_dbaf25f92c8385ab,refuted)).
verdict(c_dbaf25f92c8385ab,unknown) :- node(n242,unknown).
query(verdict(c_dbaf25f92c8385ab,unknown)).
node(n255,supported) :- status(o_31567d4ac1d16c2acbcc,supported).
node(n255,refuted) :- status(o_31567d4ac1d16c2acbcc,refuted).
node(n255,unknown) :- status(o_31567d4ac1d16c2acbcc,unknown).
node(n256,supported) :- status(o_0422afe210a6634a74b7,supported).
node(n256,refuted) :- status(o_0422afe210a6634a74b7,refuted).
node(n256,unknown) :- status(o_0422afe210a6634a74b7,unknown).
node(n257,supported) :- status(o_cc08480e8dd5fcb35cb9,supported).
node(n257,refuted) :- status(o_cc08480e8dd5fcb35cb9,refuted).
node(n257,unknown) :- status(o_cc08480e8dd5fcb35cb9,unknown).
node(n254,supported) :- node(n255,supported), node(n256,supported), node(n257,supported).
node(n254,refuted) :- node(n255,refuted).
node(n254,refuted) :- node(n256,refuted).
node(n254,refuted) :- node(n257,refuted).
node(n254,unknown) :- \+ node(n254,supported), \+ node(n254,refuted).
node(n259,supported) :- status(o_0cf0db8bf43a64f73a20,supported).
node(n259,refuted) :- status(o_0cf0db8bf43a64f73a20,refuted).
node(n259,unknown) :- status(o_0cf0db8bf43a64f73a20,unknown).
node(n260,supported) :- status(o_9b634c4c1840f2b99d83,supported).
node(n260,refuted) :- status(o_9b634c4c1840f2b99d83,refuted).
node(n260,unknown) :- status(o_9b634c4c1840f2b99d83,unknown).
node(n261,supported) :- status(o_34a13fe03d9f258c5bf4,supported).
node(n261,refuted) :- status(o_34a13fe03d9f258c5bf4,refuted).
node(n261,unknown) :- status(o_34a13fe03d9f258c5bf4,unknown).
node(n258,supported) :- node(n259,supported), node(n260,supported), node(n261,supported).
node(n258,refuted) :- node(n259,refuted).
node(n258,refuted) :- node(n260,refuted).
node(n258,refuted) :- node(n261,refuted).
node(n258,unknown) :- \+ node(n258,supported), \+ node(n258,refuted).
node(n253,refuted) :- node(n254,refuted), node(n258,refuted), node(n9,refuted).
node(n253,supported) :- node(n254,supported).
node(n253,supported) :- node(n258,supported).
node(n253,supported) :- node(n9,supported).
node(n253,unknown) :- \+ node(n253,supported), \+ node(n253,refuted).
verdict(c_176940b60a65b30e,supported) :- node(n253,supported).
query(verdict(c_176940b60a65b30e,supported)).
verdict(c_176940b60a65b30e,refuted) :- node(n253,refuted).
query(verdict(c_176940b60a65b30e,refuted)).
verdict(c_176940b60a65b30e,unknown) :- node(n253,unknown).
query(verdict(c_176940b60a65b30e,unknown)).
node(n264,supported) :- status(o_3bd3676a2fdf6682d156,supported).
node(n264,refuted) :- status(o_3bd3676a2fdf6682d156,refuted).
node(n264,unknown) :- status(o_3bd3676a2fdf6682d156,unknown).
node(n265,supported) :- status(o_7bc5750ddcaacc9f2db8,supported).
node(n265,refuted) :- status(o_7bc5750ddcaacc9f2db8,refuted).
node(n265,unknown) :- status(o_7bc5750ddcaacc9f2db8,unknown).
node(n266,supported) :- status(o_d9da9dc0d7bf3b63e40c,supported).
node(n266,refuted) :- status(o_d9da9dc0d7bf3b63e40c,refuted).
node(n266,unknown) :- status(o_d9da9dc0d7bf3b63e40c,unknown).
node(n267,supported) :- status(o_cbcfe2831bbaeb029e50,supported).
node(n267,refuted) :- status(o_cbcfe2831bbaeb029e50,refuted).
node(n267,unknown) :- status(o_cbcfe2831bbaeb029e50,unknown).
node(n263,supported) :- node(n264,supported), node(n265,supported), node(n266,supported), node(n267,supported).
node(n263,refuted) :- node(n264,refuted).
node(n263,refuted) :- node(n265,refuted).
node(n263,refuted) :- node(n266,refuted).
node(n263,refuted) :- node(n267,refuted).
node(n263,unknown) :- \+ node(n263,supported), \+ node(n263,refuted).
node(n269,supported) :- status(o_950ab3db52d5ef775b24,supported).
node(n269,refuted) :- status(o_950ab3db52d5ef775b24,refuted).
node(n269,unknown) :- status(o_950ab3db52d5ef775b24,unknown).
node(n270,supported) :- status(o_ea7d1a0cda684657a6cb,supported).
node(n270,refuted) :- status(o_ea7d1a0cda684657a6cb,refuted).
node(n270,unknown) :- status(o_ea7d1a0cda684657a6cb,unknown).
node(n271,supported) :- status(o_0f63a1ff8cd74af06bb0,supported).
node(n271,refuted) :- status(o_0f63a1ff8cd74af06bb0,refuted).
node(n271,unknown) :- status(o_0f63a1ff8cd74af06bb0,unknown).
node(n272,supported) :- status(o_deb5c9d493cc179a2442,supported).
node(n272,refuted) :- status(o_deb5c9d493cc179a2442,refuted).
node(n272,unknown) :- status(o_deb5c9d493cc179a2442,unknown).
node(n268,supported) :- node(n269,supported), node(n270,supported), node(n271,supported), node(n272,supported).
node(n268,refuted) :- node(n269,refuted).
node(n268,refuted) :- node(n270,refuted).
node(n268,refuted) :- node(n271,refuted).
node(n268,refuted) :- node(n272,refuted).
node(n268,unknown) :- \+ node(n268,supported), \+ node(n268,refuted).
node(n262,refuted) :- node(n263,refuted), node(n268,refuted), node(n9,refuted).
node(n262,supported) :- node(n263,supported).
node(n262,supported) :- node(n268,supported).
node(n262,supported) :- node(n9,supported).
node(n262,unknown) :- \+ node(n262,supported), \+ node(n262,refuted).
verdict(c_5f794c4aa81a2c79,supported) :- node(n262,supported).
query(verdict(c_5f794c4aa81a2c79,supported)).
verdict(c_5f794c4aa81a2c79,refuted) :- node(n262,refuted).
query(verdict(c_5f794c4aa81a2c79,refuted)).
verdict(c_5f794c4aa81a2c79,unknown) :- node(n262,unknown).
query(verdict(c_5f794c4aa81a2c79,unknown)).
node(n275,supported) :- status(o_96610ad10ccd7cab58fa,supported).
node(n275,refuted) :- status(o_96610ad10ccd7cab58fa,refuted).
node(n275,unknown) :- status(o_96610ad10ccd7cab58fa,unknown).
node(n276,supported) :- status(o_9deb5d47f7de742b093f,supported).
node(n276,refuted) :- status(o_9deb5d47f7de742b093f,refuted).
node(n276,unknown) :- status(o_9deb5d47f7de742b093f,unknown).
node(n277,supported) :- status(o_b177efe5d73ef7370d34,supported).
node(n277,refuted) :- status(o_b177efe5d73ef7370d34,refuted).
node(n277,unknown) :- status(o_b177efe5d73ef7370d34,unknown).
node(n278,supported) :- status(o_995297a727509b361992,supported).
node(n278,refuted) :- status(o_995297a727509b361992,refuted).
node(n278,unknown) :- status(o_995297a727509b361992,unknown).
node(n274,supported) :- node(n275,supported), node(n276,supported), node(n277,supported), node(n278,supported).
node(n274,refuted) :- node(n275,refuted).
node(n274,refuted) :- node(n276,refuted).
node(n274,refuted) :- node(n277,refuted).
node(n274,refuted) :- node(n278,refuted).
node(n274,unknown) :- \+ node(n274,supported), \+ node(n274,refuted).
node(n280,supported) :- status(o_a81e63bffa39e5bebe59,supported).
node(n280,refuted) :- status(o_a81e63bffa39e5bebe59,refuted).
node(n280,unknown) :- status(o_a81e63bffa39e5bebe59,unknown).
node(n281,supported) :- status(o_4321a34bfd7f8b93de5b,supported).
node(n281,refuted) :- status(o_4321a34bfd7f8b93de5b,refuted).
node(n281,unknown) :- status(o_4321a34bfd7f8b93de5b,unknown).
node(n282,supported) :- status(o_7b73227cb18f3be107b9,supported).
node(n282,refuted) :- status(o_7b73227cb18f3be107b9,refuted).
node(n282,unknown) :- status(o_7b73227cb18f3be107b9,unknown).
node(n283,supported) :- status(o_9a9256001c14fd1c907b,supported).
node(n283,refuted) :- status(o_9a9256001c14fd1c907b,refuted).
node(n283,unknown) :- status(o_9a9256001c14fd1c907b,unknown).
node(n279,supported) :- node(n280,supported), node(n281,supported), node(n282,supported), node(n283,supported).
node(n279,refuted) :- node(n280,refuted).
node(n279,refuted) :- node(n281,refuted).
node(n279,refuted) :- node(n282,refuted).
node(n279,refuted) :- node(n283,refuted).
node(n279,unknown) :- \+ node(n279,supported), \+ node(n279,refuted).
node(n273,refuted) :- node(n274,refuted), node(n279,refuted), node(n9,refuted).
node(n273,supported) :- node(n274,supported).
node(n273,supported) :- node(n279,supported).
node(n273,supported) :- node(n9,supported).
node(n273,unknown) :- \+ node(n273,supported), \+ node(n273,refuted).
verdict(c_2e2aaa3f9dee6fa0,supported) :- node(n273,supported).
query(verdict(c_2e2aaa3f9dee6fa0,supported)).
verdict(c_2e2aaa3f9dee6fa0,refuted) :- node(n273,refuted).
query(verdict(c_2e2aaa3f9dee6fa0,refuted)).
verdict(c_2e2aaa3f9dee6fa0,unknown) :- node(n273,unknown).
query(verdict(c_2e2aaa3f9dee6fa0,unknown)).
node(n286,supported) :- status(o_ebdea209f5dc0c12c7cf,supported).
node(n286,refuted) :- status(o_ebdea209f5dc0c12c7cf,refuted).
node(n286,unknown) :- status(o_ebdea209f5dc0c12c7cf,unknown).
node(n287,supported) :- status(o_888009261ebdea9b886b,supported).
node(n287,refuted) :- status(o_888009261ebdea9b886b,refuted).
node(n287,unknown) :- status(o_888009261ebdea9b886b,unknown).
node(n288,supported) :- status(o_37f395cdc7913ab4d4b9,supported).
node(n288,refuted) :- status(o_37f395cdc7913ab4d4b9,refuted).
node(n288,unknown) :- status(o_37f395cdc7913ab4d4b9,unknown).
node(n289,supported) :- status(o_86d282e11ab1fe970e48,supported).
node(n289,refuted) :- status(o_86d282e11ab1fe970e48,refuted).
node(n289,unknown) :- status(o_86d282e11ab1fe970e48,unknown).
node(n285,supported) :- node(n286,supported), node(n287,supported), node(n288,supported), node(n289,supported).
node(n285,refuted) :- node(n286,refuted).
node(n285,refuted) :- node(n287,refuted).
node(n285,refuted) :- node(n288,refuted).
node(n285,refuted) :- node(n289,refuted).
node(n285,unknown) :- \+ node(n285,supported), \+ node(n285,refuted).
node(n291,supported) :- status(o_ac62d38d74013d52ecc1,supported).
node(n291,refuted) :- status(o_ac62d38d74013d52ecc1,refuted).
node(n291,unknown) :- status(o_ac62d38d74013d52ecc1,unknown).
node(n292,supported) :- status(o_37c145cbf544cf442107,supported).
node(n292,refuted) :- status(o_37c145cbf544cf442107,refuted).
node(n292,unknown) :- status(o_37c145cbf544cf442107,unknown).
node(n293,supported) :- status(o_a29d0262e5507f6a6b0b,supported).
node(n293,refuted) :- status(o_a29d0262e5507f6a6b0b,refuted).
node(n293,unknown) :- status(o_a29d0262e5507f6a6b0b,unknown).
node(n294,supported) :- status(o_3d702ce4ee606e6d27c3,supported).
node(n294,refuted) :- status(o_3d702ce4ee606e6d27c3,refuted).
node(n294,unknown) :- status(o_3d702ce4ee606e6d27c3,unknown).
node(n290,supported) :- node(n291,supported), node(n292,supported), node(n293,supported), node(n294,supported).
node(n290,refuted) :- node(n291,refuted).
node(n290,refuted) :- node(n292,refuted).
node(n290,refuted) :- node(n293,refuted).
node(n290,refuted) :- node(n294,refuted).
node(n290,unknown) :- \+ node(n290,supported), \+ node(n290,refuted).
node(n284,refuted) :- node(n285,refuted), node(n290,refuted), node(n9,refuted).
node(n284,supported) :- node(n285,supported).
node(n284,supported) :- node(n290,supported).
node(n284,supported) :- node(n9,supported).
node(n284,unknown) :- \+ node(n284,supported), \+ node(n284,refuted).
verdict(c_e7a4d59a1002496f,supported) :- node(n284,supported).
query(verdict(c_e7a4d59a1002496f,supported)).
verdict(c_e7a4d59a1002496f,refuted) :- node(n284,refuted).
query(verdict(c_e7a4d59a1002496f,refuted)).
verdict(c_e7a4d59a1002496f,unknown) :- node(n284,unknown).
query(verdict(c_e7a4d59a1002496f,unknown)).
node(n297,supported) :- status(o_21319c52721bd786cbe1,supported).
node(n297,refuted) :- status(o_21319c52721bd786cbe1,refuted).
node(n297,unknown) :- status(o_21319c52721bd786cbe1,unknown).
node(n298,supported) :- status(o_981bf9c2fe6e80a1796f,supported).
node(n298,refuted) :- status(o_981bf9c2fe6e80a1796f,refuted).
node(n298,unknown) :- status(o_981bf9c2fe6e80a1796f,unknown).
node(n299,supported) :- status(o_ba7cb1c84f04bd7fd4e0,supported).
node(n299,refuted) :- status(o_ba7cb1c84f04bd7fd4e0,refuted).
node(n299,unknown) :- status(o_ba7cb1c84f04bd7fd4e0,unknown).
node(n296,supported) :- node(n297,supported), node(n298,supported), node(n299,supported).
node(n296,refuted) :- node(n297,refuted).
node(n296,refuted) :- node(n298,refuted).
node(n296,refuted) :- node(n299,refuted).
node(n296,unknown) :- \+ node(n296,supported), \+ node(n296,refuted).
node(n301,supported) :- status(o_2d1ce8e2ab8aca3740fb,supported).
node(n301,refuted) :- status(o_2d1ce8e2ab8aca3740fb,refuted).
node(n301,unknown) :- status(o_2d1ce8e2ab8aca3740fb,unknown).
node(n302,supported) :- status(o_cca21f815b2cedd78f60,supported).
node(n302,refuted) :- status(o_cca21f815b2cedd78f60,refuted).
node(n302,unknown) :- status(o_cca21f815b2cedd78f60,unknown).
node(n303,supported) :- status(o_a4acc59cec322d8f0d07,supported).
node(n303,refuted) :- status(o_a4acc59cec322d8f0d07,refuted).
node(n303,unknown) :- status(o_a4acc59cec322d8f0d07,unknown).
node(n300,supported) :- node(n301,supported), node(n302,supported), node(n303,supported).
node(n300,refuted) :- node(n301,refuted).
node(n300,refuted) :- node(n302,refuted).
node(n300,refuted) :- node(n303,refuted).
node(n300,unknown) :- \+ node(n300,supported), \+ node(n300,refuted).
node(n295,refuted) :- node(n296,refuted), node(n300,refuted), node(n9,refuted).
node(n295,supported) :- node(n296,supported).
node(n295,supported) :- node(n300,supported).
node(n295,supported) :- node(n9,supported).
node(n295,unknown) :- \+ node(n295,supported), \+ node(n295,refuted).
verdict(c_5e896e0cb4db7bb6,supported) :- node(n295,supported).
query(verdict(c_5e896e0cb4db7bb6,supported)).
verdict(c_5e896e0cb4db7bb6,refuted) :- node(n295,refuted).
query(verdict(c_5e896e0cb4db7bb6,refuted)).
verdict(c_5e896e0cb4db7bb6,unknown) :- node(n295,unknown).
query(verdict(c_5e896e0cb4db7bb6,unknown)).
node(n306,supported) :- status(o_74696ff4131f29c347e6,supported).
node(n306,refuted) :- status(o_74696ff4131f29c347e6,refuted).
node(n306,unknown) :- status(o_74696ff4131f29c347e6,unknown).
node(n307,supported) :- status(o_45efc7de7edea09f2ab2,supported).
node(n307,refuted) :- status(o_45efc7de7edea09f2ab2,refuted).
node(n307,unknown) :- status(o_45efc7de7edea09f2ab2,unknown).
node(n308,supported) :- status(o_7393d396786bb9131215,supported).
node(n308,refuted) :- status(o_7393d396786bb9131215,refuted).
node(n308,unknown) :- status(o_7393d396786bb9131215,unknown).
node(n309,supported) :- status(o_a0e633d67f9b887141cf,supported).
node(n309,refuted) :- status(o_a0e633d67f9b887141cf,refuted).
node(n309,unknown) :- status(o_a0e633d67f9b887141cf,unknown).
node(n305,supported) :- node(n306,supported), node(n307,supported), node(n308,supported), node(n309,supported).
node(n305,refuted) :- node(n306,refuted).
node(n305,refuted) :- node(n307,refuted).
node(n305,refuted) :- node(n308,refuted).
node(n305,refuted) :- node(n309,refuted).
node(n305,unknown) :- \+ node(n305,supported), \+ node(n305,refuted).
node(n311,supported) :- status(o_06a51d14cf9be6e26c38,supported).
node(n311,refuted) :- status(o_06a51d14cf9be6e26c38,refuted).
node(n311,unknown) :- status(o_06a51d14cf9be6e26c38,unknown).
node(n312,supported) :- status(o_2417422dca3a36503b0c,supported).
node(n312,refuted) :- status(o_2417422dca3a36503b0c,refuted).
node(n312,unknown) :- status(o_2417422dca3a36503b0c,unknown).
node(n313,supported) :- status(o_d6cb23e45e4607f37c7a,supported).
node(n313,refuted) :- status(o_d6cb23e45e4607f37c7a,refuted).
node(n313,unknown) :- status(o_d6cb23e45e4607f37c7a,unknown).
node(n314,supported) :- status(o_5945df731764dc88f23b,supported).
node(n314,refuted) :- status(o_5945df731764dc88f23b,refuted).
node(n314,unknown) :- status(o_5945df731764dc88f23b,unknown).
node(n310,supported) :- node(n311,supported), node(n312,supported), node(n313,supported), node(n314,supported).
node(n310,refuted) :- node(n311,refuted).
node(n310,refuted) :- node(n312,refuted).
node(n310,refuted) :- node(n313,refuted).
node(n310,refuted) :- node(n314,refuted).
node(n310,unknown) :- \+ node(n310,supported), \+ node(n310,refuted).
node(n304,refuted) :- node(n305,refuted), node(n310,refuted), node(n9,refuted).
node(n304,supported) :- node(n305,supported).
node(n304,supported) :- node(n310,supported).
node(n304,supported) :- node(n9,supported).
node(n304,unknown) :- \+ node(n304,supported), \+ node(n304,refuted).
verdict(c_3c50e7a55cee4c82,supported) :- node(n304,supported).
query(verdict(c_3c50e7a55cee4c82,supported)).
verdict(c_3c50e7a55cee4c82,refuted) :- node(n304,refuted).
query(verdict(c_3c50e7a55cee4c82,refuted)).
verdict(c_3c50e7a55cee4c82,unknown) :- node(n304,unknown).
query(verdict(c_3c50e7a55cee4c82,unknown)).
node(n317,supported) :- status(o_58fd681106e9badb688d,supported).
node(n317,refuted) :- status(o_58fd681106e9badb688d,refuted).
node(n317,unknown) :- status(o_58fd681106e9badb688d,unknown).
node(n318,supported) :- status(o_6e870bc4d9ee09ca1db0,supported).
node(n318,refuted) :- status(o_6e870bc4d9ee09ca1db0,refuted).
node(n318,unknown) :- status(o_6e870bc4d9ee09ca1db0,unknown).
node(n319,supported) :- status(o_ee02416d60c830d0ed3b,supported).
node(n319,refuted) :- status(o_ee02416d60c830d0ed3b,refuted).
node(n319,unknown) :- status(o_ee02416d60c830d0ed3b,unknown).
node(n320,supported) :- status(o_84bb915a197998ce35c6,supported).
node(n320,refuted) :- status(o_84bb915a197998ce35c6,refuted).
node(n320,unknown) :- status(o_84bb915a197998ce35c6,unknown).
node(n316,supported) :- node(n317,supported), node(n318,supported), node(n319,supported), node(n320,supported).
node(n316,refuted) :- node(n317,refuted).
node(n316,refuted) :- node(n318,refuted).
node(n316,refuted) :- node(n319,refuted).
node(n316,refuted) :- node(n320,refuted).
node(n316,unknown) :- \+ node(n316,supported), \+ node(n316,refuted).
node(n322,supported) :- status(o_5d8a9b39d28dbd858578,supported).
node(n322,refuted) :- status(o_5d8a9b39d28dbd858578,refuted).
node(n322,unknown) :- status(o_5d8a9b39d28dbd858578,unknown).
node(n323,supported) :- status(o_53d0c0bb94fdabc73b99,supported).
node(n323,refuted) :- status(o_53d0c0bb94fdabc73b99,refuted).
node(n323,unknown) :- status(o_53d0c0bb94fdabc73b99,unknown).
node(n324,supported) :- status(o_c33542d0176b31519e79,supported).
node(n324,refuted) :- status(o_c33542d0176b31519e79,refuted).
node(n324,unknown) :- status(o_c33542d0176b31519e79,unknown).
node(n325,supported) :- status(o_e534007adfa10727b692,supported).
node(n325,refuted) :- status(o_e534007adfa10727b692,refuted).
node(n325,unknown) :- status(o_e534007adfa10727b692,unknown).
node(n321,supported) :- node(n322,supported), node(n323,supported), node(n324,supported), node(n325,supported).
node(n321,refuted) :- node(n322,refuted).
node(n321,refuted) :- node(n323,refuted).
node(n321,refuted) :- node(n324,refuted).
node(n321,refuted) :- node(n325,refuted).
node(n321,unknown) :- \+ node(n321,supported), \+ node(n321,refuted).
node(n315,refuted) :- node(n316,refuted), node(n321,refuted), node(n9,refuted).
node(n315,supported) :- node(n316,supported).
node(n315,supported) :- node(n321,supported).
node(n315,supported) :- node(n9,supported).
node(n315,unknown) :- \+ node(n315,supported), \+ node(n315,refuted).
verdict(c_cafe0c740ca4e509,supported) :- node(n315,supported).
query(verdict(c_cafe0c740ca4e509,supported)).
verdict(c_cafe0c740ca4e509,refuted) :- node(n315,refuted).
query(verdict(c_cafe0c740ca4e509,refuted)).
verdict(c_cafe0c740ca4e509,unknown) :- node(n315,unknown).
query(verdict(c_cafe0c740ca4e509,unknown)).
node(n328,supported) :- status(o_79fcb94bd0a0ded259bb,supported).
node(n328,refuted) :- status(o_79fcb94bd0a0ded259bb,refuted).
node(n328,unknown) :- status(o_79fcb94bd0a0ded259bb,unknown).
node(n329,supported) :- status(o_b603883e777bf32b3162,supported).
node(n329,refuted) :- status(o_b603883e777bf32b3162,refuted).
node(n329,unknown) :- status(o_b603883e777bf32b3162,unknown).
node(n330,supported) :- status(o_b57558fca6fb9aacb2ea,supported).
node(n330,refuted) :- status(o_b57558fca6fb9aacb2ea,refuted).
node(n330,unknown) :- status(o_b57558fca6fb9aacb2ea,unknown).
node(n331,supported) :- status(o_3f702530c791396ba344,supported).
node(n331,refuted) :- status(o_3f702530c791396ba344,refuted).
node(n331,unknown) :- status(o_3f702530c791396ba344,unknown).
node(n327,supported) :- node(n328,supported), node(n329,supported), node(n330,supported), node(n331,supported).
node(n327,refuted) :- node(n328,refuted).
node(n327,refuted) :- node(n329,refuted).
node(n327,refuted) :- node(n330,refuted).
node(n327,refuted) :- node(n331,refuted).
node(n327,unknown) :- \+ node(n327,supported), \+ node(n327,refuted).
node(n333,supported) :- status(o_af1b6361179d0b1dc51d,supported).
node(n333,refuted) :- status(o_af1b6361179d0b1dc51d,refuted).
node(n333,unknown) :- status(o_af1b6361179d0b1dc51d,unknown).
node(n334,supported) :- status(o_e420dddc066851ac89e2,supported).
node(n334,refuted) :- status(o_e420dddc066851ac89e2,refuted).
node(n334,unknown) :- status(o_e420dddc066851ac89e2,unknown).
node(n335,supported) :- status(o_46bb713f6a111fe28fde,supported).
node(n335,refuted) :- status(o_46bb713f6a111fe28fde,refuted).
node(n335,unknown) :- status(o_46bb713f6a111fe28fde,unknown).
node(n336,supported) :- status(o_bfaccc34b94dc00bdbd0,supported).
node(n336,refuted) :- status(o_bfaccc34b94dc00bdbd0,refuted).
node(n336,unknown) :- status(o_bfaccc34b94dc00bdbd0,unknown).
node(n332,supported) :- node(n333,supported), node(n334,supported), node(n335,supported), node(n336,supported).
node(n332,refuted) :- node(n333,refuted).
node(n332,refuted) :- node(n334,refuted).
node(n332,refuted) :- node(n335,refuted).
node(n332,refuted) :- node(n336,refuted).
node(n332,unknown) :- \+ node(n332,supported), \+ node(n332,refuted).
node(n326,refuted) :- node(n327,refuted), node(n332,refuted), node(n9,refuted).
node(n326,supported) :- node(n327,supported).
node(n326,supported) :- node(n332,supported).
node(n326,supported) :- node(n9,supported).
node(n326,unknown) :- \+ node(n326,supported), \+ node(n326,refuted).
verdict(c_fd4391e321d98412,supported) :- node(n326,supported).
query(verdict(c_fd4391e321d98412,supported)).
verdict(c_fd4391e321d98412,refuted) :- node(n326,refuted).
query(verdict(c_fd4391e321d98412,refuted)).
verdict(c_fd4391e321d98412,unknown) :- node(n326,unknown).
query(verdict(c_fd4391e321d98412,unknown)).
node(n339,supported) :- status(o_73ef785df814b2d1b8bf,supported).
node(n339,refuted) :- status(o_73ef785df814b2d1b8bf,refuted).
node(n339,unknown) :- status(o_73ef785df814b2d1b8bf,unknown).
node(n340,supported) :- status(o_2a06088b54f04f5b4d88,supported).
node(n340,refuted) :- status(o_2a06088b54f04f5b4d88,refuted).
node(n340,unknown) :- status(o_2a06088b54f04f5b4d88,unknown).
node(n341,supported) :- status(o_98ea1b9e3abe7a34709c,supported).
node(n341,refuted) :- status(o_98ea1b9e3abe7a34709c,refuted).
node(n341,unknown) :- status(o_98ea1b9e3abe7a34709c,unknown).
node(n338,supported) :- node(n339,supported), node(n340,supported), node(n341,supported).
node(n338,refuted) :- node(n339,refuted).
node(n338,refuted) :- node(n340,refuted).
node(n338,refuted) :- node(n341,refuted).
node(n338,unknown) :- \+ node(n338,supported), \+ node(n338,refuted).
node(n343,supported) :- status(o_21b74d969b09ec042152,supported).
node(n343,refuted) :- status(o_21b74d969b09ec042152,refuted).
node(n343,unknown) :- status(o_21b74d969b09ec042152,unknown).
node(n344,supported) :- status(o_aea4ccc8f3c98224500e,supported).
node(n344,refuted) :- status(o_aea4ccc8f3c98224500e,refuted).
node(n344,unknown) :- status(o_aea4ccc8f3c98224500e,unknown).
node(n345,supported) :- status(o_480a8d666ac3e7e389a1,supported).
node(n345,refuted) :- status(o_480a8d666ac3e7e389a1,refuted).
node(n345,unknown) :- status(o_480a8d666ac3e7e389a1,unknown).
node(n342,supported) :- node(n343,supported), node(n344,supported), node(n345,supported).
node(n342,refuted) :- node(n343,refuted).
node(n342,refuted) :- node(n344,refuted).
node(n342,refuted) :- node(n345,refuted).
node(n342,unknown) :- \+ node(n342,supported), \+ node(n342,refuted).
node(n337,refuted) :- node(n338,refuted), node(n342,refuted), node(n9,refuted).
node(n337,supported) :- node(n338,supported).
node(n337,supported) :- node(n342,supported).
node(n337,supported) :- node(n9,supported).
node(n337,unknown) :- \+ node(n337,supported), \+ node(n337,refuted).
verdict(c_34620de2b0344aaa,supported) :- node(n337,supported).
query(verdict(c_34620de2b0344aaa,supported)).
verdict(c_34620de2b0344aaa,refuted) :- node(n337,refuted).
query(verdict(c_34620de2b0344aaa,refuted)).
verdict(c_34620de2b0344aaa,unknown) :- node(n337,unknown).
query(verdict(c_34620de2b0344aaa,unknown)).
node(n348,supported) :- status(o_402164050b3a66f31e31,supported).
node(n348,refuted) :- status(o_402164050b3a66f31e31,refuted).
node(n348,unknown) :- status(o_402164050b3a66f31e31,unknown).
node(n349,supported) :- status(o_3dfc7c3b00c967610382,supported).
node(n349,refuted) :- status(o_3dfc7c3b00c967610382,refuted).
node(n349,unknown) :- status(o_3dfc7c3b00c967610382,unknown).
node(n350,supported) :- status(o_cf8da1392540c00750e8,supported).
node(n350,refuted) :- status(o_cf8da1392540c00750e8,refuted).
node(n350,unknown) :- status(o_cf8da1392540c00750e8,unknown).
node(n351,supported) :- status(o_66757b15f877295bf6e6,supported).
node(n351,refuted) :- status(o_66757b15f877295bf6e6,refuted).
node(n351,unknown) :- status(o_66757b15f877295bf6e6,unknown).
node(n347,supported) :- node(n348,supported), node(n349,supported), node(n350,supported), node(n351,supported).
node(n347,refuted) :- node(n348,refuted).
node(n347,refuted) :- node(n349,refuted).
node(n347,refuted) :- node(n350,refuted).
node(n347,refuted) :- node(n351,refuted).
node(n347,unknown) :- \+ node(n347,supported), \+ node(n347,refuted).
node(n353,supported) :- status(o_41fb82ecbc37247ea18b,supported).
node(n353,refuted) :- status(o_41fb82ecbc37247ea18b,refuted).
node(n353,unknown) :- status(o_41fb82ecbc37247ea18b,unknown).
node(n354,supported) :- status(o_15a0e9413475ec5d02f5,supported).
node(n354,refuted) :- status(o_15a0e9413475ec5d02f5,refuted).
node(n354,unknown) :- status(o_15a0e9413475ec5d02f5,unknown).
node(n355,supported) :- status(o_c98f4a373f3d46187e36,supported).
node(n355,refuted) :- status(o_c98f4a373f3d46187e36,refuted).
node(n355,unknown) :- status(o_c98f4a373f3d46187e36,unknown).
node(n356,supported) :- status(o_aeeac1560ce333f98c30,supported).
node(n356,refuted) :- status(o_aeeac1560ce333f98c30,refuted).
node(n356,unknown) :- status(o_aeeac1560ce333f98c30,unknown).
node(n352,supported) :- node(n353,supported), node(n354,supported), node(n355,supported), node(n356,supported).
node(n352,refuted) :- node(n353,refuted).
node(n352,refuted) :- node(n354,refuted).
node(n352,refuted) :- node(n355,refuted).
node(n352,refuted) :- node(n356,refuted).
node(n352,unknown) :- \+ node(n352,supported), \+ node(n352,refuted).
node(n346,refuted) :- node(n347,refuted), node(n352,refuted), node(n9,refuted).
node(n346,supported) :- node(n347,supported).
node(n346,supported) :- node(n352,supported).
node(n346,supported) :- node(n9,supported).
node(n346,unknown) :- \+ node(n346,supported), \+ node(n346,refuted).
verdict(c_da5fccd05faedc74,supported) :- node(n346,supported).
query(verdict(c_da5fccd05faedc74,supported)).
verdict(c_da5fccd05faedc74,refuted) :- node(n346,refuted).
query(verdict(c_da5fccd05faedc74,refuted)).
verdict(c_da5fccd05faedc74,unknown) :- node(n346,unknown).
query(verdict(c_da5fccd05faedc74,unknown)).
node(n359,supported) :- status(o_355a19fba1ac50c245ba,supported).
node(n359,refuted) :- status(o_355a19fba1ac50c245ba,refuted).
node(n359,unknown) :- status(o_355a19fba1ac50c245ba,unknown).
node(n360,supported) :- status(o_482a1c312f6236103139,supported).
node(n360,refuted) :- status(o_482a1c312f6236103139,refuted).
node(n360,unknown) :- status(o_482a1c312f6236103139,unknown).
node(n361,supported) :- status(o_4b83f0a887414c79c4db,supported).
node(n361,refuted) :- status(o_4b83f0a887414c79c4db,refuted).
node(n361,unknown) :- status(o_4b83f0a887414c79c4db,unknown).
node(n362,supported) :- status(o_04d9a716b3f3eef7ef6a,supported).
node(n362,refuted) :- status(o_04d9a716b3f3eef7ef6a,refuted).
node(n362,unknown) :- status(o_04d9a716b3f3eef7ef6a,unknown).
node(n358,supported) :- node(n359,supported), node(n360,supported), node(n361,supported), node(n362,supported).
node(n358,refuted) :- node(n359,refuted).
node(n358,refuted) :- node(n360,refuted).
node(n358,refuted) :- node(n361,refuted).
node(n358,refuted) :- node(n362,refuted).
node(n358,unknown) :- \+ node(n358,supported), \+ node(n358,refuted).
node(n364,supported) :- status(o_c8dbd7186fc89ca3848e,supported).
node(n364,refuted) :- status(o_c8dbd7186fc89ca3848e,refuted).
node(n364,unknown) :- status(o_c8dbd7186fc89ca3848e,unknown).
node(n365,supported) :- status(o_893a10a134dba7b21d76,supported).
node(n365,refuted) :- status(o_893a10a134dba7b21d76,refuted).
node(n365,unknown) :- status(o_893a10a134dba7b21d76,unknown).
node(n366,supported) :- status(o_e4708847e48f06ef8504,supported).
node(n366,refuted) :- status(o_e4708847e48f06ef8504,refuted).
node(n366,unknown) :- status(o_e4708847e48f06ef8504,unknown).
node(n367,supported) :- status(o_e2f997f7bf8deaa1bbaa,supported).
node(n367,refuted) :- status(o_e2f997f7bf8deaa1bbaa,refuted).
node(n367,unknown) :- status(o_e2f997f7bf8deaa1bbaa,unknown).
node(n363,supported) :- node(n364,supported), node(n365,supported), node(n366,supported), node(n367,supported).
node(n363,refuted) :- node(n364,refuted).
node(n363,refuted) :- node(n365,refuted).
node(n363,refuted) :- node(n366,refuted).
node(n363,refuted) :- node(n367,refuted).
node(n363,unknown) :- \+ node(n363,supported), \+ node(n363,refuted).
node(n357,refuted) :- node(n358,refuted), node(n363,refuted), node(n9,refuted).
node(n357,supported) :- node(n358,supported).
node(n357,supported) :- node(n363,supported).
node(n357,supported) :- node(n9,supported).
node(n357,unknown) :- \+ node(n357,supported), \+ node(n357,refuted).
verdict(c_667aa17d5022c6d0,supported) :- node(n357,supported).
query(verdict(c_667aa17d5022c6d0,supported)).
verdict(c_667aa17d5022c6d0,refuted) :- node(n357,refuted).
query(verdict(c_667aa17d5022c6d0,refuted)).
verdict(c_667aa17d5022c6d0,unknown) :- node(n357,unknown).
query(verdict(c_667aa17d5022c6d0,unknown)).
node(n370,supported) :- status(o_880d3171f85379b20948,supported).
node(n370,refuted) :- status(o_880d3171f85379b20948,refuted).
node(n370,unknown) :- status(o_880d3171f85379b20948,unknown).
node(n371,supported) :- status(o_03017c3ce36bb07ecc71,supported).
node(n371,refuted) :- status(o_03017c3ce36bb07ecc71,refuted).
node(n371,unknown) :- status(o_03017c3ce36bb07ecc71,unknown).
node(n372,supported) :- status(o_fe283af840cc2256477d,supported).
node(n372,refuted) :- status(o_fe283af840cc2256477d,refuted).
node(n372,unknown) :- status(o_fe283af840cc2256477d,unknown).
node(n373,supported) :- status(o_cde41612a89d28849a62,supported).
node(n373,refuted) :- status(o_cde41612a89d28849a62,refuted).
node(n373,unknown) :- status(o_cde41612a89d28849a62,unknown).
node(n369,supported) :- node(n370,supported), node(n371,supported), node(n372,supported), node(n373,supported).
node(n369,refuted) :- node(n370,refuted).
node(n369,refuted) :- node(n371,refuted).
node(n369,refuted) :- node(n372,refuted).
node(n369,refuted) :- node(n373,refuted).
node(n369,unknown) :- \+ node(n369,supported), \+ node(n369,refuted).
node(n375,supported) :- status(o_0359969dc6f1835db0e0,supported).
node(n375,refuted) :- status(o_0359969dc6f1835db0e0,refuted).
node(n375,unknown) :- status(o_0359969dc6f1835db0e0,unknown).
node(n376,supported) :- status(o_5e95ebe9d48d81287a2d,supported).
node(n376,refuted) :- status(o_5e95ebe9d48d81287a2d,refuted).
node(n376,unknown) :- status(o_5e95ebe9d48d81287a2d,unknown).
node(n377,supported) :- status(o_fd04cd794a93d5dc4a3a,supported).
node(n377,refuted) :- status(o_fd04cd794a93d5dc4a3a,refuted).
node(n377,unknown) :- status(o_fd04cd794a93d5dc4a3a,unknown).
node(n378,supported) :- status(o_b904668ab147a52228e4,supported).
node(n378,refuted) :- status(o_b904668ab147a52228e4,refuted).
node(n378,unknown) :- status(o_b904668ab147a52228e4,unknown).
node(n374,supported) :- node(n375,supported), node(n376,supported), node(n377,supported), node(n378,supported).
node(n374,refuted) :- node(n375,refuted).
node(n374,refuted) :- node(n376,refuted).
node(n374,refuted) :- node(n377,refuted).
node(n374,refuted) :- node(n378,refuted).
node(n374,unknown) :- \+ node(n374,supported), \+ node(n374,refuted).
node(n368,refuted) :- node(n369,refuted), node(n374,refuted), node(n9,refuted).
node(n368,supported) :- node(n369,supported).
node(n368,supported) :- node(n374,supported).
node(n368,supported) :- node(n9,supported).
node(n368,unknown) :- \+ node(n368,supported), \+ node(n368,refuted).
verdict(c_3658dfd6d36373b7,supported) :- node(n368,supported).
query(verdict(c_3658dfd6d36373b7,supported)).
verdict(c_3658dfd6d36373b7,refuted) :- node(n368,refuted).
query(verdict(c_3658dfd6d36373b7,refuted)).
verdict(c_3658dfd6d36373b7,unknown) :- node(n368,unknown).
query(verdict(c_3658dfd6d36373b7,unknown)).
node(n381,supported) :- status(o_32716e84ac91136e718b,supported).
node(n381,refuted) :- status(o_32716e84ac91136e718b,refuted).
node(n381,unknown) :- status(o_32716e84ac91136e718b,unknown).
node(n382,supported) :- status(o_29fd0428224f8f56e425,supported).
node(n382,refuted) :- status(o_29fd0428224f8f56e425,refuted).
node(n382,unknown) :- status(o_29fd0428224f8f56e425,unknown).
node(n383,supported) :- status(o_54ff6cad6b6f0a38cfb4,supported).
node(n383,refuted) :- status(o_54ff6cad6b6f0a38cfb4,refuted).
node(n383,unknown) :- status(o_54ff6cad6b6f0a38cfb4,unknown).
node(n380,supported) :- node(n381,supported), node(n382,supported), node(n383,supported).
node(n380,refuted) :- node(n381,refuted).
node(n380,refuted) :- node(n382,refuted).
node(n380,refuted) :- node(n383,refuted).
node(n380,unknown) :- \+ node(n380,supported), \+ node(n380,refuted).
node(n385,supported) :- status(o_9e152ec50f2e5029e159,supported).
node(n385,refuted) :- status(o_9e152ec50f2e5029e159,refuted).
node(n385,unknown) :- status(o_9e152ec50f2e5029e159,unknown).
node(n386,supported) :- status(o_0a027f17307007525801,supported).
node(n386,refuted) :- status(o_0a027f17307007525801,refuted).
node(n386,unknown) :- status(o_0a027f17307007525801,unknown).
node(n387,supported) :- status(o_4f168cd3692d67e50979,supported).
node(n387,refuted) :- status(o_4f168cd3692d67e50979,refuted).
node(n387,unknown) :- status(o_4f168cd3692d67e50979,unknown).
node(n384,supported) :- node(n385,supported), node(n386,supported), node(n387,supported).
node(n384,refuted) :- node(n385,refuted).
node(n384,refuted) :- node(n386,refuted).
node(n384,refuted) :- node(n387,refuted).
node(n384,unknown) :- \+ node(n384,supported), \+ node(n384,refuted).
node(n379,refuted) :- node(n380,refuted), node(n384,refuted), node(n9,refuted).
node(n379,supported) :- node(n380,supported).
node(n379,supported) :- node(n384,supported).
node(n379,supported) :- node(n9,supported).
node(n379,unknown) :- \+ node(n379,supported), \+ node(n379,refuted).
verdict(c_e1ef0182dceb91d6,supported) :- node(n379,supported).
query(verdict(c_e1ef0182dceb91d6,supported)).
verdict(c_e1ef0182dceb91d6,refuted) :- node(n379,refuted).
query(verdict(c_e1ef0182dceb91d6,refuted)).
verdict(c_e1ef0182dceb91d6,unknown) :- node(n379,unknown).
query(verdict(c_e1ef0182dceb91d6,unknown)).
node(n390,supported) :- status(o_19f36f5b09e9ab099ea4,supported).
node(n390,refuted) :- status(o_19f36f5b09e9ab099ea4,refuted).
node(n390,unknown) :- status(o_19f36f5b09e9ab099ea4,unknown).
node(n391,supported) :- status(o_794b5356e84051037fd5,supported).
node(n391,refuted) :- status(o_794b5356e84051037fd5,refuted).
node(n391,unknown) :- status(o_794b5356e84051037fd5,unknown).
node(n392,supported) :- status(o_a28cf40d91c2185d7b0a,supported).
node(n392,refuted) :- status(o_a28cf40d91c2185d7b0a,refuted).
node(n392,unknown) :- status(o_a28cf40d91c2185d7b0a,unknown).
node(n393,supported) :- status(o_a4c439420ab00051c2a0,supported).
node(n393,refuted) :- status(o_a4c439420ab00051c2a0,refuted).
node(n393,unknown) :- status(o_a4c439420ab00051c2a0,unknown).
node(n389,supported) :- node(n390,supported), node(n391,supported), node(n392,supported), node(n393,supported).
node(n389,refuted) :- node(n390,refuted).
node(n389,refuted) :- node(n391,refuted).
node(n389,refuted) :- node(n392,refuted).
node(n389,refuted) :- node(n393,refuted).
node(n389,unknown) :- \+ node(n389,supported), \+ node(n389,refuted).
node(n395,supported) :- status(o_5387994c83094efca66a,supported).
node(n395,refuted) :- status(o_5387994c83094efca66a,refuted).
node(n395,unknown) :- status(o_5387994c83094efca66a,unknown).
node(n396,supported) :- status(o_0a320a39b6c45586701d,supported).
node(n396,refuted) :- status(o_0a320a39b6c45586701d,refuted).
node(n396,unknown) :- status(o_0a320a39b6c45586701d,unknown).
node(n397,supported) :- status(o_ba4d56fa3e47aa437932,supported).
node(n397,refuted) :- status(o_ba4d56fa3e47aa437932,refuted).
node(n397,unknown) :- status(o_ba4d56fa3e47aa437932,unknown).
node(n398,supported) :- status(o_d465bfa16a2bd1e73e4f,supported).
node(n398,refuted) :- status(o_d465bfa16a2bd1e73e4f,refuted).
node(n398,unknown) :- status(o_d465bfa16a2bd1e73e4f,unknown).
node(n394,supported) :- node(n395,supported), node(n396,supported), node(n397,supported), node(n398,supported).
node(n394,refuted) :- node(n395,refuted).
node(n394,refuted) :- node(n396,refuted).
node(n394,refuted) :- node(n397,refuted).
node(n394,refuted) :- node(n398,refuted).
node(n394,unknown) :- \+ node(n394,supported), \+ node(n394,refuted).
node(n388,refuted) :- node(n389,refuted), node(n394,refuted), node(n9,refuted).
node(n388,supported) :- node(n389,supported).
node(n388,supported) :- node(n394,supported).
node(n388,supported) :- node(n9,supported).
node(n388,unknown) :- \+ node(n388,supported), \+ node(n388,refuted).
verdict(c_62005cf47922d1ba,supported) :- node(n388,supported).
query(verdict(c_62005cf47922d1ba,supported)).
verdict(c_62005cf47922d1ba,refuted) :- node(n388,refuted).
query(verdict(c_62005cf47922d1ba,refuted)).
verdict(c_62005cf47922d1ba,unknown) :- node(n388,unknown).
query(verdict(c_62005cf47922d1ba,unknown)).
node(n401,supported) :- status(o_70155044e137fa0d8a20,supported).
node(n401,refuted) :- status(o_70155044e137fa0d8a20,refuted).
node(n401,unknown) :- status(o_70155044e137fa0d8a20,unknown).
node(n402,supported) :- status(o_680dd57c03543389cb1c,supported).
node(n402,refuted) :- status(o_680dd57c03543389cb1c,refuted).
node(n402,unknown) :- status(o_680dd57c03543389cb1c,unknown).
node(n403,supported) :- status(o_3708e936abdea4e529a6,supported).
node(n403,refuted) :- status(o_3708e936abdea4e529a6,refuted).
node(n403,unknown) :- status(o_3708e936abdea4e529a6,unknown).
node(n404,supported) :- status(o_890b148b53aa96dbdea7,supported).
node(n404,refuted) :- status(o_890b148b53aa96dbdea7,refuted).
node(n404,unknown) :- status(o_890b148b53aa96dbdea7,unknown).
node(n400,supported) :- node(n401,supported), node(n402,supported), node(n403,supported), node(n404,supported).
node(n400,refuted) :- node(n401,refuted).
node(n400,refuted) :- node(n402,refuted).
node(n400,refuted) :- node(n403,refuted).
node(n400,refuted) :- node(n404,refuted).
node(n400,unknown) :- \+ node(n400,supported), \+ node(n400,refuted).
node(n406,supported) :- status(o_085560713cb1a8b43154,supported).
node(n406,refuted) :- status(o_085560713cb1a8b43154,refuted).
node(n406,unknown) :- status(o_085560713cb1a8b43154,unknown).
node(n407,supported) :- status(o_a29a41ef3b14dc3b7d73,supported).
node(n407,refuted) :- status(o_a29a41ef3b14dc3b7d73,refuted).
node(n407,unknown) :- status(o_a29a41ef3b14dc3b7d73,unknown).
node(n408,supported) :- status(o_934983b633e5a697e28d,supported).
node(n408,refuted) :- status(o_934983b633e5a697e28d,refuted).
node(n408,unknown) :- status(o_934983b633e5a697e28d,unknown).
node(n409,supported) :- status(o_33e54bde119619a502be,supported).
node(n409,refuted) :- status(o_33e54bde119619a502be,refuted).
node(n409,unknown) :- status(o_33e54bde119619a502be,unknown).
node(n405,supported) :- node(n406,supported), node(n407,supported), node(n408,supported), node(n409,supported).
node(n405,refuted) :- node(n406,refuted).
node(n405,refuted) :- node(n407,refuted).
node(n405,refuted) :- node(n408,refuted).
node(n405,refuted) :- node(n409,refuted).
node(n405,unknown) :- \+ node(n405,supported), \+ node(n405,refuted).
node(n399,refuted) :- node(n400,refuted), node(n405,refuted), node(n9,refuted).
node(n399,supported) :- node(n400,supported).
node(n399,supported) :- node(n405,supported).
node(n399,supported) :- node(n9,supported).
node(n399,unknown) :- \+ node(n399,supported), \+ node(n399,refuted).
verdict(c_a6690dbe7cfea116,supported) :- node(n399,supported).
query(verdict(c_a6690dbe7cfea116,supported)).
verdict(c_a6690dbe7cfea116,refuted) :- node(n399,refuted).
query(verdict(c_a6690dbe7cfea116,refuted)).
verdict(c_a6690dbe7cfea116,unknown) :- node(n399,unknown).
query(verdict(c_a6690dbe7cfea116,unknown)).
node(n412,supported) :- status(o_533dd9b9efbfe17e57e8,supported).
node(n412,refuted) :- status(o_533dd9b9efbfe17e57e8,refuted).
node(n412,unknown) :- status(o_533dd9b9efbfe17e57e8,unknown).
node(n413,supported) :- status(o_7add1d1135ffa4da8996,supported).
node(n413,refuted) :- status(o_7add1d1135ffa4da8996,refuted).
node(n413,unknown) :- status(o_7add1d1135ffa4da8996,unknown).
node(n414,supported) :- status(o_b0028b0b240491ae2768,supported).
node(n414,refuted) :- status(o_b0028b0b240491ae2768,refuted).
node(n414,unknown) :- status(o_b0028b0b240491ae2768,unknown).
node(n415,supported) :- status(o_a9be3a590ca349db95da,supported).
node(n415,refuted) :- status(o_a9be3a590ca349db95da,refuted).
node(n415,unknown) :- status(o_a9be3a590ca349db95da,unknown).
node(n411,supported) :- node(n412,supported), node(n413,supported), node(n414,supported), node(n415,supported).
node(n411,refuted) :- node(n412,refuted).
node(n411,refuted) :- node(n413,refuted).
node(n411,refuted) :- node(n414,refuted).
node(n411,refuted) :- node(n415,refuted).
node(n411,unknown) :- \+ node(n411,supported), \+ node(n411,refuted).
node(n417,supported) :- status(o_8fc0b3338cc2f2aae517,supported).
node(n417,refuted) :- status(o_8fc0b3338cc2f2aae517,refuted).
node(n417,unknown) :- status(o_8fc0b3338cc2f2aae517,unknown).
node(n418,supported) :- status(o_c3e947989ba8236f9df8,supported).
node(n418,refuted) :- status(o_c3e947989ba8236f9df8,refuted).
node(n418,unknown) :- status(o_c3e947989ba8236f9df8,unknown).
node(n419,supported) :- status(o_1b1d1b1988830aebfadf,supported).
node(n419,refuted) :- status(o_1b1d1b1988830aebfadf,refuted).
node(n419,unknown) :- status(o_1b1d1b1988830aebfadf,unknown).
node(n420,supported) :- status(o_8c10222f138ba19bf5f2,supported).
node(n420,refuted) :- status(o_8c10222f138ba19bf5f2,refuted).
node(n420,unknown) :- status(o_8c10222f138ba19bf5f2,unknown).
node(n416,supported) :- node(n417,supported), node(n418,supported), node(n419,supported), node(n420,supported).
node(n416,refuted) :- node(n417,refuted).
node(n416,refuted) :- node(n418,refuted).
node(n416,refuted) :- node(n419,refuted).
node(n416,refuted) :- node(n420,refuted).
node(n416,unknown) :- \+ node(n416,supported), \+ node(n416,refuted).
node(n410,refuted) :- node(n411,refuted), node(n416,refuted), node(n9,refuted).
node(n410,supported) :- node(n411,supported).
node(n410,supported) :- node(n416,supported).
node(n410,supported) :- node(n9,supported).
node(n410,unknown) :- \+ node(n410,supported), \+ node(n410,refuted).
verdict(c_b54dbfe132d5de42,supported) :- node(n410,supported).
query(verdict(c_b54dbfe132d5de42,supported)).
verdict(c_b54dbfe132d5de42,refuted) :- node(n410,refuted).
query(verdict(c_b54dbfe132d5de42,refuted)).
verdict(c_b54dbfe132d5de42,unknown) :- node(n410,unknown).
query(verdict(c_b54dbfe132d5de42,unknown)).
node(n423,supported) :- status(o_9aa9398419b8720c2904,supported).
node(n423,refuted) :- status(o_9aa9398419b8720c2904,refuted).
node(n423,unknown) :- status(o_9aa9398419b8720c2904,unknown).
node(n424,supported) :- status(o_393d37c0b1e34f922acf,supported).
node(n424,refuted) :- status(o_393d37c0b1e34f922acf,refuted).
node(n424,unknown) :- status(o_393d37c0b1e34f922acf,unknown).
node(n425,supported) :- status(o_d34fb6f9b4b26cbf1270,supported).
node(n425,refuted) :- status(o_d34fb6f9b4b26cbf1270,refuted).
node(n425,unknown) :- status(o_d34fb6f9b4b26cbf1270,unknown).
node(n422,supported) :- node(n423,supported), node(n424,supported), node(n425,supported).
node(n422,refuted) :- node(n423,refuted).
node(n422,refuted) :- node(n424,refuted).
node(n422,refuted) :- node(n425,refuted).
node(n422,unknown) :- \+ node(n422,supported), \+ node(n422,refuted).
node(n427,supported) :- status(o_70aa97afad1db9495b33,supported).
node(n427,refuted) :- status(o_70aa97afad1db9495b33,refuted).
node(n427,unknown) :- status(o_70aa97afad1db9495b33,unknown).
node(n428,supported) :- status(o_dbc69557e04af9f4e9d8,supported).
node(n428,refuted) :- status(o_dbc69557e04af9f4e9d8,refuted).
node(n428,unknown) :- status(o_dbc69557e04af9f4e9d8,unknown).
node(n429,supported) :- status(o_dcb2ed7a46df89f934be,supported).
node(n429,refuted) :- status(o_dcb2ed7a46df89f934be,refuted).
node(n429,unknown) :- status(o_dcb2ed7a46df89f934be,unknown).
node(n426,supported) :- node(n427,supported), node(n428,supported), node(n429,supported).
node(n426,refuted) :- node(n427,refuted).
node(n426,refuted) :- node(n428,refuted).
node(n426,refuted) :- node(n429,refuted).
node(n426,unknown) :- \+ node(n426,supported), \+ node(n426,refuted).
node(n421,refuted) :- node(n422,refuted), node(n426,refuted), node(n9,refuted).
node(n421,supported) :- node(n422,supported).
node(n421,supported) :- node(n426,supported).
node(n421,supported) :- node(n9,supported).
node(n421,unknown) :- \+ node(n421,supported), \+ node(n421,refuted).
verdict(c_d3e68035cdf1135a,supported) :- node(n421,supported).
query(verdict(c_d3e68035cdf1135a,supported)).
verdict(c_d3e68035cdf1135a,refuted) :- node(n421,refuted).
query(verdict(c_d3e68035cdf1135a,refuted)).
verdict(c_d3e68035cdf1135a,unknown) :- node(n421,unknown).
query(verdict(c_d3e68035cdf1135a,unknown)).
node(n432,supported) :- status(o_28e89dadd482246f9120,supported).
node(n432,refuted) :- status(o_28e89dadd482246f9120,refuted).
node(n432,unknown) :- status(o_28e89dadd482246f9120,unknown).
node(n433,supported) :- status(o_81493205849ce356b11a,supported).
node(n433,refuted) :- status(o_81493205849ce356b11a,refuted).
node(n433,unknown) :- status(o_81493205849ce356b11a,unknown).
node(n434,supported) :- status(o_db82a82c3b7af847537d,supported).
node(n434,refuted) :- status(o_db82a82c3b7af847537d,refuted).
node(n434,unknown) :- status(o_db82a82c3b7af847537d,unknown).
node(n435,supported) :- status(o_6e0576a3ed266675bc4c,supported).
node(n435,refuted) :- status(o_6e0576a3ed266675bc4c,refuted).
node(n435,unknown) :- status(o_6e0576a3ed266675bc4c,unknown).
node(n431,supported) :- node(n432,supported), node(n433,supported), node(n434,supported), node(n435,supported).
node(n431,refuted) :- node(n432,refuted).
node(n431,refuted) :- node(n433,refuted).
node(n431,refuted) :- node(n434,refuted).
node(n431,refuted) :- node(n435,refuted).
node(n431,unknown) :- \+ node(n431,supported), \+ node(n431,refuted).
node(n437,supported) :- status(o_7ebfdfdda6cd43210235,supported).
node(n437,refuted) :- status(o_7ebfdfdda6cd43210235,refuted).
node(n437,unknown) :- status(o_7ebfdfdda6cd43210235,unknown).
node(n438,supported) :- status(o_d7b4ca64409317efac7c,supported).
node(n438,refuted) :- status(o_d7b4ca64409317efac7c,refuted).
node(n438,unknown) :- status(o_d7b4ca64409317efac7c,unknown).
node(n439,supported) :- status(o_8023677404c9057ac91d,supported).
node(n439,refuted) :- status(o_8023677404c9057ac91d,refuted).
node(n439,unknown) :- status(o_8023677404c9057ac91d,unknown).
node(n440,supported) :- status(o_fc46fe5ed0ad4cac09da,supported).
node(n440,refuted) :- status(o_fc46fe5ed0ad4cac09da,refuted).
node(n440,unknown) :- status(o_fc46fe5ed0ad4cac09da,unknown).
node(n436,supported) :- node(n437,supported), node(n438,supported), node(n439,supported), node(n440,supported).
node(n436,refuted) :- node(n437,refuted).
node(n436,refuted) :- node(n438,refuted).
node(n436,refuted) :- node(n439,refuted).
node(n436,refuted) :- node(n440,refuted).
node(n436,unknown) :- \+ node(n436,supported), \+ node(n436,refuted).
node(n430,refuted) :- node(n431,refuted), node(n436,refuted), node(n9,refuted).
node(n430,supported) :- node(n431,supported).
node(n430,supported) :- node(n436,supported).
node(n430,supported) :- node(n9,supported).
node(n430,unknown) :- \+ node(n430,supported), \+ node(n430,refuted).
verdict(c_7f2cb8e3371c4fde,supported) :- node(n430,supported).
query(verdict(c_7f2cb8e3371c4fde,supported)).
verdict(c_7f2cb8e3371c4fde,refuted) :- node(n430,refuted).
query(verdict(c_7f2cb8e3371c4fde,refuted)).
verdict(c_7f2cb8e3371c4fde,unknown) :- node(n430,unknown).
query(verdict(c_7f2cb8e3371c4fde,unknown)).
node(n443,supported) :- status(o_c8da05b6d96bbc7a4573,supported).
node(n443,refuted) :- status(o_c8da05b6d96bbc7a4573,refuted).
node(n443,unknown) :- status(o_c8da05b6d96bbc7a4573,unknown).
node(n444,supported) :- status(o_5f6d56185294e478ff16,supported).
node(n444,refuted) :- status(o_5f6d56185294e478ff16,refuted).
node(n444,unknown) :- status(o_5f6d56185294e478ff16,unknown).
node(n445,supported) :- status(o_d953fc8a78bccc0529c1,supported).
node(n445,refuted) :- status(o_d953fc8a78bccc0529c1,refuted).
node(n445,unknown) :- status(o_d953fc8a78bccc0529c1,unknown).
node(n446,supported) :- status(o_a798113d7da25921886d,supported).
node(n446,refuted) :- status(o_a798113d7da25921886d,refuted).
node(n446,unknown) :- status(o_a798113d7da25921886d,unknown).
node(n442,supported) :- node(n443,supported), node(n444,supported), node(n445,supported), node(n446,supported).
node(n442,refuted) :- node(n443,refuted).
node(n442,refuted) :- node(n444,refuted).
node(n442,refuted) :- node(n445,refuted).
node(n442,refuted) :- node(n446,refuted).
node(n442,unknown) :- \+ node(n442,supported), \+ node(n442,refuted).
node(n448,supported) :- status(o_e23d226dd55413e5e2ac,supported).
node(n448,refuted) :- status(o_e23d226dd55413e5e2ac,refuted).
node(n448,unknown) :- status(o_e23d226dd55413e5e2ac,unknown).
node(n449,supported) :- status(o_a3a1df1fbf749dfa5ff2,supported).
node(n449,refuted) :- status(o_a3a1df1fbf749dfa5ff2,refuted).
node(n449,unknown) :- status(o_a3a1df1fbf749dfa5ff2,unknown).
node(n450,supported) :- status(o_01764e82499f5cd52ea4,supported).
node(n450,refuted) :- status(o_01764e82499f5cd52ea4,refuted).
node(n450,unknown) :- status(o_01764e82499f5cd52ea4,unknown).
node(n451,supported) :- status(o_eda88ddfb64a1312e49e,supported).
node(n451,refuted) :- status(o_eda88ddfb64a1312e49e,refuted).
node(n451,unknown) :- status(o_eda88ddfb64a1312e49e,unknown).
node(n447,supported) :- node(n448,supported), node(n449,supported), node(n450,supported), node(n451,supported).
node(n447,refuted) :- node(n448,refuted).
node(n447,refuted) :- node(n449,refuted).
node(n447,refuted) :- node(n450,refuted).
node(n447,refuted) :- node(n451,refuted).
node(n447,unknown) :- \+ node(n447,supported), \+ node(n447,refuted).
node(n441,refuted) :- node(n442,refuted), node(n447,refuted), node(n9,refuted).
node(n441,supported) :- node(n442,supported).
node(n441,supported) :- node(n447,supported).
node(n441,supported) :- node(n9,supported).
node(n441,unknown) :- \+ node(n441,supported), \+ node(n441,refuted).
verdict(c_2156384777faff9f,supported) :- node(n441,supported).
query(verdict(c_2156384777faff9f,supported)).
verdict(c_2156384777faff9f,refuted) :- node(n441,refuted).
query(verdict(c_2156384777faff9f,refuted)).
verdict(c_2156384777faff9f,unknown) :- node(n441,unknown).
query(verdict(c_2156384777faff9f,unknown)).
node(n454,supported) :- status(o_a56a2b891053a730ab9a,supported).
node(n454,refuted) :- status(o_a56a2b891053a730ab9a,refuted).
node(n454,unknown) :- status(o_a56a2b891053a730ab9a,unknown).
node(n455,supported) :- status(o_a6d81e0706884f706a19,supported).
node(n455,refuted) :- status(o_a6d81e0706884f706a19,refuted).
node(n455,unknown) :- status(o_a6d81e0706884f706a19,unknown).
node(n456,supported) :- status(o_d2edda89bf3f3411b7d9,supported).
node(n456,refuted) :- status(o_d2edda89bf3f3411b7d9,refuted).
node(n456,unknown) :- status(o_d2edda89bf3f3411b7d9,unknown).
node(n457,supported) :- status(o_301abc32044c718c7118,supported).
node(n457,refuted) :- status(o_301abc32044c718c7118,refuted).
node(n457,unknown) :- status(o_301abc32044c718c7118,unknown).
node(n453,supported) :- node(n454,supported), node(n455,supported), node(n456,supported), node(n457,supported).
node(n453,refuted) :- node(n454,refuted).
node(n453,refuted) :- node(n455,refuted).
node(n453,refuted) :- node(n456,refuted).
node(n453,refuted) :- node(n457,refuted).
node(n453,unknown) :- \+ node(n453,supported), \+ node(n453,refuted).
node(n459,supported) :- status(o_ad7c14d104cabccf23f6,supported).
node(n459,refuted) :- status(o_ad7c14d104cabccf23f6,refuted).
node(n459,unknown) :- status(o_ad7c14d104cabccf23f6,unknown).
node(n460,supported) :- status(o_42b6d2f613311f7ce846,supported).
node(n460,refuted) :- status(o_42b6d2f613311f7ce846,refuted).
node(n460,unknown) :- status(o_42b6d2f613311f7ce846,unknown).
node(n461,supported) :- status(o_ef3293d74a9d10dc4fbd,supported).
node(n461,refuted) :- status(o_ef3293d74a9d10dc4fbd,refuted).
node(n461,unknown) :- status(o_ef3293d74a9d10dc4fbd,unknown).
node(n462,supported) :- status(o_7a8defbec8463a8c7f01,supported).
node(n462,refuted) :- status(o_7a8defbec8463a8c7f01,refuted).
node(n462,unknown) :- status(o_7a8defbec8463a8c7f01,unknown).
node(n458,supported) :- node(n459,supported), node(n460,supported), node(n461,supported), node(n462,supported).
node(n458,refuted) :- node(n459,refuted).
node(n458,refuted) :- node(n460,refuted).
node(n458,refuted) :- node(n461,refuted).
node(n458,refuted) :- node(n462,refuted).
node(n458,unknown) :- \+ node(n458,supported), \+ node(n458,refuted).
node(n452,refuted) :- node(n453,refuted), node(n458,refuted), node(n9,refuted).
node(n452,supported) :- node(n453,supported).
node(n452,supported) :- node(n458,supported).
node(n452,supported) :- node(n9,supported).
node(n452,unknown) :- \+ node(n452,supported), \+ node(n452,refuted).
verdict(c_12d1eb2db04951ad,supported) :- node(n452,supported).
query(verdict(c_12d1eb2db04951ad,supported)).
verdict(c_12d1eb2db04951ad,refuted) :- node(n452,refuted).
query(verdict(c_12d1eb2db04951ad,refuted)).
verdict(c_12d1eb2db04951ad,unknown) :- node(n452,unknown).
query(verdict(c_12d1eb2db04951ad,unknown)).
node(n465,supported) :- status(o_3d7d93c54ec1b38702d5,supported).
node(n465,refuted) :- status(o_3d7d93c54ec1b38702d5,refuted).
node(n465,unknown) :- status(o_3d7d93c54ec1b38702d5,unknown).
node(n466,supported) :- status(o_6e707e0fab928955adf3,supported).
node(n466,refuted) :- status(o_6e707e0fab928955adf3,refuted).
node(n466,unknown) :- status(o_6e707e0fab928955adf3,unknown).
node(n467,supported) :- status(o_fa5811094579865e8074,supported).
node(n467,refuted) :- status(o_fa5811094579865e8074,refuted).
node(n467,unknown) :- status(o_fa5811094579865e8074,unknown).
node(n464,supported) :- node(n465,supported), node(n466,supported), node(n467,supported).
node(n464,refuted) :- node(n465,refuted).
node(n464,refuted) :- node(n466,refuted).
node(n464,refuted) :- node(n467,refuted).
node(n464,unknown) :- \+ node(n464,supported), \+ node(n464,refuted).
node(n469,supported) :- status(o_acdf642e5d06dc114def,supported).
node(n469,refuted) :- status(o_acdf642e5d06dc114def,refuted).
node(n469,unknown) :- status(o_acdf642e5d06dc114def,unknown).
node(n470,supported) :- status(o_b7e9de59802fa88fe245,supported).
node(n470,refuted) :- status(o_b7e9de59802fa88fe245,refuted).
node(n470,unknown) :- status(o_b7e9de59802fa88fe245,unknown).
node(n471,supported) :- status(o_95b12e4d0e6a3c22b8d0,supported).
node(n471,refuted) :- status(o_95b12e4d0e6a3c22b8d0,refuted).
node(n471,unknown) :- status(o_95b12e4d0e6a3c22b8d0,unknown).
node(n468,supported) :- node(n469,supported), node(n470,supported), node(n471,supported).
node(n468,refuted) :- node(n469,refuted).
node(n468,refuted) :- node(n470,refuted).
node(n468,refuted) :- node(n471,refuted).
node(n468,unknown) :- \+ node(n468,supported), \+ node(n468,refuted).
node(n463,refuted) :- node(n464,refuted), node(n468,refuted), node(n9,refuted).
node(n463,supported) :- node(n464,supported).
node(n463,supported) :- node(n468,supported).
node(n463,supported) :- node(n9,supported).
node(n463,unknown) :- \+ node(n463,supported), \+ node(n463,refuted).
verdict(c_24ecb1a5a020ffe6,supported) :- node(n463,supported).
query(verdict(c_24ecb1a5a020ffe6,supported)).
verdict(c_24ecb1a5a020ffe6,refuted) :- node(n463,refuted).
query(verdict(c_24ecb1a5a020ffe6,refuted)).
verdict(c_24ecb1a5a020ffe6,unknown) :- node(n463,unknown).
query(verdict(c_24ecb1a5a020ffe6,unknown)).
node(n474,supported) :- status(o_88c50fb5059f8212051c,supported).
node(n474,refuted) :- status(o_88c50fb5059f8212051c,refuted).
node(n474,unknown) :- status(o_88c50fb5059f8212051c,unknown).
node(n475,supported) :- status(o_4b56d6c8843b75424c71,supported).
node(n475,refuted) :- status(o_4b56d6c8843b75424c71,refuted).
node(n475,unknown) :- status(o_4b56d6c8843b75424c71,unknown).
node(n476,supported) :- status(o_3af916ad7d95a2a2de3c,supported).
node(n476,refuted) :- status(o_3af916ad7d95a2a2de3c,refuted).
node(n476,unknown) :- status(o_3af916ad7d95a2a2de3c,unknown).
node(n477,supported) :- status(o_21ebb3057eeee6b30925,supported).
node(n477,refuted) :- status(o_21ebb3057eeee6b30925,refuted).
node(n477,unknown) :- status(o_21ebb3057eeee6b30925,unknown).
node(n473,supported) :- node(n474,supported), node(n475,supported), node(n476,supported), node(n477,supported).
node(n473,refuted) :- node(n474,refuted).
node(n473,refuted) :- node(n475,refuted).
node(n473,refuted) :- node(n476,refuted).
node(n473,refuted) :- node(n477,refuted).
node(n473,unknown) :- \+ node(n473,supported), \+ node(n473,refuted).
node(n479,supported) :- status(o_22d40b8c8143d112c6d6,supported).
node(n479,refuted) :- status(o_22d40b8c8143d112c6d6,refuted).
node(n479,unknown) :- status(o_22d40b8c8143d112c6d6,unknown).
node(n480,supported) :- status(o_3500eb1666ae680f2659,supported).
node(n480,refuted) :- status(o_3500eb1666ae680f2659,refuted).
node(n480,unknown) :- status(o_3500eb1666ae680f2659,unknown).
node(n481,supported) :- status(o_ade077e5436a9a77c478,supported).
node(n481,refuted) :- status(o_ade077e5436a9a77c478,refuted).
node(n481,unknown) :- status(o_ade077e5436a9a77c478,unknown).
node(n482,supported) :- status(o_6fb4744fe4db4d3ff6c7,supported).
node(n482,refuted) :- status(o_6fb4744fe4db4d3ff6c7,refuted).
node(n482,unknown) :- status(o_6fb4744fe4db4d3ff6c7,unknown).
node(n478,supported) :- node(n479,supported), node(n480,supported), node(n481,supported), node(n482,supported).
node(n478,refuted) :- node(n479,refuted).
node(n478,refuted) :- node(n480,refuted).
node(n478,refuted) :- node(n481,refuted).
node(n478,refuted) :- node(n482,refuted).
node(n478,unknown) :- \+ node(n478,supported), \+ node(n478,refuted).
node(n472,refuted) :- node(n473,refuted), node(n478,refuted), node(n9,refuted).
node(n472,supported) :- node(n473,supported).
node(n472,supported) :- node(n478,supported).
node(n472,supported) :- node(n9,supported).
node(n472,unknown) :- \+ node(n472,supported), \+ node(n472,refuted).
verdict(c_4f39ec1337d71179,supported) :- node(n472,supported).
query(verdict(c_4f39ec1337d71179,supported)).
verdict(c_4f39ec1337d71179,refuted) :- node(n472,refuted).
query(verdict(c_4f39ec1337d71179,refuted)).
verdict(c_4f39ec1337d71179,unknown) :- node(n472,unknown).
query(verdict(c_4f39ec1337d71179,unknown)).
node(n485,supported) :- status(o_03056a50380814f9afc3,supported).
node(n485,refuted) :- status(o_03056a50380814f9afc3,refuted).
node(n485,unknown) :- status(o_03056a50380814f9afc3,unknown).
node(n486,supported) :- status(o_feb580e2df21a4c31f94,supported).
node(n486,refuted) :- status(o_feb580e2df21a4c31f94,refuted).
node(n486,unknown) :- status(o_feb580e2df21a4c31f94,unknown).
node(n487,supported) :- status(o_f93c7f0cd7f4abb7e873,supported).
node(n487,refuted) :- status(o_f93c7f0cd7f4abb7e873,refuted).
node(n487,unknown) :- status(o_f93c7f0cd7f4abb7e873,unknown).
node(n488,supported) :- status(o_a8211898c6351603939e,supported).
node(n488,refuted) :- status(o_a8211898c6351603939e,refuted).
node(n488,unknown) :- status(o_a8211898c6351603939e,unknown).
node(n484,supported) :- node(n485,supported), node(n486,supported), node(n487,supported), node(n488,supported).
node(n484,refuted) :- node(n485,refuted).
node(n484,refuted) :- node(n486,refuted).
node(n484,refuted) :- node(n487,refuted).
node(n484,refuted) :- node(n488,refuted).
node(n484,unknown) :- \+ node(n484,supported), \+ node(n484,refuted).
node(n490,supported) :- status(o_521b485086d57d954475,supported).
node(n490,refuted) :- status(o_521b485086d57d954475,refuted).
node(n490,unknown) :- status(o_521b485086d57d954475,unknown).
node(n491,supported) :- status(o_7abb67f7350c48b3824d,supported).
node(n491,refuted) :- status(o_7abb67f7350c48b3824d,refuted).
node(n491,unknown) :- status(o_7abb67f7350c48b3824d,unknown).
node(n492,supported) :- status(o_0ccc8cbdd5c7ab1cf9f1,supported).
node(n492,refuted) :- status(o_0ccc8cbdd5c7ab1cf9f1,refuted).
node(n492,unknown) :- status(o_0ccc8cbdd5c7ab1cf9f1,unknown).
node(n493,supported) :- status(o_81c42e465ef204b6b0da,supported).
node(n493,refuted) :- status(o_81c42e465ef204b6b0da,refuted).
node(n493,unknown) :- status(o_81c42e465ef204b6b0da,unknown).
node(n489,supported) :- node(n490,supported), node(n491,supported), node(n492,supported), node(n493,supported).
node(n489,refuted) :- node(n490,refuted).
node(n489,refuted) :- node(n491,refuted).
node(n489,refuted) :- node(n492,refuted).
node(n489,refuted) :- node(n493,refuted).
node(n489,unknown) :- \+ node(n489,supported), \+ node(n489,refuted).
node(n483,refuted) :- node(n484,refuted), node(n489,refuted), node(n9,refuted).
node(n483,supported) :- node(n484,supported).
node(n483,supported) :- node(n489,supported).
node(n483,supported) :- node(n9,supported).
node(n483,unknown) :- \+ node(n483,supported), \+ node(n483,refuted).
verdict(c_80cdbd69eae472db,supported) :- node(n483,supported).
query(verdict(c_80cdbd69eae472db,supported)).
verdict(c_80cdbd69eae472db,refuted) :- node(n483,refuted).
query(verdict(c_80cdbd69eae472db,refuted)).
verdict(c_80cdbd69eae472db,unknown) :- node(n483,unknown).
query(verdict(c_80cdbd69eae472db,unknown)).
node(n496,supported) :- status(o_c8cb944fac2f307b4212,supported).
node(n496,refuted) :- status(o_c8cb944fac2f307b4212,refuted).
node(n496,unknown) :- status(o_c8cb944fac2f307b4212,unknown).
node(n497,supported) :- status(o_eef3b9a0209ba9e874b8,supported).
node(n497,refuted) :- status(o_eef3b9a0209ba9e874b8,refuted).
node(n497,unknown) :- status(o_eef3b9a0209ba9e874b8,unknown).
node(n498,supported) :- status(o_febb76dc35c42a1a2edc,supported).
node(n498,refuted) :- status(o_febb76dc35c42a1a2edc,refuted).
node(n498,unknown) :- status(o_febb76dc35c42a1a2edc,unknown).
node(n499,supported) :- status(o_1f55d18774f13f1fe42e,supported).
node(n499,refuted) :- status(o_1f55d18774f13f1fe42e,refuted).
node(n499,unknown) :- status(o_1f55d18774f13f1fe42e,unknown).
node(n495,supported) :- node(n496,supported), node(n497,supported), node(n498,supported), node(n499,supported).
node(n495,refuted) :- node(n496,refuted).
node(n495,refuted) :- node(n497,refuted).
node(n495,refuted) :- node(n498,refuted).
node(n495,refuted) :- node(n499,refuted).
node(n495,unknown) :- \+ node(n495,supported), \+ node(n495,refuted).
node(n501,supported) :- status(o_1582d31449aad38a0ceb,supported).
node(n501,refuted) :- status(o_1582d31449aad38a0ceb,refuted).
node(n501,unknown) :- status(o_1582d31449aad38a0ceb,unknown).
node(n502,supported) :- status(o_7df28a6a6df1f9389720,supported).
node(n502,refuted) :- status(o_7df28a6a6df1f9389720,refuted).
node(n502,unknown) :- status(o_7df28a6a6df1f9389720,unknown).
node(n503,supported) :- status(o_72ce21eba031bac85280,supported).
node(n503,refuted) :- status(o_72ce21eba031bac85280,refuted).
node(n503,unknown) :- status(o_72ce21eba031bac85280,unknown).
node(n504,supported) :- status(o_dcc47511502e7c6c6127,supported).
node(n504,refuted) :- status(o_dcc47511502e7c6c6127,refuted).
node(n504,unknown) :- status(o_dcc47511502e7c6c6127,unknown).
node(n500,supported) :- node(n501,supported), node(n502,supported), node(n503,supported), node(n504,supported).
node(n500,refuted) :- node(n501,refuted).
node(n500,refuted) :- node(n502,refuted).
node(n500,refuted) :- node(n503,refuted).
node(n500,refuted) :- node(n504,refuted).
node(n500,unknown) :- \+ node(n500,supported), \+ node(n500,refuted).
node(n494,refuted) :- node(n495,refuted), node(n500,refuted), node(n9,refuted).
node(n494,supported) :- node(n495,supported).
node(n494,supported) :- node(n500,supported).
node(n494,supported) :- node(n9,supported).
node(n494,unknown) :- \+ node(n494,supported), \+ node(n494,refuted).
verdict(c_e881dba62dc4b9ac,supported) :- node(n494,supported).
query(verdict(c_e881dba62dc4b9ac,supported)).
verdict(c_e881dba62dc4b9ac,refuted) :- node(n494,refuted).
query(verdict(c_e881dba62dc4b9ac,refuted)).
verdict(c_e881dba62dc4b9ac,unknown) :- node(n494,unknown).
query(verdict(c_e881dba62dc4b9ac,unknown)).
node(n507,supported) :- status(o_46e2dd63b322c5dfaba0,supported).
node(n507,refuted) :- status(o_46e2dd63b322c5dfaba0,refuted).
node(n507,unknown) :- status(o_46e2dd63b322c5dfaba0,unknown).
node(n508,supported) :- status(o_28cc0864bf8f1d29c69d,supported).
node(n508,refuted) :- status(o_28cc0864bf8f1d29c69d,refuted).
node(n508,unknown) :- status(o_28cc0864bf8f1d29c69d,unknown).
node(n509,supported) :- status(o_ec58f92678b8a1512fb2,supported).
node(n509,refuted) :- status(o_ec58f92678b8a1512fb2,refuted).
node(n509,unknown) :- status(o_ec58f92678b8a1512fb2,unknown).
node(n506,supported) :- node(n507,supported), node(n508,supported), node(n509,supported).
node(n506,refuted) :- node(n507,refuted).
node(n506,refuted) :- node(n508,refuted).
node(n506,refuted) :- node(n509,refuted).
node(n506,unknown) :- \+ node(n506,supported), \+ node(n506,refuted).
node(n511,supported) :- status(o_aea6f7d8f854ee7d47f8,supported).
node(n511,refuted) :- status(o_aea6f7d8f854ee7d47f8,refuted).
node(n511,unknown) :- status(o_aea6f7d8f854ee7d47f8,unknown).
node(n512,supported) :- status(o_101eaa5b25466317589b,supported).
node(n512,refuted) :- status(o_101eaa5b25466317589b,refuted).
node(n512,unknown) :- status(o_101eaa5b25466317589b,unknown).
node(n513,supported) :- status(o_9426a03f39fe6c4cc08c,supported).
node(n513,refuted) :- status(o_9426a03f39fe6c4cc08c,refuted).
node(n513,unknown) :- status(o_9426a03f39fe6c4cc08c,unknown).
node(n510,supported) :- node(n511,supported), node(n512,supported), node(n513,supported).
node(n510,refuted) :- node(n511,refuted).
node(n510,refuted) :- node(n512,refuted).
node(n510,refuted) :- node(n513,refuted).
node(n510,unknown) :- \+ node(n510,supported), \+ node(n510,refuted).
node(n505,refuted) :- node(n506,refuted), node(n510,refuted), node(n9,refuted).
node(n505,supported) :- node(n506,supported).
node(n505,supported) :- node(n510,supported).
node(n505,supported) :- node(n9,supported).
node(n505,unknown) :- \+ node(n505,supported), \+ node(n505,refuted).
verdict(c_e3a9fde600eb6651,supported) :- node(n505,supported).
query(verdict(c_e3a9fde600eb6651,supported)).
verdict(c_e3a9fde600eb6651,refuted) :- node(n505,refuted).
query(verdict(c_e3a9fde600eb6651,refuted)).
verdict(c_e3a9fde600eb6651,unknown) :- node(n505,unknown).
query(verdict(c_e3a9fde600eb6651,unknown)).
node(n516,supported) :- status(o_afd1ae869eb5580bd720,supported).
node(n516,refuted) :- status(o_afd1ae869eb5580bd720,refuted).
node(n516,unknown) :- status(o_afd1ae869eb5580bd720,unknown).
node(n517,supported) :- status(o_482217f933d93a8510f1,supported).
node(n517,refuted) :- status(o_482217f933d93a8510f1,refuted).
node(n517,unknown) :- status(o_482217f933d93a8510f1,unknown).
node(n518,supported) :- status(o_5d51183e02d7b4f935fe,supported).
node(n518,refuted) :- status(o_5d51183e02d7b4f935fe,refuted).
node(n518,unknown) :- status(o_5d51183e02d7b4f935fe,unknown).
node(n519,supported) :- status(o_682e57e3d8673e74c97e,supported).
node(n519,refuted) :- status(o_682e57e3d8673e74c97e,refuted).
node(n519,unknown) :- status(o_682e57e3d8673e74c97e,unknown).
node(n515,supported) :- node(n516,supported), node(n517,supported), node(n518,supported), node(n519,supported).
node(n515,refuted) :- node(n516,refuted).
node(n515,refuted) :- node(n517,refuted).
node(n515,refuted) :- node(n518,refuted).
node(n515,refuted) :- node(n519,refuted).
node(n515,unknown) :- \+ node(n515,supported), \+ node(n515,refuted).
node(n521,supported) :- status(o_91584bd492b37beb31a1,supported).
node(n521,refuted) :- status(o_91584bd492b37beb31a1,refuted).
node(n521,unknown) :- status(o_91584bd492b37beb31a1,unknown).
node(n522,supported) :- status(o_373f3bb1437902c9b0d8,supported).
node(n522,refuted) :- status(o_373f3bb1437902c9b0d8,refuted).
node(n522,unknown) :- status(o_373f3bb1437902c9b0d8,unknown).
node(n523,supported) :- status(o_380735a74fad3aaee04e,supported).
node(n523,refuted) :- status(o_380735a74fad3aaee04e,refuted).
node(n523,unknown) :- status(o_380735a74fad3aaee04e,unknown).
node(n524,supported) :- status(o_3650361b8fdf51669fa0,supported).
node(n524,refuted) :- status(o_3650361b8fdf51669fa0,refuted).
node(n524,unknown) :- status(o_3650361b8fdf51669fa0,unknown).
node(n520,supported) :- node(n521,supported), node(n522,supported), node(n523,supported), node(n524,supported).
node(n520,refuted) :- node(n521,refuted).
node(n520,refuted) :- node(n522,refuted).
node(n520,refuted) :- node(n523,refuted).
node(n520,refuted) :- node(n524,refuted).
node(n520,unknown) :- \+ node(n520,supported), \+ node(n520,refuted).
node(n514,refuted) :- node(n515,refuted), node(n520,refuted), node(n9,refuted).
node(n514,supported) :- node(n515,supported).
node(n514,supported) :- node(n520,supported).
node(n514,supported) :- node(n9,supported).
node(n514,unknown) :- \+ node(n514,supported), \+ node(n514,refuted).
verdict(c_b7e376bd69a03c94,supported) :- node(n514,supported).
query(verdict(c_b7e376bd69a03c94,supported)).
verdict(c_b7e376bd69a03c94,refuted) :- node(n514,refuted).
query(verdict(c_b7e376bd69a03c94,refuted)).
verdict(c_b7e376bd69a03c94,unknown) :- node(n514,unknown).
query(verdict(c_b7e376bd69a03c94,unknown)).
node(n527,supported) :- status(o_80357a5d20213527abba,supported).
node(n527,refuted) :- status(o_80357a5d20213527abba,refuted).
node(n527,unknown) :- status(o_80357a5d20213527abba,unknown).
node(n528,supported) :- status(o_0abb8855c2588967d11c,supported).
node(n528,refuted) :- status(o_0abb8855c2588967d11c,refuted).
node(n528,unknown) :- status(o_0abb8855c2588967d11c,unknown).
node(n529,supported) :- status(o_9f753c9c0d6118e3e852,supported).
node(n529,refuted) :- status(o_9f753c9c0d6118e3e852,refuted).
node(n529,unknown) :- status(o_9f753c9c0d6118e3e852,unknown).
node(n530,supported) :- status(o_c6bd231419704666718a,supported).
node(n530,refuted) :- status(o_c6bd231419704666718a,refuted).
node(n530,unknown) :- status(o_c6bd231419704666718a,unknown).
node(n526,supported) :- node(n527,supported), node(n528,supported), node(n529,supported), node(n530,supported).
node(n526,refuted) :- node(n527,refuted).
node(n526,refuted) :- node(n528,refuted).
node(n526,refuted) :- node(n529,refuted).
node(n526,refuted) :- node(n530,refuted).
node(n526,unknown) :- \+ node(n526,supported), \+ node(n526,refuted).
node(n532,supported) :- status(o_e28207a28515ef85a3e8,supported).
node(n532,refuted) :- status(o_e28207a28515ef85a3e8,refuted).
node(n532,unknown) :- status(o_e28207a28515ef85a3e8,unknown).
node(n533,supported) :- status(o_06d0d73af4ce63709ebc,supported).
node(n533,refuted) :- status(o_06d0d73af4ce63709ebc,refuted).
node(n533,unknown) :- status(o_06d0d73af4ce63709ebc,unknown).
node(n534,supported) :- status(o_3b407c1a58f5da1df839,supported).
node(n534,refuted) :- status(o_3b407c1a58f5da1df839,refuted).
node(n534,unknown) :- status(o_3b407c1a58f5da1df839,unknown).
node(n535,supported) :- status(o_e8253b9dedd8fe6f07a7,supported).
node(n535,refuted) :- status(o_e8253b9dedd8fe6f07a7,refuted).
node(n535,unknown) :- status(o_e8253b9dedd8fe6f07a7,unknown).
node(n531,supported) :- node(n532,supported), node(n533,supported), node(n534,supported), node(n535,supported).
node(n531,refuted) :- node(n532,refuted).
node(n531,refuted) :- node(n533,refuted).
node(n531,refuted) :- node(n534,refuted).
node(n531,refuted) :- node(n535,refuted).
node(n531,unknown) :- \+ node(n531,supported), \+ node(n531,refuted).
node(n525,refuted) :- node(n526,refuted), node(n531,refuted), node(n9,refuted).
node(n525,supported) :- node(n526,supported).
node(n525,supported) :- node(n531,supported).
node(n525,supported) :- node(n9,supported).
node(n525,unknown) :- \+ node(n525,supported), \+ node(n525,refuted).
verdict(c_bd48493214ca0d05,supported) :- node(n525,supported).
query(verdict(c_bd48493214ca0d05,supported)).
verdict(c_bd48493214ca0d05,refuted) :- node(n525,refuted).
query(verdict(c_bd48493214ca0d05,refuted)).
verdict(c_bd48493214ca0d05,unknown) :- node(n525,unknown).
query(verdict(c_bd48493214ca0d05,unknown)).
node(n538,supported) :- status(o_99c3fb3979eef5f0942f,supported).
node(n538,refuted) :- status(o_99c3fb3979eef5f0942f,refuted).
node(n538,unknown) :- status(o_99c3fb3979eef5f0942f,unknown).
node(n539,supported) :- status(o_6bf12afc5c27f7e06131,supported).
node(n539,refuted) :- status(o_6bf12afc5c27f7e06131,refuted).
node(n539,unknown) :- status(o_6bf12afc5c27f7e06131,unknown).
node(n540,supported) :- status(o_5385944e773eb4e7db98,supported).
node(n540,refuted) :- status(o_5385944e773eb4e7db98,refuted).
node(n540,unknown) :- status(o_5385944e773eb4e7db98,unknown).
node(n541,supported) :- status(o_8af3fdf7d35af4575479,supported).
node(n541,refuted) :- status(o_8af3fdf7d35af4575479,refuted).
node(n541,unknown) :- status(o_8af3fdf7d35af4575479,unknown).
node(n537,supported) :- node(n538,supported), node(n539,supported), node(n540,supported), node(n541,supported).
node(n537,refuted) :- node(n538,refuted).
node(n537,refuted) :- node(n539,refuted).
node(n537,refuted) :- node(n540,refuted).
node(n537,refuted) :- node(n541,refuted).
node(n537,unknown) :- \+ node(n537,supported), \+ node(n537,refuted).
node(n543,supported) :- status(o_4a0d0b4b4ef89d5b53df,supported).
node(n543,refuted) :- status(o_4a0d0b4b4ef89d5b53df,refuted).
node(n543,unknown) :- status(o_4a0d0b4b4ef89d5b53df,unknown).
node(n544,supported) :- status(o_12ea7062cfa833ba3c85,supported).
node(n544,refuted) :- status(o_12ea7062cfa833ba3c85,refuted).
node(n544,unknown) :- status(o_12ea7062cfa833ba3c85,unknown).
node(n545,supported) :- status(o_6b6d387a88501cabedd1,supported).
node(n545,refuted) :- status(o_6b6d387a88501cabedd1,refuted).
node(n545,unknown) :- status(o_6b6d387a88501cabedd1,unknown).
node(n546,supported) :- status(o_90e29416513134f09009,supported).
node(n546,refuted) :- status(o_90e29416513134f09009,refuted).
node(n546,unknown) :- status(o_90e29416513134f09009,unknown).
node(n542,supported) :- node(n543,supported), node(n544,supported), node(n545,supported), node(n546,supported).
node(n542,refuted) :- node(n543,refuted).
node(n542,refuted) :- node(n544,refuted).
node(n542,refuted) :- node(n545,refuted).
node(n542,refuted) :- node(n546,refuted).
node(n542,unknown) :- \+ node(n542,supported), \+ node(n542,refuted).
node(n536,refuted) :- node(n537,refuted), node(n542,refuted), node(n9,refuted).
node(n536,supported) :- node(n537,supported).
node(n536,supported) :- node(n542,supported).
node(n536,supported) :- node(n9,supported).
node(n536,unknown) :- \+ node(n536,supported), \+ node(n536,refuted).
verdict(c_753ab00a57cd5dbf,supported) :- node(n536,supported).
query(verdict(c_753ab00a57cd5dbf,supported)).
verdict(c_753ab00a57cd5dbf,refuted) :- node(n536,refuted).
query(verdict(c_753ab00a57cd5dbf,refuted)).
verdict(c_753ab00a57cd5dbf,unknown) :- node(n536,unknown).
query(verdict(c_753ab00a57cd5dbf,unknown)).
node(n549,supported) :- status(o_b42bfb8b0357ba394852,supported).
node(n549,refuted) :- status(o_b42bfb8b0357ba394852,refuted).
node(n549,unknown) :- status(o_b42bfb8b0357ba394852,unknown).
node(n550,supported) :- status(o_1fc9d78bb914f21a623c,supported).
node(n550,refuted) :- status(o_1fc9d78bb914f21a623c,refuted).
node(n550,unknown) :- status(o_1fc9d78bb914f21a623c,unknown).
node(n551,supported) :- status(o_ddaad6b3c53e25ce0d18,supported).
node(n551,refuted) :- status(o_ddaad6b3c53e25ce0d18,refuted).
node(n551,unknown) :- status(o_ddaad6b3c53e25ce0d18,unknown).
node(n548,supported) :- node(n549,supported), node(n550,supported), node(n551,supported).
node(n548,refuted) :- node(n549,refuted).
node(n548,refuted) :- node(n550,refuted).
node(n548,refuted) :- node(n551,refuted).
node(n548,unknown) :- \+ node(n548,supported), \+ node(n548,refuted).
node(n553,supported) :- status(o_5c6781a2c4b0fc630d1e,supported).
node(n553,refuted) :- status(o_5c6781a2c4b0fc630d1e,refuted).
node(n553,unknown) :- status(o_5c6781a2c4b0fc630d1e,unknown).
node(n554,supported) :- status(o_b2f2f3f9c8e76389f265,supported).
node(n554,refuted) :- status(o_b2f2f3f9c8e76389f265,refuted).
node(n554,unknown) :- status(o_b2f2f3f9c8e76389f265,unknown).
node(n555,supported) :- status(o_6397aa38a20d30c1219e,supported).
node(n555,refuted) :- status(o_6397aa38a20d30c1219e,refuted).
node(n555,unknown) :- status(o_6397aa38a20d30c1219e,unknown).
node(n552,supported) :- node(n553,supported), node(n554,supported), node(n555,supported).
node(n552,refuted) :- node(n553,refuted).
node(n552,refuted) :- node(n554,refuted).
node(n552,refuted) :- node(n555,refuted).
node(n552,unknown) :- \+ node(n552,supported), \+ node(n552,refuted).
node(n547,refuted) :- node(n548,refuted), node(n552,refuted), node(n9,refuted).
node(n547,supported) :- node(n548,supported).
node(n547,supported) :- node(n552,supported).
node(n547,supported) :- node(n9,supported).
node(n547,unknown) :- \+ node(n547,supported), \+ node(n547,refuted).
verdict(c_8aa0734e988201da,supported) :- node(n547,supported).
query(verdict(c_8aa0734e988201da,supported)).
verdict(c_8aa0734e988201da,refuted) :- node(n547,refuted).
query(verdict(c_8aa0734e988201da,refuted)).
verdict(c_8aa0734e988201da,unknown) :- node(n547,unknown).
query(verdict(c_8aa0734e988201da,unknown)).
node(n558,supported) :- status(o_cf7be680b6e981bfd1b7,supported).
node(n558,refuted) :- status(o_cf7be680b6e981bfd1b7,refuted).
node(n558,unknown) :- status(o_cf7be680b6e981bfd1b7,unknown).
node(n559,supported) :- status(o_5b1c5ead063a9de38e81,supported).
node(n559,refuted) :- status(o_5b1c5ead063a9de38e81,refuted).
node(n559,unknown) :- status(o_5b1c5ead063a9de38e81,unknown).
node(n560,supported) :- status(o_def7f101e71a79c773f6,supported).
node(n560,refuted) :- status(o_def7f101e71a79c773f6,refuted).
node(n560,unknown) :- status(o_def7f101e71a79c773f6,unknown).
node(n561,supported) :- status(o_075ed942a82e2b7cd60a,supported).
node(n561,refuted) :- status(o_075ed942a82e2b7cd60a,refuted).
node(n561,unknown) :- status(o_075ed942a82e2b7cd60a,unknown).
node(n557,supported) :- node(n558,supported), node(n559,supported), node(n560,supported), node(n561,supported).
node(n557,refuted) :- node(n558,refuted).
node(n557,refuted) :- node(n559,refuted).
node(n557,refuted) :- node(n560,refuted).
node(n557,refuted) :- node(n561,refuted).
node(n557,unknown) :- \+ node(n557,supported), \+ node(n557,refuted).
node(n563,supported) :- status(o_738ccd3eda1589953570,supported).
node(n563,refuted) :- status(o_738ccd3eda1589953570,refuted).
node(n563,unknown) :- status(o_738ccd3eda1589953570,unknown).
node(n564,supported) :- status(o_603df3755828951766b4,supported).
node(n564,refuted) :- status(o_603df3755828951766b4,refuted).
node(n564,unknown) :- status(o_603df3755828951766b4,unknown).
node(n565,supported) :- status(o_9d6fc4c759caefac4372,supported).
node(n565,refuted) :- status(o_9d6fc4c759caefac4372,refuted).
node(n565,unknown) :- status(o_9d6fc4c759caefac4372,unknown).
node(n566,supported) :- status(o_9fa6303f729eba60fa01,supported).
node(n566,refuted) :- status(o_9fa6303f729eba60fa01,refuted).
node(n566,unknown) :- status(o_9fa6303f729eba60fa01,unknown).
node(n562,supported) :- node(n563,supported), node(n564,supported), node(n565,supported), node(n566,supported).
node(n562,refuted) :- node(n563,refuted).
node(n562,refuted) :- node(n564,refuted).
node(n562,refuted) :- node(n565,refuted).
node(n562,refuted) :- node(n566,refuted).
node(n562,unknown) :- \+ node(n562,supported), \+ node(n562,refuted).
node(n556,refuted) :- node(n557,refuted), node(n562,refuted), node(n9,refuted).
node(n556,supported) :- node(n557,supported).
node(n556,supported) :- node(n562,supported).
node(n556,supported) :- node(n9,supported).
node(n556,unknown) :- \+ node(n556,supported), \+ node(n556,refuted).
verdict(c_08c5bf5eef03db10,supported) :- node(n556,supported).
query(verdict(c_08c5bf5eef03db10,supported)).
verdict(c_08c5bf5eef03db10,refuted) :- node(n556,refuted).
query(verdict(c_08c5bf5eef03db10,refuted)).
verdict(c_08c5bf5eef03db10,unknown) :- node(n556,unknown).
query(verdict(c_08c5bf5eef03db10,unknown)).
node(n569,supported) :- status(o_e401cb98da497c54b540,supported).
node(n569,refuted) :- status(o_e401cb98da497c54b540,refuted).
node(n569,unknown) :- status(o_e401cb98da497c54b540,unknown).
node(n570,supported) :- status(o_8dda71046579a5984946,supported).
node(n570,refuted) :- status(o_8dda71046579a5984946,refuted).
node(n570,unknown) :- status(o_8dda71046579a5984946,unknown).
node(n571,supported) :- status(o_1faf9c1d9f85fc16afe1,supported).
node(n571,refuted) :- status(o_1faf9c1d9f85fc16afe1,refuted).
node(n571,unknown) :- status(o_1faf9c1d9f85fc16afe1,unknown).
node(n572,supported) :- status(o_091dfef35f2ba6af6b62,supported).
node(n572,refuted) :- status(o_091dfef35f2ba6af6b62,refuted).
node(n572,unknown) :- status(o_091dfef35f2ba6af6b62,unknown).
node(n568,supported) :- node(n569,supported), node(n570,supported), node(n571,supported), node(n572,supported).
node(n568,refuted) :- node(n569,refuted).
node(n568,refuted) :- node(n570,refuted).
node(n568,refuted) :- node(n571,refuted).
node(n568,refuted) :- node(n572,refuted).
node(n568,unknown) :- \+ node(n568,supported), \+ node(n568,refuted).
node(n574,supported) :- status(o_e7178f8dafa28fe4c533,supported).
node(n574,refuted) :- status(o_e7178f8dafa28fe4c533,refuted).
node(n574,unknown) :- status(o_e7178f8dafa28fe4c533,unknown).
node(n575,supported) :- status(o_00e84f3386f7981d363a,supported).
node(n575,refuted) :- status(o_00e84f3386f7981d363a,refuted).
node(n575,unknown) :- status(o_00e84f3386f7981d363a,unknown).
node(n576,supported) :- status(o_41dcd0301333256f9c17,supported).
node(n576,refuted) :- status(o_41dcd0301333256f9c17,refuted).
node(n576,unknown) :- status(o_41dcd0301333256f9c17,unknown).
node(n577,supported) :- status(o_fb87b37ebbb68166c26b,supported).
node(n577,refuted) :- status(o_fb87b37ebbb68166c26b,refuted).
node(n577,unknown) :- status(o_fb87b37ebbb68166c26b,unknown).
node(n573,supported) :- node(n574,supported), node(n575,supported), node(n576,supported), node(n577,supported).
node(n573,refuted) :- node(n574,refuted).
node(n573,refuted) :- node(n575,refuted).
node(n573,refuted) :- node(n576,refuted).
node(n573,refuted) :- node(n577,refuted).
node(n573,unknown) :- \+ node(n573,supported), \+ node(n573,refuted).
node(n567,refuted) :- node(n568,refuted), node(n573,refuted), node(n9,refuted).
node(n567,supported) :- node(n568,supported).
node(n567,supported) :- node(n573,supported).
node(n567,supported) :- node(n9,supported).
node(n567,unknown) :- \+ node(n567,supported), \+ node(n567,refuted).
verdict(c_b5ba136f3bc12ce3,supported) :- node(n567,supported).
query(verdict(c_b5ba136f3bc12ce3,supported)).
verdict(c_b5ba136f3bc12ce3,refuted) :- node(n567,refuted).
query(verdict(c_b5ba136f3bc12ce3,refuted)).
verdict(c_b5ba136f3bc12ce3,unknown) :- node(n567,unknown).
query(verdict(c_b5ba136f3bc12ce3,unknown)).
node(n580,supported) :- status(o_49d63036c03f2ea9c01d,supported).
node(n580,refuted) :- status(o_49d63036c03f2ea9c01d,refuted).
node(n580,unknown) :- status(o_49d63036c03f2ea9c01d,unknown).
node(n581,supported) :- status(o_312a1b5d49b5c7ea650b,supported).
node(n581,refuted) :- status(o_312a1b5d49b5c7ea650b,refuted).
node(n581,unknown) :- status(o_312a1b5d49b5c7ea650b,unknown).
node(n582,supported) :- status(o_35bdd255c7d8e6493ebc,supported).
node(n582,refuted) :- status(o_35bdd255c7d8e6493ebc,refuted).
node(n582,unknown) :- status(o_35bdd255c7d8e6493ebc,unknown).
node(n583,supported) :- status(o_10941fe54afdc04955f5,supported).
node(n583,refuted) :- status(o_10941fe54afdc04955f5,refuted).
node(n583,unknown) :- status(o_10941fe54afdc04955f5,unknown).
node(n579,supported) :- node(n580,supported), node(n581,supported), node(n582,supported), node(n583,supported).
node(n579,refuted) :- node(n580,refuted).
node(n579,refuted) :- node(n581,refuted).
node(n579,refuted) :- node(n582,refuted).
node(n579,refuted) :- node(n583,refuted).
node(n579,unknown) :- \+ node(n579,supported), \+ node(n579,refuted).
node(n585,supported) :- status(o_c785fad72da6e6e289a2,supported).
node(n585,refuted) :- status(o_c785fad72da6e6e289a2,refuted).
node(n585,unknown) :- status(o_c785fad72da6e6e289a2,unknown).
node(n586,supported) :- status(o_1b3f0defcf3f665388d3,supported).
node(n586,refuted) :- status(o_1b3f0defcf3f665388d3,refuted).
node(n586,unknown) :- status(o_1b3f0defcf3f665388d3,unknown).
node(n587,supported) :- status(o_2c907980377dc80dd271,supported).
node(n587,refuted) :- status(o_2c907980377dc80dd271,refuted).
node(n587,unknown) :- status(o_2c907980377dc80dd271,unknown).
node(n588,supported) :- status(o_1ec64f2af1c6804f1204,supported).
node(n588,refuted) :- status(o_1ec64f2af1c6804f1204,refuted).
node(n588,unknown) :- status(o_1ec64f2af1c6804f1204,unknown).
node(n584,supported) :- node(n585,supported), node(n586,supported), node(n587,supported), node(n588,supported).
node(n584,refuted) :- node(n585,refuted).
node(n584,refuted) :- node(n586,refuted).
node(n584,refuted) :- node(n587,refuted).
node(n584,refuted) :- node(n588,refuted).
node(n584,unknown) :- \+ node(n584,supported), \+ node(n584,refuted).
node(n578,refuted) :- node(n579,refuted), node(n584,refuted), node(n9,refuted).
node(n578,supported) :- node(n579,supported).
node(n578,supported) :- node(n584,supported).
node(n578,supported) :- node(n9,supported).
node(n578,unknown) :- \+ node(n578,supported), \+ node(n578,refuted).
verdict(c_697044ff0f463ca3,supported) :- node(n578,supported).
query(verdict(c_697044ff0f463ca3,supported)).
verdict(c_697044ff0f463ca3,refuted) :- node(n578,refuted).
query(verdict(c_697044ff0f463ca3,refuted)).
verdict(c_697044ff0f463ca3,unknown) :- node(n578,unknown).
query(verdict(c_697044ff0f463ca3,unknown)).
node(n591,supported) :- status(o_6693bc2edd43f7265d16,supported).
node(n591,refuted) :- status(o_6693bc2edd43f7265d16,refuted).
node(n591,unknown) :- status(o_6693bc2edd43f7265d16,unknown).
node(n592,supported) :- status(o_78f1772efe2839a0bdda,supported).
node(n592,refuted) :- status(o_78f1772efe2839a0bdda,refuted).
node(n592,unknown) :- status(o_78f1772efe2839a0bdda,unknown).
node(n593,supported) :- status(o_efd29a5eabe112b90c9a,supported).
node(n593,refuted) :- status(o_efd29a5eabe112b90c9a,refuted).
node(n593,unknown) :- status(o_efd29a5eabe112b90c9a,unknown).
node(n590,supported) :- node(n591,supported), node(n592,supported), node(n593,supported).
node(n590,refuted) :- node(n591,refuted).
node(n590,refuted) :- node(n592,refuted).
node(n590,refuted) :- node(n593,refuted).
node(n590,unknown) :- \+ node(n590,supported), \+ node(n590,refuted).
node(n595,supported) :- status(o_f5bb319e4baf66ce7931,supported).
node(n595,refuted) :- status(o_f5bb319e4baf66ce7931,refuted).
node(n595,unknown) :- status(o_f5bb319e4baf66ce7931,unknown).
node(n596,supported) :- status(o_af720b627e3797e31111,supported).
node(n596,refuted) :- status(o_af720b627e3797e31111,refuted).
node(n596,unknown) :- status(o_af720b627e3797e31111,unknown).
node(n597,supported) :- status(o_eadb337b974322e3e19c,supported).
node(n597,refuted) :- status(o_eadb337b974322e3e19c,refuted).
node(n597,unknown) :- status(o_eadb337b974322e3e19c,unknown).
node(n594,supported) :- node(n595,supported), node(n596,supported), node(n597,supported).
node(n594,refuted) :- node(n595,refuted).
node(n594,refuted) :- node(n596,refuted).
node(n594,refuted) :- node(n597,refuted).
node(n594,unknown) :- \+ node(n594,supported), \+ node(n594,refuted).
node(n589,refuted) :- node(n590,refuted), node(n594,refuted), node(n9,refuted).
node(n589,supported) :- node(n590,supported).
node(n589,supported) :- node(n594,supported).
node(n589,supported) :- node(n9,supported).
node(n589,unknown) :- \+ node(n589,supported), \+ node(n589,refuted).
verdict(c_60ac5050d29335b2,supported) :- node(n589,supported).
query(verdict(c_60ac5050d29335b2,supported)).
verdict(c_60ac5050d29335b2,refuted) :- node(n589,refuted).
query(verdict(c_60ac5050d29335b2,refuted)).
verdict(c_60ac5050d29335b2,unknown) :- node(n589,unknown).
query(verdict(c_60ac5050d29335b2,unknown)).
node(n600,supported) :- status(o_63e4d40fec225bbdd7f6,supported).
node(n600,refuted) :- status(o_63e4d40fec225bbdd7f6,refuted).
node(n600,unknown) :- status(o_63e4d40fec225bbdd7f6,unknown).
node(n601,supported) :- status(o_7fbfd2423099a0b8b1d3,supported).
node(n601,refuted) :- status(o_7fbfd2423099a0b8b1d3,refuted).
node(n601,unknown) :- status(o_7fbfd2423099a0b8b1d3,unknown).
node(n602,supported) :- status(o_d00e00d25b5fc9e8b8ef,supported).
node(n602,refuted) :- status(o_d00e00d25b5fc9e8b8ef,refuted).
node(n602,unknown) :- status(o_d00e00d25b5fc9e8b8ef,unknown).
node(n603,supported) :- status(o_fb6f996261eb642f0e77,supported).
node(n603,refuted) :- status(o_fb6f996261eb642f0e77,refuted).
node(n603,unknown) :- status(o_fb6f996261eb642f0e77,unknown).
node(n599,supported) :- node(n600,supported), node(n601,supported), node(n602,supported), node(n603,supported).
node(n599,refuted) :- node(n600,refuted).
node(n599,refuted) :- node(n601,refuted).
node(n599,refuted) :- node(n602,refuted).
node(n599,refuted) :- node(n603,refuted).
node(n599,unknown) :- \+ node(n599,supported), \+ node(n599,refuted).
node(n605,supported) :- status(o_9308c92fbe649babffc9,supported).
node(n605,refuted) :- status(o_9308c92fbe649babffc9,refuted).
node(n605,unknown) :- status(o_9308c92fbe649babffc9,unknown).
node(n606,supported) :- status(o_1066fcea5c37414e3c57,supported).
node(n606,refuted) :- status(o_1066fcea5c37414e3c57,refuted).
node(n606,unknown) :- status(o_1066fcea5c37414e3c57,unknown).
node(n607,supported) :- status(o_e99d4fb0ee9312c90292,supported).
node(n607,refuted) :- status(o_e99d4fb0ee9312c90292,refuted).
node(n607,unknown) :- status(o_e99d4fb0ee9312c90292,unknown).
node(n608,supported) :- status(o_614a2e4050aa71f8b651,supported).
node(n608,refuted) :- status(o_614a2e4050aa71f8b651,refuted).
node(n608,unknown) :- status(o_614a2e4050aa71f8b651,unknown).
node(n604,supported) :- node(n605,supported), node(n606,supported), node(n607,supported), node(n608,supported).
node(n604,refuted) :- node(n605,refuted).
node(n604,refuted) :- node(n606,refuted).
node(n604,refuted) :- node(n607,refuted).
node(n604,refuted) :- node(n608,refuted).
node(n604,unknown) :- \+ node(n604,supported), \+ node(n604,refuted).
node(n598,refuted) :- node(n599,refuted), node(n604,refuted), node(n9,refuted).
node(n598,supported) :- node(n599,supported).
node(n598,supported) :- node(n604,supported).
node(n598,supported) :- node(n9,supported).
node(n598,unknown) :- \+ node(n598,supported), \+ node(n598,refuted).
verdict(c_ea872825eab36b7a,supported) :- node(n598,supported).
query(verdict(c_ea872825eab36b7a,supported)).
verdict(c_ea872825eab36b7a,refuted) :- node(n598,refuted).
query(verdict(c_ea872825eab36b7a,refuted)).
verdict(c_ea872825eab36b7a,unknown) :- node(n598,unknown).
query(verdict(c_ea872825eab36b7a,unknown)).
node(n611,supported) :- status(o_3b5844f19691a227b6d7,supported).
node(n611,refuted) :- status(o_3b5844f19691a227b6d7,refuted).
node(n611,unknown) :- status(o_3b5844f19691a227b6d7,unknown).
node(n612,supported) :- status(o_ec4310698b6582d7f82f,supported).
node(n612,refuted) :- status(o_ec4310698b6582d7f82f,refuted).
node(n612,unknown) :- status(o_ec4310698b6582d7f82f,unknown).
node(n613,supported) :- status(o_e0817f737b36fd62f919,supported).
node(n613,refuted) :- status(o_e0817f737b36fd62f919,refuted).
node(n613,unknown) :- status(o_e0817f737b36fd62f919,unknown).
node(n614,supported) :- status(o_d72e1fe86f761463c965,supported).
node(n614,refuted) :- status(o_d72e1fe86f761463c965,refuted).
node(n614,unknown) :- status(o_d72e1fe86f761463c965,unknown).
node(n610,supported) :- node(n611,supported), node(n612,supported), node(n613,supported), node(n614,supported).
node(n610,refuted) :- node(n611,refuted).
node(n610,refuted) :- node(n612,refuted).
node(n610,refuted) :- node(n613,refuted).
node(n610,refuted) :- node(n614,refuted).
node(n610,unknown) :- \+ node(n610,supported), \+ node(n610,refuted).
node(n616,supported) :- status(o_631faac8fffc60050255,supported).
node(n616,refuted) :- status(o_631faac8fffc60050255,refuted).
node(n616,unknown) :- status(o_631faac8fffc60050255,unknown).
node(n617,supported) :- status(o_ee16e8e7f9a44f1f4df7,supported).
node(n617,refuted) :- status(o_ee16e8e7f9a44f1f4df7,refuted).
node(n617,unknown) :- status(o_ee16e8e7f9a44f1f4df7,unknown).
node(n618,supported) :- status(o_d6365bc28b33fd46d85a,supported).
node(n618,refuted) :- status(o_d6365bc28b33fd46d85a,refuted).
node(n618,unknown) :- status(o_d6365bc28b33fd46d85a,unknown).
node(n619,supported) :- status(o_1d378b9fe764c3a2032c,supported).
node(n619,refuted) :- status(o_1d378b9fe764c3a2032c,refuted).
node(n619,unknown) :- status(o_1d378b9fe764c3a2032c,unknown).
node(n615,supported) :- node(n616,supported), node(n617,supported), node(n618,supported), node(n619,supported).
node(n615,refuted) :- node(n616,refuted).
node(n615,refuted) :- node(n617,refuted).
node(n615,refuted) :- node(n618,refuted).
node(n615,refuted) :- node(n619,refuted).
node(n615,unknown) :- \+ node(n615,supported), \+ node(n615,refuted).
node(n609,refuted) :- node(n610,refuted), node(n615,refuted), node(n9,refuted).
node(n609,supported) :- node(n610,supported).
node(n609,supported) :- node(n615,supported).
node(n609,supported) :- node(n9,supported).
node(n609,unknown) :- \+ node(n609,supported), \+ node(n609,refuted).
verdict(c_e6eefdf8246c1396,supported) :- node(n609,supported).
query(verdict(c_e6eefdf8246c1396,supported)).
verdict(c_e6eefdf8246c1396,refuted) :- node(n609,refuted).
query(verdict(c_e6eefdf8246c1396,refuted)).
verdict(c_e6eefdf8246c1396,unknown) :- node(n609,unknown).
query(verdict(c_e6eefdf8246c1396,unknown)).
node(n622,supported) :- status(o_2835776e8debb4d2072c,supported).
node(n622,refuted) :- status(o_2835776e8debb4d2072c,refuted).
node(n622,unknown) :- status(o_2835776e8debb4d2072c,unknown).
node(n623,supported) :- status(o_93aec2bf909c2b85cc0e,supported).
node(n623,refuted) :- status(o_93aec2bf909c2b85cc0e,refuted).
node(n623,unknown) :- status(o_93aec2bf909c2b85cc0e,unknown).
node(n624,supported) :- status(o_17d1744f7d1b60deb409,supported).
node(n624,refuted) :- status(o_17d1744f7d1b60deb409,refuted).
node(n624,unknown) :- status(o_17d1744f7d1b60deb409,unknown).
node(n625,supported) :- status(o_40ef598178534c9f3e41,supported).
node(n625,refuted) :- status(o_40ef598178534c9f3e41,refuted).
node(n625,unknown) :- status(o_40ef598178534c9f3e41,unknown).
node(n621,supported) :- node(n622,supported), node(n623,supported), node(n624,supported), node(n625,supported).
node(n621,refuted) :- node(n622,refuted).
node(n621,refuted) :- node(n623,refuted).
node(n621,refuted) :- node(n624,refuted).
node(n621,refuted) :- node(n625,refuted).
node(n621,unknown) :- \+ node(n621,supported), \+ node(n621,refuted).
node(n627,supported) :- status(o_bcb953009455804af474,supported).
node(n627,refuted) :- status(o_bcb953009455804af474,refuted).
node(n627,unknown) :- status(o_bcb953009455804af474,unknown).
node(n628,supported) :- status(o_8796ccec6b5d882b08bc,supported).
node(n628,refuted) :- status(o_8796ccec6b5d882b08bc,refuted).
node(n628,unknown) :- status(o_8796ccec6b5d882b08bc,unknown).
node(n629,supported) :- status(o_d6a53790183477eec59a,supported).
node(n629,refuted) :- status(o_d6a53790183477eec59a,refuted).
node(n629,unknown) :- status(o_d6a53790183477eec59a,unknown).
node(n630,supported) :- status(o_53e72aba9c4e4d16ce2b,supported).
node(n630,refuted) :- status(o_53e72aba9c4e4d16ce2b,refuted).
node(n630,unknown) :- status(o_53e72aba9c4e4d16ce2b,unknown).
node(n626,supported) :- node(n627,supported), node(n628,supported), node(n629,supported), node(n630,supported).
node(n626,refuted) :- node(n627,refuted).
node(n626,refuted) :- node(n628,refuted).
node(n626,refuted) :- node(n629,refuted).
node(n626,refuted) :- node(n630,refuted).
node(n626,unknown) :- \+ node(n626,supported), \+ node(n626,refuted).
node(n620,refuted) :- node(n621,refuted), node(n626,refuted), node(n9,refuted).
node(n620,supported) :- node(n621,supported).
node(n620,supported) :- node(n626,supported).
node(n620,supported) :- node(n9,supported).
node(n620,unknown) :- \+ node(n620,supported), \+ node(n620,refuted).
verdict(c_be927c41aa1a4515,supported) :- node(n620,supported).
query(verdict(c_be927c41aa1a4515,supported)).
verdict(c_be927c41aa1a4515,refuted) :- node(n620,refuted).
query(verdict(c_be927c41aa1a4515,refuted)).
verdict(c_be927c41aa1a4515,unknown) :- node(n620,unknown).
query(verdict(c_be927c41aa1a4515,unknown)).
node(n633,supported) :- status(o_c854dccb8bffecafac3d,supported).
node(n633,refuted) :- status(o_c854dccb8bffecafac3d,refuted).
node(n633,unknown) :- status(o_c854dccb8bffecafac3d,unknown).
node(n634,supported) :- status(o_a9867d1ffb9e349e0ec1,supported).
node(n634,refuted) :- status(o_a9867d1ffb9e349e0ec1,refuted).
node(n634,unknown) :- status(o_a9867d1ffb9e349e0ec1,unknown).
node(n635,supported) :- status(o_4e59e16fcf14adef2198,supported).
node(n635,refuted) :- status(o_4e59e16fcf14adef2198,refuted).
node(n635,unknown) :- status(o_4e59e16fcf14adef2198,unknown).
node(n632,supported) :- node(n633,supported), node(n634,supported), node(n635,supported).
node(n632,refuted) :- node(n633,refuted).
node(n632,refuted) :- node(n634,refuted).
node(n632,refuted) :- node(n635,refuted).
node(n632,unknown) :- \+ node(n632,supported), \+ node(n632,refuted).
node(n637,supported) :- status(o_08cded7ba7857446182b,supported).
node(n637,refuted) :- status(o_08cded7ba7857446182b,refuted).
node(n637,unknown) :- status(o_08cded7ba7857446182b,unknown).
node(n638,supported) :- status(o_8e90bb945df5d8f95add,supported).
node(n638,refuted) :- status(o_8e90bb945df5d8f95add,refuted).
node(n638,unknown) :- status(o_8e90bb945df5d8f95add,unknown).
node(n639,supported) :- status(o_aa3c4ebc6b2466fcd72c,supported).
node(n639,refuted) :- status(o_aa3c4ebc6b2466fcd72c,refuted).
node(n639,unknown) :- status(o_aa3c4ebc6b2466fcd72c,unknown).
node(n636,supported) :- node(n637,supported), node(n638,supported), node(n639,supported).
node(n636,refuted) :- node(n637,refuted).
node(n636,refuted) :- node(n638,refuted).
node(n636,refuted) :- node(n639,refuted).
node(n636,unknown) :- \+ node(n636,supported), \+ node(n636,refuted).
node(n631,refuted) :- node(n632,refuted), node(n636,refuted), node(n9,refuted).
node(n631,supported) :- node(n632,supported).
node(n631,supported) :- node(n636,supported).
node(n631,supported) :- node(n9,supported).
node(n631,unknown) :- \+ node(n631,supported), \+ node(n631,refuted).
verdict(c_2f9aa51d5e249e66,supported) :- node(n631,supported).
query(verdict(c_2f9aa51d5e249e66,supported)).
verdict(c_2f9aa51d5e249e66,refuted) :- node(n631,refuted).
query(verdict(c_2f9aa51d5e249e66,refuted)).
verdict(c_2f9aa51d5e249e66,unknown) :- node(n631,unknown).
query(verdict(c_2f9aa51d5e249e66,unknown)).
node(n642,supported) :- status(o_e6686e4cb2652f37c92a,supported).
node(n642,refuted) :- status(o_e6686e4cb2652f37c92a,refuted).
node(n642,unknown) :- status(o_e6686e4cb2652f37c92a,unknown).
node(n643,supported) :- status(o_38f040d734b29475c9db,supported).
node(n643,refuted) :- status(o_38f040d734b29475c9db,refuted).
node(n643,unknown) :- status(o_38f040d734b29475c9db,unknown).
node(n644,supported) :- status(o_427e112beaab682e2bef,supported).
node(n644,refuted) :- status(o_427e112beaab682e2bef,refuted).
node(n644,unknown) :- status(o_427e112beaab682e2bef,unknown).
node(n645,supported) :- status(o_bae505cc4e849e95360b,supported).
node(n645,refuted) :- status(o_bae505cc4e849e95360b,refuted).
node(n645,unknown) :- status(o_bae505cc4e849e95360b,unknown).
node(n641,supported) :- node(n642,supported), node(n643,supported), node(n644,supported), node(n645,supported).
node(n641,refuted) :- node(n642,refuted).
node(n641,refuted) :- node(n643,refuted).
node(n641,refuted) :- node(n644,refuted).
node(n641,refuted) :- node(n645,refuted).
node(n641,unknown) :- \+ node(n641,supported), \+ node(n641,refuted).
node(n647,supported) :- status(o_3d1614558427c82424f2,supported).
node(n647,refuted) :- status(o_3d1614558427c82424f2,refuted).
node(n647,unknown) :- status(o_3d1614558427c82424f2,unknown).
node(n648,supported) :- status(o_5ed1283dceb9c6ec2527,supported).
node(n648,refuted) :- status(o_5ed1283dceb9c6ec2527,refuted).
node(n648,unknown) :- status(o_5ed1283dceb9c6ec2527,unknown).
node(n649,supported) :- status(o_6d74fd641a4e40c96bf1,supported).
node(n649,refuted) :- status(o_6d74fd641a4e40c96bf1,refuted).
node(n649,unknown) :- status(o_6d74fd641a4e40c96bf1,unknown).
node(n650,supported) :- status(o_477adf5909e07fbf041c,supported).
node(n650,refuted) :- status(o_477adf5909e07fbf041c,refuted).
node(n650,unknown) :- status(o_477adf5909e07fbf041c,unknown).
node(n646,supported) :- node(n647,supported), node(n648,supported), node(n649,supported), node(n650,supported).
node(n646,refuted) :- node(n647,refuted).
node(n646,refuted) :- node(n648,refuted).
node(n646,refuted) :- node(n649,refuted).
node(n646,refuted) :- node(n650,refuted).
node(n646,unknown) :- \+ node(n646,supported), \+ node(n646,refuted).
node(n640,refuted) :- node(n641,refuted), node(n646,refuted), node(n9,refuted).
node(n640,supported) :- node(n641,supported).
node(n640,supported) :- node(n646,supported).
node(n640,supported) :- node(n9,supported).
node(n640,unknown) :- \+ node(n640,supported), \+ node(n640,refuted).
verdict(c_55cb3d6d40d7b302,supported) :- node(n640,supported).
query(verdict(c_55cb3d6d40d7b302,supported)).
verdict(c_55cb3d6d40d7b302,refuted) :- node(n640,refuted).
query(verdict(c_55cb3d6d40d7b302,refuted)).
verdict(c_55cb3d6d40d7b302,unknown) :- node(n640,unknown).
query(verdict(c_55cb3d6d40d7b302,unknown)).
node(n653,supported) :- status(o_9f9ccc87bfb7a5ce1444,supported).
node(n653,refuted) :- status(o_9f9ccc87bfb7a5ce1444,refuted).
node(n653,unknown) :- status(o_9f9ccc87bfb7a5ce1444,unknown).
node(n654,supported) :- status(o_bdbfb324f758561b2103,supported).
node(n654,refuted) :- status(o_bdbfb324f758561b2103,refuted).
node(n654,unknown) :- status(o_bdbfb324f758561b2103,unknown).
node(n655,supported) :- status(o_103c13e684d1509163ce,supported).
node(n655,refuted) :- status(o_103c13e684d1509163ce,refuted).
node(n655,unknown) :- status(o_103c13e684d1509163ce,unknown).
node(n656,supported) :- status(o_15c1e274791c21dc484c,supported).
node(n656,refuted) :- status(o_15c1e274791c21dc484c,refuted).
node(n656,unknown) :- status(o_15c1e274791c21dc484c,unknown).
node(n652,supported) :- node(n653,supported), node(n654,supported), node(n655,supported), node(n656,supported).
node(n652,refuted) :- node(n653,refuted).
node(n652,refuted) :- node(n654,refuted).
node(n652,refuted) :- node(n655,refuted).
node(n652,refuted) :- node(n656,refuted).
node(n652,unknown) :- \+ node(n652,supported), \+ node(n652,refuted).
node(n658,supported) :- status(o_889291a73b03266f4686,supported).
node(n658,refuted) :- status(o_889291a73b03266f4686,refuted).
node(n658,unknown) :- status(o_889291a73b03266f4686,unknown).
node(n659,supported) :- status(o_b91e0467309db80f5f8a,supported).
node(n659,refuted) :- status(o_b91e0467309db80f5f8a,refuted).
node(n659,unknown) :- status(o_b91e0467309db80f5f8a,unknown).
node(n660,supported) :- status(o_9d4779f493d34cfffc84,supported).
node(n660,refuted) :- status(o_9d4779f493d34cfffc84,refuted).
node(n660,unknown) :- status(o_9d4779f493d34cfffc84,unknown).
node(n661,supported) :- status(o_bbdc1bedf1bbde6367b3,supported).
node(n661,refuted) :- status(o_bbdc1bedf1bbde6367b3,refuted).
node(n661,unknown) :- status(o_bbdc1bedf1bbde6367b3,unknown).
node(n657,supported) :- node(n658,supported), node(n659,supported), node(n660,supported), node(n661,supported).
node(n657,refuted) :- node(n658,refuted).
node(n657,refuted) :- node(n659,refuted).
node(n657,refuted) :- node(n660,refuted).
node(n657,refuted) :- node(n661,refuted).
node(n657,unknown) :- \+ node(n657,supported), \+ node(n657,refuted).
node(n651,refuted) :- node(n652,refuted), node(n657,refuted), node(n9,refuted).
node(n651,supported) :- node(n652,supported).
node(n651,supported) :- node(n657,supported).
node(n651,supported) :- node(n9,supported).
node(n651,unknown) :- \+ node(n651,supported), \+ node(n651,refuted).
verdict(c_9d64c941d14eb47a,supported) :- node(n651,supported).
query(verdict(c_9d64c941d14eb47a,supported)).
verdict(c_9d64c941d14eb47a,refuted) :- node(n651,refuted).
query(verdict(c_9d64c941d14eb47a,refuted)).
verdict(c_9d64c941d14eb47a,unknown) :- node(n651,unknown).
query(verdict(c_9d64c941d14eb47a,unknown)).
node(n664,supported) :- status(o_c57419beb55216697801,supported).
node(n664,refuted) :- status(o_c57419beb55216697801,refuted).
node(n664,unknown) :- status(o_c57419beb55216697801,unknown).
node(n665,supported) :- status(o_c2b59cde7f58169d5785,supported).
node(n665,refuted) :- status(o_c2b59cde7f58169d5785,refuted).
node(n665,unknown) :- status(o_c2b59cde7f58169d5785,unknown).
node(n666,supported) :- status(o_1b6372b3d5e324e108ce,supported).
node(n666,refuted) :- status(o_1b6372b3d5e324e108ce,refuted).
node(n666,unknown) :- status(o_1b6372b3d5e324e108ce,unknown).
node(n667,supported) :- status(o_7e11955a4bef5f562a66,supported).
node(n667,refuted) :- status(o_7e11955a4bef5f562a66,refuted).
node(n667,unknown) :- status(o_7e11955a4bef5f562a66,unknown).
node(n663,supported) :- node(n664,supported), node(n665,supported), node(n666,supported), node(n667,supported).
node(n663,refuted) :- node(n664,refuted).
node(n663,refuted) :- node(n665,refuted).
node(n663,refuted) :- node(n666,refuted).
node(n663,refuted) :- node(n667,refuted).
node(n663,unknown) :- \+ node(n663,supported), \+ node(n663,refuted).
node(n669,supported) :- status(o_814499a0b2d441249e2f,supported).
node(n669,refuted) :- status(o_814499a0b2d441249e2f,refuted).
node(n669,unknown) :- status(o_814499a0b2d441249e2f,unknown).
node(n670,supported) :- status(o_3068351bd4071d37339b,supported).
node(n670,refuted) :- status(o_3068351bd4071d37339b,refuted).
node(n670,unknown) :- status(o_3068351bd4071d37339b,unknown).
node(n671,supported) :- status(o_6b40e9cdc337a99ac6fa,supported).
node(n671,refuted) :- status(o_6b40e9cdc337a99ac6fa,refuted).
node(n671,unknown) :- status(o_6b40e9cdc337a99ac6fa,unknown).
node(n672,supported) :- status(o_267c83da7744704da392,supported).
node(n672,refuted) :- status(o_267c83da7744704da392,refuted).
node(n672,unknown) :- status(o_267c83da7744704da392,unknown).
node(n668,supported) :- node(n669,supported), node(n670,supported), node(n671,supported), node(n672,supported).
node(n668,refuted) :- node(n669,refuted).
node(n668,refuted) :- node(n670,refuted).
node(n668,refuted) :- node(n671,refuted).
node(n668,refuted) :- node(n672,refuted).
node(n668,unknown) :- \+ node(n668,supported), \+ node(n668,refuted).
node(n662,refuted) :- node(n663,refuted), node(n668,refuted), node(n9,refuted).
node(n662,supported) :- node(n663,supported).
node(n662,supported) :- node(n668,supported).
node(n662,supported) :- node(n9,supported).
node(n662,unknown) :- \+ node(n662,supported), \+ node(n662,refuted).
verdict(c_26424d55f93a6746,supported) :- node(n662,supported).
query(verdict(c_26424d55f93a6746,supported)).
verdict(c_26424d55f93a6746,refuted) :- node(n662,refuted).
query(verdict(c_26424d55f93a6746,refuted)).
verdict(c_26424d55f93a6746,unknown) :- node(n662,unknown).
query(verdict(c_26424d55f93a6746,unknown)).
node(n675,supported) :- status(o_0dc24c3f760494fb2fb7,supported).
node(n675,refuted) :- status(o_0dc24c3f760494fb2fb7,refuted).
node(n675,unknown) :- status(o_0dc24c3f760494fb2fb7,unknown).
node(n676,supported) :- status(o_370d3ca55a3582cead47,supported).
node(n676,refuted) :- status(o_370d3ca55a3582cead47,refuted).
node(n676,unknown) :- status(o_370d3ca55a3582cead47,unknown).
node(n677,supported) :- status(o_a2b443e44c3b9d1c0bca,supported).
node(n677,refuted) :- status(o_a2b443e44c3b9d1c0bca,refuted).
node(n677,unknown) :- status(o_a2b443e44c3b9d1c0bca,unknown).
node(n674,supported) :- node(n675,supported), node(n676,supported), node(n677,supported).
node(n674,refuted) :- node(n675,refuted).
node(n674,refuted) :- node(n676,refuted).
node(n674,refuted) :- node(n677,refuted).
node(n674,unknown) :- \+ node(n674,supported), \+ node(n674,refuted).
node(n679,supported) :- status(o_54e3178f782c9b6e55ef,supported).
node(n679,refuted) :- status(o_54e3178f782c9b6e55ef,refuted).
node(n679,unknown) :- status(o_54e3178f782c9b6e55ef,unknown).
node(n680,supported) :- status(o_f1787eb4c84a0ee42b1d,supported).
node(n680,refuted) :- status(o_f1787eb4c84a0ee42b1d,refuted).
node(n680,unknown) :- status(o_f1787eb4c84a0ee42b1d,unknown).
node(n681,supported) :- status(o_cd814323bb9f5a9fb831,supported).
node(n681,refuted) :- status(o_cd814323bb9f5a9fb831,refuted).
node(n681,unknown) :- status(o_cd814323bb9f5a9fb831,unknown).
node(n678,supported) :- node(n679,supported), node(n680,supported), node(n681,supported).
node(n678,refuted) :- node(n679,refuted).
node(n678,refuted) :- node(n680,refuted).
node(n678,refuted) :- node(n681,refuted).
node(n678,unknown) :- \+ node(n678,supported), \+ node(n678,refuted).
node(n673,refuted) :- node(n674,refuted), node(n678,refuted), node(n9,refuted).
node(n673,supported) :- node(n674,supported).
node(n673,supported) :- node(n678,supported).
node(n673,supported) :- node(n9,supported).
node(n673,unknown) :- \+ node(n673,supported), \+ node(n673,refuted).
verdict(c_4ce0b47ea7313258,supported) :- node(n673,supported).
query(verdict(c_4ce0b47ea7313258,supported)).
verdict(c_4ce0b47ea7313258,refuted) :- node(n673,refuted).
query(verdict(c_4ce0b47ea7313258,refuted)).
verdict(c_4ce0b47ea7313258,unknown) :- node(n673,unknown).
query(verdict(c_4ce0b47ea7313258,unknown)).
node(n684,supported) :- status(o_da44656b3ad7f5998173,supported).
node(n684,refuted) :- status(o_da44656b3ad7f5998173,refuted).
node(n684,unknown) :- status(o_da44656b3ad7f5998173,unknown).
node(n685,supported) :- status(o_e4b35d9d8d6d46c264c4,supported).
node(n685,refuted) :- status(o_e4b35d9d8d6d46c264c4,refuted).
node(n685,unknown) :- status(o_e4b35d9d8d6d46c264c4,unknown).
node(n686,supported) :- status(o_dab5ed08a19c05060028,supported).
node(n686,refuted) :- status(o_dab5ed08a19c05060028,refuted).
node(n686,unknown) :- status(o_dab5ed08a19c05060028,unknown).
node(n687,supported) :- status(o_87423769375bdb526643,supported).
node(n687,refuted) :- status(o_87423769375bdb526643,refuted).
node(n687,unknown) :- status(o_87423769375bdb526643,unknown).
node(n683,supported) :- node(n684,supported), node(n685,supported), node(n686,supported), node(n687,supported).
node(n683,refuted) :- node(n684,refuted).
node(n683,refuted) :- node(n685,refuted).
node(n683,refuted) :- node(n686,refuted).
node(n683,refuted) :- node(n687,refuted).
node(n683,unknown) :- \+ node(n683,supported), \+ node(n683,refuted).
node(n689,supported) :- status(o_505ac6a684a885ca2dc1,supported).
node(n689,refuted) :- status(o_505ac6a684a885ca2dc1,refuted).
node(n689,unknown) :- status(o_505ac6a684a885ca2dc1,unknown).
node(n690,supported) :- status(o_067b95cdf0df9fb8f0d6,supported).
node(n690,refuted) :- status(o_067b95cdf0df9fb8f0d6,refuted).
node(n690,unknown) :- status(o_067b95cdf0df9fb8f0d6,unknown).
node(n691,supported) :- status(o_33ec28b58faf21051d06,supported).
node(n691,refuted) :- status(o_33ec28b58faf21051d06,refuted).
node(n691,unknown) :- status(o_33ec28b58faf21051d06,unknown).
node(n692,supported) :- status(o_f5c2b5754d86991f607d,supported).
node(n692,refuted) :- status(o_f5c2b5754d86991f607d,refuted).
node(n692,unknown) :- status(o_f5c2b5754d86991f607d,unknown).
node(n688,supported) :- node(n689,supported), node(n690,supported), node(n691,supported), node(n692,supported).
node(n688,refuted) :- node(n689,refuted).
node(n688,refuted) :- node(n690,refuted).
node(n688,refuted) :- node(n691,refuted).
node(n688,refuted) :- node(n692,refuted).
node(n688,unknown) :- \+ node(n688,supported), \+ node(n688,refuted).
node(n682,refuted) :- node(n683,refuted), node(n688,refuted), node(n9,refuted).
node(n682,supported) :- node(n683,supported).
node(n682,supported) :- node(n688,supported).
node(n682,supported) :- node(n9,supported).
node(n682,unknown) :- \+ node(n682,supported), \+ node(n682,refuted).
verdict(c_4ddd68744453b073,supported) :- node(n682,supported).
query(verdict(c_4ddd68744453b073,supported)).
verdict(c_4ddd68744453b073,refuted) :- node(n682,refuted).
query(verdict(c_4ddd68744453b073,refuted)).
verdict(c_4ddd68744453b073,unknown) :- node(n682,unknown).
query(verdict(c_4ddd68744453b073,unknown)).
node(n695,supported) :- status(o_38225b5263fab48c5e08,supported).
node(n695,refuted) :- status(o_38225b5263fab48c5e08,refuted).
node(n695,unknown) :- status(o_38225b5263fab48c5e08,unknown).
node(n696,supported) :- status(o_6c62f248a5208cb56091,supported).
node(n696,refuted) :- status(o_6c62f248a5208cb56091,refuted).
node(n696,unknown) :- status(o_6c62f248a5208cb56091,unknown).
node(n697,supported) :- status(o_d8014b3822777dc37c7c,supported).
node(n697,refuted) :- status(o_d8014b3822777dc37c7c,refuted).
node(n697,unknown) :- status(o_d8014b3822777dc37c7c,unknown).
node(n698,supported) :- status(o_b42b949add243fc960da,supported).
node(n698,refuted) :- status(o_b42b949add243fc960da,refuted).
node(n698,unknown) :- status(o_b42b949add243fc960da,unknown).
node(n694,supported) :- node(n695,supported), node(n696,supported), node(n697,supported), node(n698,supported).
node(n694,refuted) :- node(n695,refuted).
node(n694,refuted) :- node(n696,refuted).
node(n694,refuted) :- node(n697,refuted).
node(n694,refuted) :- node(n698,refuted).
node(n694,unknown) :- \+ node(n694,supported), \+ node(n694,refuted).
node(n700,supported) :- status(o_d32f52ee0e593de63183,supported).
node(n700,refuted) :- status(o_d32f52ee0e593de63183,refuted).
node(n700,unknown) :- status(o_d32f52ee0e593de63183,unknown).
node(n701,supported) :- status(o_728b376e763b595b04d1,supported).
node(n701,refuted) :- status(o_728b376e763b595b04d1,refuted).
node(n701,unknown) :- status(o_728b376e763b595b04d1,unknown).
node(n702,supported) :- status(o_d3e8bddcf3fbf581b29b,supported).
node(n702,refuted) :- status(o_d3e8bddcf3fbf581b29b,refuted).
node(n702,unknown) :- status(o_d3e8bddcf3fbf581b29b,unknown).
node(n703,supported) :- status(o_d2127065c3ff98ba98b1,supported).
node(n703,refuted) :- status(o_d2127065c3ff98ba98b1,refuted).
node(n703,unknown) :- status(o_d2127065c3ff98ba98b1,unknown).
node(n699,supported) :- node(n700,supported), node(n701,supported), node(n702,supported), node(n703,supported).
node(n699,refuted) :- node(n700,refuted).
node(n699,refuted) :- node(n701,refuted).
node(n699,refuted) :- node(n702,refuted).
node(n699,refuted) :- node(n703,refuted).
node(n699,unknown) :- \+ node(n699,supported), \+ node(n699,refuted).
node(n693,refuted) :- node(n694,refuted), node(n699,refuted), node(n9,refuted).
node(n693,supported) :- node(n694,supported).
node(n693,supported) :- node(n699,supported).
node(n693,supported) :- node(n9,supported).
node(n693,unknown) :- \+ node(n693,supported), \+ node(n693,refuted).
verdict(c_fcfeb90794b07da5,supported) :- node(n693,supported).
query(verdict(c_fcfeb90794b07da5,supported)).
verdict(c_fcfeb90794b07da5,refuted) :- node(n693,refuted).
query(verdict(c_fcfeb90794b07da5,refuted)).
verdict(c_fcfeb90794b07da5,unknown) :- node(n693,unknown).
query(verdict(c_fcfeb90794b07da5,unknown)).
node(n706,supported) :- status(o_9c612041f7dcbfdd3a91,supported).
node(n706,refuted) :- status(o_9c612041f7dcbfdd3a91,refuted).
node(n706,unknown) :- status(o_9c612041f7dcbfdd3a91,unknown).
node(n707,supported) :- status(o_3c819739f8d7586923cd,supported).
node(n707,refuted) :- status(o_3c819739f8d7586923cd,refuted).
node(n707,unknown) :- status(o_3c819739f8d7586923cd,unknown).
node(n708,supported) :- status(o_d0fd28b19816f6286015,supported).
node(n708,refuted) :- status(o_d0fd28b19816f6286015,refuted).
node(n708,unknown) :- status(o_d0fd28b19816f6286015,unknown).
node(n709,supported) :- status(o_a5f0f740368e040d23ab,supported).
node(n709,refuted) :- status(o_a5f0f740368e040d23ab,refuted).
node(n709,unknown) :- status(o_a5f0f740368e040d23ab,unknown).
node(n705,supported) :- node(n706,supported), node(n707,supported), node(n708,supported), node(n709,supported).
node(n705,refuted) :- node(n706,refuted).
node(n705,refuted) :- node(n707,refuted).
node(n705,refuted) :- node(n708,refuted).
node(n705,refuted) :- node(n709,refuted).
node(n705,unknown) :- \+ node(n705,supported), \+ node(n705,refuted).
node(n711,supported) :- status(o_7a7a868f60a336ea91d8,supported).
node(n711,refuted) :- status(o_7a7a868f60a336ea91d8,refuted).
node(n711,unknown) :- status(o_7a7a868f60a336ea91d8,unknown).
node(n712,supported) :- status(o_5dc59784e1a5d69b0bd5,supported).
node(n712,refuted) :- status(o_5dc59784e1a5d69b0bd5,refuted).
node(n712,unknown) :- status(o_5dc59784e1a5d69b0bd5,unknown).
node(n713,supported) :- status(o_020f591c4e6a62bcd58d,supported).
node(n713,refuted) :- status(o_020f591c4e6a62bcd58d,refuted).
node(n713,unknown) :- status(o_020f591c4e6a62bcd58d,unknown).
node(n714,supported) :- status(o_7251e3df35df8c8d83db,supported).
node(n714,refuted) :- status(o_7251e3df35df8c8d83db,refuted).
node(n714,unknown) :- status(o_7251e3df35df8c8d83db,unknown).
node(n710,supported) :- node(n711,supported), node(n712,supported), node(n713,supported), node(n714,supported).
node(n710,refuted) :- node(n711,refuted).
node(n710,refuted) :- node(n712,refuted).
node(n710,refuted) :- node(n713,refuted).
node(n710,refuted) :- node(n714,refuted).
node(n710,unknown) :- \+ node(n710,supported), \+ node(n710,refuted).
node(n704,refuted) :- node(n705,refuted), node(n710,refuted), node(n9,refuted).
node(n704,supported) :- node(n705,supported).
node(n704,supported) :- node(n710,supported).
node(n704,supported) :- node(n9,supported).
node(n704,unknown) :- \+ node(n704,supported), \+ node(n704,refuted).
verdict(c_e67af2d58ad8eff8,supported) :- node(n704,supported).
query(verdict(c_e67af2d58ad8eff8,supported)).
verdict(c_e67af2d58ad8eff8,refuted) :- node(n704,refuted).
query(verdict(c_e67af2d58ad8eff8,refuted)).
verdict(c_e67af2d58ad8eff8,unknown) :- node(n704,unknown).
query(verdict(c_e67af2d58ad8eff8,unknown)).
node(n717,supported) :- status(o_1695e57a2440e2a079e4,supported).
node(n717,refuted) :- status(o_1695e57a2440e2a079e4,refuted).
node(n717,unknown) :- status(o_1695e57a2440e2a079e4,unknown).
node(n718,supported) :- status(o_155eff17059105cd37fe,supported).
node(n718,refuted) :- status(o_155eff17059105cd37fe,refuted).
node(n718,unknown) :- status(o_155eff17059105cd37fe,unknown).
node(n719,supported) :- status(o_830f61633eba3e009470,supported).
node(n719,refuted) :- status(o_830f61633eba3e009470,refuted).
node(n719,unknown) :- status(o_830f61633eba3e009470,unknown).
node(n716,supported) :- node(n717,supported), node(n718,supported), node(n719,supported).
node(n716,refuted) :- node(n717,refuted).
node(n716,refuted) :- node(n718,refuted).
node(n716,refuted) :- node(n719,refuted).
node(n716,unknown) :- \+ node(n716,supported), \+ node(n716,refuted).
node(n721,supported) :- status(o_1de2423fdb744b02201e,supported).
node(n721,refuted) :- status(o_1de2423fdb744b02201e,refuted).
node(n721,unknown) :- status(o_1de2423fdb744b02201e,unknown).
node(n722,supported) :- status(o_39d3caffdc4883b2e5e1,supported).
node(n722,refuted) :- status(o_39d3caffdc4883b2e5e1,refuted).
node(n722,unknown) :- status(o_39d3caffdc4883b2e5e1,unknown).
node(n723,supported) :- status(o_c414304f1ad9f6d96be1,supported).
node(n723,refuted) :- status(o_c414304f1ad9f6d96be1,refuted).
node(n723,unknown) :- status(o_c414304f1ad9f6d96be1,unknown).
node(n720,supported) :- node(n721,supported), node(n722,supported), node(n723,supported).
node(n720,refuted) :- node(n721,refuted).
node(n720,refuted) :- node(n722,refuted).
node(n720,refuted) :- node(n723,refuted).
node(n720,unknown) :- \+ node(n720,supported), \+ node(n720,refuted).
node(n715,refuted) :- node(n716,refuted), node(n720,refuted), node(n9,refuted).
node(n715,supported) :- node(n716,supported).
node(n715,supported) :- node(n720,supported).
node(n715,supported) :- node(n9,supported).
node(n715,unknown) :- \+ node(n715,supported), \+ node(n715,refuted).
verdict(c_790e0b87f93d3fc0,supported) :- node(n715,supported).
query(verdict(c_790e0b87f93d3fc0,supported)).
verdict(c_790e0b87f93d3fc0,refuted) :- node(n715,refuted).
query(verdict(c_790e0b87f93d3fc0,refuted)).
verdict(c_790e0b87f93d3fc0,unknown) :- node(n715,unknown).
query(verdict(c_790e0b87f93d3fc0,unknown)).
node(n726,supported) :- status(o_bd41b1fce932bcd0db43,supported).
node(n726,refuted) :- status(o_bd41b1fce932bcd0db43,refuted).
node(n726,unknown) :- status(o_bd41b1fce932bcd0db43,unknown).
node(n727,supported) :- status(o_04a3f7e0d8b23dfaae7c,supported).
node(n727,refuted) :- status(o_04a3f7e0d8b23dfaae7c,refuted).
node(n727,unknown) :- status(o_04a3f7e0d8b23dfaae7c,unknown).
node(n728,supported) :- status(o_eb5abd4780782cd0239c,supported).
node(n728,refuted) :- status(o_eb5abd4780782cd0239c,refuted).
node(n728,unknown) :- status(o_eb5abd4780782cd0239c,unknown).
node(n729,supported) :- status(o_14e0e73a59cb6610f98c,supported).
node(n729,refuted) :- status(o_14e0e73a59cb6610f98c,refuted).
node(n729,unknown) :- status(o_14e0e73a59cb6610f98c,unknown).
node(n725,supported) :- node(n726,supported), node(n727,supported), node(n728,supported), node(n729,supported).
node(n725,refuted) :- node(n726,refuted).
node(n725,refuted) :- node(n727,refuted).
node(n725,refuted) :- node(n728,refuted).
node(n725,refuted) :- node(n729,refuted).
node(n725,unknown) :- \+ node(n725,supported), \+ node(n725,refuted).
node(n731,supported) :- status(o_4679e86d8b4651b720f4,supported).
node(n731,refuted) :- status(o_4679e86d8b4651b720f4,refuted).
node(n731,unknown) :- status(o_4679e86d8b4651b720f4,unknown).
node(n732,supported) :- status(o_289c97c4d92308d2e3f5,supported).
node(n732,refuted) :- status(o_289c97c4d92308d2e3f5,refuted).
node(n732,unknown) :- status(o_289c97c4d92308d2e3f5,unknown).
node(n733,supported) :- status(o_20d430102235f54cfd79,supported).
node(n733,refuted) :- status(o_20d430102235f54cfd79,refuted).
node(n733,unknown) :- status(o_20d430102235f54cfd79,unknown).
node(n734,supported) :- status(o_47910096ce2bb41c2b1e,supported).
node(n734,refuted) :- status(o_47910096ce2bb41c2b1e,refuted).
node(n734,unknown) :- status(o_47910096ce2bb41c2b1e,unknown).
node(n730,supported) :- node(n731,supported), node(n732,supported), node(n733,supported), node(n734,supported).
node(n730,refuted) :- node(n731,refuted).
node(n730,refuted) :- node(n732,refuted).
node(n730,refuted) :- node(n733,refuted).
node(n730,refuted) :- node(n734,refuted).
node(n730,unknown) :- \+ node(n730,supported), \+ node(n730,refuted).
node(n724,refuted) :- node(n725,refuted), node(n730,refuted), node(n9,refuted).
node(n724,supported) :- node(n725,supported).
node(n724,supported) :- node(n730,supported).
node(n724,supported) :- node(n9,supported).
node(n724,unknown) :- \+ node(n724,supported), \+ node(n724,refuted).
verdict(c_b25c830079d61e87,supported) :- node(n724,supported).
query(verdict(c_b25c830079d61e87,supported)).
verdict(c_b25c830079d61e87,refuted) :- node(n724,refuted).
query(verdict(c_b25c830079d61e87,refuted)).
verdict(c_b25c830079d61e87,unknown) :- node(n724,unknown).
query(verdict(c_b25c830079d61e87,unknown)).
node(n737,supported) :- status(o_9ae23e961b8d07503b18,supported).
node(n737,refuted) :- status(o_9ae23e961b8d07503b18,refuted).
node(n737,unknown) :- status(o_9ae23e961b8d07503b18,unknown).
node(n738,supported) :- status(o_e34806bde7575dd22e67,supported).
node(n738,refuted) :- status(o_e34806bde7575dd22e67,refuted).
node(n738,unknown) :- status(o_e34806bde7575dd22e67,unknown).
node(n739,supported) :- status(o_79b5f8dbc92b30527023,supported).
node(n739,refuted) :- status(o_79b5f8dbc92b30527023,refuted).
node(n739,unknown) :- status(o_79b5f8dbc92b30527023,unknown).
node(n740,supported) :- status(o_b18fcc7a6299a36075f9,supported).
node(n740,refuted) :- status(o_b18fcc7a6299a36075f9,refuted).
node(n740,unknown) :- status(o_b18fcc7a6299a36075f9,unknown).
node(n736,supported) :- node(n737,supported), node(n738,supported), node(n739,supported), node(n740,supported).
node(n736,refuted) :- node(n737,refuted).
node(n736,refuted) :- node(n738,refuted).
node(n736,refuted) :- node(n739,refuted).
node(n736,refuted) :- node(n740,refuted).
node(n736,unknown) :- \+ node(n736,supported), \+ node(n736,refuted).
node(n742,supported) :- status(o_bc11f2b89b2f201e88d0,supported).
node(n742,refuted) :- status(o_bc11f2b89b2f201e88d0,refuted).
node(n742,unknown) :- status(o_bc11f2b89b2f201e88d0,unknown).
node(n743,supported) :- status(o_d4eb0291b8f20fb4c3ac,supported).
node(n743,refuted) :- status(o_d4eb0291b8f20fb4c3ac,refuted).
node(n743,unknown) :- status(o_d4eb0291b8f20fb4c3ac,unknown).
node(n744,supported) :- status(o_effc920ba2ff17c3f981,supported).
node(n744,refuted) :- status(o_effc920ba2ff17c3f981,refuted).
node(n744,unknown) :- status(o_effc920ba2ff17c3f981,unknown).
node(n745,supported) :- status(o_41f8e5bd8d3c88b4aa1e,supported).
node(n745,refuted) :- status(o_41f8e5bd8d3c88b4aa1e,refuted).
node(n745,unknown) :- status(o_41f8e5bd8d3c88b4aa1e,unknown).
node(n741,supported) :- node(n742,supported), node(n743,supported), node(n744,supported), node(n745,supported).
node(n741,refuted) :- node(n742,refuted).
node(n741,refuted) :- node(n743,refuted).
node(n741,refuted) :- node(n744,refuted).
node(n741,refuted) :- node(n745,refuted).
node(n741,unknown) :- \+ node(n741,supported), \+ node(n741,refuted).
node(n735,refuted) :- node(n736,refuted), node(n741,refuted), node(n9,refuted).
node(n735,supported) :- node(n736,supported).
node(n735,supported) :- node(n741,supported).
node(n735,supported) :- node(n9,supported).
node(n735,unknown) :- \+ node(n735,supported), \+ node(n735,refuted).
verdict(c_9610aff46d2c9bdc,supported) :- node(n735,supported).
query(verdict(c_9610aff46d2c9bdc,supported)).
verdict(c_9610aff46d2c9bdc,refuted) :- node(n735,refuted).
query(verdict(c_9610aff46d2c9bdc,refuted)).
verdict(c_9610aff46d2c9bdc,unknown) :- node(n735,unknown).
query(verdict(c_9610aff46d2c9bdc,unknown)).
node(n748,supported) :- status(o_4749c8d705310bba3b46,supported).
node(n748,refuted) :- status(o_4749c8d705310bba3b46,refuted).
node(n748,unknown) :- status(o_4749c8d705310bba3b46,unknown).
node(n749,supported) :- status(o_bbab2a4bf6ca397c7399,supported).
node(n749,refuted) :- status(o_bbab2a4bf6ca397c7399,refuted).
node(n749,unknown) :- status(o_bbab2a4bf6ca397c7399,unknown).
node(n750,supported) :- status(o_3e3c4f6693d28b9ec014,supported).
node(n750,refuted) :- status(o_3e3c4f6693d28b9ec014,refuted).
node(n750,unknown) :- status(o_3e3c4f6693d28b9ec014,unknown).
node(n751,supported) :- status(o_8feabcb2fcd7e5961dd1,supported).
node(n751,refuted) :- status(o_8feabcb2fcd7e5961dd1,refuted).
node(n751,unknown) :- status(o_8feabcb2fcd7e5961dd1,unknown).
node(n747,supported) :- node(n748,supported), node(n749,supported), node(n750,supported), node(n751,supported).
node(n747,refuted) :- node(n748,refuted).
node(n747,refuted) :- node(n749,refuted).
node(n747,refuted) :- node(n750,refuted).
node(n747,refuted) :- node(n751,refuted).
node(n747,unknown) :- \+ node(n747,supported), \+ node(n747,refuted).
node(n753,supported) :- status(o_68dc25f61199658be1a7,supported).
node(n753,refuted) :- status(o_68dc25f61199658be1a7,refuted).
node(n753,unknown) :- status(o_68dc25f61199658be1a7,unknown).
node(n754,supported) :- status(o_f3db2c09fcd0e8303ce0,supported).
node(n754,refuted) :- status(o_f3db2c09fcd0e8303ce0,refuted).
node(n754,unknown) :- status(o_f3db2c09fcd0e8303ce0,unknown).
node(n755,supported) :- status(o_8a1d8391f0b57f1b5e87,supported).
node(n755,refuted) :- status(o_8a1d8391f0b57f1b5e87,refuted).
node(n755,unknown) :- status(o_8a1d8391f0b57f1b5e87,unknown).
node(n756,supported) :- status(o_6f9dcec3ea86b6cecd1c,supported).
node(n756,refuted) :- status(o_6f9dcec3ea86b6cecd1c,refuted).
node(n756,unknown) :- status(o_6f9dcec3ea86b6cecd1c,unknown).
node(n752,supported) :- node(n753,supported), node(n754,supported), node(n755,supported), node(n756,supported).
node(n752,refuted) :- node(n753,refuted).
node(n752,refuted) :- node(n754,refuted).
node(n752,refuted) :- node(n755,refuted).
node(n752,refuted) :- node(n756,refuted).
node(n752,unknown) :- \+ node(n752,supported), \+ node(n752,refuted).
node(n746,refuted) :- node(n747,refuted), node(n752,refuted), node(n9,refuted).
node(n746,supported) :- node(n747,supported).
node(n746,supported) :- node(n752,supported).
node(n746,supported) :- node(n9,supported).
node(n746,unknown) :- \+ node(n746,supported), \+ node(n746,refuted).
verdict(c_32c8bd36f9d62fd3,supported) :- node(n746,supported).
query(verdict(c_32c8bd36f9d62fd3,supported)).
verdict(c_32c8bd36f9d62fd3,refuted) :- node(n746,refuted).
query(verdict(c_32c8bd36f9d62fd3,refuted)).
verdict(c_32c8bd36f9d62fd3,unknown) :- node(n746,unknown).
query(verdict(c_32c8bd36f9d62fd3,unknown)).
node(n759,supported) :- status(o_3b167a0aef257de9c568,supported).
node(n759,refuted) :- status(o_3b167a0aef257de9c568,refuted).
node(n759,unknown) :- status(o_3b167a0aef257de9c568,unknown).
node(n760,supported) :- status(o_948b7714da06d37906f0,supported).
node(n760,refuted) :- status(o_948b7714da06d37906f0,refuted).
node(n760,unknown) :- status(o_948b7714da06d37906f0,unknown).
node(n761,supported) :- status(o_d1273b84354d867e095a,supported).
node(n761,refuted) :- status(o_d1273b84354d867e095a,refuted).
node(n761,unknown) :- status(o_d1273b84354d867e095a,unknown).
node(n758,supported) :- node(n759,supported), node(n760,supported), node(n761,supported).
node(n758,refuted) :- node(n759,refuted).
node(n758,refuted) :- node(n760,refuted).
node(n758,refuted) :- node(n761,refuted).
node(n758,unknown) :- \+ node(n758,supported), \+ node(n758,refuted).
node(n757,refuted) :- node(n758,refuted), node(n9,refuted).
node(n757,supported) :- node(n758,supported).
node(n757,supported) :- node(n9,supported).
node(n757,unknown) :- \+ node(n757,supported), \+ node(n757,refuted).
verdict(c_5f9fc9f927eda786,supported) :- node(n757,supported).
query(verdict(c_5f9fc9f927eda786,supported)).
verdict(c_5f9fc9f927eda786,refuted) :- node(n757,refuted).
query(verdict(c_5f9fc9f927eda786,refuted)).
verdict(c_5f9fc9f927eda786,unknown) :- node(n757,unknown).
query(verdict(c_5f9fc9f927eda786,unknown)).
node(n764,supported) :- status(o_76b35bcadc9ef6ef8e20,supported).
node(n764,refuted) :- status(o_76b35bcadc9ef6ef8e20,refuted).
node(n764,unknown) :- status(o_76b35bcadc9ef6ef8e20,unknown).
node(n765,supported) :- status(o_cade8b480e74d438fcc7,supported).
node(n765,refuted) :- status(o_cade8b480e74d438fcc7,refuted).
node(n765,unknown) :- status(o_cade8b480e74d438fcc7,unknown).
node(n766,supported) :- status(o_4f2104f4ddc40b6525b3,supported).
node(n766,refuted) :- status(o_4f2104f4ddc40b6525b3,refuted).
node(n766,unknown) :- status(o_4f2104f4ddc40b6525b3,unknown).
node(n767,supported) :- status(o_ec5429a7b34c929fb83d,supported).
node(n767,refuted) :- status(o_ec5429a7b34c929fb83d,refuted).
node(n767,unknown) :- status(o_ec5429a7b34c929fb83d,unknown).
node(n763,supported) :- node(n764,supported), node(n765,supported), node(n766,supported), node(n767,supported).
node(n763,refuted) :- node(n764,refuted).
node(n763,refuted) :- node(n765,refuted).
node(n763,refuted) :- node(n766,refuted).
node(n763,refuted) :- node(n767,refuted).
node(n763,unknown) :- \+ node(n763,supported), \+ node(n763,refuted).
node(n762,refuted) :- node(n763,refuted), node(n9,refuted).
node(n762,supported) :- node(n763,supported).
node(n762,supported) :- node(n9,supported).
node(n762,unknown) :- \+ node(n762,supported), \+ node(n762,refuted).
verdict(c_708a4033fbe632ea,supported) :- node(n762,supported).
query(verdict(c_708a4033fbe632ea,supported)).
verdict(c_708a4033fbe632ea,refuted) :- node(n762,refuted).
query(verdict(c_708a4033fbe632ea,refuted)).
verdict(c_708a4033fbe632ea,unknown) :- node(n762,unknown).
query(verdict(c_708a4033fbe632ea,unknown)).
node(n770,supported) :- status(o_d7ee50d8db99f78050ee,supported).
node(n770,refuted) :- status(o_d7ee50d8db99f78050ee,refuted).
node(n770,unknown) :- status(o_d7ee50d8db99f78050ee,unknown).
node(n771,supported) :- status(o_606e7fdaf9cfb4b21781,supported).
node(n771,refuted) :- status(o_606e7fdaf9cfb4b21781,refuted).
node(n771,unknown) :- status(o_606e7fdaf9cfb4b21781,unknown).
node(n772,supported) :- status(o_8361cfecb97ec523e45d,supported).
node(n772,refuted) :- status(o_8361cfecb97ec523e45d,refuted).
node(n772,unknown) :- status(o_8361cfecb97ec523e45d,unknown).
node(n773,supported) :- status(o_72f168e9aca5bd4cb4ae,supported).
node(n773,refuted) :- status(o_72f168e9aca5bd4cb4ae,refuted).
node(n773,unknown) :- status(o_72f168e9aca5bd4cb4ae,unknown).
node(n769,supported) :- node(n770,supported), node(n771,supported), node(n772,supported), node(n773,supported).
node(n769,refuted) :- node(n770,refuted).
node(n769,refuted) :- node(n771,refuted).
node(n769,refuted) :- node(n772,refuted).
node(n769,refuted) :- node(n773,refuted).
node(n769,unknown) :- \+ node(n769,supported), \+ node(n769,refuted).
node(n768,refuted) :- node(n769,refuted), node(n9,refuted).
node(n768,supported) :- node(n769,supported).
node(n768,supported) :- node(n9,supported).
node(n768,unknown) :- \+ node(n768,supported), \+ node(n768,refuted).
verdict(c_19c77e90f59d1aa0,supported) :- node(n768,supported).
query(verdict(c_19c77e90f59d1aa0,supported)).
verdict(c_19c77e90f59d1aa0,refuted) :- node(n768,refuted).
query(verdict(c_19c77e90f59d1aa0,refuted)).
verdict(c_19c77e90f59d1aa0,unknown) :- node(n768,unknown).
query(verdict(c_19c77e90f59d1aa0,unknown)).
node(n776,supported) :- status(o_12096bdf1014ffd4077d,supported).
node(n776,refuted) :- status(o_12096bdf1014ffd4077d,refuted).
node(n776,unknown) :- status(o_12096bdf1014ffd4077d,unknown).
node(n777,supported) :- status(o_c756e29a21507f001213,supported).
node(n777,refuted) :- status(o_c756e29a21507f001213,refuted).
node(n777,unknown) :- status(o_c756e29a21507f001213,unknown).
node(n778,supported) :- status(o_b787c366b41256f7e1c4,supported).
node(n778,refuted) :- status(o_b787c366b41256f7e1c4,refuted).
node(n778,unknown) :- status(o_b787c366b41256f7e1c4,unknown).
node(n779,supported) :- status(o_296feb38668a8f05eb7b,supported).
node(n779,refuted) :- status(o_296feb38668a8f05eb7b,refuted).
node(n779,unknown) :- status(o_296feb38668a8f05eb7b,unknown).
node(n775,supported) :- node(n776,supported), node(n777,supported), node(n778,supported), node(n779,supported).
node(n775,refuted) :- node(n776,refuted).
node(n775,refuted) :- node(n777,refuted).
node(n775,refuted) :- node(n778,refuted).
node(n775,refuted) :- node(n779,refuted).
node(n775,unknown) :- \+ node(n775,supported), \+ node(n775,refuted).
node(n774,refuted) :- node(n775,refuted), node(n9,refuted).
node(n774,supported) :- node(n775,supported).
node(n774,supported) :- node(n9,supported).
node(n774,unknown) :- \+ node(n774,supported), \+ node(n774,refuted).
verdict(c_77642c1b4e6fe5b3,supported) :- node(n774,supported).
query(verdict(c_77642c1b4e6fe5b3,supported)).
verdict(c_77642c1b4e6fe5b3,refuted) :- node(n774,refuted).
query(verdict(c_77642c1b4e6fe5b3,refuted)).
verdict(c_77642c1b4e6fe5b3,unknown) :- node(n774,unknown).
query(verdict(c_77642c1b4e6fe5b3,unknown)).
node(n782,supported) :- status(o_a88d121d4fa3d9baa042,supported).
node(n782,refuted) :- status(o_a88d121d4fa3d9baa042,refuted).
node(n782,unknown) :- status(o_a88d121d4fa3d9baa042,unknown).
node(n783,supported) :- status(o_32532f61be18153e97ef,supported).
node(n783,refuted) :- status(o_32532f61be18153e97ef,refuted).
node(n783,unknown) :- status(o_32532f61be18153e97ef,unknown).
node(n784,supported) :- status(o_3ed5364270d4c98f8111,supported).
node(n784,refuted) :- status(o_3ed5364270d4c98f8111,refuted).
node(n784,unknown) :- status(o_3ed5364270d4c98f8111,unknown).
node(n781,supported) :- node(n782,supported), node(n783,supported), node(n784,supported).
node(n781,refuted) :- node(n782,refuted).
node(n781,refuted) :- node(n783,refuted).
node(n781,refuted) :- node(n784,refuted).
node(n781,unknown) :- \+ node(n781,supported), \+ node(n781,refuted).
node(n780,refuted) :- node(n781,refuted), node(n9,refuted).
node(n780,supported) :- node(n781,supported).
node(n780,supported) :- node(n9,supported).
node(n780,unknown) :- \+ node(n780,supported), \+ node(n780,refuted).
verdict(c_7e37cb8189cf3162,supported) :- node(n780,supported).
query(verdict(c_7e37cb8189cf3162,supported)).
verdict(c_7e37cb8189cf3162,refuted) :- node(n780,refuted).
query(verdict(c_7e37cb8189cf3162,refuted)).
verdict(c_7e37cb8189cf3162,unknown) :- node(n780,unknown).
query(verdict(c_7e37cb8189cf3162,unknown)).
node(n787,supported) :- status(o_d7ac5035eded8e971761,supported).
node(n787,refuted) :- status(o_d7ac5035eded8e971761,refuted).
node(n787,unknown) :- status(o_d7ac5035eded8e971761,unknown).
node(n788,supported) :- status(o_6a7cd51126352371c072,supported).
node(n788,refuted) :- status(o_6a7cd51126352371c072,refuted).
node(n788,unknown) :- status(o_6a7cd51126352371c072,unknown).
node(n789,supported) :- status(o_db36a470810ed3dda20a,supported).
node(n789,refuted) :- status(o_db36a470810ed3dda20a,refuted).
node(n789,unknown) :- status(o_db36a470810ed3dda20a,unknown).
node(n790,supported) :- status(o_6e1aab03e377642dd091,supported).
node(n790,refuted) :- status(o_6e1aab03e377642dd091,refuted).
node(n790,unknown) :- status(o_6e1aab03e377642dd091,unknown).
node(n786,supported) :- node(n787,supported), node(n788,supported), node(n789,supported), node(n790,supported).
node(n786,refuted) :- node(n787,refuted).
node(n786,refuted) :- node(n788,refuted).
node(n786,refuted) :- node(n789,refuted).
node(n786,refuted) :- node(n790,refuted).
node(n786,unknown) :- \+ node(n786,supported), \+ node(n786,refuted).
node(n785,refuted) :- node(n786,refuted), node(n9,refuted).
node(n785,supported) :- node(n786,supported).
node(n785,supported) :- node(n9,supported).
node(n785,unknown) :- \+ node(n785,supported), \+ node(n785,refuted).
verdict(c_634ec48b2a36cae9,supported) :- node(n785,supported).
query(verdict(c_634ec48b2a36cae9,supported)).
verdict(c_634ec48b2a36cae9,refuted) :- node(n785,refuted).
query(verdict(c_634ec48b2a36cae9,refuted)).
verdict(c_634ec48b2a36cae9,unknown) :- node(n785,unknown).
query(verdict(c_634ec48b2a36cae9,unknown)).
node(n793,supported) :- status(o_a82280ddc960ec34a3d0,supported).
node(n793,refuted) :- status(o_a82280ddc960ec34a3d0,refuted).
node(n793,unknown) :- status(o_a82280ddc960ec34a3d0,unknown).
node(n794,supported) :- status(o_3600ff54c76bc02eac4c,supported).
node(n794,refuted) :- status(o_3600ff54c76bc02eac4c,refuted).
node(n794,unknown) :- status(o_3600ff54c76bc02eac4c,unknown).
node(n795,supported) :- status(o_0617943eb68e06303c49,supported).
node(n795,refuted) :- status(o_0617943eb68e06303c49,refuted).
node(n795,unknown) :- status(o_0617943eb68e06303c49,unknown).
node(n796,supported) :- status(o_31662048fc25bb8d3885,supported).
node(n796,refuted) :- status(o_31662048fc25bb8d3885,refuted).
node(n796,unknown) :- status(o_31662048fc25bb8d3885,unknown).
node(n792,supported) :- node(n793,supported), node(n794,supported), node(n795,supported), node(n796,supported).
node(n792,refuted) :- node(n793,refuted).
node(n792,refuted) :- node(n794,refuted).
node(n792,refuted) :- node(n795,refuted).
node(n792,refuted) :- node(n796,refuted).
node(n792,unknown) :- \+ node(n792,supported), \+ node(n792,refuted).
node(n791,refuted) :- node(n792,refuted), node(n9,refuted).
node(n791,supported) :- node(n792,supported).
node(n791,supported) :- node(n9,supported).
node(n791,unknown) :- \+ node(n791,supported), \+ node(n791,refuted).
verdict(c_29a280e24d38d65c,supported) :- node(n791,supported).
query(verdict(c_29a280e24d38d65c,supported)).
verdict(c_29a280e24d38d65c,refuted) :- node(n791,refuted).
query(verdict(c_29a280e24d38d65c,refuted)).
verdict(c_29a280e24d38d65c,unknown) :- node(n791,unknown).
query(verdict(c_29a280e24d38d65c,unknown)).
node(n799,supported) :- status(o_0996f82f7930e7004422,supported).
node(n799,refuted) :- status(o_0996f82f7930e7004422,refuted).
node(n799,unknown) :- status(o_0996f82f7930e7004422,unknown).
node(n800,supported) :- status(o_6438813fac3b0c62753f,supported).
node(n800,refuted) :- status(o_6438813fac3b0c62753f,refuted).
node(n800,unknown) :- status(o_6438813fac3b0c62753f,unknown).
node(n801,supported) :- status(o_ee475014315fb305c192,supported).
node(n801,refuted) :- status(o_ee475014315fb305c192,refuted).
node(n801,unknown) :- status(o_ee475014315fb305c192,unknown).
node(n802,supported) :- status(o_39919b5deae80da4fe1e,supported).
node(n802,refuted) :- status(o_39919b5deae80da4fe1e,refuted).
node(n802,unknown) :- status(o_39919b5deae80da4fe1e,unknown).
node(n798,supported) :- node(n799,supported), node(n800,supported), node(n801,supported), node(n802,supported).
node(n798,refuted) :- node(n799,refuted).
node(n798,refuted) :- node(n800,refuted).
node(n798,refuted) :- node(n801,refuted).
node(n798,refuted) :- node(n802,refuted).
node(n798,unknown) :- \+ node(n798,supported), \+ node(n798,refuted).
node(n797,refuted) :- node(n798,refuted), node(n9,refuted).
node(n797,supported) :- node(n798,supported).
node(n797,supported) :- node(n9,supported).
node(n797,unknown) :- \+ node(n797,supported), \+ node(n797,refuted).
verdict(c_fd185f1cc0cdc884,supported) :- node(n797,supported).
query(verdict(c_fd185f1cc0cdc884,supported)).
verdict(c_fd185f1cc0cdc884,refuted) :- node(n797,refuted).
query(verdict(c_fd185f1cc0cdc884,refuted)).
verdict(c_fd185f1cc0cdc884,unknown) :- node(n797,unknown).
query(verdict(c_fd185f1cc0cdc884,unknown)).
node(n805,supported) :- status(o_39ddd8f48aab0945d3ef,supported).
node(n805,refuted) :- status(o_39ddd8f48aab0945d3ef,refuted).
node(n805,unknown) :- status(o_39ddd8f48aab0945d3ef,unknown).
node(n806,supported) :- status(o_0e0f03537c26da468806,supported).
node(n806,refuted) :- status(o_0e0f03537c26da468806,refuted).
node(n806,unknown) :- status(o_0e0f03537c26da468806,unknown).
node(n807,supported) :- status(o_6a144a3090d472dff4da,supported).
node(n807,refuted) :- status(o_6a144a3090d472dff4da,refuted).
node(n807,unknown) :- status(o_6a144a3090d472dff4da,unknown).
node(n804,supported) :- node(n805,supported), node(n806,supported), node(n807,supported).
node(n804,refuted) :- node(n805,refuted).
node(n804,refuted) :- node(n806,refuted).
node(n804,refuted) :- node(n807,refuted).
node(n804,unknown) :- \+ node(n804,supported), \+ node(n804,refuted).
node(n803,refuted) :- node(n804,refuted), node(n9,refuted).
node(n803,supported) :- node(n804,supported).
node(n803,supported) :- node(n9,supported).
node(n803,unknown) :- \+ node(n803,supported), \+ node(n803,refuted).
verdict(c_260774e601365bfe,supported) :- node(n803,supported).
query(verdict(c_260774e601365bfe,supported)).
verdict(c_260774e601365bfe,refuted) :- node(n803,refuted).
query(verdict(c_260774e601365bfe,refuted)).
verdict(c_260774e601365bfe,unknown) :- node(n803,unknown).
query(verdict(c_260774e601365bfe,unknown)).
node(n810,supported) :- status(o_c4f5fd73bec2f7321198,supported).
node(n810,refuted) :- status(o_c4f5fd73bec2f7321198,refuted).
node(n810,unknown) :- status(o_c4f5fd73bec2f7321198,unknown).
node(n811,supported) :- status(o_1664bb1b29db19185da0,supported).
node(n811,refuted) :- status(o_1664bb1b29db19185da0,refuted).
node(n811,unknown) :- status(o_1664bb1b29db19185da0,unknown).
node(n812,supported) :- status(o_280e74e244449b3cfd77,supported).
node(n812,refuted) :- status(o_280e74e244449b3cfd77,refuted).
node(n812,unknown) :- status(o_280e74e244449b3cfd77,unknown).
node(n813,supported) :- status(o_a40a693968ee9aa1312d,supported).
node(n813,refuted) :- status(o_a40a693968ee9aa1312d,refuted).
node(n813,unknown) :- status(o_a40a693968ee9aa1312d,unknown).
node(n809,supported) :- node(n810,supported), node(n811,supported), node(n812,supported), node(n813,supported).
node(n809,refuted) :- node(n810,refuted).
node(n809,refuted) :- node(n811,refuted).
node(n809,refuted) :- node(n812,refuted).
node(n809,refuted) :- node(n813,refuted).
node(n809,unknown) :- \+ node(n809,supported), \+ node(n809,refuted).
node(n808,refuted) :- node(n809,refuted), node(n9,refuted).
node(n808,supported) :- node(n809,supported).
node(n808,supported) :- node(n9,supported).
node(n808,unknown) :- \+ node(n808,supported), \+ node(n808,refuted).
verdict(c_7230fd627a8bb345,supported) :- node(n808,supported).
query(verdict(c_7230fd627a8bb345,supported)).
verdict(c_7230fd627a8bb345,refuted) :- node(n808,refuted).
query(verdict(c_7230fd627a8bb345,refuted)).
verdict(c_7230fd627a8bb345,unknown) :- node(n808,unknown).
query(verdict(c_7230fd627a8bb345,unknown)).
node(n816,supported) :- status(o_cc66678bdf98844bc9fb,supported).
node(n816,refuted) :- status(o_cc66678bdf98844bc9fb,refuted).
node(n816,unknown) :- status(o_cc66678bdf98844bc9fb,unknown).
node(n817,supported) :- status(o_0a90630f8ae8493f2e41,supported).
node(n817,refuted) :- status(o_0a90630f8ae8493f2e41,refuted).
node(n817,unknown) :- status(o_0a90630f8ae8493f2e41,unknown).
node(n818,supported) :- status(o_f2a642294ec7f3c60b72,supported).
node(n818,refuted) :- status(o_f2a642294ec7f3c60b72,refuted).
node(n818,unknown) :- status(o_f2a642294ec7f3c60b72,unknown).
node(n819,supported) :- status(o_f45d9b14edc801ef3ca4,supported).
node(n819,refuted) :- status(o_f45d9b14edc801ef3ca4,refuted).
node(n819,unknown) :- status(o_f45d9b14edc801ef3ca4,unknown).
node(n815,supported) :- node(n816,supported), node(n817,supported), node(n818,supported), node(n819,supported).
node(n815,refuted) :- node(n816,refuted).
node(n815,refuted) :- node(n817,refuted).
node(n815,refuted) :- node(n818,refuted).
node(n815,refuted) :- node(n819,refuted).
node(n815,unknown) :- \+ node(n815,supported), \+ node(n815,refuted).
node(n814,refuted) :- node(n815,refuted), node(n9,refuted).
node(n814,supported) :- node(n815,supported).
node(n814,supported) :- node(n9,supported).
node(n814,unknown) :- \+ node(n814,supported), \+ node(n814,refuted).
verdict(c_80cfe7eb2f9d0fcf,supported) :- node(n814,supported).
query(verdict(c_80cfe7eb2f9d0fcf,supported)).
verdict(c_80cfe7eb2f9d0fcf,refuted) :- node(n814,refuted).
query(verdict(c_80cfe7eb2f9d0fcf,refuted)).
verdict(c_80cfe7eb2f9d0fcf,unknown) :- node(n814,unknown).
query(verdict(c_80cfe7eb2f9d0fcf,unknown)).
node(n822,supported) :- status(o_4e42c010934f2f36c5e4,supported).
node(n822,refuted) :- status(o_4e42c010934f2f36c5e4,refuted).
node(n822,unknown) :- status(o_4e42c010934f2f36c5e4,unknown).
node(n823,supported) :- status(o_ea9ac559ff0b60cd70aa,supported).
node(n823,refuted) :- status(o_ea9ac559ff0b60cd70aa,refuted).
node(n823,unknown) :- status(o_ea9ac559ff0b60cd70aa,unknown).
node(n824,supported) :- status(o_7e81a84526ba5f2ed35b,supported).
node(n824,refuted) :- status(o_7e81a84526ba5f2ed35b,refuted).
node(n824,unknown) :- status(o_7e81a84526ba5f2ed35b,unknown).
node(n825,supported) :- status(o_b1214eb33abb28f31731,supported).
node(n825,refuted) :- status(o_b1214eb33abb28f31731,refuted).
node(n825,unknown) :- status(o_b1214eb33abb28f31731,unknown).
node(n821,supported) :- node(n822,supported), node(n823,supported), node(n824,supported), node(n825,supported).
node(n821,refuted) :- node(n822,refuted).
node(n821,refuted) :- node(n823,refuted).
node(n821,refuted) :- node(n824,refuted).
node(n821,refuted) :- node(n825,refuted).
node(n821,unknown) :- \+ node(n821,supported), \+ node(n821,refuted).
node(n820,refuted) :- node(n821,refuted), node(n9,refuted).
node(n820,supported) :- node(n821,supported).
node(n820,supported) :- node(n9,supported).
node(n820,unknown) :- \+ node(n820,supported), \+ node(n820,refuted).
verdict(c_563ffd7e84d9611c,supported) :- node(n820,supported).
query(verdict(c_563ffd7e84d9611c,supported)).
verdict(c_563ffd7e84d9611c,refuted) :- node(n820,refuted).
query(verdict(c_563ffd7e84d9611c,refuted)).
verdict(c_563ffd7e84d9611c,unknown) :- node(n820,unknown).
query(verdict(c_563ffd7e84d9611c,unknown)).
node(n828,supported) :- status(o_bfe16197617115d3e200,supported).
node(n828,refuted) :- status(o_bfe16197617115d3e200,refuted).
node(n828,unknown) :- status(o_bfe16197617115d3e200,unknown).
node(n829,supported) :- status(o_56dcde9618fa955ea7bd,supported).
node(n829,refuted) :- status(o_56dcde9618fa955ea7bd,refuted).
node(n829,unknown) :- status(o_56dcde9618fa955ea7bd,unknown).
node(n830,supported) :- status(o_67f6959423b876ea7a6b,supported).
node(n830,refuted) :- status(o_67f6959423b876ea7a6b,refuted).
node(n830,unknown) :- status(o_67f6959423b876ea7a6b,unknown).
node(n827,supported) :- node(n828,supported), node(n829,supported), node(n830,supported).
node(n827,refuted) :- node(n828,refuted).
node(n827,refuted) :- node(n829,refuted).
node(n827,refuted) :- node(n830,refuted).
node(n827,unknown) :- \+ node(n827,supported), \+ node(n827,refuted).
node(n826,refuted) :- node(n827,refuted), node(n9,refuted).
node(n826,supported) :- node(n827,supported).
node(n826,supported) :- node(n9,supported).
node(n826,unknown) :- \+ node(n826,supported), \+ node(n826,refuted).
verdict(c_cfbb41f3538a586d,supported) :- node(n826,supported).
query(verdict(c_cfbb41f3538a586d,supported)).
verdict(c_cfbb41f3538a586d,refuted) :- node(n826,refuted).
query(verdict(c_cfbb41f3538a586d,refuted)).
verdict(c_cfbb41f3538a586d,unknown) :- node(n826,unknown).
query(verdict(c_cfbb41f3538a586d,unknown)).
node(n833,supported) :- status(o_4ddffbf6933ad269c7b3,supported).
node(n833,refuted) :- status(o_4ddffbf6933ad269c7b3,refuted).
node(n833,unknown) :- status(o_4ddffbf6933ad269c7b3,unknown).
node(n834,supported) :- status(o_78c675799fca887a4d17,supported).
node(n834,refuted) :- status(o_78c675799fca887a4d17,refuted).
node(n834,unknown) :- status(o_78c675799fca887a4d17,unknown).
node(n835,supported) :- status(o_c22f2390e67774f3b296,supported).
node(n835,refuted) :- status(o_c22f2390e67774f3b296,refuted).
node(n835,unknown) :- status(o_c22f2390e67774f3b296,unknown).
node(n836,supported) :- status(o_3da2a2e97f3135d39036,supported).
node(n836,refuted) :- status(o_3da2a2e97f3135d39036,refuted).
node(n836,unknown) :- status(o_3da2a2e97f3135d39036,unknown).
node(n832,supported) :- node(n833,supported), node(n834,supported), node(n835,supported), node(n836,supported).
node(n832,refuted) :- node(n833,refuted).
node(n832,refuted) :- node(n834,refuted).
node(n832,refuted) :- node(n835,refuted).
node(n832,refuted) :- node(n836,refuted).
node(n832,unknown) :- \+ node(n832,supported), \+ node(n832,refuted).
node(n831,refuted) :- node(n832,refuted), node(n9,refuted).
node(n831,supported) :- node(n832,supported).
node(n831,supported) :- node(n9,supported).
node(n831,unknown) :- \+ node(n831,supported), \+ node(n831,refuted).
verdict(c_97e12d748c234dfe,supported) :- node(n831,supported).
query(verdict(c_97e12d748c234dfe,supported)).
verdict(c_97e12d748c234dfe,refuted) :- node(n831,refuted).
query(verdict(c_97e12d748c234dfe,refuted)).
verdict(c_97e12d748c234dfe,unknown) :- node(n831,unknown).
query(verdict(c_97e12d748c234dfe,unknown)).
node(n839,supported) :- status(o_99686f78ba054fa8919c,supported).
node(n839,refuted) :- status(o_99686f78ba054fa8919c,refuted).
node(n839,unknown) :- status(o_99686f78ba054fa8919c,unknown).
node(n840,supported) :- status(o_6bc523b6b1836c14590f,supported).
node(n840,refuted) :- status(o_6bc523b6b1836c14590f,refuted).
node(n840,unknown) :- status(o_6bc523b6b1836c14590f,unknown).
node(n841,supported) :- status(o_34054f0aa8dc823c7e2b,supported).
node(n841,refuted) :- status(o_34054f0aa8dc823c7e2b,refuted).
node(n841,unknown) :- status(o_34054f0aa8dc823c7e2b,unknown).
node(n842,supported) :- status(o_59f0b8dea2d24c1878c1,supported).
node(n842,refuted) :- status(o_59f0b8dea2d24c1878c1,refuted).
node(n842,unknown) :- status(o_59f0b8dea2d24c1878c1,unknown).
node(n838,supported) :- node(n839,supported), node(n840,supported), node(n841,supported), node(n842,supported).
node(n838,refuted) :- node(n839,refuted).
node(n838,refuted) :- node(n840,refuted).
node(n838,refuted) :- node(n841,refuted).
node(n838,refuted) :- node(n842,refuted).
node(n838,unknown) :- \+ node(n838,supported), \+ node(n838,refuted).
node(n837,refuted) :- node(n838,refuted), node(n9,refuted).
node(n837,supported) :- node(n838,supported).
node(n837,supported) :- node(n9,supported).
node(n837,unknown) :- \+ node(n837,supported), \+ node(n837,refuted).
verdict(c_3674f006539e446d,supported) :- node(n837,supported).
query(verdict(c_3674f006539e446d,supported)).
verdict(c_3674f006539e446d,refuted) :- node(n837,refuted).
query(verdict(c_3674f006539e446d,refuted)).
verdict(c_3674f006539e446d,unknown) :- node(n837,unknown).
query(verdict(c_3674f006539e446d,unknown)).
node(n845,supported) :- status(o_62afbbc79e74e4b46314,supported).
node(n845,refuted) :- status(o_62afbbc79e74e4b46314,refuted).
node(n845,unknown) :- status(o_62afbbc79e74e4b46314,unknown).
node(n846,supported) :- status(o_a50df53d4aa8b2234a6b,supported).
node(n846,refuted) :- status(o_a50df53d4aa8b2234a6b,refuted).
node(n846,unknown) :- status(o_a50df53d4aa8b2234a6b,unknown).
node(n847,supported) :- status(o_830a7c0ad7e79d53229f,supported).
node(n847,refuted) :- status(o_830a7c0ad7e79d53229f,refuted).
node(n847,unknown) :- status(o_830a7c0ad7e79d53229f,unknown).
node(n848,supported) :- status(o_c8fcdc4e29b717ea8f13,supported).
node(n848,refuted) :- status(o_c8fcdc4e29b717ea8f13,refuted).
node(n848,unknown) :- status(o_c8fcdc4e29b717ea8f13,unknown).
node(n844,supported) :- node(n845,supported), node(n846,supported), node(n847,supported), node(n848,supported).
node(n844,refuted) :- node(n845,refuted).
node(n844,refuted) :- node(n846,refuted).
node(n844,refuted) :- node(n847,refuted).
node(n844,refuted) :- node(n848,refuted).
node(n844,unknown) :- \+ node(n844,supported), \+ node(n844,refuted).
node(n843,refuted) :- node(n844,refuted), node(n9,refuted).
node(n843,supported) :- node(n844,supported).
node(n843,supported) :- node(n9,supported).
node(n843,unknown) :- \+ node(n843,supported), \+ node(n843,refuted).
verdict(c_8c0302f6d042433a,supported) :- node(n843,supported).
query(verdict(c_8c0302f6d042433a,supported)).
verdict(c_8c0302f6d042433a,refuted) :- node(n843,refuted).
query(verdict(c_8c0302f6d042433a,refuted)).
verdict(c_8c0302f6d042433a,unknown) :- node(n843,unknown).
query(verdict(c_8c0302f6d042433a,unknown)).
node(n851,supported) :- status(o_c6332f069ed47da63689,supported).
node(n851,refuted) :- status(o_c6332f069ed47da63689,refuted).
node(n851,unknown) :- status(o_c6332f069ed47da63689,unknown).
node(n852,supported) :- status(o_31d2fef1b5854d6750a9,supported).
node(n852,refuted) :- status(o_31d2fef1b5854d6750a9,refuted).
node(n852,unknown) :- status(o_31d2fef1b5854d6750a9,unknown).
node(n853,supported) :- status(o_3928173bdac8b7b74a8f,supported).
node(n853,refuted) :- status(o_3928173bdac8b7b74a8f,refuted).
node(n853,unknown) :- status(o_3928173bdac8b7b74a8f,unknown).
node(n850,supported) :- node(n851,supported), node(n852,supported), node(n853,supported).
node(n850,refuted) :- node(n851,refuted).
node(n850,refuted) :- node(n852,refuted).
node(n850,refuted) :- node(n853,refuted).
node(n850,unknown) :- \+ node(n850,supported), \+ node(n850,refuted).
node(n849,refuted) :- node(n850,refuted), node(n9,refuted).
node(n849,supported) :- node(n850,supported).
node(n849,supported) :- node(n9,supported).
node(n849,unknown) :- \+ node(n849,supported), \+ node(n849,refuted).
verdict(c_5c1deb0a234c67dc,supported) :- node(n849,supported).
query(verdict(c_5c1deb0a234c67dc,supported)).
verdict(c_5c1deb0a234c67dc,refuted) :- node(n849,refuted).
query(verdict(c_5c1deb0a234c67dc,refuted)).
verdict(c_5c1deb0a234c67dc,unknown) :- node(n849,unknown).
query(verdict(c_5c1deb0a234c67dc,unknown)).
node(n856,supported) :- status(o_4a1698b1b8925f4af31b,supported).
node(n856,refuted) :- status(o_4a1698b1b8925f4af31b,refuted).
node(n856,unknown) :- status(o_4a1698b1b8925f4af31b,unknown).
node(n857,supported) :- status(o_13b966bcfccc11a88483,supported).
node(n857,refuted) :- status(o_13b966bcfccc11a88483,refuted).
node(n857,unknown) :- status(o_13b966bcfccc11a88483,unknown).
node(n858,supported) :- status(o_614663ad6093ec558f06,supported).
node(n858,refuted) :- status(o_614663ad6093ec558f06,refuted).
node(n858,unknown) :- status(o_614663ad6093ec558f06,unknown).
node(n859,supported) :- status(o_c315f437f02f6ab89eb9,supported).
node(n859,refuted) :- status(o_c315f437f02f6ab89eb9,refuted).
node(n859,unknown) :- status(o_c315f437f02f6ab89eb9,unknown).
node(n855,supported) :- node(n856,supported), node(n857,supported), node(n858,supported), node(n859,supported).
node(n855,refuted) :- node(n856,refuted).
node(n855,refuted) :- node(n857,refuted).
node(n855,refuted) :- node(n858,refuted).
node(n855,refuted) :- node(n859,refuted).
node(n855,unknown) :- \+ node(n855,supported), \+ node(n855,refuted).
node(n854,refuted) :- node(n855,refuted), node(n9,refuted).
node(n854,supported) :- node(n855,supported).
node(n854,supported) :- node(n9,supported).
node(n854,unknown) :- \+ node(n854,supported), \+ node(n854,refuted).
verdict(c_aea53ef456b192e7,supported) :- node(n854,supported).
query(verdict(c_aea53ef456b192e7,supported)).
verdict(c_aea53ef456b192e7,refuted) :- node(n854,refuted).
query(verdict(c_aea53ef456b192e7,refuted)).
verdict(c_aea53ef456b192e7,unknown) :- node(n854,unknown).
query(verdict(c_aea53ef456b192e7,unknown)).
node(n862,supported) :- status(o_88c7c6c35ac4aa90e4c7,supported).
node(n862,refuted) :- status(o_88c7c6c35ac4aa90e4c7,refuted).
node(n862,unknown) :- status(o_88c7c6c35ac4aa90e4c7,unknown).
node(n863,supported) :- status(o_1acc58b760821bed93fa,supported).
node(n863,refuted) :- status(o_1acc58b760821bed93fa,refuted).
node(n863,unknown) :- status(o_1acc58b760821bed93fa,unknown).
node(n864,supported) :- status(o_64b7d3f7e8fe33c867b7,supported).
node(n864,refuted) :- status(o_64b7d3f7e8fe33c867b7,refuted).
node(n864,unknown) :- status(o_64b7d3f7e8fe33c867b7,unknown).
node(n865,supported) :- status(o_1fe5cb13c72d709036a5,supported).
node(n865,refuted) :- status(o_1fe5cb13c72d709036a5,refuted).
node(n865,unknown) :- status(o_1fe5cb13c72d709036a5,unknown).
node(n861,supported) :- node(n862,supported), node(n863,supported), node(n864,supported), node(n865,supported).
node(n861,refuted) :- node(n862,refuted).
node(n861,refuted) :- node(n863,refuted).
node(n861,refuted) :- node(n864,refuted).
node(n861,refuted) :- node(n865,refuted).
node(n861,unknown) :- \+ node(n861,supported), \+ node(n861,refuted).
node(n860,refuted) :- node(n861,refuted), node(n9,refuted).
node(n860,supported) :- node(n861,supported).
node(n860,supported) :- node(n9,supported).
node(n860,unknown) :- \+ node(n860,supported), \+ node(n860,refuted).
verdict(c_1fa564203a352811,supported) :- node(n860,supported).
query(verdict(c_1fa564203a352811,supported)).
verdict(c_1fa564203a352811,refuted) :- node(n860,refuted).
query(verdict(c_1fa564203a352811,refuted)).
verdict(c_1fa564203a352811,unknown) :- node(n860,unknown).
query(verdict(c_1fa564203a352811,unknown)).
node(n868,supported) :- status(o_c9216a24ec3c1b90138d,supported).
node(n868,refuted) :- status(o_c9216a24ec3c1b90138d,refuted).
node(n868,unknown) :- status(o_c9216a24ec3c1b90138d,unknown).
node(n869,supported) :- status(o_1dccba490d4ea65f9a73,supported).
node(n869,refuted) :- status(o_1dccba490d4ea65f9a73,refuted).
node(n869,unknown) :- status(o_1dccba490d4ea65f9a73,unknown).
node(n870,supported) :- status(o_49854d2bc6f3a059d6ff,supported).
node(n870,refuted) :- status(o_49854d2bc6f3a059d6ff,refuted).
node(n870,unknown) :- status(o_49854d2bc6f3a059d6ff,unknown).
node(n871,supported) :- status(o_115d8c60f2e94f47a1e8,supported).
node(n871,refuted) :- status(o_115d8c60f2e94f47a1e8,refuted).
node(n871,unknown) :- status(o_115d8c60f2e94f47a1e8,unknown).
node(n867,supported) :- node(n868,supported), node(n869,supported), node(n870,supported), node(n871,supported).
node(n867,refuted) :- node(n868,refuted).
node(n867,refuted) :- node(n869,refuted).
node(n867,refuted) :- node(n870,refuted).
node(n867,refuted) :- node(n871,refuted).
node(n867,unknown) :- \+ node(n867,supported), \+ node(n867,refuted).
node(n866,refuted) :- node(n867,refuted), node(n9,refuted).
node(n866,supported) :- node(n867,supported).
node(n866,supported) :- node(n9,supported).
node(n866,unknown) :- \+ node(n866,supported), \+ node(n866,refuted).
verdict(c_beead8e9bb94cd38,supported) :- node(n866,supported).
query(verdict(c_beead8e9bb94cd38,supported)).
verdict(c_beead8e9bb94cd38,refuted) :- node(n866,refuted).
query(verdict(c_beead8e9bb94cd38,refuted)).
verdict(c_beead8e9bb94cd38,unknown) :- node(n866,unknown).
query(verdict(c_beead8e9bb94cd38,unknown)).
node(n874,supported) :- status(o_668a3fff57a960a01dec,supported).
node(n874,refuted) :- status(o_668a3fff57a960a01dec,refuted).
node(n874,unknown) :- status(o_668a3fff57a960a01dec,unknown).
node(n875,supported) :- status(o_c4fae8eeade7f381cf3d,supported).
node(n875,refuted) :- status(o_c4fae8eeade7f381cf3d,refuted).
node(n875,unknown) :- status(o_c4fae8eeade7f381cf3d,unknown).
node(n876,supported) :- status(o_75d51a00c3ba36a2d6fe,supported).
node(n876,refuted) :- status(o_75d51a00c3ba36a2d6fe,refuted).
node(n876,unknown) :- status(o_75d51a00c3ba36a2d6fe,unknown).
node(n873,supported) :- node(n874,supported), node(n875,supported), node(n876,supported).
node(n873,refuted) :- node(n874,refuted).
node(n873,refuted) :- node(n875,refuted).
node(n873,refuted) :- node(n876,refuted).
node(n873,unknown) :- \+ node(n873,supported), \+ node(n873,refuted).
node(n872,refuted) :- node(n873,refuted), node(n9,refuted).
node(n872,supported) :- node(n873,supported).
node(n872,supported) :- node(n9,supported).
node(n872,unknown) :- \+ node(n872,supported), \+ node(n872,refuted).
verdict(c_bd8e0a2dd123be6c,supported) :- node(n872,supported).
query(verdict(c_bd8e0a2dd123be6c,supported)).
verdict(c_bd8e0a2dd123be6c,refuted) :- node(n872,refuted).
query(verdict(c_bd8e0a2dd123be6c,refuted)).
verdict(c_bd8e0a2dd123be6c,unknown) :- node(n872,unknown).
query(verdict(c_bd8e0a2dd123be6c,unknown)).
node(n879,supported) :- status(o_bbdbce4079c22878551c,supported).
node(n879,refuted) :- status(o_bbdbce4079c22878551c,refuted).
node(n879,unknown) :- status(o_bbdbce4079c22878551c,unknown).
node(n880,supported) :- status(o_ef91b59276c35a3edfc5,supported).
node(n880,refuted) :- status(o_ef91b59276c35a3edfc5,refuted).
node(n880,unknown) :- status(o_ef91b59276c35a3edfc5,unknown).
node(n881,supported) :- status(o_81e6f94978c079f4646b,supported).
node(n881,refuted) :- status(o_81e6f94978c079f4646b,refuted).
node(n881,unknown) :- status(o_81e6f94978c079f4646b,unknown).
node(n882,supported) :- status(o_2fc5c14e7925da5ed922,supported).
node(n882,refuted) :- status(o_2fc5c14e7925da5ed922,refuted).
node(n882,unknown) :- status(o_2fc5c14e7925da5ed922,unknown).
node(n878,supported) :- node(n879,supported), node(n880,supported), node(n881,supported), node(n882,supported).
node(n878,refuted) :- node(n879,refuted).
node(n878,refuted) :- node(n880,refuted).
node(n878,refuted) :- node(n881,refuted).
node(n878,refuted) :- node(n882,refuted).
node(n878,unknown) :- \+ node(n878,supported), \+ node(n878,refuted).
node(n877,refuted) :- node(n878,refuted), node(n9,refuted).
node(n877,supported) :- node(n878,supported).
node(n877,supported) :- node(n9,supported).
node(n877,unknown) :- \+ node(n877,supported), \+ node(n877,refuted).
verdict(c_c95c47526caa224a,supported) :- node(n877,supported).
query(verdict(c_c95c47526caa224a,supported)).
verdict(c_c95c47526caa224a,refuted) :- node(n877,refuted).
query(verdict(c_c95c47526caa224a,refuted)).
verdict(c_c95c47526caa224a,unknown) :- node(n877,unknown).
query(verdict(c_c95c47526caa224a,unknown)).
node(n885,supported) :- status(o_f674d81c34370fc67445,supported).
node(n885,refuted) :- status(o_f674d81c34370fc67445,refuted).
node(n885,unknown) :- status(o_f674d81c34370fc67445,unknown).
node(n886,supported) :- status(o_31a3cb021e7a9c1fdac8,supported).
node(n886,refuted) :- status(o_31a3cb021e7a9c1fdac8,refuted).
node(n886,unknown) :- status(o_31a3cb021e7a9c1fdac8,unknown).
node(n887,supported) :- status(o_06058e0e09d07f718e88,supported).
node(n887,refuted) :- status(o_06058e0e09d07f718e88,refuted).
node(n887,unknown) :- status(o_06058e0e09d07f718e88,unknown).
node(n888,supported) :- status(o_c8ee7ccaaabaee2b82c7,supported).
node(n888,refuted) :- status(o_c8ee7ccaaabaee2b82c7,refuted).
node(n888,unknown) :- status(o_c8ee7ccaaabaee2b82c7,unknown).
node(n884,supported) :- node(n885,supported), node(n886,supported), node(n887,supported), node(n888,supported).
node(n884,refuted) :- node(n885,refuted).
node(n884,refuted) :- node(n886,refuted).
node(n884,refuted) :- node(n887,refuted).
node(n884,refuted) :- node(n888,refuted).
node(n884,unknown) :- \+ node(n884,supported), \+ node(n884,refuted).
node(n883,refuted) :- node(n884,refuted), node(n9,refuted).
node(n883,supported) :- node(n884,supported).
node(n883,supported) :- node(n9,supported).
node(n883,unknown) :- \+ node(n883,supported), \+ node(n883,refuted).
verdict(c_3f107dbd22e49a05,supported) :- node(n883,supported).
query(verdict(c_3f107dbd22e49a05,supported)).
verdict(c_3f107dbd22e49a05,refuted) :- node(n883,refuted).
query(verdict(c_3f107dbd22e49a05,refuted)).
verdict(c_3f107dbd22e49a05,unknown) :- node(n883,unknown).
query(verdict(c_3f107dbd22e49a05,unknown)).
node(n891,supported) :- status(o_0463a4e8b051fb3bcd88,supported).
node(n891,refuted) :- status(o_0463a4e8b051fb3bcd88,refuted).
node(n891,unknown) :- status(o_0463a4e8b051fb3bcd88,unknown).
node(n892,supported) :- status(o_c6a4f5ff2be5c2a22c2c,supported).
node(n892,refuted) :- status(o_c6a4f5ff2be5c2a22c2c,refuted).
node(n892,unknown) :- status(o_c6a4f5ff2be5c2a22c2c,unknown).
node(n893,supported) :- status(o_a4691cddd84829f0d2ff,supported).
node(n893,refuted) :- status(o_a4691cddd84829f0d2ff,refuted).
node(n893,unknown) :- status(o_a4691cddd84829f0d2ff,unknown).
node(n894,supported) :- status(o_215640e2f741040bbbc9,supported).
node(n894,refuted) :- status(o_215640e2f741040bbbc9,refuted).
node(n894,unknown) :- status(o_215640e2f741040bbbc9,unknown).
node(n890,supported) :- node(n891,supported), node(n892,supported), node(n893,supported), node(n894,supported).
node(n890,refuted) :- node(n891,refuted).
node(n890,refuted) :- node(n892,refuted).
node(n890,refuted) :- node(n893,refuted).
node(n890,refuted) :- node(n894,refuted).
node(n890,unknown) :- \+ node(n890,supported), \+ node(n890,refuted).
node(n889,refuted) :- node(n890,refuted), node(n9,refuted).
node(n889,supported) :- node(n890,supported).
node(n889,supported) :- node(n9,supported).
node(n889,unknown) :- \+ node(n889,supported), \+ node(n889,refuted).
verdict(c_d574235d43194a15,supported) :- node(n889,supported).
query(verdict(c_d574235d43194a15,supported)).
verdict(c_d574235d43194a15,refuted) :- node(n889,refuted).
query(verdict(c_d574235d43194a15,refuted)).
verdict(c_d574235d43194a15,unknown) :- node(n889,unknown).
query(verdict(c_d574235d43194a15,unknown)).
node(n897,supported) :- status(o_8bb40208e05c741de57c,supported).
node(n897,refuted) :- status(o_8bb40208e05c741de57c,refuted).
node(n897,unknown) :- status(o_8bb40208e05c741de57c,unknown).
node(n898,supported) :- status(o_873d74cfad30944f2f40,supported).
node(n898,refuted) :- status(o_873d74cfad30944f2f40,refuted).
node(n898,unknown) :- status(o_873d74cfad30944f2f40,unknown).
node(n899,supported) :- status(o_2ee3c8d25bc591228859,supported).
node(n899,refuted) :- status(o_2ee3c8d25bc591228859,refuted).
node(n899,unknown) :- status(o_2ee3c8d25bc591228859,unknown).
node(n896,supported) :- node(n897,supported), node(n898,supported), node(n899,supported).
node(n896,refuted) :- node(n897,refuted).
node(n896,refuted) :- node(n898,refuted).
node(n896,refuted) :- node(n899,refuted).
node(n896,unknown) :- \+ node(n896,supported), \+ node(n896,refuted).
node(n901,supported) :- status(o_0e93c7cbc4607f03cdb8,supported).
node(n901,refuted) :- status(o_0e93c7cbc4607f03cdb8,refuted).
node(n901,unknown) :- status(o_0e93c7cbc4607f03cdb8,unknown).
node(n902,supported) :- status(o_57c9cd4cf12f4c81b2ea,supported).
node(n902,refuted) :- status(o_57c9cd4cf12f4c81b2ea,refuted).
node(n902,unknown) :- status(o_57c9cd4cf12f4c81b2ea,unknown).
node(n903,supported) :- status(o_4fec84417a868a565920,supported).
node(n903,refuted) :- status(o_4fec84417a868a565920,refuted).
node(n903,unknown) :- status(o_4fec84417a868a565920,unknown).
node(n900,supported) :- node(n901,supported), node(n902,supported), node(n903,supported).
node(n900,refuted) :- node(n901,refuted).
node(n900,refuted) :- node(n902,refuted).
node(n900,refuted) :- node(n903,refuted).
node(n900,unknown) :- \+ node(n900,supported), \+ node(n900,refuted).
node(n895,refuted) :- node(n896,refuted), node(n900,refuted), node(n9,refuted).
node(n895,supported) :- node(n896,supported).
node(n895,supported) :- node(n900,supported).
node(n895,supported) :- node(n9,supported).
node(n895,unknown) :- \+ node(n895,supported), \+ node(n895,refuted).
verdict(c_1b3161c1ca19c1d8,supported) :- node(n895,supported).
query(verdict(c_1b3161c1ca19c1d8,supported)).
verdict(c_1b3161c1ca19c1d8,refuted) :- node(n895,refuted).
query(verdict(c_1b3161c1ca19c1d8,refuted)).
verdict(c_1b3161c1ca19c1d8,unknown) :- node(n895,unknown).
query(verdict(c_1b3161c1ca19c1d8,unknown)).
node(n906,supported) :- status(o_55c1c67b835c754e8999,supported).
node(n906,refuted) :- status(o_55c1c67b835c754e8999,refuted).
node(n906,unknown) :- status(o_55c1c67b835c754e8999,unknown).
node(n907,supported) :- status(o_6a8df846d961108514e0,supported).
node(n907,refuted) :- status(o_6a8df846d961108514e0,refuted).
node(n907,unknown) :- status(o_6a8df846d961108514e0,unknown).
node(n908,supported) :- status(o_f55a72155d860008d9e3,supported).
node(n908,refuted) :- status(o_f55a72155d860008d9e3,refuted).
node(n908,unknown) :- status(o_f55a72155d860008d9e3,unknown).
node(n909,supported) :- status(o_63b7b2b44ada3858a4fa,supported).
node(n909,refuted) :- status(o_63b7b2b44ada3858a4fa,refuted).
node(n909,unknown) :- status(o_63b7b2b44ada3858a4fa,unknown).
node(n905,supported) :- node(n906,supported), node(n907,supported), node(n908,supported), node(n909,supported).
node(n905,refuted) :- node(n906,refuted).
node(n905,refuted) :- node(n907,refuted).
node(n905,refuted) :- node(n908,refuted).
node(n905,refuted) :- node(n909,refuted).
node(n905,unknown) :- \+ node(n905,supported), \+ node(n905,refuted).
node(n911,supported) :- status(o_3aef72adaa350abe3058,supported).
node(n911,refuted) :- status(o_3aef72adaa350abe3058,refuted).
node(n911,unknown) :- status(o_3aef72adaa350abe3058,unknown).
node(n912,supported) :- status(o_96d6b33fa67bbb65801d,supported).
node(n912,refuted) :- status(o_96d6b33fa67bbb65801d,refuted).
node(n912,unknown) :- status(o_96d6b33fa67bbb65801d,unknown).
node(n913,supported) :- status(o_038ecd395bdd41c1d344,supported).
node(n913,refuted) :- status(o_038ecd395bdd41c1d344,refuted).
node(n913,unknown) :- status(o_038ecd395bdd41c1d344,unknown).
node(n914,supported) :- status(o_19ea84cfc61d9ad96c7d,supported).
node(n914,refuted) :- status(o_19ea84cfc61d9ad96c7d,refuted).
node(n914,unknown) :- status(o_19ea84cfc61d9ad96c7d,unknown).
node(n910,supported) :- node(n911,supported), node(n912,supported), node(n913,supported), node(n914,supported).
node(n910,refuted) :- node(n911,refuted).
node(n910,refuted) :- node(n912,refuted).
node(n910,refuted) :- node(n913,refuted).
node(n910,refuted) :- node(n914,refuted).
node(n910,unknown) :- \+ node(n910,supported), \+ node(n910,refuted).
node(n904,refuted) :- node(n905,refuted), node(n910,refuted), node(n9,refuted).
node(n904,supported) :- node(n905,supported).
node(n904,supported) :- node(n910,supported).
node(n904,supported) :- node(n9,supported).
node(n904,unknown) :- \+ node(n904,supported), \+ node(n904,refuted).
verdict(c_976014d2eadb1689,supported) :- node(n904,supported).
query(verdict(c_976014d2eadb1689,supported)).
verdict(c_976014d2eadb1689,refuted) :- node(n904,refuted).
query(verdict(c_976014d2eadb1689,refuted)).
verdict(c_976014d2eadb1689,unknown) :- node(n904,unknown).
query(verdict(c_976014d2eadb1689,unknown)).
node(n917,supported) :- status(o_247a4509331cccaac1d6,supported).
node(n917,refuted) :- status(o_247a4509331cccaac1d6,refuted).
node(n917,unknown) :- status(o_247a4509331cccaac1d6,unknown).
node(n918,supported) :- status(o_725373ebd0ba4c63d2ef,supported).
node(n918,refuted) :- status(o_725373ebd0ba4c63d2ef,refuted).
node(n918,unknown) :- status(o_725373ebd0ba4c63d2ef,unknown).
node(n919,supported) :- status(o_ef0900d9fd1cf13abdf9,supported).
node(n919,refuted) :- status(o_ef0900d9fd1cf13abdf9,refuted).
node(n919,unknown) :- status(o_ef0900d9fd1cf13abdf9,unknown).
node(n920,supported) :- status(o_bb177b76e82955afd892,supported).
node(n920,refuted) :- status(o_bb177b76e82955afd892,refuted).
node(n920,unknown) :- status(o_bb177b76e82955afd892,unknown).
node(n916,supported) :- node(n917,supported), node(n918,supported), node(n919,supported), node(n920,supported).
node(n916,refuted) :- node(n917,refuted).
node(n916,refuted) :- node(n918,refuted).
node(n916,refuted) :- node(n919,refuted).
node(n916,refuted) :- node(n920,refuted).
node(n916,unknown) :- \+ node(n916,supported), \+ node(n916,refuted).
node(n922,supported) :- status(o_d97c7c2712413bd5d595,supported).
node(n922,refuted) :- status(o_d97c7c2712413bd5d595,refuted).
node(n922,unknown) :- status(o_d97c7c2712413bd5d595,unknown).
node(n923,supported) :- status(o_28a1de3558c4b531f8d9,supported).
node(n923,refuted) :- status(o_28a1de3558c4b531f8d9,refuted).
node(n923,unknown) :- status(o_28a1de3558c4b531f8d9,unknown).
node(n924,supported) :- status(o_c6ba6fb61720f9af4a62,supported).
node(n924,refuted) :- status(o_c6ba6fb61720f9af4a62,refuted).
node(n924,unknown) :- status(o_c6ba6fb61720f9af4a62,unknown).
node(n925,supported) :- status(o_c4d5a8f637398dbe56ab,supported).
node(n925,refuted) :- status(o_c4d5a8f637398dbe56ab,refuted).
node(n925,unknown) :- status(o_c4d5a8f637398dbe56ab,unknown).
node(n921,supported) :- node(n922,supported), node(n923,supported), node(n924,supported), node(n925,supported).
node(n921,refuted) :- node(n922,refuted).
node(n921,refuted) :- node(n923,refuted).
node(n921,refuted) :- node(n924,refuted).
node(n921,refuted) :- node(n925,refuted).
node(n921,unknown) :- \+ node(n921,supported), \+ node(n921,refuted).
node(n915,refuted) :- node(n916,refuted), node(n921,refuted), node(n9,refuted).
node(n915,supported) :- node(n916,supported).
node(n915,supported) :- node(n921,supported).
node(n915,supported) :- node(n9,supported).
node(n915,unknown) :- \+ node(n915,supported), \+ node(n915,refuted).
verdict(c_ab8ff85e2930f2ef,supported) :- node(n915,supported).
query(verdict(c_ab8ff85e2930f2ef,supported)).
verdict(c_ab8ff85e2930f2ef,refuted) :- node(n915,refuted).
query(verdict(c_ab8ff85e2930f2ef,refuted)).
verdict(c_ab8ff85e2930f2ef,unknown) :- node(n915,unknown).
query(verdict(c_ab8ff85e2930f2ef,unknown)).
node(n928,supported) :- status(o_d131f92fd425cdb10771,supported).
node(n928,refuted) :- status(o_d131f92fd425cdb10771,refuted).
node(n928,unknown) :- status(o_d131f92fd425cdb10771,unknown).
node(n929,supported) :- status(o_2df3db888eee5a6f8521,supported).
node(n929,refuted) :- status(o_2df3db888eee5a6f8521,refuted).
node(n929,unknown) :- status(o_2df3db888eee5a6f8521,unknown).
node(n930,supported) :- status(o_c4ba84a0918378e21f7d,supported).
node(n930,refuted) :- status(o_c4ba84a0918378e21f7d,refuted).
node(n930,unknown) :- status(o_c4ba84a0918378e21f7d,unknown).
node(n931,supported) :- status(o_f085f77fa801f9a88b1b,supported).
node(n931,refuted) :- status(o_f085f77fa801f9a88b1b,refuted).
node(n931,unknown) :- status(o_f085f77fa801f9a88b1b,unknown).
node(n927,supported) :- node(n928,supported), node(n929,supported), node(n930,supported), node(n931,supported).
node(n927,refuted) :- node(n928,refuted).
node(n927,refuted) :- node(n929,refuted).
node(n927,refuted) :- node(n930,refuted).
node(n927,refuted) :- node(n931,refuted).
node(n927,unknown) :- \+ node(n927,supported), \+ node(n927,refuted).
node(n933,supported) :- status(o_b1e3ac763f76abbe2f30,supported).
node(n933,refuted) :- status(o_b1e3ac763f76abbe2f30,refuted).
node(n933,unknown) :- status(o_b1e3ac763f76abbe2f30,unknown).
node(n934,supported) :- status(o_ebe611f1c8762619764a,supported).
node(n934,refuted) :- status(o_ebe611f1c8762619764a,refuted).
node(n934,unknown) :- status(o_ebe611f1c8762619764a,unknown).
node(n935,supported) :- status(o_abe9f9d1122f5b93172a,supported).
node(n935,refuted) :- status(o_abe9f9d1122f5b93172a,refuted).
node(n935,unknown) :- status(o_abe9f9d1122f5b93172a,unknown).
node(n936,supported) :- status(o_00a289a3cedd0ca402bf,supported).
node(n936,refuted) :- status(o_00a289a3cedd0ca402bf,refuted).
node(n936,unknown) :- status(o_00a289a3cedd0ca402bf,unknown).
node(n932,supported) :- node(n933,supported), node(n934,supported), node(n935,supported), node(n936,supported).
node(n932,refuted) :- node(n933,refuted).
node(n932,refuted) :- node(n934,refuted).
node(n932,refuted) :- node(n935,refuted).
node(n932,refuted) :- node(n936,refuted).
node(n932,unknown) :- \+ node(n932,supported), \+ node(n932,refuted).
node(n926,refuted) :- node(n927,refuted), node(n932,refuted), node(n9,refuted).
node(n926,supported) :- node(n927,supported).
node(n926,supported) :- node(n932,supported).
node(n926,supported) :- node(n9,supported).
node(n926,unknown) :- \+ node(n926,supported), \+ node(n926,refuted).
verdict(c_ccdbfeea64daab7b,supported) :- node(n926,supported).
query(verdict(c_ccdbfeea64daab7b,supported)).
verdict(c_ccdbfeea64daab7b,refuted) :- node(n926,refuted).
query(verdict(c_ccdbfeea64daab7b,refuted)).
verdict(c_ccdbfeea64daab7b,unknown) :- node(n926,unknown).
query(verdict(c_ccdbfeea64daab7b,unknown)).
node(n939,supported) :- status(o_b10a9f96609b04c63224,supported).
node(n939,refuted) :- status(o_b10a9f96609b04c63224,refuted).
node(n939,unknown) :- status(o_b10a9f96609b04c63224,unknown).
node(n940,supported) :- status(o_881863e337dd650b51f1,supported).
node(n940,refuted) :- status(o_881863e337dd650b51f1,refuted).
node(n940,unknown) :- status(o_881863e337dd650b51f1,unknown).
node(n941,supported) :- status(o_9636879589e48d6fc359,supported).
node(n941,refuted) :- status(o_9636879589e48d6fc359,refuted).
node(n941,unknown) :- status(o_9636879589e48d6fc359,unknown).
node(n938,supported) :- node(n939,supported), node(n940,supported), node(n941,supported).
node(n938,refuted) :- node(n939,refuted).
node(n938,refuted) :- node(n940,refuted).
node(n938,refuted) :- node(n941,refuted).
node(n938,unknown) :- \+ node(n938,supported), \+ node(n938,refuted).
node(n943,supported) :- status(o_f505abe27a16db3da67f,supported).
node(n943,refuted) :- status(o_f505abe27a16db3da67f,refuted).
node(n943,unknown) :- status(o_f505abe27a16db3da67f,unknown).
node(n944,supported) :- status(o_21e4d2170e4690d207d7,supported).
node(n944,refuted) :- status(o_21e4d2170e4690d207d7,refuted).
node(n944,unknown) :- status(o_21e4d2170e4690d207d7,unknown).
node(n945,supported) :- status(o_0120afb530917478f5b4,supported).
node(n945,refuted) :- status(o_0120afb530917478f5b4,refuted).
node(n945,unknown) :- status(o_0120afb530917478f5b4,unknown).
node(n942,supported) :- node(n943,supported), node(n944,supported), node(n945,supported).
node(n942,refuted) :- node(n943,refuted).
node(n942,refuted) :- node(n944,refuted).
node(n942,refuted) :- node(n945,refuted).
node(n942,unknown) :- \+ node(n942,supported), \+ node(n942,refuted).
node(n937,refuted) :- node(n938,refuted), node(n942,refuted), node(n9,refuted).
node(n937,supported) :- node(n938,supported).
node(n937,supported) :- node(n942,supported).
node(n937,supported) :- node(n9,supported).
node(n937,unknown) :- \+ node(n937,supported), \+ node(n937,refuted).
verdict(c_79313bb6c2826da0,supported) :- node(n937,supported).
query(verdict(c_79313bb6c2826da0,supported)).
verdict(c_79313bb6c2826da0,refuted) :- node(n937,refuted).
query(verdict(c_79313bb6c2826da0,refuted)).
verdict(c_79313bb6c2826da0,unknown) :- node(n937,unknown).
query(verdict(c_79313bb6c2826da0,unknown)).
node(n948,supported) :- status(o_a5db06aca7558d5d87ff,supported).
node(n948,refuted) :- status(o_a5db06aca7558d5d87ff,refuted).
node(n948,unknown) :- status(o_a5db06aca7558d5d87ff,unknown).
node(n949,supported) :- status(o_d3d8cc3011e619564d68,supported).
node(n949,refuted) :- status(o_d3d8cc3011e619564d68,refuted).
node(n949,unknown) :- status(o_d3d8cc3011e619564d68,unknown).
node(n950,supported) :- status(o_90bd208550715c463043,supported).
node(n950,refuted) :- status(o_90bd208550715c463043,refuted).
node(n950,unknown) :- status(o_90bd208550715c463043,unknown).
node(n951,supported) :- status(o_15a8dfa19cf7b1f1c856,supported).
node(n951,refuted) :- status(o_15a8dfa19cf7b1f1c856,refuted).
node(n951,unknown) :- status(o_15a8dfa19cf7b1f1c856,unknown).
node(n947,supported) :- node(n948,supported), node(n949,supported), node(n950,supported), node(n951,supported).
node(n947,refuted) :- node(n948,refuted).
node(n947,refuted) :- node(n949,refuted).
node(n947,refuted) :- node(n950,refuted).
node(n947,refuted) :- node(n951,refuted).
node(n947,unknown) :- \+ node(n947,supported), \+ node(n947,refuted).
node(n953,supported) :- status(o_9bdd877535a38def7dfe,supported).
node(n953,refuted) :- status(o_9bdd877535a38def7dfe,refuted).
node(n953,unknown) :- status(o_9bdd877535a38def7dfe,unknown).
node(n954,supported) :- status(o_98e7f06c6336c9cc3707,supported).
node(n954,refuted) :- status(o_98e7f06c6336c9cc3707,refuted).
node(n954,unknown) :- status(o_98e7f06c6336c9cc3707,unknown).
node(n955,supported) :- status(o_4731064fb1cbec098856,supported).
node(n955,refuted) :- status(o_4731064fb1cbec098856,refuted).
node(n955,unknown) :- status(o_4731064fb1cbec098856,unknown).
node(n956,supported) :- status(o_92d732613a61e1358729,supported).
node(n956,refuted) :- status(o_92d732613a61e1358729,refuted).
node(n956,unknown) :- status(o_92d732613a61e1358729,unknown).
node(n952,supported) :- node(n953,supported), node(n954,supported), node(n955,supported), node(n956,supported).
node(n952,refuted) :- node(n953,refuted).
node(n952,refuted) :- node(n954,refuted).
node(n952,refuted) :- node(n955,refuted).
node(n952,refuted) :- node(n956,refuted).
node(n952,unknown) :- \+ node(n952,supported), \+ node(n952,refuted).
node(n946,refuted) :- node(n947,refuted), node(n952,refuted), node(n9,refuted).
node(n946,supported) :- node(n947,supported).
node(n946,supported) :- node(n952,supported).
node(n946,supported) :- node(n9,supported).
node(n946,unknown) :- \+ node(n946,supported), \+ node(n946,refuted).
verdict(c_aa8d08e915f358eb,supported) :- node(n946,supported).
query(verdict(c_aa8d08e915f358eb,supported)).
verdict(c_aa8d08e915f358eb,refuted) :- node(n946,refuted).
query(verdict(c_aa8d08e915f358eb,refuted)).
verdict(c_aa8d08e915f358eb,unknown) :- node(n946,unknown).
query(verdict(c_aa8d08e915f358eb,unknown)).
node(n959,supported) :- status(o_ecf730f1f458f2341348,supported).
node(n959,refuted) :- status(o_ecf730f1f458f2341348,refuted).
node(n959,unknown) :- status(o_ecf730f1f458f2341348,unknown).
node(n960,supported) :- status(o_dc7672bba93bc777db3a,supported).
node(n960,refuted) :- status(o_dc7672bba93bc777db3a,refuted).
node(n960,unknown) :- status(o_dc7672bba93bc777db3a,unknown).
node(n961,supported) :- status(o_a2f451743f4b973e9a8d,supported).
node(n961,refuted) :- status(o_a2f451743f4b973e9a8d,refuted).
node(n961,unknown) :- status(o_a2f451743f4b973e9a8d,unknown).
node(n962,supported) :- status(o_a8a95ff2b2bac94b19c7,supported).
node(n962,refuted) :- status(o_a8a95ff2b2bac94b19c7,refuted).
node(n962,unknown) :- status(o_a8a95ff2b2bac94b19c7,unknown).
node(n958,supported) :- node(n959,supported), node(n960,supported), node(n961,supported), node(n962,supported).
node(n958,refuted) :- node(n959,refuted).
node(n958,refuted) :- node(n960,refuted).
node(n958,refuted) :- node(n961,refuted).
node(n958,refuted) :- node(n962,refuted).
node(n958,unknown) :- \+ node(n958,supported), \+ node(n958,refuted).
node(n964,supported) :- status(o_5e2cb7807c23ddfbfbaa,supported).
node(n964,refuted) :- status(o_5e2cb7807c23ddfbfbaa,refuted).
node(n964,unknown) :- status(o_5e2cb7807c23ddfbfbaa,unknown).
node(n965,supported) :- status(o_6d568bef0acc52bfcaac,supported).
node(n965,refuted) :- status(o_6d568bef0acc52bfcaac,refuted).
node(n965,unknown) :- status(o_6d568bef0acc52bfcaac,unknown).
node(n966,supported) :- status(o_9f2102c3b6a6669e62b2,supported).
node(n966,refuted) :- status(o_9f2102c3b6a6669e62b2,refuted).
node(n966,unknown) :- status(o_9f2102c3b6a6669e62b2,unknown).
node(n967,supported) :- status(o_1d7ae98b073e697469bb,supported).
node(n967,refuted) :- status(o_1d7ae98b073e697469bb,refuted).
node(n967,unknown) :- status(o_1d7ae98b073e697469bb,unknown).
node(n963,supported) :- node(n964,supported), node(n965,supported), node(n966,supported), node(n967,supported).
node(n963,refuted) :- node(n964,refuted).
node(n963,refuted) :- node(n965,refuted).
node(n963,refuted) :- node(n966,refuted).
node(n963,refuted) :- node(n967,refuted).
node(n963,unknown) :- \+ node(n963,supported), \+ node(n963,refuted).
node(n957,refuted) :- node(n958,refuted), node(n963,refuted), node(n9,refuted).
node(n957,supported) :- node(n958,supported).
node(n957,supported) :- node(n963,supported).
node(n957,supported) :- node(n9,supported).
node(n957,unknown) :- \+ node(n957,supported), \+ node(n957,refuted).
verdict(c_b4fbb9521bea4d3e,supported) :- node(n957,supported).
query(verdict(c_b4fbb9521bea4d3e,supported)).
verdict(c_b4fbb9521bea4d3e,refuted) :- node(n957,refuted).
query(verdict(c_b4fbb9521bea4d3e,refuted)).
verdict(c_b4fbb9521bea4d3e,unknown) :- node(n957,unknown).
query(verdict(c_b4fbb9521bea4d3e,unknown)).
node(n970,supported) :- status(o_5aad0b6f464c90daf2c4,supported).
node(n970,refuted) :- status(o_5aad0b6f464c90daf2c4,refuted).
node(n970,unknown) :- status(o_5aad0b6f464c90daf2c4,unknown).
node(n971,supported) :- status(o_80cebdaf44c01eca00f4,supported).
node(n971,refuted) :- status(o_80cebdaf44c01eca00f4,refuted).
node(n971,unknown) :- status(o_80cebdaf44c01eca00f4,unknown).
node(n972,supported) :- status(o_6c014c5dca7fa9f17f52,supported).
node(n972,refuted) :- status(o_6c014c5dca7fa9f17f52,refuted).
node(n972,unknown) :- status(o_6c014c5dca7fa9f17f52,unknown).
node(n973,supported) :- status(o_148ea4c38a3b4751c91d,supported).
node(n973,refuted) :- status(o_148ea4c38a3b4751c91d,refuted).
node(n973,unknown) :- status(o_148ea4c38a3b4751c91d,unknown).
node(n969,supported) :- node(n970,supported), node(n971,supported), node(n972,supported), node(n973,supported).
node(n969,refuted) :- node(n970,refuted).
node(n969,refuted) :- node(n971,refuted).
node(n969,refuted) :- node(n972,refuted).
node(n969,refuted) :- node(n973,refuted).
node(n969,unknown) :- \+ node(n969,supported), \+ node(n969,refuted).
node(n975,supported) :- status(o_3772b49a57dc0741b5f2,supported).
node(n975,refuted) :- status(o_3772b49a57dc0741b5f2,refuted).
node(n975,unknown) :- status(o_3772b49a57dc0741b5f2,unknown).
node(n976,supported) :- status(o_5e2fe45a61f243b7abac,supported).
node(n976,refuted) :- status(o_5e2fe45a61f243b7abac,refuted).
node(n976,unknown) :- status(o_5e2fe45a61f243b7abac,unknown).
node(n977,supported) :- status(o_35679d94ec7f78269939,supported).
node(n977,refuted) :- status(o_35679d94ec7f78269939,refuted).
node(n977,unknown) :- status(o_35679d94ec7f78269939,unknown).
node(n978,supported) :- status(o_18d9999d11ac1d090f84,supported).
node(n978,refuted) :- status(o_18d9999d11ac1d090f84,refuted).
node(n978,unknown) :- status(o_18d9999d11ac1d090f84,unknown).
node(n974,supported) :- node(n975,supported), node(n976,supported), node(n977,supported), node(n978,supported).
node(n974,refuted) :- node(n975,refuted).
node(n974,refuted) :- node(n976,refuted).
node(n974,refuted) :- node(n977,refuted).
node(n974,refuted) :- node(n978,refuted).
node(n974,unknown) :- \+ node(n974,supported), \+ node(n974,refuted).
node(n968,refuted) :- node(n969,refuted), node(n974,refuted), node(n9,refuted).
node(n968,supported) :- node(n969,supported).
node(n968,supported) :- node(n974,supported).
node(n968,supported) :- node(n9,supported).
node(n968,unknown) :- \+ node(n968,supported), \+ node(n968,refuted).
verdict(c_1ba3d1f734e4ab03,supported) :- node(n968,supported).
query(verdict(c_1ba3d1f734e4ab03,supported)).
verdict(c_1ba3d1f734e4ab03,refuted) :- node(n968,refuted).
query(verdict(c_1ba3d1f734e4ab03,refuted)).
verdict(c_1ba3d1f734e4ab03,unknown) :- node(n968,unknown).
query(verdict(c_1ba3d1f734e4ab03,unknown)).
node(n981,supported) :- status(o_d62e779d0ce15d43083c,supported).
node(n981,refuted) :- status(o_d62e779d0ce15d43083c,refuted).
node(n981,unknown) :- status(o_d62e779d0ce15d43083c,unknown).
node(n982,supported) :- status(o_cc2405f43ecd7cf0f296,supported).
node(n982,refuted) :- status(o_cc2405f43ecd7cf0f296,refuted).
node(n982,unknown) :- status(o_cc2405f43ecd7cf0f296,unknown).
node(n983,supported) :- status(o_39916c4551d7bd5f856e,supported).
node(n983,refuted) :- status(o_39916c4551d7bd5f856e,refuted).
node(n983,unknown) :- status(o_39916c4551d7bd5f856e,unknown).
node(n980,supported) :- node(n981,supported), node(n982,supported), node(n983,supported).
node(n980,refuted) :- node(n981,refuted).
node(n980,refuted) :- node(n982,refuted).
node(n980,refuted) :- node(n983,refuted).
node(n980,unknown) :- \+ node(n980,supported), \+ node(n980,refuted).
node(n985,supported) :- status(o_f5865b8c291700bb1849,supported).
node(n985,refuted) :- status(o_f5865b8c291700bb1849,refuted).
node(n985,unknown) :- status(o_f5865b8c291700bb1849,unknown).
node(n986,supported) :- status(o_cb76d2e819ced06dc6c4,supported).
node(n986,refuted) :- status(o_cb76d2e819ced06dc6c4,refuted).
node(n986,unknown) :- status(o_cb76d2e819ced06dc6c4,unknown).
node(n987,supported) :- status(o_5126e9d04183de4b0317,supported).
node(n987,refuted) :- status(o_5126e9d04183de4b0317,refuted).
node(n987,unknown) :- status(o_5126e9d04183de4b0317,unknown).
node(n984,supported) :- node(n985,supported), node(n986,supported), node(n987,supported).
node(n984,refuted) :- node(n985,refuted).
node(n984,refuted) :- node(n986,refuted).
node(n984,refuted) :- node(n987,refuted).
node(n984,unknown) :- \+ node(n984,supported), \+ node(n984,refuted).
node(n979,refuted) :- node(n980,refuted), node(n984,refuted), node(n9,refuted).
node(n979,supported) :- node(n980,supported).
node(n979,supported) :- node(n984,supported).
node(n979,supported) :- node(n9,supported).
node(n979,unknown) :- \+ node(n979,supported), \+ node(n979,refuted).
verdict(c_8f5db4d47d19cf79,supported) :- node(n979,supported).
query(verdict(c_8f5db4d47d19cf79,supported)).
verdict(c_8f5db4d47d19cf79,refuted) :- node(n979,refuted).
query(verdict(c_8f5db4d47d19cf79,refuted)).
verdict(c_8f5db4d47d19cf79,unknown) :- node(n979,unknown).
query(verdict(c_8f5db4d47d19cf79,unknown)).
node(n990,supported) :- status(o_889f7e7ec2ff2d666ebc,supported).
node(n990,refuted) :- status(o_889f7e7ec2ff2d666ebc,refuted).
node(n990,unknown) :- status(o_889f7e7ec2ff2d666ebc,unknown).
node(n991,supported) :- status(o_edd12c32aa138aab04ad,supported).
node(n991,refuted) :- status(o_edd12c32aa138aab04ad,refuted).
node(n991,unknown) :- status(o_edd12c32aa138aab04ad,unknown).
node(n992,supported) :- status(o_3c0091074de4af8a45ed,supported).
node(n992,refuted) :- status(o_3c0091074de4af8a45ed,refuted).
node(n992,unknown) :- status(o_3c0091074de4af8a45ed,unknown).
node(n993,supported) :- status(o_a4c4c8ab5215e5374d10,supported).
node(n993,refuted) :- status(o_a4c4c8ab5215e5374d10,refuted).
node(n993,unknown) :- status(o_a4c4c8ab5215e5374d10,unknown).
node(n989,supported) :- node(n990,supported), node(n991,supported), node(n992,supported), node(n993,supported).
node(n989,refuted) :- node(n990,refuted).
node(n989,refuted) :- node(n991,refuted).
node(n989,refuted) :- node(n992,refuted).
node(n989,refuted) :- node(n993,refuted).
node(n989,unknown) :- \+ node(n989,supported), \+ node(n989,refuted).
node(n995,supported) :- status(o_f294dcaf38a20c58bae0,supported).
node(n995,refuted) :- status(o_f294dcaf38a20c58bae0,refuted).
node(n995,unknown) :- status(o_f294dcaf38a20c58bae0,unknown).
node(n996,supported) :- status(o_f6cfbe131fbec241597c,supported).
node(n996,refuted) :- status(o_f6cfbe131fbec241597c,refuted).
node(n996,unknown) :- status(o_f6cfbe131fbec241597c,unknown).
node(n997,supported) :- status(o_a4f45f48e4dd5e847513,supported).
node(n997,refuted) :- status(o_a4f45f48e4dd5e847513,refuted).
node(n997,unknown) :- status(o_a4f45f48e4dd5e847513,unknown).
node(n998,supported) :- status(o_06b8e795c32eb0920560,supported).
node(n998,refuted) :- status(o_06b8e795c32eb0920560,refuted).
node(n998,unknown) :- status(o_06b8e795c32eb0920560,unknown).
node(n994,supported) :- node(n995,supported), node(n996,supported), node(n997,supported), node(n998,supported).
node(n994,refuted) :- node(n995,refuted).
node(n994,refuted) :- node(n996,refuted).
node(n994,refuted) :- node(n997,refuted).
node(n994,refuted) :- node(n998,refuted).
node(n994,unknown) :- \+ node(n994,supported), \+ node(n994,refuted).
node(n988,refuted) :- node(n989,refuted), node(n994,refuted), node(n9,refuted).
node(n988,supported) :- node(n989,supported).
node(n988,supported) :- node(n994,supported).
node(n988,supported) :- node(n9,supported).
node(n988,unknown) :- \+ node(n988,supported), \+ node(n988,refuted).
verdict(c_4d1927aad4b47dd3,supported) :- node(n988,supported).
query(verdict(c_4d1927aad4b47dd3,supported)).
verdict(c_4d1927aad4b47dd3,refuted) :- node(n988,refuted).
query(verdict(c_4d1927aad4b47dd3,refuted)).
verdict(c_4d1927aad4b47dd3,unknown) :- node(n988,unknown).
query(verdict(c_4d1927aad4b47dd3,unknown)).
node(n1001,supported) :- status(o_f4372f91ef04d28b664e,supported).
node(n1001,refuted) :- status(o_f4372f91ef04d28b664e,refuted).
node(n1001,unknown) :- status(o_f4372f91ef04d28b664e,unknown).
node(n1002,supported) :- status(o_f6578062d2347187aae2,supported).
node(n1002,refuted) :- status(o_f6578062d2347187aae2,refuted).
node(n1002,unknown) :- status(o_f6578062d2347187aae2,unknown).
node(n1003,supported) :- status(o_3801bb65f9b835721eb1,supported).
node(n1003,refuted) :- status(o_3801bb65f9b835721eb1,refuted).
node(n1003,unknown) :- status(o_3801bb65f9b835721eb1,unknown).
node(n1004,supported) :- status(o_754a5e62f9895b9429c2,supported).
node(n1004,refuted) :- status(o_754a5e62f9895b9429c2,refuted).
node(n1004,unknown) :- status(o_754a5e62f9895b9429c2,unknown).
node(n1000,supported) :- node(n1001,supported), node(n1002,supported), node(n1003,supported), node(n1004,supported).
node(n1000,refuted) :- node(n1001,refuted).
node(n1000,refuted) :- node(n1002,refuted).
node(n1000,refuted) :- node(n1003,refuted).
node(n1000,refuted) :- node(n1004,refuted).
node(n1000,unknown) :- \+ node(n1000,supported), \+ node(n1000,refuted).
node(n1006,supported) :- status(o_d9aedf24173c22d880d2,supported).
node(n1006,refuted) :- status(o_d9aedf24173c22d880d2,refuted).
node(n1006,unknown) :- status(o_d9aedf24173c22d880d2,unknown).
node(n1007,supported) :- status(o_d208daf792bb4b4b31f1,supported).
node(n1007,refuted) :- status(o_d208daf792bb4b4b31f1,refuted).
node(n1007,unknown) :- status(o_d208daf792bb4b4b31f1,unknown).
node(n1008,supported) :- status(o_2a81113b58599e53f050,supported).
node(n1008,refuted) :- status(o_2a81113b58599e53f050,refuted).
node(n1008,unknown) :- status(o_2a81113b58599e53f050,unknown).
node(n1009,supported) :- status(o_f5347cbd038d23b745cc,supported).
node(n1009,refuted) :- status(o_f5347cbd038d23b745cc,refuted).
node(n1009,unknown) :- status(o_f5347cbd038d23b745cc,unknown).
node(n1005,supported) :- node(n1006,supported), node(n1007,supported), node(n1008,supported), node(n1009,supported).
node(n1005,refuted) :- node(n1006,refuted).
node(n1005,refuted) :- node(n1007,refuted).
node(n1005,refuted) :- node(n1008,refuted).
node(n1005,refuted) :- node(n1009,refuted).
node(n1005,unknown) :- \+ node(n1005,supported), \+ node(n1005,refuted).
node(n999,refuted) :- node(n1000,refuted), node(n1005,refuted), node(n9,refuted).
node(n999,supported) :- node(n1000,supported).
node(n999,supported) :- node(n1005,supported).
node(n999,supported) :- node(n9,supported).
node(n999,unknown) :- \+ node(n999,supported), \+ node(n999,refuted).
verdict(c_d1d0e6956a75203a,supported) :- node(n999,supported).
query(verdict(c_d1d0e6956a75203a,supported)).
verdict(c_d1d0e6956a75203a,refuted) :- node(n999,refuted).
query(verdict(c_d1d0e6956a75203a,refuted)).
verdict(c_d1d0e6956a75203a,unknown) :- node(n999,unknown).
query(verdict(c_d1d0e6956a75203a,unknown)).
node(n1012,supported) :- status(o_eed2867752b2c39965ac,supported).
node(n1012,refuted) :- status(o_eed2867752b2c39965ac,refuted).
node(n1012,unknown) :- status(o_eed2867752b2c39965ac,unknown).
node(n1013,supported) :- status(o_032d682d1b49d19d74da,supported).
node(n1013,refuted) :- status(o_032d682d1b49d19d74da,refuted).
node(n1013,unknown) :- status(o_032d682d1b49d19d74da,unknown).
node(n1014,supported) :- status(o_060bf76258d0a00c3a21,supported).
node(n1014,refuted) :- status(o_060bf76258d0a00c3a21,refuted).
node(n1014,unknown) :- status(o_060bf76258d0a00c3a21,unknown).
node(n1015,supported) :- status(o_f1e74a26f62316ca208a,supported).
node(n1015,refuted) :- status(o_f1e74a26f62316ca208a,refuted).
node(n1015,unknown) :- status(o_f1e74a26f62316ca208a,unknown).
node(n1011,supported) :- node(n1012,supported), node(n1013,supported), node(n1014,supported), node(n1015,supported).
node(n1011,refuted) :- node(n1012,refuted).
node(n1011,refuted) :- node(n1013,refuted).
node(n1011,refuted) :- node(n1014,refuted).
node(n1011,refuted) :- node(n1015,refuted).
node(n1011,unknown) :- \+ node(n1011,supported), \+ node(n1011,refuted).
node(n1017,supported) :- status(o_3ee4ba0812fa24956733,supported).
node(n1017,refuted) :- status(o_3ee4ba0812fa24956733,refuted).
node(n1017,unknown) :- status(o_3ee4ba0812fa24956733,unknown).
node(n1018,supported) :- status(o_b6e1bcc617624bdc684a,supported).
node(n1018,refuted) :- status(o_b6e1bcc617624bdc684a,refuted).
node(n1018,unknown) :- status(o_b6e1bcc617624bdc684a,unknown).
node(n1019,supported) :- status(o_39778b09351a3148af76,supported).
node(n1019,refuted) :- status(o_39778b09351a3148af76,refuted).
node(n1019,unknown) :- status(o_39778b09351a3148af76,unknown).
node(n1020,supported) :- status(o_1fbb141553d2890483ca,supported).
node(n1020,refuted) :- status(o_1fbb141553d2890483ca,refuted).
node(n1020,unknown) :- status(o_1fbb141553d2890483ca,unknown).
node(n1016,supported) :- node(n1017,supported), node(n1018,supported), node(n1019,supported), node(n1020,supported).
node(n1016,refuted) :- node(n1017,refuted).
node(n1016,refuted) :- node(n1018,refuted).
node(n1016,refuted) :- node(n1019,refuted).
node(n1016,refuted) :- node(n1020,refuted).
node(n1016,unknown) :- \+ node(n1016,supported), \+ node(n1016,refuted).
node(n1010,refuted) :- node(n1011,refuted), node(n1016,refuted), node(n9,refuted).
node(n1010,supported) :- node(n1011,supported).
node(n1010,supported) :- node(n1016,supported).
node(n1010,supported) :- node(n9,supported).
node(n1010,unknown) :- \+ node(n1010,supported), \+ node(n1010,refuted).
verdict(c_50b257b8f9099213,supported) :- node(n1010,supported).
query(verdict(c_50b257b8f9099213,supported)).
verdict(c_50b257b8f9099213,refuted) :- node(n1010,refuted).
query(verdict(c_50b257b8f9099213,refuted)).
verdict(c_50b257b8f9099213,unknown) :- node(n1010,unknown).
query(verdict(c_50b257b8f9099213,unknown)).
node(n1023,supported) :- status(o_6b0abad21eaff72b5c60,supported).
node(n1023,refuted) :- status(o_6b0abad21eaff72b5c60,refuted).
node(n1023,unknown) :- status(o_6b0abad21eaff72b5c60,unknown).
node(n1024,supported) :- status(o_d3e4c9c731b5111421a5,supported).
node(n1024,refuted) :- status(o_d3e4c9c731b5111421a5,refuted).
node(n1024,unknown) :- status(o_d3e4c9c731b5111421a5,unknown).
node(n1025,supported) :- status(o_836fb12b9690bc498e14,supported).
node(n1025,refuted) :- status(o_836fb12b9690bc498e14,refuted).
node(n1025,unknown) :- status(o_836fb12b9690bc498e14,unknown).
node(n1022,supported) :- node(n1023,supported), node(n1024,supported), node(n1025,supported).
node(n1022,refuted) :- node(n1023,refuted).
node(n1022,refuted) :- node(n1024,refuted).
node(n1022,refuted) :- node(n1025,refuted).
node(n1022,unknown) :- \+ node(n1022,supported), \+ node(n1022,refuted).
node(n1027,supported) :- status(o_a24f6920764e14c87cb7,supported).
node(n1027,refuted) :- status(o_a24f6920764e14c87cb7,refuted).
node(n1027,unknown) :- status(o_a24f6920764e14c87cb7,unknown).
node(n1028,supported) :- status(o_bb18c9d9fec4a5067da7,supported).
node(n1028,refuted) :- status(o_bb18c9d9fec4a5067da7,refuted).
node(n1028,unknown) :- status(o_bb18c9d9fec4a5067da7,unknown).
node(n1029,supported) :- status(o_112e2a0d652ec3539bda,supported).
node(n1029,refuted) :- status(o_112e2a0d652ec3539bda,refuted).
node(n1029,unknown) :- status(o_112e2a0d652ec3539bda,unknown).
node(n1026,supported) :- node(n1027,supported), node(n1028,supported), node(n1029,supported).
node(n1026,refuted) :- node(n1027,refuted).
node(n1026,refuted) :- node(n1028,refuted).
node(n1026,refuted) :- node(n1029,refuted).
node(n1026,unknown) :- \+ node(n1026,supported), \+ node(n1026,refuted).
node(n1021,refuted) :- node(n1022,refuted), node(n1026,refuted), node(n9,refuted).
node(n1021,supported) :- node(n1022,supported).
node(n1021,supported) :- node(n1026,supported).
node(n1021,supported) :- node(n9,supported).
node(n1021,unknown) :- \+ node(n1021,supported), \+ node(n1021,refuted).
verdict(c_5a992ec8a968b4af,supported) :- node(n1021,supported).
query(verdict(c_5a992ec8a968b4af,supported)).
verdict(c_5a992ec8a968b4af,refuted) :- node(n1021,refuted).
query(verdict(c_5a992ec8a968b4af,refuted)).
verdict(c_5a992ec8a968b4af,unknown) :- node(n1021,unknown).
query(verdict(c_5a992ec8a968b4af,unknown)).
node(n1032,supported) :- status(o_4aee3cdb481ed904433b,supported).
node(n1032,refuted) :- status(o_4aee3cdb481ed904433b,refuted).
node(n1032,unknown) :- status(o_4aee3cdb481ed904433b,unknown).
node(n1033,supported) :- status(o_cda019e8d0fad21ba51d,supported).
node(n1033,refuted) :- status(o_cda019e8d0fad21ba51d,refuted).
node(n1033,unknown) :- status(o_cda019e8d0fad21ba51d,unknown).
node(n1034,supported) :- status(o_c0f3d0d377de91d95907,supported).
node(n1034,refuted) :- status(o_c0f3d0d377de91d95907,refuted).
node(n1034,unknown) :- status(o_c0f3d0d377de91d95907,unknown).
node(n1035,supported) :- status(o_9b630a8dcb7cdd733d01,supported).
node(n1035,refuted) :- status(o_9b630a8dcb7cdd733d01,refuted).
node(n1035,unknown) :- status(o_9b630a8dcb7cdd733d01,unknown).
node(n1031,supported) :- node(n1032,supported), node(n1033,supported), node(n1034,supported), node(n1035,supported).
node(n1031,refuted) :- node(n1032,refuted).
node(n1031,refuted) :- node(n1033,refuted).
node(n1031,refuted) :- node(n1034,refuted).
node(n1031,refuted) :- node(n1035,refuted).
node(n1031,unknown) :- \+ node(n1031,supported), \+ node(n1031,refuted).
node(n1037,supported) :- status(o_91d87a0d0f5d48d1add0,supported).
node(n1037,refuted) :- status(o_91d87a0d0f5d48d1add0,refuted).
node(n1037,unknown) :- status(o_91d87a0d0f5d48d1add0,unknown).
node(n1038,supported) :- status(o_44ead850c31571c1064d,supported).
node(n1038,refuted) :- status(o_44ead850c31571c1064d,refuted).
node(n1038,unknown) :- status(o_44ead850c31571c1064d,unknown).
node(n1039,supported) :- status(o_2beff14e0797e2a4132a,supported).
node(n1039,refuted) :- status(o_2beff14e0797e2a4132a,refuted).
node(n1039,unknown) :- status(o_2beff14e0797e2a4132a,unknown).
node(n1040,supported) :- status(o_6f21d3231fd831ede60f,supported).
node(n1040,refuted) :- status(o_6f21d3231fd831ede60f,refuted).
node(n1040,unknown) :- status(o_6f21d3231fd831ede60f,unknown).
node(n1036,supported) :- node(n1037,supported), node(n1038,supported), node(n1039,supported), node(n1040,supported).
node(n1036,refuted) :- node(n1037,refuted).
node(n1036,refuted) :- node(n1038,refuted).
node(n1036,refuted) :- node(n1039,refuted).
node(n1036,refuted) :- node(n1040,refuted).
node(n1036,unknown) :- \+ node(n1036,supported), \+ node(n1036,refuted).
node(n1030,refuted) :- node(n1031,refuted), node(n1036,refuted), node(n9,refuted).
node(n1030,supported) :- node(n1031,supported).
node(n1030,supported) :- node(n1036,supported).
node(n1030,supported) :- node(n9,supported).
node(n1030,unknown) :- \+ node(n1030,supported), \+ node(n1030,refuted).
verdict(c_5127cf239a21564c,supported) :- node(n1030,supported).
query(verdict(c_5127cf239a21564c,supported)).
verdict(c_5127cf239a21564c,refuted) :- node(n1030,refuted).
query(verdict(c_5127cf239a21564c,refuted)).
verdict(c_5127cf239a21564c,unknown) :- node(n1030,unknown).
query(verdict(c_5127cf239a21564c,unknown)).
node(n1043,supported) :- status(o_4956ebd7841f4b2dbbfa,supported).
node(n1043,refuted) :- status(o_4956ebd7841f4b2dbbfa,refuted).
node(n1043,unknown) :- status(o_4956ebd7841f4b2dbbfa,unknown).
node(n1044,supported) :- status(o_b5e0e5a466530334d0a2,supported).
node(n1044,refuted) :- status(o_b5e0e5a466530334d0a2,refuted).
node(n1044,unknown) :- status(o_b5e0e5a466530334d0a2,unknown).
node(n1045,supported) :- status(o_5347d3e42ba2bc53d991,supported).
node(n1045,refuted) :- status(o_5347d3e42ba2bc53d991,refuted).
node(n1045,unknown) :- status(o_5347d3e42ba2bc53d991,unknown).
node(n1046,supported) :- status(o_a74f939b3f2a0845ede0,supported).
node(n1046,refuted) :- status(o_a74f939b3f2a0845ede0,refuted).
node(n1046,unknown) :- status(o_a74f939b3f2a0845ede0,unknown).
node(n1042,supported) :- node(n1043,supported), node(n1044,supported), node(n1045,supported), node(n1046,supported).
node(n1042,refuted) :- node(n1043,refuted).
node(n1042,refuted) :- node(n1044,refuted).
node(n1042,refuted) :- node(n1045,refuted).
node(n1042,refuted) :- node(n1046,refuted).
node(n1042,unknown) :- \+ node(n1042,supported), \+ node(n1042,refuted).
node(n1048,supported) :- status(o_678e2847974edbda881a,supported).
node(n1048,refuted) :- status(o_678e2847974edbda881a,refuted).
node(n1048,unknown) :- status(o_678e2847974edbda881a,unknown).
node(n1049,supported) :- status(o_e14682bd6f638efbaa7f,supported).
node(n1049,refuted) :- status(o_e14682bd6f638efbaa7f,refuted).
node(n1049,unknown) :- status(o_e14682bd6f638efbaa7f,unknown).
node(n1050,supported) :- status(o_72e743c5aef0c7a0e1ae,supported).
node(n1050,refuted) :- status(o_72e743c5aef0c7a0e1ae,refuted).
node(n1050,unknown) :- status(o_72e743c5aef0c7a0e1ae,unknown).
node(n1051,supported) :- status(o_a1df8b1b0a191b840f64,supported).
node(n1051,refuted) :- status(o_a1df8b1b0a191b840f64,refuted).
node(n1051,unknown) :- status(o_a1df8b1b0a191b840f64,unknown).
node(n1047,supported) :- node(n1048,supported), node(n1049,supported), node(n1050,supported), node(n1051,supported).
node(n1047,refuted) :- node(n1048,refuted).
node(n1047,refuted) :- node(n1049,refuted).
node(n1047,refuted) :- node(n1050,refuted).
node(n1047,refuted) :- node(n1051,refuted).
node(n1047,unknown) :- \+ node(n1047,supported), \+ node(n1047,refuted).
node(n1041,refuted) :- node(n1042,refuted), node(n1047,refuted), node(n9,refuted).
node(n1041,supported) :- node(n1042,supported).
node(n1041,supported) :- node(n1047,supported).
node(n1041,supported) :- node(n9,supported).
node(n1041,unknown) :- \+ node(n1041,supported), \+ node(n1041,refuted).
verdict(c_6651f84ba0d7e1b0,supported) :- node(n1041,supported).
query(verdict(c_6651f84ba0d7e1b0,supported)).
verdict(c_6651f84ba0d7e1b0,refuted) :- node(n1041,refuted).
query(verdict(c_6651f84ba0d7e1b0,refuted)).
verdict(c_6651f84ba0d7e1b0,unknown) :- node(n1041,unknown).
query(verdict(c_6651f84ba0d7e1b0,unknown)).
node(n1054,supported) :- status(o_25ceb9fa4f69c4dc6ef2,supported).
node(n1054,refuted) :- status(o_25ceb9fa4f69c4dc6ef2,refuted).
node(n1054,unknown) :- status(o_25ceb9fa4f69c4dc6ef2,unknown).
node(n1055,supported) :- status(o_dd57d8628d17932bb36c,supported).
node(n1055,refuted) :- status(o_dd57d8628d17932bb36c,refuted).
node(n1055,unknown) :- status(o_dd57d8628d17932bb36c,unknown).
node(n1056,supported) :- status(o_3d5223e94b62df0ed33f,supported).
node(n1056,refuted) :- status(o_3d5223e94b62df0ed33f,refuted).
node(n1056,unknown) :- status(o_3d5223e94b62df0ed33f,unknown).
node(n1057,supported) :- status(o_4865d8b53913358047ac,supported).
node(n1057,refuted) :- status(o_4865d8b53913358047ac,refuted).
node(n1057,unknown) :- status(o_4865d8b53913358047ac,unknown).
node(n1053,supported) :- node(n1054,supported), node(n1055,supported), node(n1056,supported), node(n1057,supported).
node(n1053,refuted) :- node(n1054,refuted).
node(n1053,refuted) :- node(n1055,refuted).
node(n1053,refuted) :- node(n1056,refuted).
node(n1053,refuted) :- node(n1057,refuted).
node(n1053,unknown) :- \+ node(n1053,supported), \+ node(n1053,refuted).
node(n1059,supported) :- status(o_3d369f995ab971c6c2e6,supported).
node(n1059,refuted) :- status(o_3d369f995ab971c6c2e6,refuted).
node(n1059,unknown) :- status(o_3d369f995ab971c6c2e6,unknown).
node(n1060,supported) :- status(o_0ef255dcd24b4d1f7d48,supported).
node(n1060,refuted) :- status(o_0ef255dcd24b4d1f7d48,refuted).
node(n1060,unknown) :- status(o_0ef255dcd24b4d1f7d48,unknown).
node(n1061,supported) :- status(o_e3feadf276d8fc2c5bfb,supported).
node(n1061,refuted) :- status(o_e3feadf276d8fc2c5bfb,refuted).
node(n1061,unknown) :- status(o_e3feadf276d8fc2c5bfb,unknown).
node(n1062,supported) :- status(o_b5d515d69a4982d63ccc,supported).
node(n1062,refuted) :- status(o_b5d515d69a4982d63ccc,refuted).
node(n1062,unknown) :- status(o_b5d515d69a4982d63ccc,unknown).
node(n1058,supported) :- node(n1059,supported), node(n1060,supported), node(n1061,supported), node(n1062,supported).
node(n1058,refuted) :- node(n1059,refuted).
node(n1058,refuted) :- node(n1060,refuted).
node(n1058,refuted) :- node(n1061,refuted).
node(n1058,refuted) :- node(n1062,refuted).
node(n1058,unknown) :- \+ node(n1058,supported), \+ node(n1058,refuted).
node(n1052,refuted) :- node(n1053,refuted), node(n1058,refuted), node(n9,refuted).
node(n1052,supported) :- node(n1053,supported).
node(n1052,supported) :- node(n1058,supported).
node(n1052,supported) :- node(n9,supported).
node(n1052,unknown) :- \+ node(n1052,supported), \+ node(n1052,refuted).
verdict(c_12e56224f40f34f8,supported) :- node(n1052,supported).
query(verdict(c_12e56224f40f34f8,supported)).
verdict(c_12e56224f40f34f8,refuted) :- node(n1052,refuted).
query(verdict(c_12e56224f40f34f8,refuted)).
verdict(c_12e56224f40f34f8,unknown) :- node(n1052,unknown).
query(verdict(c_12e56224f40f34f8,unknown)).
node(n1065,supported) :- status(o_bdca5d32ba0923f5461c,supported).
node(n1065,refuted) :- status(o_bdca5d32ba0923f5461c,refuted).
node(n1065,unknown) :- status(o_bdca5d32ba0923f5461c,unknown).
node(n1066,supported) :- status(o_ad085c3429fdd3eb2559,supported).
node(n1066,refuted) :- status(o_ad085c3429fdd3eb2559,refuted).
node(n1066,unknown) :- status(o_ad085c3429fdd3eb2559,unknown).
node(n1067,supported) :- status(o_d58522cf484d985ed585,supported).
node(n1067,refuted) :- status(o_d58522cf484d985ed585,refuted).
node(n1067,unknown) :- status(o_d58522cf484d985ed585,unknown).
node(n1064,supported) :- node(n1065,supported), node(n1066,supported), node(n1067,supported).
node(n1064,refuted) :- node(n1065,refuted).
node(n1064,refuted) :- node(n1066,refuted).
node(n1064,refuted) :- node(n1067,refuted).
node(n1064,unknown) :- \+ node(n1064,supported), \+ node(n1064,refuted).
node(n1069,supported) :- status(o_a0a14b68747d20b3ca71,supported).
node(n1069,refuted) :- status(o_a0a14b68747d20b3ca71,refuted).
node(n1069,unknown) :- status(o_a0a14b68747d20b3ca71,unknown).
node(n1070,supported) :- status(o_c132fed578dee4d371ed,supported).
node(n1070,refuted) :- status(o_c132fed578dee4d371ed,refuted).
node(n1070,unknown) :- status(o_c132fed578dee4d371ed,unknown).
node(n1071,supported) :- status(o_c46bb9220bf685fad680,supported).
node(n1071,refuted) :- status(o_c46bb9220bf685fad680,refuted).
node(n1071,unknown) :- status(o_c46bb9220bf685fad680,unknown).
node(n1068,supported) :- node(n1069,supported), node(n1070,supported), node(n1071,supported).
node(n1068,refuted) :- node(n1069,refuted).
node(n1068,refuted) :- node(n1070,refuted).
node(n1068,refuted) :- node(n1071,refuted).
node(n1068,unknown) :- \+ node(n1068,supported), \+ node(n1068,refuted).
node(n1063,refuted) :- node(n1064,refuted), node(n1068,refuted), node(n9,refuted).
node(n1063,supported) :- node(n1064,supported).
node(n1063,supported) :- node(n1068,supported).
node(n1063,supported) :- node(n9,supported).
node(n1063,unknown) :- \+ node(n1063,supported), \+ node(n1063,refuted).
verdict(c_f9ae84851ddd01a3,supported) :- node(n1063,supported).
query(verdict(c_f9ae84851ddd01a3,supported)).
verdict(c_f9ae84851ddd01a3,refuted) :- node(n1063,refuted).
query(verdict(c_f9ae84851ddd01a3,refuted)).
verdict(c_f9ae84851ddd01a3,unknown) :- node(n1063,unknown).
query(verdict(c_f9ae84851ddd01a3,unknown)).
node(n1074,supported) :- status(o_e96e6d602b3170911c18,supported).
node(n1074,refuted) :- status(o_e96e6d602b3170911c18,refuted).
node(n1074,unknown) :- status(o_e96e6d602b3170911c18,unknown).
node(n1075,supported) :- status(o_d6e9070ccb5ac0abf8a5,supported).
node(n1075,refuted) :- status(o_d6e9070ccb5ac0abf8a5,refuted).
node(n1075,unknown) :- status(o_d6e9070ccb5ac0abf8a5,unknown).
node(n1076,supported) :- status(o_8369477e5f47ddd0ec63,supported).
node(n1076,refuted) :- status(o_8369477e5f47ddd0ec63,refuted).
node(n1076,unknown) :- status(o_8369477e5f47ddd0ec63,unknown).
node(n1077,supported) :- status(o_9832c0c8da6e4d701a2d,supported).
node(n1077,refuted) :- status(o_9832c0c8da6e4d701a2d,refuted).
node(n1077,unknown) :- status(o_9832c0c8da6e4d701a2d,unknown).
node(n1073,supported) :- node(n1074,supported), node(n1075,supported), node(n1076,supported), node(n1077,supported).
node(n1073,refuted) :- node(n1074,refuted).
node(n1073,refuted) :- node(n1075,refuted).
node(n1073,refuted) :- node(n1076,refuted).
node(n1073,refuted) :- node(n1077,refuted).
node(n1073,unknown) :- \+ node(n1073,supported), \+ node(n1073,refuted).
node(n1079,supported) :- status(o_700c7a349a050fb0d69b,supported).
node(n1079,refuted) :- status(o_700c7a349a050fb0d69b,refuted).
node(n1079,unknown) :- status(o_700c7a349a050fb0d69b,unknown).
node(n1080,supported) :- status(o_67f362038ae07dc6785f,supported).
node(n1080,refuted) :- status(o_67f362038ae07dc6785f,refuted).
node(n1080,unknown) :- status(o_67f362038ae07dc6785f,unknown).
node(n1081,supported) :- status(o_33c84e23086d3d1c4d71,supported).
node(n1081,refuted) :- status(o_33c84e23086d3d1c4d71,refuted).
node(n1081,unknown) :- status(o_33c84e23086d3d1c4d71,unknown).
node(n1082,supported) :- status(o_14c8bac5d590172949bb,supported).
node(n1082,refuted) :- status(o_14c8bac5d590172949bb,refuted).
node(n1082,unknown) :- status(o_14c8bac5d590172949bb,unknown).
node(n1078,supported) :- node(n1079,supported), node(n1080,supported), node(n1081,supported), node(n1082,supported).
node(n1078,refuted) :- node(n1079,refuted).
node(n1078,refuted) :- node(n1080,refuted).
node(n1078,refuted) :- node(n1081,refuted).
node(n1078,refuted) :- node(n1082,refuted).
node(n1078,unknown) :- \+ node(n1078,supported), \+ node(n1078,refuted).
node(n1072,refuted) :- node(n1073,refuted), node(n1078,refuted), node(n9,refuted).
node(n1072,supported) :- node(n1073,supported).
node(n1072,supported) :- node(n1078,supported).
node(n1072,supported) :- node(n9,supported).
node(n1072,unknown) :- \+ node(n1072,supported), \+ node(n1072,refuted).
verdict(c_de38e3ebc586e202,supported) :- node(n1072,supported).
query(verdict(c_de38e3ebc586e202,supported)).
verdict(c_de38e3ebc586e202,refuted) :- node(n1072,refuted).
query(verdict(c_de38e3ebc586e202,refuted)).
verdict(c_de38e3ebc586e202,unknown) :- node(n1072,unknown).
query(verdict(c_de38e3ebc586e202,unknown)).
node(n1085,supported) :- status(o_1ceb53b4a10a944203e2,supported).
node(n1085,refuted) :- status(o_1ceb53b4a10a944203e2,refuted).
node(n1085,unknown) :- status(o_1ceb53b4a10a944203e2,unknown).
node(n1086,supported) :- status(o_f3bbbd2224fcc2109168,supported).
node(n1086,refuted) :- status(o_f3bbbd2224fcc2109168,refuted).
node(n1086,unknown) :- status(o_f3bbbd2224fcc2109168,unknown).
node(n1087,supported) :- status(o_7bbae0e47ef3c8aa5dbe,supported).
node(n1087,refuted) :- status(o_7bbae0e47ef3c8aa5dbe,refuted).
node(n1087,unknown) :- status(o_7bbae0e47ef3c8aa5dbe,unknown).
node(n1088,supported) :- status(o_a820966ae1f6a7409351,supported).
node(n1088,refuted) :- status(o_a820966ae1f6a7409351,refuted).
node(n1088,unknown) :- status(o_a820966ae1f6a7409351,unknown).
node(n1084,supported) :- node(n1085,supported), node(n1086,supported), node(n1087,supported), node(n1088,supported).
node(n1084,refuted) :- node(n1085,refuted).
node(n1084,refuted) :- node(n1086,refuted).
node(n1084,refuted) :- node(n1087,refuted).
node(n1084,refuted) :- node(n1088,refuted).
node(n1084,unknown) :- \+ node(n1084,supported), \+ node(n1084,refuted).
node(n1090,supported) :- status(o_355b9ea7abbd746d1146,supported).
node(n1090,refuted) :- status(o_355b9ea7abbd746d1146,refuted).
node(n1090,unknown) :- status(o_355b9ea7abbd746d1146,unknown).
node(n1091,supported) :- status(o_84e16fa617233a4d72ab,supported).
node(n1091,refuted) :- status(o_84e16fa617233a4d72ab,refuted).
node(n1091,unknown) :- status(o_84e16fa617233a4d72ab,unknown).
node(n1092,supported) :- status(o_cf9a5e3b8d14a71db84a,supported).
node(n1092,refuted) :- status(o_cf9a5e3b8d14a71db84a,refuted).
node(n1092,unknown) :- status(o_cf9a5e3b8d14a71db84a,unknown).
node(n1093,supported) :- status(o_5656525bbdb4a0a237c1,supported).
node(n1093,refuted) :- status(o_5656525bbdb4a0a237c1,refuted).
node(n1093,unknown) :- status(o_5656525bbdb4a0a237c1,unknown).
node(n1089,supported) :- node(n1090,supported), node(n1091,supported), node(n1092,supported), node(n1093,supported).
node(n1089,refuted) :- node(n1090,refuted).
node(n1089,refuted) :- node(n1091,refuted).
node(n1089,refuted) :- node(n1092,refuted).
node(n1089,refuted) :- node(n1093,refuted).
node(n1089,unknown) :- \+ node(n1089,supported), \+ node(n1089,refuted).
node(n1083,refuted) :- node(n1084,refuted), node(n1089,refuted), node(n9,refuted).
node(n1083,supported) :- node(n1084,supported).
node(n1083,supported) :- node(n1089,supported).
node(n1083,supported) :- node(n9,supported).
node(n1083,unknown) :- \+ node(n1083,supported), \+ node(n1083,refuted).
verdict(c_67198fa57711e2c0,supported) :- node(n1083,supported).
query(verdict(c_67198fa57711e2c0,supported)).
verdict(c_67198fa57711e2c0,refuted) :- node(n1083,refuted).
query(verdict(c_67198fa57711e2c0,refuted)).
verdict(c_67198fa57711e2c0,unknown) :- node(n1083,unknown).
query(verdict(c_67198fa57711e2c0,unknown)).
node(n1096,supported) :- status(o_16618e7be493465642a4,supported).
node(n1096,refuted) :- status(o_16618e7be493465642a4,refuted).
node(n1096,unknown) :- status(o_16618e7be493465642a4,unknown).
node(n1097,supported) :- status(o_2d49d0889550ad05c77e,supported).
node(n1097,refuted) :- status(o_2d49d0889550ad05c77e,refuted).
node(n1097,unknown) :- status(o_2d49d0889550ad05c77e,unknown).
node(n1098,supported) :- status(o_8f3ee2f3ec0690291f56,supported).
node(n1098,refuted) :- status(o_8f3ee2f3ec0690291f56,refuted).
node(n1098,unknown) :- status(o_8f3ee2f3ec0690291f56,unknown).
node(n1099,supported) :- status(o_b8bd1cc9f993f0188714,supported).
node(n1099,refuted) :- status(o_b8bd1cc9f993f0188714,refuted).
node(n1099,unknown) :- status(o_b8bd1cc9f993f0188714,unknown).
node(n1095,supported) :- node(n1096,supported), node(n1097,supported), node(n1098,supported), node(n1099,supported).
node(n1095,refuted) :- node(n1096,refuted).
node(n1095,refuted) :- node(n1097,refuted).
node(n1095,refuted) :- node(n1098,refuted).
node(n1095,refuted) :- node(n1099,refuted).
node(n1095,unknown) :- \+ node(n1095,supported), \+ node(n1095,refuted).
node(n1101,supported) :- status(o_f1d171b673d93c68898f,supported).
node(n1101,refuted) :- status(o_f1d171b673d93c68898f,refuted).
node(n1101,unknown) :- status(o_f1d171b673d93c68898f,unknown).
node(n1102,supported) :- status(o_59a3c08799dec2ed7724,supported).
node(n1102,refuted) :- status(o_59a3c08799dec2ed7724,refuted).
node(n1102,unknown) :- status(o_59a3c08799dec2ed7724,unknown).
node(n1103,supported) :- status(o_7f2cb7d398f60b1f2295,supported).
node(n1103,refuted) :- status(o_7f2cb7d398f60b1f2295,refuted).
node(n1103,unknown) :- status(o_7f2cb7d398f60b1f2295,unknown).
node(n1104,supported) :- status(o_37ce9b247bf80a40a21c,supported).
node(n1104,refuted) :- status(o_37ce9b247bf80a40a21c,refuted).
node(n1104,unknown) :- status(o_37ce9b247bf80a40a21c,unknown).
node(n1100,supported) :- node(n1101,supported), node(n1102,supported), node(n1103,supported), node(n1104,supported).
node(n1100,refuted) :- node(n1101,refuted).
node(n1100,refuted) :- node(n1102,refuted).
node(n1100,refuted) :- node(n1103,refuted).
node(n1100,refuted) :- node(n1104,refuted).
node(n1100,unknown) :- \+ node(n1100,supported), \+ node(n1100,refuted).
node(n1094,refuted) :- node(n1095,refuted), node(n1100,refuted), node(n9,refuted).
node(n1094,supported) :- node(n1095,supported).
node(n1094,supported) :- node(n1100,supported).
node(n1094,supported) :- node(n9,supported).
node(n1094,unknown) :- \+ node(n1094,supported), \+ node(n1094,refuted).
verdict(c_a1ee29a0bede6934,supported) :- node(n1094,supported).
query(verdict(c_a1ee29a0bede6934,supported)).
verdict(c_a1ee29a0bede6934,refuted) :- node(n1094,refuted).
query(verdict(c_a1ee29a0bede6934,refuted)).
verdict(c_a1ee29a0bede6934,unknown) :- node(n1094,unknown).
query(verdict(c_a1ee29a0bede6934,unknown)).
node(n1107,supported) :- status(o_8d7194f1159c22291b34,supported).
node(n1107,refuted) :- status(o_8d7194f1159c22291b34,refuted).
node(n1107,unknown) :- status(o_8d7194f1159c22291b34,unknown).
node(n1108,supported) :- status(o_fd05fe030c73478a4d3f,supported).
node(n1108,refuted) :- status(o_fd05fe030c73478a4d3f,refuted).
node(n1108,unknown) :- status(o_fd05fe030c73478a4d3f,unknown).
node(n1109,supported) :- status(o_c27f27c89a11a0c4245b,supported).
node(n1109,refuted) :- status(o_c27f27c89a11a0c4245b,refuted).
node(n1109,unknown) :- status(o_c27f27c89a11a0c4245b,unknown).
node(n1106,supported) :- node(n1107,supported), node(n1108,supported), node(n1109,supported).
node(n1106,refuted) :- node(n1107,refuted).
node(n1106,refuted) :- node(n1108,refuted).
node(n1106,refuted) :- node(n1109,refuted).
node(n1106,unknown) :- \+ node(n1106,supported), \+ node(n1106,refuted).
node(n1111,supported) :- status(o_66c45649dc481cdc23a5,supported).
node(n1111,refuted) :- status(o_66c45649dc481cdc23a5,refuted).
node(n1111,unknown) :- status(o_66c45649dc481cdc23a5,unknown).
node(n1112,supported) :- status(o_8da2ec05cff0a0ace46e,supported).
node(n1112,refuted) :- status(o_8da2ec05cff0a0ace46e,refuted).
node(n1112,unknown) :- status(o_8da2ec05cff0a0ace46e,unknown).
node(n1113,supported) :- status(o_045aaf59e47a1322b521,supported).
node(n1113,refuted) :- status(o_045aaf59e47a1322b521,refuted).
node(n1113,unknown) :- status(o_045aaf59e47a1322b521,unknown).
node(n1110,supported) :- node(n1111,supported), node(n1112,supported), node(n1113,supported).
node(n1110,refuted) :- node(n1111,refuted).
node(n1110,refuted) :- node(n1112,refuted).
node(n1110,refuted) :- node(n1113,refuted).
node(n1110,unknown) :- \+ node(n1110,supported), \+ node(n1110,refuted).
node(n1105,refuted) :- node(n1106,refuted), node(n1110,refuted), node(n9,refuted).
node(n1105,supported) :- node(n1106,supported).
node(n1105,supported) :- node(n1110,supported).
node(n1105,supported) :- node(n9,supported).
node(n1105,unknown) :- \+ node(n1105,supported), \+ node(n1105,refuted).
verdict(c_a7d8c519f572df40,supported) :- node(n1105,supported).
query(verdict(c_a7d8c519f572df40,supported)).
verdict(c_a7d8c519f572df40,refuted) :- node(n1105,refuted).
query(verdict(c_a7d8c519f572df40,refuted)).
verdict(c_a7d8c519f572df40,unknown) :- node(n1105,unknown).
query(verdict(c_a7d8c519f572df40,unknown)).
node(n1116,supported) :- status(o_6e4647d4b43561d1fdbc,supported).
node(n1116,refuted) :- status(o_6e4647d4b43561d1fdbc,refuted).
node(n1116,unknown) :- status(o_6e4647d4b43561d1fdbc,unknown).
node(n1117,supported) :- status(o_67af35a0ea8c2de1d4b2,supported).
node(n1117,refuted) :- status(o_67af35a0ea8c2de1d4b2,refuted).
node(n1117,unknown) :- status(o_67af35a0ea8c2de1d4b2,unknown).
node(n1118,supported) :- status(o_eb09ac1f2d6009f160f1,supported).
node(n1118,refuted) :- status(o_eb09ac1f2d6009f160f1,refuted).
node(n1118,unknown) :- status(o_eb09ac1f2d6009f160f1,unknown).
node(n1119,supported) :- status(o_82b2b1c5e3eccec268b9,supported).
node(n1119,refuted) :- status(o_82b2b1c5e3eccec268b9,refuted).
node(n1119,unknown) :- status(o_82b2b1c5e3eccec268b9,unknown).
node(n1115,supported) :- node(n1116,supported), node(n1117,supported), node(n1118,supported), node(n1119,supported).
node(n1115,refuted) :- node(n1116,refuted).
node(n1115,refuted) :- node(n1117,refuted).
node(n1115,refuted) :- node(n1118,refuted).
node(n1115,refuted) :- node(n1119,refuted).
node(n1115,unknown) :- \+ node(n1115,supported), \+ node(n1115,refuted).
node(n1121,supported) :- status(o_6d93f26475345fc6f68d,supported).
node(n1121,refuted) :- status(o_6d93f26475345fc6f68d,refuted).
node(n1121,unknown) :- status(o_6d93f26475345fc6f68d,unknown).
node(n1122,supported) :- status(o_049a81424d015bb5f479,supported).
node(n1122,refuted) :- status(o_049a81424d015bb5f479,refuted).
node(n1122,unknown) :- status(o_049a81424d015bb5f479,unknown).
node(n1123,supported) :- status(o_e817cd45ae8ffb6075ef,supported).
node(n1123,refuted) :- status(o_e817cd45ae8ffb6075ef,refuted).
node(n1123,unknown) :- status(o_e817cd45ae8ffb6075ef,unknown).
node(n1124,supported) :- status(o_0b8a594e2384acef8925,supported).
node(n1124,refuted) :- status(o_0b8a594e2384acef8925,refuted).
node(n1124,unknown) :- status(o_0b8a594e2384acef8925,unknown).
node(n1120,supported) :- node(n1121,supported), node(n1122,supported), node(n1123,supported), node(n1124,supported).
node(n1120,refuted) :- node(n1121,refuted).
node(n1120,refuted) :- node(n1122,refuted).
node(n1120,refuted) :- node(n1123,refuted).
node(n1120,refuted) :- node(n1124,refuted).
node(n1120,unknown) :- \+ node(n1120,supported), \+ node(n1120,refuted).
node(n1114,refuted) :- node(n1115,refuted), node(n1120,refuted), node(n9,refuted).
node(n1114,supported) :- node(n1115,supported).
node(n1114,supported) :- node(n1120,supported).
node(n1114,supported) :- node(n9,supported).
node(n1114,unknown) :- \+ node(n1114,supported), \+ node(n1114,refuted).
verdict(c_be9d10bf619f48a5,supported) :- node(n1114,supported).
query(verdict(c_be9d10bf619f48a5,supported)).
verdict(c_be9d10bf619f48a5,refuted) :- node(n1114,refuted).
query(verdict(c_be9d10bf619f48a5,refuted)).
verdict(c_be9d10bf619f48a5,unknown) :- node(n1114,unknown).
query(verdict(c_be9d10bf619f48a5,unknown)).
node(n1127,supported) :- status(o_8706dc1df63bd2d65aae,supported).
node(n1127,refuted) :- status(o_8706dc1df63bd2d65aae,refuted).
node(n1127,unknown) :- status(o_8706dc1df63bd2d65aae,unknown).
node(n1128,supported) :- status(o_a5bd26d7c53cb46b62a5,supported).
node(n1128,refuted) :- status(o_a5bd26d7c53cb46b62a5,refuted).
node(n1128,unknown) :- status(o_a5bd26d7c53cb46b62a5,unknown).
node(n1129,supported) :- status(o_7fe99231c72cd79dd2af,supported).
node(n1129,refuted) :- status(o_7fe99231c72cd79dd2af,refuted).
node(n1129,unknown) :- status(o_7fe99231c72cd79dd2af,unknown).
node(n1130,supported) :- status(o_78be6857d601b49cd1d8,supported).
node(n1130,refuted) :- status(o_78be6857d601b49cd1d8,refuted).
node(n1130,unknown) :- status(o_78be6857d601b49cd1d8,unknown).
node(n1126,supported) :- node(n1127,supported), node(n1128,supported), node(n1129,supported), node(n1130,supported).
node(n1126,refuted) :- node(n1127,refuted).
node(n1126,refuted) :- node(n1128,refuted).
node(n1126,refuted) :- node(n1129,refuted).
node(n1126,refuted) :- node(n1130,refuted).
node(n1126,unknown) :- \+ node(n1126,supported), \+ node(n1126,refuted).
node(n1132,supported) :- status(o_bdecc11e1fd3eb264b89,supported).
node(n1132,refuted) :- status(o_bdecc11e1fd3eb264b89,refuted).
node(n1132,unknown) :- status(o_bdecc11e1fd3eb264b89,unknown).
node(n1133,supported) :- status(o_02f8a48ab6b74937c9d3,supported).
node(n1133,refuted) :- status(o_02f8a48ab6b74937c9d3,refuted).
node(n1133,unknown) :- status(o_02f8a48ab6b74937c9d3,unknown).
node(n1134,supported) :- status(o_ff615e2386f9d54bd884,supported).
node(n1134,refuted) :- status(o_ff615e2386f9d54bd884,refuted).
node(n1134,unknown) :- status(o_ff615e2386f9d54bd884,unknown).
node(n1135,supported) :- status(o_3d872477d0fafd2e69d0,supported).
node(n1135,refuted) :- status(o_3d872477d0fafd2e69d0,refuted).
node(n1135,unknown) :- status(o_3d872477d0fafd2e69d0,unknown).
node(n1131,supported) :- node(n1132,supported), node(n1133,supported), node(n1134,supported), node(n1135,supported).
node(n1131,refuted) :- node(n1132,refuted).
node(n1131,refuted) :- node(n1133,refuted).
node(n1131,refuted) :- node(n1134,refuted).
node(n1131,refuted) :- node(n1135,refuted).
node(n1131,unknown) :- \+ node(n1131,supported), \+ node(n1131,refuted).
node(n1125,refuted) :- node(n1126,refuted), node(n1131,refuted), node(n9,refuted).
node(n1125,supported) :- node(n1126,supported).
node(n1125,supported) :- node(n1131,supported).
node(n1125,supported) :- node(n9,supported).
node(n1125,unknown) :- \+ node(n1125,supported), \+ node(n1125,refuted).
verdict(c_1df5aa4c76b3de53,supported) :- node(n1125,supported).
query(verdict(c_1df5aa4c76b3de53,supported)).
verdict(c_1df5aa4c76b3de53,refuted) :- node(n1125,refuted).
query(verdict(c_1df5aa4c76b3de53,refuted)).
verdict(c_1df5aa4c76b3de53,unknown) :- node(n1125,unknown).
query(verdict(c_1df5aa4c76b3de53,unknown)).
node(n1138,supported) :- status(o_ef342d81bcc2832ab377,supported).
node(n1138,refuted) :- status(o_ef342d81bcc2832ab377,refuted).
node(n1138,unknown) :- status(o_ef342d81bcc2832ab377,unknown).
node(n1139,supported) :- status(o_02a368cb5b9b36ce5fc1,supported).
node(n1139,refuted) :- status(o_02a368cb5b9b36ce5fc1,refuted).
node(n1139,unknown) :- status(o_02a368cb5b9b36ce5fc1,unknown).
node(n1140,supported) :- status(o_a8b99355a4444259bb21,supported).
node(n1140,refuted) :- status(o_a8b99355a4444259bb21,refuted).
node(n1140,unknown) :- status(o_a8b99355a4444259bb21,unknown).
node(n1141,supported) :- status(o_3176c768a8c28b372d0b,supported).
node(n1141,refuted) :- status(o_3176c768a8c28b372d0b,refuted).
node(n1141,unknown) :- status(o_3176c768a8c28b372d0b,unknown).
node(n1137,supported) :- node(n1138,supported), node(n1139,supported), node(n1140,supported), node(n1141,supported).
node(n1137,refuted) :- node(n1138,refuted).
node(n1137,refuted) :- node(n1139,refuted).
node(n1137,refuted) :- node(n1140,refuted).
node(n1137,refuted) :- node(n1141,refuted).
node(n1137,unknown) :- \+ node(n1137,supported), \+ node(n1137,refuted).
node(n1143,supported) :- status(o_5497ee0beb54cc3cc70f,supported).
node(n1143,refuted) :- status(o_5497ee0beb54cc3cc70f,refuted).
node(n1143,unknown) :- status(o_5497ee0beb54cc3cc70f,unknown).
node(n1144,supported) :- status(o_e23f55433d4c1e7b5354,supported).
node(n1144,refuted) :- status(o_e23f55433d4c1e7b5354,refuted).
node(n1144,unknown) :- status(o_e23f55433d4c1e7b5354,unknown).
node(n1145,supported) :- status(o_77b4fc96785ec067eae5,supported).
node(n1145,refuted) :- status(o_77b4fc96785ec067eae5,refuted).
node(n1145,unknown) :- status(o_77b4fc96785ec067eae5,unknown).
node(n1146,supported) :- status(o_c0fac4d93351ceaf8277,supported).
node(n1146,refuted) :- status(o_c0fac4d93351ceaf8277,refuted).
node(n1146,unknown) :- status(o_c0fac4d93351ceaf8277,unknown).
node(n1142,supported) :- node(n1143,supported), node(n1144,supported), node(n1145,supported), node(n1146,supported).
node(n1142,refuted) :- node(n1143,refuted).
node(n1142,refuted) :- node(n1144,refuted).
node(n1142,refuted) :- node(n1145,refuted).
node(n1142,refuted) :- node(n1146,refuted).
node(n1142,unknown) :- \+ node(n1142,supported), \+ node(n1142,refuted).
node(n1136,refuted) :- node(n1137,refuted), node(n1142,refuted), node(n9,refuted).
node(n1136,supported) :- node(n1137,supported).
node(n1136,supported) :- node(n1142,supported).
node(n1136,supported) :- node(n9,supported).
node(n1136,unknown) :- \+ node(n1136,supported), \+ node(n1136,refuted).
verdict(c_862e869faafba51a,supported) :- node(n1136,supported).
query(verdict(c_862e869faafba51a,supported)).
verdict(c_862e869faafba51a,refuted) :- node(n1136,refuted).
query(verdict(c_862e869faafba51a,refuted)).
verdict(c_862e869faafba51a,unknown) :- node(n1136,unknown).
query(verdict(c_862e869faafba51a,unknown)).
node(n1149,supported) :- status(o_55920f4a9a5758d9c921,supported).
node(n1149,refuted) :- status(o_55920f4a9a5758d9c921,refuted).
node(n1149,unknown) :- status(o_55920f4a9a5758d9c921,unknown).
node(n1150,supported) :- status(o_90980f81af9431f9601b,supported).
node(n1150,refuted) :- status(o_90980f81af9431f9601b,refuted).
node(n1150,unknown) :- status(o_90980f81af9431f9601b,unknown).
node(n1151,supported) :- status(o_73fb4e0ab6c90e240c97,supported).
node(n1151,refuted) :- status(o_73fb4e0ab6c90e240c97,refuted).
node(n1151,unknown) :- status(o_73fb4e0ab6c90e240c97,unknown).
node(n1148,supported) :- node(n1149,supported), node(n1150,supported), node(n1151,supported).
node(n1148,refuted) :- node(n1149,refuted).
node(n1148,refuted) :- node(n1150,refuted).
node(n1148,refuted) :- node(n1151,refuted).
node(n1148,unknown) :- \+ node(n1148,supported), \+ node(n1148,refuted).
node(n1153,supported) :- status(o_9a2d2617f98ba516101a,supported).
node(n1153,refuted) :- status(o_9a2d2617f98ba516101a,refuted).
node(n1153,unknown) :- status(o_9a2d2617f98ba516101a,unknown).
node(n1154,supported) :- status(o_3bccf11b36ee58a44a73,supported).
node(n1154,refuted) :- status(o_3bccf11b36ee58a44a73,refuted).
node(n1154,unknown) :- status(o_3bccf11b36ee58a44a73,unknown).
node(n1155,supported) :- status(o_efda2be13d76625cd3be,supported).
node(n1155,refuted) :- status(o_efda2be13d76625cd3be,refuted).
node(n1155,unknown) :- status(o_efda2be13d76625cd3be,unknown).
node(n1152,supported) :- node(n1153,supported), node(n1154,supported), node(n1155,supported).
node(n1152,refuted) :- node(n1153,refuted).
node(n1152,refuted) :- node(n1154,refuted).
node(n1152,refuted) :- node(n1155,refuted).
node(n1152,unknown) :- \+ node(n1152,supported), \+ node(n1152,refuted).
node(n1147,refuted) :- node(n1148,refuted), node(n1152,refuted), node(n9,refuted).
node(n1147,supported) :- node(n1148,supported).
node(n1147,supported) :- node(n1152,supported).
node(n1147,supported) :- node(n9,supported).
node(n1147,unknown) :- \+ node(n1147,supported), \+ node(n1147,refuted).
verdict(c_bb336a8ccecc056b,supported) :- node(n1147,supported).
query(verdict(c_bb336a8ccecc056b,supported)).
verdict(c_bb336a8ccecc056b,refuted) :- node(n1147,refuted).
query(verdict(c_bb336a8ccecc056b,refuted)).
verdict(c_bb336a8ccecc056b,unknown) :- node(n1147,unknown).
query(verdict(c_bb336a8ccecc056b,unknown)).
node(n1158,supported) :- status(o_3dd31675e35a06e080d1,supported).
node(n1158,refuted) :- status(o_3dd31675e35a06e080d1,refuted).
node(n1158,unknown) :- status(o_3dd31675e35a06e080d1,unknown).
node(n1159,supported) :- status(o_b9e6d81aca0b40b4612d,supported).
node(n1159,refuted) :- status(o_b9e6d81aca0b40b4612d,refuted).
node(n1159,unknown) :- status(o_b9e6d81aca0b40b4612d,unknown).
node(n1160,supported) :- status(o_7a05d5fe78e69743d0a9,supported).
node(n1160,refuted) :- status(o_7a05d5fe78e69743d0a9,refuted).
node(n1160,unknown) :- status(o_7a05d5fe78e69743d0a9,unknown).
node(n1161,supported) :- status(o_ca81a3788866570be8a1,supported).
node(n1161,refuted) :- status(o_ca81a3788866570be8a1,refuted).
node(n1161,unknown) :- status(o_ca81a3788866570be8a1,unknown).
node(n1157,supported) :- node(n1158,supported), node(n1159,supported), node(n1160,supported), node(n1161,supported).
node(n1157,refuted) :- node(n1158,refuted).
node(n1157,refuted) :- node(n1159,refuted).
node(n1157,refuted) :- node(n1160,refuted).
node(n1157,refuted) :- node(n1161,refuted).
node(n1157,unknown) :- \+ node(n1157,supported), \+ node(n1157,refuted).
node(n1163,supported) :- status(o_b963e89c439122675439,supported).
node(n1163,refuted) :- status(o_b963e89c439122675439,refuted).
node(n1163,unknown) :- status(o_b963e89c439122675439,unknown).
node(n1164,supported) :- status(o_cee82e4b161b918581f3,supported).
node(n1164,refuted) :- status(o_cee82e4b161b918581f3,refuted).
node(n1164,unknown) :- status(o_cee82e4b161b918581f3,unknown).
node(n1165,supported) :- status(o_cf5703ec66abd9abb42c,supported).
node(n1165,refuted) :- status(o_cf5703ec66abd9abb42c,refuted).
node(n1165,unknown) :- status(o_cf5703ec66abd9abb42c,unknown).
node(n1166,supported) :- status(o_d67f1c8773933c90285a,supported).
node(n1166,refuted) :- status(o_d67f1c8773933c90285a,refuted).
node(n1166,unknown) :- status(o_d67f1c8773933c90285a,unknown).
node(n1162,supported) :- node(n1163,supported), node(n1164,supported), node(n1165,supported), node(n1166,supported).
node(n1162,refuted) :- node(n1163,refuted).
node(n1162,refuted) :- node(n1164,refuted).
node(n1162,refuted) :- node(n1165,refuted).
node(n1162,refuted) :- node(n1166,refuted).
node(n1162,unknown) :- \+ node(n1162,supported), \+ node(n1162,refuted).
node(n1156,refuted) :- node(n1157,refuted), node(n1162,refuted), node(n9,refuted).
node(n1156,supported) :- node(n1157,supported).
node(n1156,supported) :- node(n1162,supported).
node(n1156,supported) :- node(n9,supported).
node(n1156,unknown) :- \+ node(n1156,supported), \+ node(n1156,refuted).
verdict(c_b4be1cd3814b029d,supported) :- node(n1156,supported).
query(verdict(c_b4be1cd3814b029d,supported)).
verdict(c_b4be1cd3814b029d,refuted) :- node(n1156,refuted).
query(verdict(c_b4be1cd3814b029d,refuted)).
verdict(c_b4be1cd3814b029d,unknown) :- node(n1156,unknown).
query(verdict(c_b4be1cd3814b029d,unknown)).
node(n1169,supported) :- status(o_2e854d90869d8a95bb63,supported).
node(n1169,refuted) :- status(o_2e854d90869d8a95bb63,refuted).
node(n1169,unknown) :- status(o_2e854d90869d8a95bb63,unknown).
node(n1170,supported) :- status(o_16d196355fcc35ded997,supported).
node(n1170,refuted) :- status(o_16d196355fcc35ded997,refuted).
node(n1170,unknown) :- status(o_16d196355fcc35ded997,unknown).
node(n1171,supported) :- status(o_114b6fee83ab718a4c3e,supported).
node(n1171,refuted) :- status(o_114b6fee83ab718a4c3e,refuted).
node(n1171,unknown) :- status(o_114b6fee83ab718a4c3e,unknown).
node(n1172,supported) :- status(o_9435e5f81ea0db193068,supported).
node(n1172,refuted) :- status(o_9435e5f81ea0db193068,refuted).
node(n1172,unknown) :- status(o_9435e5f81ea0db193068,unknown).
node(n1168,supported) :- node(n1169,supported), node(n1170,supported), node(n1171,supported), node(n1172,supported).
node(n1168,refuted) :- node(n1169,refuted).
node(n1168,refuted) :- node(n1170,refuted).
node(n1168,refuted) :- node(n1171,refuted).
node(n1168,refuted) :- node(n1172,refuted).
node(n1168,unknown) :- \+ node(n1168,supported), \+ node(n1168,refuted).
node(n1174,supported) :- status(o_e47a4d6f4c19369cc520,supported).
node(n1174,refuted) :- status(o_e47a4d6f4c19369cc520,refuted).
node(n1174,unknown) :- status(o_e47a4d6f4c19369cc520,unknown).
node(n1175,supported) :- status(o_40f23e2c84922125bdcd,supported).
node(n1175,refuted) :- status(o_40f23e2c84922125bdcd,refuted).
node(n1175,unknown) :- status(o_40f23e2c84922125bdcd,unknown).
node(n1176,supported) :- status(o_3184f696640c5db5a20c,supported).
node(n1176,refuted) :- status(o_3184f696640c5db5a20c,refuted).
node(n1176,unknown) :- status(o_3184f696640c5db5a20c,unknown).
node(n1177,supported) :- status(o_ed9c79182c7bda9ed78b,supported).
node(n1177,refuted) :- status(o_ed9c79182c7bda9ed78b,refuted).
node(n1177,unknown) :- status(o_ed9c79182c7bda9ed78b,unknown).
node(n1173,supported) :- node(n1174,supported), node(n1175,supported), node(n1176,supported), node(n1177,supported).
node(n1173,refuted) :- node(n1174,refuted).
node(n1173,refuted) :- node(n1175,refuted).
node(n1173,refuted) :- node(n1176,refuted).
node(n1173,refuted) :- node(n1177,refuted).
node(n1173,unknown) :- \+ node(n1173,supported), \+ node(n1173,refuted).
node(n1167,refuted) :- node(n1168,refuted), node(n1173,refuted), node(n9,refuted).
node(n1167,supported) :- node(n1168,supported).
node(n1167,supported) :- node(n1173,supported).
node(n1167,supported) :- node(n9,supported).
node(n1167,unknown) :- \+ node(n1167,supported), \+ node(n1167,refuted).
verdict(c_51e34aa5b8619115,supported) :- node(n1167,supported).
query(verdict(c_51e34aa5b8619115,supported)).
verdict(c_51e34aa5b8619115,refuted) :- node(n1167,refuted).
query(verdict(c_51e34aa5b8619115,refuted)).
verdict(c_51e34aa5b8619115,unknown) :- node(n1167,unknown).
query(verdict(c_51e34aa5b8619115,unknown)).
node(n1180,supported) :- status(o_27c9900c15218fad0686,supported).
node(n1180,refuted) :- status(o_27c9900c15218fad0686,refuted).
node(n1180,unknown) :- status(o_27c9900c15218fad0686,unknown).
node(n1181,supported) :- status(o_0b581073e8b6ed33e96c,supported).
node(n1181,refuted) :- status(o_0b581073e8b6ed33e96c,refuted).
node(n1181,unknown) :- status(o_0b581073e8b6ed33e96c,unknown).
node(n1182,supported) :- status(o_8eed4906f485e3836619,supported).
node(n1182,refuted) :- status(o_8eed4906f485e3836619,refuted).
node(n1182,unknown) :- status(o_8eed4906f485e3836619,unknown).
node(n1183,supported) :- status(o_fa1f7b8264a7c9dcd4af,supported).
node(n1183,refuted) :- status(o_fa1f7b8264a7c9dcd4af,refuted).
node(n1183,unknown) :- status(o_fa1f7b8264a7c9dcd4af,unknown).
node(n1179,supported) :- node(n1180,supported), node(n1181,supported), node(n1182,supported), node(n1183,supported).
node(n1179,refuted) :- node(n1180,refuted).
node(n1179,refuted) :- node(n1181,refuted).
node(n1179,refuted) :- node(n1182,refuted).
node(n1179,refuted) :- node(n1183,refuted).
node(n1179,unknown) :- \+ node(n1179,supported), \+ node(n1179,refuted).
node(n1185,supported) :- status(o_297745845b2758937d7e,supported).
node(n1185,refuted) :- status(o_297745845b2758937d7e,refuted).
node(n1185,unknown) :- status(o_297745845b2758937d7e,unknown).
node(n1186,supported) :- status(o_2de261beb9c15da6586f,supported).
node(n1186,refuted) :- status(o_2de261beb9c15da6586f,refuted).
node(n1186,unknown) :- status(o_2de261beb9c15da6586f,unknown).
node(n1187,supported) :- status(o_ddb00a01159bbae30aae,supported).
node(n1187,refuted) :- status(o_ddb00a01159bbae30aae,refuted).
node(n1187,unknown) :- status(o_ddb00a01159bbae30aae,unknown).
node(n1188,supported) :- status(o_fd349301f9d4df886c6a,supported).
node(n1188,refuted) :- status(o_fd349301f9d4df886c6a,refuted).
node(n1188,unknown) :- status(o_fd349301f9d4df886c6a,unknown).
node(n1184,supported) :- node(n1185,supported), node(n1186,supported), node(n1187,supported), node(n1188,supported).
node(n1184,refuted) :- node(n1185,refuted).
node(n1184,refuted) :- node(n1186,refuted).
node(n1184,refuted) :- node(n1187,refuted).
node(n1184,refuted) :- node(n1188,refuted).
node(n1184,unknown) :- \+ node(n1184,supported), \+ node(n1184,refuted).
node(n1178,refuted) :- node(n1179,refuted), node(n1184,refuted), node(n9,refuted).
node(n1178,supported) :- node(n1179,supported).
node(n1178,supported) :- node(n1184,supported).
node(n1178,supported) :- node(n9,supported).
node(n1178,unknown) :- \+ node(n1178,supported), \+ node(n1178,refuted).
verdict(c_bfce8f7c0519a09b,supported) :- node(n1178,supported).
query(verdict(c_bfce8f7c0519a09b,supported)).
verdict(c_bfce8f7c0519a09b,refuted) :- node(n1178,refuted).
query(verdict(c_bfce8f7c0519a09b,refuted)).
verdict(c_bfce8f7c0519a09b,unknown) :- node(n1178,unknown).
query(verdict(c_bfce8f7c0519a09b,unknown)).
node(n1191,supported) :- status(o_db998b28f25a13f0a5b0,supported).
node(n1191,refuted) :- status(o_db998b28f25a13f0a5b0,refuted).
node(n1191,unknown) :- status(o_db998b28f25a13f0a5b0,unknown).
node(n1192,supported) :- status(o_4e58de7c0652d9253c6a,supported).
node(n1192,refuted) :- status(o_4e58de7c0652d9253c6a,refuted).
node(n1192,unknown) :- status(o_4e58de7c0652d9253c6a,unknown).
node(n1193,supported) :- status(o_1b5a0146b5194e923661,supported).
node(n1193,refuted) :- status(o_1b5a0146b5194e923661,refuted).
node(n1193,unknown) :- status(o_1b5a0146b5194e923661,unknown).
node(n1190,supported) :- node(n1191,supported), node(n1192,supported), node(n1193,supported).
node(n1190,refuted) :- node(n1191,refuted).
node(n1190,refuted) :- node(n1192,refuted).
node(n1190,refuted) :- node(n1193,refuted).
node(n1190,unknown) :- \+ node(n1190,supported), \+ node(n1190,refuted).
node(n1195,supported) :- status(o_256ce0d1d6a9ea21492c,supported).
node(n1195,refuted) :- status(o_256ce0d1d6a9ea21492c,refuted).
node(n1195,unknown) :- status(o_256ce0d1d6a9ea21492c,unknown).
node(n1196,supported) :- status(o_123b645049041f11345d,supported).
node(n1196,refuted) :- status(o_123b645049041f11345d,refuted).
node(n1196,unknown) :- status(o_123b645049041f11345d,unknown).
node(n1197,supported) :- status(o_a6ee0b4fdcea28e94244,supported).
node(n1197,refuted) :- status(o_a6ee0b4fdcea28e94244,refuted).
node(n1197,unknown) :- status(o_a6ee0b4fdcea28e94244,unknown).
node(n1194,supported) :- node(n1195,supported), node(n1196,supported), node(n1197,supported).
node(n1194,refuted) :- node(n1195,refuted).
node(n1194,refuted) :- node(n1196,refuted).
node(n1194,refuted) :- node(n1197,refuted).
node(n1194,unknown) :- \+ node(n1194,supported), \+ node(n1194,refuted).
node(n1189,refuted) :- node(n1190,refuted), node(n1194,refuted), node(n9,refuted).
node(n1189,supported) :- node(n1190,supported).
node(n1189,supported) :- node(n1194,supported).
node(n1189,supported) :- node(n9,supported).
node(n1189,unknown) :- \+ node(n1189,supported), \+ node(n1189,refuted).
verdict(c_f750d42a9211869a,supported) :- node(n1189,supported).
query(verdict(c_f750d42a9211869a,supported)).
verdict(c_f750d42a9211869a,refuted) :- node(n1189,refuted).
query(verdict(c_f750d42a9211869a,refuted)).
verdict(c_f750d42a9211869a,unknown) :- node(n1189,unknown).
query(verdict(c_f750d42a9211869a,unknown)).
node(n1200,supported) :- status(o_7ec5ef68f99b8c9eee80,supported).
node(n1200,refuted) :- status(o_7ec5ef68f99b8c9eee80,refuted).
node(n1200,unknown) :- status(o_7ec5ef68f99b8c9eee80,unknown).
node(n1201,supported) :- status(o_d0e0cc6e0f93d3c26e2f,supported).
node(n1201,refuted) :- status(o_d0e0cc6e0f93d3c26e2f,refuted).
node(n1201,unknown) :- status(o_d0e0cc6e0f93d3c26e2f,unknown).
node(n1202,supported) :- status(o_c18e5e743c22e59082f3,supported).
node(n1202,refuted) :- status(o_c18e5e743c22e59082f3,refuted).
node(n1202,unknown) :- status(o_c18e5e743c22e59082f3,unknown).
node(n1203,supported) :- status(o_dd7dcd0a0be0a7d36d06,supported).
node(n1203,refuted) :- status(o_dd7dcd0a0be0a7d36d06,refuted).
node(n1203,unknown) :- status(o_dd7dcd0a0be0a7d36d06,unknown).
node(n1199,supported) :- node(n1200,supported), node(n1201,supported), node(n1202,supported), node(n1203,supported).
node(n1199,refuted) :- node(n1200,refuted).
node(n1199,refuted) :- node(n1201,refuted).
node(n1199,refuted) :- node(n1202,refuted).
node(n1199,refuted) :- node(n1203,refuted).
node(n1199,unknown) :- \+ node(n1199,supported), \+ node(n1199,refuted).
node(n1205,supported) :- status(o_533294e01e7077b17ee5,supported).
node(n1205,refuted) :- status(o_533294e01e7077b17ee5,refuted).
node(n1205,unknown) :- status(o_533294e01e7077b17ee5,unknown).
node(n1206,supported) :- status(o_dd894d97034bfc415849,supported).
node(n1206,refuted) :- status(o_dd894d97034bfc415849,refuted).
node(n1206,unknown) :- status(o_dd894d97034bfc415849,unknown).
node(n1207,supported) :- status(o_cd414cb687321f1be59d,supported).
node(n1207,refuted) :- status(o_cd414cb687321f1be59d,refuted).
node(n1207,unknown) :- status(o_cd414cb687321f1be59d,unknown).
node(n1208,supported) :- status(o_7784360eebc16e5aa8c0,supported).
node(n1208,refuted) :- status(o_7784360eebc16e5aa8c0,refuted).
node(n1208,unknown) :- status(o_7784360eebc16e5aa8c0,unknown).
node(n1204,supported) :- node(n1205,supported), node(n1206,supported), node(n1207,supported), node(n1208,supported).
node(n1204,refuted) :- node(n1205,refuted).
node(n1204,refuted) :- node(n1206,refuted).
node(n1204,refuted) :- node(n1207,refuted).
node(n1204,refuted) :- node(n1208,refuted).
node(n1204,unknown) :- \+ node(n1204,supported), \+ node(n1204,refuted).
node(n1198,refuted) :- node(n1199,refuted), node(n1204,refuted), node(n9,refuted).
node(n1198,supported) :- node(n1199,supported).
node(n1198,supported) :- node(n1204,supported).
node(n1198,supported) :- node(n9,supported).
node(n1198,unknown) :- \+ node(n1198,supported), \+ node(n1198,refuted).
verdict(c_500800d832dfb6eb,supported) :- node(n1198,supported).
query(verdict(c_500800d832dfb6eb,supported)).
verdict(c_500800d832dfb6eb,refuted) :- node(n1198,refuted).
query(verdict(c_500800d832dfb6eb,refuted)).
verdict(c_500800d832dfb6eb,unknown) :- node(n1198,unknown).
query(verdict(c_500800d832dfb6eb,unknown)).
node(n1211,supported) :- status(o_b575f12ec9102d6fbe20,supported).
node(n1211,refuted) :- status(o_b575f12ec9102d6fbe20,refuted).
node(n1211,unknown) :- status(o_b575f12ec9102d6fbe20,unknown).
node(n1212,supported) :- status(o_dc2465ef366877b97935,supported).
node(n1212,refuted) :- status(o_dc2465ef366877b97935,refuted).
node(n1212,unknown) :- status(o_dc2465ef366877b97935,unknown).
node(n1213,supported) :- status(o_10cd29128fa9024e07cf,supported).
node(n1213,refuted) :- status(o_10cd29128fa9024e07cf,refuted).
node(n1213,unknown) :- status(o_10cd29128fa9024e07cf,unknown).
node(n1214,supported) :- status(o_76b8758c6ed9da6ba25f,supported).
node(n1214,refuted) :- status(o_76b8758c6ed9da6ba25f,refuted).
node(n1214,unknown) :- status(o_76b8758c6ed9da6ba25f,unknown).
node(n1210,supported) :- node(n1211,supported), node(n1212,supported), node(n1213,supported), node(n1214,supported).
node(n1210,refuted) :- node(n1211,refuted).
node(n1210,refuted) :- node(n1212,refuted).
node(n1210,refuted) :- node(n1213,refuted).
node(n1210,refuted) :- node(n1214,refuted).
node(n1210,unknown) :- \+ node(n1210,supported), \+ node(n1210,refuted).
node(n1216,supported) :- status(o_61eeb6034cdd70d1d66b,supported).
node(n1216,refuted) :- status(o_61eeb6034cdd70d1d66b,refuted).
node(n1216,unknown) :- status(o_61eeb6034cdd70d1d66b,unknown).
node(n1217,supported) :- status(o_6df5b84179eb7c51f630,supported).
node(n1217,refuted) :- status(o_6df5b84179eb7c51f630,refuted).
node(n1217,unknown) :- status(o_6df5b84179eb7c51f630,unknown).
node(n1218,supported) :- status(o_dd362728f3ef147cc7ec,supported).
node(n1218,refuted) :- status(o_dd362728f3ef147cc7ec,refuted).
node(n1218,unknown) :- status(o_dd362728f3ef147cc7ec,unknown).
node(n1219,supported) :- status(o_55f08a6b10ce56e7685c,supported).
node(n1219,refuted) :- status(o_55f08a6b10ce56e7685c,refuted).
node(n1219,unknown) :- status(o_55f08a6b10ce56e7685c,unknown).
node(n1215,supported) :- node(n1216,supported), node(n1217,supported), node(n1218,supported), node(n1219,supported).
node(n1215,refuted) :- node(n1216,refuted).
node(n1215,refuted) :- node(n1217,refuted).
node(n1215,refuted) :- node(n1218,refuted).
node(n1215,refuted) :- node(n1219,refuted).
node(n1215,unknown) :- \+ node(n1215,supported), \+ node(n1215,refuted).
node(n1209,refuted) :- node(n1210,refuted), node(n1215,refuted), node(n9,refuted).
node(n1209,supported) :- node(n1210,supported).
node(n1209,supported) :- node(n1215,supported).
node(n1209,supported) :- node(n9,supported).
node(n1209,unknown) :- \+ node(n1209,supported), \+ node(n1209,refuted).
verdict(c_b3f73204bf6c64c1,supported) :- node(n1209,supported).
query(verdict(c_b3f73204bf6c64c1,supported)).
verdict(c_b3f73204bf6c64c1,refuted) :- node(n1209,refuted).
query(verdict(c_b3f73204bf6c64c1,refuted)).
verdict(c_b3f73204bf6c64c1,unknown) :- node(n1209,unknown).
query(verdict(c_b3f73204bf6c64c1,unknown)).
node(n1222,supported) :- status(o_3f3388d354110fdbf3f4,supported).
node(n1222,refuted) :- status(o_3f3388d354110fdbf3f4,refuted).
node(n1222,unknown) :- status(o_3f3388d354110fdbf3f4,unknown).
node(n1223,supported) :- status(o_2d8880eb0bd80eaf99cd,supported).
node(n1223,refuted) :- status(o_2d8880eb0bd80eaf99cd,refuted).
node(n1223,unknown) :- status(o_2d8880eb0bd80eaf99cd,unknown).
node(n1224,supported) :- status(o_f4595235c4e01725f985,supported).
node(n1224,refuted) :- status(o_f4595235c4e01725f985,refuted).
node(n1224,unknown) :- status(o_f4595235c4e01725f985,unknown).
node(n1225,supported) :- status(o_7588601aaef449314c79,supported).
node(n1225,refuted) :- status(o_7588601aaef449314c79,refuted).
node(n1225,unknown) :- status(o_7588601aaef449314c79,unknown).
node(n1221,supported) :- node(n1222,supported), node(n1223,supported), node(n1224,supported), node(n1225,supported).
node(n1221,refuted) :- node(n1222,refuted).
node(n1221,refuted) :- node(n1223,refuted).
node(n1221,refuted) :- node(n1224,refuted).
node(n1221,refuted) :- node(n1225,refuted).
node(n1221,unknown) :- \+ node(n1221,supported), \+ node(n1221,refuted).
node(n1227,supported) :- status(o_985cf8525b26d0d7eaa8,supported).
node(n1227,refuted) :- status(o_985cf8525b26d0d7eaa8,refuted).
node(n1227,unknown) :- status(o_985cf8525b26d0d7eaa8,unknown).
node(n1228,supported) :- status(o_14af9463427e5ae1beea,supported).
node(n1228,refuted) :- status(o_14af9463427e5ae1beea,refuted).
node(n1228,unknown) :- status(o_14af9463427e5ae1beea,unknown).
node(n1229,supported) :- status(o_ee1f4875a1b4a92601cc,supported).
node(n1229,refuted) :- status(o_ee1f4875a1b4a92601cc,refuted).
node(n1229,unknown) :- status(o_ee1f4875a1b4a92601cc,unknown).
node(n1230,supported) :- status(o_a5c9ad57179f673941da,supported).
node(n1230,refuted) :- status(o_a5c9ad57179f673941da,refuted).
node(n1230,unknown) :- status(o_a5c9ad57179f673941da,unknown).
node(n1226,supported) :- node(n1227,supported), node(n1228,supported), node(n1229,supported), node(n1230,supported).
node(n1226,refuted) :- node(n1227,refuted).
node(n1226,refuted) :- node(n1228,refuted).
node(n1226,refuted) :- node(n1229,refuted).
node(n1226,refuted) :- node(n1230,refuted).
node(n1226,unknown) :- \+ node(n1226,supported), \+ node(n1226,refuted).
node(n1220,refuted) :- node(n1221,refuted), node(n1226,refuted), node(n9,refuted).
node(n1220,supported) :- node(n1221,supported).
node(n1220,supported) :- node(n1226,supported).
node(n1220,supported) :- node(n9,supported).
node(n1220,unknown) :- \+ node(n1220,supported), \+ node(n1220,refuted).
verdict(c_3858232af3bd921e,supported) :- node(n1220,supported).
query(verdict(c_3858232af3bd921e,supported)).
verdict(c_3858232af3bd921e,refuted) :- node(n1220,refuted).
query(verdict(c_3858232af3bd921e,refuted)).
verdict(c_3858232af3bd921e,unknown) :- node(n1220,unknown).
query(verdict(c_3858232af3bd921e,unknown)).
node(n1233,supported) :- status(o_cd6a608cf0d21ad05b58,supported).
node(n1233,refuted) :- status(o_cd6a608cf0d21ad05b58,refuted).
node(n1233,unknown) :- status(o_cd6a608cf0d21ad05b58,unknown).
node(n1234,supported) :- status(o_e377df09da0eae980bfc,supported).
node(n1234,refuted) :- status(o_e377df09da0eae980bfc,refuted).
node(n1234,unknown) :- status(o_e377df09da0eae980bfc,unknown).
node(n1235,supported) :- status(o_ea04e2592f38d3108d5f,supported).
node(n1235,refuted) :- status(o_ea04e2592f38d3108d5f,refuted).
node(n1235,unknown) :- status(o_ea04e2592f38d3108d5f,unknown).
node(n1232,supported) :- node(n1233,supported), node(n1234,supported), node(n1235,supported).
node(n1232,refuted) :- node(n1233,refuted).
node(n1232,refuted) :- node(n1234,refuted).
node(n1232,refuted) :- node(n1235,refuted).
node(n1232,unknown) :- \+ node(n1232,supported), \+ node(n1232,refuted).
node(n1237,supported) :- status(o_b2dfa516891c521461db,supported).
node(n1237,refuted) :- status(o_b2dfa516891c521461db,refuted).
node(n1237,unknown) :- status(o_b2dfa516891c521461db,unknown).
node(n1238,supported) :- status(o_f70988638752e3595b50,supported).
node(n1238,refuted) :- status(o_f70988638752e3595b50,refuted).
node(n1238,unknown) :- status(o_f70988638752e3595b50,unknown).
node(n1239,supported) :- status(o_5e94c2e8eadcfc77dac6,supported).
node(n1239,refuted) :- status(o_5e94c2e8eadcfc77dac6,refuted).
node(n1239,unknown) :- status(o_5e94c2e8eadcfc77dac6,unknown).
node(n1236,supported) :- node(n1237,supported), node(n1238,supported), node(n1239,supported).
node(n1236,refuted) :- node(n1237,refuted).
node(n1236,refuted) :- node(n1238,refuted).
node(n1236,refuted) :- node(n1239,refuted).
node(n1236,unknown) :- \+ node(n1236,supported), \+ node(n1236,refuted).
node(n1231,refuted) :- node(n1232,refuted), node(n1236,refuted), node(n9,refuted).
node(n1231,supported) :- node(n1232,supported).
node(n1231,supported) :- node(n1236,supported).
node(n1231,supported) :- node(n9,supported).
node(n1231,unknown) :- \+ node(n1231,supported), \+ node(n1231,refuted).
verdict(c_2c9cb0126c8ac1b6,supported) :- node(n1231,supported).
query(verdict(c_2c9cb0126c8ac1b6,supported)).
verdict(c_2c9cb0126c8ac1b6,refuted) :- node(n1231,refuted).
query(verdict(c_2c9cb0126c8ac1b6,refuted)).
verdict(c_2c9cb0126c8ac1b6,unknown) :- node(n1231,unknown).
query(verdict(c_2c9cb0126c8ac1b6,unknown)).
node(n1242,supported) :- status(o_8d12f7876d1d2c230dfc,supported).
node(n1242,refuted) :- status(o_8d12f7876d1d2c230dfc,refuted).
node(n1242,unknown) :- status(o_8d12f7876d1d2c230dfc,unknown).
node(n1243,supported) :- status(o_0b73b9c8b9d80db7b645,supported).
node(n1243,refuted) :- status(o_0b73b9c8b9d80db7b645,refuted).
node(n1243,unknown) :- status(o_0b73b9c8b9d80db7b645,unknown).
node(n1244,supported) :- status(o_f5a73b432826c391814b,supported).
node(n1244,refuted) :- status(o_f5a73b432826c391814b,refuted).
node(n1244,unknown) :- status(o_f5a73b432826c391814b,unknown).
node(n1245,supported) :- status(o_db78ccc20e830be93917,supported).
node(n1245,refuted) :- status(o_db78ccc20e830be93917,refuted).
node(n1245,unknown) :- status(o_db78ccc20e830be93917,unknown).
node(n1241,supported) :- node(n1242,supported), node(n1243,supported), node(n1244,supported), node(n1245,supported).
node(n1241,refuted) :- node(n1242,refuted).
node(n1241,refuted) :- node(n1243,refuted).
node(n1241,refuted) :- node(n1244,refuted).
node(n1241,refuted) :- node(n1245,refuted).
node(n1241,unknown) :- \+ node(n1241,supported), \+ node(n1241,refuted).
node(n1247,supported) :- status(o_209ec5a3f83e29ead293,supported).
node(n1247,refuted) :- status(o_209ec5a3f83e29ead293,refuted).
node(n1247,unknown) :- status(o_209ec5a3f83e29ead293,unknown).
node(n1248,supported) :- status(o_ce133ee13628fc406642,supported).
node(n1248,refuted) :- status(o_ce133ee13628fc406642,refuted).
node(n1248,unknown) :- status(o_ce133ee13628fc406642,unknown).
node(n1249,supported) :- status(o_2cca762e9694a9c6d4f5,supported).
node(n1249,refuted) :- status(o_2cca762e9694a9c6d4f5,refuted).
node(n1249,unknown) :- status(o_2cca762e9694a9c6d4f5,unknown).
node(n1250,supported) :- status(o_5ab9eb70f3d28560ef45,supported).
node(n1250,refuted) :- status(o_5ab9eb70f3d28560ef45,refuted).
node(n1250,unknown) :- status(o_5ab9eb70f3d28560ef45,unknown).
node(n1246,supported) :- node(n1247,supported), node(n1248,supported), node(n1249,supported), node(n1250,supported).
node(n1246,refuted) :- node(n1247,refuted).
node(n1246,refuted) :- node(n1248,refuted).
node(n1246,refuted) :- node(n1249,refuted).
node(n1246,refuted) :- node(n1250,refuted).
node(n1246,unknown) :- \+ node(n1246,supported), \+ node(n1246,refuted).
node(n1240,refuted) :- node(n1241,refuted), node(n1246,refuted), node(n9,refuted).
node(n1240,supported) :- node(n1241,supported).
node(n1240,supported) :- node(n1246,supported).
node(n1240,supported) :- node(n9,supported).
node(n1240,unknown) :- \+ node(n1240,supported), \+ node(n1240,refuted).
verdict(c_2f3a1006ac760606,supported) :- node(n1240,supported).
query(verdict(c_2f3a1006ac760606,supported)).
verdict(c_2f3a1006ac760606,refuted) :- node(n1240,refuted).
query(verdict(c_2f3a1006ac760606,refuted)).
verdict(c_2f3a1006ac760606,unknown) :- node(n1240,unknown).
query(verdict(c_2f3a1006ac760606,unknown)).
node(n1253,supported) :- status(o_be920165638086f9696e,supported).
node(n1253,refuted) :- status(o_be920165638086f9696e,refuted).
node(n1253,unknown) :- status(o_be920165638086f9696e,unknown).
node(n1254,supported) :- status(o_0dee611c29be95170142,supported).
node(n1254,refuted) :- status(o_0dee611c29be95170142,refuted).
node(n1254,unknown) :- status(o_0dee611c29be95170142,unknown).
node(n1255,supported) :- status(o_8648c9f38f6dee565588,supported).
node(n1255,refuted) :- status(o_8648c9f38f6dee565588,refuted).
node(n1255,unknown) :- status(o_8648c9f38f6dee565588,unknown).
node(n1256,supported) :- status(o_cf1c46bd18b65e02e905,supported).
node(n1256,refuted) :- status(o_cf1c46bd18b65e02e905,refuted).
node(n1256,unknown) :- status(o_cf1c46bd18b65e02e905,unknown).
node(n1252,supported) :- node(n1253,supported), node(n1254,supported), node(n1255,supported), node(n1256,supported).
node(n1252,refuted) :- node(n1253,refuted).
node(n1252,refuted) :- node(n1254,refuted).
node(n1252,refuted) :- node(n1255,refuted).
node(n1252,refuted) :- node(n1256,refuted).
node(n1252,unknown) :- \+ node(n1252,supported), \+ node(n1252,refuted).
node(n1258,supported) :- status(o_384f76bed80b6a497a4a,supported).
node(n1258,refuted) :- status(o_384f76bed80b6a497a4a,refuted).
node(n1258,unknown) :- status(o_384f76bed80b6a497a4a,unknown).
node(n1259,supported) :- status(o_951cdefdee3dda8af591,supported).
node(n1259,refuted) :- status(o_951cdefdee3dda8af591,refuted).
node(n1259,unknown) :- status(o_951cdefdee3dda8af591,unknown).
node(n1260,supported) :- status(o_37c6cab1af8f2a20dec8,supported).
node(n1260,refuted) :- status(o_37c6cab1af8f2a20dec8,refuted).
node(n1260,unknown) :- status(o_37c6cab1af8f2a20dec8,unknown).
node(n1261,supported) :- status(o_0fb3afbed6a16d0c028e,supported).
node(n1261,refuted) :- status(o_0fb3afbed6a16d0c028e,refuted).
node(n1261,unknown) :- status(o_0fb3afbed6a16d0c028e,unknown).
node(n1257,supported) :- node(n1258,supported), node(n1259,supported), node(n1260,supported), node(n1261,supported).
node(n1257,refuted) :- node(n1258,refuted).
node(n1257,refuted) :- node(n1259,refuted).
node(n1257,refuted) :- node(n1260,refuted).
node(n1257,refuted) :- node(n1261,refuted).
node(n1257,unknown) :- \+ node(n1257,supported), \+ node(n1257,refuted).
node(n1251,refuted) :- node(n1252,refuted), node(n1257,refuted), node(n9,refuted).
node(n1251,supported) :- node(n1252,supported).
node(n1251,supported) :- node(n1257,supported).
node(n1251,supported) :- node(n9,supported).
node(n1251,unknown) :- \+ node(n1251,supported), \+ node(n1251,refuted).
verdict(c_bd6f4a76b316843b,supported) :- node(n1251,supported).
query(verdict(c_bd6f4a76b316843b,supported)).
verdict(c_bd6f4a76b316843b,refuted) :- node(n1251,refuted).
query(verdict(c_bd6f4a76b316843b,refuted)).
verdict(c_bd6f4a76b316843b,unknown) :- node(n1251,unknown).
query(verdict(c_bd6f4a76b316843b,unknown)).
node(n1264,supported) :- status(o_35212e85fa94812329d6,supported).
node(n1264,refuted) :- status(o_35212e85fa94812329d6,refuted).
node(n1264,unknown) :- status(o_35212e85fa94812329d6,unknown).
node(n1265,supported) :- status(o_397651ef7644dff0b15c,supported).
node(n1265,refuted) :- status(o_397651ef7644dff0b15c,refuted).
node(n1265,unknown) :- status(o_397651ef7644dff0b15c,unknown).
node(n1266,supported) :- status(o_d063b069e64888cc1804,supported).
node(n1266,refuted) :- status(o_d063b069e64888cc1804,refuted).
node(n1266,unknown) :- status(o_d063b069e64888cc1804,unknown).
node(n1267,supported) :- status(o_5ae8854efccdf6eb4ab4,supported).
node(n1267,refuted) :- status(o_5ae8854efccdf6eb4ab4,refuted).
node(n1267,unknown) :- status(o_5ae8854efccdf6eb4ab4,unknown).
node(n1263,supported) :- node(n1264,supported), node(n1265,supported), node(n1266,supported), node(n1267,supported).
node(n1263,refuted) :- node(n1264,refuted).
node(n1263,refuted) :- node(n1265,refuted).
node(n1263,refuted) :- node(n1266,refuted).
node(n1263,refuted) :- node(n1267,refuted).
node(n1263,unknown) :- \+ node(n1263,supported), \+ node(n1263,refuted).
node(n1269,supported) :- status(o_e581d252866b4d8b2106,supported).
node(n1269,refuted) :- status(o_e581d252866b4d8b2106,refuted).
node(n1269,unknown) :- status(o_e581d252866b4d8b2106,unknown).
node(n1270,supported) :- status(o_8ed05054839e75f77de0,supported).
node(n1270,refuted) :- status(o_8ed05054839e75f77de0,refuted).
node(n1270,unknown) :- status(o_8ed05054839e75f77de0,unknown).
node(n1271,supported) :- status(o_e197d1dcb927026dcb44,supported).
node(n1271,refuted) :- status(o_e197d1dcb927026dcb44,refuted).
node(n1271,unknown) :- status(o_e197d1dcb927026dcb44,unknown).
node(n1272,supported) :- status(o_4d5ec9c610fd9c336ad4,supported).
node(n1272,refuted) :- status(o_4d5ec9c610fd9c336ad4,refuted).
node(n1272,unknown) :- status(o_4d5ec9c610fd9c336ad4,unknown).
node(n1268,supported) :- node(n1269,supported), node(n1270,supported), node(n1271,supported), node(n1272,supported).
node(n1268,refuted) :- node(n1269,refuted).
node(n1268,refuted) :- node(n1270,refuted).
node(n1268,refuted) :- node(n1271,refuted).
node(n1268,refuted) :- node(n1272,refuted).
node(n1268,unknown) :- \+ node(n1268,supported), \+ node(n1268,refuted).
node(n1262,refuted) :- node(n1263,refuted), node(n1268,refuted), node(n9,refuted).
node(n1262,supported) :- node(n1263,supported).
node(n1262,supported) :- node(n1268,supported).
node(n1262,supported) :- node(n9,supported).
node(n1262,unknown) :- \+ node(n1262,supported), \+ node(n1262,refuted).
verdict(c_9f1e6e1ff7e506ed,supported) :- node(n1262,supported).
query(verdict(c_9f1e6e1ff7e506ed,supported)).
verdict(c_9f1e6e1ff7e506ed,refuted) :- node(n1262,refuted).
query(verdict(c_9f1e6e1ff7e506ed,refuted)).
verdict(c_9f1e6e1ff7e506ed,unknown) :- node(n1262,unknown).
query(verdict(c_9f1e6e1ff7e506ed,unknown)).
node(n1275,supported) :- status(o_0a2580a433b8d0ef3b0c,supported).
node(n1275,refuted) :- status(o_0a2580a433b8d0ef3b0c,refuted).
node(n1275,unknown) :- status(o_0a2580a433b8d0ef3b0c,unknown).
node(n1276,supported) :- status(o_3a991123a9cf0247c302,supported).
node(n1276,refuted) :- status(o_3a991123a9cf0247c302,refuted).
node(n1276,unknown) :- status(o_3a991123a9cf0247c302,unknown).
node(n1277,supported) :- status(o_ece6022cec0b402b6acf,supported).
node(n1277,refuted) :- status(o_ece6022cec0b402b6acf,refuted).
node(n1277,unknown) :- status(o_ece6022cec0b402b6acf,unknown).
node(n1274,supported) :- node(n1275,supported), node(n1276,supported), node(n1277,supported).
node(n1274,refuted) :- node(n1275,refuted).
node(n1274,refuted) :- node(n1276,refuted).
node(n1274,refuted) :- node(n1277,refuted).
node(n1274,unknown) :- \+ node(n1274,supported), \+ node(n1274,refuted).
node(n1279,supported) :- status(o_aa9d4bd1c17850ec1241,supported).
node(n1279,refuted) :- status(o_aa9d4bd1c17850ec1241,refuted).
node(n1279,unknown) :- status(o_aa9d4bd1c17850ec1241,unknown).
node(n1280,supported) :- status(o_b4608152dc8e13efdeb8,supported).
node(n1280,refuted) :- status(o_b4608152dc8e13efdeb8,refuted).
node(n1280,unknown) :- status(o_b4608152dc8e13efdeb8,unknown).
node(n1281,supported) :- status(o_50bf9ed44022bea1d7fc,supported).
node(n1281,refuted) :- status(o_50bf9ed44022bea1d7fc,refuted).
node(n1281,unknown) :- status(o_50bf9ed44022bea1d7fc,unknown).
node(n1278,supported) :- node(n1279,supported), node(n1280,supported), node(n1281,supported).
node(n1278,refuted) :- node(n1279,refuted).
node(n1278,refuted) :- node(n1280,refuted).
node(n1278,refuted) :- node(n1281,refuted).
node(n1278,unknown) :- \+ node(n1278,supported), \+ node(n1278,refuted).
node(n1273,refuted) :- node(n1274,refuted), node(n1278,refuted), node(n9,refuted).
node(n1273,supported) :- node(n1274,supported).
node(n1273,supported) :- node(n1278,supported).
node(n1273,supported) :- node(n9,supported).
node(n1273,unknown) :- \+ node(n1273,supported), \+ node(n1273,refuted).
verdict(c_f8acc4a3515dfad6,supported) :- node(n1273,supported).
query(verdict(c_f8acc4a3515dfad6,supported)).
verdict(c_f8acc4a3515dfad6,refuted) :- node(n1273,refuted).
query(verdict(c_f8acc4a3515dfad6,refuted)).
verdict(c_f8acc4a3515dfad6,unknown) :- node(n1273,unknown).
query(verdict(c_f8acc4a3515dfad6,unknown)).
node(n1284,supported) :- status(o_e5e05449de764f4e05ff,supported).
node(n1284,refuted) :- status(o_e5e05449de764f4e05ff,refuted).
node(n1284,unknown) :- status(o_e5e05449de764f4e05ff,unknown).
node(n1285,supported) :- status(o_21d3ae04a9290c7b986d,supported).
node(n1285,refuted) :- status(o_21d3ae04a9290c7b986d,refuted).
node(n1285,unknown) :- status(o_21d3ae04a9290c7b986d,unknown).
node(n1286,supported) :- status(o_4e084109631d589b69de,supported).
node(n1286,refuted) :- status(o_4e084109631d589b69de,refuted).
node(n1286,unknown) :- status(o_4e084109631d589b69de,unknown).
node(n1287,supported) :- status(o_60ac771ebfecf1e51df8,supported).
node(n1287,refuted) :- status(o_60ac771ebfecf1e51df8,refuted).
node(n1287,unknown) :- status(o_60ac771ebfecf1e51df8,unknown).
node(n1283,supported) :- node(n1284,supported), node(n1285,supported), node(n1286,supported), node(n1287,supported).
node(n1283,refuted) :- node(n1284,refuted).
node(n1283,refuted) :- node(n1285,refuted).
node(n1283,refuted) :- node(n1286,refuted).
node(n1283,refuted) :- node(n1287,refuted).
node(n1283,unknown) :- \+ node(n1283,supported), \+ node(n1283,refuted).
node(n1289,supported) :- status(o_d43f8fdfc0005afea177,supported).
node(n1289,refuted) :- status(o_d43f8fdfc0005afea177,refuted).
node(n1289,unknown) :- status(o_d43f8fdfc0005afea177,unknown).
node(n1290,supported) :- status(o_5934e747983b9894f72c,supported).
node(n1290,refuted) :- status(o_5934e747983b9894f72c,refuted).
node(n1290,unknown) :- status(o_5934e747983b9894f72c,unknown).
node(n1291,supported) :- status(o_8261c27e16dac47860f4,supported).
node(n1291,refuted) :- status(o_8261c27e16dac47860f4,refuted).
node(n1291,unknown) :- status(o_8261c27e16dac47860f4,unknown).
node(n1292,supported) :- status(o_9bf4dca6964a628a50cc,supported).
node(n1292,refuted) :- status(o_9bf4dca6964a628a50cc,refuted).
node(n1292,unknown) :- status(o_9bf4dca6964a628a50cc,unknown).
node(n1288,supported) :- node(n1289,supported), node(n1290,supported), node(n1291,supported), node(n1292,supported).
node(n1288,refuted) :- node(n1289,refuted).
node(n1288,refuted) :- node(n1290,refuted).
node(n1288,refuted) :- node(n1291,refuted).
node(n1288,refuted) :- node(n1292,refuted).
node(n1288,unknown) :- \+ node(n1288,supported), \+ node(n1288,refuted).
node(n1282,refuted) :- node(n1283,refuted), node(n1288,refuted), node(n9,refuted).
node(n1282,supported) :- node(n1283,supported).
node(n1282,supported) :- node(n1288,supported).
node(n1282,supported) :- node(n9,supported).
node(n1282,unknown) :- \+ node(n1282,supported), \+ node(n1282,refuted).
verdict(c_97c717699c53d4e8,supported) :- node(n1282,supported).
query(verdict(c_97c717699c53d4e8,supported)).
verdict(c_97c717699c53d4e8,refuted) :- node(n1282,refuted).
query(verdict(c_97c717699c53d4e8,refuted)).
verdict(c_97c717699c53d4e8,unknown) :- node(n1282,unknown).
query(verdict(c_97c717699c53d4e8,unknown)).
node(n1295,supported) :- status(o_233dde696d2e9c5de735,supported).
node(n1295,refuted) :- status(o_233dde696d2e9c5de735,refuted).
node(n1295,unknown) :- status(o_233dde696d2e9c5de735,unknown).
node(n1296,supported) :- status(o_69fffe22a82f2b8f8d91,supported).
node(n1296,refuted) :- status(o_69fffe22a82f2b8f8d91,refuted).
node(n1296,unknown) :- status(o_69fffe22a82f2b8f8d91,unknown).
node(n1297,supported) :- status(o_c9f8dffccbf2118f33f8,supported).
node(n1297,refuted) :- status(o_c9f8dffccbf2118f33f8,refuted).
node(n1297,unknown) :- status(o_c9f8dffccbf2118f33f8,unknown).
node(n1298,supported) :- status(o_f70b5956a5f24c4664a8,supported).
node(n1298,refuted) :- status(o_f70b5956a5f24c4664a8,refuted).
node(n1298,unknown) :- status(o_f70b5956a5f24c4664a8,unknown).
node(n1294,supported) :- node(n1295,supported), node(n1296,supported), node(n1297,supported), node(n1298,supported).
node(n1294,refuted) :- node(n1295,refuted).
node(n1294,refuted) :- node(n1296,refuted).
node(n1294,refuted) :- node(n1297,refuted).
node(n1294,refuted) :- node(n1298,refuted).
node(n1294,unknown) :- \+ node(n1294,supported), \+ node(n1294,refuted).
node(n1300,supported) :- status(o_ab71f9e6c64c37308cbb,supported).
node(n1300,refuted) :- status(o_ab71f9e6c64c37308cbb,refuted).
node(n1300,unknown) :- status(o_ab71f9e6c64c37308cbb,unknown).
node(n1301,supported) :- status(o_b431455d88ce64a88865,supported).
node(n1301,refuted) :- status(o_b431455d88ce64a88865,refuted).
node(n1301,unknown) :- status(o_b431455d88ce64a88865,unknown).
node(n1302,supported) :- status(o_6ced51da0dc7498976d3,supported).
node(n1302,refuted) :- status(o_6ced51da0dc7498976d3,refuted).
node(n1302,unknown) :- status(o_6ced51da0dc7498976d3,unknown).
node(n1303,supported) :- status(o_5d67cc778d6f1485b3c6,supported).
node(n1303,refuted) :- status(o_5d67cc778d6f1485b3c6,refuted).
node(n1303,unknown) :- status(o_5d67cc778d6f1485b3c6,unknown).
node(n1299,supported) :- node(n1300,supported), node(n1301,supported), node(n1302,supported), node(n1303,supported).
node(n1299,refuted) :- node(n1300,refuted).
node(n1299,refuted) :- node(n1301,refuted).
node(n1299,refuted) :- node(n1302,refuted).
node(n1299,refuted) :- node(n1303,refuted).
node(n1299,unknown) :- \+ node(n1299,supported), \+ node(n1299,refuted).
node(n1293,refuted) :- node(n1294,refuted), node(n1299,refuted), node(n9,refuted).
node(n1293,supported) :- node(n1294,supported).
node(n1293,supported) :- node(n1299,supported).
node(n1293,supported) :- node(n9,supported).
node(n1293,unknown) :- \+ node(n1293,supported), \+ node(n1293,refuted).
verdict(c_cf52a3ecb74746ba,supported) :- node(n1293,supported).
query(verdict(c_cf52a3ecb74746ba,supported)).
verdict(c_cf52a3ecb74746ba,refuted) :- node(n1293,refuted).
query(verdict(c_cf52a3ecb74746ba,refuted)).
verdict(c_cf52a3ecb74746ba,unknown) :- node(n1293,unknown).
query(verdict(c_cf52a3ecb74746ba,unknown)).
node(n1306,supported) :- status(o_f0ef7908a7bb43d41792,supported).
node(n1306,refuted) :- status(o_f0ef7908a7bb43d41792,refuted).
node(n1306,unknown) :- status(o_f0ef7908a7bb43d41792,unknown).
node(n1307,supported) :- status(o_84641b5d925bc52c2f8e,supported).
node(n1307,refuted) :- status(o_84641b5d925bc52c2f8e,refuted).
node(n1307,unknown) :- status(o_84641b5d925bc52c2f8e,unknown).
node(n1308,supported) :- status(o_a948353aa15f40e41192,supported).
node(n1308,refuted) :- status(o_a948353aa15f40e41192,refuted).
node(n1308,unknown) :- status(o_a948353aa15f40e41192,unknown).
node(n1309,supported) :- status(o_15eaf91babc7eaba92b2,supported).
node(n1309,refuted) :- status(o_15eaf91babc7eaba92b2,refuted).
node(n1309,unknown) :- status(o_15eaf91babc7eaba92b2,unknown).
node(n1305,supported) :- node(n1306,supported), node(n1307,supported), node(n1308,supported), node(n1309,supported).
node(n1305,refuted) :- node(n1306,refuted).
node(n1305,refuted) :- node(n1307,refuted).
node(n1305,refuted) :- node(n1308,refuted).
node(n1305,refuted) :- node(n1309,refuted).
node(n1305,unknown) :- \+ node(n1305,supported), \+ node(n1305,refuted).
node(n1311,supported) :- status(o_c930e2dffe090a2ddd39,supported).
node(n1311,refuted) :- status(o_c930e2dffe090a2ddd39,refuted).
node(n1311,unknown) :- status(o_c930e2dffe090a2ddd39,unknown).
node(n1312,supported) :- status(o_4efd3e167ab266ff6597,supported).
node(n1312,refuted) :- status(o_4efd3e167ab266ff6597,refuted).
node(n1312,unknown) :- status(o_4efd3e167ab266ff6597,unknown).
node(n1313,supported) :- status(o_1da06c2c709b91e03edb,supported).
node(n1313,refuted) :- status(o_1da06c2c709b91e03edb,refuted).
node(n1313,unknown) :- status(o_1da06c2c709b91e03edb,unknown).
node(n1314,supported) :- status(o_7b53b358a5e413184821,supported).
node(n1314,refuted) :- status(o_7b53b358a5e413184821,refuted).
node(n1314,unknown) :- status(o_7b53b358a5e413184821,unknown).
node(n1310,supported) :- node(n1311,supported), node(n1312,supported), node(n1313,supported), node(n1314,supported).
node(n1310,refuted) :- node(n1311,refuted).
node(n1310,refuted) :- node(n1312,refuted).
node(n1310,refuted) :- node(n1313,refuted).
node(n1310,refuted) :- node(n1314,refuted).
node(n1310,unknown) :- \+ node(n1310,supported), \+ node(n1310,refuted).
node(n1304,refuted) :- node(n1305,refuted), node(n1310,refuted), node(n9,refuted).
node(n1304,supported) :- node(n1305,supported).
node(n1304,supported) :- node(n1310,supported).
node(n1304,supported) :- node(n9,supported).
node(n1304,unknown) :- \+ node(n1304,supported), \+ node(n1304,refuted).
verdict(c_c8aa9aca2c981e0f,supported) :- node(n1304,supported).
query(verdict(c_c8aa9aca2c981e0f,supported)).
verdict(c_c8aa9aca2c981e0f,refuted) :- node(n1304,refuted).
query(verdict(c_c8aa9aca2c981e0f,refuted)).
verdict(c_c8aa9aca2c981e0f,unknown) :- node(n1304,unknown).
query(verdict(c_c8aa9aca2c981e0f,unknown)).
node(n1317,supported) :- status(o_418f2289dae2c6527e6a,supported).
node(n1317,refuted) :- status(o_418f2289dae2c6527e6a,refuted).
node(n1317,unknown) :- status(o_418f2289dae2c6527e6a,unknown).
node(n1318,supported) :- status(o_842e4269a090dd2b5512,supported).
node(n1318,refuted) :- status(o_842e4269a090dd2b5512,refuted).
node(n1318,unknown) :- status(o_842e4269a090dd2b5512,unknown).
node(n1319,supported) :- status(o_2f9e0f463bb3f8951f80,supported).
node(n1319,refuted) :- status(o_2f9e0f463bb3f8951f80,refuted).
node(n1319,unknown) :- status(o_2f9e0f463bb3f8951f80,unknown).
node(n1316,supported) :- node(n1317,supported), node(n1318,supported), node(n1319,supported).
node(n1316,refuted) :- node(n1317,refuted).
node(n1316,refuted) :- node(n1318,refuted).
node(n1316,refuted) :- node(n1319,refuted).
node(n1316,unknown) :- \+ node(n1316,supported), \+ node(n1316,refuted).
node(n1321,supported) :- status(o_fd961e4c997836c7b542,supported).
node(n1321,refuted) :- status(o_fd961e4c997836c7b542,refuted).
node(n1321,unknown) :- status(o_fd961e4c997836c7b542,unknown).
node(n1322,supported) :- status(o_c40bbae46800aa87e8d6,supported).
node(n1322,refuted) :- status(o_c40bbae46800aa87e8d6,refuted).
node(n1322,unknown) :- status(o_c40bbae46800aa87e8d6,unknown).
node(n1323,supported) :- status(o_8485da62a489ee004499,supported).
node(n1323,refuted) :- status(o_8485da62a489ee004499,refuted).
node(n1323,unknown) :- status(o_8485da62a489ee004499,unknown).
node(n1320,supported) :- node(n1321,supported), node(n1322,supported), node(n1323,supported).
node(n1320,refuted) :- node(n1321,refuted).
node(n1320,refuted) :- node(n1322,refuted).
node(n1320,refuted) :- node(n1323,refuted).
node(n1320,unknown) :- \+ node(n1320,supported), \+ node(n1320,refuted).
node(n1315,refuted) :- node(n1316,refuted), node(n1320,refuted), node(n9,refuted).
node(n1315,supported) :- node(n1316,supported).
node(n1315,supported) :- node(n1320,supported).
node(n1315,supported) :- node(n9,supported).
node(n1315,unknown) :- \+ node(n1315,supported), \+ node(n1315,refuted).
verdict(c_23b953edbe6a807d,supported) :- node(n1315,supported).
query(verdict(c_23b953edbe6a807d,supported)).
verdict(c_23b953edbe6a807d,refuted) :- node(n1315,refuted).
query(verdict(c_23b953edbe6a807d,refuted)).
verdict(c_23b953edbe6a807d,unknown) :- node(n1315,unknown).
query(verdict(c_23b953edbe6a807d,unknown)).
node(n1326,supported) :- status(o_554d583c1ad401f6371e,supported).
node(n1326,refuted) :- status(o_554d583c1ad401f6371e,refuted).
node(n1326,unknown) :- status(o_554d583c1ad401f6371e,unknown).
node(n1327,supported) :- status(o_880ba8c5e2ad75cbd3ac,supported).
node(n1327,refuted) :- status(o_880ba8c5e2ad75cbd3ac,refuted).
node(n1327,unknown) :- status(o_880ba8c5e2ad75cbd3ac,unknown).
node(n1328,supported) :- status(o_48f4f942b589f04cfc01,supported).
node(n1328,refuted) :- status(o_48f4f942b589f04cfc01,refuted).
node(n1328,unknown) :- status(o_48f4f942b589f04cfc01,unknown).
node(n1329,supported) :- status(o_2c256cd7c4dd049745fb,supported).
node(n1329,refuted) :- status(o_2c256cd7c4dd049745fb,refuted).
node(n1329,unknown) :- status(o_2c256cd7c4dd049745fb,unknown).
node(n1325,supported) :- node(n1326,supported), node(n1327,supported), node(n1328,supported), node(n1329,supported).
node(n1325,refuted) :- node(n1326,refuted).
node(n1325,refuted) :- node(n1327,refuted).
node(n1325,refuted) :- node(n1328,refuted).
node(n1325,refuted) :- node(n1329,refuted).
node(n1325,unknown) :- \+ node(n1325,supported), \+ node(n1325,refuted).
node(n1331,supported) :- status(o_650319a47b9b5a3e96b4,supported).
node(n1331,refuted) :- status(o_650319a47b9b5a3e96b4,refuted).
node(n1331,unknown) :- status(o_650319a47b9b5a3e96b4,unknown).
node(n1332,supported) :- status(o_c850ae13ce86802cba39,supported).
node(n1332,refuted) :- status(o_c850ae13ce86802cba39,refuted).
node(n1332,unknown) :- status(o_c850ae13ce86802cba39,unknown).
node(n1333,supported) :- status(o_acf6d635d18126c401ff,supported).
node(n1333,refuted) :- status(o_acf6d635d18126c401ff,refuted).
node(n1333,unknown) :- status(o_acf6d635d18126c401ff,unknown).
node(n1334,supported) :- status(o_a52d7d14f94ee7919241,supported).
node(n1334,refuted) :- status(o_a52d7d14f94ee7919241,refuted).
node(n1334,unknown) :- status(o_a52d7d14f94ee7919241,unknown).
node(n1330,supported) :- node(n1331,supported), node(n1332,supported), node(n1333,supported), node(n1334,supported).
node(n1330,refuted) :- node(n1331,refuted).
node(n1330,refuted) :- node(n1332,refuted).
node(n1330,refuted) :- node(n1333,refuted).
node(n1330,refuted) :- node(n1334,refuted).
node(n1330,unknown) :- \+ node(n1330,supported), \+ node(n1330,refuted).
node(n1324,refuted) :- node(n1325,refuted), node(n1330,refuted), node(n9,refuted).
node(n1324,supported) :- node(n1325,supported).
node(n1324,supported) :- node(n1330,supported).
node(n1324,supported) :- node(n9,supported).
node(n1324,unknown) :- \+ node(n1324,supported), \+ node(n1324,refuted).
verdict(c_eb3ea356143ce10b,supported) :- node(n1324,supported).
query(verdict(c_eb3ea356143ce10b,supported)).
verdict(c_eb3ea356143ce10b,refuted) :- node(n1324,refuted).
query(verdict(c_eb3ea356143ce10b,refuted)).
verdict(c_eb3ea356143ce10b,unknown) :- node(n1324,unknown).
query(verdict(c_eb3ea356143ce10b,unknown)).
node(n1337,supported) :- status(o_a1aae904be2f928304d6,supported).
node(n1337,refuted) :- status(o_a1aae904be2f928304d6,refuted).
node(n1337,unknown) :- status(o_a1aae904be2f928304d6,unknown).
node(n1338,supported) :- status(o_7b643ec98a8a72f40e1f,supported).
node(n1338,refuted) :- status(o_7b643ec98a8a72f40e1f,refuted).
node(n1338,unknown) :- status(o_7b643ec98a8a72f40e1f,unknown).
node(n1339,supported) :- status(o_1866b1ec2beadfe3fcfe,supported).
node(n1339,refuted) :- status(o_1866b1ec2beadfe3fcfe,refuted).
node(n1339,unknown) :- status(o_1866b1ec2beadfe3fcfe,unknown).
node(n1340,supported) :- status(o_1f3340a2a91c8822faca,supported).
node(n1340,refuted) :- status(o_1f3340a2a91c8822faca,refuted).
node(n1340,unknown) :- status(o_1f3340a2a91c8822faca,unknown).
node(n1336,supported) :- node(n1337,supported), node(n1338,supported), node(n1339,supported), node(n1340,supported).
node(n1336,refuted) :- node(n1337,refuted).
node(n1336,refuted) :- node(n1338,refuted).
node(n1336,refuted) :- node(n1339,refuted).
node(n1336,refuted) :- node(n1340,refuted).
node(n1336,unknown) :- \+ node(n1336,supported), \+ node(n1336,refuted).
node(n1342,supported) :- status(o_5fcc5fe1d91e74d46e5c,supported).
node(n1342,refuted) :- status(o_5fcc5fe1d91e74d46e5c,refuted).
node(n1342,unknown) :- status(o_5fcc5fe1d91e74d46e5c,unknown).
node(n1343,supported) :- status(o_5779b732736080e32dbc,supported).
node(n1343,refuted) :- status(o_5779b732736080e32dbc,refuted).
node(n1343,unknown) :- status(o_5779b732736080e32dbc,unknown).
node(n1344,supported) :- status(o_7d6476da18525cf61888,supported).
node(n1344,refuted) :- status(o_7d6476da18525cf61888,refuted).
node(n1344,unknown) :- status(o_7d6476da18525cf61888,unknown).
node(n1345,supported) :- status(o_8f362de248675a5de157,supported).
node(n1345,refuted) :- status(o_8f362de248675a5de157,refuted).
node(n1345,unknown) :- status(o_8f362de248675a5de157,unknown).
node(n1341,supported) :- node(n1342,supported), node(n1343,supported), node(n1344,supported), node(n1345,supported).
node(n1341,refuted) :- node(n1342,refuted).
node(n1341,refuted) :- node(n1343,refuted).
node(n1341,refuted) :- node(n1344,refuted).
node(n1341,refuted) :- node(n1345,refuted).
node(n1341,unknown) :- \+ node(n1341,supported), \+ node(n1341,refuted).
node(n1335,refuted) :- node(n1336,refuted), node(n1341,refuted), node(n9,refuted).
node(n1335,supported) :- node(n1336,supported).
node(n1335,supported) :- node(n1341,supported).
node(n1335,supported) :- node(n9,supported).
node(n1335,unknown) :- \+ node(n1335,supported), \+ node(n1335,refuted).
verdict(c_babbbdf44ec14729,supported) :- node(n1335,supported).
query(verdict(c_babbbdf44ec14729,supported)).
verdict(c_babbbdf44ec14729,refuted) :- node(n1335,refuted).
query(verdict(c_babbbdf44ec14729,refuted)).
verdict(c_babbbdf44ec14729,unknown) :- node(n1335,unknown).
query(verdict(c_babbbdf44ec14729,unknown)).
node(n1348,supported) :- status(o_e98136905fa99407c995,supported).
node(n1348,refuted) :- status(o_e98136905fa99407c995,refuted).
node(n1348,unknown) :- status(o_e98136905fa99407c995,unknown).
node(n1349,supported) :- status(o_38b1b2c5afb1433acd2a,supported).
node(n1349,refuted) :- status(o_38b1b2c5afb1433acd2a,refuted).
node(n1349,unknown) :- status(o_38b1b2c5afb1433acd2a,unknown).
node(n1350,supported) :- status(o_831fef9d5f43f38a7214,supported).
node(n1350,refuted) :- status(o_831fef9d5f43f38a7214,refuted).
node(n1350,unknown) :- status(o_831fef9d5f43f38a7214,unknown).
node(n1351,supported) :- status(o_765d2d8205b705db09fa,supported).
node(n1351,refuted) :- status(o_765d2d8205b705db09fa,refuted).
node(n1351,unknown) :- status(o_765d2d8205b705db09fa,unknown).
node(n1347,supported) :- node(n1348,supported), node(n1349,supported), node(n1350,supported), node(n1351,supported).
node(n1347,refuted) :- node(n1348,refuted).
node(n1347,refuted) :- node(n1349,refuted).
node(n1347,refuted) :- node(n1350,refuted).
node(n1347,refuted) :- node(n1351,refuted).
node(n1347,unknown) :- \+ node(n1347,supported), \+ node(n1347,refuted).
node(n1353,supported) :- status(o_1c85d9248b48db909bd8,supported).
node(n1353,refuted) :- status(o_1c85d9248b48db909bd8,refuted).
node(n1353,unknown) :- status(o_1c85d9248b48db909bd8,unknown).
node(n1354,supported) :- status(o_cd8747bff95cfe88b027,supported).
node(n1354,refuted) :- status(o_cd8747bff95cfe88b027,refuted).
node(n1354,unknown) :- status(o_cd8747bff95cfe88b027,unknown).
node(n1355,supported) :- status(o_f2c4afd91e85998ffc96,supported).
node(n1355,refuted) :- status(o_f2c4afd91e85998ffc96,refuted).
node(n1355,unknown) :- status(o_f2c4afd91e85998ffc96,unknown).
node(n1356,supported) :- status(o_accf334d108e9206b015,supported).
node(n1356,refuted) :- status(o_accf334d108e9206b015,refuted).
node(n1356,unknown) :- status(o_accf334d108e9206b015,unknown).
node(n1352,supported) :- node(n1353,supported), node(n1354,supported), node(n1355,supported), node(n1356,supported).
node(n1352,refuted) :- node(n1353,refuted).
node(n1352,refuted) :- node(n1354,refuted).
node(n1352,refuted) :- node(n1355,refuted).
node(n1352,refuted) :- node(n1356,refuted).
node(n1352,unknown) :- \+ node(n1352,supported), \+ node(n1352,refuted).
node(n1346,refuted) :- node(n1347,refuted), node(n1352,refuted), node(n9,refuted).
node(n1346,supported) :- node(n1347,supported).
node(n1346,supported) :- node(n1352,supported).
node(n1346,supported) :- node(n9,supported).
node(n1346,unknown) :- \+ node(n1346,supported), \+ node(n1346,refuted).
verdict(c_9dbf87fba581e4a4,supported) :- node(n1346,supported).
query(verdict(c_9dbf87fba581e4a4,supported)).
verdict(c_9dbf87fba581e4a4,refuted) :- node(n1346,refuted).
query(verdict(c_9dbf87fba581e4a4,refuted)).
verdict(c_9dbf87fba581e4a4,unknown) :- node(n1346,unknown).
query(verdict(c_9dbf87fba581e4a4,unknown)).
node(n1359,supported) :- status(o_73f953214a253dd8f68c,supported).
node(n1359,refuted) :- status(o_73f953214a253dd8f68c,refuted).
node(n1359,unknown) :- status(o_73f953214a253dd8f68c,unknown).
node(n1360,supported) :- status(o_77635d914d8ad7bc185b,supported).
node(n1360,refuted) :- status(o_77635d914d8ad7bc185b,refuted).
node(n1360,unknown) :- status(o_77635d914d8ad7bc185b,unknown).
node(n1361,supported) :- status(o_ef4e548f0ae2eaf0b516,supported).
node(n1361,refuted) :- status(o_ef4e548f0ae2eaf0b516,refuted).
node(n1361,unknown) :- status(o_ef4e548f0ae2eaf0b516,unknown).
node(n1358,supported) :- node(n1359,supported), node(n1360,supported), node(n1361,supported).
node(n1358,refuted) :- node(n1359,refuted).
node(n1358,refuted) :- node(n1360,refuted).
node(n1358,refuted) :- node(n1361,refuted).
node(n1358,unknown) :- \+ node(n1358,supported), \+ node(n1358,refuted).
node(n1363,supported) :- status(o_99d5df8fc7c0e35a3115,supported).
node(n1363,refuted) :- status(o_99d5df8fc7c0e35a3115,refuted).
node(n1363,unknown) :- status(o_99d5df8fc7c0e35a3115,unknown).
node(n1364,supported) :- status(o_f35e2d21782b6ef9e33d,supported).
node(n1364,refuted) :- status(o_f35e2d21782b6ef9e33d,refuted).
node(n1364,unknown) :- status(o_f35e2d21782b6ef9e33d,unknown).
node(n1365,supported) :- status(o_d4e16cdcc124d804fb79,supported).
node(n1365,refuted) :- status(o_d4e16cdcc124d804fb79,refuted).
node(n1365,unknown) :- status(o_d4e16cdcc124d804fb79,unknown).
node(n1362,supported) :- node(n1363,supported), node(n1364,supported), node(n1365,supported).
node(n1362,refuted) :- node(n1363,refuted).
node(n1362,refuted) :- node(n1364,refuted).
node(n1362,refuted) :- node(n1365,refuted).
node(n1362,unknown) :- \+ node(n1362,supported), \+ node(n1362,refuted).
node(n1357,refuted) :- node(n1358,refuted), node(n1362,refuted), node(n9,refuted).
node(n1357,supported) :- node(n1358,supported).
node(n1357,supported) :- node(n1362,supported).
node(n1357,supported) :- node(n9,supported).
node(n1357,unknown) :- \+ node(n1357,supported), \+ node(n1357,refuted).
verdict(c_39923ec2a2a7bdfc,supported) :- node(n1357,supported).
query(verdict(c_39923ec2a2a7bdfc,supported)).
verdict(c_39923ec2a2a7bdfc,refuted) :- node(n1357,refuted).
query(verdict(c_39923ec2a2a7bdfc,refuted)).
verdict(c_39923ec2a2a7bdfc,unknown) :- node(n1357,unknown).
query(verdict(c_39923ec2a2a7bdfc,unknown)).
node(n1368,supported) :- status(o_5a798042e42cbfdc3ba5,supported).
node(n1368,refuted) :- status(o_5a798042e42cbfdc3ba5,refuted).
node(n1368,unknown) :- status(o_5a798042e42cbfdc3ba5,unknown).
node(n1369,supported) :- status(o_f66b9bd7b2b5a1bed6da,supported).
node(n1369,refuted) :- status(o_f66b9bd7b2b5a1bed6da,refuted).
node(n1369,unknown) :- status(o_f66b9bd7b2b5a1bed6da,unknown).
node(n1370,supported) :- status(o_077bf51dc0af9b66c63c,supported).
node(n1370,refuted) :- status(o_077bf51dc0af9b66c63c,refuted).
node(n1370,unknown) :- status(o_077bf51dc0af9b66c63c,unknown).
node(n1371,supported) :- status(o_773e2a3f088021a77906,supported).
node(n1371,refuted) :- status(o_773e2a3f088021a77906,refuted).
node(n1371,unknown) :- status(o_773e2a3f088021a77906,unknown).
node(n1367,supported) :- node(n1368,supported), node(n1369,supported), node(n1370,supported), node(n1371,supported).
node(n1367,refuted) :- node(n1368,refuted).
node(n1367,refuted) :- node(n1369,refuted).
node(n1367,refuted) :- node(n1370,refuted).
node(n1367,refuted) :- node(n1371,refuted).
node(n1367,unknown) :- \+ node(n1367,supported), \+ node(n1367,refuted).
node(n1373,supported) :- status(o_5edd5fc6af2188a87f56,supported).
node(n1373,refuted) :- status(o_5edd5fc6af2188a87f56,refuted).
node(n1373,unknown) :- status(o_5edd5fc6af2188a87f56,unknown).
node(n1374,supported) :- status(o_7a4de60d11afc861ceb1,supported).
node(n1374,refuted) :- status(o_7a4de60d11afc861ceb1,refuted).
node(n1374,unknown) :- status(o_7a4de60d11afc861ceb1,unknown).
node(n1375,supported) :- status(o_655c4da19cf1de846d19,supported).
node(n1375,refuted) :- status(o_655c4da19cf1de846d19,refuted).
node(n1375,unknown) :- status(o_655c4da19cf1de846d19,unknown).
node(n1376,supported) :- status(o_fab4f075c7f1b8226c11,supported).
node(n1376,refuted) :- status(o_fab4f075c7f1b8226c11,refuted).
node(n1376,unknown) :- status(o_fab4f075c7f1b8226c11,unknown).
node(n1372,supported) :- node(n1373,supported), node(n1374,supported), node(n1375,supported), node(n1376,supported).
node(n1372,refuted) :- node(n1373,refuted).
node(n1372,refuted) :- node(n1374,refuted).
node(n1372,refuted) :- node(n1375,refuted).
node(n1372,refuted) :- node(n1376,refuted).
node(n1372,unknown) :- \+ node(n1372,supported), \+ node(n1372,refuted).
node(n1366,refuted) :- node(n1367,refuted), node(n1372,refuted), node(n9,refuted).
node(n1366,supported) :- node(n1367,supported).
node(n1366,supported) :- node(n1372,supported).
node(n1366,supported) :- node(n9,supported).
node(n1366,unknown) :- \+ node(n1366,supported), \+ node(n1366,refuted).
verdict(c_ec777e2ed8a68eb8,supported) :- node(n1366,supported).
query(verdict(c_ec777e2ed8a68eb8,supported)).
verdict(c_ec777e2ed8a68eb8,refuted) :- node(n1366,refuted).
query(verdict(c_ec777e2ed8a68eb8,refuted)).
verdict(c_ec777e2ed8a68eb8,unknown) :- node(n1366,unknown).
query(verdict(c_ec777e2ed8a68eb8,unknown)).
node(n1379,supported) :- status(o_608b8120a4b046460cbf,supported).
node(n1379,refuted) :- status(o_608b8120a4b046460cbf,refuted).
node(n1379,unknown) :- status(o_608b8120a4b046460cbf,unknown).
node(n1380,supported) :- status(o_6bfbe84ab2ffcf25c7df,supported).
node(n1380,refuted) :- status(o_6bfbe84ab2ffcf25c7df,refuted).
node(n1380,unknown) :- status(o_6bfbe84ab2ffcf25c7df,unknown).
node(n1381,supported) :- status(o_56f9d2b6ce3c962e5814,supported).
node(n1381,refuted) :- status(o_56f9d2b6ce3c962e5814,refuted).
node(n1381,unknown) :- status(o_56f9d2b6ce3c962e5814,unknown).
node(n1382,supported) :- status(o_6f9e13cf909a274e058b,supported).
node(n1382,refuted) :- status(o_6f9e13cf909a274e058b,refuted).
node(n1382,unknown) :- status(o_6f9e13cf909a274e058b,unknown).
node(n1378,supported) :- node(n1379,supported), node(n1380,supported), node(n1381,supported), node(n1382,supported).
node(n1378,refuted) :- node(n1379,refuted).
node(n1378,refuted) :- node(n1380,refuted).
node(n1378,refuted) :- node(n1381,refuted).
node(n1378,refuted) :- node(n1382,refuted).
node(n1378,unknown) :- \+ node(n1378,supported), \+ node(n1378,refuted).
node(n1384,supported) :- status(o_f5ba74b7bbe1b31403f3,supported).
node(n1384,refuted) :- status(o_f5ba74b7bbe1b31403f3,refuted).
node(n1384,unknown) :- status(o_f5ba74b7bbe1b31403f3,unknown).
node(n1385,supported) :- status(o_00a49d6062a2c3a315c7,supported).
node(n1385,refuted) :- status(o_00a49d6062a2c3a315c7,refuted).
node(n1385,unknown) :- status(o_00a49d6062a2c3a315c7,unknown).
node(n1386,supported) :- status(o_1bfe67fc072ab79c8012,supported).
node(n1386,refuted) :- status(o_1bfe67fc072ab79c8012,refuted).
node(n1386,unknown) :- status(o_1bfe67fc072ab79c8012,unknown).
node(n1387,supported) :- status(o_f801481b50e0479853d0,supported).
node(n1387,refuted) :- status(o_f801481b50e0479853d0,refuted).
node(n1387,unknown) :- status(o_f801481b50e0479853d0,unknown).
node(n1383,supported) :- node(n1384,supported), node(n1385,supported), node(n1386,supported), node(n1387,supported).
node(n1383,refuted) :- node(n1384,refuted).
node(n1383,refuted) :- node(n1385,refuted).
node(n1383,refuted) :- node(n1386,refuted).
node(n1383,refuted) :- node(n1387,refuted).
node(n1383,unknown) :- \+ node(n1383,supported), \+ node(n1383,refuted).
node(n1377,refuted) :- node(n1378,refuted), node(n1383,refuted), node(n9,refuted).
node(n1377,supported) :- node(n1378,supported).
node(n1377,supported) :- node(n1383,supported).
node(n1377,supported) :- node(n9,supported).
node(n1377,unknown) :- \+ node(n1377,supported), \+ node(n1377,refuted).
verdict(c_bbd28ea43f377621,supported) :- node(n1377,supported).
query(verdict(c_bbd28ea43f377621,supported)).
verdict(c_bbd28ea43f377621,refuted) :- node(n1377,refuted).
query(verdict(c_bbd28ea43f377621,refuted)).
verdict(c_bbd28ea43f377621,unknown) :- node(n1377,unknown).
query(verdict(c_bbd28ea43f377621,unknown)).
node(n1390,supported) :- status(o_7b960b5d721fd46bc3f3,supported).
node(n1390,refuted) :- status(o_7b960b5d721fd46bc3f3,refuted).
node(n1390,unknown) :- status(o_7b960b5d721fd46bc3f3,unknown).
node(n1391,supported) :- status(o_2f9d3dcefeeee0f67afe,supported).
node(n1391,refuted) :- status(o_2f9d3dcefeeee0f67afe,refuted).
node(n1391,unknown) :- status(o_2f9d3dcefeeee0f67afe,unknown).
node(n1392,supported) :- status(o_140c44e3c3bc1d78de4b,supported).
node(n1392,refuted) :- status(o_140c44e3c3bc1d78de4b,refuted).
node(n1392,unknown) :- status(o_140c44e3c3bc1d78de4b,unknown).
node(n1393,supported) :- status(o_275697c6bcd0f2c823e2,supported).
node(n1393,refuted) :- status(o_275697c6bcd0f2c823e2,refuted).
node(n1393,unknown) :- status(o_275697c6bcd0f2c823e2,unknown).
node(n1389,supported) :- node(n1390,supported), node(n1391,supported), node(n1392,supported), node(n1393,supported).
node(n1389,refuted) :- node(n1390,refuted).
node(n1389,refuted) :- node(n1391,refuted).
node(n1389,refuted) :- node(n1392,refuted).
node(n1389,refuted) :- node(n1393,refuted).
node(n1389,unknown) :- \+ node(n1389,supported), \+ node(n1389,refuted).
node(n1395,supported) :- status(o_0bf50896b2537f2f80ed,supported).
node(n1395,refuted) :- status(o_0bf50896b2537f2f80ed,refuted).
node(n1395,unknown) :- status(o_0bf50896b2537f2f80ed,unknown).
node(n1396,supported) :- status(o_6e7b495fecfad560cc92,supported).
node(n1396,refuted) :- status(o_6e7b495fecfad560cc92,refuted).
node(n1396,unknown) :- status(o_6e7b495fecfad560cc92,unknown).
node(n1397,supported) :- status(o_16880d75a3a7b9799823,supported).
node(n1397,refuted) :- status(o_16880d75a3a7b9799823,refuted).
node(n1397,unknown) :- status(o_16880d75a3a7b9799823,unknown).
node(n1398,supported) :- status(o_6761df32008c0a2e8123,supported).
node(n1398,refuted) :- status(o_6761df32008c0a2e8123,refuted).
node(n1398,unknown) :- status(o_6761df32008c0a2e8123,unknown).
node(n1394,supported) :- node(n1395,supported), node(n1396,supported), node(n1397,supported), node(n1398,supported).
node(n1394,refuted) :- node(n1395,refuted).
node(n1394,refuted) :- node(n1396,refuted).
node(n1394,refuted) :- node(n1397,refuted).
node(n1394,refuted) :- node(n1398,refuted).
node(n1394,unknown) :- \+ node(n1394,supported), \+ node(n1394,refuted).
node(n1388,refuted) :- node(n1389,refuted), node(n1394,refuted), node(n9,refuted).
node(n1388,supported) :- node(n1389,supported).
node(n1388,supported) :- node(n1394,supported).
node(n1388,supported) :- node(n9,supported).
node(n1388,unknown) :- \+ node(n1388,supported), \+ node(n1388,refuted).
verdict(c_5fe050d30a142910,supported) :- node(n1388,supported).
query(verdict(c_5fe050d30a142910,supported)).
verdict(c_5fe050d30a142910,refuted) :- node(n1388,refuted).
query(verdict(c_5fe050d30a142910,refuted)).
verdict(c_5fe050d30a142910,unknown) :- node(n1388,unknown).
query(verdict(c_5fe050d30a142910,unknown)).
node(n1401,supported) :- status(o_04ec26e4efdcab4c47ff,supported).
node(n1401,refuted) :- status(o_04ec26e4efdcab4c47ff,refuted).
node(n1401,unknown) :- status(o_04ec26e4efdcab4c47ff,unknown).
node(n1402,supported) :- status(o_b97461d759167ce5ea2a,supported).
node(n1402,refuted) :- status(o_b97461d759167ce5ea2a,refuted).
node(n1402,unknown) :- status(o_b97461d759167ce5ea2a,unknown).
node(n1403,supported) :- status(o_25f456ed0d6fc97ec5f8,supported).
node(n1403,refuted) :- status(o_25f456ed0d6fc97ec5f8,refuted).
node(n1403,unknown) :- status(o_25f456ed0d6fc97ec5f8,unknown).
node(n1400,supported) :- node(n1401,supported), node(n1402,supported), node(n1403,supported).
node(n1400,refuted) :- node(n1401,refuted).
node(n1400,refuted) :- node(n1402,refuted).
node(n1400,refuted) :- node(n1403,refuted).
node(n1400,unknown) :- \+ node(n1400,supported), \+ node(n1400,refuted).
node(n1405,supported) :- status(o_b3f2bb1bde0a2f3c6cbb,supported).
node(n1405,refuted) :- status(o_b3f2bb1bde0a2f3c6cbb,refuted).
node(n1405,unknown) :- status(o_b3f2bb1bde0a2f3c6cbb,unknown).
node(n1406,supported) :- status(o_3a2132a595dfe5dfb343,supported).
node(n1406,refuted) :- status(o_3a2132a595dfe5dfb343,refuted).
node(n1406,unknown) :- status(o_3a2132a595dfe5dfb343,unknown).
node(n1407,supported) :- status(o_de438038c7925581809c,supported).
node(n1407,refuted) :- status(o_de438038c7925581809c,refuted).
node(n1407,unknown) :- status(o_de438038c7925581809c,unknown).
node(n1404,supported) :- node(n1405,supported), node(n1406,supported), node(n1407,supported).
node(n1404,refuted) :- node(n1405,refuted).
node(n1404,refuted) :- node(n1406,refuted).
node(n1404,refuted) :- node(n1407,refuted).
node(n1404,unknown) :- \+ node(n1404,supported), \+ node(n1404,refuted).
node(n1399,refuted) :- node(n1400,refuted), node(n1404,refuted), node(n9,refuted).
node(n1399,supported) :- node(n1400,supported).
node(n1399,supported) :- node(n1404,supported).
node(n1399,supported) :- node(n9,supported).
node(n1399,unknown) :- \+ node(n1399,supported), \+ node(n1399,refuted).
verdict(c_e83142933f5b3047,supported) :- node(n1399,supported).
query(verdict(c_e83142933f5b3047,supported)).
verdict(c_e83142933f5b3047,refuted) :- node(n1399,refuted).
query(verdict(c_e83142933f5b3047,refuted)).
verdict(c_e83142933f5b3047,unknown) :- node(n1399,unknown).
query(verdict(c_e83142933f5b3047,unknown)).
node(n1410,supported) :- status(o_1a54aa9ccf831515f3e7,supported).
node(n1410,refuted) :- status(o_1a54aa9ccf831515f3e7,refuted).
node(n1410,unknown) :- status(o_1a54aa9ccf831515f3e7,unknown).
node(n1411,supported) :- status(o_af570ab68034254e62ed,supported).
node(n1411,refuted) :- status(o_af570ab68034254e62ed,refuted).
node(n1411,unknown) :- status(o_af570ab68034254e62ed,unknown).
node(n1412,supported) :- status(o_3cb1c0d6bd359a20bea9,supported).
node(n1412,refuted) :- status(o_3cb1c0d6bd359a20bea9,refuted).
node(n1412,unknown) :- status(o_3cb1c0d6bd359a20bea9,unknown).
node(n1413,supported) :- status(o_2282e43241a3234d63ba,supported).
node(n1413,refuted) :- status(o_2282e43241a3234d63ba,refuted).
node(n1413,unknown) :- status(o_2282e43241a3234d63ba,unknown).
node(n1409,supported) :- node(n1410,supported), node(n1411,supported), node(n1412,supported), node(n1413,supported).
node(n1409,refuted) :- node(n1410,refuted).
node(n1409,refuted) :- node(n1411,refuted).
node(n1409,refuted) :- node(n1412,refuted).
node(n1409,refuted) :- node(n1413,refuted).
node(n1409,unknown) :- \+ node(n1409,supported), \+ node(n1409,refuted).
node(n1415,supported) :- status(o_6cccf5218521a4fc3551,supported).
node(n1415,refuted) :- status(o_6cccf5218521a4fc3551,refuted).
node(n1415,unknown) :- status(o_6cccf5218521a4fc3551,unknown).
node(n1416,supported) :- status(o_78bb8b1145b13fbcf8ed,supported).
node(n1416,refuted) :- status(o_78bb8b1145b13fbcf8ed,refuted).
node(n1416,unknown) :- status(o_78bb8b1145b13fbcf8ed,unknown).
node(n1417,supported) :- status(o_f55894965878e5ba23a0,supported).
node(n1417,refuted) :- status(o_f55894965878e5ba23a0,refuted).
node(n1417,unknown) :- status(o_f55894965878e5ba23a0,unknown).
node(n1418,supported) :- status(o_f02b6fcd3df6ee126f00,supported).
node(n1418,refuted) :- status(o_f02b6fcd3df6ee126f00,refuted).
node(n1418,unknown) :- status(o_f02b6fcd3df6ee126f00,unknown).
node(n1414,supported) :- node(n1415,supported), node(n1416,supported), node(n1417,supported), node(n1418,supported).
node(n1414,refuted) :- node(n1415,refuted).
node(n1414,refuted) :- node(n1416,refuted).
node(n1414,refuted) :- node(n1417,refuted).
node(n1414,refuted) :- node(n1418,refuted).
node(n1414,unknown) :- \+ node(n1414,supported), \+ node(n1414,refuted).
node(n1408,refuted) :- node(n1409,refuted), node(n1414,refuted), node(n9,refuted).
node(n1408,supported) :- node(n1409,supported).
node(n1408,supported) :- node(n1414,supported).
node(n1408,supported) :- node(n9,supported).
node(n1408,unknown) :- \+ node(n1408,supported), \+ node(n1408,refuted).
verdict(c_a159d3d00a9281a4,supported) :- node(n1408,supported).
query(verdict(c_a159d3d00a9281a4,supported)).
verdict(c_a159d3d00a9281a4,refuted) :- node(n1408,refuted).
query(verdict(c_a159d3d00a9281a4,refuted)).
verdict(c_a159d3d00a9281a4,unknown) :- node(n1408,unknown).
query(verdict(c_a159d3d00a9281a4,unknown)).
node(n1421,supported) :- status(o_f173a5d7b9e1fefdf9cd,supported).
node(n1421,refuted) :- status(o_f173a5d7b9e1fefdf9cd,refuted).
node(n1421,unknown) :- status(o_f173a5d7b9e1fefdf9cd,unknown).
node(n1422,supported) :- status(o_9bcd39cf8d67db3f73e5,supported).
node(n1422,refuted) :- status(o_9bcd39cf8d67db3f73e5,refuted).
node(n1422,unknown) :- status(o_9bcd39cf8d67db3f73e5,unknown).
node(n1423,supported) :- status(o_50ab1da0f8742a99d023,supported).
node(n1423,refuted) :- status(o_50ab1da0f8742a99d023,refuted).
node(n1423,unknown) :- status(o_50ab1da0f8742a99d023,unknown).
node(n1424,supported) :- status(o_586e0f67a5819b654d78,supported).
node(n1424,refuted) :- status(o_586e0f67a5819b654d78,refuted).
node(n1424,unknown) :- status(o_586e0f67a5819b654d78,unknown).
node(n1420,supported) :- node(n1421,supported), node(n1422,supported), node(n1423,supported), node(n1424,supported).
node(n1420,refuted) :- node(n1421,refuted).
node(n1420,refuted) :- node(n1422,refuted).
node(n1420,refuted) :- node(n1423,refuted).
node(n1420,refuted) :- node(n1424,refuted).
node(n1420,unknown) :- \+ node(n1420,supported), \+ node(n1420,refuted).
node(n1426,supported) :- status(o_5d3ce3fcd246fd7b8c9b,supported).
node(n1426,refuted) :- status(o_5d3ce3fcd246fd7b8c9b,refuted).
node(n1426,unknown) :- status(o_5d3ce3fcd246fd7b8c9b,unknown).
node(n1427,supported) :- status(o_e2c5bc0c2d4b1267c059,supported).
node(n1427,refuted) :- status(o_e2c5bc0c2d4b1267c059,refuted).
node(n1427,unknown) :- status(o_e2c5bc0c2d4b1267c059,unknown).
node(n1428,supported) :- status(o_630684c7fc1162ca5530,supported).
node(n1428,refuted) :- status(o_630684c7fc1162ca5530,refuted).
node(n1428,unknown) :- status(o_630684c7fc1162ca5530,unknown).
node(n1429,supported) :- status(o_e85177531c234eda872d,supported).
node(n1429,refuted) :- status(o_e85177531c234eda872d,refuted).
node(n1429,unknown) :- status(o_e85177531c234eda872d,unknown).
node(n1425,supported) :- node(n1426,supported), node(n1427,supported), node(n1428,supported), node(n1429,supported).
node(n1425,refuted) :- node(n1426,refuted).
node(n1425,refuted) :- node(n1427,refuted).
node(n1425,refuted) :- node(n1428,refuted).
node(n1425,refuted) :- node(n1429,refuted).
node(n1425,unknown) :- \+ node(n1425,supported), \+ node(n1425,refuted).
node(n1419,refuted) :- node(n1420,refuted), node(n1425,refuted), node(n9,refuted).
node(n1419,supported) :- node(n1420,supported).
node(n1419,supported) :- node(n1425,supported).
node(n1419,supported) :- node(n9,supported).
node(n1419,unknown) :- \+ node(n1419,supported), \+ node(n1419,refuted).
verdict(c_84b544a57719001d,supported) :- node(n1419,supported).
query(verdict(c_84b544a57719001d,supported)).
verdict(c_84b544a57719001d,refuted) :- node(n1419,refuted).
query(verdict(c_84b544a57719001d,refuted)).
verdict(c_84b544a57719001d,unknown) :- node(n1419,unknown).
query(verdict(c_84b544a57719001d,unknown)).
node(n1432,supported) :- status(o_33dc779f414a59de7e73,supported).
node(n1432,refuted) :- status(o_33dc779f414a59de7e73,refuted).
node(n1432,unknown) :- status(o_33dc779f414a59de7e73,unknown).
node(n1433,supported) :- status(o_69fcd8a3890e230153ac,supported).
node(n1433,refuted) :- status(o_69fcd8a3890e230153ac,refuted).
node(n1433,unknown) :- status(o_69fcd8a3890e230153ac,unknown).
node(n1434,supported) :- status(o_a1afcfce81052abf7af0,supported).
node(n1434,refuted) :- status(o_a1afcfce81052abf7af0,refuted).
node(n1434,unknown) :- status(o_a1afcfce81052abf7af0,unknown).
node(n1435,supported) :- status(o_d6fa0a0ae270bcfd8a6c,supported).
node(n1435,refuted) :- status(o_d6fa0a0ae270bcfd8a6c,refuted).
node(n1435,unknown) :- status(o_d6fa0a0ae270bcfd8a6c,unknown).
node(n1431,supported) :- node(n1432,supported), node(n1433,supported), node(n1434,supported), node(n1435,supported).
node(n1431,refuted) :- node(n1432,refuted).
node(n1431,refuted) :- node(n1433,refuted).
node(n1431,refuted) :- node(n1434,refuted).
node(n1431,refuted) :- node(n1435,refuted).
node(n1431,unknown) :- \+ node(n1431,supported), \+ node(n1431,refuted).
node(n1437,supported) :- status(o_e29ed797926b66159c3d,supported).
node(n1437,refuted) :- status(o_e29ed797926b66159c3d,refuted).
node(n1437,unknown) :- status(o_e29ed797926b66159c3d,unknown).
node(n1438,supported) :- status(o_ad9bf51d5e582ea8e6d6,supported).
node(n1438,refuted) :- status(o_ad9bf51d5e582ea8e6d6,refuted).
node(n1438,unknown) :- status(o_ad9bf51d5e582ea8e6d6,unknown).
node(n1439,supported) :- status(o_558732b29fada72af7d5,supported).
node(n1439,refuted) :- status(o_558732b29fada72af7d5,refuted).
node(n1439,unknown) :- status(o_558732b29fada72af7d5,unknown).
node(n1440,supported) :- status(o_39888368b9bc4929a1ad,supported).
node(n1440,refuted) :- status(o_39888368b9bc4929a1ad,refuted).
node(n1440,unknown) :- status(o_39888368b9bc4929a1ad,unknown).
node(n1436,supported) :- node(n1437,supported), node(n1438,supported), node(n1439,supported), node(n1440,supported).
node(n1436,refuted) :- node(n1437,refuted).
node(n1436,refuted) :- node(n1438,refuted).
node(n1436,refuted) :- node(n1439,refuted).
node(n1436,refuted) :- node(n1440,refuted).
node(n1436,unknown) :- \+ node(n1436,supported), \+ node(n1436,refuted).
node(n1430,refuted) :- node(n1431,refuted), node(n1436,refuted), node(n9,refuted).
node(n1430,supported) :- node(n1431,supported).
node(n1430,supported) :- node(n1436,supported).
node(n1430,supported) :- node(n9,supported).
node(n1430,unknown) :- \+ node(n1430,supported), \+ node(n1430,refuted).
verdict(c_65baad884608a444,supported) :- node(n1430,supported).
query(verdict(c_65baad884608a444,supported)).
verdict(c_65baad884608a444,refuted) :- node(n1430,refuted).
query(verdict(c_65baad884608a444,refuted)).
verdict(c_65baad884608a444,unknown) :- node(n1430,unknown).
query(verdict(c_65baad884608a444,unknown)).
node(n1443,supported) :- status(o_91268a74137a26ca6d45,supported).
node(n1443,refuted) :- status(o_91268a74137a26ca6d45,refuted).
node(n1443,unknown) :- status(o_91268a74137a26ca6d45,unknown).
node(n1444,supported) :- status(o_4bd72714916b558d7957,supported).
node(n1444,refuted) :- status(o_4bd72714916b558d7957,refuted).
node(n1444,unknown) :- status(o_4bd72714916b558d7957,unknown).
node(n1445,supported) :- status(o_b16806619732d4412a92,supported).
node(n1445,refuted) :- status(o_b16806619732d4412a92,refuted).
node(n1445,unknown) :- status(o_b16806619732d4412a92,unknown).
node(n1442,supported) :- node(n1443,supported), node(n1444,supported), node(n1445,supported).
node(n1442,refuted) :- node(n1443,refuted).
node(n1442,refuted) :- node(n1444,refuted).
node(n1442,refuted) :- node(n1445,refuted).
node(n1442,unknown) :- \+ node(n1442,supported), \+ node(n1442,refuted).
node(n1447,supported) :- status(o_69048f56fe5f7d10a2a1,supported).
node(n1447,refuted) :- status(o_69048f56fe5f7d10a2a1,refuted).
node(n1447,unknown) :- status(o_69048f56fe5f7d10a2a1,unknown).
node(n1448,supported) :- status(o_0fddd8517a5e66afab4a,supported).
node(n1448,refuted) :- status(o_0fddd8517a5e66afab4a,refuted).
node(n1448,unknown) :- status(o_0fddd8517a5e66afab4a,unknown).
node(n1449,supported) :- status(o_f40b63cfcd6f2a36a7d3,supported).
node(n1449,refuted) :- status(o_f40b63cfcd6f2a36a7d3,refuted).
node(n1449,unknown) :- status(o_f40b63cfcd6f2a36a7d3,unknown).
node(n1446,supported) :- node(n1447,supported), node(n1448,supported), node(n1449,supported).
node(n1446,refuted) :- node(n1447,refuted).
node(n1446,refuted) :- node(n1448,refuted).
node(n1446,refuted) :- node(n1449,refuted).
node(n1446,unknown) :- \+ node(n1446,supported), \+ node(n1446,refuted).
node(n1441,refuted) :- node(n1442,refuted), node(n1446,refuted), node(n9,refuted).
node(n1441,supported) :- node(n1442,supported).
node(n1441,supported) :- node(n1446,supported).
node(n1441,supported) :- node(n9,supported).
node(n1441,unknown) :- \+ node(n1441,supported), \+ node(n1441,refuted).
verdict(c_bdf67f203a07a2c5,supported) :- node(n1441,supported).
query(verdict(c_bdf67f203a07a2c5,supported)).
verdict(c_bdf67f203a07a2c5,refuted) :- node(n1441,refuted).
query(verdict(c_bdf67f203a07a2c5,refuted)).
verdict(c_bdf67f203a07a2c5,unknown) :- node(n1441,unknown).
query(verdict(c_bdf67f203a07a2c5,unknown)).
node(n1452,supported) :- status(o_6263a2412b8c3cbaaab6,supported).
node(n1452,refuted) :- status(o_6263a2412b8c3cbaaab6,refuted).
node(n1452,unknown) :- status(o_6263a2412b8c3cbaaab6,unknown).
node(n1453,supported) :- status(o_fe0ecb7e9a367df1c2fc,supported).
node(n1453,refuted) :- status(o_fe0ecb7e9a367df1c2fc,refuted).
node(n1453,unknown) :- status(o_fe0ecb7e9a367df1c2fc,unknown).
node(n1454,supported) :- status(o_87edf482a57349db5a1c,supported).
node(n1454,refuted) :- status(o_87edf482a57349db5a1c,refuted).
node(n1454,unknown) :- status(o_87edf482a57349db5a1c,unknown).
node(n1455,supported) :- status(o_b0fc9653ee27181cba71,supported).
node(n1455,refuted) :- status(o_b0fc9653ee27181cba71,refuted).
node(n1455,unknown) :- status(o_b0fc9653ee27181cba71,unknown).
node(n1451,supported) :- node(n1452,supported), node(n1453,supported), node(n1454,supported), node(n1455,supported).
node(n1451,refuted) :- node(n1452,refuted).
node(n1451,refuted) :- node(n1453,refuted).
node(n1451,refuted) :- node(n1454,refuted).
node(n1451,refuted) :- node(n1455,refuted).
node(n1451,unknown) :- \+ node(n1451,supported), \+ node(n1451,refuted).
node(n1457,supported) :- status(o_6cb206aac10d9ea041ee,supported).
node(n1457,refuted) :- status(o_6cb206aac10d9ea041ee,refuted).
node(n1457,unknown) :- status(o_6cb206aac10d9ea041ee,unknown).
node(n1458,supported) :- status(o_fd4269e5df22ea945f46,supported).
node(n1458,refuted) :- status(o_fd4269e5df22ea945f46,refuted).
node(n1458,unknown) :- status(o_fd4269e5df22ea945f46,unknown).
node(n1459,supported) :- status(o_2814fe74183fa7c91cd1,supported).
node(n1459,refuted) :- status(o_2814fe74183fa7c91cd1,refuted).
node(n1459,unknown) :- status(o_2814fe74183fa7c91cd1,unknown).
node(n1460,supported) :- status(o_a70793afe41b708425ea,supported).
node(n1460,refuted) :- status(o_a70793afe41b708425ea,refuted).
node(n1460,unknown) :- status(o_a70793afe41b708425ea,unknown).
node(n1456,supported) :- node(n1457,supported), node(n1458,supported), node(n1459,supported), node(n1460,supported).
node(n1456,refuted) :- node(n1457,refuted).
node(n1456,refuted) :- node(n1458,refuted).
node(n1456,refuted) :- node(n1459,refuted).
node(n1456,refuted) :- node(n1460,refuted).
node(n1456,unknown) :- \+ node(n1456,supported), \+ node(n1456,refuted).
node(n1450,refuted) :- node(n1451,refuted), node(n1456,refuted), node(n9,refuted).
node(n1450,supported) :- node(n1451,supported).
node(n1450,supported) :- node(n1456,supported).
node(n1450,supported) :- node(n9,supported).
node(n1450,unknown) :- \+ node(n1450,supported), \+ node(n1450,refuted).
verdict(c_6b2ce623f65e429a,supported) :- node(n1450,supported).
query(verdict(c_6b2ce623f65e429a,supported)).
verdict(c_6b2ce623f65e429a,refuted) :- node(n1450,refuted).
query(verdict(c_6b2ce623f65e429a,refuted)).
verdict(c_6b2ce623f65e429a,unknown) :- node(n1450,unknown).
query(verdict(c_6b2ce623f65e429a,unknown)).
node(n1463,supported) :- status(o_6fbfe6aebfefe18b81ce,supported).
node(n1463,refuted) :- status(o_6fbfe6aebfefe18b81ce,refuted).
node(n1463,unknown) :- status(o_6fbfe6aebfefe18b81ce,unknown).
node(n1464,supported) :- status(o_efa78458c5243af85e21,supported).
node(n1464,refuted) :- status(o_efa78458c5243af85e21,refuted).
node(n1464,unknown) :- status(o_efa78458c5243af85e21,unknown).
node(n1465,supported) :- status(o_9c15940fea77f229744f,supported).
node(n1465,refuted) :- status(o_9c15940fea77f229744f,refuted).
node(n1465,unknown) :- status(o_9c15940fea77f229744f,unknown).
node(n1466,supported) :- status(o_e6fd7d39987113209bbc,supported).
node(n1466,refuted) :- status(o_e6fd7d39987113209bbc,refuted).
node(n1466,unknown) :- status(o_e6fd7d39987113209bbc,unknown).
node(n1462,supported) :- node(n1463,supported), node(n1464,supported), node(n1465,supported), node(n1466,supported).
node(n1462,refuted) :- node(n1463,refuted).
node(n1462,refuted) :- node(n1464,refuted).
node(n1462,refuted) :- node(n1465,refuted).
node(n1462,refuted) :- node(n1466,refuted).
node(n1462,unknown) :- \+ node(n1462,supported), \+ node(n1462,refuted).
node(n1468,supported) :- status(o_67e4e5e22a0947cc8b02,supported).
node(n1468,refuted) :- status(o_67e4e5e22a0947cc8b02,refuted).
node(n1468,unknown) :- status(o_67e4e5e22a0947cc8b02,unknown).
node(n1469,supported) :- status(o_68112609dc8f2f51964d,supported).
node(n1469,refuted) :- status(o_68112609dc8f2f51964d,refuted).
node(n1469,unknown) :- status(o_68112609dc8f2f51964d,unknown).
node(n1470,supported) :- status(o_c43b9b4129d98c8de6d9,supported).
node(n1470,refuted) :- status(o_c43b9b4129d98c8de6d9,refuted).
node(n1470,unknown) :- status(o_c43b9b4129d98c8de6d9,unknown).
node(n1471,supported) :- status(o_4996dcb197a72903202c,supported).
node(n1471,refuted) :- status(o_4996dcb197a72903202c,refuted).
node(n1471,unknown) :- status(o_4996dcb197a72903202c,unknown).
node(n1467,supported) :- node(n1468,supported), node(n1469,supported), node(n1470,supported), node(n1471,supported).
node(n1467,refuted) :- node(n1468,refuted).
node(n1467,refuted) :- node(n1469,refuted).
node(n1467,refuted) :- node(n1470,refuted).
node(n1467,refuted) :- node(n1471,refuted).
node(n1467,unknown) :- \+ node(n1467,supported), \+ node(n1467,refuted).
node(n1461,refuted) :- node(n1462,refuted), node(n1467,refuted), node(n9,refuted).
node(n1461,supported) :- node(n1462,supported).
node(n1461,supported) :- node(n1467,supported).
node(n1461,supported) :- node(n9,supported).
node(n1461,unknown) :- \+ node(n1461,supported), \+ node(n1461,refuted).
verdict(c_dc850915e665825d,supported) :- node(n1461,supported).
query(verdict(c_dc850915e665825d,supported)).
verdict(c_dc850915e665825d,refuted) :- node(n1461,refuted).
query(verdict(c_dc850915e665825d,refuted)).
verdict(c_dc850915e665825d,unknown) :- node(n1461,unknown).
query(verdict(c_dc850915e665825d,unknown)).
node(n1474,supported) :- status(o_1ed920b9990565a06668,supported).
node(n1474,refuted) :- status(o_1ed920b9990565a06668,refuted).
node(n1474,unknown) :- status(o_1ed920b9990565a06668,unknown).
node(n1475,supported) :- status(o_c857d2bf04558f48b742,supported).
node(n1475,refuted) :- status(o_c857d2bf04558f48b742,refuted).
node(n1475,unknown) :- status(o_c857d2bf04558f48b742,unknown).
node(n1476,supported) :- status(o_d15c27632971b3e29246,supported).
node(n1476,refuted) :- status(o_d15c27632971b3e29246,refuted).
node(n1476,unknown) :- status(o_d15c27632971b3e29246,unknown).
node(n1477,supported) :- status(o_585e4db6437c600548a6,supported).
node(n1477,refuted) :- status(o_585e4db6437c600548a6,refuted).
node(n1477,unknown) :- status(o_585e4db6437c600548a6,unknown).
node(n1473,supported) :- node(n1474,supported), node(n1475,supported), node(n1476,supported), node(n1477,supported).
node(n1473,refuted) :- node(n1474,refuted).
node(n1473,refuted) :- node(n1475,refuted).
node(n1473,refuted) :- node(n1476,refuted).
node(n1473,refuted) :- node(n1477,refuted).
node(n1473,unknown) :- \+ node(n1473,supported), \+ node(n1473,refuted).
node(n1479,supported) :- status(o_115e911fb1b8436b7821,supported).
node(n1479,refuted) :- status(o_115e911fb1b8436b7821,refuted).
node(n1479,unknown) :- status(o_115e911fb1b8436b7821,unknown).
node(n1480,supported) :- status(o_583f8ca9ee00bec03a60,supported).
node(n1480,refuted) :- status(o_583f8ca9ee00bec03a60,refuted).
node(n1480,unknown) :- status(o_583f8ca9ee00bec03a60,unknown).
node(n1481,supported) :- status(o_d087113568f0ecd777a7,supported).
node(n1481,refuted) :- status(o_d087113568f0ecd777a7,refuted).
node(n1481,unknown) :- status(o_d087113568f0ecd777a7,unknown).
node(n1482,supported) :- status(o_2bffda20ec8fe75b07eb,supported).
node(n1482,refuted) :- status(o_2bffda20ec8fe75b07eb,refuted).
node(n1482,unknown) :- status(o_2bffda20ec8fe75b07eb,unknown).
node(n1478,supported) :- node(n1479,supported), node(n1480,supported), node(n1481,supported), node(n1482,supported).
node(n1478,refuted) :- node(n1479,refuted).
node(n1478,refuted) :- node(n1480,refuted).
node(n1478,refuted) :- node(n1481,refuted).
node(n1478,refuted) :- node(n1482,refuted).
node(n1478,unknown) :- \+ node(n1478,supported), \+ node(n1478,refuted).
node(n1472,refuted) :- node(n1473,refuted), node(n1478,refuted), node(n9,refuted).
node(n1472,supported) :- node(n1473,supported).
node(n1472,supported) :- node(n1478,supported).
node(n1472,supported) :- node(n9,supported).
node(n1472,unknown) :- \+ node(n1472,supported), \+ node(n1472,refuted).
verdict(c_a3e29b753ab3dbea,supported) :- node(n1472,supported).
query(verdict(c_a3e29b753ab3dbea,supported)).
verdict(c_a3e29b753ab3dbea,refuted) :- node(n1472,refuted).
query(verdict(c_a3e29b753ab3dbea,refuted)).
verdict(c_a3e29b753ab3dbea,unknown) :- node(n1472,unknown).
query(verdict(c_a3e29b753ab3dbea,unknown)).
node(n1485,supported) :- status(o_bad38350e3de0467dfd3,supported).
node(n1485,refuted) :- status(o_bad38350e3de0467dfd3,refuted).
node(n1485,unknown) :- status(o_bad38350e3de0467dfd3,unknown).
node(n1486,supported) :- status(o_6b00adb6ed8e1192ea8f,supported).
node(n1486,refuted) :- status(o_6b00adb6ed8e1192ea8f,refuted).
node(n1486,unknown) :- status(o_6b00adb6ed8e1192ea8f,unknown).
node(n1487,supported) :- status(o_87ce9c08bd12f3797657,supported).
node(n1487,refuted) :- status(o_87ce9c08bd12f3797657,refuted).
node(n1487,unknown) :- status(o_87ce9c08bd12f3797657,unknown).
node(n1484,supported) :- node(n1485,supported), node(n1486,supported), node(n1487,supported).
node(n1484,refuted) :- node(n1485,refuted).
node(n1484,refuted) :- node(n1486,refuted).
node(n1484,refuted) :- node(n1487,refuted).
node(n1484,unknown) :- \+ node(n1484,supported), \+ node(n1484,refuted).
node(n1483,refuted) :- node(n1484,refuted), node(n9,refuted).
node(n1483,supported) :- node(n1484,supported).
node(n1483,supported) :- node(n9,supported).
node(n1483,unknown) :- \+ node(n1483,supported), \+ node(n1483,refuted).
verdict(c_892d3345458955f9,supported) :- node(n1483,supported).
query(verdict(c_892d3345458955f9,supported)).
verdict(c_892d3345458955f9,refuted) :- node(n1483,refuted).
query(verdict(c_892d3345458955f9,refuted)).
verdict(c_892d3345458955f9,unknown) :- node(n1483,unknown).
query(verdict(c_892d3345458955f9,unknown)).
node(n1490,supported) :- status(o_140108997bc4d4f0bc72,supported).
node(n1490,refuted) :- status(o_140108997bc4d4f0bc72,refuted).
node(n1490,unknown) :- status(o_140108997bc4d4f0bc72,unknown).
node(n1491,supported) :- status(o_88ef2e2b3898c05617c3,supported).
node(n1491,refuted) :- status(o_88ef2e2b3898c05617c3,refuted).
node(n1491,unknown) :- status(o_88ef2e2b3898c05617c3,unknown).
node(n1492,supported) :- status(o_6f675db72fdf5e519f4a,supported).
node(n1492,refuted) :- status(o_6f675db72fdf5e519f4a,refuted).
node(n1492,unknown) :- status(o_6f675db72fdf5e519f4a,unknown).
node(n1493,supported) :- status(o_f1184516bdb3309cd8b9,supported).
node(n1493,refuted) :- status(o_f1184516bdb3309cd8b9,refuted).
node(n1493,unknown) :- status(o_f1184516bdb3309cd8b9,unknown).
node(n1489,supported) :- node(n1490,supported), node(n1491,supported), node(n1492,supported), node(n1493,supported).
node(n1489,refuted) :- node(n1490,refuted).
node(n1489,refuted) :- node(n1491,refuted).
node(n1489,refuted) :- node(n1492,refuted).
node(n1489,refuted) :- node(n1493,refuted).
node(n1489,unknown) :- \+ node(n1489,supported), \+ node(n1489,refuted).
node(n1488,refuted) :- node(n1489,refuted), node(n9,refuted).
node(n1488,supported) :- node(n1489,supported).
node(n1488,supported) :- node(n9,supported).
node(n1488,unknown) :- \+ node(n1488,supported), \+ node(n1488,refuted).
verdict(c_40b1010fc5dcff17,supported) :- node(n1488,supported).
query(verdict(c_40b1010fc5dcff17,supported)).
verdict(c_40b1010fc5dcff17,refuted) :- node(n1488,refuted).
query(verdict(c_40b1010fc5dcff17,refuted)).
verdict(c_40b1010fc5dcff17,unknown) :- node(n1488,unknown).
query(verdict(c_40b1010fc5dcff17,unknown)).
node(n1496,supported) :- status(o_e3cb3a441c534a595f7a,supported).
node(n1496,refuted) :- status(o_e3cb3a441c534a595f7a,refuted).
node(n1496,unknown) :- status(o_e3cb3a441c534a595f7a,unknown).
node(n1497,supported) :- status(o_4dc83d88b988e80eb113,supported).
node(n1497,refuted) :- status(o_4dc83d88b988e80eb113,refuted).
node(n1497,unknown) :- status(o_4dc83d88b988e80eb113,unknown).
node(n1498,supported) :- status(o_c2e9ea5043f377c76ea9,supported).
node(n1498,refuted) :- status(o_c2e9ea5043f377c76ea9,refuted).
node(n1498,unknown) :- status(o_c2e9ea5043f377c76ea9,unknown).
node(n1499,supported) :- status(o_74bf1320a9a15aeb2302,supported).
node(n1499,refuted) :- status(o_74bf1320a9a15aeb2302,refuted).
node(n1499,unknown) :- status(o_74bf1320a9a15aeb2302,unknown).
node(n1495,supported) :- node(n1496,supported), node(n1497,supported), node(n1498,supported), node(n1499,supported).
node(n1495,refuted) :- node(n1496,refuted).
node(n1495,refuted) :- node(n1497,refuted).
node(n1495,refuted) :- node(n1498,refuted).
node(n1495,refuted) :- node(n1499,refuted).
node(n1495,unknown) :- \+ node(n1495,supported), \+ node(n1495,refuted).
node(n1494,refuted) :- node(n1495,refuted), node(n9,refuted).
node(n1494,supported) :- node(n1495,supported).
node(n1494,supported) :- node(n9,supported).
node(n1494,unknown) :- \+ node(n1494,supported), \+ node(n1494,refuted).
verdict(c_080be742b80386c4,supported) :- node(n1494,supported).
query(verdict(c_080be742b80386c4,supported)).
verdict(c_080be742b80386c4,refuted) :- node(n1494,refuted).
query(verdict(c_080be742b80386c4,refuted)).
verdict(c_080be742b80386c4,unknown) :- node(n1494,unknown).
query(verdict(c_080be742b80386c4,unknown)).
node(n1502,supported) :- status(o_83ba879525ebe62f7a7c,supported).
node(n1502,refuted) :- status(o_83ba879525ebe62f7a7c,refuted).
node(n1502,unknown) :- status(o_83ba879525ebe62f7a7c,unknown).
node(n1503,supported) :- status(o_7bea8e26deec4b36c459,supported).
node(n1503,refuted) :- status(o_7bea8e26deec4b36c459,refuted).
node(n1503,unknown) :- status(o_7bea8e26deec4b36c459,unknown).
node(n1504,supported) :- status(o_6f61965829a9667777de,supported).
node(n1504,refuted) :- status(o_6f61965829a9667777de,refuted).
node(n1504,unknown) :- status(o_6f61965829a9667777de,unknown).
node(n1505,supported) :- status(o_75291eec3196fa4db1c1,supported).
node(n1505,refuted) :- status(o_75291eec3196fa4db1c1,refuted).
node(n1505,unknown) :- status(o_75291eec3196fa4db1c1,unknown).
node(n1501,supported) :- node(n1502,supported), node(n1503,supported), node(n1504,supported), node(n1505,supported).
node(n1501,refuted) :- node(n1502,refuted).
node(n1501,refuted) :- node(n1503,refuted).
node(n1501,refuted) :- node(n1504,refuted).
node(n1501,refuted) :- node(n1505,refuted).
node(n1501,unknown) :- \+ node(n1501,supported), \+ node(n1501,refuted).
node(n1500,refuted) :- node(n1501,refuted), node(n9,refuted).
node(n1500,supported) :- node(n1501,supported).
node(n1500,supported) :- node(n9,supported).
node(n1500,unknown) :- \+ node(n1500,supported), \+ node(n1500,refuted).
verdict(c_dbeeb7abde02af00,supported) :- node(n1500,supported).
query(verdict(c_dbeeb7abde02af00,supported)).
verdict(c_dbeeb7abde02af00,refuted) :- node(n1500,refuted).
query(verdict(c_dbeeb7abde02af00,refuted)).
verdict(c_dbeeb7abde02af00,unknown) :- node(n1500,unknown).
query(verdict(c_dbeeb7abde02af00,unknown)).
node(n1508,supported) :- status(o_29679e9a353ec2751421,supported).
node(n1508,refuted) :- status(o_29679e9a353ec2751421,refuted).
node(n1508,unknown) :- status(o_29679e9a353ec2751421,unknown).
node(n1509,supported) :- status(o_b47e3edafb3d4f0c29de,supported).
node(n1509,refuted) :- status(o_b47e3edafb3d4f0c29de,refuted).
node(n1509,unknown) :- status(o_b47e3edafb3d4f0c29de,unknown).
node(n1510,supported) :- status(o_47e0163c92f9d9af95b6,supported).
node(n1510,refuted) :- status(o_47e0163c92f9d9af95b6,refuted).
node(n1510,unknown) :- status(o_47e0163c92f9d9af95b6,unknown).
node(n1507,supported) :- node(n1508,supported), node(n1509,supported), node(n1510,supported).
node(n1507,refuted) :- node(n1508,refuted).
node(n1507,refuted) :- node(n1509,refuted).
node(n1507,refuted) :- node(n1510,refuted).
node(n1507,unknown) :- \+ node(n1507,supported), \+ node(n1507,refuted).
node(n1512,supported) :- status(o_1e945f32d6b761c7acc9,supported).
node(n1512,refuted) :- status(o_1e945f32d6b761c7acc9,refuted).
node(n1512,unknown) :- status(o_1e945f32d6b761c7acc9,unknown).
node(n1513,supported) :- status(o_da519866cb1c60a54815,supported).
node(n1513,refuted) :- status(o_da519866cb1c60a54815,refuted).
node(n1513,unknown) :- status(o_da519866cb1c60a54815,unknown).
node(n1514,supported) :- status(o_bdf03b5c0638bb84d5a2,supported).
node(n1514,refuted) :- status(o_bdf03b5c0638bb84d5a2,refuted).
node(n1514,unknown) :- status(o_bdf03b5c0638bb84d5a2,unknown).
node(n1511,supported) :- node(n1512,supported), node(n1513,supported), node(n1514,supported).
node(n1511,refuted) :- node(n1512,refuted).
node(n1511,refuted) :- node(n1513,refuted).
node(n1511,refuted) :- node(n1514,refuted).
node(n1511,unknown) :- \+ node(n1511,supported), \+ node(n1511,refuted).
node(n1506,refuted) :- node(n1507,refuted), node(n1511,refuted), node(n9,refuted).
node(n1506,supported) :- node(n1507,supported).
node(n1506,supported) :- node(n1511,supported).
node(n1506,supported) :- node(n9,supported).
node(n1506,unknown) :- \+ node(n1506,supported), \+ node(n1506,refuted).
verdict(c_fd65913998fb501d,supported) :- node(n1506,supported).
query(verdict(c_fd65913998fb501d,supported)).
verdict(c_fd65913998fb501d,refuted) :- node(n1506,refuted).
query(verdict(c_fd65913998fb501d,refuted)).
verdict(c_fd65913998fb501d,unknown) :- node(n1506,unknown).
query(verdict(c_fd65913998fb501d,unknown)).
node(n1517,supported) :- status(o_a8f3cdfb2b4a0501a6eb,supported).
node(n1517,refuted) :- status(o_a8f3cdfb2b4a0501a6eb,refuted).
node(n1517,unknown) :- status(o_a8f3cdfb2b4a0501a6eb,unknown).
node(n1518,supported) :- status(o_d559a78cd9a76269c3c8,supported).
node(n1518,refuted) :- status(o_d559a78cd9a76269c3c8,refuted).
node(n1518,unknown) :- status(o_d559a78cd9a76269c3c8,unknown).
node(n1519,supported) :- status(o_4cf18a5cd3a678b16eb8,supported).
node(n1519,refuted) :- status(o_4cf18a5cd3a678b16eb8,refuted).
node(n1519,unknown) :- status(o_4cf18a5cd3a678b16eb8,unknown).
node(n1520,supported) :- status(o_35ef4484df9ca4d2274d,supported).
node(n1520,refuted) :- status(o_35ef4484df9ca4d2274d,refuted).
node(n1520,unknown) :- status(o_35ef4484df9ca4d2274d,unknown).
node(n1516,supported) :- node(n1517,supported), node(n1518,supported), node(n1519,supported), node(n1520,supported).
node(n1516,refuted) :- node(n1517,refuted).
node(n1516,refuted) :- node(n1518,refuted).
node(n1516,refuted) :- node(n1519,refuted).
node(n1516,refuted) :- node(n1520,refuted).
node(n1516,unknown) :- \+ node(n1516,supported), \+ node(n1516,refuted).
node(n1522,supported) :- status(o_1224741dccf4df4fc0dd,supported).
node(n1522,refuted) :- status(o_1224741dccf4df4fc0dd,refuted).
node(n1522,unknown) :- status(o_1224741dccf4df4fc0dd,unknown).
node(n1523,supported) :- status(o_cf34ec0f2ad55fd34d42,supported).
node(n1523,refuted) :- status(o_cf34ec0f2ad55fd34d42,refuted).
node(n1523,unknown) :- status(o_cf34ec0f2ad55fd34d42,unknown).
node(n1524,supported) :- status(o_d3ccd8b2b7fbcc59448a,supported).
node(n1524,refuted) :- status(o_d3ccd8b2b7fbcc59448a,refuted).
node(n1524,unknown) :- status(o_d3ccd8b2b7fbcc59448a,unknown).
node(n1525,supported) :- status(o_3e01a6f18f5e5edaac0b,supported).
node(n1525,refuted) :- status(o_3e01a6f18f5e5edaac0b,refuted).
node(n1525,unknown) :- status(o_3e01a6f18f5e5edaac0b,unknown).
node(n1521,supported) :- node(n1522,supported), node(n1523,supported), node(n1524,supported), node(n1525,supported).
node(n1521,refuted) :- node(n1522,refuted).
node(n1521,refuted) :- node(n1523,refuted).
node(n1521,refuted) :- node(n1524,refuted).
node(n1521,refuted) :- node(n1525,refuted).
node(n1521,unknown) :- \+ node(n1521,supported), \+ node(n1521,refuted).
node(n1515,refuted) :- node(n1516,refuted), node(n1521,refuted), node(n9,refuted).
node(n1515,supported) :- node(n1516,supported).
node(n1515,supported) :- node(n1521,supported).
node(n1515,supported) :- node(n9,supported).
node(n1515,unknown) :- \+ node(n1515,supported), \+ node(n1515,refuted).
verdict(c_963a5d22ac28ea5e,supported) :- node(n1515,supported).
query(verdict(c_963a5d22ac28ea5e,supported)).
verdict(c_963a5d22ac28ea5e,refuted) :- node(n1515,refuted).
query(verdict(c_963a5d22ac28ea5e,refuted)).
verdict(c_963a5d22ac28ea5e,unknown) :- node(n1515,unknown).
query(verdict(c_963a5d22ac28ea5e,unknown)).
node(n1528,supported) :- status(o_1ae70ed557b31fd76040,supported).
node(n1528,refuted) :- status(o_1ae70ed557b31fd76040,refuted).
node(n1528,unknown) :- status(o_1ae70ed557b31fd76040,unknown).
node(n1529,supported) :- status(o_1e4b920985a85de66dc4,supported).
node(n1529,refuted) :- status(o_1e4b920985a85de66dc4,refuted).
node(n1529,unknown) :- status(o_1e4b920985a85de66dc4,unknown).
node(n1530,supported) :- status(o_bba7840921cde4ed5cf5,supported).
node(n1530,refuted) :- status(o_bba7840921cde4ed5cf5,refuted).
node(n1530,unknown) :- status(o_bba7840921cde4ed5cf5,unknown).
node(n1531,supported) :- status(o_e26d5de6bcec9f254da2,supported).
node(n1531,refuted) :- status(o_e26d5de6bcec9f254da2,refuted).
node(n1531,unknown) :- status(o_e26d5de6bcec9f254da2,unknown).
node(n1527,supported) :- node(n1528,supported), node(n1529,supported), node(n1530,supported), node(n1531,supported).
node(n1527,refuted) :- node(n1528,refuted).
node(n1527,refuted) :- node(n1529,refuted).
node(n1527,refuted) :- node(n1530,refuted).
node(n1527,refuted) :- node(n1531,refuted).
node(n1527,unknown) :- \+ node(n1527,supported), \+ node(n1527,refuted).
node(n1533,supported) :- status(o_352c664881c4b3221822,supported).
node(n1533,refuted) :- status(o_352c664881c4b3221822,refuted).
node(n1533,unknown) :- status(o_352c664881c4b3221822,unknown).
node(n1534,supported) :- status(o_646e6906b144f9ea616a,supported).
node(n1534,refuted) :- status(o_646e6906b144f9ea616a,refuted).
node(n1534,unknown) :- status(o_646e6906b144f9ea616a,unknown).
node(n1535,supported) :- status(o_7f5068cc07034ce53972,supported).
node(n1535,refuted) :- status(o_7f5068cc07034ce53972,refuted).
node(n1535,unknown) :- status(o_7f5068cc07034ce53972,unknown).
node(n1536,supported) :- status(o_dfd8f6bf8fe912583eb1,supported).
node(n1536,refuted) :- status(o_dfd8f6bf8fe912583eb1,refuted).
node(n1536,unknown) :- status(o_dfd8f6bf8fe912583eb1,unknown).
node(n1532,supported) :- node(n1533,supported), node(n1534,supported), node(n1535,supported), node(n1536,supported).
node(n1532,refuted) :- node(n1533,refuted).
node(n1532,refuted) :- node(n1534,refuted).
node(n1532,refuted) :- node(n1535,refuted).
node(n1532,refuted) :- node(n1536,refuted).
node(n1532,unknown) :- \+ node(n1532,supported), \+ node(n1532,refuted).
node(n1526,refuted) :- node(n1527,refuted), node(n1532,refuted), node(n9,refuted).
node(n1526,supported) :- node(n1527,supported).
node(n1526,supported) :- node(n1532,supported).
node(n1526,supported) :- node(n9,supported).
node(n1526,unknown) :- \+ node(n1526,supported), \+ node(n1526,refuted).
verdict(c_17a207c3cfe35659,supported) :- node(n1526,supported).
query(verdict(c_17a207c3cfe35659,supported)).
verdict(c_17a207c3cfe35659,refuted) :- node(n1526,refuted).
query(verdict(c_17a207c3cfe35659,refuted)).
verdict(c_17a207c3cfe35659,unknown) :- node(n1526,unknown).
query(verdict(c_17a207c3cfe35659,unknown)).
node(n1539,supported) :- status(o_bc4a52f0398ccfe67c0e,supported).
node(n1539,refuted) :- status(o_bc4a52f0398ccfe67c0e,refuted).
node(n1539,unknown) :- status(o_bc4a52f0398ccfe67c0e,unknown).
node(n1540,supported) :- status(o_876c693751b04872860e,supported).
node(n1540,refuted) :- status(o_876c693751b04872860e,refuted).
node(n1540,unknown) :- status(o_876c693751b04872860e,unknown).
node(n1541,supported) :- status(o_d8973fe006c2fd358813,supported).
node(n1541,refuted) :- status(o_d8973fe006c2fd358813,refuted).
node(n1541,unknown) :- status(o_d8973fe006c2fd358813,unknown).
node(n1542,supported) :- status(o_9861ae06cef22b234378,supported).
node(n1542,refuted) :- status(o_9861ae06cef22b234378,refuted).
node(n1542,unknown) :- status(o_9861ae06cef22b234378,unknown).
node(n1538,supported) :- node(n1539,supported), node(n1540,supported), node(n1541,supported), node(n1542,supported).
node(n1538,refuted) :- node(n1539,refuted).
node(n1538,refuted) :- node(n1540,refuted).
node(n1538,refuted) :- node(n1541,refuted).
node(n1538,refuted) :- node(n1542,refuted).
node(n1538,unknown) :- \+ node(n1538,supported), \+ node(n1538,refuted).
node(n1544,supported) :- status(o_052f6eec21cba5fac7b3,supported).
node(n1544,refuted) :- status(o_052f6eec21cba5fac7b3,refuted).
node(n1544,unknown) :- status(o_052f6eec21cba5fac7b3,unknown).
node(n1545,supported) :- status(o_64fa6ff1e96d1458920f,supported).
node(n1545,refuted) :- status(o_64fa6ff1e96d1458920f,refuted).
node(n1545,unknown) :- status(o_64fa6ff1e96d1458920f,unknown).
node(n1546,supported) :- status(o_239e69f63afaf0e3db63,supported).
node(n1546,refuted) :- status(o_239e69f63afaf0e3db63,refuted).
node(n1546,unknown) :- status(o_239e69f63afaf0e3db63,unknown).
node(n1547,supported) :- status(o_2f37bf0fbb432d94a4ee,supported).
node(n1547,refuted) :- status(o_2f37bf0fbb432d94a4ee,refuted).
node(n1547,unknown) :- status(o_2f37bf0fbb432d94a4ee,unknown).
node(n1543,supported) :- node(n1544,supported), node(n1545,supported), node(n1546,supported), node(n1547,supported).
node(n1543,refuted) :- node(n1544,refuted).
node(n1543,refuted) :- node(n1545,refuted).
node(n1543,refuted) :- node(n1546,refuted).
node(n1543,refuted) :- node(n1547,refuted).
node(n1543,unknown) :- \+ node(n1543,supported), \+ node(n1543,refuted).
node(n1537,refuted) :- node(n1538,refuted), node(n1543,refuted), node(n9,refuted).
node(n1537,supported) :- node(n1538,supported).
node(n1537,supported) :- node(n1543,supported).
node(n1537,supported) :- node(n9,supported).
node(n1537,unknown) :- \+ node(n1537,supported), \+ node(n1537,refuted).
verdict(c_badace33ee8ad774,supported) :- node(n1537,supported).
query(verdict(c_badace33ee8ad774,supported)).
verdict(c_badace33ee8ad774,refuted) :- node(n1537,refuted).
query(verdict(c_badace33ee8ad774,refuted)).
verdict(c_badace33ee8ad774,unknown) :- node(n1537,unknown).
query(verdict(c_badace33ee8ad774,unknown)).
node(n1550,supported) :- status(o_753c75f6072cd83064a5,supported).
node(n1550,refuted) :- status(o_753c75f6072cd83064a5,refuted).
node(n1550,unknown) :- status(o_753c75f6072cd83064a5,unknown).
node(n1551,supported) :- status(o_0ef8926f1071064c5e2b,supported).
node(n1551,refuted) :- status(o_0ef8926f1071064c5e2b,refuted).
node(n1551,unknown) :- status(o_0ef8926f1071064c5e2b,unknown).
node(n1552,supported) :- status(o_f2345f54d8791dcdad77,supported).
node(n1552,refuted) :- status(o_f2345f54d8791dcdad77,refuted).
node(n1552,unknown) :- status(o_f2345f54d8791dcdad77,unknown).
node(n1549,supported) :- node(n1550,supported), node(n1551,supported), node(n1552,supported).
node(n1549,refuted) :- node(n1550,refuted).
node(n1549,refuted) :- node(n1551,refuted).
node(n1549,refuted) :- node(n1552,refuted).
node(n1549,unknown) :- \+ node(n1549,supported), \+ node(n1549,refuted).
node(n1548,refuted) :- node(n1549,refuted), node(n9,refuted).
node(n1548,supported) :- node(n1549,supported).
node(n1548,supported) :- node(n9,supported).
node(n1548,unknown) :- \+ node(n1548,supported), \+ node(n1548,refuted).
verdict(c_4444dfc11772e53b,supported) :- node(n1548,supported).
query(verdict(c_4444dfc11772e53b,supported)).
verdict(c_4444dfc11772e53b,refuted) :- node(n1548,refuted).
query(verdict(c_4444dfc11772e53b,refuted)).
verdict(c_4444dfc11772e53b,unknown) :- node(n1548,unknown).
query(verdict(c_4444dfc11772e53b,unknown)).
node(n1555,supported) :- status(o_99ff1c47e1ca2b5812bc,supported).
node(n1555,refuted) :- status(o_99ff1c47e1ca2b5812bc,refuted).
node(n1555,unknown) :- status(o_99ff1c47e1ca2b5812bc,unknown).
node(n1556,supported) :- status(o_85b42e9a172552eb6a8b,supported).
node(n1556,refuted) :- status(o_85b42e9a172552eb6a8b,refuted).
node(n1556,unknown) :- status(o_85b42e9a172552eb6a8b,unknown).
node(n1557,supported) :- status(o_5ab6bb3d30ef057d6d27,supported).
node(n1557,refuted) :- status(o_5ab6bb3d30ef057d6d27,refuted).
node(n1557,unknown) :- status(o_5ab6bb3d30ef057d6d27,unknown).
node(n1558,supported) :- status(o_9c5a86fe03fc4efb7e24,supported).
node(n1558,refuted) :- status(o_9c5a86fe03fc4efb7e24,refuted).
node(n1558,unknown) :- status(o_9c5a86fe03fc4efb7e24,unknown).
node(n1554,supported) :- node(n1555,supported), node(n1556,supported), node(n1557,supported), node(n1558,supported).
node(n1554,refuted) :- node(n1555,refuted).
node(n1554,refuted) :- node(n1556,refuted).
node(n1554,refuted) :- node(n1557,refuted).
node(n1554,refuted) :- node(n1558,refuted).
node(n1554,unknown) :- \+ node(n1554,supported), \+ node(n1554,refuted).
node(n1553,refuted) :- node(n1554,refuted), node(n9,refuted).
node(n1553,supported) :- node(n1554,supported).
node(n1553,supported) :- node(n9,supported).
node(n1553,unknown) :- \+ node(n1553,supported), \+ node(n1553,refuted).
verdict(c_20e2af00b67d612e,supported) :- node(n1553,supported).
query(verdict(c_20e2af00b67d612e,supported)).
verdict(c_20e2af00b67d612e,refuted) :- node(n1553,refuted).
query(verdict(c_20e2af00b67d612e,refuted)).
verdict(c_20e2af00b67d612e,unknown) :- node(n1553,unknown).
query(verdict(c_20e2af00b67d612e,unknown)).
node(n1561,supported) :- status(o_f36f01403ef85188afcd,supported).
node(n1561,refuted) :- status(o_f36f01403ef85188afcd,refuted).
node(n1561,unknown) :- status(o_f36f01403ef85188afcd,unknown).
node(n1562,supported) :- status(o_d4cbd03a461d5a4f56a5,supported).
node(n1562,refuted) :- status(o_d4cbd03a461d5a4f56a5,refuted).
node(n1562,unknown) :- status(o_d4cbd03a461d5a4f56a5,unknown).
node(n1563,supported) :- status(o_ac6dff7b5be32257e072,supported).
node(n1563,refuted) :- status(o_ac6dff7b5be32257e072,refuted).
node(n1563,unknown) :- status(o_ac6dff7b5be32257e072,unknown).
node(n1564,supported) :- status(o_253da40d97157a06620e,supported).
node(n1564,refuted) :- status(o_253da40d97157a06620e,refuted).
node(n1564,unknown) :- status(o_253da40d97157a06620e,unknown).
node(n1560,supported) :- node(n1561,supported), node(n1562,supported), node(n1563,supported), node(n1564,supported).
node(n1560,refuted) :- node(n1561,refuted).
node(n1560,refuted) :- node(n1562,refuted).
node(n1560,refuted) :- node(n1563,refuted).
node(n1560,refuted) :- node(n1564,refuted).
node(n1560,unknown) :- \+ node(n1560,supported), \+ node(n1560,refuted).
node(n1559,refuted) :- node(n1560,refuted), node(n9,refuted).
node(n1559,supported) :- node(n1560,supported).
node(n1559,supported) :- node(n9,supported).
node(n1559,unknown) :- \+ node(n1559,supported), \+ node(n1559,refuted).
verdict(c_f7152edac2421484,supported) :- node(n1559,supported).
query(verdict(c_f7152edac2421484,supported)).
verdict(c_f7152edac2421484,refuted) :- node(n1559,refuted).
query(verdict(c_f7152edac2421484,refuted)).
verdict(c_f7152edac2421484,unknown) :- node(n1559,unknown).
query(verdict(c_f7152edac2421484,unknown)).
node(n1567,supported) :- status(o_0c5a452ab1ce4be48585,supported).
node(n1567,refuted) :- status(o_0c5a452ab1ce4be48585,refuted).
node(n1567,unknown) :- status(o_0c5a452ab1ce4be48585,unknown).
node(n1568,supported) :- status(o_9eb7fa37ac31842fb854,supported).
node(n1568,refuted) :- status(o_9eb7fa37ac31842fb854,refuted).
node(n1568,unknown) :- status(o_9eb7fa37ac31842fb854,unknown).
node(n1569,supported) :- status(o_b53cb4ba50efdc299010,supported).
node(n1569,refuted) :- status(o_b53cb4ba50efdc299010,refuted).
node(n1569,unknown) :- status(o_b53cb4ba50efdc299010,unknown).
node(n1570,supported) :- status(o_b7b5d85d4ebe728c13f5,supported).
node(n1570,refuted) :- status(o_b7b5d85d4ebe728c13f5,refuted).
node(n1570,unknown) :- status(o_b7b5d85d4ebe728c13f5,unknown).
node(n1566,supported) :- node(n1567,supported), node(n1568,supported), node(n1569,supported), node(n1570,supported).
node(n1566,refuted) :- node(n1567,refuted).
node(n1566,refuted) :- node(n1568,refuted).
node(n1566,refuted) :- node(n1569,refuted).
node(n1566,refuted) :- node(n1570,refuted).
node(n1566,unknown) :- \+ node(n1566,supported), \+ node(n1566,refuted).
node(n1565,refuted) :- node(n1566,refuted), node(n9,refuted).
node(n1565,supported) :- node(n1566,supported).
node(n1565,supported) :- node(n9,supported).
node(n1565,unknown) :- \+ node(n1565,supported), \+ node(n1565,refuted).
verdict(c_5a413edde57d3ba4,supported) :- node(n1565,supported).
query(verdict(c_5a413edde57d3ba4,supported)).
verdict(c_5a413edde57d3ba4,refuted) :- node(n1565,refuted).
query(verdict(c_5a413edde57d3ba4,refuted)).
verdict(c_5a413edde57d3ba4,unknown) :- node(n1565,unknown).
query(verdict(c_5a413edde57d3ba4,unknown)).
node(n1573,supported) :- status(o_055e122bc274eb1317e4,supported).
node(n1573,refuted) :- status(o_055e122bc274eb1317e4,refuted).
node(n1573,unknown) :- status(o_055e122bc274eb1317e4,unknown).
node(n1574,supported) :- status(o_ed3c7ef8383df4a317f2,supported).
node(n1574,refuted) :- status(o_ed3c7ef8383df4a317f2,refuted).
node(n1574,unknown) :- status(o_ed3c7ef8383df4a317f2,unknown).
node(n1575,supported) :- status(o_cd573afdba4e02fae6e0,supported).
node(n1575,refuted) :- status(o_cd573afdba4e02fae6e0,refuted).
node(n1575,unknown) :- status(o_cd573afdba4e02fae6e0,unknown).
node(n1572,supported) :- node(n1573,supported), node(n1574,supported), node(n1575,supported).
node(n1572,refuted) :- node(n1573,refuted).
node(n1572,refuted) :- node(n1574,refuted).
node(n1572,refuted) :- node(n1575,refuted).
node(n1572,unknown) :- \+ node(n1572,supported), \+ node(n1572,refuted).
node(n1577,supported) :- status(o_edb7c6e9f6d749181047,supported).
node(n1577,refuted) :- status(o_edb7c6e9f6d749181047,refuted).
node(n1577,unknown) :- status(o_edb7c6e9f6d749181047,unknown).
node(n1578,supported) :- status(o_0ee395ddf83ac9b9f901,supported).
node(n1578,refuted) :- status(o_0ee395ddf83ac9b9f901,refuted).
node(n1578,unknown) :- status(o_0ee395ddf83ac9b9f901,unknown).
node(n1579,supported) :- status(o_614d3a3ac5f5ea694117,supported).
node(n1579,refuted) :- status(o_614d3a3ac5f5ea694117,refuted).
node(n1579,unknown) :- status(o_614d3a3ac5f5ea694117,unknown).
node(n1576,supported) :- node(n1577,supported), node(n1578,supported), node(n1579,supported).
node(n1576,refuted) :- node(n1577,refuted).
node(n1576,refuted) :- node(n1578,refuted).
node(n1576,refuted) :- node(n1579,refuted).
node(n1576,unknown) :- \+ node(n1576,supported), \+ node(n1576,refuted).
node(n1571,refuted) :- node(n1572,refuted), node(n1576,refuted), node(n9,refuted).
node(n1571,supported) :- node(n1572,supported).
node(n1571,supported) :- node(n1576,supported).
node(n1571,supported) :- node(n9,supported).
node(n1571,unknown) :- \+ node(n1571,supported), \+ node(n1571,refuted).
verdict(c_411dddc2efd5a643,supported) :- node(n1571,supported).
query(verdict(c_411dddc2efd5a643,supported)).
verdict(c_411dddc2efd5a643,refuted) :- node(n1571,refuted).
query(verdict(c_411dddc2efd5a643,refuted)).
verdict(c_411dddc2efd5a643,unknown) :- node(n1571,unknown).
query(verdict(c_411dddc2efd5a643,unknown)).
node(n1582,supported) :- status(o_f5c891b41d8568660adc,supported).
node(n1582,refuted) :- status(o_f5c891b41d8568660adc,refuted).
node(n1582,unknown) :- status(o_f5c891b41d8568660adc,unknown).
node(n1583,supported) :- status(o_d5a5640ffb152cae68c0,supported).
node(n1583,refuted) :- status(o_d5a5640ffb152cae68c0,refuted).
node(n1583,unknown) :- status(o_d5a5640ffb152cae68c0,unknown).
node(n1584,supported) :- status(o_4fb64114ee390cffc479,supported).
node(n1584,refuted) :- status(o_4fb64114ee390cffc479,refuted).
node(n1584,unknown) :- status(o_4fb64114ee390cffc479,unknown).
node(n1585,supported) :- status(o_aae5f133f63271ada841,supported).
node(n1585,refuted) :- status(o_aae5f133f63271ada841,refuted).
node(n1585,unknown) :- status(o_aae5f133f63271ada841,unknown).
node(n1581,supported) :- node(n1582,supported), node(n1583,supported), node(n1584,supported), node(n1585,supported).
node(n1581,refuted) :- node(n1582,refuted).
node(n1581,refuted) :- node(n1583,refuted).
node(n1581,refuted) :- node(n1584,refuted).
node(n1581,refuted) :- node(n1585,refuted).
node(n1581,unknown) :- \+ node(n1581,supported), \+ node(n1581,refuted).
node(n1587,supported) :- status(o_aac77d26c05752344272,supported).
node(n1587,refuted) :- status(o_aac77d26c05752344272,refuted).
node(n1587,unknown) :- status(o_aac77d26c05752344272,unknown).
node(n1588,supported) :- status(o_5d4723ed329abc964615,supported).
node(n1588,refuted) :- status(o_5d4723ed329abc964615,refuted).
node(n1588,unknown) :- status(o_5d4723ed329abc964615,unknown).
node(n1589,supported) :- status(o_8a176bec2fab30e5db7c,supported).
node(n1589,refuted) :- status(o_8a176bec2fab30e5db7c,refuted).
node(n1589,unknown) :- status(o_8a176bec2fab30e5db7c,unknown).
node(n1590,supported) :- status(o_640d4c3e579ac8985a2c,supported).
node(n1590,refuted) :- status(o_640d4c3e579ac8985a2c,refuted).
node(n1590,unknown) :- status(o_640d4c3e579ac8985a2c,unknown).
node(n1586,supported) :- node(n1587,supported), node(n1588,supported), node(n1589,supported), node(n1590,supported).
node(n1586,refuted) :- node(n1587,refuted).
node(n1586,refuted) :- node(n1588,refuted).
node(n1586,refuted) :- node(n1589,refuted).
node(n1586,refuted) :- node(n1590,refuted).
node(n1586,unknown) :- \+ node(n1586,supported), \+ node(n1586,refuted).
node(n1580,refuted) :- node(n1581,refuted), node(n1586,refuted), node(n9,refuted).
node(n1580,supported) :- node(n1581,supported).
node(n1580,supported) :- node(n1586,supported).
node(n1580,supported) :- node(n9,supported).
node(n1580,unknown) :- \+ node(n1580,supported), \+ node(n1580,refuted).
verdict(c_6bd395fbce7e9857,supported) :- node(n1580,supported).
query(verdict(c_6bd395fbce7e9857,supported)).
verdict(c_6bd395fbce7e9857,refuted) :- node(n1580,refuted).
query(verdict(c_6bd395fbce7e9857,refuted)).
verdict(c_6bd395fbce7e9857,unknown) :- node(n1580,unknown).
query(verdict(c_6bd395fbce7e9857,unknown)).
node(n1593,supported) :- status(o_5543b48f93b41c665066,supported).
node(n1593,refuted) :- status(o_5543b48f93b41c665066,refuted).
node(n1593,unknown) :- status(o_5543b48f93b41c665066,unknown).
node(n1594,supported) :- status(o_a6b32541d3280bedcd62,supported).
node(n1594,refuted) :- status(o_a6b32541d3280bedcd62,refuted).
node(n1594,unknown) :- status(o_a6b32541d3280bedcd62,unknown).
node(n1595,supported) :- status(o_d87baee3f3f4b211234b,supported).
node(n1595,refuted) :- status(o_d87baee3f3f4b211234b,refuted).
node(n1595,unknown) :- status(o_d87baee3f3f4b211234b,unknown).
node(n1596,supported) :- status(o_21043c93e62d1b9e278b,supported).
node(n1596,refuted) :- status(o_21043c93e62d1b9e278b,refuted).
node(n1596,unknown) :- status(o_21043c93e62d1b9e278b,unknown).
node(n1592,supported) :- node(n1593,supported), node(n1594,supported), node(n1595,supported), node(n1596,supported).
node(n1592,refuted) :- node(n1593,refuted).
node(n1592,refuted) :- node(n1594,refuted).
node(n1592,refuted) :- node(n1595,refuted).
node(n1592,refuted) :- node(n1596,refuted).
node(n1592,unknown) :- \+ node(n1592,supported), \+ node(n1592,refuted).
node(n1598,supported) :- status(o_d4b61e9af99e88b16127,supported).
node(n1598,refuted) :- status(o_d4b61e9af99e88b16127,refuted).
node(n1598,unknown) :- status(o_d4b61e9af99e88b16127,unknown).
node(n1599,supported) :- status(o_92c4f7bce0a3c6cbd00a,supported).
node(n1599,refuted) :- status(o_92c4f7bce0a3c6cbd00a,refuted).
node(n1599,unknown) :- status(o_92c4f7bce0a3c6cbd00a,unknown).
node(n1600,supported) :- status(o_3270f00b704af3711907,supported).
node(n1600,refuted) :- status(o_3270f00b704af3711907,refuted).
node(n1600,unknown) :- status(o_3270f00b704af3711907,unknown).
node(n1601,supported) :- status(o_31c4bdbedf8bce6bf47b,supported).
node(n1601,refuted) :- status(o_31c4bdbedf8bce6bf47b,refuted).
node(n1601,unknown) :- status(o_31c4bdbedf8bce6bf47b,unknown).
node(n1597,supported) :- node(n1598,supported), node(n1599,supported), node(n1600,supported), node(n1601,supported).
node(n1597,refuted) :- node(n1598,refuted).
node(n1597,refuted) :- node(n1599,refuted).
node(n1597,refuted) :- node(n1600,refuted).
node(n1597,refuted) :- node(n1601,refuted).
node(n1597,unknown) :- \+ node(n1597,supported), \+ node(n1597,refuted).
node(n1591,refuted) :- node(n1592,refuted), node(n1597,refuted), node(n9,refuted).
node(n1591,supported) :- node(n1592,supported).
node(n1591,supported) :- node(n1597,supported).
node(n1591,supported) :- node(n9,supported).
node(n1591,unknown) :- \+ node(n1591,supported), \+ node(n1591,refuted).
verdict(c_ddbcea7780af2da0,supported) :- node(n1591,supported).
query(verdict(c_ddbcea7780af2da0,supported)).
verdict(c_ddbcea7780af2da0,refuted) :- node(n1591,refuted).
query(verdict(c_ddbcea7780af2da0,refuted)).
verdict(c_ddbcea7780af2da0,unknown) :- node(n1591,unknown).
query(verdict(c_ddbcea7780af2da0,unknown)).
node(n1604,supported) :- status(o_4463ce10bc8db87c448d,supported).
node(n1604,refuted) :- status(o_4463ce10bc8db87c448d,refuted).
node(n1604,unknown) :- status(o_4463ce10bc8db87c448d,unknown).
node(n1605,supported) :- status(o_49b7b3906b0bc487e9c7,supported).
node(n1605,refuted) :- status(o_49b7b3906b0bc487e9c7,refuted).
node(n1605,unknown) :- status(o_49b7b3906b0bc487e9c7,unknown).
node(n1606,supported) :- status(o_7b507422892e7e993156,supported).
node(n1606,refuted) :- status(o_7b507422892e7e993156,refuted).
node(n1606,unknown) :- status(o_7b507422892e7e993156,unknown).
node(n1607,supported) :- status(o_35c3fff1897937b5f4e1,supported).
node(n1607,refuted) :- status(o_35c3fff1897937b5f4e1,refuted).
node(n1607,unknown) :- status(o_35c3fff1897937b5f4e1,unknown).
node(n1603,supported) :- node(n1604,supported), node(n1605,supported), node(n1606,supported), node(n1607,supported).
node(n1603,refuted) :- node(n1604,refuted).
node(n1603,refuted) :- node(n1605,refuted).
node(n1603,refuted) :- node(n1606,refuted).
node(n1603,refuted) :- node(n1607,refuted).
node(n1603,unknown) :- \+ node(n1603,supported), \+ node(n1603,refuted).
node(n1609,supported) :- status(o_d38d47c62950ba62ba0f,supported).
node(n1609,refuted) :- status(o_d38d47c62950ba62ba0f,refuted).
node(n1609,unknown) :- status(o_d38d47c62950ba62ba0f,unknown).
node(n1610,supported) :- status(o_306a85c7bf0c3b1fb134,supported).
node(n1610,refuted) :- status(o_306a85c7bf0c3b1fb134,refuted).
node(n1610,unknown) :- status(o_306a85c7bf0c3b1fb134,unknown).
node(n1611,supported) :- status(o_8d01c3acf241794c1041,supported).
node(n1611,refuted) :- status(o_8d01c3acf241794c1041,refuted).
node(n1611,unknown) :- status(o_8d01c3acf241794c1041,unknown).
node(n1612,supported) :- status(o_d1f5d53fc68f5414b81a,supported).
node(n1612,refuted) :- status(o_d1f5d53fc68f5414b81a,refuted).
node(n1612,unknown) :- status(o_d1f5d53fc68f5414b81a,unknown).
node(n1608,supported) :- node(n1609,supported), node(n1610,supported), node(n1611,supported), node(n1612,supported).
node(n1608,refuted) :- node(n1609,refuted).
node(n1608,refuted) :- node(n1610,refuted).
node(n1608,refuted) :- node(n1611,refuted).
node(n1608,refuted) :- node(n1612,refuted).
node(n1608,unknown) :- \+ node(n1608,supported), \+ node(n1608,refuted).
node(n1602,refuted) :- node(n1603,refuted), node(n1608,refuted), node(n9,refuted).
node(n1602,supported) :- node(n1603,supported).
node(n1602,supported) :- node(n1608,supported).
node(n1602,supported) :- node(n9,supported).
node(n1602,unknown) :- \+ node(n1602,supported), \+ node(n1602,refuted).
verdict(c_b74ca6ddde4c39a5,supported) :- node(n1602,supported).
query(verdict(c_b74ca6ddde4c39a5,supported)).
verdict(c_b74ca6ddde4c39a5,refuted) :- node(n1602,refuted).
query(verdict(c_b74ca6ddde4c39a5,refuted)).
verdict(c_b74ca6ddde4c39a5,unknown) :- node(n1602,unknown).
query(verdict(c_b74ca6ddde4c39a5,unknown)).
node(n1615,supported) :- status(o_998f75ee08cac164c587,supported).
node(n1615,refuted) :- status(o_998f75ee08cac164c587,refuted).
node(n1615,unknown) :- status(o_998f75ee08cac164c587,unknown).
node(n1616,supported) :- status(o_61bdaed29aab200b1e07,supported).
node(n1616,refuted) :- status(o_61bdaed29aab200b1e07,refuted).
node(n1616,unknown) :- status(o_61bdaed29aab200b1e07,unknown).
node(n1617,supported) :- status(o_96ce62cf8febb6cd537b,supported).
node(n1617,refuted) :- status(o_96ce62cf8febb6cd537b,refuted).
node(n1617,unknown) :- status(o_96ce62cf8febb6cd537b,unknown).
node(n1614,supported) :- node(n1615,supported), node(n1616,supported), node(n1617,supported).
node(n1614,refuted) :- node(n1615,refuted).
node(n1614,refuted) :- node(n1616,refuted).
node(n1614,refuted) :- node(n1617,refuted).
node(n1614,unknown) :- \+ node(n1614,supported), \+ node(n1614,refuted).
node(n1619,supported) :- status(o_a63396895046639d305d,supported).
node(n1619,refuted) :- status(o_a63396895046639d305d,refuted).
node(n1619,unknown) :- status(o_a63396895046639d305d,unknown).
node(n1620,supported) :- status(o_4d1e186ffb4ca961fe68,supported).
node(n1620,refuted) :- status(o_4d1e186ffb4ca961fe68,refuted).
node(n1620,unknown) :- status(o_4d1e186ffb4ca961fe68,unknown).
node(n1621,supported) :- status(o_3128cf40030e2666d0b6,supported).
node(n1621,refuted) :- status(o_3128cf40030e2666d0b6,refuted).
node(n1621,unknown) :- status(o_3128cf40030e2666d0b6,unknown).
node(n1618,supported) :- node(n1619,supported), node(n1620,supported), node(n1621,supported).
node(n1618,refuted) :- node(n1619,refuted).
node(n1618,refuted) :- node(n1620,refuted).
node(n1618,refuted) :- node(n1621,refuted).
node(n1618,unknown) :- \+ node(n1618,supported), \+ node(n1618,refuted).
node(n1613,refuted) :- node(n1614,refuted), node(n1618,refuted), node(n9,refuted).
node(n1613,supported) :- node(n1614,supported).
node(n1613,supported) :- node(n1618,supported).
node(n1613,supported) :- node(n9,supported).
node(n1613,unknown) :- \+ node(n1613,supported), \+ node(n1613,refuted).
verdict(c_51ab88afca83af1b,supported) :- node(n1613,supported).
query(verdict(c_51ab88afca83af1b,supported)).
verdict(c_51ab88afca83af1b,refuted) :- node(n1613,refuted).
query(verdict(c_51ab88afca83af1b,refuted)).
verdict(c_51ab88afca83af1b,unknown) :- node(n1613,unknown).
query(verdict(c_51ab88afca83af1b,unknown)).
node(n1624,supported) :- status(o_34ac3c891c24d2b4b3f2,supported).
node(n1624,refuted) :- status(o_34ac3c891c24d2b4b3f2,refuted).
node(n1624,unknown) :- status(o_34ac3c891c24d2b4b3f2,unknown).
node(n1625,supported) :- status(o_a086747c0bca31f63072,supported).
node(n1625,refuted) :- status(o_a086747c0bca31f63072,refuted).
node(n1625,unknown) :- status(o_a086747c0bca31f63072,unknown).
node(n1626,supported) :- status(o_4c943b721a042ecfdab0,supported).
node(n1626,refuted) :- status(o_4c943b721a042ecfdab0,refuted).
node(n1626,unknown) :- status(o_4c943b721a042ecfdab0,unknown).
node(n1627,supported) :- status(o_42cef371c4962d3b8ee7,supported).
node(n1627,refuted) :- status(o_42cef371c4962d3b8ee7,refuted).
node(n1627,unknown) :- status(o_42cef371c4962d3b8ee7,unknown).
node(n1623,supported) :- node(n1624,supported), node(n1625,supported), node(n1626,supported), node(n1627,supported).
node(n1623,refuted) :- node(n1624,refuted).
node(n1623,refuted) :- node(n1625,refuted).
node(n1623,refuted) :- node(n1626,refuted).
node(n1623,refuted) :- node(n1627,refuted).
node(n1623,unknown) :- \+ node(n1623,supported), \+ node(n1623,refuted).
node(n1629,supported) :- status(o_4e15353745e93cd230e9,supported).
node(n1629,refuted) :- status(o_4e15353745e93cd230e9,refuted).
node(n1629,unknown) :- status(o_4e15353745e93cd230e9,unknown).
node(n1630,supported) :- status(o_cf2bfd8e5c5b4458c88e,supported).
node(n1630,refuted) :- status(o_cf2bfd8e5c5b4458c88e,refuted).
node(n1630,unknown) :- status(o_cf2bfd8e5c5b4458c88e,unknown).
node(n1631,supported) :- status(o_770951911732ba83ee3f,supported).
node(n1631,refuted) :- status(o_770951911732ba83ee3f,refuted).
node(n1631,unknown) :- status(o_770951911732ba83ee3f,unknown).
node(n1632,supported) :- status(o_262ea7c3c423c81fd329,supported).
node(n1632,refuted) :- status(o_262ea7c3c423c81fd329,refuted).
node(n1632,unknown) :- status(o_262ea7c3c423c81fd329,unknown).
node(n1628,supported) :- node(n1629,supported), node(n1630,supported), node(n1631,supported), node(n1632,supported).
node(n1628,refuted) :- node(n1629,refuted).
node(n1628,refuted) :- node(n1630,refuted).
node(n1628,refuted) :- node(n1631,refuted).
node(n1628,refuted) :- node(n1632,refuted).
node(n1628,unknown) :- \+ node(n1628,supported), \+ node(n1628,refuted).
node(n1622,refuted) :- node(n1623,refuted), node(n1628,refuted), node(n9,refuted).
node(n1622,supported) :- node(n1623,supported).
node(n1622,supported) :- node(n1628,supported).
node(n1622,supported) :- node(n9,supported).
node(n1622,unknown) :- \+ node(n1622,supported), \+ node(n1622,refuted).
verdict(c_a9725db4ea7c3b4e,supported) :- node(n1622,supported).
query(verdict(c_a9725db4ea7c3b4e,supported)).
verdict(c_a9725db4ea7c3b4e,refuted) :- node(n1622,refuted).
query(verdict(c_a9725db4ea7c3b4e,refuted)).
verdict(c_a9725db4ea7c3b4e,unknown) :- node(n1622,unknown).
query(verdict(c_a9725db4ea7c3b4e,unknown)).
node(n1635,supported) :- status(o_a8a59d8daf7cd1d501d5,supported).
node(n1635,refuted) :- status(o_a8a59d8daf7cd1d501d5,refuted).
node(n1635,unknown) :- status(o_a8a59d8daf7cd1d501d5,unknown).
node(n1636,supported) :- status(o_2cf63e93e52f6e82c61f,supported).
node(n1636,refuted) :- status(o_2cf63e93e52f6e82c61f,refuted).
node(n1636,unknown) :- status(o_2cf63e93e52f6e82c61f,unknown).
node(n1637,supported) :- status(o_9bb58f92d89902da3fd9,supported).
node(n1637,refuted) :- status(o_9bb58f92d89902da3fd9,refuted).
node(n1637,unknown) :- status(o_9bb58f92d89902da3fd9,unknown).
node(n1638,supported) :- status(o_b6973c9b52c5e191fb7d,supported).
node(n1638,refuted) :- status(o_b6973c9b52c5e191fb7d,refuted).
node(n1638,unknown) :- status(o_b6973c9b52c5e191fb7d,unknown).
node(n1634,supported) :- node(n1635,supported), node(n1636,supported), node(n1637,supported), node(n1638,supported).
node(n1634,refuted) :- node(n1635,refuted).
node(n1634,refuted) :- node(n1636,refuted).
node(n1634,refuted) :- node(n1637,refuted).
node(n1634,refuted) :- node(n1638,refuted).
node(n1634,unknown) :- \+ node(n1634,supported), \+ node(n1634,refuted).
node(n1640,supported) :- status(o_868c1d305ce07819bf7b,supported).
node(n1640,refuted) :- status(o_868c1d305ce07819bf7b,refuted).
node(n1640,unknown) :- status(o_868c1d305ce07819bf7b,unknown).
node(n1641,supported) :- status(o_7e2fa1dcf7021591212f,supported).
node(n1641,refuted) :- status(o_7e2fa1dcf7021591212f,refuted).
node(n1641,unknown) :- status(o_7e2fa1dcf7021591212f,unknown).
node(n1642,supported) :- status(o_e6fbbe996a5ac3572aff,supported).
node(n1642,refuted) :- status(o_e6fbbe996a5ac3572aff,refuted).
node(n1642,unknown) :- status(o_e6fbbe996a5ac3572aff,unknown).
node(n1643,supported) :- status(o_2e9ecf9b054bec36530e,supported).
node(n1643,refuted) :- status(o_2e9ecf9b054bec36530e,refuted).
node(n1643,unknown) :- status(o_2e9ecf9b054bec36530e,unknown).
node(n1639,supported) :- node(n1640,supported), node(n1641,supported), node(n1642,supported), node(n1643,supported).
node(n1639,refuted) :- node(n1640,refuted).
node(n1639,refuted) :- node(n1641,refuted).
node(n1639,refuted) :- node(n1642,refuted).
node(n1639,refuted) :- node(n1643,refuted).
node(n1639,unknown) :- \+ node(n1639,supported), \+ node(n1639,refuted).
node(n1633,refuted) :- node(n1634,refuted), node(n1639,refuted), node(n9,refuted).
node(n1633,supported) :- node(n1634,supported).
node(n1633,supported) :- node(n1639,supported).
node(n1633,supported) :- node(n9,supported).
node(n1633,unknown) :- \+ node(n1633,supported), \+ node(n1633,refuted).
verdict(c_8bd7b5ab30b0d1b4,supported) :- node(n1633,supported).
query(verdict(c_8bd7b5ab30b0d1b4,supported)).
verdict(c_8bd7b5ab30b0d1b4,refuted) :- node(n1633,refuted).
query(verdict(c_8bd7b5ab30b0d1b4,refuted)).
verdict(c_8bd7b5ab30b0d1b4,unknown) :- node(n1633,unknown).
query(verdict(c_8bd7b5ab30b0d1b4,unknown)).
node(n1646,supported) :- status(o_22d43944e691a7530a58,supported).
node(n1646,refuted) :- status(o_22d43944e691a7530a58,refuted).
node(n1646,unknown) :- status(o_22d43944e691a7530a58,unknown).
node(n1647,supported) :- status(o_bbe56d8dd9cf078e6d9a,supported).
node(n1647,refuted) :- status(o_bbe56d8dd9cf078e6d9a,refuted).
node(n1647,unknown) :- status(o_bbe56d8dd9cf078e6d9a,unknown).
node(n1648,supported) :- status(o_aced07fa4d11a2a2a8c6,supported).
node(n1648,refuted) :- status(o_aced07fa4d11a2a2a8c6,refuted).
node(n1648,unknown) :- status(o_aced07fa4d11a2a2a8c6,unknown).
node(n1649,supported) :- status(o_fb839559a9ab3ce039a8,supported).
node(n1649,refuted) :- status(o_fb839559a9ab3ce039a8,refuted).
node(n1649,unknown) :- status(o_fb839559a9ab3ce039a8,unknown).
node(n1645,supported) :- node(n1646,supported), node(n1647,supported), node(n1648,supported), node(n1649,supported).
node(n1645,refuted) :- node(n1646,refuted).
node(n1645,refuted) :- node(n1647,refuted).
node(n1645,refuted) :- node(n1648,refuted).
node(n1645,refuted) :- node(n1649,refuted).
node(n1645,unknown) :- \+ node(n1645,supported), \+ node(n1645,refuted).
node(n1651,supported) :- status(o_bdaa56e3a17668d27ff0,supported).
node(n1651,refuted) :- status(o_bdaa56e3a17668d27ff0,refuted).
node(n1651,unknown) :- status(o_bdaa56e3a17668d27ff0,unknown).
node(n1652,supported) :- status(o_a8909c887b879deddb42,supported).
node(n1652,refuted) :- status(o_a8909c887b879deddb42,refuted).
node(n1652,unknown) :- status(o_a8909c887b879deddb42,unknown).
node(n1653,supported) :- status(o_5c2e28dc4cd76446cd2b,supported).
node(n1653,refuted) :- status(o_5c2e28dc4cd76446cd2b,refuted).
node(n1653,unknown) :- status(o_5c2e28dc4cd76446cd2b,unknown).
node(n1654,supported) :- status(o_fb62507e37eaa7a827a2,supported).
node(n1654,refuted) :- status(o_fb62507e37eaa7a827a2,refuted).
node(n1654,unknown) :- status(o_fb62507e37eaa7a827a2,unknown).
node(n1650,supported) :- node(n1651,supported), node(n1652,supported), node(n1653,supported), node(n1654,supported).
node(n1650,refuted) :- node(n1651,refuted).
node(n1650,refuted) :- node(n1652,refuted).
node(n1650,refuted) :- node(n1653,refuted).
node(n1650,refuted) :- node(n1654,refuted).
node(n1650,unknown) :- \+ node(n1650,supported), \+ node(n1650,refuted).
node(n1644,refuted) :- node(n1645,refuted), node(n1650,refuted), node(n9,refuted).
node(n1644,supported) :- node(n1645,supported).
node(n1644,supported) :- node(n1650,supported).
node(n1644,supported) :- node(n9,supported).
node(n1644,unknown) :- \+ node(n1644,supported), \+ node(n1644,refuted).
verdict(c_78e9af5709327cae,supported) :- node(n1644,supported).
query(verdict(c_78e9af5709327cae,supported)).
verdict(c_78e9af5709327cae,refuted) :- node(n1644,refuted).
query(verdict(c_78e9af5709327cae,refuted)).
verdict(c_78e9af5709327cae,unknown) :- node(n1644,unknown).
query(verdict(c_78e9af5709327cae,unknown)).
node(n1657,supported) :- status(o_046299b5b9dc9d6173fc,supported).
node(n1657,refuted) :- status(o_046299b5b9dc9d6173fc,refuted).
node(n1657,unknown) :- status(o_046299b5b9dc9d6173fc,unknown).
node(n1658,supported) :- status(o_969cf8b9bff80c807f3c,supported).
node(n1658,refuted) :- status(o_969cf8b9bff80c807f3c,refuted).
node(n1658,unknown) :- status(o_969cf8b9bff80c807f3c,unknown).
node(n1659,supported) :- status(o_86aaec6a802035dd76e9,supported).
node(n1659,refuted) :- status(o_86aaec6a802035dd76e9,refuted).
node(n1659,unknown) :- status(o_86aaec6a802035dd76e9,unknown).
node(n1656,supported) :- node(n1657,supported), node(n1658,supported), node(n1659,supported).
node(n1656,refuted) :- node(n1657,refuted).
node(n1656,refuted) :- node(n1658,refuted).
node(n1656,refuted) :- node(n1659,refuted).
node(n1656,unknown) :- \+ node(n1656,supported), \+ node(n1656,refuted).
node(n1661,supported) :- status(o_a69e181fe997e4a6cd46,supported).
node(n1661,refuted) :- status(o_a69e181fe997e4a6cd46,refuted).
node(n1661,unknown) :- status(o_a69e181fe997e4a6cd46,unknown).
node(n1662,supported) :- status(o_06d138357f91f3d2e7dd,supported).
node(n1662,refuted) :- status(o_06d138357f91f3d2e7dd,refuted).
node(n1662,unknown) :- status(o_06d138357f91f3d2e7dd,unknown).
node(n1663,supported) :- status(o_dc231652ba17847959d8,supported).
node(n1663,refuted) :- status(o_dc231652ba17847959d8,refuted).
node(n1663,unknown) :- status(o_dc231652ba17847959d8,unknown).
node(n1660,supported) :- node(n1661,supported), node(n1662,supported), node(n1663,supported).
node(n1660,refuted) :- node(n1661,refuted).
node(n1660,refuted) :- node(n1662,refuted).
node(n1660,refuted) :- node(n1663,refuted).
node(n1660,unknown) :- \+ node(n1660,supported), \+ node(n1660,refuted).
node(n1655,refuted) :- node(n1656,refuted), node(n1660,refuted), node(n9,refuted).
node(n1655,supported) :- node(n1656,supported).
node(n1655,supported) :- node(n1660,supported).
node(n1655,supported) :- node(n9,supported).
node(n1655,unknown) :- \+ node(n1655,supported), \+ node(n1655,refuted).
verdict(c_66d0991f1c9dc5e1,supported) :- node(n1655,supported).
query(verdict(c_66d0991f1c9dc5e1,supported)).
verdict(c_66d0991f1c9dc5e1,refuted) :- node(n1655,refuted).
query(verdict(c_66d0991f1c9dc5e1,refuted)).
verdict(c_66d0991f1c9dc5e1,unknown) :- node(n1655,unknown).
query(verdict(c_66d0991f1c9dc5e1,unknown)).
node(n1666,supported) :- status(o_829a3aa169c0dc7fb256,supported).
node(n1666,refuted) :- status(o_829a3aa169c0dc7fb256,refuted).
node(n1666,unknown) :- status(o_829a3aa169c0dc7fb256,unknown).
node(n1667,supported) :- status(o_0576e51cb53cf034be80,supported).
node(n1667,refuted) :- status(o_0576e51cb53cf034be80,refuted).
node(n1667,unknown) :- status(o_0576e51cb53cf034be80,unknown).
node(n1668,supported) :- status(o_b347f73065f2a2687f9c,supported).
node(n1668,refuted) :- status(o_b347f73065f2a2687f9c,refuted).
node(n1668,unknown) :- status(o_b347f73065f2a2687f9c,unknown).
node(n1669,supported) :- status(o_f2b6a31921f12896229f,supported).
node(n1669,refuted) :- status(o_f2b6a31921f12896229f,refuted).
node(n1669,unknown) :- status(o_f2b6a31921f12896229f,unknown).
node(n1665,supported) :- node(n1666,supported), node(n1667,supported), node(n1668,supported), node(n1669,supported).
node(n1665,refuted) :- node(n1666,refuted).
node(n1665,refuted) :- node(n1667,refuted).
node(n1665,refuted) :- node(n1668,refuted).
node(n1665,refuted) :- node(n1669,refuted).
node(n1665,unknown) :- \+ node(n1665,supported), \+ node(n1665,refuted).
node(n1671,supported) :- status(o_7f4bd77ddfcff7c6fe16,supported).
node(n1671,refuted) :- status(o_7f4bd77ddfcff7c6fe16,refuted).
node(n1671,unknown) :- status(o_7f4bd77ddfcff7c6fe16,unknown).
node(n1672,supported) :- status(o_3b38e704d7cfde274828,supported).
node(n1672,refuted) :- status(o_3b38e704d7cfde274828,refuted).
node(n1672,unknown) :- status(o_3b38e704d7cfde274828,unknown).
node(n1673,supported) :- status(o_f40c9e181ee09d46085b,supported).
node(n1673,refuted) :- status(o_f40c9e181ee09d46085b,refuted).
node(n1673,unknown) :- status(o_f40c9e181ee09d46085b,unknown).
node(n1674,supported) :- status(o_1e8c00031d3e0af749a1,supported).
node(n1674,refuted) :- status(o_1e8c00031d3e0af749a1,refuted).
node(n1674,unknown) :- status(o_1e8c00031d3e0af749a1,unknown).
node(n1670,supported) :- node(n1671,supported), node(n1672,supported), node(n1673,supported), node(n1674,supported).
node(n1670,refuted) :- node(n1671,refuted).
node(n1670,refuted) :- node(n1672,refuted).
node(n1670,refuted) :- node(n1673,refuted).
node(n1670,refuted) :- node(n1674,refuted).
node(n1670,unknown) :- \+ node(n1670,supported), \+ node(n1670,refuted).
node(n1664,refuted) :- node(n1665,refuted), node(n1670,refuted), node(n9,refuted).
node(n1664,supported) :- node(n1665,supported).
node(n1664,supported) :- node(n1670,supported).
node(n1664,supported) :- node(n9,supported).
node(n1664,unknown) :- \+ node(n1664,supported), \+ node(n1664,refuted).
verdict(c_99a9eb500448d6de,supported) :- node(n1664,supported).
query(verdict(c_99a9eb500448d6de,supported)).
verdict(c_99a9eb500448d6de,refuted) :- node(n1664,refuted).
query(verdict(c_99a9eb500448d6de,refuted)).
verdict(c_99a9eb500448d6de,unknown) :- node(n1664,unknown).
query(verdict(c_99a9eb500448d6de,unknown)).
node(n1677,supported) :- status(o_e56ed5a5002e1b38f364,supported).
node(n1677,refuted) :- status(o_e56ed5a5002e1b38f364,refuted).
node(n1677,unknown) :- status(o_e56ed5a5002e1b38f364,unknown).
node(n1678,supported) :- status(o_31f9d5cea7290e38c58a,supported).
node(n1678,refuted) :- status(o_31f9d5cea7290e38c58a,refuted).
node(n1678,unknown) :- status(o_31f9d5cea7290e38c58a,unknown).
node(n1679,supported) :- status(o_81a173ea8b53518399f3,supported).
node(n1679,refuted) :- status(o_81a173ea8b53518399f3,refuted).
node(n1679,unknown) :- status(o_81a173ea8b53518399f3,unknown).
node(n1680,supported) :- status(o_67e00e9927c65ccb062b,supported).
node(n1680,refuted) :- status(o_67e00e9927c65ccb062b,refuted).
node(n1680,unknown) :- status(o_67e00e9927c65ccb062b,unknown).
node(n1676,supported) :- node(n1677,supported), node(n1678,supported), node(n1679,supported), node(n1680,supported).
node(n1676,refuted) :- node(n1677,refuted).
node(n1676,refuted) :- node(n1678,refuted).
node(n1676,refuted) :- node(n1679,refuted).
node(n1676,refuted) :- node(n1680,refuted).
node(n1676,unknown) :- \+ node(n1676,supported), \+ node(n1676,refuted).
node(n1682,supported) :- status(o_78dcb7a3edbf856a2873,supported).
node(n1682,refuted) :- status(o_78dcb7a3edbf856a2873,refuted).
node(n1682,unknown) :- status(o_78dcb7a3edbf856a2873,unknown).
node(n1683,supported) :- status(o_f08f989014d89432acd9,supported).
node(n1683,refuted) :- status(o_f08f989014d89432acd9,refuted).
node(n1683,unknown) :- status(o_f08f989014d89432acd9,unknown).
node(n1684,supported) :- status(o_f2f00087cb3df5057797,supported).
node(n1684,refuted) :- status(o_f2f00087cb3df5057797,refuted).
node(n1684,unknown) :- status(o_f2f00087cb3df5057797,unknown).
node(n1685,supported) :- status(o_69487d3048788c389fd8,supported).
node(n1685,refuted) :- status(o_69487d3048788c389fd8,refuted).
node(n1685,unknown) :- status(o_69487d3048788c389fd8,unknown).
node(n1681,supported) :- node(n1682,supported), node(n1683,supported), node(n1684,supported), node(n1685,supported).
node(n1681,refuted) :- node(n1682,refuted).
node(n1681,refuted) :- node(n1683,refuted).
node(n1681,refuted) :- node(n1684,refuted).
node(n1681,refuted) :- node(n1685,refuted).
node(n1681,unknown) :- \+ node(n1681,supported), \+ node(n1681,refuted).
node(n1675,refuted) :- node(n1676,refuted), node(n1681,refuted), node(n9,refuted).
node(n1675,supported) :- node(n1676,supported).
node(n1675,supported) :- node(n1681,supported).
node(n1675,supported) :- node(n9,supported).
node(n1675,unknown) :- \+ node(n1675,supported), \+ node(n1675,refuted).
verdict(c_eb0a5319081c58e4,supported) :- node(n1675,supported).
query(verdict(c_eb0a5319081c58e4,supported)).
verdict(c_eb0a5319081c58e4,refuted) :- node(n1675,refuted).
query(verdict(c_eb0a5319081c58e4,refuted)).
verdict(c_eb0a5319081c58e4,unknown) :- node(n1675,unknown).
query(verdict(c_eb0a5319081c58e4,unknown)).
node(n1688,supported) :- status(o_a56a8583cafdbc06b4d3,supported).
node(n1688,refuted) :- status(o_a56a8583cafdbc06b4d3,refuted).
node(n1688,unknown) :- status(o_a56a8583cafdbc06b4d3,unknown).
node(n1689,supported) :- status(o_204725cf9d532d2ddcee,supported).
node(n1689,refuted) :- status(o_204725cf9d532d2ddcee,refuted).
node(n1689,unknown) :- status(o_204725cf9d532d2ddcee,unknown).
node(n1690,supported) :- status(o_bc27d5e1602669d5e933,supported).
node(n1690,refuted) :- status(o_bc27d5e1602669d5e933,refuted).
node(n1690,unknown) :- status(o_bc27d5e1602669d5e933,unknown).
node(n1691,supported) :- status(o_609a6b132446b56ef3c7,supported).
node(n1691,refuted) :- status(o_609a6b132446b56ef3c7,refuted).
node(n1691,unknown) :- status(o_609a6b132446b56ef3c7,unknown).
node(n1687,supported) :- node(n1688,supported), node(n1689,supported), node(n1690,supported), node(n1691,supported).
node(n1687,refuted) :- node(n1688,refuted).
node(n1687,refuted) :- node(n1689,refuted).
node(n1687,refuted) :- node(n1690,refuted).
node(n1687,refuted) :- node(n1691,refuted).
node(n1687,unknown) :- \+ node(n1687,supported), \+ node(n1687,refuted).
node(n1693,supported) :- status(o_aa4013957de23f08775d,supported).
node(n1693,refuted) :- status(o_aa4013957de23f08775d,refuted).
node(n1693,unknown) :- status(o_aa4013957de23f08775d,unknown).
node(n1694,supported) :- status(o_2dca12888dd0535bfcd2,supported).
node(n1694,refuted) :- status(o_2dca12888dd0535bfcd2,refuted).
node(n1694,unknown) :- status(o_2dca12888dd0535bfcd2,unknown).
node(n1695,supported) :- status(o_8fa48f5d98d50afef031,supported).
node(n1695,refuted) :- status(o_8fa48f5d98d50afef031,refuted).
node(n1695,unknown) :- status(o_8fa48f5d98d50afef031,unknown).
node(n1696,supported) :- status(o_843ab1dfc5fa898aae39,supported).
node(n1696,refuted) :- status(o_843ab1dfc5fa898aae39,refuted).
node(n1696,unknown) :- status(o_843ab1dfc5fa898aae39,unknown).
node(n1692,supported) :- node(n1693,supported), node(n1694,supported), node(n1695,supported), node(n1696,supported).
node(n1692,refuted) :- node(n1693,refuted).
node(n1692,refuted) :- node(n1694,refuted).
node(n1692,refuted) :- node(n1695,refuted).
node(n1692,refuted) :- node(n1696,refuted).
node(n1692,unknown) :- \+ node(n1692,supported), \+ node(n1692,refuted).
node(n1686,refuted) :- node(n1687,refuted), node(n1692,refuted), node(n9,refuted).
node(n1686,supported) :- node(n1687,supported).
node(n1686,supported) :- node(n1692,supported).
node(n1686,supported) :- node(n9,supported).
node(n1686,unknown) :- \+ node(n1686,supported), \+ node(n1686,refuted).
verdict(c_34ece5d66c5daffb,supported) :- node(n1686,supported).
query(verdict(c_34ece5d66c5daffb,supported)).
verdict(c_34ece5d66c5daffb,refuted) :- node(n1686,refuted).
query(verdict(c_34ece5d66c5daffb,refuted)).
verdict(c_34ece5d66c5daffb,unknown) :- node(n1686,unknown).
query(verdict(c_34ece5d66c5daffb,unknown)).
node(n1699,supported) :- status(o_ee035c7b7bdb3cf7252c,supported).
node(n1699,refuted) :- status(o_ee035c7b7bdb3cf7252c,refuted).
node(n1699,unknown) :- status(o_ee035c7b7bdb3cf7252c,unknown).
node(n1700,supported) :- status(o_7d18a7ab20b944a82b6e,supported).
node(n1700,refuted) :- status(o_7d18a7ab20b944a82b6e,refuted).
node(n1700,unknown) :- status(o_7d18a7ab20b944a82b6e,unknown).
node(n1701,supported) :- status(o_775aa410741fa388d325,supported).
node(n1701,refuted) :- status(o_775aa410741fa388d325,refuted).
node(n1701,unknown) :- status(o_775aa410741fa388d325,unknown).
node(n1698,supported) :- node(n1699,supported), node(n1700,supported), node(n1701,supported).
node(n1698,refuted) :- node(n1699,refuted).
node(n1698,refuted) :- node(n1700,refuted).
node(n1698,refuted) :- node(n1701,refuted).
node(n1698,unknown) :- \+ node(n1698,supported), \+ node(n1698,refuted).
node(n1703,supported) :- status(o_094b461de82acccc01fa,supported).
node(n1703,refuted) :- status(o_094b461de82acccc01fa,refuted).
node(n1703,unknown) :- status(o_094b461de82acccc01fa,unknown).
node(n1704,supported) :- status(o_45099dd24a330a357a53,supported).
node(n1704,refuted) :- status(o_45099dd24a330a357a53,refuted).
node(n1704,unknown) :- status(o_45099dd24a330a357a53,unknown).
node(n1705,supported) :- status(o_1115de17296796d6eda5,supported).
node(n1705,refuted) :- status(o_1115de17296796d6eda5,refuted).
node(n1705,unknown) :- status(o_1115de17296796d6eda5,unknown).
node(n1702,supported) :- node(n1703,supported), node(n1704,supported), node(n1705,supported).
node(n1702,refuted) :- node(n1703,refuted).
node(n1702,refuted) :- node(n1704,refuted).
node(n1702,refuted) :- node(n1705,refuted).
node(n1702,unknown) :- \+ node(n1702,supported), \+ node(n1702,refuted).
node(n1697,refuted) :- node(n1698,refuted), node(n1702,refuted), node(n9,refuted).
node(n1697,supported) :- node(n1698,supported).
node(n1697,supported) :- node(n1702,supported).
node(n1697,supported) :- node(n9,supported).
node(n1697,unknown) :- \+ node(n1697,supported), \+ node(n1697,refuted).
verdict(c_63960e8ad3a9a7f6,supported) :- node(n1697,supported).
query(verdict(c_63960e8ad3a9a7f6,supported)).
verdict(c_63960e8ad3a9a7f6,refuted) :- node(n1697,refuted).
query(verdict(c_63960e8ad3a9a7f6,refuted)).
verdict(c_63960e8ad3a9a7f6,unknown) :- node(n1697,unknown).
query(verdict(c_63960e8ad3a9a7f6,unknown)).
node(n1708,supported) :- status(o_4a67461753c49f4d9e3a,supported).
node(n1708,refuted) :- status(o_4a67461753c49f4d9e3a,refuted).
node(n1708,unknown) :- status(o_4a67461753c49f4d9e3a,unknown).
node(n1709,supported) :- status(o_3073fcc4b82dfe413b16,supported).
node(n1709,refuted) :- status(o_3073fcc4b82dfe413b16,refuted).
node(n1709,unknown) :- status(o_3073fcc4b82dfe413b16,unknown).
node(n1710,supported) :- status(o_bba2254c9c18166b0fa4,supported).
node(n1710,refuted) :- status(o_bba2254c9c18166b0fa4,refuted).
node(n1710,unknown) :- status(o_bba2254c9c18166b0fa4,unknown).
node(n1711,supported) :- status(o_039c1d10356f1e16e83b,supported).
node(n1711,refuted) :- status(o_039c1d10356f1e16e83b,refuted).
node(n1711,unknown) :- status(o_039c1d10356f1e16e83b,unknown).
node(n1707,supported) :- node(n1708,supported), node(n1709,supported), node(n1710,supported), node(n1711,supported).
node(n1707,refuted) :- node(n1708,refuted).
node(n1707,refuted) :- node(n1709,refuted).
node(n1707,refuted) :- node(n1710,refuted).
node(n1707,refuted) :- node(n1711,refuted).
node(n1707,unknown) :- \+ node(n1707,supported), \+ node(n1707,refuted).
node(n1713,supported) :- status(o_f0dd83e4ed4c79ef195d,supported).
node(n1713,refuted) :- status(o_f0dd83e4ed4c79ef195d,refuted).
node(n1713,unknown) :- status(o_f0dd83e4ed4c79ef195d,unknown).
node(n1714,supported) :- status(o_f2755e5816ad799ba222,supported).
node(n1714,refuted) :- status(o_f2755e5816ad799ba222,refuted).
node(n1714,unknown) :- status(o_f2755e5816ad799ba222,unknown).
node(n1715,supported) :- status(o_4e1a48420355c6079a38,supported).
node(n1715,refuted) :- status(o_4e1a48420355c6079a38,refuted).
node(n1715,unknown) :- status(o_4e1a48420355c6079a38,unknown).
node(n1716,supported) :- status(o_f1c9d070086d48972e4c,supported).
node(n1716,refuted) :- status(o_f1c9d070086d48972e4c,refuted).
node(n1716,unknown) :- status(o_f1c9d070086d48972e4c,unknown).
node(n1712,supported) :- node(n1713,supported), node(n1714,supported), node(n1715,supported), node(n1716,supported).
node(n1712,refuted) :- node(n1713,refuted).
node(n1712,refuted) :- node(n1714,refuted).
node(n1712,refuted) :- node(n1715,refuted).
node(n1712,refuted) :- node(n1716,refuted).
node(n1712,unknown) :- \+ node(n1712,supported), \+ node(n1712,refuted).
node(n1706,refuted) :- node(n1707,refuted), node(n1712,refuted), node(n9,refuted).
node(n1706,supported) :- node(n1707,supported).
node(n1706,supported) :- node(n1712,supported).
node(n1706,supported) :- node(n9,supported).
node(n1706,unknown) :- \+ node(n1706,supported), \+ node(n1706,refuted).
verdict(c_b90ec4e16140682f,supported) :- node(n1706,supported).
query(verdict(c_b90ec4e16140682f,supported)).
verdict(c_b90ec4e16140682f,refuted) :- node(n1706,refuted).
query(verdict(c_b90ec4e16140682f,refuted)).
verdict(c_b90ec4e16140682f,unknown) :- node(n1706,unknown).
query(verdict(c_b90ec4e16140682f,unknown)).
node(n1719,supported) :- status(o_12f2bae4a8a458df64ed,supported).
node(n1719,refuted) :- status(o_12f2bae4a8a458df64ed,refuted).
node(n1719,unknown) :- status(o_12f2bae4a8a458df64ed,unknown).
node(n1720,supported) :- status(o_a6dc7ac72a260132cd67,supported).
node(n1720,refuted) :- status(o_a6dc7ac72a260132cd67,refuted).
node(n1720,unknown) :- status(o_a6dc7ac72a260132cd67,unknown).
node(n1721,supported) :- status(o_fc6ce820061694a002dd,supported).
node(n1721,refuted) :- status(o_fc6ce820061694a002dd,refuted).
node(n1721,unknown) :- status(o_fc6ce820061694a002dd,unknown).
node(n1722,supported) :- status(o_be134f62dc32b7c452fc,supported).
node(n1722,refuted) :- status(o_be134f62dc32b7c452fc,refuted).
node(n1722,unknown) :- status(o_be134f62dc32b7c452fc,unknown).
node(n1718,supported) :- node(n1719,supported), node(n1720,supported), node(n1721,supported), node(n1722,supported).
node(n1718,refuted) :- node(n1719,refuted).
node(n1718,refuted) :- node(n1720,refuted).
node(n1718,refuted) :- node(n1721,refuted).
node(n1718,refuted) :- node(n1722,refuted).
node(n1718,unknown) :- \+ node(n1718,supported), \+ node(n1718,refuted).
node(n1724,supported) :- status(o_0b3484ac141e66dd06f4,supported).
node(n1724,refuted) :- status(o_0b3484ac141e66dd06f4,refuted).
node(n1724,unknown) :- status(o_0b3484ac141e66dd06f4,unknown).
node(n1725,supported) :- status(o_897b6b848b85c5f8074f,supported).
node(n1725,refuted) :- status(o_897b6b848b85c5f8074f,refuted).
node(n1725,unknown) :- status(o_897b6b848b85c5f8074f,unknown).
node(n1726,supported) :- status(o_fcedf07f04919f51cf20,supported).
node(n1726,refuted) :- status(o_fcedf07f04919f51cf20,refuted).
node(n1726,unknown) :- status(o_fcedf07f04919f51cf20,unknown).
node(n1727,supported) :- status(o_1da4d5282dc93a6627f9,supported).
node(n1727,refuted) :- status(o_1da4d5282dc93a6627f9,refuted).
node(n1727,unknown) :- status(o_1da4d5282dc93a6627f9,unknown).
node(n1723,supported) :- node(n1724,supported), node(n1725,supported), node(n1726,supported), node(n1727,supported).
node(n1723,refuted) :- node(n1724,refuted).
node(n1723,refuted) :- node(n1725,refuted).
node(n1723,refuted) :- node(n1726,refuted).
node(n1723,refuted) :- node(n1727,refuted).
node(n1723,unknown) :- \+ node(n1723,supported), \+ node(n1723,refuted).
node(n1717,refuted) :- node(n1718,refuted), node(n1723,refuted), node(n9,refuted).
node(n1717,supported) :- node(n1718,supported).
node(n1717,supported) :- node(n1723,supported).
node(n1717,supported) :- node(n9,supported).
node(n1717,unknown) :- \+ node(n1717,supported), \+ node(n1717,refuted).
verdict(c_19935cd24deb7dfa,supported) :- node(n1717,supported).
query(verdict(c_19935cd24deb7dfa,supported)).
verdict(c_19935cd24deb7dfa,refuted) :- node(n1717,refuted).
query(verdict(c_19935cd24deb7dfa,refuted)).
verdict(c_19935cd24deb7dfa,unknown) :- node(n1717,unknown).
query(verdict(c_19935cd24deb7dfa,unknown)).
node(n1730,supported) :- status(o_4d321f78e9a2e0469624,supported).
node(n1730,refuted) :- status(o_4d321f78e9a2e0469624,refuted).
node(n1730,unknown) :- status(o_4d321f78e9a2e0469624,unknown).
node(n1731,supported) :- status(o_faf3e5edd3f305743bed,supported).
node(n1731,refuted) :- status(o_faf3e5edd3f305743bed,refuted).
node(n1731,unknown) :- status(o_faf3e5edd3f305743bed,unknown).
node(n1732,supported) :- status(o_327000ad80abbdb40ff2,supported).
node(n1732,refuted) :- status(o_327000ad80abbdb40ff2,refuted).
node(n1732,unknown) :- status(o_327000ad80abbdb40ff2,unknown).
node(n1733,supported) :- status(o_7a824cce4f4d39be73b1,supported).
node(n1733,refuted) :- status(o_7a824cce4f4d39be73b1,refuted).
node(n1733,unknown) :- status(o_7a824cce4f4d39be73b1,unknown).
node(n1729,supported) :- node(n1730,supported), node(n1731,supported), node(n1732,supported), node(n1733,supported).
node(n1729,refuted) :- node(n1730,refuted).
node(n1729,refuted) :- node(n1731,refuted).
node(n1729,refuted) :- node(n1732,refuted).
node(n1729,refuted) :- node(n1733,refuted).
node(n1729,unknown) :- \+ node(n1729,supported), \+ node(n1729,refuted).
node(n1735,supported) :- status(o_1322ae48ea8a05a3baa6,supported).
node(n1735,refuted) :- status(o_1322ae48ea8a05a3baa6,refuted).
node(n1735,unknown) :- status(o_1322ae48ea8a05a3baa6,unknown).
node(n1736,supported) :- status(o_a2b5ca456b8fa7f00966,supported).
node(n1736,refuted) :- status(o_a2b5ca456b8fa7f00966,refuted).
node(n1736,unknown) :- status(o_a2b5ca456b8fa7f00966,unknown).
node(n1737,supported) :- status(o_5eb7f94bf064e829d366,supported).
node(n1737,refuted) :- status(o_5eb7f94bf064e829d366,refuted).
node(n1737,unknown) :- status(o_5eb7f94bf064e829d366,unknown).
node(n1738,supported) :- status(o_e0c102a3ef5c5d5f74fd,supported).
node(n1738,refuted) :- status(o_e0c102a3ef5c5d5f74fd,refuted).
node(n1738,unknown) :- status(o_e0c102a3ef5c5d5f74fd,unknown).
node(n1734,supported) :- node(n1735,supported), node(n1736,supported), node(n1737,supported), node(n1738,supported).
node(n1734,refuted) :- node(n1735,refuted).
node(n1734,refuted) :- node(n1736,refuted).
node(n1734,refuted) :- node(n1737,refuted).
node(n1734,refuted) :- node(n1738,refuted).
node(n1734,unknown) :- \+ node(n1734,supported), \+ node(n1734,refuted).
node(n1728,refuted) :- node(n1729,refuted), node(n1734,refuted), node(n9,refuted).
node(n1728,supported) :- node(n1729,supported).
node(n1728,supported) :- node(n1734,supported).
node(n1728,supported) :- node(n9,supported).
node(n1728,unknown) :- \+ node(n1728,supported), \+ node(n1728,refuted).
verdict(c_caeb6f06774f637d,supported) :- node(n1728,supported).
query(verdict(c_caeb6f06774f637d,supported)).
verdict(c_caeb6f06774f637d,refuted) :- node(n1728,refuted).
query(verdict(c_caeb6f06774f637d,refuted)).
verdict(c_caeb6f06774f637d,unknown) :- node(n1728,unknown).
query(verdict(c_caeb6f06774f637d,unknown)).
node(n1741,supported) :- status(o_40856c6b0763d40ea7f1,supported).
node(n1741,refuted) :- status(o_40856c6b0763d40ea7f1,refuted).
node(n1741,unknown) :- status(o_40856c6b0763d40ea7f1,unknown).
node(n1742,supported) :- status(o_78abaa31c67da556aff2,supported).
node(n1742,refuted) :- status(o_78abaa31c67da556aff2,refuted).
node(n1742,unknown) :- status(o_78abaa31c67da556aff2,unknown).
node(n1743,supported) :- status(o_daa75a381ecbcfa88369,supported).
node(n1743,refuted) :- status(o_daa75a381ecbcfa88369,refuted).
node(n1743,unknown) :- status(o_daa75a381ecbcfa88369,unknown).
node(n1740,supported) :- node(n1741,supported), node(n1742,supported), node(n1743,supported).
node(n1740,refuted) :- node(n1741,refuted).
node(n1740,refuted) :- node(n1742,refuted).
node(n1740,refuted) :- node(n1743,refuted).
node(n1740,unknown) :- \+ node(n1740,supported), \+ node(n1740,refuted).
node(n1745,supported) :- status(o_db998042cb35b6e7bb68,supported).
node(n1745,refuted) :- status(o_db998042cb35b6e7bb68,refuted).
node(n1745,unknown) :- status(o_db998042cb35b6e7bb68,unknown).
node(n1746,supported) :- status(o_9731d806c4443dbd04e4,supported).
node(n1746,refuted) :- status(o_9731d806c4443dbd04e4,refuted).
node(n1746,unknown) :- status(o_9731d806c4443dbd04e4,unknown).
node(n1747,supported) :- status(o_87e58d94156aaabaac31,supported).
node(n1747,refuted) :- status(o_87e58d94156aaabaac31,refuted).
node(n1747,unknown) :- status(o_87e58d94156aaabaac31,unknown).
node(n1744,supported) :- node(n1745,supported), node(n1746,supported), node(n1747,supported).
node(n1744,refuted) :- node(n1745,refuted).
node(n1744,refuted) :- node(n1746,refuted).
node(n1744,refuted) :- node(n1747,refuted).
node(n1744,unknown) :- \+ node(n1744,supported), \+ node(n1744,refuted).
node(n1739,refuted) :- node(n1740,refuted), node(n1744,refuted), node(n9,refuted).
node(n1739,supported) :- node(n1740,supported).
node(n1739,supported) :- node(n1744,supported).
node(n1739,supported) :- node(n9,supported).
node(n1739,unknown) :- \+ node(n1739,supported), \+ node(n1739,refuted).
verdict(c_162510de984b6d71,supported) :- node(n1739,supported).
query(verdict(c_162510de984b6d71,supported)).
verdict(c_162510de984b6d71,refuted) :- node(n1739,refuted).
query(verdict(c_162510de984b6d71,refuted)).
verdict(c_162510de984b6d71,unknown) :- node(n1739,unknown).
query(verdict(c_162510de984b6d71,unknown)).
node(n1750,supported) :- status(o_f06fe9592fa0a515d469,supported).
node(n1750,refuted) :- status(o_f06fe9592fa0a515d469,refuted).
node(n1750,unknown) :- status(o_f06fe9592fa0a515d469,unknown).
node(n1751,supported) :- status(o_6d126d89ae968db9970e,supported).
node(n1751,refuted) :- status(o_6d126d89ae968db9970e,refuted).
node(n1751,unknown) :- status(o_6d126d89ae968db9970e,unknown).
node(n1752,supported) :- status(o_94fd15241717d9faf933,supported).
node(n1752,refuted) :- status(o_94fd15241717d9faf933,refuted).
node(n1752,unknown) :- status(o_94fd15241717d9faf933,unknown).
node(n1753,supported) :- status(o_9ce0cc5e6a772f28b4f7,supported).
node(n1753,refuted) :- status(o_9ce0cc5e6a772f28b4f7,refuted).
node(n1753,unknown) :- status(o_9ce0cc5e6a772f28b4f7,unknown).
node(n1749,supported) :- node(n1750,supported), node(n1751,supported), node(n1752,supported), node(n1753,supported).
node(n1749,refuted) :- node(n1750,refuted).
node(n1749,refuted) :- node(n1751,refuted).
node(n1749,refuted) :- node(n1752,refuted).
node(n1749,refuted) :- node(n1753,refuted).
node(n1749,unknown) :- \+ node(n1749,supported), \+ node(n1749,refuted).
node(n1755,supported) :- status(o_3e199d5fdb8d466fb70d,supported).
node(n1755,refuted) :- status(o_3e199d5fdb8d466fb70d,refuted).
node(n1755,unknown) :- status(o_3e199d5fdb8d466fb70d,unknown).
node(n1756,supported) :- status(o_0d8984f9ba9ba9247e34,supported).
node(n1756,refuted) :- status(o_0d8984f9ba9ba9247e34,refuted).
node(n1756,unknown) :- status(o_0d8984f9ba9ba9247e34,unknown).
node(n1757,supported) :- status(o_4d0c7c6265b3089b07e0,supported).
node(n1757,refuted) :- status(o_4d0c7c6265b3089b07e0,refuted).
node(n1757,unknown) :- status(o_4d0c7c6265b3089b07e0,unknown).
node(n1758,supported) :- status(o_7ca35e073d20292b0cb0,supported).
node(n1758,refuted) :- status(o_7ca35e073d20292b0cb0,refuted).
node(n1758,unknown) :- status(o_7ca35e073d20292b0cb0,unknown).
node(n1754,supported) :- node(n1755,supported), node(n1756,supported), node(n1757,supported), node(n1758,supported).
node(n1754,refuted) :- node(n1755,refuted).
node(n1754,refuted) :- node(n1756,refuted).
node(n1754,refuted) :- node(n1757,refuted).
node(n1754,refuted) :- node(n1758,refuted).
node(n1754,unknown) :- \+ node(n1754,supported), \+ node(n1754,refuted).
node(n1748,refuted) :- node(n1749,refuted), node(n1754,refuted), node(n9,refuted).
node(n1748,supported) :- node(n1749,supported).
node(n1748,supported) :- node(n1754,supported).
node(n1748,supported) :- node(n9,supported).
node(n1748,unknown) :- \+ node(n1748,supported), \+ node(n1748,refuted).
verdict(c_a48987af7ba40a15,supported) :- node(n1748,supported).
query(verdict(c_a48987af7ba40a15,supported)).
verdict(c_a48987af7ba40a15,refuted) :- node(n1748,refuted).
query(verdict(c_a48987af7ba40a15,refuted)).
verdict(c_a48987af7ba40a15,unknown) :- node(n1748,unknown).
query(verdict(c_a48987af7ba40a15,unknown)).
node(n1761,supported) :- status(o_fc2e3b03d27948185b9f,supported).
node(n1761,refuted) :- status(o_fc2e3b03d27948185b9f,refuted).
node(n1761,unknown) :- status(o_fc2e3b03d27948185b9f,unknown).
node(n1762,supported) :- status(o_3cfc88c982d6f719b1eb,supported).
node(n1762,refuted) :- status(o_3cfc88c982d6f719b1eb,refuted).
node(n1762,unknown) :- status(o_3cfc88c982d6f719b1eb,unknown).
node(n1763,supported) :- status(o_ead7fa18e7e347b42e7a,supported).
node(n1763,refuted) :- status(o_ead7fa18e7e347b42e7a,refuted).
node(n1763,unknown) :- status(o_ead7fa18e7e347b42e7a,unknown).
node(n1764,supported) :- status(o_3b4991f7ba55b501a774,supported).
node(n1764,refuted) :- status(o_3b4991f7ba55b501a774,refuted).
node(n1764,unknown) :- status(o_3b4991f7ba55b501a774,unknown).
node(n1760,supported) :- node(n1761,supported), node(n1762,supported), node(n1763,supported), node(n1764,supported).
node(n1760,refuted) :- node(n1761,refuted).
node(n1760,refuted) :- node(n1762,refuted).
node(n1760,refuted) :- node(n1763,refuted).
node(n1760,refuted) :- node(n1764,refuted).
node(n1760,unknown) :- \+ node(n1760,supported), \+ node(n1760,refuted).
node(n1766,supported) :- status(o_2e8bf76007ae8f4a0465,supported).
node(n1766,refuted) :- status(o_2e8bf76007ae8f4a0465,refuted).
node(n1766,unknown) :- status(o_2e8bf76007ae8f4a0465,unknown).
node(n1767,supported) :- status(o_e129b08123df2e6898b5,supported).
node(n1767,refuted) :- status(o_e129b08123df2e6898b5,refuted).
node(n1767,unknown) :- status(o_e129b08123df2e6898b5,unknown).
node(n1768,supported) :- status(o_a41848fa24a0b54038fa,supported).
node(n1768,refuted) :- status(o_a41848fa24a0b54038fa,refuted).
node(n1768,unknown) :- status(o_a41848fa24a0b54038fa,unknown).
node(n1769,supported) :- status(o_6f08aa4295b14eeb4332,supported).
node(n1769,refuted) :- status(o_6f08aa4295b14eeb4332,refuted).
node(n1769,unknown) :- status(o_6f08aa4295b14eeb4332,unknown).
node(n1765,supported) :- node(n1766,supported), node(n1767,supported), node(n1768,supported), node(n1769,supported).
node(n1765,refuted) :- node(n1766,refuted).
node(n1765,refuted) :- node(n1767,refuted).
node(n1765,refuted) :- node(n1768,refuted).
node(n1765,refuted) :- node(n1769,refuted).
node(n1765,unknown) :- \+ node(n1765,supported), \+ node(n1765,refuted).
node(n1759,refuted) :- node(n1760,refuted), node(n1765,refuted), node(n9,refuted).
node(n1759,supported) :- node(n1760,supported).
node(n1759,supported) :- node(n1765,supported).
node(n1759,supported) :- node(n9,supported).
node(n1759,unknown) :- \+ node(n1759,supported), \+ node(n1759,refuted).
verdict(c_d970e134b4a1bc10,supported) :- node(n1759,supported).
query(verdict(c_d970e134b4a1bc10,supported)).
verdict(c_d970e134b4a1bc10,refuted) :- node(n1759,refuted).
query(verdict(c_d970e134b4a1bc10,refuted)).
verdict(c_d970e134b4a1bc10,unknown) :- node(n1759,unknown).
query(verdict(c_d970e134b4a1bc10,unknown)).
node(n1772,supported) :- status(o_7f5741e6d7632eb6a1a4,supported).
node(n1772,refuted) :- status(o_7f5741e6d7632eb6a1a4,refuted).
node(n1772,unknown) :- status(o_7f5741e6d7632eb6a1a4,unknown).
node(n1773,supported) :- status(o_3fe547b68488f0f3c153,supported).
node(n1773,refuted) :- status(o_3fe547b68488f0f3c153,refuted).
node(n1773,unknown) :- status(o_3fe547b68488f0f3c153,unknown).
node(n1774,supported) :- status(o_dee43e88572cb215de78,supported).
node(n1774,refuted) :- status(o_dee43e88572cb215de78,refuted).
node(n1774,unknown) :- status(o_dee43e88572cb215de78,unknown).
node(n1775,supported) :- status(o_2765580ee0ba46fdda13,supported).
node(n1775,refuted) :- status(o_2765580ee0ba46fdda13,refuted).
node(n1775,unknown) :- status(o_2765580ee0ba46fdda13,unknown).
node(n1771,supported) :- node(n1772,supported), node(n1773,supported), node(n1774,supported), node(n1775,supported).
node(n1771,refuted) :- node(n1772,refuted).
node(n1771,refuted) :- node(n1773,refuted).
node(n1771,refuted) :- node(n1774,refuted).
node(n1771,refuted) :- node(n1775,refuted).
node(n1771,unknown) :- \+ node(n1771,supported), \+ node(n1771,refuted).
node(n1777,supported) :- status(o_b699ae805ed9c6f04db9,supported).
node(n1777,refuted) :- status(o_b699ae805ed9c6f04db9,refuted).
node(n1777,unknown) :- status(o_b699ae805ed9c6f04db9,unknown).
node(n1778,supported) :- status(o_b2ec04d30f8dee6517bc,supported).
node(n1778,refuted) :- status(o_b2ec04d30f8dee6517bc,refuted).
node(n1778,unknown) :- status(o_b2ec04d30f8dee6517bc,unknown).
node(n1779,supported) :- status(o_31a379e156078cfe5b5e,supported).
node(n1779,refuted) :- status(o_31a379e156078cfe5b5e,refuted).
node(n1779,unknown) :- status(o_31a379e156078cfe5b5e,unknown).
node(n1780,supported) :- status(o_30b73e196cde223bfc12,supported).
node(n1780,refuted) :- status(o_30b73e196cde223bfc12,refuted).
node(n1780,unknown) :- status(o_30b73e196cde223bfc12,unknown).
node(n1776,supported) :- node(n1777,supported), node(n1778,supported), node(n1779,supported), node(n1780,supported).
node(n1776,refuted) :- node(n1777,refuted).
node(n1776,refuted) :- node(n1778,refuted).
node(n1776,refuted) :- node(n1779,refuted).
node(n1776,refuted) :- node(n1780,refuted).
node(n1776,unknown) :- \+ node(n1776,supported), \+ node(n1776,refuted).
node(n1770,refuted) :- node(n1771,refuted), node(n1776,refuted), node(n9,refuted).
node(n1770,supported) :- node(n1771,supported).
node(n1770,supported) :- node(n1776,supported).
node(n1770,supported) :- node(n9,supported).
node(n1770,unknown) :- \+ node(n1770,supported), \+ node(n1770,refuted).
verdict(c_4bb2e519539288fd,supported) :- node(n1770,supported).
query(verdict(c_4bb2e519539288fd,supported)).
verdict(c_4bb2e519539288fd,refuted) :- node(n1770,refuted).
query(verdict(c_4bb2e519539288fd,refuted)).
verdict(c_4bb2e519539288fd,unknown) :- node(n1770,unknown).
query(verdict(c_4bb2e519539288fd,unknown)).
node(n1783,supported) :- status(o_fce1fba09a2f21ebfc31,supported).
node(n1783,refuted) :- status(o_fce1fba09a2f21ebfc31,refuted).
node(n1783,unknown) :- status(o_fce1fba09a2f21ebfc31,unknown).
node(n1784,supported) :- status(o_9af73b546cdd58da29c9,supported).
node(n1784,refuted) :- status(o_9af73b546cdd58da29c9,refuted).
node(n1784,unknown) :- status(o_9af73b546cdd58da29c9,unknown).
node(n1785,supported) :- status(o_8f0c953629a53c8f8fa0,supported).
node(n1785,refuted) :- status(o_8f0c953629a53c8f8fa0,refuted).
node(n1785,unknown) :- status(o_8f0c953629a53c8f8fa0,unknown).
node(n1782,supported) :- node(n1783,supported), node(n1784,supported), node(n1785,supported).
node(n1782,refuted) :- node(n1783,refuted).
node(n1782,refuted) :- node(n1784,refuted).
node(n1782,refuted) :- node(n1785,refuted).
node(n1782,unknown) :- \+ node(n1782,supported), \+ node(n1782,refuted).
node(n1781,refuted) :- node(n1782,refuted), node(n9,refuted).
node(n1781,supported) :- node(n1782,supported).
node(n1781,supported) :- node(n9,supported).
node(n1781,unknown) :- \+ node(n1781,supported), \+ node(n1781,refuted).
verdict(c_efb312bc41deb0a2,supported) :- node(n1781,supported).
query(verdict(c_efb312bc41deb0a2,supported)).
verdict(c_efb312bc41deb0a2,refuted) :- node(n1781,refuted).
query(verdict(c_efb312bc41deb0a2,refuted)).
verdict(c_efb312bc41deb0a2,unknown) :- node(n1781,unknown).
query(verdict(c_efb312bc41deb0a2,unknown)).
node(n1788,supported) :- status(o_ea21f852150cc0b24217,supported).
node(n1788,refuted) :- status(o_ea21f852150cc0b24217,refuted).
node(n1788,unknown) :- status(o_ea21f852150cc0b24217,unknown).
node(n1789,supported) :- status(o_3baa72ecbf70e6fd9d13,supported).
node(n1789,refuted) :- status(o_3baa72ecbf70e6fd9d13,refuted).
node(n1789,unknown) :- status(o_3baa72ecbf70e6fd9d13,unknown).
node(n1790,supported) :- status(o_67c198908a696f1a1378,supported).
node(n1790,refuted) :- status(o_67c198908a696f1a1378,refuted).
node(n1790,unknown) :- status(o_67c198908a696f1a1378,unknown).
node(n1791,supported) :- status(o_d2f231da2ffba9e122ec,supported).
node(n1791,refuted) :- status(o_d2f231da2ffba9e122ec,refuted).
node(n1791,unknown) :- status(o_d2f231da2ffba9e122ec,unknown).
node(n1787,supported) :- node(n1788,supported), node(n1789,supported), node(n1790,supported), node(n1791,supported).
node(n1787,refuted) :- node(n1788,refuted).
node(n1787,refuted) :- node(n1789,refuted).
node(n1787,refuted) :- node(n1790,refuted).
node(n1787,refuted) :- node(n1791,refuted).
node(n1787,unknown) :- \+ node(n1787,supported), \+ node(n1787,refuted).
node(n1786,refuted) :- node(n1787,refuted), node(n9,refuted).
node(n1786,supported) :- node(n1787,supported).
node(n1786,supported) :- node(n9,supported).
node(n1786,unknown) :- \+ node(n1786,supported), \+ node(n1786,refuted).
verdict(c_6f77b35dedfd8307,supported) :- node(n1786,supported).
query(verdict(c_6f77b35dedfd8307,supported)).
verdict(c_6f77b35dedfd8307,refuted) :- node(n1786,refuted).
query(verdict(c_6f77b35dedfd8307,refuted)).
verdict(c_6f77b35dedfd8307,unknown) :- node(n1786,unknown).
query(verdict(c_6f77b35dedfd8307,unknown)).
node(n1794,supported) :- status(o_be198c5a38ac69282199,supported).
node(n1794,refuted) :- status(o_be198c5a38ac69282199,refuted).
node(n1794,unknown) :- status(o_be198c5a38ac69282199,unknown).
node(n1795,supported) :- status(o_15488ab1a7cec7f44a95,supported).
node(n1795,refuted) :- status(o_15488ab1a7cec7f44a95,refuted).
node(n1795,unknown) :- status(o_15488ab1a7cec7f44a95,unknown).
node(n1796,supported) :- status(o_e61d6019545240e21512,supported).
node(n1796,refuted) :- status(o_e61d6019545240e21512,refuted).
node(n1796,unknown) :- status(o_e61d6019545240e21512,unknown).
node(n1797,supported) :- status(o_200fabbddc546e015aab,supported).
node(n1797,refuted) :- status(o_200fabbddc546e015aab,refuted).
node(n1797,unknown) :- status(o_200fabbddc546e015aab,unknown).
node(n1793,supported) :- node(n1794,supported), node(n1795,supported), node(n1796,supported), node(n1797,supported).
node(n1793,refuted) :- node(n1794,refuted).
node(n1793,refuted) :- node(n1795,refuted).
node(n1793,refuted) :- node(n1796,refuted).
node(n1793,refuted) :- node(n1797,refuted).
node(n1793,unknown) :- \+ node(n1793,supported), \+ node(n1793,refuted).
node(n1792,refuted) :- node(n1793,refuted), node(n9,refuted).
node(n1792,supported) :- node(n1793,supported).
node(n1792,supported) :- node(n9,supported).
node(n1792,unknown) :- \+ node(n1792,supported), \+ node(n1792,refuted).
verdict(c_921d1aad1656c235,supported) :- node(n1792,supported).
query(verdict(c_921d1aad1656c235,supported)).
verdict(c_921d1aad1656c235,refuted) :- node(n1792,refuted).
query(verdict(c_921d1aad1656c235,refuted)).
verdict(c_921d1aad1656c235,unknown) :- node(n1792,unknown).
query(verdict(c_921d1aad1656c235,unknown)).
node(n1800,supported) :- status(o_7e8c9cc0f7fa86251719,supported).
node(n1800,refuted) :- status(o_7e8c9cc0f7fa86251719,refuted).
node(n1800,unknown) :- status(o_7e8c9cc0f7fa86251719,unknown).
node(n1801,supported) :- status(o_985ca8c01a917014aa0b,supported).
node(n1801,refuted) :- status(o_985ca8c01a917014aa0b,refuted).
node(n1801,unknown) :- status(o_985ca8c01a917014aa0b,unknown).
node(n1802,supported) :- status(o_03aec88a8a8cdf6c9150,supported).
node(n1802,refuted) :- status(o_03aec88a8a8cdf6c9150,refuted).
node(n1802,unknown) :- status(o_03aec88a8a8cdf6c9150,unknown).
node(n1803,supported) :- status(o_51a10900bea196e24acf,supported).
node(n1803,refuted) :- status(o_51a10900bea196e24acf,refuted).
node(n1803,unknown) :- status(o_51a10900bea196e24acf,unknown).
node(n1799,supported) :- node(n1800,supported), node(n1801,supported), node(n1802,supported), node(n1803,supported).
node(n1799,refuted) :- node(n1800,refuted).
node(n1799,refuted) :- node(n1801,refuted).
node(n1799,refuted) :- node(n1802,refuted).
node(n1799,refuted) :- node(n1803,refuted).
node(n1799,unknown) :- \+ node(n1799,supported), \+ node(n1799,refuted).
node(n1798,refuted) :- node(n1799,refuted), node(n9,refuted).
node(n1798,supported) :- node(n1799,supported).
node(n1798,supported) :- node(n9,supported).
node(n1798,unknown) :- \+ node(n1798,supported), \+ node(n1798,refuted).
verdict(c_80793c0852edb45b,supported) :- node(n1798,supported).
query(verdict(c_80793c0852edb45b,supported)).
verdict(c_80793c0852edb45b,refuted) :- node(n1798,refuted).
query(verdict(c_80793c0852edb45b,refuted)).
verdict(c_80793c0852edb45b,unknown) :- node(n1798,unknown).
query(verdict(c_80793c0852edb45b,unknown)).
node(n1806,supported) :- status(o_a5a0799fbcc3cd119876,supported).
node(n1806,refuted) :- status(o_a5a0799fbcc3cd119876,refuted).
node(n1806,unknown) :- status(o_a5a0799fbcc3cd119876,unknown).
node(n1807,supported) :- status(o_7750c71126a1910ffb8c,supported).
node(n1807,refuted) :- status(o_7750c71126a1910ffb8c,refuted).
node(n1807,unknown) :- status(o_7750c71126a1910ffb8c,unknown).
node(n1808,supported) :- status(o_c619d06b6de0b8136b1d,supported).
node(n1808,refuted) :- status(o_c619d06b6de0b8136b1d,refuted).
node(n1808,unknown) :- status(o_c619d06b6de0b8136b1d,unknown).
node(n1805,supported) :- node(n1806,supported), node(n1807,supported), node(n1808,supported).
node(n1805,refuted) :- node(n1806,refuted).
node(n1805,refuted) :- node(n1807,refuted).
node(n1805,refuted) :- node(n1808,refuted).
node(n1805,unknown) :- \+ node(n1805,supported), \+ node(n1805,refuted).
node(n1804,refuted) :- node(n1805,refuted), node(n9,refuted).
node(n1804,supported) :- node(n1805,supported).
node(n1804,supported) :- node(n9,supported).
node(n1804,unknown) :- \+ node(n1804,supported), \+ node(n1804,refuted).
verdict(c_7965cea7047300c4,supported) :- node(n1804,supported).
query(verdict(c_7965cea7047300c4,supported)).
verdict(c_7965cea7047300c4,refuted) :- node(n1804,refuted).
query(verdict(c_7965cea7047300c4,refuted)).
verdict(c_7965cea7047300c4,unknown) :- node(n1804,unknown).
query(verdict(c_7965cea7047300c4,unknown)).
node(n1811,supported) :- status(o_58918967d74c99963a40,supported).
node(n1811,refuted) :- status(o_58918967d74c99963a40,refuted).
node(n1811,unknown) :- status(o_58918967d74c99963a40,unknown).
node(n1812,supported) :- status(o_a8dd249e67dbcda4f802,supported).
node(n1812,refuted) :- status(o_a8dd249e67dbcda4f802,refuted).
node(n1812,unknown) :- status(o_a8dd249e67dbcda4f802,unknown).
node(n1813,supported) :- status(o_4978d2879076a93ffb7a,supported).
node(n1813,refuted) :- status(o_4978d2879076a93ffb7a,refuted).
node(n1813,unknown) :- status(o_4978d2879076a93ffb7a,unknown).
node(n1814,supported) :- status(o_b60c07d71b60273cd421,supported).
node(n1814,refuted) :- status(o_b60c07d71b60273cd421,refuted).
node(n1814,unknown) :- status(o_b60c07d71b60273cd421,unknown).
node(n1810,supported) :- node(n1811,supported), node(n1812,supported), node(n1813,supported), node(n1814,supported).
node(n1810,refuted) :- node(n1811,refuted).
node(n1810,refuted) :- node(n1812,refuted).
node(n1810,refuted) :- node(n1813,refuted).
node(n1810,refuted) :- node(n1814,refuted).
node(n1810,unknown) :- \+ node(n1810,supported), \+ node(n1810,refuted).
node(n1809,refuted) :- node(n1810,refuted), node(n9,refuted).
node(n1809,supported) :- node(n1810,supported).
node(n1809,supported) :- node(n9,supported).
node(n1809,unknown) :- \+ node(n1809,supported), \+ node(n1809,refuted).
verdict(c_d8dfec79fcdd7966,supported) :- node(n1809,supported).
query(verdict(c_d8dfec79fcdd7966,supported)).
verdict(c_d8dfec79fcdd7966,refuted) :- node(n1809,refuted).
query(verdict(c_d8dfec79fcdd7966,refuted)).
verdict(c_d8dfec79fcdd7966,unknown) :- node(n1809,unknown).
query(verdict(c_d8dfec79fcdd7966,unknown)).
node(n1817,supported) :- status(o_eebc051d240182f0288d,supported).
node(n1817,refuted) :- status(o_eebc051d240182f0288d,refuted).
node(n1817,unknown) :- status(o_eebc051d240182f0288d,unknown).
node(n1818,supported) :- status(o_c6ca1955471e568f2bf6,supported).
node(n1818,refuted) :- status(o_c6ca1955471e568f2bf6,refuted).
node(n1818,unknown) :- status(o_c6ca1955471e568f2bf6,unknown).
node(n1819,supported) :- status(o_0811959c9dfe24d15a88,supported).
node(n1819,refuted) :- status(o_0811959c9dfe24d15a88,refuted).
node(n1819,unknown) :- status(o_0811959c9dfe24d15a88,unknown).
node(n1820,supported) :- status(o_eb7d5a9f888f58bb8732,supported).
node(n1820,refuted) :- status(o_eb7d5a9f888f58bb8732,refuted).
node(n1820,unknown) :- status(o_eb7d5a9f888f58bb8732,unknown).
node(n1816,supported) :- node(n1817,supported), node(n1818,supported), node(n1819,supported), node(n1820,supported).
node(n1816,refuted) :- node(n1817,refuted).
node(n1816,refuted) :- node(n1818,refuted).
node(n1816,refuted) :- node(n1819,refuted).
node(n1816,refuted) :- node(n1820,refuted).
node(n1816,unknown) :- \+ node(n1816,supported), \+ node(n1816,refuted).
node(n1815,refuted) :- node(n1816,refuted), node(n9,refuted).
node(n1815,supported) :- node(n1816,supported).
node(n1815,supported) :- node(n9,supported).
node(n1815,unknown) :- \+ node(n1815,supported), \+ node(n1815,refuted).
verdict(c_86ec3ed560c1ef3a,supported) :- node(n1815,supported).
query(verdict(c_86ec3ed560c1ef3a,supported)).
verdict(c_86ec3ed560c1ef3a,refuted) :- node(n1815,refuted).
query(verdict(c_86ec3ed560c1ef3a,refuted)).
verdict(c_86ec3ed560c1ef3a,unknown) :- node(n1815,unknown).
query(verdict(c_86ec3ed560c1ef3a,unknown)).
node(n1823,supported) :- status(o_ec892c70930bb46d69ba,supported).
node(n1823,refuted) :- status(o_ec892c70930bb46d69ba,refuted).
node(n1823,unknown) :- status(o_ec892c70930bb46d69ba,unknown).
node(n1824,supported) :- status(o_7442a3d19f20279f7334,supported).
node(n1824,refuted) :- status(o_7442a3d19f20279f7334,refuted).
node(n1824,unknown) :- status(o_7442a3d19f20279f7334,unknown).
node(n1825,supported) :- status(o_63783cca1b37f7d0cbb9,supported).
node(n1825,refuted) :- status(o_63783cca1b37f7d0cbb9,refuted).
node(n1825,unknown) :- status(o_63783cca1b37f7d0cbb9,unknown).
node(n1826,supported) :- status(o_f60785b734a97af131f2,supported).
node(n1826,refuted) :- status(o_f60785b734a97af131f2,refuted).
node(n1826,unknown) :- status(o_f60785b734a97af131f2,unknown).
node(n1822,supported) :- node(n1823,supported), node(n1824,supported), node(n1825,supported), node(n1826,supported).
node(n1822,refuted) :- node(n1823,refuted).
node(n1822,refuted) :- node(n1824,refuted).
node(n1822,refuted) :- node(n1825,refuted).
node(n1822,refuted) :- node(n1826,refuted).
node(n1822,unknown) :- \+ node(n1822,supported), \+ node(n1822,refuted).
node(n1821,refuted) :- node(n1822,refuted), node(n9,refuted).
node(n1821,supported) :- node(n1822,supported).
node(n1821,supported) :- node(n9,supported).
node(n1821,unknown) :- \+ node(n1821,supported), \+ node(n1821,refuted).
verdict(c_508fa8e3d46be123,supported) :- node(n1821,supported).
query(verdict(c_508fa8e3d46be123,supported)).
verdict(c_508fa8e3d46be123,refuted) :- node(n1821,refuted).
query(verdict(c_508fa8e3d46be123,refuted)).
verdict(c_508fa8e3d46be123,unknown) :- node(n1821,unknown).
query(verdict(c_508fa8e3d46be123,unknown)).
