# Speaker and utterance binding in AMI

We reused eight annotated utterances from eight AMI meetings in the earlier [alignment study](scope_and_alignment_20261119.md). In each utterance, one speaker presents a choice between two alternatives. We also made four controls per utterance by changing the speaker label, querying an earlier time, or putting the alternatives in different speakers’ turns or different utterances by the same speaker. The controls reuse the original words and require no new human labels. These are diagnostic cases for reported speech, with no estimate of performance on unseen meetings.

All three checks supported the eight original utterances. Pooling words across speakers gave false support on 24 of 32 controls. Restricting the search to one speaker reduced that count to eight, all cases with two utterances. Requiring both alternatives from one utterance gave zero false support. Matching uses phrases from the annotations in this test.

We also ran the existing compiler on eight indirect-speech claims for the utterances. Three usable programs preserve both the speaker role and the reported alternatives, one leaves the alternatives inside a phrase, and four have no program. The three usable programs pass all 15 exact DeepProbLog queries when we supply the speaker and utterance candidates and hold other observations fixed. The programs share a reporting event between the speaker predicate and the predicate that checks the full utterance.

## Automatic windows

We compared the earlier Pyannote model with Reverb v1. Both ran on the same 75-second distant-microphone excerpt per meeting, with the same speaker embedding and clustering setup. Word timings and text came from the manual transcript, and we used a preceding labeled speech segment to map predicted speaker clusters to named speakers. Each target query had a 35-second search interval. The tested window assignment allows other speakers to overlap when one estimated speaker has a uniquely active content word on each side of the spoken “or.” We deduplicated candidate windows by word IDs, ranked them by token overlap with the claim, and ran the same frozen textual entailment model on the top one or top three. This comparison does not measure transcription errors or train a relation classifier.

Pyannote supported one of eight correct-speaker queries with the original word assignment or the top candidate, and two with up to three candidates. Reverb supported one under each condition. All wrong-speaker and earlier-time queries remained unknown. Giving the number of speakers or allowing several clusters to map to one speaker did not change these counts. In six Pyannote and seven Reverb examples, no target words were assigned to the requested speaker before ranking or text scoring. Word-level annotations reveal words from another speaker in the additional Pyannote match, even with all target words present.

The [AMI corpus](https://groups.inf.ed.ac.uk/ami/download/) is available under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Model details are in the [Reverb paper](https://arxiv.org/abs/2410.03930) and [sherpa-onnx model documentation](https://k2-fsa.github.io/sherpa/onnx/speaker-diarization/models.html). The archive includes cached diarization and transcript scores. Audio and model weights are available separately from their sources.

## Replay

In the archive root, use Python 3.12 and the dependencies in `requirements-compilation.txt` and `requirements-verification.txt`. These commands replay compilation and inference from cached parser outputs, annotated transcripts, diarization, and entailment scores. The checksum file covers the derived results and the provided test report records the full project test run.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
run=exp/probabilistic_verification/ami_speaker_binding_20261126
python scripts/evaluate_or_followup_compilation.py "$run/compiler" "$run/compiler/amr.jsonl" "$run/compiled.json"
python scripts/evaluate_ami_speaker_binding.py binding
python scripts/evaluate_ami_speaker_binding.py prepare
python scripts/evaluate_ami_speaker_binding.py evaluate
python scripts/check_ami_speaker_binding.py
python scripts/ami_speaker_binding_report.py
python -m pytest -q tests/test_ami_speaker_binding.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/ami_speaker_binding_20261126')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```

## Next steps

- Use annotated speaker and utterance windows in the first speech binding comparison. Keep the compiler abstentions visible so the result shows which claims reach inference.
- Compare the candidate windows again using the annotated mapping from clusters to speaker IDs for the target interval. This shows how much of the missing content comes from naming speakers versus detecting their speech and assigning words to it.
