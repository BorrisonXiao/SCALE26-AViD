"""The automatic overlap proposals still need evidence for both branches."""
from evaluate_ami_speaker_binding import overlap_windows, ranked_windows


def utterance():
    return {'clip_words': [
        dict(text='Orders',start=1.1,end=1.3,word_id='a'),
        dict(text='or',start=1.4,end=1.6,word_id='b'),
        dict(text='refunds',start=1.7,end=1.9,word_id='c'),
        dict(text='.',start=2.0,end=2.1,word_id='d'),
    ]}


def test_overlap_cannot_assign_a_whole_branch_to_a_speaker():
    turns = [dict(start=1.0,end=2.2,cluster=0),dict(start=1.5,end=2.2,cluster=1)]
    assert list(overlap_windows(utterance(),turns,{0:'A',1:'B'},1,3))==[]


def test_multiple_candidates_stay_within_the_requested_speaker_and_time():
    valid=dict(text='Orders or refunds.', start=1.0, end=2.0, speaker='A', word_ids=['a','b','c'])
    proposed=dict(strict=[valid,dict(valid, speaker='B'),dict(valid,start=10,end=11)],
                  overlap=[dict(valid,end=2.1,anchors=[['orders'],['refunds']]),
                           dict(valid,word_ids=['x','y','z'], anchors=[['orders'],['exchanges']])])
    query=dict(speaker='A',start=1.0,end=3.0)
    assert ranked_windows(proposed,query,'Orders or refunds.')==[valid]
