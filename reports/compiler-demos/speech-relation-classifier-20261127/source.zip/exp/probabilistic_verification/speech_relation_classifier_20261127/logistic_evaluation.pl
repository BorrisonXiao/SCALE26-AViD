% Exact categorical evidence; internal unknown = neither supported nor refuted.
0.51267369618544434::status(o_000730c96e06a0d8eb8f,supported); 0::status(o_000730c96e06a0d8eb8f,refuted); 0.48732630381455566::status(o_000730c96e06a0d8eb8f,unknown).
0.40058283525211141::status(o_006408ef8c0395cba831,supported); 0::status(o_006408ef8c0395cba831,refuted); 0.59941716474788853::status(o_006408ef8c0395cba831,unknown).
0.045692827552556992::status(o_00ad64f51dae10718060,supported); 0::status(o_00ad64f51dae10718060,refuted); 0.95430717244744301::status(o_00ad64f51dae10718060,unknown).
0.72335165686353298::status(o_00fb41f1e22830074c78,supported); 0::status(o_00fb41f1e22830074c78,refuted); 0.27664834313646702::status(o_00fb41f1e22830074c78,unknown).
1::status(o_013590ea4e7cd47378f9,supported); 0::status(o_013590ea4e7cd47378f9,refuted); 0::status(o_013590ea4e7cd47378f9,unknown).
0.26828955437261837::status(o_0176f303990cb1a43f5f,supported); 0::status(o_0176f303990cb1a43f5f,refuted); 0.73171044562738163::status(o_0176f303990cb1a43f5f,unknown).
1::status(o_019d3c007e49851e214c,supported); 0::status(o_019d3c007e49851e214c,refuted); 0::status(o_019d3c007e49851e214c,unknown).
0.99213320016860962::status(o_01b9c045b65ad2a7db10,supported); 0::status(o_01b9c045b65ad2a7db10,refuted); 0.0078667998313903809::status(o_01b9c045b65ad2a7db10,unknown).
1::status(o_01ff1e8d0f4aa7a71943,supported); 0::status(o_01ff1e8d0f4aa7a71943,refuted); 0::status(o_01ff1e8d0f4aa7a71943,unknown).
0.67629057793032687::status(o_04be10164d619f9eaf96,supported); 0::status(o_04be10164d619f9eaf96,refuted); 0.32370942206967313::status(o_04be10164d619f9eaf96,unknown).
0.9814574122428894::status(o_054020a30df144eed425,supported); 0::status(o_054020a30df144eed425,refuted); 0.018542587757110596::status(o_054020a30df144eed425,unknown).
0.18716649970367355::status(o_05929e27873600e36733,supported); 0::status(o_05929e27873600e36733,refuted); 0.81283350029632651::status(o_05929e27873600e36733,unknown).
4.394259667606093e-05::status(o_05d6e4c2285b76e8f4ae,supported); 0::status(o_05d6e4c2285b76e8f4ae,refuted); 0.99995605740332394::status(o_05d6e4c2285b76e8f4ae,unknown).
0.67014139818444596::status(o_06b67517fb89dbac98b8,supported); 0::status(o_06b67517fb89dbac98b8,refuted); 0.32985860181555404::status(o_06b67517fb89dbac98b8,unknown).
1::status(o_083cbd9d5b0dc69706a0,supported); 0::status(o_083cbd9d5b0dc69706a0,refuted); 0::status(o_083cbd9d5b0dc69706a0,unknown).
0.29771421661017777::status(o_094350b43c7453be0e63,supported); 0::status(o_094350b43c7453be0e63,refuted); 0.70228578338982217::status(o_094350b43c7453be0e63,unknown).
0.20310970056015587::status(o_09b238a23fe4af8cacd1,supported); 0::status(o_09b238a23fe4af8cacd1,refuted); 0.79689029943984413::status(o_09b238a23fe4af8cacd1,unknown).
0.98598873615264893::status(o_09d3b514598d1c4af582,supported); 0::status(o_09d3b514598d1c4af582,refuted); 0.014011263847351074::status(o_09d3b514598d1c4af582,unknown).
0::status(o_09f56b988afeba1515ca,supported); 1::status(o_09f56b988afeba1515ca,refuted); 0::status(o_09f56b988afeba1515ca,unknown).
0.037853103131055832::status(o_0ab84c0c657cadb3f157,supported); 0::status(o_0ab84c0c657cadb3f157,refuted); 0.96214689686894417::status(o_0ab84c0c657cadb3f157,unknown).
0.34819854080380347::status(o_0b0642323388b2ee12d9,supported); 0::status(o_0b0642323388b2ee12d9,refuted); 0.65180145919619648::status(o_0b0642323388b2ee12d9,unknown).
0::status(o_0b21c24297026375629d,supported); 1::status(o_0b21c24297026375629d,refuted); 0::status(o_0b21c24297026375629d,unknown).
1::status(o_0b506808665499301698,supported); 0::status(o_0b506808665499301698,refuted); 0::status(o_0b506808665499301698,unknown).
0.62521180049902358::status(o_0b56e6d4b50fb0d52828,supported); 0::status(o_0b56e6d4b50fb0d52828,refuted); 0.37478819950097642::status(o_0b56e6d4b50fb0d52828,unknown).
0::status(o_0bb25e513cc714113aa2,supported); 1::status(o_0bb25e513cc714113aa2,refuted); 0::status(o_0bb25e513cc714113aa2,unknown).
0.10388609021902084::status(o_0c90bca29a4e311111cd,supported); 0::status(o_0c90bca29a4e311111cd,refuted); 0.89611390978097916::status(o_0c90bca29a4e311111cd,unknown).
0.3336655695722176::status(o_0c9965e9d630899ba817,supported); 0::status(o_0c9965e9d630899ba817,refuted); 0.6663344304277824::status(o_0c9965e9d630899ba817,unknown).
1::status(o_0cd26ca4a5bc930651ec,supported); 0::status(o_0cd26ca4a5bc930651ec,refuted); 0::status(o_0cd26ca4a5bc930651ec,unknown).
0.2362430346122546::status(o_0cdfc050b594786a72a3,supported); 0::status(o_0cdfc050b594786a72a3,refuted); 0.7637569653877454::status(o_0cdfc050b594786a72a3,unknown).
0.976348876953125::status(o_0e48a0a360f3dd32a90e,supported); 0::status(o_0e48a0a360f3dd32a90e,refuted); 0.023651123046875::status(o_0e48a0a360f3dd32a90e,unknown).
0.59064883670199464::status(o_0efbd94f2fbf1b375633,supported); 0::status(o_0efbd94f2fbf1b375633,refuted); 0.40935116329800536::status(o_0efbd94f2fbf1b375633,unknown).
0.2133974062939846::status(o_1057b77d00153ef3b411,supported); 0::status(o_1057b77d00153ef3b411,refuted); 0.78660259370601537::status(o_1057b77d00153ef3b411,unknown).
0::status(o_1074e465ebfb67ae40c2,supported); 1::status(o_1074e465ebfb67ae40c2,refuted); 0::status(o_1074e465ebfb67ae40c2,unknown).
0::status(o_10915a9fda153071f95c,supported); 1::status(o_10915a9fda153071f95c,refuted); 0::status(o_10915a9fda153071f95c,unknown).
0.22909369395574933::status(o_10a8db2f2e7019906595,supported); 0::status(o_10a8db2f2e7019906595,refuted); 0.7709063060442507::status(o_10a8db2f2e7019906595,unknown).
1::status(o_112c56a5876082625cab,supported); 0::status(o_112c56a5876082625cab,refuted); 0::status(o_112c56a5876082625cab,unknown).
0::status(o_116556a461efcae85586,supported); 1::status(o_116556a461efcae85586,refuted); 0::status(o_116556a461efcae85586,unknown).
0.60295927359717438::status(o_116a6aa90f422b50ac59,supported); 0::status(o_116a6aa90f422b50ac59,refuted); 0.39704072640282562::status(o_116a6aa90f422b50ac59,unknown).
0::status(o_116cf17b18dcec48ebc4,supported); 1::status(o_116cf17b18dcec48ebc4,refuted); 0::status(o_116cf17b18dcec48ebc4,unknown).
0::status(o_12040c1eda66a2928b74,supported); 1::status(o_12040c1eda66a2928b74,refuted); 0::status(o_12040c1eda66a2928b74,unknown).
1::status(o_12a5d326e6f06090caa9,supported); 0::status(o_12a5d326e6f06090caa9,refuted); 0::status(o_12a5d326e6f06090caa9,unknown).
1::status(o_12cda33193bc97021ac5,supported); 0::status(o_12cda33193bc97021ac5,refuted); 0::status(o_12cda33193bc97021ac5,unknown).
1::status(o_1323d3792df5a3a36716,supported); 0::status(o_1323d3792df5a3a36716,refuted); 0::status(o_1323d3792df5a3a36716,unknown).
1::status(o_1398aa96f0a0ce1058ab,supported); 0::status(o_1398aa96f0a0ce1058ab,refuted); 0::status(o_1398aa96f0a0ce1058ab,unknown).
0.20066223274789757::status(o_14c281143258c71d61cf,supported); 0::status(o_14c281143258c71d61cf,refuted); 0.79933776725210248::status(o_14c281143258c71d61cf,unknown).
1::status(o_14fef005a694e0ee7732,supported); 0::status(o_14fef005a694e0ee7732,refuted); 0::status(o_14fef005a694e0ee7732,unknown).
0.24228181976937849::status(o_151613d849b42fc0def6,supported); 0::status(o_151613d849b42fc0def6,refuted); 0.75771818023062154::status(o_151613d849b42fc0def6,unknown).
0.60560096976815259::status(o_152f51e19cbe552645b1,supported); 0::status(o_152f51e19cbe552645b1,refuted); 0.39439903023184741::status(o_152f51e19cbe552645b1,unknown).
0.63097204530121542::status(o_15c705588fdbdd88fce7,supported); 0::status(o_15c705588fdbdd88fce7,refuted); 0.36902795469878458::status(o_15c705588fdbdd88fce7,unknown).
1::status(o_15cbdee1adc3cc0bb827,supported); 0::status(o_15cbdee1adc3cc0bb827,refuted); 0::status(o_15cbdee1adc3cc0bb827,unknown).
0.59064883670199464::status(o_15dd3003b07c3406c3d9,supported); 0::status(o_15dd3003b07c3406c3d9,refuted); 0.40935116329800536::status(o_15dd3003b07c3406c3d9,unknown).
0.0023976406082510948::status(o_1624fef7be7b0edbb259,supported); 0::status(o_1624fef7be7b0edbb259,refuted); 0.99760235939174891::status(o_1624fef7be7b0edbb259,unknown).
0.98706090450286865::status(o_1656c3e7ffe312946de8,supported); 0::status(o_1656c3e7ffe312946de8,refuted); 0.012939095497131348::status(o_1656c3e7ffe312946de8,unknown).
1::status(o_16ad8aedbec72e5f6d85,supported); 0::status(o_16ad8aedbec72e5f6d85,refuted); 0::status(o_16ad8aedbec72e5f6d85,unknown).
0.0029208550695329905::status(o_179d5f2131acb24ee0f8,supported); 0::status(o_179d5f2131acb24ee0f8,refuted); 0.99707914493046701::status(o_179d5f2131acb24ee0f8,unknown).
1::status(o_184dfd465f9165e3b445,supported); 0::status(o_184dfd465f9165e3b445,refuted); 0::status(o_184dfd465f9165e3b445,unknown).
1::status(o_186bead0f48e9193133f,supported); 0::status(o_186bead0f48e9193133f,refuted); 0::status(o_186bead0f48e9193133f,unknown).
0.00027939380379393697::status(o_1959c21204d936b7bb18,supported); 0::status(o_1959c21204d936b7bb18,refuted); 0.99972060619620606::status(o_1959c21204d936b7bb18,unknown).
0.32443726915540849::status(o_1a10759b6ce32873e5cc,supported); 0::status(o_1a10759b6ce32873e5cc,refuted); 0.67556273084459151::status(o_1a10759b6ce32873e5cc,unknown).
0.24287842070011395::status(o_1a4320445babc1ec7672,supported); 0::status(o_1a4320445babc1ec7672,refuted); 0.75712157929988599::status(o_1a4320445babc1ec7672,unknown).
0.19229594109113379::status(o_1ab9ae7073de465c322d,supported); 0::status(o_1ab9ae7073de465c322d,refuted); 0.80770405890886621::status(o_1ab9ae7073de465c322d,unknown).
0.48891161461378951::status(o_1ae7fd9f5588216a2256,supported); 0::status(o_1ae7fd9f5588216a2256,refuted); 0.51108838538621049::status(o_1ae7fd9f5588216a2256,unknown).
0::status(o_1b1423734fde71379068,supported); 1::status(o_1b1423734fde71379068,refuted); 0::status(o_1b1423734fde71379068,unknown).
0::status(o_1b90e36801a3fa33f344,supported); 1::status(o_1b90e36801a3fa33f344,refuted); 0::status(o_1b90e36801a3fa33f344,unknown).
1::status(o_1b9a463f96b4838dc620,supported); 0::status(o_1b9a463f96b4838dc620,refuted); 0::status(o_1b9a463f96b4838dc620,unknown).
1::status(o_1c48799d98d6ddb371fc,supported); 0::status(o_1c48799d98d6ddb371fc,refuted); 0::status(o_1c48799d98d6ddb371fc,unknown).
1::status(o_1c4d720ea7ef876005ef,supported); 0::status(o_1c4d720ea7ef876005ef,refuted); 0::status(o_1c4d720ea7ef876005ef,unknown).
1::status(o_1cdfcf4bd6b2a11ae04d,supported); 0::status(o_1cdfcf4bd6b2a11ae04d,refuted); 0::status(o_1cdfcf4bd6b2a11ae04d,unknown).
0::status(o_1cfdeb7ca9527102074f,supported); 1::status(o_1cfdeb7ca9527102074f,refuted); 0::status(o_1cfdeb7ca9527102074f,unknown).
7.9832112533040345e-05::status(o_1dae4fe2cf3e39a0b459,supported); 0::status(o_1dae4fe2cf3e39a0b459,refuted); 0.99992016788746696::status(o_1dae4fe2cf3e39a0b459,unknown).
0.3267414933664608::status(o_1df1b32830663bda55a1,supported); 0::status(o_1df1b32830663bda55a1,refuted); 0.67325850663353926::status(o_1df1b32830663bda55a1,unknown).
0.98928332328796387::status(o_1e30d3abfd6bc3fa23db,supported); 0::status(o_1e30d3abfd6bc3fa23db,refuted); 0.010716676712036133::status(o_1e30d3abfd6bc3fa23db,unknown).
0.69422269685182314::status(o_1ee7c863e0b340d611f7,supported); 0::status(o_1ee7c863e0b340d611f7,refuted); 0.30577730314817686::status(o_1ee7c863e0b340d611f7,unknown).
0::status(o_1fe0b77a2ad953872a1d,supported); 1::status(o_1fe0b77a2ad953872a1d,refuted); 0::status(o_1fe0b77a2ad953872a1d,unknown).
1::status(o_203f97a458cb512201d8,supported); 0::status(o_203f97a458cb512201d8,refuted); 0::status(o_203f97a458cb512201d8,unknown).
1::status(o_206c7645fd2a570c31b3,supported); 0::status(o_206c7645fd2a570c31b3,refuted); 0::status(o_206c7645fd2a570c31b3,unknown).
0.0001668355253059417::status(o_20a6b10f82f1bdb4116c,supported); 0::status(o_20a6b10f82f1bdb4116c,refuted); 0.99983316447469406::status(o_20a6b10f82f1bdb4116c,unknown).
0.00026651250664144754::status(o_21cbac8973411012256d,supported); 0::status(o_21cbac8973411012256d,refuted); 0.99973348749335855::status(o_21cbac8973411012256d,unknown).
1::status(o_220d684cb55d13711edb,supported); 0::status(o_220d684cb55d13711edb,refuted); 0::status(o_220d684cb55d13711edb,unknown).
1::status(o_2348673ae2c21fd301fa,supported); 0::status(o_2348673ae2c21fd301fa,refuted); 0::status(o_2348673ae2c21fd301fa,unknown).
0.17744335653387286::status(o_238947f1af294ba162d8,supported); 0::status(o_238947f1af294ba162d8,refuted); 0.82255664346612711::status(o_238947f1af294ba162d8,unknown).
0.039551112800836563::status(o_23c3b989771dd7b30fb1,supported); 0::status(o_23c3b989771dd7b30fb1,refuted); 0.96044888719916344::status(o_23c3b989771dd7b30fb1,unknown).
1::status(o_23d9abf97c7312e11c48,supported); 0::status(o_23d9abf97c7312e11c48,refuted); 0::status(o_23d9abf97c7312e11c48,unknown).
0.25839648013427508::status(o_23e3f5736d6b690880ce,supported); 0::status(o_23e3f5736d6b690880ce,refuted); 0.74160351986572492::status(o_23e3f5736d6b690880ce,unknown).
0.2791481798599636::status(o_2490396a075eca9e2a74,supported); 0::status(o_2490396a075eca9e2a74,refuted); 0.72085182014003646::status(o_2490396a075eca9e2a74,unknown).
0.002602787222713232::status(o_249ea1bc115028c1e037,supported); 0::status(o_249ea1bc115028c1e037,refuted); 0.99739721277728677::status(o_249ea1bc115028c1e037,unknown).
1::status(o_24a13cb94c06f178b089,supported); 0::status(o_24a13cb94c06f178b089,refuted); 0::status(o_24a13cb94c06f178b089,unknown).
0::status(o_25e747be1c2660bb459a,supported); 1::status(o_25e747be1c2660bb459a,refuted); 0::status(o_25e747be1c2660bb459a,unknown).
1::status(o_267b5b0b56834cb3c2f5,supported); 0::status(o_267b5b0b56834cb3c2f5,refuted); 0::status(o_267b5b0b56834cb3c2f5,unknown).
0.61694091558456421::status(o_270ed160e9bd874b468b,supported); 0::status(o_270ed160e9bd874b468b,refuted); 0.38305908441543579::status(o_270ed160e9bd874b468b,unknown).
0.13451996445655823::status(o_2766f5fcbb03d17fa84f,supported); 0::status(o_2766f5fcbb03d17fa84f,refuted); 0.86548003554344177::status(o_2766f5fcbb03d17fa84f,unknown).
0.99810886383056641::status(o_27ba79585d8586cc1136,supported); 0::status(o_27ba79585d8586cc1136,refuted); 0.0018911361694335938::status(o_27ba79585d8586cc1136,unknown).
0::status(o_28363b70e799e5f58c6c,supported); 1::status(o_28363b70e799e5f58c6c,refuted); 0::status(o_28363b70e799e5f58c6c,unknown).
0.00028077524621039629::status(o_289ed5d7dede9e57bf46,supported); 0::status(o_289ed5d7dede9e57bf46,refuted); 0.9997192247537896::status(o_289ed5d7dede9e57bf46,unknown).
0.00044824578799307346::status(o_2922fca11dca06c5894e,supported); 0::status(o_2922fca11dca06c5894e,refuted); 0.99955175421200693::status(o_2922fca11dca06c5894e,unknown).
0.24720217475481024::status(o_292b1b88c95cdf4698b3,supported); 0::status(o_292b1b88c95cdf4698b3,refuted); 0.75279782524518979::status(o_292b1b88c95cdf4698b3,unknown).
0.78545029701849134::status(o_297e59f156505592a4b0,supported); 0::status(o_297e59f156505592a4b0,refuted); 0.21454970298150866::status(o_297e59f156505592a4b0,unknown).
1::status(o_2a4b68297b2649f9b517,supported); 0::status(o_2a4b68297b2649f9b517,refuted); 0::status(o_2a4b68297b2649f9b517,unknown).
0::status(o_2a8d799d7c3ff2741d63,supported); 1::status(o_2a8d799d7c3ff2741d63,refuted); 0::status(o_2a8d799d7c3ff2741d63,unknown).
0::status(o_2b1db21bbc723dc42d7c,supported); 1::status(o_2b1db21bbc723dc42d7c,refuted); 0::status(o_2b1db21bbc723dc42d7c,unknown).
1::status(o_2bcf0f4261f6e40cc071,supported); 0::status(o_2bcf0f4261f6e40cc071,refuted); 0::status(o_2bcf0f4261f6e40cc071,unknown).
0.45078909333920353::status(o_2c392a06444f4cd5bd26,supported); 0::status(o_2c392a06444f4cd5bd26,refuted); 0.54921090666079642::status(o_2c392a06444f4cd5bd26,unknown).
0.19632613136466429::status(o_2c84bf08d2b036d66898,supported); 0::status(o_2c84bf08d2b036d66898,refuted); 0.80367386863533574::status(o_2c84bf08d2b036d66898,unknown).
0.99547606706619263::status(o_2d850f1da22f76248283,supported); 0::status(o_2d850f1da22f76248283,refuted); 0.004523932933807373::status(o_2d850f1da22f76248283,unknown).
1::status(o_2d96fc15d0de6148efc9,supported); 0::status(o_2d96fc15d0de6148efc9,refuted); 0::status(o_2d96fc15d0de6148efc9,unknown).
0::status(o_2dc8ba914e1f52414287,supported); 1::status(o_2dc8ba914e1f52414287,refuted); 0::status(o_2dc8ba914e1f52414287,unknown).
0.99726450443267822::status(o_2dd8d437c786e7f1c4f1,supported); 0::status(o_2dd8d437c786e7f1c4f1,refuted); 0.0027354955673217773::status(o_2dd8d437c786e7f1c4f1,unknown).
0.47045918946799326::status(o_2e976143865b741ab025,supported); 0::status(o_2e976143865b741ab025,refuted); 0.52954081053200674::status(o_2e976143865b741ab025,unknown).
0.22783341461938156::status(o_2f8672e418d2c4cb048a,supported); 0::status(o_2f8672e418d2c4cb048a,refuted); 0.77216658538061844::status(o_2f8672e418d2c4cb048a,unknown).
1::status(o_2f96c65a44127f6522c5,supported); 0::status(o_2f96c65a44127f6522c5,refuted); 0::status(o_2f96c65a44127f6522c5,unknown).
0.9814574122428894::status(o_3096b55322047d08483c,supported); 0::status(o_3096b55322047d08483c,refuted); 0.018542587757110596::status(o_3096b55322047d08483c,unknown).
0.00096308212960138917::status(o_309baf1c9fe60620599b,supported); 0::status(o_309baf1c9fe60620599b,refuted); 0.99903691787039861::status(o_309baf1c9fe60620599b,unknown).
0.0018071738304570317::status(o_30b058adc25f756c087b,supported); 0::status(o_30b058adc25f756c087b,refuted); 0.99819282616954297::status(o_30b058adc25f756c087b,unknown).
1::status(o_3123999d9cf307bca68b,supported); 0::status(o_3123999d9cf307bca68b,refuted); 0::status(o_3123999d9cf307bca68b,unknown).
0.00011525061563588679::status(o_318192354e832d2c844f,supported); 0::status(o_318192354e832d2c844f,refuted); 0.99988474938436411::status(o_318192354e832d2c844f,unknown).
0.00058511312818154693::status(o_3381c08b4d591e2913dd,supported); 0::status(o_3381c08b4d591e2913dd,refuted); 0.99941488687181845::status(o_3381c08b4d591e2913dd,unknown).
1::status(o_34150bb5f882b79c353c,supported); 0::status(o_34150bb5f882b79c353c,refuted); 0::status(o_34150bb5f882b79c353c,unknown).
0.0013882720377296209::status(o_352102850a6208f28228,supported); 0::status(o_352102850a6208f28228,refuted); 0.99861172796227038::status(o_352102850a6208f28228,unknown).
0.31907950101890964::status(o_359ff78e6704a5fbcafa,supported); 0::status(o_359ff78e6704a5fbcafa,refuted); 0.68092049898109042::status(o_359ff78e6704a5fbcafa,unknown).
1::status(o_35af888d6b2099f8d460,supported); 0::status(o_35af888d6b2099f8d460,refuted); 0::status(o_35af888d6b2099f8d460,unknown).
0.1501396967008444::status(o_36b2a1e1e14cb348ad04,supported); 0::status(o_36b2a1e1e14cb348ad04,refuted); 0.84986030329915563::status(o_36b2a1e1e14cb348ad04,unknown).
1::status(o_36b2dbd9f2bc80d0d708,supported); 0::status(o_36b2dbd9f2bc80d0d708,refuted); 0::status(o_36b2dbd9f2bc80d0d708,unknown).
0.021092737093567848::status(o_36e53627d4fe36d9d282,supported); 0::status(o_36e53627d4fe36d9d282,refuted); 0.97890726290643215::status(o_36e53627d4fe36d9d282,unknown).
0.0070033296942710876::status(o_3703f0e48dbff253ad64,supported); 0::status(o_3703f0e48dbff253ad64,refuted); 0.99299667030572891::status(o_3703f0e48dbff253ad64,unknown).
1::status(o_373177f9ba14320bdde9,supported); 0::status(o_373177f9ba14320bdde9,refuted); 0::status(o_373177f9ba14320bdde9,unknown).
0.64354465567556274::status(o_37d7ad41426bf255b761,supported); 0::status(o_37d7ad41426bf255b761,refuted); 0.35645534432443726::status(o_37d7ad41426bf255b761,unknown).
1::status(o_38815adad6c30f9b86b3,supported); 0::status(o_38815adad6c30f9b86b3,refuted); 0::status(o_38815adad6c30f9b86b3,unknown).
0.988739013671875::status(o_38aaedabf761c64ff28c,supported); 0::status(o_38aaedabf761c64ff28c,refuted); 0.011260986328125::status(o_38aaedabf761c64ff28c,unknown).
1::status(o_38e2ad15775b0f2959c8,supported); 0::status(o_38e2ad15775b0f2959c8,refuted); 0::status(o_38e2ad15775b0f2959c8,unknown).
0.61771134898671276::status(o_391054f01387a78474e4,supported); 0::status(o_391054f01387a78474e4,refuted); 0.38228865101328724::status(o_391054f01387a78474e4,unknown).
0.23105795662110934::status(o_3955123710d5107f611e,supported); 0::status(o_3955123710d5107f611e,refuted); 0.76894204337889072::status(o_3955123710d5107f611e,unknown).
0.003689546836540103::status(o_396fa5905bb77d9558a3,supported); 0::status(o_396fa5905bb77d9558a3,refuted); 0.9963104531634599::status(o_396fa5905bb77d9558a3,unknown).
1::status(o_399c116ba02245698e98,supported); 0::status(o_399c116ba02245698e98,refuted); 0::status(o_399c116ba02245698e98,unknown).
1::status(o_399e75495498d0ab2deb,supported); 0::status(o_399e75495498d0ab2deb,refuted); 0::status(o_399e75495498d0ab2deb,unknown).
1::status(o_39f3c00c33d2d06295a3,supported); 0::status(o_39f3c00c33d2d06295a3,refuted); 0::status(o_39f3c00c33d2d06295a3,unknown).
0.00063080125255510211::status(o_3a466d2fc15cf77dbf8b,supported); 0::status(o_3a466d2fc15cf77dbf8b,refuted); 0.9993691987474449::status(o_3a466d2fc15cf77dbf8b,unknown).
0.42721959904405776::status(o_3a60c8d2435113b637e6,supported); 0::status(o_3a60c8d2435113b637e6,refuted); 0.57278040095594229::status(o_3a60c8d2435113b637e6,unknown).
0.2766593005094688::status(o_3b0d9e9515285e6ea157,supported); 0::status(o_3b0d9e9515285e6ea157,refuted); 0.72334069949053115::status(o_3b0d9e9515285e6ea157,unknown).
0.096061237156391144::status(o_3b275837263ec2f1f5c2,supported); 0::status(o_3b275837263ec2f1f5c2,refuted); 0.90393876284360886::status(o_3b275837263ec2f1f5c2,unknown).
0.56019621807698294::status(o_3b5220bffac1abcbb055,supported); 0::status(o_3b5220bffac1abcbb055,refuted); 0.43980378192301706::status(o_3b5220bffac1abcbb055,unknown).
0::status(o_3b76e7cf5d023a1f892d,supported); 1::status(o_3b76e7cf5d023a1f892d,refuted); 0::status(o_3b76e7cf5d023a1f892d,unknown).
0.55604892172959974::status(o_3c78a94bc648b2496d91,supported); 0::status(o_3c78a94bc648b2496d91,refuted); 0.44395107827040026::status(o_3c78a94bc648b2496d91,unknown).
1::status(o_3d5e970a0f2d371e11f0,supported); 0::status(o_3d5e970a0f2d371e11f0,refuted); 0::status(o_3d5e970a0f2d371e11f0,unknown).
1::status(o_3e5b5ebb25c63596c8b9,supported); 0::status(o_3e5b5ebb25c63596c8b9,refuted); 0::status(o_3e5b5ebb25c63596c8b9,unknown).
1::status(o_3ebb7cc6fd3b9bf0da57,supported); 0::status(o_3ebb7cc6fd3b9bf0da57,refuted); 0::status(o_3ebb7cc6fd3b9bf0da57,unknown).
0::status(o_3ebfdaacc153b1aec974,supported); 1::status(o_3ebfdaacc153b1aec974,refuted); 0::status(o_3ebfdaacc153b1aec974,unknown).
1::status(o_3ef2af9e543b9aeb6785,supported); 0::status(o_3ef2af9e543b9aeb6785,refuted); 0::status(o_3ef2af9e543b9aeb6785,unknown).
0.5446169871586849::status(o_3f0a0d697ec759914a33,supported); 0::status(o_3f0a0d697ec759914a33,refuted); 0.4553830128413151::status(o_3f0a0d697ec759914a33,unknown).
0.60295927359717438::status(o_3f635067430d393e42dc,supported); 0::status(o_3f635067430d393e42dc,refuted); 0.39704072640282562::status(o_3f635067430d393e42dc,unknown).
1::status(o_40b6701dc274d888d09c,supported); 0::status(o_40b6701dc274d888d09c,refuted); 0::status(o_40b6701dc274d888d09c,unknown).
0.32439384632201973::status(o_4124816458cc7be7791d,supported); 0::status(o_4124816458cc7be7791d,refuted); 0.67560615367798027::status(o_4124816458cc7be7791d,unknown).
1::status(o_41b5df560211afc7c834,supported); 0::status(o_41b5df560211afc7c834,refuted); 0::status(o_41b5df560211afc7c834,unknown).
1::status(o_420ab2af0de775219296,supported); 0::status(o_420ab2af0de775219296,refuted); 0::status(o_420ab2af0de775219296,unknown).
0.62068403752941337::status(o_4367edc539cfc7d0475a,supported); 0::status(o_4367edc539cfc7d0475a,refuted); 0.37931596247058663::status(o_4367edc539cfc7d0475a,unknown).
0.32439384632201973::status(o_44618462cec09485859f,supported); 0::status(o_44618462cec09485859f,refuted); 0.67560615367798027::status(o_44618462cec09485859f,unknown).
0::status(o_44ccc51ad29ebcf095fa,supported); 1::status(o_44ccc51ad29ebcf095fa,refuted); 0::status(o_44ccc51ad29ebcf095fa,unknown).
0.64424905361761975::status(o_461ada905dff67f06def,supported); 0::status(o_461ada905dff67f06def,refuted); 0.35575094638238025::status(o_461ada905dff67f06def,unknown).
0.18355340419469587::status(o_464aecc4ce5a1844d124,supported); 0::status(o_464aecc4ce5a1844d124,refuted); 0.8164465958053041::status(o_464aecc4ce5a1844d124,unknown).
0.99794512987136841::status(o_467a6bf0b446f87730d3,supported); 0::status(o_467a6bf0b446f87730d3,refuted); 0.0020548701286315918::status(o_467a6bf0b446f87730d3,unknown).
1::status(o_468be3babf641307d972,supported); 0::status(o_468be3babf641307d972,refuted); 0::status(o_468be3babf641307d972,unknown).
0.67048180430993831::status(o_4693b80ef71d719f4d3e,supported); 0::status(o_4693b80ef71d719f4d3e,refuted); 0.32951819569006169::status(o_4693b80ef71d719f4d3e,unknown).
1::status(o_46fa8574cbc3841b84e1,supported); 0::status(o_46fa8574cbc3841b84e1,refuted); 0::status(o_46fa8574cbc3841b84e1,unknown).
1::status(o_487bf05f6123fea6f67b,supported); 0::status(o_487bf05f6123fea6f67b,refuted); 0::status(o_487bf05f6123fea6f67b,unknown).
0.26867974287424717::status(o_489efec430fd0fa66716,supported); 0::status(o_489efec430fd0fa66716,refuted); 0.73132025712575288::status(o_489efec430fd0fa66716,unknown).
0.52321884901376903::status(o_498b72a46f1580476d79,supported); 0::status(o_498b72a46f1580476d79,refuted); 0.47678115098623097::status(o_498b72a46f1580476d79,unknown).
0.4066462516784668::status(o_4abdbe95c42e70b6cdbb,supported); 0::status(o_4abdbe95c42e70b6cdbb,refuted); 0.5933537483215332::status(o_4abdbe95c42e70b6cdbb,unknown).
1::status(o_4bbe840db4065bfc6c84,supported); 0::status(o_4bbe840db4065bfc6c84,refuted); 0::status(o_4bbe840db4065bfc6c84,unknown).
1::status(o_4bd273288a69a1575e33,supported); 0::status(o_4bd273288a69a1575e33,refuted); 0::status(o_4bd273288a69a1575e33,unknown).
1::status(o_4c204b82679f5c16048c,supported); 0::status(o_4c204b82679f5c16048c,refuted); 0::status(o_4c204b82679f5c16048c,unknown).
1::status(o_4c34fc29dd7bd15ba929,supported); 0::status(o_4c34fc29dd7bd15ba929,refuted); 0::status(o_4c34fc29dd7bd15ba929,unknown).
0.59548482063864561::status(o_4c7d266e173cfd04fe2a,supported); 0::status(o_4c7d266e173cfd04fe2a,refuted); 0.40451517936135439::status(o_4c7d266e173cfd04fe2a,unknown).
1::status(o_4ccbe967e40edc2464d9,supported); 0::status(o_4ccbe967e40edc2464d9,refuted); 0::status(o_4ccbe967e40edc2464d9,unknown).
1::status(o_4d28b89477c7f6aea0c9,supported); 0::status(o_4d28b89477c7f6aea0c9,refuted); 0::status(o_4d28b89477c7f6aea0c9,unknown).
1::status(o_4d435abcbe591d662c5b,supported); 0::status(o_4d435abcbe591d662c5b,refuted); 0::status(o_4d435abcbe591d662c5b,unknown).
0.021092737093567848::status(o_4d902c8529fc6baca58e,supported); 0::status(o_4d902c8529fc6baca58e,refuted); 0.97890726290643215::status(o_4d902c8529fc6baca58e,unknown).
1::status(o_4dc336be9417dcfa6dd2,supported); 0::status(o_4dc336be9417dcfa6dd2,refuted); 0::status(o_4dc336be9417dcfa6dd2,unknown).
0.20063170880206746::status(o_4e3cfe1e783f7853fcf4,supported); 0::status(o_4e3cfe1e783f7853fcf4,refuted); 0.79936829119793251::status(o_4e3cfe1e783f7853fcf4,unknown).
1::status(o_4edcb702012cf5cd4928,supported); 0::status(o_4edcb702012cf5cd4928,refuted); 0::status(o_4edcb702012cf5cd4928,unknown).
0.02884664386510849::status(o_4f838aae2dddccf14152,supported); 0::status(o_4f838aae2dddccf14152,refuted); 0.97115335613489151::status(o_4f838aae2dddccf14152,unknown).
1::status(o_503ca5414c5c0df03060,supported); 0::status(o_503ca5414c5c0df03060,refuted); 0::status(o_503ca5414c5c0df03060,unknown).
0::status(o_50971347455099471fdc,supported); 1::status(o_50971347455099471fdc,refuted); 0::status(o_50971347455099471fdc,unknown).
0::status(o_50b819a41b5a1f8449e8,supported); 1::status(o_50b819a41b5a1f8449e8,refuted); 0::status(o_50b819a41b5a1f8449e8,unknown).
1::status(o_50ead26e45ebd4c332dc,supported); 0::status(o_50ead26e45ebd4c332dc,refuted); 0::status(o_50ead26e45ebd4c332dc,unknown).
1::status(o_510820d653cee6d3b321,supported); 0::status(o_510820d653cee6d3b321,refuted); 0::status(o_510820d653cee6d3b321,unknown).
0.99794512987136841::status(o_516021b852b3c39b4a39,supported); 0::status(o_516021b852b3c39b4a39,refuted); 0.0020548701286315918::status(o_516021b852b3c39b4a39,unknown).
0::status(o_51b7c3bed597455aec56,supported); 1::status(o_51b7c3bed597455aec56,refuted); 0::status(o_51b7c3bed597455aec56,unknown).
1::status(o_51c0fc64d79cad130828,supported); 0::status(o_51c0fc64d79cad130828,refuted); 0::status(o_51c0fc64d79cad130828,unknown).
1::status(o_5320cd848352bc38e08f,supported); 0::status(o_5320cd848352bc38e08f,refuted); 0::status(o_5320cd848352bc38e08f,unknown).
1::status(o_5335f2c044a5c453f1d3,supported); 0::status(o_5335f2c044a5c453f1d3,refuted); 0::status(o_5335f2c044a5c453f1d3,unknown).
0.0005490043549798429::status(o_533e9538d86e08d0687c,supported); 0::status(o_533e9538d86e08d0687c,refuted); 0.99945099564502016::status(o_533e9538d86e08d0687c,unknown).
0::status(o_547f458e637c4c57d2fc,supported); 1::status(o_547f458e637c4c57d2fc,refuted); 0::status(o_547f458e637c4c57d2fc,unknown).
0::status(o_554bfd6c154be204b5f6,supported); 1::status(o_554bfd6c154be204b5f6,refuted); 0::status(o_554bfd6c154be204b5f6,unknown).
0.0031784586608409882::status(o_55ad6c431d2f2e4f4dba,supported); 0::status(o_55ad6c431d2f2e4f4dba,refuted); 0.99682154133915901::status(o_55ad6c431d2f2e4f4dba,unknown).
1::status(o_56c8a19be2e2f94458c5,supported); 0::status(o_56c8a19be2e2f94458c5,refuted); 0::status(o_56c8a19be2e2f94458c5,unknown).
0::status(o_56e59f114d85ccbf37b4,supported); 1::status(o_56e59f114d85ccbf37b4,refuted); 0::status(o_56e59f114d85ccbf37b4,unknown).
0.091254428029060364::status(o_584b435ed4cfd0f7dedb,supported); 0::status(o_584b435ed4cfd0f7dedb,refuted); 0.90874557197093964::status(o_584b435ed4cfd0f7dedb,unknown).
1::status(o_58619889581c02348863,supported); 0::status(o_58619889581c02348863,refuted); 0::status(o_58619889581c02348863,unknown).
0.27334199875687309::status(o_58ae1cb619f437dd76c7,supported); 0::status(o_58ae1cb619f437dd76c7,refuted); 0.72665800124312696::status(o_58ae1cb619f437dd76c7,unknown).
0.99524873495101929::status(o_5a4107cc4ed2530df561,supported); 0::status(o_5a4107cc4ed2530df561,refuted); 0.0047512650489807129::status(o_5a4107cc4ed2530df561,unknown).
5.6373784900642931e-05::status(o_5b06b30206d25196f22d,supported); 0::status(o_5b06b30206d25196f22d,refuted); 0.99994362621509936::status(o_5b06b30206d25196f22d,unknown).
0.22783341461938156::status(o_5ba37f7ae93210d01b8d,supported); 0::status(o_5ba37f7ae93210d01b8d,refuted); 0.77216658538061844::status(o_5ba37f7ae93210d01b8d,unknown).
0.97427183389663696::status(o_5ba8da655c850e0036e8,supported); 0::status(o_5ba8da655c850e0036e8,refuted); 0.025728166103363037::status(o_5ba8da655c850e0036e8,unknown).
0.71475537349000173::status(o_5cf58a7b7b034e427bcc,supported); 0::status(o_5cf58a7b7b034e427bcc,refuted); 0.28524462650999827::status(o_5cf58a7b7b034e427bcc,unknown).
0.003883931552991271::status(o_5d1219a9d345299a68a6,supported); 0::status(o_5d1219a9d345299a68a6,refuted); 0.99611606844700873::status(o_5d1219a9d345299a68a6,unknown).
0.6157456622530415::status(o_5d899fd43466722082ff,supported); 0::status(o_5d899fd43466722082ff,refuted); 0.3842543377469585::status(o_5d899fd43466722082ff,unknown).
0.00012811402848456055::status(o_5dcf2050f78a23e17baa,supported); 0::status(o_5dcf2050f78a23e17baa,refuted); 0.99987188597151544::status(o_5dcf2050f78a23e17baa,unknown).
1::status(o_5ddedab498303c96e83a,supported); 0::status(o_5ddedab498303c96e83a,refuted); 0::status(o_5ddedab498303c96e83a,unknown).
0.0007167395087890327::status(o_5de500d84c14aa36d180,supported); 0::status(o_5de500d84c14aa36d180,refuted); 0.99928326049121097::status(o_5de500d84c14aa36d180,unknown).
0.63310902975620786::status(o_5e2eb1f02e2acf62a86d,supported); 0::status(o_5e2eb1f02e2acf62a86d,refuted); 0.36689097024379214::status(o_5e2eb1f02e2acf62a86d,unknown).
1::status(o_5e492fe8162d57aadf78,supported); 0::status(o_5e492fe8162d57aadf78,refuted); 0::status(o_5e492fe8162d57aadf78,unknown).
0.0016958331689238548::status(o_5ea03014ecb5e885f832,supported); 0::status(o_5ea03014ecb5e885f832,refuted); 0.99830416683107615::status(o_5ea03014ecb5e885f832,unknown).
1::status(o_5ed964c5cb9a7faefe37,supported); 0::status(o_5ed964c5cb9a7faefe37,refuted); 0::status(o_5ed964c5cb9a7faefe37,unknown).
0.69321541940515385::status(o_5f28285bb8f6675ce263,supported); 0::status(o_5f28285bb8f6675ce263,refuted); 0.30678458059484615::status(o_5f28285bb8f6675ce263,unknown).
1::status(o_5fecb3b1ecec92f01d33,supported); 0::status(o_5fecb3b1ecec92f01d33,refuted); 0::status(o_5fecb3b1ecec92f01d33,unknown).
0.98928332328796387::status(o_60cd1e3d78ad39dacf25,supported); 0::status(o_60cd1e3d78ad39dacf25,refuted); 0.010716676712036133::status(o_60cd1e3d78ad39dacf25,unknown).
0.00019939233607146889::status(o_60f4d140724633210c01,supported); 0::status(o_60f4d140724633210c01,refuted); 0.99980060766392853::status(o_60f4d140724633210c01,unknown).
0.00038813083665445447::status(o_621dfc36926a9e5fbfde,supported); 0::status(o_621dfc36926a9e5fbfde,refuted); 0.99961186916334555::status(o_621dfc36926a9e5fbfde,unknown).
1::status(o_62344e839b3bb75a04d6,supported); 0::status(o_62344e839b3bb75a04d6,refuted); 0::status(o_62344e839b3bb75a04d6,unknown).
0.72930726178536853::status(o_624ffa0d0bd1f7f92cd4,supported); 0::status(o_624ffa0d0bd1f7f92cd4,refuted); 0.27069273821463147::status(o_624ffa0d0bd1f7f92cd4,unknown).
1::status(o_626b65d31b3b92b99320,supported); 0::status(o_626b65d31b3b92b99320,refuted); 0::status(o_626b65d31b3b92b99320,unknown).
1::status(o_62af9e58173e39eba6d3,supported); 0::status(o_62af9e58173e39eba6d3,refuted); 0::status(o_62af9e58173e39eba6d3,unknown).
0::status(o_6393e12e124c3ee350f1,supported); 1::status(o_6393e12e124c3ee350f1,refuted); 0::status(o_6393e12e124c3ee350f1,unknown).
1::status(o_6450ff128c268e222c8b,supported); 0::status(o_6450ff128c268e222c8b,refuted); 0::status(o_6450ff128c268e222c8b,unknown).
0.099834618680556958::status(o_6532d7ec3efa3f8c6015,supported); 0::status(o_6532d7ec3efa3f8c6015,refuted); 0.90016538131944301::status(o_6532d7ec3efa3f8c6015,unknown).
1::status(o_658e7851d79c344f94da,supported); 0::status(o_658e7851d79c344f94da,refuted); 0::status(o_658e7851d79c344f94da,unknown).
1::status(o_66bd7d087c86af0550dd,supported); 0::status(o_66bd7d087c86af0550dd,refuted); 0::status(o_66bd7d087c86af0550dd,unknown).
1::status(o_673fee03e493346b746e,supported); 0::status(o_673fee03e493346b746e,refuted); 0::status(o_673fee03e493346b746e,unknown).
1::status(o_67476fac70e4de2de21c,supported); 0::status(o_67476fac70e4de2de21c,refuted); 0::status(o_67476fac70e4de2de21c,unknown).
1::status(o_692fa001f5cd3238473a,supported); 0::status(o_692fa001f5cd3238473a,refuted); 0::status(o_692fa001f5cd3238473a,unknown).
0.98721271753311157::status(o_69ab1a8196e6ce11ec89,supported); 0::status(o_69ab1a8196e6ce11ec89,refuted); 0.012787282466888428::status(o_69ab1a8196e6ce11ec89,unknown).
1::status(o_6a5e555e4daa7914c677,supported); 0::status(o_6a5e555e4daa7914c677,refuted); 0::status(o_6a5e555e4daa7914c677,unknown).
1::status(o_6accc46dc260687c5818,supported); 0::status(o_6accc46dc260687c5818,refuted); 0::status(o_6accc46dc260687c5818,unknown).
0.99506652355194092::status(o_6b16873a1dc74e54c5dd,supported); 0::status(o_6b16873a1dc74e54c5dd,refuted); 0.004933476448059082::status(o_6b16873a1dc74e54c5dd,unknown).
0.988739013671875::status(o_6ba663ee66a3a824c2c2,supported); 0::status(o_6ba663ee66a3a824c2c2,refuted); 0.011260986328125::status(o_6ba663ee66a3a824c2c2,unknown).
0.00085279322229325771::status(o_6c93acc7924c8be4cfd6,supported); 0::status(o_6c93acc7924c8be4cfd6,refuted); 0.99914720677770674::status(o_6c93acc7924c8be4cfd6,unknown).
0.17908329447327972::status(o_6cff6c9209477777094e,supported); 0::status(o_6cff6c9209477777094e,refuted); 0.82091670552672025::status(o_6cff6c9209477777094e,unknown).
1::status(o_6d1b54fe5d1ae2c36c58,supported); 0::status(o_6d1b54fe5d1ae2c36c58,refuted); 0::status(o_6d1b54fe5d1ae2c36c58,unknown).
0.2589945870564957::status(o_6d1c86657356599bbb62,supported); 0::status(o_6d1c86657356599bbb62,refuted); 0.7410054129435043::status(o_6d1c86657356599bbb62,unknown).
0.00044824578799307346::status(o_6d34ed7be83f472c3061,supported); 0::status(o_6d34ed7be83f472c3061,refuted); 0.99955175421200693::status(o_6d34ed7be83f472c3061,unknown).
1::status(o_6e2294cf3b1f0eb8808f,supported); 0::status(o_6e2294cf3b1f0eb8808f,refuted); 0::status(o_6e2294cf3b1f0eb8808f,unknown).
0.00022408674703910947::status(o_6e30eb83c838330d2c4b,supported); 0::status(o_6e30eb83c838330d2c4b,refuted); 0.99977591325296089::status(o_6e30eb83c838330d2c4b,unknown).
1::status(o_6e62e3e89e4305da18d4,supported); 0::status(o_6e62e3e89e4305da18d4,refuted); 0::status(o_6e62e3e89e4305da18d4,unknown).
1::status(o_6eee66a36d1bfc59e677,supported); 0::status(o_6eee66a36d1bfc59e677,refuted); 0::status(o_6eee66a36d1bfc59e677,unknown).
0::status(o_6f0f32e8b6895343eeb1,supported); 1::status(o_6f0f32e8b6895343eeb1,refuted); 0::status(o_6f0f32e8b6895343eeb1,unknown).
1::status(o_6fe268939122920fc664,supported); 0::status(o_6fe268939122920fc664,refuted); 0::status(o_6fe268939122920fc664,unknown).
0.64354465567556274::status(o_70b9ee27084195915155,supported); 0::status(o_70b9ee27084195915155,refuted); 0.35645534432443726::status(o_70b9ee27084195915155,unknown).
0::status(o_7158d7fcec3492c63471,supported); 1::status(o_7158d7fcec3492c63471,refuted); 0::status(o_7158d7fcec3492c63471,unknown).
1::status(o_71d43d1c4404a38ce2d3,supported); 0::status(o_71d43d1c4404a38ce2d3,refuted); 0::status(o_71d43d1c4404a38ce2d3,unknown).
1::status(o_71dc0665a3dd07e090d4,supported); 0::status(o_71dc0665a3dd07e090d4,refuted); 0::status(o_71dc0665a3dd07e090d4,unknown).
0.00019939233607146889::status(o_71dc35bc325aa3663e39,supported); 0::status(o_71dc35bc325aa3663e39,refuted); 0.99980060766392853::status(o_71dc35bc325aa3663e39,unknown).
0.49817322870543185::status(o_729d639a8e4320e8ebe8,supported); 0::status(o_729d639a8e4320e8ebe8,refuted); 0.5018267712945681::status(o_729d639a8e4320e8ebe8,unknown).
0.0024758365470916033::status(o_72b91ad6971397c1f622,supported); 0::status(o_72b91ad6971397c1f622,refuted); 0.9975241634529084::status(o_72b91ad6971397c1f622,unknown).
1::status(o_7382abb16ee50d667551,supported); 0::status(o_7382abb16ee50d667551,refuted); 0::status(o_7382abb16ee50d667551,unknown).
1::status(o_74607d141de396bc1302,supported); 0::status(o_74607d141de396bc1302,refuted); 0::status(o_74607d141de396bc1302,unknown).
0.3267414933664608::status(o_750272459a32718c5ba1,supported); 0::status(o_750272459a32718c5ba1,refuted); 0.67325850663353926::status(o_750272459a32718c5ba1,unknown).
0.00035556388320401311::status(o_753e010ec4f8d2aa3097,supported); 0::status(o_753e010ec4f8d2aa3097,refuted); 0.99964443611679599::status(o_753e010ec4f8d2aa3097,unknown).
0.017168149352073669::status(o_7596a40616fd56b8ea9e,supported); 0::status(o_7596a40616fd56b8ea9e,refuted); 0.98283185064792633::status(o_7596a40616fd56b8ea9e,unknown).
0.00027316782507114112::status(o_759afe6441f2303c28b6,supported); 0::status(o_759afe6441f2303c28b6,refuted); 0.99972683217492886::status(o_759afe6441f2303c28b6,unknown).
0.69422269685182314::status(o_765c3babdecde637c01f,supported); 0::status(o_765c3babdecde637c01f,refuted); 0.30577730314817686::status(o_765c3babdecde637c01f,unknown).
1::status(o_7664e13e53630bb96e10,supported); 0::status(o_7664e13e53630bb96e10,refuted); 0::status(o_7664e13e53630bb96e10,unknown).
0.56114206596813354::status(o_78545cbec07cdef331fb,supported); 0::status(o_78545cbec07cdef331fb,refuted); 0.43885793403186646::status(o_78545cbec07cdef331fb,unknown).
1::status(o_78ea6efaa4bd8715a358,supported); 0::status(o_78ea6efaa4bd8715a358,refuted); 0::status(o_78ea6efaa4bd8715a358,unknown).
2.2375324988388456e-05::status(o_7932a9e3c3cff51e4d66,supported); 0::status(o_7932a9e3c3cff51e4d66,refuted); 0.99997762467501161::status(o_7932a9e3c3cff51e4d66,unknown).
1::status(o_7a358bd719284660b76c,supported); 0::status(o_7a358bd719284660b76c,refuted); 0::status(o_7a358bd719284660b76c,unknown).
0.00062835169956088066::status(o_7a797b663c4aec95363b,supported); 0::status(o_7a797b663c4aec95363b,refuted); 0.99937164830043912::status(o_7a797b663c4aec95363b,unknown).
0.15453670094831037::status(o_7ab054b366cbc1de9ae0,supported); 0::status(o_7ab054b366cbc1de9ae0,refuted); 0.8454632990516896::status(o_7ab054b366cbc1de9ae0,unknown).
1::status(o_7ab202ac62c8fdee8969,supported); 0::status(o_7ab202ac62c8fdee8969,refuted); 0::status(o_7ab202ac62c8fdee8969,unknown).
1::status(o_7b3b724da1e045bcfdf5,supported); 0::status(o_7b3b724da1e045bcfdf5,refuted); 0::status(o_7b3b724da1e045bcfdf5,unknown).
1::status(o_7b689f0c8711deefb48b,supported); 0::status(o_7b689f0c8711deefb48b,refuted); 0::status(o_7b689f0c8711deefb48b,unknown).
1::status(o_7cb182bee4bd6aa25d27,supported); 0::status(o_7cb182bee4bd6aa25d27,refuted); 0::status(o_7cb182bee4bd6aa25d27,unknown).
0.71475537349000173::status(o_7d76d0e158ae641f79a7,supported); 0::status(o_7d76d0e158ae641f79a7,refuted); 0.28524462650999827::status(o_7d76d0e158ae641f79a7,unknown).
0::status(o_7dadf53904ba4c0f227a,supported); 1::status(o_7dadf53904ba4c0f227a,refuted); 0::status(o_7dadf53904ba4c0f227a,unknown).
1::status(o_7e140e58dcd1ffabe966,supported); 0::status(o_7e140e58dcd1ffabe966,refuted); 0::status(o_7e140e58dcd1ffabe966,unknown).
0.22048295676347288::status(o_7e470dd82029c2c3181b,supported); 0::status(o_7e470dd82029c2c3181b,refuted); 0.77951704323652715::status(o_7e470dd82029c2c3181b,unknown).
9.0030916908290237e-05::status(o_7e6d1e9d390d01146f61,supported); 0::status(o_7e6d1e9d390d01146f61,refuted); 0.99990996908309171::status(o_7e6d1e9d390d01146f61,unknown).
0.0060226605273783207::status(o_7eedce19a0d8caee91bd,supported); 0::status(o_7eedce19a0d8caee91bd,refuted); 0.99397733947262168::status(o_7eedce19a0d8caee91bd,unknown).
1::status(o_7eee86f9ab30f79637a5,supported); 0::status(o_7eee86f9ab30f79637a5,refuted); 0::status(o_7eee86f9ab30f79637a5,unknown).
0.99506819248199463::status(o_7f434f93751d75eba66f,supported); 0::status(o_7f434f93751d75eba66f,refuted); 0.0049318075180053711::status(o_7f434f93751d75eba66f,unknown).
1::status(o_813c68fa7c9f6f54e2f9,supported); 0::status(o_813c68fa7c9f6f54e2f9,refuted); 0::status(o_813c68fa7c9f6f54e2f9,unknown).
1::status(o_8147183eb3fc7c8faf4d,supported); 0::status(o_8147183eb3fc7c8faf4d,refuted); 0::status(o_8147183eb3fc7c8faf4d,unknown).
4.2283380025764927e-05::status(o_815231a2d896d5b78c95,supported); 0::status(o_815231a2d896d5b78c95,refuted); 0.99995771661997424::status(o_815231a2d896d5b78c95,unknown).
1::status(o_8170d8aba1e36f3532f4,supported); 0::status(o_8170d8aba1e36f3532f4,refuted); 0::status(o_8170d8aba1e36f3532f4,unknown).
0.42259186025700812::status(o_81b70f7fd49741508db9,supported); 0::status(o_81b70f7fd49741508db9,refuted); 0.57740813974299188::status(o_81b70f7fd49741508db9,unknown).
0::status(o_8245c9557609075d1254,supported); 1::status(o_8245c9557609075d1254,refuted); 0::status(o_8245c9557609075d1254,unknown).
0::status(o_8279128e56b6913bde0e,supported); 1::status(o_8279128e56b6913bde0e,refuted); 0::status(o_8279128e56b6913bde0e,unknown).
0.67014139818444596::status(o_82a4042b418ec673ede4,supported); 0::status(o_82a4042b418ec673ede4,refuted); 0.32985860181555404::status(o_82a4042b418ec673ede4,unknown).
1::status(o_82bbd48a4f6e398a8bed,supported); 0::status(o_82bbd48a4f6e398a8bed,refuted); 0::status(o_82bbd48a4f6e398a8bed,unknown).
0.20453299792886978::status(o_82e4c8c1d9640cc8f6dc,supported); 0::status(o_82e4c8c1d9640cc8f6dc,refuted); 0.79546700207113019::status(o_82e4c8c1d9640cc8f6dc,unknown).
0.99506819248199463::status(o_831e848ea1787e7f0d40,supported); 0::status(o_831e848ea1787e7f0d40,refuted); 0.0049318075180053711::status(o_831e848ea1787e7f0d40,unknown).
0.00011422050738474354::status(o_837bc04c8c3e200fc177,supported); 0::status(o_837bc04c8c3e200fc177,refuted); 0.99988577949261526::status(o_837bc04c8c3e200fc177,unknown).
1::status(o_83d936f13cdca3e59e6c,supported); 0::status(o_83d936f13cdca3e59e6c,refuted); 0::status(o_83d936f13cdca3e59e6c,unknown).
1::status(o_847be245a2f62b39c3e8,supported); 0::status(o_847be245a2f62b39c3e8,refuted); 0::status(o_847be245a2f62b39c3e8,unknown).
0.40917093839253943::status(o_84faafa5cb57bea66a95,supported); 0::status(o_84faafa5cb57bea66a95,refuted); 0.59082906160746052::status(o_84faafa5cb57bea66a95,unknown).
0.99007987976074219::status(o_853da64aa4711d55ca21,supported); 0::status(o_853da64aa4711d55ca21,refuted); 0.0099201202392578125::status(o_853da64aa4711d55ca21,unknown).
0.096061237156391144::status(o_863ed4e97bf651e1e44c,supported); 0::status(o_863ed4e97bf651e1e44c,refuted); 0.90393876284360886::status(o_863ed4e97bf651e1e44c,unknown).
0.96754372119903564::status(o_8649ee2b8fb56fa387a2,supported); 0::status(o_8649ee2b8fb56fa387a2,refuted); 0.032456278800964355::status(o_8649ee2b8fb56fa387a2,unknown).
1::status(o_8651aa1952cad480cf99,supported); 0::status(o_8651aa1952cad480cf99,refuted); 0::status(o_8651aa1952cad480cf99,unknown).
0.0050932755693793297::status(o_8705912f65db6960a7da,supported); 0::status(o_8705912f65db6960a7da,refuted); 0.99490672443062067::status(o_8705912f65db6960a7da,unknown).
0.22309549152851105::status(o_87c6f779d2bf9d67f12f,supported); 0::status(o_87c6f779d2bf9d67f12f,refuted); 0.77690450847148895::status(o_87c6f779d2bf9d67f12f,unknown).
1::status(o_88312bff917834c6249f,supported); 0::status(o_88312bff917834c6249f,refuted); 0::status(o_88312bff917834c6249f,unknown).
1::status(o_8879f1449daf661265ba,supported); 0::status(o_8879f1449daf661265ba,refuted); 0::status(o_8879f1449daf661265ba,unknown).
1::status(o_88a8f4560471ac7e3f57,supported); 0::status(o_88a8f4560471ac7e3f57,refuted); 0::status(o_88a8f4560471ac7e3f57,unknown).
0.001097465050406754::status(o_89606d816f92de7028e9,supported); 0::status(o_89606d816f92de7028e9,refuted); 0.99890253494959325::status(o_89606d816f92de7028e9,unknown).
1::status(o_8990b558b754924c8135,supported); 0::status(o_8990b558b754924c8135,refuted); 0::status(o_8990b558b754924c8135,unknown).
1::status(o_899f6d1e9971d66ff22a,supported); 0::status(o_899f6d1e9971d66ff22a,refuted); 0::status(o_899f6d1e9971d66ff22a,unknown).
1::status(o_8a26b3ed952a1c4018b0,supported); 0::status(o_8a26b3ed952a1c4018b0,refuted); 0::status(o_8a26b3ed952a1c4018b0,unknown).
1::status(o_8ad74737af466d05ed74,supported); 0::status(o_8ad74737af466d05ed74,refuted); 0::status(o_8ad74737af466d05ed74,unknown).
0.56199225726309787::status(o_8b2e8ab5d0ad3a3f0943,supported); 0::status(o_8b2e8ab5d0ad3a3f0943,refuted); 0.43800774273690213::status(o_8b2e8ab5d0ad3a3f0943,unknown).
0.0004814279091078788::status(o_8bbb40edd8fdd15f34b1,supported); 0::status(o_8bbb40edd8fdd15f34b1,refuted); 0.99951857209089212::status(o_8bbb40edd8fdd15f34b1,unknown).
0.1732276127250354::status(o_8bdfa29d3cfe545d6aa5,supported); 0::status(o_8bdfa29d3cfe545d6aa5,refuted); 0.8267723872749646::status(o_8bdfa29d3cfe545d6aa5,unknown).
1::status(o_8bf56445f49d06603852,supported); 0::status(o_8bf56445f49d06603852,refuted); 0::status(o_8bf56445f49d06603852,unknown).
0::status(o_8c0e46800b777240f572,supported); 1::status(o_8c0e46800b777240f572,refuted); 0::status(o_8c0e46800b777240f572,unknown).
0.0010018589673563838::status(o_8dd5253489bebc0b1eaa,supported); 0::status(o_8dd5253489bebc0b1eaa,refuted); 0.99899814103264362::status(o_8dd5253489bebc0b1eaa,unknown).
0::status(o_8e82df60feb90809d347,supported); 1::status(o_8e82df60feb90809d347,refuted); 0::status(o_8e82df60feb90809d347,unknown).
1::status(o_8fbff6ccea84adc7ed12,supported); 0::status(o_8fbff6ccea84adc7ed12,refuted); 0::status(o_8fbff6ccea84adc7ed12,unknown).
1::status(o_903d3c5d25ed624913ca,supported); 0::status(o_903d3c5d25ed624913ca,refuted); 0::status(o_903d3c5d25ed624913ca,unknown).
1::status(o_90b2e6464fe6a7762bc5,supported); 0::status(o_90b2e6464fe6a7762bc5,refuted); 0::status(o_90b2e6464fe6a7762bc5,unknown).
0.99738341569900513::status(o_91ef6f91fb3a040e1388,supported); 0::status(o_91ef6f91fb3a040e1388,refuted); 0.002616584300994873::status(o_91ef6f91fb3a040e1388,unknown).
1::status(o_91f192664ecf4a3fba34,supported); 0::status(o_91f192664ecf4a3fba34,refuted); 0::status(o_91f192664ecf4a3fba34,unknown).
0.17949568202229413::status(o_93a517dea00ddf3bb51f,supported); 0::status(o_93a517dea00ddf3bb51f,refuted); 0.82050431797770584::status(o_93a517dea00ddf3bb51f,unknown).
0.35481984999927751::status(o_93df643ed94feb17640f,supported); 0::status(o_93df643ed94feb17640f,refuted); 0.64518015000072249::status(o_93df643ed94feb17640f,unknown).
1::status(o_94899b7b31651c05575e,supported); 0::status(o_94899b7b31651c05575e,refuted); 0::status(o_94899b7b31651c05575e,unknown).
0.6027421409056315::status(o_94f261b8fa32bc37ab16,supported); 0::status(o_94f261b8fa32bc37ab16,refuted); 0.3972578590943685::status(o_94f261b8fa32bc37ab16,unknown).
1::status(o_94f6be4ebb1742c9b932,supported); 0::status(o_94f6be4ebb1742c9b932,refuted); 0::status(o_94f6be4ebb1742c9b932,unknown).
1::status(o_94f99dcbc4a137dbb4df,supported); 0::status(o_94f99dcbc4a137dbb4df,refuted); 0::status(o_94f99dcbc4a137dbb4df,unknown).
1::status(o_95009ef7d75cf3937cb7,supported); 0::status(o_95009ef7d75cf3937cb7,refuted); 0::status(o_95009ef7d75cf3937cb7,unknown).
1::status(o_95082c8251807b896d1e,supported); 0::status(o_95082c8251807b896d1e,refuted); 0::status(o_95082c8251807b896d1e,unknown).
0.99007987976074219::status(o_9587f71948ac3e900a38,supported); 0::status(o_9587f71948ac3e900a38,refuted); 0.0099201202392578125::status(o_9587f71948ac3e900a38,unknown).
0.51267369618544434::status(o_96069de593c1d7fdae19,supported); 0::status(o_96069de593c1d7fdae19,refuted); 0.48732630381455566::status(o_96069de593c1d7fdae19,unknown).
0.17266773513180428::status(o_96102c5d08ec4802912a,supported); 0::status(o_96102c5d08ec4802912a,refuted); 0.82733226486819578::status(o_96102c5d08ec4802912a,unknown).
1::status(o_96167a7123b6c2e9f0ec,supported); 0::status(o_96167a7123b6c2e9f0ec,refuted); 0::status(o_96167a7123b6c2e9f0ec,unknown).
0.60430598979781869::status(o_9773d5107f8b856a1adb,supported); 0::status(o_9773d5107f8b856a1adb,refuted); 0.39569401020218131::status(o_9773d5107f8b856a1adb,unknown).
1::status(o_979841b6f049d5e81c68,supported); 0::status(o_979841b6f049d5e81c68,refuted); 0::status(o_979841b6f049d5e81c68,unknown).
1::status(o_97ea8e2ea18d65f02c6a,supported); 0::status(o_97ea8e2ea18d65f02c6a,refuted); 0::status(o_97ea8e2ea18d65f02c6a,unknown).
1::status(o_9805547594a986be76df,supported); 0::status(o_9805547594a986be76df,refuted); 0::status(o_9805547594a986be76df,unknown).
1::status(o_9818e77fc95dc64d61a3,supported); 0::status(o_9818e77fc95dc64d61a3,refuted); 0::status(o_9818e77fc95dc64d61a3,unknown).
0.56174170970916748::status(o_98225b54cc668445b322,supported); 0::status(o_98225b54cc668445b322,refuted); 0.43825829029083252::status(o_98225b54cc668445b322,unknown).
0.99547606706619263::status(o_9826c61f999beb568501,supported); 0::status(o_9826c61f999beb568501,refuted); 0.004523932933807373::status(o_9826c61f999beb568501,unknown).
0.002602787222713232::status(o_985e32de6cb09ac4b4a6,supported); 0::status(o_985e32de6cb09ac4b4a6,refuted); 0.99739721277728677::status(o_985e32de6cb09ac4b4a6,unknown).
0.41286338869577466::status(o_986a15a0a84721a1f9b5,supported); 0::status(o_986a15a0a84721a1f9b5,refuted); 0.58713661130422534::status(o_986a15a0a84721a1f9b5,unknown).
0.99738341569900513::status(o_987ef028bb2406b4f5ef,supported); 0::status(o_987ef028bb2406b4f5ef,refuted); 0.002616584300994873::status(o_987ef028bb2406b4f5ef,unknown).
1::status(o_98db8628004b5feefd23,supported); 0::status(o_98db8628004b5feefd23,refuted); 0::status(o_98db8628004b5feefd23,unknown).
0.17620717593138152::status(o_99bef5e590b9a7457e9d,supported); 0::status(o_99bef5e590b9a7457e9d,refuted); 0.82379282406861853::status(o_99bef5e590b9a7457e9d,unknown).
1::status(o_9b0c16661c9475878347,supported); 0::status(o_9b0c16661c9475878347,refuted); 0::status(o_9b0c16661c9475878347,unknown).
0.22048295676347288::status(o_9b2ba101eedc382abc28,supported); 0::status(o_9b2ba101eedc382abc28,refuted); 0.77951704323652715::status(o_9b2ba101eedc382abc28,unknown).
1::status(o_9be155994cd0a4efa5f1,supported); 0::status(o_9be155994cd0a4efa5f1,refuted); 0::status(o_9be155994cd0a4efa5f1,unknown).
0.72335165686353298::status(o_9c8bfa8f1f3de7e45ace,supported); 0::status(o_9c8bfa8f1f3de7e45ace,refuted); 0.27664834313646702::status(o_9c8bfa8f1f3de7e45ace,unknown).
0.0042693153955042362::status(o_9c996d0d25ffc6722380,supported); 0::status(o_9c996d0d25ffc6722380,refuted); 0.99573068460449576::status(o_9c996d0d25ffc6722380,unknown).
1::status(o_9d214bcfea904b0f2580,supported); 0::status(o_9d214bcfea904b0f2580,refuted); 0::status(o_9d214bcfea904b0f2580,unknown).
0.96754372119903564::status(o_9da1edaecfe98641b294,supported); 0::status(o_9da1edaecfe98641b294,refuted); 0.032456278800964355::status(o_9da1edaecfe98641b294,unknown).
1::status(o_9e597c41be33369f1ca2,supported); 0::status(o_9e597c41be33369f1ca2,refuted); 0::status(o_9e597c41be33369f1ca2,unknown).
1::status(o_9e7c08cf4d93d74ef9cc,supported); 0::status(o_9e7c08cf4d93d74ef9cc,refuted); 0::status(o_9e7c08cf4d93d74ef9cc,unknown).
1::status(o_9ee589f86c1d037995ef,supported); 0::status(o_9ee589f86c1d037995ef,refuted); 0::status(o_9ee589f86c1d037995ef,unknown).
1::status(o_9ef7603bd61a3cd1162b,supported); 0::status(o_9ef7603bd61a3cd1162b,refuted); 0::status(o_9ef7603bd61a3cd1162b,unknown).
0::status(o_9f3628d5487121818b7e,supported); 1::status(o_9f3628d5487121818b7e,refuted); 0::status(o_9f3628d5487121818b7e,unknown).
1::status(o_9fce83ed2f2d9c5c3dcc,supported); 0::status(o_9fce83ed2f2d9c5c3dcc,refuted); 0::status(o_9fce83ed2f2d9c5c3dcc,unknown).
1::status(o_a000b1a83a8285c61c3a,supported); 0::status(o_a000b1a83a8285c61c3a,refuted); 0::status(o_a000b1a83a8285c61c3a,unknown).
0::status(o_a1cad329f5c1cf4ffc48,supported); 1::status(o_a1cad329f5c1cf4ffc48,refuted); 0::status(o_a1cad329f5c1cf4ffc48,unknown).
0.067158885300159454::status(o_a1d564c8d71011994ec5,supported); 0::status(o_a1d564c8d71011994ec5,refuted); 0.93284111469984055::status(o_a1d564c8d71011994ec5,unknown).
0.3336655695722176::status(o_a332867ed37ac3c0a6fd,supported); 0::status(o_a332867ed37ac3c0a6fd,refuted); 0.6663344304277824::status(o_a332867ed37ac3c0a6fd,unknown).
1::status(o_a3a4e1a87af149f975dc,supported); 0::status(o_a3a4e1a87af149f975dc,refuted); 0::status(o_a3a4e1a87af149f975dc,unknown).
0.54567309306371836::status(o_a3a88c8517287f14d09f,supported); 0::status(o_a3a88c8517287f14d09f,refuted); 0.45432690693628164::status(o_a3a88c8517287f14d09f,unknown).
0.70547658205032349::status(o_a456230c045faf540dde,supported); 0::status(o_a456230c045faf540dde,refuted); 0.29452341794967651::status(o_a456230c045faf540dde,unknown).
0.225900868017505::status(o_a5160bf4e372cd9792c6,supported); 0::status(o_a5160bf4e372cd9792c6,refuted); 0.77409913198249503::status(o_a5160bf4e372cd9792c6,unknown).
0.002940004225820303::status(o_a52b8462a8fe02f16c14,supported); 0::status(o_a52b8462a8fe02f16c14,refuted); 0.9970599957741797::status(o_a52b8462a8fe02f16c14,unknown).
1::status(o_a53f289362ec1bbcd8b7,supported); 0::status(o_a53f289362ec1bbcd8b7,refuted); 0::status(o_a53f289362ec1bbcd8b7,unknown).
0.47045918946799326::status(o_a5f4b27a7bded40186de,supported); 0::status(o_a5f4b27a7bded40186de,refuted); 0.52954081053200674::status(o_a5f4b27a7bded40186de,unknown).
0.17032217937338145::status(o_a60f64901ce66b1dbe1e,supported); 0::status(o_a60f64901ce66b1dbe1e,refuted); 0.82967782062661855::status(o_a60f64901ce66b1dbe1e,unknown).
1::status(o_a63bf7070875552f6d21,supported); 0::status(o_a63bf7070875552f6d21,refuted); 0::status(o_a63bf7070875552f6d21,unknown).
0.41473562707187001::status(o_a6eb05b59e76c238828f,supported); 0::status(o_a6eb05b59e76c238828f,refuted); 0.58526437292812994::status(o_a6eb05b59e76c238828f,unknown).
0.26720590754960177::status(o_a71f4ef44eba9fc6cb0e,supported); 0::status(o_a71f4ef44eba9fc6cb0e,refuted); 0.73279409245039817::status(o_a71f4ef44eba9fc6cb0e,unknown).
0.61694091558456421::status(o_a847bc5016b667b9083c,supported); 0::status(o_a847bc5016b667b9083c,refuted); 0.38305908441543579::status(o_a847bc5016b667b9083c,unknown).
1::status(o_a861a84daf7bf7442aa1,supported); 0::status(o_a861a84daf7bf7442aa1,refuted); 0::status(o_a861a84daf7bf7442aa1,unknown).
1::status(o_a8b5da03e7ff284e8699,supported); 0::status(o_a8b5da03e7ff284e8699,refuted); 0::status(o_a8b5da03e7ff284e8699,unknown).
1::status(o_a9c3d4b5a6a78fc0c800,supported); 0::status(o_a9c3d4b5a6a78fc0c800,refuted); 0::status(o_a9c3d4b5a6a78fc0c800,unknown).
0::status(o_aa4896e6bedec74068ac,supported); 1::status(o_aa4896e6bedec74068ac,refuted); 0::status(o_aa4896e6bedec74068ac,unknown).
0.31271256201733877::status(o_ab78405154f59670a15b,supported); 0::status(o_ab78405154f59670a15b,refuted); 0.68728743798266123::status(o_ab78405154f59670a15b,unknown).
0.74738532304763794::status(o_abbf600a16b903392499,supported); 0::status(o_abbf600a16b903392499,refuted); 0.25261467695236206::status(o_abbf600a16b903392499,unknown).
0.17727372387088441::status(o_ac518f68b190c18d5168,supported); 0::status(o_ac518f68b190c18d5168,refuted); 0.82272627612911564::status(o_ac518f68b190c18d5168,unknown).
0::status(o_ad270d0bba0f02906684,supported); 1::status(o_ad270d0bba0f02906684,refuted); 0::status(o_ad270d0bba0f02906684,unknown).
1::status(o_ad515c2cab6f8e2eba96,supported); 0::status(o_ad515c2cab6f8e2eba96,refuted); 0::status(o_ad515c2cab6f8e2eba96,unknown).
1::status(o_ada7dddae314288a80e4,supported); 0::status(o_ada7dddae314288a80e4,refuted); 0::status(o_ada7dddae314288a80e4,unknown).
0.63056268109834379::status(o_ae956e35ebe3ab49ed4f,supported); 0::status(o_ae956e35ebe3ab49ed4f,refuted); 0.36943731890165621::status(o_ae956e35ebe3ab49ed4f,unknown).
1::status(o_af663c4cce7eee55ceee,supported); 0::status(o_af663c4cce7eee55ceee,refuted); 0::status(o_af663c4cce7eee55ceee,unknown).
0.15634080606225739::status(o_b01ab74324e6cb68c66a,supported); 0::status(o_b01ab74324e6cb68c66a,refuted); 0.84365919393774258::status(o_b01ab74324e6cb68c66a,unknown).
0::status(o_b0276694968e0c63f518,supported); 1::status(o_b0276694968e0c63f518,refuted); 0::status(o_b0276694968e0c63f518,unknown).
0.55604892172959974::status(o_b0978ff4ff104df4cc09,supported); 0::status(o_b0978ff4ff104df4cc09,refuted); 0.44395107827040026::status(o_b0978ff4ff104df4cc09,unknown).
1::status(o_b0e8bca2d14335cf2d09,supported); 0::status(o_b0e8bca2d14335cf2d09,refuted); 0::status(o_b0e8bca2d14335cf2d09,unknown).
0::status(o_b10425345588ad700a70,supported); 1::status(o_b10425345588ad700a70,refuted); 0::status(o_b10425345588ad700a70,unknown).
0.00048713211435824633::status(o_b197e360bc252fdf5fc1,supported); 0::status(o_b197e360bc252fdf5fc1,refuted); 0.99951286788564175::status(o_b197e360bc252fdf5fc1,unknown).
0.48062722102977179::status(o_b26e9c91a61e4acd664f,supported); 0::status(o_b26e9c91a61e4acd664f,refuted); 0.51937277897022827::status(o_b26e9c91a61e4acd664f,unknown).
1::status(o_b283f14827e32875a668,supported); 0::status(o_b283f14827e32875a668,refuted); 0::status(o_b283f14827e32875a668,unknown).
0.99660646915435791::status(o_b328e9ca52ef1bfa898c,supported); 0::status(o_b328e9ca52ef1bfa898c,refuted); 0.0033935308456420898::status(o_b328e9ca52ef1bfa898c,unknown).
0.96011406183242798::status(o_b3db7ce52ed5148415de,supported); 0::status(o_b3db7ce52ed5148415de,refuted); 0.039885938167572021::status(o_b3db7ce52ed5148415de,unknown).
1::status(o_b470b3d75d34aad86396,supported); 0::status(o_b470b3d75d34aad86396,refuted); 0::status(o_b470b3d75d34aad86396,unknown).
1::status(o_b4ea2d93469199ed9d0b,supported); 0::status(o_b4ea2d93469199ed9d0b,refuted); 0::status(o_b4ea2d93469199ed9d0b,unknown).
0.00045137316919863224::status(o_b517a77ee1450f94492d,supported); 0::status(o_b517a77ee1450f94492d,refuted); 0.99954862683080137::status(o_b517a77ee1450f94492d,unknown).
1::status(o_b5f7d6cec7ba9d902819,supported); 0::status(o_b5f7d6cec7ba9d902819,refuted); 0::status(o_b5f7d6cec7ba9d902819,unknown).
1::status(o_b62d5c50944b561f115b,supported); 0::status(o_b62d5c50944b561f115b,refuted); 0::status(o_b62d5c50944b561f115b,unknown).
0.00076209998223930597::status(o_b67fc15ec96533ecc714,supported); 0::status(o_b67fc15ec96533ecc714,refuted); 0.99923790001776069::status(o_b67fc15ec96533ecc714,unknown).
1::status(o_b72da8b5270254124f28,supported); 0::status(o_b72da8b5270254124f28,refuted); 0::status(o_b72da8b5270254124f28,unknown).
1::status(o_b889a587d55becc59e30,supported); 0::status(o_b889a587d55becc59e30,refuted); 0::status(o_b889a587d55becc59e30,unknown).
1::status(o_b8ab0e8b5899754bc649,supported); 0::status(o_b8ab0e8b5899754bc649,refuted); 0::status(o_b8ab0e8b5899754bc649,unknown).
0.19355997361995056::status(o_b9e706ab190a594eb146,supported); 0::status(o_b9e706ab190a594eb146,refuted); 0.80644002638004941::status(o_b9e706ab190a594eb146,unknown).
1::status(o_ba1ad09e558610f37c26,supported); 0::status(o_ba1ad09e558610f37c26,refuted); 0::status(o_ba1ad09e558610f37c26,unknown).
0.21143395962012582::status(o_ba6cbb6148cb84b02cd5,supported); 0::status(o_ba6cbb6148cb84b02cd5,refuted); 0.78856604037987421::status(o_ba6cbb6148cb84b02cd5,unknown).
0.24228181976937849::status(o_bb2375f6aafe3f649c3a,supported); 0::status(o_bb2375f6aafe3f649c3a,refuted); 0.75771818023062154::status(o_bb2375f6aafe3f649c3a,unknown).
0::status(o_bb49dc57d836132fc296,supported); 1::status(o_bb49dc57d836132fc296,refuted); 0::status(o_bb49dc57d836132fc296,unknown).
0.19764673249016596::status(o_bbeaa2bcaa24e37600e3,supported); 0::status(o_bbeaa2bcaa24e37600e3,refuted); 0.80235326750983404::status(o_bbeaa2bcaa24e37600e3,unknown).
0.15821032226085663::status(o_bd84b91f8391005dc64f,supported); 0::status(o_bd84b91f8391005dc64f,refuted); 0.84178967773914337::status(o_bd84b91f8391005dc64f,unknown).
1::status(o_bf6c260396eebb3ee297,supported); 0::status(o_bf6c260396eebb3ee297,refuted); 0::status(o_bf6c260396eebb3ee297,unknown).
1.2276381312403828e-05::status(o_c107783c00ca77d9b4f7,supported); 0::status(o_c107783c00ca77d9b4f7,refuted); 0.9999877236186876::status(o_c107783c00ca77d9b4f7,unknown).
1::status(o_c163174454ecf4f02c39,supported); 0::status(o_c163174454ecf4f02c39,refuted); 0::status(o_c163174454ecf4f02c39,unknown).
0.99185353517532349::status(o_c1a0ea0a90ddc374bee9,supported); 0::status(o_c1a0ea0a90ddc374bee9,refuted); 0.0081464648246765137::status(o_c1a0ea0a90ddc374bee9,unknown).
0.98997622728347778::status(o_c1e22e1d7ebd0e67f386,supported); 0::status(o_c1e22e1d7ebd0e67f386,refuted); 0.010023772716522217::status(o_c1e22e1d7ebd0e67f386,unknown).
0.2129049152135849::status(o_c249d16667f4761fac5d,supported); 0::status(o_c249d16667f4761fac5d,refuted); 0.7870950847864151::status(o_c249d16667f4761fac5d,unknown).
0::status(o_c38257176a64045332c2,supported); 1::status(o_c38257176a64045332c2,refuted); 0::status(o_c38257176a64045332c2,unknown).
0.17347724643658499::status(o_c3d5b580e815a1798d83,supported); 0::status(o_c3d5b580e815a1798d83,refuted); 0.82652275356341498::status(o_c3d5b580e815a1798d83,unknown).
0::status(o_c3f3d2ee8ed8aa5066a2,supported); 1::status(o_c3f3d2ee8ed8aa5066a2,refuted); 0::status(o_c3f3d2ee8ed8aa5066a2,unknown).
1::status(o_c55c64c7eea4170106d8,supported); 0::status(o_c55c64c7eea4170106d8,refuted); 0::status(o_c55c64c7eea4170106d8,unknown).
0.24287842070011395::status(o_c57c78a31c64eb1dc203,supported); 0::status(o_c57c78a31c64eb1dc203,refuted); 0.75712157929988599::status(o_c57c78a31c64eb1dc203,unknown).
1::status(o_c59980b0c637bd3a1d59,supported); 0::status(o_c59980b0c637bd3a1d59,refuted); 0::status(o_c59980b0c637bd3a1d59,unknown).
0.0016452829586341977::status(o_c5a0f3d78b2dcc0d5cfe,supported); 0::status(o_c5a0f3d78b2dcc0d5cfe,refuted); 0.9983547170413658::status(o_c5a0f3d78b2dcc0d5cfe,unknown).
1::status(o_c5eb6b7b22d0ba65e52a,supported); 0::status(o_c5eb6b7b22d0ba65e52a,refuted); 0::status(o_c5eb6b7b22d0ba65e52a,unknown).
1::status(o_c620ef08f3c6e92e7234,supported); 0::status(o_c620ef08f3c6e92e7234,refuted); 0::status(o_c620ef08f3c6e92e7234,unknown).
0.0013122661039233208::status(o_c6913096ba00a1d58047,supported); 0::status(o_c6913096ba00a1d58047,refuted); 0.99868773389607668::status(o_c6913096ba00a1d58047,unknown).
0.059880557084575611::status(o_c6948330fa57b57a2ed8,supported); 0::status(o_c6948330fa57b57a2ed8,refuted); 0.94011944291542437::status(o_c6948330fa57b57a2ed8,unknown).
0.19005654916321202::status(o_c6bb737d309959d1de9c,supported); 0::status(o_c6bb737d309959d1de9c,refuted); 0.80994345083678798::status(o_c6bb737d309959d1de9c,unknown).
0.0037578577175736427::status(o_c6c52942ef307e707bec,supported); 0::status(o_c6c52942ef307e707bec,refuted); 0.99624214228242636::status(o_c6c52942ef307e707bec,unknown).
1::status(o_c7bf8036bd21467ff354,supported); 0::status(o_c7bf8036bd21467ff354,refuted); 0::status(o_c7bf8036bd21467ff354,unknown).
1::status(o_c869ff7441fbf816727d,supported); 0::status(o_c869ff7441fbf816727d,refuted); 0::status(o_c869ff7441fbf816727d,unknown).
0.002940004225820303::status(o_c8c87baa0a5d3c85a437,supported); 0::status(o_c8c87baa0a5d3c85a437,refuted); 0.9970599957741797::status(o_c8c87baa0a5d3c85a437,unknown).
0.00039488702896051109::status(o_c8ca54c1023c47b9da78,supported); 0::status(o_c8ca54c1023c47b9da78,refuted); 0.99960511297103949::status(o_c8ca54c1023c47b9da78,unknown).
0.0018071738304570317::status(o_c92ec08ef0174a46fd51,supported); 0::status(o_c92ec08ef0174a46fd51,refuted); 0.99819282616954297::status(o_c92ec08ef0174a46fd51,unknown).
1::status(o_c93d9a77d40c39cbe0b4,supported); 0::status(o_c93d9a77d40c39cbe0b4,refuted); 0::status(o_c93d9a77d40c39cbe0b4,unknown).
0.63310902975620786::status(o_ca1896a556f8b59513a9,supported); 0::status(o_ca1896a556f8b59513a9,refuted); 0.36689097024379214::status(o_ca1896a556f8b59513a9,unknown).
1::status(o_ca254481495c5bf916e8,supported); 0::status(o_ca254481495c5bf916e8,refuted); 0::status(o_ca254481495c5bf916e8,unknown).
1::status(o_ca39965b176b9773d7ec,supported); 0::status(o_ca39965b176b9773d7ec,refuted); 0::status(o_ca39965b176b9773d7ec,unknown).
0::status(o_ca9f6f63879a2153f2cf,supported); 1::status(o_ca9f6f63879a2153f2cf,refuted); 0::status(o_ca9f6f63879a2153f2cf,unknown).
0::status(o_cacee04898d5fefa5d0e,supported); 1::status(o_cacee04898d5fefa5d0e,refuted); 0::status(o_cacee04898d5fefa5d0e,unknown).
0.52321884901376903::status(o_caf5d136e54d491f273c,supported); 0::status(o_caf5d136e54d491f273c,refuted); 0.47678115098623097::status(o_caf5d136e54d491f273c,unknown).
0::status(o_cb3f44454338804a17bb,supported); 1::status(o_cb3f44454338804a17bb,refuted); 0::status(o_cb3f44454338804a17bb,unknown).
0::status(o_cc3b8c84f2cfab7e78ba,supported); 1::status(o_cc3b8c84f2cfab7e78ba,refuted); 0::status(o_cc3b8c84f2cfab7e78ba,unknown).
0.78545029701849134::status(o_ccc3257e5f93554db0b1,supported); 0::status(o_ccc3257e5f93554db0b1,refuted); 0.21454970298150866::status(o_ccc3257e5f93554db0b1,unknown).
1::status(o_cdf694541ca7147e7b2c,supported); 0::status(o_cdf694541ca7147e7b2c,refuted); 0::status(o_cdf694541ca7147e7b2c,unknown).
0.34819854080380347::status(o_ce94b9f9efa519c1d158,supported); 0::status(o_ce94b9f9efa519c1d158,refuted); 0.65180145919619648::status(o_ce94b9f9efa519c1d158,unknown).
0.00027939380379393697::status(o_cece0fee3cf3a62f2296,supported); 0::status(o_cece0fee3cf3a62f2296,refuted); 0.99972060619620606::status(o_cece0fee3cf3a62f2296,unknown).
1::status(o_cee4d72d02c6d9ca6ea1,supported); 0::status(o_cee4d72d02c6d9ca6ea1,refuted); 0::status(o_cee4d72d02c6d9ca6ea1,unknown).
1::status(o_ceeb794293e96c7f6ce5,supported); 0::status(o_ceeb794293e96c7f6ce5,refuted); 0::status(o_ceeb794293e96c7f6ce5,unknown).
1::status(o_cf8b8d0103995873b1e3,supported); 0::status(o_cf8b8d0103995873b1e3,refuted); 0::status(o_cf8b8d0103995873b1e3,unknown).
1::status(o_cfafc56fb5d9082a81f7,supported); 0::status(o_cfafc56fb5d9082a81f7,refuted); 0::status(o_cfafc56fb5d9082a81f7,unknown).
0.00066984596196562052::status(o_cff621ae48eb4f0c9a97,supported); 0::status(o_cff621ae48eb4f0c9a97,refuted); 0.99933015403803438::status(o_cff621ae48eb4f0c9a97,unknown).
0.976348876953125::status(o_d00768634721260ecd49,supported); 0::status(o_d00768634721260ecd49,refuted); 0.023651123046875::status(o_d00768634721260ecd49,unknown).
0.6157456622530415::status(o_d020f413985a6f53df52,supported); 0::status(o_d020f413985a6f53df52,refuted); 0.3842543377469585::status(o_d020f413985a6f53df52,unknown).
1::status(o_d065ca5871f90679237c,supported); 0::status(o_d065ca5871f90679237c,refuted); 0::status(o_d065ca5871f90679237c,unknown).
0.00012811402848456055::status(o_d0ebebdbd3b10f345c66,supported); 0::status(o_d0ebebdbd3b10f345c66,refuted); 0.99987188597151544::status(o_d0ebebdbd3b10f345c66,unknown).
1::status(o_d11c1a177ee12190fc24,supported); 0::status(o_d11c1a177ee12190fc24,refuted); 0::status(o_d11c1a177ee12190fc24,unknown).
1::status(o_d15b07d6a3b5f11628e6,supported); 0::status(o_d15b07d6a3b5f11628e6,refuted); 0::status(o_d15b07d6a3b5f11628e6,unknown).
1::status(o_d1e1786c6ec431dc8eab,supported); 0::status(o_d1e1786c6ec431dc8eab,refuted); 0::status(o_d1e1786c6ec431dc8eab,unknown).
0::status(o_d20a3b8edef1feef8322,supported); 1::status(o_d20a3b8edef1feef8322,refuted); 0::status(o_d20a3b8edef1feef8322,unknown).
0.17727372387088441::status(o_d242a82ea74f371c8502,supported); 0::status(o_d242a82ea74f371c8502,refuted); 0.82272627612911564::status(o_d242a82ea74f371c8502,unknown).
0::status(o_d246b22a2ae198ed84cb,supported); 1::status(o_d246b22a2ae198ed84cb,refuted); 0::status(o_d246b22a2ae198ed84cb,unknown).
0.16845106469907029::status(o_d25f245dc586ee58e9e4,supported); 0::status(o_d25f245dc586ee58e9e4,refuted); 0.83154893530092977::status(o_d25f245dc586ee58e9e4,unknown).
0.0050932755693793297::status(o_d26303da72c9399c63fd,supported); 0::status(o_d26303da72c9399c63fd,refuted); 0.99490672443062067::status(o_d26303da72c9399c63fd,unknown).
0.36376477629544635::status(o_d27800b9078c2bcfa0fd,supported); 0::status(o_d27800b9078c2bcfa0fd,refuted); 0.63623522370455365::status(o_d27800b9078c2bcfa0fd,unknown).
0::status(o_d27cda058d9fc24ab3e5,supported); 1::status(o_d27cda058d9fc24ab3e5,refuted); 0::status(o_d27cda058d9fc24ab3e5,unknown).
0.99887460470199585::status(o_d3599bdec4ede12fc6ea,supported); 0::status(o_d3599bdec4ede12fc6ea,refuted); 0.0011253952980041504::status(o_d3599bdec4ede12fc6ea,unknown).
0::status(o_d37dc66ead8066eda751,supported); 1::status(o_d37dc66ead8066eda751,refuted); 0::status(o_d37dc66ead8066eda751,unknown).
0.99810886383056641::status(o_d3efe2aaf645e90c64e7,supported); 0::status(o_d3efe2aaf645e90c64e7,refuted); 0.0018911361694335938::status(o_d3efe2aaf645e90c64e7,unknown).
0.99155628681182861::status(o_d438df36e2dd2c1df23e,supported); 0::status(o_d438df36e2dd2c1df23e,refuted); 0.0084437131881713867::status(o_d438df36e2dd2c1df23e,unknown).
0.76357456406184987::status(o_d5084105f491e2bf2be7,supported); 0::status(o_d5084105f491e2bf2be7,refuted); 0.23642543593815013::status(o_d5084105f491e2bf2be7,unknown).
0.0070033296942710876::status(o_d61bb4b8886a9f23b31b,supported); 0::status(o_d61bb4b8886a9f23b31b,refuted); 0.99299667030572891::status(o_d61bb4b8886a9f23b31b,unknown).
1::status(o_d6336b584fbc3a69eaa1,supported); 0::status(o_d6336b584fbc3a69eaa1,refuted); 0::status(o_d6336b584fbc3a69eaa1,unknown).
1::status(o_d66a466f6baa370526cc,supported); 0::status(o_d66a466f6baa370526cc,refuted); 0::status(o_d66a466f6baa370526cc,unknown).
1::status(o_d69f69360c70ad5a8bcb,supported); 0::status(o_d69f69360c70ad5a8bcb,refuted); 0::status(o_d69f69360c70ad5a8bcb,unknown).
0::status(o_d6c1af468a7d92b046ec,supported); 1::status(o_d6c1af468a7d92b046ec,refuted); 0::status(o_d6c1af468a7d92b046ec,unknown).
0.039551112800836563::status(o_d6f47e33fcbfb6a4d1d3,supported); 0::status(o_d6f47e33fcbfb6a4d1d3,refuted); 0.96044888719916344::status(o_d6f47e33fcbfb6a4d1d3,unknown).
1::status(o_d6f980618c081bea65ce,supported); 0::status(o_d6f980618c081bea65ce,refuted); 0::status(o_d6f980618c081bea65ce,unknown).
0::status(o_d7af19569aeb6110cb07,supported); 1::status(o_d7af19569aeb6110cb07,refuted); 0::status(o_d7af19569aeb6110cb07,unknown).
0.00050635967636480927::status(o_d7b148d73e64c16452f0,supported); 0::status(o_d7b148d73e64c16452f0,refuted); 0.99949364032363519::status(o_d7b148d73e64c16452f0,unknown).
1::status(o_d7fe0af95472039e1ba7,supported); 0::status(o_d7fe0af95472039e1ba7,refuted); 0::status(o_d7fe0af95472039e1ba7,unknown).
0.0093486057594418526::status(o_da11a3406ccbf7b7bf78,supported); 0::status(o_da11a3406ccbf7b7bf78,refuted); 0.99065139424055815::status(o_da11a3406ccbf7b7bf78,unknown).
0.015547662042081356::status(o_da2dec6deb9958294f83,supported); 0::status(o_da2dec6deb9958294f83,refuted); 0.98445233795791864::status(o_da2dec6deb9958294f83,unknown).
1::status(o_dab1a2687cf1b9f4d58b,supported); 0::status(o_dab1a2687cf1b9f4d58b,refuted); 0::status(o_dab1a2687cf1b9f4d58b,unknown).
0.0018518617143854499::status(o_db164fc7378e8d33b396,supported); 0::status(o_db164fc7378e8d33b396,refuted); 0.99814813828561455::status(o_db164fc7378e8d33b396,unknown).
0::status(o_db53cf1ff805e50cd252,supported); 1::status(o_db53cf1ff805e50cd252,refuted); 0::status(o_db53cf1ff805e50cd252,unknown).
1::status(o_dce5ad48dbd95e41c5e8,supported); 0::status(o_dce5ad48dbd95e41c5e8,refuted); 0::status(o_dce5ad48dbd95e41c5e8,unknown).
0::status(o_dcece1f5b9ad4d232de0,supported); 1::status(o_dcece1f5b9ad4d232de0,refuted); 0::status(o_dcece1f5b9ad4d232de0,unknown).
0.2766593005094688::status(o_ddf687e9e4b9cac3ea36,supported); 0::status(o_ddf687e9e4b9cac3ea36,refuted); 0.72334069949053115::status(o_ddf687e9e4b9cac3ea36,unknown).
1::status(o_df4f7af0f7119c6cd395,supported); 0::status(o_df4f7af0f7119c6cd395,refuted); 0::status(o_df4f7af0f7119c6cd395,unknown).
0::status(o_df6a6a49655e1e74555f,supported); 1::status(o_df6a6a49655e1e74555f,refuted); 0::status(o_df6a6a49655e1e74555f,unknown).
0.24368026490845215::status(o_dfcb1b94635ba602bdd7,supported); 0::status(o_dfcb1b94635ba602bdd7,refuted); 0.75631973509154782::status(o_dfcb1b94635ba602bdd7,unknown).
0.19538599857576402::status(o_dfd008e29d5ac0f1031a,supported); 0::status(o_dfd008e29d5ac0f1031a,refuted); 0.804614001424236::status(o_dfd008e29d5ac0f1031a,unknown).
0::status(o_dfd30d8cc785ba014691,supported); 1::status(o_dfd30d8cc785ba014691,refuted); 0::status(o_dfd30d8cc785ba014691,unknown).
1::status(o_e0148433680edb0ed27a,supported); 0::status(o_e0148433680edb0ed27a,refuted); 0::status(o_e0148433680edb0ed27a,unknown).
1::status(o_e05085af967da8e8a1cc,supported); 0::status(o_e05085af967da8e8a1cc,refuted); 0::status(o_e05085af967da8e8a1cc,unknown).
0::status(o_e07693f06d6eb6721439,supported); 1::status(o_e07693f06d6eb6721439,refuted); 0::status(o_e07693f06d6eb6721439,unknown).
0.62521180049902358::status(o_e0b239c7737087ef281f,supported); 0::status(o_e0b239c7737087ef281f,refuted); 0.37478819950097642::status(o_e0b239c7737087ef281f,unknown).
0.99887460470199585::status(o_e0f03769bf1492c04f00,supported); 0::status(o_e0f03769bf1492c04f00,refuted); 0.0011253952980041504::status(o_e0f03769bf1492c04f00,unknown).
0.32443726915540849::status(o_e2676468acc3c8837c8d,supported); 0::status(o_e2676468acc3c8837c8d,refuted); 0.67556273084459151::status(o_e2676468acc3c8837c8d,unknown).
0.58578857000318696::status(o_e2ac0dec45f9fc5d6649,supported); 0::status(o_e2ac0dec45f9fc5d6649,refuted); 0.41421142999681304::status(o_e2ac0dec45f9fc5d6649,unknown).
0.59548482063864561::status(o_e2f6af634ca7716aa55e,supported); 0::status(o_e2f6af634ca7716aa55e,refuted); 0.40451517936135439::status(o_e2f6af634ca7716aa55e,unknown).
0.28868305664749422::status(o_e30c248f492214e2b81a,supported); 0::status(o_e30c248f492214e2b81a,refuted); 0.71131694335250573::status(o_e30c248f492214e2b81a,unknown).
0.00043609272688627243::status(o_e3e7b682d79edaf1d3aa,supported); 0::status(o_e3e7b682d79edaf1d3aa,refuted); 0.99956390727311373::status(o_e3e7b682d79edaf1d3aa,unknown).
1::status(o_e3ed2d883b167f5d2873,supported); 0::status(o_e3ed2d883b167f5d2873,refuted); 0::status(o_e3ed2d883b167f5d2873,unknown).
1::status(o_e4813344d64f93dec787,supported); 0::status(o_e4813344d64f93dec787,refuted); 0::status(o_e4813344d64f93dec787,unknown).
0.99213320016860962::status(o_e49a41c70b393015e60d,supported); 0::status(o_e49a41c70b393015e60d,refuted); 0.0078667998313903809::status(o_e49a41c70b393015e60d,unknown).
0.99470680952072144::status(o_e648cc0dd3f0c19db09d,supported); 0::status(o_e648cc0dd3f0c19db09d,refuted); 0.0052931904792785645::status(o_e648cc0dd3f0c19db09d,unknown).
1::status(o_e6633275f025ac26b63b,supported); 0::status(o_e6633275f025ac26b63b,refuted); 0::status(o_e6633275f025ac26b63b,unknown).
0.61771134898671276::status(o_e6d6d93052230dd9aa65,supported); 0::status(o_e6d6d93052230dd9aa65,refuted); 0.38228865101328724::status(o_e6d6d93052230dd9aa65,unknown).
1::status(o_e6d780801b0c118067fe,supported); 0::status(o_e6d780801b0c118067fe,refuted); 0::status(o_e6d780801b0c118067fe,unknown).
0.99660646915435791::status(o_e763b1a16b0ea19be3a5,supported); 0::status(o_e763b1a16b0ea19be3a5,refuted); 0.0033935308456420898::status(o_e763b1a16b0ea19be3a5,unknown).
1::status(o_e7b5c586b30afcfd1d19,supported); 0::status(o_e7b5c586b30afcfd1d19,refuted); 0::status(o_e7b5c586b30afcfd1d19,unknown).
1::status(o_e7c465b2b9628c60bc2c,supported); 0::status(o_e7c465b2b9628c60bc2c,refuted); 0::status(o_e7c465b2b9628c60bc2c,unknown).
0::status(o_e81c15ba688783c6c9c2,supported); 1::status(o_e81c15ba688783c6c9c2,refuted); 0::status(o_e81c15ba688783c6c9c2,unknown).
1::status(o_e87315b464b1c5f30512,supported); 0::status(o_e87315b464b1c5f30512,refuted); 0::status(o_e87315b464b1c5f30512,unknown).
0.24893507805087303::status(o_e985aa974e7a96cfa0e9,supported); 0::status(o_e985aa974e7a96cfa0e9,refuted); 0.751064921949127::status(o_e985aa974e7a96cfa0e9,unknown).
0.02884664386510849::status(o_e9d0790131dd175ce6bb,supported); 0::status(o_e9d0790131dd175ce6bb,refuted); 0.97115335613489151::status(o_e9d0790131dd175ce6bb,unknown).
1::status(o_ea1e565e27a63343135a,supported); 0::status(o_ea1e565e27a63343135a,refuted); 0::status(o_ea1e565e27a63343135a,unknown).
1::status(o_ea1fa258de3938e26697,supported); 0::status(o_ea1fa258de3938e26697,refuted); 0::status(o_ea1fa258de3938e26697,unknown).
0.00063768832478672266::status(o_ea66860c2e940d9cd5b6,supported); 0::status(o_ea66860c2e940d9cd5b6,refuted); 0.99936231167521328::status(o_ea66860c2e940d9cd5b6,unknown).
0::status(o_ead10d7a9bffcca8d20f,supported); 1::status(o_ead10d7a9bffcca8d20f,refuted); 0::status(o_ead10d7a9bffcca8d20f,unknown).
0.18679465447632115::status(o_eb0bb2d3a610e269cb09,supported); 0::status(o_eb0bb2d3a610e269cb09,refuted); 0.81320534552367885::status(o_eb0bb2d3a610e269cb09,unknown).
1::status(o_eb1abd2431ddf7d6b62b,supported); 0::status(o_eb1abd2431ddf7d6b62b,refuted); 0::status(o_eb1abd2431ddf7d6b62b,unknown).
0.0018518617143854499::status(o_ec0370b4ed1fd4597d65,supported); 0::status(o_ec0370b4ed1fd4597d65,refuted); 0.99814813828561455::status(o_ec0370b4ed1fd4597d65,unknown).
1::status(o_ecc201056cb590f6f64a,supported); 0::status(o_ecc201056cb590f6f64a,refuted); 0::status(o_ecc201056cb590f6f64a,unknown).
1::status(o_ecfedabe6ce1e9e563bf,supported); 0::status(o_ecfedabe6ce1e9e563bf,refuted); 0::status(o_ecfedabe6ce1e9e563bf,unknown).
0.99185353517532349::status(o_ee8a25ae07d4cb7d488c,supported); 0::status(o_ee8a25ae07d4cb7d488c,refuted); 0.0081464648246765137::status(o_ee8a25ae07d4cb7d488c,unknown).
0.69321541940515385::status(o_ee96f668af800e35740e,supported); 0::status(o_ee96f668af800e35740e,refuted); 0.30678458059484615::status(o_ee96f668af800e35740e,unknown).
1::status(o_ef7885eff8b428b2d697,supported); 0::status(o_ef7885eff8b428b2d697,refuted); 0::status(o_ef7885eff8b428b2d697,unknown).
0.0013008691603317857::status(o_ef9eaadfe73950a55feb,supported); 0::status(o_ef9eaadfe73950a55feb,refuted); 0.99869913083966821::status(o_ef9eaadfe73950a55feb,unknown).
1::status(o_effdd62922efadc0a661,supported); 0::status(o_effdd62922efadc0a661,refuted); 0::status(o_effdd62922efadc0a661,unknown).
1::status(o_f152bef1705394970e0d,supported); 0::status(o_f152bef1705394970e0d,refuted); 0::status(o_f152bef1705394970e0d,unknown).
0.97427183389663696::status(o_f1e6623d7b7c46c10405,supported); 0::status(o_f1e6623d7b7c46c10405,refuted); 0.025728166103363037::status(o_f1e6623d7b7c46c10405,unknown).
0.39220755016604381::status(o_f1e6893f088760188f97,supported); 0::status(o_f1e6893f088760188f97,refuted); 0.60779244983395619::status(o_f1e6893f088760188f97,unknown).
0.003883931552991271::status(o_f1fb0d85003d55b85afb,supported); 0::status(o_f1fb0d85003d55b85afb,refuted); 0.99611606844700873::status(o_f1fb0d85003d55b85afb,unknown).
1::status(o_f222a7cb466a0384cde9,supported); 0::status(o_f222a7cb466a0384cde9,refuted); 0::status(o_f222a7cb466a0384cde9,unknown).
1::status(o_f296509176f1f25458ff,supported); 0::status(o_f296509176f1f25458ff,refuted); 0::status(o_f296509176f1f25458ff,unknown).
0.26828955437261837::status(o_f2aa9ec1f54dc7d43ce9,supported); 0::status(o_f2aa9ec1f54dc7d43ce9,refuted); 0.73171044562738163::status(o_f2aa9ec1f54dc7d43ce9,unknown).
0.99726450443267822::status(o_f38f2cd83b5b77899ffd,supported); 0::status(o_f38f2cd83b5b77899ffd,refuted); 0.0027354955673217773::status(o_f38f2cd83b5b77899ffd,unknown).
0.99506652355194092::status(o_f413e52d14f0ddea856b,supported); 0::status(o_f413e52d14f0ddea856b,refuted); 0.004933476448059082::status(o_f413e52d14f0ddea856b,unknown).
0::status(o_f56bcb23fe70ba56277b,supported); 1::status(o_f56bcb23fe70ba56277b,refuted); 0::status(o_f56bcb23fe70ba56277b,unknown).
1::status(o_f6181481a4896d3a6bd4,supported); 0::status(o_f6181481a4896d3a6bd4,refuted); 0::status(o_f6181481a4896d3a6bd4,unknown).
1::status(o_f66e167540304469dcdb,supported); 0::status(o_f66e167540304469dcdb,refuted); 0::status(o_f66e167540304469dcdb,unknown).
0.62305337314760978::status(o_f679bbba7f76f9b70a9c,supported); 0::status(o_f679bbba7f76f9b70a9c,refuted); 0.37694662685239022::status(o_f679bbba7f76f9b70a9c,unknown).
1::status(o_f790596b85b8ff79e38c,supported); 0::status(o_f790596b85b8ff79e38c,refuted); 0::status(o_f790596b85b8ff79e38c,unknown).
1::status(o_f7e156383510e9dfb240,supported); 0::status(o_f7e156383510e9dfb240,refuted); 0::status(o_f7e156383510e9dfb240,unknown).
1::status(o_f7f0d7b2186d8fe0fef9,supported); 0::status(o_f7f0d7b2186d8fe0fef9,refuted); 0::status(o_f7f0d7b2186d8fe0fef9,unknown).
0::status(o_f7fcaa37851f7cbed69f,supported); 1::status(o_f7fcaa37851f7cbed69f,refuted); 0::status(o_f7fcaa37851f7cbed69f,unknown).
0.088479405165872757::status(o_f83648b580bb845d7add,supported); 0::status(o_f83648b580bb845d7add,refuted); 0.91152059483412728::status(o_f83648b580bb845d7add,unknown).
0.0047103664837777615::status(o_f8947ca704c3a19cd4a6,supported); 0::status(o_f8947ca704c3a19cd4a6,refuted); 0.99528963351622224::status(o_f8947ca704c3a19cd4a6,unknown).
0.17032217937338145::status(o_f8e5ef4099cfcfdcaccd,supported); 0::status(o_f8e5ef4099cfcfdcaccd,refuted); 0.82967782062661855::status(o_f8e5ef4099cfcfdcaccd,unknown).
1::status(o_f92a43a4b7026f2e16f6,supported); 0::status(o_f92a43a4b7026f2e16f6,refuted); 0::status(o_f92a43a4b7026f2e16f6,unknown).
1::status(o_f99f5148bbe294fb2ad2,supported); 0::status(o_f99f5148bbe294fb2ad2,refuted); 0::status(o_f99f5148bbe294fb2ad2,unknown).
1::status(o_f9fcc8d8663b60758d8a,supported); 0::status(o_f9fcc8d8663b60758d8a,refuted); 0::status(o_f9fcc8d8663b60758d8a,unknown).
1::status(o_fa3447bb9429caee23e0,supported); 0::status(o_fa3447bb9429caee23e0,refuted); 0::status(o_fa3447bb9429caee23e0,unknown).
0.24720217475481024::status(o_fb303ae9a5163291104d,supported); 0::status(o_fb303ae9a5163291104d,refuted); 0.75279782524518979::status(o_fb303ae9a5163291104d,unknown).
0.1935151324992867::status(o_fb48c389cd39727c9307,supported); 0::status(o_fb48c389cd39727c9307,refuted); 0.80648486750071324::status(o_fb48c389cd39727c9307,unknown).
1::status(o_fb4f999100b6d242ae1c,supported); 0::status(o_fb4f999100b6d242ae1c,refuted); 0::status(o_fb4f999100b6d242ae1c,unknown).
0.64424905361761975::status(o_fb68810a4bd828d5a04a,supported); 0::status(o_fb68810a4bd828d5a04a,refuted); 0.35575094638238025::status(o_fb68810a4bd828d5a04a,unknown).
1::status(o_fb8f4bb93e7d143d0497,supported); 0::status(o_fb8f4bb93e7d143d0497,refuted); 0::status(o_fb8f4bb93e7d143d0497,unknown).
0::status(o_fbd740e0ed92baed7d02,supported); 1::status(o_fbd740e0ed92baed7d02,refuted); 0::status(o_fbd740e0ed92baed7d02,unknown).
0.96227091550827026::status(o_fbfbd5bd60bb6478e94d,supported); 0::status(o_fbfbd5bd60bb6478e94d,refuted); 0.037729084491729736::status(o_fbfbd5bd60bb6478e94d,unknown).
0.60430598979781869::status(o_fbfd1ecc8996c0d6ed75,supported); 0::status(o_fbfd1ecc8996c0d6ed75,refuted); 0.39569401020218131::status(o_fbfd1ecc8996c0d6ed75,unknown).
0.015679161995649338::status(o_fc2a7d9023c3179aeab6,supported); 0::status(o_fc2a7d9023c3179aeab6,refuted); 0.98432083800435066::status(o_fc2a7d9023c3179aeab6,unknown).
0.0044489046558737755::status(o_fc2e2391ee64e5b1be81,supported); 0::status(o_fc2e2391ee64e5b1be81,refuted); 0.99555109534412622::status(o_fc2e2391ee64e5b1be81,unknown).
0.0060011227615177631::status(o_fc95ca510d87dd43e20f,supported); 0::status(o_fc95ca510d87dd43e20f,refuted); 0.99399887723848224::status(o_fc95ca510d87dd43e20f,unknown).
1::status(o_fcd4bd69e38e07fd54f8,supported); 0::status(o_fcd4bd69e38e07fd54f8,refuted); 0::status(o_fcd4bd69e38e07fd54f8,unknown).
1::status(o_fd58f4d4dffe33849075,supported); 0::status(o_fd58f4d4dffe33849075,refuted); 0::status(o_fd58f4d4dffe33849075,unknown).
1::status(o_fd8b24f518d8ddb9e11e,supported); 0::status(o_fd8b24f518d8ddb9e11e,refuted); 0::status(o_fd8b24f518d8ddb9e11e,unknown).
1::status(o_fdaed9c3037474490813,supported); 0::status(o_fdaed9c3037474490813,refuted); 0::status(o_fdaed9c3037474490813,unknown).
0::status(o_fdc55e0b47ccc863e214,supported); 1::status(o_fdc55e0b47ccc863e214,refuted); 0::status(o_fdc55e0b47ccc863e214,unknown).
1::status(o_fe210805d494555d3cfd,supported); 0::status(o_fe210805d494555d3cfd,refuted); 0::status(o_fe210805d494555d3cfd,unknown).
0.44626516994090804::status(o_fe94407da10c20b74e32,supported); 0::status(o_fe94407da10c20b74e32,refuted); 0.55373483005909196::status(o_fe94407da10c20b74e32,unknown).
1::status(o_ff2623d54849c287222a,supported); 0::status(o_ff2623d54849c287222a,refuted); 0::status(o_ff2623d54849c287222a,unknown).
1::status(o_fff85f6daeee8d2fda36,supported); 0::status(o_fff85f6daeee8d2fda36,refuted); 0::status(o_fff85f6daeee8d2fda36,unknown).
node(n2,supported) :- status(o_626b65d31b3b92b99320,supported).
node(n2,refuted) :- status(o_626b65d31b3b92b99320,refuted).
node(n2,unknown) :- status(o_626b65d31b3b92b99320,unknown).
node(n3,supported) :- status(o_420ab2af0de775219296,supported).
node(n3,refuted) :- status(o_420ab2af0de775219296,refuted).
node(n3,unknown) :- status(o_420ab2af0de775219296,unknown).
node(n4,supported) :- status(o_d020f413985a6f53df52,supported).
node(n4,refuted) :- status(o_d020f413985a6f53df52,refuted).
node(n4,unknown) :- status(o_d020f413985a6f53df52,unknown).
node(n1,supported) :- node(n2,supported), node(n3,supported), node(n4,supported).
node(n1,refuted) :- node(n2,refuted).
node(n1,refuted) :- node(n3,refuted).
node(n1,refuted) :- node(n4,refuted).
node(n1,unknown) :- \+ node(n1,supported), \+ node(n1,refuted).
node(n6,supported) :- status(o_f56bcb23fe70ba56277b,supported).
node(n6,refuted) :- status(o_f56bcb23fe70ba56277b,refuted).
node(n6,unknown) :- status(o_f56bcb23fe70ba56277b,unknown).
node(n7,supported) :- status(o_1323d3792df5a3a36716,supported).
node(n7,refuted) :- status(o_1323d3792df5a3a36716,refuted).
node(n7,unknown) :- status(o_1323d3792df5a3a36716,unknown).
node(n8,supported) :- status(o_151613d849b42fc0def6,supported).
node(n8,refuted) :- status(o_151613d849b42fc0def6,refuted).
node(n8,unknown) :- status(o_151613d849b42fc0def6,unknown).
node(n5,supported) :- node(n6,supported), node(n7,supported), node(n8,supported).
node(n5,refuted) :- node(n6,refuted).
node(n5,refuted) :- node(n7,refuted).
node(n5,refuted) :- node(n8,refuted).
node(n5,unknown) :- \+ node(n5,supported), \+ node(n5,refuted).
node(n9,unknown).
node(n0,refuted) :- node(n1,refuted), node(n5,refuted), node(n9,refuted).
node(n0,supported) :- node(n1,supported).
node(n0,supported) :- node(n5,supported).
node(n0,supported) :- node(n9,supported).
node(n0,unknown) :- \+ node(n0,supported), \+ node(n0,refuted).
verdict(c_c7f5eeda9a99c2f3,supported) :- node(n0,supported).
query(verdict(c_c7f5eeda9a99c2f3,supported)).
verdict(c_c7f5eeda9a99c2f3,refuted) :- node(n0,refuted).
query(verdict(c_c7f5eeda9a99c2f3,refuted)).
verdict(c_c7f5eeda9a99c2f3,unknown) :- node(n0,unknown).
query(verdict(c_c7f5eeda9a99c2f3,unknown)).
node(n12,supported) :- status(o_b328e9ca52ef1bfa898c,supported).
node(n12,refuted) :- status(o_b328e9ca52ef1bfa898c,refuted).
node(n12,unknown) :- status(o_b328e9ca52ef1bfa898c,unknown).
node(n11,supported) :- node(n2,supported), node(n3,supported), node(n12,supported), node(n4,supported).
node(n11,refuted) :- node(n2,refuted).
node(n11,refuted) :- node(n3,refuted).
node(n11,refuted) :- node(n12,refuted).
node(n11,refuted) :- node(n4,refuted).
node(n11,unknown) :- \+ node(n11,supported), \+ node(n11,refuted).
node(n14,supported) :- status(o_3703f0e48dbff253ad64,supported).
node(n14,refuted) :- status(o_3703f0e48dbff253ad64,refuted).
node(n14,unknown) :- status(o_3703f0e48dbff253ad64,unknown).
node(n13,supported) :- node(n6,supported), node(n7,supported), node(n14,supported), node(n8,supported).
node(n13,refuted) :- node(n6,refuted).
node(n13,refuted) :- node(n7,refuted).
node(n13,refuted) :- node(n14,refuted).
node(n13,refuted) :- node(n8,refuted).
node(n13,unknown) :- \+ node(n13,supported), \+ node(n13,refuted).
node(n10,refuted) :- node(n11,refuted), node(n13,refuted), node(n9,refuted).
node(n10,supported) :- node(n11,supported).
node(n10,supported) :- node(n13,supported).
node(n10,supported) :- node(n9,supported).
node(n10,unknown) :- \+ node(n10,supported), \+ node(n10,refuted).
verdict(c_2e4a0e2883d08423,supported) :- node(n10,supported).
query(verdict(c_2e4a0e2883d08423,supported)).
verdict(c_2e4a0e2883d08423,refuted) :- node(n10,refuted).
query(verdict(c_2e4a0e2883d08423,refuted)).
verdict(c_2e4a0e2883d08423,unknown) :- node(n10,unknown).
query(verdict(c_2e4a0e2883d08423,unknown)).
node(n17,supported) :- status(o_7382abb16ee50d667551,supported).
node(n17,refuted) :- status(o_7382abb16ee50d667551,refuted).
node(n17,unknown) :- status(o_7382abb16ee50d667551,unknown).
node(n18,supported) :- status(o_4c34fc29dd7bd15ba929,supported).
node(n18,refuted) :- status(o_4c34fc29dd7bd15ba929,refuted).
node(n18,unknown) :- status(o_4c34fc29dd7bd15ba929,unknown).
node(n19,supported) :- status(o_f83648b580bb845d7add,supported).
node(n19,refuted) :- status(o_f83648b580bb845d7add,refuted).
node(n19,unknown) :- status(o_f83648b580bb845d7add,unknown).
node(n16,supported) :- node(n17,supported), node(n18,supported), node(n19,supported).
node(n16,refuted) :- node(n17,refuted).
node(n16,refuted) :- node(n18,refuted).
node(n16,refuted) :- node(n19,refuted).
node(n16,unknown) :- \+ node(n16,supported), \+ node(n16,refuted).
node(n21,supported) :- status(o_28363b70e799e5f58c6c,supported).
node(n21,refuted) :- status(o_28363b70e799e5f58c6c,refuted).
node(n21,unknown) :- status(o_28363b70e799e5f58c6c,unknown).
node(n22,supported) :- status(o_013590ea4e7cd47378f9,supported).
node(n22,refuted) :- status(o_013590ea4e7cd47378f9,refuted).
node(n22,unknown) :- status(o_013590ea4e7cd47378f9,unknown).
node(n23,supported) :- status(o_6cff6c9209477777094e,supported).
node(n23,refuted) :- status(o_6cff6c9209477777094e,refuted).
node(n23,unknown) :- status(o_6cff6c9209477777094e,unknown).
node(n20,supported) :- node(n21,supported), node(n22,supported), node(n23,supported).
node(n20,refuted) :- node(n21,refuted).
node(n20,refuted) :- node(n22,refuted).
node(n20,refuted) :- node(n23,refuted).
node(n20,unknown) :- \+ node(n20,supported), \+ node(n20,refuted).
node(n15,refuted) :- node(n16,refuted), node(n20,refuted), node(n9,refuted).
node(n15,supported) :- node(n16,supported).
node(n15,supported) :- node(n20,supported).
node(n15,supported) :- node(n9,supported).
node(n15,unknown) :- \+ node(n15,supported), \+ node(n15,refuted).
verdict(c_abc20b853eb66b22,supported) :- node(n15,supported).
query(verdict(c_abc20b853eb66b22,supported)).
verdict(c_abc20b853eb66b22,refuted) :- node(n15,refuted).
query(verdict(c_abc20b853eb66b22,refuted)).
verdict(c_abc20b853eb66b22,unknown) :- node(n15,unknown).
query(verdict(c_abc20b853eb66b22,unknown)).
node(n26,supported) :- status(o_72b91ad6971397c1f622,supported).
node(n26,refuted) :- status(o_72b91ad6971397c1f622,refuted).
node(n26,unknown) :- status(o_72b91ad6971397c1f622,unknown).
node(n25,supported) :- node(n17,supported), node(n18,supported), node(n26,supported), node(n19,supported).
node(n25,refuted) :- node(n17,refuted).
node(n25,refuted) :- node(n18,refuted).
node(n25,refuted) :- node(n26,refuted).
node(n25,refuted) :- node(n19,refuted).
node(n25,unknown) :- \+ node(n25,supported), \+ node(n25,refuted).
node(n28,supported) :- status(o_7a797b663c4aec95363b,supported).
node(n28,refuted) :- status(o_7a797b663c4aec95363b,refuted).
node(n28,unknown) :- status(o_7a797b663c4aec95363b,unknown).
node(n27,supported) :- node(n21,supported), node(n22,supported), node(n28,supported), node(n23,supported).
node(n27,refuted) :- node(n21,refuted).
node(n27,refuted) :- node(n22,refuted).
node(n27,refuted) :- node(n28,refuted).
node(n27,refuted) :- node(n23,refuted).
node(n27,unknown) :- \+ node(n27,supported), \+ node(n27,refuted).
node(n24,refuted) :- node(n25,refuted), node(n27,refuted), node(n9,refuted).
node(n24,supported) :- node(n25,supported).
node(n24,supported) :- node(n27,supported).
node(n24,supported) :- node(n9,supported).
node(n24,unknown) :- \+ node(n24,supported), \+ node(n24,refuted).
verdict(c_8b57ed2a02045944,supported) :- node(n24,supported).
query(verdict(c_8b57ed2a02045944,supported)).
verdict(c_8b57ed2a02045944,refuted) :- node(n24,refuted).
query(verdict(c_8b57ed2a02045944,refuted)).
verdict(c_8b57ed2a02045944,unknown) :- node(n24,unknown).
query(verdict(c_8b57ed2a02045944,unknown)).
node(n31,supported) :- status(o_ca9f6f63879a2153f2cf,supported).
node(n31,refuted) :- status(o_ca9f6f63879a2153f2cf,refuted).
node(n31,unknown) :- status(o_ca9f6f63879a2153f2cf,unknown).
node(n32,supported) :- status(o_88312bff917834c6249f,supported).
node(n32,refuted) :- status(o_88312bff917834c6249f,refuted).
node(n32,unknown) :- status(o_88312bff917834c6249f,unknown).
node(n33,supported) :- status(o_5d899fd43466722082ff,supported).
node(n33,refuted) :- status(o_5d899fd43466722082ff,refuted).
node(n33,unknown) :- status(o_5d899fd43466722082ff,unknown).
node(n30,supported) :- node(n31,supported), node(n32,supported), node(n33,supported).
node(n30,refuted) :- node(n31,refuted).
node(n30,refuted) :- node(n32,refuted).
node(n30,refuted) :- node(n33,refuted).
node(n30,unknown) :- \+ node(n30,supported), \+ node(n30,refuted).
node(n35,supported) :- status(o_62af9e58173e39eba6d3,supported).
node(n35,refuted) :- status(o_62af9e58173e39eba6d3,refuted).
node(n35,unknown) :- status(o_62af9e58173e39eba6d3,unknown).
node(n36,supported) :- status(o_f99f5148bbe294fb2ad2,supported).
node(n36,refuted) :- status(o_f99f5148bbe294fb2ad2,refuted).
node(n36,unknown) :- status(o_f99f5148bbe294fb2ad2,unknown).
node(n37,supported) :- status(o_bb2375f6aafe3f649c3a,supported).
node(n37,refuted) :- status(o_bb2375f6aafe3f649c3a,refuted).
node(n37,unknown) :- status(o_bb2375f6aafe3f649c3a,unknown).
node(n34,supported) :- node(n35,supported), node(n36,supported), node(n37,supported).
node(n34,refuted) :- node(n35,refuted).
node(n34,refuted) :- node(n36,refuted).
node(n34,refuted) :- node(n37,refuted).
node(n34,unknown) :- \+ node(n34,supported), \+ node(n34,refuted).
node(n29,refuted) :- node(n30,refuted), node(n34,refuted), node(n9,refuted).
node(n29,supported) :- node(n30,supported).
node(n29,supported) :- node(n34,supported).
node(n29,supported) :- node(n9,supported).
node(n29,unknown) :- \+ node(n29,supported), \+ node(n29,refuted).
verdict(c_0aedbe8153f2130d,supported) :- node(n29,supported).
query(verdict(c_0aedbe8153f2130d,supported)).
verdict(c_0aedbe8153f2130d,refuted) :- node(n29,refuted).
query(verdict(c_0aedbe8153f2130d,refuted)).
verdict(c_0aedbe8153f2130d,unknown) :- node(n29,unknown).
query(verdict(c_0aedbe8153f2130d,unknown)).
node(n40,supported) :- status(o_e763b1a16b0ea19be3a5,supported).
node(n40,refuted) :- status(o_e763b1a16b0ea19be3a5,refuted).
node(n40,unknown) :- status(o_e763b1a16b0ea19be3a5,unknown).
node(n39,supported) :- node(n31,supported), node(n32,supported), node(n40,supported), node(n33,supported).
node(n39,refuted) :- node(n31,refuted).
node(n39,refuted) :- node(n32,refuted).
node(n39,refuted) :- node(n40,refuted).
node(n39,refuted) :- node(n33,refuted).
node(n39,unknown) :- \+ node(n39,supported), \+ node(n39,refuted).
node(n42,supported) :- status(o_d61bb4b8886a9f23b31b,supported).
node(n42,refuted) :- status(o_d61bb4b8886a9f23b31b,refuted).
node(n42,unknown) :- status(o_d61bb4b8886a9f23b31b,unknown).
node(n41,supported) :- node(n35,supported), node(n36,supported), node(n42,supported), node(n37,supported).
node(n41,refuted) :- node(n35,refuted).
node(n41,refuted) :- node(n36,refuted).
node(n41,refuted) :- node(n42,refuted).
node(n41,refuted) :- node(n37,refuted).
node(n41,unknown) :- \+ node(n41,supported), \+ node(n41,refuted).
node(n38,refuted) :- node(n39,refuted), node(n41,refuted), node(n9,refuted).
node(n38,supported) :- node(n39,supported).
node(n38,supported) :- node(n41,supported).
node(n38,supported) :- node(n9,supported).
node(n38,unknown) :- \+ node(n38,supported), \+ node(n38,refuted).
verdict(c_1e9fcb857c1d2a37,supported) :- node(n38,supported).
query(verdict(c_1e9fcb857c1d2a37,supported)).
verdict(c_1e9fcb857c1d2a37,refuted) :- node(n38,refuted).
query(verdict(c_1e9fcb857c1d2a37,refuted)).
verdict(c_1e9fcb857c1d2a37,unknown) :- node(n38,unknown).
query(verdict(c_1e9fcb857c1d2a37,unknown)).
node(n45,supported) :- status(o_fbd740e0ed92baed7d02,supported).
node(n45,refuted) :- status(o_fbd740e0ed92baed7d02,refuted).
node(n45,unknown) :- status(o_fbd740e0ed92baed7d02,unknown).
node(n46,supported) :- status(o_71d43d1c4404a38ce2d3,supported).
node(n46,refuted) :- status(o_71d43d1c4404a38ce2d3,refuted).
node(n46,unknown) :- status(o_71d43d1c4404a38ce2d3,unknown).
node(n47,supported) :- status(o_c57c78a31c64eb1dc203,supported).
node(n47,refuted) :- status(o_c57c78a31c64eb1dc203,refuted).
node(n47,unknown) :- status(o_c57c78a31c64eb1dc203,unknown).
node(n44,supported) :- node(n45,supported), node(n46,supported), node(n47,supported).
node(n44,refuted) :- node(n45,refuted).
node(n44,refuted) :- node(n46,refuted).
node(n44,refuted) :- node(n47,refuted).
node(n44,unknown) :- \+ node(n44,supported), \+ node(n44,refuted).
node(n49,supported) :- status(o_658e7851d79c344f94da,supported).
node(n49,refuted) :- status(o_658e7851d79c344f94da,refuted).
node(n49,unknown) :- status(o_658e7851d79c344f94da,unknown).
node(n50,supported) :- status(o_c869ff7441fbf816727d,supported).
node(n50,refuted) :- status(o_c869ff7441fbf816727d,refuted).
node(n50,unknown) :- status(o_c869ff7441fbf816727d,unknown).
node(n51,supported) :- status(o_116a6aa90f422b50ac59,supported).
node(n51,refuted) :- status(o_116a6aa90f422b50ac59,refuted).
node(n51,unknown) :- status(o_116a6aa90f422b50ac59,unknown).
node(n48,supported) :- node(n49,supported), node(n50,supported), node(n51,supported).
node(n48,refuted) :- node(n49,refuted).
node(n48,refuted) :- node(n50,refuted).
node(n48,refuted) :- node(n51,refuted).
node(n48,unknown) :- \+ node(n48,supported), \+ node(n48,refuted).
node(n43,refuted) :- node(n44,refuted), node(n48,refuted), node(n9,refuted).
node(n43,supported) :- node(n44,supported).
node(n43,supported) :- node(n48,supported).
node(n43,supported) :- node(n9,supported).
node(n43,unknown) :- \+ node(n43,supported), \+ node(n43,refuted).
verdict(c_dce47711d1e00175,supported) :- node(n43,supported).
query(verdict(c_dce47711d1e00175,supported)).
verdict(c_dce47711d1e00175,refuted) :- node(n43,refuted).
query(verdict(c_dce47711d1e00175,refuted)).
verdict(c_dce47711d1e00175,unknown) :- node(n43,unknown).
query(verdict(c_dce47711d1e00175,unknown)).
node(n54,supported) :- status(o_c8c87baa0a5d3c85a437,supported).
node(n54,refuted) :- status(o_c8c87baa0a5d3c85a437,refuted).
node(n54,unknown) :- status(o_c8c87baa0a5d3c85a437,unknown).
node(n53,supported) :- node(n45,supported), node(n46,supported), node(n54,supported), node(n47,supported).
node(n53,refuted) :- node(n45,refuted).
node(n53,refuted) :- node(n46,refuted).
node(n53,refuted) :- node(n54,refuted).
node(n53,refuted) :- node(n47,refuted).
node(n53,unknown) :- \+ node(n53,supported), \+ node(n53,refuted).
node(n56,supported) :- status(o_0e48a0a360f3dd32a90e,supported).
node(n56,refuted) :- status(o_0e48a0a360f3dd32a90e,refuted).
node(n56,unknown) :- status(o_0e48a0a360f3dd32a90e,unknown).
node(n55,supported) :- node(n49,supported), node(n50,supported), node(n56,supported), node(n51,supported).
node(n55,refuted) :- node(n49,refuted).
node(n55,refuted) :- node(n50,refuted).
node(n55,refuted) :- node(n56,refuted).
node(n55,refuted) :- node(n51,refuted).
node(n55,unknown) :- \+ node(n55,supported), \+ node(n55,refuted).
node(n52,refuted) :- node(n53,refuted), node(n55,refuted), node(n9,refuted).
node(n52,supported) :- node(n53,supported).
node(n52,supported) :- node(n55,supported).
node(n52,supported) :- node(n9,supported).
node(n52,unknown) :- \+ node(n52,supported), \+ node(n52,refuted).
verdict(c_9075b421366e57ae,supported) :- node(n52,supported).
query(verdict(c_9075b421366e57ae,supported)).
verdict(c_9075b421366e57ae,refuted) :- node(n52,refuted).
query(verdict(c_9075b421366e57ae,refuted)).
verdict(c_9075b421366e57ae,unknown) :- node(n52,unknown).
query(verdict(c_9075b421366e57ae,unknown)).
node(n59,supported) :- status(o_1cfdeb7ca9527102074f,supported).
node(n59,refuted) :- status(o_1cfdeb7ca9527102074f,refuted).
node(n59,unknown) :- status(o_1cfdeb7ca9527102074f,unknown).
node(n60,supported) :- status(o_4d435abcbe591d662c5b,supported).
node(n60,refuted) :- status(o_4d435abcbe591d662c5b,refuted).
node(n60,unknown) :- status(o_4d435abcbe591d662c5b,unknown).
node(n61,supported) :- status(o_81b70f7fd49741508db9,supported).
node(n61,refuted) :- status(o_81b70f7fd49741508db9,refuted).
node(n61,unknown) :- status(o_81b70f7fd49741508db9,unknown).
node(n58,supported) :- node(n59,supported), node(n60,supported), node(n61,supported).
node(n58,refuted) :- node(n59,refuted).
node(n58,refuted) :- node(n60,refuted).
node(n58,refuted) :- node(n61,refuted).
node(n58,unknown) :- \+ node(n58,supported), \+ node(n58,refuted).
node(n63,supported) :- status(o_399c116ba02245698e98,supported).
node(n63,refuted) :- status(o_399c116ba02245698e98,refuted).
node(n63,unknown) :- status(o_399c116ba02245698e98,unknown).
node(n64,supported) :- status(o_e6633275f025ac26b63b,supported).
node(n64,refuted) :- status(o_e6633275f025ac26b63b,refuted).
node(n64,unknown) :- status(o_e6633275f025ac26b63b,unknown).
node(n65,supported) :- status(o_0cdfc050b594786a72a3,supported).
node(n65,refuted) :- status(o_0cdfc050b594786a72a3,refuted).
node(n65,unknown) :- status(o_0cdfc050b594786a72a3,unknown).
node(n62,supported) :- node(n63,supported), node(n64,supported), node(n65,supported).
node(n62,refuted) :- node(n63,refuted).
node(n62,refuted) :- node(n64,refuted).
node(n62,refuted) :- node(n65,refuted).
node(n62,unknown) :- \+ node(n62,supported), \+ node(n62,refuted).
node(n57,refuted) :- node(n58,refuted), node(n62,refuted), node(n9,refuted).
node(n57,supported) :- node(n58,supported).
node(n57,supported) :- node(n62,supported).
node(n57,supported) :- node(n9,supported).
node(n57,unknown) :- \+ node(n57,supported), \+ node(n57,refuted).
verdict(c_e945aa684e28ebfd,supported) :- node(n57,supported).
query(verdict(c_e945aa684e28ebfd,supported)).
verdict(c_e945aa684e28ebfd,refuted) :- node(n57,refuted).
query(verdict(c_e945aa684e28ebfd,refuted)).
verdict(c_e945aa684e28ebfd,unknown) :- node(n57,unknown).
query(verdict(c_e945aa684e28ebfd,unknown)).
node(n68,supported) :- status(o_6c93acc7924c8be4cfd6,supported).
node(n68,refuted) :- status(o_6c93acc7924c8be4cfd6,refuted).
node(n68,unknown) :- status(o_6c93acc7924c8be4cfd6,unknown).
node(n67,supported) :- node(n59,supported), node(n60,supported), node(n68,supported), node(n61,supported).
node(n67,refuted) :- node(n59,refuted).
node(n67,refuted) :- node(n60,refuted).
node(n67,refuted) :- node(n68,refuted).
node(n67,refuted) :- node(n61,refuted).
node(n67,unknown) :- \+ node(n67,supported), \+ node(n67,refuted).
node(n70,supported) :- status(o_b197e360bc252fdf5fc1,supported).
node(n70,refuted) :- status(o_b197e360bc252fdf5fc1,refuted).
node(n70,unknown) :- status(o_b197e360bc252fdf5fc1,unknown).
node(n69,supported) :- node(n63,supported), node(n64,supported), node(n70,supported), node(n65,supported).
node(n69,refuted) :- node(n63,refuted).
node(n69,refuted) :- node(n64,refuted).
node(n69,refuted) :- node(n70,refuted).
node(n69,refuted) :- node(n65,refuted).
node(n69,unknown) :- \+ node(n69,supported), \+ node(n69,refuted).
node(n66,refuted) :- node(n67,refuted), node(n69,refuted), node(n9,refuted).
node(n66,supported) :- node(n67,supported).
node(n66,supported) :- node(n69,supported).
node(n66,supported) :- node(n9,supported).
node(n66,unknown) :- \+ node(n66,supported), \+ node(n66,refuted).
verdict(c_4e3a2630c182d029,supported) :- node(n66,supported).
query(verdict(c_4e3a2630c182d029,supported)).
verdict(c_4e3a2630c182d029,refuted) :- node(n66,refuted).
query(verdict(c_4e3a2630c182d029,refuted)).
verdict(c_4e3a2630c182d029,unknown) :- node(n66,unknown).
query(verdict(c_4e3a2630c182d029,unknown)).
node(n73,supported) :- status(o_3123999d9cf307bca68b,supported).
node(n73,refuted) :- status(o_3123999d9cf307bca68b,refuted).
node(n73,unknown) :- status(o_3123999d9cf307bca68b,unknown).
node(n74,supported) :- status(o_2f96c65a44127f6522c5,supported).
node(n74,refuted) :- status(o_2f96c65a44127f6522c5,refuted).
node(n74,unknown) :- status(o_2f96c65a44127f6522c5,unknown).
node(n75,supported) :- status(o_1a4320445babc1ec7672,supported).
node(n75,refuted) :- status(o_1a4320445babc1ec7672,refuted).
node(n75,unknown) :- status(o_1a4320445babc1ec7672,unknown).
node(n72,supported) :- node(n73,supported), node(n74,supported), node(n75,supported).
node(n72,refuted) :- node(n73,refuted).
node(n72,refuted) :- node(n74,refuted).
node(n72,refuted) :- node(n75,refuted).
node(n72,unknown) :- \+ node(n72,supported), \+ node(n72,refuted).
node(n77,supported) :- status(o_b0276694968e0c63f518,supported).
node(n77,refuted) :- status(o_b0276694968e0c63f518,refuted).
node(n77,unknown) :- status(o_b0276694968e0c63f518,unknown).
node(n78,supported) :- status(o_ea1fa258de3938e26697,supported).
node(n78,refuted) :- status(o_ea1fa258de3938e26697,refuted).
node(n78,unknown) :- status(o_ea1fa258de3938e26697,unknown).
node(n79,supported) :- status(o_3f635067430d393e42dc,supported).
node(n79,refuted) :- status(o_3f635067430d393e42dc,refuted).
node(n79,unknown) :- status(o_3f635067430d393e42dc,unknown).
node(n76,supported) :- node(n77,supported), node(n78,supported), node(n79,supported).
node(n76,refuted) :- node(n77,refuted).
node(n76,refuted) :- node(n78,refuted).
node(n76,refuted) :- node(n79,refuted).
node(n76,unknown) :- \+ node(n76,supported), \+ node(n76,refuted).
node(n71,refuted) :- node(n72,refuted), node(n76,refuted), node(n9,refuted).
node(n71,supported) :- node(n72,supported).
node(n71,supported) :- node(n76,supported).
node(n71,supported) :- node(n9,supported).
node(n71,unknown) :- \+ node(n71,supported), \+ node(n71,refuted).
verdict(c_2f8c39cdc957afc1,supported) :- node(n71,supported).
query(verdict(c_2f8c39cdc957afc1,supported)).
verdict(c_2f8c39cdc957afc1,refuted) :- node(n71,refuted).
query(verdict(c_2f8c39cdc957afc1,refuted)).
verdict(c_2f8c39cdc957afc1,unknown) :- node(n71,unknown).
query(verdict(c_2f8c39cdc957afc1,unknown)).
node(n82,supported) :- status(o_a52b8462a8fe02f16c14,supported).
node(n82,refuted) :- status(o_a52b8462a8fe02f16c14,refuted).
node(n82,unknown) :- status(o_a52b8462a8fe02f16c14,unknown).
node(n81,supported) :- node(n73,supported), node(n74,supported), node(n82,supported), node(n75,supported).
node(n81,refuted) :- node(n73,refuted).
node(n81,refuted) :- node(n74,refuted).
node(n81,refuted) :- node(n82,refuted).
node(n81,refuted) :- node(n75,refuted).
node(n81,unknown) :- \+ node(n81,supported), \+ node(n81,refuted).
node(n84,supported) :- status(o_d00768634721260ecd49,supported).
node(n84,refuted) :- status(o_d00768634721260ecd49,refuted).
node(n84,unknown) :- status(o_d00768634721260ecd49,unknown).
node(n83,supported) :- node(n77,supported), node(n78,supported), node(n84,supported), node(n79,supported).
node(n83,refuted) :- node(n77,refuted).
node(n83,refuted) :- node(n78,refuted).
node(n83,refuted) :- node(n84,refuted).
node(n83,refuted) :- node(n79,refuted).
node(n83,unknown) :- \+ node(n83,supported), \+ node(n83,refuted).
node(n80,refuted) :- node(n81,refuted), node(n83,refuted), node(n9,refuted).
node(n80,supported) :- node(n81,supported).
node(n80,supported) :- node(n83,supported).
node(n80,supported) :- node(n9,supported).
node(n80,unknown) :- \+ node(n80,supported), \+ node(n80,refuted).
verdict(c_2b909e36206a14cd,supported) :- node(n80,supported).
query(verdict(c_2b909e36206a14cd,supported)).
verdict(c_2b909e36206a14cd,refuted) :- node(n80,refuted).
query(verdict(c_2b909e36206a14cd,refuted)).
verdict(c_2b909e36206a14cd,unknown) :- node(n80,unknown).
query(verdict(c_2b909e36206a14cd,unknown)).
node(n87,supported) :- status(o_9be155994cd0a4efa5f1,supported).
node(n87,refuted) :- status(o_9be155994cd0a4efa5f1,refuted).
node(n87,unknown) :- status(o_9be155994cd0a4efa5f1,unknown).
node(n88,supported) :- status(o_b72da8b5270254124f28,supported).
node(n88,refuted) :- status(o_b72da8b5270254124f28,refuted).
node(n88,unknown) :- status(o_b72da8b5270254124f28,unknown).
node(n89,supported) :- status(o_e0b239c7737087ef281f,supported).
node(n89,refuted) :- status(o_e0b239c7737087ef281f,refuted).
node(n89,unknown) :- status(o_e0b239c7737087ef281f,unknown).
node(n86,supported) :- node(n87,supported), node(n88,supported), node(n89,supported).
node(n86,refuted) :- node(n87,refuted).
node(n86,refuted) :- node(n88,refuted).
node(n86,refuted) :- node(n89,refuted).
node(n86,unknown) :- \+ node(n86,supported), \+ node(n86,refuted).
node(n91,supported) :- status(o_c3f3d2ee8ed8aa5066a2,supported).
node(n91,refuted) :- status(o_c3f3d2ee8ed8aa5066a2,refuted).
node(n91,unknown) :- status(o_c3f3d2ee8ed8aa5066a2,unknown).
node(n92,supported) :- status(o_4dc336be9417dcfa6dd2,supported).
node(n92,refuted) :- status(o_4dc336be9417dcfa6dd2,refuted).
node(n92,unknown) :- status(o_4dc336be9417dcfa6dd2,unknown).
node(n93,supported) :- status(o_1df1b32830663bda55a1,supported).
node(n93,refuted) :- status(o_1df1b32830663bda55a1,refuted).
node(n93,unknown) :- status(o_1df1b32830663bda55a1,unknown).
node(n90,supported) :- node(n91,supported), node(n92,supported), node(n93,supported).
node(n90,refuted) :- node(n91,refuted).
node(n90,refuted) :- node(n92,refuted).
node(n90,refuted) :- node(n93,refuted).
node(n90,unknown) :- \+ node(n90,supported), \+ node(n90,refuted).
node(n85,refuted) :- node(n86,refuted), node(n90,refuted), node(n9,refuted).
node(n85,supported) :- node(n86,supported).
node(n85,supported) :- node(n90,supported).
node(n85,supported) :- node(n9,supported).
node(n85,unknown) :- \+ node(n85,supported), \+ node(n85,refuted).
verdict(c_339da9dd34e3e451,supported) :- node(n85,supported).
query(verdict(c_339da9dd34e3e451,supported)).
verdict(c_339da9dd34e3e451,refuted) :- node(n85,refuted).
query(verdict(c_339da9dd34e3e451,refuted)).
verdict(c_339da9dd34e3e451,unknown) :- node(n85,unknown).
query(verdict(c_339da9dd34e3e451,unknown)).
node(n96,supported) :- status(o_91ef6f91fb3a040e1388,supported).
node(n96,refuted) :- status(o_91ef6f91fb3a040e1388,refuted).
node(n96,unknown) :- status(o_91ef6f91fb3a040e1388,unknown).
node(n95,supported) :- node(n87,supported), node(n88,supported), node(n96,supported), node(n89,supported).
node(n95,refuted) :- node(n87,refuted).
node(n95,refuted) :- node(n88,refuted).
node(n95,refuted) :- node(n96,refuted).
node(n95,refuted) :- node(n89,refuted).
node(n95,unknown) :- \+ node(n95,supported), \+ node(n95,refuted).
node(n98,supported) :- status(o_c92ec08ef0174a46fd51,supported).
node(n98,refuted) :- status(o_c92ec08ef0174a46fd51,refuted).
node(n98,unknown) :- status(o_c92ec08ef0174a46fd51,unknown).
node(n97,supported) :- node(n91,supported), node(n92,supported), node(n98,supported), node(n93,supported).
node(n97,refuted) :- node(n91,refuted).
node(n97,refuted) :- node(n92,refuted).
node(n97,refuted) :- node(n98,refuted).
node(n97,refuted) :- node(n93,refuted).
node(n97,unknown) :- \+ node(n97,supported), \+ node(n97,refuted).
node(n94,refuted) :- node(n95,refuted), node(n97,refuted), node(n9,refuted).
node(n94,supported) :- node(n95,supported).
node(n94,supported) :- node(n97,supported).
node(n94,supported) :- node(n9,supported).
node(n94,unknown) :- \+ node(n94,supported), \+ node(n94,refuted).
verdict(c_87306c1092f5156d,supported) :- node(n94,supported).
query(verdict(c_87306c1092f5156d,supported)).
verdict(c_87306c1092f5156d,refuted) :- node(n94,refuted).
query(verdict(c_87306c1092f5156d,refuted)).
verdict(c_87306c1092f5156d,unknown) :- node(n94,unknown).
query(verdict(c_87306c1092f5156d,unknown)).
node(n101,supported) :- status(o_e6d780801b0c118067fe,supported).
node(n101,refuted) :- status(o_e6d780801b0c118067fe,refuted).
node(n101,unknown) :- status(o_e6d780801b0c118067fe,unknown).
node(n102,supported) :- status(o_cfafc56fb5d9082a81f7,supported).
node(n102,refuted) :- status(o_cfafc56fb5d9082a81f7,refuted).
node(n102,unknown) :- status(o_cfafc56fb5d9082a81f7,unknown).
node(n103,supported) :- status(o_8bdfa29d3cfe545d6aa5,supported).
node(n103,refuted) :- status(o_8bdfa29d3cfe545d6aa5,refuted).
node(n103,unknown) :- status(o_8bdfa29d3cfe545d6aa5,unknown).
node(n100,supported) :- node(n101,supported), node(n102,supported), node(n103,supported).
node(n100,refuted) :- node(n101,refuted).
node(n100,refuted) :- node(n102,refuted).
node(n100,refuted) :- node(n103,refuted).
node(n100,unknown) :- \+ node(n100,supported), \+ node(n100,refuted).
node(n105,supported) :- status(o_6393e12e124c3ee350f1,supported).
node(n105,refuted) :- status(o_6393e12e124c3ee350f1,refuted).
node(n105,unknown) :- status(o_6393e12e124c3ee350f1,unknown).
node(n106,supported) :- status(o_c5eb6b7b22d0ba65e52a,supported).
node(n106,refuted) :- status(o_c5eb6b7b22d0ba65e52a,refuted).
node(n106,unknown) :- status(o_c5eb6b7b22d0ba65e52a,unknown).
node(n107,supported) :- status(o_a5160bf4e372cd9792c6,supported).
node(n107,refuted) :- status(o_a5160bf4e372cd9792c6,refuted).
node(n107,unknown) :- status(o_a5160bf4e372cd9792c6,unknown).
node(n104,supported) :- node(n105,supported), node(n106,supported), node(n107,supported).
node(n104,refuted) :- node(n105,refuted).
node(n104,refuted) :- node(n106,refuted).
node(n104,refuted) :- node(n107,refuted).
node(n104,unknown) :- \+ node(n104,supported), \+ node(n104,refuted).
node(n99,refuted) :- node(n100,refuted), node(n104,refuted), node(n9,refuted).
node(n99,supported) :- node(n100,supported).
node(n99,supported) :- node(n104,supported).
node(n99,supported) :- node(n9,supported).
node(n99,unknown) :- \+ node(n99,supported), \+ node(n99,refuted).
verdict(c_6f2067ba277a4039,supported) :- node(n99,supported).
query(verdict(c_6f2067ba277a4039,supported)).
verdict(c_6f2067ba277a4039,refuted) :- node(n99,refuted).
query(verdict(c_6f2067ba277a4039,refuted)).
verdict(c_6f2067ba277a4039,unknown) :- node(n99,unknown).
query(verdict(c_6f2067ba277a4039,unknown)).
node(n110,supported) :- status(o_621dfc36926a9e5fbfde,supported).
node(n110,refuted) :- status(o_621dfc36926a9e5fbfde,refuted).
node(n110,unknown) :- status(o_621dfc36926a9e5fbfde,unknown).
node(n109,supported) :- node(n101,supported), node(n102,supported), node(n110,supported), node(n103,supported).
node(n109,refuted) :- node(n101,refuted).
node(n109,refuted) :- node(n102,refuted).
node(n109,refuted) :- node(n110,refuted).
node(n109,refuted) :- node(n103,refuted).
node(n109,unknown) :- \+ node(n109,supported), \+ node(n109,refuted).
node(n112,supported) :- status(o_352102850a6208f28228,supported).
node(n112,refuted) :- status(o_352102850a6208f28228,refuted).
node(n112,unknown) :- status(o_352102850a6208f28228,unknown).
node(n111,supported) :- node(n105,supported), node(n106,supported), node(n112,supported), node(n107,supported).
node(n111,refuted) :- node(n105,refuted).
node(n111,refuted) :- node(n106,refuted).
node(n111,refuted) :- node(n112,refuted).
node(n111,refuted) :- node(n107,refuted).
node(n111,unknown) :- \+ node(n111,supported), \+ node(n111,refuted).
node(n108,refuted) :- node(n109,refuted), node(n111,refuted), node(n9,refuted).
node(n108,supported) :- node(n109,supported).
node(n108,supported) :- node(n111,supported).
node(n108,supported) :- node(n9,supported).
node(n108,unknown) :- \+ node(n108,supported), \+ node(n108,refuted).
verdict(c_da547f1516895f1b,supported) :- node(n108,supported).
query(verdict(c_da547f1516895f1b,supported)).
verdict(c_da547f1516895f1b,refuted) :- node(n108,refuted).
query(verdict(c_da547f1516895f1b,refuted)).
verdict(c_da547f1516895f1b,unknown) :- node(n108,unknown).
query(verdict(c_da547f1516895f1b,unknown)).
node(n115,supported) :- status(o_aa4896e6bedec74068ac,supported).
node(n115,refuted) :- status(o_aa4896e6bedec74068ac,refuted).
node(n115,unknown) :- status(o_aa4896e6bedec74068ac,unknown).
node(n116,supported) :- status(o_38815adad6c30f9b86b3,supported).
node(n116,refuted) :- status(o_38815adad6c30f9b86b3,refuted).
node(n116,unknown) :- status(o_38815adad6c30f9b86b3,unknown).
node(n117,supported) :- status(o_0b56e6d4b50fb0d52828,supported).
node(n117,refuted) :- status(o_0b56e6d4b50fb0d52828,refuted).
node(n117,unknown) :- status(o_0b56e6d4b50fb0d52828,unknown).
node(n114,supported) :- node(n115,supported), node(n116,supported), node(n117,supported).
node(n114,refuted) :- node(n115,refuted).
node(n114,refuted) :- node(n116,refuted).
node(n114,refuted) :- node(n117,refuted).
node(n114,unknown) :- \+ node(n114,supported), \+ node(n114,refuted).
node(n119,supported) :- status(o_8651aa1952cad480cf99,supported).
node(n119,refuted) :- status(o_8651aa1952cad480cf99,refuted).
node(n119,unknown) :- status(o_8651aa1952cad480cf99,unknown).
node(n120,supported) :- status(o_503ca5414c5c0df03060,supported).
node(n120,refuted) :- status(o_503ca5414c5c0df03060,refuted).
node(n120,unknown) :- status(o_503ca5414c5c0df03060,unknown).
node(n121,supported) :- status(o_750272459a32718c5ba1,supported).
node(n121,refuted) :- status(o_750272459a32718c5ba1,refuted).
node(n121,unknown) :- status(o_750272459a32718c5ba1,unknown).
node(n118,supported) :- node(n119,supported), node(n120,supported), node(n121,supported).
node(n118,refuted) :- node(n119,refuted).
node(n118,refuted) :- node(n120,refuted).
node(n118,refuted) :- node(n121,refuted).
node(n118,unknown) :- \+ node(n118,supported), \+ node(n118,refuted).
node(n113,refuted) :- node(n114,refuted), node(n118,refuted), node(n9,refuted).
node(n113,supported) :- node(n114,supported).
node(n113,supported) :- node(n118,supported).
node(n113,supported) :- node(n9,supported).
node(n113,unknown) :- \+ node(n113,supported), \+ node(n113,refuted).
verdict(c_e106ce4ed1ce31a3,supported) :- node(n113,supported).
query(verdict(c_e106ce4ed1ce31a3,supported)).
verdict(c_e106ce4ed1ce31a3,refuted) :- node(n113,refuted).
query(verdict(c_e106ce4ed1ce31a3,refuted)).
verdict(c_e106ce4ed1ce31a3,unknown) :- node(n113,unknown).
query(verdict(c_e106ce4ed1ce31a3,unknown)).
node(n124,supported) :- status(o_987ef028bb2406b4f5ef,supported).
node(n124,refuted) :- status(o_987ef028bb2406b4f5ef,refuted).
node(n124,unknown) :- status(o_987ef028bb2406b4f5ef,unknown).
node(n123,supported) :- node(n115,supported), node(n116,supported), node(n124,supported), node(n117,supported).
node(n123,refuted) :- node(n115,refuted).
node(n123,refuted) :- node(n116,refuted).
node(n123,refuted) :- node(n124,refuted).
node(n123,refuted) :- node(n117,refuted).
node(n123,unknown) :- \+ node(n123,supported), \+ node(n123,refuted).
node(n126,supported) :- status(o_30b058adc25f756c087b,supported).
node(n126,refuted) :- status(o_30b058adc25f756c087b,refuted).
node(n126,unknown) :- status(o_30b058adc25f756c087b,unknown).
node(n125,supported) :- node(n119,supported), node(n120,supported), node(n126,supported), node(n121,supported).
node(n125,refuted) :- node(n119,refuted).
node(n125,refuted) :- node(n120,refuted).
node(n125,refuted) :- node(n126,refuted).
node(n125,refuted) :- node(n121,refuted).
node(n125,unknown) :- \+ node(n125,supported), \+ node(n125,refuted).
node(n122,refuted) :- node(n123,refuted), node(n125,refuted), node(n9,refuted).
node(n122,supported) :- node(n123,supported).
node(n122,supported) :- node(n125,supported).
node(n122,supported) :- node(n9,supported).
node(n122,unknown) :- \+ node(n122,supported), \+ node(n122,refuted).
verdict(c_90e13336ec809399,supported) :- node(n122,supported).
query(verdict(c_90e13336ec809399,supported)).
verdict(c_90e13336ec809399,refuted) :- node(n122,refuted).
query(verdict(c_90e13336ec809399,refuted)).
verdict(c_90e13336ec809399,unknown) :- node(n122,unknown).
query(verdict(c_90e13336ec809399,unknown)).
node(n129,supported) :- status(o_10915a9fda153071f95c,supported).
node(n129,refuted) :- status(o_10915a9fda153071f95c,refuted).
node(n129,unknown) :- status(o_10915a9fda153071f95c,unknown).
node(n130,supported) :- status(o_8147183eb3fc7c8faf4d,supported).
node(n130,refuted) :- status(o_8147183eb3fc7c8faf4d,refuted).
node(n130,unknown) :- status(o_8147183eb3fc7c8faf4d,unknown).
node(n131,supported) :- status(o_0b0642323388b2ee12d9,supported).
node(n131,refuted) :- status(o_0b0642323388b2ee12d9,refuted).
node(n131,unknown) :- status(o_0b0642323388b2ee12d9,unknown).
node(n128,supported) :- node(n129,supported), node(n130,supported), node(n131,supported).
node(n128,refuted) :- node(n129,refuted).
node(n128,refuted) :- node(n130,refuted).
node(n128,refuted) :- node(n131,refuted).
node(n128,unknown) :- \+ node(n128,supported), \+ node(n128,refuted).
node(n133,supported) :- status(o_23d9abf97c7312e11c48,supported).
node(n133,refuted) :- status(o_23d9abf97c7312e11c48,refuted).
node(n133,unknown) :- status(o_23d9abf97c7312e11c48,unknown).
node(n134,supported) :- status(o_3ef2af9e543b9aeb6785,supported).
node(n134,refuted) :- status(o_3ef2af9e543b9aeb6785,refuted).
node(n134,unknown) :- status(o_3ef2af9e543b9aeb6785,unknown).
node(n135,supported) :- status(o_e6d6d93052230dd9aa65,supported).
node(n135,refuted) :- status(o_e6d6d93052230dd9aa65,refuted).
node(n135,unknown) :- status(o_e6d6d93052230dd9aa65,unknown).
node(n132,supported) :- node(n133,supported), node(n134,supported), node(n135,supported).
node(n132,refuted) :- node(n133,refuted).
node(n132,refuted) :- node(n134,refuted).
node(n132,refuted) :- node(n135,refuted).
node(n132,unknown) :- \+ node(n132,supported), \+ node(n132,refuted).
node(n127,refuted) :- node(n128,refuted), node(n132,refuted), node(n9,refuted).
node(n127,supported) :- node(n128,supported).
node(n127,supported) :- node(n132,supported).
node(n127,supported) :- node(n9,supported).
node(n127,unknown) :- \+ node(n127,supported), \+ node(n127,refuted).
verdict(c_51172713c6eec07e,supported) :- node(n127,supported).
query(verdict(c_51172713c6eec07e,supported)).
verdict(c_51172713c6eec07e,refuted) :- node(n127,refuted).
query(verdict(c_51172713c6eec07e,refuted)).
verdict(c_51172713c6eec07e,unknown) :- node(n127,unknown).
query(verdict(c_51172713c6eec07e,unknown)).
node(n138,supported) :- status(o_db164fc7378e8d33b396,supported).
node(n138,refuted) :- status(o_db164fc7378e8d33b396,refuted).
node(n138,unknown) :- status(o_db164fc7378e8d33b396,unknown).
node(n137,supported) :- node(n129,supported), node(n130,supported), node(n138,supported), node(n131,supported).
node(n137,refuted) :- node(n129,refuted).
node(n137,refuted) :- node(n130,refuted).
node(n137,refuted) :- node(n138,refuted).
node(n137,refuted) :- node(n131,refuted).
node(n137,unknown) :- \+ node(n137,supported), \+ node(n137,refuted).
node(n140,supported) :- status(o_853da64aa4711d55ca21,supported).
node(n140,refuted) :- status(o_853da64aa4711d55ca21,refuted).
node(n140,unknown) :- status(o_853da64aa4711d55ca21,unknown).
node(n139,supported) :- node(n133,supported), node(n134,supported), node(n140,supported), node(n135,supported).
node(n139,refuted) :- node(n133,refuted).
node(n139,refuted) :- node(n134,refuted).
node(n139,refuted) :- node(n140,refuted).
node(n139,refuted) :- node(n135,refuted).
node(n139,unknown) :- \+ node(n139,supported), \+ node(n139,refuted).
node(n136,refuted) :- node(n137,refuted), node(n139,refuted), node(n9,refuted).
node(n136,supported) :- node(n137,supported).
node(n136,supported) :- node(n139,supported).
node(n136,supported) :- node(n9,supported).
node(n136,unknown) :- \+ node(n136,supported), \+ node(n136,refuted).
verdict(c_6dd3c7db50cc73ff,supported) :- node(n136,supported).
query(verdict(c_6dd3c7db50cc73ff,supported)).
verdict(c_6dd3c7db50cc73ff,refuted) :- node(n136,refuted).
query(verdict(c_6dd3c7db50cc73ff,refuted)).
verdict(c_6dd3c7db50cc73ff,unknown) :- node(n136,unknown).
query(verdict(c_6dd3c7db50cc73ff,unknown)).
node(n143,supported) :- status(o_1b1423734fde71379068,supported).
node(n143,refuted) :- status(o_1b1423734fde71379068,refuted).
node(n143,unknown) :- status(o_1b1423734fde71379068,unknown).
node(n144,supported) :- status(o_71dc0665a3dd07e090d4,supported).
node(n144,refuted) :- status(o_71dc0665a3dd07e090d4,refuted).
node(n144,unknown) :- status(o_71dc0665a3dd07e090d4,unknown).
node(n145,supported) :- status(o_82e4c8c1d9640cc8f6dc,supported).
node(n145,refuted) :- status(o_82e4c8c1d9640cc8f6dc,refuted).
node(n145,unknown) :- status(o_82e4c8c1d9640cc8f6dc,unknown).
node(n142,supported) :- node(n143,supported), node(n144,supported), node(n145,supported).
node(n142,refuted) :- node(n143,refuted).
node(n142,refuted) :- node(n144,refuted).
node(n142,refuted) :- node(n145,refuted).
node(n142,unknown) :- \+ node(n142,supported), \+ node(n142,refuted).
node(n147,supported) :- status(o_39f3c00c33d2d06295a3,supported).
node(n147,refuted) :- status(o_39f3c00c33d2d06295a3,refuted).
node(n147,unknown) :- status(o_39f3c00c33d2d06295a3,unknown).
node(n148,supported) :- status(o_7cb182bee4bd6aa25d27,supported).
node(n148,refuted) :- status(o_7cb182bee4bd6aa25d27,refuted).
node(n148,unknown) :- status(o_7cb182bee4bd6aa25d27,unknown).
node(n149,supported) :- status(o_1057b77d00153ef3b411,supported).
node(n149,refuted) :- status(o_1057b77d00153ef3b411,refuted).
node(n149,unknown) :- status(o_1057b77d00153ef3b411,unknown).
node(n146,supported) :- node(n147,supported), node(n148,supported), node(n149,supported).
node(n146,refuted) :- node(n147,refuted).
node(n146,refuted) :- node(n148,refuted).
node(n146,refuted) :- node(n149,refuted).
node(n146,unknown) :- \+ node(n146,supported), \+ node(n146,refuted).
node(n141,refuted) :- node(n142,refuted), node(n146,refuted), node(n9,refuted).
node(n141,supported) :- node(n142,supported).
node(n141,supported) :- node(n146,supported).
node(n141,supported) :- node(n9,supported).
node(n141,unknown) :- \+ node(n141,supported), \+ node(n141,refuted).
verdict(c_a9161500b73427ff,supported) :- node(n141,supported).
query(verdict(c_a9161500b73427ff,supported)).
verdict(c_a9161500b73427ff,refuted) :- node(n141,refuted).
query(verdict(c_a9161500b73427ff,refuted)).
verdict(c_a9161500b73427ff,unknown) :- node(n141,unknown).
query(verdict(c_a9161500b73427ff,unknown)).
node(n152,supported) :- status(o_b67fc15ec96533ecc714,supported).
node(n152,refuted) :- status(o_b67fc15ec96533ecc714,refuted).
node(n152,unknown) :- status(o_b67fc15ec96533ecc714,unknown).
node(n151,supported) :- node(n143,supported), node(n144,supported), node(n152,supported), node(n145,supported).
node(n151,refuted) :- node(n143,refuted).
node(n151,refuted) :- node(n144,refuted).
node(n151,refuted) :- node(n152,refuted).
node(n151,refuted) :- node(n145,refuted).
node(n151,unknown) :- \+ node(n151,supported), \+ node(n151,refuted).
node(n154,supported) :- status(o_7eedce19a0d8caee91bd,supported).
node(n154,refuted) :- status(o_7eedce19a0d8caee91bd,refuted).
node(n154,unknown) :- status(o_7eedce19a0d8caee91bd,unknown).
node(n153,supported) :- node(n147,supported), node(n148,supported), node(n154,supported), node(n149,supported).
node(n153,refuted) :- node(n147,refuted).
node(n153,refuted) :- node(n148,refuted).
node(n153,refuted) :- node(n154,refuted).
node(n153,refuted) :- node(n149,refuted).
node(n153,unknown) :- \+ node(n153,supported), \+ node(n153,refuted).
node(n150,refuted) :- node(n151,refuted), node(n153,refuted), node(n9,refuted).
node(n150,supported) :- node(n151,supported).
node(n150,supported) :- node(n153,supported).
node(n150,supported) :- node(n9,supported).
node(n150,unknown) :- \+ node(n150,supported), \+ node(n150,refuted).
verdict(c_fcb82393da3eedcf,supported) :- node(n150,supported).
query(verdict(c_fcb82393da3eedcf,supported)).
verdict(c_fcb82393da3eedcf,refuted) :- node(n150,refuted).
query(verdict(c_fcb82393da3eedcf,refuted)).
verdict(c_fcb82393da3eedcf,unknown) :- node(n150,unknown).
query(verdict(c_fcb82393da3eedcf,unknown)).
node(n157,supported) :- status(o_97ea8e2ea18d65f02c6a,supported).
node(n157,refuted) :- status(o_97ea8e2ea18d65f02c6a,refuted).
node(n157,unknown) :- status(o_97ea8e2ea18d65f02c6a,unknown).
node(n158,supported) :- status(o_b470b3d75d34aad86396,supported).
node(n158,refuted) :- status(o_b470b3d75d34aad86396,refuted).
node(n158,unknown) :- status(o_b470b3d75d34aad86396,unknown).
node(n159,supported) :- status(o_ce94b9f9efa519c1d158,supported).
node(n159,refuted) :- status(o_ce94b9f9efa519c1d158,refuted).
node(n159,unknown) :- status(o_ce94b9f9efa519c1d158,unknown).
node(n156,supported) :- node(n157,supported), node(n158,supported), node(n159,supported).
node(n156,refuted) :- node(n157,refuted).
node(n156,refuted) :- node(n158,refuted).
node(n156,refuted) :- node(n159,refuted).
node(n156,unknown) :- \+ node(n156,supported), \+ node(n156,refuted).
node(n161,supported) :- status(o_d37dc66ead8066eda751,supported).
node(n161,refuted) :- status(o_d37dc66ead8066eda751,refuted).
node(n161,unknown) :- status(o_d37dc66ead8066eda751,unknown).
node(n162,supported) :- status(o_c7bf8036bd21467ff354,supported).
node(n162,refuted) :- status(o_c7bf8036bd21467ff354,refuted).
node(n162,unknown) :- status(o_c7bf8036bd21467ff354,unknown).
node(n163,supported) :- status(o_391054f01387a78474e4,supported).
node(n163,refuted) :- status(o_391054f01387a78474e4,refuted).
node(n163,unknown) :- status(o_391054f01387a78474e4,unknown).
node(n160,supported) :- node(n161,supported), node(n162,supported), node(n163,supported).
node(n160,refuted) :- node(n161,refuted).
node(n160,refuted) :- node(n162,refuted).
node(n160,refuted) :- node(n163,refuted).
node(n160,unknown) :- \+ node(n160,supported), \+ node(n160,refuted).
node(n155,refuted) :- node(n156,refuted), node(n160,refuted), node(n9,refuted).
node(n155,supported) :- node(n156,supported).
node(n155,supported) :- node(n160,supported).
node(n155,supported) :- node(n9,supported).
node(n155,unknown) :- \+ node(n155,supported), \+ node(n155,refuted).
verdict(c_dd2753f9c14e2d5f,supported) :- node(n155,supported).
query(verdict(c_dd2753f9c14e2d5f,supported)).
verdict(c_dd2753f9c14e2d5f,refuted) :- node(n155,refuted).
query(verdict(c_dd2753f9c14e2d5f,refuted)).
verdict(c_dd2753f9c14e2d5f,unknown) :- node(n155,unknown).
query(verdict(c_dd2753f9c14e2d5f,unknown)).
node(n166,supported) :- status(o_ec0370b4ed1fd4597d65,supported).
node(n166,refuted) :- status(o_ec0370b4ed1fd4597d65,refuted).
node(n166,unknown) :- status(o_ec0370b4ed1fd4597d65,unknown).
node(n165,supported) :- node(n157,supported), node(n158,supported), node(n166,supported), node(n159,supported).
node(n165,refuted) :- node(n157,refuted).
node(n165,refuted) :- node(n158,refuted).
node(n165,refuted) :- node(n166,refuted).
node(n165,refuted) :- node(n159,refuted).
node(n165,unknown) :- \+ node(n165,supported), \+ node(n165,refuted).
node(n168,supported) :- status(o_9587f71948ac3e900a38,supported).
node(n168,refuted) :- status(o_9587f71948ac3e900a38,refuted).
node(n168,unknown) :- status(o_9587f71948ac3e900a38,unknown).
node(n167,supported) :- node(n161,supported), node(n162,supported), node(n168,supported), node(n163,supported).
node(n167,refuted) :- node(n161,refuted).
node(n167,refuted) :- node(n162,refuted).
node(n167,refuted) :- node(n168,refuted).
node(n167,refuted) :- node(n163,refuted).
node(n167,unknown) :- \+ node(n167,supported), \+ node(n167,refuted).
node(n164,refuted) :- node(n165,refuted), node(n167,refuted), node(n9,refuted).
node(n164,supported) :- node(n165,supported).
node(n164,supported) :- node(n167,supported).
node(n164,supported) :- node(n9,supported).
node(n164,unknown) :- \+ node(n164,supported), \+ node(n164,refuted).
verdict(c_bb9ceb45d824e459,supported) :- node(n164,supported).
query(verdict(c_bb9ceb45d824e459,supported)).
verdict(c_bb9ceb45d824e459,refuted) :- node(n164,refuted).
query(verdict(c_bb9ceb45d824e459,refuted)).
verdict(c_bb9ceb45d824e459,unknown) :- node(n164,unknown).
query(verdict(c_bb9ceb45d824e459,unknown)).
node(n171,supported) :- status(o_fdc55e0b47ccc863e214,supported).
node(n171,refuted) :- status(o_fdc55e0b47ccc863e214,refuted).
node(n171,unknown) :- status(o_fdc55e0b47ccc863e214,unknown).
node(n172,supported) :- status(o_9fce83ed2f2d9c5c3dcc,supported).
node(n172,refuted) :- status(o_9fce83ed2f2d9c5c3dcc,refuted).
node(n172,unknown) :- status(o_9fce83ed2f2d9c5c3dcc,unknown).
node(n173,supported) :- status(o_7d76d0e158ae641f79a7,supported).
node(n173,refuted) :- status(o_7d76d0e158ae641f79a7,refuted).
node(n173,unknown) :- status(o_7d76d0e158ae641f79a7,unknown).
node(n170,supported) :- node(n171,supported), node(n172,supported), node(n173,supported).
node(n170,refuted) :- node(n171,refuted).
node(n170,refuted) :- node(n172,refuted).
node(n170,refuted) :- node(n173,refuted).
node(n170,unknown) :- \+ node(n170,supported), \+ node(n170,refuted).
node(n175,supported) :- status(o_2a4b68297b2649f9b517,supported).
node(n175,refuted) :- status(o_2a4b68297b2649f9b517,refuted).
node(n175,unknown) :- status(o_2a4b68297b2649f9b517,unknown).
node(n176,supported) :- status(o_ceeb794293e96c7f6ce5,supported).
node(n176,refuted) :- status(o_ceeb794293e96c7f6ce5,refuted).
node(n176,unknown) :- status(o_ceeb794293e96c7f6ce5,unknown).
node(n177,supported) :- status(o_00fb41f1e22830074c78,supported).
node(n177,refuted) :- status(o_00fb41f1e22830074c78,refuted).
node(n177,unknown) :- status(o_00fb41f1e22830074c78,unknown).
node(n174,supported) :- node(n175,supported), node(n176,supported), node(n177,supported).
node(n174,refuted) :- node(n175,refuted).
node(n174,refuted) :- node(n176,refuted).
node(n174,refuted) :- node(n177,refuted).
node(n174,unknown) :- \+ node(n174,supported), \+ node(n174,refuted).
node(n169,refuted) :- node(n170,refuted), node(n174,refuted), node(n9,refuted).
node(n169,supported) :- node(n170,supported).
node(n169,supported) :- node(n174,supported).
node(n169,supported) :- node(n9,supported).
node(n169,unknown) :- \+ node(n169,supported), \+ node(n169,refuted).
verdict(c_26ef71cdfaf60d6b,supported) :- node(n169,supported).
query(verdict(c_26ef71cdfaf60d6b,supported)).
verdict(c_26ef71cdfaf60d6b,refuted) :- node(n169,refuted).
query(verdict(c_26ef71cdfaf60d6b,refuted)).
verdict(c_26ef71cdfaf60d6b,unknown) :- node(n169,unknown).
query(verdict(c_26ef71cdfaf60d6b,unknown)).
node(n180,supported) :- status(o_1959c21204d936b7bb18,supported).
node(n180,refuted) :- status(o_1959c21204d936b7bb18,refuted).
node(n180,unknown) :- status(o_1959c21204d936b7bb18,unknown).
node(n179,supported) :- node(n171,supported), node(n172,supported), node(n180,supported), node(n173,supported).
node(n179,refuted) :- node(n171,refuted).
node(n179,refuted) :- node(n172,refuted).
node(n179,refuted) :- node(n180,refuted).
node(n179,refuted) :- node(n173,refuted).
node(n179,unknown) :- \+ node(n179,supported), \+ node(n179,refuted).
node(n182,supported) :- status(o_9da1edaecfe98641b294,supported).
node(n182,refuted) :- status(o_9da1edaecfe98641b294,refuted).
node(n182,unknown) :- status(o_9da1edaecfe98641b294,unknown).
node(n181,supported) :- node(n175,supported), node(n176,supported), node(n182,supported), node(n177,supported).
node(n181,refuted) :- node(n175,refuted).
node(n181,refuted) :- node(n176,refuted).
node(n181,refuted) :- node(n182,refuted).
node(n181,refuted) :- node(n177,refuted).
node(n181,unknown) :- \+ node(n181,supported), \+ node(n181,refuted).
node(n178,refuted) :- node(n179,refuted), node(n181,refuted), node(n9,refuted).
node(n178,supported) :- node(n179,supported).
node(n178,supported) :- node(n181,supported).
node(n178,supported) :- node(n9,supported).
node(n178,unknown) :- \+ node(n178,supported), \+ node(n178,refuted).
verdict(c_601f25244df69984,supported) :- node(n178,supported).
query(verdict(c_601f25244df69984,supported)).
verdict(c_601f25244df69984,refuted) :- node(n178,refuted).
query(verdict(c_601f25244df69984,refuted)).
verdict(c_601f25244df69984,unknown) :- node(n178,unknown).
query(verdict(c_601f25244df69984,unknown)).
node(n185,supported) :- status(o_51b7c3bed597455aec56,supported).
node(n185,refuted) :- status(o_51b7c3bed597455aec56,refuted).
node(n185,unknown) :- status(o_51b7c3bed597455aec56,unknown).
node(n186,supported) :- status(o_f296509176f1f25458ff,supported).
node(n186,refuted) :- status(o_f296509176f1f25458ff,refuted).
node(n186,unknown) :- status(o_f296509176f1f25458ff,unknown).
node(n187,supported) :- status(o_4693b80ef71d719f4d3e,supported).
node(n187,refuted) :- status(o_4693b80ef71d719f4d3e,refuted).
node(n187,unknown) :- status(o_4693b80ef71d719f4d3e,unknown).
node(n184,supported) :- node(n185,supported), node(n186,supported), node(n187,supported).
node(n184,refuted) :- node(n185,refuted).
node(n184,refuted) :- node(n186,refuted).
node(n184,refuted) :- node(n187,refuted).
node(n184,unknown) :- \+ node(n184,supported), \+ node(n184,refuted).
node(n189,supported) :- status(o_a3a4e1a87af149f975dc,supported).
node(n189,refuted) :- status(o_a3a4e1a87af149f975dc,refuted).
node(n189,unknown) :- status(o_a3a4e1a87af149f975dc,unknown).
node(n190,supported) :- status(o_e4813344d64f93dec787,supported).
node(n190,refuted) :- status(o_e4813344d64f93dec787,refuted).
node(n190,unknown) :- status(o_e4813344d64f93dec787,unknown).
node(n191,supported) :- status(o_359ff78e6704a5fbcafa,supported).
node(n191,refuted) :- status(o_359ff78e6704a5fbcafa,refuted).
node(n191,unknown) :- status(o_359ff78e6704a5fbcafa,unknown).
node(n188,supported) :- node(n189,supported), node(n190,supported), node(n191,supported).
node(n188,refuted) :- node(n189,refuted).
node(n188,refuted) :- node(n190,refuted).
node(n188,refuted) :- node(n191,refuted).
node(n188,unknown) :- \+ node(n188,supported), \+ node(n188,refuted).
node(n183,refuted) :- node(n184,refuted), node(n188,refuted), node(n9,refuted).
node(n183,supported) :- node(n184,supported).
node(n183,supported) :- node(n188,supported).
node(n183,supported) :- node(n9,supported).
node(n183,unknown) :- \+ node(n183,supported), \+ node(n183,refuted).
verdict(c_c8b52f895e41c83c,supported) :- node(n183,supported).
query(verdict(c_c8b52f895e41c83c,supported)).
verdict(c_c8b52f895e41c83c,refuted) :- node(n183,refuted).
query(verdict(c_c8b52f895e41c83c,refuted)).
verdict(c_c8b52f895e41c83c,unknown) :- node(n183,unknown).
query(verdict(c_c8b52f895e41c83c,unknown)).
node(n194,supported) :- status(o_318192354e832d2c844f,supported).
node(n194,refuted) :- status(o_318192354e832d2c844f,refuted).
node(n194,unknown) :- status(o_318192354e832d2c844f,unknown).
node(n193,supported) :- node(n185,supported), node(n186,supported), node(n194,supported), node(n187,supported).
node(n193,refuted) :- node(n185,refuted).
node(n193,refuted) :- node(n186,refuted).
node(n193,refuted) :- node(n194,refuted).
node(n193,refuted) :- node(n187,refuted).
node(n193,unknown) :- \+ node(n193,supported), \+ node(n193,refuted).
node(n196,supported) :- status(o_1dae4fe2cf3e39a0b459,supported).
node(n196,refuted) :- status(o_1dae4fe2cf3e39a0b459,refuted).
node(n196,unknown) :- status(o_1dae4fe2cf3e39a0b459,unknown).
node(n195,supported) :- node(n189,supported), node(n190,supported), node(n196,supported), node(n191,supported).
node(n195,refuted) :- node(n189,refuted).
node(n195,refuted) :- node(n190,refuted).
node(n195,refuted) :- node(n196,refuted).
node(n195,refuted) :- node(n191,refuted).
node(n195,unknown) :- \+ node(n195,supported), \+ node(n195,refuted).
node(n192,refuted) :- node(n193,refuted), node(n195,refuted), node(n9,refuted).
node(n192,supported) :- node(n193,supported).
node(n192,supported) :- node(n195,supported).
node(n192,supported) :- node(n9,supported).
node(n192,unknown) :- \+ node(n192,supported), \+ node(n192,refuted).
verdict(c_873e074d92a715a8,supported) :- node(n192,supported).
query(verdict(c_873e074d92a715a8,supported)).
verdict(c_873e074d92a715a8,refuted) :- node(n192,refuted).
query(verdict(c_873e074d92a715a8,refuted)).
verdict(c_873e074d92a715a8,unknown) :- node(n192,unknown).
query(verdict(c_873e074d92a715a8,unknown)).
node(n199,supported) :- status(o_5ddedab498303c96e83a,supported).
node(n199,refuted) :- status(o_5ddedab498303c96e83a,refuted).
node(n199,unknown) :- status(o_5ddedab498303c96e83a,unknown).
node(n200,supported) :- status(o_98db8628004b5feefd23,supported).
node(n200,refuted) :- status(o_98db8628004b5feefd23,refuted).
node(n200,unknown) :- status(o_98db8628004b5feefd23,unknown).
node(n201,supported) :- status(o_5cf58a7b7b034e427bcc,supported).
node(n201,refuted) :- status(o_5cf58a7b7b034e427bcc,refuted).
node(n201,unknown) :- status(o_5cf58a7b7b034e427bcc,unknown).
node(n198,supported) :- node(n199,supported), node(n200,supported), node(n201,supported).
node(n198,refuted) :- node(n199,refuted).
node(n198,refuted) :- node(n200,refuted).
node(n198,refuted) :- node(n201,refuted).
node(n198,unknown) :- \+ node(n198,supported), \+ node(n198,refuted).
node(n203,supported) :- status(o_1b90e36801a3fa33f344,supported).
node(n203,refuted) :- status(o_1b90e36801a3fa33f344,refuted).
node(n203,unknown) :- status(o_1b90e36801a3fa33f344,unknown).
node(n204,supported) :- status(o_203f97a458cb512201d8,supported).
node(n204,refuted) :- status(o_203f97a458cb512201d8,refuted).
node(n204,unknown) :- status(o_203f97a458cb512201d8,unknown).
node(n205,supported) :- status(o_9c8bfa8f1f3de7e45ace,supported).
node(n205,refuted) :- status(o_9c8bfa8f1f3de7e45ace,refuted).
node(n205,unknown) :- status(o_9c8bfa8f1f3de7e45ace,unknown).
node(n202,supported) :- node(n203,supported), node(n204,supported), node(n205,supported).
node(n202,refuted) :- node(n203,refuted).
node(n202,refuted) :- node(n204,refuted).
node(n202,refuted) :- node(n205,refuted).
node(n202,unknown) :- \+ node(n202,supported), \+ node(n202,refuted).
node(n197,refuted) :- node(n198,refuted), node(n202,refuted), node(n9,refuted).
node(n197,supported) :- node(n198,supported).
node(n197,supported) :- node(n202,supported).
node(n197,supported) :- node(n9,supported).
node(n197,unknown) :- \+ node(n197,supported), \+ node(n197,refuted).
verdict(c_e0fe8a36bc3577ea,supported) :- node(n197,supported).
query(verdict(c_e0fe8a36bc3577ea,supported)).
verdict(c_e0fe8a36bc3577ea,refuted) :- node(n197,refuted).
query(verdict(c_e0fe8a36bc3577ea,refuted)).
verdict(c_e0fe8a36bc3577ea,unknown) :- node(n197,unknown).
query(verdict(c_e0fe8a36bc3577ea,unknown)).
node(n208,supported) :- status(o_cece0fee3cf3a62f2296,supported).
node(n208,refuted) :- status(o_cece0fee3cf3a62f2296,refuted).
node(n208,unknown) :- status(o_cece0fee3cf3a62f2296,unknown).
node(n207,supported) :- node(n199,supported), node(n200,supported), node(n208,supported), node(n201,supported).
node(n207,refuted) :- node(n199,refuted).
node(n207,refuted) :- node(n200,refuted).
node(n207,refuted) :- node(n208,refuted).
node(n207,refuted) :- node(n201,refuted).
node(n207,unknown) :- \+ node(n207,supported), \+ node(n207,refuted).
node(n210,supported) :- status(o_8649ee2b8fb56fa387a2,supported).
node(n210,refuted) :- status(o_8649ee2b8fb56fa387a2,refuted).
node(n210,unknown) :- status(o_8649ee2b8fb56fa387a2,unknown).
node(n209,supported) :- node(n203,supported), node(n204,supported), node(n210,supported), node(n205,supported).
node(n209,refuted) :- node(n203,refuted).
node(n209,refuted) :- node(n204,refuted).
node(n209,refuted) :- node(n210,refuted).
node(n209,refuted) :- node(n205,refuted).
node(n209,unknown) :- \+ node(n209,supported), \+ node(n209,refuted).
node(n206,refuted) :- node(n207,refuted), node(n209,refuted), node(n9,refuted).
node(n206,supported) :- node(n207,supported).
node(n206,supported) :- node(n209,supported).
node(n206,supported) :- node(n9,supported).
node(n206,unknown) :- \+ node(n206,supported), \+ node(n206,refuted).
verdict(c_ac4b3d0d4181b7ca,supported) :- node(n206,supported).
query(verdict(c_ac4b3d0d4181b7ca,supported)).
verdict(c_ac4b3d0d4181b7ca,refuted) :- node(n206,refuted).
query(verdict(c_ac4b3d0d4181b7ca,refuted)).
verdict(c_ac4b3d0d4181b7ca,unknown) :- node(n206,unknown).
query(verdict(c_ac4b3d0d4181b7ca,unknown)).
node(n213,supported) :- status(o_df4f7af0f7119c6cd395,supported).
node(n213,refuted) :- status(o_df4f7af0f7119c6cd395,refuted).
node(n213,unknown) :- status(o_df4f7af0f7119c6cd395,unknown).
node(n214,supported) :- status(o_399e75495498d0ab2deb,supported).
node(n214,refuted) :- status(o_399e75495498d0ab2deb,refuted).
node(n214,unknown) :- status(o_399e75495498d0ab2deb,unknown).
node(n215,supported) :- status(o_297e59f156505592a4b0,supported).
node(n215,refuted) :- status(o_297e59f156505592a4b0,refuted).
node(n215,unknown) :- status(o_297e59f156505592a4b0,unknown).
node(n212,supported) :- node(n213,supported), node(n214,supported), node(n215,supported).
node(n212,refuted) :- node(n213,refuted).
node(n212,refuted) :- node(n214,refuted).
node(n212,refuted) :- node(n215,refuted).
node(n212,unknown) :- \+ node(n212,supported), \+ node(n212,refuted).
node(n217,supported) :- status(o_7dadf53904ba4c0f227a,supported).
node(n217,refuted) :- status(o_7dadf53904ba4c0f227a,refuted).
node(n217,unknown) :- status(o_7dadf53904ba4c0f227a,unknown).
node(n218,supported) :- status(o_fb4f999100b6d242ae1c,supported).
node(n218,refuted) :- status(o_fb4f999100b6d242ae1c,refuted).
node(n218,unknown) :- status(o_fb4f999100b6d242ae1c,unknown).
node(n219,supported) :- status(o_2f8672e418d2c4cb048a,supported).
node(n219,refuted) :- status(o_2f8672e418d2c4cb048a,refuted).
node(n219,unknown) :- status(o_2f8672e418d2c4cb048a,unknown).
node(n216,supported) :- node(n217,supported), node(n218,supported), node(n219,supported).
node(n216,refuted) :- node(n217,refuted).
node(n216,refuted) :- node(n218,refuted).
node(n216,refuted) :- node(n219,refuted).
node(n216,unknown) :- \+ node(n216,supported), \+ node(n216,refuted).
node(n211,refuted) :- node(n212,refuted), node(n216,refuted), node(n9,refuted).
node(n211,supported) :- node(n212,supported).
node(n211,supported) :- node(n216,supported).
node(n211,supported) :- node(n9,supported).
node(n211,unknown) :- \+ node(n211,supported), \+ node(n211,refuted).
verdict(c_82295b80b52f6f9e,supported) :- node(n211,supported).
query(verdict(c_82295b80b52f6f9e,supported)).
verdict(c_82295b80b52f6f9e,refuted) :- node(n211,refuted).
query(verdict(c_82295b80b52f6f9e,refuted)).
verdict(c_82295b80b52f6f9e,unknown) :- node(n211,unknown).
query(verdict(c_82295b80b52f6f9e,unknown)).
node(n222,supported) :- status(o_ee8a25ae07d4cb7d488c,supported).
node(n222,refuted) :- status(o_ee8a25ae07d4cb7d488c,refuted).
node(n222,unknown) :- status(o_ee8a25ae07d4cb7d488c,unknown).
node(n221,supported) :- node(n213,supported), node(n214,supported), node(n222,supported), node(n215,supported).
node(n221,refuted) :- node(n213,refuted).
node(n221,refuted) :- node(n214,refuted).
node(n221,refuted) :- node(n222,refuted).
node(n221,refuted) :- node(n215,refuted).
node(n221,unknown) :- \+ node(n221,supported), \+ node(n221,refuted).
node(n224,supported) :- status(o_6d34ed7be83f472c3061,supported).
node(n224,refuted) :- status(o_6d34ed7be83f472c3061,refuted).
node(n224,unknown) :- status(o_6d34ed7be83f472c3061,unknown).
node(n223,supported) :- node(n217,supported), node(n218,supported), node(n224,supported), node(n219,supported).
node(n223,refuted) :- node(n217,refuted).
node(n223,refuted) :- node(n218,refuted).
node(n223,refuted) :- node(n224,refuted).
node(n223,refuted) :- node(n219,refuted).
node(n223,unknown) :- \+ node(n223,supported), \+ node(n223,refuted).
node(n220,refuted) :- node(n221,refuted), node(n223,refuted), node(n9,refuted).
node(n220,supported) :- node(n221,supported).
node(n220,supported) :- node(n223,supported).
node(n220,supported) :- node(n9,supported).
node(n220,unknown) :- \+ node(n220,supported), \+ node(n220,refuted).
verdict(c_a8ef21e3ee90f71e,supported) :- node(n220,supported).
query(verdict(c_a8ef21e3ee90f71e,supported)).
verdict(c_a8ef21e3ee90f71e,refuted) :- node(n220,refuted).
query(verdict(c_a8ef21e3ee90f71e,refuted)).
verdict(c_a8ef21e3ee90f71e,unknown) :- node(n220,unknown).
query(verdict(c_a8ef21e3ee90f71e,unknown)).
node(n227,supported) :- status(o_74607d141de396bc1302,supported).
node(n227,refuted) :- status(o_74607d141de396bc1302,refuted).
node(n227,unknown) :- status(o_74607d141de396bc1302,unknown).
node(n228,supported) :- status(o_847be245a2f62b39c3e8,supported).
node(n228,refuted) :- status(o_847be245a2f62b39c3e8,refuted).
node(n228,unknown) :- status(o_847be245a2f62b39c3e8,unknown).
node(n229,supported) :- status(o_2c392a06444f4cd5bd26,supported).
node(n229,refuted) :- status(o_2c392a06444f4cd5bd26,refuted).
node(n229,unknown) :- status(o_2c392a06444f4cd5bd26,unknown).
node(n226,supported) :- node(n227,supported), node(n228,supported), node(n229,supported).
node(n226,refuted) :- node(n227,refuted).
node(n226,refuted) :- node(n228,refuted).
node(n226,refuted) :- node(n229,refuted).
node(n226,unknown) :- \+ node(n226,supported), \+ node(n226,refuted).
node(n231,supported) :- status(o_cb3f44454338804a17bb,supported).
node(n231,refuted) :- status(o_cb3f44454338804a17bb,refuted).
node(n231,unknown) :- status(o_cb3f44454338804a17bb,unknown).
node(n232,supported) :- status(o_f222a7cb466a0384cde9,supported).
node(n232,refuted) :- status(o_f222a7cb466a0384cde9,refuted).
node(n232,unknown) :- status(o_f222a7cb466a0384cde9,unknown).
node(n233,supported) :- status(o_1ab9ae7073de465c322d,supported).
node(n233,refuted) :- status(o_1ab9ae7073de465c322d,refuted).
node(n233,unknown) :- status(o_1ab9ae7073de465c322d,unknown).
node(n230,supported) :- node(n231,supported), node(n232,supported), node(n233,supported).
node(n230,refuted) :- node(n231,refuted).
node(n230,refuted) :- node(n232,refuted).
node(n230,refuted) :- node(n233,refuted).
node(n230,unknown) :- \+ node(n230,supported), \+ node(n230,refuted).
node(n225,refuted) :- node(n226,refuted), node(n230,refuted), node(n9,refuted).
node(n225,supported) :- node(n226,supported).
node(n225,supported) :- node(n230,supported).
node(n225,supported) :- node(n9,supported).
node(n225,unknown) :- \+ node(n225,supported), \+ node(n225,refuted).
verdict(c_077e9982a16d9e0d,supported) :- node(n225,supported).
query(verdict(c_077e9982a16d9e0d,supported)).
verdict(c_077e9982a16d9e0d,refuted) :- node(n225,refuted).
query(verdict(c_077e9982a16d9e0d,refuted)).
verdict(c_077e9982a16d9e0d,unknown) :- node(n225,unknown).
query(verdict(c_077e9982a16d9e0d,unknown)).
node(n236,supported) :- status(o_396fa5905bb77d9558a3,supported).
node(n236,refuted) :- status(o_396fa5905bb77d9558a3,refuted).
node(n236,unknown) :- status(o_396fa5905bb77d9558a3,unknown).
node(n235,supported) :- node(n227,supported), node(n228,supported), node(n236,supported), node(n229,supported).
node(n235,refuted) :- node(n227,refuted).
node(n235,refuted) :- node(n228,refuted).
node(n235,refuted) :- node(n236,refuted).
node(n235,refuted) :- node(n229,refuted).
node(n235,unknown) :- \+ node(n235,supported), \+ node(n235,refuted).
node(n238,supported) :- status(o_c6913096ba00a1d58047,supported).
node(n238,refuted) :- status(o_c6913096ba00a1d58047,refuted).
node(n238,unknown) :- status(o_c6913096ba00a1d58047,unknown).
node(n237,supported) :- node(n231,supported), node(n232,supported), node(n238,supported), node(n233,supported).
node(n237,refuted) :- node(n231,refuted).
node(n237,refuted) :- node(n232,refuted).
node(n237,refuted) :- node(n238,refuted).
node(n237,refuted) :- node(n233,refuted).
node(n237,unknown) :- \+ node(n237,supported), \+ node(n237,refuted).
node(n234,refuted) :- node(n235,refuted), node(n237,refuted), node(n9,refuted).
node(n234,supported) :- node(n235,supported).
node(n234,supported) :- node(n237,supported).
node(n234,supported) :- node(n9,supported).
node(n234,unknown) :- \+ node(n234,supported), \+ node(n234,refuted).
verdict(c_ba8adb18b5bf5c46,supported) :- node(n234,supported).
query(verdict(c_ba8adb18b5bf5c46,supported)).
verdict(c_ba8adb18b5bf5c46,refuted) :- node(n234,refuted).
query(verdict(c_ba8adb18b5bf5c46,refuted)).
verdict(c_ba8adb18b5bf5c46,unknown) :- node(n234,unknown).
query(verdict(c_ba8adb18b5bf5c46,unknown)).
node(n241,supported) :- status(o_3ebfdaacc153b1aec974,supported).
node(n241,refuted) :- status(o_3ebfdaacc153b1aec974,refuted).
node(n241,unknown) :- status(o_3ebfdaacc153b1aec974,unknown).
node(n242,supported) :- status(o_373177f9ba14320bdde9,supported).
node(n242,refuted) :- status(o_373177f9ba14320bdde9,refuted).
node(n242,unknown) :- status(o_373177f9ba14320bdde9,unknown).
node(n243,supported) :- status(o_ccc3257e5f93554db0b1,supported).
node(n243,refuted) :- status(o_ccc3257e5f93554db0b1,refuted).
node(n243,unknown) :- status(o_ccc3257e5f93554db0b1,unknown).
node(n240,supported) :- node(n241,supported), node(n242,supported), node(n243,supported).
node(n240,refuted) :- node(n241,refuted).
node(n240,refuted) :- node(n242,refuted).
node(n240,refuted) :- node(n243,refuted).
node(n240,unknown) :- \+ node(n240,supported), \+ node(n240,refuted).
node(n245,supported) :- status(o_fd8b24f518d8ddb9e11e,supported).
node(n245,refuted) :- status(o_fd8b24f518d8ddb9e11e,refuted).
node(n245,unknown) :- status(o_fd8b24f518d8ddb9e11e,unknown).
node(n246,supported) :- status(o_184dfd465f9165e3b445,supported).
node(n246,refuted) :- status(o_184dfd465f9165e3b445,refuted).
node(n246,unknown) :- status(o_184dfd465f9165e3b445,unknown).
node(n247,supported) :- status(o_5ba37f7ae93210d01b8d,supported).
node(n247,refuted) :- status(o_5ba37f7ae93210d01b8d,refuted).
node(n247,unknown) :- status(o_5ba37f7ae93210d01b8d,unknown).
node(n244,supported) :- node(n245,supported), node(n246,supported), node(n247,supported).
node(n244,refuted) :- node(n245,refuted).
node(n244,refuted) :- node(n246,refuted).
node(n244,refuted) :- node(n247,refuted).
node(n244,unknown) :- \+ node(n244,supported), \+ node(n244,refuted).
node(n239,refuted) :- node(n240,refuted), node(n244,refuted), node(n9,refuted).
node(n239,supported) :- node(n240,supported).
node(n239,supported) :- node(n244,supported).
node(n239,supported) :- node(n9,supported).
node(n239,unknown) :- \+ node(n239,supported), \+ node(n239,refuted).
verdict(c_52aef3d653cdce86,supported) :- node(n239,supported).
query(verdict(c_52aef3d653cdce86,supported)).
verdict(c_52aef3d653cdce86,refuted) :- node(n239,refuted).
query(verdict(c_52aef3d653cdce86,refuted)).
verdict(c_52aef3d653cdce86,unknown) :- node(n239,unknown).
query(verdict(c_52aef3d653cdce86,unknown)).
node(n250,supported) :- status(o_c1a0ea0a90ddc374bee9,supported).
node(n250,refuted) :- status(o_c1a0ea0a90ddc374bee9,refuted).
node(n250,unknown) :- status(o_c1a0ea0a90ddc374bee9,unknown).
node(n249,supported) :- node(n241,supported), node(n242,supported), node(n250,supported), node(n243,supported).
node(n249,refuted) :- node(n241,refuted).
node(n249,refuted) :- node(n242,refuted).
node(n249,refuted) :- node(n250,refuted).
node(n249,refuted) :- node(n243,refuted).
node(n249,unknown) :- \+ node(n249,supported), \+ node(n249,refuted).
node(n252,supported) :- status(o_2922fca11dca06c5894e,supported).
node(n252,refuted) :- status(o_2922fca11dca06c5894e,refuted).
node(n252,unknown) :- status(o_2922fca11dca06c5894e,unknown).
node(n251,supported) :- node(n245,supported), node(n246,supported), node(n252,supported), node(n247,supported).
node(n251,refuted) :- node(n245,refuted).
node(n251,refuted) :- node(n246,refuted).
node(n251,refuted) :- node(n252,refuted).
node(n251,refuted) :- node(n247,refuted).
node(n251,unknown) :- \+ node(n251,supported), \+ node(n251,refuted).
node(n248,refuted) :- node(n249,refuted), node(n251,refuted), node(n9,refuted).
node(n248,supported) :- node(n249,supported).
node(n248,supported) :- node(n251,supported).
node(n248,supported) :- node(n9,supported).
node(n248,unknown) :- \+ node(n248,supported), \+ node(n248,refuted).
verdict(c_d7bb67071992fd45,supported) :- node(n248,supported).
query(verdict(c_d7bb67071992fd45,supported)).
verdict(c_d7bb67071992fd45,refuted) :- node(n248,refuted).
query(verdict(c_d7bb67071992fd45,refuted)).
verdict(c_d7bb67071992fd45,unknown) :- node(n248,unknown).
query(verdict(c_d7bb67071992fd45,unknown)).
node(n255,supported) :- status(o_ad515c2cab6f8e2eba96,supported).
node(n255,refuted) :- status(o_ad515c2cab6f8e2eba96,refuted).
node(n255,unknown) :- status(o_ad515c2cab6f8e2eba96,unknown).
node(n256,supported) :- status(o_2d96fc15d0de6148efc9,supported).
node(n256,refuted) :- status(o_2d96fc15d0de6148efc9,refuted).
node(n256,unknown) :- status(o_2d96fc15d0de6148efc9,unknown).
node(n257,supported) :- status(o_44618462cec09485859f,supported).
node(n257,refuted) :- status(o_44618462cec09485859f,refuted).
node(n257,unknown) :- status(o_44618462cec09485859f,unknown).
node(n254,supported) :- node(n255,supported), node(n256,supported), node(n257,supported).
node(n254,refuted) :- node(n255,refuted).
node(n254,refuted) :- node(n256,refuted).
node(n254,refuted) :- node(n257,refuted).
node(n254,unknown) :- \+ node(n254,supported), \+ node(n254,refuted).
node(n253,refuted) :- node(n254,refuted), node(n9,refuted).
node(n253,supported) :- node(n254,supported).
node(n253,supported) :- node(n9,supported).
node(n253,unknown) :- \+ node(n253,supported), \+ node(n253,refuted).
verdict(c_ffdf8a87b74aaafb,supported) :- node(n253,supported).
query(verdict(c_ffdf8a87b74aaafb,supported)).
verdict(c_ffdf8a87b74aaafb,refuted) :- node(n253,refuted).
query(verdict(c_ffdf8a87b74aaafb,refuted)).
verdict(c_ffdf8a87b74aaafb,unknown) :- node(n253,unknown).
query(verdict(c_ffdf8a87b74aaafb,unknown)).
node(n260,supported) :- status(o_5ba8da655c850e0036e8,supported).
node(n260,refuted) :- status(o_5ba8da655c850e0036e8,refuted).
node(n260,unknown) :- status(o_5ba8da655c850e0036e8,unknown).
node(n259,supported) :- node(n255,supported), node(n256,supported), node(n260,supported), node(n257,supported).
node(n259,refuted) :- node(n255,refuted).
node(n259,refuted) :- node(n256,refuted).
node(n259,refuted) :- node(n260,refuted).
node(n259,refuted) :- node(n257,refuted).
node(n259,unknown) :- \+ node(n259,supported), \+ node(n259,refuted).
node(n258,refuted) :- node(n259,refuted), node(n9,refuted).
node(n258,supported) :- node(n259,supported).
node(n258,supported) :- node(n9,supported).
node(n258,unknown) :- \+ node(n258,supported), \+ node(n258,refuted).
verdict(c_6485e19df482c56d,supported) :- node(n258,supported).
query(verdict(c_6485e19df482c56d,supported)).
verdict(c_6485e19df482c56d,refuted) :- node(n258,refuted).
query(verdict(c_6485e19df482c56d,refuted)).
verdict(c_6485e19df482c56d,unknown) :- node(n258,unknown).
query(verdict(c_6485e19df482c56d,unknown)).
node(n263,supported) :- status(o_15cbdee1adc3cc0bb827,supported).
node(n263,refuted) :- status(o_15cbdee1adc3cc0bb827,refuted).
node(n263,unknown) :- status(o_15cbdee1adc3cc0bb827,unknown).
node(n264,supported) :- status(o_c55c64c7eea4170106d8,supported).
node(n264,refuted) :- status(o_c55c64c7eea4170106d8,refuted).
node(n264,unknown) :- status(o_c55c64c7eea4170106d8,unknown).
node(n265,supported) :- status(o_3955123710d5107f611e,supported).
node(n265,refuted) :- status(o_3955123710d5107f611e,refuted).
node(n265,unknown) :- status(o_3955123710d5107f611e,unknown).
node(n262,supported) :- node(n263,supported), node(n264,supported), node(n265,supported).
node(n262,refuted) :- node(n263,refuted).
node(n262,refuted) :- node(n264,refuted).
node(n262,refuted) :- node(n265,refuted).
node(n262,unknown) :- \+ node(n262,supported), \+ node(n262,refuted).
node(n261,refuted) :- node(n262,refuted), node(n9,refuted).
node(n261,supported) :- node(n262,supported).
node(n261,supported) :- node(n9,supported).
node(n261,unknown) :- \+ node(n261,supported), \+ node(n261,refuted).
verdict(c_47627cfb1d1c44a2,supported) :- node(n261,supported).
query(verdict(c_47627cfb1d1c44a2,supported)).
verdict(c_47627cfb1d1c44a2,refuted) :- node(n261,refuted).
query(verdict(c_47627cfb1d1c44a2,refuted)).
verdict(c_47627cfb1d1c44a2,unknown) :- node(n261,unknown).
query(verdict(c_47627cfb1d1c44a2,unknown)).
node(n268,supported) :- status(o_fbfbd5bd60bb6478e94d,supported).
node(n268,refuted) :- status(o_fbfbd5bd60bb6478e94d,refuted).
node(n268,unknown) :- status(o_fbfbd5bd60bb6478e94d,unknown).
node(n267,supported) :- node(n263,supported), node(n264,supported), node(n268,supported), node(n265,supported).
node(n267,refuted) :- node(n263,refuted).
node(n267,refuted) :- node(n264,refuted).
node(n267,refuted) :- node(n268,refuted).
node(n267,refuted) :- node(n265,refuted).
node(n267,unknown) :- \+ node(n267,supported), \+ node(n267,refuted).
node(n266,refuted) :- node(n267,refuted), node(n9,refuted).
node(n266,supported) :- node(n267,supported).
node(n266,supported) :- node(n9,supported).
node(n266,unknown) :- \+ node(n266,supported), \+ node(n266,refuted).
verdict(c_ac33778fd48e5b14,supported) :- node(n266,supported).
query(verdict(c_ac33778fd48e5b14,supported)).
verdict(c_ac33778fd48e5b14,refuted) :- node(n266,refuted).
query(verdict(c_ac33778fd48e5b14,refuted)).
verdict(c_ac33778fd48e5b14,unknown) :- node(n266,unknown).
query(verdict(c_ac33778fd48e5b14,unknown)).
node(n271,supported) :- status(o_ead10d7a9bffcca8d20f,supported).
node(n271,refuted) :- status(o_ead10d7a9bffcca8d20f,refuted).
node(n271,unknown) :- status(o_ead10d7a9bffcca8d20f,unknown).
node(n272,supported) :- status(o_a8b5da03e7ff284e8699,supported).
node(n272,refuted) :- status(o_a8b5da03e7ff284e8699,refuted).
node(n272,unknown) :- status(o_a8b5da03e7ff284e8699,unknown).
node(n273,supported) :- status(o_4124816458cc7be7791d,supported).
node(n273,refuted) :- status(o_4124816458cc7be7791d,refuted).
node(n273,unknown) :- status(o_4124816458cc7be7791d,unknown).
node(n270,supported) :- node(n271,supported), node(n272,supported), node(n273,supported).
node(n270,refuted) :- node(n271,refuted).
node(n270,refuted) :- node(n272,refuted).
node(n270,refuted) :- node(n273,refuted).
node(n270,unknown) :- \+ node(n270,supported), \+ node(n270,refuted).
node(n269,refuted) :- node(n270,refuted), node(n9,refuted).
node(n269,supported) :- node(n270,supported).
node(n269,supported) :- node(n9,supported).
node(n269,unknown) :- \+ node(n269,supported), \+ node(n269,refuted).
verdict(c_96ff3396e5fe6d4a,supported) :- node(n269,supported).
query(verdict(c_96ff3396e5fe6d4a,supported)).
verdict(c_96ff3396e5fe6d4a,refuted) :- node(n269,refuted).
query(verdict(c_96ff3396e5fe6d4a,refuted)).
verdict(c_96ff3396e5fe6d4a,unknown) :- node(n269,unknown).
query(verdict(c_96ff3396e5fe6d4a,unknown)).
node(n276,supported) :- status(o_f1e6623d7b7c46c10405,supported).
node(n276,refuted) :- status(o_f1e6623d7b7c46c10405,refuted).
node(n276,unknown) :- status(o_f1e6623d7b7c46c10405,unknown).
node(n275,supported) :- node(n271,supported), node(n272,supported), node(n276,supported), node(n273,supported).
node(n275,refuted) :- node(n271,refuted).
node(n275,refuted) :- node(n272,refuted).
node(n275,refuted) :- node(n276,refuted).
node(n275,refuted) :- node(n273,refuted).
node(n275,unknown) :- \+ node(n275,supported), \+ node(n275,refuted).
node(n274,refuted) :- node(n275,refuted), node(n9,refuted).
node(n274,supported) :- node(n275,supported).
node(n274,supported) :- node(n9,supported).
node(n274,unknown) :- \+ node(n274,supported), \+ node(n274,refuted).
verdict(c_16b001e3b0b34138,supported) :- node(n274,supported).
query(verdict(c_16b001e3b0b34138,supported)).
verdict(c_16b001e3b0b34138,refuted) :- node(n274,refuted).
query(verdict(c_16b001e3b0b34138,refuted)).
verdict(c_16b001e3b0b34138,unknown) :- node(n274,unknown).
query(verdict(c_16b001e3b0b34138,unknown)).
node(n279,supported) :- status(o_4ccbe967e40edc2464d9,supported).
node(n279,refuted) :- status(o_4ccbe967e40edc2464d9,refuted).
node(n279,unknown) :- status(o_4ccbe967e40edc2464d9,unknown).
node(n280,supported) :- status(o_7b3b724da1e045bcfdf5,supported).
node(n280,refuted) :- status(o_7b3b724da1e045bcfdf5,refuted).
node(n280,unknown) :- status(o_7b3b724da1e045bcfdf5,unknown).
node(n281,supported) :- status(o_461ada905dff67f06def,supported).
node(n281,refuted) :- status(o_461ada905dff67f06def,refuted).
node(n281,unknown) :- status(o_461ada905dff67f06def,unknown).
node(n278,supported) :- node(n279,supported), node(n280,supported), node(n281,supported).
node(n278,refuted) :- node(n279,refuted).
node(n278,refuted) :- node(n280,refuted).
node(n278,refuted) :- node(n281,refuted).
node(n278,unknown) :- \+ node(n278,supported), \+ node(n278,refuted).
node(n277,refuted) :- node(n278,refuted), node(n9,refuted).
node(n277,supported) :- node(n278,supported).
node(n277,supported) :- node(n9,supported).
node(n277,unknown) :- \+ node(n277,supported), \+ node(n277,refuted).
verdict(c_001e3d7469e1b667,supported) :- node(n277,supported).
query(verdict(c_001e3d7469e1b667,supported)).
verdict(c_001e3d7469e1b667,refuted) :- node(n277,refuted).
query(verdict(c_001e3d7469e1b667,refuted)).
verdict(c_001e3d7469e1b667,unknown) :- node(n277,unknown).
query(verdict(c_001e3d7469e1b667,unknown)).
node(n284,supported) :- status(o_d3efe2aaf645e90c64e7,supported).
node(n284,refuted) :- status(o_d3efe2aaf645e90c64e7,refuted).
node(n284,unknown) :- status(o_d3efe2aaf645e90c64e7,unknown).
node(n283,supported) :- node(n279,supported), node(n280,supported), node(n284,supported), node(n281,supported).
node(n283,refuted) :- node(n279,refuted).
node(n283,refuted) :- node(n280,refuted).
node(n283,refuted) :- node(n284,refuted).
node(n283,refuted) :- node(n281,refuted).
node(n283,unknown) :- \+ node(n283,supported), \+ node(n283,refuted).
node(n282,refuted) :- node(n283,refuted), node(n9,refuted).
node(n282,supported) :- node(n283,supported).
node(n282,supported) :- node(n9,supported).
node(n282,unknown) :- \+ node(n282,supported), \+ node(n282,refuted).
verdict(c_98925e2561229c4b,supported) :- node(n282,supported).
query(verdict(c_98925e2561229c4b,supported)).
verdict(c_98925e2561229c4b,refuted) :- node(n282,refuted).
query(verdict(c_98925e2561229c4b,refuted)).
verdict(c_98925e2561229c4b,unknown) :- node(n282,unknown).
query(verdict(c_98925e2561229c4b,unknown)).
node(n287,supported) :- status(o_e05085af967da8e8a1cc,supported).
node(n287,refuted) :- status(o_e05085af967da8e8a1cc,refuted).
node(n287,unknown) :- status(o_e05085af967da8e8a1cc,unknown).
node(n288,supported) :- status(o_ada7dddae314288a80e4,supported).
node(n288,refuted) :- status(o_ada7dddae314288a80e4,refuted).
node(n288,unknown) :- status(o_ada7dddae314288a80e4,unknown).
node(n289,supported) :- status(o_a71f4ef44eba9fc6cb0e,supported).
node(n289,refuted) :- status(o_a71f4ef44eba9fc6cb0e,refuted).
node(n289,unknown) :- status(o_a71f4ef44eba9fc6cb0e,unknown).
node(n286,supported) :- node(n287,supported), node(n288,supported), node(n289,supported).
node(n286,refuted) :- node(n287,refuted).
node(n286,refuted) :- node(n288,refuted).
node(n286,refuted) :- node(n289,refuted).
node(n286,unknown) :- \+ node(n286,supported), \+ node(n286,refuted).
node(n285,refuted) :- node(n286,refuted), node(n9,refuted).
node(n285,supported) :- node(n286,supported).
node(n285,supported) :- node(n9,supported).
node(n285,unknown) :- \+ node(n285,supported), \+ node(n285,refuted).
verdict(c_30c647228e190e33,supported) :- node(n285,supported).
query(verdict(c_30c647228e190e33,supported)).
verdict(c_30c647228e190e33,refuted) :- node(n285,refuted).
query(verdict(c_30c647228e190e33,refuted)).
verdict(c_30c647228e190e33,unknown) :- node(n285,unknown).
query(verdict(c_30c647228e190e33,unknown)).
node(n292,supported) :- status(o_20a6b10f82f1bdb4116c,supported).
node(n292,refuted) :- status(o_20a6b10f82f1bdb4116c,refuted).
node(n292,unknown) :- status(o_20a6b10f82f1bdb4116c,unknown).
node(n291,supported) :- node(n287,supported), node(n288,supported), node(n292,supported), node(n289,supported).
node(n291,refuted) :- node(n287,refuted).
node(n291,refuted) :- node(n288,refuted).
node(n291,refuted) :- node(n292,refuted).
node(n291,refuted) :- node(n289,refuted).
node(n291,unknown) :- \+ node(n291,supported), \+ node(n291,refuted).
node(n290,refuted) :- node(n291,refuted), node(n9,refuted).
node(n290,supported) :- node(n291,supported).
node(n290,supported) :- node(n9,supported).
node(n290,unknown) :- \+ node(n290,supported), \+ node(n290,refuted).
verdict(c_d9e011e6e3bc951f,supported) :- node(n290,supported).
query(verdict(c_d9e011e6e3bc951f,supported)).
verdict(c_d9e011e6e3bc951f,refuted) :- node(n290,refuted).
query(verdict(c_d9e011e6e3bc951f,refuted)).
verdict(c_d9e011e6e3bc951f,unknown) :- node(n290,unknown).
query(verdict(c_d9e011e6e3bc951f,unknown)).
node(n295,supported) :- status(o_e07693f06d6eb6721439,supported).
node(n295,refuted) :- status(o_e07693f06d6eb6721439,refuted).
node(n295,unknown) :- status(o_e07693f06d6eb6721439,unknown).
node(n296,supported) :- status(o_41b5df560211afc7c834,supported).
node(n296,refuted) :- status(o_41b5df560211afc7c834,refuted).
node(n296,unknown) :- status(o_41b5df560211afc7c834,unknown).
node(n297,supported) :- status(o_fb68810a4bd828d5a04a,supported).
node(n297,refuted) :- status(o_fb68810a4bd828d5a04a,refuted).
node(n297,unknown) :- status(o_fb68810a4bd828d5a04a,unknown).
node(n294,supported) :- node(n295,supported), node(n296,supported), node(n297,supported).
node(n294,refuted) :- node(n295,refuted).
node(n294,refuted) :- node(n296,refuted).
node(n294,refuted) :- node(n297,refuted).
node(n294,unknown) :- \+ node(n294,supported), \+ node(n294,refuted).
node(n293,refuted) :- node(n294,refuted), node(n9,refuted).
node(n293,supported) :- node(n294,supported).
node(n293,supported) :- node(n9,supported).
node(n293,unknown) :- \+ node(n293,supported), \+ node(n293,refuted).
verdict(c_5daa57b065d5e03c,supported) :- node(n293,supported).
query(verdict(c_5daa57b065d5e03c,supported)).
verdict(c_5daa57b065d5e03c,refuted) :- node(n293,refuted).
query(verdict(c_5daa57b065d5e03c,refuted)).
verdict(c_5daa57b065d5e03c,unknown) :- node(n293,unknown).
query(verdict(c_5daa57b065d5e03c,unknown)).
node(n300,supported) :- status(o_27ba79585d8586cc1136,supported).
node(n300,refuted) :- status(o_27ba79585d8586cc1136,refuted).
node(n300,unknown) :- status(o_27ba79585d8586cc1136,unknown).
node(n299,supported) :- node(n295,supported), node(n296,supported), node(n300,supported), node(n297,supported).
node(n299,refuted) :- node(n295,refuted).
node(n299,refuted) :- node(n296,refuted).
node(n299,refuted) :- node(n300,refuted).
node(n299,refuted) :- node(n297,refuted).
node(n299,unknown) :- \+ node(n299,supported), \+ node(n299,refuted).
node(n298,refuted) :- node(n299,refuted), node(n9,refuted).
node(n298,supported) :- node(n299,supported).
node(n298,supported) :- node(n9,supported).
node(n298,unknown) :- \+ node(n298,supported), \+ node(n298,refuted).
verdict(c_5c64c208b425dd1b,supported) :- node(n298,supported).
query(verdict(c_5c64c208b425dd1b,supported)).
verdict(c_5c64c208b425dd1b,refuted) :- node(n298,refuted).
query(verdict(c_5c64c208b425dd1b,refuted)).
verdict(c_5c64c208b425dd1b,unknown) :- node(n298,unknown).
query(verdict(c_5c64c208b425dd1b,unknown)).
node(n303,supported) :- status(o_6f0f32e8b6895343eeb1,supported).
node(n303,refuted) :- status(o_6f0f32e8b6895343eeb1,refuted).
node(n303,unknown) :- status(o_6f0f32e8b6895343eeb1,unknown).
node(n304,supported) :- status(o_8a26b3ed952a1c4018b0,supported).
node(n304,refuted) :- status(o_8a26b3ed952a1c4018b0,refuted).
node(n304,unknown) :- status(o_8a26b3ed952a1c4018b0,unknown).
node(n305,supported) :- status(o_d242a82ea74f371c8502,supported).
node(n305,refuted) :- status(o_d242a82ea74f371c8502,refuted).
node(n305,unknown) :- status(o_d242a82ea74f371c8502,unknown).
node(n302,supported) :- node(n303,supported), node(n304,supported), node(n305,supported).
node(n302,refuted) :- node(n303,refuted).
node(n302,refuted) :- node(n304,refuted).
node(n302,refuted) :- node(n305,refuted).
node(n302,unknown) :- \+ node(n302,supported), \+ node(n302,refuted).
node(n307,supported) :- status(o_5335f2c044a5c453f1d3,supported).
node(n307,refuted) :- status(o_5335f2c044a5c453f1d3,refuted).
node(n307,unknown) :- status(o_5335f2c044a5c453f1d3,unknown).
node(n308,supported) :- status(o_88a8f4560471ac7e3f57,supported).
node(n308,refuted) :- status(o_88a8f4560471ac7e3f57,refuted).
node(n308,unknown) :- status(o_88a8f4560471ac7e3f57,unknown).
node(n309,supported) :- status(o_4c7d266e173cfd04fe2a,supported).
node(n309,refuted) :- status(o_4c7d266e173cfd04fe2a,refuted).
node(n309,unknown) :- status(o_4c7d266e173cfd04fe2a,unknown).
node(n306,supported) :- node(n307,supported), node(n308,supported), node(n309,supported).
node(n306,refuted) :- node(n307,refuted).
node(n306,refuted) :- node(n308,refuted).
node(n306,refuted) :- node(n309,refuted).
node(n306,unknown) :- \+ node(n306,supported), \+ node(n306,refuted).
node(n301,refuted) :- node(n302,refuted), node(n306,refuted), node(n9,refuted).
node(n301,supported) :- node(n302,supported).
node(n301,supported) :- node(n306,supported).
node(n301,supported) :- node(n9,supported).
node(n301,unknown) :- \+ node(n301,supported), \+ node(n301,refuted).
verdict(c_a5e8084b13b83d3a,supported) :- node(n301,supported).
query(verdict(c_a5e8084b13b83d3a,supported)).
verdict(c_a5e8084b13b83d3a,refuted) :- node(n301,refuted).
query(verdict(c_a5e8084b13b83d3a,refuted)).
verdict(c_a5e8084b13b83d3a,unknown) :- node(n301,unknown).
query(verdict(c_a5e8084b13b83d3a,unknown)).
node(n312,supported) :- status(o_249ea1bc115028c1e037,supported).
node(n312,refuted) :- status(o_249ea1bc115028c1e037,refuted).
node(n312,unknown) :- status(o_249ea1bc115028c1e037,unknown).
node(n311,supported) :- node(n303,supported), node(n304,supported), node(n312,supported), node(n305,supported).
node(n311,refuted) :- node(n303,refuted).
node(n311,refuted) :- node(n304,refuted).
node(n311,refuted) :- node(n312,refuted).
node(n311,refuted) :- node(n305,refuted).
node(n311,unknown) :- \+ node(n311,supported), \+ node(n311,refuted).
node(n314,supported) :- status(o_3096b55322047d08483c,supported).
node(n314,refuted) :- status(o_3096b55322047d08483c,refuted).
node(n314,unknown) :- status(o_3096b55322047d08483c,unknown).
node(n313,supported) :- node(n307,supported), node(n308,supported), node(n314,supported), node(n309,supported).
node(n313,refuted) :- node(n307,refuted).
node(n313,refuted) :- node(n308,refuted).
node(n313,refuted) :- node(n314,refuted).
node(n313,refuted) :- node(n309,refuted).
node(n313,unknown) :- \+ node(n313,supported), \+ node(n313,refuted).
node(n310,refuted) :- node(n311,refuted), node(n313,refuted), node(n9,refuted).
node(n310,supported) :- node(n311,supported).
node(n310,supported) :- node(n313,supported).
node(n310,supported) :- node(n9,supported).
node(n310,unknown) :- \+ node(n310,supported), \+ node(n310,refuted).
verdict(c_40397af7159d2eb0,supported) :- node(n310,supported).
query(verdict(c_40397af7159d2eb0,supported)).
verdict(c_40397af7159d2eb0,refuted) :- node(n310,refuted).
query(verdict(c_40397af7159d2eb0,refuted)).
verdict(c_40397af7159d2eb0,unknown) :- node(n310,unknown).
query(verdict(c_40397af7159d2eb0,unknown)).
node(n317,supported) :- status(o_bb49dc57d836132fc296,supported).
node(n317,refuted) :- status(o_bb49dc57d836132fc296,refuted).
node(n317,unknown) :- status(o_bb49dc57d836132fc296,unknown).
node(n318,supported) :- status(o_82bbd48a4f6e398a8bed,supported).
node(n318,refuted) :- status(o_82bbd48a4f6e398a8bed,refuted).
node(n318,unknown) :- status(o_82bbd48a4f6e398a8bed,unknown).
node(n319,supported) :- status(o_a6eb05b59e76c238828f,supported).
node(n319,refuted) :- status(o_a6eb05b59e76c238828f,refuted).
node(n319,unknown) :- status(o_a6eb05b59e76c238828f,unknown).
node(n316,supported) :- node(n317,supported), node(n318,supported), node(n319,supported).
node(n316,refuted) :- node(n317,refuted).
node(n316,refuted) :- node(n318,refuted).
node(n316,refuted) :- node(n319,refuted).
node(n316,unknown) :- \+ node(n316,supported), \+ node(n316,refuted).
node(n321,supported) :- status(o_56c8a19be2e2f94458c5,supported).
node(n321,refuted) :- status(o_56c8a19be2e2f94458c5,refuted).
node(n321,unknown) :- status(o_56c8a19be2e2f94458c5,unknown).
node(n322,supported) :- status(o_e7b5c586b30afcfd1d19,supported).
node(n322,refuted) :- status(o_e7b5c586b30afcfd1d19,refuted).
node(n322,unknown) :- status(o_e7b5c586b30afcfd1d19,unknown).
node(n323,supported) :- status(o_93df643ed94feb17640f,supported).
node(n323,refuted) :- status(o_93df643ed94feb17640f,refuted).
node(n323,unknown) :- status(o_93df643ed94feb17640f,unknown).
node(n320,supported) :- node(n321,supported), node(n322,supported), node(n323,supported).
node(n320,refuted) :- node(n321,refuted).
node(n320,refuted) :- node(n322,refuted).
node(n320,refuted) :- node(n323,refuted).
node(n320,unknown) :- \+ node(n320,supported), \+ node(n320,refuted).
node(n315,refuted) :- node(n316,refuted), node(n320,refuted), node(n9,refuted).
node(n315,supported) :- node(n316,supported).
node(n315,supported) :- node(n320,supported).
node(n315,supported) :- node(n9,supported).
node(n315,unknown) :- \+ node(n315,supported), \+ node(n315,refuted).
verdict(c_727c957c387c7af1,supported) :- node(n315,supported).
query(verdict(c_727c957c387c7af1,supported)).
verdict(c_727c957c387c7af1,refuted) :- node(n315,refuted).
query(verdict(c_727c957c387c7af1,refuted)).
verdict(c_727c957c387c7af1,unknown) :- node(n315,unknown).
query(verdict(c_727c957c387c7af1,unknown)).
node(n326,supported) :- status(o_1624fef7be7b0edbb259,supported).
node(n326,refuted) :- status(o_1624fef7be7b0edbb259,refuted).
node(n326,unknown) :- status(o_1624fef7be7b0edbb259,unknown).
node(n325,supported) :- node(n317,supported), node(n318,supported), node(n326,supported), node(n319,supported).
node(n325,refuted) :- node(n317,refuted).
node(n325,refuted) :- node(n318,refuted).
node(n325,refuted) :- node(n326,refuted).
node(n325,refuted) :- node(n319,refuted).
node(n325,unknown) :- \+ node(n325,supported), \+ node(n325,refuted).
node(n328,supported) :- status(o_89606d816f92de7028e9,supported).
node(n328,refuted) :- status(o_89606d816f92de7028e9,refuted).
node(n328,unknown) :- status(o_89606d816f92de7028e9,unknown).
node(n327,supported) :- node(n321,supported), node(n322,supported), node(n328,supported), node(n323,supported).
node(n327,refuted) :- node(n321,refuted).
node(n327,refuted) :- node(n322,refuted).
node(n327,refuted) :- node(n328,refuted).
node(n327,refuted) :- node(n323,refuted).
node(n327,unknown) :- \+ node(n327,supported), \+ node(n327,refuted).
node(n324,refuted) :- node(n325,refuted), node(n327,refuted), node(n9,refuted).
node(n324,supported) :- node(n325,supported).
node(n324,supported) :- node(n327,supported).
node(n324,supported) :- node(n9,supported).
node(n324,unknown) :- \+ node(n324,supported), \+ node(n324,refuted).
verdict(c_02088e0161c6e062,supported) :- node(n324,supported).
query(verdict(c_02088e0161c6e062,supported)).
verdict(c_02088e0161c6e062,refuted) :- node(n324,refuted).
query(verdict(c_02088e0161c6e062,refuted)).
verdict(c_02088e0161c6e062,unknown) :- node(n324,unknown).
query(verdict(c_02088e0161c6e062,unknown)).
node(n331,supported) :- status(o_9e7c08cf4d93d74ef9cc,supported).
node(n331,refuted) :- status(o_9e7c08cf4d93d74ef9cc,refuted).
node(n331,unknown) :- status(o_9e7c08cf4d93d74ef9cc,unknown).
node(n332,supported) :- status(o_d7fe0af95472039e1ba7,supported).
node(n332,refuted) :- status(o_d7fe0af95472039e1ba7,refuted).
node(n332,unknown) :- status(o_d7fe0af95472039e1ba7,unknown).
node(n333,supported) :- status(o_ac518f68b190c18d5168,supported).
node(n333,refuted) :- status(o_ac518f68b190c18d5168,refuted).
node(n333,unknown) :- status(o_ac518f68b190c18d5168,unknown).
node(n330,supported) :- node(n331,supported), node(n332,supported), node(n333,supported).
node(n330,refuted) :- node(n331,refuted).
node(n330,refuted) :- node(n332,refuted).
node(n330,refuted) :- node(n333,refuted).
node(n330,unknown) :- \+ node(n330,supported), \+ node(n330,refuted).
node(n335,supported) :- status(o_3b76e7cf5d023a1f892d,supported).
node(n335,refuted) :- status(o_3b76e7cf5d023a1f892d,refuted).
node(n335,unknown) :- status(o_3b76e7cf5d023a1f892d,unknown).
node(n336,supported) :- status(o_ef7885eff8b428b2d697,supported).
node(n336,refuted) :- status(o_ef7885eff8b428b2d697,refuted).
node(n336,unknown) :- status(o_ef7885eff8b428b2d697,unknown).
node(n337,supported) :- status(o_e2f6af634ca7716aa55e,supported).
node(n337,refuted) :- status(o_e2f6af634ca7716aa55e,refuted).
node(n337,unknown) :- status(o_e2f6af634ca7716aa55e,unknown).
node(n334,supported) :- node(n335,supported), node(n336,supported), node(n337,supported).
node(n334,refuted) :- node(n335,refuted).
node(n334,refuted) :- node(n336,refuted).
node(n334,refuted) :- node(n337,refuted).
node(n334,unknown) :- \+ node(n334,supported), \+ node(n334,refuted).
node(n329,refuted) :- node(n330,refuted), node(n334,refuted), node(n9,refuted).
node(n329,supported) :- node(n330,supported).
node(n329,supported) :- node(n334,supported).
node(n329,supported) :- node(n9,supported).
node(n329,unknown) :- \+ node(n329,supported), \+ node(n329,refuted).
verdict(c_321cc40ac4510b98,supported) :- node(n329,supported).
query(verdict(c_321cc40ac4510b98,supported)).
verdict(c_321cc40ac4510b98,refuted) :- node(n329,refuted).
query(verdict(c_321cc40ac4510b98,refuted)).
verdict(c_321cc40ac4510b98,unknown) :- node(n329,unknown).
query(verdict(c_321cc40ac4510b98,unknown)).
node(n340,supported) :- status(o_985e32de6cb09ac4b4a6,supported).
node(n340,refuted) :- status(o_985e32de6cb09ac4b4a6,refuted).
node(n340,unknown) :- status(o_985e32de6cb09ac4b4a6,unknown).
node(n339,supported) :- node(n331,supported), node(n332,supported), node(n340,supported), node(n333,supported).
node(n339,refuted) :- node(n331,refuted).
node(n339,refuted) :- node(n332,refuted).
node(n339,refuted) :- node(n340,refuted).
node(n339,refuted) :- node(n333,refuted).
node(n339,unknown) :- \+ node(n339,supported), \+ node(n339,refuted).
node(n342,supported) :- status(o_054020a30df144eed425,supported).
node(n342,refuted) :- status(o_054020a30df144eed425,refuted).
node(n342,unknown) :- status(o_054020a30df144eed425,unknown).
node(n341,supported) :- node(n335,supported), node(n336,supported), node(n342,supported), node(n337,supported).
node(n341,refuted) :- node(n335,refuted).
node(n341,refuted) :- node(n336,refuted).
node(n341,refuted) :- node(n342,refuted).
node(n341,refuted) :- node(n337,refuted).
node(n341,unknown) :- \+ node(n341,supported), \+ node(n341,refuted).
node(n338,refuted) :- node(n339,refuted), node(n341,refuted), node(n9,refuted).
node(n338,supported) :- node(n339,supported).
node(n338,supported) :- node(n341,supported).
node(n338,supported) :- node(n9,supported).
node(n338,unknown) :- \+ node(n338,supported), \+ node(n338,refuted).
verdict(c_4e41157d3c727f19,supported) :- node(n338,supported).
query(verdict(c_4e41157d3c727f19,supported)).
verdict(c_4e41157d3c727f19,refuted) :- node(n338,refuted).
query(verdict(c_4e41157d3c727f19,refuted)).
verdict(c_4e41157d3c727f19,unknown) :- node(n338,unknown).
query(verdict(c_4e41157d3c727f19,unknown)).
node(n345,supported) :- status(o_56e59f114d85ccbf37b4,supported).
node(n345,refuted) :- status(o_56e59f114d85ccbf37b4,refuted).
node(n345,unknown) :- status(o_56e59f114d85ccbf37b4,unknown).
node(n346,supported) :- status(o_692fa001f5cd3238473a,supported).
node(n346,refuted) :- status(o_692fa001f5cd3238473a,refuted).
node(n346,unknown) :- status(o_692fa001f5cd3238473a,unknown).
node(n347,supported) :- status(o_292b1b88c95cdf4698b3,supported).
node(n347,refuted) :- status(o_292b1b88c95cdf4698b3,refuted).
node(n347,unknown) :- status(o_292b1b88c95cdf4698b3,unknown).
node(n344,supported) :- node(n345,supported), node(n346,supported), node(n347,supported).
node(n344,refuted) :- node(n345,refuted).
node(n344,refuted) :- node(n346,refuted).
node(n344,refuted) :- node(n347,refuted).
node(n344,unknown) :- \+ node(n344,supported), \+ node(n344,refuted).
node(n349,supported) :- status(o_9b0c16661c9475878347,supported).
node(n349,refuted) :- status(o_9b0c16661c9475878347,refuted).
node(n349,unknown) :- status(o_9b0c16661c9475878347,unknown).
node(n350,supported) :- status(o_ff2623d54849c287222a,supported).
node(n350,refuted) :- status(o_ff2623d54849c287222a,refuted).
node(n350,unknown) :- status(o_ff2623d54849c287222a,unknown).
node(n351,supported) :- status(o_5e2eb1f02e2acf62a86d,supported).
node(n351,refuted) :- status(o_5e2eb1f02e2acf62a86d,refuted).
node(n351,unknown) :- status(o_5e2eb1f02e2acf62a86d,unknown).
node(n348,supported) :- node(n349,supported), node(n350,supported), node(n351,supported).
node(n348,refuted) :- node(n349,refuted).
node(n348,refuted) :- node(n350,refuted).
node(n348,refuted) :- node(n351,refuted).
node(n348,unknown) :- \+ node(n348,supported), \+ node(n348,refuted).
node(n343,refuted) :- node(n344,refuted), node(n348,refuted), node(n9,refuted).
node(n343,supported) :- node(n344,supported).
node(n343,supported) :- node(n348,supported).
node(n343,supported) :- node(n9,supported).
node(n343,unknown) :- \+ node(n343,supported), \+ node(n343,refuted).
verdict(c_b19ec84d4be6573f,supported) :- node(n343,supported).
query(verdict(c_b19ec84d4be6573f,supported)).
verdict(c_b19ec84d4be6573f,refuted) :- node(n343,refuted).
query(verdict(c_b19ec84d4be6573f,refuted)).
verdict(c_b19ec84d4be6573f,unknown) :- node(n343,unknown).
query(verdict(c_b19ec84d4be6573f,unknown)).
node(n354,supported) :- status(o_270ed160e9bd874b468b,supported).
node(n354,refuted) :- status(o_270ed160e9bd874b468b,refuted).
node(n354,unknown) :- status(o_270ed160e9bd874b468b,unknown).
node(n353,supported) :- node(n345,supported), node(n346,supported), node(n354,supported), node(n347,supported).
node(n353,refuted) :- node(n345,refuted).
node(n353,refuted) :- node(n346,refuted).
node(n353,refuted) :- node(n354,refuted).
node(n353,refuted) :- node(n347,refuted).
node(n353,unknown) :- \+ node(n353,supported), \+ node(n353,refuted).
node(n356,supported) :- status(o_e49a41c70b393015e60d,supported).
node(n356,refuted) :- status(o_e49a41c70b393015e60d,refuted).
node(n356,unknown) :- status(o_e49a41c70b393015e60d,unknown).
node(n355,supported) :- node(n349,supported), node(n350,supported), node(n356,supported), node(n351,supported).
node(n355,refuted) :- node(n349,refuted).
node(n355,refuted) :- node(n350,refuted).
node(n355,refuted) :- node(n356,refuted).
node(n355,refuted) :- node(n351,refuted).
node(n355,unknown) :- \+ node(n355,supported), \+ node(n355,refuted).
node(n352,refuted) :- node(n353,refuted), node(n355,refuted), node(n9,refuted).
node(n352,supported) :- node(n353,supported).
node(n352,supported) :- node(n355,supported).
node(n352,supported) :- node(n9,supported).
node(n352,unknown) :- \+ node(n352,supported), \+ node(n352,refuted).
verdict(c_26c3b7d2f4e3929f,supported) :- node(n352,supported).
query(verdict(c_26c3b7d2f4e3929f,supported)).
verdict(c_26c3b7d2f4e3929f,refuted) :- node(n352,refuted).
query(verdict(c_26c3b7d2f4e3929f,refuted)).
verdict(c_26c3b7d2f4e3929f,unknown) :- node(n352,unknown).
query(verdict(c_26c3b7d2f4e3929f,unknown)).
node(n359,supported) :- status(o_dcece1f5b9ad4d232de0,supported).
node(n359,refuted) :- status(o_dcece1f5b9ad4d232de0,refuted).
node(n359,unknown) :- status(o_dcece1f5b9ad4d232de0,unknown).
node(n360,supported) :- status(o_019d3c007e49851e214c,supported).
node(n360,refuted) :- status(o_019d3c007e49851e214c,refuted).
node(n360,unknown) :- status(o_019d3c007e49851e214c,unknown).
node(n361,supported) :- status(o_dfd008e29d5ac0f1031a,supported).
node(n361,refuted) :- status(o_dfd008e29d5ac0f1031a,refuted).
node(n361,unknown) :- status(o_dfd008e29d5ac0f1031a,unknown).
node(n358,supported) :- node(n359,supported), node(n360,supported), node(n361,supported).
node(n358,refuted) :- node(n359,refuted).
node(n358,refuted) :- node(n360,refuted).
node(n358,refuted) :- node(n361,refuted).
node(n358,unknown) :- \+ node(n358,supported), \+ node(n358,refuted).
node(n363,supported) :- status(o_e87315b464b1c5f30512,supported).
node(n363,refuted) :- status(o_e87315b464b1c5f30512,refuted).
node(n363,unknown) :- status(o_e87315b464b1c5f30512,unknown).
node(n364,supported) :- status(o_fdaed9c3037474490813,supported).
node(n364,refuted) :- status(o_fdaed9c3037474490813,refuted).
node(n364,unknown) :- status(o_fdaed9c3037474490813,unknown).
node(n365,supported) :- status(o_8b2e8ab5d0ad3a3f0943,supported).
node(n365,refuted) :- status(o_8b2e8ab5d0ad3a3f0943,refuted).
node(n365,unknown) :- status(o_8b2e8ab5d0ad3a3f0943,unknown).
node(n362,supported) :- node(n363,supported), node(n364,supported), node(n365,supported).
node(n362,refuted) :- node(n363,refuted).
node(n362,refuted) :- node(n364,refuted).
node(n362,refuted) :- node(n365,refuted).
node(n362,unknown) :- \+ node(n362,supported), \+ node(n362,refuted).
node(n357,refuted) :- node(n358,refuted), node(n362,refuted), node(n9,refuted).
node(n357,supported) :- node(n358,supported).
node(n357,supported) :- node(n362,supported).
node(n357,supported) :- node(n9,supported).
node(n357,unknown) :- \+ node(n357,supported), \+ node(n357,refuted).
verdict(c_63eb6c0ebe1759aa,supported) :- node(n357,supported).
query(verdict(c_63eb6c0ebe1759aa,supported)).
verdict(c_63eb6c0ebe1759aa,refuted) :- node(n357,refuted).
query(verdict(c_63eb6c0ebe1759aa,refuted)).
verdict(c_63eb6c0ebe1759aa,unknown) :- node(n357,unknown).
query(verdict(c_63eb6c0ebe1759aa,unknown)).
node(n368,supported) :- status(o_9c996d0d25ffc6722380,supported).
node(n368,refuted) :- status(o_9c996d0d25ffc6722380,refuted).
node(n368,unknown) :- status(o_9c996d0d25ffc6722380,unknown).
node(n367,supported) :- node(n359,supported), node(n360,supported), node(n368,supported), node(n361,supported).
node(n367,refuted) :- node(n359,refuted).
node(n367,refuted) :- node(n360,refuted).
node(n367,refuted) :- node(n368,refuted).
node(n367,refuted) :- node(n361,refuted).
node(n367,unknown) :- \+ node(n367,supported), \+ node(n367,refuted).
node(n370,supported) :- status(o_c1e22e1d7ebd0e67f386,supported).
node(n370,refuted) :- status(o_c1e22e1d7ebd0e67f386,refuted).
node(n370,unknown) :- status(o_c1e22e1d7ebd0e67f386,unknown).
node(n369,supported) :- node(n363,supported), node(n364,supported), node(n370,supported), node(n365,supported).
node(n369,refuted) :- node(n363,refuted).
node(n369,refuted) :- node(n364,refuted).
node(n369,refuted) :- node(n370,refuted).
node(n369,refuted) :- node(n365,refuted).
node(n369,unknown) :- \+ node(n369,supported), \+ node(n369,refuted).
node(n366,refuted) :- node(n367,refuted), node(n369,refuted), node(n9,refuted).
node(n366,supported) :- node(n367,supported).
node(n366,supported) :- node(n369,supported).
node(n366,supported) :- node(n9,supported).
node(n366,unknown) :- \+ node(n366,supported), \+ node(n366,refuted).
verdict(c_c9ce644448bf43b4,supported) :- node(n366,supported).
query(verdict(c_c9ce644448bf43b4,supported)).
verdict(c_c9ce644448bf43b4,refuted) :- node(n366,refuted).
query(verdict(c_c9ce644448bf43b4,refuted)).
verdict(c_c9ce644448bf43b4,unknown) :- node(n366,unknown).
query(verdict(c_c9ce644448bf43b4,unknown)).
node(n373,supported) :- status(o_f790596b85b8ff79e38c,supported).
node(n373,refuted) :- status(o_f790596b85b8ff79e38c,refuted).
node(n373,unknown) :- status(o_f790596b85b8ff79e38c,unknown).
node(n374,supported) :- status(o_a63bf7070875552f6d21,supported).
node(n374,refuted) :- status(o_a63bf7070875552f6d21,refuted).
node(n374,unknown) :- status(o_a63bf7070875552f6d21,unknown).
node(n375,supported) :- status(o_fb303ae9a5163291104d,supported).
node(n375,refuted) :- status(o_fb303ae9a5163291104d,refuted).
node(n375,unknown) :- status(o_fb303ae9a5163291104d,unknown).
node(n372,supported) :- node(n373,supported), node(n374,supported), node(n375,supported).
node(n372,refuted) :- node(n373,refuted).
node(n372,refuted) :- node(n374,refuted).
node(n372,refuted) :- node(n375,refuted).
node(n372,unknown) :- \+ node(n372,supported), \+ node(n372,refuted).
node(n377,supported) :- status(o_2a8d799d7c3ff2741d63,supported).
node(n377,refuted) :- status(o_2a8d799d7c3ff2741d63,refuted).
node(n377,unknown) :- status(o_2a8d799d7c3ff2741d63,unknown).
node(n378,supported) :- status(o_8ad74737af466d05ed74,supported).
node(n378,refuted) :- status(o_8ad74737af466d05ed74,refuted).
node(n378,unknown) :- status(o_8ad74737af466d05ed74,unknown).
node(n379,supported) :- status(o_ca1896a556f8b59513a9,supported).
node(n379,refuted) :- status(o_ca1896a556f8b59513a9,refuted).
node(n379,unknown) :- status(o_ca1896a556f8b59513a9,unknown).
node(n376,supported) :- node(n377,supported), node(n378,supported), node(n379,supported).
node(n376,refuted) :- node(n377,refuted).
node(n376,refuted) :- node(n378,refuted).
node(n376,refuted) :- node(n379,refuted).
node(n376,unknown) :- \+ node(n376,supported), \+ node(n376,refuted).
node(n371,refuted) :- node(n372,refuted), node(n376,refuted), node(n9,refuted).
node(n371,supported) :- node(n372,supported).
node(n371,supported) :- node(n376,supported).
node(n371,supported) :- node(n9,supported).
node(n371,unknown) :- \+ node(n371,supported), \+ node(n371,refuted).
verdict(c_8d8cf0d9a33a520a,supported) :- node(n371,supported).
query(verdict(c_8d8cf0d9a33a520a,supported)).
verdict(c_8d8cf0d9a33a520a,refuted) :- node(n371,refuted).
query(verdict(c_8d8cf0d9a33a520a,refuted)).
verdict(c_8d8cf0d9a33a520a,unknown) :- node(n371,unknown).
query(verdict(c_8d8cf0d9a33a520a,unknown)).
node(n382,supported) :- status(o_a847bc5016b667b9083c,supported).
node(n382,refuted) :- status(o_a847bc5016b667b9083c,refuted).
node(n382,unknown) :- status(o_a847bc5016b667b9083c,unknown).
node(n381,supported) :- node(n373,supported), node(n374,supported), node(n382,supported), node(n375,supported).
node(n381,refuted) :- node(n373,refuted).
node(n381,refuted) :- node(n374,refuted).
node(n381,refuted) :- node(n382,refuted).
node(n381,refuted) :- node(n375,refuted).
node(n381,unknown) :- \+ node(n381,supported), \+ node(n381,refuted).
node(n384,supported) :- status(o_01b9c045b65ad2a7db10,supported).
node(n384,refuted) :- status(o_01b9c045b65ad2a7db10,refuted).
node(n384,unknown) :- status(o_01b9c045b65ad2a7db10,unknown).
node(n383,supported) :- node(n377,supported), node(n378,supported), node(n384,supported), node(n379,supported).
node(n383,refuted) :- node(n377,refuted).
node(n383,refuted) :- node(n378,refuted).
node(n383,refuted) :- node(n384,refuted).
node(n383,refuted) :- node(n379,refuted).
node(n383,unknown) :- \+ node(n383,supported), \+ node(n383,refuted).
node(n380,refuted) :- node(n381,refuted), node(n383,refuted), node(n9,refuted).
node(n380,supported) :- node(n381,supported).
node(n380,supported) :- node(n383,supported).
node(n380,supported) :- node(n9,supported).
node(n380,unknown) :- \+ node(n380,supported), \+ node(n380,refuted).
verdict(c_0f43d7038c160121,supported) :- node(n380,supported).
query(verdict(c_0f43d7038c160121,supported)).
verdict(c_0f43d7038c160121,refuted) :- node(n380,refuted).
query(verdict(c_0f43d7038c160121,refuted)).
verdict(c_0f43d7038c160121,unknown) :- node(n380,unknown).
query(verdict(c_0f43d7038c160121,unknown)).
node(n387,supported) :- status(o_8c0e46800b777240f572,supported).
node(n387,refuted) :- status(o_8c0e46800b777240f572,refuted).
node(n387,unknown) :- status(o_8c0e46800b777240f572,unknown).
node(n388,supported) :- status(o_899f6d1e9971d66ff22a,supported).
node(n388,refuted) :- status(o_899f6d1e9971d66ff22a,refuted).
node(n388,unknown) :- status(o_899f6d1e9971d66ff22a,unknown).
node(n389,supported) :- status(o_e2676468acc3c8837c8d,supported).
node(n389,refuted) :- status(o_e2676468acc3c8837c8d,refuted).
node(n389,unknown) :- status(o_e2676468acc3c8837c8d,unknown).
node(n386,supported) :- node(n387,supported), node(n388,supported), node(n389,supported).
node(n386,refuted) :- node(n387,refuted).
node(n386,refuted) :- node(n388,refuted).
node(n386,refuted) :- node(n389,refuted).
node(n386,unknown) :- \+ node(n386,supported), \+ node(n386,refuted).
node(n391,supported) :- status(o_8170d8aba1e36f3532f4,supported).
node(n391,refuted) :- status(o_8170d8aba1e36f3532f4,refuted).
node(n391,unknown) :- status(o_8170d8aba1e36f3532f4,unknown).
node(n392,supported) :- status(o_d1e1786c6ec431dc8eab,supported).
node(n392,refuted) :- status(o_d1e1786c6ec431dc8eab,refuted).
node(n392,unknown) :- status(o_d1e1786c6ec431dc8eab,unknown).
node(n393,supported) :- status(o_765c3babdecde637c01f,supported).
node(n393,refuted) :- status(o_765c3babdecde637c01f,refuted).
node(n393,unknown) :- status(o_765c3babdecde637c01f,unknown).
node(n390,supported) :- node(n391,supported), node(n392,supported), node(n393,supported).
node(n390,refuted) :- node(n391,refuted).
node(n390,refuted) :- node(n392,refuted).
node(n390,refuted) :- node(n393,refuted).
node(n390,unknown) :- \+ node(n390,supported), \+ node(n390,refuted).
node(n385,refuted) :- node(n386,refuted), node(n390,refuted), node(n9,refuted).
node(n385,supported) :- node(n386,supported).
node(n385,supported) :- node(n390,supported).
node(n385,supported) :- node(n9,supported).
node(n385,unknown) :- \+ node(n385,supported), \+ node(n385,refuted).
verdict(c_6821ebf78a2860b0,supported) :- node(n385,supported).
query(verdict(c_6821ebf78a2860b0,supported)).
verdict(c_6821ebf78a2860b0,refuted) :- node(n385,refuted).
query(verdict(c_6821ebf78a2860b0,refuted)).
verdict(c_6821ebf78a2860b0,unknown) :- node(n385,unknown).
query(verdict(c_6821ebf78a2860b0,unknown)).
node(n396,supported) :- status(o_d0ebebdbd3b10f345c66,supported).
node(n396,refuted) :- status(o_d0ebebdbd3b10f345c66,refuted).
node(n396,unknown) :- status(o_d0ebebdbd3b10f345c66,unknown).
node(n395,supported) :- node(n387,supported), node(n388,supported), node(n396,supported), node(n389,supported).
node(n395,refuted) :- node(n387,refuted).
node(n395,refuted) :- node(n388,refuted).
node(n395,refuted) :- node(n396,refuted).
node(n395,refuted) :- node(n389,refuted).
node(n395,unknown) :- \+ node(n395,supported), \+ node(n395,refuted).
node(n398,supported) :- status(o_60cd1e3d78ad39dacf25,supported).
node(n398,refuted) :- status(o_60cd1e3d78ad39dacf25,refuted).
node(n398,unknown) :- status(o_60cd1e3d78ad39dacf25,unknown).
node(n397,supported) :- node(n391,supported), node(n392,supported), node(n398,supported), node(n393,supported).
node(n397,refuted) :- node(n391,refuted).
node(n397,refuted) :- node(n392,refuted).
node(n397,refuted) :- node(n398,refuted).
node(n397,refuted) :- node(n393,refuted).
node(n397,unknown) :- \+ node(n397,supported), \+ node(n397,refuted).
node(n394,refuted) :- node(n395,refuted), node(n397,refuted), node(n9,refuted).
node(n394,supported) :- node(n395,supported).
node(n394,supported) :- node(n397,supported).
node(n394,supported) :- node(n9,supported).
node(n394,unknown) :- \+ node(n394,supported), \+ node(n394,refuted).
verdict(c_f6f7192231dd7018,supported) :- node(n394,supported).
query(verdict(c_f6f7192231dd7018,supported)).
verdict(c_f6f7192231dd7018,refuted) :- node(n394,refuted).
query(verdict(c_f6f7192231dd7018,refuted)).
verdict(c_f6f7192231dd7018,unknown) :- node(n394,unknown).
query(verdict(c_f6f7192231dd7018,unknown)).
node(n401,supported) :- status(o_0bb25e513cc714113aa2,supported).
node(n401,refuted) :- status(o_0bb25e513cc714113aa2,refuted).
node(n401,unknown) :- status(o_0bb25e513cc714113aa2,unknown).
node(n402,supported) :- status(o_a861a84daf7bf7442aa1,supported).
node(n402,refuted) :- status(o_a861a84daf7bf7442aa1,refuted).
node(n402,unknown) :- status(o_a861a84daf7bf7442aa1,unknown).
node(n403,supported) :- status(o_e985aa974e7a96cfa0e9,supported).
node(n403,refuted) :- status(o_e985aa974e7a96cfa0e9,refuted).
node(n403,unknown) :- status(o_e985aa974e7a96cfa0e9,unknown).
node(n400,supported) :- node(n401,supported), node(n402,supported), node(n403,supported).
node(n400,refuted) :- node(n401,refuted).
node(n400,refuted) :- node(n402,refuted).
node(n400,refuted) :- node(n403,refuted).
node(n400,unknown) :- \+ node(n400,supported), \+ node(n400,refuted).
node(n405,supported) :- status(o_9818e77fc95dc64d61a3,supported).
node(n405,refuted) :- status(o_9818e77fc95dc64d61a3,refuted).
node(n405,unknown) :- status(o_9818e77fc95dc64d61a3,unknown).
node(n406,supported) :- status(o_f7e156383510e9dfb240,supported).
node(n406,refuted) :- status(o_f7e156383510e9dfb240,refuted).
node(n406,unknown) :- status(o_f7e156383510e9dfb240,unknown).
node(n407,supported) :- status(o_152f51e19cbe552645b1,supported).
node(n407,refuted) :- status(o_152f51e19cbe552645b1,refuted).
node(n407,unknown) :- status(o_152f51e19cbe552645b1,unknown).
node(n404,supported) :- node(n405,supported), node(n406,supported), node(n407,supported).
node(n404,refuted) :- node(n405,refuted).
node(n404,refuted) :- node(n406,refuted).
node(n404,refuted) :- node(n407,refuted).
node(n404,unknown) :- \+ node(n404,supported), \+ node(n404,refuted).
node(n399,refuted) :- node(n400,refuted), node(n404,refuted), node(n9,refuted).
node(n399,supported) :- node(n400,supported).
node(n399,supported) :- node(n404,supported).
node(n399,supported) :- node(n9,supported).
node(n399,unknown) :- \+ node(n399,supported), \+ node(n399,refuted).
verdict(c_456cbfb73f9e47a0,supported) :- node(n399,supported).
query(verdict(c_456cbfb73f9e47a0,supported)).
verdict(c_456cbfb73f9e47a0,refuted) :- node(n399,refuted).
query(verdict(c_456cbfb73f9e47a0,refuted)).
verdict(c_456cbfb73f9e47a0,unknown) :- node(n399,unknown).
query(verdict(c_456cbfb73f9e47a0,unknown)).
node(n410,supported) :- status(o_837bc04c8c3e200fc177,supported).
node(n410,refuted) :- status(o_837bc04c8c3e200fc177,refuted).
node(n410,unknown) :- status(o_837bc04c8c3e200fc177,unknown).
node(n409,supported) :- node(n401,supported), node(n402,supported), node(n410,supported), node(n403,supported).
node(n409,refuted) :- node(n401,refuted).
node(n409,refuted) :- node(n402,refuted).
node(n409,refuted) :- node(n410,refuted).
node(n409,refuted) :- node(n403,refuted).
node(n409,unknown) :- \+ node(n409,supported), \+ node(n409,refuted).
node(n412,supported) :- status(o_a1d564c8d71011994ec5,supported).
node(n412,refuted) :- status(o_a1d564c8d71011994ec5,refuted).
node(n412,unknown) :- status(o_a1d564c8d71011994ec5,unknown).
node(n411,supported) :- node(n405,supported), node(n406,supported), node(n412,supported), node(n407,supported).
node(n411,refuted) :- node(n405,refuted).
node(n411,refuted) :- node(n406,refuted).
node(n411,refuted) :- node(n412,refuted).
node(n411,refuted) :- node(n407,refuted).
node(n411,unknown) :- \+ node(n411,supported), \+ node(n411,refuted).
node(n408,refuted) :- node(n409,refuted), node(n411,refuted), node(n9,refuted).
node(n408,supported) :- node(n409,supported).
node(n408,supported) :- node(n411,supported).
node(n408,supported) :- node(n9,supported).
node(n408,unknown) :- \+ node(n408,supported), \+ node(n408,refuted).
verdict(c_726ea15c133b3f7c,supported) :- node(n408,supported).
query(verdict(c_726ea15c133b3f7c,supported)).
verdict(c_726ea15c133b3f7c,refuted) :- node(n408,refuted).
query(verdict(c_726ea15c133b3f7c,refuted)).
verdict(c_726ea15c133b3f7c,unknown) :- node(n408,unknown).
query(verdict(c_726ea15c133b3f7c,unknown)).
node(n415,supported) :- status(o_36b2dbd9f2bc80d0d708,supported).
node(n415,refuted) :- status(o_36b2dbd9f2bc80d0d708,refuted).
node(n415,unknown) :- status(o_36b2dbd9f2bc80d0d708,unknown).
node(n416,supported) :- status(o_c620ef08f3c6e92e7234,supported).
node(n416,refuted) :- status(o_c620ef08f3c6e92e7234,refuted).
node(n416,unknown) :- status(o_c620ef08f3c6e92e7234,unknown).
node(n417,supported) :- status(o_1a10759b6ce32873e5cc,supported).
node(n417,refuted) :- status(o_1a10759b6ce32873e5cc,refuted).
node(n417,unknown) :- status(o_1a10759b6ce32873e5cc,unknown).
node(n414,supported) :- node(n415,supported), node(n416,supported), node(n417,supported).
node(n414,refuted) :- node(n415,refuted).
node(n414,refuted) :- node(n416,refuted).
node(n414,refuted) :- node(n417,refuted).
node(n414,unknown) :- \+ node(n414,supported), \+ node(n414,refuted).
node(n419,supported) :- status(o_f7fcaa37851f7cbed69f,supported).
node(n419,refuted) :- status(o_f7fcaa37851f7cbed69f,refuted).
node(n419,unknown) :- status(o_f7fcaa37851f7cbed69f,unknown).
node(n420,supported) :- status(o_effdd62922efadc0a661,supported).
node(n420,refuted) :- status(o_effdd62922efadc0a661,refuted).
node(n420,unknown) :- status(o_effdd62922efadc0a661,unknown).
node(n421,supported) :- status(o_1ee7c863e0b340d611f7,supported).
node(n421,refuted) :- status(o_1ee7c863e0b340d611f7,refuted).
node(n421,unknown) :- status(o_1ee7c863e0b340d611f7,unknown).
node(n418,supported) :- node(n419,supported), node(n420,supported), node(n421,supported).
node(n418,refuted) :- node(n419,refuted).
node(n418,refuted) :- node(n420,refuted).
node(n418,refuted) :- node(n421,refuted).
node(n418,unknown) :- \+ node(n418,supported), \+ node(n418,refuted).
node(n413,refuted) :- node(n414,refuted), node(n418,refuted), node(n9,refuted).
node(n413,supported) :- node(n414,supported).
node(n413,supported) :- node(n418,supported).
node(n413,supported) :- node(n9,supported).
node(n413,unknown) :- \+ node(n413,supported), \+ node(n413,refuted).
verdict(c_a66de1b0f86ffb95,supported) :- node(n413,supported).
query(verdict(c_a66de1b0f86ffb95,supported)).
verdict(c_a66de1b0f86ffb95,refuted) :- node(n413,refuted).
query(verdict(c_a66de1b0f86ffb95,refuted)).
verdict(c_a66de1b0f86ffb95,unknown) :- node(n413,unknown).
query(verdict(c_a66de1b0f86ffb95,unknown)).
node(n424,supported) :- status(o_5dcf2050f78a23e17baa,supported).
node(n424,refuted) :- status(o_5dcf2050f78a23e17baa,refuted).
node(n424,unknown) :- status(o_5dcf2050f78a23e17baa,unknown).
node(n423,supported) :- node(n415,supported), node(n416,supported), node(n424,supported), node(n417,supported).
node(n423,refuted) :- node(n415,refuted).
node(n423,refuted) :- node(n416,refuted).
node(n423,refuted) :- node(n424,refuted).
node(n423,refuted) :- node(n417,refuted).
node(n423,unknown) :- \+ node(n423,supported), \+ node(n423,refuted).
node(n426,supported) :- status(o_1e30d3abfd6bc3fa23db,supported).
node(n426,refuted) :- status(o_1e30d3abfd6bc3fa23db,refuted).
node(n426,unknown) :- status(o_1e30d3abfd6bc3fa23db,unknown).
node(n425,supported) :- node(n419,supported), node(n420,supported), node(n426,supported), node(n421,supported).
node(n425,refuted) :- node(n419,refuted).
node(n425,refuted) :- node(n420,refuted).
node(n425,refuted) :- node(n426,refuted).
node(n425,refuted) :- node(n421,refuted).
node(n425,unknown) :- \+ node(n425,supported), \+ node(n425,refuted).
node(n422,refuted) :- node(n423,refuted), node(n425,refuted), node(n9,refuted).
node(n422,supported) :- node(n423,supported).
node(n422,supported) :- node(n425,supported).
node(n422,supported) :- node(n9,supported).
node(n422,unknown) :- \+ node(n422,supported), \+ node(n422,refuted).
verdict(c_9d251b79d19b62bc,supported) :- node(n422,supported).
query(verdict(c_9d251b79d19b62bc,supported)).
verdict(c_9d251b79d19b62bc,refuted) :- node(n422,refuted).
query(verdict(c_9d251b79d19b62bc,refuted)).
verdict(c_9d251b79d19b62bc,unknown) :- node(n422,unknown).
query(verdict(c_9d251b79d19b62bc,unknown)).
node(n429,supported) :- status(o_6e2294cf3b1f0eb8808f,supported).
node(n429,refuted) :- status(o_6e2294cf3b1f0eb8808f,refuted).
node(n429,unknown) :- status(o_6e2294cf3b1f0eb8808f,unknown).
node(n430,supported) :- status(o_d69f69360c70ad5a8bcb,supported).
node(n430,refuted) :- status(o_d69f69360c70ad5a8bcb,refuted).
node(n430,unknown) :- status(o_d69f69360c70ad5a8bcb,unknown).
node(n431,supported) :- status(o_2e976143865b741ab025,supported).
node(n431,refuted) :- status(o_2e976143865b741ab025,refuted).
node(n431,unknown) :- status(o_2e976143865b741ab025,unknown).
node(n428,supported) :- node(n429,supported), node(n430,supported), node(n431,supported).
node(n428,refuted) :- node(n429,refuted).
node(n428,refuted) :- node(n430,refuted).
node(n428,refuted) :- node(n431,refuted).
node(n428,unknown) :- \+ node(n428,supported), \+ node(n428,refuted).
node(n433,supported) :- status(o_dfd30d8cc785ba014691,supported).
node(n433,refuted) :- status(o_dfd30d8cc785ba014691,refuted).
node(n433,unknown) :- status(o_dfd30d8cc785ba014691,unknown).
node(n434,supported) :- status(o_fd58f4d4dffe33849075,supported).
node(n434,refuted) :- status(o_fd58f4d4dffe33849075,refuted).
node(n434,unknown) :- status(o_fd58f4d4dffe33849075,unknown).
node(n435,supported) :- status(o_3b0d9e9515285e6ea157,supported).
node(n435,refuted) :- status(o_3b0d9e9515285e6ea157,refuted).
node(n435,unknown) :- status(o_3b0d9e9515285e6ea157,unknown).
node(n432,supported) :- node(n433,supported), node(n434,supported), node(n435,supported).
node(n432,refuted) :- node(n433,refuted).
node(n432,refuted) :- node(n434,refuted).
node(n432,refuted) :- node(n435,refuted).
node(n432,unknown) :- \+ node(n432,supported), \+ node(n432,refuted).
node(n427,refuted) :- node(n428,refuted), node(n432,refuted), node(n9,refuted).
node(n427,supported) :- node(n428,supported).
node(n427,supported) :- node(n432,supported).
node(n427,supported) :- node(n9,supported).
node(n427,unknown) :- \+ node(n427,supported), \+ node(n427,refuted).
verdict(c_7f868a82729ec72a,supported) :- node(n427,supported).
query(verdict(c_7f868a82729ec72a,supported)).
verdict(c_7f868a82729ec72a,refuted) :- node(n427,refuted).
query(verdict(c_7f868a82729ec72a,refuted)).
verdict(c_7f868a82729ec72a,unknown) :- node(n427,unknown).
query(verdict(c_7f868a82729ec72a,unknown)).
node(n438,supported) :- status(o_23c3b989771dd7b30fb1,supported).
node(n438,refuted) :- status(o_23c3b989771dd7b30fb1,refuted).
node(n438,unknown) :- status(o_23c3b989771dd7b30fb1,unknown).
node(n437,supported) :- node(n429,supported), node(n430,supported), node(n438,supported), node(n431,supported).
node(n437,refuted) :- node(n429,refuted).
node(n437,refuted) :- node(n430,refuted).
node(n437,refuted) :- node(n438,refuted).
node(n437,refuted) :- node(n431,refuted).
node(n437,unknown) :- \+ node(n437,supported), \+ node(n437,refuted).
node(n440,supported) :- status(o_5d1219a9d345299a68a6,supported).
node(n440,refuted) :- status(o_5d1219a9d345299a68a6,refuted).
node(n440,unknown) :- status(o_5d1219a9d345299a68a6,unknown).
node(n439,supported) :- node(n433,supported), node(n434,supported), node(n440,supported), node(n435,supported).
node(n439,refuted) :- node(n433,refuted).
node(n439,refuted) :- node(n434,refuted).
node(n439,refuted) :- node(n440,refuted).
node(n439,refuted) :- node(n435,refuted).
node(n439,unknown) :- \+ node(n439,supported), \+ node(n439,refuted).
node(n436,refuted) :- node(n437,refuted), node(n439,refuted), node(n9,refuted).
node(n436,supported) :- node(n437,supported).
node(n436,supported) :- node(n439,supported).
node(n436,supported) :- node(n9,supported).
node(n436,unknown) :- \+ node(n436,supported), \+ node(n436,refuted).
verdict(c_cbc2995484280ded,supported) :- node(n436,supported).
query(verdict(c_cbc2995484280ded,supported)).
verdict(c_cbc2995484280ded,refuted) :- node(n436,refuted).
query(verdict(c_cbc2995484280ded,refuted)).
verdict(c_cbc2995484280ded,unknown) :- node(n436,unknown).
query(verdict(c_cbc2995484280ded,unknown)).
node(n443,supported) :- status(o_6eee66a36d1bfc59e677,supported).
node(n443,refuted) :- status(o_6eee66a36d1bfc59e677,refuted).
node(n443,unknown) :- status(o_6eee66a36d1bfc59e677,unknown).
node(n444,supported) :- status(o_0b506808665499301698,supported).
node(n444,refuted) :- status(o_0b506808665499301698,refuted).
node(n444,unknown) :- status(o_0b506808665499301698,unknown).
node(n445,supported) :- status(o_58ae1cb619f437dd76c7,supported).
node(n445,refuted) :- status(o_58ae1cb619f437dd76c7,refuted).
node(n445,unknown) :- status(o_58ae1cb619f437dd76c7,unknown).
node(n442,supported) :- node(n443,supported), node(n444,supported), node(n445,supported).
node(n442,refuted) :- node(n443,refuted).
node(n442,refuted) :- node(n444,refuted).
node(n442,refuted) :- node(n445,refuted).
node(n442,unknown) :- \+ node(n442,supported), \+ node(n442,refuted).
node(n447,supported) :- status(o_df6a6a49655e1e74555f,supported).
node(n447,refuted) :- status(o_df6a6a49655e1e74555f,refuted).
node(n447,unknown) :- status(o_df6a6a49655e1e74555f,unknown).
node(n448,supported) :- status(o_c59980b0c637bd3a1d59,supported).
node(n448,refuted) :- status(o_c59980b0c637bd3a1d59,refuted).
node(n448,unknown) :- status(o_c59980b0c637bd3a1d59,unknown).
node(n449,supported) :- status(o_2c84bf08d2b036d66898,supported).
node(n449,refuted) :- status(o_2c84bf08d2b036d66898,refuted).
node(n449,unknown) :- status(o_2c84bf08d2b036d66898,unknown).
node(n446,supported) :- node(n447,supported), node(n448,supported), node(n449,supported).
node(n446,refuted) :- node(n447,refuted).
node(n446,refuted) :- node(n448,refuted).
node(n446,refuted) :- node(n449,refuted).
node(n446,unknown) :- \+ node(n446,supported), \+ node(n446,refuted).
node(n441,refuted) :- node(n442,refuted), node(n446,refuted), node(n9,refuted).
node(n441,supported) :- node(n442,supported).
node(n441,supported) :- node(n446,supported).
node(n441,supported) :- node(n9,supported).
node(n441,unknown) :- \+ node(n441,supported), \+ node(n441,refuted).
verdict(c_409b19da5526ffe1,supported) :- node(n441,supported).
query(verdict(c_409b19da5526ffe1,supported)).
verdict(c_409b19da5526ffe1,refuted) :- node(n441,refuted).
query(verdict(c_409b19da5526ffe1,refuted)).
verdict(c_409b19da5526ffe1,unknown) :- node(n441,unknown).
query(verdict(c_409b19da5526ffe1,unknown)).
node(n452,supported) :- status(o_584b435ed4cfd0f7dedb,supported).
node(n452,refuted) :- status(o_584b435ed4cfd0f7dedb,refuted).
node(n452,unknown) :- status(o_584b435ed4cfd0f7dedb,unknown).
node(n451,supported) :- node(n443,supported), node(n444,supported), node(n452,supported), node(n445,supported).
node(n451,refuted) :- node(n443,refuted).
node(n451,refuted) :- node(n444,refuted).
node(n451,refuted) :- node(n452,refuted).
node(n451,refuted) :- node(n445,refuted).
node(n451,unknown) :- \+ node(n451,supported), \+ node(n451,refuted).
node(n454,supported) :- status(o_c5a0f3d78b2dcc0d5cfe,supported).
node(n454,refuted) :- status(o_c5a0f3d78b2dcc0d5cfe,refuted).
node(n454,unknown) :- status(o_c5a0f3d78b2dcc0d5cfe,unknown).
node(n453,supported) :- node(n447,supported), node(n448,supported), node(n454,supported), node(n449,supported).
node(n453,refuted) :- node(n447,refuted).
node(n453,refuted) :- node(n448,refuted).
node(n453,refuted) :- node(n454,refuted).
node(n453,refuted) :- node(n449,refuted).
node(n453,unknown) :- \+ node(n453,supported), \+ node(n453,refuted).
node(n450,refuted) :- node(n451,refuted), node(n453,refuted), node(n9,refuted).
node(n450,supported) :- node(n451,supported).
node(n450,supported) :- node(n453,supported).
node(n450,supported) :- node(n9,supported).
node(n450,unknown) :- \+ node(n450,supported), \+ node(n450,refuted).
verdict(c_e59b836265e9ed95,supported) :- node(n450,supported).
query(verdict(c_e59b836265e9ed95,supported)).
verdict(c_e59b836265e9ed95,refuted) :- node(n450,refuted).
query(verdict(c_e59b836265e9ed95,refuted)).
verdict(c_e59b836265e9ed95,unknown) :- node(n450,unknown).
query(verdict(c_e59b836265e9ed95,unknown)).
node(n457,supported) :- status(o_b10425345588ad700a70,supported).
node(n457,refuted) :- status(o_b10425345588ad700a70,refuted).
node(n457,unknown) :- status(o_b10425345588ad700a70,unknown).
node(n458,supported) :- status(o_46fa8574cbc3841b84e1,supported).
node(n458,refuted) :- status(o_46fa8574cbc3841b84e1,refuted).
node(n458,unknown) :- status(o_46fa8574cbc3841b84e1,unknown).
node(n459,supported) :- status(o_a5f4b27a7bded40186de,supported).
node(n459,refuted) :- status(o_a5f4b27a7bded40186de,refuted).
node(n459,unknown) :- status(o_a5f4b27a7bded40186de,unknown).
node(n456,supported) :- node(n457,supported), node(n458,supported), node(n459,supported).
node(n456,refuted) :- node(n457,refuted).
node(n456,refuted) :- node(n458,refuted).
node(n456,refuted) :- node(n459,refuted).
node(n456,unknown) :- \+ node(n456,supported), \+ node(n456,refuted).
node(n461,supported) :- status(o_6a5e555e4daa7914c677,supported).
node(n461,refuted) :- status(o_6a5e555e4daa7914c677,refuted).
node(n461,unknown) :- status(o_6a5e555e4daa7914c677,unknown).
node(n462,supported) :- status(o_b8ab0e8b5899754bc649,supported).
node(n462,refuted) :- status(o_b8ab0e8b5899754bc649,refuted).
node(n462,unknown) :- status(o_b8ab0e8b5899754bc649,unknown).
node(n463,supported) :- status(o_ddf687e9e4b9cac3ea36,supported).
node(n463,refuted) :- status(o_ddf687e9e4b9cac3ea36,refuted).
node(n463,unknown) :- status(o_ddf687e9e4b9cac3ea36,unknown).
node(n460,supported) :- node(n461,supported), node(n462,supported), node(n463,supported).
node(n460,refuted) :- node(n461,refuted).
node(n460,refuted) :- node(n462,refuted).
node(n460,refuted) :- node(n463,refuted).
node(n460,unknown) :- \+ node(n460,supported), \+ node(n460,refuted).
node(n455,refuted) :- node(n456,refuted), node(n460,refuted), node(n9,refuted).
node(n455,supported) :- node(n456,supported).
node(n455,supported) :- node(n460,supported).
node(n455,supported) :- node(n9,supported).
node(n455,unknown) :- \+ node(n455,supported), \+ node(n455,refuted).
verdict(c_3242a79f3f00ce0b,supported) :- node(n455,supported).
query(verdict(c_3242a79f3f00ce0b,supported)).
verdict(c_3242a79f3f00ce0b,refuted) :- node(n455,refuted).
query(verdict(c_3242a79f3f00ce0b,refuted)).
verdict(c_3242a79f3f00ce0b,unknown) :- node(n455,unknown).
query(verdict(c_3242a79f3f00ce0b,unknown)).
node(n466,supported) :- status(o_d6f47e33fcbfb6a4d1d3,supported).
node(n466,refuted) :- status(o_d6f47e33fcbfb6a4d1d3,refuted).
node(n466,unknown) :- status(o_d6f47e33fcbfb6a4d1d3,unknown).
node(n465,supported) :- node(n457,supported), node(n458,supported), node(n466,supported), node(n459,supported).
node(n465,refuted) :- node(n457,refuted).
node(n465,refuted) :- node(n458,refuted).
node(n465,refuted) :- node(n466,refuted).
node(n465,refuted) :- node(n459,refuted).
node(n465,unknown) :- \+ node(n465,supported), \+ node(n465,refuted).
node(n468,supported) :- status(o_f1fb0d85003d55b85afb,supported).
node(n468,refuted) :- status(o_f1fb0d85003d55b85afb,refuted).
node(n468,unknown) :- status(o_f1fb0d85003d55b85afb,unknown).
node(n467,supported) :- node(n461,supported), node(n462,supported), node(n468,supported), node(n463,supported).
node(n467,refuted) :- node(n461,refuted).
node(n467,refuted) :- node(n462,refuted).
node(n467,refuted) :- node(n468,refuted).
node(n467,refuted) :- node(n463,refuted).
node(n467,unknown) :- \+ node(n467,supported), \+ node(n467,refuted).
node(n464,refuted) :- node(n465,refuted), node(n467,refuted), node(n9,refuted).
node(n464,supported) :- node(n465,supported).
node(n464,supported) :- node(n467,supported).
node(n464,supported) :- node(n9,supported).
node(n464,unknown) :- \+ node(n464,supported), \+ node(n464,refuted).
verdict(c_4f7a645ec16fa7ea,supported) :- node(n464,supported).
query(verdict(c_4f7a645ec16fa7ea,supported)).
verdict(c_4f7a645ec16fa7ea,refuted) :- node(n464,refuted).
query(verdict(c_4f7a645ec16fa7ea,refuted)).
verdict(c_4f7a645ec16fa7ea,unknown) :- node(n464,unknown).
query(verdict(c_4f7a645ec16fa7ea,unknown)).
node(n471,supported) :- status(o_2348673ae2c21fd301fa,supported).
node(n471,refuted) :- status(o_2348673ae2c21fd301fa,refuted).
node(n471,unknown) :- status(o_2348673ae2c21fd301fa,unknown).
node(n472,supported) :- status(o_e7c465b2b9628c60bc2c,supported).
node(n472,refuted) :- status(o_e7c465b2b9628c60bc2c,refuted).
node(n472,unknown) :- status(o_e7c465b2b9628c60bc2c,unknown).
node(n473,supported) :- status(o_6d1c86657356599bbb62,supported).
node(n473,refuted) :- status(o_6d1c86657356599bbb62,refuted).
node(n473,unknown) :- status(o_6d1c86657356599bbb62,unknown).
node(n470,supported) :- node(n471,supported), node(n472,supported), node(n473,supported).
node(n470,refuted) :- node(n471,refuted).
node(n470,refuted) :- node(n472,refuted).
node(n470,refuted) :- node(n473,refuted).
node(n470,unknown) :- \+ node(n470,supported), \+ node(n470,refuted).
node(n475,supported) :- status(o_50b819a41b5a1f8449e8,supported).
node(n475,refuted) :- status(o_50b819a41b5a1f8449e8,refuted).
node(n475,unknown) :- status(o_50b819a41b5a1f8449e8,unknown).
node(n476,supported) :- status(o_206c7645fd2a570c31b3,supported).
node(n476,refuted) :- status(o_206c7645fd2a570c31b3,refuted).
node(n476,unknown) :- status(o_206c7645fd2a570c31b3,unknown).
node(n477,supported) :- status(o_094350b43c7453be0e63,supported).
node(n477,refuted) :- status(o_094350b43c7453be0e63,refuted).
node(n477,unknown) :- status(o_094350b43c7453be0e63,unknown).
node(n474,supported) :- node(n475,supported), node(n476,supported), node(n477,supported).
node(n474,refuted) :- node(n475,refuted).
node(n474,refuted) :- node(n476,refuted).
node(n474,refuted) :- node(n477,refuted).
node(n474,unknown) :- \+ node(n474,supported), \+ node(n474,refuted).
node(n469,refuted) :- node(n470,refuted), node(n474,refuted), node(n9,refuted).
node(n469,supported) :- node(n470,supported).
node(n469,supported) :- node(n474,supported).
node(n469,supported) :- node(n9,supported).
node(n469,unknown) :- \+ node(n469,supported), \+ node(n469,refuted).
verdict(c_e50bcb82f3cb6b6e,supported) :- node(n469,supported).
query(verdict(c_e50bcb82f3cb6b6e,supported)).
verdict(c_e50bcb82f3cb6b6e,refuted) :- node(n469,refuted).
query(verdict(c_e50bcb82f3cb6b6e,refuted)).
verdict(c_e50bcb82f3cb6b6e,unknown) :- node(n469,unknown).
query(verdict(c_e50bcb82f3cb6b6e,unknown)).
node(n480,supported) :- status(o_fc2e2391ee64e5b1be81,supported).
node(n480,refuted) :- status(o_fc2e2391ee64e5b1be81,refuted).
node(n480,unknown) :- status(o_fc2e2391ee64e5b1be81,unknown).
node(n479,supported) :- node(n471,supported), node(n472,supported), node(n480,supported), node(n473,supported).
node(n479,refuted) :- node(n471,refuted).
node(n479,refuted) :- node(n472,refuted).
node(n479,refuted) :- node(n480,refuted).
node(n479,refuted) :- node(n473,refuted).
node(n479,unknown) :- \+ node(n479,supported), \+ node(n479,refuted).
node(n482,supported) :- status(o_533e9538d86e08d0687c,supported).
node(n482,refuted) :- status(o_533e9538d86e08d0687c,refuted).
node(n482,unknown) :- status(o_533e9538d86e08d0687c,unknown).
node(n481,supported) :- node(n475,supported), node(n476,supported), node(n482,supported), node(n477,supported).
node(n481,refuted) :- node(n475,refuted).
node(n481,refuted) :- node(n476,refuted).
node(n481,refuted) :- node(n482,refuted).
node(n481,refuted) :- node(n477,refuted).
node(n481,unknown) :- \+ node(n481,supported), \+ node(n481,refuted).
node(n478,refuted) :- node(n479,refuted), node(n481,refuted), node(n9,refuted).
node(n478,supported) :- node(n479,supported).
node(n478,supported) :- node(n481,supported).
node(n478,supported) :- node(n9,supported).
node(n478,unknown) :- \+ node(n478,supported), \+ node(n478,refuted).
verdict(c_693dda55f14571a0,supported) :- node(n478,supported).
query(verdict(c_693dda55f14571a0,supported)).
verdict(c_693dda55f14571a0,refuted) :- node(n478,refuted).
query(verdict(c_693dda55f14571a0,refuted)).
verdict(c_693dda55f14571a0,unknown) :- node(n478,unknown).
query(verdict(c_693dda55f14571a0,unknown)).
node(n485,supported) :- status(o_50971347455099471fdc,supported).
node(n485,refuted) :- status(o_50971347455099471fdc,refuted).
node(n485,unknown) :- status(o_50971347455099471fdc,unknown).
node(n486,supported) :- status(o_cee4d72d02c6d9ca6ea1,supported).
node(n486,refuted) :- status(o_cee4d72d02c6d9ca6ea1,refuted).
node(n486,unknown) :- status(o_cee4d72d02c6d9ca6ea1,unknown).
node(n487,supported) :- status(o_f1e6893f088760188f97,supported).
node(n487,refuted) :- status(o_f1e6893f088760188f97,refuted).
node(n487,unknown) :- status(o_f1e6893f088760188f97,unknown).
node(n484,supported) :- node(n485,supported), node(n486,supported), node(n487,supported).
node(n484,refuted) :- node(n485,refuted).
node(n484,refuted) :- node(n486,refuted).
node(n484,refuted) :- node(n487,refuted).
node(n484,unknown) :- \+ node(n484,supported), \+ node(n484,refuted).
node(n489,supported) :- status(o_14fef005a694e0ee7732,supported).
node(n489,refuted) :- status(o_14fef005a694e0ee7732,refuted).
node(n489,unknown) :- status(o_14fef005a694e0ee7732,unknown).
node(n490,supported) :- status(o_e3ed2d883b167f5d2873,supported).
node(n490,refuted) :- status(o_e3ed2d883b167f5d2873,refuted).
node(n490,unknown) :- status(o_e3ed2d883b167f5d2873,unknown).
node(n491,supported) :- status(o_09b238a23fe4af8cacd1,supported).
node(n491,refuted) :- status(o_09b238a23fe4af8cacd1,refuted).
node(n491,unknown) :- status(o_09b238a23fe4af8cacd1,unknown).
node(n488,supported) :- node(n489,supported), node(n490,supported), node(n491,supported).
node(n488,refuted) :- node(n489,refuted).
node(n488,refuted) :- node(n490,refuted).
node(n488,refuted) :- node(n491,refuted).
node(n488,unknown) :- \+ node(n488,supported), \+ node(n488,refuted).
node(n483,refuted) :- node(n484,refuted), node(n488,refuted), node(n9,refuted).
node(n483,supported) :- node(n484,supported).
node(n483,supported) :- node(n488,supported).
node(n483,supported) :- node(n9,supported).
node(n483,unknown) :- \+ node(n483,supported), \+ node(n483,refuted).
verdict(c_374140956894c9ee,supported) :- node(n483,supported).
query(verdict(c_374140956894c9ee,supported)).
verdict(c_374140956894c9ee,refuted) :- node(n483,refuted).
query(verdict(c_374140956894c9ee,refuted)).
verdict(c_374140956894c9ee,unknown) :- node(n483,unknown).
query(verdict(c_374140956894c9ee,unknown)).
node(n494,supported) :- status(o_7e6d1e9d390d01146f61,supported).
node(n494,refuted) :- status(o_7e6d1e9d390d01146f61,refuted).
node(n494,unknown) :- status(o_7e6d1e9d390d01146f61,unknown).
node(n493,supported) :- node(n485,supported), node(n486,supported), node(n494,supported), node(n487,supported).
node(n493,refuted) :- node(n485,refuted).
node(n493,refuted) :- node(n486,refuted).
node(n493,refuted) :- node(n494,refuted).
node(n493,refuted) :- node(n487,refuted).
node(n493,unknown) :- \+ node(n493,supported), \+ node(n493,refuted).
node(n496,supported) :- status(o_98225b54cc668445b322,supported).
node(n496,refuted) :- status(o_98225b54cc668445b322,refuted).
node(n496,unknown) :- status(o_98225b54cc668445b322,unknown).
node(n495,supported) :- node(n489,supported), node(n490,supported), node(n496,supported), node(n491,supported).
node(n495,refuted) :- node(n489,refuted).
node(n495,refuted) :- node(n490,refuted).
node(n495,refuted) :- node(n496,refuted).
node(n495,refuted) :- node(n491,refuted).
node(n495,unknown) :- \+ node(n495,supported), \+ node(n495,refuted).
node(n492,refuted) :- node(n493,refuted), node(n495,refuted), node(n9,refuted).
node(n492,supported) :- node(n493,supported).
node(n492,supported) :- node(n495,supported).
node(n492,supported) :- node(n9,supported).
node(n492,unknown) :- \+ node(n492,supported), \+ node(n492,refuted).
verdict(c_48ac78b100182f37,supported) :- node(n492,supported).
query(verdict(c_48ac78b100182f37,supported)).
verdict(c_48ac78b100182f37,refuted) :- node(n492,refuted).
query(verdict(c_48ac78b100182f37,refuted)).
verdict(c_48ac78b100182f37,unknown) :- node(n492,unknown).
query(verdict(c_48ac78b100182f37,unknown)).
node(n499,supported) :- status(o_a000b1a83a8285c61c3a,supported).
node(n499,refuted) :- status(o_a000b1a83a8285c61c3a,refuted).
node(n499,unknown) :- status(o_a000b1a83a8285c61c3a,unknown).
node(n500,supported) :- status(o_4bbe840db4065bfc6c84,supported).
node(n500,refuted) :- status(o_4bbe840db4065bfc6c84,refuted).
node(n500,unknown) :- status(o_4bbe840db4065bfc6c84,unknown).
node(n501,supported) :- status(o_729d639a8e4320e8ebe8,supported).
node(n501,refuted) :- status(o_729d639a8e4320e8ebe8,refuted).
node(n501,unknown) :- status(o_729d639a8e4320e8ebe8,unknown).
node(n498,supported) :- node(n499,supported), node(n500,supported), node(n501,supported).
node(n498,refuted) :- node(n499,refuted).
node(n498,refuted) :- node(n500,refuted).
node(n498,refuted) :- node(n501,refuted).
node(n498,unknown) :- \+ node(n498,supported), \+ node(n498,refuted).
node(n497,refuted) :- node(n498,refuted), node(n9,refuted).
node(n497,supported) :- node(n498,supported).
node(n497,supported) :- node(n9,supported).
node(n497,unknown) :- \+ node(n497,supported), \+ node(n497,refuted).
verdict(c_f0a74aa9b5829501,supported) :- node(n497,supported).
query(verdict(c_f0a74aa9b5829501,supported)).
verdict(c_f0a74aa9b5829501,refuted) :- node(n497,refuted).
query(verdict(c_f0a74aa9b5829501,refuted)).
verdict(c_f0a74aa9b5829501,unknown) :- node(n497,unknown).
query(verdict(c_f0a74aa9b5829501,unknown)).
node(n504,supported) :- status(o_c249d16667f4761fac5d,supported).
node(n504,refuted) :- status(o_c249d16667f4761fac5d,refuted).
node(n504,unknown) :- status(o_c249d16667f4761fac5d,unknown).
node(n503,supported) :- node(n499,supported), node(n500,supported), node(n504,supported), node(n501,supported).
node(n503,refuted) :- node(n499,refuted).
node(n503,refuted) :- node(n500,refuted).
node(n503,refuted) :- node(n504,refuted).
node(n503,refuted) :- node(n501,refuted).
node(n503,unknown) :- \+ node(n503,supported), \+ node(n503,refuted).
node(n502,refuted) :- node(n503,refuted), node(n9,refuted).
node(n502,supported) :- node(n503,supported).
node(n502,supported) :- node(n9,supported).
node(n502,unknown) :- \+ node(n502,supported), \+ node(n502,refuted).
verdict(c_72937407fa549517,supported) :- node(n502,supported).
query(verdict(c_72937407fa549517,supported)).
verdict(c_72937407fa549517,refuted) :- node(n502,refuted).
query(verdict(c_72937407fa549517,refuted)).
verdict(c_72937407fa549517,unknown) :- node(n502,unknown).
query(verdict(c_72937407fa549517,unknown)).
node(n507,supported) :- status(o_cc3b8c84f2cfab7e78ba,supported).
node(n507,refuted) :- status(o_cc3b8c84f2cfab7e78ba,refuted).
node(n507,unknown) :- status(o_cc3b8c84f2cfab7e78ba,unknown).
node(n508,supported) :- status(o_267b5b0b56834cb3c2f5,supported).
node(n508,refuted) :- status(o_267b5b0b56834cb3c2f5,refuted).
node(n508,unknown) :- status(o_267b5b0b56834cb3c2f5,unknown).
node(n509,supported) :- status(o_c6bb737d309959d1de9c,supported).
node(n509,refuted) :- status(o_c6bb737d309959d1de9c,refuted).
node(n509,unknown) :- status(o_c6bb737d309959d1de9c,unknown).
node(n506,supported) :- node(n507,supported), node(n508,supported), node(n509,supported).
node(n506,refuted) :- node(n507,refuted).
node(n506,refuted) :- node(n508,refuted).
node(n506,refuted) :- node(n509,refuted).
node(n506,unknown) :- \+ node(n506,supported), \+ node(n506,refuted).
node(n511,supported) :- status(o_6fe268939122920fc664,supported).
node(n511,refuted) :- status(o_6fe268939122920fc664,refuted).
node(n511,unknown) :- status(o_6fe268939122920fc664,unknown).
node(n512,supported) :- status(o_b4ea2d93469199ed9d0b,supported).
node(n512,refuted) :- status(o_b4ea2d93469199ed9d0b,refuted).
node(n512,unknown) :- status(o_b4ea2d93469199ed9d0b,unknown).
node(n513,supported) :- status(o_a3a88c8517287f14d09f,supported).
node(n513,refuted) :- status(o_a3a88c8517287f14d09f,refuted).
node(n513,unknown) :- status(o_a3a88c8517287f14d09f,unknown).
node(n510,supported) :- node(n511,supported), node(n512,supported), node(n513,supported).
node(n510,refuted) :- node(n511,refuted).
node(n510,refuted) :- node(n512,refuted).
node(n510,refuted) :- node(n513,refuted).
node(n510,unknown) :- \+ node(n510,supported), \+ node(n510,refuted).
node(n505,refuted) :- node(n506,refuted), node(n510,refuted), node(n9,refuted).
node(n505,supported) :- node(n506,supported).
node(n505,supported) :- node(n510,supported).
node(n505,supported) :- node(n9,supported).
node(n505,unknown) :- \+ node(n505,supported), \+ node(n505,refuted).
verdict(c_784d157fd66ee963,supported) :- node(n505,supported).
query(verdict(c_784d157fd66ee963,supported)).
verdict(c_784d157fd66ee963,refuted) :- node(n505,refuted).
query(verdict(c_784d157fd66ee963,refuted)).
verdict(c_784d157fd66ee963,unknown) :- node(n505,unknown).
query(verdict(c_784d157fd66ee963,unknown)).
node(n516,supported) :- status(o_ef9eaadfe73950a55feb,supported).
node(n516,refuted) :- status(o_ef9eaadfe73950a55feb,refuted).
node(n516,unknown) :- status(o_ef9eaadfe73950a55feb,unknown).
node(n515,supported) :- node(n507,supported), node(n508,supported), node(n516,supported), node(n509,supported).
node(n515,refuted) :- node(n507,refuted).
node(n515,refuted) :- node(n508,refuted).
node(n515,refuted) :- node(n516,refuted).
node(n515,refuted) :- node(n509,refuted).
node(n515,unknown) :- \+ node(n515,supported), \+ node(n515,refuted).
node(n518,supported) :- status(o_0c90bca29a4e311111cd,supported).
node(n518,refuted) :- status(o_0c90bca29a4e311111cd,refuted).
node(n518,unknown) :- status(o_0c90bca29a4e311111cd,unknown).
node(n517,supported) :- node(n511,supported), node(n512,supported), node(n518,supported), node(n513,supported).
node(n517,refuted) :- node(n511,refuted).
node(n517,refuted) :- node(n512,refuted).
node(n517,refuted) :- node(n518,refuted).
node(n517,refuted) :- node(n513,refuted).
node(n517,unknown) :- \+ node(n517,supported), \+ node(n517,refuted).
node(n514,refuted) :- node(n515,refuted), node(n517,refuted), node(n9,refuted).
node(n514,supported) :- node(n515,supported).
node(n514,supported) :- node(n517,supported).
node(n514,supported) :- node(n9,supported).
node(n514,unknown) :- \+ node(n514,supported), \+ node(n514,refuted).
verdict(c_bfe59da6ef073530,supported) :- node(n514,supported).
query(verdict(c_bfe59da6ef073530,supported)).
verdict(c_bfe59da6ef073530,refuted) :- node(n514,refuted).
query(verdict(c_bfe59da6ef073530,refuted)).
verdict(c_bfe59da6ef073530,unknown) :- node(n514,unknown).
query(verdict(c_bfe59da6ef073530,unknown)).
node(n521,supported) :- status(o_d66a466f6baa370526cc,supported).
node(n521,refuted) :- status(o_d66a466f6baa370526cc,refuted).
node(n521,unknown) :- status(o_d66a466f6baa370526cc,unknown).
node(n522,supported) :- status(o_d6336b584fbc3a69eaa1,supported).
node(n522,refuted) :- status(o_d6336b584fbc3a69eaa1,refuted).
node(n522,unknown) :- status(o_d6336b584fbc3a69eaa1,unknown).
node(n523,supported) :- status(o_fb48c389cd39727c9307,supported).
node(n523,refuted) :- status(o_fb48c389cd39727c9307,refuted).
node(n523,unknown) :- status(o_fb48c389cd39727c9307,unknown).
node(n520,supported) :- node(n521,supported), node(n522,supported), node(n523,supported).
node(n520,refuted) :- node(n521,refuted).
node(n520,refuted) :- node(n522,refuted).
node(n520,refuted) :- node(n523,refuted).
node(n520,unknown) :- \+ node(n520,supported), \+ node(n520,refuted).
node(n519,refuted) :- node(n520,refuted), node(n9,refuted).
node(n519,supported) :- node(n520,supported).
node(n519,supported) :- node(n9,supported).
node(n519,unknown) :- \+ node(n519,supported), \+ node(n519,refuted).
verdict(c_da18ee0d8a977215,supported) :- node(n519,supported).
query(verdict(c_da18ee0d8a977215,supported)).
verdict(c_da18ee0d8a977215,refuted) :- node(n519,refuted).
query(verdict(c_da18ee0d8a977215,refuted)).
verdict(c_da18ee0d8a977215,unknown) :- node(n519,unknown).
query(verdict(c_da18ee0d8a977215,unknown)).
node(n526,supported) :- status(o_5de500d84c14aa36d180,supported).
node(n526,refuted) :- status(o_5de500d84c14aa36d180,refuted).
node(n526,unknown) :- status(o_5de500d84c14aa36d180,unknown).
node(n525,supported) :- node(n521,supported), node(n522,supported), node(n526,supported), node(n523,supported).
node(n525,refuted) :- node(n521,refuted).
node(n525,refuted) :- node(n522,refuted).
node(n525,refuted) :- node(n526,refuted).
node(n525,refuted) :- node(n523,refuted).
node(n525,unknown) :- \+ node(n525,supported), \+ node(n525,refuted).
node(n524,refuted) :- node(n525,refuted), node(n9,refuted).
node(n524,supported) :- node(n525,supported).
node(n524,supported) :- node(n9,supported).
node(n524,unknown) :- \+ node(n524,supported), \+ node(n524,refuted).
verdict(c_9579a49d35782ac6,supported) :- node(n524,supported).
query(verdict(c_9579a49d35782ac6,supported)).
verdict(c_9579a49d35782ac6,refuted) :- node(n524,refuted).
query(verdict(c_9579a49d35782ac6,refuted)).
verdict(c_9579a49d35782ac6,unknown) :- node(n524,unknown).
query(verdict(c_9579a49d35782ac6,unknown)).
node(n529,supported) :- status(o_2b1db21bbc723dc42d7c,supported).
node(n529,refuted) :- status(o_2b1db21bbc723dc42d7c,refuted).
node(n529,unknown) :- status(o_2b1db21bbc723dc42d7c,unknown).
node(n530,supported) :- status(o_b62d5c50944b561f115b,supported).
node(n530,refuted) :- status(o_b62d5c50944b561f115b,refuted).
node(n530,unknown) :- status(o_b62d5c50944b561f115b,unknown).
node(n531,supported) :- status(o_fe94407da10c20b74e32,supported).
node(n531,refuted) :- status(o_fe94407da10c20b74e32,refuted).
node(n531,unknown) :- status(o_fe94407da10c20b74e32,unknown).
node(n528,supported) :- node(n529,supported), node(n530,supported), node(n531,supported).
node(n528,refuted) :- node(n529,refuted).
node(n528,refuted) :- node(n530,refuted).
node(n528,refuted) :- node(n531,refuted).
node(n528,unknown) :- \+ node(n528,supported), \+ node(n528,refuted).
node(n533,supported) :- status(o_96167a7123b6c2e9f0ec,supported).
node(n533,refuted) :- status(o_96167a7123b6c2e9f0ec,refuted).
node(n533,unknown) :- status(o_96167a7123b6c2e9f0ec,unknown).
node(n534,supported) :- status(o_b0e8bca2d14335cf2d09,supported).
node(n534,refuted) :- status(o_b0e8bca2d14335cf2d09,refuted).
node(n534,unknown) :- status(o_b0e8bca2d14335cf2d09,unknown).
node(n535,supported) :- status(o_4367edc539cfc7d0475a,supported).
node(n535,refuted) :- status(o_4367edc539cfc7d0475a,refuted).
node(n535,unknown) :- status(o_4367edc539cfc7d0475a,unknown).
node(n532,supported) :- node(n533,supported), node(n534,supported), node(n535,supported).
node(n532,refuted) :- node(n533,refuted).
node(n532,refuted) :- node(n534,refuted).
node(n532,refuted) :- node(n535,refuted).
node(n532,unknown) :- \+ node(n532,supported), \+ node(n532,refuted).
node(n527,refuted) :- node(n528,refuted), node(n532,refuted), node(n9,refuted).
node(n527,supported) :- node(n528,supported).
node(n527,supported) :- node(n532,supported).
node(n527,supported) :- node(n9,supported).
node(n527,unknown) :- \+ node(n527,supported), \+ node(n527,refuted).
verdict(c_cf8dd306852c7564,supported) :- node(n527,supported).
query(verdict(c_cf8dd306852c7564,supported)).
verdict(c_cf8dd306852c7564,refuted) :- node(n527,refuted).
query(verdict(c_cf8dd306852c7564,refuted)).
verdict(c_cf8dd306852c7564,unknown) :- node(n527,unknown).
query(verdict(c_cf8dd306852c7564,unknown)).
node(n538,supported) :- status(o_cff621ae48eb4f0c9a97,supported).
node(n538,refuted) :- status(o_cff621ae48eb4f0c9a97,refuted).
node(n538,unknown) :- status(o_cff621ae48eb4f0c9a97,unknown).
node(n537,supported) :- node(n529,supported), node(n530,supported), node(n538,supported), node(n531,supported).
node(n537,refuted) :- node(n529,refuted).
node(n537,refuted) :- node(n530,refuted).
node(n537,refuted) :- node(n538,refuted).
node(n537,refuted) :- node(n531,refuted).
node(n537,unknown) :- \+ node(n537,supported), \+ node(n537,refuted).
node(n540,supported) :- status(o_ea66860c2e940d9cd5b6,supported).
node(n540,refuted) :- status(o_ea66860c2e940d9cd5b6,refuted).
node(n540,unknown) :- status(o_ea66860c2e940d9cd5b6,unknown).
node(n539,supported) :- node(n533,supported), node(n534,supported), node(n540,supported), node(n535,supported).
node(n539,refuted) :- node(n533,refuted).
node(n539,refuted) :- node(n534,refuted).
node(n539,refuted) :- node(n540,refuted).
node(n539,refuted) :- node(n535,refuted).
node(n539,unknown) :- \+ node(n539,supported), \+ node(n539,refuted).
node(n536,refuted) :- node(n537,refuted), node(n539,refuted), node(n9,refuted).
node(n536,supported) :- node(n537,supported).
node(n536,supported) :- node(n539,supported).
node(n536,supported) :- node(n9,supported).
node(n536,unknown) :- \+ node(n536,supported), \+ node(n536,refuted).
verdict(c_e6161446469e0abb,supported) :- node(n536,supported).
query(verdict(c_e6161446469e0abb,supported)).
verdict(c_e6161446469e0abb,refuted) :- node(n536,refuted).
query(verdict(c_e6161446469e0abb,refuted)).
verdict(c_e6161446469e0abb,unknown) :- node(n536,unknown).
query(verdict(c_e6161446469e0abb,unknown)).
node(n543,supported) :- status(o_554bfd6c154be204b5f6,supported).
node(n543,refuted) :- status(o_554bfd6c154be204b5f6,refuted).
node(n543,unknown) :- status(o_554bfd6c154be204b5f6,unknown).
node(n544,supported) :- status(o_6450ff128c268e222c8b,supported).
node(n544,refuted) :- status(o_6450ff128c268e222c8b,refuted).
node(n544,unknown) :- status(o_6450ff128c268e222c8b,unknown).
node(n545,supported) :- status(o_b01ab74324e6cb68c66a,supported).
node(n545,refuted) :- status(o_b01ab74324e6cb68c66a,refuted).
node(n545,unknown) :- status(o_b01ab74324e6cb68c66a,unknown).
node(n542,supported) :- node(n543,supported), node(n544,supported), node(n545,supported).
node(n542,refuted) :- node(n543,refuted).
node(n542,refuted) :- node(n544,refuted).
node(n542,refuted) :- node(n545,refuted).
node(n542,unknown) :- \+ node(n542,supported), \+ node(n542,refuted).
node(n547,supported) :- status(o_7a358bd719284660b76c,supported).
node(n547,refuted) :- status(o_7a358bd719284660b76c,refuted).
node(n547,unknown) :- status(o_7a358bd719284660b76c,unknown).
node(n548,supported) :- status(o_1c48799d98d6ddb371fc,supported).
node(n548,refuted) :- status(o_1c48799d98d6ddb371fc,refuted).
node(n548,unknown) :- status(o_1c48799d98d6ddb371fc,unknown).
node(n549,supported) :- status(o_04be10164d619f9eaf96,supported).
node(n549,refuted) :- status(o_04be10164d619f9eaf96,refuted).
node(n549,unknown) :- status(o_04be10164d619f9eaf96,unknown).
node(n546,supported) :- node(n547,supported), node(n548,supported), node(n549,supported).
node(n546,refuted) :- node(n547,refuted).
node(n546,refuted) :- node(n548,refuted).
node(n546,refuted) :- node(n549,refuted).
node(n546,unknown) :- \+ node(n546,supported), \+ node(n546,refuted).
node(n541,refuted) :- node(n542,refuted), node(n546,refuted), node(n9,refuted).
node(n541,supported) :- node(n542,supported).
node(n541,supported) :- node(n546,supported).
node(n541,supported) :- node(n9,supported).
node(n541,unknown) :- \+ node(n541,supported), \+ node(n541,refuted).
verdict(c_40199fa58fb27f88,supported) :- node(n541,supported).
query(verdict(c_40199fa58fb27f88,supported)).
verdict(c_40199fa58fb27f88,refuted) :- node(n541,refuted).
query(verdict(c_40199fa58fb27f88,refuted)).
verdict(c_40199fa58fb27f88,unknown) :- node(n541,unknown).
query(verdict(c_40199fa58fb27f88,unknown)).
node(n552,supported) :- status(o_b517a77ee1450f94492d,supported).
node(n552,refuted) :- status(o_b517a77ee1450f94492d,refuted).
node(n552,unknown) :- status(o_b517a77ee1450f94492d,unknown).
node(n551,supported) :- node(n543,supported), node(n544,supported), node(n552,supported), node(n545,supported).
node(n551,refuted) :- node(n543,refuted).
node(n551,refuted) :- node(n544,refuted).
node(n551,refuted) :- node(n552,refuted).
node(n551,refuted) :- node(n545,refuted).
node(n551,unknown) :- \+ node(n551,supported), \+ node(n551,refuted).
node(n554,supported) :- status(o_e648cc0dd3f0c19db09d,supported).
node(n554,refuted) :- status(o_e648cc0dd3f0c19db09d,refuted).
node(n554,unknown) :- status(o_e648cc0dd3f0c19db09d,unknown).
node(n553,supported) :- node(n547,supported), node(n548,supported), node(n554,supported), node(n549,supported).
node(n553,refuted) :- node(n547,refuted).
node(n553,refuted) :- node(n548,refuted).
node(n553,refuted) :- node(n554,refuted).
node(n553,refuted) :- node(n549,refuted).
node(n553,unknown) :- \+ node(n553,supported), \+ node(n553,refuted).
node(n550,refuted) :- node(n551,refuted), node(n553,refuted), node(n9,refuted).
node(n550,supported) :- node(n551,supported).
node(n550,supported) :- node(n553,supported).
node(n550,supported) :- node(n9,supported).
node(n550,unknown) :- \+ node(n550,supported), \+ node(n550,refuted).
verdict(c_c076a8312465fd17,supported) :- node(n550,supported).
query(verdict(c_c076a8312465fd17,supported)).
verdict(c_c076a8312465fd17,refuted) :- node(n550,refuted).
query(verdict(c_c076a8312465fd17,refuted)).
verdict(c_c076a8312465fd17,unknown) :- node(n550,unknown).
query(verdict(c_c076a8312465fd17,unknown)).
node(n557,supported) :- status(o_d6c1af468a7d92b046ec,supported).
node(n557,refuted) :- status(o_d6c1af468a7d92b046ec,refuted).
node(n557,unknown) :- status(o_d6c1af468a7d92b046ec,unknown).
node(n558,supported) :- status(o_7eee86f9ab30f79637a5,supported).
node(n558,refuted) :- status(o_7eee86f9ab30f79637a5,refuted).
node(n558,unknown) :- status(o_7eee86f9ab30f79637a5,unknown).
node(n559,supported) :- status(o_1ae7fd9f5588216a2256,supported).
node(n559,refuted) :- status(o_1ae7fd9f5588216a2256,refuted).
node(n559,unknown) :- status(o_1ae7fd9f5588216a2256,unknown).
node(n556,supported) :- node(n557,supported), node(n558,supported), node(n559,supported).
node(n556,refuted) :- node(n557,refuted).
node(n556,refuted) :- node(n558,refuted).
node(n556,refuted) :- node(n559,refuted).
node(n556,unknown) :- \+ node(n556,supported), \+ node(n556,refuted).
node(n561,supported) :- status(o_d065ca5871f90679237c,supported).
node(n561,refuted) :- status(o_d065ca5871f90679237c,refuted).
node(n561,unknown) :- status(o_d065ca5871f90679237c,unknown).
node(n562,supported) :- status(o_3ebb7cc6fd3b9bf0da57,supported).
node(n562,refuted) :- status(o_3ebb7cc6fd3b9bf0da57,refuted).
node(n562,unknown) :- status(o_3ebb7cc6fd3b9bf0da57,unknown).
node(n563,supported) :- status(o_14c281143258c71d61cf,supported).
node(n563,refuted) :- status(o_14c281143258c71d61cf,refuted).
node(n563,unknown) :- status(o_14c281143258c71d61cf,unknown).
node(n560,supported) :- node(n561,supported), node(n562,supported), node(n563,supported).
node(n560,refuted) :- node(n561,refuted).
node(n560,refuted) :- node(n562,refuted).
node(n560,refuted) :- node(n563,refuted).
node(n560,unknown) :- \+ node(n560,supported), \+ node(n560,refuted).
node(n555,refuted) :- node(n556,refuted), node(n560,refuted), node(n9,refuted).
node(n555,supported) :- node(n556,supported).
node(n555,supported) :- node(n560,supported).
node(n555,supported) :- node(n9,supported).
node(n555,unknown) :- \+ node(n555,supported), \+ node(n555,refuted).
verdict(c_7eb10dd7a060ff1c,supported) :- node(n555,supported).
query(verdict(c_7eb10dd7a060ff1c,supported)).
verdict(c_7eb10dd7a060ff1c,refuted) :- node(n555,refuted).
query(verdict(c_7eb10dd7a060ff1c,refuted)).
verdict(c_7eb10dd7a060ff1c,unknown) :- node(n555,unknown).
query(verdict(c_7eb10dd7a060ff1c,unknown)).
node(n566,supported) :- status(o_da11a3406ccbf7b7bf78,supported).
node(n566,refuted) :- status(o_da11a3406ccbf7b7bf78,refuted).
node(n566,unknown) :- status(o_da11a3406ccbf7b7bf78,unknown).
node(n565,supported) :- node(n557,supported), node(n558,supported), node(n566,supported), node(n559,supported).
node(n565,refuted) :- node(n557,refuted).
node(n565,refuted) :- node(n558,refuted).
node(n565,refuted) :- node(n566,refuted).
node(n565,refuted) :- node(n559,refuted).
node(n565,unknown) :- \+ node(n565,supported), \+ node(n565,refuted).
node(n568,supported) :- status(o_8dd5253489bebc0b1eaa,supported).
node(n568,refuted) :- status(o_8dd5253489bebc0b1eaa,refuted).
node(n568,unknown) :- status(o_8dd5253489bebc0b1eaa,unknown).
node(n567,supported) :- node(n561,supported), node(n562,supported), node(n568,supported), node(n563,supported).
node(n567,refuted) :- node(n561,refuted).
node(n567,refuted) :- node(n562,refuted).
node(n567,refuted) :- node(n568,refuted).
node(n567,refuted) :- node(n563,refuted).
node(n567,unknown) :- \+ node(n567,supported), \+ node(n567,refuted).
node(n564,refuted) :- node(n565,refuted), node(n567,refuted), node(n9,refuted).
node(n564,supported) :- node(n565,supported).
node(n564,supported) :- node(n567,supported).
node(n564,supported) :- node(n9,supported).
node(n564,unknown) :- \+ node(n564,supported), \+ node(n564,refuted).
verdict(c_59c25f59daa7243e,supported) :- node(n564,supported).
query(verdict(c_59c25f59daa7243e,supported)).
verdict(c_59c25f59daa7243e,refuted) :- node(n564,refuted).
query(verdict(c_59c25f59daa7243e,refuted)).
verdict(c_59c25f59daa7243e,unknown) :- node(n564,unknown).
query(verdict(c_59c25f59daa7243e,unknown)).
node(n571,supported) :- status(o_ea1e565e27a63343135a,supported).
node(n571,refuted) :- status(o_ea1e565e27a63343135a,refuted).
node(n571,unknown) :- status(o_ea1e565e27a63343135a,unknown).
node(n572,supported) :- status(o_4edcb702012cf5cd4928,supported).
node(n572,refuted) :- status(o_4edcb702012cf5cd4928,refuted).
node(n572,unknown) :- status(o_4edcb702012cf5cd4928,unknown).
node(n573,supported) :- status(o_94f261b8fa32bc37ab16,supported).
node(n573,refuted) :- status(o_94f261b8fa32bc37ab16,refuted).
node(n573,unknown) :- status(o_94f261b8fa32bc37ab16,unknown).
node(n570,supported) :- node(n571,supported), node(n572,supported), node(n573,supported).
node(n570,refuted) :- node(n571,refuted).
node(n570,refuted) :- node(n572,refuted).
node(n570,refuted) :- node(n573,refuted).
node(n570,unknown) :- \+ node(n570,supported), \+ node(n570,refuted).
node(n575,supported) :- status(o_09f56b988afeba1515ca,supported).
node(n575,refuted) :- status(o_09f56b988afeba1515ca,refuted).
node(n575,unknown) :- status(o_09f56b988afeba1515ca,unknown).
node(n576,supported) :- status(o_94f6be4ebb1742c9b932,supported).
node(n576,refuted) :- status(o_94f6be4ebb1742c9b932,refuted).
node(n576,unknown) :- status(o_94f6be4ebb1742c9b932,unknown).
node(n577,supported) :- status(o_2490396a075eca9e2a74,supported).
node(n577,refuted) :- status(o_2490396a075eca9e2a74,refuted).
node(n577,unknown) :- status(o_2490396a075eca9e2a74,unknown).
node(n574,supported) :- node(n575,supported), node(n576,supported), node(n577,supported).
node(n574,refuted) :- node(n575,refuted).
node(n574,refuted) :- node(n576,refuted).
node(n574,refuted) :- node(n577,refuted).
node(n574,unknown) :- \+ node(n574,supported), \+ node(n574,refuted).
node(n569,refuted) :- node(n570,refuted), node(n574,refuted), node(n9,refuted).
node(n569,supported) :- node(n570,supported).
node(n569,supported) :- node(n574,supported).
node(n569,supported) :- node(n9,supported).
node(n569,unknown) :- \+ node(n569,supported), \+ node(n569,refuted).
verdict(c_d4d7685b0467fe5a,supported) :- node(n569,supported).
query(verdict(c_d4d7685b0467fe5a,supported)).
verdict(c_d4d7685b0467fe5a,refuted) :- node(n569,refuted).
query(verdict(c_d4d7685b0467fe5a,refuted)).
verdict(c_d4d7685b0467fe5a,unknown) :- node(n569,unknown).
query(verdict(c_d4d7685b0467fe5a,unknown)).
node(n580,supported) :- status(o_0ab84c0c657cadb3f157,supported).
node(n580,refuted) :- status(o_0ab84c0c657cadb3f157,refuted).
node(n580,unknown) :- status(o_0ab84c0c657cadb3f157,unknown).
node(n579,supported) :- node(n571,supported), node(n572,supported), node(n580,supported), node(n573,supported).
node(n579,refuted) :- node(n571,refuted).
node(n579,refuted) :- node(n572,refuted).
node(n579,refuted) :- node(n580,refuted).
node(n579,refuted) :- node(n573,refuted).
node(n579,unknown) :- \+ node(n579,supported), \+ node(n579,refuted).
node(n582,supported) :- status(o_759afe6441f2303c28b6,supported).
node(n582,refuted) :- status(o_759afe6441f2303c28b6,refuted).
node(n582,unknown) :- status(o_759afe6441f2303c28b6,unknown).
node(n581,supported) :- node(n575,supported), node(n576,supported), node(n582,supported), node(n577,supported).
node(n581,refuted) :- node(n575,refuted).
node(n581,refuted) :- node(n576,refuted).
node(n581,refuted) :- node(n582,refuted).
node(n581,refuted) :- node(n577,refuted).
node(n581,unknown) :- \+ node(n581,supported), \+ node(n581,refuted).
node(n578,refuted) :- node(n579,refuted), node(n581,refuted), node(n9,refuted).
node(n578,supported) :- node(n579,supported).
node(n578,supported) :- node(n581,supported).
node(n578,supported) :- node(n9,supported).
node(n578,unknown) :- \+ node(n578,supported), \+ node(n578,refuted).
verdict(c_72d15eab5844091b,supported) :- node(n578,supported).
query(verdict(c_72d15eab5844091b,supported)).
verdict(c_72d15eab5844091b,refuted) :- node(n578,refuted).
query(verdict(c_72d15eab5844091b,refuted)).
verdict(c_72d15eab5844091b,unknown) :- node(n578,unknown).
query(verdict(c_72d15eab5844091b,unknown)).
node(n585,supported) :- status(o_813c68fa7c9f6f54e2f9,supported).
node(n585,refuted) :- status(o_813c68fa7c9f6f54e2f9,refuted).
node(n585,unknown) :- status(o_813c68fa7c9f6f54e2f9,unknown).
node(n586,supported) :- status(o_62344e839b3bb75a04d6,supported).
node(n586,refuted) :- status(o_62344e839b3bb75a04d6,refuted).
node(n586,unknown) :- status(o_62344e839b3bb75a04d6,unknown).
node(n587,supported) :- status(o_e2ac0dec45f9fc5d6649,supported).
node(n587,refuted) :- status(o_e2ac0dec45f9fc5d6649,refuted).
node(n587,unknown) :- status(o_e2ac0dec45f9fc5d6649,unknown).
node(n584,supported) :- node(n585,supported), node(n586,supported), node(n587,supported).
node(n584,refuted) :- node(n585,refuted).
node(n584,refuted) :- node(n586,refuted).
node(n584,refuted) :- node(n587,refuted).
node(n584,unknown) :- \+ node(n584,supported), \+ node(n584,refuted).
node(n589,supported) :- status(o_116cf17b18dcec48ebc4,supported).
node(n589,refuted) :- status(o_116cf17b18dcec48ebc4,refuted).
node(n589,unknown) :- status(o_116cf17b18dcec48ebc4,unknown).
node(n590,supported) :- status(o_fff85f6daeee8d2fda36,supported).
node(n590,refuted) :- status(o_fff85f6daeee8d2fda36,refuted).
node(n590,unknown) :- status(o_fff85f6daeee8d2fda36,unknown).
node(n591,supported) :- status(o_78545cbec07cdef331fb,supported).
node(n591,refuted) :- status(o_78545cbec07cdef331fb,refuted).
node(n591,unknown) :- status(o_78545cbec07cdef331fb,unknown).
node(n588,supported) :- node(n589,supported), node(n590,supported), node(n591,supported).
node(n588,refuted) :- node(n589,refuted).
node(n588,refuted) :- node(n590,refuted).
node(n588,refuted) :- node(n591,refuted).
node(n588,unknown) :- \+ node(n588,supported), \+ node(n588,refuted).
node(n583,refuted) :- node(n584,refuted), node(n588,refuted), node(n9,refuted).
node(n583,supported) :- node(n584,supported).
node(n583,supported) :- node(n588,supported).
node(n583,supported) :- node(n9,supported).
node(n583,unknown) :- \+ node(n583,supported), \+ node(n583,refuted).
verdict(c_dfacfc4efce2ecbd,supported) :- node(n583,supported).
query(verdict(c_dfacfc4efce2ecbd,supported)).
verdict(c_dfacfc4efce2ecbd,refuted) :- node(n583,refuted).
query(verdict(c_dfacfc4efce2ecbd,refuted)).
verdict(c_dfacfc4efce2ecbd,unknown) :- node(n583,unknown).
query(verdict(c_dfacfc4efce2ecbd,unknown)).
node(n594,supported) :- status(o_5a4107cc4ed2530df561,supported).
node(n594,refuted) :- status(o_5a4107cc4ed2530df561,refuted).
node(n594,unknown) :- status(o_5a4107cc4ed2530df561,unknown).
node(n593,supported) :- node(n585,supported), node(n586,supported), node(n594,supported), node(n587,supported).
node(n593,refuted) :- node(n585,refuted).
node(n593,refuted) :- node(n586,refuted).
node(n593,refuted) :- node(n594,refuted).
node(n593,refuted) :- node(n587,refuted).
node(n593,unknown) :- \+ node(n593,supported), \+ node(n593,refuted).
node(n596,supported) :- status(o_8bbb40edd8fdd15f34b1,supported).
node(n596,refuted) :- status(o_8bbb40edd8fdd15f34b1,refuted).
node(n596,unknown) :- status(o_8bbb40edd8fdd15f34b1,unknown).
node(n595,supported) :- node(n589,supported), node(n590,supported), node(n596,supported), node(n591,supported).
node(n595,refuted) :- node(n589,refuted).
node(n595,refuted) :- node(n590,refuted).
node(n595,refuted) :- node(n596,refuted).
node(n595,refuted) :- node(n591,refuted).
node(n595,unknown) :- \+ node(n595,supported), \+ node(n595,refuted).
node(n592,refuted) :- node(n593,refuted), node(n595,refuted), node(n9,refuted).
node(n592,supported) :- node(n593,supported).
node(n592,supported) :- node(n595,supported).
node(n592,supported) :- node(n9,supported).
node(n592,unknown) :- \+ node(n592,supported), \+ node(n592,refuted).
verdict(c_cef7c61d4eaa966d,supported) :- node(n592,supported).
query(verdict(c_cef7c61d4eaa966d,supported)).
verdict(c_cef7c61d4eaa966d,refuted) :- node(n592,refuted).
query(verdict(c_cef7c61d4eaa966d,refuted)).
verdict(c_cef7c61d4eaa966d,unknown) :- node(n592,unknown).
query(verdict(c_cef7c61d4eaa966d,unknown)).
node(n599,supported) :- status(o_6d1b54fe5d1ae2c36c58,supported).
node(n599,refuted) :- status(o_6d1b54fe5d1ae2c36c58,refuted).
node(n599,unknown) :- status(o_6d1b54fe5d1ae2c36c58,unknown).
node(n600,supported) :- status(o_f92a43a4b7026f2e16f6,supported).
node(n600,refuted) :- status(o_f92a43a4b7026f2e16f6,refuted).
node(n600,unknown) :- status(o_f92a43a4b7026f2e16f6,unknown).
node(n601,supported) :- status(o_eb0bb2d3a610e269cb09,supported).
node(n601,refuted) :- status(o_eb0bb2d3a610e269cb09,refuted).
node(n601,unknown) :- status(o_eb0bb2d3a610e269cb09,unknown).
node(n598,supported) :- node(n599,supported), node(n600,supported), node(n601,supported).
node(n598,refuted) :- node(n599,refuted).
node(n598,refuted) :- node(n600,refuted).
node(n598,refuted) :- node(n601,refuted).
node(n598,unknown) :- \+ node(n598,supported), \+ node(n598,refuted).
node(n597,refuted) :- node(n598,refuted), node(n9,refuted).
node(n597,supported) :- node(n598,supported).
node(n597,supported) :- node(n9,supported).
node(n597,unknown) :- \+ node(n597,supported), \+ node(n597,refuted).
verdict(c_5e66f31199a55a6c,supported) :- node(n597,supported).
query(verdict(c_5e66f31199a55a6c,supported)).
verdict(c_5e66f31199a55a6c,refuted) :- node(n597,refuted).
query(verdict(c_5e66f31199a55a6c,refuted)).
verdict(c_5e66f31199a55a6c,unknown) :- node(n597,unknown).
query(verdict(c_5e66f31199a55a6c,unknown)).
node(n604,supported) :- status(o_09d3b514598d1c4af582,supported).
node(n604,refuted) :- status(o_09d3b514598d1c4af582,refuted).
node(n604,unknown) :- status(o_09d3b514598d1c4af582,unknown).
node(n603,supported) :- node(n599,supported), node(n600,supported), node(n604,supported), node(n601,supported).
node(n603,refuted) :- node(n599,refuted).
node(n603,refuted) :- node(n600,refuted).
node(n603,refuted) :- node(n604,refuted).
node(n603,refuted) :- node(n601,refuted).
node(n603,unknown) :- \+ node(n603,supported), \+ node(n603,refuted).
node(n602,refuted) :- node(n603,refuted), node(n9,refuted).
node(n602,supported) :- node(n603,supported).
node(n602,supported) :- node(n9,supported).
node(n602,unknown) :- \+ node(n602,supported), \+ node(n602,refuted).
verdict(c_18f6dc6a7a67c38a,supported) :- node(n602,supported).
query(verdict(c_18f6dc6a7a67c38a,supported)).
verdict(c_18f6dc6a7a67c38a,refuted) :- node(n602,refuted).
query(verdict(c_18f6dc6a7a67c38a,refuted)).
verdict(c_18f6dc6a7a67c38a,unknown) :- node(n602,unknown).
query(verdict(c_18f6dc6a7a67c38a,unknown)).
node(n607,supported) :- status(o_7b689f0c8711deefb48b,supported).
node(n607,refuted) :- status(o_7b689f0c8711deefb48b,refuted).
node(n607,unknown) :- status(o_7b689f0c8711deefb48b,unknown).
node(n608,supported) :- status(o_3d5e970a0f2d371e11f0,supported).
node(n608,refuted) :- status(o_3d5e970a0f2d371e11f0,refuted).
node(n608,unknown) :- status(o_3d5e970a0f2d371e11f0,unknown).
node(n609,supported) :- status(o_f679bbba7f76f9b70a9c,supported).
node(n609,refuted) :- status(o_f679bbba7f76f9b70a9c,refuted).
node(n609,unknown) :- status(o_f679bbba7f76f9b70a9c,unknown).
node(n606,supported) :- node(n607,supported), node(n608,supported), node(n609,supported).
node(n606,refuted) :- node(n607,refuted).
node(n606,refuted) :- node(n608,refuted).
node(n606,refuted) :- node(n609,refuted).
node(n606,unknown) :- \+ node(n606,supported), \+ node(n606,refuted).
node(n605,refuted) :- node(n606,refuted), node(n9,refuted).
node(n605,supported) :- node(n606,supported).
node(n605,supported) :- node(n9,supported).
node(n605,unknown) :- \+ node(n605,supported), \+ node(n605,refuted).
verdict(c_bfcf70d08951db7c,supported) :- node(n605,supported).
query(verdict(c_bfcf70d08951db7c,supported)).
verdict(c_bfcf70d08951db7c,refuted) :- node(n605,refuted).
query(verdict(c_bfcf70d08951db7c,refuted)).
verdict(c_bfcf70d08951db7c,unknown) :- node(n605,unknown).
query(verdict(c_bfcf70d08951db7c,unknown)).
node(n612,supported) :- status(o_abbf600a16b903392499,supported).
node(n612,refuted) :- status(o_abbf600a16b903392499,refuted).
node(n612,unknown) :- status(o_abbf600a16b903392499,unknown).
node(n611,supported) :- node(n607,supported), node(n608,supported), node(n612,supported), node(n609,supported).
node(n611,refuted) :- node(n607,refuted).
node(n611,refuted) :- node(n608,refuted).
node(n611,refuted) :- node(n612,refuted).
node(n611,refuted) :- node(n609,refuted).
node(n611,unknown) :- \+ node(n611,supported), \+ node(n611,refuted).
node(n610,refuted) :- node(n611,refuted), node(n9,refuted).
node(n610,supported) :- node(n611,supported).
node(n610,supported) :- node(n9,supported).
node(n610,unknown) :- \+ node(n610,supported), \+ node(n610,refuted).
verdict(c_1d2d754e8da238b2,supported) :- node(n610,supported).
query(verdict(c_1d2d754e8da238b2,supported)).
verdict(c_1d2d754e8da238b2,refuted) :- node(n610,refuted).
query(verdict(c_1d2d754e8da238b2,refuted)).
verdict(c_1d2d754e8da238b2,unknown) :- node(n610,unknown).
query(verdict(c_1d2d754e8da238b2,unknown)).
node(n615,supported) :- status(o_b283f14827e32875a668,supported).
node(n615,refuted) :- status(o_b283f14827e32875a668,refuted).
node(n615,unknown) :- status(o_b283f14827e32875a668,unknown).
node(n616,supported) :- status(o_112c56a5876082625cab,supported).
node(n616,refuted) :- status(o_112c56a5876082625cab,refuted).
node(n616,unknown) :- status(o_112c56a5876082625cab,unknown).
node(n617,supported) :- status(o_06b67517fb89dbac98b8,supported).
node(n617,refuted) :- status(o_06b67517fb89dbac98b8,refuted).
node(n617,unknown) :- status(o_06b67517fb89dbac98b8,unknown).
node(n614,supported) :- node(n615,supported), node(n616,supported), node(n617,supported).
node(n614,refuted) :- node(n615,refuted).
node(n614,refuted) :- node(n616,refuted).
node(n614,refuted) :- node(n617,refuted).
node(n614,unknown) :- \+ node(n614,supported), \+ node(n614,refuted).
node(n613,refuted) :- node(n614,refuted), node(n9,refuted).
node(n613,supported) :- node(n614,supported).
node(n613,supported) :- node(n9,supported).
node(n613,unknown) :- \+ node(n613,supported), \+ node(n613,refuted).
verdict(c_0bcbfa2b0b5b90ec,supported) :- node(n613,supported).
query(verdict(c_0bcbfa2b0b5b90ec,supported)).
verdict(c_0bcbfa2b0b5b90ec,refuted) :- node(n613,refuted).
query(verdict(c_0bcbfa2b0b5b90ec,refuted)).
verdict(c_0bcbfa2b0b5b90ec,unknown) :- node(n613,unknown).
query(verdict(c_0bcbfa2b0b5b90ec,unknown)).
node(n620,supported) :- status(o_2dd8d437c786e7f1c4f1,supported).
node(n620,refuted) :- status(o_2dd8d437c786e7f1c4f1,refuted).
node(n620,unknown) :- status(o_2dd8d437c786e7f1c4f1,unknown).
node(n619,supported) :- node(n615,supported), node(n616,supported), node(n620,supported), node(n617,supported).
node(n619,refuted) :- node(n615,refuted).
node(n619,refuted) :- node(n616,refuted).
node(n619,refuted) :- node(n620,refuted).
node(n619,refuted) :- node(n617,refuted).
node(n619,unknown) :- \+ node(n619,supported), \+ node(n619,refuted).
node(n618,refuted) :- node(n619,refuted), node(n9,refuted).
node(n618,supported) :- node(n619,supported).
node(n618,supported) :- node(n9,supported).
node(n618,unknown) :- \+ node(n618,supported), \+ node(n618,refuted).
verdict(c_0e7843d522801a6b,supported) :- node(n618,supported).
query(verdict(c_0e7843d522801a6b,supported)).
verdict(c_0e7843d522801a6b,refuted) :- node(n618,refuted).
query(verdict(c_0e7843d522801a6b,refuted)).
verdict(c_0e7843d522801a6b,unknown) :- node(n618,unknown).
query(verdict(c_0e7843d522801a6b,unknown)).
node(n623,supported) :- status(o_bf6c260396eebb3ee297,supported).
node(n623,refuted) :- status(o_bf6c260396eebb3ee297,refuted).
node(n623,unknown) :- status(o_bf6c260396eebb3ee297,unknown).
node(n624,supported) :- status(o_eb1abd2431ddf7d6b62b,supported).
node(n624,refuted) :- status(o_eb1abd2431ddf7d6b62b,refuted).
node(n624,unknown) :- status(o_eb1abd2431ddf7d6b62b,unknown).
node(n625,supported) :- status(o_3f0a0d697ec759914a33,supported).
node(n625,refuted) :- status(o_3f0a0d697ec759914a33,refuted).
node(n625,unknown) :- status(o_3f0a0d697ec759914a33,unknown).
node(n622,supported) :- node(n623,supported), node(n624,supported), node(n625,supported).
node(n622,refuted) :- node(n623,refuted).
node(n622,refuted) :- node(n624,refuted).
node(n622,refuted) :- node(n625,refuted).
node(n622,unknown) :- \+ node(n622,supported), \+ node(n622,refuted).
node(n621,refuted) :- node(n622,refuted), node(n9,refuted).
node(n621,supported) :- node(n622,supported).
node(n621,supported) :- node(n9,supported).
node(n621,unknown) :- \+ node(n621,supported), \+ node(n621,refuted).
verdict(c_c3383c1a152ceba0,supported) :- node(n621,supported).
query(verdict(c_c3383c1a152ceba0,supported)).
verdict(c_c3383c1a152ceba0,refuted) :- node(n621,refuted).
query(verdict(c_c3383c1a152ceba0,refuted)).
verdict(c_c3383c1a152ceba0,unknown) :- node(n621,unknown).
query(verdict(c_c3383c1a152ceba0,unknown)).
node(n628,supported) :- status(o_b3db7ce52ed5148415de,supported).
node(n628,refuted) :- status(o_b3db7ce52ed5148415de,refuted).
node(n628,unknown) :- status(o_b3db7ce52ed5148415de,unknown).
node(n627,supported) :- node(n623,supported), node(n624,supported), node(n628,supported), node(n625,supported).
node(n627,refuted) :- node(n623,refuted).
node(n627,refuted) :- node(n624,refuted).
node(n627,refuted) :- node(n628,refuted).
node(n627,refuted) :- node(n625,refuted).
node(n627,unknown) :- \+ node(n627,supported), \+ node(n627,refuted).
node(n626,refuted) :- node(n627,refuted), node(n9,refuted).
node(n626,supported) :- node(n627,supported).
node(n626,supported) :- node(n9,supported).
node(n626,unknown) :- \+ node(n626,supported), \+ node(n626,refuted).
verdict(c_ed612970e6084c49,supported) :- node(n626,supported).
query(verdict(c_ed612970e6084c49,supported)).
verdict(c_ed612970e6084c49,refuted) :- node(n626,refuted).
query(verdict(c_ed612970e6084c49,refuted)).
verdict(c_ed612970e6084c49,unknown) :- node(n626,unknown).
query(verdict(c_ed612970e6084c49,unknown)).
node(n631,supported) :- status(o_1fe0b77a2ad953872a1d,supported).
node(n631,refuted) :- status(o_1fe0b77a2ad953872a1d,refuted).
node(n631,unknown) :- status(o_1fe0b77a2ad953872a1d,unknown).
node(n632,supported) :- status(o_c93d9a77d40c39cbe0b4,supported).
node(n632,refuted) :- status(o_c93d9a77d40c39cbe0b4,refuted).
node(n632,unknown) :- status(o_c93d9a77d40c39cbe0b4,unknown).
node(n633,supported) :- status(o_82a4042b418ec673ede4,supported).
node(n633,refuted) :- status(o_82a4042b418ec673ede4,refuted).
node(n633,unknown) :- status(o_82a4042b418ec673ede4,unknown).
node(n630,supported) :- node(n631,supported), node(n632,supported), node(n633,supported).
node(n630,refuted) :- node(n631,refuted).
node(n630,refuted) :- node(n632,refuted).
node(n630,refuted) :- node(n633,refuted).
node(n630,unknown) :- \+ node(n630,supported), \+ node(n630,refuted).
node(n629,refuted) :- node(n630,refuted), node(n9,refuted).
node(n629,supported) :- node(n630,supported).
node(n629,supported) :- node(n9,supported).
node(n629,unknown) :- \+ node(n629,supported), \+ node(n629,refuted).
verdict(c_c91aa1ef07f6aa93,supported) :- node(n629,supported).
query(verdict(c_c91aa1ef07f6aa93,supported)).
verdict(c_c91aa1ef07f6aa93,refuted) :- node(n629,refuted).
query(verdict(c_c91aa1ef07f6aa93,refuted)).
verdict(c_c91aa1ef07f6aa93,unknown) :- node(n629,unknown).
query(verdict(c_c91aa1ef07f6aa93,unknown)).
node(n636,supported) :- status(o_f38f2cd83b5b77899ffd,supported).
node(n636,refuted) :- status(o_f38f2cd83b5b77899ffd,refuted).
node(n636,unknown) :- status(o_f38f2cd83b5b77899ffd,unknown).
node(n635,supported) :- node(n631,supported), node(n632,supported), node(n636,supported), node(n633,supported).
node(n635,refuted) :- node(n631,refuted).
node(n635,refuted) :- node(n632,refuted).
node(n635,refuted) :- node(n636,refuted).
node(n635,refuted) :- node(n633,refuted).
node(n635,unknown) :- \+ node(n635,supported), \+ node(n635,refuted).
node(n634,refuted) :- node(n635,refuted), node(n9,refuted).
node(n634,supported) :- node(n635,supported).
node(n634,supported) :- node(n9,supported).
node(n634,unknown) :- \+ node(n634,supported), \+ node(n634,refuted).
verdict(c_e8b9f3e8643512ed,supported) :- node(n634,supported).
query(verdict(c_e8b9f3e8643512ed,supported)).
verdict(c_e8b9f3e8643512ed,refuted) :- node(n634,refuted).
query(verdict(c_e8b9f3e8643512ed,refuted)).
verdict(c_e8b9f3e8643512ed,unknown) :- node(n634,unknown).
query(verdict(c_e8b9f3e8643512ed,unknown)).
node(n639,supported) :- status(o_51c0fc64d79cad130828,supported).
node(n639,refuted) :- status(o_51c0fc64d79cad130828,refuted).
node(n639,unknown) :- status(o_51c0fc64d79cad130828,unknown).
node(n640,supported) :- status(o_78ea6efaa4bd8715a358,supported).
node(n640,refuted) :- status(o_78ea6efaa4bd8715a358,refuted).
node(n640,unknown) :- status(o_78ea6efaa4bd8715a358,unknown).
node(n641,supported) :- status(o_10a8db2f2e7019906595,supported).
node(n641,refuted) :- status(o_10a8db2f2e7019906595,refuted).
node(n641,unknown) :- status(o_10a8db2f2e7019906595,unknown).
node(n638,supported) :- node(n639,supported), node(n640,supported), node(n641,supported).
node(n638,refuted) :- node(n639,refuted).
node(n638,refuted) :- node(n640,refuted).
node(n638,refuted) :- node(n641,refuted).
node(n638,unknown) :- \+ node(n638,supported), \+ node(n638,refuted).
node(n637,refuted) :- node(n638,refuted), node(n9,refuted).
node(n637,supported) :- node(n638,supported).
node(n637,supported) :- node(n9,supported).
node(n637,unknown) :- \+ node(n637,supported), \+ node(n637,refuted).
verdict(c_65497c194b05ff2f,supported) :- node(n637,supported).
query(verdict(c_65497c194b05ff2f,supported)).
verdict(c_65497c194b05ff2f,refuted) :- node(n637,refuted).
query(verdict(c_65497c194b05ff2f,refuted)).
verdict(c_65497c194b05ff2f,unknown) :- node(n637,unknown).
query(verdict(c_65497c194b05ff2f,unknown)).
node(n644,supported) :- status(o_289ed5d7dede9e57bf46,supported).
node(n644,refuted) :- status(o_289ed5d7dede9e57bf46,refuted).
node(n644,unknown) :- status(o_289ed5d7dede9e57bf46,unknown).
node(n643,supported) :- node(n639,supported), node(n640,supported), node(n644,supported), node(n641,supported).
node(n643,refuted) :- node(n639,refuted).
node(n643,refuted) :- node(n640,refuted).
node(n643,refuted) :- node(n644,refuted).
node(n643,refuted) :- node(n641,refuted).
node(n643,unknown) :- \+ node(n643,supported), \+ node(n643,refuted).
node(n642,refuted) :- node(n643,refuted), node(n9,refuted).
node(n642,supported) :- node(n643,supported).
node(n642,supported) :- node(n9,supported).
node(n642,unknown) :- \+ node(n642,supported), \+ node(n642,refuted).
verdict(c_62ff68e46b401b87,supported) :- node(n642,supported).
query(verdict(c_62ff68e46b401b87,supported)).
verdict(c_62ff68e46b401b87,refuted) :- node(n642,refuted).
query(verdict(c_62ff68e46b401b87,refuted)).
verdict(c_62ff68e46b401b87,unknown) :- node(n642,unknown).
query(verdict(c_62ff68e46b401b87,unknown)).
node(n647,supported) :- status(o_903d3c5d25ed624913ca,supported).
node(n647,refuted) :- status(o_903d3c5d25ed624913ca,refuted).
node(n647,unknown) :- status(o_903d3c5d25ed624913ca,unknown).
node(n648,supported) :- status(o_a53f289362ec1bbcd8b7,supported).
node(n648,refuted) :- status(o_a53f289362ec1bbcd8b7,refuted).
node(n648,unknown) :- status(o_a53f289362ec1bbcd8b7,unknown).
node(n649,supported) :- status(o_986a15a0a84721a1f9b5,supported).
node(n649,refuted) :- status(o_986a15a0a84721a1f9b5,refuted).
node(n649,unknown) :- status(o_986a15a0a84721a1f9b5,unknown).
node(n646,supported) :- node(n647,supported), node(n648,supported), node(n649,supported).
node(n646,refuted) :- node(n647,refuted).
node(n646,refuted) :- node(n648,refuted).
node(n646,refuted) :- node(n649,refuted).
node(n646,unknown) :- \+ node(n646,supported), \+ node(n646,refuted).
node(n645,refuted) :- node(n646,refuted), node(n9,refuted).
node(n645,supported) :- node(n646,supported).
node(n645,supported) :- node(n9,supported).
node(n645,unknown) :- \+ node(n645,supported), \+ node(n645,refuted).
verdict(c_fc606b14f227c928,supported) :- node(n645,supported).
query(verdict(c_fc606b14f227c928,supported)).
verdict(c_fc606b14f227c928,refuted) :- node(n645,refuted).
query(verdict(c_fc606b14f227c928,refuted)).
verdict(c_fc606b14f227c928,unknown) :- node(n645,unknown).
query(verdict(c_fc606b14f227c928,unknown)).
node(n652,supported) :- status(o_05d6e4c2285b76e8f4ae,supported).
node(n652,refuted) :- status(o_05d6e4c2285b76e8f4ae,refuted).
node(n652,unknown) :- status(o_05d6e4c2285b76e8f4ae,unknown).
node(n651,supported) :- node(n647,supported), node(n648,supported), node(n652,supported), node(n649,supported).
node(n651,refuted) :- node(n647,refuted).
node(n651,refuted) :- node(n648,refuted).
node(n651,refuted) :- node(n652,refuted).
node(n651,refuted) :- node(n649,refuted).
node(n651,unknown) :- \+ node(n651,supported), \+ node(n651,refuted).
node(n650,refuted) :- node(n651,refuted), node(n9,refuted).
node(n650,supported) :- node(n651,supported).
node(n650,supported) :- node(n9,supported).
node(n650,unknown) :- \+ node(n650,supported), \+ node(n650,refuted).
verdict(c_da8464b3ad35733f,supported) :- node(n650,supported).
query(verdict(c_da8464b3ad35733f,supported)).
verdict(c_da8464b3ad35733f,refuted) :- node(n650,refuted).
query(verdict(c_da8464b3ad35733f,refuted)).
verdict(c_da8464b3ad35733f,unknown) :- node(n650,unknown).
query(verdict(c_da8464b3ad35733f,unknown)).
node(n655,supported) :- status(o_7ab202ac62c8fdee8969,supported).
node(n655,refuted) :- status(o_7ab202ac62c8fdee8969,refuted).
node(n655,unknown) :- status(o_7ab202ac62c8fdee8969,unknown).
node(n656,supported) :- status(o_4d28b89477c7f6aea0c9,supported).
node(n656,refuted) :- status(o_4d28b89477c7f6aea0c9,refuted).
node(n656,unknown) :- status(o_4d28b89477c7f6aea0c9,unknown).
node(n657,supported) :- status(o_b0978ff4ff104df4cc09,supported).
node(n657,refuted) :- status(o_b0978ff4ff104df4cc09,refuted).
node(n657,unknown) :- status(o_b0978ff4ff104df4cc09,unknown).
node(n654,supported) :- node(n655,supported), node(n656,supported), node(n657,supported).
node(n654,refuted) :- node(n655,refuted).
node(n654,refuted) :- node(n656,refuted).
node(n654,refuted) :- node(n657,refuted).
node(n654,unknown) :- \+ node(n654,supported), \+ node(n654,refuted).
node(n659,supported) :- status(o_44ccc51ad29ebcf095fa,supported).
node(n659,refuted) :- status(o_44ccc51ad29ebcf095fa,refuted).
node(n659,unknown) :- status(o_44ccc51ad29ebcf095fa,unknown).
node(n660,supported) :- status(o_b5f7d6cec7ba9d902819,supported).
node(n660,refuted) :- status(o_b5f7d6cec7ba9d902819,refuted).
node(n660,unknown) :- status(o_b5f7d6cec7ba9d902819,unknown).
node(n661,supported) :- status(o_a332867ed37ac3c0a6fd,supported).
node(n661,refuted) :- status(o_a332867ed37ac3c0a6fd,refuted).
node(n661,unknown) :- status(o_a332867ed37ac3c0a6fd,unknown).
node(n658,supported) :- node(n659,supported), node(n660,supported), node(n661,supported).
node(n658,refuted) :- node(n659,refuted).
node(n658,refuted) :- node(n660,refuted).
node(n658,refuted) :- node(n661,refuted).
node(n658,unknown) :- \+ node(n658,supported), \+ node(n658,refuted).
node(n653,refuted) :- node(n654,refuted), node(n658,refuted), node(n9,refuted).
node(n653,supported) :- node(n654,supported).
node(n653,supported) :- node(n658,supported).
node(n653,supported) :- node(n9,supported).
node(n653,unknown) :- \+ node(n653,supported), \+ node(n653,refuted).
verdict(c_76d3cff98c3cd47d,supported) :- node(n653,supported).
query(verdict(c_76d3cff98c3cd47d,supported)).
verdict(c_76d3cff98c3cd47d,refuted) :- node(n653,refuted).
query(verdict(c_76d3cff98c3cd47d,refuted)).
verdict(c_76d3cff98c3cd47d,unknown) :- node(n653,unknown).
query(verdict(c_76d3cff98c3cd47d,unknown)).
node(n664,supported) :- status(o_863ed4e97bf651e1e44c,supported).
node(n664,refuted) :- status(o_863ed4e97bf651e1e44c,refuted).
node(n664,unknown) :- status(o_863ed4e97bf651e1e44c,unknown).
node(n663,supported) :- node(n655,supported), node(n656,supported), node(n664,supported), node(n657,supported).
node(n663,refuted) :- node(n655,refuted).
node(n663,refuted) :- node(n656,refuted).
node(n663,refuted) :- node(n664,refuted).
node(n663,refuted) :- node(n657,refuted).
node(n663,unknown) :- \+ node(n663,supported), \+ node(n663,refuted).
node(n666,supported) :- status(o_4d902c8529fc6baca58e,supported).
node(n666,refuted) :- status(o_4d902c8529fc6baca58e,refuted).
node(n666,unknown) :- status(o_4d902c8529fc6baca58e,unknown).
node(n665,supported) :- node(n659,supported), node(n660,supported), node(n666,supported), node(n661,supported).
node(n665,refuted) :- node(n659,refuted).
node(n665,refuted) :- node(n660,refuted).
node(n665,refuted) :- node(n666,refuted).
node(n665,refuted) :- node(n661,refuted).
node(n665,unknown) :- \+ node(n665,supported), \+ node(n665,refuted).
node(n662,refuted) :- node(n663,refuted), node(n665,refuted), node(n9,refuted).
node(n662,supported) :- node(n663,supported).
node(n662,supported) :- node(n665,supported).
node(n662,supported) :- node(n9,supported).
node(n662,unknown) :- \+ node(n662,supported), \+ node(n662,refuted).
verdict(c_d327805eae33696f,supported) :- node(n662,supported).
query(verdict(c_d327805eae33696f,supported)).
verdict(c_d327805eae33696f,refuted) :- node(n662,refuted).
query(verdict(c_d327805eae33696f,refuted)).
verdict(c_d327805eae33696f,unknown) :- node(n662,unknown).
query(verdict(c_d327805eae33696f,unknown)).
node(n669,supported) :- status(o_1398aa96f0a0ce1058ab,supported).
node(n669,refuted) :- status(o_1398aa96f0a0ce1058ab,refuted).
node(n669,unknown) :- status(o_1398aa96f0a0ce1058ab,unknown).
node(n670,supported) :- status(o_510820d653cee6d3b321,supported).
node(n670,refuted) :- status(o_510820d653cee6d3b321,refuted).
node(n670,unknown) :- status(o_510820d653cee6d3b321,unknown).
node(n671,supported) :- status(o_ba6cbb6148cb84b02cd5,supported).
node(n671,refuted) :- status(o_ba6cbb6148cb84b02cd5,refuted).
node(n671,unknown) :- status(o_ba6cbb6148cb84b02cd5,unknown).
node(n668,supported) :- node(n669,supported), node(n670,supported), node(n671,supported).
node(n668,refuted) :- node(n669,refuted).
node(n668,refuted) :- node(n670,refuted).
node(n668,refuted) :- node(n671,refuted).
node(n668,unknown) :- \+ node(n668,supported), \+ node(n668,refuted).
node(n673,supported) :- status(o_8e82df60feb90809d347,supported).
node(n673,refuted) :- status(o_8e82df60feb90809d347,refuted).
node(n673,unknown) :- status(o_8e82df60feb90809d347,unknown).
node(n674,supported) :- status(o_9ef7603bd61a3cd1162b,supported).
node(n674,refuted) :- status(o_9ef7603bd61a3cd1162b,refuted).
node(n674,unknown) :- status(o_9ef7603bd61a3cd1162b,unknown).
node(n675,supported) :- status(o_d27800b9078c2bcfa0fd,supported).
node(n675,refuted) :- status(o_d27800b9078c2bcfa0fd,refuted).
node(n675,unknown) :- status(o_d27800b9078c2bcfa0fd,unknown).
node(n672,supported) :- node(n673,supported), node(n674,supported), node(n675,supported).
node(n672,refuted) :- node(n673,refuted).
node(n672,refuted) :- node(n674,refuted).
node(n672,refuted) :- node(n675,refuted).
node(n672,unknown) :- \+ node(n672,supported), \+ node(n672,refuted).
node(n667,refuted) :- node(n668,refuted), node(n672,refuted), node(n9,refuted).
node(n667,supported) :- node(n668,supported).
node(n667,supported) :- node(n672,supported).
node(n667,supported) :- node(n9,supported).
node(n667,unknown) :- \+ node(n667,supported), \+ node(n667,refuted).
verdict(c_69599ac032d3ddc4,supported) :- node(n667,supported).
query(verdict(c_69599ac032d3ddc4,supported)).
verdict(c_69599ac032d3ddc4,refuted) :- node(n667,refuted).
query(verdict(c_69599ac032d3ddc4,refuted)).
verdict(c_69599ac032d3ddc4,unknown) :- node(n667,unknown).
query(verdict(c_69599ac032d3ddc4,unknown)).
node(n678,supported) :- status(o_3a466d2fc15cf77dbf8b,supported).
node(n678,refuted) :- status(o_3a466d2fc15cf77dbf8b,refuted).
node(n678,unknown) :- status(o_3a466d2fc15cf77dbf8b,unknown).
node(n677,supported) :- node(n669,supported), node(n670,supported), node(n678,supported), node(n671,supported).
node(n677,refuted) :- node(n669,refuted).
node(n677,refuted) :- node(n670,refuted).
node(n677,refuted) :- node(n678,refuted).
node(n677,refuted) :- node(n671,refuted).
node(n677,unknown) :- \+ node(n677,supported), \+ node(n677,refuted).
node(n680,supported) :- status(o_00ad64f51dae10718060,supported).
node(n680,refuted) :- status(o_00ad64f51dae10718060,refuted).
node(n680,unknown) :- status(o_00ad64f51dae10718060,unknown).
node(n679,supported) :- node(n673,supported), node(n674,supported), node(n680,supported), node(n675,supported).
node(n679,refuted) :- node(n673,refuted).
node(n679,refuted) :- node(n674,refuted).
node(n679,refuted) :- node(n680,refuted).
node(n679,refuted) :- node(n675,refuted).
node(n679,unknown) :- \+ node(n679,supported), \+ node(n679,refuted).
node(n676,refuted) :- node(n677,refuted), node(n679,refuted), node(n9,refuted).
node(n676,supported) :- node(n677,supported).
node(n676,supported) :- node(n679,supported).
node(n676,supported) :- node(n9,supported).
node(n676,unknown) :- \+ node(n676,supported), \+ node(n676,refuted).
verdict(c_30a9690ff1c9e3b8,supported) :- node(n676,supported).
query(verdict(c_30a9690ff1c9e3b8,supported)).
verdict(c_30a9690ff1c9e3b8,refuted) :- node(n676,refuted).
query(verdict(c_30a9690ff1c9e3b8,refuted)).
verdict(c_30a9690ff1c9e3b8,unknown) :- node(n676,unknown).
query(verdict(c_30a9690ff1c9e3b8,unknown)).
node(n683,supported) :- status(o_d246b22a2ae198ed84cb,supported).
node(n683,refuted) :- status(o_d246b22a2ae198ed84cb,refuted).
node(n683,unknown) :- status(o_d246b22a2ae198ed84cb,unknown).
node(n684,supported) :- status(o_7664e13e53630bb96e10,supported).
node(n684,refuted) :- status(o_7664e13e53630bb96e10,refuted).
node(n684,unknown) :- status(o_7664e13e53630bb96e10,unknown).
node(n685,supported) :- status(o_3c78a94bc648b2496d91,supported).
node(n685,refuted) :- status(o_3c78a94bc648b2496d91,refuted).
node(n685,unknown) :- status(o_3c78a94bc648b2496d91,unknown).
node(n682,supported) :- node(n683,supported), node(n684,supported), node(n685,supported).
node(n682,refuted) :- node(n683,refuted).
node(n682,refuted) :- node(n684,refuted).
node(n682,refuted) :- node(n685,refuted).
node(n682,unknown) :- \+ node(n682,supported), \+ node(n682,refuted).
node(n687,supported) :- status(o_673fee03e493346b746e,supported).
node(n687,refuted) :- status(o_673fee03e493346b746e,refuted).
node(n687,unknown) :- status(o_673fee03e493346b746e,unknown).
node(n688,supported) :- status(o_ca39965b176b9773d7ec,supported).
node(n688,refuted) :- status(o_ca39965b176b9773d7ec,refuted).
node(n688,unknown) :- status(o_ca39965b176b9773d7ec,unknown).
node(n689,supported) :- status(o_0c9965e9d630899ba817,supported).
node(n689,refuted) :- status(o_0c9965e9d630899ba817,refuted).
node(n689,unknown) :- status(o_0c9965e9d630899ba817,unknown).
node(n686,supported) :- node(n687,supported), node(n688,supported), node(n689,supported).
node(n686,refuted) :- node(n687,refuted).
node(n686,refuted) :- node(n688,refuted).
node(n686,refuted) :- node(n689,refuted).
node(n686,unknown) :- \+ node(n686,supported), \+ node(n686,refuted).
node(n681,refuted) :- node(n682,refuted), node(n686,refuted), node(n9,refuted).
node(n681,supported) :- node(n682,supported).
node(n681,supported) :- node(n686,supported).
node(n681,supported) :- node(n9,supported).
node(n681,unknown) :- \+ node(n681,supported), \+ node(n681,refuted).
verdict(c_e55cb49dae8bc29d,supported) :- node(n681,supported).
query(verdict(c_e55cb49dae8bc29d,supported)).
verdict(c_e55cb49dae8bc29d,refuted) :- node(n681,refuted).
query(verdict(c_e55cb49dae8bc29d,refuted)).
verdict(c_e55cb49dae8bc29d,unknown) :- node(n681,unknown).
query(verdict(c_e55cb49dae8bc29d,unknown)).
node(n692,supported) :- status(o_3b275837263ec2f1f5c2,supported).
node(n692,refuted) :- status(o_3b275837263ec2f1f5c2,refuted).
node(n692,unknown) :- status(o_3b275837263ec2f1f5c2,unknown).
node(n691,supported) :- node(n683,supported), node(n684,supported), node(n692,supported), node(n685,supported).
node(n691,refuted) :- node(n683,refuted).
node(n691,refuted) :- node(n684,refuted).
node(n691,refuted) :- node(n692,refuted).
node(n691,refuted) :- node(n685,refuted).
node(n691,unknown) :- \+ node(n691,supported), \+ node(n691,refuted).
node(n694,supported) :- status(o_36e53627d4fe36d9d282,supported).
node(n694,refuted) :- status(o_36e53627d4fe36d9d282,refuted).
node(n694,unknown) :- status(o_36e53627d4fe36d9d282,unknown).
node(n693,supported) :- node(n687,supported), node(n688,supported), node(n694,supported), node(n689,supported).
node(n693,refuted) :- node(n687,refuted).
node(n693,refuted) :- node(n688,refuted).
node(n693,refuted) :- node(n694,refuted).
node(n693,refuted) :- node(n689,refuted).
node(n693,unknown) :- \+ node(n693,supported), \+ node(n693,refuted).
node(n690,refuted) :- node(n691,refuted), node(n693,refuted), node(n9,refuted).
node(n690,supported) :- node(n691,supported).
node(n690,supported) :- node(n693,supported).
node(n690,supported) :- node(n9,supported).
node(n690,unknown) :- \+ node(n690,supported), \+ node(n690,refuted).
verdict(c_a473a263971f633c,supported) :- node(n690,supported).
query(verdict(c_a473a263971f633c,supported)).
verdict(c_a473a263971f633c,refuted) :- node(n690,refuted).
query(verdict(c_a473a263971f633c,refuted)).
verdict(c_a473a263971f633c,unknown) :- node(n690,unknown).
query(verdict(c_a473a263971f633c,unknown)).
node(n697,supported) :- status(o_468be3babf641307d972,supported).
node(n697,refuted) :- status(o_468be3babf641307d972,refuted).
node(n697,unknown) :- status(o_468be3babf641307d972,unknown).
node(n698,supported) :- status(o_9ee589f86c1d037995ef,supported).
node(n698,refuted) :- status(o_9ee589f86c1d037995ef,refuted).
node(n698,unknown) :- status(o_9ee589f86c1d037995ef,unknown).
node(n699,supported) :- status(o_489efec430fd0fa66716,supported).
node(n699,refuted) :- status(o_489efec430fd0fa66716,refuted).
node(n699,unknown) :- status(o_489efec430fd0fa66716,unknown).
node(n696,supported) :- node(n697,supported), node(n698,supported), node(n699,supported).
node(n696,refuted) :- node(n697,refuted).
node(n696,refuted) :- node(n698,refuted).
node(n696,refuted) :- node(n699,refuted).
node(n696,unknown) :- \+ node(n696,supported), \+ node(n696,refuted).
node(n701,supported) :- status(o_c38257176a64045332c2,supported).
node(n701,refuted) :- status(o_c38257176a64045332c2,refuted).
node(n701,unknown) :- status(o_c38257176a64045332c2,unknown).
node(n702,supported) :- status(o_d11c1a177ee12190fc24,supported).
node(n702,refuted) :- status(o_d11c1a177ee12190fc24,refuted).
node(n702,unknown) :- status(o_d11c1a177ee12190fc24,unknown).
node(n703,supported) :- status(o_05929e27873600e36733,supported).
node(n703,refuted) :- status(o_05929e27873600e36733,refuted).
node(n703,unknown) :- status(o_05929e27873600e36733,unknown).
node(n700,supported) :- node(n701,supported), node(n702,supported), node(n703,supported).
node(n700,refuted) :- node(n701,refuted).
node(n700,refuted) :- node(n702,refuted).
node(n700,refuted) :- node(n703,refuted).
node(n700,unknown) :- \+ node(n700,supported), \+ node(n700,refuted).
node(n695,refuted) :- node(n696,refuted), node(n700,refuted), node(n9,refuted).
node(n695,supported) :- node(n696,supported).
node(n695,supported) :- node(n700,supported).
node(n695,supported) :- node(n9,supported).
node(n695,unknown) :- \+ node(n695,supported), \+ node(n695,refuted).
verdict(c_66651debf95379b5,supported) :- node(n695,supported).
query(verdict(c_66651debf95379b5,supported)).
verdict(c_66651debf95379b5,refuted) :- node(n695,refuted).
query(verdict(c_66651debf95379b5,refuted)).
verdict(c_66651debf95379b5,unknown) :- node(n695,unknown).
query(verdict(c_66651debf95379b5,unknown)).
node(n706,supported) :- status(o_309baf1c9fe60620599b,supported).
node(n706,refuted) :- status(o_309baf1c9fe60620599b,refuted).
node(n706,unknown) :- status(o_309baf1c9fe60620599b,unknown).
node(n705,supported) :- node(n697,supported), node(n698,supported), node(n706,supported), node(n699,supported).
node(n705,refuted) :- node(n697,refuted).
node(n705,refuted) :- node(n698,refuted).
node(n705,refuted) :- node(n706,refuted).
node(n705,refuted) :- node(n699,refuted).
node(n705,unknown) :- \+ node(n705,supported), \+ node(n705,refuted).
node(n708,supported) :- status(o_fc95ca510d87dd43e20f,supported).
node(n708,refuted) :- status(o_fc95ca510d87dd43e20f,refuted).
node(n708,unknown) :- status(o_fc95ca510d87dd43e20f,unknown).
node(n707,supported) :- node(n701,supported), node(n702,supported), node(n708,supported), node(n703,supported).
node(n707,refuted) :- node(n701,refuted).
node(n707,refuted) :- node(n702,refuted).
node(n707,refuted) :- node(n708,refuted).
node(n707,refuted) :- node(n703,refuted).
node(n707,unknown) :- \+ node(n707,supported), \+ node(n707,refuted).
node(n704,refuted) :- node(n705,refuted), node(n707,refuted), node(n9,refuted).
node(n704,supported) :- node(n705,supported).
node(n704,supported) :- node(n707,supported).
node(n704,supported) :- node(n9,supported).
node(n704,unknown) :- \+ node(n704,supported), \+ node(n704,refuted).
verdict(c_cc3b47501bcf939c,supported) :- node(n704,supported).
query(verdict(c_cc3b47501bcf939c,supported)).
verdict(c_cc3b47501bcf939c,refuted) :- node(n704,refuted).
query(verdict(c_cc3b47501bcf939c,refuted)).
verdict(c_cc3b47501bcf939c,unknown) :- node(n704,unknown).
query(verdict(c_cc3b47501bcf939c,unknown)).
node(n711,supported) :- status(o_5e492fe8162d57aadf78,supported).
node(n711,refuted) :- status(o_5e492fe8162d57aadf78,refuted).
node(n711,unknown) :- status(o_5e492fe8162d57aadf78,unknown).
node(n712,supported) :- status(o_4bd273288a69a1575e33,supported).
node(n712,refuted) :- status(o_4bd273288a69a1575e33,refuted).
node(n712,unknown) :- status(o_4bd273288a69a1575e33,unknown).
node(n713,supported) :- status(o_c3d5b580e815a1798d83,supported).
node(n713,refuted) :- status(o_c3d5b580e815a1798d83,refuted).
node(n713,unknown) :- status(o_c3d5b580e815a1798d83,unknown).
node(n710,supported) :- node(n711,supported), node(n712,supported), node(n713,supported).
node(n710,refuted) :- node(n711,refuted).
node(n710,refuted) :- node(n712,refuted).
node(n710,refuted) :- node(n713,refuted).
node(n710,unknown) :- \+ node(n710,supported), \+ node(n710,refuted).
node(n715,supported) :- status(o_d20a3b8edef1feef8322,supported).
node(n715,refuted) :- status(o_d20a3b8edef1feef8322,refuted).
node(n715,unknown) :- status(o_d20a3b8edef1feef8322,unknown).
node(n716,supported) :- status(o_d15b07d6a3b5f11628e6,supported).
node(n716,refuted) :- status(o_d15b07d6a3b5f11628e6,refuted).
node(n716,unknown) :- status(o_d15b07d6a3b5f11628e6,unknown).
node(n717,supported) :- status(o_464aecc4ce5a1844d124,supported).
node(n717,refuted) :- status(o_464aecc4ce5a1844d124,refuted).
node(n717,unknown) :- status(o_464aecc4ce5a1844d124,unknown).
node(n714,supported) :- node(n715,supported), node(n716,supported), node(n717,supported).
node(n714,refuted) :- node(n715,refuted).
node(n714,refuted) :- node(n716,refuted).
node(n714,refuted) :- node(n717,refuted).
node(n714,unknown) :- \+ node(n714,supported), \+ node(n714,refuted).
node(n709,refuted) :- node(n710,refuted), node(n714,refuted), node(n9,refuted).
node(n709,supported) :- node(n710,supported).
node(n709,supported) :- node(n714,supported).
node(n709,supported) :- node(n9,supported).
node(n709,unknown) :- \+ node(n709,supported), \+ node(n709,refuted).
verdict(c_0b4f469f774a0326,supported) :- node(n709,supported).
query(verdict(c_0b4f469f774a0326,supported)).
verdict(c_0b4f469f774a0326,refuted) :- node(n709,refuted).
query(verdict(c_0b4f469f774a0326,refuted)).
verdict(c_0b4f469f774a0326,unknown) :- node(n709,unknown).
query(verdict(c_0b4f469f774a0326,unknown)).
node(n720,supported) :- status(o_c107783c00ca77d9b4f7,supported).
node(n720,refuted) :- status(o_c107783c00ca77d9b4f7,refuted).
node(n720,unknown) :- status(o_c107783c00ca77d9b4f7,unknown).
node(n719,supported) :- node(n711,supported), node(n712,supported), node(n720,supported), node(n713,supported).
node(n719,refuted) :- node(n711,refuted).
node(n719,refuted) :- node(n712,refuted).
node(n719,refuted) :- node(n720,refuted).
node(n719,refuted) :- node(n713,refuted).
node(n719,unknown) :- \+ node(n719,supported), \+ node(n719,refuted).
node(n722,supported) :- status(o_815231a2d896d5b78c95,supported).
node(n722,refuted) :- status(o_815231a2d896d5b78c95,refuted).
node(n722,unknown) :- status(o_815231a2d896d5b78c95,unknown).
node(n721,supported) :- node(n715,supported), node(n716,supported), node(n722,supported), node(n717,supported).
node(n721,refuted) :- node(n715,refuted).
node(n721,refuted) :- node(n716,refuted).
node(n721,refuted) :- node(n722,refuted).
node(n721,refuted) :- node(n717,refuted).
node(n721,unknown) :- \+ node(n721,supported), \+ node(n721,refuted).
node(n718,refuted) :- node(n719,refuted), node(n721,refuted), node(n9,refuted).
node(n718,supported) :- node(n719,supported).
node(n718,supported) :- node(n721,supported).
node(n718,supported) :- node(n9,supported).
node(n718,unknown) :- \+ node(n718,supported), \+ node(n718,refuted).
verdict(c_c14c96edb65607f8,supported) :- node(n718,supported).
query(verdict(c_c14c96edb65607f8,supported)).
verdict(c_c14c96edb65607f8,refuted) :- node(n718,refuted).
query(verdict(c_c14c96edb65607f8,refuted)).
verdict(c_c14c96edb65607f8,unknown) :- node(n718,unknown).
query(verdict(c_c14c96edb65607f8,unknown)).
node(n725,supported) :- status(o_5320cd848352bc38e08f,supported).
node(n725,refuted) :- status(o_5320cd848352bc38e08f,refuted).
node(n725,unknown) :- status(o_5320cd848352bc38e08f,unknown).
node(n726,supported) :- status(o_1c4d720ea7ef876005ef,supported).
node(n726,refuted) :- status(o_1c4d720ea7ef876005ef,refuted).
node(n726,unknown) :- status(o_1c4d720ea7ef876005ef,unknown).
node(n727,supported) :- status(o_5f28285bb8f6675ce263,supported).
node(n727,refuted) :- status(o_5f28285bb8f6675ce263,refuted).
node(n727,unknown) :- status(o_5f28285bb8f6675ce263,unknown).
node(n724,supported) :- node(n725,supported), node(n726,supported), node(n727,supported).
node(n724,refuted) :- node(n725,refuted).
node(n724,refuted) :- node(n726,refuted).
node(n724,refuted) :- node(n727,refuted).
node(n724,unknown) :- \+ node(n724,supported), \+ node(n724,refuted).
node(n723,refuted) :- node(n724,refuted), node(n9,refuted).
node(n723,supported) :- node(n724,supported).
node(n723,supported) :- node(n9,supported).
node(n723,unknown) :- \+ node(n723,supported), \+ node(n723,refuted).
verdict(c_5bf9c9a6a1da28cd,supported) :- node(n723,supported).
query(verdict(c_5bf9c9a6a1da28cd,supported)).
verdict(c_5bf9c9a6a1da28cd,refuted) :- node(n723,refuted).
query(verdict(c_5bf9c9a6a1da28cd,refuted)).
verdict(c_5bf9c9a6a1da28cd,unknown) :- node(n723,unknown).
query(verdict(c_5bf9c9a6a1da28cd,unknown)).
node(n730,supported) :- status(o_f413e52d14f0ddea856b,supported).
node(n730,refuted) :- status(o_f413e52d14f0ddea856b,refuted).
node(n730,unknown) :- status(o_f413e52d14f0ddea856b,unknown).
node(n729,supported) :- node(n725,supported), node(n726,supported), node(n730,supported), node(n727,supported).
node(n729,refuted) :- node(n725,refuted).
node(n729,refuted) :- node(n726,refuted).
node(n729,refuted) :- node(n730,refuted).
node(n729,refuted) :- node(n727,refuted).
node(n729,unknown) :- \+ node(n729,supported), \+ node(n729,refuted).
node(n728,refuted) :- node(n729,refuted), node(n9,refuted).
node(n728,supported) :- node(n729,supported).
node(n728,supported) :- node(n9,supported).
node(n728,unknown) :- \+ node(n728,supported), \+ node(n728,refuted).
verdict(c_4f770107f08ca6de,supported) :- node(n728,supported).
query(verdict(c_4f770107f08ca6de,supported)).
verdict(c_4f770107f08ca6de,refuted) :- node(n728,refuted).
query(verdict(c_4f770107f08ca6de,refuted)).
verdict(c_4f770107f08ca6de,unknown) :- node(n728,unknown).
query(verdict(c_4f770107f08ca6de,unknown)).
node(n733,supported) :- status(o_5ed964c5cb9a7faefe37,supported).
node(n733,refuted) :- status(o_5ed964c5cb9a7faefe37,refuted).
node(n733,unknown) :- status(o_5ed964c5cb9a7faefe37,unknown).
node(n734,supported) :- status(o_f7f0d7b2186d8fe0fef9,supported).
node(n734,refuted) :- status(o_f7f0d7b2186d8fe0fef9,refuted).
node(n734,unknown) :- status(o_f7f0d7b2186d8fe0fef9,unknown).
node(n735,supported) :- status(o_624ffa0d0bd1f7f92cd4,supported).
node(n735,refuted) :- status(o_624ffa0d0bd1f7f92cd4,refuted).
node(n735,unknown) :- status(o_624ffa0d0bd1f7f92cd4,unknown).
node(n732,supported) :- node(n733,supported), node(n734,supported), node(n735,supported).
node(n732,refuted) :- node(n733,refuted).
node(n732,refuted) :- node(n734,refuted).
node(n732,refuted) :- node(n735,refuted).
node(n732,unknown) :- \+ node(n732,supported), \+ node(n732,refuted).
node(n731,refuted) :- node(n732,refuted), node(n9,refuted).
node(n731,supported) :- node(n732,supported).
node(n731,supported) :- node(n9,supported).
node(n731,unknown) :- \+ node(n731,supported), \+ node(n731,refuted).
verdict(c_c61f35631b4adfd4,supported) :- node(n731,supported).
query(verdict(c_c61f35631b4adfd4,supported)).
verdict(c_c61f35631b4adfd4,refuted) :- node(n731,refuted).
query(verdict(c_c61f35631b4adfd4,refuted)).
verdict(c_c61f35631b4adfd4,unknown) :- node(n731,unknown).
query(verdict(c_c61f35631b4adfd4,unknown)).
node(n738,supported) :- status(o_a456230c045faf540dde,supported).
node(n738,refuted) :- status(o_a456230c045faf540dde,refuted).
node(n738,unknown) :- status(o_a456230c045faf540dde,unknown).
node(n737,supported) :- node(n733,supported), node(n734,supported), node(n738,supported), node(n735,supported).
node(n737,refuted) :- node(n733,refuted).
node(n737,refuted) :- node(n734,refuted).
node(n737,refuted) :- node(n738,refuted).
node(n737,refuted) :- node(n735,refuted).
node(n737,unknown) :- \+ node(n737,supported), \+ node(n737,refuted).
node(n736,refuted) :- node(n737,refuted), node(n9,refuted).
node(n736,supported) :- node(n737,supported).
node(n736,supported) :- node(n9,supported).
node(n736,unknown) :- \+ node(n736,supported), \+ node(n736,refuted).
verdict(c_f53b9ae641d18b2b,supported) :- node(n736,supported).
query(verdict(c_f53b9ae641d18b2b,supported)).
verdict(c_f53b9ae641d18b2b,refuted) :- node(n736,refuted).
query(verdict(c_f53b9ae641d18b2b,refuted)).
verdict(c_f53b9ae641d18b2b,unknown) :- node(n736,unknown).
query(verdict(c_f53b9ae641d18b2b,unknown)).
node(n741,supported) :- status(o_12040c1eda66a2928b74,supported).
node(n741,refuted) :- status(o_12040c1eda66a2928b74,refuted).
node(n741,unknown) :- status(o_12040c1eda66a2928b74,unknown).
node(n742,supported) :- status(o_f152bef1705394970e0d,supported).
node(n742,refuted) :- status(o_f152bef1705394970e0d,refuted).
node(n742,unknown) :- status(o_f152bef1705394970e0d,unknown).
node(n743,supported) :- status(o_ee96f668af800e35740e,supported).
node(n743,refuted) :- status(o_ee96f668af800e35740e,refuted).
node(n743,unknown) :- status(o_ee96f668af800e35740e,unknown).
node(n740,supported) :- node(n741,supported), node(n742,supported), node(n743,supported).
node(n740,refuted) :- node(n741,refuted).
node(n740,refuted) :- node(n742,refuted).
node(n740,refuted) :- node(n743,refuted).
node(n740,unknown) :- \+ node(n740,supported), \+ node(n740,refuted).
node(n739,refuted) :- node(n740,refuted), node(n9,refuted).
node(n739,supported) :- node(n740,supported).
node(n739,supported) :- node(n9,supported).
node(n739,unknown) :- \+ node(n739,supported), \+ node(n739,refuted).
verdict(c_e5ee7a83ef32647c,supported) :- node(n739,supported).
query(verdict(c_e5ee7a83ef32647c,supported)).
verdict(c_e5ee7a83ef32647c,refuted) :- node(n739,refuted).
query(verdict(c_e5ee7a83ef32647c,refuted)).
verdict(c_e5ee7a83ef32647c,unknown) :- node(n739,unknown).
query(verdict(c_e5ee7a83ef32647c,unknown)).
node(n746,supported) :- status(o_6b16873a1dc74e54c5dd,supported).
node(n746,refuted) :- status(o_6b16873a1dc74e54c5dd,refuted).
node(n746,unknown) :- status(o_6b16873a1dc74e54c5dd,unknown).
node(n745,supported) :- node(n741,supported), node(n742,supported), node(n746,supported), node(n743,supported).
node(n745,refuted) :- node(n741,refuted).
node(n745,refuted) :- node(n742,refuted).
node(n745,refuted) :- node(n746,refuted).
node(n745,refuted) :- node(n743,refuted).
node(n745,unknown) :- \+ node(n745,supported), \+ node(n745,refuted).
node(n744,refuted) :- node(n745,refuted), node(n9,refuted).
node(n744,supported) :- node(n745,supported).
node(n744,supported) :- node(n9,supported).
node(n744,unknown) :- \+ node(n744,supported), \+ node(n744,refuted).
verdict(c_f124799dc0d8ca08,supported) :- node(n744,supported).
query(verdict(c_f124799dc0d8ca08,supported)).
verdict(c_f124799dc0d8ca08,refuted) :- node(n744,refuted).
query(verdict(c_f124799dc0d8ca08,refuted)).
verdict(c_f124799dc0d8ca08,unknown) :- node(n744,unknown).
query(verdict(c_f124799dc0d8ca08,unknown)).
node(n749,supported) :- status(o_1cdfcf4bd6b2a11ae04d,supported).
node(n749,refuted) :- status(o_1cdfcf4bd6b2a11ae04d,refuted).
node(n749,unknown) :- status(o_1cdfcf4bd6b2a11ae04d,unknown).
node(n750,supported) :- status(o_5fecb3b1ecec92f01d33,supported).
node(n750,refuted) :- status(o_5fecb3b1ecec92f01d33,refuted).
node(n750,unknown) :- status(o_5fecb3b1ecec92f01d33,unknown).
node(n751,supported) :- status(o_93a517dea00ddf3bb51f,supported).
node(n751,refuted) :- status(o_93a517dea00ddf3bb51f,refuted).
node(n751,unknown) :- status(o_93a517dea00ddf3bb51f,unknown).
node(n748,supported) :- node(n749,supported), node(n750,supported), node(n751,supported).
node(n748,refuted) :- node(n749,refuted).
node(n748,refuted) :- node(n750,refuted).
node(n748,refuted) :- node(n751,refuted).
node(n748,unknown) :- \+ node(n748,supported), \+ node(n748,refuted).
node(n747,refuted) :- node(n748,refuted), node(n9,refuted).
node(n747,supported) :- node(n748,supported).
node(n747,supported) :- node(n9,supported).
node(n747,unknown) :- \+ node(n747,supported), \+ node(n747,refuted).
verdict(c_e6b44b67e4a74aaa,supported) :- node(n747,supported).
query(verdict(c_e6b44b67e4a74aaa,supported)).
verdict(c_e6b44b67e4a74aaa,refuted) :- node(n747,refuted).
query(verdict(c_e6b44b67e4a74aaa,refuted)).
verdict(c_e6b44b67e4a74aaa,unknown) :- node(n747,unknown).
query(verdict(c_e6b44b67e4a74aaa,unknown)).
node(n754,supported) :- status(o_c8ca54c1023c47b9da78,supported).
node(n754,refuted) :- status(o_c8ca54c1023c47b9da78,refuted).
node(n754,unknown) :- status(o_c8ca54c1023c47b9da78,unknown).
node(n753,supported) :- node(n749,supported), node(n750,supported), node(n754,supported), node(n751,supported).
node(n753,refuted) :- node(n749,refuted).
node(n753,refuted) :- node(n750,refuted).
node(n753,refuted) :- node(n754,refuted).
node(n753,refuted) :- node(n751,refuted).
node(n753,unknown) :- \+ node(n753,supported), \+ node(n753,refuted).
node(n752,refuted) :- node(n753,refuted), node(n9,refuted).
node(n752,supported) :- node(n753,supported).
node(n752,supported) :- node(n9,supported).
node(n752,unknown) :- \+ node(n752,supported), \+ node(n752,refuted).
verdict(c_f0da04f19a165c5f,supported) :- node(n752,supported).
query(verdict(c_f0da04f19a165c5f,supported)).
verdict(c_f0da04f19a165c5f,refuted) :- node(n752,refuted).
query(verdict(c_f0da04f19a165c5f,refuted)).
verdict(c_f0da04f19a165c5f,unknown) :- node(n752,unknown).
query(verdict(c_f0da04f19a165c5f,unknown)).
node(n757,supported) :- status(o_83d936f13cdca3e59e6c,supported).
node(n757,refuted) :- status(o_83d936f13cdca3e59e6c,refuted).
node(n757,unknown) :- status(o_83d936f13cdca3e59e6c,unknown).
node(n758,supported) :- status(o_cdf694541ca7147e7b2c,supported).
node(n758,refuted) :- status(o_cdf694541ca7147e7b2c,refuted).
node(n758,unknown) :- status(o_cdf694541ca7147e7b2c,unknown).
node(n759,supported) :- status(o_c6948330fa57b57a2ed8,supported).
node(n759,refuted) :- status(o_c6948330fa57b57a2ed8,refuted).
node(n759,unknown) :- status(o_c6948330fa57b57a2ed8,unknown).
node(n756,supported) :- node(n757,supported), node(n758,supported), node(n759,supported).
node(n756,refuted) :- node(n757,refuted).
node(n756,refuted) :- node(n758,refuted).
node(n756,refuted) :- node(n759,refuted).
node(n756,unknown) :- \+ node(n756,supported), \+ node(n756,refuted).
node(n755,refuted) :- node(n756,refuted), node(n9,refuted).
node(n755,supported) :- node(n756,supported).
node(n755,supported) :- node(n9,supported).
node(n755,unknown) :- \+ node(n755,supported), \+ node(n755,refuted).
verdict(c_f5f81b936e31802f,supported) :- node(n755,supported).
query(verdict(c_f5f81b936e31802f,supported)).
verdict(c_f5f81b936e31802f,refuted) :- node(n755,refuted).
query(verdict(c_f5f81b936e31802f,refuted)).
verdict(c_f5f81b936e31802f,unknown) :- node(n755,unknown).
query(verdict(c_f5f81b936e31802f,unknown)).
node(n762,supported) :- status(o_21cbac8973411012256d,supported).
node(n762,refuted) :- status(o_21cbac8973411012256d,refuted).
node(n762,unknown) :- status(o_21cbac8973411012256d,unknown).
node(n761,supported) :- node(n757,supported), node(n758,supported), node(n762,supported), node(n759,supported).
node(n761,refuted) :- node(n757,refuted).
node(n761,refuted) :- node(n758,refuted).
node(n761,refuted) :- node(n762,refuted).
node(n761,refuted) :- node(n759,refuted).
node(n761,unknown) :- \+ node(n761,supported), \+ node(n761,refuted).
node(n760,refuted) :- node(n761,refuted), node(n9,refuted).
node(n760,supported) :- node(n761,supported).
node(n760,supported) :- node(n9,supported).
node(n760,unknown) :- \+ node(n760,supported), \+ node(n760,refuted).
verdict(c_50caea61055247ff,supported) :- node(n760,supported).
query(verdict(c_50caea61055247ff,supported)).
verdict(c_50caea61055247ff,refuted) :- node(n760,refuted).
query(verdict(c_50caea61055247ff,refuted)).
verdict(c_50caea61055247ff,unknown) :- node(n760,unknown).
query(verdict(c_50caea61055247ff,unknown)).
node(n765,supported) :- status(o_a9c3d4b5a6a78fc0c800,supported).
node(n765,refuted) :- status(o_a9c3d4b5a6a78fc0c800,refuted).
node(n765,unknown) :- status(o_a9c3d4b5a6a78fc0c800,unknown).
node(n766,supported) :- status(o_fb8f4bb93e7d143d0497,supported).
node(n766,refuted) :- status(o_fb8f4bb93e7d143d0497,refuted).
node(n766,unknown) :- status(o_fb8f4bb93e7d143d0497,unknown).
node(n767,supported) :- status(o_96069de593c1d7fdae19,supported).
node(n767,refuted) :- status(o_96069de593c1d7fdae19,refuted).
node(n767,unknown) :- status(o_96069de593c1d7fdae19,unknown).
node(n764,supported) :- node(n765,supported), node(n766,supported), node(n767,supported).
node(n764,refuted) :- node(n765,refuted).
node(n764,refuted) :- node(n766,refuted).
node(n764,refuted) :- node(n767,refuted).
node(n764,unknown) :- \+ node(n764,supported), \+ node(n764,refuted).
node(n763,refuted) :- node(n764,refuted), node(n9,refuted).
node(n763,supported) :- node(n764,supported).
node(n763,supported) :- node(n9,supported).
node(n763,unknown) :- \+ node(n763,supported), \+ node(n763,refuted).
verdict(c_bc0ba4410e4c9ed9,supported) :- node(n763,supported).
query(verdict(c_bc0ba4410e4c9ed9,supported)).
verdict(c_bc0ba4410e4c9ed9,refuted) :- node(n763,refuted).
query(verdict(c_bc0ba4410e4c9ed9,refuted)).
verdict(c_bc0ba4410e4c9ed9,unknown) :- node(n763,unknown).
query(verdict(c_bc0ba4410e4c9ed9,unknown)).
node(n770,supported) :- status(o_831e848ea1787e7f0d40,supported).
node(n770,refuted) :- status(o_831e848ea1787e7f0d40,refuted).
node(n770,unknown) :- status(o_831e848ea1787e7f0d40,unknown).
node(n769,supported) :- node(n765,supported), node(n766,supported), node(n770,supported), node(n767,supported).
node(n769,refuted) :- node(n765,refuted).
node(n769,refuted) :- node(n766,refuted).
node(n769,refuted) :- node(n770,refuted).
node(n769,refuted) :- node(n767,refuted).
node(n769,unknown) :- \+ node(n769,supported), \+ node(n769,refuted).
node(n768,refuted) :- node(n769,refuted), node(n9,refuted).
node(n768,supported) :- node(n769,supported).
node(n768,supported) :- node(n9,supported).
node(n768,unknown) :- \+ node(n768,supported), \+ node(n768,refuted).
verdict(c_0879bdde8deb6b4b,supported) :- node(n768,supported).
query(verdict(c_0879bdde8deb6b4b,supported)).
verdict(c_0879bdde8deb6b4b,refuted) :- node(n768,refuted).
query(verdict(c_0879bdde8deb6b4b,refuted)).
verdict(c_0879bdde8deb6b4b,unknown) :- node(n768,unknown).
query(verdict(c_0879bdde8deb6b4b,unknown)).
node(n773,supported) :- status(o_01ff1e8d0f4aa7a71943,supported).
node(n773,refuted) :- status(o_01ff1e8d0f4aa7a71943,refuted).
node(n773,unknown) :- status(o_01ff1e8d0f4aa7a71943,unknown).
node(n774,supported) :- status(o_91f192664ecf4a3fba34,supported).
node(n774,refuted) :- status(o_91f192664ecf4a3fba34,refuted).
node(n774,unknown) :- status(o_91f192664ecf4a3fba34,unknown).
node(n775,supported) :- status(o_ab78405154f59670a15b,supported).
node(n775,refuted) :- status(o_ab78405154f59670a15b,refuted).
node(n775,unknown) :- status(o_ab78405154f59670a15b,unknown).
node(n772,supported) :- node(n773,supported), node(n774,supported), node(n775,supported).
node(n772,refuted) :- node(n773,refuted).
node(n772,refuted) :- node(n774,refuted).
node(n772,refuted) :- node(n775,refuted).
node(n772,unknown) :- \+ node(n772,supported), \+ node(n772,refuted).
node(n771,refuted) :- node(n772,refuted), node(n9,refuted).
node(n771,supported) :- node(n772,supported).
node(n771,supported) :- node(n9,supported).
node(n771,unknown) :- \+ node(n771,supported), \+ node(n771,refuted).
verdict(c_84bf3736f3a943b8,supported) :- node(n771,supported).
query(verdict(c_84bf3736f3a943b8,supported)).
verdict(c_84bf3736f3a943b8,refuted) :- node(n771,refuted).
query(verdict(c_84bf3736f3a943b8,refuted)).
verdict(c_84bf3736f3a943b8,unknown) :- node(n771,unknown).
query(verdict(c_84bf3736f3a943b8,unknown)).
node(n778,supported) :- status(o_4abdbe95c42e70b6cdbb,supported).
node(n778,refuted) :- status(o_4abdbe95c42e70b6cdbb,refuted).
node(n778,unknown) :- status(o_4abdbe95c42e70b6cdbb,unknown).
node(n777,supported) :- node(n773,supported), node(n774,supported), node(n778,supported), node(n775,supported).
node(n777,refuted) :- node(n773,refuted).
node(n777,refuted) :- node(n774,refuted).
node(n777,refuted) :- node(n778,refuted).
node(n777,refuted) :- node(n775,refuted).
node(n777,unknown) :- \+ node(n777,supported), \+ node(n777,refuted).
node(n776,refuted) :- node(n777,refuted), node(n9,refuted).
node(n776,supported) :- node(n777,supported).
node(n776,supported) :- node(n9,supported).
node(n776,unknown) :- \+ node(n776,supported), \+ node(n776,refuted).
verdict(c_c4c4133053defaf8,supported) :- node(n776,supported).
query(verdict(c_c4c4133053defaf8,supported)).
verdict(c_c4c4133053defaf8,refuted) :- node(n776,refuted).
query(verdict(c_c4c4133053defaf8,refuted)).
verdict(c_c4c4133053defaf8,unknown) :- node(n776,unknown).
query(verdict(c_c4c4133053defaf8,unknown)).
node(n781,supported) :- status(o_ad270d0bba0f02906684,supported).
node(n781,refuted) :- status(o_ad270d0bba0f02906684,refuted).
node(n781,unknown) :- status(o_ad270d0bba0f02906684,unknown).
node(n782,supported) :- status(o_ecfedabe6ce1e9e563bf,supported).
node(n782,refuted) :- status(o_ecfedabe6ce1e9e563bf,refuted).
node(n782,unknown) :- status(o_ecfedabe6ce1e9e563bf,unknown).
node(n783,supported) :- status(o_000730c96e06a0d8eb8f,supported).
node(n783,refuted) :- status(o_000730c96e06a0d8eb8f,refuted).
node(n783,unknown) :- status(o_000730c96e06a0d8eb8f,unknown).
node(n780,supported) :- node(n781,supported), node(n782,supported), node(n783,supported).
node(n780,refuted) :- node(n781,refuted).
node(n780,refuted) :- node(n782,refuted).
node(n780,refuted) :- node(n783,refuted).
node(n780,unknown) :- \+ node(n780,supported), \+ node(n780,refuted).
node(n779,refuted) :- node(n780,refuted), node(n9,refuted).
node(n779,supported) :- node(n780,supported).
node(n779,supported) :- node(n9,supported).
node(n779,unknown) :- \+ node(n779,supported), \+ node(n779,refuted).
verdict(c_5f7165ae55e5a87b,supported) :- node(n779,supported).
query(verdict(c_5f7165ae55e5a87b,supported)).
verdict(c_5f7165ae55e5a87b,refuted) :- node(n779,refuted).
query(verdict(c_5f7165ae55e5a87b,refuted)).
verdict(c_5f7165ae55e5a87b,unknown) :- node(n779,unknown).
query(verdict(c_5f7165ae55e5a87b,unknown)).
node(n786,supported) :- status(o_7f434f93751d75eba66f,supported).
node(n786,refuted) :- status(o_7f434f93751d75eba66f,refuted).
node(n786,unknown) :- status(o_7f434f93751d75eba66f,unknown).
node(n785,supported) :- node(n781,supported), node(n782,supported), node(n786,supported), node(n783,supported).
node(n785,refuted) :- node(n781,refuted).
node(n785,refuted) :- node(n782,refuted).
node(n785,refuted) :- node(n786,refuted).
node(n785,refuted) :- node(n783,refuted).
node(n785,unknown) :- \+ node(n785,supported), \+ node(n785,refuted).
node(n784,refuted) :- node(n785,refuted), node(n9,refuted).
node(n784,supported) :- node(n785,supported).
node(n784,supported) :- node(n9,supported).
node(n784,unknown) :- \+ node(n784,supported), \+ node(n784,refuted).
verdict(c_371b5e9ca8b10be8,supported) :- node(n784,supported).
query(verdict(c_371b5e9ca8b10be8,supported)).
verdict(c_371b5e9ca8b10be8,refuted) :- node(n784,refuted).
query(verdict(c_371b5e9ca8b10be8,refuted)).
verdict(c_371b5e9ca8b10be8,unknown) :- node(n784,unknown).
query(verdict(c_371b5e9ca8b10be8,unknown)).
node(n789,supported) :- status(o_b889a587d55becc59e30,supported).
node(n789,refuted) :- status(o_b889a587d55becc59e30,refuted).
node(n789,unknown) :- status(o_b889a587d55becc59e30,unknown).
node(n790,supported) :- status(o_66bd7d087c86af0550dd,supported).
node(n790,refuted) :- status(o_66bd7d087c86af0550dd,refuted).
node(n790,unknown) :- status(o_66bd7d087c86af0550dd,unknown).
node(n791,supported) :- status(o_37d7ad41426bf255b761,supported).
node(n791,refuted) :- status(o_37d7ad41426bf255b761,refuted).
node(n791,unknown) :- status(o_37d7ad41426bf255b761,unknown).
node(n788,supported) :- node(n789,supported), node(n790,supported), node(n791,supported).
node(n788,refuted) :- node(n789,refuted).
node(n788,refuted) :- node(n790,refuted).
node(n788,refuted) :- node(n791,refuted).
node(n788,unknown) :- \+ node(n788,supported), \+ node(n788,refuted).
node(n793,supported) :- status(o_1074e465ebfb67ae40c2,supported).
node(n793,refuted) :- status(o_1074e465ebfb67ae40c2,refuted).
node(n793,unknown) :- status(o_1074e465ebfb67ae40c2,unknown).
node(n794,supported) :- status(o_12a5d326e6f06090caa9,supported).
node(n794,refuted) :- status(o_12a5d326e6f06090caa9,refuted).
node(n794,unknown) :- status(o_12a5d326e6f06090caa9,unknown).
node(n795,supported) :- status(o_7e470dd82029c2c3181b,supported).
node(n795,refuted) :- status(o_7e470dd82029c2c3181b,refuted).
node(n795,unknown) :- status(o_7e470dd82029c2c3181b,unknown).
node(n792,supported) :- node(n793,supported), node(n794,supported), node(n795,supported).
node(n792,refuted) :- node(n793,refuted).
node(n792,refuted) :- node(n794,refuted).
node(n792,refuted) :- node(n795,refuted).
node(n792,unknown) :- \+ node(n792,supported), \+ node(n792,refuted).
node(n787,refuted) :- node(n788,refuted), node(n792,refuted), node(n9,refuted).
node(n787,supported) :- node(n788,supported).
node(n787,supported) :- node(n792,supported).
node(n787,supported) :- node(n9,supported).
node(n787,unknown) :- \+ node(n787,supported), \+ node(n787,refuted).
verdict(c_f7ef5e702cb58caa,supported) :- node(n787,supported).
query(verdict(c_f7ef5e702cb58caa,supported)).
verdict(c_f7ef5e702cb58caa,refuted) :- node(n787,refuted).
query(verdict(c_f7ef5e702cb58caa,refuted)).
verdict(c_f7ef5e702cb58caa,unknown) :- node(n787,unknown).
query(verdict(c_f7ef5e702cb58caa,unknown)).
node(n798,supported) :- status(o_38aaedabf761c64ff28c,supported).
node(n798,refuted) :- status(o_38aaedabf761c64ff28c,refuted).
node(n798,unknown) :- status(o_38aaedabf761c64ff28c,unknown).
node(n797,supported) :- node(n789,supported), node(n790,supported), node(n798,supported), node(n791,supported).
node(n797,refuted) :- node(n789,refuted).
node(n797,refuted) :- node(n790,refuted).
node(n797,refuted) :- node(n798,refuted).
node(n797,refuted) :- node(n791,refuted).
node(n797,unknown) :- \+ node(n797,supported), \+ node(n797,refuted).
node(n800,supported) :- status(o_8705912f65db6960a7da,supported).
node(n800,refuted) :- status(o_8705912f65db6960a7da,refuted).
node(n800,unknown) :- status(o_8705912f65db6960a7da,unknown).
node(n799,supported) :- node(n793,supported), node(n794,supported), node(n800,supported), node(n795,supported).
node(n799,refuted) :- node(n793,refuted).
node(n799,refuted) :- node(n794,refuted).
node(n799,refuted) :- node(n800,refuted).
node(n799,refuted) :- node(n795,refuted).
node(n799,unknown) :- \+ node(n799,supported), \+ node(n799,refuted).
node(n796,refuted) :- node(n797,refuted), node(n799,refuted), node(n9,refuted).
node(n796,supported) :- node(n797,supported).
node(n796,supported) :- node(n799,supported).
node(n796,supported) :- node(n9,supported).
node(n796,unknown) :- \+ node(n796,supported), \+ node(n796,refuted).
verdict(c_b0f07ba738677687,supported) :- node(n796,supported).
query(verdict(c_b0f07ba738677687,supported)).
verdict(c_b0f07ba738677687,refuted) :- node(n796,refuted).
query(verdict(c_b0f07ba738677687,refuted)).
verdict(c_b0f07ba738677687,unknown) :- node(n796,unknown).
query(verdict(c_b0f07ba738677687,unknown)).
node(n803,supported) :- status(o_12cda33193bc97021ac5,supported).
node(n803,refuted) :- status(o_12cda33193bc97021ac5,refuted).
node(n803,unknown) :- status(o_12cda33193bc97021ac5,unknown).
node(n804,supported) :- status(o_35af888d6b2099f8d460,supported).
node(n804,refuted) :- status(o_35af888d6b2099f8d460,refuted).
node(n804,unknown) :- status(o_35af888d6b2099f8d460,unknown).
node(n805,supported) :- status(o_ae956e35ebe3ab49ed4f,supported).
node(n805,refuted) :- status(o_ae956e35ebe3ab49ed4f,refuted).
node(n805,unknown) :- status(o_ae956e35ebe3ab49ed4f,unknown).
node(n802,supported) :- node(n803,supported), node(n804,supported), node(n805,supported).
node(n802,refuted) :- node(n803,refuted).
node(n802,refuted) :- node(n804,refuted).
node(n802,refuted) :- node(n805,refuted).
node(n802,unknown) :- \+ node(n802,supported), \+ node(n802,refuted).
node(n807,supported) :- status(o_8245c9557609075d1254,supported).
node(n807,refuted) :- status(o_8245c9557609075d1254,refuted).
node(n807,unknown) :- status(o_8245c9557609075d1254,unknown).
node(n808,supported) :- status(o_8990b558b754924c8135,supported).
node(n808,refuted) :- status(o_8990b558b754924c8135,refuted).
node(n808,unknown) :- status(o_8990b558b754924c8135,unknown).
node(n809,supported) :- status(o_b9e706ab190a594eb146,supported).
node(n809,refuted) :- status(o_b9e706ab190a594eb146,refuted).
node(n809,unknown) :- status(o_b9e706ab190a594eb146,unknown).
node(n806,supported) :- node(n807,supported), node(n808,supported), node(n809,supported).
node(n806,refuted) :- node(n807,refuted).
node(n806,refuted) :- node(n808,refuted).
node(n806,refuted) :- node(n809,refuted).
node(n806,unknown) :- \+ node(n806,supported), \+ node(n806,refuted).
node(n801,refuted) :- node(n802,refuted), node(n806,refuted), node(n9,refuted).
node(n801,supported) :- node(n802,supported).
node(n801,supported) :- node(n806,supported).
node(n801,supported) :- node(n9,supported).
node(n801,unknown) :- \+ node(n801,supported), \+ node(n801,refuted).
verdict(c_a21288c6a238beaf,supported) :- node(n801,supported).
query(verdict(c_a21288c6a238beaf,supported)).
verdict(c_a21288c6a238beaf,refuted) :- node(n801,refuted).
query(verdict(c_a21288c6a238beaf,refuted)).
verdict(c_a21288c6a238beaf,unknown) :- node(n801,unknown).
query(verdict(c_a21288c6a238beaf,unknown)).
node(n812,supported) :- status(o_bd84b91f8391005dc64f,supported).
node(n812,refuted) :- status(o_bd84b91f8391005dc64f,refuted).
node(n812,unknown) :- status(o_bd84b91f8391005dc64f,unknown).
node(n811,supported) :- node(n803,supported), node(n804,supported), node(n812,supported), node(n805,supported).
node(n811,refuted) :- node(n803,refuted).
node(n811,refuted) :- node(n804,refuted).
node(n811,refuted) :- node(n812,refuted).
node(n811,refuted) :- node(n805,refuted).
node(n811,unknown) :- \+ node(n811,supported), \+ node(n811,refuted).
node(n814,supported) :- status(o_55ad6c431d2f2e4f4dba,supported).
node(n814,refuted) :- status(o_55ad6c431d2f2e4f4dba,refuted).
node(n814,unknown) :- status(o_55ad6c431d2f2e4f4dba,unknown).
node(n813,supported) :- node(n807,supported), node(n808,supported), node(n814,supported), node(n809,supported).
node(n813,refuted) :- node(n807,refuted).
node(n813,refuted) :- node(n808,refuted).
node(n813,refuted) :- node(n814,refuted).
node(n813,refuted) :- node(n809,refuted).
node(n813,unknown) :- \+ node(n813,supported), \+ node(n813,refuted).
node(n810,refuted) :- node(n811,refuted), node(n813,refuted), node(n9,refuted).
node(n810,supported) :- node(n811,supported).
node(n810,supported) :- node(n813,supported).
node(n810,supported) :- node(n9,supported).
node(n810,unknown) :- \+ node(n810,supported), \+ node(n810,refuted).
verdict(c_50dbf7bf30d010ad,supported) :- node(n810,supported).
query(verdict(c_50dbf7bf30d010ad,supported)).
verdict(c_50dbf7bf30d010ad,refuted) :- node(n810,refuted).
query(verdict(c_50dbf7bf30d010ad,refuted)).
verdict(c_50dbf7bf30d010ad,unknown) :- node(n810,unknown).
query(verdict(c_50dbf7bf30d010ad,unknown)).
node(n817,supported) :- status(o_116556a461efcae85586,supported).
node(n817,refuted) :- status(o_116556a461efcae85586,refuted).
node(n817,unknown) :- status(o_116556a461efcae85586,unknown).
node(n818,supported) :- status(o_8879f1449daf661265ba,supported).
node(n818,refuted) :- status(o_8879f1449daf661265ba,refuted).
node(n818,unknown) :- status(o_8879f1449daf661265ba,unknown).
node(n819,supported) :- status(o_70b9ee27084195915155,supported).
node(n819,refuted) :- status(o_70b9ee27084195915155,refuted).
node(n819,unknown) :- status(o_70b9ee27084195915155,unknown).
node(n816,supported) :- node(n817,supported), node(n818,supported), node(n819,supported).
node(n816,refuted) :- node(n817,refuted).
node(n816,refuted) :- node(n818,refuted).
node(n816,refuted) :- node(n819,refuted).
node(n816,unknown) :- \+ node(n816,supported), \+ node(n816,refuted).
node(n821,supported) :- status(o_3e5b5ebb25c63596c8b9,supported).
node(n821,refuted) :- status(o_3e5b5ebb25c63596c8b9,refuted).
node(n821,unknown) :- status(o_3e5b5ebb25c63596c8b9,unknown).
node(n822,supported) :- status(o_186bead0f48e9193133f,supported).
node(n822,refuted) :- status(o_186bead0f48e9193133f,refuted).
node(n822,unknown) :- status(o_186bead0f48e9193133f,unknown).
node(n823,supported) :- status(o_9b2ba101eedc382abc28,supported).
node(n823,refuted) :- status(o_9b2ba101eedc382abc28,refuted).
node(n823,unknown) :- status(o_9b2ba101eedc382abc28,unknown).
node(n820,supported) :- node(n821,supported), node(n822,supported), node(n823,supported).
node(n820,refuted) :- node(n821,refuted).
node(n820,refuted) :- node(n822,refuted).
node(n820,refuted) :- node(n823,refuted).
node(n820,unknown) :- \+ node(n820,supported), \+ node(n820,refuted).
node(n815,refuted) :- node(n816,refuted), node(n820,refuted), node(n9,refuted).
node(n815,supported) :- node(n816,supported).
node(n815,supported) :- node(n820,supported).
node(n815,supported) :- node(n9,supported).
node(n815,unknown) :- \+ node(n815,supported), \+ node(n815,refuted).
verdict(c_0a1a9cf8cea40737,supported) :- node(n815,supported).
query(verdict(c_0a1a9cf8cea40737,supported)).
verdict(c_0a1a9cf8cea40737,refuted) :- node(n815,refuted).
query(verdict(c_0a1a9cf8cea40737,refuted)).
verdict(c_0a1a9cf8cea40737,unknown) :- node(n815,unknown).
query(verdict(c_0a1a9cf8cea40737,unknown)).
node(n826,supported) :- status(o_6ba663ee66a3a824c2c2,supported).
node(n826,refuted) :- status(o_6ba663ee66a3a824c2c2,refuted).
node(n826,unknown) :- status(o_6ba663ee66a3a824c2c2,unknown).
node(n825,supported) :- node(n817,supported), node(n818,supported), node(n826,supported), node(n819,supported).
node(n825,refuted) :- node(n817,refuted).
node(n825,refuted) :- node(n818,refuted).
node(n825,refuted) :- node(n826,refuted).
node(n825,refuted) :- node(n819,refuted).
node(n825,unknown) :- \+ node(n825,supported), \+ node(n825,refuted).
node(n828,supported) :- status(o_d26303da72c9399c63fd,supported).
node(n828,refuted) :- status(o_d26303da72c9399c63fd,refuted).
node(n828,unknown) :- status(o_d26303da72c9399c63fd,unknown).
node(n827,supported) :- node(n821,supported), node(n822,supported), node(n828,supported), node(n823,supported).
node(n827,refuted) :- node(n821,refuted).
node(n827,refuted) :- node(n822,refuted).
node(n827,refuted) :- node(n828,refuted).
node(n827,refuted) :- node(n823,refuted).
node(n827,unknown) :- \+ node(n827,supported), \+ node(n827,refuted).
node(n824,refuted) :- node(n825,refuted), node(n827,refuted), node(n9,refuted).
node(n824,supported) :- node(n825,supported).
node(n824,supported) :- node(n827,supported).
node(n824,supported) :- node(n9,supported).
node(n824,unknown) :- \+ node(n824,supported), \+ node(n824,refuted).
verdict(c_6d78fe95a363bd56,supported) :- node(n824,supported).
query(verdict(c_6d78fe95a363bd56,supported)).
verdict(c_6d78fe95a363bd56,refuted) :- node(n824,refuted).
query(verdict(c_6d78fe95a363bd56,refuted)).
verdict(c_6d78fe95a363bd56,unknown) :- node(n824,unknown).
query(verdict(c_6d78fe95a363bd56,unknown)).
node(n831,supported) :- status(o_1b9a463f96b4838dc620,supported).
node(n831,refuted) :- status(o_1b9a463f96b4838dc620,refuted).
node(n831,unknown) :- status(o_1b9a463f96b4838dc620,unknown).
node(n832,supported) :- status(o_7e140e58dcd1ffabe966,supported).
node(n832,refuted) :- status(o_7e140e58dcd1ffabe966,refuted).
node(n832,unknown) :- status(o_7e140e58dcd1ffabe966,unknown).
node(n833,supported) :- status(o_96102c5d08ec4802912a,supported).
node(n833,refuted) :- status(o_96102c5d08ec4802912a,refuted).
node(n833,unknown) :- status(o_96102c5d08ec4802912a,unknown).
node(n830,supported) :- node(n831,supported), node(n832,supported), node(n833,supported).
node(n830,refuted) :- node(n831,refuted).
node(n830,refuted) :- node(n832,refuted).
node(n830,refuted) :- node(n833,refuted).
node(n830,unknown) :- \+ node(n830,supported), \+ node(n830,refuted).
node(n835,supported) :- status(o_e81c15ba688783c6c9c2,supported).
node(n835,refuted) :- status(o_e81c15ba688783c6c9c2,refuted).
node(n835,unknown) :- status(o_e81c15ba688783c6c9c2,unknown).
node(n836,supported) :- status(o_95082c8251807b896d1e,supported).
node(n836,refuted) :- status(o_95082c8251807b896d1e,refuted).
node(n836,unknown) :- status(o_95082c8251807b896d1e,unknown).
node(n837,supported) :- status(o_3a60c8d2435113b637e6,supported).
node(n837,refuted) :- status(o_3a60c8d2435113b637e6,refuted).
node(n837,unknown) :- status(o_3a60c8d2435113b637e6,unknown).
node(n834,supported) :- node(n835,supported), node(n836,supported), node(n837,supported).
node(n834,refuted) :- node(n835,refuted).
node(n834,refuted) :- node(n836,refuted).
node(n834,refuted) :- node(n837,refuted).
node(n834,unknown) :- \+ node(n834,supported), \+ node(n834,refuted).
node(n829,refuted) :- node(n830,refuted), node(n834,refuted), node(n9,refuted).
node(n829,supported) :- node(n830,supported).
node(n829,supported) :- node(n834,supported).
node(n829,supported) :- node(n9,supported).
node(n829,unknown) :- \+ node(n829,supported), \+ node(n829,refuted).
verdict(c_e6f359fb38183ea9,supported) :- node(n829,supported).
query(verdict(c_e6f359fb38183ea9,supported)).
verdict(c_e6f359fb38183ea9,refuted) :- node(n829,refuted).
query(verdict(c_e6f359fb38183ea9,refuted)).
verdict(c_e6f359fb38183ea9,unknown) :- node(n829,unknown).
query(verdict(c_e6f359fb38183ea9,unknown)).
node(n840,supported) :- status(o_e3e7b682d79edaf1d3aa,supported).
node(n840,refuted) :- status(o_e3e7b682d79edaf1d3aa,refuted).
node(n840,unknown) :- status(o_e3e7b682d79edaf1d3aa,unknown).
node(n839,supported) :- node(n831,supported), node(n832,supported), node(n840,supported), node(n833,supported).
node(n839,refuted) :- node(n831,refuted).
node(n839,refuted) :- node(n832,refuted).
node(n839,refuted) :- node(n840,refuted).
node(n839,refuted) :- node(n833,refuted).
node(n839,unknown) :- \+ node(n839,supported), \+ node(n839,refuted).
node(n842,supported) :- status(o_c6c52942ef307e707bec,supported).
node(n842,refuted) :- status(o_c6c52942ef307e707bec,refuted).
node(n842,unknown) :- status(o_c6c52942ef307e707bec,unknown).
node(n841,supported) :- node(n835,supported), node(n836,supported), node(n842,supported), node(n837,supported).
node(n841,refuted) :- node(n835,refuted).
node(n841,refuted) :- node(n836,refuted).
node(n841,refuted) :- node(n842,refuted).
node(n841,refuted) :- node(n837,refuted).
node(n841,unknown) :- \+ node(n841,supported), \+ node(n841,refuted).
node(n838,refuted) :- node(n839,refuted), node(n841,refuted), node(n9,refuted).
node(n838,supported) :- node(n839,supported).
node(n838,supported) :- node(n841,supported).
node(n838,supported) :- node(n9,supported).
node(n838,unknown) :- \+ node(n838,supported), \+ node(n838,refuted).
verdict(c_1ae6046847c0bfb1,supported) :- node(n838,supported).
query(verdict(c_1ae6046847c0bfb1,supported)).
verdict(c_1ae6046847c0bfb1,refuted) :- node(n838,refuted).
query(verdict(c_1ae6046847c0bfb1,refuted)).
verdict(c_1ae6046847c0bfb1,unknown) :- node(n838,unknown).
query(verdict(c_1ae6046847c0bfb1,unknown)).
node(n845,supported) :- status(o_38e2ad15775b0f2959c8,supported).
node(n845,refuted) :- status(o_38e2ad15775b0f2959c8,refuted).
node(n845,unknown) :- status(o_38e2ad15775b0f2959c8,unknown).
node(n846,supported) :- status(o_34150bb5f882b79c353c,supported).
node(n846,refuted) :- status(o_34150bb5f882b79c353c,refuted).
node(n846,unknown) :- status(o_34150bb5f882b79c353c,unknown).
node(n847,supported) :- status(o_d25f245dc586ee58e9e4,supported).
node(n847,refuted) :- status(o_d25f245dc586ee58e9e4,refuted).
node(n847,unknown) :- status(o_d25f245dc586ee58e9e4,unknown).
node(n844,supported) :- node(n845,supported), node(n846,supported), node(n847,supported).
node(n844,refuted) :- node(n845,refuted).
node(n844,refuted) :- node(n846,refuted).
node(n844,refuted) :- node(n847,refuted).
node(n844,unknown) :- \+ node(n844,supported), \+ node(n844,refuted).
node(n849,supported) :- status(o_d7af19569aeb6110cb07,supported).
node(n849,refuted) :- status(o_d7af19569aeb6110cb07,refuted).
node(n849,unknown) :- status(o_d7af19569aeb6110cb07,unknown).
node(n850,supported) :- status(o_9805547594a986be76df,supported).
node(n850,refuted) :- status(o_9805547594a986be76df,refuted).
node(n850,unknown) :- status(o_9805547594a986be76df,unknown).
node(n851,supported) :- status(o_238947f1af294ba162d8,supported).
node(n851,refuted) :- status(o_238947f1af294ba162d8,refuted).
node(n851,unknown) :- status(o_238947f1af294ba162d8,unknown).
node(n848,supported) :- node(n849,supported), node(n850,supported), node(n851,supported).
node(n848,refuted) :- node(n849,refuted).
node(n848,refuted) :- node(n850,refuted).
node(n848,refuted) :- node(n851,refuted).
node(n848,unknown) :- \+ node(n848,supported), \+ node(n848,refuted).
node(n843,refuted) :- node(n844,refuted), node(n848,refuted), node(n9,refuted).
node(n843,supported) :- node(n844,supported).
node(n843,supported) :- node(n848,supported).
node(n843,supported) :- node(n9,supported).
node(n843,unknown) :- \+ node(n843,supported), \+ node(n843,refuted).
verdict(c_e85eba56a89a1bfc,supported) :- node(n843,supported).
query(verdict(c_e85eba56a89a1bfc,supported)).
verdict(c_e85eba56a89a1bfc,refuted) :- node(n843,refuted).
query(verdict(c_e85eba56a89a1bfc,refuted)).
verdict(c_e85eba56a89a1bfc,unknown) :- node(n843,unknown).
query(verdict(c_e85eba56a89a1bfc,unknown)).
node(n854,supported) :- status(o_7932a9e3c3cff51e4d66,supported).
node(n854,refuted) :- status(o_7932a9e3c3cff51e4d66,refuted).
node(n854,unknown) :- status(o_7932a9e3c3cff51e4d66,unknown).
node(n853,supported) :- node(n845,supported), node(n846,supported), node(n854,supported), node(n847,supported).
node(n853,refuted) :- node(n845,refuted).
node(n853,refuted) :- node(n846,refuted).
node(n853,refuted) :- node(n854,refuted).
node(n853,refuted) :- node(n847,refuted).
node(n853,unknown) :- \+ node(n853,supported), \+ node(n853,refuted).
node(n856,supported) :- status(o_3381c08b4d591e2913dd,supported).
node(n856,refuted) :- status(o_3381c08b4d591e2913dd,refuted).
node(n856,unknown) :- status(o_3381c08b4d591e2913dd,unknown).
node(n855,supported) :- node(n849,supported), node(n850,supported), node(n856,supported), node(n851,supported).
node(n855,refuted) :- node(n849,refuted).
node(n855,refuted) :- node(n850,refuted).
node(n855,refuted) :- node(n856,refuted).
node(n855,refuted) :- node(n851,refuted).
node(n855,unknown) :- \+ node(n855,supported), \+ node(n855,refuted).
node(n852,refuted) :- node(n853,refuted), node(n855,refuted), node(n9,refuted).
node(n852,supported) :- node(n853,supported).
node(n852,supported) :- node(n855,supported).
node(n852,supported) :- node(n9,supported).
node(n852,unknown) :- \+ node(n852,supported), \+ node(n852,refuted).
verdict(c_c8190667c466f530,supported) :- node(n852,supported).
query(verdict(c_c8190667c466f530,supported)).
verdict(c_c8190667c466f530,refuted) :- node(n852,refuted).
query(verdict(c_c8190667c466f530,refuted)).
verdict(c_c8190667c466f530,unknown) :- node(n852,unknown).
query(verdict(c_c8190667c466f530,unknown)).
node(n859,supported) :- status(o_ecc201056cb590f6f64a,supported).
node(n859,refuted) :- status(o_ecc201056cb590f6f64a,refuted).
node(n859,unknown) :- status(o_ecc201056cb590f6f64a,unknown).
node(n860,supported) :- status(o_0cd26ca4a5bc930651ec,supported).
node(n860,refuted) :- status(o_0cd26ca4a5bc930651ec,refuted).
node(n860,unknown) :- status(o_0cd26ca4a5bc930651ec,unknown).
node(n861,supported) :- status(o_0efbd94f2fbf1b375633,supported).
node(n861,refuted) :- status(o_0efbd94f2fbf1b375633,refuted).
node(n861,unknown) :- status(o_0efbd94f2fbf1b375633,unknown).
node(n858,supported) :- node(n859,supported), node(n860,supported), node(n861,supported).
node(n858,refuted) :- node(n859,refuted).
node(n858,refuted) :- node(n860,refuted).
node(n858,refuted) :- node(n861,refuted).
node(n858,unknown) :- \+ node(n858,supported), \+ node(n858,refuted).
node(n863,supported) :- status(o_0b21c24297026375629d,supported).
node(n863,refuted) :- status(o_0b21c24297026375629d,refuted).
node(n863,unknown) :- status(o_0b21c24297026375629d,unknown).
node(n864,supported) :- status(o_220d684cb55d13711edb,supported).
node(n864,refuted) :- status(o_220d684cb55d13711edb,refuted).
node(n864,unknown) :- status(o_220d684cb55d13711edb,unknown).
node(n865,supported) :- status(o_0176f303990cb1a43f5f,supported).
node(n865,refuted) :- status(o_0176f303990cb1a43f5f,refuted).
node(n865,unknown) :- status(o_0176f303990cb1a43f5f,unknown).
node(n862,supported) :- node(n863,supported), node(n864,supported), node(n865,supported).
node(n862,refuted) :- node(n863,refuted).
node(n862,refuted) :- node(n864,refuted).
node(n862,refuted) :- node(n865,refuted).
node(n862,unknown) :- \+ node(n862,supported), \+ node(n862,refuted).
node(n857,refuted) :- node(n858,refuted), node(n862,refuted), node(n9,refuted).
node(n857,supported) :- node(n858,supported).
node(n857,supported) :- node(n862,supported).
node(n857,supported) :- node(n9,supported).
node(n857,unknown) :- \+ node(n857,supported), \+ node(n857,refuted).
verdict(c_42fc7e1b9d57a2d1,supported) :- node(n857,supported).
query(verdict(c_42fc7e1b9d57a2d1,supported)).
verdict(c_42fc7e1b9d57a2d1,refuted) :- node(n857,refuted).
query(verdict(c_42fc7e1b9d57a2d1,refuted)).
verdict(c_42fc7e1b9d57a2d1,unknown) :- node(n857,unknown).
query(verdict(c_42fc7e1b9d57a2d1,unknown)).
node(n868,supported) :- status(o_2d850f1da22f76248283,supported).
node(n868,refuted) :- status(o_2d850f1da22f76248283,refuted).
node(n868,unknown) :- status(o_2d850f1da22f76248283,unknown).
node(n867,supported) :- node(n859,supported), node(n860,supported), node(n868,supported), node(n861,supported).
node(n867,refuted) :- node(n859,refuted).
node(n867,refuted) :- node(n860,refuted).
node(n867,refuted) :- node(n868,refuted).
node(n867,refuted) :- node(n861,refuted).
node(n867,unknown) :- \+ node(n867,supported), \+ node(n867,refuted).
node(n870,supported) :- status(o_60f4d140724633210c01,supported).
node(n870,refuted) :- status(o_60f4d140724633210c01,refuted).
node(n870,unknown) :- status(o_60f4d140724633210c01,unknown).
node(n869,supported) :- node(n863,supported), node(n864,supported), node(n870,supported), node(n865,supported).
node(n869,refuted) :- node(n863,refuted).
node(n869,refuted) :- node(n864,refuted).
node(n869,refuted) :- node(n870,refuted).
node(n869,refuted) :- node(n865,refuted).
node(n869,unknown) :- \+ node(n869,supported), \+ node(n869,refuted).
node(n866,refuted) :- node(n867,refuted), node(n869,refuted), node(n9,refuted).
node(n866,supported) :- node(n867,supported).
node(n866,supported) :- node(n869,supported).
node(n866,supported) :- node(n9,supported).
node(n866,unknown) :- \+ node(n866,supported), \+ node(n866,refuted).
verdict(c_f64062f4a6e93d97,supported) :- node(n866,supported).
query(verdict(c_f64062f4a6e93d97,supported)).
verdict(c_f64062f4a6e93d97,refuted) :- node(n866,refuted).
query(verdict(c_f64062f4a6e93d97,refuted)).
verdict(c_f64062f4a6e93d97,unknown) :- node(n866,unknown).
query(verdict(c_f64062f4a6e93d97,unknown)).
node(n873,supported) :- status(o_fcd4bd69e38e07fd54f8,supported).
node(n873,refuted) :- status(o_fcd4bd69e38e07fd54f8,refuted).
node(n873,unknown) :- status(o_fcd4bd69e38e07fd54f8,unknown).
node(n874,supported) :- status(o_af663c4cce7eee55ceee,supported).
node(n874,refuted) :- status(o_af663c4cce7eee55ceee,refuted).
node(n874,unknown) :- status(o_af663c4cce7eee55ceee,unknown).
node(n875,supported) :- status(o_b26e9c91a61e4acd664f,supported).
node(n875,refuted) :- status(o_b26e9c91a61e4acd664f,refuted).
node(n875,unknown) :- status(o_b26e9c91a61e4acd664f,unknown).
node(n872,supported) :- node(n873,supported), node(n874,supported), node(n875,supported).
node(n872,refuted) :- node(n873,refuted).
node(n872,refuted) :- node(n874,refuted).
node(n872,refuted) :- node(n875,refuted).
node(n872,unknown) :- \+ node(n872,supported), \+ node(n872,refuted).
node(n877,supported) :- status(o_7158d7fcec3492c63471,supported).
node(n877,refuted) :- status(o_7158d7fcec3492c63471,refuted).
node(n877,unknown) :- status(o_7158d7fcec3492c63471,unknown).
node(n878,supported) :- status(o_8bf56445f49d06603852,supported).
node(n878,refuted) :- status(o_8bf56445f49d06603852,refuted).
node(n878,unknown) :- status(o_8bf56445f49d06603852,unknown).
node(n879,supported) :- status(o_dfcb1b94635ba602bdd7,supported).
node(n879,refuted) :- status(o_dfcb1b94635ba602bdd7,refuted).
node(n879,unknown) :- status(o_dfcb1b94635ba602bdd7,unknown).
node(n876,supported) :- node(n877,supported), node(n878,supported), node(n879,supported).
node(n876,refuted) :- node(n877,refuted).
node(n876,refuted) :- node(n878,refuted).
node(n876,refuted) :- node(n879,refuted).
node(n876,unknown) :- \+ node(n876,supported), \+ node(n876,refuted).
node(n871,refuted) :- node(n872,refuted), node(n876,refuted), node(n9,refuted).
node(n871,supported) :- node(n872,supported).
node(n871,supported) :- node(n876,supported).
node(n871,supported) :- node(n9,supported).
node(n871,unknown) :- \+ node(n871,supported), \+ node(n871,refuted).
verdict(c_6971d7eb826fa84e,supported) :- node(n871,supported).
query(verdict(c_6971d7eb826fa84e,supported)).
verdict(c_6971d7eb826fa84e,refuted) :- node(n871,refuted).
query(verdict(c_6971d7eb826fa84e,refuted)).
verdict(c_6971d7eb826fa84e,unknown) :- node(n871,unknown).
query(verdict(c_6971d7eb826fa84e,unknown)).
node(n882,supported) :- status(o_69ab1a8196e6ce11ec89,supported).
node(n882,refuted) :- status(o_69ab1a8196e6ce11ec89,refuted).
node(n882,unknown) :- status(o_69ab1a8196e6ce11ec89,unknown).
node(n881,supported) :- node(n873,supported), node(n874,supported), node(n882,supported), node(n875,supported).
node(n881,refuted) :- node(n873,refuted).
node(n881,refuted) :- node(n874,refuted).
node(n881,refuted) :- node(n882,refuted).
node(n881,refuted) :- node(n875,refuted).
node(n881,unknown) :- \+ node(n881,supported), \+ node(n881,refuted).
node(n884,supported) :- status(o_753e010ec4f8d2aa3097,supported).
node(n884,refuted) :- status(o_753e010ec4f8d2aa3097,refuted).
node(n884,unknown) :- status(o_753e010ec4f8d2aa3097,unknown).
node(n883,supported) :- node(n877,supported), node(n878,supported), node(n884,supported), node(n879,supported).
node(n883,refuted) :- node(n877,refuted).
node(n883,refuted) :- node(n878,refuted).
node(n883,refuted) :- node(n884,refuted).
node(n883,refuted) :- node(n879,refuted).
node(n883,unknown) :- \+ node(n883,supported), \+ node(n883,refuted).
node(n880,refuted) :- node(n881,refuted), node(n883,refuted), node(n9,refuted).
node(n880,supported) :- node(n881,supported).
node(n880,supported) :- node(n883,supported).
node(n880,supported) :- node(n9,supported).
node(n880,unknown) :- \+ node(n880,supported), \+ node(n880,refuted).
verdict(c_2eef0136e335d5ae,supported) :- node(n880,supported).
query(verdict(c_2eef0136e335d5ae,supported)).
verdict(c_2eef0136e335d5ae,refuted) :- node(n880,refuted).
query(verdict(c_2eef0136e335d5ae,refuted)).
verdict(c_2eef0136e335d5ae,unknown) :- node(n880,unknown).
query(verdict(c_2eef0136e335d5ae,unknown)).
node(n887,supported) :- status(o_db53cf1ff805e50cd252,supported).
node(n887,refuted) :- status(o_db53cf1ff805e50cd252,refuted).
node(n887,unknown) :- status(o_db53cf1ff805e50cd252,unknown).
node(n888,supported) :- status(o_ca254481495c5bf916e8,supported).
node(n888,refuted) :- status(o_ca254481495c5bf916e8,refuted).
node(n888,unknown) :- status(o_ca254481495c5bf916e8,unknown).
node(n889,supported) :- status(o_15dd3003b07c3406c3d9,supported).
node(n889,refuted) :- status(o_15dd3003b07c3406c3d9,refuted).
node(n889,unknown) :- status(o_15dd3003b07c3406c3d9,unknown).
node(n886,supported) :- node(n887,supported), node(n888,supported), node(n889,supported).
node(n886,refuted) :- node(n887,refuted).
node(n886,refuted) :- node(n888,refuted).
node(n886,refuted) :- node(n889,refuted).
node(n886,unknown) :- \+ node(n886,supported), \+ node(n886,refuted).
node(n891,supported) :- status(o_8fbff6ccea84adc7ed12,supported).
node(n891,refuted) :- status(o_8fbff6ccea84adc7ed12,refuted).
node(n891,unknown) :- status(o_8fbff6ccea84adc7ed12,unknown).
node(n892,supported) :- status(o_dce5ad48dbd95e41c5e8,supported).
node(n892,refuted) :- status(o_dce5ad48dbd95e41c5e8,refuted).
node(n892,unknown) :- status(o_dce5ad48dbd95e41c5e8,unknown).
node(n893,supported) :- status(o_f2aa9ec1f54dc7d43ce9,supported).
node(n893,refuted) :- status(o_f2aa9ec1f54dc7d43ce9,refuted).
node(n893,unknown) :- status(o_f2aa9ec1f54dc7d43ce9,unknown).
node(n890,supported) :- node(n891,supported), node(n892,supported), node(n893,supported).
node(n890,refuted) :- node(n891,refuted).
node(n890,refuted) :- node(n892,refuted).
node(n890,refuted) :- node(n893,refuted).
node(n890,unknown) :- \+ node(n890,supported), \+ node(n890,refuted).
node(n885,refuted) :- node(n886,refuted), node(n890,refuted), node(n9,refuted).
node(n885,supported) :- node(n886,supported).
node(n885,supported) :- node(n890,supported).
node(n885,supported) :- node(n9,supported).
node(n885,unknown) :- \+ node(n885,supported), \+ node(n885,refuted).
verdict(c_ce9997d773e909d3,supported) :- node(n885,supported).
query(verdict(c_ce9997d773e909d3,supported)).
verdict(c_ce9997d773e909d3,refuted) :- node(n885,refuted).
query(verdict(c_ce9997d773e909d3,refuted)).
verdict(c_ce9997d773e909d3,unknown) :- node(n885,unknown).
query(verdict(c_ce9997d773e909d3,unknown)).
node(n896,supported) :- status(o_9826c61f999beb568501,supported).
node(n896,refuted) :- status(o_9826c61f999beb568501,refuted).
node(n896,unknown) :- status(o_9826c61f999beb568501,unknown).
node(n895,supported) :- node(n887,supported), node(n888,supported), node(n896,supported), node(n889,supported).
node(n895,refuted) :- node(n887,refuted).
node(n895,refuted) :- node(n888,refuted).
node(n895,refuted) :- node(n896,refuted).
node(n895,refuted) :- node(n889,refuted).
node(n895,unknown) :- \+ node(n895,supported), \+ node(n895,refuted).
node(n898,supported) :- status(o_71dc35bc325aa3663e39,supported).
node(n898,refuted) :- status(o_71dc35bc325aa3663e39,refuted).
node(n898,unknown) :- status(o_71dc35bc325aa3663e39,unknown).
node(n897,supported) :- node(n891,supported), node(n892,supported), node(n898,supported), node(n893,supported).
node(n897,refuted) :- node(n891,refuted).
node(n897,refuted) :- node(n892,refuted).
node(n897,refuted) :- node(n898,refuted).
node(n897,refuted) :- node(n893,refuted).
node(n897,unknown) :- \+ node(n897,supported), \+ node(n897,refuted).
node(n894,refuted) :- node(n895,refuted), node(n897,refuted), node(n9,refuted).
node(n894,supported) :- node(n895,supported).
node(n894,supported) :- node(n897,supported).
node(n894,supported) :- node(n9,supported).
node(n894,unknown) :- \+ node(n894,supported), \+ node(n894,refuted).
verdict(c_a82551b9bab7fc91,supported) :- node(n894,supported).
query(verdict(c_a82551b9bab7fc91,supported)).
verdict(c_a82551b9bab7fc91,refuted) :- node(n894,refuted).
query(verdict(c_a82551b9bab7fc91,refuted)).
verdict(c_a82551b9bab7fc91,unknown) :- node(n894,unknown).
query(verdict(c_a82551b9bab7fc91,unknown)).
node(n901,supported) :- status(o_95009ef7d75cf3937cb7,supported).
node(n901,refuted) :- status(o_95009ef7d75cf3937cb7,refuted).
node(n901,unknown) :- status(o_95009ef7d75cf3937cb7,unknown).
node(n902,supported) :- status(o_f9fcc8d8663b60758d8a,supported).
node(n902,refuted) :- status(o_f9fcc8d8663b60758d8a,refuted).
node(n902,unknown) :- status(o_f9fcc8d8663b60758d8a,unknown).
node(n903,supported) :- status(o_9773d5107f8b856a1adb,supported).
node(n903,refuted) :- status(o_9773d5107f8b856a1adb,refuted).
node(n903,unknown) :- status(o_9773d5107f8b856a1adb,unknown).
node(n900,supported) :- node(n901,supported), node(n902,supported), node(n903,supported).
node(n900,refuted) :- node(n901,refuted).
node(n900,refuted) :- node(n902,refuted).
node(n900,refuted) :- node(n903,refuted).
node(n900,unknown) :- \+ node(n900,supported), \+ node(n900,refuted).
node(n899,refuted) :- node(n900,refuted), node(n9,refuted).
node(n899,supported) :- node(n900,supported).
node(n899,supported) :- node(n9,supported).
node(n899,unknown) :- \+ node(n899,supported), \+ node(n899,refuted).
verdict(c_d2ebacd0ddda3699,supported) :- node(n899,supported).
query(verdict(c_d2ebacd0ddda3699,supported)).
verdict(c_d2ebacd0ddda3699,refuted) :- node(n899,refuted).
query(verdict(c_d2ebacd0ddda3699,refuted)).
verdict(c_d2ebacd0ddda3699,unknown) :- node(n899,unknown).
query(verdict(c_d2ebacd0ddda3699,unknown)).
node(n906,supported) :- status(o_e0f03769bf1492c04f00,supported).
node(n906,refuted) :- status(o_e0f03769bf1492c04f00,refuted).
node(n906,unknown) :- status(o_e0f03769bf1492c04f00,unknown).
node(n905,supported) :- node(n901,supported), node(n902,supported), node(n906,supported), node(n903,supported).
node(n905,refuted) :- node(n901,refuted).
node(n905,refuted) :- node(n902,refuted).
node(n905,refuted) :- node(n906,refuted).
node(n905,refuted) :- node(n903,refuted).
node(n905,unknown) :- \+ node(n905,supported), \+ node(n905,refuted).
node(n904,refuted) :- node(n905,refuted), node(n9,refuted).
node(n904,supported) :- node(n905,supported).
node(n904,supported) :- node(n9,supported).
node(n904,unknown) :- \+ node(n904,supported), \+ node(n904,refuted).
verdict(c_ede50cc174a80b15,supported) :- node(n904,supported).
query(verdict(c_ede50cc174a80b15,supported)).
verdict(c_ede50cc174a80b15,refuted) :- node(n904,refuted).
query(verdict(c_ede50cc174a80b15,refuted)).
verdict(c_ede50cc174a80b15,unknown) :- node(n904,unknown).
query(verdict(c_ede50cc174a80b15,unknown)).
node(n909,supported) :- status(o_2bcf0f4261f6e40cc071,supported).
node(n909,refuted) :- status(o_2bcf0f4261f6e40cc071,refuted).
node(n909,unknown) :- status(o_2bcf0f4261f6e40cc071,unknown).
node(n910,supported) :- status(o_fe210805d494555d3cfd,supported).
node(n910,refuted) :- status(o_fe210805d494555d3cfd,refuted).
node(n910,unknown) :- status(o_fe210805d494555d3cfd,unknown).
node(n911,supported) :- status(o_d5084105f491e2bf2be7,supported).
node(n911,refuted) :- status(o_d5084105f491e2bf2be7,refuted).
node(n911,unknown) :- status(o_d5084105f491e2bf2be7,unknown).
node(n908,supported) :- node(n909,supported), node(n910,supported), node(n911,supported).
node(n908,refuted) :- node(n909,refuted).
node(n908,refuted) :- node(n910,refuted).
node(n908,refuted) :- node(n911,refuted).
node(n908,unknown) :- \+ node(n908,supported), \+ node(n908,refuted).
node(n907,refuted) :- node(n908,refuted), node(n9,refuted).
node(n907,supported) :- node(n908,supported).
node(n907,supported) :- node(n9,supported).
node(n907,unknown) :- \+ node(n907,supported), \+ node(n907,refuted).
verdict(c_adf1c3cfa09e8371,supported) :- node(n907,supported).
query(verdict(c_adf1c3cfa09e8371,supported)).
verdict(c_adf1c3cfa09e8371,refuted) :- node(n907,refuted).
query(verdict(c_adf1c3cfa09e8371,refuted)).
verdict(c_adf1c3cfa09e8371,unknown) :- node(n907,unknown).
query(verdict(c_adf1c3cfa09e8371,unknown)).
node(n914,supported) :- status(o_d438df36e2dd2c1df23e,supported).
node(n914,refuted) :- status(o_d438df36e2dd2c1df23e,refuted).
node(n914,unknown) :- status(o_d438df36e2dd2c1df23e,unknown).
node(n913,supported) :- node(n909,supported), node(n910,supported), node(n914,supported), node(n911,supported).
node(n913,refuted) :- node(n909,refuted).
node(n913,refuted) :- node(n910,refuted).
node(n913,refuted) :- node(n914,refuted).
node(n913,refuted) :- node(n911,refuted).
node(n913,unknown) :- \+ node(n913,supported), \+ node(n913,refuted).
node(n912,refuted) :- node(n913,refuted), node(n9,refuted).
node(n912,supported) :- node(n913,supported).
node(n912,supported) :- node(n9,supported).
node(n912,unknown) :- \+ node(n912,supported), \+ node(n912,refuted).
verdict(c_e76d47d75c0b734c,supported) :- node(n912,supported).
query(verdict(c_e76d47d75c0b734c,supported)).
verdict(c_e76d47d75c0b734c,refuted) :- node(n912,refuted).
query(verdict(c_e76d47d75c0b734c,refuted)).
verdict(c_e76d47d75c0b734c,unknown) :- node(n912,unknown).
query(verdict(c_e76d47d75c0b734c,unknown)).
node(n917,supported) :- status(o_9f3628d5487121818b7e,supported).
node(n917,refuted) :- status(o_9f3628d5487121818b7e,refuted).
node(n917,unknown) :- status(o_9f3628d5487121818b7e,unknown).
node(n918,supported) :- status(o_fa3447bb9429caee23e0,supported).
node(n918,refuted) :- status(o_fa3447bb9429caee23e0,refuted).
node(n918,unknown) :- status(o_fa3447bb9429caee23e0,unknown).
node(n919,supported) :- status(o_fbfd1ecc8996c0d6ed75,supported).
node(n919,refuted) :- status(o_fbfd1ecc8996c0d6ed75,refuted).
node(n919,unknown) :- status(o_fbfd1ecc8996c0d6ed75,unknown).
node(n916,supported) :- node(n917,supported), node(n918,supported), node(n919,supported).
node(n916,refuted) :- node(n917,refuted).
node(n916,refuted) :- node(n918,refuted).
node(n916,refuted) :- node(n919,refuted).
node(n916,unknown) :- \+ node(n916,supported), \+ node(n916,refuted).
node(n915,refuted) :- node(n916,refuted), node(n9,refuted).
node(n915,supported) :- node(n916,supported).
node(n915,supported) :- node(n9,supported).
node(n915,unknown) :- \+ node(n915,supported), \+ node(n915,refuted).
verdict(c_86ba030695677f63,supported) :- node(n915,supported).
query(verdict(c_86ba030695677f63,supported)).
verdict(c_86ba030695677f63,refuted) :- node(n915,refuted).
query(verdict(c_86ba030695677f63,refuted)).
verdict(c_86ba030695677f63,unknown) :- node(n915,unknown).
query(verdict(c_86ba030695677f63,unknown)).
node(n922,supported) :- status(o_d3599bdec4ede12fc6ea,supported).
node(n922,refuted) :- status(o_d3599bdec4ede12fc6ea,refuted).
node(n922,unknown) :- status(o_d3599bdec4ede12fc6ea,unknown).
node(n921,supported) :- node(n917,supported), node(n918,supported), node(n922,supported), node(n919,supported).
node(n921,refuted) :- node(n917,refuted).
node(n921,refuted) :- node(n918,refuted).
node(n921,refuted) :- node(n922,refuted).
node(n921,refuted) :- node(n919,refuted).
node(n921,unknown) :- \+ node(n921,supported), \+ node(n921,refuted).
node(n920,refuted) :- node(n921,refuted), node(n9,refuted).
node(n920,supported) :- node(n921,supported).
node(n920,supported) :- node(n9,supported).
node(n920,unknown) :- \+ node(n920,supported), \+ node(n920,refuted).
verdict(c_0ee9f7f411d294f3,supported) :- node(n920,supported).
query(verdict(c_0ee9f7f411d294f3,supported)).
verdict(c_0ee9f7f411d294f3,refuted) :- node(n920,refuted).
query(verdict(c_0ee9f7f411d294f3,refuted)).
verdict(c_0ee9f7f411d294f3,unknown) :- node(n920,unknown).
query(verdict(c_0ee9f7f411d294f3,unknown)).
node(n925,supported) :- status(o_6accc46dc260687c5818,supported).
node(n925,refuted) :- status(o_6accc46dc260687c5818,refuted).
node(n925,unknown) :- status(o_6accc46dc260687c5818,unknown).
node(n926,supported) :- status(o_67476fac70e4de2de21c,supported).
node(n926,refuted) :- status(o_67476fac70e4de2de21c,refuted).
node(n926,unknown) :- status(o_67476fac70e4de2de21c,unknown).
node(n927,supported) :- status(o_99bef5e590b9a7457e9d,supported).
node(n927,refuted) :- status(o_99bef5e590b9a7457e9d,refuted).
node(n927,unknown) :- status(o_99bef5e590b9a7457e9d,unknown).
node(n924,supported) :- node(n925,supported), node(n926,supported), node(n927,supported).
node(n924,refuted) :- node(n925,refuted).
node(n924,refuted) :- node(n926,refuted).
node(n924,refuted) :- node(n927,refuted).
node(n924,unknown) :- \+ node(n924,supported), \+ node(n924,refuted).
node(n923,refuted) :- node(n924,refuted), node(n9,refuted).
node(n923,supported) :- node(n924,supported).
node(n923,supported) :- node(n9,supported).
node(n923,unknown) :- \+ node(n923,supported), \+ node(n923,refuted).
verdict(c_a0e41c49a55902fa,supported) :- node(n923,supported).
query(verdict(c_a0e41c49a55902fa,supported)).
verdict(c_a0e41c49a55902fa,refuted) :- node(n923,refuted).
query(verdict(c_a0e41c49a55902fa,refuted)).
verdict(c_a0e41c49a55902fa,unknown) :- node(n923,unknown).
query(verdict(c_a0e41c49a55902fa,unknown)).
node(n930,supported) :- status(o_179d5f2131acb24ee0f8,supported).
node(n930,refuted) :- status(o_179d5f2131acb24ee0f8,refuted).
node(n930,unknown) :- status(o_179d5f2131acb24ee0f8,unknown).
node(n929,supported) :- node(n925,supported), node(n926,supported), node(n930,supported), node(n927,supported).
node(n929,refuted) :- node(n925,refuted).
node(n929,refuted) :- node(n926,refuted).
node(n929,refuted) :- node(n930,refuted).
node(n929,refuted) :- node(n927,refuted).
node(n929,unknown) :- \+ node(n929,supported), \+ node(n929,refuted).
node(n928,refuted) :- node(n929,refuted), node(n9,refuted).
node(n928,supported) :- node(n929,supported).
node(n928,supported) :- node(n9,supported).
node(n928,unknown) :- \+ node(n928,supported), \+ node(n928,refuted).
verdict(c_5eb564393ef8eb30,supported) :- node(n928,supported).
query(verdict(c_5eb564393ef8eb30,supported)).
verdict(c_5eb564393ef8eb30,refuted) :- node(n928,refuted).
query(verdict(c_5eb564393ef8eb30,refuted)).
verdict(c_5eb564393ef8eb30,unknown) :- node(n928,unknown).
query(verdict(c_5eb564393ef8eb30,unknown)).
node(n933,supported) :- status(o_6e62e3e89e4305da18d4,supported).
node(n933,refuted) :- status(o_6e62e3e89e4305da18d4,refuted).
node(n933,unknown) :- status(o_6e62e3e89e4305da18d4,unknown).
node(n934,supported) :- status(o_9d214bcfea904b0f2580,supported).
node(n934,refuted) :- status(o_9d214bcfea904b0f2580,refuted).
node(n934,unknown) :- status(o_9d214bcfea904b0f2580,unknown).
node(n935,supported) :- status(o_6532d7ec3efa3f8c6015,supported).
node(n935,refuted) :- status(o_6532d7ec3efa3f8c6015,refuted).
node(n935,unknown) :- status(o_6532d7ec3efa3f8c6015,unknown).
node(n932,supported) :- node(n933,supported), node(n934,supported), node(n935,supported).
node(n932,refuted) :- node(n933,refuted).
node(n932,refuted) :- node(n934,refuted).
node(n932,refuted) :- node(n935,refuted).
node(n932,unknown) :- \+ node(n932,supported), \+ node(n932,refuted).
node(n931,refuted) :- node(n932,refuted), node(n9,refuted).
node(n931,supported) :- node(n932,supported).
node(n931,supported) :- node(n9,supported).
node(n931,unknown) :- \+ node(n931,supported), \+ node(n931,refuted).
verdict(c_94ef7c3220ec8db7,supported) :- node(n931,supported).
query(verdict(c_94ef7c3220ec8db7,supported)).
verdict(c_94ef7c3220ec8db7,refuted) :- node(n931,refuted).
query(verdict(c_94ef7c3220ec8db7,refuted)).
verdict(c_94ef7c3220ec8db7,unknown) :- node(n931,unknown).
query(verdict(c_94ef7c3220ec8db7,unknown)).
node(n938,supported) :- status(o_d7b148d73e64c16452f0,supported).
node(n938,refuted) :- status(o_d7b148d73e64c16452f0,refuted).
node(n938,unknown) :- status(o_d7b148d73e64c16452f0,unknown).
node(n937,supported) :- node(n933,supported), node(n934,supported), node(n938,supported), node(n935,supported).
node(n937,refuted) :- node(n933,refuted).
node(n937,refuted) :- node(n934,refuted).
node(n937,refuted) :- node(n938,refuted).
node(n937,refuted) :- node(n935,refuted).
node(n937,unknown) :- \+ node(n937,supported), \+ node(n937,refuted).
node(n936,refuted) :- node(n937,refuted), node(n9,refuted).
node(n936,supported) :- node(n937,supported).
node(n936,supported) :- node(n9,supported).
node(n936,unknown) :- \+ node(n936,supported), \+ node(n936,refuted).
verdict(c_efebe980d1eb8b8e,supported) :- node(n936,supported).
query(verdict(c_efebe980d1eb8b8e,supported)).
verdict(c_efebe980d1eb8b8e,refuted) :- node(n936,refuted).
query(verdict(c_efebe980d1eb8b8e,refuted)).
verdict(c_efebe980d1eb8b8e,unknown) :- node(n936,unknown).
query(verdict(c_efebe980d1eb8b8e,unknown)).
node(n941,supported) :- status(o_e0148433680edb0ed27a,supported).
node(n941,refuted) :- status(o_e0148433680edb0ed27a,refuted).
node(n941,unknown) :- status(o_e0148433680edb0ed27a,unknown).
node(n942,supported) :- status(o_487bf05f6123fea6f67b,supported).
node(n942,refuted) :- status(o_487bf05f6123fea6f67b,refuted).
node(n942,unknown) :- status(o_487bf05f6123fea6f67b,unknown).
node(n943,supported) :- status(o_498b72a46f1580476d79,supported).
node(n943,refuted) :- status(o_498b72a46f1580476d79,refuted).
node(n943,unknown) :- status(o_498b72a46f1580476d79,unknown).
node(n940,supported) :- node(n941,supported), node(n942,supported), node(n943,supported).
node(n940,refuted) :- node(n941,refuted).
node(n940,refuted) :- node(n942,refuted).
node(n940,refuted) :- node(n943,refuted).
node(n940,unknown) :- \+ node(n940,supported), \+ node(n940,refuted).
node(n945,supported) :- status(o_a1cad329f5c1cf4ffc48,supported).
node(n945,refuted) :- status(o_a1cad329f5c1cf4ffc48,refuted).
node(n945,unknown) :- status(o_a1cad329f5c1cf4ffc48,unknown).
node(n946,supported) :- status(o_40b6701dc274d888d09c,supported).
node(n946,refuted) :- status(o_40b6701dc274d888d09c,refuted).
node(n946,unknown) :- status(o_40b6701dc274d888d09c,unknown).
node(n947,supported) :- status(o_a60f64901ce66b1dbe1e,supported).
node(n947,refuted) :- status(o_a60f64901ce66b1dbe1e,refuted).
node(n947,unknown) :- status(o_a60f64901ce66b1dbe1e,unknown).
node(n944,supported) :- node(n945,supported), node(n946,supported), node(n947,supported).
node(n944,refuted) :- node(n945,refuted).
node(n944,refuted) :- node(n946,refuted).
node(n944,refuted) :- node(n947,refuted).
node(n944,unknown) :- \+ node(n944,supported), \+ node(n944,refuted).
node(n939,refuted) :- node(n940,refuted), node(n944,refuted), node(n9,refuted).
node(n939,supported) :- node(n940,supported).
node(n939,supported) :- node(n944,supported).
node(n939,supported) :- node(n9,supported).
node(n939,unknown) :- \+ node(n939,supported), \+ node(n939,refuted).
verdict(c_4713da9e23efcec8,supported) :- node(n939,supported).
query(verdict(c_4713da9e23efcec8,supported)).
verdict(c_4713da9e23efcec8,refuted) :- node(n939,refuted).
query(verdict(c_4713da9e23efcec8,refuted)).
verdict(c_4713da9e23efcec8,unknown) :- node(n939,unknown).
query(verdict(c_4713da9e23efcec8,unknown)).
node(n950,supported) :- status(o_516021b852b3c39b4a39,supported).
node(n950,refuted) :- status(o_516021b852b3c39b4a39,refuted).
node(n950,unknown) :- status(o_516021b852b3c39b4a39,unknown).
node(n949,supported) :- node(n941,supported), node(n942,supported), node(n950,supported), node(n943,supported).
node(n949,refuted) :- node(n941,refuted).
node(n949,refuted) :- node(n942,refuted).
node(n949,refuted) :- node(n950,refuted).
node(n949,refuted) :- node(n943,refuted).
node(n949,unknown) :- \+ node(n949,supported), \+ node(n949,refuted).
node(n952,supported) :- status(o_4f838aae2dddccf14152,supported).
node(n952,refuted) :- status(o_4f838aae2dddccf14152,refuted).
node(n952,unknown) :- status(o_4f838aae2dddccf14152,unknown).
node(n951,supported) :- node(n945,supported), node(n946,supported), node(n952,supported), node(n947,supported).
node(n951,refuted) :- node(n945,refuted).
node(n951,refuted) :- node(n946,refuted).
node(n951,refuted) :- node(n952,refuted).
node(n951,refuted) :- node(n947,refuted).
node(n951,unknown) :- \+ node(n951,supported), \+ node(n951,refuted).
node(n948,refuted) :- node(n949,refuted), node(n951,refuted), node(n9,refuted).
node(n948,supported) :- node(n949,supported).
node(n948,supported) :- node(n951,supported).
node(n948,supported) :- node(n9,supported).
node(n948,unknown) :- \+ node(n948,supported), \+ node(n948,refuted).
verdict(c_694138822246f9c1,supported) :- node(n948,supported).
query(verdict(c_694138822246f9c1,supported)).
verdict(c_694138822246f9c1,refuted) :- node(n948,refuted).
query(verdict(c_694138822246f9c1,refuted)).
verdict(c_694138822246f9c1,unknown) :- node(n948,unknown).
query(verdict(c_694138822246f9c1,unknown)).
node(n955,supported) :- status(o_24a13cb94c06f178b089,supported).
node(n955,refuted) :- status(o_24a13cb94c06f178b089,refuted).
node(n955,unknown) :- status(o_24a13cb94c06f178b089,unknown).
node(n956,supported) :- status(o_c163174454ecf4f02c39,supported).
node(n956,refuted) :- status(o_c163174454ecf4f02c39,refuted).
node(n956,unknown) :- status(o_c163174454ecf4f02c39,unknown).
node(n957,supported) :- status(o_bbeaa2bcaa24e37600e3,supported).
node(n957,refuted) :- status(o_bbeaa2bcaa24e37600e3,refuted).
node(n957,unknown) :- status(o_bbeaa2bcaa24e37600e3,unknown).
node(n954,supported) :- node(n955,supported), node(n956,supported), node(n957,supported).
node(n954,refuted) :- node(n955,refuted).
node(n954,refuted) :- node(n956,refuted).
node(n954,refuted) :- node(n957,refuted).
node(n954,unknown) :- \+ node(n954,supported), \+ node(n954,refuted).
node(n959,supported) :- status(o_25e747be1c2660bb459a,supported).
node(n959,refuted) :- status(o_25e747be1c2660bb459a,refuted).
node(n959,unknown) :- status(o_25e747be1c2660bb459a,unknown).
node(n960,supported) :- status(o_dab1a2687cf1b9f4d58b,supported).
node(n960,refuted) :- status(o_dab1a2687cf1b9f4d58b,refuted).
node(n960,unknown) :- status(o_dab1a2687cf1b9f4d58b,unknown).
node(n961,supported) :- status(o_36b2a1e1e14cb348ad04,supported).
node(n961,refuted) :- status(o_36b2a1e1e14cb348ad04,refuted).
node(n961,unknown) :- status(o_36b2a1e1e14cb348ad04,unknown).
node(n958,supported) :- node(n959,supported), node(n960,supported), node(n961,supported).
node(n958,refuted) :- node(n959,refuted).
node(n958,refuted) :- node(n960,refuted).
node(n958,refuted) :- node(n961,refuted).
node(n958,unknown) :- \+ node(n958,supported), \+ node(n958,refuted).
node(n953,refuted) :- node(n954,refuted), node(n958,refuted), node(n9,refuted).
node(n953,supported) :- node(n954,supported).
node(n953,supported) :- node(n958,supported).
node(n953,supported) :- node(n9,supported).
node(n953,unknown) :- \+ node(n953,supported), \+ node(n953,refuted).
verdict(c_584580cc38eb5c71,supported) :- node(n953,supported).
query(verdict(c_584580cc38eb5c71,supported)).
verdict(c_584580cc38eb5c71,refuted) :- node(n953,refuted).
query(verdict(c_584580cc38eb5c71,refuted)).
verdict(c_584580cc38eb5c71,unknown) :- node(n953,unknown).
query(verdict(c_584580cc38eb5c71,unknown)).
node(n964,supported) :- status(o_da2dec6deb9958294f83,supported).
node(n964,refuted) :- status(o_da2dec6deb9958294f83,refuted).
node(n964,unknown) :- status(o_da2dec6deb9958294f83,unknown).
node(n963,supported) :- node(n955,supported), node(n956,supported), node(n964,supported), node(n957,supported).
node(n963,refuted) :- node(n955,refuted).
node(n963,refuted) :- node(n956,refuted).
node(n963,refuted) :- node(n964,refuted).
node(n963,refuted) :- node(n957,refuted).
node(n963,unknown) :- \+ node(n963,supported), \+ node(n963,refuted).
node(n966,supported) :- status(o_87c6f779d2bf9d67f12f,supported).
node(n966,refuted) :- status(o_87c6f779d2bf9d67f12f,refuted).
node(n966,unknown) :- status(o_87c6f779d2bf9d67f12f,unknown).
node(n965,supported) :- node(n959,supported), node(n960,supported), node(n966,supported), node(n961,supported).
node(n965,refuted) :- node(n959,refuted).
node(n965,refuted) :- node(n960,refuted).
node(n965,refuted) :- node(n966,refuted).
node(n965,refuted) :- node(n961,refuted).
node(n965,unknown) :- \+ node(n965,supported), \+ node(n965,refuted).
node(n962,refuted) :- node(n963,refuted), node(n965,refuted), node(n9,refuted).
node(n962,supported) :- node(n963,supported).
node(n962,supported) :- node(n965,supported).
node(n962,supported) :- node(n9,supported).
node(n962,unknown) :- \+ node(n962,supported), \+ node(n962,refuted).
verdict(c_81581e729bcc12f8,supported) :- node(n962,supported).
query(verdict(c_81581e729bcc12f8,supported)).
verdict(c_81581e729bcc12f8,refuted) :- node(n962,refuted).
query(verdict(c_81581e729bcc12f8,refuted)).
verdict(c_81581e729bcc12f8,unknown) :- node(n962,unknown).
query(verdict(c_81581e729bcc12f8,unknown)).
node(n969,supported) :- status(o_d27cda058d9fc24ab3e5,supported).
node(n969,refuted) :- status(o_d27cda058d9fc24ab3e5,refuted).
node(n969,unknown) :- status(o_d27cda058d9fc24ab3e5,unknown).
node(n970,supported) :- status(o_16ad8aedbec72e5f6d85,supported).
node(n970,refuted) :- status(o_16ad8aedbec72e5f6d85,refuted).
node(n970,unknown) :- status(o_16ad8aedbec72e5f6d85,unknown).
node(n971,supported) :- status(o_caf5d136e54d491f273c,supported).
node(n971,refuted) :- status(o_caf5d136e54d491f273c,refuted).
node(n971,unknown) :- status(o_caf5d136e54d491f273c,unknown).
node(n968,supported) :- node(n969,supported), node(n970,supported), node(n971,supported).
node(n968,refuted) :- node(n969,refuted).
node(n968,refuted) :- node(n970,refuted).
node(n968,refuted) :- node(n971,refuted).
node(n968,unknown) :- \+ node(n968,supported), \+ node(n968,refuted).
node(n973,supported) :- status(o_94f99dcbc4a137dbb4df,supported).
node(n973,refuted) :- status(o_94f99dcbc4a137dbb4df,refuted).
node(n973,unknown) :- status(o_94f99dcbc4a137dbb4df,unknown).
node(n974,supported) :- status(o_90b2e6464fe6a7762bc5,supported).
node(n974,refuted) :- status(o_90b2e6464fe6a7762bc5,refuted).
node(n974,unknown) :- status(o_90b2e6464fe6a7762bc5,unknown).
node(n975,supported) :- status(o_f8e5ef4099cfcfdcaccd,supported).
node(n975,refuted) :- status(o_f8e5ef4099cfcfdcaccd,refuted).
node(n975,unknown) :- status(o_f8e5ef4099cfcfdcaccd,unknown).
node(n972,supported) :- node(n973,supported), node(n974,supported), node(n975,supported).
node(n972,refuted) :- node(n973,refuted).
node(n972,refuted) :- node(n974,refuted).
node(n972,refuted) :- node(n975,refuted).
node(n972,unknown) :- \+ node(n972,supported), \+ node(n972,refuted).
node(n967,refuted) :- node(n968,refuted), node(n972,refuted), node(n9,refuted).
node(n967,supported) :- node(n968,supported).
node(n967,supported) :- node(n972,supported).
node(n967,supported) :- node(n9,supported).
node(n967,unknown) :- \+ node(n967,supported), \+ node(n967,refuted).
verdict(c_8047ca6088c9d1e3,supported) :- node(n967,supported).
query(verdict(c_8047ca6088c9d1e3,supported)).
verdict(c_8047ca6088c9d1e3,refuted) :- node(n967,refuted).
query(verdict(c_8047ca6088c9d1e3,refuted)).
verdict(c_8047ca6088c9d1e3,unknown) :- node(n967,unknown).
query(verdict(c_8047ca6088c9d1e3,unknown)).
node(n978,supported) :- status(o_467a6bf0b446f87730d3,supported).
node(n978,refuted) :- status(o_467a6bf0b446f87730d3,refuted).
node(n978,unknown) :- status(o_467a6bf0b446f87730d3,unknown).
node(n977,supported) :- node(n969,supported), node(n970,supported), node(n978,supported), node(n971,supported).
node(n977,refuted) :- node(n969,refuted).
node(n977,refuted) :- node(n970,refuted).
node(n977,refuted) :- node(n978,refuted).
node(n977,refuted) :- node(n971,refuted).
node(n977,unknown) :- \+ node(n977,supported), \+ node(n977,refuted).
node(n980,supported) :- status(o_e9d0790131dd175ce6bb,supported).
node(n980,refuted) :- status(o_e9d0790131dd175ce6bb,refuted).
node(n980,unknown) :- status(o_e9d0790131dd175ce6bb,unknown).
node(n979,supported) :- node(n973,supported), node(n974,supported), node(n980,supported), node(n975,supported).
node(n979,refuted) :- node(n973,refuted).
node(n979,refuted) :- node(n974,refuted).
node(n979,refuted) :- node(n980,refuted).
node(n979,refuted) :- node(n975,refuted).
node(n979,unknown) :- \+ node(n979,supported), \+ node(n979,refuted).
node(n976,refuted) :- node(n977,refuted), node(n979,refuted), node(n9,refuted).
node(n976,supported) :- node(n977,supported).
node(n976,supported) :- node(n979,supported).
node(n976,supported) :- node(n9,supported).
node(n976,unknown) :- \+ node(n976,supported), \+ node(n976,refuted).
verdict(c_112e8cd276cd98be,supported) :- node(n976,supported).
query(verdict(c_112e8cd276cd98be,supported)).
verdict(c_112e8cd276cd98be,refuted) :- node(n976,refuted).
query(verdict(c_112e8cd276cd98be,refuted)).
verdict(c_112e8cd276cd98be,unknown) :- node(n976,unknown).
query(verdict(c_112e8cd276cd98be,unknown)).
node(n983,supported) :- status(o_979841b6f049d5e81c68,supported).
node(n983,refuted) :- status(o_979841b6f049d5e81c68,refuted).
node(n983,unknown) :- status(o_979841b6f049d5e81c68,unknown).
node(n984,supported) :- status(o_58619889581c02348863,supported).
node(n984,refuted) :- status(o_58619889581c02348863,refuted).
node(n984,unknown) :- status(o_58619889581c02348863,unknown).
node(n985,supported) :- status(o_15c705588fdbdd88fce7,supported).
node(n985,refuted) :- status(o_15c705588fdbdd88fce7,refuted).
node(n985,unknown) :- status(o_15c705588fdbdd88fce7,unknown).
node(n982,supported) :- node(n983,supported), node(n984,supported), node(n985,supported).
node(n982,refuted) :- node(n983,refuted).
node(n982,refuted) :- node(n984,refuted).
node(n982,refuted) :- node(n985,refuted).
node(n982,unknown) :- \+ node(n982,supported), \+ node(n982,refuted).
node(n987,supported) :- status(o_2dc8ba914e1f52414287,supported).
node(n987,refuted) :- status(o_2dc8ba914e1f52414287,refuted).
node(n987,unknown) :- status(o_2dc8ba914e1f52414287,unknown).
node(n988,supported) :- status(o_f66e167540304469dcdb,supported).
node(n988,refuted) :- status(o_f66e167540304469dcdb,refuted).
node(n988,unknown) :- status(o_f66e167540304469dcdb,unknown).
node(n989,supported) :- status(o_006408ef8c0395cba831,supported).
node(n989,refuted) :- status(o_006408ef8c0395cba831,refuted).
node(n989,unknown) :- status(o_006408ef8c0395cba831,unknown).
node(n986,supported) :- node(n987,supported), node(n988,supported), node(n989,supported).
node(n986,refuted) :- node(n987,refuted).
node(n986,refuted) :- node(n988,refuted).
node(n986,refuted) :- node(n989,refuted).
node(n986,unknown) :- \+ node(n986,supported), \+ node(n986,refuted).
node(n981,refuted) :- node(n982,refuted), node(n986,refuted), node(n9,refuted).
node(n981,supported) :- node(n982,supported).
node(n981,supported) :- node(n986,supported).
node(n981,supported) :- node(n9,supported).
node(n981,unknown) :- \+ node(n981,supported), \+ node(n981,refuted).
verdict(c_c95a5b3fd54ac065,supported) :- node(n981,supported).
query(verdict(c_c95a5b3fd54ac065,supported)).
verdict(c_c95a5b3fd54ac065,refuted) :- node(n981,refuted).
query(verdict(c_c95a5b3fd54ac065,refuted)).
verdict(c_c95a5b3fd54ac065,unknown) :- node(n981,unknown).
query(verdict(c_c95a5b3fd54ac065,unknown)).
node(n992,supported) :- status(o_2766f5fcbb03d17fa84f,supported).
node(n992,refuted) :- status(o_2766f5fcbb03d17fa84f,refuted).
node(n992,unknown) :- status(o_2766f5fcbb03d17fa84f,unknown).
node(n991,supported) :- node(n983,supported), node(n984,supported), node(n992,supported), node(n985,supported).
node(n991,refuted) :- node(n983,refuted).
node(n991,refuted) :- node(n984,refuted).
node(n991,refuted) :- node(n992,refuted).
node(n991,refuted) :- node(n985,refuted).
node(n991,unknown) :- \+ node(n991,supported), \+ node(n991,refuted).
node(n994,supported) :- status(o_6e30eb83c838330d2c4b,supported).
node(n994,refuted) :- status(o_6e30eb83c838330d2c4b,refuted).
node(n994,unknown) :- status(o_6e30eb83c838330d2c4b,unknown).
node(n993,supported) :- node(n987,supported), node(n988,supported), node(n994,supported), node(n989,supported).
node(n993,refuted) :- node(n987,refuted).
node(n993,refuted) :- node(n988,refuted).
node(n993,refuted) :- node(n994,refuted).
node(n993,refuted) :- node(n989,refuted).
node(n993,unknown) :- \+ node(n993,supported), \+ node(n993,refuted).
node(n990,refuted) :- node(n991,refuted), node(n993,refuted), node(n9,refuted).
node(n990,supported) :- node(n991,supported).
node(n990,supported) :- node(n993,supported).
node(n990,supported) :- node(n9,supported).
node(n990,unknown) :- \+ node(n990,supported), \+ node(n990,refuted).
verdict(c_c16d1f9c72790245,supported) :- node(n990,supported).
query(verdict(c_c16d1f9c72790245,supported)).
verdict(c_c16d1f9c72790245,refuted) :- node(n990,refuted).
query(verdict(c_c16d1f9c72790245,refuted)).
verdict(c_c16d1f9c72790245,unknown) :- node(n990,unknown).
query(verdict(c_c16d1f9c72790245,unknown)).
node(n997,supported) :- status(o_50ead26e45ebd4c332dc,supported).
node(n997,refuted) :- status(o_50ead26e45ebd4c332dc,refuted).
node(n997,unknown) :- status(o_50ead26e45ebd4c332dc,unknown).
node(n998,supported) :- status(o_d6f980618c081bea65ce,supported).
node(n998,refuted) :- status(o_d6f980618c081bea65ce,refuted).
node(n998,unknown) :- status(o_d6f980618c081bea65ce,unknown).
node(n999,supported) :- status(o_4e3cfe1e783f7853fcf4,supported).
node(n999,refuted) :- status(o_4e3cfe1e783f7853fcf4,refuted).
node(n999,unknown) :- status(o_4e3cfe1e783f7853fcf4,unknown).
node(n996,supported) :- node(n997,supported), node(n998,supported), node(n999,supported).
node(n996,refuted) :- node(n997,refuted).
node(n996,refuted) :- node(n998,refuted).
node(n996,refuted) :- node(n999,refuted).
node(n996,unknown) :- \+ node(n996,supported), \+ node(n996,refuted).
node(n1001,supported) :- status(o_547f458e637c4c57d2fc,supported).
node(n1001,refuted) :- status(o_547f458e637c4c57d2fc,refuted).
node(n1001,unknown) :- status(o_547f458e637c4c57d2fc,unknown).
node(n1002,supported) :- status(o_9e597c41be33369f1ca2,supported).
node(n1002,refuted) :- status(o_9e597c41be33369f1ca2,refuted).
node(n1002,unknown) :- status(o_9e597c41be33369f1ca2,unknown).
node(n1003,supported) :- status(o_23e3f5736d6b690880ce,supported).
node(n1003,refuted) :- status(o_23e3f5736d6b690880ce,refuted).
node(n1003,unknown) :- status(o_23e3f5736d6b690880ce,unknown).
node(n1000,supported) :- node(n1001,supported), node(n1002,supported), node(n1003,supported).
node(n1000,refuted) :- node(n1001,refuted).
node(n1000,refuted) :- node(n1002,refuted).
node(n1000,refuted) :- node(n1003,refuted).
node(n1000,unknown) :- \+ node(n1000,supported), \+ node(n1000,refuted).
node(n995,refuted) :- node(n996,refuted), node(n1000,refuted), node(n9,refuted).
node(n995,supported) :- node(n996,supported).
node(n995,supported) :- node(n1000,supported).
node(n995,supported) :- node(n9,supported).
node(n995,unknown) :- \+ node(n995,supported), \+ node(n995,refuted).
verdict(c_94f2fd80e19bf408,supported) :- node(n995,supported).
query(verdict(c_94f2fd80e19bf408,supported)).
verdict(c_94f2fd80e19bf408,refuted) :- node(n995,refuted).
query(verdict(c_94f2fd80e19bf408,refuted)).
verdict(c_94f2fd80e19bf408,unknown) :- node(n995,unknown).
query(verdict(c_94f2fd80e19bf408,unknown)).
node(n1006,supported) :- status(o_fc2a7d9023c3179aeab6,supported).
node(n1006,refuted) :- status(o_fc2a7d9023c3179aeab6,refuted).
node(n1006,unknown) :- status(o_fc2a7d9023c3179aeab6,unknown).
node(n1005,supported) :- node(n997,supported), node(n998,supported), node(n1006,supported), node(n999,supported).
node(n1005,refuted) :- node(n997,refuted).
node(n1005,refuted) :- node(n998,refuted).
node(n1005,refuted) :- node(n1006,refuted).
node(n1005,refuted) :- node(n999,refuted).
node(n1005,unknown) :- \+ node(n1005,supported), \+ node(n1005,refuted).
node(n1008,supported) :- status(o_f8947ca704c3a19cd4a6,supported).
node(n1008,refuted) :- status(o_f8947ca704c3a19cd4a6,refuted).
node(n1008,unknown) :- status(o_f8947ca704c3a19cd4a6,unknown).
node(n1007,supported) :- node(n1001,supported), node(n1002,supported), node(n1008,supported), node(n1003,supported).
node(n1007,refuted) :- node(n1001,refuted).
node(n1007,refuted) :- node(n1002,refuted).
node(n1007,refuted) :- node(n1008,refuted).
node(n1007,refuted) :- node(n1003,refuted).
node(n1007,unknown) :- \+ node(n1007,supported), \+ node(n1007,refuted).
node(n1004,refuted) :- node(n1005,refuted), node(n1007,refuted), node(n9,refuted).
node(n1004,supported) :- node(n1005,supported).
node(n1004,supported) :- node(n1007,supported).
node(n1004,supported) :- node(n9,supported).
node(n1004,unknown) :- \+ node(n1004,supported), \+ node(n1004,refuted).
verdict(c_652c3816b95fc268,supported) :- node(n1004,supported).
query(verdict(c_652c3816b95fc268,supported)).
verdict(c_652c3816b95fc268,refuted) :- node(n1004,refuted).
query(verdict(c_652c3816b95fc268,refuted)).
verdict(c_652c3816b95fc268,unknown) :- node(n1004,unknown).
query(verdict(c_652c3816b95fc268,unknown)).
node(n1011,supported) :- status(o_ba1ad09e558610f37c26,supported).
node(n1011,refuted) :- status(o_ba1ad09e558610f37c26,refuted).
node(n1011,unknown) :- status(o_ba1ad09e558610f37c26,unknown).
node(n1012,supported) :- status(o_083cbd9d5b0dc69706a0,supported).
node(n1012,refuted) :- status(o_083cbd9d5b0dc69706a0,refuted).
node(n1012,unknown) :- status(o_083cbd9d5b0dc69706a0,unknown).
node(n1013,supported) :- status(o_84faafa5cb57bea66a95,supported).
node(n1013,refuted) :- status(o_84faafa5cb57bea66a95,refuted).
node(n1013,unknown) :- status(o_84faafa5cb57bea66a95,unknown).
node(n1010,supported) :- node(n1011,supported), node(n1012,supported), node(n1013,supported).
node(n1010,refuted) :- node(n1011,refuted).
node(n1010,refuted) :- node(n1012,refuted).
node(n1010,refuted) :- node(n1013,refuted).
node(n1010,unknown) :- \+ node(n1010,supported), \+ node(n1010,refuted).
node(n1015,supported) :- status(o_cacee04898d5fefa5d0e,supported).
node(n1015,refuted) :- status(o_cacee04898d5fefa5d0e,refuted).
node(n1015,unknown) :- status(o_cacee04898d5fefa5d0e,unknown).
node(n1016,supported) :- status(o_94899b7b31651c05575e,supported).
node(n1016,refuted) :- status(o_94899b7b31651c05575e,refuted).
node(n1016,unknown) :- status(o_94899b7b31651c05575e,unknown).
node(n1017,supported) :- status(o_e30c248f492214e2b81a,supported).
node(n1017,refuted) :- status(o_e30c248f492214e2b81a,refuted).
node(n1017,unknown) :- status(o_e30c248f492214e2b81a,unknown).
node(n1014,supported) :- node(n1015,supported), node(n1016,supported), node(n1017,supported).
node(n1014,refuted) :- node(n1015,refuted).
node(n1014,refuted) :- node(n1016,refuted).
node(n1014,refuted) :- node(n1017,refuted).
node(n1014,unknown) :- \+ node(n1014,supported), \+ node(n1014,refuted).
node(n1009,refuted) :- node(n1010,refuted), node(n1014,refuted), node(n9,refuted).
node(n1009,supported) :- node(n1010,supported).
node(n1009,supported) :- node(n1014,supported).
node(n1009,supported) :- node(n9,supported).
node(n1009,unknown) :- \+ node(n1009,supported), \+ node(n1009,refuted).
verdict(c_719d32a9eaf9e26f,supported) :- node(n1009,supported).
query(verdict(c_719d32a9eaf9e26f,supported)).
verdict(c_719d32a9eaf9e26f,refuted) :- node(n1009,refuted).
query(verdict(c_719d32a9eaf9e26f,refuted)).
verdict(c_719d32a9eaf9e26f,unknown) :- node(n1009,unknown).
query(verdict(c_719d32a9eaf9e26f,unknown)).
node(n1020,supported) :- status(o_1656c3e7ffe312946de8,supported).
node(n1020,refuted) :- status(o_1656c3e7ffe312946de8,refuted).
node(n1020,unknown) :- status(o_1656c3e7ffe312946de8,unknown).
node(n1019,supported) :- node(n1011,supported), node(n1012,supported), node(n1020,supported), node(n1013,supported).
node(n1019,refuted) :- node(n1011,refuted).
node(n1019,refuted) :- node(n1012,refuted).
node(n1019,refuted) :- node(n1020,refuted).
node(n1019,refuted) :- node(n1013,refuted).
node(n1019,unknown) :- \+ node(n1019,supported), \+ node(n1019,refuted).
node(n1022,supported) :- status(o_5ea03014ecb5e885f832,supported).
node(n1022,refuted) :- status(o_5ea03014ecb5e885f832,refuted).
node(n1022,unknown) :- status(o_5ea03014ecb5e885f832,unknown).
node(n1021,supported) :- node(n1015,supported), node(n1016,supported), node(n1022,supported), node(n1017,supported).
node(n1021,refuted) :- node(n1015,refuted).
node(n1021,refuted) :- node(n1016,refuted).
node(n1021,refuted) :- node(n1022,refuted).
node(n1021,refuted) :- node(n1017,refuted).
node(n1021,unknown) :- \+ node(n1021,supported), \+ node(n1021,refuted).
node(n1018,refuted) :- node(n1019,refuted), node(n1021,refuted), node(n9,refuted).
node(n1018,supported) :- node(n1019,supported).
node(n1018,supported) :- node(n1021,supported).
node(n1018,supported) :- node(n9,supported).
node(n1018,unknown) :- \+ node(n1018,supported), \+ node(n1018,refuted).
verdict(c_b1ce33c9cdbd5de7,supported) :- node(n1018,supported).
query(verdict(c_b1ce33c9cdbd5de7,supported)).
verdict(c_b1ce33c9cdbd5de7,refuted) :- node(n1018,refuted).
query(verdict(c_b1ce33c9cdbd5de7,refuted)).
verdict(c_b1ce33c9cdbd5de7,unknown) :- node(n1018,unknown).
query(verdict(c_b1ce33c9cdbd5de7,unknown)).
node(n1025,supported) :- status(o_cf8b8d0103995873b1e3,supported).
node(n1025,refuted) :- status(o_cf8b8d0103995873b1e3,refuted).
node(n1025,unknown) :- status(o_cf8b8d0103995873b1e3,unknown).
node(n1026,supported) :- status(o_f6181481a4896d3a6bd4,supported).
node(n1026,refuted) :- status(o_f6181481a4896d3a6bd4,refuted).
node(n1026,unknown) :- status(o_f6181481a4896d3a6bd4,unknown).
node(n1027,supported) :- status(o_3b5220bffac1abcbb055,supported).
node(n1027,refuted) :- status(o_3b5220bffac1abcbb055,refuted).
node(n1027,unknown) :- status(o_3b5220bffac1abcbb055,unknown).
node(n1024,supported) :- node(n1025,supported), node(n1026,supported), node(n1027,supported).
node(n1024,refuted) :- node(n1025,refuted).
node(n1024,refuted) :- node(n1026,refuted).
node(n1024,refuted) :- node(n1027,refuted).
node(n1024,unknown) :- \+ node(n1024,supported), \+ node(n1024,refuted).
node(n1029,supported) :- status(o_8279128e56b6913bde0e,supported).
node(n1029,refuted) :- status(o_8279128e56b6913bde0e,refuted).
node(n1029,unknown) :- status(o_8279128e56b6913bde0e,unknown).
node(n1030,supported) :- status(o_4c204b82679f5c16048c,supported).
node(n1030,refuted) :- status(o_4c204b82679f5c16048c,refuted).
node(n1030,unknown) :- status(o_4c204b82679f5c16048c,unknown).
node(n1031,supported) :- status(o_7ab054b366cbc1de9ae0,supported).
node(n1031,refuted) :- status(o_7ab054b366cbc1de9ae0,refuted).
node(n1031,unknown) :- status(o_7ab054b366cbc1de9ae0,unknown).
node(n1028,supported) :- node(n1029,supported), node(n1030,supported), node(n1031,supported).
node(n1028,refuted) :- node(n1029,refuted).
node(n1028,refuted) :- node(n1030,refuted).
node(n1028,refuted) :- node(n1031,refuted).
node(n1028,unknown) :- \+ node(n1028,supported), \+ node(n1028,refuted).
node(n1023,refuted) :- node(n1024,refuted), node(n1028,refuted), node(n9,refuted).
node(n1023,supported) :- node(n1024,supported).
node(n1023,supported) :- node(n1028,supported).
node(n1023,supported) :- node(n9,supported).
node(n1023,unknown) :- \+ node(n1023,supported), \+ node(n1023,refuted).
verdict(c_1192b9cfd7539bf1,supported) :- node(n1023,supported).
query(verdict(c_1192b9cfd7539bf1,supported)).
verdict(c_1192b9cfd7539bf1,refuted) :- node(n1023,refuted).
query(verdict(c_1192b9cfd7539bf1,refuted)).
verdict(c_1192b9cfd7539bf1,unknown) :- node(n1023,unknown).
query(verdict(c_1192b9cfd7539bf1,unknown)).
node(n1034,supported) :- status(o_7596a40616fd56b8ea9e,supported).
node(n1034,refuted) :- status(o_7596a40616fd56b8ea9e,refuted).
node(n1034,unknown) :- status(o_7596a40616fd56b8ea9e,unknown).
node(n1033,supported) :- node(n1025,supported), node(n1026,supported), node(n1034,supported), node(n1027,supported).
node(n1033,refuted) :- node(n1025,refuted).
node(n1033,refuted) :- node(n1026,refuted).
node(n1033,refuted) :- node(n1034,refuted).
node(n1033,refuted) :- node(n1027,refuted).
node(n1033,unknown) :- \+ node(n1033,supported), \+ node(n1033,refuted).
node(n1036,supported) :- status(o_5b06b30206d25196f22d,supported).
node(n1036,refuted) :- status(o_5b06b30206d25196f22d,refuted).
node(n1036,unknown) :- status(o_5b06b30206d25196f22d,unknown).
node(n1035,supported) :- node(n1029,supported), node(n1030,supported), node(n1036,supported), node(n1031,supported).
node(n1035,refuted) :- node(n1029,refuted).
node(n1035,refuted) :- node(n1030,refuted).
node(n1035,refuted) :- node(n1036,refuted).
node(n1035,refuted) :- node(n1031,refuted).
node(n1035,unknown) :- \+ node(n1035,supported), \+ node(n1035,refuted).
node(n1032,refuted) :- node(n1033,refuted), node(n1035,refuted), node(n9,refuted).
node(n1032,supported) :- node(n1033,supported).
node(n1032,supported) :- node(n1035,supported).
node(n1032,supported) :- node(n9,supported).
node(n1032,unknown) :- \+ node(n1032,supported), \+ node(n1032,refuted).
verdict(c_42af9ac069689865,supported) :- node(n1032,supported).
query(verdict(c_42af9ac069689865,supported)).
verdict(c_42af9ac069689865,refuted) :- node(n1032,refuted).
query(verdict(c_42af9ac069689865,refuted)).
verdict(c_42af9ac069689865,unknown) :- node(n1032,unknown).
query(verdict(c_42af9ac069689865,unknown)).
