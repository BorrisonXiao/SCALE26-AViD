% Exact categorical evidence; internal unknown = neither supported nor refuted.
0.51267369618544434::status(o_000730c96e06a0d8eb8f,supported); 0::status(o_000730c96e06a0d8eb8f,refuted); 0.48732630381455566::status(o_000730c96e06a0d8eb8f,unknown).
0.40058283525211141::status(o_006408ef8c0395cba831,supported); 0::status(o_006408ef8c0395cba831,refuted); 0.59941716474788853::status(o_006408ef8c0395cba831,unknown).
0.045692827552556992::status(o_00ad64f51dae10718060,supported); 0::status(o_00ad64f51dae10718060,refuted); 0.95430717244744301::status(o_00ad64f51dae10718060,unknown).
0.72335165686353298::status(o_00fb41f1e22830074c78,supported); 0::status(o_00fb41f1e22830074c78,refuted); 0.27664834313646702::status(o_00fb41f1e22830074c78,unknown).
1::status(o_013590ea4e7cd47378f9,supported); 0::status(o_013590ea4e7cd47378f9,refuted); 0::status(o_013590ea4e7cd47378f9,unknown).
0.26828955437261837::status(o_0176f303990cb1a43f5f,supported); 0::status(o_0176f303990cb1a43f5f,refuted); 0.73171044562738163::status(o_0176f303990cb1a43f5f,unknown).
1::status(o_019d3c007e49851e214c,supported); 0::status(o_019d3c007e49851e214c,refuted); 0::status(o_019d3c007e49851e214c,unknown).
0.02884664386510849::status(o_01ad4330f5406c237312,supported); 0::status(o_01ad4330f5406c237312,refuted); 0.97115335613489151::status(o_01ad4330f5406c237312,unknown).
0.99213320016860962::status(o_01b9c045b65ad2a7db10,supported); 0::status(o_01b9c045b65ad2a7db10,refuted); 0.0078667998313903809::status(o_01b9c045b65ad2a7db10,unknown).
1::status(o_01ff1e8d0f4aa7a71943,supported); 0::status(o_01ff1e8d0f4aa7a71943,refuted); 0::status(o_01ff1e8d0f4aa7a71943,unknown).
0.10388609021902084::status(o_02598e26aba3f04f7414,supported); 0::status(o_02598e26aba3f04f7414,refuted); 0.89611390978097916::status(o_02598e26aba3f04f7414,unknown).
0.99726450443267822::status(o_028ccbfd684f18456ef9,supported); 0::status(o_028ccbfd684f18456ef9,refuted); 0.0027354955673217773::status(o_028ccbfd684f18456ef9,unknown).
0::status(o_0347fab024a2d2e2f3d1,supported); 1::status(o_0347fab024a2d2e2f3d1,refuted); 0::status(o_0347fab024a2d2e2f3d1,unknown).
0.99738341569900513::status(o_041fad2098b36bf1c955,supported); 0::status(o_041fad2098b36bf1c955,refuted); 0.002616584300994873::status(o_041fad2098b36bf1c955,unknown).
0.70547658205032349::status(o_042c59d5f551c076a221,supported); 0::status(o_042c59d5f551c076a221,refuted); 0.29452341794967651::status(o_042c59d5f551c076a221,unknown).
0.58027324992316753::status(o_0469678a18c2af8fff5a,supported); 0::status(o_0469678a18c2af8fff5a,refuted); 0.41972675007683247::status(o_0469678a18c2af8fff5a,unknown).
1::status(o_04a19c86c299e7e9dd4f,supported); 0::status(o_04a19c86c299e7e9dd4f,refuted); 0::status(o_04a19c86c299e7e9dd4f,unknown).
0.67629057793032687::status(o_04be10164d619f9eaf96,supported); 0::status(o_04be10164d619f9eaf96,refuted); 0.32370942206967313::status(o_04be10164d619f9eaf96,unknown).
0.64125230196340421::status(o_050830b1b614ac139fdc,supported); 0::status(o_050830b1b614ac139fdc,refuted); 0.35874769803659579::status(o_050830b1b614ac139fdc,unknown).
0.9814574122428894::status(o_054020a30df144eed425,supported); 0::status(o_054020a30df144eed425,refuted); 0.018542587757110596::status(o_054020a30df144eed425,unknown).
1::status(o_058860153206f2e9dfcc,supported); 0::status(o_058860153206f2e9dfcc,refuted); 0::status(o_058860153206f2e9dfcc,unknown).
0.18716649970367355::status(o_05929e27873600e36733,supported); 0::status(o_05929e27873600e36733,refuted); 0.81283350029632651::status(o_05929e27873600e36733,unknown).
1::status(o_05c145946acc27ed1a62,supported); 0::status(o_05c145946acc27ed1a62,refuted); 0::status(o_05c145946acc27ed1a62,unknown).
1::status(o_05ca39bf601f27f4c89d,supported); 0::status(o_05ca39bf601f27f4c89d,refuted); 0::status(o_05ca39bf601f27f4c89d,unknown).
4.394259667606093e-05::status(o_05d6e4c2285b76e8f4ae,supported); 0::status(o_05d6e4c2285b76e8f4ae,refuted); 0.99995605740332394::status(o_05d6e4c2285b76e8f4ae,unknown).
0.00011422050738474354::status(o_067e2819627a57195566,supported); 0::status(o_067e2819627a57195566,refuted); 0.99988577949261526::status(o_067e2819627a57195566,unknown).
0.67014139818444596::status(o_06b67517fb89dbac98b8,supported); 0::status(o_06b67517fb89dbac98b8,refuted); 0.32985860181555404::status(o_06b67517fb89dbac98b8,unknown).
0.015547662042081356::status(o_06e06b4b8d8f22815c4a,supported); 0::status(o_06e06b4b8d8f22815c4a,refuted); 0.98445233795791864::status(o_06e06b4b8d8f22815c4a,unknown).
0.00022408674703910947::status(o_070ddd3fc6f996b4b5de,supported); 0::status(o_070ddd3fc6f996b4b5de,refuted); 0.99977591325296089::status(o_070ddd3fc6f996b4b5de,unknown).
0.58498724485705667::status(o_079ffb8014e36063f7f1,supported); 0::status(o_079ffb8014e36063f7f1,refuted); 0.41501275514294333::status(o_079ffb8014e36063f7f1,unknown).
0::status(o_0802b7563c92a645e247,supported); 1::status(o_0802b7563c92a645e247,refuted); 0::status(o_0802b7563c92a645e247,unknown).
1::status(o_083cbd9d5b0dc69706a0,supported); 0::status(o_083cbd9d5b0dc69706a0,refuted); 0::status(o_083cbd9d5b0dc69706a0,unknown).
1::status(o_0840e73ef5e81b84dda9,supported); 0::status(o_0840e73ef5e81b84dda9,refuted); 0::status(o_0840e73ef5e81b84dda9,unknown).
0.00045137316919863224::status(o_091ad2efd73a5142bb9c,supported); 0::status(o_091ad2efd73a5142bb9c,refuted); 0.99954862683080137::status(o_091ad2efd73a5142bb9c,unknown).
0.5115780308242156::status(o_093ff53a11755a57e8fc,supported); 0::status(o_093ff53a11755a57e8fc,refuted); 0.4884219691757844::status(o_093ff53a11755a57e8fc,unknown).
0.29771421661017777::status(o_094350b43c7453be0e63,supported); 0::status(o_094350b43c7453be0e63,refuted); 0.70228578338982217::status(o_094350b43c7453be0e63,unknown).
0.20310970056015587::status(o_09b238a23fe4af8cacd1,supported); 0::status(o_09b238a23fe4af8cacd1,refuted); 0.79689029943984413::status(o_09b238a23fe4af8cacd1,unknown).
0.98598873615264893::status(o_09d3b514598d1c4af582,supported); 0::status(o_09d3b514598d1c4af582,refuted); 0.014011263847351074::status(o_09d3b514598d1c4af582,unknown).
0::status(o_09f56b988afeba1515ca,supported); 1::status(o_09f56b988afeba1515ca,refuted); 0::status(o_09f56b988afeba1515ca,unknown).
0.002940004225820303::status(o_0a6da4afed6c4395b90e,supported); 0::status(o_0a6da4afed6c4395b90e,refuted); 0.9970599957741797::status(o_0a6da4afed6c4395b90e,unknown).
0.037853103131055832::status(o_0ab84c0c657cadb3f157,supported); 0::status(o_0ab84c0c657cadb3f157,refuted); 0.96214689686894417::status(o_0ab84c0c657cadb3f157,unknown).
0.96011406183242798::status(o_0ac2ad204bcbb831e6fc,supported); 0::status(o_0ac2ad204bcbb831e6fc,refuted); 0.039885938167572021::status(o_0ac2ad204bcbb831e6fc,unknown).
0.34819854080380347::status(o_0b0642323388b2ee12d9,supported); 0::status(o_0b0642323388b2ee12d9,refuted); 0.65180145919619648::status(o_0b0642323388b2ee12d9,unknown).
0::status(o_0b21c24297026375629d,supported); 1::status(o_0b21c24297026375629d,refuted); 0::status(o_0b21c24297026375629d,unknown).
1::status(o_0b506808665499301698,supported); 0::status(o_0b506808665499301698,refuted); 0::status(o_0b506808665499301698,unknown).
0.62521180049902358::status(o_0b56e6d4b50fb0d52828,supported); 0::status(o_0b56e6d4b50fb0d52828,refuted); 0.37478819950097642::status(o_0b56e6d4b50fb0d52828,unknown).
0.62198611454551467::status(o_0b66e0c6ab80da20bc0d,supported); 0::status(o_0b66e0c6ab80da20bc0d,refuted); 0.37801388545448533::status(o_0b66e0c6ab80da20bc0d,unknown).
0::status(o_0bb25e513cc714113aa2,supported); 1::status(o_0bb25e513cc714113aa2,refuted); 0::status(o_0bb25e513cc714113aa2,unknown).
0.017168149352073669::status(o_0bcdc91913f2c7419c4f,supported); 0::status(o_0bcdc91913f2c7419c4f,refuted); 0.98283185064792633::status(o_0bcdc91913f2c7419c4f,unknown).
0.0047103664837777615::status(o_0bf97da4374af873874f,supported); 0::status(o_0bf97da4374af873874f,refuted); 0.99528963351622224::status(o_0bf97da4374af873874f,unknown).
1::status(o_0c793e3b0f72451b42ef,supported); 0::status(o_0c793e3b0f72451b42ef,refuted); 0::status(o_0c793e3b0f72451b42ef,unknown).
0.10388609021902084::status(o_0c90bca29a4e311111cd,supported); 0::status(o_0c90bca29a4e311111cd,refuted); 0.89611390978097916::status(o_0c90bca29a4e311111cd,unknown).
0.3336655695722176::status(o_0c9965e9d630899ba817,supported); 0::status(o_0c9965e9d630899ba817,refuted); 0.6663344304277824::status(o_0c9965e9d630899ba817,unknown).
1::status(o_0cd26ca4a5bc930651ec,supported); 0::status(o_0cd26ca4a5bc930651ec,refuted); 0::status(o_0cd26ca4a5bc930651ec,unknown).
0.2362430346122546::status(o_0cdfc050b594786a72a3,supported); 0::status(o_0cdfc050b594786a72a3,refuted); 0.7637569653877454::status(o_0cdfc050b594786a72a3,unknown).
0.0007167395087890327::status(o_0d41988d33bb0f0a7147,supported); 0::status(o_0d41988d33bb0f0a7147,refuted); 0.99928326049121097::status(o_0d41988d33bb0f0a7147,unknown).
0.22666917858368055::status(o_0db1095447975839ff73,supported); 0::status(o_0db1095447975839ff73,refuted); 0.77333082141631948::status(o_0db1095447975839ff73,unknown).
1::status(o_0de6d9f1e5f55090b2c0,supported); 0::status(o_0de6d9f1e5f55090b2c0,refuted); 0::status(o_0de6d9f1e5f55090b2c0,unknown).
0.55291095055175743::status(o_0de7272c2832a9a75113,supported); 0::status(o_0de7272c2832a9a75113,refuted); 0.44708904944824257::status(o_0de7272c2832a9a75113,unknown).
0.976348876953125::status(o_0e48a0a360f3dd32a90e,supported); 0::status(o_0e48a0a360f3dd32a90e,refuted); 0.023651123046875::status(o_0e48a0a360f3dd32a90e,unknown).
0.99506819248199463::status(o_0eab514c6a8e357e7162,supported); 0::status(o_0eab514c6a8e357e7162,refuted); 0.0049318075180053711::status(o_0eab514c6a8e357e7162,unknown).
0.59064883670199464::status(o_0efbd94f2fbf1b375633,supported); 0::status(o_0efbd94f2fbf1b375633,refuted); 0.40935116329800536::status(o_0efbd94f2fbf1b375633,unknown).
0::status(o_0f9dd195f20580cedc72,supported); 1::status(o_0f9dd195f20580cedc72,refuted); 0::status(o_0f9dd195f20580cedc72,unknown).
0.2133974062939846::status(o_1057b77d00153ef3b411,supported); 0::status(o_1057b77d00153ef3b411,refuted); 0.78660259370601537::status(o_1057b77d00153ef3b411,unknown).
0::status(o_1074e465ebfb67ae40c2,supported); 1::status(o_1074e465ebfb67ae40c2,refuted); 0::status(o_1074e465ebfb67ae40c2,unknown).
1::status(o_108e8350667af0064d16,supported); 0::status(o_108e8350667af0064d16,refuted); 0::status(o_108e8350667af0064d16,unknown).
0::status(o_10915a9fda153071f95c,supported); 1::status(o_10915a9fda153071f95c,refuted); 0::status(o_10915a9fda153071f95c,unknown).
0.22909369395574933::status(o_10a8db2f2e7019906595,supported); 0::status(o_10a8db2f2e7019906595,refuted); 0.7709063060442507::status(o_10a8db2f2e7019906595,unknown).
1::status(o_10de2c256708a7718cf7,supported); 0::status(o_10de2c256708a7718cf7,refuted); 0::status(o_10de2c256708a7718cf7,unknown).
0.59984773717448137::status(o_10e8a46673ae84f365cf,supported); 0::status(o_10e8a46673ae84f365cf,refuted); 0.40015226282551863::status(o_10e8a46673ae84f365cf,unknown).
1::status(o_112c56a5876082625cab,supported); 0::status(o_112c56a5876082625cab,refuted); 0::status(o_112c56a5876082625cab,unknown).
0::status(o_116556a461efcae85586,supported); 1::status(o_116556a461efcae85586,refuted); 0::status(o_116556a461efcae85586,unknown).
0.60295927359717438::status(o_116a6aa90f422b50ac59,supported); 0::status(o_116a6aa90f422b50ac59,refuted); 0.39704072640282562::status(o_116a6aa90f422b50ac59,unknown).
0::status(o_116cf17b18dcec48ebc4,supported); 1::status(o_116cf17b18dcec48ebc4,refuted); 0::status(o_116cf17b18dcec48ebc4,unknown).
0::status(o_12040c1eda66a2928b74,supported); 1::status(o_12040c1eda66a2928b74,refuted); 0::status(o_12040c1eda66a2928b74,unknown).
0.72849249050291232::status(o_122c44f023aaa66fc623,supported); 0::status(o_122c44f023aaa66fc623,refuted); 0.27150750949708768::status(o_122c44f023aaa66fc623,unknown).
0.99007987976074219::status(o_12474bc22d945a333a5f,supported); 0::status(o_12474bc22d945a333a5f,refuted); 0.0099201202392578125::status(o_12474bc22d945a333a5f,unknown).
1::status(o_12a5d326e6f06090caa9,supported); 0::status(o_12a5d326e6f06090caa9,refuted); 0::status(o_12a5d326e6f06090caa9,unknown).
1::status(o_12cda33193bc97021ac5,supported); 0::status(o_12cda33193bc97021ac5,refuted); 0::status(o_12cda33193bc97021ac5,unknown).
1::status(o_1323d3792df5a3a36716,supported); 0::status(o_1323d3792df5a3a36716,refuted); 0::status(o_1323d3792df5a3a36716,unknown).
1::status(o_1398aa96f0a0ce1058ab,supported); 0::status(o_1398aa96f0a0ce1058ab,refuted); 0::status(o_1398aa96f0a0ce1058ab,unknown).
1::status(o_13cf9f36c7c53248fc6e,supported); 0::status(o_13cf9f36c7c53248fc6e,refuted); 0::status(o_13cf9f36c7c53248fc6e,unknown).
0.20066223274789757::status(o_14c281143258c71d61cf,supported); 0::status(o_14c281143258c71d61cf,refuted); 0.79933776725210248::status(o_14c281143258c71d61cf,unknown).
1::status(o_14fef005a694e0ee7732,supported); 0::status(o_14fef005a694e0ee7732,refuted); 0::status(o_14fef005a694e0ee7732,unknown).
0.24228181976937849::status(o_151613d849b42fc0def6,supported); 0::status(o_151613d849b42fc0def6,refuted); 0.75771818023062154::status(o_151613d849b42fc0def6,unknown).
0.60560096976815259::status(o_152f51e19cbe552645b1,supported); 0::status(o_152f51e19cbe552645b1,refuted); 0.39439903023184741::status(o_152f51e19cbe552645b1,unknown).
0.30022704115354287::status(o_15479461b6845627923e,supported); 0::status(o_15479461b6845627923e,refuted); 0.69977295884645718::status(o_15479461b6845627923e,unknown).
0.63097204530121542::status(o_15c705588fdbdd88fce7,supported); 0::status(o_15c705588fdbdd88fce7,refuted); 0.36902795469878458::status(o_15c705588fdbdd88fce7,unknown).
1::status(o_15cbdee1adc3cc0bb827,supported); 0::status(o_15cbdee1adc3cc0bb827,refuted); 0::status(o_15cbdee1adc3cc0bb827,unknown).
1::status(o_15ccaaab8c8fe1a8c83d,supported); 0::status(o_15ccaaab8c8fe1a8c83d,refuted); 0::status(o_15ccaaab8c8fe1a8c83d,unknown).
0.59064883670199464::status(o_15dd3003b07c3406c3d9,supported); 0::status(o_15dd3003b07c3406c3d9,refuted); 0.40935116329800536::status(o_15dd3003b07c3406c3d9,unknown).
1::status(o_160ff53d9bd1ce576a08,supported); 0::status(o_160ff53d9bd1ce576a08,refuted); 0::status(o_160ff53d9bd1ce576a08,unknown).
0.0023976406082510948::status(o_1624fef7be7b0edbb259,supported); 0::status(o_1624fef7be7b0edbb259,refuted); 0.99760235939174891::status(o_1624fef7be7b0edbb259,unknown).
0.99506652355194092::status(o_16329f89fa27dbece70e,supported); 0::status(o_16329f89fa27dbece70e,refuted); 0.004933476448059082::status(o_16329f89fa27dbece70e,unknown).
1::status(o_1653fabca7bd2846cb50,supported); 0::status(o_1653fabca7bd2846cb50,refuted); 0::status(o_1653fabca7bd2846cb50,unknown).
0.98706090450286865::status(o_1656c3e7ffe312946de8,supported); 0::status(o_1656c3e7ffe312946de8,refuted); 0.012939095497131348::status(o_1656c3e7ffe312946de8,unknown).
1::status(o_16ad8aedbec72e5f6d85,supported); 0::status(o_16ad8aedbec72e5f6d85,refuted); 0::status(o_16ad8aedbec72e5f6d85,unknown).
1::status(o_170d0ee7dce62ae44a31,supported); 0::status(o_170d0ee7dce62ae44a31,refuted); 0::status(o_170d0ee7dce62ae44a31,unknown).
0.00076209998223930597::status(o_17349294e25e0e5020ac,supported); 0::status(o_17349294e25e0e5020ac,refuted); 0.99923790001776069::status(o_17349294e25e0e5020ac,unknown).
0::status(o_1738467a933739f96632,supported); 1::status(o_1738467a933739f96632,refuted); 0::status(o_1738467a933739f96632,unknown).
0::status(o_179679f64f422ac72616,supported); 1::status(o_179679f64f422ac72616,refuted); 0::status(o_179679f64f422ac72616,unknown).
0.0029208550695329905::status(o_179d5f2131acb24ee0f8,supported); 0::status(o_179d5f2131acb24ee0f8,refuted); 0.99707914493046701::status(o_179d5f2131acb24ee0f8,unknown).
1::status(o_184dfd465f9165e3b445,supported); 0::status(o_184dfd465f9165e3b445,refuted); 0::status(o_184dfd465f9165e3b445,unknown).
1::status(o_1867e86911f21c8cdb17,supported); 0::status(o_1867e86911f21c8cdb17,refuted); 0::status(o_1867e86911f21c8cdb17,unknown).
1::status(o_186bead0f48e9193133f,supported); 0::status(o_186bead0f48e9193133f,refuted); 0::status(o_186bead0f48e9193133f,unknown).
0.32172180369775238::status(o_189ef189b9bcb3da2f8f,supported); 0::status(o_189ef189b9bcb3da2f8f,refuted); 0.67827819630224762::status(o_189ef189b9bcb3da2f8f,unknown).
0.00027939380379393697::status(o_1959c21204d936b7bb18,supported); 0::status(o_1959c21204d936b7bb18,refuted); 0.99972060619620606::status(o_1959c21204d936b7bb18,unknown).
0::status(o_19bfb78ed1d6c099b760,supported); 1::status(o_19bfb78ed1d6c099b760,refuted); 0::status(o_19bfb78ed1d6c099b760,unknown).
0.32443726915540849::status(o_1a10759b6ce32873e5cc,supported); 0::status(o_1a10759b6ce32873e5cc,refuted); 0.67556273084459151::status(o_1a10759b6ce32873e5cc,unknown).
0.24287842070011395::status(o_1a4320445babc1ec7672,supported); 0::status(o_1a4320445babc1ec7672,refuted); 0.75712157929988599::status(o_1a4320445babc1ec7672,unknown).
1::status(o_1a65a3aa61fceb1375c6,supported); 0::status(o_1a65a3aa61fceb1375c6,refuted); 0::status(o_1a65a3aa61fceb1375c6,unknown).
0::status(o_1a7d5a68c4ef49e9c738,supported); 1::status(o_1a7d5a68c4ef49e9c738,refuted); 0::status(o_1a7d5a68c4ef49e9c738,unknown).
0.19229594109113379::status(o_1ab9ae7073de465c322d,supported); 0::status(o_1ab9ae7073de465c322d,refuted); 0.80770405890886621::status(o_1ab9ae7073de465c322d,unknown).
0.48891161461378951::status(o_1ae7fd9f5588216a2256,supported); 0::status(o_1ae7fd9f5588216a2256,refuted); 0.51108838538621049::status(o_1ae7fd9f5588216a2256,unknown).
0::status(o_1b1423734fde71379068,supported); 1::status(o_1b1423734fde71379068,refuted); 0::status(o_1b1423734fde71379068,unknown).
0.003689546836540103::status(o_1b6e6b08c568ed054f01,supported); 0::status(o_1b6e6b08c568ed054f01,refuted); 0.9963104531634599::status(o_1b6e6b08c568ed054f01,unknown).
0::status(o_1b90e36801a3fa33f344,supported); 1::status(o_1b90e36801a3fa33f344,refuted); 0::status(o_1b90e36801a3fa33f344,unknown).
1::status(o_1b9a463f96b4838dc620,supported); 0::status(o_1b9a463f96b4838dc620,refuted); 0::status(o_1b9a463f96b4838dc620,unknown).
0.091254428029060364::status(o_1beb39eed0efe9fbf9ed,supported); 0::status(o_1beb39eed0efe9fbf9ed,refuted); 0.90874557197093964::status(o_1beb39eed0efe9fbf9ed,unknown).
0::status(o_1bedfa209fa9024a96b9,supported); 1::status(o_1bedfa209fa9024a96b9,refuted); 0::status(o_1bedfa209fa9024a96b9,unknown).
9.0030916908290237e-05::status(o_1c102ea19fa41cc6f7b5,supported); 0::status(o_1c102ea19fa41cc6f7b5,refuted); 0.99990996908309171::status(o_1c102ea19fa41cc6f7b5,unknown).
1::status(o_1c3761a1c0db66722da2,supported); 0::status(o_1c3761a1c0db66722da2,refuted); 0::status(o_1c3761a1c0db66722da2,unknown).
1::status(o_1c48799d98d6ddb371fc,supported); 0::status(o_1c48799d98d6ddb371fc,refuted); 0::status(o_1c48799d98d6ddb371fc,unknown).
1::status(o_1c4d720ea7ef876005ef,supported); 0::status(o_1c4d720ea7ef876005ef,refuted); 0::status(o_1c4d720ea7ef876005ef,unknown).
1::status(o_1c8b6397265f9bbacd19,supported); 0::status(o_1c8b6397265f9bbacd19,refuted); 0::status(o_1c8b6397265f9bbacd19,unknown).
1::status(o_1cdfcf4bd6b2a11ae04d,supported); 0::status(o_1cdfcf4bd6b2a11ae04d,refuted); 0::status(o_1cdfcf4bd6b2a11ae04d,unknown).
0::status(o_1cfdeb7ca9527102074f,supported); 1::status(o_1cfdeb7ca9527102074f,refuted); 0::status(o_1cfdeb7ca9527102074f,unknown).
7.9832112533040345e-05::status(o_1dae4fe2cf3e39a0b459,supported); 0::status(o_1dae4fe2cf3e39a0b459,refuted); 0.99992016788746696::status(o_1dae4fe2cf3e39a0b459,unknown).
0.3267414933664608::status(o_1df1b32830663bda55a1,supported); 0::status(o_1df1b32830663bda55a1,refuted); 0.67325850663353926::status(o_1df1b32830663bda55a1,unknown).
0.021092737093567848::status(o_1e2f8ae673d92cb792c1,supported); 0::status(o_1e2f8ae673d92cb792c1,refuted); 0.97890726290643215::status(o_1e2f8ae673d92cb792c1,unknown).
0.98928332328796387::status(o_1e30d3abfd6bc3fa23db,supported); 0::status(o_1e30d3abfd6bc3fa23db,refuted); 0.010716676712036133::status(o_1e30d3abfd6bc3fa23db,unknown).
1::status(o_1e32ab84608d835cf928,supported); 0::status(o_1e32ab84608d835cf928,refuted); 0::status(o_1e32ab84608d835cf928,unknown).
0.00039488702896051109::status(o_1e3a95c264ceff711b50,supported); 0::status(o_1e3a95c264ceff711b50,refuted); 0.99960511297103949::status(o_1e3a95c264ceff711b50,unknown).
1::status(o_1e3b57b0e0098ff42258,supported); 0::status(o_1e3b57b0e0098ff42258,refuted); 0::status(o_1e3b57b0e0098ff42258,unknown).
1::status(o_1e68d38c9134d9179c77,supported); 0::status(o_1e68d38c9134d9179c77,refuted); 0::status(o_1e68d38c9134d9179c77,unknown).
0::status(o_1ecfd9745f37dbec787c,supported); 1::status(o_1ecfd9745f37dbec787c,refuted); 0::status(o_1ecfd9745f37dbec787c,unknown).
0.69422269685182314::status(o_1ee7c863e0b340d611f7,supported); 0::status(o_1ee7c863e0b340d611f7,refuted); 0.30577730314817686::status(o_1ee7c863e0b340d611f7,unknown).
0.0060226605273783207::status(o_1f150e921c59c5abe116,supported); 0::status(o_1f150e921c59c5abe116,refuted); 0.99397733947262168::status(o_1f150e921c59c5abe116,unknown).
0::status(o_1fe0b77a2ad953872a1d,supported); 1::status(o_1fe0b77a2ad953872a1d,refuted); 0::status(o_1fe0b77a2ad953872a1d,unknown).
1::status(o_203f97a458cb512201d8,supported); 0::status(o_203f97a458cb512201d8,refuted); 0::status(o_203f97a458cb512201d8,unknown).
1::status(o_204a348fd9d52a41ce05,supported); 0::status(o_204a348fd9d52a41ce05,refuted); 0::status(o_204a348fd9d52a41ce05,unknown).
1::status(o_206c7645fd2a570c31b3,supported); 0::status(o_206c7645fd2a570c31b3,refuted); 0::status(o_206c7645fd2a570c31b3,unknown).
0.0001668355253059417::status(o_20a6b10f82f1bdb4116c,supported); 0::status(o_20a6b10f82f1bdb4116c,refuted); 0.99983316447469406::status(o_20a6b10f82f1bdb4116c,unknown).
0.99185353517532349::status(o_2110913504ae3a6d717f,supported); 0::status(o_2110913504ae3a6d717f,refuted); 0.0081464648246765137::status(o_2110913504ae3a6d717f,unknown).
1::status(o_211a230140a143765b19,supported); 0::status(o_211a230140a143765b19,refuted); 0::status(o_211a230140a143765b19,unknown).
0.0093486057594418526::status(o_213800c7847d4f4dc72b,supported); 0::status(o_213800c7847d4f4dc72b,refuted); 0.99065139424055815::status(o_213800c7847d4f4dc72b,unknown).
0.40951737828231399::status(o_2156c33407e33c2da08d,supported); 0::status(o_2156c33407e33c2da08d,refuted); 0.59048262171768595::status(o_2156c33407e33c2da08d,unknown).
1::status(o_217eee88d6f48a693fa1,supported); 0::status(o_217eee88d6f48a693fa1,refuted); 0::status(o_217eee88d6f48a693fa1,unknown).
0.00026651250664144754::status(o_21cbac8973411012256d,supported); 0::status(o_21cbac8973411012256d,refuted); 0.99973348749335855::status(o_21cbac8973411012256d,unknown).
1::status(o_220d684cb55d13711edb,supported); 0::status(o_220d684cb55d13711edb,refuted); 0::status(o_220d684cb55d13711edb,unknown).
0.99547606706619263::status(o_228911afb332cccb7a06,supported); 0::status(o_228911afb332cccb7a06,refuted); 0.004523932933807373::status(o_228911afb332cccb7a06,unknown).
0.067158885300159454::status(o_2292f7ff9597d888312e,supported); 0::status(o_2292f7ff9597d888312e,refuted); 0.93284111469984055::status(o_2292f7ff9597d888312e,unknown).
1::status(o_22da77ef3f35ab45bf31,supported); 0::status(o_22da77ef3f35ab45bf31,refuted); 0::status(o_22da77ef3f35ab45bf31,unknown).
0.50334479052197967::status(o_22e9ead9db7eeb1571be,supported); 0::status(o_22e9ead9db7eeb1571be,refuted); 0.49665520947802033::status(o_22e9ead9db7eeb1571be,unknown).
1::status(o_2348673ae2c21fd301fa,supported); 0::status(o_2348673ae2c21fd301fa,refuted); 0::status(o_2348673ae2c21fd301fa,unknown).
1::status(o_2378d7029e40f95e4cd4,supported); 0::status(o_2378d7029e40f95e4cd4,refuted); 0::status(o_2378d7029e40f95e4cd4,unknown).
0.17744335653387286::status(o_238947f1af294ba162d8,supported); 0::status(o_238947f1af294ba162d8,refuted); 0.82255664346612711::status(o_238947f1af294ba162d8,unknown).
0.039551112800836563::status(o_23c3b989771dd7b30fb1,supported); 0::status(o_23c3b989771dd7b30fb1,refuted); 0.96044888719916344::status(o_23c3b989771dd7b30fb1,unknown).
1::status(o_23d0cd703da387a2c543,supported); 0::status(o_23d0cd703da387a2c543,refuted); 0::status(o_23d0cd703da387a2c543,unknown).
1::status(o_23d9abf97c7312e11c48,supported); 0::status(o_23d9abf97c7312e11c48,refuted); 0::status(o_23d9abf97c7312e11c48,unknown).
0.25839648013427508::status(o_23e3f5736d6b690880ce,supported); 0::status(o_23e3f5736d6b690880ce,refuted); 0.74160351986572492::status(o_23e3f5736d6b690880ce,unknown).
0.2791481798599636::status(o_2490396a075eca9e2a74,supported); 0::status(o_2490396a075eca9e2a74,refuted); 0.72085182014003646::status(o_2490396a075eca9e2a74,unknown).
0.002602787222713232::status(o_249ea1bc115028c1e037,supported); 0::status(o_249ea1bc115028c1e037,refuted); 0.99739721277728677::status(o_249ea1bc115028c1e037,unknown).
1::status(o_24a13cb94c06f178b089,supported); 0::status(o_24a13cb94c06f178b089,refuted); 0::status(o_24a13cb94c06f178b089,unknown).
0.37767917560506059::status(o_24b6ee12cd71ce15dac9,supported); 0::status(o_24b6ee12cd71ce15dac9,refuted); 0.62232082439493941::status(o_24b6ee12cd71ce15dac9,unknown).
1::status(o_24cc5560bbaac5f07481,supported); 0::status(o_24cc5560bbaac5f07481,refuted); 0::status(o_24cc5560bbaac5f07481,unknown).
0.31882658014979082::status(o_250acaa8aff4b6e1a7e1,supported); 0::status(o_250acaa8aff4b6e1a7e1,refuted); 0.68117341985020918::status(o_250acaa8aff4b6e1a7e1,unknown).
0::status(o_25e747be1c2660bb459a,supported); 1::status(o_25e747be1c2660bb459a,refuted); 0::status(o_25e747be1c2660bb459a,unknown).
0::status(o_2601b953080415fcfe17,supported); 1::status(o_2601b953080415fcfe17,refuted); 0::status(o_2601b953080415fcfe17,unknown).
1::status(o_267b5b0b56834cb3c2f5,supported); 0::status(o_267b5b0b56834cb3c2f5,refuted); 0::status(o_267b5b0b56834cb3c2f5,unknown).
0.61694091558456421::status(o_270ed160e9bd874b468b,supported); 0::status(o_270ed160e9bd874b468b,refuted); 0.38305908441543579::status(o_270ed160e9bd874b468b,unknown).
0.11307581451868662::status(o_2725fc701c8fff4a9539,supported); 0::status(o_2725fc701c8fff4a9539,refuted); 0.88692418548131335::status(o_2725fc701c8fff4a9539,unknown).
0.13451996445655823::status(o_2766f5fcbb03d17fa84f,supported); 0::status(o_2766f5fcbb03d17fa84f,refuted); 0.86548003554344177::status(o_2766f5fcbb03d17fa84f,unknown).
1::status(o_276b7db7f222c96a70ac,supported); 0::status(o_276b7db7f222c96a70ac,refuted); 0::status(o_276b7db7f222c96a70ac,unknown).
0.00066984596196562052::status(o_278fdadbcbf76b23bee6,supported); 0::status(o_278fdadbcbf76b23bee6,refuted); 0.99933015403803438::status(o_278fdadbcbf76b23bee6,unknown).
0.00043609272688627243::status(o_27a8f0181a1a862419d4,supported); 0::status(o_27a8f0181a1a862419d4,refuted); 0.99956390727311373::status(o_27a8f0181a1a862419d4,unknown).
0.99810886383056641::status(o_27ba79585d8586cc1136,supported); 0::status(o_27ba79585d8586cc1136,refuted); 0.0018911361694335938::status(o_27ba79585d8586cc1136,unknown).
0::status(o_28363b70e799e5f58c6c,supported); 1::status(o_28363b70e799e5f58c6c,refuted); 0::status(o_28363b70e799e5f58c6c,unknown).
0.37767917560506059::status(o_285f931438bbb688b6dd,supported); 0::status(o_285f931438bbb688b6dd,refuted); 0.62232082439493941::status(o_285f931438bbb688b6dd,unknown).
0.00028077524621039629::status(o_289ed5d7dede9e57bf46,supported); 0::status(o_289ed5d7dede9e57bf46,refuted); 0.9997192247537896::status(o_289ed5d7dede9e57bf46,unknown).
0.00044824578799307346::status(o_2922fca11dca06c5894e,supported); 0::status(o_2922fca11dca06c5894e,refuted); 0.99955175421200693::status(o_2922fca11dca06c5894e,unknown).
0.24720217475481024::status(o_292b1b88c95cdf4698b3,supported); 0::status(o_292b1b88c95cdf4698b3,refuted); 0.75279782524518979::status(o_292b1b88c95cdf4698b3,unknown).
0.78545029701849134::status(o_297e59f156505592a4b0,supported); 0::status(o_297e59f156505592a4b0,refuted); 0.21454970298150866::status(o_297e59f156505592a4b0,unknown).
0.4066462516784668::status(o_29d60681a30a1a2eef60,supported); 0::status(o_29d60681a30a1a2eef60,refuted); 0.5933537483215332::status(o_29d60681a30a1a2eef60,unknown).
0.55291095055175743::status(o_29dc598ecfd4000498ba,supported); 0::status(o_29dc598ecfd4000498ba,refuted); 0.44708904944824257::status(o_29dc598ecfd4000498ba,unknown).
1::status(o_2a34f8118e578ebd1bca,supported); 0::status(o_2a34f8118e578ebd1bca,refuted); 0::status(o_2a34f8118e578ebd1bca,unknown).
1::status(o_2a4b68297b2649f9b517,supported); 0::status(o_2a4b68297b2649f9b517,refuted); 0::status(o_2a4b68297b2649f9b517,unknown).
0::status(o_2a8d799d7c3ff2741d63,supported); 1::status(o_2a8d799d7c3ff2741d63,refuted); 0::status(o_2a8d799d7c3ff2741d63,unknown).
1::status(o_2adf63f27b64168a71c8,supported); 0::status(o_2adf63f27b64168a71c8,refuted); 0::status(o_2adf63f27b64168a71c8,unknown).
0::status(o_2b1db21bbc723dc42d7c,supported); 1::status(o_2b1db21bbc723dc42d7c,refuted); 0::status(o_2b1db21bbc723dc42d7c,unknown).
0.24297107134799403::status(o_2b9644fae39bbf492314,supported); 0::status(o_2b9644fae39bbf492314,refuted); 0.75702892865200599::status(o_2b9644fae39bbf492314,unknown).
1::status(o_2bcf0f4261f6e40cc071,supported); 0::status(o_2bcf0f4261f6e40cc071,refuted); 0::status(o_2bcf0f4261f6e40cc071,unknown).
0.45078909333920353::status(o_2c392a06444f4cd5bd26,supported); 0::status(o_2c392a06444f4cd5bd26,refuted); 0.54921090666079642::status(o_2c392a06444f4cd5bd26,unknown).
0.002940004225820303::status(o_2c82bbe1bcef131ec096,supported); 0::status(o_2c82bbe1bcef131ec096,refuted); 0.9970599957741797::status(o_2c82bbe1bcef131ec096,unknown).
0.19632613136466429::status(o_2c84bf08d2b036d66898,supported); 0::status(o_2c84bf08d2b036d66898,refuted); 0.80367386863533574::status(o_2c84bf08d2b036d66898,unknown).
0::status(o_2d33407197aa16c0cc54,supported); 1::status(o_2d33407197aa16c0cc54,refuted); 0::status(o_2d33407197aa16c0cc54,unknown).
0.99547606706619263::status(o_2d850f1da22f76248283,supported); 0::status(o_2d850f1da22f76248283,refuted); 0.004523932933807373::status(o_2d850f1da22f76248283,unknown).
0.02225978524058617::status(o_2d8988a2d77d10ef5109,supported); 0::status(o_2d8988a2d77d10ef5109,refuted); 0.97774021475941386::status(o_2d8988a2d77d10ef5109,unknown).
1::status(o_2d96fc15d0de6148efc9,supported); 0::status(o_2d96fc15d0de6148efc9,refuted); 0::status(o_2d96fc15d0de6148efc9,unknown).
0.097550913653572963::status(o_2db814643b3ef700e36d,supported); 0::status(o_2db814643b3ef700e36d,refuted); 0.90244908634642707::status(o_2db814643b3ef700e36d,unknown).
0::status(o_2dc8ba914e1f52414287,supported); 1::status(o_2dc8ba914e1f52414287,refuted); 0::status(o_2dc8ba914e1f52414287,unknown).
0.99726450443267822::status(o_2dd8d437c786e7f1c4f1,supported); 0::status(o_2dd8d437c786e7f1c4f1,refuted); 0.0027354955673217773::status(o_2dd8d437c786e7f1c4f1,unknown).
0::status(o_2dea827bf24c4381a852,supported); 1::status(o_2dea827bf24c4381a852,refuted); 0::status(o_2dea827bf24c4381a852,unknown).
1::status(o_2e71ea0f927b7104f7f8,supported); 0::status(o_2e71ea0f927b7104f7f8,refuted); 0::status(o_2e71ea0f927b7104f7f8,unknown).
0.47045918946799326::status(o_2e976143865b741ab025,supported); 0::status(o_2e976143865b741ab025,refuted); 0.52954081053200674::status(o_2e976143865b741ab025,unknown).
1::status(o_2e98414894506cac07f0,supported); 0::status(o_2e98414894506cac07f0,refuted); 0::status(o_2e98414894506cac07f0,unknown).
0.22783341461938156::status(o_2f8672e418d2c4cb048a,supported); 0::status(o_2f8672e418d2c4cb048a,refuted); 0.77216658538061844::status(o_2f8672e418d2c4cb048a,unknown).
1::status(o_2f96c65a44127f6522c5,supported); 0::status(o_2f96c65a44127f6522c5,refuted); 0::status(o_2f96c65a44127f6522c5,unknown).
0.58637967737669439::status(o_30194b0d0f14faf8ca42,supported); 0::status(o_30194b0d0f14faf8ca42,refuted); 0.41362032262330561::status(o_30194b0d0f14faf8ca42,unknown).
0.9814574122428894::status(o_3096b55322047d08483c,supported); 0::status(o_3096b55322047d08483c,refuted); 0.018542587757110596::status(o_3096b55322047d08483c,unknown).
0.00096308212960138917::status(o_309baf1c9fe60620599b,supported); 0::status(o_309baf1c9fe60620599b,refuted); 0.99903691787039861::status(o_309baf1c9fe60620599b,unknown).
0.0018071738304570317::status(o_30b058adc25f756c087b,supported); 0::status(o_30b058adc25f756c087b,refuted); 0.99819282616954297::status(o_30b058adc25f756c087b,unknown).
1.2276381312403828e-05::status(o_310aab1a432ee8220650,supported); 0::status(o_310aab1a432ee8220650,refuted); 0.9999877236186876::status(o_310aab1a432ee8220650,unknown).
1::status(o_3123999d9cf307bca68b,supported); 0::status(o_3123999d9cf307bca68b,refuted); 0::status(o_3123999d9cf307bca68b,unknown).
0.00011525061563588679::status(o_318192354e832d2c844f,supported); 0::status(o_318192354e832d2c844f,refuted); 0.99988474938436411::status(o_318192354e832d2c844f,unknown).
0.002602787222713232::status(o_32c2a8233d221534c0bd,supported); 0::status(o_32c2a8233d221534c0bd,refuted); 0.99739721277728677::status(o_32c2a8233d221534c0bd,unknown).
0.00058511312818154693::status(o_3381c08b4d591e2913dd,supported); 0::status(o_3381c08b4d591e2913dd,refuted); 0.99941488687181845::status(o_3381c08b4d591e2913dd,unknown).
1::status(o_34150bb5f882b79c353c,supported); 0::status(o_34150bb5f882b79c353c,refuted); 0::status(o_34150bb5f882b79c353c,unknown).
0.6398029348717047::status(o_34ab18ffb1400ec03c65,supported); 0::status(o_34ab18ffb1400ec03c65,refuted); 0.3601970651282953::status(o_34ab18ffb1400ec03c65,unknown).
0.0013882720377296209::status(o_352102850a6208f28228,supported); 0::status(o_352102850a6208f28228,refuted); 0.99861172796227038::status(o_352102850a6208f28228,unknown).
0.0004814279091078788::status(o_3545bc8aec28e257d5b7,supported); 0::status(o_3545bc8aec28e257d5b7,refuted); 0.99951857209089212::status(o_3545bc8aec28e257d5b7,unknown).
0.31907950101890964::status(o_359ff78e6704a5fbcafa,supported); 0::status(o_359ff78e6704a5fbcafa,refuted); 0.68092049898109042::status(o_359ff78e6704a5fbcafa,unknown).
1::status(o_35af888d6b2099f8d460,supported); 0::status(o_35af888d6b2099f8d460,refuted); 0::status(o_35af888d6b2099f8d460,unknown).
0.1501396967008444::status(o_36b2a1e1e14cb348ad04,supported); 0::status(o_36b2a1e1e14cb348ad04,refuted); 0.84986030329915563::status(o_36b2a1e1e14cb348ad04,unknown).
1::status(o_36b2dbd9f2bc80d0d708,supported); 0::status(o_36b2dbd9f2bc80d0d708,refuted); 0::status(o_36b2dbd9f2bc80d0d708,unknown).
0.021092737093567848::status(o_36e53627d4fe36d9d282,supported); 0::status(o_36e53627d4fe36d9d282,refuted); 0.97890726290643215::status(o_36e53627d4fe36d9d282,unknown).
0.0070033296942710876::status(o_3703f0e48dbff253ad64,supported); 0::status(o_3703f0e48dbff253ad64,refuted); 0.99299667030572891::status(o_3703f0e48dbff253ad64,unknown).
1::status(o_373177f9ba14320bdde9,supported); 0::status(o_373177f9ba14320bdde9,refuted); 0::status(o_373177f9ba14320bdde9,unknown).
0.00038813083665445447::status(o_3775f24b6ce7b53f7674,supported); 0::status(o_3775f24b6ce7b53f7674,refuted); 0.99961186916334555::status(o_3775f24b6ce7b53f7674,unknown).
0.64354465567556274::status(o_37d7ad41426bf255b761,supported); 0::status(o_37d7ad41426bf255b761,refuted); 0.35645534432443726::status(o_37d7ad41426bf255b761,unknown).
1::status(o_380c40bfe3409b206be3,supported); 0::status(o_380c40bfe3409b206be3,refuted); 0::status(o_380c40bfe3409b206be3,unknown).
0.28838067438115472::status(o_380cd7bea85edcfdbe35,supported); 0::status(o_380cd7bea85edcfdbe35,refuted); 0.71161932561884522::status(o_380cd7bea85edcfdbe35,unknown).
1::status(o_38815adad6c30f9b86b3,supported); 0::status(o_38815adad6c30f9b86b3,refuted); 0::status(o_38815adad6c30f9b86b3,unknown).
0.988739013671875::status(o_38aaedabf761c64ff28c,supported); 0::status(o_38aaedabf761c64ff28c,refuted); 0.011260986328125::status(o_38aaedabf761c64ff28c,unknown).
1::status(o_38e2ad15775b0f2959c8,supported); 0::status(o_38e2ad15775b0f2959c8,refuted); 0::status(o_38e2ad15775b0f2959c8,unknown).
1::status(o_38f770423f4fadb0e38b,supported); 0::status(o_38f770423f4fadb0e38b,refuted); 0::status(o_38f770423f4fadb0e38b,unknown).
0.015679161995649338::status(o_39005afb97f8a829d7d1,supported); 0::status(o_39005afb97f8a829d7d1,refuted); 0.98432083800435066::status(o_39005afb97f8a829d7d1,unknown).
0.61771134898671276::status(o_391054f01387a78474e4,supported); 0::status(o_391054f01387a78474e4,refuted); 0.38228865101328724::status(o_391054f01387a78474e4,unknown).
1::status(o_393a2f8651fb79da30b6,supported); 0::status(o_393a2f8651fb79da30b6,refuted); 0::status(o_393a2f8651fb79da30b6,unknown).
0.23105795662110934::status(o_3955123710d5107f611e,supported); 0::status(o_3955123710d5107f611e,refuted); 0.76894204337889072::status(o_3955123710d5107f611e,unknown).
0.003689546836540103::status(o_396fa5905bb77d9558a3,supported); 0::status(o_396fa5905bb77d9558a3,refuted); 0.9963104531634599::status(o_396fa5905bb77d9558a3,unknown).
1::status(o_399c116ba02245698e98,supported); 0::status(o_399c116ba02245698e98,refuted); 0::status(o_399c116ba02245698e98,unknown).
1::status(o_399e75495498d0ab2deb,supported); 0::status(o_399e75495498d0ab2deb,refuted); 0::status(o_399e75495498d0ab2deb,unknown).
0.41550036072050733::status(o_39a8c8ef1979ccaeef61,supported); 0::status(o_39a8c8ef1979ccaeef61,refuted); 0.58449963927949267::status(o_39a8c8ef1979ccaeef61,unknown).
1::status(o_39f3c00c33d2d06295a3,supported); 0::status(o_39f3c00c33d2d06295a3,refuted); 0::status(o_39f3c00c33d2d06295a3,unknown).
1::status(o_3a21de68f73d3b421a84,supported); 0::status(o_3a21de68f73d3b421a84,refuted); 0::status(o_3a21de68f73d3b421a84,unknown).
0.00063080125255510211::status(o_3a466d2fc15cf77dbf8b,supported); 0::status(o_3a466d2fc15cf77dbf8b,refuted); 0.9993691987474449::status(o_3a466d2fc15cf77dbf8b,unknown).
0.42721959904405776::status(o_3a60c8d2435113b637e6,supported); 0::status(o_3a60c8d2435113b637e6,refuted); 0.57278040095594229::status(o_3a60c8d2435113b637e6,unknown).
1::status(o_3a95662b5a7b3831334b,supported); 0::status(o_3a95662b5a7b3831334b,refuted); 0::status(o_3a95662b5a7b3831334b,unknown).
0.2766593005094688::status(o_3b0d9e9515285e6ea157,supported); 0::status(o_3b0d9e9515285e6ea157,refuted); 0.72334069949053115::status(o_3b0d9e9515285e6ea157,unknown).
0.096061237156391144::status(o_3b275837263ec2f1f5c2,supported); 0::status(o_3b275837263ec2f1f5c2,refuted); 0.90393876284360886::status(o_3b275837263ec2f1f5c2,unknown).
0.56019621807698294::status(o_3b5220bffac1abcbb055,supported); 0::status(o_3b5220bffac1abcbb055,refuted); 0.43980378192301706::status(o_3b5220bffac1abcbb055,unknown).
0::status(o_3b76e7cf5d023a1f892d,supported); 1::status(o_3b76e7cf5d023a1f892d,refuted); 0::status(o_3b76e7cf5d023a1f892d,unknown).
0::status(o_3b7d9537a6901a4b7b3d,supported); 1::status(o_3b7d9537a6901a4b7b3d,refuted); 0::status(o_3b7d9537a6901a4b7b3d,unknown).
0.55604892172959974::status(o_3c78a94bc648b2496d91,supported); 0::status(o_3c78a94bc648b2496d91,refuted); 0.44395107827040026::status(o_3c78a94bc648b2496d91,unknown).
0::status(o_3cdd0ef40a74ebbfa5b3,supported); 1::status(o_3cdd0ef40a74ebbfa5b3,refuted); 0::status(o_3cdd0ef40a74ebbfa5b3,unknown).
1::status(o_3d5e970a0f2d371e11f0,supported); 0::status(o_3d5e970a0f2d371e11f0,refuted); 0::status(o_3d5e970a0f2d371e11f0,unknown).
1::status(o_3dc719635cbee4f9209d,supported); 0::status(o_3dc719635cbee4f9209d,refuted); 0::status(o_3dc719635cbee4f9209d,unknown).
7.9832112533040345e-05::status(o_3ddbc48e0bd2ddc2f05e,supported); 0::status(o_3ddbc48e0bd2ddc2f05e,refuted); 0.99992016788746696::status(o_3ddbc48e0bd2ddc2f05e,unknown).
1::status(o_3e5b5ebb25c63596c8b9,supported); 0::status(o_3e5b5ebb25c63596c8b9,refuted); 0::status(o_3e5b5ebb25c63596c8b9,unknown).
1::status(o_3ebb7cc6fd3b9bf0da57,supported); 0::status(o_3ebb7cc6fd3b9bf0da57,refuted); 0::status(o_3ebb7cc6fd3b9bf0da57,unknown).
0::status(o_3ebfdaacc153b1aec974,supported); 1::status(o_3ebfdaacc153b1aec974,refuted); 0::status(o_3ebfdaacc153b1aec974,unknown).
1::status(o_3ef2af9e543b9aeb6785,supported); 0::status(o_3ef2af9e543b9aeb6785,refuted); 0::status(o_3ef2af9e543b9aeb6785,unknown).
0.5446169871586849::status(o_3f0a0d697ec759914a33,supported); 0::status(o_3f0a0d697ec759914a33,refuted); 0.4553830128413151::status(o_3f0a0d697ec759914a33,unknown).
0.60295927359717438::status(o_3f635067430d393e42dc,supported); 0::status(o_3f635067430d393e42dc,refuted); 0.39704072640282562::status(o_3f635067430d393e42dc,unknown).
0.21149467982393813::status(o_3f872fd87aefd55acf08,supported); 0::status(o_3f872fd87aefd55acf08,refuted); 0.7885053201760619::status(o_3f872fd87aefd55acf08,unknown).
0.00026651250664144754::status(o_3fe166d91c3df56103db,supported); 0::status(o_3fe166d91c3df56103db,refuted); 0.99973348749335855::status(o_3fe166d91c3df56103db,unknown).
1::status(o_40b6701dc274d888d09c,supported); 0::status(o_40b6701dc274d888d09c,refuted); 0::status(o_40b6701dc274d888d09c,unknown).
0.32439384632201973::status(o_4124816458cc7be7791d,supported); 0::status(o_4124816458cc7be7791d,refuted); 0.67560615367798027::status(o_4124816458cc7be7791d,unknown).
0.48558621161158549::status(o_4143c39b6b2c1555f7bf,supported); 0::status(o_4143c39b6b2c1555f7bf,refuted); 0.51441378838841456::status(o_4143c39b6b2c1555f7bf,unknown).
1::status(o_414bd271e9205058cbf8,supported); 0::status(o_414bd271e9205058cbf8,refuted); 0::status(o_414bd271e9205058cbf8,unknown).
1::status(o_41ac68c1d660e1bb05ae,supported); 0::status(o_41ac68c1d660e1bb05ae,refuted); 0::status(o_41ac68c1d660e1bb05ae,unknown).
1::status(o_41b5df560211afc7c834,supported); 0::status(o_41b5df560211afc7c834,refuted); 0::status(o_41b5df560211afc7c834,unknown).
1::status(o_420ab2af0de775219296,supported); 0::status(o_420ab2af0de775219296,refuted); 0::status(o_420ab2af0de775219296,unknown).
0.0050932755693793297::status(o_42712c9a896856e135a9,supported); 0::status(o_42712c9a896856e135a9,refuted); 0.99490672443062067::status(o_42712c9a896856e135a9,unknown).
0::status(o_428c52bfe6beb5064445,supported); 1::status(o_428c52bfe6beb5064445,refuted); 0::status(o_428c52bfe6beb5064445,unknown).
0.0018071738304570317::status(o_42dd308b583fa4fe42dc,supported); 0::status(o_42dd308b583fa4fe42dc,refuted); 0.99819282616954297::status(o_42dd308b583fa4fe42dc,unknown).
0.99810886383056641::status(o_432df4da2bf892eb26a9,supported); 0::status(o_432df4da2bf892eb26a9,refuted); 0.0018911361694335938::status(o_432df4da2bf892eb26a9,unknown).
0.62068403752941337::status(o_4367edc539cfc7d0475a,supported); 0::status(o_4367edc539cfc7d0475a,refuted); 0.37931596247058663::status(o_4367edc539cfc7d0475a,unknown).
0.53125500219524435::status(o_4383f569be8bbd298ec9,supported); 0::status(o_4383f569be8bbd298ec9,refuted); 0.46874499780475565::status(o_4383f569be8bbd298ec9,unknown).
0.003883931552991271::status(o_4388ba497a6b1fcfe362,supported); 0::status(o_4388ba497a6b1fcfe362,refuted); 0.99611606844700873::status(o_4388ba497a6b1fcfe362,unknown).
1::status(o_443a780d1a947cf61f25,supported); 0::status(o_443a780d1a947cf61f25,refuted); 0::status(o_443a780d1a947cf61f25,unknown).
0.32439384632201973::status(o_44618462cec09485859f,supported); 0::status(o_44618462cec09485859f,refuted); 0.67560615367798027::status(o_44618462cec09485859f,unknown).
0.25723296770265724::status(o_44a21853ef99f1124603,supported); 0::status(o_44a21853ef99f1124603,refuted); 0.74276703229734276::status(o_44a21853ef99f1124603,unknown).
0::status(o_44ccc51ad29ebcf095fa,supported); 1::status(o_44ccc51ad29ebcf095fa,refuted); 0::status(o_44ccc51ad29ebcf095fa,unknown).
1::status(o_4601243a45bff3aa98fe,supported); 0::status(o_4601243a45bff3aa98fe,refuted); 0::status(o_4601243a45bff3aa98fe,unknown).
0.64424905361761975::status(o_461ada905dff67f06def,supported); 0::status(o_461ada905dff67f06def,refuted); 0.35575094638238025::status(o_461ada905dff67f06def,unknown).
0.18355340419469587::status(o_464aecc4ce5a1844d124,supported); 0::status(o_464aecc4ce5a1844d124,refuted); 0.8164465958053041::status(o_464aecc4ce5a1844d124,unknown).
0.26201390196868501::status(o_466f7b5469f19dcd8595,supported); 0::status(o_466f7b5469f19dcd8595,refuted); 0.73798609803131499::status(o_466f7b5469f19dcd8595,unknown).
0.99794512987136841::status(o_467a6bf0b446f87730d3,supported); 0::status(o_467a6bf0b446f87730d3,refuted); 0.0020548701286315918::status(o_467a6bf0b446f87730d3,unknown).
1::status(o_468be3babf641307d972,supported); 0::status(o_468be3babf641307d972,refuted); 0::status(o_468be3babf641307d972,unknown).
0.67048180430993831::status(o_4693b80ef71d719f4d3e,supported); 0::status(o_4693b80ef71d719f4d3e,refuted); 0.32951819569006169::status(o_4693b80ef71d719f4d3e,unknown).
0.9814574122428894::status(o_46b0dfa33bf5a3670b0f,supported); 0::status(o_46b0dfa33bf5a3670b0f,refuted); 0.018542587757110596::status(o_46b0dfa33bf5a3670b0f,unknown).
0.25449993768299639::status(o_46da85bc07a45229d1aa,supported); 0::status(o_46da85bc07a45229d1aa,refuted); 0.74550006231700361::status(o_46da85bc07a45229d1aa,unknown).
1::status(o_46fa8574cbc3841b84e1,supported); 0::status(o_46fa8574cbc3841b84e1,refuted); 0::status(o_46fa8574cbc3841b84e1,unknown).
0::status(o_471d1181fdaf00aa00b5,supported); 1::status(o_471d1181fdaf00aa00b5,refuted); 0::status(o_471d1181fdaf00aa00b5,unknown).
1::status(o_487bf05f6123fea6f67b,supported); 0::status(o_487bf05f6123fea6f67b,refuted); 0::status(o_487bf05f6123fea6f67b,unknown).
1::status(o_4889e109a1357ef49372,supported); 0::status(o_4889e109a1357ef49372,refuted); 0::status(o_4889e109a1357ef49372,unknown).
0.26867974287424717::status(o_489efec430fd0fa66716,supported); 0::status(o_489efec430fd0fa66716,refuted); 0.73132025712575288::status(o_489efec430fd0fa66716,unknown).
0.2468198586260133::status(o_492292701bc2126d5a87,supported); 0::status(o_492292701bc2126d5a87,refuted); 0.7531801413739867::status(o_492292701bc2126d5a87,unknown).
0.98997622728347778::status(o_49424336ff3d6fa1e5a2,supported); 0::status(o_49424336ff3d6fa1e5a2,refuted); 0.010023772716522217::status(o_49424336ff3d6fa1e5a2,unknown).
1::status(o_4974ccb7f09d177acb73,supported); 0::status(o_4974ccb7f09d177acb73,refuted); 0::status(o_4974ccb7f09d177acb73,unknown).
0.52321884901376903::status(o_498b72a46f1580476d79,supported); 0::status(o_498b72a46f1580476d79,refuted); 0.47678115098623097::status(o_498b72a46f1580476d79,unknown).
0.20809095698265942::status(o_4a0151fb6805df655848,supported); 0::status(o_4a0151fb6805df655848,refuted); 0.79190904301734055::status(o_4a0151fb6805df655848,unknown).
0.4066462516784668::status(o_4abdbe95c42e70b6cdbb,supported); 0::status(o_4abdbe95c42e70b6cdbb,refuted); 0.5933537483215332::status(o_4abdbe95c42e70b6cdbb,unknown).
1::status(o_4ae4190636ea9cb0d1b3,supported); 0::status(o_4ae4190636ea9cb0d1b3,refuted); 0::status(o_4ae4190636ea9cb0d1b3,unknown).
0.00035556388320401311::status(o_4ae5d13a86d7c5e68e12,supported); 0::status(o_4ae5d13a86d7c5e68e12,refuted); 0.99964443611679599::status(o_4ae5d13a86d7c5e68e12,unknown).
0::status(o_4b0a9bcf7d2044dea776,supported); 1::status(o_4b0a9bcf7d2044dea776,refuted); 0::status(o_4b0a9bcf7d2044dea776,unknown).
1::status(o_4b0fe690f14697082397,supported); 0::status(o_4b0fe690f14697082397,refuted); 0::status(o_4b0fe690f14697082397,unknown).
1::status(o_4b339f8cc33e3c309bda,supported); 0::status(o_4b339f8cc33e3c309bda,refuted); 0::status(o_4b339f8cc33e3c309bda,unknown).
0.00062835169956088066::status(o_4b84c45365ec494c93a2,supported); 0::status(o_4b84c45365ec494c93a2,refuted); 0.99937164830043912::status(o_4b84c45365ec494c93a2,unknown).
1::status(o_4bbe840db4065bfc6c84,supported); 0::status(o_4bbe840db4065bfc6c84,refuted); 0::status(o_4bbe840db4065bfc6c84,unknown).
0::status(o_4bca52c95c013cb5b8ab,supported); 1::status(o_4bca52c95c013cb5b8ab,refuted); 0::status(o_4bca52c95c013cb5b8ab,unknown).
1::status(o_4bd273288a69a1575e33,supported); 0::status(o_4bd273288a69a1575e33,refuted); 0::status(o_4bd273288a69a1575e33,unknown).
0::status(o_4be5cd0492ea953c4cb1,supported); 1::status(o_4be5cd0492ea953c4cb1,refuted); 0::status(o_4be5cd0492ea953c4cb1,unknown).
1::status(o_4c204b82679f5c16048c,supported); 0::status(o_4c204b82679f5c16048c,refuted); 0::status(o_4c204b82679f5c16048c,unknown).
1::status(o_4c34fc29dd7bd15ba929,supported); 0::status(o_4c34fc29dd7bd15ba929,refuted); 0::status(o_4c34fc29dd7bd15ba929,unknown).
1::status(o_4c5c44c26ad6679b527c,supported); 0::status(o_4c5c44c26ad6679b527c,refuted); 0::status(o_4c5c44c26ad6679b527c,unknown).
0.59548482063864561::status(o_4c7d266e173cfd04fe2a,supported); 0::status(o_4c7d266e173cfd04fe2a,refuted); 0.40451517936135439::status(o_4c7d266e173cfd04fe2a,unknown).
1::status(o_4cb9960ca7f0acce0bc5,supported); 0::status(o_4cb9960ca7f0acce0bc5,refuted); 0::status(o_4cb9960ca7f0acce0bc5,unknown).
1::status(o_4ccbe967e40edc2464d9,supported); 0::status(o_4ccbe967e40edc2464d9,refuted); 0::status(o_4ccbe967e40edc2464d9,unknown).
1::status(o_4cfe86e56e553ff656b9,supported); 0::status(o_4cfe86e56e553ff656b9,refuted); 0::status(o_4cfe86e56e553ff656b9,unknown).
0.0042693153955042362::status(o_4d25c3dbaf34ec623f52,supported); 0::status(o_4d25c3dbaf34ec623f52,refuted); 0.99573068460449576::status(o_4d25c3dbaf34ec623f52,unknown).
1::status(o_4d28b89477c7f6aea0c9,supported); 0::status(o_4d28b89477c7f6aea0c9,refuted); 0::status(o_4d28b89477c7f6aea0c9,unknown).
1::status(o_4d435abcbe591d662c5b,supported); 0::status(o_4d435abcbe591d662c5b,refuted); 0::status(o_4d435abcbe591d662c5b,unknown).
1::status(o_4d736a643b5273861977,supported); 0::status(o_4d736a643b5273861977,refuted); 0::status(o_4d736a643b5273861977,unknown).
0.021092737093567848::status(o_4d902c8529fc6baca58e,supported); 0::status(o_4d902c8529fc6baca58e,refuted); 0.97890726290643215::status(o_4d902c8529fc6baca58e,unknown).
1::status(o_4dc336be9417dcfa6dd2,supported); 0::status(o_4dc336be9417dcfa6dd2,refuted); 0::status(o_4dc336be9417dcfa6dd2,unknown).
0.0050932755693793297::status(o_4e32f1f77278f61b3b1d,supported); 0::status(o_4e32f1f77278f61b3b1d,refuted); 0.99490672443062067::status(o_4e32f1f77278f61b3b1d,unknown).
0.20063170880206746::status(o_4e3cfe1e783f7853fcf4,supported); 0::status(o_4e3cfe1e783f7853fcf4,refuted); 0.79936829119793251::status(o_4e3cfe1e783f7853fcf4,unknown).
1::status(o_4edcb702012cf5cd4928,supported); 0::status(o_4edcb702012cf5cd4928,refuted); 0::status(o_4edcb702012cf5cd4928,unknown).
0.21558990198612427::status(o_4f6c07a8b2375285bbfc,supported); 0::status(o_4f6c07a8b2375285bbfc,refuted); 0.78441009801387573::status(o_4f6c07a8b2375285bbfc,unknown).
0.02884664386510849::status(o_4f838aae2dddccf14152,supported); 0::status(o_4f838aae2dddccf14152,refuted); 0.97115335613489151::status(o_4f838aae2dddccf14152,unknown).
0.00027939380379393697::status(o_50208b41fa6cd1f34645,supported); 0::status(o_50208b41fa6cd1f34645,refuted); 0.99972060619620606::status(o_50208b41fa6cd1f34645,unknown).
1::status(o_502227769b166b7bc26e,supported); 0::status(o_502227769b166b7bc26e,refuted); 0::status(o_502227769b166b7bc26e,unknown).
1::status(o_503ca5414c5c0df03060,supported); 0::status(o_503ca5414c5c0df03060,refuted); 0::status(o_503ca5414c5c0df03060,unknown).
0::status(o_50971347455099471fdc,supported); 1::status(o_50971347455099471fdc,refuted); 0::status(o_50971347455099471fdc,unknown).
0::status(o_50b819a41b5a1f8449e8,supported); 1::status(o_50b819a41b5a1f8449e8,refuted); 0::status(o_50b819a41b5a1f8449e8,unknown).
1::status(o_50ead26e45ebd4c332dc,supported); 0::status(o_50ead26e45ebd4c332dc,refuted); 0::status(o_50ead26e45ebd4c332dc,unknown).
1::status(o_510820d653cee6d3b321,supported); 0::status(o_510820d653cee6d3b321,refuted); 0::status(o_510820d653cee6d3b321,unknown).
0.0024758365470916033::status(o_5143c4f9ecc7ce300335,supported); 0::status(o_5143c4f9ecc7ce300335,refuted); 0.9975241634529084::status(o_5143c4f9ecc7ce300335,unknown).
0.99794512987136841::status(o_516021b852b3c39b4a39,supported); 0::status(o_516021b852b3c39b4a39,refuted); 0.0020548701286315918::status(o_516021b852b3c39b4a39,unknown).
0::status(o_51b7c3bed597455aec56,supported); 1::status(o_51b7c3bed597455aec56,refuted); 0::status(o_51b7c3bed597455aec56,unknown).
1::status(o_51c0fc64d79cad130828,supported); 0::status(o_51c0fc64d79cad130828,refuted); 0::status(o_51c0fc64d79cad130828,unknown).
1::status(o_522091bddd09e36906b0,supported); 0::status(o_522091bddd09e36906b0,refuted); 0::status(o_522091bddd09e36906b0,unknown).
1::status(o_5291ecff22d470a8116b,supported); 0::status(o_5291ecff22d470a8116b,refuted); 0::status(o_5291ecff22d470a8116b,unknown).
0.54932334459972665::status(o_52976f59be312c9da9b3,supported); 0::status(o_52976f59be312c9da9b3,refuted); 0.45067665540027335::status(o_52976f59be312c9da9b3,unknown).
1::status(o_52a3a0dffca894bba6d6,supported); 0::status(o_52a3a0dffca894bba6d6,refuted); 0::status(o_52a3a0dffca894bba6d6,unknown).
1::status(o_52cbde1248def674a8f0,supported); 0::status(o_52cbde1248def674a8f0,refuted); 0::status(o_52cbde1248def674a8f0,unknown).
1::status(o_5320cd848352bc38e08f,supported); 0::status(o_5320cd848352bc38e08f,refuted); 0::status(o_5320cd848352bc38e08f,unknown).
1::status(o_5335f2c044a5c453f1d3,supported); 0::status(o_5335f2c044a5c453f1d3,refuted); 0::status(o_5335f2c044a5c453f1d3,unknown).
0.0005490043549798429::status(o_533e9538d86e08d0687c,supported); 0::status(o_533e9538d86e08d0687c,refuted); 0.99945099564502016::status(o_533e9538d86e08d0687c,unknown).
0.54636852398171065::status(o_539a76c120556250747f,supported); 0::status(o_539a76c120556250747f,refuted); 0.45363147601828935::status(o_539a76c120556250747f,unknown).
1::status(o_5412b6dea82c96a289a6,supported); 0::status(o_5412b6dea82c96a289a6,refuted); 0::status(o_5412b6dea82c96a289a6,unknown).
0.52707836810175879::status(o_5460f7ef36cb23c4075c,supported); 0::status(o_5460f7ef36cb23c4075c,refuted); 0.47292163189824121::status(o_5460f7ef36cb23c4075c,unknown).
0.60488887780861078::status(o_54747b64333c8705917b,supported); 0::status(o_54747b64333c8705917b,refuted); 0.39511112219138922::status(o_54747b64333c8705917b,unknown).
0::status(o_547f458e637c4c57d2fc,supported); 1::status(o_547f458e637c4c57d2fc,refuted); 0::status(o_547f458e637c4c57d2fc,unknown).
0.31518975007828343::status(o_54aefc839be5302210bf,supported); 0::status(o_54aefc839be5302210bf,refuted); 0.68481024992171657::status(o_54aefc839be5302210bf,unknown).
0.0001668355253059417::status(o_54c943276457363fbbe1,supported); 0::status(o_54c943276457363fbbe1,refuted); 0.99983316447469406::status(o_54c943276457363fbbe1,unknown).
1::status(o_5541a92daebb236774b9,supported); 0::status(o_5541a92daebb236774b9,refuted); 0::status(o_5541a92daebb236774b9,unknown).
0.58637967737669439::status(o_554947636f601b144d28,supported); 0::status(o_554947636f601b144d28,refuted); 0.41362032262330561::status(o_554947636f601b144d28,unknown).
0::status(o_554bfd6c154be204b5f6,supported); 1::status(o_554bfd6c154be204b5f6,refuted); 0::status(o_554bfd6c154be204b5f6,unknown).
1::status(o_5594deda7efcd63d3b5e,supported); 0::status(o_5594deda7efcd63d3b5e,refuted); 0::status(o_5594deda7efcd63d3b5e,unknown).
0.0031784586608409882::status(o_55ad6c431d2f2e4f4dba,supported); 0::status(o_55ad6c431d2f2e4f4dba,refuted); 0.99682154133915901::status(o_55ad6c431d2f2e4f4dba,unknown).
1::status(o_55b6ef454f27363f3017,supported); 0::status(o_55b6ef454f27363f3017,refuted); 0::status(o_55b6ef454f27363f3017,unknown).
1::status(o_55f80f8e3fff5c90dc56,supported); 0::status(o_55f80f8e3fff5c90dc56,refuted); 0::status(o_55f80f8e3fff5c90dc56,unknown).
0.00027939380379393697::status(o_5603683a4da939be9f2a,supported); 0::status(o_5603683a4da939be9f2a,refuted); 0.99972060619620606::status(o_5603683a4da939be9f2a,unknown).
0.61694091558456421::status(o_56ad42ee0b74ed3afa7b,supported); 0::status(o_56ad42ee0b74ed3afa7b,refuted); 0.38305908441543579::status(o_56ad42ee0b74ed3afa7b,unknown).
1::status(o_56c8a19be2e2f94458c5,supported); 0::status(o_56c8a19be2e2f94458c5,refuted); 0::status(o_56c8a19be2e2f94458c5,unknown).
0::status(o_56e59f114d85ccbf37b4,supported); 1::status(o_56e59f114d85ccbf37b4,refuted); 0::status(o_56e59f114d85ccbf37b4,unknown).
0.61780141521719734::status(o_577f9eda53efd92de539,supported); 0::status(o_577f9eda53efd92de539,refuted); 0.38219858478280266::status(o_577f9eda53efd92de539,unknown).
0.091254428029060364::status(o_584b435ed4cfd0f7dedb,supported); 0::status(o_584b435ed4cfd0f7dedb,refuted); 0.90874557197093964::status(o_584b435ed4cfd0f7dedb,unknown).
1::status(o_58619889581c02348863,supported); 0::status(o_58619889581c02348863,refuted); 0::status(o_58619889581c02348863,unknown).
5.6373784900642931e-05::status(o_58651adc8b8045305295,supported); 0::status(o_58651adc8b8045305295,refuted); 0.99994362621509936::status(o_58651adc8b8045305295,unknown).
0.27334199875687309::status(o_58ae1cb619f437dd76c7,supported); 0::status(o_58ae1cb619f437dd76c7,refuted); 0.72665800124312696::status(o_58ae1cb619f437dd76c7,unknown).
0.58011855578135862::status(o_58f7cac111d9e7143035,supported); 0::status(o_58f7cac111d9e7143035,refuted); 0.41988144421864138::status(o_58f7cac111d9e7143035,unknown).
1::status(o_5946bbada845f2842d11,supported); 0::status(o_5946bbada845f2842d11,refuted); 0::status(o_5946bbada845f2842d11,unknown).
0.98706090450286865::status(o_5985f74ffd642d018f0c,supported); 0::status(o_5985f74ffd642d018f0c,refuted); 0.012939095497131348::status(o_5985f74ffd642d018f0c,unknown).
0::status(o_59bd0b466267eb69465f,supported); 1::status(o_59bd0b466267eb69465f,refuted); 0::status(o_59bd0b466267eb69465f,unknown).
0.99524873495101929::status(o_5a4107cc4ed2530df561,supported); 0::status(o_5a4107cc4ed2530df561,refuted); 0.0047512650489807129::status(o_5a4107cc4ed2530df561,unknown).
0.00058511312818154693::status(o_5a8d90fdb110cafe06ef,supported); 0::status(o_5a8d90fdb110cafe06ef,refuted); 0.99941488687181845::status(o_5a8d90fdb110cafe06ef,unknown).
0.14585956196848071::status(o_5abe132dd12d7436d9ff,supported); 0::status(o_5abe132dd12d7436d9ff,refuted); 0.85414043803151929::status(o_5abe132dd12d7436d9ff,unknown).
0.25870247465189983::status(o_5afb1e996d5ff006e47a,supported); 0::status(o_5afb1e996d5ff006e47a,refuted); 0.74129752534810023::status(o_5afb1e996d5ff006e47a,unknown).
5.6373784900642931e-05::status(o_5b06b30206d25196f22d,supported); 0::status(o_5b06b30206d25196f22d,refuted); 0.99994362621509936::status(o_5b06b30206d25196f22d,unknown).
0.9814574122428894::status(o_5b7aa884b8d837f96d1e,supported); 0::status(o_5b7aa884b8d837f96d1e,refuted); 0.018542587757110596::status(o_5b7aa884b8d837f96d1e,unknown).
0.22783341461938156::status(o_5ba37f7ae93210d01b8d,supported); 0::status(o_5ba37f7ae93210d01b8d,refuted); 0.77216658538061844::status(o_5ba37f7ae93210d01b8d,unknown).
0.97427183389663696::status(o_5ba8da655c850e0036e8,supported); 0::status(o_5ba8da655c850e0036e8,refuted); 0.025728166103363037::status(o_5ba8da655c850e0036e8,unknown).
0::status(o_5bb731a25da57997cd4b,supported); 1::status(o_5bb731a25da57997cd4b,refuted); 0::status(o_5bb731a25da57997cd4b,unknown).
0.30022704115354287::status(o_5c003abdd94b198d7228,supported); 0::status(o_5c003abdd94b198d7228,refuted); 0.69977295884645718::status(o_5c003abdd94b198d7228,unknown).
0::status(o_5c632d30d38144eed6c2,supported); 1::status(o_5c632d30d38144eed6c2,refuted); 0::status(o_5c632d30d38144eed6c2,unknown).
1::status(o_5c97404ff56f4d21cb80,supported); 0::status(o_5c97404ff56f4d21cb80,refuted); 0::status(o_5c97404ff56f4d21cb80,unknown).
0.71475537349000173::status(o_5cf58a7b7b034e427bcc,supported); 0::status(o_5cf58a7b7b034e427bcc,refuted); 0.28524462650999827::status(o_5cf58a7b7b034e427bcc,unknown).
0.003883931552991271::status(o_5d1219a9d345299a68a6,supported); 0::status(o_5d1219a9d345299a68a6,refuted); 0.99611606844700873::status(o_5d1219a9d345299a68a6,unknown).
0.6157456622530415::status(o_5d899fd43466722082ff,supported); 0::status(o_5d899fd43466722082ff,refuted); 0.3842543377469585::status(o_5d899fd43466722082ff,unknown).
0.00012811402848456055::status(o_5dcf2050f78a23e17baa,supported); 0::status(o_5dcf2050f78a23e17baa,refuted); 0.99987188597151544::status(o_5dcf2050f78a23e17baa,unknown).
1::status(o_5ddedab498303c96e83a,supported); 0::status(o_5ddedab498303c96e83a,refuted); 0::status(o_5ddedab498303c96e83a,unknown).
0.0007167395087890327::status(o_5de500d84c14aa36d180,supported); 0::status(o_5de500d84c14aa36d180,refuted); 0.99928326049121097::status(o_5de500d84c14aa36d180,unknown).
0.63310902975620786::status(o_5e2eb1f02e2acf62a86d,supported); 0::status(o_5e2eb1f02e2acf62a86d,refuted); 0.36689097024379214::status(o_5e2eb1f02e2acf62a86d,unknown).
1::status(o_5e492fe8162d57aadf78,supported); 0::status(o_5e492fe8162d57aadf78,refuted); 0::status(o_5e492fe8162d57aadf78,unknown).
0.25816698581701109::status(o_5e71380d8ee2db992e9c,supported); 0::status(o_5e71380d8ee2db992e9c,refuted); 0.74183301418298897::status(o_5e71380d8ee2db992e9c,unknown).
0.0016958331689238548::status(o_5ea03014ecb5e885f832,supported); 0::status(o_5ea03014ecb5e885f832,refuted); 0.99830416683107615::status(o_5ea03014ecb5e885f832,unknown).
1::status(o_5ed964c5cb9a7faefe37,supported); 0::status(o_5ed964c5cb9a7faefe37,refuted); 0::status(o_5ed964c5cb9a7faefe37,unknown).
1::status(o_5ee2f790fea281a947ed,supported); 0::status(o_5ee2f790fea281a947ed,refuted); 0::status(o_5ee2f790fea281a947ed,unknown).
0::status(o_5f1df02afdbe6bee9105,supported); 1::status(o_5f1df02afdbe6bee9105,refuted); 0::status(o_5f1df02afdbe6bee9105,unknown).
0.69321541940515385::status(o_5f28285bb8f6675ce263,supported); 0::status(o_5f28285bb8f6675ce263,refuted); 0.30678458059484615::status(o_5f28285bb8f6675ce263,unknown).
0.19211416330309658::status(o_5f3315cd38dc9be35e4d,supported); 0::status(o_5f3315cd38dc9be35e4d,refuted); 0.80788583669690339::status(o_5f3315cd38dc9be35e4d,unknown).
1::status(o_5f750d902446ac7d3632,supported); 0::status(o_5f750d902446ac7d3632,refuted); 0::status(o_5f750d902446ac7d3632,unknown).
1::status(o_5fecb3b1ecec92f01d33,supported); 0::status(o_5fecb3b1ecec92f01d33,refuted); 0::status(o_5fecb3b1ecec92f01d33,unknown).
0.98928332328796387::status(o_60cd1e3d78ad39dacf25,supported); 0::status(o_60cd1e3d78ad39dacf25,refuted); 0.010716676712036133::status(o_60cd1e3d78ad39dacf25,unknown).
0.00019939233607146889::status(o_60f4d140724633210c01,supported); 0::status(o_60f4d140724633210c01,refuted); 0.99980060766392853::status(o_60f4d140724633210c01,unknown).
0::status(o_610e409cc34287fab3d1,supported); 1::status(o_610e409cc34287fab3d1,refuted); 0::status(o_610e409cc34287fab3d1,unknown).
0::status(o_618616a7183903773cb2,supported); 1::status(o_618616a7183903773cb2,refuted); 0::status(o_618616a7183903773cb2,unknown).
0.99506652355194092::status(o_6187e5789daf90932631,supported); 0::status(o_6187e5789daf90932631,refuted); 0.004933476448059082::status(o_6187e5789daf90932631,unknown).
1::status(o_6194dd554d41d13db0ab,supported); 0::status(o_6194dd554d41d13db0ab,refuted); 0::status(o_6194dd554d41d13db0ab,unknown).
1::status(o_61e6aff881f1083d539d,supported); 0::status(o_61e6aff881f1083d539d,refuted); 0::status(o_61e6aff881f1083d539d,unknown).
0.00038813083665445447::status(o_621dfc36926a9e5fbfde,supported); 0::status(o_621dfc36926a9e5fbfde,refuted); 0.99961186916334555::status(o_621dfc36926a9e5fbfde,unknown).
1::status(o_62344e839b3bb75a04d6,supported); 0::status(o_62344e839b3bb75a04d6,refuted); 0::status(o_62344e839b3bb75a04d6,unknown).
0.72930726178536853::status(o_624ffa0d0bd1f7f92cd4,supported); 0::status(o_624ffa0d0bd1f7f92cd4,refuted); 0.27069273821463147::status(o_624ffa0d0bd1f7f92cd4,unknown).
1::status(o_626b65d31b3b92b99320,supported); 0::status(o_626b65d31b3b92b99320,refuted); 0::status(o_626b65d31b3b92b99320,unknown).
0.99155628681182861::status(o_629dc282f430be00ec55,supported); 0::status(o_629dc282f430be00ec55,refuted); 0.0084437131881713867::status(o_629dc282f430be00ec55,unknown).
1::status(o_62af9e58173e39eba6d3,supported); 0::status(o_62af9e58173e39eba6d3,refuted); 0::status(o_62af9e58173e39eba6d3,unknown).
0::status(o_630034cdf9f5fc94069c,supported); 1::status(o_630034cdf9f5fc94069c,refuted); 0::status(o_630034cdf9f5fc94069c,unknown).
0::status(o_6393e12e124c3ee350f1,supported); 1::status(o_6393e12e124c3ee350f1,refuted); 0::status(o_6393e12e124c3ee350f1,unknown).
0::status(o_6412bf5da791271fed4a,supported); 1::status(o_6412bf5da791271fed4a,refuted); 0::status(o_6412bf5da791271fed4a,unknown).
0.41550036072050733::status(o_642264a48f7aec5c30e2,supported); 0::status(o_642264a48f7aec5c30e2,refuted); 0.58449963927949267::status(o_642264a48f7aec5c30e2,unknown).
1::status(o_6450ff128c268e222c8b,supported); 0::status(o_6450ff128c268e222c8b,refuted); 0::status(o_6450ff128c268e222c8b,unknown).
0.66678006529301059::status(o_646f7fbcefb7786adad1,supported); 0::status(o_646f7fbcefb7786adad1,refuted); 0.33321993470698941::status(o_646f7fbcefb7786adad1,unknown).
0.56916671898022009::status(o_6498afbe5c01020df025,supported); 0::status(o_6498afbe5c01020df025,refuted); 0.43083328101977991::status(o_6498afbe5c01020df025,unknown).
1::status(o_651364aa679d8f6f7279,supported); 0::status(o_651364aa679d8f6f7279,refuted); 0::status(o_651364aa679d8f6f7279,unknown).
0.099834618680556958::status(o_6532d7ec3efa3f8c6015,supported); 0::status(o_6532d7ec3efa3f8c6015,refuted); 0.90016538131944301::status(o_6532d7ec3efa3f8c6015,unknown).
1::status(o_658e7851d79c344f94da,supported); 0::status(o_658e7851d79c344f94da,refuted); 0::status(o_658e7851d79c344f94da,unknown).
0.46966454048493733::status(o_661290ccae6ac5396e8e,supported); 0::status(o_661290ccae6ac5396e8e,refuted); 0.53033545951506267::status(o_661290ccae6ac5396e8e,unknown).
0.56824234941493657::status(o_6636bbb02daeb3468e6d,supported); 0::status(o_6636bbb02daeb3468e6d,refuted); 0.43175765058506343::status(o_6636bbb02daeb3468e6d,unknown).
1::status(o_666172dbc2614927985f,supported); 0::status(o_666172dbc2614927985f,refuted); 0::status(o_666172dbc2614927985f,unknown).
1::status(o_66bd7d087c86af0550dd,supported); 0::status(o_66bd7d087c86af0550dd,refuted); 0::status(o_66bd7d087c86af0550dd,unknown).
1::status(o_673fee03e493346b746e,supported); 0::status(o_673fee03e493346b746e,refuted); 0::status(o_673fee03e493346b746e,unknown).
1::status(o_67476fac70e4de2de21c,supported); 0::status(o_67476fac70e4de2de21c,refuted); 0::status(o_67476fac70e4de2de21c,unknown).
0::status(o_677e2547b5a54995c384,supported); 1::status(o_677e2547b5a54995c384,refuted); 0::status(o_677e2547b5a54995c384,unknown).
0.017571487860209182::status(o_679d0a6bc23073b0925d,supported); 0::status(o_679d0a6bc23073b0925d,refuted); 0.98242851213979077::status(o_679d0a6bc23073b0925d,unknown).
0::status(o_6853eeb3d0cbbcba5e5f,supported); 1::status(o_6853eeb3d0cbbcba5e5f,refuted); 0::status(o_6853eeb3d0cbbcba5e5f,unknown).
0::status(o_68829cac35bb3a925898,supported); 1::status(o_68829cac35bb3a925898,refuted); 0::status(o_68829cac35bb3a925898,unknown).
1::status(o_68e499ae33b6472996f5,supported); 0::status(o_68e499ae33b6472996f5,refuted); 0::status(o_68e499ae33b6472996f5,unknown).
1::status(o_692fa001f5cd3238473a,supported); 0::status(o_692fa001f5cd3238473a,refuted); 0::status(o_692fa001f5cd3238473a,unknown).
0.2158120867173586::status(o_69611b50a1e65ec70e3f,supported); 0::status(o_69611b50a1e65ec70e3f,refuted); 0.78418791328264137::status(o_69611b50a1e65ec70e3f,unknown).
1::status(o_6964896e981a9ecc7347,supported); 0::status(o_6964896e981a9ecc7347,refuted); 0::status(o_6964896e981a9ecc7347,unknown).
0.98721271753311157::status(o_69ab1a8196e6ce11ec89,supported); 0::status(o_69ab1a8196e6ce11ec89,refuted); 0.012787282466888428::status(o_69ab1a8196e6ce11ec89,unknown).
1::status(o_6a5e555e4daa7914c677,supported); 0::status(o_6a5e555e4daa7914c677,refuted); 0::status(o_6a5e555e4daa7914c677,unknown).
1::status(o_6accc46dc260687c5818,supported); 0::status(o_6accc46dc260687c5818,refuted); 0::status(o_6accc46dc260687c5818,unknown).
1::status(o_6b098069cb53a4d561b8,supported); 0::status(o_6b098069cb53a4d561b8,refuted); 0::status(o_6b098069cb53a4d561b8,unknown).
0.99506652355194092::status(o_6b16873a1dc74e54c5dd,supported); 0::status(o_6b16873a1dc74e54c5dd,refuted); 0.004933476448059082::status(o_6b16873a1dc74e54c5dd,unknown).
0.988739013671875::status(o_6ba663ee66a3a824c2c2,supported); 0::status(o_6ba663ee66a3a824c2c2,refuted); 0.011260986328125::status(o_6ba663ee66a3a824c2c2,unknown).
0.28838067438115472::status(o_6bfa53317f4a1ffba4a5,supported); 0::status(o_6bfa53317f4a1ffba4a5,refuted); 0.71161932561884522::status(o_6bfa53317f4a1ffba4a5,unknown).
0.00085279322229325771::status(o_6c93acc7924c8be4cfd6,supported); 0::status(o_6c93acc7924c8be4cfd6,refuted); 0.99914720677770674::status(o_6c93acc7924c8be4cfd6,unknown).
1::status(o_6ca9b18073d22c691c53,supported); 0::status(o_6ca9b18073d22c691c53,refuted); 0::status(o_6ca9b18073d22c691c53,unknown).
1::status(o_6cebf5b5294eecf6659a,supported); 0::status(o_6cebf5b5294eecf6659a,refuted); 0::status(o_6cebf5b5294eecf6659a,unknown).
0.17908329447327972::status(o_6cff6c9209477777094e,supported); 0::status(o_6cff6c9209477777094e,refuted); 0.82091670552672025::status(o_6cff6c9209477777094e,unknown).
1::status(o_6d1b54fe5d1ae2c36c58,supported); 0::status(o_6d1b54fe5d1ae2c36c58,refuted); 0::status(o_6d1b54fe5d1ae2c36c58,unknown).
0.2589945870564957::status(o_6d1c86657356599bbb62,supported); 0::status(o_6d1c86657356599bbb62,refuted); 0.7410054129435043::status(o_6d1c86657356599bbb62,unknown).
0.00044824578799307346::status(o_6d34ed7be83f472c3061,supported); 0::status(o_6d34ed7be83f472c3061,refuted); 0.99955175421200693::status(o_6d34ed7be83f472c3061,unknown).
1::status(o_6e2294cf3b1f0eb8808f,supported); 0::status(o_6e2294cf3b1f0eb8808f,refuted); 0::status(o_6e2294cf3b1f0eb8808f,unknown).
0.00022408674703910947::status(o_6e30eb83c838330d2c4b,supported); 0::status(o_6e30eb83c838330d2c4b,refuted); 0.99977591325296089::status(o_6e30eb83c838330d2c4b,unknown).
1::status(o_6e3cfaffc8186d1b0bbe,supported); 0::status(o_6e3cfaffc8186d1b0bbe,refuted); 0::status(o_6e3cfaffc8186d1b0bbe,unknown).
1::status(o_6e62e3e89e4305da18d4,supported); 0::status(o_6e62e3e89e4305da18d4,refuted); 0::status(o_6e62e3e89e4305da18d4,unknown).
1::status(o_6eee66a36d1bfc59e677,supported); 0::status(o_6eee66a36d1bfc59e677,refuted); 0::status(o_6eee66a36d1bfc59e677,unknown).
0.00019939233607146889::status(o_6ef5f6b21c0a02d7649f,supported); 0::status(o_6ef5f6b21c0a02d7649f,refuted); 0.99980060766392853::status(o_6ef5f6b21c0a02d7649f,unknown).
0::status(o_6f0f32e8b6895343eeb1,supported); 1::status(o_6f0f32e8b6895343eeb1,refuted); 0::status(o_6f0f32e8b6895343eeb1,unknown).
1::status(o_6f339ef01849b86af0ba,supported); 0::status(o_6f339ef01849b86af0ba,refuted); 0::status(o_6f339ef01849b86af0ba,unknown).
0.36099548022710864::status(o_6fd10b2ac9221a9ab4a7,supported); 0::status(o_6fd10b2ac9221a9ab4a7,refuted); 0.6390045197728913::status(o_6fd10b2ac9221a9ab4a7,unknown).
1::status(o_6fe268939122920fc664,supported); 0::status(o_6fe268939122920fc664,refuted); 0::status(o_6fe268939122920fc664,unknown).
1::status(o_7027cfe40588b5027439,supported); 0::status(o_7027cfe40588b5027439,refuted); 0::status(o_7027cfe40588b5027439,unknown).
1::status(o_707e927e077d4854b711,supported); 0::status(o_707e927e077d4854b711,refuted); 0::status(o_707e927e077d4854b711,unknown).
0.37032851198878464::status(o_70865af1be6f3e96a862,supported); 0::status(o_70865af1be6f3e96a862,refuted); 0.62967148801121531::status(o_70865af1be6f3e96a862,unknown).
0.64354465567556274::status(o_70b9ee27084195915155,supported); 0::status(o_70b9ee27084195915155,refuted); 0.35645534432443726::status(o_70b9ee27084195915155,unknown).
0::status(o_70bcbaec205a0d0cc30a,supported); 1::status(o_70bcbaec205a0d0cc30a,refuted); 0::status(o_70bcbaec205a0d0cc30a,unknown).
0.00012811402848456055::status(o_70ee7ff2b945257f7138,supported); 0::status(o_70ee7ff2b945257f7138,refuted); 0.99987188597151544::status(o_70ee7ff2b945257f7138,unknown).
0::status(o_7158d7fcec3492c63471,supported); 1::status(o_7158d7fcec3492c63471,refuted); 0::status(o_7158d7fcec3492c63471,unknown).
1::status(o_71d43d1c4404a38ce2d3,supported); 0::status(o_71d43d1c4404a38ce2d3,refuted); 0::status(o_71d43d1c4404a38ce2d3,unknown).
1::status(o_71dc0665a3dd07e090d4,supported); 0::status(o_71dc0665a3dd07e090d4,refuted); 0::status(o_71dc0665a3dd07e090d4,unknown).
0.00019939233607146889::status(o_71dc35bc325aa3663e39,supported); 0::status(o_71dc35bc325aa3663e39,refuted); 0.99980060766392853::status(o_71dc35bc325aa3663e39,unknown).
0.49817322870543185::status(o_729d639a8e4320e8ebe8,supported); 0::status(o_729d639a8e4320e8ebe8,refuted); 0.5018267712945681::status(o_729d639a8e4320e8ebe8,unknown).
1::status(o_72acaf36a257ce51ee74,supported); 0::status(o_72acaf36a257ce51ee74,refuted); 0::status(o_72acaf36a257ce51ee74,unknown).
0.0024758365470916033::status(o_72b91ad6971397c1f622,supported); 0::status(o_72b91ad6971397c1f622,refuted); 0.9975241634529084::status(o_72b91ad6971397c1f622,unknown).
0.99660646915435791::status(o_7330bc82f088bb7191f6,supported); 0::status(o_7330bc82f088bb7191f6,refuted); 0.0033935308456420898::status(o_7330bc82f088bb7191f6,unknown).
0.0016452829586341977::status(o_734af3776dcf8b1fdb49,supported); 0::status(o_734af3776dcf8b1fdb49,refuted); 0.9983547170413658::status(o_734af3776dcf8b1fdb49,unknown).
0.66259841625241822::status(o_7366fa3c499d4cd9541b,supported); 0::status(o_7366fa3c499d4cd9541b,refuted); 0.33740158374758178::status(o_7366fa3c499d4cd9541b,unknown).
1::status(o_7379ff4abb0f4c918400,supported); 0::status(o_7379ff4abb0f4c918400,refuted); 0::status(o_7379ff4abb0f4c918400,unknown).
1::status(o_7382abb16ee50d667551,supported); 0::status(o_7382abb16ee50d667551,refuted); 0::status(o_7382abb16ee50d667551,unknown).
0::status(o_73951d5b9614f58fe5c3,supported); 1::status(o_73951d5b9614f58fe5c3,refuted); 0::status(o_73951d5b9614f58fe5c3,unknown).
1::status(o_74607d141de396bc1302,supported); 0::status(o_74607d141de396bc1302,refuted); 0::status(o_74607d141de396bc1302,unknown).
1::status(o_74f027feffc37ca9dd97,supported); 0::status(o_74f027feffc37ca9dd97,refuted); 0::status(o_74f027feffc37ca9dd97,unknown).
0.3267414933664608::status(o_750272459a32718c5ba1,supported); 0::status(o_750272459a32718c5ba1,refuted); 0.67325850663353926::status(o_750272459a32718c5ba1,unknown).
0.00035556388320401311::status(o_753e010ec4f8d2aa3097,supported); 0::status(o_753e010ec4f8d2aa3097,refuted); 0.99964443611679599::status(o_753e010ec4f8d2aa3097,unknown).
1::status(o_7552674d7b6e1516e358,supported); 0::status(o_7552674d7b6e1516e358,refuted); 0::status(o_7552674d7b6e1516e358,unknown).
0.017168149352073669::status(o_7596a40616fd56b8ea9e,supported); 0::status(o_7596a40616fd56b8ea9e,refuted); 0.98283185064792633::status(o_7596a40616fd56b8ea9e,unknown).
0.00027316782507114112::status(o_759afe6441f2303c28b6,supported); 0::status(o_759afe6441f2303c28b6,refuted); 0.99972683217492886::status(o_759afe6441f2303c28b6,unknown).
1::status(o_75b800a72091c280603b,supported); 0::status(o_75b800a72091c280603b,refuted); 0::status(o_75b800a72091c280603b,unknown).
1::status(o_762baed664fd7c851e4f,supported); 0::status(o_762baed664fd7c851e4f,refuted); 0::status(o_762baed664fd7c851e4f,unknown).
0.69422269685182314::status(o_765c3babdecde637c01f,supported); 0::status(o_765c3babdecde637c01f,refuted); 0.30577730314817686::status(o_765c3babdecde637c01f,unknown).
1::status(o_7664e13e53630bb96e10,supported); 0::status(o_7664e13e53630bb96e10,refuted); 0::status(o_7664e13e53630bb96e10,unknown).
0.21773626871697288::status(o_770d666b39ab7b0fada1,supported); 0::status(o_770d666b39ab7b0fada1,refuted); 0.78226373128302717::status(o_770d666b39ab7b0fada1,unknown).
0.66286114808256291::status(o_774734f7f73ba8e84954,supported); 0::status(o_774734f7f73ba8e84954,refuted); 0.33713885191743709::status(o_774734f7f73ba8e84954,unknown).
0::status(o_774847ccadade7fa38ea,supported); 1::status(o_774847ccadade7fa38ea,refuted); 0::status(o_774847ccadade7fa38ea,unknown).
1::status(o_7777262499d19cfc9d75,supported); 0::status(o_7777262499d19cfc9d75,refuted); 0::status(o_7777262499d19cfc9d75,unknown).
0::status(o_77e05eb57f599270bea5,supported); 1::status(o_77e05eb57f599270bea5,refuted); 0::status(o_77e05eb57f599270bea5,unknown).
0.56114206596813354::status(o_78545cbec07cdef331fb,supported); 0::status(o_78545cbec07cdef331fb,refuted); 0.43885793403186646::status(o_78545cbec07cdef331fb,unknown).
1::status(o_789746893159446ba4b5,supported); 0::status(o_789746893159446ba4b5,refuted); 0::status(o_789746893159446ba4b5,unknown).
0.99506819248199463::status(o_78a0a99e73395c0c8674,supported); 0::status(o_78a0a99e73395c0c8674,refuted); 0.0049318075180053711::status(o_78a0a99e73395c0c8674,unknown).
1::status(o_78d4c9f384590326694d,supported); 0::status(o_78d4c9f384590326694d,refuted); 0::status(o_78d4c9f384590326694d,unknown).
1::status(o_78ea6efaa4bd8715a358,supported); 0::status(o_78ea6efaa4bd8715a358,refuted); 0::status(o_78ea6efaa4bd8715a358,unknown).
2.2375324988388456e-05::status(o_7932a9e3c3cff51e4d66,supported); 0::status(o_7932a9e3c3cff51e4d66,refuted); 0.99997762467501161::status(o_7932a9e3c3cff51e4d66,unknown).
1::status(o_79382d61888a85fc7ba0,supported); 0::status(o_79382d61888a85fc7ba0,refuted); 0::status(o_79382d61888a85fc7ba0,unknown).
1::status(o_796cca04ae13beb5056a,supported); 0::status(o_796cca04ae13beb5056a,refuted); 0::status(o_796cca04ae13beb5056a,unknown).
1::status(o_7a358bd719284660b76c,supported); 0::status(o_7a358bd719284660b76c,refuted); 0::status(o_7a358bd719284660b76c,unknown).
0::status(o_7a501a3a35811556d44b,supported); 1::status(o_7a501a3a35811556d44b,refuted); 0::status(o_7a501a3a35811556d44b,unknown).
0.00062835169956088066::status(o_7a797b663c4aec95363b,supported); 0::status(o_7a797b663c4aec95363b,refuted); 0.99937164830043912::status(o_7a797b663c4aec95363b,unknown).
0.15453670094831037::status(o_7ab054b366cbc1de9ae0,supported); 0::status(o_7ab054b366cbc1de9ae0,refuted); 0.8454632990516896::status(o_7ab054b366cbc1de9ae0,unknown).
1::status(o_7ab202ac62c8fdee8969,supported); 0::status(o_7ab202ac62c8fdee8969,refuted); 0::status(o_7ab202ac62c8fdee8969,unknown).
1::status(o_7acb591d47f0c59bfcd5,supported); 0::status(o_7acb591d47f0c59bfcd5,refuted); 0::status(o_7acb591d47f0c59bfcd5,unknown).
0.53504799636989575::status(o_7ae1b46cef3b45e7f186,supported); 0::status(o_7ae1b46cef3b45e7f186,refuted); 0.46495200363010425::status(o_7ae1b46cef3b45e7f186,unknown).
0.00096308212960138917::status(o_7ae5fc7a8b2e4a33a87d,supported); 0::status(o_7ae5fc7a8b2e4a33a87d,refuted); 0.99903691787039861::status(o_7ae5fc7a8b2e4a33a87d,unknown).
0.54227643882800292::status(o_7aea84e92ef7f5d0dbb5,supported); 0::status(o_7aea84e92ef7f5d0dbb5,refuted); 0.45772356117199708::status(o_7aea84e92ef7f5d0dbb5,unknown).
1::status(o_7b3ae359f177745704f2,supported); 0::status(o_7b3ae359f177745704f2,refuted); 0::status(o_7b3ae359f177745704f2,unknown).
1::status(o_7b3b724da1e045bcfdf5,supported); 0::status(o_7b3b724da1e045bcfdf5,refuted); 0::status(o_7b3b724da1e045bcfdf5,unknown).
0.0010018589673563838::status(o_7b4c13fd26340f116903,supported); 0::status(o_7b4c13fd26340f116903,refuted); 0.99899814103264362::status(o_7b4c13fd26340f116903,unknown).
1::status(o_7b689f0c8711deefb48b,supported); 0::status(o_7b689f0c8711deefb48b,refuted); 0::status(o_7b689f0c8711deefb48b,unknown).
1::status(o_7cb182bee4bd6aa25d27,supported); 0::status(o_7cb182bee4bd6aa25d27,refuted); 0::status(o_7cb182bee4bd6aa25d27,unknown).
1::status(o_7d697e425055dcf0a5e1,supported); 0::status(o_7d697e425055dcf0a5e1,refuted); 0::status(o_7d697e425055dcf0a5e1,unknown).
0.71475537349000173::status(o_7d76d0e158ae641f79a7,supported); 0::status(o_7d76d0e158ae641f79a7,refuted); 0.28524462650999827::status(o_7d76d0e158ae641f79a7,unknown).
0::status(o_7dadf53904ba4c0f227a,supported); 1::status(o_7dadf53904ba4c0f227a,refuted); 0::status(o_7dadf53904ba4c0f227a,unknown).
0.44029060614000282::status(o_7dc163d16bcdb473de4d,supported); 0::status(o_7dc163d16bcdb473de4d,refuted); 0.55970939385999718::status(o_7dc163d16bcdb473de4d,unknown).
1::status(o_7e0854b5c7269b6e3e2f,supported); 0::status(o_7e0854b5c7269b6e3e2f,refuted); 0::status(o_7e0854b5c7269b6e3e2f,unknown).
1::status(o_7e140e58dcd1ffabe966,supported); 0::status(o_7e140e58dcd1ffabe966,refuted); 0::status(o_7e140e58dcd1ffabe966,unknown).
1::status(o_7e33a51c69785c1cc67a,supported); 0::status(o_7e33a51c69785c1cc67a,refuted); 0::status(o_7e33a51c69785c1cc67a,unknown).
0.22048295676347288::status(o_7e470dd82029c2c3181b,supported); 0::status(o_7e470dd82029c2c3181b,refuted); 0.77951704323652715::status(o_7e470dd82029c2c3181b,unknown).
0.72849249050291232::status(o_7e4726a29e848a714e81,supported); 0::status(o_7e4726a29e848a714e81,refuted); 0.27150750949708768::status(o_7e4726a29e848a714e81,unknown).
0.25816698581701109::status(o_7e65df3825f3ca00bb59,supported); 0::status(o_7e65df3825f3ca00bb59,refuted); 0.74183301418298897::status(o_7e65df3825f3ca00bb59,unknown).
9.0030916908290237e-05::status(o_7e6d1e9d390d01146f61,supported); 0::status(o_7e6d1e9d390d01146f61,refuted); 0.99990996908309171::status(o_7e6d1e9d390d01146f61,unknown).
0.045692827552556992::status(o_7e88fec1c93fd306ec6d,supported); 0::status(o_7e88fec1c93fd306ec6d,refuted); 0.95430717244744301::status(o_7e88fec1c93fd306ec6d,unknown).
1::status(o_7eb2a2dd2fb0feb7bca4,supported); 0::status(o_7eb2a2dd2fb0feb7bca4,refuted); 0::status(o_7eb2a2dd2fb0feb7bca4,unknown).
0.0060226605273783207::status(o_7eedce19a0d8caee91bd,supported); 0::status(o_7eedce19a0d8caee91bd,refuted); 0.99397733947262168::status(o_7eedce19a0d8caee91bd,unknown).
1::status(o_7eee86f9ab30f79637a5,supported); 0::status(o_7eee86f9ab30f79637a5,refuted); 0::status(o_7eee86f9ab30f79637a5,unknown).
0.99506819248199463::status(o_7f434f93751d75eba66f,supported); 0::status(o_7f434f93751d75eba66f,refuted); 0.0049318075180053711::status(o_7f434f93751d75eba66f,unknown).
0::status(o_7f6a2b66195fb7629db3,supported); 1::status(o_7f6a2b66195fb7629db3,refuted); 0::status(o_7f6a2b66195fb7629db3,unknown).
0.66553917572983945::status(o_7fb080887d485a88d449,supported); 0::status(o_7fb080887d485a88d449,refuted); 0.33446082427016055::status(o_7fb080887d485a88d449,unknown).
0.20828733388887996::status(o_7fe29d277fa55cae5fc6,supported); 0::status(o_7fe29d277fa55cae5fc6,refuted); 0.79171266611112001::status(o_7fe29d277fa55cae5fc6,unknown).
1::status(o_803fd27cc8fb184ed1f0,supported); 0::status(o_803fd27cc8fb184ed1f0,refuted); 0::status(o_803fd27cc8fb184ed1f0,unknown).
1::status(o_8074d8c8add830483027,supported); 0::status(o_8074d8c8add830483027,refuted); 0::status(o_8074d8c8add830483027,unknown).
1::status(o_8089345792f1e7f0c3cf,supported); 0::status(o_8089345792f1e7f0c3cf,refuted); 0::status(o_8089345792f1e7f0c3cf,unknown).
0.19697684497381904::status(o_811d64b45024ef9f452f,supported); 0::status(o_811d64b45024ef9f452f,refuted); 0.80302315502618093::status(o_811d64b45024ef9f452f,unknown).
1::status(o_813c68fa7c9f6f54e2f9,supported); 0::status(o_813c68fa7c9f6f54e2f9,refuted); 0::status(o_813c68fa7c9f6f54e2f9,unknown).
1::status(o_8147183eb3fc7c8faf4d,supported); 0::status(o_8147183eb3fc7c8faf4d,refuted); 0::status(o_8147183eb3fc7c8faf4d,unknown).
4.2283380025764927e-05::status(o_815231a2d896d5b78c95,supported); 0::status(o_815231a2d896d5b78c95,refuted); 0.99995771661997424::status(o_815231a2d896d5b78c95,unknown).
1::status(o_8170d8aba1e36f3532f4,supported); 0::status(o_8170d8aba1e36f3532f4,refuted); 0::status(o_8170d8aba1e36f3532f4,unknown).
0.42259186025700812::status(o_81b70f7fd49741508db9,supported); 0::status(o_81b70f7fd49741508db9,refuted); 0.57740813974299188::status(o_81b70f7fd49741508db9,unknown).
1::status(o_81d6792452dfb5223419,supported); 0::status(o_81d6792452dfb5223419,refuted); 0::status(o_81d6792452dfb5223419,unknown).
1::status(o_81e23bef391605b03342,supported); 0::status(o_81e23bef391605b03342,refuted); 0::status(o_81e23bef391605b03342,unknown).
0::status(o_8245c9557609075d1254,supported); 1::status(o_8245c9557609075d1254,refuted); 0::status(o_8245c9557609075d1254,unknown).
0::status(o_8279128e56b6913bde0e,supported); 1::status(o_8279128e56b6913bde0e,refuted); 0::status(o_8279128e56b6913bde0e,unknown).
0.67014139818444596::status(o_82a4042b418ec673ede4,supported); 0::status(o_82a4042b418ec673ede4,refuted); 0.32985860181555404::status(o_82a4042b418ec673ede4,unknown).
1::status(o_82bbd48a4f6e398a8bed,supported); 0::status(o_82bbd48a4f6e398a8bed,refuted); 0::status(o_82bbd48a4f6e398a8bed,unknown).
1::status(o_82d3c180d0f41229c489,supported); 0::status(o_82d3c180d0f41229c489,refuted); 0::status(o_82d3c180d0f41229c489,unknown).
0.20453299792886978::status(o_82e4c8c1d9640cc8f6dc,supported); 0::status(o_82e4c8c1d9640cc8f6dc,refuted); 0.79546700207113019::status(o_82e4c8c1d9640cc8f6dc,unknown).
0.0018518617143854499::status(o_82ead0c37cf8d88466bf,supported); 0::status(o_82ead0c37cf8d88466bf,refuted); 0.99814813828561455::status(o_82ead0c37cf8d88466bf,unknown).
0.58027324992316753::status(o_831c724376ed891d5c06,supported); 0::status(o_831c724376ed891d5c06,refuted); 0.41972675007683247::status(o_831c724376ed891d5c06,unknown).
0.99506819248199463::status(o_831e848ea1787e7f0d40,supported); 0::status(o_831e848ea1787e7f0d40,refuted); 0.0049318075180053711::status(o_831e848ea1787e7f0d40,unknown).
1::status(o_83655bd54be7d72eda28,supported); 0::status(o_83655bd54be7d72eda28,refuted); 0::status(o_83655bd54be7d72eda28,unknown).
1::status(o_837ad0acca3f476f0e0e,supported); 0::status(o_837ad0acca3f476f0e0e,refuted); 0::status(o_837ad0acca3f476f0e0e,unknown).
0.00011422050738474354::status(o_837bc04c8c3e200fc177,supported); 0::status(o_837bc04c8c3e200fc177,refuted); 0.99988577949261526::status(o_837bc04c8c3e200fc177,unknown).
0.21776666236879091::status(o_83a507c35c6fa3c8ba31,supported); 0::status(o_83a507c35c6fa3c8ba31,refuted); 0.78223333763120906::status(o_83a507c35c6fa3c8ba31,unknown).
4.2283380025764927e-05::status(o_83d6e086f1e6f591cd80,supported); 0::status(o_83d6e086f1e6f591cd80,refuted); 0.99995771661997424::status(o_83d6e086f1e6f591cd80,unknown).
1::status(o_83d936f13cdca3e59e6c,supported); 0::status(o_83d936f13cdca3e59e6c,refuted); 0::status(o_83d936f13cdca3e59e6c,unknown).
1::status(o_8448ce9484ba108c05d2,supported); 0::status(o_8448ce9484ba108c05d2,refuted); 0::status(o_8448ce9484ba108c05d2,unknown).
0.54636852398171065::status(o_8455cf13ff83602b8d7a,supported); 0::status(o_8455cf13ff83602b8d7a,refuted); 0.45363147601828935::status(o_8455cf13ff83602b8d7a,unknown).
1::status(o_847be245a2f62b39c3e8,supported); 0::status(o_847be245a2f62b39c3e8,refuted); 0::status(o_847be245a2f62b39c3e8,unknown).
0.40917093839253943::status(o_84faafa5cb57bea66a95,supported); 0::status(o_84faafa5cb57bea66a95,refuted); 0.59082906160746052::status(o_84faafa5cb57bea66a95,unknown).
1::status(o_8509ef55adc33bf673e0,supported); 0::status(o_8509ef55adc33bf673e0,refuted); 0::status(o_8509ef55adc33bf673e0,unknown).
0.99007987976074219::status(o_853da64aa4711d55ca21,supported); 0::status(o_853da64aa4711d55ca21,refuted); 0.0099201202392578125::status(o_853da64aa4711d55ca21,unknown).
1::status(o_8540ecd929df9a4c6613,supported); 0::status(o_8540ecd929df9a4c6613,refuted); 0::status(o_8540ecd929df9a4c6613,unknown).
1::status(o_8582954a008614b11285,supported); 0::status(o_8582954a008614b11285,refuted); 0::status(o_8582954a008614b11285,unknown).
1::status(o_8589bd1f91c4cf7ea773,supported); 0::status(o_8589bd1f91c4cf7ea773,refuted); 0::status(o_8589bd1f91c4cf7ea773,unknown).
1::status(o_85ecace8c89fbf09d844,supported); 0::status(o_85ecace8c89fbf09d844,refuted); 0::status(o_85ecace8c89fbf09d844,unknown).
1::status(o_863ac15c051c41c6fb0e,supported); 0::status(o_863ac15c051c41c6fb0e,refuted); 0::status(o_863ac15c051c41c6fb0e,unknown).
0.096061237156391144::status(o_863ed4e97bf651e1e44c,supported); 0::status(o_863ed4e97bf651e1e44c,refuted); 0.90393876284360886::status(o_863ed4e97bf651e1e44c,unknown).
0.96754372119903564::status(o_8649ee2b8fb56fa387a2,supported); 0::status(o_8649ee2b8fb56fa387a2,refuted); 0.032456278800964355::status(o_8649ee2b8fb56fa387a2,unknown).
1::status(o_8651aa1952cad480cf99,supported); 0::status(o_8651aa1952cad480cf99,refuted); 0::status(o_8651aa1952cad480cf99,unknown).
1::status(o_86e5d30c3525e48daa85,supported); 0::status(o_86e5d30c3525e48daa85,refuted); 0::status(o_86e5d30c3525e48daa85,unknown).
0.0050932755693793297::status(o_8705912f65db6960a7da,supported); 0::status(o_8705912f65db6960a7da,refuted); 0.99490672443062067::status(o_8705912f65db6960a7da,unknown).
1::status(o_8754a2eb6f1632d3894e,supported); 0::status(o_8754a2eb6f1632d3894e,refuted); 0::status(o_8754a2eb6f1632d3894e,unknown).
0.21149467982393813::status(o_87886bde68ce53859ce7,supported); 0::status(o_87886bde68ce53859ce7,refuted); 0.7885053201760619::status(o_87886bde68ce53859ce7,unknown).
0.22309549152851105::status(o_87c6f779d2bf9d67f12f,supported); 0::status(o_87c6f779d2bf9d67f12f,refuted); 0.77690450847148895::status(o_87c6f779d2bf9d67f12f,unknown).
1::status(o_88312bff917834c6249f,supported); 0::status(o_88312bff917834c6249f,refuted); 0::status(o_88312bff917834c6249f,unknown).
1::status(o_8879f1449daf661265ba,supported); 0::status(o_8879f1449daf661265ba,refuted); 0::status(o_8879f1449daf661265ba,unknown).
1::status(o_888e296d3760e6649da5,supported); 0::status(o_888e296d3760e6649da5,refuted); 0::status(o_888e296d3760e6649da5,unknown).
1::status(o_88a8f4560471ac7e3f57,supported); 0::status(o_88a8f4560471ac7e3f57,refuted); 0::status(o_88a8f4560471ac7e3f57,unknown).
0::status(o_88aa1a732c8b38e524f8,supported); 1::status(o_88aa1a732c8b38e524f8,refuted); 0::status(o_88aa1a732c8b38e524f8,unknown).
1::status(o_88df8c090a5a7f3c3d3a,supported); 0::status(o_88df8c090a5a7f3c3d3a,refuted); 0::status(o_88df8c090a5a7f3c3d3a,unknown).
0.040284478738328675::status(o_890a32d7b2641f32c5ec,supported); 0::status(o_890a32d7b2641f32c5ec,refuted); 0.95971552126167137::status(o_890a32d7b2641f32c5ec,unknown).
1::status(o_891f853b75118d720452,supported); 0::status(o_891f853b75118d720452,refuted); 0::status(o_891f853b75118d720452,unknown).
1::status(o_89498c0173051a3cfa1d,supported); 0::status(o_89498c0173051a3cfa1d,refuted); 0::status(o_89498c0173051a3cfa1d,unknown).
1::status(o_894ed44e00af1de02d98,supported); 0::status(o_894ed44e00af1de02d98,refuted); 0::status(o_894ed44e00af1de02d98,unknown).
0.62198611454551467::status(o_895158f28f17fb1a505b,supported); 0::status(o_895158f28f17fb1a505b,refuted); 0.37801388545448533::status(o_895158f28f17fb1a505b,unknown).
0.001097465050406754::status(o_89606d816f92de7028e9,supported); 0::status(o_89606d816f92de7028e9,refuted); 0.99890253494959325::status(o_89606d816f92de7028e9,unknown).
0::status(o_898b1f53a472641e6346,supported); 1::status(o_898b1f53a472641e6346,refuted); 0::status(o_898b1f53a472641e6346,unknown).
1::status(o_8990b558b754924c8135,supported); 0::status(o_8990b558b754924c8135,refuted); 0::status(o_8990b558b754924c8135,unknown).
1::status(o_899f6d1e9971d66ff22a,supported); 0::status(o_899f6d1e9971d66ff22a,refuted); 0::status(o_899f6d1e9971d66ff22a,unknown).
1::status(o_8a018336087166fa1fcb,supported); 0::status(o_8a018336087166fa1fcb,refuted); 0::status(o_8a018336087166fa1fcb,unknown).
1::status(o_8a26b3ed952a1c4018b0,supported); 0::status(o_8a26b3ed952a1c4018b0,refuted); 0::status(o_8a26b3ed952a1c4018b0,unknown).
0.99213320016860962::status(o_8a8d039de2ae895fabc3,supported); 0::status(o_8a8d039de2ae895fabc3,refuted); 0.0078667998313903809::status(o_8a8d039de2ae895fabc3,unknown).
1::status(o_8ad74737af466d05ed74,supported); 0::status(o_8ad74737af466d05ed74,refuted); 0::status(o_8ad74737af466d05ed74,unknown).
0.17079248176971215::status(o_8afa94d64229ee7194e7,supported); 0::status(o_8afa94d64229ee7194e7,refuted); 0.82920751823028782::status(o_8afa94d64229ee7194e7,unknown).
0.56199225726309787::status(o_8b2e8ab5d0ad3a3f0943,supported); 0::status(o_8b2e8ab5d0ad3a3f0943,refuted); 0.43800774273690213::status(o_8b2e8ab5d0ad3a3f0943,unknown).
0.0004814279091078788::status(o_8bbb40edd8fdd15f34b1,supported); 0::status(o_8bbb40edd8fdd15f34b1,refuted); 0.99951857209089212::status(o_8bbb40edd8fdd15f34b1,unknown).
0.1732276127250354::status(o_8bdfa29d3cfe545d6aa5,supported); 0::status(o_8bdfa29d3cfe545d6aa5,refuted); 0.8267723872749646::status(o_8bdfa29d3cfe545d6aa5,unknown).
1::status(o_8bec9fddfc0c3c190cbe,supported); 0::status(o_8bec9fddfc0c3c190cbe,refuted); 0::status(o_8bec9fddfc0c3c190cbe,unknown).
1::status(o_8bf56445f49d06603852,supported); 0::status(o_8bf56445f49d06603852,refuted); 0::status(o_8bf56445f49d06603852,unknown).
0::status(o_8c0e46800b777240f572,supported); 1::status(o_8c0e46800b777240f572,refuted); 0::status(o_8c0e46800b777240f572,unknown).
1::status(o_8c22c3c59e4d458a41fa,supported); 0::status(o_8c22c3c59e4d458a41fa,refuted); 0::status(o_8c22c3c59e4d458a41fa,unknown).
1::status(o_8c2d7715ca2f3bb57ae1,supported); 0::status(o_8c2d7715ca2f3bb57ae1,refuted); 0::status(o_8c2d7715ca2f3bb57ae1,unknown).
1::status(o_8c702a2a68f06f9afbd0,supported); 0::status(o_8c702a2a68f06f9afbd0,refuted); 0::status(o_8c702a2a68f06f9afbd0,unknown).
0::status(o_8c86a75ab4104376f2d2,supported); 1::status(o_8c86a75ab4104376f2d2,refuted); 0::status(o_8c86a75ab4104376f2d2,unknown).
0::status(o_8cadb48d16c9918b926c,supported); 1::status(o_8cadb48d16c9918b926c,refuted); 0::status(o_8cadb48d16c9918b926c,unknown).
0::status(o_8d356fc40911012e5651,supported); 1::status(o_8d356fc40911012e5651,refuted); 0::status(o_8d356fc40911012e5651,unknown).
0.23487731540459511::status(o_8d7cfa0bd427541098c4,supported); 0::status(o_8d7cfa0bd427541098c4,refuted); 0.76512268459540489::status(o_8d7cfa0bd427541098c4,unknown).
0.0010018589673563838::status(o_8dd5253489bebc0b1eaa,supported); 0::status(o_8dd5253489bebc0b1eaa,refuted); 0.99899814103264362::status(o_8dd5253489bebc0b1eaa,unknown).
0.3341615115170195::status(o_8e1ae51055aca74517de,supported); 0::status(o_8e1ae51055aca74517de,refuted); 0.66583848848298044::status(o_8e1ae51055aca74517de,unknown).
1::status(o_8e738396ab0d068c07b0,supported); 0::status(o_8e738396ab0d068c07b0,refuted); 0::status(o_8e738396ab0d068c07b0,unknown).
0::status(o_8e82df60feb90809d347,supported); 1::status(o_8e82df60feb90809d347,refuted); 0::status(o_8e82df60feb90809d347,unknown).
0.988739013671875::status(o_8ee67e7ec9d1900cc0ab,supported); 0::status(o_8ee67e7ec9d1900cc0ab,refuted); 0.011260986328125::status(o_8ee67e7ec9d1900cc0ab,unknown).
0.0060011227615177631::status(o_8f5e5f3725a73e3d21df,supported); 0::status(o_8f5e5f3725a73e3d21df,refuted); 0.99399887723848224::status(o_8f5e5f3725a73e3d21df,unknown).
0::status(o_8f89266ed6586f14ff07,supported); 1::status(o_8f89266ed6586f14ff07,refuted); 0::status(o_8f89266ed6586f14ff07,unknown).
1::status(o_8fbff6ccea84adc7ed12,supported); 0::status(o_8fbff6ccea84adc7ed12,refuted); 0::status(o_8fbff6ccea84adc7ed12,unknown).
1::status(o_901a7085deb40c961140,supported); 0::status(o_901a7085deb40c961140,refuted); 0::status(o_901a7085deb40c961140,unknown).
0.58011855578135862::status(o_90216118768ee53261e7,supported); 0::status(o_90216118768ee53261e7,refuted); 0.41988144421864138::status(o_90216118768ee53261e7,unknown).
1::status(o_903d3c5d25ed624913ca,supported); 0::status(o_903d3c5d25ed624913ca,refuted); 0::status(o_903d3c5d25ed624913ca,unknown).
1::status(o_90b2e6464fe6a7762bc5,supported); 0::status(o_90b2e6464fe6a7762bc5,refuted); 0::status(o_90b2e6464fe6a7762bc5,unknown).
1::status(o_91a56628d4ea87c285c2,supported); 0::status(o_91a56628d4ea87c285c2,refuted); 0::status(o_91a56628d4ea87c285c2,unknown).
0.99738341569900513::status(o_91ef6f91fb3a040e1388,supported); 0::status(o_91ef6f91fb3a040e1388,refuted); 0.002616584300994873::status(o_91ef6f91fb3a040e1388,unknown).
1::status(o_91f192664ecf4a3fba34,supported); 0::status(o_91f192664ecf4a3fba34,refuted); 0::status(o_91f192664ecf4a3fba34,unknown).
0.17949568202229413::status(o_93a517dea00ddf3bb51f,supported); 0::status(o_93a517dea00ddf3bb51f,refuted); 0.82050431797770584::status(o_93a517dea00ddf3bb51f,unknown).
0.0018518617143854499::status(o_93dca9ca614b3f400d69,supported); 0::status(o_93dca9ca614b3f400d69,refuted); 0.99814813828561455::status(o_93dca9ca614b3f400d69,unknown).
0.35481984999927751::status(o_93df643ed94feb17640f,supported); 0::status(o_93df643ed94feb17640f,refuted); 0.64518015000072249::status(o_93df643ed94feb17640f,unknown).
4.394259667606093e-05::status(o_940420087e1c9625160f,supported); 0::status(o_940420087e1c9625160f,refuted); 0.99995605740332394::status(o_940420087e1c9625160f,unknown).
0.21915586922954955::status(o_94102236461d358ea7a8,supported); 0::status(o_94102236461d358ea7a8,refuted); 0.78084413077045045::status(o_94102236461d358ea7a8,unknown).
0.23394372641207595::status(o_94560e7f3dbd9339c9ab,supported); 0::status(o_94560e7f3dbd9339c9ab,refuted); 0.76605627358792405::status(o_94560e7f3dbd9339c9ab,unknown).
1::status(o_94688c8225449e6c6486,supported); 0::status(o_94688c8225449e6c6486,refuted); 0::status(o_94688c8225449e6c6486,unknown).
1::status(o_94899b7b31651c05575e,supported); 0::status(o_94899b7b31651c05575e,refuted); 0::status(o_94899b7b31651c05575e,unknown).
0.6027421409056315::status(o_94f261b8fa32bc37ab16,supported); 0::status(o_94f261b8fa32bc37ab16,refuted); 0.3972578590943685::status(o_94f261b8fa32bc37ab16,unknown).
1::status(o_94f6be4ebb1742c9b932,supported); 0::status(o_94f6be4ebb1742c9b932,refuted); 0::status(o_94f6be4ebb1742c9b932,unknown).
1::status(o_94f99dcbc4a137dbb4df,supported); 0::status(o_94f99dcbc4a137dbb4df,refuted); 0::status(o_94f99dcbc4a137dbb4df,unknown).
1::status(o_95009ef7d75cf3937cb7,supported); 0::status(o_95009ef7d75cf3937cb7,refuted); 0::status(o_95009ef7d75cf3937cb7,unknown).
1::status(o_95082c8251807b896d1e,supported); 0::status(o_95082c8251807b896d1e,refuted); 0::status(o_95082c8251807b896d1e,unknown).
2.2375324988388456e-05::status(o_95238e269fc803ada4b4,supported); 0::status(o_95238e269fc803ada4b4,refuted); 0.99997762467501161::status(o_95238e269fc803ada4b4,unknown).
0.99007987976074219::status(o_9587f71948ac3e900a38,supported); 0::status(o_9587f71948ac3e900a38,refuted); 0.0099201202392578125::status(o_9587f71948ac3e900a38,unknown).
0.51267369618544434::status(o_96069de593c1d7fdae19,supported); 0::status(o_96069de593c1d7fdae19,refuted); 0.48732630381455566::status(o_96069de593c1d7fdae19,unknown).
0.17266773513180428::status(o_96102c5d08ec4802912a,supported); 0::status(o_96102c5d08ec4802912a,refuted); 0.82733226486819578::status(o_96102c5d08ec4802912a,unknown).
1::status(o_96167a7123b6c2e9f0ec,supported); 0::status(o_96167a7123b6c2e9f0ec,refuted); 0::status(o_96167a7123b6c2e9f0ec,unknown).
1::status(o_965ecb77a6978bc617ab,supported); 0::status(o_965ecb77a6978bc617ab,refuted); 0::status(o_965ecb77a6978bc617ab,unknown).
1::status(o_9691d99a8c76e81bf837,supported); 0::status(o_9691d99a8c76e81bf837,refuted); 0::status(o_9691d99a8c76e81bf837,unknown).
0.43881929352964893::status(o_96bb13bf87d14c403272,supported); 0::status(o_96bb13bf87d14c403272,refuted); 0.56118070647035112::status(o_96bb13bf87d14c403272,unknown).
0.001097465050406754::status(o_96d6411a747075bc852a,supported); 0::status(o_96d6411a747075bc852a,refuted); 0.99890253494959325::status(o_96d6411a747075bc852a,unknown).
0.99660646915435791::status(o_975f5231325659ca3bed,supported); 0::status(o_975f5231325659ca3bed,refuted); 0.0033935308456420898::status(o_975f5231325659ca3bed,unknown).
0.32702082896239254::status(o_9769c3e96d7113c579ae,supported); 0::status(o_9769c3e96d7113c579ae,refuted); 0.6729791710376074::status(o_9769c3e96d7113c579ae,unknown).
0.60430598979781869::status(o_9773d5107f8b856a1adb,supported); 0::status(o_9773d5107f8b856a1adb,refuted); 0.39569401020218131::status(o_9773d5107f8b856a1adb,unknown).
1::status(o_979841b6f049d5e81c68,supported); 0::status(o_979841b6f049d5e81c68,refuted); 0::status(o_979841b6f049d5e81c68,unknown).
1::status(o_97a0c04e32f0f1927307,supported); 0::status(o_97a0c04e32f0f1927307,refuted); 0::status(o_97a0c04e32f0f1927307,unknown).
1::status(o_97ea8e2ea18d65f02c6a,supported); 0::status(o_97ea8e2ea18d65f02c6a,refuted); 0::status(o_97ea8e2ea18d65f02c6a,unknown).
1::status(o_9801df7066ee4a3a7426,supported); 0::status(o_9801df7066ee4a3a7426,refuted); 0::status(o_9801df7066ee4a3a7426,unknown).
1::status(o_9805547594a986be76df,supported); 0::status(o_9805547594a986be76df,refuted); 0::status(o_9805547594a986be76df,unknown).
1::status(o_9818e77fc95dc64d61a3,supported); 0::status(o_9818e77fc95dc64d61a3,refuted); 0::status(o_9818e77fc95dc64d61a3,unknown).
0.56174170970916748::status(o_98225b54cc668445b322,supported); 0::status(o_98225b54cc668445b322,refuted); 0.43825829029083252::status(o_98225b54cc668445b322,unknown).
0.99547606706619263::status(o_9826c61f999beb568501,supported); 0::status(o_9826c61f999beb568501,refuted); 0.004523932933807373::status(o_9826c61f999beb568501,unknown).
0.002602787222713232::status(o_985e32de6cb09ac4b4a6,supported); 0::status(o_985e32de6cb09ac4b4a6,refuted); 0.99739721277728677::status(o_985e32de6cb09ac4b4a6,unknown).
0.41286338869577466::status(o_986a15a0a84721a1f9b5,supported); 0::status(o_986a15a0a84721a1f9b5,refuted); 0.58713661130422534::status(o_986a15a0a84721a1f9b5,unknown).
0.99738341569900513::status(o_987ef028bb2406b4f5ef,supported); 0::status(o_987ef028bb2406b4f5ef,refuted); 0.002616584300994873::status(o_987ef028bb2406b4f5ef,unknown).
1::status(o_98db8628004b5feefd23,supported); 0::status(o_98db8628004b5feefd23,refuted); 0::status(o_98db8628004b5feefd23,unknown).
0.17620717593138152::status(o_99bef5e590b9a7457e9d,supported); 0::status(o_99bef5e590b9a7457e9d,refuted); 0.82379282406861853::status(o_99bef5e590b9a7457e9d,unknown).
0.57482654283530843::status(o_9a6280fbb0269d385b43,supported); 0::status(o_9a6280fbb0269d385b43,refuted); 0.42517345716469157::status(o_9a6280fbb0269d385b43,unknown).
0.039551112800836563::status(o_9a8c105a20daacb8d5da,supported); 0::status(o_9a8c105a20daacb8d5da,refuted); 0.96044888719916344::status(o_9a8c105a20daacb8d5da,unknown).
0.19697684497381904::status(o_9b01bf4b59307623c76c,supported); 0::status(o_9b01bf4b59307623c76c,refuted); 0.80302315502618093::status(o_9b01bf4b59307623c76c,unknown).
1::status(o_9b0c16661c9475878347,supported); 0::status(o_9b0c16661c9475878347,refuted); 0::status(o_9b0c16661c9475878347,unknown).
0.22048295676347288::status(o_9b2ba101eedc382abc28,supported); 0::status(o_9b2ba101eedc382abc28,refuted); 0.77951704323652715::status(o_9b2ba101eedc382abc28,unknown).
1::status(o_9b35d21ef720404483ac,supported); 0::status(o_9b35d21ef720404483ac,refuted); 0::status(o_9b35d21ef720404483ac,unknown).
1::status(o_9bd7f7fd4458d8537db8,supported); 0::status(o_9bd7f7fd4458d8537db8,refuted); 0::status(o_9bd7f7fd4458d8537db8,unknown).
1::status(o_9be155994cd0a4efa5f1,supported); 0::status(o_9be155994cd0a4efa5f1,refuted); 0::status(o_9be155994cd0a4efa5f1,unknown).
0.41969079237416868::status(o_9c0bc07f26c7673adcbd,supported); 0::status(o_9c0bc07f26c7673adcbd,refuted); 0.58030920762583138::status(o_9c0bc07f26c7673adcbd,unknown).
0.66501856022478645::status(o_9c5f776b396a8173bf15,supported); 0::status(o_9c5f776b396a8173bf15,refuted); 0.33498143977521355::status(o_9c5f776b396a8173bf15,unknown).
0.72335165686353298::status(o_9c8bfa8f1f3de7e45ace,supported); 0::status(o_9c8bfa8f1f3de7e45ace,refuted); 0.27664834313646702::status(o_9c8bfa8f1f3de7e45ace,unknown).
0.0042693153955042362::status(o_9c996d0d25ffc6722380,supported); 0::status(o_9c996d0d25ffc6722380,refuted); 0.99573068460449576::status(o_9c996d0d25ffc6722380,unknown).
1::status(o_9d214bcfea904b0f2580,supported); 0::status(o_9d214bcfea904b0f2580,refuted); 0::status(o_9d214bcfea904b0f2580,unknown).
0.96754372119903564::status(o_9da1edaecfe98641b294,supported); 0::status(o_9da1edaecfe98641b294,refuted); 0.032456278800964355::status(o_9da1edaecfe98641b294,unknown).
1::status(o_9db8c84379d107580a2e,supported); 0::status(o_9db8c84379d107580a2e,refuted); 0::status(o_9db8c84379d107580a2e,unknown).
0.99524873495101929::status(o_9e3901a97ecb32b80ef2,supported); 0::status(o_9e3901a97ecb32b80ef2,refuted); 0.0047512650489807129::status(o_9e3901a97ecb32b80ef2,unknown).
0.096061237156391144::status(o_9e488ab794c3ecc9d519,supported); 0::status(o_9e488ab794c3ecc9d519,refuted); 0.90393876284360886::status(o_9e488ab794c3ecc9d519,unknown).
0::status(o_9e4d77a4f5c14166f0de,supported); 1::status(o_9e4d77a4f5c14166f0de,refuted); 0::status(o_9e4d77a4f5c14166f0de,unknown).
1::status(o_9e597c41be33369f1ca2,supported); 0::status(o_9e597c41be33369f1ca2,refuted); 0::status(o_9e597c41be33369f1ca2,unknown).
1::status(o_9e7c08cf4d93d74ef9cc,supported); 0::status(o_9e7c08cf4d93d74ef9cc,refuted); 0::status(o_9e7c08cf4d93d74ef9cc,unknown).
1::status(o_9ea3ad69f29464758cb4,supported); 0::status(o_9ea3ad69f29464758cb4,refuted); 0::status(o_9ea3ad69f29464758cb4,unknown).
1::status(o_9ea8f089ba0e5881a538,supported); 0::status(o_9ea8f089ba0e5881a538,refuted); 0::status(o_9ea8f089ba0e5881a538,unknown).
1::status(o_9ee589f86c1d037995ef,supported); 0::status(o_9ee589f86c1d037995ef,refuted); 0::status(o_9ee589f86c1d037995ef,unknown).
1::status(o_9ef7603bd61a3cd1162b,supported); 0::status(o_9ef7603bd61a3cd1162b,refuted); 0::status(o_9ef7603bd61a3cd1162b,unknown).
0.0018071738304570317::status(o_9f04e1728f0131f2a986,supported); 0::status(o_9f04e1728f0131f2a986,refuted); 0.99819282616954297::status(o_9f04e1728f0131f2a986,unknown).
0::status(o_9f3628d5487121818b7e,supported); 1::status(o_9f3628d5487121818b7e,refuted); 0::status(o_9f3628d5487121818b7e,unknown).
0.00027316782507114112::status(o_9f4d3a3a00a6d6c8d19f,supported); 0::status(o_9f4d3a3a00a6d6c8d19f,refuted); 0.99972683217492886::status(o_9f4d3a3a00a6d6c8d19f,unknown).
1::status(o_9f6593e389bfdab5f963,supported); 0::status(o_9f6593e389bfdab5f963,refuted); 0::status(o_9f6593e389bfdab5f963,unknown).
0::status(o_9faab04386fc89f65ed1,supported); 1::status(o_9faab04386fc89f65ed1,refuted); 0::status(o_9faab04386fc89f65ed1,unknown).
1::status(o_9fb586b2b673b5832def,supported); 0::status(o_9fb586b2b673b5832def,refuted); 0::status(o_9fb586b2b673b5832def,unknown).
1::status(o_9fce83ed2f2d9c5c3dcc,supported); 0::status(o_9fce83ed2f2d9c5c3dcc,refuted); 0::status(o_9fce83ed2f2d9c5c3dcc,unknown).
1::status(o_a000b1a83a8285c61c3a,supported); 0::status(o_a000b1a83a8285c61c3a,refuted); 0::status(o_a000b1a83a8285c61c3a,unknown).
1::status(o_a105a99b1d10b026cfdf,supported); 0::status(o_a105a99b1d10b026cfdf,refuted); 0::status(o_a105a99b1d10b026cfdf,unknown).
1::status(o_a1c6c4f3d6f09b403b85,supported); 0::status(o_a1c6c4f3d6f09b403b85,refuted); 0::status(o_a1c6c4f3d6f09b403b85,unknown).
0.0044489046558737755::status(o_a1cacc5a8516f0025956,supported); 0::status(o_a1cacc5a8516f0025956,refuted); 0.99555109534412622::status(o_a1cacc5a8516f0025956,unknown).
0::status(o_a1cad329f5c1cf4ffc48,supported); 1::status(o_a1cad329f5c1cf4ffc48,refuted); 0::status(o_a1cad329f5c1cf4ffc48,unknown).
0.067158885300159454::status(o_a1d564c8d71011994ec5,supported); 0::status(o_a1d564c8d71011994ec5,refuted); 0.93284111469984055::status(o_a1d564c8d71011994ec5,unknown).
0.31518975007828343::status(o_a1f401bcd892cdf9cf10,supported); 0::status(o_a1f401bcd892cdf9cf10,refuted); 0.68481024992171657::status(o_a1f401bcd892cdf9cf10,unknown).
1::status(o_a1ff27aeb67294210c2c,supported); 0::status(o_a1ff27aeb67294210c2c,refuted); 0::status(o_a1ff27aeb67294210c2c,unknown).
1::status(o_a2c17c89266c5946d2f0,supported); 0::status(o_a2c17c89266c5946d2f0,refuted); 0::status(o_a2c17c89266c5946d2f0,unknown).
0.3336655695722176::status(o_a332867ed37ac3c0a6fd,supported); 0::status(o_a332867ed37ac3c0a6fd,refuted); 0.6663344304277824::status(o_a332867ed37ac3c0a6fd,unknown).
1::status(o_a3a4e1a87af149f975dc,supported); 0::status(o_a3a4e1a87af149f975dc,refuted); 0::status(o_a3a4e1a87af149f975dc,unknown).
0.55373503006441438::status(o_a3a80f5b35f8c45d1509,supported); 0::status(o_a3a80f5b35f8c45d1509,refuted); 0.44626496993558562::status(o_a3a80f5b35f8c45d1509,unknown).
0.54567309306371836::status(o_a3a88c8517287f14d09f,supported); 0::status(o_a3a88c8517287f14d09f,refuted); 0.45432690693628164::status(o_a3a88c8517287f14d09f,unknown).
0::status(o_a443ab6f8b75c4009ed5,supported); 1::status(o_a443ab6f8b75c4009ed5,refuted); 0::status(o_a443ab6f8b75c4009ed5,unknown).
0.70547658205032349::status(o_a456230c045faf540dde,supported); 0::status(o_a456230c045faf540dde,refuted); 0.29452341794967651::status(o_a456230c045faf540dde,unknown).
0.225900868017505::status(o_a5160bf4e372cd9792c6,supported); 0::status(o_a5160bf4e372cd9792c6,refuted); 0.77409913198249503::status(o_a5160bf4e372cd9792c6,unknown).
0.002940004225820303::status(o_a52b8462a8fe02f16c14,supported); 0::status(o_a52b8462a8fe02f16c14,refuted); 0.9970599957741797::status(o_a52b8462a8fe02f16c14,unknown).
1::status(o_a53f289362ec1bbcd8b7,supported); 0::status(o_a53f289362ec1bbcd8b7,refuted); 0::status(o_a53f289362ec1bbcd8b7,unknown).
1::status(o_a5d49525956c8bb07c82,supported); 0::status(o_a5d49525956c8bb07c82,refuted); 0::status(o_a5d49525956c8bb07c82,unknown).
0.47045918946799326::status(o_a5f4b27a7bded40186de,supported); 0::status(o_a5f4b27a7bded40186de,refuted); 0.52954081053200674::status(o_a5f4b27a7bded40186de,unknown).
0.17032217937338145::status(o_a60f64901ce66b1dbe1e,supported); 0::status(o_a60f64901ce66b1dbe1e,refuted); 0.82967782062661855::status(o_a60f64901ce66b1dbe1e,unknown).
0.35721692502030078::status(o_a63b26eec5ba7afe02b2,supported); 0::status(o_a63b26eec5ba7afe02b2,refuted); 0.64278307497969922::status(o_a63b26eec5ba7afe02b2,unknown).
1::status(o_a63bf7070875552f6d21,supported); 0::status(o_a63bf7070875552f6d21,refuted); 0::status(o_a63bf7070875552f6d21,unknown).
1::status(o_a64a4ede3b0eb99550bd,supported); 0::status(o_a64a4ede3b0eb99550bd,refuted); 0::status(o_a64a4ede3b0eb99550bd,unknown).
1::status(o_a664dd21ffd4c146c946,supported); 0::status(o_a664dd21ffd4c146c946,refuted); 0::status(o_a664dd21ffd4c146c946,unknown).
0.41473562707187001::status(o_a6eb05b59e76c238828f,supported); 0::status(o_a6eb05b59e76c238828f,refuted); 0.58526437292812994::status(o_a6eb05b59e76c238828f,unknown).
0.26720590754960177::status(o_a71f4ef44eba9fc6cb0e,supported); 0::status(o_a71f4ef44eba9fc6cb0e,refuted); 0.73279409245039817::status(o_a71f4ef44eba9fc6cb0e,unknown).
1::status(o_a71f75cacf8a7d59e3ad,supported); 0::status(o_a71f75cacf8a7d59e3ad,refuted); 0::status(o_a71f75cacf8a7d59e3ad,unknown).
0.61694091558456421::status(o_a847bc5016b667b9083c,supported); 0::status(o_a847bc5016b667b9083c,refuted); 0.38305908441543579::status(o_a847bc5016b667b9083c,unknown).
0.65947310145431026::status(o_a8542fbc1961c95928dc,supported); 0::status(o_a8542fbc1961c95928dc,refuted); 0.34052689854568974::status(o_a8542fbc1961c95928dc,unknown).
1::status(o_a861a84daf7bf7442aa1,supported); 0::status(o_a861a84daf7bf7442aa1,refuted); 0::status(o_a861a84daf7bf7442aa1,unknown).
1::status(o_a8b5da03e7ff284e8699,supported); 0::status(o_a8b5da03e7ff284e8699,refuted); 0::status(o_a8b5da03e7ff284e8699,unknown).
0.021092737093567848::status(o_a8bdfd4aee684bc7a893,supported); 0::status(o_a8bdfd4aee684bc7a893,refuted); 0.97890726290643215::status(o_a8bdfd4aee684bc7a893,unknown).
0.0013008691603317857::status(o_a9970893fae10dea967c,supported); 0::status(o_a9970893fae10dea967c,refuted); 0.99869913083966821::status(o_a9970893fae10dea967c,unknown).
1::status(o_a9c3d4b5a6a78fc0c800,supported); 0::status(o_a9c3d4b5a6a78fc0c800,refuted); 0::status(o_a9c3d4b5a6a78fc0c800,unknown).
0.00044824578799307346::status(o_a9ddb306244e1e07f205,supported); 0::status(o_a9ddb306244e1e07f205,refuted); 0.99955175421200693::status(o_a9ddb306244e1e07f205,unknown).
0.60488887780861078::status(o_aa09cc56431805dbf5f0,supported); 0::status(o_aa09cc56431805dbf5f0,refuted); 0.39511112219138922::status(o_aa09cc56431805dbf5f0,unknown).
0::status(o_aa4896e6bedec74068ac,supported); 1::status(o_aa4896e6bedec74068ac,refuted); 0::status(o_aa4896e6bedec74068ac,unknown).
0.22309549152851105::status(o_aa54a5c1bc11ed054e90,supported); 0::status(o_aa54a5c1bc11ed054e90,refuted); 0.77690450847148895::status(o_aa54a5c1bc11ed054e90,unknown).
0.31271256201733877::status(o_ab78405154f59670a15b,supported); 0::status(o_ab78405154f59670a15b,refuted); 0.68728743798266123::status(o_ab78405154f59670a15b,unknown).
0.74738532304763794::status(o_abbf600a16b903392499,supported); 0::status(o_abbf600a16b903392499,refuted); 0.25261467695236206::status(o_abbf600a16b903392499,unknown).
0.99726450443267822::status(o_ac15488f0ff53b9b43c6,supported); 0::status(o_ac15488f0ff53b9b43c6,refuted); 0.0027354955673217773::status(o_ac15488f0ff53b9b43c6,unknown).
0.72886959124827455::status(o_ac1860d8c2e650b4f592,supported); 0::status(o_ac1860d8c2e650b4f592,refuted); 0.27113040875172545::status(o_ac1860d8c2e650b4f592,unknown).
0.49295832610057155::status(o_ac494f7e5861f20da9aa,supported); 0::status(o_ac494f7e5861f20da9aa,refuted); 0.50704167389942845::status(o_ac494f7e5861f20da9aa,unknown).
0.17727372387088441::status(o_ac518f68b190c18d5168,supported); 0::status(o_ac518f68b190c18d5168,refuted); 0.82272627612911564::status(o_ac518f68b190c18d5168,unknown).
1::status(o_acb7df52b1aac321db9c,supported); 0::status(o_acb7df52b1aac321db9c,refuted); 0::status(o_acb7df52b1aac321db9c,unknown).
0.48092911277113626::status(o_acfa28449ce40418c684,supported); 0::status(o_acfa28449ce40418c684,refuted); 0.51907088722886374::status(o_acfa28449ce40418c684,unknown).
1::status(o_ad198bdcb579bc4ac533,supported); 0::status(o_ad198bdcb579bc4ac533,refuted); 0::status(o_ad198bdcb579bc4ac533,unknown).
0::status(o_ad270d0bba0f02906684,supported); 1::status(o_ad270d0bba0f02906684,refuted); 0::status(o_ad270d0bba0f02906684,unknown).
1::status(o_ad28a0fef7501f900959,supported); 0::status(o_ad28a0fef7501f900959,refuted); 0::status(o_ad28a0fef7501f900959,unknown).
1::status(o_ad515c2cab6f8e2eba96,supported); 0::status(o_ad515c2cab6f8e2eba96,refuted); 0::status(o_ad515c2cab6f8e2eba96,unknown).
1::status(o_ada7dddae314288a80e4,supported); 0::status(o_ada7dddae314288a80e4,refuted); 0::status(o_ada7dddae314288a80e4,unknown).
0.14585956196848071::status(o_ae073b7b1c01be206191,supported); 0::status(o_ae073b7b1c01be206191,refuted); 0.85414043803151929::status(o_ae073b7b1c01be206191,unknown).
0.63056268109834379::status(o_ae956e35ebe3ab49ed4f,supported); 0::status(o_ae956e35ebe3ab49ed4f,refuted); 0.36943731890165621::status(o_ae956e35ebe3ab49ed4f,unknown).
0.98928332328796387::status(o_af3c0f52a89aa928e33a,supported); 0::status(o_af3c0f52a89aa928e33a,refuted); 0.010716676712036133::status(o_af3c0f52a89aa928e33a,unknown).
1::status(o_af663c4cce7eee55ceee,supported); 0::status(o_af663c4cce7eee55ceee,refuted); 0::status(o_af663c4cce7eee55ceee,unknown).
0.0023976406082510948::status(o_aff7145314f3a0bd408c,supported); 0::status(o_aff7145314f3a0bd408c,refuted); 0.99760235939174891::status(o_aff7145314f3a0bd408c,unknown).
0.15634080606225739::status(o_b01ab74324e6cb68c66a,supported); 0::status(o_b01ab74324e6cb68c66a,refuted); 0.84365919393774258::status(o_b01ab74324e6cb68c66a,unknown).
0::status(o_b0276694968e0c63f518,supported); 1::status(o_b0276694968e0c63f518,refuted); 0::status(o_b0276694968e0c63f518,unknown).
1::status(o_b0920e19405a033d6046,supported); 0::status(o_b0920e19405a033d6046,refuted); 0::status(o_b0920e19405a033d6046,unknown).
0.55604892172959974::status(o_b0978ff4ff104df4cc09,supported); 0::status(o_b0978ff4ff104df4cc09,refuted); 0.44395107827040026::status(o_b0978ff4ff104df4cc09,unknown).
0.55372391428368573::status(o_b0b4e1d706573255ed9a,supported); 0::status(o_b0b4e1d706573255ed9a,refuted); 0.44627608571631427::status(o_b0b4e1d706573255ed9a,unknown).
1::status(o_b0e8bca2d14335cf2d09,supported); 0::status(o_b0e8bca2d14335cf2d09,refuted); 0::status(o_b0e8bca2d14335cf2d09,unknown).
0::status(o_b10425345588ad700a70,supported); 1::status(o_b10425345588ad700a70,refuted); 0::status(o_b10425345588ad700a70,unknown).
0::status(o_b111b45648a53c82e655,supported); 1::status(o_b111b45648a53c82e655,refuted); 0::status(o_b111b45648a53c82e655,unknown).
1::status(o_b1468347bd908ffb7f58,supported); 0::status(o_b1468347bd908ffb7f58,refuted); 0::status(o_b1468347bd908ffb7f58,unknown).
0.00048713211435824633::status(o_b197e360bc252fdf5fc1,supported); 0::status(o_b197e360bc252fdf5fc1,refuted); 0.99951286788564175::status(o_b197e360bc252fdf5fc1,unknown).
0.99887460470199585::status(o_b1a091d1b7e890a84d71,supported); 0::status(o_b1a091d1b7e890a84d71,refuted); 0.0011253952980041504::status(o_b1a091d1b7e890a84d71,unknown).
0::status(o_b1a7fb8e32e341df1f36,supported); 1::status(o_b1a7fb8e32e341df1f36,refuted); 0::status(o_b1a7fb8e32e341df1f36,unknown).
0.00012811402848456055::status(o_b1cbcc15186303e65d12,supported); 0::status(o_b1cbcc15186303e65d12,refuted); 0.99987188597151544::status(o_b1cbcc15186303e65d12,unknown).
1::status(o_b23002bbfbacc338f218,supported); 0::status(o_b23002bbfbacc338f218,refuted); 0::status(o_b23002bbfbacc338f218,unknown).
0.48062722102977179::status(o_b26e9c91a61e4acd664f,supported); 0::status(o_b26e9c91a61e4acd664f,refuted); 0.51937277897022827::status(o_b26e9c91a61e4acd664f,unknown).
1::status(o_b283f14827e32875a668,supported); 0::status(o_b283f14827e32875a668,refuted); 0::status(o_b283f14827e32875a668,unknown).
1::status(o_b2cf84aadfd92e4de12f,supported); 0::status(o_b2cf84aadfd92e4de12f,refuted); 0::status(o_b2cf84aadfd92e4de12f,unknown).
0.99660646915435791::status(o_b328e9ca52ef1bfa898c,supported); 0::status(o_b328e9ca52ef1bfa898c,refuted); 0.0033935308456420898::status(o_b328e9ca52ef1bfa898c,unknown).
0.29045807650480537::status(o_b374fb746bec73cde178,supported); 0::status(o_b374fb746bec73cde178,refuted); 0.70954192349519463::status(o_b374fb746bec73cde178,unknown).
0.13451996445655823::status(o_b375d832440f77cc9142,supported); 0::status(o_b375d832440f77cc9142,refuted); 0.86548003554344177::status(o_b375d832440f77cc9142,unknown).
0.0037578577175736427::status(o_b376ab0435aa7657dfa7,supported); 0::status(o_b376ab0435aa7657dfa7,refuted); 0.99624214228242636::status(o_b376ab0435aa7657dfa7,unknown).
0.96011406183242798::status(o_b3db7ce52ed5148415de,supported); 0::status(o_b3db7ce52ed5148415de,refuted); 0.039885938167572021::status(o_b3db7ce52ed5148415de,unknown).
0.23865454708325592::status(o_b4356c30b901a27e41b0,supported); 0::status(o_b4356c30b901a27e41b0,refuted); 0.76134545291674405::status(o_b4356c30b901a27e41b0,unknown).
1::status(o_b470b3d75d34aad86396,supported); 0::status(o_b470b3d75d34aad86396,refuted); 0::status(o_b470b3d75d34aad86396,unknown).
0.60312688209197685::status(o_b4aaaa12aba945e12f4a,supported); 0::status(o_b4aaaa12aba945e12f4a,refuted); 0.39687311790802315::status(o_b4aaaa12aba945e12f4a,unknown).
1::status(o_b4c022dd4fee1cc39ce7,supported); 0::status(o_b4c022dd4fee1cc39ce7,refuted); 0::status(o_b4c022dd4fee1cc39ce7,unknown).
1::status(o_b4ddb54b84bf9eb67316,supported); 0::status(o_b4ddb54b84bf9eb67316,refuted); 0::status(o_b4ddb54b84bf9eb67316,unknown).
1::status(o_b4ea2d93469199ed9d0b,supported); 0::status(o_b4ea2d93469199ed9d0b,refuted); 0::status(o_b4ea2d93469199ed9d0b,unknown).
0.00045137316919863224::status(o_b517a77ee1450f94492d,supported); 0::status(o_b517a77ee1450f94492d,refuted); 0.99954862683080137::status(o_b517a77ee1450f94492d,unknown).
0.14524199038813515::status(o_b527cafd80424f77a0cc,supported); 0::status(o_b527cafd80424f77a0cc,refuted); 0.85475800961186488::status(o_b527cafd80424f77a0cc,unknown).
0.0005490043549798429::status(o_b5469a9631104dd67b04,supported); 0::status(o_b5469a9631104dd67b04,refuted); 0.99945099564502016::status(o_b5469a9631104dd67b04,unknown).
1::status(o_b5f7d6cec7ba9d902819,supported); 0::status(o_b5f7d6cec7ba9d902819,refuted); 0::status(o_b5f7d6cec7ba9d902819,unknown).
0.00028077524621039629::status(o_b5fad5d1aa0ba1d00523,supported); 0::status(o_b5fad5d1aa0ba1d00523,refuted); 0.9997192247537896::status(o_b5fad5d1aa0ba1d00523,unknown).
1::status(o_b62d5c50944b561f115b,supported); 0::status(o_b62d5c50944b561f115b,refuted); 0::status(o_b62d5c50944b561f115b,unknown).
0.00076209998223930597::status(o_b67fc15ec96533ecc714,supported); 0::status(o_b67fc15ec96533ecc714,refuted); 0.99923790001776069::status(o_b67fc15ec96533ecc714,unknown).
1::status(o_b6973840e1186cf278ae,supported); 0::status(o_b6973840e1186cf278ae,refuted); 0::status(o_b6973840e1186cf278ae,unknown).
1::status(o_b6a76ea1b5aba1fd50cb,supported); 0::status(o_b6a76ea1b5aba1fd50cb,refuted); 0::status(o_b6a76ea1b5aba1fd50cb,unknown).
1::status(o_b6abde984791764baf26,supported); 0::status(o_b6abde984791764baf26,refuted); 0::status(o_b6abde984791764baf26,unknown).
0.99794512987136841::status(o_b6da0934c57b4722a45d,supported); 0::status(o_b6da0934c57b4722a45d,refuted); 0.0020548701286315918::status(o_b6da0934c57b4722a45d,unknown).
1::status(o_b72da8b5270254124f28,supported); 0::status(o_b72da8b5270254124f28,refuted); 0::status(o_b72da8b5270254124f28,unknown).
0.74738532304763794::status(o_b75f0a1d43ebd8c864e5,supported); 0::status(o_b75f0a1d43ebd8c864e5,refuted); 0.25261467695236206::status(o_b75f0a1d43ebd8c864e5,unknown).
1::status(o_b8414827f35113e9dffd,supported); 0::status(o_b8414827f35113e9dffd,refuted); 0::status(o_b8414827f35113e9dffd,unknown).
1::status(o_b889a587d55becc59e30,supported); 0::status(o_b889a587d55becc59e30,refuted); 0::status(o_b889a587d55becc59e30,unknown).
1::status(o_b8ab0e8b5899754bc649,supported); 0::status(o_b8ab0e8b5899754bc649,refuted); 0::status(o_b8ab0e8b5899754bc649,unknown).
1::status(o_b8f4f9b5c5dd653fc3b8,supported); 0::status(o_b8f4f9b5c5dd653fc3b8,refuted); 0::status(o_b8f4f9b5c5dd653fc3b8,unknown).
1::status(o_b9739de91b3f5f02b15c,supported); 0::status(o_b9739de91b3f5f02b15c,refuted); 0::status(o_b9739de91b3f5f02b15c,unknown).
1::status(o_b9b8fd2fae99ad091ba6,supported); 0::status(o_b9b8fd2fae99ad091ba6,refuted); 0::status(o_b9b8fd2fae99ad091ba6,unknown).
0.19355997361995056::status(o_b9e706ab190a594eb146,supported); 0::status(o_b9e706ab190a594eb146,refuted); 0.80644002638004941::status(o_b9e706ab190a594eb146,unknown).
1::status(o_ba1ad09e558610f37c26,supported); 0::status(o_ba1ad09e558610f37c26,refuted); 0::status(o_ba1ad09e558610f37c26,unknown).
0.00085279322229325771::status(o_ba687b3dd0438b6e82c1,supported); 0::status(o_ba687b3dd0438b6e82c1,refuted); 0.99914720677770674::status(o_ba687b3dd0438b6e82c1,unknown).
0.21143395962012582::status(o_ba6cbb6148cb84b02cd5,supported); 0::status(o_ba6cbb6148cb84b02cd5,refuted); 0.78856604037987421::status(o_ba6cbb6148cb84b02cd5,unknown).
1::status(o_bab9e0c3174ede88ebe6,supported); 0::status(o_bab9e0c3174ede88ebe6,refuted); 0::status(o_bab9e0c3174ede88ebe6,unknown).
0.24228181976937849::status(o_bb2375f6aafe3f649c3a,supported); 0::status(o_bb2375f6aafe3f649c3a,refuted); 0.75771818023062154::status(o_bb2375f6aafe3f649c3a,unknown).
0::status(o_bb49dc57d836132fc296,supported); 1::status(o_bb49dc57d836132fc296,refuted); 0::status(o_bb49dc57d836132fc296,unknown).
0.35994603273202497::status(o_bba03d6bf4cdd7efcf2a,supported); 0::status(o_bba03d6bf4cdd7efcf2a,refuted); 0.64005396726797503::status(o_bba03d6bf4cdd7efcf2a,unknown).
0.19764673249016596::status(o_bbeaa2bcaa24e37600e3,supported); 0::status(o_bbeaa2bcaa24e37600e3,refuted); 0.80235326750983404::status(o_bbeaa2bcaa24e37600e3,unknown).
1::status(o_bc16c0fec338ac0f8f9f,supported); 0::status(o_bc16c0fec338ac0f8f9f,refuted); 0::status(o_bc16c0fec338ac0f8f9f,unknown).
1::status(o_bc63e8dac77512358da1,supported); 0::status(o_bc63e8dac77512358da1,refuted); 0::status(o_bc63e8dac77512358da1,unknown).
1::status(o_bc644de20b847e0d9548,supported); 0::status(o_bc644de20b847e0d9548,refuted); 0::status(o_bc644de20b847e0d9548,unknown).
0.56174170970916748::status(o_bcf23991d5b6948b8f4c,supported); 0::status(o_bcf23991d5b6948b8f4c,refuted); 0.43825829029083252::status(o_bcf23991d5b6948b8f4c,unknown).
0.19911559554456601::status(o_bd021a8e3581ee1f79ee,supported); 0::status(o_bd021a8e3581ee1f79ee,refuted); 0.80088440445543396::status(o_bd021a8e3581ee1f79ee,unknown).
1::status(o_bd79a8afeeee8d42a7d6,supported); 0::status(o_bd79a8afeeee8d42a7d6,refuted); 0::status(o_bd79a8afeeee8d42a7d6,unknown).
0.15821032226085663::status(o_bd84b91f8391005dc64f,supported); 0::status(o_bd84b91f8391005dc64f,refuted); 0.84178967773914337::status(o_bd84b91f8391005dc64f,unknown).
0.0013122661039233208::status(o_bd99fe4091ca4d2e478d,supported); 0::status(o_bd99fe4091ca4d2e478d,refuted); 0.99868773389607668::status(o_bd99fe4091ca4d2e478d,unknown).
0.00044824578799307346::status(o_be13be3d4c6205f52669,supported); 0::status(o_be13be3d4c6205f52669,refuted); 0.99955175421200693::status(o_be13be3d4c6205f52669,unknown).
0.26495786561529716::status(o_be174e5182e3090c52ec,supported); 0::status(o_be174e5182e3090c52ec,refuted); 0.73504213438470289::status(o_be174e5182e3090c52ec,unknown).
0.13829396324310489::status(o_bed9cba98098a663382f,supported); 0::status(o_bed9cba98098a663382f,refuted); 0.86170603675689517::status(o_bed9cba98098a663382f,unknown).
0.39417715116874186::status(o_bef7109ddbb42cd4b312,supported); 0::status(o_bef7109ddbb42cd4b312,refuted); 0.60582284883125814::status(o_bef7109ddbb42cd4b312,unknown).
0.26128760864246486::status(o_bf4b91d72c479726340a,supported); 0::status(o_bf4b91d72c479726340a,refuted); 0.73871239135753508::status(o_bf4b91d72c479726340a,unknown).
1::status(o_bf6c260396eebb3ee297,supported); 0::status(o_bf6c260396eebb3ee297,refuted); 0::status(o_bf6c260396eebb3ee297,unknown).
1::status(o_c0b9f9cc36c1a4fdf237,supported); 0::status(o_c0b9f9cc36c1a4fdf237,refuted); 0::status(o_c0b9f9cc36c1a4fdf237,unknown).
1.2276381312403828e-05::status(o_c107783c00ca77d9b4f7,supported); 0::status(o_c107783c00ca77d9b4f7,refuted); 0.9999877236186876::status(o_c107783c00ca77d9b4f7,unknown).
1::status(o_c163174454ecf4f02c39,supported); 0::status(o_c163174454ecf4f02c39,refuted); 0::status(o_c163174454ecf4f02c39,unknown).
0.32172180369775238::status(o_c1693cf3e33a5cb2ee44,supported); 0::status(o_c1693cf3e33a5cb2ee44,refuted); 0.67827819630224762::status(o_c1693cf3e33a5cb2ee44,unknown).
0.99738341569900513::status(o_c1773f141e564be5f6e3,supported); 0::status(o_c1773f141e564be5f6e3,refuted); 0.002616584300994873::status(o_c1773f141e564be5f6e3,unknown).
0.99185353517532349::status(o_c1a0ea0a90ddc374bee9,supported); 0::status(o_c1a0ea0a90ddc374bee9,refuted); 0.0081464648246765137::status(o_c1a0ea0a90ddc374bee9,unknown).
1::status(o_c1a15dcd8af3a9d1ab00,supported); 0::status(o_c1a15dcd8af3a9d1ab00,refuted); 0::status(o_c1a15dcd8af3a9d1ab00,unknown).
0.98997622728347778::status(o_c1e22e1d7ebd0e67f386,supported); 0::status(o_c1e22e1d7ebd0e67f386,refuted); 0.010023772716522217::status(o_c1e22e1d7ebd0e67f386,unknown).
0.2129049152135849::status(o_c249d16667f4761fac5d,supported); 0::status(o_c249d16667f4761fac5d,refuted); 0.7870950847864151::status(o_c249d16667f4761fac5d,unknown).
1::status(o_c24e97ffc3157f12ff91,supported); 0::status(o_c24e97ffc3157f12ff91,refuted); 0::status(o_c24e97ffc3157f12ff91,unknown).
1::status(o_c2ebff65bcdfa7e88354,supported); 0::status(o_c2ebff65bcdfa7e88354,refuted); 0::status(o_c2ebff65bcdfa7e88354,unknown).
0.96227091550827026::status(o_c2f27d55393c72492b18,supported); 0::status(o_c2f27d55393c72492b18,refuted); 0.037729084491729736::status(o_c2f27d55393c72492b18,unknown).
0.50334479052197967::status(o_c32a1844e6b38d8955c7,supported); 0::status(o_c32a1844e6b38d8955c7,refuted); 0.49665520947802033::status(o_c32a1844e6b38d8955c7,unknown).
0::status(o_c38257176a64045332c2,supported); 1::status(o_c38257176a64045332c2,refuted); 0::status(o_c38257176a64045332c2,unknown).
0.17347724643658499::status(o_c3d5b580e815a1798d83,supported); 0::status(o_c3d5b580e815a1798d83,refuted); 0.82652275356341498::status(o_c3d5b580e815a1798d83,unknown).
0::status(o_c3f3d2ee8ed8aa5066a2,supported); 1::status(o_c3f3d2ee8ed8aa5066a2,refuted); 0::status(o_c3f3d2ee8ed8aa5066a2,unknown).
0.99794512987136841::status(o_c4027eadbe7b8affdfbf,supported); 0::status(o_c4027eadbe7b8affdfbf,refuted); 0.0020548701286315918::status(o_c4027eadbe7b8affdfbf,unknown).
1::status(o_c4ae29fcad8293dd32ad,supported); 0::status(o_c4ae29fcad8293dd32ad,refuted); 0::status(o_c4ae29fcad8293dd32ad,unknown).
1::status(o_c50fbffad84f3ff1c3d6,supported); 0::status(o_c50fbffad84f3ff1c3d6,refuted); 0::status(o_c50fbffad84f3ff1c3d6,unknown).
1::status(o_c55c64c7eea4170106d8,supported); 0::status(o_c55c64c7eea4170106d8,refuted); 0::status(o_c55c64c7eea4170106d8,unknown).
0.24287842070011395::status(o_c57c78a31c64eb1dc203,supported); 0::status(o_c57c78a31c64eb1dc203,refuted); 0.75712157929988599::status(o_c57c78a31c64eb1dc203,unknown).
1::status(o_c59980b0c637bd3a1d59,supported); 0::status(o_c59980b0c637bd3a1d59,refuted); 0::status(o_c59980b0c637bd3a1d59,unknown).
0.0016452829586341977::status(o_c5a0f3d78b2dcc0d5cfe,supported); 0::status(o_c5a0f3d78b2dcc0d5cfe,refuted); 0.9983547170413658::status(o_c5a0f3d78b2dcc0d5cfe,unknown).
1::status(o_c5eb6b7b22d0ba65e52a,supported); 0::status(o_c5eb6b7b22d0ba65e52a,refuted); 0::status(o_c5eb6b7b22d0ba65e52a,unknown).
1::status(o_c620ef08f3c6e92e7234,supported); 0::status(o_c620ef08f3c6e92e7234,refuted); 0::status(o_c620ef08f3c6e92e7234,unknown).
0.65947310145431026::status(o_c661faf7a37e2a505db1,supported); 0::status(o_c661faf7a37e2a505db1,refuted); 0.34052689854568974::status(o_c661faf7a37e2a505db1,unknown).
0.0013122661039233208::status(o_c6913096ba00a1d58047,supported); 0::status(o_c6913096ba00a1d58047,refuted); 0.99868773389607668::status(o_c6913096ba00a1d58047,unknown).
0.059880557084575611::status(o_c6948330fa57b57a2ed8,supported); 0::status(o_c6948330fa57b57a2ed8,refuted); 0.94011944291542437::status(o_c6948330fa57b57a2ed8,unknown).
0.19005654916321202::status(o_c6bb737d309959d1de9c,supported); 0::status(o_c6bb737d309959d1de9c,refuted); 0.80994345083678798::status(o_c6bb737d309959d1de9c,unknown).
0.0037578577175736427::status(o_c6c52942ef307e707bec,supported); 0::status(o_c6c52942ef307e707bec,refuted); 0.99624214228242636::status(o_c6c52942ef307e707bec,unknown).
0.00063768832478672266::status(o_c6ee13107df8ad8c2234,supported); 0::status(o_c6ee13107df8ad8c2234,refuted); 0.99936231167521328::status(o_c6ee13107df8ad8c2234,unknown).
0.096061237156391144::status(o_c706f70be5bc06928d1f,supported); 0::status(o_c706f70be5bc06928d1f,refuted); 0.90393876284360886::status(o_c706f70be5bc06928d1f,unknown).
1::status(o_c70a09badf34c22b49e4,supported); 0::status(o_c70a09badf34c22b49e4,refuted); 0::status(o_c70a09badf34c22b49e4,unknown).
1::status(o_c7195516e858f0529c83,supported); 0::status(o_c7195516e858f0529c83,refuted); 0::status(o_c7195516e858f0529c83,unknown).
0::status(o_c71fc8a56ea3c02c3252,supported); 1::status(o_c71fc8a56ea3c02c3252,refuted); 0::status(o_c71fc8a56ea3c02c3252,unknown).
0.00050635967636480927::status(o_c7b7b6942e1e116397fc,supported); 0::status(o_c7b7b6942e1e116397fc,refuted); 0.99949364032363519::status(o_c7b7b6942e1e116397fc,unknown).
1::status(o_c7bf8036bd21467ff354,supported); 0::status(o_c7bf8036bd21467ff354,refuted); 0::status(o_c7bf8036bd21467ff354,unknown).
0.27356761674592983::status(o_c8149288d612034b7975,supported); 0::status(o_c8149288d612034b7975,refuted); 0.72643238325407022::status(o_c8149288d612034b7975,unknown).
0.27356761674592983::status(o_c8605cd44710e8fd1d4b,supported); 0::status(o_c8605cd44710e8fd1d4b,refuted); 0.72643238325407022::status(o_c8605cd44710e8fd1d4b,unknown).
1::status(o_c869ff7441fbf816727d,supported); 0::status(o_c869ff7441fbf816727d,refuted); 0::status(o_c869ff7441fbf816727d,unknown).
1::status(o_c86a949de1ef2146f795,supported); 0::status(o_c86a949de1ef2146f795,refuted); 0::status(o_c86a949de1ef2146f795,unknown).
0.48558621161158549::status(o_c8870fd758d22405687e,supported); 0::status(o_c8870fd758d22405687e,refuted); 0.51441378838841456::status(o_c8870fd758d22405687e,unknown).
1::status(o_c88da2b1f1182dbef06d,supported); 0::status(o_c88da2b1f1182dbef06d,refuted); 0::status(o_c88da2b1f1182dbef06d,unknown).
0.002940004225820303::status(o_c8c87baa0a5d3c85a437,supported); 0::status(o_c8c87baa0a5d3c85a437,refuted); 0.9970599957741797::status(o_c8c87baa0a5d3c85a437,unknown).
0.00039488702896051109::status(o_c8ca54c1023c47b9da78,supported); 0::status(o_c8ca54c1023c47b9da78,refuted); 0.99960511297103949::status(o_c8ca54c1023c47b9da78,unknown).
0.0018071738304570317::status(o_c92ec08ef0174a46fd51,supported); 0::status(o_c92ec08ef0174a46fd51,refuted); 0.99819282616954297::status(o_c92ec08ef0174a46fd51,unknown).
1::status(o_c93d9a77d40c39cbe0b4,supported); 0::status(o_c93d9a77d40c39cbe0b4,refuted); 0::status(o_c93d9a77d40c39cbe0b4,unknown).
0.20358817616639588::status(o_c9ab649646aaad534d09,supported); 0::status(o_c9ab649646aaad534d09,refuted); 0.79641182383360409::status(o_c9ab649646aaad534d09,unknown).
0.97427183389663696::status(o_c9f49e13133c7c6b7242,supported); 0::status(o_c9f49e13133c7c6b7242,refuted); 0.025728166103363037::status(o_c9f49e13133c7c6b7242,unknown).
0.63310902975620786::status(o_ca1896a556f8b59513a9,supported); 0::status(o_ca1896a556f8b59513a9,refuted); 0.36689097024379214::status(o_ca1896a556f8b59513a9,unknown).
1::status(o_ca254481495c5bf916e8,supported); 0::status(o_ca254481495c5bf916e8,refuted); 0::status(o_ca254481495c5bf916e8,unknown).
1::status(o_ca39965b176b9773d7ec,supported); 0::status(o_ca39965b176b9773d7ec,refuted); 0::status(o_ca39965b176b9773d7ec,unknown).
0.66501856022478645::status(o_ca8d6e8f84304a946ab8,supported); 0::status(o_ca8d6e8f84304a946ab8,refuted); 0.33498143977521355::status(o_ca8d6e8f84304a946ab8,unknown).
0::status(o_ca9f6f63879a2153f2cf,supported); 1::status(o_ca9f6f63879a2153f2cf,refuted); 0::status(o_ca9f6f63879a2153f2cf,unknown).
0::status(o_caced41357c98a580312,supported); 1::status(o_caced41357c98a580312,refuted); 0::status(o_caced41357c98a580312,unknown).
0::status(o_cacee04898d5fefa5d0e,supported); 1::status(o_cacee04898d5fefa5d0e,refuted); 0::status(o_cacee04898d5fefa5d0e,unknown).
0.52321884901376903::status(o_caf5d136e54d491f273c,supported); 0::status(o_caf5d136e54d491f273c,refuted); 0.47678115098623097::status(o_caf5d136e54d491f273c,unknown).
0::status(o_cb3f44454338804a17bb,supported); 1::status(o_cb3f44454338804a17bb,refuted); 0::status(o_cb3f44454338804a17bb,unknown).
1::status(o_cbce5f11faab4a46ecad,supported); 0::status(o_cbce5f11faab4a46ecad,refuted); 0::status(o_cbce5f11faab4a46ecad,unknown).
0.031903255351594731::status(o_cc2701322facf86a8f9f,supported); 0::status(o_cc2701322facf86a8f9f,refuted); 0.96809674464840523::status(o_cc2701322facf86a8f9f,unknown).
0::status(o_cc3b8c84f2cfab7e78ba,supported); 1::status(o_cc3b8c84f2cfab7e78ba,refuted); 0::status(o_cc3b8c84f2cfab7e78ba,unknown).
0.78545029701849134::status(o_ccc3257e5f93554db0b1,supported); 0::status(o_ccc3257e5f93554db0b1,refuted); 0.21454970298150866::status(o_ccc3257e5f93554db0b1,unknown).
0.66286114808256291::status(o_cd4beeb4437c602fbbd2,supported); 0::status(o_cd4beeb4437c602fbbd2,refuted); 0.33713885191743709::status(o_cd4beeb4437c602fbbd2,unknown).
0.056215571972891329::status(o_cd5f8407c5e8e647ad1f,supported); 0::status(o_cd5f8407c5e8e647ad1f,refuted); 0.94378442802710871::status(o_cd5f8407c5e8e647ad1f,unknown).
0.97427183389663696::status(o_cdcfd205345369b741b4,supported); 0::status(o_cdcfd205345369b741b4,refuted); 0.025728166103363037::status(o_cdcfd205345369b741b4,unknown).
1::status(o_cdf694541ca7147e7b2c,supported); 0::status(o_cdf694541ca7147e7b2c,refuted); 0::status(o_cdf694541ca7147e7b2c,unknown).
0.00011525061563588679::status(o_ce215c2b098f01fd3d9b,supported); 0::status(o_ce215c2b098f01fd3d9b,refuted); 0.99988474938436411::status(o_ce215c2b098f01fd3d9b,unknown).
0.19124871013090158::status(o_ce471059f3edb76ec69e,supported); 0::status(o_ce471059f3edb76ec69e,refuted); 0.80875128986909839::status(o_ce471059f3edb76ec69e,unknown).
0.34819854080380347::status(o_ce94b9f9efa519c1d158,supported); 0::status(o_ce94b9f9efa519c1d158,refuted); 0.65180145919619648::status(o_ce94b9f9efa519c1d158,unknown).
0.00027939380379393697::status(o_cece0fee3cf3a62f2296,supported); 0::status(o_cece0fee3cf3a62f2296,refuted); 0.99972060619620606::status(o_cece0fee3cf3a62f2296,unknown).
1::status(o_cee4d72d02c6d9ca6ea1,supported); 0::status(o_cee4d72d02c6d9ca6ea1,refuted); 0::status(o_cee4d72d02c6d9ca6ea1,unknown).
1::status(o_ceeb794293e96c7f6ce5,supported); 0::status(o_ceeb794293e96c7f6ce5,refuted); 0::status(o_ceeb794293e96c7f6ce5,unknown).
1::status(o_cf8b8d0103995873b1e3,supported); 0::status(o_cf8b8d0103995873b1e3,refuted); 0::status(o_cf8b8d0103995873b1e3,unknown).
1::status(o_cfafc56fb5d9082a81f7,supported); 0::status(o_cfafc56fb5d9082a81f7,refuted); 0::status(o_cfafc56fb5d9082a81f7,unknown).
1::status(o_cfafe2954f9dd4ddd934,supported); 0::status(o_cfafe2954f9dd4ddd934,refuted); 0::status(o_cfafe2954f9dd4ddd934,unknown).
0.00066984596196562052::status(o_cff621ae48eb4f0c9a97,supported); 0::status(o_cff621ae48eb4f0c9a97,refuted); 0.99933015403803438::status(o_cff621ae48eb4f0c9a97,unknown).
0.976348876953125::status(o_d00768634721260ecd49,supported); 0::status(o_d00768634721260ecd49,refuted); 0.023651123046875::status(o_d00768634721260ecd49,unknown).
0.6157456622530415::status(o_d020f413985a6f53df52,supported); 0::status(o_d020f413985a6f53df52,refuted); 0.3842543377469585::status(o_d020f413985a6f53df52,unknown).
1::status(o_d065ca5871f90679237c,supported); 0::status(o_d065ca5871f90679237c,refuted); 0::status(o_d065ca5871f90679237c,unknown).
0.00012811402848456055::status(o_d0ebebdbd3b10f345c66,supported); 0::status(o_d0ebebdbd3b10f345c66,refuted); 0.99987188597151544::status(o_d0ebebdbd3b10f345c66,unknown).
0.00019939233607146889::status(o_d11319c86f48ea287feb,supported); 0::status(o_d11319c86f48ea287feb,refuted); 0.99980060766392853::status(o_d11319c86f48ea287feb,unknown).
1::status(o_d11c1a177ee12190fc24,supported); 0::status(o_d11c1a177ee12190fc24,refuted); 0::status(o_d11c1a177ee12190fc24,unknown).
1::status(o_d15b07d6a3b5f11628e6,supported); 0::status(o_d15b07d6a3b5f11628e6,refuted); 0::status(o_d15b07d6a3b5f11628e6,unknown).
1::status(o_d1af824111d09e18ad95,supported); 0::status(o_d1af824111d09e18ad95,refuted); 0::status(o_d1af824111d09e18ad95,unknown).
1::status(o_d1d6a93949512537e120,supported); 0::status(o_d1d6a93949512537e120,refuted); 0::status(o_d1d6a93949512537e120,unknown).
1::status(o_d1e1786c6ec431dc8eab,supported); 0::status(o_d1e1786c6ec431dc8eab,refuted); 0::status(o_d1e1786c6ec431dc8eab,unknown).
0::status(o_d20a3b8edef1feef8322,supported); 1::status(o_d20a3b8edef1feef8322,refuted); 0::status(o_d20a3b8edef1feef8322,unknown).
0.17727372387088441::status(o_d242a82ea74f371c8502,supported); 0::status(o_d242a82ea74f371c8502,refuted); 0.82272627612911564::status(o_d242a82ea74f371c8502,unknown).
0::status(o_d246b22a2ae198ed84cb,supported); 1::status(o_d246b22a2ae198ed84cb,refuted); 0::status(o_d246b22a2ae198ed84cb,unknown).
0::status(o_d25beeaf793a2d11aafd,supported); 1::status(o_d25beeaf793a2d11aafd,refuted); 0::status(o_d25beeaf793a2d11aafd,unknown).
0.16845106469907029::status(o_d25f245dc586ee58e9e4,supported); 0::status(o_d25f245dc586ee58e9e4,refuted); 0.83154893530092977::status(o_d25f245dc586ee58e9e4,unknown).
0.0050932755693793297::status(o_d26303da72c9399c63fd,supported); 0::status(o_d26303da72c9399c63fd,refuted); 0.99490672443062067::status(o_d26303da72c9399c63fd,unknown).
0.00048713211435824633::status(o_d2709399b56d26183136,supported); 0::status(o_d2709399b56d26183136,refuted); 0.99951286788564175::status(o_d2709399b56d26183136,unknown).
0.36376477629544635::status(o_d27800b9078c2bcfa0fd,supported); 0::status(o_d27800b9078c2bcfa0fd,refuted); 0.63623522370455365::status(o_d27800b9078c2bcfa0fd,unknown).
0::status(o_d27cda058d9fc24ab3e5,supported); 1::status(o_d27cda058d9fc24ab3e5,refuted); 0::status(o_d27cda058d9fc24ab3e5,unknown).
1::status(o_d2965574aa889d612dd7,supported); 0::status(o_d2965574aa889d612dd7,refuted); 0::status(o_d2965574aa889d612dd7,unknown).
0::status(o_d2b04100e77590a0f383,supported); 1::status(o_d2b04100e77590a0f383,refuted); 0::status(o_d2b04100e77590a0f383,unknown).
0::status(o_d2d85c7e4cab2bfa8055,supported); 1::status(o_d2d85c7e4cab2bfa8055,refuted); 0::status(o_d2d85c7e4cab2bfa8055,unknown).
1::status(o_d2f74ce791abcfcda10d,supported); 0::status(o_d2f74ce791abcfcda10d,refuted); 0::status(o_d2f74ce791abcfcda10d,unknown).
0.99887460470199585::status(o_d3599bdec4ede12fc6ea,supported); 0::status(o_d3599bdec4ede12fc6ea,refuted); 0.0011253952980041504::status(o_d3599bdec4ede12fc6ea,unknown).
0::status(o_d37dc66ead8066eda751,supported); 1::status(o_d37dc66ead8066eda751,refuted); 0::status(o_d37dc66ead8066eda751,unknown).
1::status(o_d3be1f5f64ff7e00e6dc,supported); 0::status(o_d3be1f5f64ff7e00e6dc,refuted); 0::status(o_d3be1f5f64ff7e00e6dc,unknown).
1::status(o_d3d1a29250e46709b864,supported); 0::status(o_d3d1a29250e46709b864,refuted); 0::status(o_d3d1a29250e46709b864,unknown).
0.99810886383056641::status(o_d3efe2aaf645e90c64e7,supported); 0::status(o_d3efe2aaf645e90c64e7,refuted); 0.0018911361694335938::status(o_d3efe2aaf645e90c64e7,unknown).
0::status(o_d42ec88ea5d8ee19a503,supported); 1::status(o_d42ec88ea5d8ee19a503,refuted); 0::status(o_d42ec88ea5d8ee19a503,unknown).
0.99155628681182861::status(o_d438df36e2dd2c1df23e,supported); 0::status(o_d438df36e2dd2c1df23e,refuted); 0.0084437131881713867::status(o_d438df36e2dd2c1df23e,unknown).
0.02884664386510849::status(o_d451a624944cbfac7fb9,supported); 0::status(o_d451a624944cbfac7fb9,refuted); 0.97115335613489151::status(o_d451a624944cbfac7fb9,unknown).
0::status(o_d47c60ab7ffe0336bb1e,supported); 1::status(o_d47c60ab7ffe0336bb1e,refuted); 0::status(o_d47c60ab7ffe0336bb1e,unknown).
0.76357456406184987::status(o_d5084105f491e2bf2be7,supported); 0::status(o_d5084105f491e2bf2be7,refuted); 0.23642543593815013::status(o_d5084105f491e2bf2be7,unknown).
0.55372391428368573::status(o_d523e7a15c5656813ecb,supported); 0::status(o_d523e7a15c5656813ecb,refuted); 0.44627608571631427::status(o_d523e7a15c5656813ecb,unknown).
1::status(o_d55892ae80ba20f75970,supported); 0::status(o_d55892ae80ba20f75970,refuted); 0::status(o_d55892ae80ba20f75970,unknown).
1::status(o_d55bb7692344559e3c9c,supported); 0::status(o_d55bb7692344559e3c9c,refuted); 0::status(o_d55bb7692344559e3c9c,unknown).
0.99887460470199585::status(o_d58345f480df44560e94,supported); 0::status(o_d58345f480df44560e94,refuted); 0.0011253952980041504::status(o_d58345f480df44560e94,unknown).
1::status(o_d615ab15936804bea4a8,supported); 0::status(o_d615ab15936804bea4a8,refuted); 0::status(o_d615ab15936804bea4a8,unknown).
0.0070033296942710876::status(o_d61bb4b8886a9f23b31b,supported); 0::status(o_d61bb4b8886a9f23b31b,refuted); 0.99299667030572891::status(o_d61bb4b8886a9f23b31b,unknown).
1::status(o_d6336b584fbc3a69eaa1,supported); 0::status(o_d6336b584fbc3a69eaa1,refuted); 0::status(o_d6336b584fbc3a69eaa1,unknown).
1::status(o_d66a466f6baa370526cc,supported); 0::status(o_d66a466f6baa370526cc,refuted); 0::status(o_d66a466f6baa370526cc,unknown).
1::status(o_d69f69360c70ad5a8bcb,supported); 0::status(o_d69f69360c70ad5a8bcb,refuted); 0::status(o_d69f69360c70ad5a8bcb,unknown).
0::status(o_d6c1af468a7d92b046ec,supported); 1::status(o_d6c1af468a7d92b046ec,refuted); 0::status(o_d6c1af468a7d92b046ec,unknown).
0.050029573750789383::status(o_d6d5fd3b5eaf8444639c,supported); 0::status(o_d6d5fd3b5eaf8444639c,refuted); 0.94997042624921058::status(o_d6d5fd3b5eaf8444639c,unknown).
1::status(o_d6f08f7523a2888ac57e,supported); 0::status(o_d6f08f7523a2888ac57e,refuted); 0::status(o_d6f08f7523a2888ac57e,unknown).
0.039551112800836563::status(o_d6f47e33fcbfb6a4d1d3,supported); 0::status(o_d6f47e33fcbfb6a4d1d3,refuted); 0.96044888719916344::status(o_d6f47e33fcbfb6a4d1d3,unknown).
1::status(o_d6f980618c081bea65ce,supported); 0::status(o_d6f980618c081bea65ce,refuted); 0::status(o_d6f980618c081bea65ce,unknown).
0.30231650305001806::status(o_d7061b54444afbbf957c,supported); 0::status(o_d7061b54444afbbf957c,refuted); 0.69768349694998189::status(o_d7061b54444afbbf957c,unknown).
1::status(o_d7691232d427829ddd7a,supported); 0::status(o_d7691232d427829ddd7a,refuted); 0::status(o_d7691232d427829ddd7a,unknown).
0::status(o_d7af19569aeb6110cb07,supported); 1::status(o_d7af19569aeb6110cb07,refuted); 0::status(o_d7af19569aeb6110cb07,unknown).
0.00050635967636480927::status(o_d7b148d73e64c16452f0,supported); 0::status(o_d7b148d73e64c16452f0,refuted); 0.99949364032363519::status(o_d7b148d73e64c16452f0,unknown).
1::status(o_d7fe0af95472039e1ba7,supported); 0::status(o_d7fe0af95472039e1ba7,refuted); 0::status(o_d7fe0af95472039e1ba7,unknown).
0.99547606706619263::status(o_d826f1bf8341711aa2b1,supported); 0::status(o_d826f1bf8341711aa2b1,refuted); 0.004523932933807373::status(o_d826f1bf8341711aa2b1,unknown).
0.96754372119903564::status(o_d898eb077e3a496f1a06,supported); 0::status(o_d898eb077e3a496f1a06,refuted); 0.032456278800964355::status(o_d898eb077e3a496f1a06,unknown).
0.23235140495988718::status(o_d8aa131ede849d4ad4a6,supported); 0::status(o_d8aa131ede849d4ad4a6,refuted); 0.76764859504011285::status(o_d8aa131ede849d4ad4a6,unknown).
1::status(o_d8cc7dd61697e469867a,supported); 0::status(o_d8cc7dd61697e469867a,refuted); 0::status(o_d8cc7dd61697e469867a,unknown).
0.0093486057594418526::status(o_da11a3406ccbf7b7bf78,supported); 0::status(o_da11a3406ccbf7b7bf78,refuted); 0.99065139424055815::status(o_da11a3406ccbf7b7bf78,unknown).
0.015547662042081356::status(o_da2dec6deb9958294f83,supported); 0::status(o_da2dec6deb9958294f83,refuted); 0.98445233795791864::status(o_da2dec6deb9958294f83,unknown).
1::status(o_dab1a2687cf1b9f4d58b,supported); 0::status(o_dab1a2687cf1b9f4d58b,refuted); 0::status(o_dab1a2687cf1b9f4d58b,unknown).
1::status(o_dade2534a3b2b718ab50,supported); 0::status(o_dade2534a3b2b718ab50,refuted); 0::status(o_dade2534a3b2b718ab50,unknown).
0.0018518617143854499::status(o_db164fc7378e8d33b396,supported); 0::status(o_db164fc7378e8d33b396,refuted); 0.99814813828561455::status(o_db164fc7378e8d33b396,unknown).
0.64125230196340421::status(o_db2140c2f8012c9113f2,supported); 0::status(o_db2140c2f8012c9113f2,refuted); 0.35874769803659579::status(o_db2140c2f8012c9113f2,unknown).
0::status(o_db53cf1ff805e50cd252,supported); 1::status(o_db53cf1ff805e50cd252,refuted); 0::status(o_db53cf1ff805e50cd252,unknown).
1::status(o_dc123f9776c5f251e931,supported); 0::status(o_dc123f9776c5f251e931,refuted); 0::status(o_dc123f9776c5f251e931,unknown).
0.05618885022250588::status(o_dc1b54e58c217ad4c91b,supported); 0::status(o_dc1b54e58c217ad4c91b,refuted); 0.94381114977749414::status(o_dc1b54e58c217ad4c91b,unknown).
1::status(o_dc1f670188e3c3bd8066,supported); 0::status(o_dc1f670188e3c3bd8066,refuted); 0::status(o_dc1f670188e3c3bd8066,unknown).
0.99007987976074219::status(o_dccb54e5a9ad077fe791,supported); 0::status(o_dccb54e5a9ad077fe791,refuted); 0.0099201202392578125::status(o_dccb54e5a9ad077fe791,unknown).
1::status(o_dce5ad48dbd95e41c5e8,supported); 0::status(o_dce5ad48dbd95e41c5e8,refuted); 0::status(o_dce5ad48dbd95e41c5e8,unknown).
0::status(o_dcece1f5b9ad4d232de0,supported); 1::status(o_dcece1f5b9ad4d232de0,refuted); 0::status(o_dcece1f5b9ad4d232de0,unknown).
0::status(o_dd43f8151dffbd339330,supported); 1::status(o_dd43f8151dffbd339330,refuted); 0::status(o_dd43f8151dffbd339330,unknown).
0.0031784586608409882::status(o_dd75eefdcba5cc3a1d6e,supported); 0::status(o_dd75eefdcba5cc3a1d6e,refuted); 0.99682154133915901::status(o_dd75eefdcba5cc3a1d6e,unknown).
0.98721271753311157::status(o_ddabadcf5e9ca752ce36,supported); 0::status(o_ddabadcf5e9ca752ce36,refuted); 0.012787282466888428::status(o_ddabadcf5e9ca752ce36,unknown).
0.15821032226085663::status(o_ddad557680f0c457eb29,supported); 0::status(o_ddad557680f0c457eb29,refuted); 0.84178967773914337::status(o_ddad557680f0c457eb29,unknown).
0.003883931552991271::status(o_ddcf482ea0de97b9bd79,supported); 0::status(o_ddcf482ea0de97b9bd79,refuted); 0.99611606844700873::status(o_ddcf482ea0de97b9bd79,unknown).
0.2766593005094688::status(o_ddf687e9e4b9cac3ea36,supported); 0::status(o_ddf687e9e4b9cac3ea36,refuted); 0.72334069949053115::status(o_ddf687e9e4b9cac3ea36,unknown).
1::status(o_de43be83f9ed46439a95,supported); 0::status(o_de43be83f9ed46439a95,refuted); 0::status(o_de43be83f9ed46439a95,unknown).
0.99185353517532349::status(o_dea282153a9f8aa4c074,supported); 0::status(o_dea282153a9f8aa4c074,refuted); 0.0081464648246765137::status(o_dea282153a9f8aa4c074,unknown).
0::status(o_df2ca809d43f3f543a17,supported); 1::status(o_df2ca809d43f3f543a17,refuted); 0::status(o_df2ca809d43f3f543a17,unknown).
1::status(o_df4f7af0f7119c6cd395,supported); 0::status(o_df4f7af0f7119c6cd395,refuted); 0::status(o_df4f7af0f7119c6cd395,unknown).
1::status(o_df546da126e6991e3baa,supported); 0::status(o_df546da126e6991e3baa,refuted); 0::status(o_df546da126e6991e3baa,unknown).
1::status(o_df5756f4bde87495fe6f,supported); 0::status(o_df5756f4bde87495fe6f,refuted); 0::status(o_df5756f4bde87495fe6f,unknown).
0.20828733388887996::status(o_df5f39882c13a979fe59,supported); 0::status(o_df5f39882c13a979fe59,refuted); 0.79171266611112001::status(o_df5f39882c13a979fe59,unknown).
1::status(o_df617d8d384572a26b43,supported); 0::status(o_df617d8d384572a26b43,refuted); 0::status(o_df617d8d384572a26b43,unknown).
0::status(o_df6a6a49655e1e74555f,supported); 1::status(o_df6a6a49655e1e74555f,refuted); 0::status(o_df6a6a49655e1e74555f,unknown).
0.24368026490845215::status(o_dfcb1b94635ba602bdd7,supported); 0::status(o_dfcb1b94635ba602bdd7,refuted); 0.75631973509154782::status(o_dfcb1b94635ba602bdd7,unknown).
0.19538599857576402::status(o_dfd008e29d5ac0f1031a,supported); 0::status(o_dfd008e29d5ac0f1031a,refuted); 0.804614001424236::status(o_dfd008e29d5ac0f1031a,unknown).
0::status(o_dfd30d8cc785ba014691,supported); 1::status(o_dfd30d8cc785ba014691,refuted); 0::status(o_dfd30d8cc785ba014691,unknown).
1::status(o_e0013a9f79fe6c730b3c,supported); 0::status(o_e0013a9f79fe6c730b3c,refuted); 0::status(o_e0013a9f79fe6c730b3c,unknown).
1::status(o_e0148433680edb0ed27a,supported); 0::status(o_e0148433680edb0ed27a,refuted); 0::status(o_e0148433680edb0ed27a,unknown).
1::status(o_e05085af967da8e8a1cc,supported); 0::status(o_e05085af967da8e8a1cc,refuted); 0::status(o_e05085af967da8e8a1cc,unknown).
0::status(o_e07693f06d6eb6721439,supported); 1::status(o_e07693f06d6eb6721439,refuted); 0::status(o_e07693f06d6eb6721439,unknown).
1::status(o_e0929e0eda515e65a20e,supported); 0::status(o_e0929e0eda515e65a20e,refuted); 0::status(o_e0929e0eda515e65a20e,unknown).
0.62521180049902358::status(o_e0b239c7737087ef281f,supported); 0::status(o_e0b239c7737087ef281f,refuted); 0.37478819950097642::status(o_e0b239c7737087ef281f,unknown).
0.99887460470199585::status(o_e0f03769bf1492c04f00,supported); 0::status(o_e0f03769bf1492c04f00,refuted); 0.0011253952980041504::status(o_e0f03769bf1492c04f00,unknown).
0.35994603273202497::status(o_e161ebab0d16e729bd2e,supported); 0::status(o_e161ebab0d16e729bd2e,refuted); 0.64005396726797503::status(o_e161ebab0d16e729bd2e,unknown).
0::status(o_e16cad632c00b7ee3920,supported); 1::status(o_e16cad632c00b7ee3920,refuted); 0::status(o_e16cad632c00b7ee3920,unknown).
1::status(o_e1d10f284f7ecc28d155,supported); 0::status(o_e1d10f284f7ecc28d155,refuted); 0::status(o_e1d10f284f7ecc28d155,unknown).
0.98598873615264893::status(o_e22698c89a850753537b,supported); 0::status(o_e22698c89a850753537b,refuted); 0.014011263847351074::status(o_e22698c89a850753537b,unknown).
0.32443726915540849::status(o_e2676468acc3c8837c8d,supported); 0::status(o_e2676468acc3c8837c8d,refuted); 0.67556273084459151::status(o_e2676468acc3c8837c8d,unknown).
0.58578857000318696::status(o_e2ac0dec45f9fc5d6649,supported); 0::status(o_e2ac0dec45f9fc5d6649,refuted); 0.41421142999681304::status(o_e2ac0dec45f9fc5d6649,unknown).
0.00063080125255510211::status(o_e2e359456fc51a027542,supported); 0::status(o_e2e359456fc51a027542,refuted); 0.9993691987474449::status(o_e2e359456fc51a027542,unknown).
0.59548482063864561::status(o_e2f6af634ca7716aa55e,supported); 0::status(o_e2f6af634ca7716aa55e,refuted); 0.40451517936135439::status(o_e2f6af634ca7716aa55e,unknown).
0.28868305664749422::status(o_e30c248f492214e2b81a,supported); 0::status(o_e30c248f492214e2b81a,refuted); 0.71131694335250573::status(o_e30c248f492214e2b81a,unknown).
0.53504799636989575::status(o_e30fa74c680bc3514176,supported); 0::status(o_e30fa74c680bc3514176,refuted); 0.46495200363010425::status(o_e30fa74c680bc3514176,unknown).
1::status(o_e32f5aa0459586499220,supported); 0::status(o_e32f5aa0459586499220,refuted); 0::status(o_e32f5aa0459586499220,unknown).
1::status(o_e38c4a5259a61b77728b,supported); 0::status(o_e38c4a5259a61b77728b,refuted); 0::status(o_e38c4a5259a61b77728b,unknown).
0.32702082896239254::status(o_e39ee433e673e56782c4,supported); 0::status(o_e39ee433e673e56782c4,refuted); 0.6729791710376074::status(o_e39ee433e673e56782c4,unknown).
0.99470680952072144::status(o_e3af0da140a95525e467,supported); 0::status(o_e3af0da140a95525e467,refuted); 0.0052931904792785645::status(o_e3af0da140a95525e467,unknown).
0.00043609272688627243::status(o_e3e7b682d79edaf1d3aa,supported); 0::status(o_e3e7b682d79edaf1d3aa,refuted); 0.99956390727311373::status(o_e3e7b682d79edaf1d3aa,unknown).
1::status(o_e3ed2d883b167f5d2873,supported); 0::status(o_e3ed2d883b167f5d2873,refuted); 0::status(o_e3ed2d883b167f5d2873,unknown).
1::status(o_e4813344d64f93dec787,supported); 0::status(o_e4813344d64f93dec787,refuted); 0::status(o_e4813344d64f93dec787,unknown).
0.99213320016860962::status(o_e49a41c70b393015e60d,supported); 0::status(o_e49a41c70b393015e60d,refuted); 0.0078667998313903809::status(o_e49a41c70b393015e60d,unknown).
0.071748655438401407::status(o_e50e39cf75e68990c526,supported); 0::status(o_e50e39cf75e68990c526,refuted); 0.92825134456159863::status(o_e50e39cf75e68990c526,unknown).
1::status(o_e58a954d226c34f1b35a,supported); 0::status(o_e58a954d226c34f1b35a,refuted); 0::status(o_e58a954d226c34f1b35a,unknown).
1::status(o_e6142a8630fa8df5dfab,supported); 0::status(o_e6142a8630fa8df5dfab,refuted); 0::status(o_e6142a8630fa8df5dfab,unknown).
0.99470680952072144::status(o_e648cc0dd3f0c19db09d,supported); 0::status(o_e648cc0dd3f0c19db09d,refuted); 0.0052931904792785645::status(o_e648cc0dd3f0c19db09d,unknown).
1::status(o_e6633275f025ac26b63b,supported); 0::status(o_e6633275f025ac26b63b,refuted); 0::status(o_e6633275f025ac26b63b,unknown).
0.61771134898671276::status(o_e6d6d93052230dd9aa65,supported); 0::status(o_e6d6d93052230dd9aa65,refuted); 0.38228865101328724::status(o_e6d6d93052230dd9aa65,unknown).
1::status(o_e6d780801b0c118067fe,supported); 0::status(o_e6d780801b0c118067fe,refuted); 0::status(o_e6d780801b0c118067fe,unknown).
0.99660646915435791::status(o_e763b1a16b0ea19be3a5,supported); 0::status(o_e763b1a16b0ea19be3a5,refuted); 0.0033935308456420898::status(o_e763b1a16b0ea19be3a5,unknown).
1::status(o_e7b5c586b30afcfd1d19,supported); 0::status(o_e7b5c586b30afcfd1d19,refuted); 0::status(o_e7b5c586b30afcfd1d19,unknown).
1::status(o_e7c465b2b9628c60bc2c,supported); 0::status(o_e7c465b2b9628c60bc2c,refuted); 0::status(o_e7c465b2b9628c60bc2c,unknown).
0::status(o_e81c15ba688783c6c9c2,supported); 1::status(o_e81c15ba688783c6c9c2,refuted); 0::status(o_e81c15ba688783c6c9c2,unknown).
0.56824234941493657::status(o_e82bdad67e81fab8153b,supported); 0::status(o_e82bdad67e81fab8153b,refuted); 0.43175765058506343::status(o_e82bdad67e81fab8153b,unknown).
0.99810886383056641::status(o_e85da8a53de9c803e288,supported); 0::status(o_e85da8a53de9c803e288,refuted); 0.0018911361694335938::status(o_e85da8a53de9c803e288,unknown).
1::status(o_e87315b464b1c5f30512,supported); 0::status(o_e87315b464b1c5f30512,refuted); 0::status(o_e87315b464b1c5f30512,unknown).
0.23094556464088092::status(o_e87f9d3b8e655f1b7951,supported); 0::status(o_e87f9d3b8e655f1b7951,refuted); 0.7690544353591191::status(o_e87f9d3b8e655f1b7951,unknown).
0.976348876953125::status(o_e8d5f9a2644c61db5a74,supported); 0::status(o_e8d5f9a2644c61db5a74,refuted); 0.023651123046875::status(o_e8d5f9a2644c61db5a74,unknown).
1::status(o_e8e78395f987c1477061,supported); 0::status(o_e8e78395f987c1477061,refuted); 0::status(o_e8e78395f987c1477061,unknown).
1::status(o_e8ea77c46182071a51fb,supported); 0::status(o_e8ea77c46182071a51fb,refuted); 0::status(o_e8ea77c46182071a51fb,unknown).
0.61694091558456421::status(o_e8f8c017864896cc65b9,supported); 0::status(o_e8f8c017864896cc65b9,refuted); 0.38305908441543579::status(o_e8f8c017864896cc65b9,unknown).
1::status(o_e9228a40cfdd2d28b9d7,supported); 0::status(o_e9228a40cfdd2d28b9d7,refuted); 0::status(o_e9228a40cfdd2d28b9d7,unknown).
0.2927598080774414::status(o_e937e4dc1a700fc9adec,supported); 0::status(o_e937e4dc1a700fc9adec,refuted); 0.7072401919225586::status(o_e937e4dc1a700fc9adec,unknown).
0.24893507805087303::status(o_e985aa974e7a96cfa0e9,supported); 0::status(o_e985aa974e7a96cfa0e9,refuted); 0.751064921949127::status(o_e985aa974e7a96cfa0e9,unknown).
0.59897809695338433::status(o_e9bbb82a77438c525095,supported); 0::status(o_e9bbb82a77438c525095,refuted); 0.40102190304661567::status(o_e9bbb82a77438c525095,unknown).
0::status(o_e9bc94025c5bbe5abdc9,supported); 1::status(o_e9bc94025c5bbe5abdc9,refuted); 0::status(o_e9bc94025c5bbe5abdc9,unknown).
0.02884664386510849::status(o_e9d0790131dd175ce6bb,supported); 0::status(o_e9d0790131dd175ce6bb,refuted); 0.97115335613489151::status(o_e9d0790131dd175ce6bb,unknown).
1::status(o_ea1e565e27a63343135a,supported); 0::status(o_ea1e565e27a63343135a,refuted); 0::status(o_ea1e565e27a63343135a,unknown).
1::status(o_ea1fa258de3938e26697,supported); 0::status(o_ea1fa258de3938e26697,refuted); 0::status(o_ea1fa258de3938e26697,unknown).
0.00063768832478672266::status(o_ea66860c2e940d9cd5b6,supported); 0::status(o_ea66860c2e940d9cd5b6,refuted); 0.99936231167521328::status(o_ea66860c2e940d9cd5b6,unknown).
0.66553917572983945::status(o_eaa7decac125953dee1a,supported); 0::status(o_eaa7decac125953dee1a,refuted); 0.33446082427016055::status(o_eaa7decac125953dee1a,unknown).
0::status(o_ead10d7a9bffcca8d20f,supported); 1::status(o_ead10d7a9bffcca8d20f,refuted); 0::status(o_ead10d7a9bffcca8d20f,unknown).
0::status(o_eaef4d90d09c60a2e8a8,supported); 1::status(o_eaef4d90d09c60a2e8a8,refuted); 0::status(o_eaef4d90d09c60a2e8a8,unknown).
0.18679465447632115::status(o_eb0bb2d3a610e269cb09,supported); 0::status(o_eb0bb2d3a610e269cb09,refuted); 0.81320534552367885::status(o_eb0bb2d3a610e269cb09,unknown).
1::status(o_eb1abd2431ddf7d6b62b,supported); 0::status(o_eb1abd2431ddf7d6b62b,refuted); 0::status(o_eb1abd2431ddf7d6b62b,unknown).
0.25239149623383306::status(o_eb5dbc2db32db19535e4,supported); 0::status(o_eb5dbc2db32db19535e4,refuted); 0.74760850376616694::status(o_eb5dbc2db32db19535e4,unknown).
0.0018518617143854499::status(o_ec0370b4ed1fd4597d65,supported); 0::status(o_ec0370b4ed1fd4597d65,refuted); 0.99814813828561455::status(o_ec0370b4ed1fd4597d65,unknown).
0::status(o_ec10c7d9ea00d34b1091,supported); 1::status(o_ec10c7d9ea00d34b1091,refuted); 0::status(o_ec10c7d9ea00d34b1091,unknown).
1::status(o_ecc201056cb590f6f64a,supported); 0::status(o_ecc201056cb590f6f64a,refuted); 0::status(o_ecc201056cb590f6f64a,unknown).
1::status(o_ecfedabe6ce1e9e563bf,supported); 0::status(o_ecfedabe6ce1e9e563bf,refuted); 0::status(o_ecfedabe6ce1e9e563bf,unknown).
1::status(o_edcc957c1a724bfff80c,supported); 0::status(o_edcc957c1a724bfff80c,refuted); 0::status(o_edcc957c1a724bfff80c,unknown).
0.99185353517532349::status(o_ee8a25ae07d4cb7d488c,supported); 0::status(o_ee8a25ae07d4cb7d488c,refuted); 0.0081464648246765137::status(o_ee8a25ae07d4cb7d488c,unknown).
0.69321541940515385::status(o_ee96f668af800e35740e,supported); 0::status(o_ee96f668af800e35740e,refuted); 0.30678458059484615::status(o_ee96f668af800e35740e,unknown).
0.0013882720377296209::status(o_eefcf2730e38261842f3,supported); 0::status(o_eefcf2730e38261842f3,refuted); 0.99861172796227038::status(o_eefcf2730e38261842f3,unknown).
1::status(o_ef7885eff8b428b2d697,supported); 0::status(o_ef7885eff8b428b2d697,refuted); 0::status(o_ef7885eff8b428b2d697,unknown).
0.002602787222713232::status(o_ef7fb64cd92c4d18ae36,supported); 0::status(o_ef7fb64cd92c4d18ae36,refuted); 0.99739721277728677::status(o_ef7fb64cd92c4d18ae36,unknown).
0.0013008691603317857::status(o_ef9eaadfe73950a55feb,supported); 0::status(o_ef9eaadfe73950a55feb,refuted); 0.99869913083966821::status(o_ef9eaadfe73950a55feb,unknown).
0.041569203389742605::status(o_efb95c5c392d6190bf37,supported); 0::status(o_efb95c5c392d6190bf37,refuted); 0.95843079661025743::status(o_efb95c5c392d6190bf37,unknown).
1::status(o_efc4b8402db4955ec763,supported); 0::status(o_efc4b8402db4955ec763,refuted); 0::status(o_efc4b8402db4955ec763,unknown).
1::status(o_effdd62922efadc0a661,supported); 0::status(o_effdd62922efadc0a661,refuted); 0::status(o_effdd62922efadc0a661,unknown).
0.030841464651434454::status(o_f03e0105113b8fbdc217,supported); 0::status(o_f03e0105113b8fbdc217,refuted); 0.96915853534856555::status(o_f03e0105113b8fbdc217,unknown).
0.51817659690349072::status(o_f0efb8bed3b0ad472d2b,supported); 0::status(o_f0efb8bed3b0ad472d2b,refuted); 0.48182340309650928::status(o_f0efb8bed3b0ad472d2b,unknown).
1::status(o_f0f2adcd016a4375f59e,supported); 0::status(o_f0f2adcd016a4375f59e,refuted); 0::status(o_f0f2adcd016a4375f59e,unknown).
0.72886959124827455::status(o_f10d0ca9ffd170f73344,supported); 0::status(o_f10d0ca9ffd170f73344,refuted); 0.27113040875172545::status(o_f10d0ca9ffd170f73344,unknown).
1::status(o_f12b7cafec8067591f47,supported); 0::status(o_f12b7cafec8067591f47,refuted); 0::status(o_f12b7cafec8067591f47,unknown).
0.039551112800836563::status(o_f14d89ddace4ab765e94,supported); 0::status(o_f14d89ddace4ab765e94,refuted); 0.96044888719916344::status(o_f14d89ddace4ab765e94,unknown).
1::status(o_f152bef1705394970e0d,supported); 0::status(o_f152bef1705394970e0d,refuted); 0::status(o_f152bef1705394970e0d,unknown).
0.976348876953125::status(o_f192e52bd78fde4051a3,supported); 0::status(o_f192e52bd78fde4051a3,refuted); 0.023651123046875::status(o_f192e52bd78fde4051a3,unknown).
0.97427183389663696::status(o_f1e6623d7b7c46c10405,supported); 0::status(o_f1e6623d7b7c46c10405,refuted); 0.025728166103363037::status(o_f1e6623d7b7c46c10405,unknown).
0.39220755016604381::status(o_f1e6893f088760188f97,supported); 0::status(o_f1e6893f088760188f97,refuted); 0.60779244983395619::status(o_f1e6893f088760188f97,unknown).
0.003883931552991271::status(o_f1fb0d85003d55b85afb,supported); 0::status(o_f1fb0d85003d55b85afb,refuted); 0.99611606844700873::status(o_f1fb0d85003d55b85afb,unknown).
0.988739013671875::status(o_f20500244c95629065aa,supported); 0::status(o_f20500244c95629065aa,refuted); 0.011260986328125::status(o_f20500244c95629065aa,unknown).
1::status(o_f222a7cb466a0384cde9,supported); 0::status(o_f222a7cb466a0384cde9,refuted); 0::status(o_f222a7cb466a0384cde9,unknown).
1::status(o_f26234378172ce845679,supported); 0::status(o_f26234378172ce845679,refuted); 0::status(o_f26234378172ce845679,unknown).
0::status(o_f28d10b312bf0d03a0c2,supported); 1::status(o_f28d10b312bf0d03a0c2,refuted); 0::status(o_f28d10b312bf0d03a0c2,unknown).
1::status(o_f296509176f1f25458ff,supported); 0::status(o_f296509176f1f25458ff,refuted); 0::status(o_f296509176f1f25458ff,unknown).
0.26828955437261837::status(o_f2aa9ec1f54dc7d43ce9,supported); 0::status(o_f2aa9ec1f54dc7d43ce9,refuted); 0.73171044562738163::status(o_f2aa9ec1f54dc7d43ce9,unknown).
0.99726450443267822::status(o_f38f2cd83b5b77899ffd,supported); 0::status(o_f38f2cd83b5b77899ffd,refuted); 0.0027354955673217773::status(o_f38f2cd83b5b77899ffd,unknown).
0::status(o_f38fd8f6a7740e88a6f5,supported); 1::status(o_f38fd8f6a7740e88a6f5,refuted); 0::status(o_f38fd8f6a7740e88a6f5,unknown).
0.98928332328796387::status(o_f3ba6319577988a5eec0,supported); 0::status(o_f3ba6319577988a5eec0,refuted); 0.010716676712036133::status(o_f3ba6319577988a5eec0,unknown).
0::status(o_f3badbe5371d1a6eaf14,supported); 1::status(o_f3badbe5371d1a6eaf14,refuted); 0::status(o_f3badbe5371d1a6eaf14,unknown).
0.99506652355194092::status(o_f413e52d14f0ddea856b,supported); 0::status(o_f413e52d14f0ddea856b,refuted); 0.004933476448059082::status(o_f413e52d14f0ddea856b,unknown).
1::status(o_f41fd73b6413f0c763ad,supported); 0::status(o_f41fd73b6413f0c763ad,refuted); 0::status(o_f41fd73b6413f0c763ad,unknown).
0.25723296770265724::status(o_f43886f6e888ee0f00d8,supported); 0::status(o_f43886f6e888ee0f00d8,refuted); 0.74276703229734276::status(o_f43886f6e888ee0f00d8,unknown).
0.0016958331689238548::status(o_f4abca3ab03b7732f812,supported); 0::status(o_f4abca3ab03b7732f812,refuted); 0.99830416683107615::status(o_f4abca3ab03b7732f812,unknown).
0::status(o_f56bcb23fe70ba56277b,supported); 1::status(o_f56bcb23fe70ba56277b,refuted); 0::status(o_f56bcb23fe70ba56277b,unknown).
1::status(o_f5886bd2162651b8f351,supported); 0::status(o_f5886bd2162651b8f351,refuted); 0::status(o_f5886bd2162651b8f351,unknown).
1::status(o_f5cfe65e99955778fc9c,supported); 0::status(o_f5cfe65e99955778fc9c,refuted); 0::status(o_f5cfe65e99955778fc9c,unknown).
1::status(o_f5dcfe29e57d876eb117,supported); 0::status(o_f5dcfe29e57d876eb117,refuted); 0::status(o_f5dcfe29e57d876eb117,unknown).
0.54410483536718113::status(o_f603fce5a2b3ed37902a,supported); 0::status(o_f603fce5a2b3ed37902a,refuted); 0.45589516463281887::status(o_f603fce5a2b3ed37902a,unknown).
0.99213320016860962::status(o_f6120257f80dd19de44a,supported); 0::status(o_f6120257f80dd19de44a,refuted); 0.0078667998313903809::status(o_f6120257f80dd19de44a,unknown).
1::status(o_f6181481a4896d3a6bd4,supported); 0::status(o_f6181481a4896d3a6bd4,refuted); 0::status(o_f6181481a4896d3a6bd4,unknown).
1::status(o_f66e167540304469dcdb,supported); 0::status(o_f66e167540304469dcdb,refuted); 0::status(o_f66e167540304469dcdb,unknown).
0.62305337314760978::status(o_f679bbba7f76f9b70a9c,supported); 0::status(o_f679bbba7f76f9b70a9c,refuted); 0.37694662685239022::status(o_f679bbba7f76f9b70a9c,unknown).
1::status(o_f67e07f893ed4e6105f8,supported); 0::status(o_f67e07f893ed4e6105f8,refuted); 0::status(o_f67e07f893ed4e6105f8,unknown).
0.0070033296942710876::status(o_f6db66f336f3c9742961,supported); 0::status(o_f6db66f336f3c9742961,refuted); 0.99299667030572891::status(o_f6db66f336f3c9742961,unknown).
1::status(o_f790596b85b8ff79e38c,supported); 0::status(o_f790596b85b8ff79e38c,refuted); 0::status(o_f790596b85b8ff79e38c,unknown).
1::status(o_f7e156383510e9dfb240,supported); 0::status(o_f7e156383510e9dfb240,refuted); 0::status(o_f7e156383510e9dfb240,unknown).
1::status(o_f7f0d7b2186d8fe0fef9,supported); 0::status(o_f7f0d7b2186d8fe0fef9,refuted); 0::status(o_f7f0d7b2186d8fe0fef9,unknown).
0::status(o_f7fcaa37851f7cbed69f,supported); 1::status(o_f7fcaa37851f7cbed69f,refuted); 0::status(o_f7fcaa37851f7cbed69f,unknown).
0.088479405165872757::status(o_f83648b580bb845d7add,supported); 0::status(o_f83648b580bb845d7add,refuted); 0.91152059483412728::status(o_f83648b580bb845d7add,unknown).
1::status(o_f84333ca8e71d6da24ab,supported); 0::status(o_f84333ca8e71d6da24ab,refuted); 0::status(o_f84333ca8e71d6da24ab,unknown).
0.0047103664837777615::status(o_f8947ca704c3a19cd4a6,supported); 0::status(o_f8947ca704c3a19cd4a6,refuted); 0.99528963351622224::status(o_f8947ca704c3a19cd4a6,unknown).
0.17032217937338145::status(o_f8e5ef4099cfcfdcaccd,supported); 0::status(o_f8e5ef4099cfcfdcaccd,refuted); 0.82967782062661855::status(o_f8e5ef4099cfcfdcaccd,unknown).
1::status(o_f92a43a4b7026f2e16f6,supported); 0::status(o_f92a43a4b7026f2e16f6,refuted); 0::status(o_f92a43a4b7026f2e16f6,unknown).
1::status(o_f99f5148bbe294fb2ad2,supported); 0::status(o_f99f5148bbe294fb2ad2,refuted); 0::status(o_f99f5148bbe294fb2ad2,unknown).
1::status(o_f9fcc8d8663b60758d8a,supported); 0::status(o_f9fcc8d8663b60758d8a,refuted); 0::status(o_f9fcc8d8663b60758d8a,unknown).
1::status(o_fa066b66d698c70c7011,supported); 0::status(o_fa066b66d698c70c7011,refuted); 0::status(o_fa066b66d698c70c7011,unknown).
1::status(o_fa3447bb9429caee23e0,supported); 0::status(o_fa3447bb9429caee23e0,refuted); 0::status(o_fa3447bb9429caee23e0,unknown).
1::status(o_fa38eb0be12aee6aa93c,supported); 0::status(o_fa38eb0be12aee6aa93c,refuted); 0::status(o_fa38eb0be12aee6aa93c,unknown).
0.17362482252580305::status(o_fa8b5ae6b60ab04fcffe,supported); 0::status(o_fa8b5ae6b60ab04fcffe,refuted); 0.82637517747419698::status(o_fa8b5ae6b60ab04fcffe,unknown).
1::status(o_fa9fcdce03ef829a9373,supported); 0::status(o_fa9fcdce03ef829a9373,refuted); 0::status(o_fa9fcdce03ef829a9373,unknown).
0::status(o_faa3fd928be9cc6fff93,supported); 1::status(o_faa3fd928be9cc6fff93,refuted); 0::status(o_faa3fd928be9cc6fff93,unknown).
0.24720217475481024::status(o_fb303ae9a5163291104d,supported); 0::status(o_fb303ae9a5163291104d,refuted); 0.75279782524518979::status(o_fb303ae9a5163291104d,unknown).
0.1935151324992867::status(o_fb48c389cd39727c9307,supported); 0::status(o_fb48c389cd39727c9307,refuted); 0.80648486750071324::status(o_fb48c389cd39727c9307,unknown).
1::status(o_fb4f999100b6d242ae1c,supported); 0::status(o_fb4f999100b6d242ae1c,refuted); 0::status(o_fb4f999100b6d242ae1c,unknown).
0.64424905361761975::status(o_fb68810a4bd828d5a04a,supported); 0::status(o_fb68810a4bd828d5a04a,refuted); 0.35575094638238025::status(o_fb68810a4bd828d5a04a,unknown).
1::status(o_fb8f4bb93e7d143d0497,supported); 0::status(o_fb8f4bb93e7d143d0497,refuted); 0::status(o_fb8f4bb93e7d143d0497,unknown).
0::status(o_fbd740e0ed92baed7d02,supported); 1::status(o_fbd740e0ed92baed7d02,refuted); 0::status(o_fbd740e0ed92baed7d02,unknown).
0.96227091550827026::status(o_fbfbd5bd60bb6478e94d,supported); 0::status(o_fbfbd5bd60bb6478e94d,refuted); 0.037729084491729736::status(o_fbfbd5bd60bb6478e94d,unknown).
0.60430598979781869::status(o_fbfd1ecc8996c0d6ed75,supported); 0::status(o_fbfd1ecc8996c0d6ed75,refuted); 0.39569401020218131::status(o_fbfd1ecc8996c0d6ed75,unknown).
0.015679161995649338::status(o_fc2a7d9023c3179aeab6,supported); 0::status(o_fc2a7d9023c3179aeab6,refuted); 0.98432083800435066::status(o_fc2a7d9023c3179aeab6,unknown).
0.0044489046558737755::status(o_fc2e2391ee64e5b1be81,supported); 0::status(o_fc2e2391ee64e5b1be81,refuted); 0.99555109534412622::status(o_fc2e2391ee64e5b1be81,unknown).
0.037853103131055832::status(o_fc4cd149b7981ae5e396,supported); 0::status(o_fc4cd149b7981ae5e396,refuted); 0.96214689686894417::status(o_fc4cd149b7981ae5e396,unknown).
0.96754372119903564::status(o_fc5d172618695dffb3b5,supported); 0::status(o_fc5d172618695dffb3b5,refuted); 0.032456278800964355::status(o_fc5d172618695dffb3b5,unknown).
0.0060011227615177631::status(o_fc95ca510d87dd43e20f,supported); 0::status(o_fc95ca510d87dd43e20f,refuted); 0.99399887723848224::status(o_fc95ca510d87dd43e20f,unknown).
1::status(o_fcd4bd69e38e07fd54f8,supported); 0::status(o_fcd4bd69e38e07fd54f8,refuted); 0::status(o_fcd4bd69e38e07fd54f8,unknown).
1::status(o_fd58f4d4dffe33849075,supported); 0::status(o_fd58f4d4dffe33849075,refuted); 0::status(o_fd58f4d4dffe33849075,unknown).
1::status(o_fd5ce9e04ccbd3385b3a,supported); 0::status(o_fd5ce9e04ccbd3385b3a,refuted); 0::status(o_fd5ce9e04ccbd3385b3a,unknown).
1::status(o_fd8b24f518d8ddb9e11e,supported); 0::status(o_fd8b24f518d8ddb9e11e,refuted); 0::status(o_fd8b24f518d8ddb9e11e,unknown).
1::status(o_fdaed9c3037474490813,supported); 0::status(o_fdaed9c3037474490813,refuted); 0::status(o_fdaed9c3037474490813,unknown).
0::status(o_fdc55e0b47ccc863e214,supported); 1::status(o_fdc55e0b47ccc863e214,refuted); 0::status(o_fdc55e0b47ccc863e214,unknown).
0.2129049152135849::status(o_fdd34cba933e30603ae3,supported); 0::status(o_fdd34cba933e30603ae3,refuted); 0.7870950847864151::status(o_fdd34cba933e30603ae3,unknown).
0.0029208550695329905::status(o_fdf425be58da49361244,supported); 0::status(o_fdf425be58da49361244,refuted); 0.99707914493046701::status(o_fdf425be58da49361244,unknown).
1::status(o_fe210805d494555d3cfd,supported); 0::status(o_fe210805d494555d3cfd,refuted); 0::status(o_fe210805d494555d3cfd,unknown).
0.0070033296942710876::status(o_fe68e2af69465782ff98,supported); 0::status(o_fe68e2af69465782ff98,refuted); 0.99299667030572891::status(o_fe68e2af69465782ff98,unknown).
0.44626516994090804::status(o_fe94407da10c20b74e32,supported); 0::status(o_fe94407da10c20b74e32,refuted); 0.55373483005909196::status(o_fe94407da10c20b74e32,unknown).
1::status(o_ff2623d54849c287222a,supported); 0::status(o_ff2623d54849c287222a,refuted); 0::status(o_ff2623d54849c287222a,unknown).
0.32363972038869959::status(o_ff5dd9e930964d939c3a,supported); 0::status(o_ff5dd9e930964d939c3a,refuted); 0.67636027961130041::status(o_ff5dd9e930964d939c3a,unknown).
0.20895986134710581::status(o_ffa8445aaa77c1e56ac2,supported); 0::status(o_ffa8445aaa77c1e56ac2,refuted); 0.79104013865289424::status(o_ffa8445aaa77c1e56ac2,unknown).
1::status(o_ffb3956df782ee078548,supported); 0::status(o_ffb3956df782ee078548,refuted); 0::status(o_ffb3956df782ee078548,unknown).
1::status(o_fff85f6daeee8d2fda36,supported); 0::status(o_fff85f6daeee8d2fda36,refuted); 0::status(o_fff85f6daeee8d2fda36,unknown).
node(n2,supported) :- status(o_626b65d31b3b92b99320,supported).
node(n2,refuted) :- status(o_626b65d31b3b92b99320,refuted).
node(n2,unknown) :- status(o_626b65d31b3b92b99320,unknown).
node(n3,supported) :- status(o_420ab2af0de775219296,supported).
node(n3,refuted) :- status(o_420ab2af0de775219296,refuted).
node(n3,unknown) :- status(o_420ab2af0de775219296,unknown).
node(n4,supported) :- status(o_d020f413985a6f53df52,supported).
node(n4,refuted) :- status(o_d020f413985a6f53df52,refuted).
node(n4,unknown) :- status(o_d020f413985a6f53df52,unknown).
node(n1,supported) :- node(n2,supported), node(n3,supported), node(n4,supported).
node(n1,refuted) :- node(n2,refuted).
node(n1,refuted) :- node(n3,refuted).
node(n1,refuted) :- node(n4,refuted).
node(n1,unknown) :- \+ node(n1,supported), \+ node(n1,refuted).
node(n6,supported) :- status(o_f56bcb23fe70ba56277b,supported).
node(n6,refuted) :- status(o_f56bcb23fe70ba56277b,refuted).
node(n6,unknown) :- status(o_f56bcb23fe70ba56277b,unknown).
node(n7,supported) :- status(o_1323d3792df5a3a36716,supported).
node(n7,refuted) :- status(o_1323d3792df5a3a36716,refuted).
node(n7,unknown) :- status(o_1323d3792df5a3a36716,unknown).
node(n8,supported) :- status(o_151613d849b42fc0def6,supported).
node(n8,refuted) :- status(o_151613d849b42fc0def6,refuted).
node(n8,unknown) :- status(o_151613d849b42fc0def6,unknown).
node(n5,supported) :- node(n6,supported), node(n7,supported), node(n8,supported).
node(n5,refuted) :- node(n6,refuted).
node(n5,refuted) :- node(n7,refuted).
node(n5,refuted) :- node(n8,refuted).
node(n5,unknown) :- \+ node(n5,supported), \+ node(n5,refuted).
node(n9,unknown).
node(n0,refuted) :- node(n1,refuted), node(n5,refuted), node(n9,refuted).
node(n0,supported) :- node(n1,supported).
node(n0,supported) :- node(n5,supported).
node(n0,supported) :- node(n9,supported).
node(n0,unknown) :- \+ node(n0,supported), \+ node(n0,refuted).
verdict(c_c7f5eeda9a99c2f3,supported) :- node(n0,supported).
query(verdict(c_c7f5eeda9a99c2f3,supported)).
verdict(c_c7f5eeda9a99c2f3,refuted) :- node(n0,refuted).
query(verdict(c_c7f5eeda9a99c2f3,refuted)).
verdict(c_c7f5eeda9a99c2f3,unknown) :- node(n0,unknown).
query(verdict(c_c7f5eeda9a99c2f3,unknown)).
node(n12,supported) :- status(o_b328e9ca52ef1bfa898c,supported).
node(n12,refuted) :- status(o_b328e9ca52ef1bfa898c,refuted).
node(n12,unknown) :- status(o_b328e9ca52ef1bfa898c,unknown).
node(n11,supported) :- node(n2,supported), node(n3,supported), node(n12,supported), node(n4,supported).
node(n11,refuted) :- node(n2,refuted).
node(n11,refuted) :- node(n3,refuted).
node(n11,refuted) :- node(n12,refuted).
node(n11,refuted) :- node(n4,refuted).
node(n11,unknown) :- \+ node(n11,supported), \+ node(n11,refuted).
node(n14,supported) :- status(o_3703f0e48dbff253ad64,supported).
node(n14,refuted) :- status(o_3703f0e48dbff253ad64,refuted).
node(n14,unknown) :- status(o_3703f0e48dbff253ad64,unknown).
node(n13,supported) :- node(n6,supported), node(n7,supported), node(n14,supported), node(n8,supported).
node(n13,refuted) :- node(n6,refuted).
node(n13,refuted) :- node(n7,refuted).
node(n13,refuted) :- node(n14,refuted).
node(n13,refuted) :- node(n8,refuted).
node(n13,unknown) :- \+ node(n13,supported), \+ node(n13,refuted).
node(n10,refuted) :- node(n11,refuted), node(n13,refuted), node(n9,refuted).
node(n10,supported) :- node(n11,supported).
node(n10,supported) :- node(n13,supported).
node(n10,supported) :- node(n9,supported).
node(n10,unknown) :- \+ node(n10,supported), \+ node(n10,refuted).
verdict(c_2e4a0e2883d08423,supported) :- node(n10,supported).
query(verdict(c_2e4a0e2883d08423,supported)).
verdict(c_2e4a0e2883d08423,refuted) :- node(n10,refuted).
query(verdict(c_2e4a0e2883d08423,refuted)).
verdict(c_2e4a0e2883d08423,unknown) :- node(n10,unknown).
query(verdict(c_2e4a0e2883d08423,unknown)).
node(n17,supported) :- status(o_f12b7cafec8067591f47,supported).
node(n17,refuted) :- status(o_f12b7cafec8067591f47,refuted).
node(n17,unknown) :- status(o_f12b7cafec8067591f47,unknown).
node(n18,supported) :- status(o_5594deda7efcd63d3b5e,supported).
node(n18,refuted) :- status(o_5594deda7efcd63d3b5e,refuted).
node(n18,unknown) :- status(o_5594deda7efcd63d3b5e,unknown).
node(n19,supported) :- status(o_7ae1b46cef3b45e7f186,supported).
node(n19,refuted) :- status(o_7ae1b46cef3b45e7f186,refuted).
node(n19,unknown) :- status(o_7ae1b46cef3b45e7f186,unknown).
node(n16,supported) :- node(n17,supported), node(n18,supported), node(n19,supported).
node(n16,refuted) :- node(n17,refuted).
node(n16,refuted) :- node(n18,refuted).
node(n16,refuted) :- node(n19,refuted).
node(n16,unknown) :- \+ node(n16,supported), \+ node(n16,refuted).
node(n21,supported) :- status(o_8c86a75ab4104376f2d2,supported).
node(n21,refuted) :- status(o_8c86a75ab4104376f2d2,refuted).
node(n21,unknown) :- status(o_8c86a75ab4104376f2d2,unknown).
node(n22,supported) :- status(o_6194dd554d41d13db0ab,supported).
node(n22,refuted) :- status(o_6194dd554d41d13db0ab,refuted).
node(n22,unknown) :- status(o_6194dd554d41d13db0ab,unknown).
node(n23,supported) :- status(o_87886bde68ce53859ce7,supported).
node(n23,refuted) :- status(o_87886bde68ce53859ce7,refuted).
node(n23,unknown) :- status(o_87886bde68ce53859ce7,unknown).
node(n20,supported) :- node(n21,supported), node(n22,supported), node(n23,supported).
node(n20,refuted) :- node(n21,refuted).
node(n20,refuted) :- node(n22,refuted).
node(n20,refuted) :- node(n23,refuted).
node(n20,unknown) :- \+ node(n20,supported), \+ node(n20,refuted).
node(n15,refuted) :- node(n16,refuted), node(n20,refuted), node(n9,refuted).
node(n15,supported) :- node(n16,supported).
node(n15,supported) :- node(n20,supported).
node(n15,supported) :- node(n9,supported).
node(n15,unknown) :- \+ node(n15,supported), \+ node(n15,refuted).
verdict(c_e52bf3330ff532a3,supported) :- node(n15,supported).
query(verdict(c_e52bf3330ff532a3,supported)).
verdict(c_e52bf3330ff532a3,refuted) :- node(n15,refuted).
query(verdict(c_e52bf3330ff532a3,refuted)).
verdict(c_e52bf3330ff532a3,unknown) :- node(n15,unknown).
query(verdict(c_e52bf3330ff532a3,unknown)).
node(n26,supported) :- status(o_975f5231325659ca3bed,supported).
node(n26,refuted) :- status(o_975f5231325659ca3bed,refuted).
node(n26,unknown) :- status(o_975f5231325659ca3bed,unknown).
node(n25,supported) :- node(n17,supported), node(n18,supported), node(n26,supported), node(n19,supported).
node(n25,refuted) :- node(n17,refuted).
node(n25,refuted) :- node(n18,refuted).
node(n25,refuted) :- node(n26,refuted).
node(n25,refuted) :- node(n19,refuted).
node(n25,unknown) :- \+ node(n25,supported), \+ node(n25,refuted).
node(n28,supported) :- status(o_f6db66f336f3c9742961,supported).
node(n28,refuted) :- status(o_f6db66f336f3c9742961,refuted).
node(n28,unknown) :- status(o_f6db66f336f3c9742961,unknown).
node(n27,supported) :- node(n21,supported), node(n22,supported), node(n28,supported), node(n23,supported).
node(n27,refuted) :- node(n21,refuted).
node(n27,refuted) :- node(n22,refuted).
node(n27,refuted) :- node(n28,refuted).
node(n27,refuted) :- node(n23,refuted).
node(n27,unknown) :- \+ node(n27,supported), \+ node(n27,refuted).
node(n24,refuted) :- node(n25,refuted), node(n27,refuted), node(n9,refuted).
node(n24,supported) :- node(n25,supported).
node(n24,supported) :- node(n27,supported).
node(n24,supported) :- node(n9,supported).
node(n24,unknown) :- \+ node(n24,supported), \+ node(n24,refuted).
verdict(c_278c8e93584145f2,supported) :- node(n24,supported).
query(verdict(c_278c8e93584145f2,supported)).
verdict(c_278c8e93584145f2,refuted) :- node(n24,refuted).
query(verdict(c_278c8e93584145f2,refuted)).
verdict(c_278c8e93584145f2,unknown) :- node(n24,unknown).
query(verdict(c_278c8e93584145f2,unknown)).
node(n31,supported) :- status(o_7382abb16ee50d667551,supported).
node(n31,refuted) :- status(o_7382abb16ee50d667551,refuted).
node(n31,unknown) :- status(o_7382abb16ee50d667551,unknown).
node(n32,supported) :- status(o_4c34fc29dd7bd15ba929,supported).
node(n32,refuted) :- status(o_4c34fc29dd7bd15ba929,refuted).
node(n32,unknown) :- status(o_4c34fc29dd7bd15ba929,unknown).
node(n33,supported) :- status(o_f83648b580bb845d7add,supported).
node(n33,refuted) :- status(o_f83648b580bb845d7add,refuted).
node(n33,unknown) :- status(o_f83648b580bb845d7add,unknown).
node(n30,supported) :- node(n31,supported), node(n32,supported), node(n33,supported).
node(n30,refuted) :- node(n31,refuted).
node(n30,refuted) :- node(n32,refuted).
node(n30,refuted) :- node(n33,refuted).
node(n30,unknown) :- \+ node(n30,supported), \+ node(n30,refuted).
node(n35,supported) :- status(o_28363b70e799e5f58c6c,supported).
node(n35,refuted) :- status(o_28363b70e799e5f58c6c,refuted).
node(n35,unknown) :- status(o_28363b70e799e5f58c6c,unknown).
node(n36,supported) :- status(o_013590ea4e7cd47378f9,supported).
node(n36,refuted) :- status(o_013590ea4e7cd47378f9,refuted).
node(n36,unknown) :- status(o_013590ea4e7cd47378f9,unknown).
node(n37,supported) :- status(o_6cff6c9209477777094e,supported).
node(n37,refuted) :- status(o_6cff6c9209477777094e,refuted).
node(n37,unknown) :- status(o_6cff6c9209477777094e,unknown).
node(n34,supported) :- node(n35,supported), node(n36,supported), node(n37,supported).
node(n34,refuted) :- node(n35,refuted).
node(n34,refuted) :- node(n36,refuted).
node(n34,refuted) :- node(n37,refuted).
node(n34,unknown) :- \+ node(n34,supported), \+ node(n34,refuted).
node(n29,refuted) :- node(n30,refuted), node(n34,refuted), node(n9,refuted).
node(n29,supported) :- node(n30,supported).
node(n29,supported) :- node(n34,supported).
node(n29,supported) :- node(n9,supported).
node(n29,unknown) :- \+ node(n29,supported), \+ node(n29,refuted).
verdict(c_abc20b853eb66b22,supported) :- node(n29,supported).
query(verdict(c_abc20b853eb66b22,supported)).
verdict(c_abc20b853eb66b22,refuted) :- node(n29,refuted).
query(verdict(c_abc20b853eb66b22,refuted)).
verdict(c_abc20b853eb66b22,unknown) :- node(n29,unknown).
query(verdict(c_abc20b853eb66b22,unknown)).
node(n40,supported) :- status(o_72b91ad6971397c1f622,supported).
node(n40,refuted) :- status(o_72b91ad6971397c1f622,refuted).
node(n40,unknown) :- status(o_72b91ad6971397c1f622,unknown).
node(n39,supported) :- node(n31,supported), node(n32,supported), node(n40,supported), node(n33,supported).
node(n39,refuted) :- node(n31,refuted).
node(n39,refuted) :- node(n32,refuted).
node(n39,refuted) :- node(n40,refuted).
node(n39,refuted) :- node(n33,refuted).
node(n39,unknown) :- \+ node(n39,supported), \+ node(n39,refuted).
node(n42,supported) :- status(o_7a797b663c4aec95363b,supported).
node(n42,refuted) :- status(o_7a797b663c4aec95363b,refuted).
node(n42,unknown) :- status(o_7a797b663c4aec95363b,unknown).
node(n41,supported) :- node(n35,supported), node(n36,supported), node(n42,supported), node(n37,supported).
node(n41,refuted) :- node(n35,refuted).
node(n41,refuted) :- node(n36,refuted).
node(n41,refuted) :- node(n42,refuted).
node(n41,refuted) :- node(n37,refuted).
node(n41,unknown) :- \+ node(n41,supported), \+ node(n41,refuted).
node(n38,refuted) :- node(n39,refuted), node(n41,refuted), node(n9,refuted).
node(n38,supported) :- node(n39,supported).
node(n38,supported) :- node(n41,supported).
node(n38,supported) :- node(n9,supported).
node(n38,unknown) :- \+ node(n38,supported), \+ node(n38,refuted).
verdict(c_8b57ed2a02045944,supported) :- node(n38,supported).
query(verdict(c_8b57ed2a02045944,supported)).
verdict(c_8b57ed2a02045944,refuted) :- node(n38,refuted).
query(verdict(c_8b57ed2a02045944,refuted)).
verdict(c_8b57ed2a02045944,unknown) :- node(n38,unknown).
query(verdict(c_8b57ed2a02045944,unknown)).
node(n45,supported) :- status(o_a105a99b1d10b026cfdf,supported).
node(n45,refuted) :- status(o_a105a99b1d10b026cfdf,refuted).
node(n45,unknown) :- status(o_a105a99b1d10b026cfdf,unknown).
node(n46,supported) :- status(o_04a19c86c299e7e9dd4f,supported).
node(n46,refuted) :- status(o_04a19c86c299e7e9dd4f,refuted).
node(n46,unknown) :- status(o_04a19c86c299e7e9dd4f,unknown).
node(n47,supported) :- status(o_2d8988a2d77d10ef5109,supported).
node(n47,refuted) :- status(o_2d8988a2d77d10ef5109,refuted).
node(n47,unknown) :- status(o_2d8988a2d77d10ef5109,unknown).
node(n44,supported) :- node(n45,supported), node(n46,supported), node(n47,supported).
node(n44,refuted) :- node(n45,refuted).
node(n44,refuted) :- node(n46,refuted).
node(n44,refuted) :- node(n47,refuted).
node(n44,unknown) :- \+ node(n44,supported), \+ node(n44,refuted).
node(n49,supported) :- status(o_8cadb48d16c9918b926c,supported).
node(n49,refuted) :- status(o_8cadb48d16c9918b926c,refuted).
node(n49,unknown) :- status(o_8cadb48d16c9918b926c,unknown).
node(n50,supported) :- status(o_f41fd73b6413f0c763ad,supported).
node(n50,refuted) :- status(o_f41fd73b6413f0c763ad,refuted).
node(n50,unknown) :- status(o_f41fd73b6413f0c763ad,unknown).
node(n51,supported) :- status(o_b527cafd80424f77a0cc,supported).
node(n51,refuted) :- status(o_b527cafd80424f77a0cc,refuted).
node(n51,unknown) :- status(o_b527cafd80424f77a0cc,unknown).
node(n48,supported) :- node(n49,supported), node(n50,supported), node(n51,supported).
node(n48,refuted) :- node(n49,refuted).
node(n48,refuted) :- node(n50,refuted).
node(n48,refuted) :- node(n51,refuted).
node(n48,unknown) :- \+ node(n48,supported), \+ node(n48,refuted).
node(n43,refuted) :- node(n44,refuted), node(n48,refuted), node(n9,refuted).
node(n43,supported) :- node(n44,supported).
node(n43,supported) :- node(n48,supported).
node(n43,supported) :- node(n9,supported).
node(n43,unknown) :- \+ node(n43,supported), \+ node(n43,refuted).
verdict(c_b85ef4e6c0b71019,supported) :- node(n43,supported).
query(verdict(c_b85ef4e6c0b71019,supported)).
verdict(c_b85ef4e6c0b71019,refuted) :- node(n43,refuted).
query(verdict(c_b85ef4e6c0b71019,refuted)).
verdict(c_b85ef4e6c0b71019,unknown) :- node(n43,unknown).
query(verdict(c_b85ef4e6c0b71019,unknown)).
node(n54,supported) :- status(o_5143c4f9ecc7ce300335,supported).
node(n54,refuted) :- status(o_5143c4f9ecc7ce300335,refuted).
node(n54,unknown) :- status(o_5143c4f9ecc7ce300335,unknown).
node(n53,supported) :- node(n45,supported), node(n46,supported), node(n54,supported), node(n47,supported).
node(n53,refuted) :- node(n45,refuted).
node(n53,refuted) :- node(n46,refuted).
node(n53,refuted) :- node(n54,refuted).
node(n53,refuted) :- node(n47,refuted).
node(n53,unknown) :- \+ node(n53,supported), \+ node(n53,refuted).
node(n56,supported) :- status(o_4b84c45365ec494c93a2,supported).
node(n56,refuted) :- status(o_4b84c45365ec494c93a2,refuted).
node(n56,unknown) :- status(o_4b84c45365ec494c93a2,unknown).
node(n55,supported) :- node(n49,supported), node(n50,supported), node(n56,supported), node(n51,supported).
node(n55,refuted) :- node(n49,refuted).
node(n55,refuted) :- node(n50,refuted).
node(n55,refuted) :- node(n56,refuted).
node(n55,refuted) :- node(n51,refuted).
node(n55,unknown) :- \+ node(n55,supported), \+ node(n55,refuted).
node(n52,refuted) :- node(n53,refuted), node(n55,refuted), node(n9,refuted).
node(n52,supported) :- node(n53,supported).
node(n52,supported) :- node(n55,supported).
node(n52,supported) :- node(n9,supported).
node(n52,unknown) :- \+ node(n52,supported), \+ node(n52,refuted).
verdict(c_1e146824ff06381b,supported) :- node(n52,supported).
query(verdict(c_1e146824ff06381b,supported)).
verdict(c_1e146824ff06381b,refuted) :- node(n52,refuted).
query(verdict(c_1e146824ff06381b,refuted)).
verdict(c_1e146824ff06381b,unknown) :- node(n52,unknown).
query(verdict(c_1e146824ff06381b,unknown)).
node(n59,supported) :- status(o_ca9f6f63879a2153f2cf,supported).
node(n59,refuted) :- status(o_ca9f6f63879a2153f2cf,refuted).
node(n59,unknown) :- status(o_ca9f6f63879a2153f2cf,unknown).
node(n60,supported) :- status(o_88312bff917834c6249f,supported).
node(n60,refuted) :- status(o_88312bff917834c6249f,refuted).
node(n60,unknown) :- status(o_88312bff917834c6249f,unknown).
node(n61,supported) :- status(o_5d899fd43466722082ff,supported).
node(n61,refuted) :- status(o_5d899fd43466722082ff,refuted).
node(n61,unknown) :- status(o_5d899fd43466722082ff,unknown).
node(n58,supported) :- node(n59,supported), node(n60,supported), node(n61,supported).
node(n58,refuted) :- node(n59,refuted).
node(n58,refuted) :- node(n60,refuted).
node(n58,refuted) :- node(n61,refuted).
node(n58,unknown) :- \+ node(n58,supported), \+ node(n58,refuted).
node(n63,supported) :- status(o_62af9e58173e39eba6d3,supported).
node(n63,refuted) :- status(o_62af9e58173e39eba6d3,refuted).
node(n63,unknown) :- status(o_62af9e58173e39eba6d3,unknown).
node(n64,supported) :- status(o_f99f5148bbe294fb2ad2,supported).
node(n64,refuted) :- status(o_f99f5148bbe294fb2ad2,refuted).
node(n64,unknown) :- status(o_f99f5148bbe294fb2ad2,unknown).
node(n65,supported) :- status(o_bb2375f6aafe3f649c3a,supported).
node(n65,refuted) :- status(o_bb2375f6aafe3f649c3a,refuted).
node(n65,unknown) :- status(o_bb2375f6aafe3f649c3a,unknown).
node(n62,supported) :- node(n63,supported), node(n64,supported), node(n65,supported).
node(n62,refuted) :- node(n63,refuted).
node(n62,refuted) :- node(n64,refuted).
node(n62,refuted) :- node(n65,refuted).
node(n62,unknown) :- \+ node(n62,supported), \+ node(n62,refuted).
node(n57,refuted) :- node(n58,refuted), node(n62,refuted), node(n9,refuted).
node(n57,supported) :- node(n58,supported).
node(n57,supported) :- node(n62,supported).
node(n57,supported) :- node(n9,supported).
node(n57,unknown) :- \+ node(n57,supported), \+ node(n57,refuted).
verdict(c_0aedbe8153f2130d,supported) :- node(n57,supported).
query(verdict(c_0aedbe8153f2130d,supported)).
verdict(c_0aedbe8153f2130d,refuted) :- node(n57,refuted).
query(verdict(c_0aedbe8153f2130d,refuted)).
verdict(c_0aedbe8153f2130d,unknown) :- node(n57,unknown).
query(verdict(c_0aedbe8153f2130d,unknown)).
node(n68,supported) :- status(o_e763b1a16b0ea19be3a5,supported).
node(n68,refuted) :- status(o_e763b1a16b0ea19be3a5,refuted).
node(n68,unknown) :- status(o_e763b1a16b0ea19be3a5,unknown).
node(n67,supported) :- node(n59,supported), node(n60,supported), node(n68,supported), node(n61,supported).
node(n67,refuted) :- node(n59,refuted).
node(n67,refuted) :- node(n60,refuted).
node(n67,refuted) :- node(n68,refuted).
node(n67,refuted) :- node(n61,refuted).
node(n67,unknown) :- \+ node(n67,supported), \+ node(n67,refuted).
node(n70,supported) :- status(o_d61bb4b8886a9f23b31b,supported).
node(n70,refuted) :- status(o_d61bb4b8886a9f23b31b,refuted).
node(n70,unknown) :- status(o_d61bb4b8886a9f23b31b,unknown).
node(n69,supported) :- node(n63,supported), node(n64,supported), node(n70,supported), node(n65,supported).
node(n69,refuted) :- node(n63,refuted).
node(n69,refuted) :- node(n64,refuted).
node(n69,refuted) :- node(n70,refuted).
node(n69,refuted) :- node(n65,refuted).
node(n69,unknown) :- \+ node(n69,supported), \+ node(n69,refuted).
node(n66,refuted) :- node(n67,refuted), node(n69,refuted), node(n9,refuted).
node(n66,supported) :- node(n67,supported).
node(n66,supported) :- node(n69,supported).
node(n66,supported) :- node(n9,supported).
node(n66,unknown) :- \+ node(n66,supported), \+ node(n66,refuted).
verdict(c_1e9fcb857c1d2a37,supported) :- node(n66,supported).
query(verdict(c_1e9fcb857c1d2a37,supported)).
verdict(c_1e9fcb857c1d2a37,refuted) :- node(n66,refuted).
query(verdict(c_1e9fcb857c1d2a37,refuted)).
verdict(c_1e9fcb857c1d2a37,unknown) :- node(n66,unknown).
query(verdict(c_1e9fcb857c1d2a37,unknown)).
node(n73,supported) :- status(o_19bfb78ed1d6c099b760,supported).
node(n73,refuted) :- status(o_19bfb78ed1d6c099b760,refuted).
node(n73,unknown) :- status(o_19bfb78ed1d6c099b760,unknown).
node(n74,supported) :- status(o_e9228a40cfdd2d28b9d7,supported).
node(n74,refuted) :- status(o_e9228a40cfdd2d28b9d7,refuted).
node(n74,unknown) :- status(o_e9228a40cfdd2d28b9d7,unknown).
node(n75,supported) :- status(o_e30fa74c680bc3514176,supported).
node(n75,refuted) :- status(o_e30fa74c680bc3514176,refuted).
node(n75,unknown) :- status(o_e30fa74c680bc3514176,unknown).
node(n72,supported) :- node(n73,supported), node(n74,supported), node(n75,supported).
node(n72,refuted) :- node(n73,refuted).
node(n72,refuted) :- node(n74,refuted).
node(n72,refuted) :- node(n75,refuted).
node(n72,unknown) :- \+ node(n72,supported), \+ node(n72,refuted).
node(n77,supported) :- status(o_ad28a0fef7501f900959,supported).
node(n77,refuted) :- status(o_ad28a0fef7501f900959,refuted).
node(n77,unknown) :- status(o_ad28a0fef7501f900959,unknown).
node(n78,supported) :- status(o_7e0854b5c7269b6e3e2f,supported).
node(n78,refuted) :- status(o_7e0854b5c7269b6e3e2f,refuted).
node(n78,unknown) :- status(o_7e0854b5c7269b6e3e2f,unknown).
node(n79,supported) :- status(o_3f872fd87aefd55acf08,supported).
node(n79,refuted) :- status(o_3f872fd87aefd55acf08,refuted).
node(n79,unknown) :- status(o_3f872fd87aefd55acf08,unknown).
node(n76,supported) :- node(n77,supported), node(n78,supported), node(n79,supported).
node(n76,refuted) :- node(n77,refuted).
node(n76,refuted) :- node(n78,refuted).
node(n76,refuted) :- node(n79,refuted).
node(n76,unknown) :- \+ node(n76,supported), \+ node(n76,refuted).
node(n71,refuted) :- node(n72,refuted), node(n76,refuted), node(n9,refuted).
node(n71,supported) :- node(n72,supported).
node(n71,supported) :- node(n76,supported).
node(n71,supported) :- node(n9,supported).
node(n71,unknown) :- \+ node(n71,supported), \+ node(n71,refuted).
verdict(c_b9f252616e87829a,supported) :- node(n71,supported).
query(verdict(c_b9f252616e87829a,supported)).
verdict(c_b9f252616e87829a,refuted) :- node(n71,refuted).
query(verdict(c_b9f252616e87829a,refuted)).
verdict(c_b9f252616e87829a,unknown) :- node(n71,unknown).
query(verdict(c_b9f252616e87829a,unknown)).
node(n82,supported) :- status(o_7330bc82f088bb7191f6,supported).
node(n82,refuted) :- status(o_7330bc82f088bb7191f6,refuted).
node(n82,unknown) :- status(o_7330bc82f088bb7191f6,unknown).
node(n81,supported) :- node(n73,supported), node(n74,supported), node(n82,supported), node(n75,supported).
node(n81,refuted) :- node(n73,refuted).
node(n81,refuted) :- node(n74,refuted).
node(n81,refuted) :- node(n82,refuted).
node(n81,refuted) :- node(n75,refuted).
node(n81,unknown) :- \+ node(n81,supported), \+ node(n81,refuted).
node(n84,supported) :- status(o_fe68e2af69465782ff98,supported).
node(n84,refuted) :- status(o_fe68e2af69465782ff98,refuted).
node(n84,unknown) :- status(o_fe68e2af69465782ff98,unknown).
node(n83,supported) :- node(n77,supported), node(n78,supported), node(n84,supported), node(n79,supported).
node(n83,refuted) :- node(n77,refuted).
node(n83,refuted) :- node(n78,refuted).
node(n83,refuted) :- node(n84,refuted).
node(n83,refuted) :- node(n79,refuted).
node(n83,unknown) :- \+ node(n83,supported), \+ node(n83,refuted).
node(n80,refuted) :- node(n81,refuted), node(n83,refuted), node(n9,refuted).
node(n80,supported) :- node(n81,supported).
node(n80,supported) :- node(n83,supported).
node(n80,supported) :- node(n9,supported).
node(n80,unknown) :- \+ node(n80,supported), \+ node(n80,refuted).
verdict(c_0ddc4312b7e8a606,supported) :- node(n80,supported).
query(verdict(c_0ddc4312b7e8a606,supported)).
verdict(c_0ddc4312b7e8a606,refuted) :- node(n80,refuted).
query(verdict(c_0ddc4312b7e8a606,refuted)).
verdict(c_0ddc4312b7e8a606,unknown) :- node(n80,unknown).
query(verdict(c_0ddc4312b7e8a606,unknown)).
node(n87,supported) :- status(o_fbd740e0ed92baed7d02,supported).
node(n87,refuted) :- status(o_fbd740e0ed92baed7d02,refuted).
node(n87,unknown) :- status(o_fbd740e0ed92baed7d02,unknown).
node(n88,supported) :- status(o_71d43d1c4404a38ce2d3,supported).
node(n88,refuted) :- status(o_71d43d1c4404a38ce2d3,refuted).
node(n88,unknown) :- status(o_71d43d1c4404a38ce2d3,unknown).
node(n89,supported) :- status(o_c57c78a31c64eb1dc203,supported).
node(n89,refuted) :- status(o_c57c78a31c64eb1dc203,refuted).
node(n89,unknown) :- status(o_c57c78a31c64eb1dc203,unknown).
node(n86,supported) :- node(n87,supported), node(n88,supported), node(n89,supported).
node(n86,refuted) :- node(n87,refuted).
node(n86,refuted) :- node(n88,refuted).
node(n86,refuted) :- node(n89,refuted).
node(n86,unknown) :- \+ node(n86,supported), \+ node(n86,refuted).
node(n91,supported) :- status(o_658e7851d79c344f94da,supported).
node(n91,refuted) :- status(o_658e7851d79c344f94da,refuted).
node(n91,unknown) :- status(o_658e7851d79c344f94da,unknown).
node(n92,supported) :- status(o_c869ff7441fbf816727d,supported).
node(n92,refuted) :- status(o_c869ff7441fbf816727d,refuted).
node(n92,unknown) :- status(o_c869ff7441fbf816727d,unknown).
node(n93,supported) :- status(o_116a6aa90f422b50ac59,supported).
node(n93,refuted) :- status(o_116a6aa90f422b50ac59,refuted).
node(n93,unknown) :- status(o_116a6aa90f422b50ac59,unknown).
node(n90,supported) :- node(n91,supported), node(n92,supported), node(n93,supported).
node(n90,refuted) :- node(n91,refuted).
node(n90,refuted) :- node(n92,refuted).
node(n90,refuted) :- node(n93,refuted).
node(n90,unknown) :- \+ node(n90,supported), \+ node(n90,refuted).
node(n85,refuted) :- node(n86,refuted), node(n90,refuted), node(n9,refuted).
node(n85,supported) :- node(n86,supported).
node(n85,supported) :- node(n90,supported).
node(n85,supported) :- node(n9,supported).
node(n85,unknown) :- \+ node(n85,supported), \+ node(n85,refuted).
verdict(c_dce47711d1e00175,supported) :- node(n85,supported).
query(verdict(c_dce47711d1e00175,supported)).
verdict(c_dce47711d1e00175,refuted) :- node(n85,refuted).
query(verdict(c_dce47711d1e00175,refuted)).
verdict(c_dce47711d1e00175,unknown) :- node(n85,unknown).
query(verdict(c_dce47711d1e00175,unknown)).
node(n96,supported) :- status(o_c8c87baa0a5d3c85a437,supported).
node(n96,refuted) :- status(o_c8c87baa0a5d3c85a437,refuted).
node(n96,unknown) :- status(o_c8c87baa0a5d3c85a437,unknown).
node(n95,supported) :- node(n87,supported), node(n88,supported), node(n96,supported), node(n89,supported).
node(n95,refuted) :- node(n87,refuted).
node(n95,refuted) :- node(n88,refuted).
node(n95,refuted) :- node(n96,refuted).
node(n95,refuted) :- node(n89,refuted).
node(n95,unknown) :- \+ node(n95,supported), \+ node(n95,refuted).
node(n98,supported) :- status(o_0e48a0a360f3dd32a90e,supported).
node(n98,refuted) :- status(o_0e48a0a360f3dd32a90e,refuted).
node(n98,unknown) :- status(o_0e48a0a360f3dd32a90e,unknown).
node(n97,supported) :- node(n91,supported), node(n92,supported), node(n98,supported), node(n93,supported).
node(n97,refuted) :- node(n91,refuted).
node(n97,refuted) :- node(n92,refuted).
node(n97,refuted) :- node(n98,refuted).
node(n97,refuted) :- node(n93,refuted).
node(n97,unknown) :- \+ node(n97,supported), \+ node(n97,refuted).
node(n94,refuted) :- node(n95,refuted), node(n97,refuted), node(n9,refuted).
node(n94,supported) :- node(n95,supported).
node(n94,supported) :- node(n97,supported).
node(n94,supported) :- node(n9,supported).
node(n94,unknown) :- \+ node(n94,supported), \+ node(n94,refuted).
verdict(c_9075b421366e57ae,supported) :- node(n94,supported).
query(verdict(c_9075b421366e57ae,supported)).
verdict(c_9075b421366e57ae,refuted) :- node(n94,refuted).
query(verdict(c_9075b421366e57ae,refuted)).
verdict(c_9075b421366e57ae,unknown) :- node(n94,unknown).
query(verdict(c_9075b421366e57ae,unknown)).
node(n101,supported) :- status(o_7a501a3a35811556d44b,supported).
node(n101,refuted) :- status(o_7a501a3a35811556d44b,refuted).
node(n101,unknown) :- status(o_7a501a3a35811556d44b,unknown).
node(n102,supported) :- status(o_965ecb77a6978bc617ab,supported).
node(n102,refuted) :- status(o_965ecb77a6978bc617ab,refuted).
node(n102,unknown) :- status(o_965ecb77a6978bc617ab,unknown).
node(n103,supported) :- status(o_a1f401bcd892cdf9cf10,supported).
node(n103,refuted) :- status(o_a1f401bcd892cdf9cf10,refuted).
node(n103,unknown) :- status(o_a1f401bcd892cdf9cf10,unknown).
node(n100,supported) :- node(n101,supported), node(n102,supported), node(n103,supported).
node(n100,refuted) :- node(n101,refuted).
node(n100,refuted) :- node(n102,refuted).
node(n100,refuted) :- node(n103,refuted).
node(n100,unknown) :- \+ node(n100,supported), \+ node(n100,refuted).
node(n105,supported) :- status(o_de43be83f9ed46439a95,supported).
node(n105,refuted) :- status(o_de43be83f9ed46439a95,refuted).
node(n105,unknown) :- status(o_de43be83f9ed46439a95,unknown).
node(n106,supported) :- status(o_74f027feffc37ca9dd97,supported).
node(n106,refuted) :- status(o_74f027feffc37ca9dd97,refuted).
node(n106,unknown) :- status(o_74f027feffc37ca9dd97,unknown).
node(n107,supported) :- status(o_554947636f601b144d28,supported).
node(n107,refuted) :- status(o_554947636f601b144d28,refuted).
node(n107,unknown) :- status(o_554947636f601b144d28,unknown).
node(n104,supported) :- node(n105,supported), node(n106,supported), node(n107,supported).
node(n104,refuted) :- node(n105,refuted).
node(n104,refuted) :- node(n106,refuted).
node(n104,refuted) :- node(n107,refuted).
node(n104,unknown) :- \+ node(n104,supported), \+ node(n104,refuted).
node(n99,refuted) :- node(n100,refuted), node(n104,refuted), node(n9,refuted).
node(n99,supported) :- node(n100,supported).
node(n99,supported) :- node(n104,supported).
node(n99,supported) :- node(n9,supported).
node(n99,unknown) :- \+ node(n99,supported), \+ node(n99,refuted).
verdict(c_a59388a2462a9a02,supported) :- node(n99,supported).
query(verdict(c_a59388a2462a9a02,supported)).
verdict(c_a59388a2462a9a02,refuted) :- node(n99,refuted).
query(verdict(c_a59388a2462a9a02,refuted)).
verdict(c_a59388a2462a9a02,unknown) :- node(n99,unknown).
query(verdict(c_a59388a2462a9a02,unknown)).
node(n110,supported) :- status(o_0a6da4afed6c4395b90e,supported).
node(n110,refuted) :- status(o_0a6da4afed6c4395b90e,refuted).
node(n110,unknown) :- status(o_0a6da4afed6c4395b90e,unknown).
node(n109,supported) :- node(n101,supported), node(n102,supported), node(n110,supported), node(n103,supported).
node(n109,refuted) :- node(n101,refuted).
node(n109,refuted) :- node(n102,refuted).
node(n109,refuted) :- node(n110,refuted).
node(n109,refuted) :- node(n103,refuted).
node(n109,unknown) :- \+ node(n109,supported), \+ node(n109,refuted).
node(n112,supported) :- status(o_e8d5f9a2644c61db5a74,supported).
node(n112,refuted) :- status(o_e8d5f9a2644c61db5a74,refuted).
node(n112,unknown) :- status(o_e8d5f9a2644c61db5a74,unknown).
node(n111,supported) :- node(n105,supported), node(n106,supported), node(n112,supported), node(n107,supported).
node(n111,refuted) :- node(n105,refuted).
node(n111,refuted) :- node(n106,refuted).
node(n111,refuted) :- node(n112,refuted).
node(n111,refuted) :- node(n107,refuted).
node(n111,unknown) :- \+ node(n111,supported), \+ node(n111,refuted).
node(n108,refuted) :- node(n109,refuted), node(n111,refuted), node(n9,refuted).
node(n108,supported) :- node(n109,supported).
node(n108,supported) :- node(n111,supported).
node(n108,supported) :- node(n9,supported).
node(n108,unknown) :- \+ node(n108,supported), \+ node(n108,refuted).
verdict(c_3bec57384393c8db,supported) :- node(n108,supported).
query(verdict(c_3bec57384393c8db,supported)).
verdict(c_3bec57384393c8db,refuted) :- node(n108,refuted).
query(verdict(c_3bec57384393c8db,refuted)).
verdict(c_3bec57384393c8db,unknown) :- node(n108,unknown).
query(verdict(c_3bec57384393c8db,unknown)).
node(n115,supported) :- status(o_1cfdeb7ca9527102074f,supported).
node(n115,refuted) :- status(o_1cfdeb7ca9527102074f,refuted).
node(n115,unknown) :- status(o_1cfdeb7ca9527102074f,unknown).
node(n116,supported) :- status(o_4d435abcbe591d662c5b,supported).
node(n116,refuted) :- status(o_4d435abcbe591d662c5b,refuted).
node(n116,unknown) :- status(o_4d435abcbe591d662c5b,unknown).
node(n117,supported) :- status(o_81b70f7fd49741508db9,supported).
node(n117,refuted) :- status(o_81b70f7fd49741508db9,refuted).
node(n117,unknown) :- status(o_81b70f7fd49741508db9,unknown).
node(n114,supported) :- node(n115,supported), node(n116,supported), node(n117,supported).
node(n114,refuted) :- node(n115,refuted).
node(n114,refuted) :- node(n116,refuted).
node(n114,refuted) :- node(n117,refuted).
node(n114,unknown) :- \+ node(n114,supported), \+ node(n114,refuted).
node(n119,supported) :- status(o_399c116ba02245698e98,supported).
node(n119,refuted) :- status(o_399c116ba02245698e98,refuted).
node(n119,unknown) :- status(o_399c116ba02245698e98,unknown).
node(n120,supported) :- status(o_e6633275f025ac26b63b,supported).
node(n120,refuted) :- status(o_e6633275f025ac26b63b,refuted).
node(n120,unknown) :- status(o_e6633275f025ac26b63b,unknown).
node(n121,supported) :- status(o_0cdfc050b594786a72a3,supported).
node(n121,refuted) :- status(o_0cdfc050b594786a72a3,refuted).
node(n121,unknown) :- status(o_0cdfc050b594786a72a3,unknown).
node(n118,supported) :- node(n119,supported), node(n120,supported), node(n121,supported).
node(n118,refuted) :- node(n119,refuted).
node(n118,refuted) :- node(n120,refuted).
node(n118,refuted) :- node(n121,refuted).
node(n118,unknown) :- \+ node(n118,supported), \+ node(n118,refuted).
node(n113,refuted) :- node(n114,refuted), node(n118,refuted), node(n9,refuted).
node(n113,supported) :- node(n114,supported).
node(n113,supported) :- node(n118,supported).
node(n113,supported) :- node(n9,supported).
node(n113,unknown) :- \+ node(n113,supported), \+ node(n113,refuted).
verdict(c_e945aa684e28ebfd,supported) :- node(n113,supported).
query(verdict(c_e945aa684e28ebfd,supported)).
verdict(c_e945aa684e28ebfd,refuted) :- node(n113,refuted).
query(verdict(c_e945aa684e28ebfd,refuted)).
verdict(c_e945aa684e28ebfd,unknown) :- node(n113,unknown).
query(verdict(c_e945aa684e28ebfd,unknown)).
node(n124,supported) :- status(o_6c93acc7924c8be4cfd6,supported).
node(n124,refuted) :- status(o_6c93acc7924c8be4cfd6,refuted).
node(n124,unknown) :- status(o_6c93acc7924c8be4cfd6,unknown).
node(n123,supported) :- node(n115,supported), node(n116,supported), node(n124,supported), node(n117,supported).
node(n123,refuted) :- node(n115,refuted).
node(n123,refuted) :- node(n116,refuted).
node(n123,refuted) :- node(n124,refuted).
node(n123,refuted) :- node(n117,refuted).
node(n123,unknown) :- \+ node(n123,supported), \+ node(n123,refuted).
node(n126,supported) :- status(o_b197e360bc252fdf5fc1,supported).
node(n126,refuted) :- status(o_b197e360bc252fdf5fc1,refuted).
node(n126,unknown) :- status(o_b197e360bc252fdf5fc1,unknown).
node(n125,supported) :- node(n119,supported), node(n120,supported), node(n126,supported), node(n121,supported).
node(n125,refuted) :- node(n119,refuted).
node(n125,refuted) :- node(n120,refuted).
node(n125,refuted) :- node(n126,refuted).
node(n125,refuted) :- node(n121,refuted).
node(n125,unknown) :- \+ node(n125,supported), \+ node(n125,refuted).
node(n122,refuted) :- node(n123,refuted), node(n125,refuted), node(n9,refuted).
node(n122,supported) :- node(n123,supported).
node(n122,supported) :- node(n125,supported).
node(n122,supported) :- node(n9,supported).
node(n122,unknown) :- \+ node(n122,supported), \+ node(n122,refuted).
verdict(c_4e3a2630c182d029,supported) :- node(n122,supported).
query(verdict(c_4e3a2630c182d029,supported)).
verdict(c_4e3a2630c182d029,refuted) :- node(n122,refuted).
query(verdict(c_4e3a2630c182d029,refuted)).
verdict(c_4e3a2630c182d029,unknown) :- node(n122,unknown).
query(verdict(c_4e3a2630c182d029,unknown)).
node(n129,supported) :- status(o_774847ccadade7fa38ea,supported).
node(n129,refuted) :- status(o_774847ccadade7fa38ea,refuted).
node(n129,unknown) :- status(o_774847ccadade7fa38ea,unknown).
node(n130,supported) :- status(o_d3be1f5f64ff7e00e6dc,supported).
node(n130,refuted) :- status(o_d3be1f5f64ff7e00e6dc,refuted).
node(n130,unknown) :- status(o_d3be1f5f64ff7e00e6dc,unknown).
node(n131,supported) :- status(o_2156c33407e33c2da08d,supported).
node(n131,refuted) :- status(o_2156c33407e33c2da08d,refuted).
node(n131,unknown) :- status(o_2156c33407e33c2da08d,unknown).
node(n128,supported) :- node(n129,supported), node(n130,supported), node(n131,supported).
node(n128,refuted) :- node(n129,refuted).
node(n128,refuted) :- node(n130,refuted).
node(n128,refuted) :- node(n131,refuted).
node(n128,unknown) :- \+ node(n128,supported), \+ node(n128,refuted).
node(n133,supported) :- status(o_8540ecd929df9a4c6613,supported).
node(n133,refuted) :- status(o_8540ecd929df9a4c6613,refuted).
node(n133,unknown) :- status(o_8540ecd929df9a4c6613,unknown).
node(n134,supported) :- status(o_8448ce9484ba108c05d2,supported).
node(n134,refuted) :- status(o_8448ce9484ba108c05d2,refuted).
node(n134,unknown) :- status(o_8448ce9484ba108c05d2,unknown).
node(n135,supported) :- status(o_94560e7f3dbd9339c9ab,supported).
node(n135,refuted) :- status(o_94560e7f3dbd9339c9ab,refuted).
node(n135,unknown) :- status(o_94560e7f3dbd9339c9ab,unknown).
node(n132,supported) :- node(n133,supported), node(n134,supported), node(n135,supported).
node(n132,refuted) :- node(n133,refuted).
node(n132,refuted) :- node(n134,refuted).
node(n132,refuted) :- node(n135,refuted).
node(n132,unknown) :- \+ node(n132,supported), \+ node(n132,refuted).
node(n127,refuted) :- node(n128,refuted), node(n132,refuted), node(n9,refuted).
node(n127,supported) :- node(n128,supported).
node(n127,supported) :- node(n132,supported).
node(n127,supported) :- node(n9,supported).
node(n127,unknown) :- \+ node(n127,supported), \+ node(n127,refuted).
verdict(c_04e34df3b0a2bde9,supported) :- node(n127,supported).
query(verdict(c_04e34df3b0a2bde9,supported)).
verdict(c_04e34df3b0a2bde9,refuted) :- node(n127,refuted).
query(verdict(c_04e34df3b0a2bde9,refuted)).
verdict(c_04e34df3b0a2bde9,unknown) :- node(n127,unknown).
query(verdict(c_04e34df3b0a2bde9,unknown)).
node(n138,supported) :- status(o_ba687b3dd0438b6e82c1,supported).
node(n138,refuted) :- status(o_ba687b3dd0438b6e82c1,refuted).
node(n138,unknown) :- status(o_ba687b3dd0438b6e82c1,unknown).
node(n137,supported) :- node(n129,supported), node(n130,supported), node(n138,supported), node(n131,supported).
node(n137,refuted) :- node(n129,refuted).
node(n137,refuted) :- node(n130,refuted).
node(n137,refuted) :- node(n138,refuted).
node(n137,refuted) :- node(n131,refuted).
node(n137,unknown) :- \+ node(n137,supported), \+ node(n137,refuted).
node(n140,supported) :- status(o_d2709399b56d26183136,supported).
node(n140,refuted) :- status(o_d2709399b56d26183136,refuted).
node(n140,unknown) :- status(o_d2709399b56d26183136,unknown).
node(n139,supported) :- node(n133,supported), node(n134,supported), node(n140,supported), node(n135,supported).
node(n139,refuted) :- node(n133,refuted).
node(n139,refuted) :- node(n134,refuted).
node(n139,refuted) :- node(n140,refuted).
node(n139,refuted) :- node(n135,refuted).
node(n139,unknown) :- \+ node(n139,supported), \+ node(n139,refuted).
node(n136,refuted) :- node(n137,refuted), node(n139,refuted), node(n9,refuted).
node(n136,supported) :- node(n137,supported).
node(n136,supported) :- node(n139,supported).
node(n136,supported) :- node(n9,supported).
node(n136,unknown) :- \+ node(n136,supported), \+ node(n136,refuted).
verdict(c_1b549887fd7d1a89,supported) :- node(n136,supported).
query(verdict(c_1b549887fd7d1a89,supported)).
verdict(c_1b549887fd7d1a89,refuted) :- node(n136,refuted).
query(verdict(c_1b549887fd7d1a89,refuted)).
verdict(c_1b549887fd7d1a89,unknown) :- node(n136,unknown).
query(verdict(c_1b549887fd7d1a89,unknown)).
node(n143,supported) :- status(o_3123999d9cf307bca68b,supported).
node(n143,refuted) :- status(o_3123999d9cf307bca68b,refuted).
node(n143,unknown) :- status(o_3123999d9cf307bca68b,unknown).
node(n144,supported) :- status(o_2f96c65a44127f6522c5,supported).
node(n144,refuted) :- status(o_2f96c65a44127f6522c5,refuted).
node(n144,unknown) :- status(o_2f96c65a44127f6522c5,unknown).
node(n145,supported) :- status(o_1a4320445babc1ec7672,supported).
node(n145,refuted) :- status(o_1a4320445babc1ec7672,refuted).
node(n145,unknown) :- status(o_1a4320445babc1ec7672,unknown).
node(n142,supported) :- node(n143,supported), node(n144,supported), node(n145,supported).
node(n142,refuted) :- node(n143,refuted).
node(n142,refuted) :- node(n144,refuted).
node(n142,refuted) :- node(n145,refuted).
node(n142,unknown) :- \+ node(n142,supported), \+ node(n142,refuted).
node(n147,supported) :- status(o_b0276694968e0c63f518,supported).
node(n147,refuted) :- status(o_b0276694968e0c63f518,refuted).
node(n147,unknown) :- status(o_b0276694968e0c63f518,unknown).
node(n148,supported) :- status(o_ea1fa258de3938e26697,supported).
node(n148,refuted) :- status(o_ea1fa258de3938e26697,refuted).
node(n148,unknown) :- status(o_ea1fa258de3938e26697,unknown).
node(n149,supported) :- status(o_3f635067430d393e42dc,supported).
node(n149,refuted) :- status(o_3f635067430d393e42dc,refuted).
node(n149,unknown) :- status(o_3f635067430d393e42dc,unknown).
node(n146,supported) :- node(n147,supported), node(n148,supported), node(n149,supported).
node(n146,refuted) :- node(n147,refuted).
node(n146,refuted) :- node(n148,refuted).
node(n146,refuted) :- node(n149,refuted).
node(n146,unknown) :- \+ node(n146,supported), \+ node(n146,refuted).
node(n141,refuted) :- node(n142,refuted), node(n146,refuted), node(n9,refuted).
node(n141,supported) :- node(n142,supported).
node(n141,supported) :- node(n146,supported).
node(n141,supported) :- node(n9,supported).
node(n141,unknown) :- \+ node(n141,supported), \+ node(n141,refuted).
verdict(c_2f8c39cdc957afc1,supported) :- node(n141,supported).
query(verdict(c_2f8c39cdc957afc1,supported)).
verdict(c_2f8c39cdc957afc1,refuted) :- node(n141,refuted).
query(verdict(c_2f8c39cdc957afc1,refuted)).
verdict(c_2f8c39cdc957afc1,unknown) :- node(n141,unknown).
query(verdict(c_2f8c39cdc957afc1,unknown)).
node(n152,supported) :- status(o_a52b8462a8fe02f16c14,supported).
node(n152,refuted) :- status(o_a52b8462a8fe02f16c14,refuted).
node(n152,unknown) :- status(o_a52b8462a8fe02f16c14,unknown).
node(n151,supported) :- node(n143,supported), node(n144,supported), node(n152,supported), node(n145,supported).
node(n151,refuted) :- node(n143,refuted).
node(n151,refuted) :- node(n144,refuted).
node(n151,refuted) :- node(n152,refuted).
node(n151,refuted) :- node(n145,refuted).
node(n151,unknown) :- \+ node(n151,supported), \+ node(n151,refuted).
node(n154,supported) :- status(o_d00768634721260ecd49,supported).
node(n154,refuted) :- status(o_d00768634721260ecd49,refuted).
node(n154,unknown) :- status(o_d00768634721260ecd49,unknown).
node(n153,supported) :- node(n147,supported), node(n148,supported), node(n154,supported), node(n149,supported).
node(n153,refuted) :- node(n147,refuted).
node(n153,refuted) :- node(n148,refuted).
node(n153,refuted) :- node(n154,refuted).
node(n153,refuted) :- node(n149,refuted).
node(n153,unknown) :- \+ node(n153,supported), \+ node(n153,refuted).
node(n150,refuted) :- node(n151,refuted), node(n153,refuted), node(n9,refuted).
node(n150,supported) :- node(n151,supported).
node(n150,supported) :- node(n153,supported).
node(n150,supported) :- node(n9,supported).
node(n150,unknown) :- \+ node(n150,supported), \+ node(n150,refuted).
verdict(c_2b909e36206a14cd,supported) :- node(n150,supported).
query(verdict(c_2b909e36206a14cd,supported)).
verdict(c_2b909e36206a14cd,refuted) :- node(n150,refuted).
query(verdict(c_2b909e36206a14cd,refuted)).
verdict(c_2b909e36206a14cd,unknown) :- node(n150,unknown).
query(verdict(c_2b909e36206a14cd,unknown)).
node(n157,supported) :- status(o_7e33a51c69785c1cc67a,supported).
node(n157,refuted) :- status(o_7e33a51c69785c1cc67a,refuted).
node(n157,unknown) :- status(o_7e33a51c69785c1cc67a,unknown).
node(n158,supported) :- status(o_7d697e425055dcf0a5e1,supported).
node(n158,refuted) :- status(o_7d697e425055dcf0a5e1,refuted).
node(n158,unknown) :- status(o_7d697e425055dcf0a5e1,unknown).
node(n159,supported) :- status(o_54aefc839be5302210bf,supported).
node(n159,refuted) :- status(o_54aefc839be5302210bf,refuted).
node(n159,unknown) :- status(o_54aefc839be5302210bf,unknown).
node(n156,supported) :- node(n157,supported), node(n158,supported), node(n159,supported).
node(n156,refuted) :- node(n157,refuted).
node(n156,refuted) :- node(n158,refuted).
node(n156,refuted) :- node(n159,refuted).
node(n156,unknown) :- \+ node(n156,supported), \+ node(n156,refuted).
node(n161,supported) :- status(o_3b7d9537a6901a4b7b3d,supported).
node(n161,refuted) :- status(o_3b7d9537a6901a4b7b3d,refuted).
node(n161,unknown) :- status(o_3b7d9537a6901a4b7b3d,unknown).
node(n162,supported) :- status(o_1653fabca7bd2846cb50,supported).
node(n162,refuted) :- status(o_1653fabca7bd2846cb50,refuted).
node(n162,unknown) :- status(o_1653fabca7bd2846cb50,unknown).
node(n163,supported) :- status(o_30194b0d0f14faf8ca42,supported).
node(n163,refuted) :- status(o_30194b0d0f14faf8ca42,refuted).
node(n163,unknown) :- status(o_30194b0d0f14faf8ca42,unknown).
node(n160,supported) :- node(n161,supported), node(n162,supported), node(n163,supported).
node(n160,refuted) :- node(n161,refuted).
node(n160,refuted) :- node(n162,refuted).
node(n160,refuted) :- node(n163,refuted).
node(n160,unknown) :- \+ node(n160,supported), \+ node(n160,refuted).
node(n155,refuted) :- node(n156,refuted), node(n160,refuted), node(n9,refuted).
node(n155,supported) :- node(n156,supported).
node(n155,supported) :- node(n160,supported).
node(n155,supported) :- node(n9,supported).
node(n155,unknown) :- \+ node(n155,supported), \+ node(n155,refuted).
verdict(c_aa9daa9582eecbef,supported) :- node(n155,supported).
query(verdict(c_aa9daa9582eecbef,supported)).
verdict(c_aa9daa9582eecbef,refuted) :- node(n155,refuted).
query(verdict(c_aa9daa9582eecbef,refuted)).
verdict(c_aa9daa9582eecbef,unknown) :- node(n155,unknown).
query(verdict(c_aa9daa9582eecbef,unknown)).
node(n166,supported) :- status(o_2c82bbe1bcef131ec096,supported).
node(n166,refuted) :- status(o_2c82bbe1bcef131ec096,refuted).
node(n166,unknown) :- status(o_2c82bbe1bcef131ec096,unknown).
node(n165,supported) :- node(n157,supported), node(n158,supported), node(n166,supported), node(n159,supported).
node(n165,refuted) :- node(n157,refuted).
node(n165,refuted) :- node(n158,refuted).
node(n165,refuted) :- node(n166,refuted).
node(n165,refuted) :- node(n159,refuted).
node(n165,unknown) :- \+ node(n165,supported), \+ node(n165,refuted).
node(n168,supported) :- status(o_f192e52bd78fde4051a3,supported).
node(n168,refuted) :- status(o_f192e52bd78fde4051a3,refuted).
node(n168,unknown) :- status(o_f192e52bd78fde4051a3,unknown).
node(n167,supported) :- node(n161,supported), node(n162,supported), node(n168,supported), node(n163,supported).
node(n167,refuted) :- node(n161,refuted).
node(n167,refuted) :- node(n162,refuted).
node(n167,refuted) :- node(n168,refuted).
node(n167,refuted) :- node(n163,refuted).
node(n167,unknown) :- \+ node(n167,supported), \+ node(n167,refuted).
node(n164,refuted) :- node(n165,refuted), node(n167,refuted), node(n9,refuted).
node(n164,supported) :- node(n165,supported).
node(n164,supported) :- node(n167,supported).
node(n164,supported) :- node(n9,supported).
node(n164,unknown) :- \+ node(n164,supported), \+ node(n164,refuted).
verdict(c_f7992cb5a21ac642,supported) :- node(n164,supported).
query(verdict(c_f7992cb5a21ac642,supported)).
verdict(c_f7992cb5a21ac642,refuted) :- node(n164,refuted).
query(verdict(c_f7992cb5a21ac642,refuted)).
verdict(c_f7992cb5a21ac642,unknown) :- node(n164,unknown).
query(verdict(c_f7992cb5a21ac642,unknown)).
node(n171,supported) :- status(o_9be155994cd0a4efa5f1,supported).
node(n171,refuted) :- status(o_9be155994cd0a4efa5f1,refuted).
node(n171,unknown) :- status(o_9be155994cd0a4efa5f1,unknown).
node(n172,supported) :- status(o_b72da8b5270254124f28,supported).
node(n172,refuted) :- status(o_b72da8b5270254124f28,refuted).
node(n172,unknown) :- status(o_b72da8b5270254124f28,unknown).
node(n173,supported) :- status(o_e0b239c7737087ef281f,supported).
node(n173,refuted) :- status(o_e0b239c7737087ef281f,refuted).
node(n173,unknown) :- status(o_e0b239c7737087ef281f,unknown).
node(n170,supported) :- node(n171,supported), node(n172,supported), node(n173,supported).
node(n170,refuted) :- node(n171,refuted).
node(n170,refuted) :- node(n172,refuted).
node(n170,refuted) :- node(n173,refuted).
node(n170,unknown) :- \+ node(n170,supported), \+ node(n170,refuted).
node(n175,supported) :- status(o_c3f3d2ee8ed8aa5066a2,supported).
node(n175,refuted) :- status(o_c3f3d2ee8ed8aa5066a2,refuted).
node(n175,unknown) :- status(o_c3f3d2ee8ed8aa5066a2,unknown).
node(n176,supported) :- status(o_4dc336be9417dcfa6dd2,supported).
node(n176,refuted) :- status(o_4dc336be9417dcfa6dd2,refuted).
node(n176,unknown) :- status(o_4dc336be9417dcfa6dd2,unknown).
node(n177,supported) :- status(o_1df1b32830663bda55a1,supported).
node(n177,refuted) :- status(o_1df1b32830663bda55a1,refuted).
node(n177,unknown) :- status(o_1df1b32830663bda55a1,unknown).
node(n174,supported) :- node(n175,supported), node(n176,supported), node(n177,supported).
node(n174,refuted) :- node(n175,refuted).
node(n174,refuted) :- node(n176,refuted).
node(n174,refuted) :- node(n177,refuted).
node(n174,unknown) :- \+ node(n174,supported), \+ node(n174,refuted).
node(n169,refuted) :- node(n170,refuted), node(n174,refuted), node(n9,refuted).
node(n169,supported) :- node(n170,supported).
node(n169,supported) :- node(n174,supported).
node(n169,supported) :- node(n9,supported).
node(n169,unknown) :- \+ node(n169,supported), \+ node(n169,refuted).
verdict(c_339da9dd34e3e451,supported) :- node(n169,supported).
query(verdict(c_339da9dd34e3e451,supported)).
verdict(c_339da9dd34e3e451,refuted) :- node(n169,refuted).
query(verdict(c_339da9dd34e3e451,refuted)).
verdict(c_339da9dd34e3e451,unknown) :- node(n169,unknown).
query(verdict(c_339da9dd34e3e451,unknown)).
node(n180,supported) :- status(o_91ef6f91fb3a040e1388,supported).
node(n180,refuted) :- status(o_91ef6f91fb3a040e1388,refuted).
node(n180,unknown) :- status(o_91ef6f91fb3a040e1388,unknown).
node(n179,supported) :- node(n171,supported), node(n172,supported), node(n180,supported), node(n173,supported).
node(n179,refuted) :- node(n171,refuted).
node(n179,refuted) :- node(n172,refuted).
node(n179,refuted) :- node(n180,refuted).
node(n179,refuted) :- node(n173,refuted).
node(n179,unknown) :- \+ node(n179,supported), \+ node(n179,refuted).
node(n182,supported) :- status(o_c92ec08ef0174a46fd51,supported).
node(n182,refuted) :- status(o_c92ec08ef0174a46fd51,refuted).
node(n182,unknown) :- status(o_c92ec08ef0174a46fd51,unknown).
node(n181,supported) :- node(n175,supported), node(n176,supported), node(n182,supported), node(n177,supported).
node(n181,refuted) :- node(n175,refuted).
node(n181,refuted) :- node(n176,refuted).
node(n181,refuted) :- node(n182,refuted).
node(n181,refuted) :- node(n177,refuted).
node(n181,unknown) :- \+ node(n181,supported), \+ node(n181,refuted).
node(n178,refuted) :- node(n179,refuted), node(n181,refuted), node(n9,refuted).
node(n178,supported) :- node(n179,supported).
node(n178,supported) :- node(n181,supported).
node(n178,supported) :- node(n9,supported).
node(n178,unknown) :- \+ node(n178,supported), \+ node(n178,refuted).
verdict(c_87306c1092f5156d,supported) :- node(n178,supported).
query(verdict(c_87306c1092f5156d,supported)).
verdict(c_87306c1092f5156d,refuted) :- node(n178,refuted).
query(verdict(c_87306c1092f5156d,refuted)).
verdict(c_87306c1092f5156d,unknown) :- node(n178,unknown).
query(verdict(c_87306c1092f5156d,unknown)).
node(n185,supported) :- status(o_f5cfe65e99955778fc9c,supported).
node(n185,refuted) :- status(o_f5cfe65e99955778fc9c,refuted).
node(n185,unknown) :- status(o_f5cfe65e99955778fc9c,unknown).
node(n186,supported) :- status(o_f5dcfe29e57d876eb117,supported).
node(n186,refuted) :- status(o_f5dcfe29e57d876eb117,refuted).
node(n186,unknown) :- status(o_f5dcfe29e57d876eb117,unknown).
node(n187,supported) :- status(o_cd4beeb4437c602fbbd2,supported).
node(n187,refuted) :- status(o_cd4beeb4437c602fbbd2,refuted).
node(n187,unknown) :- status(o_cd4beeb4437c602fbbd2,unknown).
node(n184,supported) :- node(n185,supported), node(n186,supported), node(n187,supported).
node(n184,refuted) :- node(n185,refuted).
node(n184,refuted) :- node(n186,refuted).
node(n184,refuted) :- node(n187,refuted).
node(n184,unknown) :- \+ node(n184,supported), \+ node(n184,refuted).
node(n189,supported) :- status(o_0802b7563c92a645e247,supported).
node(n189,refuted) :- status(o_0802b7563c92a645e247,refuted).
node(n189,unknown) :- status(o_0802b7563c92a645e247,unknown).
node(n190,supported) :- status(o_2378d7029e40f95e4cd4,supported).
node(n190,refuted) :- status(o_2378d7029e40f95e4cd4,refuted).
node(n190,unknown) :- status(o_2378d7029e40f95e4cd4,unknown).
node(n191,supported) :- status(o_c1693cf3e33a5cb2ee44,supported).
node(n191,refuted) :- status(o_c1693cf3e33a5cb2ee44,refuted).
node(n191,unknown) :- status(o_c1693cf3e33a5cb2ee44,unknown).
node(n188,supported) :- node(n189,supported), node(n190,supported), node(n191,supported).
node(n188,refuted) :- node(n189,refuted).
node(n188,refuted) :- node(n190,refuted).
node(n188,refuted) :- node(n191,refuted).
node(n188,unknown) :- \+ node(n188,supported), \+ node(n188,refuted).
node(n183,refuted) :- node(n184,refuted), node(n188,refuted), node(n9,refuted).
node(n183,supported) :- node(n184,supported).
node(n183,supported) :- node(n188,supported).
node(n183,supported) :- node(n9,supported).
node(n183,unknown) :- \+ node(n183,supported), \+ node(n183,refuted).
verdict(c_84a3ff17aa1a586d,supported) :- node(n183,supported).
query(verdict(c_84a3ff17aa1a586d,supported)).
verdict(c_84a3ff17aa1a586d,refuted) :- node(n183,refuted).
query(verdict(c_84a3ff17aa1a586d,refuted)).
verdict(c_84a3ff17aa1a586d,unknown) :- node(n183,unknown).
query(verdict(c_84a3ff17aa1a586d,unknown)).
node(n194,supported) :- status(o_c1773f141e564be5f6e3,supported).
node(n194,refuted) :- status(o_c1773f141e564be5f6e3,refuted).
node(n194,unknown) :- status(o_c1773f141e564be5f6e3,unknown).
node(n193,supported) :- node(n185,supported), node(n186,supported), node(n194,supported), node(n187,supported).
node(n193,refuted) :- node(n185,refuted).
node(n193,refuted) :- node(n186,refuted).
node(n193,refuted) :- node(n194,refuted).
node(n193,refuted) :- node(n187,refuted).
node(n193,unknown) :- \+ node(n193,supported), \+ node(n193,refuted).
node(n196,supported) :- status(o_42dd308b583fa4fe42dc,supported).
node(n196,refuted) :- status(o_42dd308b583fa4fe42dc,refuted).
node(n196,unknown) :- status(o_42dd308b583fa4fe42dc,unknown).
node(n195,supported) :- node(n189,supported), node(n190,supported), node(n196,supported), node(n191,supported).
node(n195,refuted) :- node(n189,refuted).
node(n195,refuted) :- node(n190,refuted).
node(n195,refuted) :- node(n196,refuted).
node(n195,refuted) :- node(n191,refuted).
node(n195,unknown) :- \+ node(n195,supported), \+ node(n195,refuted).
node(n192,refuted) :- node(n193,refuted), node(n195,refuted), node(n9,refuted).
node(n192,supported) :- node(n193,supported).
node(n192,supported) :- node(n195,supported).
node(n192,supported) :- node(n9,supported).
node(n192,unknown) :- \+ node(n192,supported), \+ node(n192,refuted).
verdict(c_093c3ddba3be20d0,supported) :- node(n192,supported).
query(verdict(c_093c3ddba3be20d0,supported)).
verdict(c_093c3ddba3be20d0,refuted) :- node(n192,refuted).
query(verdict(c_093c3ddba3be20d0,refuted)).
verdict(c_093c3ddba3be20d0,unknown) :- node(n192,unknown).
query(verdict(c_093c3ddba3be20d0,unknown)).
node(n199,supported) :- status(o_e6d780801b0c118067fe,supported).
node(n199,refuted) :- status(o_e6d780801b0c118067fe,refuted).
node(n199,unknown) :- status(o_e6d780801b0c118067fe,unknown).
node(n200,supported) :- status(o_cfafc56fb5d9082a81f7,supported).
node(n200,refuted) :- status(o_cfafc56fb5d9082a81f7,refuted).
node(n200,unknown) :- status(o_cfafc56fb5d9082a81f7,unknown).
node(n201,supported) :- status(o_8bdfa29d3cfe545d6aa5,supported).
node(n201,refuted) :- status(o_8bdfa29d3cfe545d6aa5,refuted).
node(n201,unknown) :- status(o_8bdfa29d3cfe545d6aa5,unknown).
node(n198,supported) :- node(n199,supported), node(n200,supported), node(n201,supported).
node(n198,refuted) :- node(n199,refuted).
node(n198,refuted) :- node(n200,refuted).
node(n198,refuted) :- node(n201,refuted).
node(n198,unknown) :- \+ node(n198,supported), \+ node(n198,refuted).
node(n203,supported) :- status(o_6393e12e124c3ee350f1,supported).
node(n203,refuted) :- status(o_6393e12e124c3ee350f1,refuted).
node(n203,unknown) :- status(o_6393e12e124c3ee350f1,unknown).
node(n204,supported) :- status(o_c5eb6b7b22d0ba65e52a,supported).
node(n204,refuted) :- status(o_c5eb6b7b22d0ba65e52a,refuted).
node(n204,unknown) :- status(o_c5eb6b7b22d0ba65e52a,unknown).
node(n205,supported) :- status(o_a5160bf4e372cd9792c6,supported).
node(n205,refuted) :- status(o_a5160bf4e372cd9792c6,refuted).
node(n205,unknown) :- status(o_a5160bf4e372cd9792c6,unknown).
node(n202,supported) :- node(n203,supported), node(n204,supported), node(n205,supported).
node(n202,refuted) :- node(n203,refuted).
node(n202,refuted) :- node(n204,refuted).
node(n202,refuted) :- node(n205,refuted).
node(n202,unknown) :- \+ node(n202,supported), \+ node(n202,refuted).
node(n197,refuted) :- node(n198,refuted), node(n202,refuted), node(n9,refuted).
node(n197,supported) :- node(n198,supported).
node(n197,supported) :- node(n202,supported).
node(n197,supported) :- node(n9,supported).
node(n197,unknown) :- \+ node(n197,supported), \+ node(n197,refuted).
verdict(c_6f2067ba277a4039,supported) :- node(n197,supported).
query(verdict(c_6f2067ba277a4039,supported)).
verdict(c_6f2067ba277a4039,refuted) :- node(n197,refuted).
query(verdict(c_6f2067ba277a4039,refuted)).
verdict(c_6f2067ba277a4039,unknown) :- node(n197,unknown).
query(verdict(c_6f2067ba277a4039,unknown)).
node(n208,supported) :- status(o_621dfc36926a9e5fbfde,supported).
node(n208,refuted) :- status(o_621dfc36926a9e5fbfde,refuted).
node(n208,unknown) :- status(o_621dfc36926a9e5fbfde,unknown).
node(n207,supported) :- node(n199,supported), node(n200,supported), node(n208,supported), node(n201,supported).
node(n207,refuted) :- node(n199,refuted).
node(n207,refuted) :- node(n200,refuted).
node(n207,refuted) :- node(n208,refuted).
node(n207,refuted) :- node(n201,refuted).
node(n207,unknown) :- \+ node(n207,supported), \+ node(n207,refuted).
node(n210,supported) :- status(o_352102850a6208f28228,supported).
node(n210,refuted) :- status(o_352102850a6208f28228,refuted).
node(n210,unknown) :- status(o_352102850a6208f28228,unknown).
node(n209,supported) :- node(n203,supported), node(n204,supported), node(n210,supported), node(n205,supported).
node(n209,refuted) :- node(n203,refuted).
node(n209,refuted) :- node(n204,refuted).
node(n209,refuted) :- node(n210,refuted).
node(n209,refuted) :- node(n205,refuted).
node(n209,unknown) :- \+ node(n209,supported), \+ node(n209,refuted).
node(n206,refuted) :- node(n207,refuted), node(n209,refuted), node(n9,refuted).
node(n206,supported) :- node(n207,supported).
node(n206,supported) :- node(n209,supported).
node(n206,supported) :- node(n9,supported).
node(n206,unknown) :- \+ node(n206,supported), \+ node(n206,refuted).
verdict(c_da547f1516895f1b,supported) :- node(n206,supported).
query(verdict(c_da547f1516895f1b,supported)).
verdict(c_da547f1516895f1b,refuted) :- node(n206,refuted).
query(verdict(c_da547f1516895f1b,refuted)).
verdict(c_da547f1516895f1b,unknown) :- node(n206,unknown).
query(verdict(c_da547f1516895f1b,unknown)).
node(n213,supported) :- status(o_888e296d3760e6649da5,supported).
node(n213,refuted) :- status(o_888e296d3760e6649da5,refuted).
node(n213,unknown) :- status(o_888e296d3760e6649da5,unknown).
node(n214,supported) :- status(o_cfafe2954f9dd4ddd934,supported).
node(n214,refuted) :- status(o_cfafe2954f9dd4ddd934,refuted).
node(n214,unknown) :- status(o_cfafe2954f9dd4ddd934,unknown).
node(n215,supported) :- status(o_bed9cba98098a663382f,supported).
node(n215,refuted) :- status(o_bed9cba98098a663382f,refuted).
node(n215,unknown) :- status(o_bed9cba98098a663382f,unknown).
node(n212,supported) :- node(n213,supported), node(n214,supported), node(n215,supported).
node(n212,refuted) :- node(n213,refuted).
node(n212,refuted) :- node(n214,refuted).
node(n212,refuted) :- node(n215,refuted).
node(n212,unknown) :- \+ node(n212,supported), \+ node(n212,refuted).
node(n217,supported) :- status(o_471d1181fdaf00aa00b5,supported).
node(n217,refuted) :- status(o_471d1181fdaf00aa00b5,refuted).
node(n217,unknown) :- status(o_471d1181fdaf00aa00b5,unknown).
node(n218,supported) :- status(o_d55892ae80ba20f75970,supported).
node(n218,refuted) :- status(o_d55892ae80ba20f75970,refuted).
node(n218,unknown) :- status(o_d55892ae80ba20f75970,unknown).
node(n219,supported) :- status(o_770d666b39ab7b0fada1,supported).
node(n219,refuted) :- status(o_770d666b39ab7b0fada1,refuted).
node(n219,unknown) :- status(o_770d666b39ab7b0fada1,unknown).
node(n216,supported) :- node(n217,supported), node(n218,supported), node(n219,supported).
node(n216,refuted) :- node(n217,refuted).
node(n216,refuted) :- node(n218,refuted).
node(n216,refuted) :- node(n219,refuted).
node(n216,unknown) :- \+ node(n216,supported), \+ node(n216,refuted).
node(n211,refuted) :- node(n212,refuted), node(n216,refuted), node(n9,refuted).
node(n211,supported) :- node(n212,supported).
node(n211,supported) :- node(n216,supported).
node(n211,supported) :- node(n9,supported).
node(n211,unknown) :- \+ node(n211,supported), \+ node(n211,refuted).
verdict(c_3b967a789372b85c,supported) :- node(n211,supported).
query(verdict(c_3b967a789372b85c,supported)).
verdict(c_3b967a789372b85c,refuted) :- node(n211,refuted).
query(verdict(c_3b967a789372b85c,refuted)).
verdict(c_3b967a789372b85c,unknown) :- node(n211,unknown).
query(verdict(c_3b967a789372b85c,unknown)).
node(n222,supported) :- status(o_3775f24b6ce7b53f7674,supported).
node(n222,refuted) :- status(o_3775f24b6ce7b53f7674,refuted).
node(n222,unknown) :- status(o_3775f24b6ce7b53f7674,unknown).
node(n221,supported) :- node(n213,supported), node(n214,supported), node(n222,supported), node(n215,supported).
node(n221,refuted) :- node(n213,refuted).
node(n221,refuted) :- node(n214,refuted).
node(n221,refuted) :- node(n222,refuted).
node(n221,refuted) :- node(n215,refuted).
node(n221,unknown) :- \+ node(n221,supported), \+ node(n221,refuted).
node(n224,supported) :- status(o_eefcf2730e38261842f3,supported).
node(n224,refuted) :- status(o_eefcf2730e38261842f3,refuted).
node(n224,unknown) :- status(o_eefcf2730e38261842f3,unknown).
node(n223,supported) :- node(n217,supported), node(n218,supported), node(n224,supported), node(n219,supported).
node(n223,refuted) :- node(n217,refuted).
node(n223,refuted) :- node(n218,refuted).
node(n223,refuted) :- node(n224,refuted).
node(n223,refuted) :- node(n219,refuted).
node(n223,unknown) :- \+ node(n223,supported), \+ node(n223,refuted).
node(n220,refuted) :- node(n221,refuted), node(n223,refuted), node(n9,refuted).
node(n220,supported) :- node(n221,supported).
node(n220,supported) :- node(n223,supported).
node(n220,supported) :- node(n9,supported).
node(n220,unknown) :- \+ node(n220,supported), \+ node(n220,refuted).
verdict(c_187da12e636cedfc,supported) :- node(n220,supported).
query(verdict(c_187da12e636cedfc,supported)).
verdict(c_187da12e636cedfc,refuted) :- node(n220,refuted).
query(verdict(c_187da12e636cedfc,refuted)).
verdict(c_187da12e636cedfc,unknown) :- node(n220,unknown).
query(verdict(c_187da12e636cedfc,unknown)).
node(n227,supported) :- status(o_aa4896e6bedec74068ac,supported).
node(n227,refuted) :- status(o_aa4896e6bedec74068ac,refuted).
node(n227,unknown) :- status(o_aa4896e6bedec74068ac,unknown).
node(n228,supported) :- status(o_38815adad6c30f9b86b3,supported).
node(n228,refuted) :- status(o_38815adad6c30f9b86b3,refuted).
node(n228,unknown) :- status(o_38815adad6c30f9b86b3,unknown).
node(n229,supported) :- status(o_0b56e6d4b50fb0d52828,supported).
node(n229,refuted) :- status(o_0b56e6d4b50fb0d52828,refuted).
node(n229,unknown) :- status(o_0b56e6d4b50fb0d52828,unknown).
node(n226,supported) :- node(n227,supported), node(n228,supported), node(n229,supported).
node(n226,refuted) :- node(n227,refuted).
node(n226,refuted) :- node(n228,refuted).
node(n226,refuted) :- node(n229,refuted).
node(n226,unknown) :- \+ node(n226,supported), \+ node(n226,refuted).
node(n231,supported) :- status(o_8651aa1952cad480cf99,supported).
node(n231,refuted) :- status(o_8651aa1952cad480cf99,refuted).
node(n231,unknown) :- status(o_8651aa1952cad480cf99,unknown).
node(n232,supported) :- status(o_503ca5414c5c0df03060,supported).
node(n232,refuted) :- status(o_503ca5414c5c0df03060,refuted).
node(n232,unknown) :- status(o_503ca5414c5c0df03060,unknown).
node(n233,supported) :- status(o_750272459a32718c5ba1,supported).
node(n233,refuted) :- status(o_750272459a32718c5ba1,refuted).
node(n233,unknown) :- status(o_750272459a32718c5ba1,unknown).
node(n230,supported) :- node(n231,supported), node(n232,supported), node(n233,supported).
node(n230,refuted) :- node(n231,refuted).
node(n230,refuted) :- node(n232,refuted).
node(n230,refuted) :- node(n233,refuted).
node(n230,unknown) :- \+ node(n230,supported), \+ node(n230,refuted).
node(n225,refuted) :- node(n226,refuted), node(n230,refuted), node(n9,refuted).
node(n225,supported) :- node(n226,supported).
node(n225,supported) :- node(n230,supported).
node(n225,supported) :- node(n9,supported).
node(n225,unknown) :- \+ node(n225,supported), \+ node(n225,refuted).
verdict(c_e106ce4ed1ce31a3,supported) :- node(n225,supported).
query(verdict(c_e106ce4ed1ce31a3,supported)).
verdict(c_e106ce4ed1ce31a3,refuted) :- node(n225,refuted).
query(verdict(c_e106ce4ed1ce31a3,refuted)).
verdict(c_e106ce4ed1ce31a3,unknown) :- node(n225,unknown).
query(verdict(c_e106ce4ed1ce31a3,unknown)).
node(n236,supported) :- status(o_987ef028bb2406b4f5ef,supported).
node(n236,refuted) :- status(o_987ef028bb2406b4f5ef,refuted).
node(n236,unknown) :- status(o_987ef028bb2406b4f5ef,unknown).
node(n235,supported) :- node(n227,supported), node(n228,supported), node(n236,supported), node(n229,supported).
node(n235,refuted) :- node(n227,refuted).
node(n235,refuted) :- node(n228,refuted).
node(n235,refuted) :- node(n236,refuted).
node(n235,refuted) :- node(n229,refuted).
node(n235,unknown) :- \+ node(n235,supported), \+ node(n235,refuted).
node(n238,supported) :- status(o_30b058adc25f756c087b,supported).
node(n238,refuted) :- status(o_30b058adc25f756c087b,refuted).
node(n238,unknown) :- status(o_30b058adc25f756c087b,unknown).
node(n237,supported) :- node(n231,supported), node(n232,supported), node(n238,supported), node(n233,supported).
node(n237,refuted) :- node(n231,refuted).
node(n237,refuted) :- node(n232,refuted).
node(n237,refuted) :- node(n238,refuted).
node(n237,refuted) :- node(n233,refuted).
node(n237,unknown) :- \+ node(n237,supported), \+ node(n237,refuted).
node(n234,refuted) :- node(n235,refuted), node(n237,refuted), node(n9,refuted).
node(n234,supported) :- node(n235,supported).
node(n234,supported) :- node(n237,supported).
node(n234,supported) :- node(n9,supported).
node(n234,unknown) :- \+ node(n234,supported), \+ node(n234,refuted).
verdict(c_90e13336ec809399,supported) :- node(n234,supported).
query(verdict(c_90e13336ec809399,supported)).
verdict(c_90e13336ec809399,refuted) :- node(n234,refuted).
query(verdict(c_90e13336ec809399,refuted)).
verdict(c_90e13336ec809399,unknown) :- node(n234,unknown).
query(verdict(c_90e13336ec809399,unknown)).
node(n241,supported) :- status(o_4be5cd0492ea953c4cb1,supported).
node(n241,refuted) :- status(o_4be5cd0492ea953c4cb1,refuted).
node(n241,unknown) :- status(o_4be5cd0492ea953c4cb1,unknown).
node(n242,supported) :- status(o_83655bd54be7d72eda28,supported).
node(n242,refuted) :- status(o_83655bd54be7d72eda28,refuted).
node(n242,unknown) :- status(o_83655bd54be7d72eda28,unknown).
node(n243,supported) :- status(o_774734f7f73ba8e84954,supported).
node(n243,refuted) :- status(o_774734f7f73ba8e84954,refuted).
node(n243,unknown) :- status(o_774734f7f73ba8e84954,unknown).
node(n240,supported) :- node(n241,supported), node(n242,supported), node(n243,supported).
node(n240,refuted) :- node(n241,refuted).
node(n240,refuted) :- node(n242,refuted).
node(n240,refuted) :- node(n243,refuted).
node(n240,unknown) :- \+ node(n240,supported), \+ node(n240,refuted).
node(n245,supported) :- status(o_82d3c180d0f41229c489,supported).
node(n245,refuted) :- status(o_82d3c180d0f41229c489,refuted).
node(n245,unknown) :- status(o_82d3c180d0f41229c489,unknown).
node(n246,supported) :- status(o_1e32ab84608d835cf928,supported).
node(n246,refuted) :- status(o_1e32ab84608d835cf928,refuted).
node(n246,unknown) :- status(o_1e32ab84608d835cf928,unknown).
node(n247,supported) :- status(o_189ef189b9bcb3da2f8f,supported).
node(n247,refuted) :- status(o_189ef189b9bcb3da2f8f,refuted).
node(n247,unknown) :- status(o_189ef189b9bcb3da2f8f,unknown).
node(n244,supported) :- node(n245,supported), node(n246,supported), node(n247,supported).
node(n244,refuted) :- node(n245,refuted).
node(n244,refuted) :- node(n246,refuted).
node(n244,refuted) :- node(n247,refuted).
node(n244,unknown) :- \+ node(n244,supported), \+ node(n244,refuted).
node(n239,refuted) :- node(n240,refuted), node(n244,refuted), node(n9,refuted).
node(n239,supported) :- node(n240,supported).
node(n239,supported) :- node(n244,supported).
node(n239,supported) :- node(n9,supported).
node(n239,unknown) :- \+ node(n239,supported), \+ node(n239,refuted).
verdict(c_9a762486fe4cf67a,supported) :- node(n239,supported).
query(verdict(c_9a762486fe4cf67a,supported)).
verdict(c_9a762486fe4cf67a,refuted) :- node(n239,refuted).
query(verdict(c_9a762486fe4cf67a,refuted)).
verdict(c_9a762486fe4cf67a,unknown) :- node(n239,unknown).
query(verdict(c_9a762486fe4cf67a,unknown)).
node(n250,supported) :- status(o_041fad2098b36bf1c955,supported).
node(n250,refuted) :- status(o_041fad2098b36bf1c955,refuted).
node(n250,unknown) :- status(o_041fad2098b36bf1c955,unknown).
node(n249,supported) :- node(n241,supported), node(n242,supported), node(n250,supported), node(n243,supported).
node(n249,refuted) :- node(n241,refuted).
node(n249,refuted) :- node(n242,refuted).
node(n249,refuted) :- node(n250,refuted).
node(n249,refuted) :- node(n243,refuted).
node(n249,unknown) :- \+ node(n249,supported), \+ node(n249,refuted).
node(n252,supported) :- status(o_9f04e1728f0131f2a986,supported).
node(n252,refuted) :- status(o_9f04e1728f0131f2a986,refuted).
node(n252,unknown) :- status(o_9f04e1728f0131f2a986,unknown).
node(n251,supported) :- node(n245,supported), node(n246,supported), node(n252,supported), node(n247,supported).
node(n251,refuted) :- node(n245,refuted).
node(n251,refuted) :- node(n246,refuted).
node(n251,refuted) :- node(n252,refuted).
node(n251,refuted) :- node(n247,refuted).
node(n251,unknown) :- \+ node(n251,supported), \+ node(n251,refuted).
node(n248,refuted) :- node(n249,refuted), node(n251,refuted), node(n9,refuted).
node(n248,supported) :- node(n249,supported).
node(n248,supported) :- node(n251,supported).
node(n248,supported) :- node(n9,supported).
node(n248,unknown) :- \+ node(n248,supported), \+ node(n248,refuted).
verdict(c_2e544a6d276a0671,supported) :- node(n248,supported).
query(verdict(c_2e544a6d276a0671,supported)).
verdict(c_2e544a6d276a0671,refuted) :- node(n248,refuted).
query(verdict(c_2e544a6d276a0671,refuted)).
verdict(c_2e544a6d276a0671,unknown) :- node(n248,unknown).
query(verdict(c_2e544a6d276a0671,unknown)).
node(n255,supported) :- status(o_10915a9fda153071f95c,supported).
node(n255,refuted) :- status(o_10915a9fda153071f95c,refuted).
node(n255,unknown) :- status(o_10915a9fda153071f95c,unknown).
node(n256,supported) :- status(o_8147183eb3fc7c8faf4d,supported).
node(n256,refuted) :- status(o_8147183eb3fc7c8faf4d,refuted).
node(n256,unknown) :- status(o_8147183eb3fc7c8faf4d,unknown).
node(n257,supported) :- status(o_0b0642323388b2ee12d9,supported).
node(n257,refuted) :- status(o_0b0642323388b2ee12d9,refuted).
node(n257,unknown) :- status(o_0b0642323388b2ee12d9,unknown).
node(n254,supported) :- node(n255,supported), node(n256,supported), node(n257,supported).
node(n254,refuted) :- node(n255,refuted).
node(n254,refuted) :- node(n256,refuted).
node(n254,refuted) :- node(n257,refuted).
node(n254,unknown) :- \+ node(n254,supported), \+ node(n254,refuted).
node(n259,supported) :- status(o_23d9abf97c7312e11c48,supported).
node(n259,refuted) :- status(o_23d9abf97c7312e11c48,refuted).
node(n259,unknown) :- status(o_23d9abf97c7312e11c48,unknown).
node(n260,supported) :- status(o_3ef2af9e543b9aeb6785,supported).
node(n260,refuted) :- status(o_3ef2af9e543b9aeb6785,refuted).
node(n260,unknown) :- status(o_3ef2af9e543b9aeb6785,unknown).
node(n261,supported) :- status(o_e6d6d93052230dd9aa65,supported).
node(n261,refuted) :- status(o_e6d6d93052230dd9aa65,refuted).
node(n261,unknown) :- status(o_e6d6d93052230dd9aa65,unknown).
node(n258,supported) :- node(n259,supported), node(n260,supported), node(n261,supported).
node(n258,refuted) :- node(n259,refuted).
node(n258,refuted) :- node(n260,refuted).
node(n258,refuted) :- node(n261,refuted).
node(n258,unknown) :- \+ node(n258,supported), \+ node(n258,refuted).
node(n253,refuted) :- node(n254,refuted), node(n258,refuted), node(n9,refuted).
node(n253,supported) :- node(n254,supported).
node(n253,supported) :- node(n258,supported).
node(n253,supported) :- node(n9,supported).
node(n253,unknown) :- \+ node(n253,supported), \+ node(n253,refuted).
verdict(c_51172713c6eec07e,supported) :- node(n253,supported).
query(verdict(c_51172713c6eec07e,supported)).
verdict(c_51172713c6eec07e,refuted) :- node(n253,refuted).
query(verdict(c_51172713c6eec07e,refuted)).
verdict(c_51172713c6eec07e,unknown) :- node(n253,unknown).
query(verdict(c_51172713c6eec07e,unknown)).
node(n264,supported) :- status(o_db164fc7378e8d33b396,supported).
node(n264,refuted) :- status(o_db164fc7378e8d33b396,refuted).
node(n264,unknown) :- status(o_db164fc7378e8d33b396,unknown).
node(n263,supported) :- node(n255,supported), node(n256,supported), node(n264,supported), node(n257,supported).
node(n263,refuted) :- node(n255,refuted).
node(n263,refuted) :- node(n256,refuted).
node(n263,refuted) :- node(n264,refuted).
node(n263,refuted) :- node(n257,refuted).
node(n263,unknown) :- \+ node(n263,supported), \+ node(n263,refuted).
node(n266,supported) :- status(o_853da64aa4711d55ca21,supported).
node(n266,refuted) :- status(o_853da64aa4711d55ca21,refuted).
node(n266,unknown) :- status(o_853da64aa4711d55ca21,unknown).
node(n265,supported) :- node(n259,supported), node(n260,supported), node(n266,supported), node(n261,supported).
node(n265,refuted) :- node(n259,refuted).
node(n265,refuted) :- node(n260,refuted).
node(n265,refuted) :- node(n266,refuted).
node(n265,refuted) :- node(n261,refuted).
node(n265,unknown) :- \+ node(n265,supported), \+ node(n265,refuted).
node(n262,refuted) :- node(n263,refuted), node(n265,refuted), node(n9,refuted).
node(n262,supported) :- node(n263,supported).
node(n262,supported) :- node(n265,supported).
node(n262,supported) :- node(n9,supported).
node(n262,unknown) :- \+ node(n262,supported), \+ node(n262,refuted).
verdict(c_6dd3c7db50cc73ff,supported) :- node(n262,supported).
query(verdict(c_6dd3c7db50cc73ff,supported)).
verdict(c_6dd3c7db50cc73ff,refuted) :- node(n262,refuted).
query(verdict(c_6dd3c7db50cc73ff,refuted)).
verdict(c_6dd3c7db50cc73ff,unknown) :- node(n262,unknown).
query(verdict(c_6dd3c7db50cc73ff,unknown)).
node(n269,supported) :- status(o_d25beeaf793a2d11aafd,supported).
node(n269,refuted) :- status(o_d25beeaf793a2d11aafd,refuted).
node(n269,unknown) :- status(o_d25beeaf793a2d11aafd,unknown).
node(n270,supported) :- status(o_8bec9fddfc0c3c190cbe,supported).
node(n270,refuted) :- status(o_8bec9fddfc0c3c190cbe,refuted).
node(n270,unknown) :- status(o_8bec9fddfc0c3c190cbe,unknown).
node(n271,supported) :- status(o_380cd7bea85edcfdbe35,supported).
node(n271,refuted) :- status(o_380cd7bea85edcfdbe35,refuted).
node(n271,unknown) :- status(o_380cd7bea85edcfdbe35,unknown).
node(n268,supported) :- node(n269,supported), node(n270,supported), node(n271,supported).
node(n268,refuted) :- node(n269,refuted).
node(n268,refuted) :- node(n270,refuted).
node(n268,refuted) :- node(n271,refuted).
node(n268,unknown) :- \+ node(n268,supported), \+ node(n268,refuted).
node(n273,supported) :- status(o_55f80f8e3fff5c90dc56,supported).
node(n273,refuted) :- status(o_55f80f8e3fff5c90dc56,refuted).
node(n273,unknown) :- status(o_55f80f8e3fff5c90dc56,unknown).
node(n274,supported) :- status(o_d615ab15936804bea4a8,supported).
node(n274,refuted) :- status(o_d615ab15936804bea4a8,refuted).
node(n274,unknown) :- status(o_d615ab15936804bea4a8,unknown).
node(n275,supported) :- status(o_ca8d6e8f84304a946ab8,supported).
node(n275,refuted) :- status(o_ca8d6e8f84304a946ab8,refuted).
node(n275,unknown) :- status(o_ca8d6e8f84304a946ab8,unknown).
node(n272,supported) :- node(n273,supported), node(n274,supported), node(n275,supported).
node(n272,refuted) :- node(n273,refuted).
node(n272,refuted) :- node(n274,refuted).
node(n272,refuted) :- node(n275,refuted).
node(n272,unknown) :- \+ node(n272,supported), \+ node(n272,refuted).
node(n267,refuted) :- node(n268,refuted), node(n272,refuted), node(n9,refuted).
node(n267,supported) :- node(n268,supported).
node(n267,supported) :- node(n272,supported).
node(n267,supported) :- node(n9,supported).
node(n267,unknown) :- \+ node(n267,supported), \+ node(n267,refuted).
verdict(c_c4b4bc8cd26f98d7,supported) :- node(n267,supported).
query(verdict(c_c4b4bc8cd26f98d7,supported)).
verdict(c_c4b4bc8cd26f98d7,refuted) :- node(n267,refuted).
query(verdict(c_c4b4bc8cd26f98d7,refuted)).
verdict(c_c4b4bc8cd26f98d7,unknown) :- node(n267,unknown).
query(verdict(c_c4b4bc8cd26f98d7,unknown)).
node(n278,supported) :- status(o_82ead0c37cf8d88466bf,supported).
node(n278,refuted) :- status(o_82ead0c37cf8d88466bf,refuted).
node(n278,unknown) :- status(o_82ead0c37cf8d88466bf,unknown).
node(n277,supported) :- node(n269,supported), node(n270,supported), node(n278,supported), node(n271,supported).
node(n277,refuted) :- node(n269,refuted).
node(n277,refuted) :- node(n270,refuted).
node(n277,refuted) :- node(n278,refuted).
node(n277,refuted) :- node(n271,refuted).
node(n277,unknown) :- \+ node(n277,supported), \+ node(n277,refuted).
node(n280,supported) :- status(o_dccb54e5a9ad077fe791,supported).
node(n280,refuted) :- status(o_dccb54e5a9ad077fe791,refuted).
node(n280,unknown) :- status(o_dccb54e5a9ad077fe791,unknown).
node(n279,supported) :- node(n273,supported), node(n274,supported), node(n280,supported), node(n275,supported).
node(n279,refuted) :- node(n273,refuted).
node(n279,refuted) :- node(n274,refuted).
node(n279,refuted) :- node(n280,refuted).
node(n279,refuted) :- node(n275,refuted).
node(n279,unknown) :- \+ node(n279,supported), \+ node(n279,refuted).
node(n276,refuted) :- node(n277,refuted), node(n279,refuted), node(n9,refuted).
node(n276,supported) :- node(n277,supported).
node(n276,supported) :- node(n279,supported).
node(n276,supported) :- node(n9,supported).
node(n276,unknown) :- \+ node(n276,supported), \+ node(n276,refuted).
verdict(c_935994c42e146e85,supported) :- node(n276,supported).
query(verdict(c_935994c42e146e85,supported)).
verdict(c_935994c42e146e85,refuted) :- node(n276,refuted).
query(verdict(c_935994c42e146e85,refuted)).
verdict(c_935994c42e146e85,unknown) :- node(n276,unknown).
query(verdict(c_935994c42e146e85,unknown)).
node(n283,supported) :- status(o_1b1423734fde71379068,supported).
node(n283,refuted) :- status(o_1b1423734fde71379068,refuted).
node(n283,unknown) :- status(o_1b1423734fde71379068,unknown).
node(n284,supported) :- status(o_71dc0665a3dd07e090d4,supported).
node(n284,refuted) :- status(o_71dc0665a3dd07e090d4,refuted).
node(n284,unknown) :- status(o_71dc0665a3dd07e090d4,unknown).
node(n285,supported) :- status(o_82e4c8c1d9640cc8f6dc,supported).
node(n285,refuted) :- status(o_82e4c8c1d9640cc8f6dc,refuted).
node(n285,unknown) :- status(o_82e4c8c1d9640cc8f6dc,unknown).
node(n282,supported) :- node(n283,supported), node(n284,supported), node(n285,supported).
node(n282,refuted) :- node(n283,refuted).
node(n282,refuted) :- node(n284,refuted).
node(n282,refuted) :- node(n285,refuted).
node(n282,unknown) :- \+ node(n282,supported), \+ node(n282,refuted).
node(n287,supported) :- status(o_39f3c00c33d2d06295a3,supported).
node(n287,refuted) :- status(o_39f3c00c33d2d06295a3,refuted).
node(n287,unknown) :- status(o_39f3c00c33d2d06295a3,unknown).
node(n288,supported) :- status(o_7cb182bee4bd6aa25d27,supported).
node(n288,refuted) :- status(o_7cb182bee4bd6aa25d27,refuted).
node(n288,unknown) :- status(o_7cb182bee4bd6aa25d27,unknown).
node(n289,supported) :- status(o_1057b77d00153ef3b411,supported).
node(n289,refuted) :- status(o_1057b77d00153ef3b411,refuted).
node(n289,unknown) :- status(o_1057b77d00153ef3b411,unknown).
node(n286,supported) :- node(n287,supported), node(n288,supported), node(n289,supported).
node(n286,refuted) :- node(n287,refuted).
node(n286,refuted) :- node(n288,refuted).
node(n286,refuted) :- node(n289,refuted).
node(n286,unknown) :- \+ node(n286,supported), \+ node(n286,refuted).
node(n281,refuted) :- node(n282,refuted), node(n286,refuted), node(n9,refuted).
node(n281,supported) :- node(n282,supported).
node(n281,supported) :- node(n286,supported).
node(n281,supported) :- node(n9,supported).
node(n281,unknown) :- \+ node(n281,supported), \+ node(n281,refuted).
verdict(c_a9161500b73427ff,supported) :- node(n281,supported).
query(verdict(c_a9161500b73427ff,supported)).
verdict(c_a9161500b73427ff,refuted) :- node(n281,refuted).
query(verdict(c_a9161500b73427ff,refuted)).
verdict(c_a9161500b73427ff,unknown) :- node(n281,unknown).
query(verdict(c_a9161500b73427ff,unknown)).
node(n292,supported) :- status(o_b67fc15ec96533ecc714,supported).
node(n292,refuted) :- status(o_b67fc15ec96533ecc714,refuted).
node(n292,unknown) :- status(o_b67fc15ec96533ecc714,unknown).
node(n291,supported) :- node(n283,supported), node(n284,supported), node(n292,supported), node(n285,supported).
node(n291,refuted) :- node(n283,refuted).
node(n291,refuted) :- node(n284,refuted).
node(n291,refuted) :- node(n292,refuted).
node(n291,refuted) :- node(n285,refuted).
node(n291,unknown) :- \+ node(n291,supported), \+ node(n291,refuted).
node(n294,supported) :- status(o_7eedce19a0d8caee91bd,supported).
node(n294,refuted) :- status(o_7eedce19a0d8caee91bd,refuted).
node(n294,unknown) :- status(o_7eedce19a0d8caee91bd,unknown).
node(n293,supported) :- node(n287,supported), node(n288,supported), node(n294,supported), node(n289,supported).
node(n293,refuted) :- node(n287,refuted).
node(n293,refuted) :- node(n288,refuted).
node(n293,refuted) :- node(n294,refuted).
node(n293,refuted) :- node(n289,refuted).
node(n293,unknown) :- \+ node(n293,supported), \+ node(n293,refuted).
node(n290,refuted) :- node(n291,refuted), node(n293,refuted), node(n9,refuted).
node(n290,supported) :- node(n291,supported).
node(n290,supported) :- node(n293,supported).
node(n290,supported) :- node(n9,supported).
node(n290,unknown) :- \+ node(n290,supported), \+ node(n290,refuted).
verdict(c_fcb82393da3eedcf,supported) :- node(n290,supported).
query(verdict(c_fcb82393da3eedcf,supported)).
verdict(c_fcb82393da3eedcf,refuted) :- node(n290,refuted).
query(verdict(c_fcb82393da3eedcf,refuted)).
verdict(c_fcb82393da3eedcf,unknown) :- node(n290,unknown).
query(verdict(c_fcb82393da3eedcf,unknown)).
node(n297,supported) :- status(o_59bd0b466267eb69465f,supported).
node(n297,refuted) :- status(o_59bd0b466267eb69465f,refuted).
node(n297,unknown) :- status(o_59bd0b466267eb69465f,unknown).
node(n298,supported) :- status(o_1a65a3aa61fceb1375c6,supported).
node(n298,refuted) :- status(o_1a65a3aa61fceb1375c6,refuted).
node(n298,unknown) :- status(o_1a65a3aa61fceb1375c6,unknown).
node(n299,supported) :- status(o_4a0151fb6805df655848,supported).
node(n299,refuted) :- status(o_4a0151fb6805df655848,refuted).
node(n299,unknown) :- status(o_4a0151fb6805df655848,unknown).
node(n296,supported) :- node(n297,supported), node(n298,supported), node(n299,supported).
node(n296,refuted) :- node(n297,refuted).
node(n296,refuted) :- node(n298,refuted).
node(n296,refuted) :- node(n299,refuted).
node(n296,unknown) :- \+ node(n296,supported), \+ node(n296,refuted).
node(n301,supported) :- status(o_b9739de91b3f5f02b15c,supported).
node(n301,refuted) :- status(o_b9739de91b3f5f02b15c,refuted).
node(n301,unknown) :- status(o_b9739de91b3f5f02b15c,unknown).
node(n302,supported) :- status(o_d2f74ce791abcfcda10d,supported).
node(n302,refuted) :- status(o_d2f74ce791abcfcda10d,refuted).
node(n302,unknown) :- status(o_d2f74ce791abcfcda10d,unknown).
node(n303,supported) :- status(o_83a507c35c6fa3c8ba31,supported).
node(n303,refuted) :- status(o_83a507c35c6fa3c8ba31,refuted).
node(n303,unknown) :- status(o_83a507c35c6fa3c8ba31,unknown).
node(n300,supported) :- node(n301,supported), node(n302,supported), node(n303,supported).
node(n300,refuted) :- node(n301,refuted).
node(n300,refuted) :- node(n302,refuted).
node(n300,refuted) :- node(n303,refuted).
node(n300,unknown) :- \+ node(n300,supported), \+ node(n300,refuted).
node(n295,refuted) :- node(n296,refuted), node(n300,refuted), node(n9,refuted).
node(n295,supported) :- node(n296,supported).
node(n295,supported) :- node(n300,supported).
node(n295,supported) :- node(n9,supported).
node(n295,unknown) :- \+ node(n295,supported), \+ node(n295,refuted).
verdict(c_74dba177a6e818ee,supported) :- node(n295,supported).
query(verdict(c_74dba177a6e818ee,supported)).
verdict(c_74dba177a6e818ee,refuted) :- node(n295,refuted).
query(verdict(c_74dba177a6e818ee,refuted)).
verdict(c_74dba177a6e818ee,unknown) :- node(n295,unknown).
query(verdict(c_74dba177a6e818ee,unknown)).
node(n306,supported) :- status(o_17349294e25e0e5020ac,supported).
node(n306,refuted) :- status(o_17349294e25e0e5020ac,refuted).
node(n306,unknown) :- status(o_17349294e25e0e5020ac,unknown).
node(n305,supported) :- node(n297,supported), node(n298,supported), node(n306,supported), node(n299,supported).
node(n305,refuted) :- node(n297,refuted).
node(n305,refuted) :- node(n298,refuted).
node(n305,refuted) :- node(n306,refuted).
node(n305,refuted) :- node(n299,refuted).
node(n305,unknown) :- \+ node(n305,supported), \+ node(n305,refuted).
node(n308,supported) :- status(o_1f150e921c59c5abe116,supported).
node(n308,refuted) :- status(o_1f150e921c59c5abe116,refuted).
node(n308,unknown) :- status(o_1f150e921c59c5abe116,unknown).
node(n307,supported) :- node(n301,supported), node(n302,supported), node(n308,supported), node(n303,supported).
node(n307,refuted) :- node(n301,refuted).
node(n307,refuted) :- node(n302,refuted).
node(n307,refuted) :- node(n308,refuted).
node(n307,refuted) :- node(n303,refuted).
node(n307,unknown) :- \+ node(n307,supported), \+ node(n307,refuted).
node(n304,refuted) :- node(n305,refuted), node(n307,refuted), node(n9,refuted).
node(n304,supported) :- node(n305,supported).
node(n304,supported) :- node(n307,supported).
node(n304,supported) :- node(n9,supported).
node(n304,unknown) :- \+ node(n304,supported), \+ node(n304,refuted).
verdict(c_5561772cebe98808,supported) :- node(n304,supported).
query(verdict(c_5561772cebe98808,supported)).
verdict(c_5561772cebe98808,refuted) :- node(n304,refuted).
query(verdict(c_5561772cebe98808,refuted)).
verdict(c_5561772cebe98808,unknown) :- node(n304,unknown).
query(verdict(c_5561772cebe98808,unknown)).
node(n311,supported) :- status(o_97ea8e2ea18d65f02c6a,supported).
node(n311,refuted) :- status(o_97ea8e2ea18d65f02c6a,refuted).
node(n311,unknown) :- status(o_97ea8e2ea18d65f02c6a,unknown).
node(n312,supported) :- status(o_b470b3d75d34aad86396,supported).
node(n312,refuted) :- status(o_b470b3d75d34aad86396,refuted).
node(n312,unknown) :- status(o_b470b3d75d34aad86396,unknown).
node(n313,supported) :- status(o_ce94b9f9efa519c1d158,supported).
node(n313,refuted) :- status(o_ce94b9f9efa519c1d158,refuted).
node(n313,unknown) :- status(o_ce94b9f9efa519c1d158,unknown).
node(n310,supported) :- node(n311,supported), node(n312,supported), node(n313,supported).
node(n310,refuted) :- node(n311,refuted).
node(n310,refuted) :- node(n312,refuted).
node(n310,refuted) :- node(n313,refuted).
node(n310,unknown) :- \+ node(n310,supported), \+ node(n310,refuted).
node(n315,supported) :- status(o_d37dc66ead8066eda751,supported).
node(n315,refuted) :- status(o_d37dc66ead8066eda751,refuted).
node(n315,unknown) :- status(o_d37dc66ead8066eda751,unknown).
node(n316,supported) :- status(o_c7bf8036bd21467ff354,supported).
node(n316,refuted) :- status(o_c7bf8036bd21467ff354,refuted).
node(n316,unknown) :- status(o_c7bf8036bd21467ff354,unknown).
node(n317,supported) :- status(o_391054f01387a78474e4,supported).
node(n317,refuted) :- status(o_391054f01387a78474e4,refuted).
node(n317,unknown) :- status(o_391054f01387a78474e4,unknown).
node(n314,supported) :- node(n315,supported), node(n316,supported), node(n317,supported).
node(n314,refuted) :- node(n315,refuted).
node(n314,refuted) :- node(n316,refuted).
node(n314,refuted) :- node(n317,refuted).
node(n314,unknown) :- \+ node(n314,supported), \+ node(n314,refuted).
node(n309,refuted) :- node(n310,refuted), node(n314,refuted), node(n9,refuted).
node(n309,supported) :- node(n310,supported).
node(n309,supported) :- node(n314,supported).
node(n309,supported) :- node(n9,supported).
node(n309,unknown) :- \+ node(n309,supported), \+ node(n309,refuted).
verdict(c_dd2753f9c14e2d5f,supported) :- node(n309,supported).
query(verdict(c_dd2753f9c14e2d5f,supported)).
verdict(c_dd2753f9c14e2d5f,refuted) :- node(n309,refuted).
query(verdict(c_dd2753f9c14e2d5f,refuted)).
verdict(c_dd2753f9c14e2d5f,unknown) :- node(n309,unknown).
query(verdict(c_dd2753f9c14e2d5f,unknown)).
node(n320,supported) :- status(o_ec0370b4ed1fd4597d65,supported).
node(n320,refuted) :- status(o_ec0370b4ed1fd4597d65,refuted).
node(n320,unknown) :- status(o_ec0370b4ed1fd4597d65,unknown).
node(n319,supported) :- node(n311,supported), node(n312,supported), node(n320,supported), node(n313,supported).
node(n319,refuted) :- node(n311,refuted).
node(n319,refuted) :- node(n312,refuted).
node(n319,refuted) :- node(n320,refuted).
node(n319,refuted) :- node(n313,refuted).
node(n319,unknown) :- \+ node(n319,supported), \+ node(n319,refuted).
node(n322,supported) :- status(o_9587f71948ac3e900a38,supported).
node(n322,refuted) :- status(o_9587f71948ac3e900a38,refuted).
node(n322,unknown) :- status(o_9587f71948ac3e900a38,unknown).
node(n321,supported) :- node(n315,supported), node(n316,supported), node(n322,supported), node(n317,supported).
node(n321,refuted) :- node(n315,refuted).
node(n321,refuted) :- node(n316,refuted).
node(n321,refuted) :- node(n322,refuted).
node(n321,refuted) :- node(n317,refuted).
node(n321,unknown) :- \+ node(n321,supported), \+ node(n321,refuted).
node(n318,refuted) :- node(n319,refuted), node(n321,refuted), node(n9,refuted).
node(n318,supported) :- node(n319,supported).
node(n318,supported) :- node(n321,supported).
node(n318,supported) :- node(n9,supported).
node(n318,unknown) :- \+ node(n318,supported), \+ node(n318,refuted).
verdict(c_bb9ceb45d824e459,supported) :- node(n318,supported).
query(verdict(c_bb9ceb45d824e459,supported)).
verdict(c_bb9ceb45d824e459,refuted) :- node(n318,refuted).
query(verdict(c_bb9ceb45d824e459,refuted)).
verdict(c_bb9ceb45d824e459,unknown) :- node(n318,unknown).
query(verdict(c_bb9ceb45d824e459,unknown)).
node(n325,supported) :- status(o_a71f75cacf8a7d59e3ad,supported).
node(n325,refuted) :- status(o_a71f75cacf8a7d59e3ad,refuted).
node(n325,unknown) :- status(o_a71f75cacf8a7d59e3ad,unknown).
node(n326,supported) :- status(o_7b3ae359f177745704f2,supported).
node(n326,refuted) :- status(o_7b3ae359f177745704f2,refuted).
node(n326,unknown) :- status(o_7b3ae359f177745704f2,unknown).
node(n327,supported) :- status(o_6bfa53317f4a1ffba4a5,supported).
node(n327,refuted) :- status(o_6bfa53317f4a1ffba4a5,refuted).
node(n327,unknown) :- status(o_6bfa53317f4a1ffba4a5,unknown).
node(n324,supported) :- node(n325,supported), node(n326,supported), node(n327,supported).
node(n324,refuted) :- node(n325,refuted).
node(n324,refuted) :- node(n326,refuted).
node(n324,refuted) :- node(n327,refuted).
node(n324,unknown) :- \+ node(n324,supported), \+ node(n324,refuted).
node(n329,supported) :- status(o_d2b04100e77590a0f383,supported).
node(n329,refuted) :- status(o_d2b04100e77590a0f383,refuted).
node(n329,unknown) :- status(o_d2b04100e77590a0f383,unknown).
node(n330,supported) :- status(o_bc16c0fec338ac0f8f9f,supported).
node(n330,refuted) :- status(o_bc16c0fec338ac0f8f9f,refuted).
node(n330,unknown) :- status(o_bc16c0fec338ac0f8f9f,unknown).
node(n331,supported) :- status(o_9c5f776b396a8173bf15,supported).
node(n331,refuted) :- status(o_9c5f776b396a8173bf15,refuted).
node(n331,unknown) :- status(o_9c5f776b396a8173bf15,unknown).
node(n328,supported) :- node(n329,supported), node(n330,supported), node(n331,supported).
node(n328,refuted) :- node(n329,refuted).
node(n328,refuted) :- node(n330,refuted).
node(n328,refuted) :- node(n331,refuted).
node(n328,unknown) :- \+ node(n328,supported), \+ node(n328,refuted).
node(n323,refuted) :- node(n324,refuted), node(n328,refuted), node(n9,refuted).
node(n323,supported) :- node(n324,supported).
node(n323,supported) :- node(n328,supported).
node(n323,supported) :- node(n9,supported).
node(n323,unknown) :- \+ node(n323,supported), \+ node(n323,refuted).
verdict(c_4438544a8bb6f8aa,supported) :- node(n323,supported).
query(verdict(c_4438544a8bb6f8aa,supported)).
verdict(c_4438544a8bb6f8aa,refuted) :- node(n323,refuted).
query(verdict(c_4438544a8bb6f8aa,refuted)).
verdict(c_4438544a8bb6f8aa,unknown) :- node(n323,unknown).
query(verdict(c_4438544a8bb6f8aa,unknown)).
node(n334,supported) :- status(o_93dca9ca614b3f400d69,supported).
node(n334,refuted) :- status(o_93dca9ca614b3f400d69,refuted).
node(n334,unknown) :- status(o_93dca9ca614b3f400d69,unknown).
node(n333,supported) :- node(n325,supported), node(n326,supported), node(n334,supported), node(n327,supported).
node(n333,refuted) :- node(n325,refuted).
node(n333,refuted) :- node(n326,refuted).
node(n333,refuted) :- node(n334,refuted).
node(n333,refuted) :- node(n327,refuted).
node(n333,unknown) :- \+ node(n333,supported), \+ node(n333,refuted).
node(n336,supported) :- status(o_12474bc22d945a333a5f,supported).
node(n336,refuted) :- status(o_12474bc22d945a333a5f,refuted).
node(n336,unknown) :- status(o_12474bc22d945a333a5f,unknown).
node(n335,supported) :- node(n329,supported), node(n330,supported), node(n336,supported), node(n331,supported).
node(n335,refuted) :- node(n329,refuted).
node(n335,refuted) :- node(n330,refuted).
node(n335,refuted) :- node(n336,refuted).
node(n335,refuted) :- node(n331,refuted).
node(n335,unknown) :- \+ node(n335,supported), \+ node(n335,refuted).
node(n332,refuted) :- node(n333,refuted), node(n335,refuted), node(n9,refuted).
node(n332,supported) :- node(n333,supported).
node(n332,supported) :- node(n335,supported).
node(n332,supported) :- node(n9,supported).
node(n332,unknown) :- \+ node(n332,supported), \+ node(n332,refuted).
verdict(c_89e96639c76b1dab,supported) :- node(n332,supported).
query(verdict(c_89e96639c76b1dab,supported)).
verdict(c_89e96639c76b1dab,refuted) :- node(n332,refuted).
query(verdict(c_89e96639c76b1dab,refuted)).
verdict(c_89e96639c76b1dab,unknown) :- node(n332,unknown).
query(verdict(c_89e96639c76b1dab,unknown)).
node(n339,supported) :- status(o_fdc55e0b47ccc863e214,supported).
node(n339,refuted) :- status(o_fdc55e0b47ccc863e214,refuted).
node(n339,unknown) :- status(o_fdc55e0b47ccc863e214,unknown).
node(n340,supported) :- status(o_9fce83ed2f2d9c5c3dcc,supported).
node(n340,refuted) :- status(o_9fce83ed2f2d9c5c3dcc,refuted).
node(n340,unknown) :- status(o_9fce83ed2f2d9c5c3dcc,unknown).
node(n341,supported) :- status(o_7d76d0e158ae641f79a7,supported).
node(n341,refuted) :- status(o_7d76d0e158ae641f79a7,refuted).
node(n341,unknown) :- status(o_7d76d0e158ae641f79a7,unknown).
node(n338,supported) :- node(n339,supported), node(n340,supported), node(n341,supported).
node(n338,refuted) :- node(n339,refuted).
node(n338,refuted) :- node(n340,refuted).
node(n338,refuted) :- node(n341,refuted).
node(n338,unknown) :- \+ node(n338,supported), \+ node(n338,refuted).
node(n343,supported) :- status(o_2a4b68297b2649f9b517,supported).
node(n343,refuted) :- status(o_2a4b68297b2649f9b517,refuted).
node(n343,unknown) :- status(o_2a4b68297b2649f9b517,unknown).
node(n344,supported) :- status(o_ceeb794293e96c7f6ce5,supported).
node(n344,refuted) :- status(o_ceeb794293e96c7f6ce5,refuted).
node(n344,unknown) :- status(o_ceeb794293e96c7f6ce5,unknown).
node(n345,supported) :- status(o_00fb41f1e22830074c78,supported).
node(n345,refuted) :- status(o_00fb41f1e22830074c78,refuted).
node(n345,unknown) :- status(o_00fb41f1e22830074c78,unknown).
node(n342,supported) :- node(n343,supported), node(n344,supported), node(n345,supported).
node(n342,refuted) :- node(n343,refuted).
node(n342,refuted) :- node(n344,refuted).
node(n342,refuted) :- node(n345,refuted).
node(n342,unknown) :- \+ node(n342,supported), \+ node(n342,refuted).
node(n337,refuted) :- node(n338,refuted), node(n342,refuted), node(n9,refuted).
node(n337,supported) :- node(n338,supported).
node(n337,supported) :- node(n342,supported).
node(n337,supported) :- node(n9,supported).
node(n337,unknown) :- \+ node(n337,supported), \+ node(n337,refuted).
verdict(c_26ef71cdfaf60d6b,supported) :- node(n337,supported).
query(verdict(c_26ef71cdfaf60d6b,supported)).
verdict(c_26ef71cdfaf60d6b,refuted) :- node(n337,refuted).
query(verdict(c_26ef71cdfaf60d6b,refuted)).
verdict(c_26ef71cdfaf60d6b,unknown) :- node(n337,unknown).
query(verdict(c_26ef71cdfaf60d6b,unknown)).
node(n348,supported) :- status(o_1959c21204d936b7bb18,supported).
node(n348,refuted) :- status(o_1959c21204d936b7bb18,refuted).
node(n348,unknown) :- status(o_1959c21204d936b7bb18,unknown).
node(n347,supported) :- node(n339,supported), node(n340,supported), node(n348,supported), node(n341,supported).
node(n347,refuted) :- node(n339,refuted).
node(n347,refuted) :- node(n340,refuted).
node(n347,refuted) :- node(n348,refuted).
node(n347,refuted) :- node(n341,refuted).
node(n347,unknown) :- \+ node(n347,supported), \+ node(n347,refuted).
node(n350,supported) :- status(o_9da1edaecfe98641b294,supported).
node(n350,refuted) :- status(o_9da1edaecfe98641b294,refuted).
node(n350,unknown) :- status(o_9da1edaecfe98641b294,unknown).
node(n349,supported) :- node(n343,supported), node(n344,supported), node(n350,supported), node(n345,supported).
node(n349,refuted) :- node(n343,refuted).
node(n349,refuted) :- node(n344,refuted).
node(n349,refuted) :- node(n350,refuted).
node(n349,refuted) :- node(n345,refuted).
node(n349,unknown) :- \+ node(n349,supported), \+ node(n349,refuted).
node(n346,refuted) :- node(n347,refuted), node(n349,refuted), node(n9,refuted).
node(n346,supported) :- node(n347,supported).
node(n346,supported) :- node(n349,supported).
node(n346,supported) :- node(n9,supported).
node(n346,unknown) :- \+ node(n346,supported), \+ node(n346,refuted).
verdict(c_601f25244df69984,supported) :- node(n346,supported).
query(verdict(c_601f25244df69984,supported)).
verdict(c_601f25244df69984,refuted) :- node(n346,refuted).
query(verdict(c_601f25244df69984,refuted)).
verdict(c_601f25244df69984,unknown) :- node(n346,unknown).
query(verdict(c_601f25244df69984,unknown)).
node(n353,supported) :- status(o_e9bc94025c5bbe5abdc9,supported).
node(n353,refuted) :- status(o_e9bc94025c5bbe5abdc9,refuted).
node(n353,unknown) :- status(o_e9bc94025c5bbe5abdc9,unknown).
node(n354,supported) :- status(o_b0920e19405a033d6046,supported).
node(n354,refuted) :- status(o_b0920e19405a033d6046,refuted).
node(n354,unknown) :- status(o_b0920e19405a033d6046,unknown).
node(n355,supported) :- status(o_050830b1b614ac139fdc,supported).
node(n355,refuted) :- status(o_050830b1b614ac139fdc,refuted).
node(n355,unknown) :- status(o_050830b1b614ac139fdc,unknown).
node(n352,supported) :- node(n353,supported), node(n354,supported), node(n355,supported).
node(n352,refuted) :- node(n353,refuted).
node(n352,refuted) :- node(n354,refuted).
node(n352,refuted) :- node(n355,refuted).
node(n352,unknown) :- \+ node(n352,supported), \+ node(n352,refuted).
node(n357,supported) :- status(o_651364aa679d8f6f7279,supported).
node(n357,refuted) :- status(o_651364aa679d8f6f7279,refuted).
node(n357,unknown) :- status(o_651364aa679d8f6f7279,unknown).
node(n358,supported) :- status(o_f26234378172ce845679,supported).
node(n358,refuted) :- status(o_f26234378172ce845679,refuted).
node(n358,unknown) :- status(o_f26234378172ce845679,unknown).
node(n359,supported) :- status(o_ac1860d8c2e650b4f592,supported).
node(n359,refuted) :- status(o_ac1860d8c2e650b4f592,refuted).
node(n359,unknown) :- status(o_ac1860d8c2e650b4f592,unknown).
node(n356,supported) :- node(n357,supported), node(n358,supported), node(n359,supported).
node(n356,refuted) :- node(n357,refuted).
node(n356,refuted) :- node(n358,refuted).
node(n356,refuted) :- node(n359,refuted).
node(n356,unknown) :- \+ node(n356,supported), \+ node(n356,refuted).
node(n351,refuted) :- node(n352,refuted), node(n356,refuted), node(n9,refuted).
node(n351,supported) :- node(n352,supported).
node(n351,supported) :- node(n356,supported).
node(n351,supported) :- node(n9,supported).
node(n351,unknown) :- \+ node(n351,supported), \+ node(n351,refuted).
verdict(c_7c07bc97997f9358,supported) :- node(n351,supported).
query(verdict(c_7c07bc97997f9358,supported)).
verdict(c_7c07bc97997f9358,refuted) :- node(n351,refuted).
query(verdict(c_7c07bc97997f9358,refuted)).
verdict(c_7c07bc97997f9358,unknown) :- node(n351,unknown).
query(verdict(c_7c07bc97997f9358,unknown)).
node(n362,supported) :- status(o_5603683a4da939be9f2a,supported).
node(n362,refuted) :- status(o_5603683a4da939be9f2a,refuted).
node(n362,unknown) :- status(o_5603683a4da939be9f2a,unknown).
node(n361,supported) :- node(n353,supported), node(n354,supported), node(n362,supported), node(n355,supported).
node(n361,refuted) :- node(n353,refuted).
node(n361,refuted) :- node(n354,refuted).
node(n361,refuted) :- node(n362,refuted).
node(n361,refuted) :- node(n355,refuted).
node(n361,unknown) :- \+ node(n361,supported), \+ node(n361,refuted).
node(n364,supported) :- status(o_fc5d172618695dffb3b5,supported).
node(n364,refuted) :- status(o_fc5d172618695dffb3b5,refuted).
node(n364,unknown) :- status(o_fc5d172618695dffb3b5,unknown).
node(n363,supported) :- node(n357,supported), node(n358,supported), node(n364,supported), node(n359,supported).
node(n363,refuted) :- node(n357,refuted).
node(n363,refuted) :- node(n358,refuted).
node(n363,refuted) :- node(n364,refuted).
node(n363,refuted) :- node(n359,refuted).
node(n363,unknown) :- \+ node(n363,supported), \+ node(n363,refuted).
node(n360,refuted) :- node(n361,refuted), node(n363,refuted), node(n9,refuted).
node(n360,supported) :- node(n361,supported).
node(n360,supported) :- node(n363,supported).
node(n360,supported) :- node(n9,supported).
node(n360,unknown) :- \+ node(n360,supported), \+ node(n360,refuted).
verdict(c_561ddf9b3b69ff9a,supported) :- node(n360,supported).
query(verdict(c_561ddf9b3b69ff9a,supported)).
verdict(c_561ddf9b3b69ff9a,refuted) :- node(n360,refuted).
query(verdict(c_561ddf9b3b69ff9a,refuted)).
verdict(c_561ddf9b3b69ff9a,unknown) :- node(n360,unknown).
query(verdict(c_561ddf9b3b69ff9a,unknown)).
node(n367,supported) :- status(o_51b7c3bed597455aec56,supported).
node(n367,refuted) :- status(o_51b7c3bed597455aec56,refuted).
node(n367,unknown) :- status(o_51b7c3bed597455aec56,unknown).
node(n368,supported) :- status(o_f296509176f1f25458ff,supported).
node(n368,refuted) :- status(o_f296509176f1f25458ff,refuted).
node(n368,unknown) :- status(o_f296509176f1f25458ff,unknown).
node(n369,supported) :- status(o_4693b80ef71d719f4d3e,supported).
node(n369,refuted) :- status(o_4693b80ef71d719f4d3e,refuted).
node(n369,unknown) :- status(o_4693b80ef71d719f4d3e,unknown).
node(n366,supported) :- node(n367,supported), node(n368,supported), node(n369,supported).
node(n366,refuted) :- node(n367,refuted).
node(n366,refuted) :- node(n368,refuted).
node(n366,refuted) :- node(n369,refuted).
node(n366,unknown) :- \+ node(n366,supported), \+ node(n366,refuted).
node(n371,supported) :- status(o_a3a4e1a87af149f975dc,supported).
node(n371,refuted) :- status(o_a3a4e1a87af149f975dc,refuted).
node(n371,unknown) :- status(o_a3a4e1a87af149f975dc,unknown).
node(n372,supported) :- status(o_e4813344d64f93dec787,supported).
node(n372,refuted) :- status(o_e4813344d64f93dec787,refuted).
node(n372,unknown) :- status(o_e4813344d64f93dec787,unknown).
node(n373,supported) :- status(o_359ff78e6704a5fbcafa,supported).
node(n373,refuted) :- status(o_359ff78e6704a5fbcafa,refuted).
node(n373,unknown) :- status(o_359ff78e6704a5fbcafa,unknown).
node(n370,supported) :- node(n371,supported), node(n372,supported), node(n373,supported).
node(n370,refuted) :- node(n371,refuted).
node(n370,refuted) :- node(n372,refuted).
node(n370,refuted) :- node(n373,refuted).
node(n370,unknown) :- \+ node(n370,supported), \+ node(n370,refuted).
node(n365,refuted) :- node(n366,refuted), node(n370,refuted), node(n9,refuted).
node(n365,supported) :- node(n366,supported).
node(n365,supported) :- node(n370,supported).
node(n365,supported) :- node(n9,supported).
node(n365,unknown) :- \+ node(n365,supported), \+ node(n365,refuted).
verdict(c_c8b52f895e41c83c,supported) :- node(n365,supported).
query(verdict(c_c8b52f895e41c83c,supported)).
verdict(c_c8b52f895e41c83c,refuted) :- node(n365,refuted).
query(verdict(c_c8b52f895e41c83c,refuted)).
verdict(c_c8b52f895e41c83c,unknown) :- node(n365,unknown).
query(verdict(c_c8b52f895e41c83c,unknown)).
node(n376,supported) :- status(o_318192354e832d2c844f,supported).
node(n376,refuted) :- status(o_318192354e832d2c844f,refuted).
node(n376,unknown) :- status(o_318192354e832d2c844f,unknown).
node(n375,supported) :- node(n367,supported), node(n368,supported), node(n376,supported), node(n369,supported).
node(n375,refuted) :- node(n367,refuted).
node(n375,refuted) :- node(n368,refuted).
node(n375,refuted) :- node(n376,refuted).
node(n375,refuted) :- node(n369,refuted).
node(n375,unknown) :- \+ node(n375,supported), \+ node(n375,refuted).
node(n378,supported) :- status(o_1dae4fe2cf3e39a0b459,supported).
node(n378,refuted) :- status(o_1dae4fe2cf3e39a0b459,refuted).
node(n378,unknown) :- status(o_1dae4fe2cf3e39a0b459,unknown).
node(n377,supported) :- node(n371,supported), node(n372,supported), node(n378,supported), node(n373,supported).
node(n377,refuted) :- node(n371,refuted).
node(n377,refuted) :- node(n372,refuted).
node(n377,refuted) :- node(n378,refuted).
node(n377,refuted) :- node(n373,refuted).
node(n377,unknown) :- \+ node(n377,supported), \+ node(n377,refuted).
node(n374,refuted) :- node(n375,refuted), node(n377,refuted), node(n9,refuted).
node(n374,supported) :- node(n375,supported).
node(n374,supported) :- node(n377,supported).
node(n374,supported) :- node(n9,supported).
node(n374,unknown) :- \+ node(n374,supported), \+ node(n374,refuted).
verdict(c_873e074d92a715a8,supported) :- node(n374,supported).
query(verdict(c_873e074d92a715a8,supported)).
verdict(c_873e074d92a715a8,refuted) :- node(n374,refuted).
query(verdict(c_873e074d92a715a8,refuted)).
verdict(c_873e074d92a715a8,unknown) :- node(n374,unknown).
query(verdict(c_873e074d92a715a8,unknown)).
node(n381,supported) :- status(o_88aa1a732c8b38e524f8,supported).
node(n381,refuted) :- status(o_88aa1a732c8b38e524f8,refuted).
node(n381,unknown) :- status(o_88aa1a732c8b38e524f8,unknown).
node(n382,supported) :- status(o_1e3b57b0e0098ff42258,supported).
node(n382,refuted) :- status(o_1e3b57b0e0098ff42258,refuted).
node(n382,unknown) :- status(o_1e3b57b0e0098ff42258,unknown).
node(n383,supported) :- status(o_7366fa3c499d4cd9541b,supported).
node(n383,refuted) :- status(o_7366fa3c499d4cd9541b,refuted).
node(n383,unknown) :- status(o_7366fa3c499d4cd9541b,unknown).
node(n380,supported) :- node(n381,supported), node(n382,supported), node(n383,supported).
node(n380,refuted) :- node(n381,refuted).
node(n380,refuted) :- node(n382,refuted).
node(n380,refuted) :- node(n383,refuted).
node(n380,unknown) :- \+ node(n380,supported), \+ node(n380,refuted).
node(n385,supported) :- status(o_4b0fe690f14697082397,supported).
node(n385,refuted) :- status(o_4b0fe690f14697082397,refuted).
node(n385,unknown) :- status(o_4b0fe690f14697082397,unknown).
node(n386,supported) :- status(o_e0929e0eda515e65a20e,supported).
node(n386,refuted) :- status(o_e0929e0eda515e65a20e,refuted).
node(n386,unknown) :- status(o_e0929e0eda515e65a20e,unknown).
node(n387,supported) :- status(o_250acaa8aff4b6e1a7e1,supported).
node(n387,refuted) :- status(o_250acaa8aff4b6e1a7e1,refuted).
node(n387,unknown) :- status(o_250acaa8aff4b6e1a7e1,unknown).
node(n384,supported) :- node(n385,supported), node(n386,supported), node(n387,supported).
node(n384,refuted) :- node(n385,refuted).
node(n384,refuted) :- node(n386,refuted).
node(n384,refuted) :- node(n387,refuted).
node(n384,unknown) :- \+ node(n384,supported), \+ node(n384,refuted).
node(n379,refuted) :- node(n380,refuted), node(n384,refuted), node(n9,refuted).
node(n379,supported) :- node(n380,supported).
node(n379,supported) :- node(n384,supported).
node(n379,supported) :- node(n9,supported).
node(n379,unknown) :- \+ node(n379,supported), \+ node(n379,refuted).
verdict(c_477cbd93a6634883,supported) :- node(n379,supported).
query(verdict(c_477cbd93a6634883,supported)).
verdict(c_477cbd93a6634883,refuted) :- node(n379,refuted).
query(verdict(c_477cbd93a6634883,refuted)).
verdict(c_477cbd93a6634883,unknown) :- node(n379,unknown).
query(verdict(c_477cbd93a6634883,unknown)).
node(n390,supported) :- status(o_ce215c2b098f01fd3d9b,supported).
node(n390,refuted) :- status(o_ce215c2b098f01fd3d9b,refuted).
node(n390,unknown) :- status(o_ce215c2b098f01fd3d9b,unknown).
node(n389,supported) :- node(n381,supported), node(n382,supported), node(n390,supported), node(n383,supported).
node(n389,refuted) :- node(n381,refuted).
node(n389,refuted) :- node(n382,refuted).
node(n389,refuted) :- node(n390,refuted).
node(n389,refuted) :- node(n383,refuted).
node(n389,unknown) :- \+ node(n389,supported), \+ node(n389,refuted).
node(n392,supported) :- status(o_3ddbc48e0bd2ddc2f05e,supported).
node(n392,refuted) :- status(o_3ddbc48e0bd2ddc2f05e,refuted).
node(n392,unknown) :- status(o_3ddbc48e0bd2ddc2f05e,unknown).
node(n391,supported) :- node(n385,supported), node(n386,supported), node(n392,supported), node(n387,supported).
node(n391,refuted) :- node(n385,refuted).
node(n391,refuted) :- node(n386,refuted).
node(n391,refuted) :- node(n392,refuted).
node(n391,refuted) :- node(n387,refuted).
node(n391,unknown) :- \+ node(n391,supported), \+ node(n391,refuted).
node(n388,refuted) :- node(n389,refuted), node(n391,refuted), node(n9,refuted).
node(n388,supported) :- node(n389,supported).
node(n388,supported) :- node(n391,supported).
node(n388,supported) :- node(n9,supported).
node(n388,unknown) :- \+ node(n388,supported), \+ node(n388,refuted).
verdict(c_adde60a2055feaa7,supported) :- node(n388,supported).
query(verdict(c_adde60a2055feaa7,supported)).
verdict(c_adde60a2055feaa7,refuted) :- node(n388,refuted).
query(verdict(c_adde60a2055feaa7,refuted)).
verdict(c_adde60a2055feaa7,unknown) :- node(n388,unknown).
query(verdict(c_adde60a2055feaa7,unknown)).
node(n395,supported) :- status(o_5ddedab498303c96e83a,supported).
node(n395,refuted) :- status(o_5ddedab498303c96e83a,refuted).
node(n395,unknown) :- status(o_5ddedab498303c96e83a,unknown).
node(n396,supported) :- status(o_98db8628004b5feefd23,supported).
node(n396,refuted) :- status(o_98db8628004b5feefd23,refuted).
node(n396,unknown) :- status(o_98db8628004b5feefd23,unknown).
node(n397,supported) :- status(o_5cf58a7b7b034e427bcc,supported).
node(n397,refuted) :- status(o_5cf58a7b7b034e427bcc,refuted).
node(n397,unknown) :- status(o_5cf58a7b7b034e427bcc,unknown).
node(n394,supported) :- node(n395,supported), node(n396,supported), node(n397,supported).
node(n394,refuted) :- node(n395,refuted).
node(n394,refuted) :- node(n396,refuted).
node(n394,refuted) :- node(n397,refuted).
node(n394,unknown) :- \+ node(n394,supported), \+ node(n394,refuted).
node(n399,supported) :- status(o_1b90e36801a3fa33f344,supported).
node(n399,refuted) :- status(o_1b90e36801a3fa33f344,refuted).
node(n399,unknown) :- status(o_1b90e36801a3fa33f344,unknown).
node(n400,supported) :- status(o_203f97a458cb512201d8,supported).
node(n400,refuted) :- status(o_203f97a458cb512201d8,refuted).
node(n400,unknown) :- status(o_203f97a458cb512201d8,unknown).
node(n401,supported) :- status(o_9c8bfa8f1f3de7e45ace,supported).
node(n401,refuted) :- status(o_9c8bfa8f1f3de7e45ace,refuted).
node(n401,unknown) :- status(o_9c8bfa8f1f3de7e45ace,unknown).
node(n398,supported) :- node(n399,supported), node(n400,supported), node(n401,supported).
node(n398,refuted) :- node(n399,refuted).
node(n398,refuted) :- node(n400,refuted).
node(n398,refuted) :- node(n401,refuted).
node(n398,unknown) :- \+ node(n398,supported), \+ node(n398,refuted).
node(n393,refuted) :- node(n394,refuted), node(n398,refuted), node(n9,refuted).
node(n393,supported) :- node(n394,supported).
node(n393,supported) :- node(n398,supported).
node(n393,supported) :- node(n9,supported).
node(n393,unknown) :- \+ node(n393,supported), \+ node(n393,refuted).
verdict(c_e0fe8a36bc3577ea,supported) :- node(n393,supported).
query(verdict(c_e0fe8a36bc3577ea,supported)).
verdict(c_e0fe8a36bc3577ea,refuted) :- node(n393,refuted).
query(verdict(c_e0fe8a36bc3577ea,refuted)).
verdict(c_e0fe8a36bc3577ea,unknown) :- node(n393,unknown).
query(verdict(c_e0fe8a36bc3577ea,unknown)).
node(n404,supported) :- status(o_cece0fee3cf3a62f2296,supported).
node(n404,refuted) :- status(o_cece0fee3cf3a62f2296,refuted).
node(n404,unknown) :- status(o_cece0fee3cf3a62f2296,unknown).
node(n403,supported) :- node(n395,supported), node(n396,supported), node(n404,supported), node(n397,supported).
node(n403,refuted) :- node(n395,refuted).
node(n403,refuted) :- node(n396,refuted).
node(n403,refuted) :- node(n404,refuted).
node(n403,refuted) :- node(n397,refuted).
node(n403,unknown) :- \+ node(n403,supported), \+ node(n403,refuted).
node(n406,supported) :- status(o_8649ee2b8fb56fa387a2,supported).
node(n406,refuted) :- status(o_8649ee2b8fb56fa387a2,refuted).
node(n406,unknown) :- status(o_8649ee2b8fb56fa387a2,unknown).
node(n405,supported) :- node(n399,supported), node(n400,supported), node(n406,supported), node(n401,supported).
node(n405,refuted) :- node(n399,refuted).
node(n405,refuted) :- node(n400,refuted).
node(n405,refuted) :- node(n406,refuted).
node(n405,refuted) :- node(n401,refuted).
node(n405,unknown) :- \+ node(n405,supported), \+ node(n405,refuted).
node(n402,refuted) :- node(n403,refuted), node(n405,refuted), node(n9,refuted).
node(n402,supported) :- node(n403,supported).
node(n402,supported) :- node(n405,supported).
node(n402,supported) :- node(n9,supported).
node(n402,unknown) :- \+ node(n402,supported), \+ node(n402,refuted).
verdict(c_ac4b3d0d4181b7ca,supported) :- node(n402,supported).
query(verdict(c_ac4b3d0d4181b7ca,supported)).
verdict(c_ac4b3d0d4181b7ca,refuted) :- node(n402,refuted).
query(verdict(c_ac4b3d0d4181b7ca,refuted)).
verdict(c_ac4b3d0d4181b7ca,unknown) :- node(n402,unknown).
query(verdict(c_ac4b3d0d4181b7ca,unknown)).
node(n409,supported) :- status(o_c86a949de1ef2146f795,supported).
node(n409,refuted) :- status(o_c86a949de1ef2146f795,refuted).
node(n409,unknown) :- status(o_c86a949de1ef2146f795,unknown).
node(n410,supported) :- status(o_4ae4190636ea9cb0d1b3,supported).
node(n410,refuted) :- status(o_4ae4190636ea9cb0d1b3,refuted).
node(n410,unknown) :- status(o_4ae4190636ea9cb0d1b3,unknown).
node(n411,supported) :- status(o_db2140c2f8012c9113f2,supported).
node(n411,refuted) :- status(o_db2140c2f8012c9113f2,refuted).
node(n411,unknown) :- status(o_db2140c2f8012c9113f2,unknown).
node(n408,supported) :- node(n409,supported), node(n410,supported), node(n411,supported).
node(n408,refuted) :- node(n409,refuted).
node(n408,refuted) :- node(n410,refuted).
node(n408,refuted) :- node(n411,refuted).
node(n408,unknown) :- \+ node(n408,supported), \+ node(n408,refuted).
node(n413,supported) :- status(o_1a7d5a68c4ef49e9c738,supported).
node(n413,refuted) :- status(o_1a7d5a68c4ef49e9c738,refuted).
node(n413,unknown) :- status(o_1a7d5a68c4ef49e9c738,unknown).
node(n414,supported) :- status(o_b4c022dd4fee1cc39ce7,supported).
node(n414,refuted) :- status(o_b4c022dd4fee1cc39ce7,refuted).
node(n414,unknown) :- status(o_b4c022dd4fee1cc39ce7,unknown).
node(n415,supported) :- status(o_f10d0ca9ffd170f73344,supported).
node(n415,refuted) :- status(o_f10d0ca9ffd170f73344,refuted).
node(n415,unknown) :- status(o_f10d0ca9ffd170f73344,unknown).
node(n412,supported) :- node(n413,supported), node(n414,supported), node(n415,supported).
node(n412,refuted) :- node(n413,refuted).
node(n412,refuted) :- node(n414,refuted).
node(n412,refuted) :- node(n415,refuted).
node(n412,unknown) :- \+ node(n412,supported), \+ node(n412,refuted).
node(n407,refuted) :- node(n408,refuted), node(n412,refuted), node(n9,refuted).
node(n407,supported) :- node(n408,supported).
node(n407,supported) :- node(n412,supported).
node(n407,supported) :- node(n9,supported).
node(n407,unknown) :- \+ node(n407,supported), \+ node(n407,refuted).
verdict(c_880ec7046ea0c467,supported) :- node(n407,supported).
query(verdict(c_880ec7046ea0c467,supported)).
verdict(c_880ec7046ea0c467,refuted) :- node(n407,refuted).
query(verdict(c_880ec7046ea0c467,refuted)).
verdict(c_880ec7046ea0c467,unknown) :- node(n407,unknown).
query(verdict(c_880ec7046ea0c467,unknown)).
node(n418,supported) :- status(o_50208b41fa6cd1f34645,supported).
node(n418,refuted) :- status(o_50208b41fa6cd1f34645,refuted).
node(n418,unknown) :- status(o_50208b41fa6cd1f34645,unknown).
node(n417,supported) :- node(n409,supported), node(n410,supported), node(n418,supported), node(n411,supported).
node(n417,refuted) :- node(n409,refuted).
node(n417,refuted) :- node(n410,refuted).
node(n417,refuted) :- node(n418,refuted).
node(n417,refuted) :- node(n411,refuted).
node(n417,unknown) :- \+ node(n417,supported), \+ node(n417,refuted).
node(n420,supported) :- status(o_d898eb077e3a496f1a06,supported).
node(n420,refuted) :- status(o_d898eb077e3a496f1a06,refuted).
node(n420,unknown) :- status(o_d898eb077e3a496f1a06,unknown).
node(n419,supported) :- node(n413,supported), node(n414,supported), node(n420,supported), node(n415,supported).
node(n419,refuted) :- node(n413,refuted).
node(n419,refuted) :- node(n414,refuted).
node(n419,refuted) :- node(n420,refuted).
node(n419,refuted) :- node(n415,refuted).
node(n419,unknown) :- \+ node(n419,supported), \+ node(n419,refuted).
node(n416,refuted) :- node(n417,refuted), node(n419,refuted), node(n9,refuted).
node(n416,supported) :- node(n417,supported).
node(n416,supported) :- node(n419,supported).
node(n416,supported) :- node(n9,supported).
node(n416,unknown) :- \+ node(n416,supported), \+ node(n416,refuted).
verdict(c_1a02ed2837637795,supported) :- node(n416,supported).
query(verdict(c_1a02ed2837637795,supported)).
verdict(c_1a02ed2837637795,refuted) :- node(n416,refuted).
query(verdict(c_1a02ed2837637795,refuted)).
verdict(c_1a02ed2837637795,unknown) :- node(n416,unknown).
query(verdict(c_1a02ed2837637795,unknown)).
node(n423,supported) :- status(o_df4f7af0f7119c6cd395,supported).
node(n423,refuted) :- status(o_df4f7af0f7119c6cd395,refuted).
node(n423,unknown) :- status(o_df4f7af0f7119c6cd395,unknown).
node(n424,supported) :- status(o_399e75495498d0ab2deb,supported).
node(n424,refuted) :- status(o_399e75495498d0ab2deb,refuted).
node(n424,unknown) :- status(o_399e75495498d0ab2deb,unknown).
node(n425,supported) :- status(o_297e59f156505592a4b0,supported).
node(n425,refuted) :- status(o_297e59f156505592a4b0,refuted).
node(n425,unknown) :- status(o_297e59f156505592a4b0,unknown).
node(n422,supported) :- node(n423,supported), node(n424,supported), node(n425,supported).
node(n422,refuted) :- node(n423,refuted).
node(n422,refuted) :- node(n424,refuted).
node(n422,refuted) :- node(n425,refuted).
node(n422,unknown) :- \+ node(n422,supported), \+ node(n422,refuted).
node(n427,supported) :- status(o_7dadf53904ba4c0f227a,supported).
node(n427,refuted) :- status(o_7dadf53904ba4c0f227a,refuted).
node(n427,unknown) :- status(o_7dadf53904ba4c0f227a,unknown).
node(n428,supported) :- status(o_fb4f999100b6d242ae1c,supported).
node(n428,refuted) :- status(o_fb4f999100b6d242ae1c,refuted).
node(n428,unknown) :- status(o_fb4f999100b6d242ae1c,unknown).
node(n429,supported) :- status(o_2f8672e418d2c4cb048a,supported).
node(n429,refuted) :- status(o_2f8672e418d2c4cb048a,refuted).
node(n429,unknown) :- status(o_2f8672e418d2c4cb048a,unknown).
node(n426,supported) :- node(n427,supported), node(n428,supported), node(n429,supported).
node(n426,refuted) :- node(n427,refuted).
node(n426,refuted) :- node(n428,refuted).
node(n426,refuted) :- node(n429,refuted).
node(n426,unknown) :- \+ node(n426,supported), \+ node(n426,refuted).
node(n421,refuted) :- node(n422,refuted), node(n426,refuted), node(n9,refuted).
node(n421,supported) :- node(n422,supported).
node(n421,supported) :- node(n426,supported).
node(n421,supported) :- node(n9,supported).
node(n421,unknown) :- \+ node(n421,supported), \+ node(n421,refuted).
verdict(c_82295b80b52f6f9e,supported) :- node(n421,supported).
query(verdict(c_82295b80b52f6f9e,supported)).
verdict(c_82295b80b52f6f9e,refuted) :- node(n421,refuted).
query(verdict(c_82295b80b52f6f9e,refuted)).
verdict(c_82295b80b52f6f9e,unknown) :- node(n421,unknown).
query(verdict(c_82295b80b52f6f9e,unknown)).
node(n432,supported) :- status(o_ee8a25ae07d4cb7d488c,supported).
node(n432,refuted) :- status(o_ee8a25ae07d4cb7d488c,refuted).
node(n432,unknown) :- status(o_ee8a25ae07d4cb7d488c,unknown).
node(n431,supported) :- node(n423,supported), node(n424,supported), node(n432,supported), node(n425,supported).
node(n431,refuted) :- node(n423,refuted).
node(n431,refuted) :- node(n424,refuted).
node(n431,refuted) :- node(n432,refuted).
node(n431,refuted) :- node(n425,refuted).
node(n431,unknown) :- \+ node(n431,supported), \+ node(n431,refuted).
node(n434,supported) :- status(o_6d34ed7be83f472c3061,supported).
node(n434,refuted) :- status(o_6d34ed7be83f472c3061,refuted).
node(n434,unknown) :- status(o_6d34ed7be83f472c3061,unknown).
node(n433,supported) :- node(n427,supported), node(n428,supported), node(n434,supported), node(n429,supported).
node(n433,refuted) :- node(n427,refuted).
node(n433,refuted) :- node(n428,refuted).
node(n433,refuted) :- node(n434,refuted).
node(n433,refuted) :- node(n429,refuted).
node(n433,unknown) :- \+ node(n433,supported), \+ node(n433,refuted).
node(n430,refuted) :- node(n431,refuted), node(n433,refuted), node(n9,refuted).
node(n430,supported) :- node(n431,supported).
node(n430,supported) :- node(n433,supported).
node(n430,supported) :- node(n9,supported).
node(n430,unknown) :- \+ node(n430,supported), \+ node(n430,refuted).
verdict(c_a8ef21e3ee90f71e,supported) :- node(n430,supported).
query(verdict(c_a8ef21e3ee90f71e,supported)).
verdict(c_a8ef21e3ee90f71e,refuted) :- node(n430,refuted).
query(verdict(c_a8ef21e3ee90f71e,refuted)).
verdict(c_a8ef21e3ee90f71e,unknown) :- node(n430,unknown).
query(verdict(c_a8ef21e3ee90f71e,unknown)).
node(n437,supported) :- status(o_803fd27cc8fb184ed1f0,supported).
node(n437,refuted) :- status(o_803fd27cc8fb184ed1f0,refuted).
node(n437,unknown) :- status(o_803fd27cc8fb184ed1f0,unknown).
node(n438,supported) :- status(o_86e5d30c3525e48daa85,supported).
node(n438,refuted) :- status(o_86e5d30c3525e48daa85,refuted).
node(n438,unknown) :- status(o_86e5d30c3525e48daa85,unknown).
node(n439,supported) :- status(o_122c44f023aaa66fc623,supported).
node(n439,refuted) :- status(o_122c44f023aaa66fc623,refuted).
node(n439,unknown) :- status(o_122c44f023aaa66fc623,unknown).
node(n436,supported) :- node(n437,supported), node(n438,supported), node(n439,supported).
node(n436,refuted) :- node(n437,refuted).
node(n436,refuted) :- node(n438,refuted).
node(n436,refuted) :- node(n439,refuted).
node(n436,unknown) :- \+ node(n436,supported), \+ node(n436,refuted).
node(n441,supported) :- status(o_73951d5b9614f58fe5c3,supported).
node(n441,refuted) :- status(o_73951d5b9614f58fe5c3,refuted).
node(n441,unknown) :- status(o_73951d5b9614f58fe5c3,unknown).
node(n442,supported) :- status(o_502227769b166b7bc26e,supported).
node(n442,refuted) :- status(o_502227769b166b7bc26e,refuted).
node(n442,unknown) :- status(o_502227769b166b7bc26e,unknown).
node(n443,supported) :- status(o_5abe132dd12d7436d9ff,supported).
node(n443,refuted) :- status(o_5abe132dd12d7436d9ff,refuted).
node(n443,unknown) :- status(o_5abe132dd12d7436d9ff,unknown).
node(n440,supported) :- node(n441,supported), node(n442,supported), node(n443,supported).
node(n440,refuted) :- node(n441,refuted).
node(n440,refuted) :- node(n442,refuted).
node(n440,refuted) :- node(n443,refuted).
node(n440,unknown) :- \+ node(n440,supported), \+ node(n440,refuted).
node(n435,refuted) :- node(n436,refuted), node(n440,refuted), node(n9,refuted).
node(n435,supported) :- node(n436,supported).
node(n435,supported) :- node(n440,supported).
node(n435,supported) :- node(n9,supported).
node(n435,unknown) :- \+ node(n435,supported), \+ node(n435,refuted).
verdict(c_5c72ff351becc5e2,supported) :- node(n435,supported).
query(verdict(c_5c72ff351becc5e2,supported)).
verdict(c_5c72ff351becc5e2,refuted) :- node(n435,refuted).
query(verdict(c_5c72ff351becc5e2,refuted)).
verdict(c_5c72ff351becc5e2,unknown) :- node(n435,unknown).
query(verdict(c_5c72ff351becc5e2,unknown)).
node(n446,supported) :- status(o_dea282153a9f8aa4c074,supported).
node(n446,refuted) :- status(o_dea282153a9f8aa4c074,refuted).
node(n446,unknown) :- status(o_dea282153a9f8aa4c074,unknown).
node(n445,supported) :- node(n437,supported), node(n438,supported), node(n446,supported), node(n439,supported).
node(n445,refuted) :- node(n437,refuted).
node(n445,refuted) :- node(n438,refuted).
node(n445,refuted) :- node(n446,refuted).
node(n445,refuted) :- node(n439,refuted).
node(n445,unknown) :- \+ node(n445,supported), \+ node(n445,refuted).
node(n448,supported) :- status(o_be13be3d4c6205f52669,supported).
node(n448,refuted) :- status(o_be13be3d4c6205f52669,refuted).
node(n448,unknown) :- status(o_be13be3d4c6205f52669,unknown).
node(n447,supported) :- node(n441,supported), node(n442,supported), node(n448,supported), node(n443,supported).
node(n447,refuted) :- node(n441,refuted).
node(n447,refuted) :- node(n442,refuted).
node(n447,refuted) :- node(n448,refuted).
node(n447,refuted) :- node(n443,refuted).
node(n447,unknown) :- \+ node(n447,supported), \+ node(n447,refuted).
node(n444,refuted) :- node(n445,refuted), node(n447,refuted), node(n9,refuted).
node(n444,supported) :- node(n445,supported).
node(n444,supported) :- node(n447,supported).
node(n444,supported) :- node(n9,supported).
node(n444,unknown) :- \+ node(n444,supported), \+ node(n444,refuted).
verdict(c_baa62df8c57102f9,supported) :- node(n444,supported).
query(verdict(c_baa62df8c57102f9,supported)).
verdict(c_baa62df8c57102f9,refuted) :- node(n444,refuted).
query(verdict(c_baa62df8c57102f9,refuted)).
verdict(c_baa62df8c57102f9,unknown) :- node(n444,unknown).
query(verdict(c_baa62df8c57102f9,unknown)).
node(n451,supported) :- status(o_74607d141de396bc1302,supported).
node(n451,refuted) :- status(o_74607d141de396bc1302,refuted).
node(n451,unknown) :- status(o_74607d141de396bc1302,unknown).
node(n452,supported) :- status(o_847be245a2f62b39c3e8,supported).
node(n452,refuted) :- status(o_847be245a2f62b39c3e8,refuted).
node(n452,unknown) :- status(o_847be245a2f62b39c3e8,unknown).
node(n453,supported) :- status(o_2c392a06444f4cd5bd26,supported).
node(n453,refuted) :- status(o_2c392a06444f4cd5bd26,refuted).
node(n453,unknown) :- status(o_2c392a06444f4cd5bd26,unknown).
node(n450,supported) :- node(n451,supported), node(n452,supported), node(n453,supported).
node(n450,refuted) :- node(n451,refuted).
node(n450,refuted) :- node(n452,refuted).
node(n450,refuted) :- node(n453,refuted).
node(n450,unknown) :- \+ node(n450,supported), \+ node(n450,refuted).
node(n455,supported) :- status(o_cb3f44454338804a17bb,supported).
node(n455,refuted) :- status(o_cb3f44454338804a17bb,refuted).
node(n455,unknown) :- status(o_cb3f44454338804a17bb,unknown).
node(n456,supported) :- status(o_f222a7cb466a0384cde9,supported).
node(n456,refuted) :- status(o_f222a7cb466a0384cde9,refuted).
node(n456,unknown) :- status(o_f222a7cb466a0384cde9,unknown).
node(n457,supported) :- status(o_1ab9ae7073de465c322d,supported).
node(n457,refuted) :- status(o_1ab9ae7073de465c322d,refuted).
node(n457,unknown) :- status(o_1ab9ae7073de465c322d,unknown).
node(n454,supported) :- node(n455,supported), node(n456,supported), node(n457,supported).
node(n454,refuted) :- node(n455,refuted).
node(n454,refuted) :- node(n456,refuted).
node(n454,refuted) :- node(n457,refuted).
node(n454,unknown) :- \+ node(n454,supported), \+ node(n454,refuted).
node(n449,refuted) :- node(n450,refuted), node(n454,refuted), node(n9,refuted).
node(n449,supported) :- node(n450,supported).
node(n449,supported) :- node(n454,supported).
node(n449,supported) :- node(n9,supported).
node(n449,unknown) :- \+ node(n449,supported), \+ node(n449,refuted).
verdict(c_077e9982a16d9e0d,supported) :- node(n449,supported).
query(verdict(c_077e9982a16d9e0d,supported)).
verdict(c_077e9982a16d9e0d,refuted) :- node(n449,refuted).
query(verdict(c_077e9982a16d9e0d,refuted)).
verdict(c_077e9982a16d9e0d,unknown) :- node(n449,unknown).
query(verdict(c_077e9982a16d9e0d,unknown)).
node(n460,supported) :- status(o_396fa5905bb77d9558a3,supported).
node(n460,refuted) :- status(o_396fa5905bb77d9558a3,refuted).
node(n460,unknown) :- status(o_396fa5905bb77d9558a3,unknown).
node(n459,supported) :- node(n451,supported), node(n452,supported), node(n460,supported), node(n453,supported).
node(n459,refuted) :- node(n451,refuted).
node(n459,refuted) :- node(n452,refuted).
node(n459,refuted) :- node(n460,refuted).
node(n459,refuted) :- node(n453,refuted).
node(n459,unknown) :- \+ node(n459,supported), \+ node(n459,refuted).
node(n462,supported) :- status(o_c6913096ba00a1d58047,supported).
node(n462,refuted) :- status(o_c6913096ba00a1d58047,refuted).
node(n462,unknown) :- status(o_c6913096ba00a1d58047,unknown).
node(n461,supported) :- node(n455,supported), node(n456,supported), node(n462,supported), node(n457,supported).
node(n461,refuted) :- node(n455,refuted).
node(n461,refuted) :- node(n456,refuted).
node(n461,refuted) :- node(n462,refuted).
node(n461,refuted) :- node(n457,refuted).
node(n461,unknown) :- \+ node(n461,supported), \+ node(n461,refuted).
node(n458,refuted) :- node(n459,refuted), node(n461,refuted), node(n9,refuted).
node(n458,supported) :- node(n459,supported).
node(n458,supported) :- node(n461,supported).
node(n458,supported) :- node(n9,supported).
node(n458,unknown) :- \+ node(n458,supported), \+ node(n458,refuted).
verdict(c_ba8adb18b5bf5c46,supported) :- node(n458,supported).
query(verdict(c_ba8adb18b5bf5c46,supported)).
verdict(c_ba8adb18b5bf5c46,refuted) :- node(n458,refuted).
query(verdict(c_ba8adb18b5bf5c46,refuted)).
verdict(c_ba8adb18b5bf5c46,unknown) :- node(n458,unknown).
query(verdict(c_ba8adb18b5bf5c46,unknown)).
node(n465,supported) :- status(o_c88da2b1f1182dbef06d,supported).
node(n465,refuted) :- status(o_c88da2b1f1182dbef06d,refuted).
node(n465,unknown) :- status(o_c88da2b1f1182dbef06d,unknown).
node(n466,supported) :- status(o_4601243a45bff3aa98fe,supported).
node(n466,refuted) :- status(o_4601243a45bff3aa98fe,refuted).
node(n466,unknown) :- status(o_4601243a45bff3aa98fe,unknown).
node(n467,supported) :- status(o_7dc163d16bcdb473de4d,supported).
node(n467,refuted) :- status(o_7dc163d16bcdb473de4d,refuted).
node(n467,unknown) :- status(o_7dc163d16bcdb473de4d,unknown).
node(n464,supported) :- node(n465,supported), node(n466,supported), node(n467,supported).
node(n464,refuted) :- node(n465,refuted).
node(n464,refuted) :- node(n466,refuted).
node(n464,refuted) :- node(n467,refuted).
node(n464,unknown) :- \+ node(n464,supported), \+ node(n464,refuted).
node(n469,supported) :- status(o_eaef4d90d09c60a2e8a8,supported).
node(n469,refuted) :- status(o_eaef4d90d09c60a2e8a8,refuted).
node(n469,unknown) :- status(o_eaef4d90d09c60a2e8a8,unknown).
node(n470,supported) :- status(o_d6f08f7523a2888ac57e,supported).
node(n470,refuted) :- status(o_d6f08f7523a2888ac57e,refuted).
node(n470,unknown) :- status(o_d6f08f7523a2888ac57e,unknown).
node(n471,supported) :- status(o_2725fc701c8fff4a9539,supported).
node(n471,refuted) :- status(o_2725fc701c8fff4a9539,refuted).
node(n471,unknown) :- status(o_2725fc701c8fff4a9539,unknown).
node(n468,supported) :- node(n469,supported), node(n470,supported), node(n471,supported).
node(n468,refuted) :- node(n469,refuted).
node(n468,refuted) :- node(n470,refuted).
node(n468,refuted) :- node(n471,refuted).
node(n468,unknown) :- \+ node(n468,supported), \+ node(n468,refuted).
node(n463,refuted) :- node(n464,refuted), node(n468,refuted), node(n9,refuted).
node(n463,supported) :- node(n464,supported).
node(n463,supported) :- node(n468,supported).
node(n463,supported) :- node(n9,supported).
node(n463,unknown) :- \+ node(n463,supported), \+ node(n463,refuted).
verdict(c_72f57073001c7139,supported) :- node(n463,supported).
query(verdict(c_72f57073001c7139,supported)).
verdict(c_72f57073001c7139,refuted) :- node(n463,refuted).
query(verdict(c_72f57073001c7139,refuted)).
verdict(c_72f57073001c7139,unknown) :- node(n463,unknown).
query(verdict(c_72f57073001c7139,unknown)).
node(n474,supported) :- status(o_1b6e6b08c568ed054f01,supported).
node(n474,refuted) :- status(o_1b6e6b08c568ed054f01,refuted).
node(n474,unknown) :- status(o_1b6e6b08c568ed054f01,unknown).
node(n473,supported) :- node(n465,supported), node(n466,supported), node(n474,supported), node(n467,supported).
node(n473,refuted) :- node(n465,refuted).
node(n473,refuted) :- node(n466,refuted).
node(n473,refuted) :- node(n474,refuted).
node(n473,refuted) :- node(n467,refuted).
node(n473,unknown) :- \+ node(n473,supported), \+ node(n473,refuted).
node(n476,supported) :- status(o_bd99fe4091ca4d2e478d,supported).
node(n476,refuted) :- status(o_bd99fe4091ca4d2e478d,refuted).
node(n476,unknown) :- status(o_bd99fe4091ca4d2e478d,unknown).
node(n475,supported) :- node(n469,supported), node(n470,supported), node(n476,supported), node(n471,supported).
node(n475,refuted) :- node(n469,refuted).
node(n475,refuted) :- node(n470,refuted).
node(n475,refuted) :- node(n476,refuted).
node(n475,refuted) :- node(n471,refuted).
node(n475,unknown) :- \+ node(n475,supported), \+ node(n475,refuted).
node(n472,refuted) :- node(n473,refuted), node(n475,refuted), node(n9,refuted).
node(n472,supported) :- node(n473,supported).
node(n472,supported) :- node(n475,supported).
node(n472,supported) :- node(n9,supported).
node(n472,unknown) :- \+ node(n472,supported), \+ node(n472,refuted).
verdict(c_cc72de8426c1f5a7,supported) :- node(n472,supported).
query(verdict(c_cc72de8426c1f5a7,supported)).
verdict(c_cc72de8426c1f5a7,refuted) :- node(n472,refuted).
query(verdict(c_cc72de8426c1f5a7,refuted)).
verdict(c_cc72de8426c1f5a7,unknown) :- node(n472,unknown).
query(verdict(c_cc72de8426c1f5a7,unknown)).
node(n479,supported) :- status(o_3ebfdaacc153b1aec974,supported).
node(n479,refuted) :- status(o_3ebfdaacc153b1aec974,refuted).
node(n479,unknown) :- status(o_3ebfdaacc153b1aec974,unknown).
node(n480,supported) :- status(o_373177f9ba14320bdde9,supported).
node(n480,refuted) :- status(o_373177f9ba14320bdde9,refuted).
node(n480,unknown) :- status(o_373177f9ba14320bdde9,unknown).
node(n481,supported) :- status(o_ccc3257e5f93554db0b1,supported).
node(n481,refuted) :- status(o_ccc3257e5f93554db0b1,refuted).
node(n481,unknown) :- status(o_ccc3257e5f93554db0b1,unknown).
node(n478,supported) :- node(n479,supported), node(n480,supported), node(n481,supported).
node(n478,refuted) :- node(n479,refuted).
node(n478,refuted) :- node(n480,refuted).
node(n478,refuted) :- node(n481,refuted).
node(n478,unknown) :- \+ node(n478,supported), \+ node(n478,refuted).
node(n483,supported) :- status(o_fd8b24f518d8ddb9e11e,supported).
node(n483,refuted) :- status(o_fd8b24f518d8ddb9e11e,refuted).
node(n483,unknown) :- status(o_fd8b24f518d8ddb9e11e,unknown).
node(n484,supported) :- status(o_184dfd465f9165e3b445,supported).
node(n484,refuted) :- status(o_184dfd465f9165e3b445,refuted).
node(n484,unknown) :- status(o_184dfd465f9165e3b445,unknown).
node(n485,supported) :- status(o_5ba37f7ae93210d01b8d,supported).
node(n485,refuted) :- status(o_5ba37f7ae93210d01b8d,refuted).
node(n485,unknown) :- status(o_5ba37f7ae93210d01b8d,unknown).
node(n482,supported) :- node(n483,supported), node(n484,supported), node(n485,supported).
node(n482,refuted) :- node(n483,refuted).
node(n482,refuted) :- node(n484,refuted).
node(n482,refuted) :- node(n485,refuted).
node(n482,unknown) :- \+ node(n482,supported), \+ node(n482,refuted).
node(n477,refuted) :- node(n478,refuted), node(n482,refuted), node(n9,refuted).
node(n477,supported) :- node(n478,supported).
node(n477,supported) :- node(n482,supported).
node(n477,supported) :- node(n9,supported).
node(n477,unknown) :- \+ node(n477,supported), \+ node(n477,refuted).
verdict(c_52aef3d653cdce86,supported) :- node(n477,supported).
query(verdict(c_52aef3d653cdce86,supported)).
verdict(c_52aef3d653cdce86,refuted) :- node(n477,refuted).
query(verdict(c_52aef3d653cdce86,refuted)).
verdict(c_52aef3d653cdce86,unknown) :- node(n477,unknown).
query(verdict(c_52aef3d653cdce86,unknown)).
node(n488,supported) :- status(o_c1a0ea0a90ddc374bee9,supported).
node(n488,refuted) :- status(o_c1a0ea0a90ddc374bee9,refuted).
node(n488,unknown) :- status(o_c1a0ea0a90ddc374bee9,unknown).
node(n487,supported) :- node(n479,supported), node(n480,supported), node(n488,supported), node(n481,supported).
node(n487,refuted) :- node(n479,refuted).
node(n487,refuted) :- node(n480,refuted).
node(n487,refuted) :- node(n488,refuted).
node(n487,refuted) :- node(n481,refuted).
node(n487,unknown) :- \+ node(n487,supported), \+ node(n487,refuted).
node(n490,supported) :- status(o_2922fca11dca06c5894e,supported).
node(n490,refuted) :- status(o_2922fca11dca06c5894e,refuted).
node(n490,unknown) :- status(o_2922fca11dca06c5894e,unknown).
node(n489,supported) :- node(n483,supported), node(n484,supported), node(n490,supported), node(n485,supported).
node(n489,refuted) :- node(n483,refuted).
node(n489,refuted) :- node(n484,refuted).
node(n489,refuted) :- node(n490,refuted).
node(n489,refuted) :- node(n485,refuted).
node(n489,unknown) :- \+ node(n489,supported), \+ node(n489,refuted).
node(n486,refuted) :- node(n487,refuted), node(n489,refuted), node(n9,refuted).
node(n486,supported) :- node(n487,supported).
node(n486,supported) :- node(n489,supported).
node(n486,supported) :- node(n9,supported).
node(n486,unknown) :- \+ node(n486,supported), \+ node(n486,refuted).
verdict(c_d7bb67071992fd45,supported) :- node(n486,supported).
query(verdict(c_d7bb67071992fd45,supported)).
verdict(c_d7bb67071992fd45,refuted) :- node(n486,refuted).
query(verdict(c_d7bb67071992fd45,refuted)).
verdict(c_d7bb67071992fd45,unknown) :- node(n486,unknown).
query(verdict(c_d7bb67071992fd45,unknown)).
node(n493,supported) :- status(o_f28d10b312bf0d03a0c2,supported).
node(n493,refuted) :- status(o_f28d10b312bf0d03a0c2,refuted).
node(n493,unknown) :- status(o_f28d10b312bf0d03a0c2,unknown).
node(n494,supported) :- status(o_7027cfe40588b5027439,supported).
node(n494,refuted) :- status(o_7027cfe40588b5027439,refuted).
node(n494,unknown) :- status(o_7027cfe40588b5027439,unknown).
node(n495,supported) :- status(o_7e4726a29e848a714e81,supported).
node(n495,refuted) :- status(o_7e4726a29e848a714e81,refuted).
node(n495,unknown) :- status(o_7e4726a29e848a714e81,unknown).
node(n492,supported) :- node(n493,supported), node(n494,supported), node(n495,supported).
node(n492,refuted) :- node(n493,refuted).
node(n492,refuted) :- node(n494,refuted).
node(n492,refuted) :- node(n495,refuted).
node(n492,unknown) :- \+ node(n492,supported), \+ node(n492,refuted).
node(n497,supported) :- status(o_1c8b6397265f9bbacd19,supported).
node(n497,refuted) :- status(o_1c8b6397265f9bbacd19,refuted).
node(n497,unknown) :- status(o_1c8b6397265f9bbacd19,unknown).
node(n498,supported) :- status(o_81e23bef391605b03342,supported).
node(n498,refuted) :- status(o_81e23bef391605b03342,refuted).
node(n498,unknown) :- status(o_81e23bef391605b03342,unknown).
node(n499,supported) :- status(o_ae073b7b1c01be206191,supported).
node(n499,refuted) :- status(o_ae073b7b1c01be206191,refuted).
node(n499,unknown) :- status(o_ae073b7b1c01be206191,unknown).
node(n496,supported) :- node(n497,supported), node(n498,supported), node(n499,supported).
node(n496,refuted) :- node(n497,refuted).
node(n496,refuted) :- node(n498,refuted).
node(n496,refuted) :- node(n499,refuted).
node(n496,unknown) :- \+ node(n496,supported), \+ node(n496,refuted).
node(n491,refuted) :- node(n492,refuted), node(n496,refuted), node(n9,refuted).
node(n491,supported) :- node(n492,supported).
node(n491,supported) :- node(n496,supported).
node(n491,supported) :- node(n9,supported).
node(n491,unknown) :- \+ node(n491,supported), \+ node(n491,refuted).
verdict(c_3c1cd5ac32b7eec1,supported) :- node(n491,supported).
query(verdict(c_3c1cd5ac32b7eec1,supported)).
verdict(c_3c1cd5ac32b7eec1,refuted) :- node(n491,refuted).
query(verdict(c_3c1cd5ac32b7eec1,refuted)).
verdict(c_3c1cd5ac32b7eec1,unknown) :- node(n491,unknown).
query(verdict(c_3c1cd5ac32b7eec1,unknown)).
node(n502,supported) :- status(o_2110913504ae3a6d717f,supported).
node(n502,refuted) :- status(o_2110913504ae3a6d717f,refuted).
node(n502,unknown) :- status(o_2110913504ae3a6d717f,unknown).
node(n501,supported) :- node(n493,supported), node(n494,supported), node(n502,supported), node(n495,supported).
node(n501,refuted) :- node(n493,refuted).
node(n501,refuted) :- node(n494,refuted).
node(n501,refuted) :- node(n502,refuted).
node(n501,refuted) :- node(n495,refuted).
node(n501,unknown) :- \+ node(n501,supported), \+ node(n501,refuted).
node(n504,supported) :- status(o_a9ddb306244e1e07f205,supported).
node(n504,refuted) :- status(o_a9ddb306244e1e07f205,refuted).
node(n504,unknown) :- status(o_a9ddb306244e1e07f205,unknown).
node(n503,supported) :- node(n497,supported), node(n498,supported), node(n504,supported), node(n499,supported).
node(n503,refuted) :- node(n497,refuted).
node(n503,refuted) :- node(n498,refuted).
node(n503,refuted) :- node(n504,refuted).
node(n503,refuted) :- node(n499,refuted).
node(n503,unknown) :- \+ node(n503,supported), \+ node(n503,refuted).
node(n500,refuted) :- node(n501,refuted), node(n503,refuted), node(n9,refuted).
node(n500,supported) :- node(n501,supported).
node(n500,supported) :- node(n503,supported).
node(n500,supported) :- node(n9,supported).
node(n500,unknown) :- \+ node(n500,supported), \+ node(n500,refuted).
verdict(c_f29c89c909d013ce,supported) :- node(n500,supported).
query(verdict(c_f29c89c909d013ce,supported)).
verdict(c_f29c89c909d013ce,refuted) :- node(n500,refuted).
query(verdict(c_f29c89c909d013ce,refuted)).
verdict(c_f29c89c909d013ce,unknown) :- node(n500,unknown).
query(verdict(c_f29c89c909d013ce,unknown)).
node(n507,supported) :- status(o_ad515c2cab6f8e2eba96,supported).
node(n507,refuted) :- status(o_ad515c2cab6f8e2eba96,refuted).
node(n507,unknown) :- status(o_ad515c2cab6f8e2eba96,unknown).
node(n508,supported) :- status(o_2d96fc15d0de6148efc9,supported).
node(n508,refuted) :- status(o_2d96fc15d0de6148efc9,refuted).
node(n508,unknown) :- status(o_2d96fc15d0de6148efc9,unknown).
node(n509,supported) :- status(o_44618462cec09485859f,supported).
node(n509,refuted) :- status(o_44618462cec09485859f,refuted).
node(n509,unknown) :- status(o_44618462cec09485859f,unknown).
node(n506,supported) :- node(n507,supported), node(n508,supported), node(n509,supported).
node(n506,refuted) :- node(n507,refuted).
node(n506,refuted) :- node(n508,refuted).
node(n506,refuted) :- node(n509,refuted).
node(n506,unknown) :- \+ node(n506,supported), \+ node(n506,refuted).
node(n505,refuted) :- node(n506,refuted), node(n9,refuted).
node(n505,supported) :- node(n506,supported).
node(n505,supported) :- node(n9,supported).
node(n505,unknown) :- \+ node(n505,supported), \+ node(n505,refuted).
verdict(c_ffdf8a87b74aaafb,supported) :- node(n505,supported).
query(verdict(c_ffdf8a87b74aaafb,supported)).
verdict(c_ffdf8a87b74aaafb,refuted) :- node(n505,refuted).
query(verdict(c_ffdf8a87b74aaafb,refuted)).
verdict(c_ffdf8a87b74aaafb,unknown) :- node(n505,unknown).
query(verdict(c_ffdf8a87b74aaafb,unknown)).
node(n512,supported) :- status(o_5ba8da655c850e0036e8,supported).
node(n512,refuted) :- status(o_5ba8da655c850e0036e8,refuted).
node(n512,unknown) :- status(o_5ba8da655c850e0036e8,unknown).
node(n511,supported) :- node(n507,supported), node(n508,supported), node(n512,supported), node(n509,supported).
node(n511,refuted) :- node(n507,refuted).
node(n511,refuted) :- node(n508,refuted).
node(n511,refuted) :- node(n512,refuted).
node(n511,refuted) :- node(n509,refuted).
node(n511,unknown) :- \+ node(n511,supported), \+ node(n511,refuted).
node(n510,refuted) :- node(n511,refuted), node(n9,refuted).
node(n510,supported) :- node(n511,supported).
node(n510,supported) :- node(n9,supported).
node(n510,unknown) :- \+ node(n510,supported), \+ node(n510,refuted).
verdict(c_6485e19df482c56d,supported) :- node(n510,supported).
query(verdict(c_6485e19df482c56d,supported)).
verdict(c_6485e19df482c56d,refuted) :- node(n510,refuted).
query(verdict(c_6485e19df482c56d,refuted)).
verdict(c_6485e19df482c56d,unknown) :- node(n510,unknown).
query(verdict(c_6485e19df482c56d,unknown)).
node(n515,supported) :- status(o_b4ddb54b84bf9eb67316,supported).
node(n515,refuted) :- status(o_b4ddb54b84bf9eb67316,refuted).
node(n515,unknown) :- status(o_b4ddb54b84bf9eb67316,unknown).
node(n516,supported) :- status(o_e0013a9f79fe6c730b3c,supported).
node(n516,refuted) :- status(o_e0013a9f79fe6c730b3c,refuted).
node(n516,unknown) :- status(o_e0013a9f79fe6c730b3c,unknown).
node(n517,supported) :- status(o_e161ebab0d16e729bd2e,supported).
node(n517,refuted) :- status(o_e161ebab0d16e729bd2e,refuted).
node(n517,unknown) :- status(o_e161ebab0d16e729bd2e,unknown).
node(n514,supported) :- node(n515,supported), node(n516,supported), node(n517,supported).
node(n514,refuted) :- node(n515,refuted).
node(n514,refuted) :- node(n516,refuted).
node(n514,refuted) :- node(n517,refuted).
node(n514,unknown) :- \+ node(n514,supported), \+ node(n514,refuted).
node(n513,refuted) :- node(n514,refuted), node(n9,refuted).
node(n513,supported) :- node(n514,supported).
node(n513,supported) :- node(n9,supported).
node(n513,unknown) :- \+ node(n513,supported), \+ node(n513,refuted).
verdict(c_3f46202dc4f1623e,supported) :- node(n513,supported).
query(verdict(c_3f46202dc4f1623e,supported)).
verdict(c_3f46202dc4f1623e,refuted) :- node(n513,refuted).
query(verdict(c_3f46202dc4f1623e,refuted)).
verdict(c_3f46202dc4f1623e,unknown) :- node(n513,unknown).
query(verdict(c_3f46202dc4f1623e,unknown)).
node(n520,supported) :- status(o_c9f49e13133c7c6b7242,supported).
node(n520,refuted) :- status(o_c9f49e13133c7c6b7242,refuted).
node(n520,unknown) :- status(o_c9f49e13133c7c6b7242,unknown).
node(n519,supported) :- node(n515,supported), node(n516,supported), node(n520,supported), node(n517,supported).
node(n519,refuted) :- node(n515,refuted).
node(n519,refuted) :- node(n516,refuted).
node(n519,refuted) :- node(n520,refuted).
node(n519,refuted) :- node(n517,refuted).
node(n519,unknown) :- \+ node(n519,supported), \+ node(n519,refuted).
node(n518,refuted) :- node(n519,refuted), node(n9,refuted).
node(n518,supported) :- node(n519,supported).
node(n518,supported) :- node(n9,supported).
node(n518,unknown) :- \+ node(n518,supported), \+ node(n518,refuted).
verdict(c_93c906dab97089b4,supported) :- node(n518,supported).
query(verdict(c_93c906dab97089b4,supported)).
verdict(c_93c906dab97089b4,refuted) :- node(n518,refuted).
query(verdict(c_93c906dab97089b4,refuted)).
verdict(c_93c906dab97089b4,unknown) :- node(n518,unknown).
query(verdict(c_93c906dab97089b4,unknown)).
node(n523,supported) :- status(o_15cbdee1adc3cc0bb827,supported).
node(n523,refuted) :- status(o_15cbdee1adc3cc0bb827,refuted).
node(n523,unknown) :- status(o_15cbdee1adc3cc0bb827,unknown).
node(n524,supported) :- status(o_c55c64c7eea4170106d8,supported).
node(n524,refuted) :- status(o_c55c64c7eea4170106d8,refuted).
node(n524,unknown) :- status(o_c55c64c7eea4170106d8,unknown).
node(n525,supported) :- status(o_3955123710d5107f611e,supported).
node(n525,refuted) :- status(o_3955123710d5107f611e,refuted).
node(n525,unknown) :- status(o_3955123710d5107f611e,unknown).
node(n522,supported) :- node(n523,supported), node(n524,supported), node(n525,supported).
node(n522,refuted) :- node(n523,refuted).
node(n522,refuted) :- node(n524,refuted).
node(n522,refuted) :- node(n525,refuted).
node(n522,unknown) :- \+ node(n522,supported), \+ node(n522,refuted).
node(n521,refuted) :- node(n522,refuted), node(n9,refuted).
node(n521,supported) :- node(n522,supported).
node(n521,supported) :- node(n9,supported).
node(n521,unknown) :- \+ node(n521,supported), \+ node(n521,refuted).
verdict(c_47627cfb1d1c44a2,supported) :- node(n521,supported).
query(verdict(c_47627cfb1d1c44a2,supported)).
verdict(c_47627cfb1d1c44a2,refuted) :- node(n521,refuted).
query(verdict(c_47627cfb1d1c44a2,refuted)).
verdict(c_47627cfb1d1c44a2,unknown) :- node(n521,unknown).
query(verdict(c_47627cfb1d1c44a2,unknown)).
node(n528,supported) :- status(o_fbfbd5bd60bb6478e94d,supported).
node(n528,refuted) :- status(o_fbfbd5bd60bb6478e94d,refuted).
node(n528,unknown) :- status(o_fbfbd5bd60bb6478e94d,unknown).
node(n527,supported) :- node(n523,supported), node(n524,supported), node(n528,supported), node(n525,supported).
node(n527,refuted) :- node(n523,refuted).
node(n527,refuted) :- node(n524,refuted).
node(n527,refuted) :- node(n528,refuted).
node(n527,refuted) :- node(n525,refuted).
node(n527,unknown) :- \+ node(n527,supported), \+ node(n527,refuted).
node(n526,refuted) :- node(n527,refuted), node(n9,refuted).
node(n526,supported) :- node(n527,supported).
node(n526,supported) :- node(n9,supported).
node(n526,unknown) :- \+ node(n526,supported), \+ node(n526,refuted).
verdict(c_ac33778fd48e5b14,supported) :- node(n526,supported).
query(verdict(c_ac33778fd48e5b14,supported)).
verdict(c_ac33778fd48e5b14,refuted) :- node(n526,refuted).
query(verdict(c_ac33778fd48e5b14,refuted)).
verdict(c_ac33778fd48e5b14,unknown) :- node(n526,unknown).
query(verdict(c_ac33778fd48e5b14,unknown)).
node(n531,supported) :- status(o_dc1f670188e3c3bd8066,supported).
node(n531,refuted) :- status(o_dc1f670188e3c3bd8066,refuted).
node(n531,unknown) :- status(o_dc1f670188e3c3bd8066,unknown).
node(n532,supported) :- status(o_6ca9b18073d22c691c53,supported).
node(n532,refuted) :- status(o_6ca9b18073d22c691c53,refuted).
node(n532,unknown) :- status(o_6ca9b18073d22c691c53,unknown).
node(n533,supported) :- status(o_46da85bc07a45229d1aa,supported).
node(n533,refuted) :- status(o_46da85bc07a45229d1aa,refuted).
node(n533,unknown) :- status(o_46da85bc07a45229d1aa,unknown).
node(n530,supported) :- node(n531,supported), node(n532,supported), node(n533,supported).
node(n530,refuted) :- node(n531,refuted).
node(n530,refuted) :- node(n532,refuted).
node(n530,refuted) :- node(n533,refuted).
node(n530,unknown) :- \+ node(n530,supported), \+ node(n530,refuted).
node(n529,refuted) :- node(n530,refuted), node(n9,refuted).
node(n529,supported) :- node(n530,supported).
node(n529,supported) :- node(n9,supported).
node(n529,unknown) :- \+ node(n529,supported), \+ node(n529,refuted).
verdict(c_08f76fc2023cc76f,supported) :- node(n529,supported).
query(verdict(c_08f76fc2023cc76f,supported)).
verdict(c_08f76fc2023cc76f,refuted) :- node(n529,refuted).
query(verdict(c_08f76fc2023cc76f,refuted)).
verdict(c_08f76fc2023cc76f,unknown) :- node(n529,unknown).
query(verdict(c_08f76fc2023cc76f,unknown)).
node(n536,supported) :- status(o_c2f27d55393c72492b18,supported).
node(n536,refuted) :- status(o_c2f27d55393c72492b18,refuted).
node(n536,unknown) :- status(o_c2f27d55393c72492b18,unknown).
node(n535,supported) :- node(n531,supported), node(n532,supported), node(n536,supported), node(n533,supported).
node(n535,refuted) :- node(n531,refuted).
node(n535,refuted) :- node(n532,refuted).
node(n535,refuted) :- node(n536,refuted).
node(n535,refuted) :- node(n533,refuted).
node(n535,unknown) :- \+ node(n535,supported), \+ node(n535,refuted).
node(n534,refuted) :- node(n535,refuted), node(n9,refuted).
node(n534,supported) :- node(n535,supported).
node(n534,supported) :- node(n9,supported).
node(n534,unknown) :- \+ node(n534,supported), \+ node(n534,refuted).
verdict(c_2af6a92410ddd279,supported) :- node(n534,supported).
query(verdict(c_2af6a92410ddd279,supported)).
verdict(c_2af6a92410ddd279,refuted) :- node(n534,refuted).
query(verdict(c_2af6a92410ddd279,refuted)).
verdict(c_2af6a92410ddd279,unknown) :- node(n534,unknown).
query(verdict(c_2af6a92410ddd279,unknown)).
node(n539,supported) :- status(o_ead10d7a9bffcca8d20f,supported).
node(n539,refuted) :- status(o_ead10d7a9bffcca8d20f,refuted).
node(n539,unknown) :- status(o_ead10d7a9bffcca8d20f,unknown).
node(n540,supported) :- status(o_a8b5da03e7ff284e8699,supported).
node(n540,refuted) :- status(o_a8b5da03e7ff284e8699,refuted).
node(n540,unknown) :- status(o_a8b5da03e7ff284e8699,unknown).
node(n541,supported) :- status(o_4124816458cc7be7791d,supported).
node(n541,refuted) :- status(o_4124816458cc7be7791d,refuted).
node(n541,unknown) :- status(o_4124816458cc7be7791d,unknown).
node(n538,supported) :- node(n539,supported), node(n540,supported), node(n541,supported).
node(n538,refuted) :- node(n539,refuted).
node(n538,refuted) :- node(n540,refuted).
node(n538,refuted) :- node(n541,refuted).
node(n538,unknown) :- \+ node(n538,supported), \+ node(n538,refuted).
node(n537,refuted) :- node(n538,refuted), node(n9,refuted).
node(n537,supported) :- node(n538,supported).
node(n537,supported) :- node(n9,supported).
node(n537,unknown) :- \+ node(n537,supported), \+ node(n537,refuted).
verdict(c_96ff3396e5fe6d4a,supported) :- node(n537,supported).
query(verdict(c_96ff3396e5fe6d4a,supported)).
verdict(c_96ff3396e5fe6d4a,refuted) :- node(n537,refuted).
query(verdict(c_96ff3396e5fe6d4a,refuted)).
verdict(c_96ff3396e5fe6d4a,unknown) :- node(n537,unknown).
query(verdict(c_96ff3396e5fe6d4a,unknown)).
node(n544,supported) :- status(o_f1e6623d7b7c46c10405,supported).
node(n544,refuted) :- status(o_f1e6623d7b7c46c10405,refuted).
node(n544,unknown) :- status(o_f1e6623d7b7c46c10405,unknown).
node(n543,supported) :- node(n539,supported), node(n540,supported), node(n544,supported), node(n541,supported).
node(n543,refuted) :- node(n539,refuted).
node(n543,refuted) :- node(n540,refuted).
node(n543,refuted) :- node(n544,refuted).
node(n543,refuted) :- node(n541,refuted).
node(n543,unknown) :- \+ node(n543,supported), \+ node(n543,refuted).
node(n542,refuted) :- node(n543,refuted), node(n9,refuted).
node(n542,supported) :- node(n543,supported).
node(n542,supported) :- node(n9,supported).
node(n542,unknown) :- \+ node(n542,supported), \+ node(n542,refuted).
verdict(c_16b001e3b0b34138,supported) :- node(n542,supported).
query(verdict(c_16b001e3b0b34138,supported)).
verdict(c_16b001e3b0b34138,refuted) :- node(n542,refuted).
query(verdict(c_16b001e3b0b34138,refuted)).
verdict(c_16b001e3b0b34138,unknown) :- node(n542,unknown).
query(verdict(c_16b001e3b0b34138,unknown)).
node(n547,supported) :- status(o_6412bf5da791271fed4a,supported).
node(n547,refuted) :- status(o_6412bf5da791271fed4a,refuted).
node(n547,unknown) :- status(o_6412bf5da791271fed4a,unknown).
node(n548,supported) :- status(o_78d4c9f384590326694d,supported).
node(n548,refuted) :- status(o_78d4c9f384590326694d,refuted).
node(n548,unknown) :- status(o_78d4c9f384590326694d,unknown).
node(n549,supported) :- status(o_bba03d6bf4cdd7efcf2a,supported).
node(n549,refuted) :- status(o_bba03d6bf4cdd7efcf2a,refuted).
node(n549,unknown) :- status(o_bba03d6bf4cdd7efcf2a,unknown).
node(n546,supported) :- node(n547,supported), node(n548,supported), node(n549,supported).
node(n546,refuted) :- node(n547,refuted).
node(n546,refuted) :- node(n548,refuted).
node(n546,refuted) :- node(n549,refuted).
node(n546,unknown) :- \+ node(n546,supported), \+ node(n546,refuted).
node(n545,refuted) :- node(n546,refuted), node(n9,refuted).
node(n545,supported) :- node(n546,supported).
node(n545,supported) :- node(n9,supported).
node(n545,unknown) :- \+ node(n545,supported), \+ node(n545,refuted).
verdict(c_7adbffed4662c077,supported) :- node(n545,supported).
query(verdict(c_7adbffed4662c077,supported)).
verdict(c_7adbffed4662c077,refuted) :- node(n545,refuted).
query(verdict(c_7adbffed4662c077,refuted)).
verdict(c_7adbffed4662c077,unknown) :- node(n545,unknown).
query(verdict(c_7adbffed4662c077,unknown)).
node(n552,supported) :- status(o_cdcfd205345369b741b4,supported).
node(n552,refuted) :- status(o_cdcfd205345369b741b4,refuted).
node(n552,unknown) :- status(o_cdcfd205345369b741b4,unknown).
node(n551,supported) :- node(n547,supported), node(n548,supported), node(n552,supported), node(n549,supported).
node(n551,refuted) :- node(n547,refuted).
node(n551,refuted) :- node(n548,refuted).
node(n551,refuted) :- node(n552,refuted).
node(n551,refuted) :- node(n549,refuted).
node(n551,unknown) :- \+ node(n551,supported), \+ node(n551,refuted).
node(n550,refuted) :- node(n551,refuted), node(n9,refuted).
node(n550,supported) :- node(n551,supported).
node(n550,supported) :- node(n9,supported).
node(n550,unknown) :- \+ node(n550,supported), \+ node(n550,refuted).
verdict(c_60beafc897aaffe7,supported) :- node(n550,supported).
query(verdict(c_60beafc897aaffe7,supported)).
verdict(c_60beafc897aaffe7,refuted) :- node(n550,refuted).
query(verdict(c_60beafc897aaffe7,refuted)).
verdict(c_60beafc897aaffe7,unknown) :- node(n550,unknown).
query(verdict(c_60beafc897aaffe7,unknown)).
node(n555,supported) :- status(o_4ccbe967e40edc2464d9,supported).
node(n555,refuted) :- status(o_4ccbe967e40edc2464d9,refuted).
node(n555,unknown) :- status(o_4ccbe967e40edc2464d9,unknown).
node(n556,supported) :- status(o_7b3b724da1e045bcfdf5,supported).
node(n556,refuted) :- status(o_7b3b724da1e045bcfdf5,refuted).
node(n556,unknown) :- status(o_7b3b724da1e045bcfdf5,unknown).
node(n557,supported) :- status(o_461ada905dff67f06def,supported).
node(n557,refuted) :- status(o_461ada905dff67f06def,refuted).
node(n557,unknown) :- status(o_461ada905dff67f06def,unknown).
node(n554,supported) :- node(n555,supported), node(n556,supported), node(n557,supported).
node(n554,refuted) :- node(n555,refuted).
node(n554,refuted) :- node(n556,refuted).
node(n554,refuted) :- node(n557,refuted).
node(n554,unknown) :- \+ node(n554,supported), \+ node(n554,refuted).
node(n553,refuted) :- node(n554,refuted), node(n9,refuted).
node(n553,supported) :- node(n554,supported).
node(n553,supported) :- node(n9,supported).
node(n553,unknown) :- \+ node(n553,supported), \+ node(n553,refuted).
verdict(c_001e3d7469e1b667,supported) :- node(n553,supported).
query(verdict(c_001e3d7469e1b667,supported)).
verdict(c_001e3d7469e1b667,refuted) :- node(n553,refuted).
query(verdict(c_001e3d7469e1b667,refuted)).
verdict(c_001e3d7469e1b667,unknown) :- node(n553,unknown).
query(verdict(c_001e3d7469e1b667,unknown)).
node(n560,supported) :- status(o_d3efe2aaf645e90c64e7,supported).
node(n560,refuted) :- status(o_d3efe2aaf645e90c64e7,refuted).
node(n560,unknown) :- status(o_d3efe2aaf645e90c64e7,unknown).
node(n559,supported) :- node(n555,supported), node(n556,supported), node(n560,supported), node(n557,supported).
node(n559,refuted) :- node(n555,refuted).
node(n559,refuted) :- node(n556,refuted).
node(n559,refuted) :- node(n560,refuted).
node(n559,refuted) :- node(n557,refuted).
node(n559,unknown) :- \+ node(n559,supported), \+ node(n559,refuted).
node(n558,refuted) :- node(n559,refuted), node(n9,refuted).
node(n558,supported) :- node(n559,supported).
node(n558,supported) :- node(n9,supported).
node(n558,unknown) :- \+ node(n558,supported), \+ node(n558,refuted).
verdict(c_98925e2561229c4b,supported) :- node(n558,supported).
query(verdict(c_98925e2561229c4b,supported)).
verdict(c_98925e2561229c4b,refuted) :- node(n558,refuted).
query(verdict(c_98925e2561229c4b,refuted)).
verdict(c_98925e2561229c4b,unknown) :- node(n558,unknown).
query(verdict(c_98925e2561229c4b,unknown)).
node(n563,supported) :- status(o_2e71ea0f927b7104f7f8,supported).
node(n563,refuted) :- status(o_2e71ea0f927b7104f7f8,refuted).
node(n563,unknown) :- status(o_2e71ea0f927b7104f7f8,unknown).
node(n564,supported) :- status(o_df546da126e6991e3baa,supported).
node(n564,refuted) :- status(o_df546da126e6991e3baa,refuted).
node(n564,unknown) :- status(o_df546da126e6991e3baa,unknown).
node(n565,supported) :- status(o_0469678a18c2af8fff5a,supported).
node(n565,refuted) :- status(o_0469678a18c2af8fff5a,refuted).
node(n565,unknown) :- status(o_0469678a18c2af8fff5a,unknown).
node(n562,supported) :- node(n563,supported), node(n564,supported), node(n565,supported).
node(n562,refuted) :- node(n563,refuted).
node(n562,refuted) :- node(n564,refuted).
node(n562,refuted) :- node(n565,refuted).
node(n562,unknown) :- \+ node(n562,supported), \+ node(n562,refuted).
node(n561,refuted) :- node(n562,refuted), node(n9,refuted).
node(n561,supported) :- node(n562,supported).
node(n561,supported) :- node(n9,supported).
node(n561,unknown) :- \+ node(n561,supported), \+ node(n561,refuted).
verdict(c_bd2b0f395daee435,supported) :- node(n561,supported).
query(verdict(c_bd2b0f395daee435,supported)).
verdict(c_bd2b0f395daee435,refuted) :- node(n561,refuted).
query(verdict(c_bd2b0f395daee435,refuted)).
verdict(c_bd2b0f395daee435,unknown) :- node(n561,unknown).
query(verdict(c_bd2b0f395daee435,unknown)).
node(n568,supported) :- status(o_432df4da2bf892eb26a9,supported).
node(n568,refuted) :- status(o_432df4da2bf892eb26a9,refuted).
node(n568,unknown) :- status(o_432df4da2bf892eb26a9,unknown).
node(n567,supported) :- node(n563,supported), node(n564,supported), node(n568,supported), node(n565,supported).
node(n567,refuted) :- node(n563,refuted).
node(n567,refuted) :- node(n564,refuted).
node(n567,refuted) :- node(n568,refuted).
node(n567,refuted) :- node(n565,refuted).
node(n567,unknown) :- \+ node(n567,supported), \+ node(n567,refuted).
node(n566,refuted) :- node(n567,refuted), node(n9,refuted).
node(n566,supported) :- node(n567,supported).
node(n566,supported) :- node(n9,supported).
node(n566,unknown) :- \+ node(n566,supported), \+ node(n566,refuted).
verdict(c_f821cb3a9eb0b247,supported) :- node(n566,supported).
query(verdict(c_f821cb3a9eb0b247,supported)).
verdict(c_f821cb3a9eb0b247,refuted) :- node(n566,refuted).
query(verdict(c_f821cb3a9eb0b247,refuted)).
verdict(c_f821cb3a9eb0b247,unknown) :- node(n566,unknown).
query(verdict(c_f821cb3a9eb0b247,unknown)).
node(n571,supported) :- status(o_e05085af967da8e8a1cc,supported).
node(n571,refuted) :- status(o_e05085af967da8e8a1cc,refuted).
node(n571,unknown) :- status(o_e05085af967da8e8a1cc,unknown).
node(n572,supported) :- status(o_ada7dddae314288a80e4,supported).
node(n572,refuted) :- status(o_ada7dddae314288a80e4,refuted).
node(n572,unknown) :- status(o_ada7dddae314288a80e4,unknown).
node(n573,supported) :- status(o_a71f4ef44eba9fc6cb0e,supported).
node(n573,refuted) :- status(o_a71f4ef44eba9fc6cb0e,refuted).
node(n573,unknown) :- status(o_a71f4ef44eba9fc6cb0e,unknown).
node(n570,supported) :- node(n571,supported), node(n572,supported), node(n573,supported).
node(n570,refuted) :- node(n571,refuted).
node(n570,refuted) :- node(n572,refuted).
node(n570,refuted) :- node(n573,refuted).
node(n570,unknown) :- \+ node(n570,supported), \+ node(n570,refuted).
node(n569,refuted) :- node(n570,refuted), node(n9,refuted).
node(n569,supported) :- node(n570,supported).
node(n569,supported) :- node(n9,supported).
node(n569,unknown) :- \+ node(n569,supported), \+ node(n569,refuted).
verdict(c_30c647228e190e33,supported) :- node(n569,supported).
query(verdict(c_30c647228e190e33,supported)).
verdict(c_30c647228e190e33,refuted) :- node(n569,refuted).
query(verdict(c_30c647228e190e33,refuted)).
verdict(c_30c647228e190e33,unknown) :- node(n569,unknown).
query(verdict(c_30c647228e190e33,unknown)).
node(n576,supported) :- status(o_20a6b10f82f1bdb4116c,supported).
node(n576,refuted) :- status(o_20a6b10f82f1bdb4116c,refuted).
node(n576,unknown) :- status(o_20a6b10f82f1bdb4116c,unknown).
node(n575,supported) :- node(n571,supported), node(n572,supported), node(n576,supported), node(n573,supported).
node(n575,refuted) :- node(n571,refuted).
node(n575,refuted) :- node(n572,refuted).
node(n575,refuted) :- node(n576,refuted).
node(n575,refuted) :- node(n573,refuted).
node(n575,unknown) :- \+ node(n575,supported), \+ node(n575,refuted).
node(n574,refuted) :- node(n575,refuted), node(n9,refuted).
node(n574,supported) :- node(n575,supported).
node(n574,supported) :- node(n9,supported).
node(n574,unknown) :- \+ node(n574,supported), \+ node(n574,refuted).
verdict(c_d9e011e6e3bc951f,supported) :- node(n574,supported).
query(verdict(c_d9e011e6e3bc951f,supported)).
verdict(c_d9e011e6e3bc951f,refuted) :- node(n574,refuted).
query(verdict(c_d9e011e6e3bc951f,refuted)).
verdict(c_d9e011e6e3bc951f,unknown) :- node(n574,unknown).
query(verdict(c_d9e011e6e3bc951f,unknown)).
node(n579,supported) :- status(o_d7691232d427829ddd7a,supported).
node(n579,refuted) :- status(o_d7691232d427829ddd7a,refuted).
node(n579,unknown) :- status(o_d7691232d427829ddd7a,unknown).
node(n580,supported) :- status(o_4889e109a1357ef49372,supported).
node(n580,refuted) :- status(o_4889e109a1357ef49372,refuted).
node(n580,unknown) :- status(o_4889e109a1357ef49372,unknown).
node(n581,supported) :- status(o_5afb1e996d5ff006e47a,supported).
node(n581,refuted) :- status(o_5afb1e996d5ff006e47a,refuted).
node(n581,unknown) :- status(o_5afb1e996d5ff006e47a,unknown).
node(n578,supported) :- node(n579,supported), node(n580,supported), node(n581,supported).
node(n578,refuted) :- node(n579,refuted).
node(n578,refuted) :- node(n580,refuted).
node(n578,refuted) :- node(n581,refuted).
node(n578,unknown) :- \+ node(n578,supported), \+ node(n578,refuted).
node(n577,refuted) :- node(n578,refuted), node(n9,refuted).
node(n577,supported) :- node(n578,supported).
node(n577,supported) :- node(n9,supported).
node(n577,unknown) :- \+ node(n577,supported), \+ node(n577,refuted).
verdict(c_4ec077c483dd6e5d,supported) :- node(n577,supported).
query(verdict(c_4ec077c483dd6e5d,supported)).
verdict(c_4ec077c483dd6e5d,refuted) :- node(n577,refuted).
query(verdict(c_4ec077c483dd6e5d,refuted)).
verdict(c_4ec077c483dd6e5d,unknown) :- node(n577,unknown).
query(verdict(c_4ec077c483dd6e5d,unknown)).
node(n584,supported) :- status(o_54c943276457363fbbe1,supported).
node(n584,refuted) :- status(o_54c943276457363fbbe1,refuted).
node(n584,unknown) :- status(o_54c943276457363fbbe1,unknown).
node(n583,supported) :- node(n579,supported), node(n580,supported), node(n584,supported), node(n581,supported).
node(n583,refuted) :- node(n579,refuted).
node(n583,refuted) :- node(n580,refuted).
node(n583,refuted) :- node(n584,refuted).
node(n583,refuted) :- node(n581,refuted).
node(n583,unknown) :- \+ node(n583,supported), \+ node(n583,refuted).
node(n582,refuted) :- node(n583,refuted), node(n9,refuted).
node(n582,supported) :- node(n583,supported).
node(n582,supported) :- node(n9,supported).
node(n582,unknown) :- \+ node(n582,supported), \+ node(n582,refuted).
verdict(c_c0a844f349555e82,supported) :- node(n582,supported).
query(verdict(c_c0a844f349555e82,supported)).
verdict(c_c0a844f349555e82,refuted) :- node(n582,refuted).
query(verdict(c_c0a844f349555e82,refuted)).
verdict(c_c0a844f349555e82,unknown) :- node(n582,unknown).
query(verdict(c_c0a844f349555e82,unknown)).
node(n587,supported) :- status(o_e07693f06d6eb6721439,supported).
node(n587,refuted) :- status(o_e07693f06d6eb6721439,refuted).
node(n587,unknown) :- status(o_e07693f06d6eb6721439,unknown).
node(n588,supported) :- status(o_41b5df560211afc7c834,supported).
node(n588,refuted) :- status(o_41b5df560211afc7c834,refuted).
node(n588,unknown) :- status(o_41b5df560211afc7c834,unknown).
node(n589,supported) :- status(o_fb68810a4bd828d5a04a,supported).
node(n589,refuted) :- status(o_fb68810a4bd828d5a04a,refuted).
node(n589,unknown) :- status(o_fb68810a4bd828d5a04a,unknown).
node(n586,supported) :- node(n587,supported), node(n588,supported), node(n589,supported).
node(n586,refuted) :- node(n587,refuted).
node(n586,refuted) :- node(n588,refuted).
node(n586,refuted) :- node(n589,refuted).
node(n586,unknown) :- \+ node(n586,supported), \+ node(n586,refuted).
node(n585,refuted) :- node(n586,refuted), node(n9,refuted).
node(n585,supported) :- node(n586,supported).
node(n585,supported) :- node(n9,supported).
node(n585,unknown) :- \+ node(n585,supported), \+ node(n585,refuted).
verdict(c_5daa57b065d5e03c,supported) :- node(n585,supported).
query(verdict(c_5daa57b065d5e03c,supported)).
verdict(c_5daa57b065d5e03c,refuted) :- node(n585,refuted).
query(verdict(c_5daa57b065d5e03c,refuted)).
verdict(c_5daa57b065d5e03c,unknown) :- node(n585,unknown).
query(verdict(c_5daa57b065d5e03c,unknown)).
node(n592,supported) :- status(o_27ba79585d8586cc1136,supported).
node(n592,refuted) :- status(o_27ba79585d8586cc1136,refuted).
node(n592,unknown) :- status(o_27ba79585d8586cc1136,unknown).
node(n591,supported) :- node(n587,supported), node(n588,supported), node(n592,supported), node(n589,supported).
node(n591,refuted) :- node(n587,refuted).
node(n591,refuted) :- node(n588,refuted).
node(n591,refuted) :- node(n592,refuted).
node(n591,refuted) :- node(n589,refuted).
node(n591,unknown) :- \+ node(n591,supported), \+ node(n591,refuted).
node(n590,refuted) :- node(n591,refuted), node(n9,refuted).
node(n590,supported) :- node(n591,supported).
node(n590,supported) :- node(n9,supported).
node(n590,unknown) :- \+ node(n590,supported), \+ node(n590,refuted).
verdict(c_5c64c208b425dd1b,supported) :- node(n590,supported).
query(verdict(c_5c64c208b425dd1b,supported)).
verdict(c_5c64c208b425dd1b,refuted) :- node(n590,refuted).
query(verdict(c_5c64c208b425dd1b,refuted)).
verdict(c_5c64c208b425dd1b,unknown) :- node(n590,unknown).
query(verdict(c_5c64c208b425dd1b,unknown)).
node(n595,supported) :- status(o_7f6a2b66195fb7629db3,supported).
node(n595,refuted) :- status(o_7f6a2b66195fb7629db3,refuted).
node(n595,unknown) :- status(o_7f6a2b66195fb7629db3,unknown).
node(n596,supported) :- status(o_8c22c3c59e4d458a41fa,supported).
node(n596,refuted) :- status(o_8c22c3c59e4d458a41fa,refuted).
node(n596,unknown) :- status(o_8c22c3c59e4d458a41fa,unknown).
node(n597,supported) :- status(o_831c724376ed891d5c06,supported).
node(n597,refuted) :- status(o_831c724376ed891d5c06,refuted).
node(n597,unknown) :- status(o_831c724376ed891d5c06,unknown).
node(n594,supported) :- node(n595,supported), node(n596,supported), node(n597,supported).
node(n594,refuted) :- node(n595,refuted).
node(n594,refuted) :- node(n596,refuted).
node(n594,refuted) :- node(n597,refuted).
node(n594,unknown) :- \+ node(n594,supported), \+ node(n594,refuted).
node(n593,refuted) :- node(n594,refuted), node(n9,refuted).
node(n593,supported) :- node(n594,supported).
node(n593,supported) :- node(n9,supported).
node(n593,unknown) :- \+ node(n593,supported), \+ node(n593,refuted).
verdict(c_6798fd6243b2e427,supported) :- node(n593,supported).
query(verdict(c_6798fd6243b2e427,supported)).
verdict(c_6798fd6243b2e427,refuted) :- node(n593,refuted).
query(verdict(c_6798fd6243b2e427,refuted)).
verdict(c_6798fd6243b2e427,unknown) :- node(n593,unknown).
query(verdict(c_6798fd6243b2e427,unknown)).
node(n600,supported) :- status(o_e85da8a53de9c803e288,supported).
node(n600,refuted) :- status(o_e85da8a53de9c803e288,refuted).
node(n600,unknown) :- status(o_e85da8a53de9c803e288,unknown).
node(n599,supported) :- node(n595,supported), node(n596,supported), node(n600,supported), node(n597,supported).
node(n599,refuted) :- node(n595,refuted).
node(n599,refuted) :- node(n596,refuted).
node(n599,refuted) :- node(n600,refuted).
node(n599,refuted) :- node(n597,refuted).
node(n599,unknown) :- \+ node(n599,supported), \+ node(n599,refuted).
node(n598,refuted) :- node(n599,refuted), node(n9,refuted).
node(n598,supported) :- node(n599,supported).
node(n598,supported) :- node(n9,supported).
node(n598,unknown) :- \+ node(n598,supported), \+ node(n598,refuted).
verdict(c_c95a28b79b3ec384,supported) :- node(n598,supported).
query(verdict(c_c95a28b79b3ec384,supported)).
verdict(c_c95a28b79b3ec384,refuted) :- node(n598,refuted).
query(verdict(c_c95a28b79b3ec384,refuted)).
verdict(c_c95a28b79b3ec384,unknown) :- node(n598,unknown).
query(verdict(c_c95a28b79b3ec384,unknown)).
node(n603,supported) :- status(o_6f0f32e8b6895343eeb1,supported).
node(n603,refuted) :- status(o_6f0f32e8b6895343eeb1,refuted).
node(n603,unknown) :- status(o_6f0f32e8b6895343eeb1,unknown).
node(n604,supported) :- status(o_8a26b3ed952a1c4018b0,supported).
node(n604,refuted) :- status(o_8a26b3ed952a1c4018b0,refuted).
node(n604,unknown) :- status(o_8a26b3ed952a1c4018b0,unknown).
node(n605,supported) :- status(o_d242a82ea74f371c8502,supported).
node(n605,refuted) :- status(o_d242a82ea74f371c8502,refuted).
node(n605,unknown) :- status(o_d242a82ea74f371c8502,unknown).
node(n602,supported) :- node(n603,supported), node(n604,supported), node(n605,supported).
node(n602,refuted) :- node(n603,refuted).
node(n602,refuted) :- node(n604,refuted).
node(n602,refuted) :- node(n605,refuted).
node(n602,unknown) :- \+ node(n602,supported), \+ node(n602,refuted).
node(n607,supported) :- status(o_5335f2c044a5c453f1d3,supported).
node(n607,refuted) :- status(o_5335f2c044a5c453f1d3,refuted).
node(n607,unknown) :- status(o_5335f2c044a5c453f1d3,unknown).
node(n608,supported) :- status(o_88a8f4560471ac7e3f57,supported).
node(n608,refuted) :- status(o_88a8f4560471ac7e3f57,refuted).
node(n608,unknown) :- status(o_88a8f4560471ac7e3f57,unknown).
node(n609,supported) :- status(o_4c7d266e173cfd04fe2a,supported).
node(n609,refuted) :- status(o_4c7d266e173cfd04fe2a,refuted).
node(n609,unknown) :- status(o_4c7d266e173cfd04fe2a,unknown).
node(n606,supported) :- node(n607,supported), node(n608,supported), node(n609,supported).
node(n606,refuted) :- node(n607,refuted).
node(n606,refuted) :- node(n608,refuted).
node(n606,refuted) :- node(n609,refuted).
node(n606,unknown) :- \+ node(n606,supported), \+ node(n606,refuted).
node(n601,refuted) :- node(n602,refuted), node(n606,refuted), node(n9,refuted).
node(n601,supported) :- node(n602,supported).
node(n601,supported) :- node(n606,supported).
node(n601,supported) :- node(n9,supported).
node(n601,unknown) :- \+ node(n601,supported), \+ node(n601,refuted).
verdict(c_a5e8084b13b83d3a,supported) :- node(n601,supported).
query(verdict(c_a5e8084b13b83d3a,supported)).
verdict(c_a5e8084b13b83d3a,refuted) :- node(n601,refuted).
query(verdict(c_a5e8084b13b83d3a,refuted)).
verdict(c_a5e8084b13b83d3a,unknown) :- node(n601,unknown).
query(verdict(c_a5e8084b13b83d3a,unknown)).
node(n612,supported) :- status(o_249ea1bc115028c1e037,supported).
node(n612,refuted) :- status(o_249ea1bc115028c1e037,refuted).
node(n612,unknown) :- status(o_249ea1bc115028c1e037,unknown).
node(n611,supported) :- node(n603,supported), node(n604,supported), node(n612,supported), node(n605,supported).
node(n611,refuted) :- node(n603,refuted).
node(n611,refuted) :- node(n604,refuted).
node(n611,refuted) :- node(n612,refuted).
node(n611,refuted) :- node(n605,refuted).
node(n611,unknown) :- \+ node(n611,supported), \+ node(n611,refuted).
node(n614,supported) :- status(o_3096b55322047d08483c,supported).
node(n614,refuted) :- status(o_3096b55322047d08483c,refuted).
node(n614,unknown) :- status(o_3096b55322047d08483c,unknown).
node(n613,supported) :- node(n607,supported), node(n608,supported), node(n614,supported), node(n609,supported).
node(n613,refuted) :- node(n607,refuted).
node(n613,refuted) :- node(n608,refuted).
node(n613,refuted) :- node(n614,refuted).
node(n613,refuted) :- node(n609,refuted).
node(n613,unknown) :- \+ node(n613,supported), \+ node(n613,refuted).
node(n610,refuted) :- node(n611,refuted), node(n613,refuted), node(n9,refuted).
node(n610,supported) :- node(n611,supported).
node(n610,supported) :- node(n613,supported).
node(n610,supported) :- node(n9,supported).
node(n610,unknown) :- \+ node(n610,supported), \+ node(n610,refuted).
verdict(c_40397af7159d2eb0,supported) :- node(n610,supported).
query(verdict(c_40397af7159d2eb0,supported)).
verdict(c_40397af7159d2eb0,refuted) :- node(n610,refuted).
query(verdict(c_40397af7159d2eb0,refuted)).
verdict(c_40397af7159d2eb0,unknown) :- node(n610,unknown).
query(verdict(c_40397af7159d2eb0,unknown)).
node(n617,supported) :- status(o_1ecfd9745f37dbec787c,supported).
node(n617,refuted) :- status(o_1ecfd9745f37dbec787c,refuted).
node(n617,unknown) :- status(o_1ecfd9745f37dbec787c,unknown).
node(n618,supported) :- status(o_bab9e0c3174ede88ebe6,supported).
node(n618,refuted) :- status(o_bab9e0c3174ede88ebe6,refuted).
node(n618,unknown) :- status(o_bab9e0c3174ede88ebe6,unknown).
node(n619,supported) :- status(o_9b01bf4b59307623c76c,supported).
node(n619,refuted) :- status(o_9b01bf4b59307623c76c,refuted).
node(n619,unknown) :- status(o_9b01bf4b59307623c76c,unknown).
node(n616,supported) :- node(n617,supported), node(n618,supported), node(n619,supported).
node(n616,refuted) :- node(n617,refuted).
node(n616,refuted) :- node(n618,refuted).
node(n616,refuted) :- node(n619,refuted).
node(n616,unknown) :- \+ node(n616,supported), \+ node(n616,refuted).
node(n621,supported) :- status(o_22da77ef3f35ab45bf31,supported).
node(n621,refuted) :- status(o_22da77ef3f35ab45bf31,refuted).
node(n621,unknown) :- status(o_22da77ef3f35ab45bf31,unknown).
node(n622,supported) :- status(o_72acaf36a257ce51ee74,supported).
node(n622,refuted) :- status(o_72acaf36a257ce51ee74,refuted).
node(n622,unknown) :- status(o_72acaf36a257ce51ee74,unknown).
node(n623,supported) :- status(o_d523e7a15c5656813ecb,supported).
node(n623,refuted) :- status(o_d523e7a15c5656813ecb,refuted).
node(n623,unknown) :- status(o_d523e7a15c5656813ecb,unknown).
node(n620,supported) :- node(n621,supported), node(n622,supported), node(n623,supported).
node(n620,refuted) :- node(n621,refuted).
node(n620,refuted) :- node(n622,refuted).
node(n620,refuted) :- node(n623,refuted).
node(n620,unknown) :- \+ node(n620,supported), \+ node(n620,refuted).
node(n615,refuted) :- node(n616,refuted), node(n620,refuted), node(n9,refuted).
node(n615,supported) :- node(n616,supported).
node(n615,supported) :- node(n620,supported).
node(n615,supported) :- node(n9,supported).
node(n615,unknown) :- \+ node(n615,supported), \+ node(n615,refuted).
verdict(c_6a9e0a3dfaa010df,supported) :- node(n615,supported).
query(verdict(c_6a9e0a3dfaa010df,supported)).
verdict(c_6a9e0a3dfaa010df,refuted) :- node(n615,refuted).
query(verdict(c_6a9e0a3dfaa010df,refuted)).
verdict(c_6a9e0a3dfaa010df,unknown) :- node(n615,unknown).
query(verdict(c_6a9e0a3dfaa010df,unknown)).
node(n626,supported) :- status(o_32c2a8233d221534c0bd,supported).
node(n626,refuted) :- status(o_32c2a8233d221534c0bd,refuted).
node(n626,unknown) :- status(o_32c2a8233d221534c0bd,unknown).
node(n625,supported) :- node(n617,supported), node(n618,supported), node(n626,supported), node(n619,supported).
node(n625,refuted) :- node(n617,refuted).
node(n625,refuted) :- node(n618,refuted).
node(n625,refuted) :- node(n626,refuted).
node(n625,refuted) :- node(n619,refuted).
node(n625,unknown) :- \+ node(n625,supported), \+ node(n625,refuted).
node(n628,supported) :- status(o_46b0dfa33bf5a3670b0f,supported).
node(n628,refuted) :- status(o_46b0dfa33bf5a3670b0f,refuted).
node(n628,unknown) :- status(o_46b0dfa33bf5a3670b0f,unknown).
node(n627,supported) :- node(n621,supported), node(n622,supported), node(n628,supported), node(n623,supported).
node(n627,refuted) :- node(n621,refuted).
node(n627,refuted) :- node(n622,refuted).
node(n627,refuted) :- node(n628,refuted).
node(n627,refuted) :- node(n623,refuted).
node(n627,unknown) :- \+ node(n627,supported), \+ node(n627,refuted).
node(n624,refuted) :- node(n625,refuted), node(n627,refuted), node(n9,refuted).
node(n624,supported) :- node(n625,supported).
node(n624,supported) :- node(n627,supported).
node(n624,supported) :- node(n9,supported).
node(n624,unknown) :- \+ node(n624,supported), \+ node(n624,refuted).
verdict(c_21595fb4e83ff0d4,supported) :- node(n624,supported).
query(verdict(c_21595fb4e83ff0d4,supported)).
verdict(c_21595fb4e83ff0d4,refuted) :- node(n624,refuted).
query(verdict(c_21595fb4e83ff0d4,refuted)).
verdict(c_21595fb4e83ff0d4,unknown) :- node(n624,unknown).
query(verdict(c_21595fb4e83ff0d4,unknown)).
node(n631,supported) :- status(o_bb49dc57d836132fc296,supported).
node(n631,refuted) :- status(o_bb49dc57d836132fc296,refuted).
node(n631,unknown) :- status(o_bb49dc57d836132fc296,unknown).
node(n632,supported) :- status(o_82bbd48a4f6e398a8bed,supported).
node(n632,refuted) :- status(o_82bbd48a4f6e398a8bed,refuted).
node(n632,unknown) :- status(o_82bbd48a4f6e398a8bed,unknown).
node(n633,supported) :- status(o_a6eb05b59e76c238828f,supported).
node(n633,refuted) :- status(o_a6eb05b59e76c238828f,refuted).
node(n633,unknown) :- status(o_a6eb05b59e76c238828f,unknown).
node(n630,supported) :- node(n631,supported), node(n632,supported), node(n633,supported).
node(n630,refuted) :- node(n631,refuted).
node(n630,refuted) :- node(n632,refuted).
node(n630,refuted) :- node(n633,refuted).
node(n630,unknown) :- \+ node(n630,supported), \+ node(n630,refuted).
node(n635,supported) :- status(o_56c8a19be2e2f94458c5,supported).
node(n635,refuted) :- status(o_56c8a19be2e2f94458c5,refuted).
node(n635,unknown) :- status(o_56c8a19be2e2f94458c5,unknown).
node(n636,supported) :- status(o_e7b5c586b30afcfd1d19,supported).
node(n636,refuted) :- status(o_e7b5c586b30afcfd1d19,refuted).
node(n636,unknown) :- status(o_e7b5c586b30afcfd1d19,unknown).
node(n637,supported) :- status(o_93df643ed94feb17640f,supported).
node(n637,refuted) :- status(o_93df643ed94feb17640f,refuted).
node(n637,unknown) :- status(o_93df643ed94feb17640f,unknown).
node(n634,supported) :- node(n635,supported), node(n636,supported), node(n637,supported).
node(n634,refuted) :- node(n635,refuted).
node(n634,refuted) :- node(n636,refuted).
node(n634,refuted) :- node(n637,refuted).
node(n634,unknown) :- \+ node(n634,supported), \+ node(n634,refuted).
node(n629,refuted) :- node(n630,refuted), node(n634,refuted), node(n9,refuted).
node(n629,supported) :- node(n630,supported).
node(n629,supported) :- node(n634,supported).
node(n629,supported) :- node(n9,supported).
node(n629,unknown) :- \+ node(n629,supported), \+ node(n629,refuted).
verdict(c_727c957c387c7af1,supported) :- node(n629,supported).
query(verdict(c_727c957c387c7af1,supported)).
verdict(c_727c957c387c7af1,refuted) :- node(n629,refuted).
query(verdict(c_727c957c387c7af1,refuted)).
verdict(c_727c957c387c7af1,unknown) :- node(n629,unknown).
query(verdict(c_727c957c387c7af1,unknown)).
node(n640,supported) :- status(o_1624fef7be7b0edbb259,supported).
node(n640,refuted) :- status(o_1624fef7be7b0edbb259,refuted).
node(n640,unknown) :- status(o_1624fef7be7b0edbb259,unknown).
node(n639,supported) :- node(n631,supported), node(n632,supported), node(n640,supported), node(n633,supported).
node(n639,refuted) :- node(n631,refuted).
node(n639,refuted) :- node(n632,refuted).
node(n639,refuted) :- node(n640,refuted).
node(n639,refuted) :- node(n633,refuted).
node(n639,unknown) :- \+ node(n639,supported), \+ node(n639,refuted).
node(n642,supported) :- status(o_89606d816f92de7028e9,supported).
node(n642,refuted) :- status(o_89606d816f92de7028e9,refuted).
node(n642,unknown) :- status(o_89606d816f92de7028e9,unknown).
node(n641,supported) :- node(n635,supported), node(n636,supported), node(n642,supported), node(n637,supported).
node(n641,refuted) :- node(n635,refuted).
node(n641,refuted) :- node(n636,refuted).
node(n641,refuted) :- node(n642,refuted).
node(n641,refuted) :- node(n637,refuted).
node(n641,unknown) :- \+ node(n641,supported), \+ node(n641,refuted).
node(n638,refuted) :- node(n639,refuted), node(n641,refuted), node(n9,refuted).
node(n638,supported) :- node(n639,supported).
node(n638,supported) :- node(n641,supported).
node(n638,supported) :- node(n9,supported).
node(n638,unknown) :- \+ node(n638,supported), \+ node(n638,refuted).
verdict(c_02088e0161c6e062,supported) :- node(n638,supported).
query(verdict(c_02088e0161c6e062,supported)).
verdict(c_02088e0161c6e062,refuted) :- node(n638,refuted).
query(verdict(c_02088e0161c6e062,refuted)).
verdict(c_02088e0161c6e062,unknown) :- node(n638,unknown).
query(verdict(c_02088e0161c6e062,unknown)).
node(n645,supported) :- status(o_df2ca809d43f3f543a17,supported).
node(n645,refuted) :- status(o_df2ca809d43f3f543a17,refuted).
node(n645,unknown) :- status(o_df2ca809d43f3f543a17,unknown).
node(n646,supported) :- status(o_9801df7066ee4a3a7426,supported).
node(n646,refuted) :- status(o_9801df7066ee4a3a7426,refuted).
node(n646,unknown) :- status(o_9801df7066ee4a3a7426,unknown).
node(n647,supported) :- status(o_96bb13bf87d14c403272,supported).
node(n647,refuted) :- status(o_96bb13bf87d14c403272,refuted).
node(n647,unknown) :- status(o_96bb13bf87d14c403272,unknown).
node(n644,supported) :- node(n645,supported), node(n646,supported), node(n647,supported).
node(n644,refuted) :- node(n645,refuted).
node(n644,refuted) :- node(n646,refuted).
node(n644,refuted) :- node(n647,refuted).
node(n644,unknown) :- \+ node(n644,supported), \+ node(n644,refuted).
node(n649,supported) :- status(o_4cb9960ca7f0acce0bc5,supported).
node(n649,refuted) :- status(o_4cb9960ca7f0acce0bc5,refuted).
node(n649,unknown) :- status(o_4cb9960ca7f0acce0bc5,unknown).
node(n650,supported) :- status(o_2adf63f27b64168a71c8,supported).
node(n650,refuted) :- status(o_2adf63f27b64168a71c8,refuted).
node(n650,unknown) :- status(o_2adf63f27b64168a71c8,unknown).
node(n651,supported) :- status(o_8e1ae51055aca74517de,supported).
node(n651,refuted) :- status(o_8e1ae51055aca74517de,refuted).
node(n651,unknown) :- status(o_8e1ae51055aca74517de,unknown).
node(n648,supported) :- node(n649,supported), node(n650,supported), node(n651,supported).
node(n648,refuted) :- node(n649,refuted).
node(n648,refuted) :- node(n650,refuted).
node(n648,refuted) :- node(n651,refuted).
node(n648,unknown) :- \+ node(n648,supported), \+ node(n648,refuted).
node(n643,refuted) :- node(n644,refuted), node(n648,refuted), node(n9,refuted).
node(n643,supported) :- node(n644,supported).
node(n643,supported) :- node(n648,supported).
node(n643,supported) :- node(n9,supported).
node(n643,unknown) :- \+ node(n643,supported), \+ node(n643,refuted).
verdict(c_4b69b8ee072f15f2,supported) :- node(n643,supported).
query(verdict(c_4b69b8ee072f15f2,supported)).
verdict(c_4b69b8ee072f15f2,refuted) :- node(n643,refuted).
query(verdict(c_4b69b8ee072f15f2,refuted)).
verdict(c_4b69b8ee072f15f2,unknown) :- node(n643,unknown).
query(verdict(c_4b69b8ee072f15f2,unknown)).
node(n654,supported) :- status(o_aff7145314f3a0bd408c,supported).
node(n654,refuted) :- status(o_aff7145314f3a0bd408c,refuted).
node(n654,unknown) :- status(o_aff7145314f3a0bd408c,unknown).
node(n653,supported) :- node(n645,supported), node(n646,supported), node(n654,supported), node(n647,supported).
node(n653,refuted) :- node(n645,refuted).
node(n653,refuted) :- node(n646,refuted).
node(n653,refuted) :- node(n654,refuted).
node(n653,refuted) :- node(n647,refuted).
node(n653,unknown) :- \+ node(n653,supported), \+ node(n653,refuted).
node(n656,supported) :- status(o_96d6411a747075bc852a,supported).
node(n656,refuted) :- status(o_96d6411a747075bc852a,refuted).
node(n656,unknown) :- status(o_96d6411a747075bc852a,unknown).
node(n655,supported) :- node(n649,supported), node(n650,supported), node(n656,supported), node(n651,supported).
node(n655,refuted) :- node(n649,refuted).
node(n655,refuted) :- node(n650,refuted).
node(n655,refuted) :- node(n656,refuted).
node(n655,refuted) :- node(n651,refuted).
node(n655,unknown) :- \+ node(n655,supported), \+ node(n655,refuted).
node(n652,refuted) :- node(n653,refuted), node(n655,refuted), node(n9,refuted).
node(n652,supported) :- node(n653,supported).
node(n652,supported) :- node(n655,supported).
node(n652,supported) :- node(n9,supported).
node(n652,unknown) :- \+ node(n652,supported), \+ node(n652,refuted).
verdict(c_00f14b97b7831d5b,supported) :- node(n652,supported).
query(verdict(c_00f14b97b7831d5b,supported)).
verdict(c_00f14b97b7831d5b,refuted) :- node(n652,refuted).
query(verdict(c_00f14b97b7831d5b,refuted)).
verdict(c_00f14b97b7831d5b,unknown) :- node(n652,unknown).
query(verdict(c_00f14b97b7831d5b,unknown)).
node(n659,supported) :- status(o_9e7c08cf4d93d74ef9cc,supported).
node(n659,refuted) :- status(o_9e7c08cf4d93d74ef9cc,refuted).
node(n659,unknown) :- status(o_9e7c08cf4d93d74ef9cc,unknown).
node(n660,supported) :- status(o_d7fe0af95472039e1ba7,supported).
node(n660,refuted) :- status(o_d7fe0af95472039e1ba7,refuted).
node(n660,unknown) :- status(o_d7fe0af95472039e1ba7,unknown).
node(n661,supported) :- status(o_ac518f68b190c18d5168,supported).
node(n661,refuted) :- status(o_ac518f68b190c18d5168,refuted).
node(n661,unknown) :- status(o_ac518f68b190c18d5168,unknown).
node(n658,supported) :- node(n659,supported), node(n660,supported), node(n661,supported).
node(n658,refuted) :- node(n659,refuted).
node(n658,refuted) :- node(n660,refuted).
node(n658,refuted) :- node(n661,refuted).
node(n658,unknown) :- \+ node(n658,supported), \+ node(n658,refuted).
node(n663,supported) :- status(o_3b76e7cf5d023a1f892d,supported).
node(n663,refuted) :- status(o_3b76e7cf5d023a1f892d,refuted).
node(n663,unknown) :- status(o_3b76e7cf5d023a1f892d,unknown).
node(n664,supported) :- status(o_ef7885eff8b428b2d697,supported).
node(n664,refuted) :- status(o_ef7885eff8b428b2d697,refuted).
node(n664,unknown) :- status(o_ef7885eff8b428b2d697,unknown).
node(n665,supported) :- status(o_e2f6af634ca7716aa55e,supported).
node(n665,refuted) :- status(o_e2f6af634ca7716aa55e,refuted).
node(n665,unknown) :- status(o_e2f6af634ca7716aa55e,unknown).
node(n662,supported) :- node(n663,supported), node(n664,supported), node(n665,supported).
node(n662,refuted) :- node(n663,refuted).
node(n662,refuted) :- node(n664,refuted).
node(n662,refuted) :- node(n665,refuted).
node(n662,unknown) :- \+ node(n662,supported), \+ node(n662,refuted).
node(n657,refuted) :- node(n658,refuted), node(n662,refuted), node(n9,refuted).
node(n657,supported) :- node(n658,supported).
node(n657,supported) :- node(n662,supported).
node(n657,supported) :- node(n9,supported).
node(n657,unknown) :- \+ node(n657,supported), \+ node(n657,refuted).
verdict(c_321cc40ac4510b98,supported) :- node(n657,supported).
query(verdict(c_321cc40ac4510b98,supported)).
verdict(c_321cc40ac4510b98,refuted) :- node(n657,refuted).
query(verdict(c_321cc40ac4510b98,refuted)).
verdict(c_321cc40ac4510b98,unknown) :- node(n657,unknown).
query(verdict(c_321cc40ac4510b98,unknown)).
node(n668,supported) :- status(o_985e32de6cb09ac4b4a6,supported).
node(n668,refuted) :- status(o_985e32de6cb09ac4b4a6,refuted).
node(n668,unknown) :- status(o_985e32de6cb09ac4b4a6,unknown).
node(n667,supported) :- node(n659,supported), node(n660,supported), node(n668,supported), node(n661,supported).
node(n667,refuted) :- node(n659,refuted).
node(n667,refuted) :- node(n660,refuted).
node(n667,refuted) :- node(n668,refuted).
node(n667,refuted) :- node(n661,refuted).
node(n667,unknown) :- \+ node(n667,supported), \+ node(n667,refuted).
node(n670,supported) :- status(o_054020a30df144eed425,supported).
node(n670,refuted) :- status(o_054020a30df144eed425,refuted).
node(n670,unknown) :- status(o_054020a30df144eed425,unknown).
node(n669,supported) :- node(n663,supported), node(n664,supported), node(n670,supported), node(n665,supported).
node(n669,refuted) :- node(n663,refuted).
node(n669,refuted) :- node(n664,refuted).
node(n669,refuted) :- node(n670,refuted).
node(n669,refuted) :- node(n665,refuted).
node(n669,unknown) :- \+ node(n669,supported), \+ node(n669,refuted).
node(n666,refuted) :- node(n667,refuted), node(n669,refuted), node(n9,refuted).
node(n666,supported) :- node(n667,supported).
node(n666,supported) :- node(n669,supported).
node(n666,supported) :- node(n9,supported).
node(n666,unknown) :- \+ node(n666,supported), \+ node(n666,refuted).
verdict(c_4e41157d3c727f19,supported) :- node(n666,supported).
query(verdict(c_4e41157d3c727f19,supported)).
verdict(c_4e41157d3c727f19,refuted) :- node(n666,refuted).
query(verdict(c_4e41157d3c727f19,refuted)).
verdict(c_4e41157d3c727f19,unknown) :- node(n666,unknown).
query(verdict(c_4e41157d3c727f19,unknown)).
node(n673,supported) :- status(o_891f853b75118d720452,supported).
node(n673,refuted) :- status(o_891f853b75118d720452,refuted).
node(n673,unknown) :- status(o_891f853b75118d720452,unknown).
node(n674,supported) :- status(o_0840e73ef5e81b84dda9,supported).
node(n674,refuted) :- status(o_0840e73ef5e81b84dda9,refuted).
node(n674,unknown) :- status(o_0840e73ef5e81b84dda9,unknown).
node(n675,supported) :- status(o_811d64b45024ef9f452f,supported).
node(n675,refuted) :- status(o_811d64b45024ef9f452f,refuted).
node(n675,unknown) :- status(o_811d64b45024ef9f452f,unknown).
node(n672,supported) :- node(n673,supported), node(n674,supported), node(n675,supported).
node(n672,refuted) :- node(n673,refuted).
node(n672,refuted) :- node(n674,refuted).
node(n672,refuted) :- node(n675,refuted).
node(n672,unknown) :- \+ node(n672,supported), \+ node(n672,refuted).
node(n677,supported) :- status(o_ec10c7d9ea00d34b1091,supported).
node(n677,refuted) :- status(o_ec10c7d9ea00d34b1091,refuted).
node(n677,unknown) :- status(o_ec10c7d9ea00d34b1091,unknown).
node(n678,supported) :- status(o_b23002bbfbacc338f218,supported).
node(n678,refuted) :- status(o_b23002bbfbacc338f218,refuted).
node(n678,unknown) :- status(o_b23002bbfbacc338f218,unknown).
node(n679,supported) :- status(o_b0b4e1d706573255ed9a,supported).
node(n679,refuted) :- status(o_b0b4e1d706573255ed9a,refuted).
node(n679,unknown) :- status(o_b0b4e1d706573255ed9a,unknown).
node(n676,supported) :- node(n677,supported), node(n678,supported), node(n679,supported).
node(n676,refuted) :- node(n677,refuted).
node(n676,refuted) :- node(n678,refuted).
node(n676,refuted) :- node(n679,refuted).
node(n676,unknown) :- \+ node(n676,supported), \+ node(n676,refuted).
node(n671,refuted) :- node(n672,refuted), node(n676,refuted), node(n9,refuted).
node(n671,supported) :- node(n672,supported).
node(n671,supported) :- node(n676,supported).
node(n671,supported) :- node(n9,supported).
node(n671,unknown) :- \+ node(n671,supported), \+ node(n671,refuted).
verdict(c_05d39aba42f02296,supported) :- node(n671,supported).
query(verdict(c_05d39aba42f02296,supported)).
verdict(c_05d39aba42f02296,refuted) :- node(n671,refuted).
query(verdict(c_05d39aba42f02296,refuted)).
verdict(c_05d39aba42f02296,unknown) :- node(n671,unknown).
query(verdict(c_05d39aba42f02296,unknown)).
node(n682,supported) :- status(o_ef7fb64cd92c4d18ae36,supported).
node(n682,refuted) :- status(o_ef7fb64cd92c4d18ae36,refuted).
node(n682,unknown) :- status(o_ef7fb64cd92c4d18ae36,unknown).
node(n681,supported) :- node(n673,supported), node(n674,supported), node(n682,supported), node(n675,supported).
node(n681,refuted) :- node(n673,refuted).
node(n681,refuted) :- node(n674,refuted).
node(n681,refuted) :- node(n682,refuted).
node(n681,refuted) :- node(n675,refuted).
node(n681,unknown) :- \+ node(n681,supported), \+ node(n681,refuted).
node(n684,supported) :- status(o_5b7aa884b8d837f96d1e,supported).
node(n684,refuted) :- status(o_5b7aa884b8d837f96d1e,refuted).
node(n684,unknown) :- status(o_5b7aa884b8d837f96d1e,unknown).
node(n683,supported) :- node(n677,supported), node(n678,supported), node(n684,supported), node(n679,supported).
node(n683,refuted) :- node(n677,refuted).
node(n683,refuted) :- node(n678,refuted).
node(n683,refuted) :- node(n684,refuted).
node(n683,refuted) :- node(n679,refuted).
node(n683,unknown) :- \+ node(n683,supported), \+ node(n683,refuted).
node(n680,refuted) :- node(n681,refuted), node(n683,refuted), node(n9,refuted).
node(n680,supported) :- node(n681,supported).
node(n680,supported) :- node(n683,supported).
node(n680,supported) :- node(n9,supported).
node(n680,unknown) :- \+ node(n680,supported), \+ node(n680,refuted).
verdict(c_8bff82662505a560,supported) :- node(n680,supported).
query(verdict(c_8bff82662505a560,supported)).
verdict(c_8bff82662505a560,refuted) :- node(n680,refuted).
query(verdict(c_8bff82662505a560,refuted)).
verdict(c_8bff82662505a560,unknown) :- node(n680,unknown).
query(verdict(c_8bff82662505a560,unknown)).
node(n687,supported) :- status(o_56e59f114d85ccbf37b4,supported).
node(n687,refuted) :- status(o_56e59f114d85ccbf37b4,refuted).
node(n687,unknown) :- status(o_56e59f114d85ccbf37b4,unknown).
node(n688,supported) :- status(o_692fa001f5cd3238473a,supported).
node(n688,refuted) :- status(o_692fa001f5cd3238473a,refuted).
node(n688,unknown) :- status(o_692fa001f5cd3238473a,unknown).
node(n689,supported) :- status(o_292b1b88c95cdf4698b3,supported).
node(n689,refuted) :- status(o_292b1b88c95cdf4698b3,refuted).
node(n689,unknown) :- status(o_292b1b88c95cdf4698b3,unknown).
node(n686,supported) :- node(n687,supported), node(n688,supported), node(n689,supported).
node(n686,refuted) :- node(n687,refuted).
node(n686,refuted) :- node(n688,refuted).
node(n686,refuted) :- node(n689,refuted).
node(n686,unknown) :- \+ node(n686,supported), \+ node(n686,refuted).
node(n691,supported) :- status(o_9b0c16661c9475878347,supported).
node(n691,refuted) :- status(o_9b0c16661c9475878347,refuted).
node(n691,unknown) :- status(o_9b0c16661c9475878347,unknown).
node(n692,supported) :- status(o_ff2623d54849c287222a,supported).
node(n692,refuted) :- status(o_ff2623d54849c287222a,refuted).
node(n692,unknown) :- status(o_ff2623d54849c287222a,unknown).
node(n693,supported) :- status(o_5e2eb1f02e2acf62a86d,supported).
node(n693,refuted) :- status(o_5e2eb1f02e2acf62a86d,refuted).
node(n693,unknown) :- status(o_5e2eb1f02e2acf62a86d,unknown).
node(n690,supported) :- node(n691,supported), node(n692,supported), node(n693,supported).
node(n690,refuted) :- node(n691,refuted).
node(n690,refuted) :- node(n692,refuted).
node(n690,refuted) :- node(n693,refuted).
node(n690,unknown) :- \+ node(n690,supported), \+ node(n690,refuted).
node(n685,refuted) :- node(n686,refuted), node(n690,refuted), node(n9,refuted).
node(n685,supported) :- node(n686,supported).
node(n685,supported) :- node(n690,supported).
node(n685,supported) :- node(n9,supported).
node(n685,unknown) :- \+ node(n685,supported), \+ node(n685,refuted).
verdict(c_b19ec84d4be6573f,supported) :- node(n685,supported).
query(verdict(c_b19ec84d4be6573f,supported)).
verdict(c_b19ec84d4be6573f,refuted) :- node(n685,refuted).
query(verdict(c_b19ec84d4be6573f,refuted)).
verdict(c_b19ec84d4be6573f,unknown) :- node(n685,unknown).
query(verdict(c_b19ec84d4be6573f,unknown)).
node(n696,supported) :- status(o_270ed160e9bd874b468b,supported).
node(n696,refuted) :- status(o_270ed160e9bd874b468b,refuted).
node(n696,unknown) :- status(o_270ed160e9bd874b468b,unknown).
node(n695,supported) :- node(n687,supported), node(n688,supported), node(n696,supported), node(n689,supported).
node(n695,refuted) :- node(n687,refuted).
node(n695,refuted) :- node(n688,refuted).
node(n695,refuted) :- node(n696,refuted).
node(n695,refuted) :- node(n689,refuted).
node(n695,unknown) :- \+ node(n695,supported), \+ node(n695,refuted).
node(n698,supported) :- status(o_e49a41c70b393015e60d,supported).
node(n698,refuted) :- status(o_e49a41c70b393015e60d,refuted).
node(n698,unknown) :- status(o_e49a41c70b393015e60d,unknown).
node(n697,supported) :- node(n691,supported), node(n692,supported), node(n698,supported), node(n693,supported).
node(n697,refuted) :- node(n691,refuted).
node(n697,refuted) :- node(n692,refuted).
node(n697,refuted) :- node(n698,refuted).
node(n697,refuted) :- node(n693,refuted).
node(n697,unknown) :- \+ node(n697,supported), \+ node(n697,refuted).
node(n694,refuted) :- node(n695,refuted), node(n697,refuted), node(n9,refuted).
node(n694,supported) :- node(n695,supported).
node(n694,supported) :- node(n697,supported).
node(n694,supported) :- node(n9,supported).
node(n694,unknown) :- \+ node(n694,supported), \+ node(n694,refuted).
verdict(c_26c3b7d2f4e3929f,supported) :- node(n694,supported).
query(verdict(c_26c3b7d2f4e3929f,supported)).
verdict(c_26c3b7d2f4e3929f,refuted) :- node(n694,refuted).
query(verdict(c_26c3b7d2f4e3929f,refuted)).
verdict(c_26c3b7d2f4e3929f,unknown) :- node(n694,unknown).
query(verdict(c_26c3b7d2f4e3929f,unknown)).
node(n701,supported) :- status(o_dd43f8151dffbd339330,supported).
node(n701,refuted) :- status(o_dd43f8151dffbd339330,refuted).
node(n701,unknown) :- status(o_dd43f8151dffbd339330,unknown).
node(n702,supported) :- status(o_05ca39bf601f27f4c89d,supported).
node(n702,refuted) :- status(o_05ca39bf601f27f4c89d,refuted).
node(n702,unknown) :- status(o_05ca39bf601f27f4c89d,unknown).
node(n703,supported) :- status(o_f43886f6e888ee0f00d8,supported).
node(n703,refuted) :- status(o_f43886f6e888ee0f00d8,refuted).
node(n703,unknown) :- status(o_f43886f6e888ee0f00d8,unknown).
node(n700,supported) :- node(n701,supported), node(n702,supported), node(n703,supported).
node(n700,refuted) :- node(n701,refuted).
node(n700,refuted) :- node(n702,refuted).
node(n700,refuted) :- node(n703,refuted).
node(n700,unknown) :- \+ node(n700,supported), \+ node(n700,refuted).
node(n705,supported) :- status(o_393a2f8651fb79da30b6,supported).
node(n705,refuted) :- status(o_393a2f8651fb79da30b6,refuted).
node(n705,unknown) :- status(o_393a2f8651fb79da30b6,unknown).
node(n706,supported) :- status(o_91a56628d4ea87c285c2,supported).
node(n706,refuted) :- status(o_91a56628d4ea87c285c2,refuted).
node(n706,unknown) :- status(o_91a56628d4ea87c285c2,unknown).
node(n707,supported) :- status(o_58f7cac111d9e7143035,supported).
node(n707,refuted) :- status(o_58f7cac111d9e7143035,refuted).
node(n707,unknown) :- status(o_58f7cac111d9e7143035,unknown).
node(n704,supported) :- node(n705,supported), node(n706,supported), node(n707,supported).
node(n704,refuted) :- node(n705,refuted).
node(n704,refuted) :- node(n706,refuted).
node(n704,refuted) :- node(n707,refuted).
node(n704,unknown) :- \+ node(n704,supported), \+ node(n704,refuted).
node(n699,refuted) :- node(n700,refuted), node(n704,refuted), node(n9,refuted).
node(n699,supported) :- node(n700,supported).
node(n699,supported) :- node(n704,supported).
node(n699,supported) :- node(n9,supported).
node(n699,unknown) :- \+ node(n699,supported), \+ node(n699,refuted).
verdict(c_58fe34168c5edf9f,supported) :- node(n699,supported).
query(verdict(c_58fe34168c5edf9f,supported)).
verdict(c_58fe34168c5edf9f,refuted) :- node(n699,refuted).
query(verdict(c_58fe34168c5edf9f,refuted)).
verdict(c_58fe34168c5edf9f,unknown) :- node(n699,unknown).
query(verdict(c_58fe34168c5edf9f,unknown)).
node(n710,supported) :- status(o_e8f8c017864896cc65b9,supported).
node(n710,refuted) :- status(o_e8f8c017864896cc65b9,refuted).
node(n710,unknown) :- status(o_e8f8c017864896cc65b9,unknown).
node(n709,supported) :- node(n701,supported), node(n702,supported), node(n710,supported), node(n703,supported).
node(n709,refuted) :- node(n701,refuted).
node(n709,refuted) :- node(n702,refuted).
node(n709,refuted) :- node(n710,refuted).
node(n709,refuted) :- node(n703,refuted).
node(n709,unknown) :- \+ node(n709,supported), \+ node(n709,refuted).
node(n712,supported) :- status(o_f6120257f80dd19de44a,supported).
node(n712,refuted) :- status(o_f6120257f80dd19de44a,refuted).
node(n712,unknown) :- status(o_f6120257f80dd19de44a,unknown).
node(n711,supported) :- node(n705,supported), node(n706,supported), node(n712,supported), node(n707,supported).
node(n711,refuted) :- node(n705,refuted).
node(n711,refuted) :- node(n706,refuted).
node(n711,refuted) :- node(n712,refuted).
node(n711,refuted) :- node(n707,refuted).
node(n711,unknown) :- \+ node(n711,supported), \+ node(n711,refuted).
node(n708,refuted) :- node(n709,refuted), node(n711,refuted), node(n9,refuted).
node(n708,supported) :- node(n709,supported).
node(n708,supported) :- node(n711,supported).
node(n708,supported) :- node(n9,supported).
node(n708,unknown) :- \+ node(n708,supported), \+ node(n708,refuted).
verdict(c_7a6407616ac83173,supported) :- node(n708,supported).
query(verdict(c_7a6407616ac83173,supported)).
verdict(c_7a6407616ac83173,refuted) :- node(n708,refuted).
query(verdict(c_7a6407616ac83173,refuted)).
verdict(c_7a6407616ac83173,unknown) :- node(n708,unknown).
query(verdict(c_7a6407616ac83173,unknown)).
node(n715,supported) :- status(o_dcece1f5b9ad4d232de0,supported).
node(n715,refuted) :- status(o_dcece1f5b9ad4d232de0,refuted).
node(n715,unknown) :- status(o_dcece1f5b9ad4d232de0,unknown).
node(n716,supported) :- status(o_019d3c007e49851e214c,supported).
node(n716,refuted) :- status(o_019d3c007e49851e214c,refuted).
node(n716,unknown) :- status(o_019d3c007e49851e214c,unknown).
node(n717,supported) :- status(o_dfd008e29d5ac0f1031a,supported).
node(n717,refuted) :- status(o_dfd008e29d5ac0f1031a,refuted).
node(n717,unknown) :- status(o_dfd008e29d5ac0f1031a,unknown).
node(n714,supported) :- node(n715,supported), node(n716,supported), node(n717,supported).
node(n714,refuted) :- node(n715,refuted).
node(n714,refuted) :- node(n716,refuted).
node(n714,refuted) :- node(n717,refuted).
node(n714,unknown) :- \+ node(n714,supported), \+ node(n714,refuted).
node(n719,supported) :- status(o_e87315b464b1c5f30512,supported).
node(n719,refuted) :- status(o_e87315b464b1c5f30512,refuted).
node(n719,unknown) :- status(o_e87315b464b1c5f30512,unknown).
node(n720,supported) :- status(o_fdaed9c3037474490813,supported).
node(n720,refuted) :- status(o_fdaed9c3037474490813,refuted).
node(n720,unknown) :- status(o_fdaed9c3037474490813,unknown).
node(n721,supported) :- status(o_8b2e8ab5d0ad3a3f0943,supported).
node(n721,refuted) :- status(o_8b2e8ab5d0ad3a3f0943,refuted).
node(n721,unknown) :- status(o_8b2e8ab5d0ad3a3f0943,unknown).
node(n718,supported) :- node(n719,supported), node(n720,supported), node(n721,supported).
node(n718,refuted) :- node(n719,refuted).
node(n718,refuted) :- node(n720,refuted).
node(n718,refuted) :- node(n721,refuted).
node(n718,unknown) :- \+ node(n718,supported), \+ node(n718,refuted).
node(n713,refuted) :- node(n714,refuted), node(n718,refuted), node(n9,refuted).
node(n713,supported) :- node(n714,supported).
node(n713,supported) :- node(n718,supported).
node(n713,supported) :- node(n9,supported).
node(n713,unknown) :- \+ node(n713,supported), \+ node(n713,refuted).
verdict(c_63eb6c0ebe1759aa,supported) :- node(n713,supported).
query(verdict(c_63eb6c0ebe1759aa,supported)).
verdict(c_63eb6c0ebe1759aa,refuted) :- node(n713,refuted).
query(verdict(c_63eb6c0ebe1759aa,refuted)).
verdict(c_63eb6c0ebe1759aa,unknown) :- node(n713,unknown).
query(verdict(c_63eb6c0ebe1759aa,unknown)).
node(n724,supported) :- status(o_9c996d0d25ffc6722380,supported).
node(n724,refuted) :- status(o_9c996d0d25ffc6722380,refuted).
node(n724,unknown) :- status(o_9c996d0d25ffc6722380,unknown).
node(n723,supported) :- node(n715,supported), node(n716,supported), node(n724,supported), node(n717,supported).
node(n723,refuted) :- node(n715,refuted).
node(n723,refuted) :- node(n716,refuted).
node(n723,refuted) :- node(n724,refuted).
node(n723,refuted) :- node(n717,refuted).
node(n723,unknown) :- \+ node(n723,supported), \+ node(n723,refuted).
node(n726,supported) :- status(o_c1e22e1d7ebd0e67f386,supported).
node(n726,refuted) :- status(o_c1e22e1d7ebd0e67f386,refuted).
node(n726,unknown) :- status(o_c1e22e1d7ebd0e67f386,unknown).
node(n725,supported) :- node(n719,supported), node(n720,supported), node(n726,supported), node(n721,supported).
node(n725,refuted) :- node(n719,refuted).
node(n725,refuted) :- node(n720,refuted).
node(n725,refuted) :- node(n726,refuted).
node(n725,refuted) :- node(n721,refuted).
node(n725,unknown) :- \+ node(n725,supported), \+ node(n725,refuted).
node(n722,refuted) :- node(n723,refuted), node(n725,refuted), node(n9,refuted).
node(n722,supported) :- node(n723,supported).
node(n722,supported) :- node(n725,supported).
node(n722,supported) :- node(n9,supported).
node(n722,unknown) :- \+ node(n722,supported), \+ node(n722,refuted).
verdict(c_c9ce644448bf43b4,supported) :- node(n722,supported).
query(verdict(c_c9ce644448bf43b4,supported)).
verdict(c_c9ce644448bf43b4,refuted) :- node(n722,refuted).
query(verdict(c_c9ce644448bf43b4,refuted)).
verdict(c_c9ce644448bf43b4,unknown) :- node(n722,unknown).
query(verdict(c_c9ce644448bf43b4,unknown)).
node(n729,supported) :- status(o_2dea827bf24c4381a852,supported).
node(n729,refuted) :- status(o_2dea827bf24c4381a852,refuted).
node(n729,unknown) :- status(o_2dea827bf24c4381a852,unknown).
node(n730,supported) :- status(o_5c97404ff56f4d21cb80,supported).
node(n730,refuted) :- status(o_5c97404ff56f4d21cb80,refuted).
node(n730,unknown) :- status(o_5c97404ff56f4d21cb80,unknown).
node(n731,supported) :- status(o_8d7cfa0bd427541098c4,supported).
node(n731,refuted) :- status(o_8d7cfa0bd427541098c4,refuted).
node(n731,unknown) :- status(o_8d7cfa0bd427541098c4,unknown).
node(n728,supported) :- node(n729,supported), node(n730,supported), node(n731,supported).
node(n728,refuted) :- node(n729,refuted).
node(n728,refuted) :- node(n730,refuted).
node(n728,refuted) :- node(n731,refuted).
node(n728,unknown) :- \+ node(n728,supported), \+ node(n728,refuted).
node(n733,supported) :- status(o_d3d1a29250e46709b864,supported).
node(n733,refuted) :- status(o_d3d1a29250e46709b864,refuted).
node(n733,unknown) :- status(o_d3d1a29250e46709b864,unknown).
node(n734,supported) :- status(o_b6a76ea1b5aba1fd50cb,supported).
node(n734,refuted) :- status(o_b6a76ea1b5aba1fd50cb,refuted).
node(n734,unknown) :- status(o_b6a76ea1b5aba1fd50cb,unknown).
node(n735,supported) :- status(o_f603fce5a2b3ed37902a,supported).
node(n735,refuted) :- status(o_f603fce5a2b3ed37902a,refuted).
node(n735,unknown) :- status(o_f603fce5a2b3ed37902a,unknown).
node(n732,supported) :- node(n733,supported), node(n734,supported), node(n735,supported).
node(n732,refuted) :- node(n733,refuted).
node(n732,refuted) :- node(n734,refuted).
node(n732,refuted) :- node(n735,refuted).
node(n732,unknown) :- \+ node(n732,supported), \+ node(n732,refuted).
node(n727,refuted) :- node(n728,refuted), node(n732,refuted), node(n9,refuted).
node(n727,supported) :- node(n728,supported).
node(n727,supported) :- node(n732,supported).
node(n727,supported) :- node(n9,supported).
node(n727,unknown) :- \+ node(n727,supported), \+ node(n727,refuted).
verdict(c_701883fdaf7a7185,supported) :- node(n727,supported).
query(verdict(c_701883fdaf7a7185,supported)).
verdict(c_701883fdaf7a7185,refuted) :- node(n727,refuted).
query(verdict(c_701883fdaf7a7185,refuted)).
verdict(c_701883fdaf7a7185,unknown) :- node(n727,unknown).
query(verdict(c_701883fdaf7a7185,unknown)).
node(n738,supported) :- status(o_4d25c3dbaf34ec623f52,supported).
node(n738,refuted) :- status(o_4d25c3dbaf34ec623f52,refuted).
node(n738,unknown) :- status(o_4d25c3dbaf34ec623f52,unknown).
node(n737,supported) :- node(n729,supported), node(n730,supported), node(n738,supported), node(n731,supported).
node(n737,refuted) :- node(n729,refuted).
node(n737,refuted) :- node(n730,refuted).
node(n737,refuted) :- node(n738,refuted).
node(n737,refuted) :- node(n731,refuted).
node(n737,unknown) :- \+ node(n737,supported), \+ node(n737,refuted).
node(n740,supported) :- status(o_49424336ff3d6fa1e5a2,supported).
node(n740,refuted) :- status(o_49424336ff3d6fa1e5a2,refuted).
node(n740,unknown) :- status(o_49424336ff3d6fa1e5a2,unknown).
node(n739,supported) :- node(n733,supported), node(n734,supported), node(n740,supported), node(n735,supported).
node(n739,refuted) :- node(n733,refuted).
node(n739,refuted) :- node(n734,refuted).
node(n739,refuted) :- node(n740,refuted).
node(n739,refuted) :- node(n735,refuted).
node(n739,unknown) :- \+ node(n739,supported), \+ node(n739,refuted).
node(n736,refuted) :- node(n737,refuted), node(n739,refuted), node(n9,refuted).
node(n736,supported) :- node(n737,supported).
node(n736,supported) :- node(n739,supported).
node(n736,supported) :- node(n9,supported).
node(n736,unknown) :- \+ node(n736,supported), \+ node(n736,refuted).
verdict(c_7872468979dd4f19,supported) :- node(n736,supported).
query(verdict(c_7872468979dd4f19,supported)).
verdict(c_7872468979dd4f19,refuted) :- node(n736,refuted).
query(verdict(c_7872468979dd4f19,refuted)).
verdict(c_7872468979dd4f19,unknown) :- node(n736,unknown).
query(verdict(c_7872468979dd4f19,unknown)).
node(n743,supported) :- status(o_f790596b85b8ff79e38c,supported).
node(n743,refuted) :- status(o_f790596b85b8ff79e38c,refuted).
node(n743,unknown) :- status(o_f790596b85b8ff79e38c,unknown).
node(n744,supported) :- status(o_a63bf7070875552f6d21,supported).
node(n744,refuted) :- status(o_a63bf7070875552f6d21,refuted).
node(n744,unknown) :- status(o_a63bf7070875552f6d21,unknown).
node(n745,supported) :- status(o_fb303ae9a5163291104d,supported).
node(n745,refuted) :- status(o_fb303ae9a5163291104d,refuted).
node(n745,unknown) :- status(o_fb303ae9a5163291104d,unknown).
node(n742,supported) :- node(n743,supported), node(n744,supported), node(n745,supported).
node(n742,refuted) :- node(n743,refuted).
node(n742,refuted) :- node(n744,refuted).
node(n742,refuted) :- node(n745,refuted).
node(n742,unknown) :- \+ node(n742,supported), \+ node(n742,refuted).
node(n747,supported) :- status(o_2a8d799d7c3ff2741d63,supported).
node(n747,refuted) :- status(o_2a8d799d7c3ff2741d63,refuted).
node(n747,unknown) :- status(o_2a8d799d7c3ff2741d63,unknown).
node(n748,supported) :- status(o_8ad74737af466d05ed74,supported).
node(n748,refuted) :- status(o_8ad74737af466d05ed74,refuted).
node(n748,unknown) :- status(o_8ad74737af466d05ed74,unknown).
node(n749,supported) :- status(o_ca1896a556f8b59513a9,supported).
node(n749,refuted) :- status(o_ca1896a556f8b59513a9,refuted).
node(n749,unknown) :- status(o_ca1896a556f8b59513a9,unknown).
node(n746,supported) :- node(n747,supported), node(n748,supported), node(n749,supported).
node(n746,refuted) :- node(n747,refuted).
node(n746,refuted) :- node(n748,refuted).
node(n746,refuted) :- node(n749,refuted).
node(n746,unknown) :- \+ node(n746,supported), \+ node(n746,refuted).
node(n741,refuted) :- node(n742,refuted), node(n746,refuted), node(n9,refuted).
node(n741,supported) :- node(n742,supported).
node(n741,supported) :- node(n746,supported).
node(n741,supported) :- node(n9,supported).
node(n741,unknown) :- \+ node(n741,supported), \+ node(n741,refuted).
verdict(c_8d8cf0d9a33a520a,supported) :- node(n741,supported).
query(verdict(c_8d8cf0d9a33a520a,supported)).
verdict(c_8d8cf0d9a33a520a,refuted) :- node(n741,refuted).
query(verdict(c_8d8cf0d9a33a520a,refuted)).
verdict(c_8d8cf0d9a33a520a,unknown) :- node(n741,unknown).
query(verdict(c_8d8cf0d9a33a520a,unknown)).
node(n752,supported) :- status(o_a847bc5016b667b9083c,supported).
node(n752,refuted) :- status(o_a847bc5016b667b9083c,refuted).
node(n752,unknown) :- status(o_a847bc5016b667b9083c,unknown).
node(n751,supported) :- node(n743,supported), node(n744,supported), node(n752,supported), node(n745,supported).
node(n751,refuted) :- node(n743,refuted).
node(n751,refuted) :- node(n744,refuted).
node(n751,refuted) :- node(n752,refuted).
node(n751,refuted) :- node(n745,refuted).
node(n751,unknown) :- \+ node(n751,supported), \+ node(n751,refuted).
node(n754,supported) :- status(o_01b9c045b65ad2a7db10,supported).
node(n754,refuted) :- status(o_01b9c045b65ad2a7db10,refuted).
node(n754,unknown) :- status(o_01b9c045b65ad2a7db10,unknown).
node(n753,supported) :- node(n747,supported), node(n748,supported), node(n754,supported), node(n749,supported).
node(n753,refuted) :- node(n747,refuted).
node(n753,refuted) :- node(n748,refuted).
node(n753,refuted) :- node(n754,refuted).
node(n753,refuted) :- node(n749,refuted).
node(n753,unknown) :- \+ node(n753,supported), \+ node(n753,refuted).
node(n750,refuted) :- node(n751,refuted), node(n753,refuted), node(n9,refuted).
node(n750,supported) :- node(n751,supported).
node(n750,supported) :- node(n753,supported).
node(n750,supported) :- node(n9,supported).
node(n750,unknown) :- \+ node(n750,supported), \+ node(n750,refuted).
verdict(c_0f43d7038c160121,supported) :- node(n750,supported).
query(verdict(c_0f43d7038c160121,supported)).
verdict(c_0f43d7038c160121,refuted) :- node(n750,refuted).
query(verdict(c_0f43d7038c160121,refuted)).
verdict(c_0f43d7038c160121,unknown) :- node(n750,unknown).
query(verdict(c_0f43d7038c160121,unknown)).
node(n757,supported) :- status(o_8c2d7715ca2f3bb57ae1,supported).
node(n757,refuted) :- status(o_8c2d7715ca2f3bb57ae1,refuted).
node(n757,unknown) :- status(o_8c2d7715ca2f3bb57ae1,unknown).
node(n758,supported) :- status(o_8c702a2a68f06f9afbd0,supported).
node(n758,refuted) :- status(o_8c702a2a68f06f9afbd0,refuted).
node(n758,unknown) :- status(o_8c702a2a68f06f9afbd0,unknown).
node(n759,supported) :- status(o_44a21853ef99f1124603,supported).
node(n759,refuted) :- status(o_44a21853ef99f1124603,refuted).
node(n759,unknown) :- status(o_44a21853ef99f1124603,unknown).
node(n756,supported) :- node(n757,supported), node(n758,supported), node(n759,supported).
node(n756,refuted) :- node(n757,refuted).
node(n756,refuted) :- node(n758,refuted).
node(n756,refuted) :- node(n759,refuted).
node(n756,unknown) :- \+ node(n756,supported), \+ node(n756,refuted).
node(n761,supported) :- status(o_faa3fd928be9cc6fff93,supported).
node(n761,refuted) :- status(o_faa3fd928be9cc6fff93,refuted).
node(n761,unknown) :- status(o_faa3fd928be9cc6fff93,unknown).
node(n762,supported) :- status(o_7552674d7b6e1516e358,supported).
node(n762,refuted) :- status(o_7552674d7b6e1516e358,refuted).
node(n762,unknown) :- status(o_7552674d7b6e1516e358,unknown).
node(n763,supported) :- status(o_90216118768ee53261e7,supported).
node(n763,refuted) :- status(o_90216118768ee53261e7,refuted).
node(n763,unknown) :- status(o_90216118768ee53261e7,unknown).
node(n760,supported) :- node(n761,supported), node(n762,supported), node(n763,supported).
node(n760,refuted) :- node(n761,refuted).
node(n760,refuted) :- node(n762,refuted).
node(n760,refuted) :- node(n763,refuted).
node(n760,unknown) :- \+ node(n760,supported), \+ node(n760,refuted).
node(n755,refuted) :- node(n756,refuted), node(n760,refuted), node(n9,refuted).
node(n755,supported) :- node(n756,supported).
node(n755,supported) :- node(n760,supported).
node(n755,supported) :- node(n9,supported).
node(n755,unknown) :- \+ node(n755,supported), \+ node(n755,refuted).
verdict(c_1cb1e82e82577d2d,supported) :- node(n755,supported).
query(verdict(c_1cb1e82e82577d2d,supported)).
verdict(c_1cb1e82e82577d2d,refuted) :- node(n755,refuted).
query(verdict(c_1cb1e82e82577d2d,refuted)).
verdict(c_1cb1e82e82577d2d,unknown) :- node(n755,unknown).
query(verdict(c_1cb1e82e82577d2d,unknown)).
node(n766,supported) :- status(o_56ad42ee0b74ed3afa7b,supported).
node(n766,refuted) :- status(o_56ad42ee0b74ed3afa7b,refuted).
node(n766,unknown) :- status(o_56ad42ee0b74ed3afa7b,unknown).
node(n765,supported) :- node(n757,supported), node(n758,supported), node(n766,supported), node(n759,supported).
node(n765,refuted) :- node(n757,refuted).
node(n765,refuted) :- node(n758,refuted).
node(n765,refuted) :- node(n766,refuted).
node(n765,refuted) :- node(n759,refuted).
node(n765,unknown) :- \+ node(n765,supported), \+ node(n765,refuted).
node(n768,supported) :- status(o_8a8d039de2ae895fabc3,supported).
node(n768,refuted) :- status(o_8a8d039de2ae895fabc3,refuted).
node(n768,unknown) :- status(o_8a8d039de2ae895fabc3,unknown).
node(n767,supported) :- node(n761,supported), node(n762,supported), node(n768,supported), node(n763,supported).
node(n767,refuted) :- node(n761,refuted).
node(n767,refuted) :- node(n762,refuted).
node(n767,refuted) :- node(n768,refuted).
node(n767,refuted) :- node(n763,refuted).
node(n767,unknown) :- \+ node(n767,supported), \+ node(n767,refuted).
node(n764,refuted) :- node(n765,refuted), node(n767,refuted), node(n9,refuted).
node(n764,supported) :- node(n765,supported).
node(n764,supported) :- node(n767,supported).
node(n764,supported) :- node(n9,supported).
node(n764,unknown) :- \+ node(n764,supported), \+ node(n764,refuted).
verdict(c_bf0e35b0c4aedc18,supported) :- node(n764,supported).
query(verdict(c_bf0e35b0c4aedc18,supported)).
verdict(c_bf0e35b0c4aedc18,refuted) :- node(n764,refuted).
query(verdict(c_bf0e35b0c4aedc18,refuted)).
verdict(c_bf0e35b0c4aedc18,unknown) :- node(n764,unknown).
query(verdict(c_bf0e35b0c4aedc18,unknown)).
node(n771,supported) :- status(o_8c0e46800b777240f572,supported).
node(n771,refuted) :- status(o_8c0e46800b777240f572,refuted).
node(n771,unknown) :- status(o_8c0e46800b777240f572,unknown).
node(n772,supported) :- status(o_899f6d1e9971d66ff22a,supported).
node(n772,refuted) :- status(o_899f6d1e9971d66ff22a,refuted).
node(n772,unknown) :- status(o_899f6d1e9971d66ff22a,unknown).
node(n773,supported) :- status(o_e2676468acc3c8837c8d,supported).
node(n773,refuted) :- status(o_e2676468acc3c8837c8d,refuted).
node(n773,unknown) :- status(o_e2676468acc3c8837c8d,unknown).
node(n770,supported) :- node(n771,supported), node(n772,supported), node(n773,supported).
node(n770,refuted) :- node(n771,refuted).
node(n770,refuted) :- node(n772,refuted).
node(n770,refuted) :- node(n773,refuted).
node(n770,unknown) :- \+ node(n770,supported), \+ node(n770,refuted).
node(n775,supported) :- status(o_8170d8aba1e36f3532f4,supported).
node(n775,refuted) :- status(o_8170d8aba1e36f3532f4,refuted).
node(n775,unknown) :- status(o_8170d8aba1e36f3532f4,unknown).
node(n776,supported) :- status(o_d1e1786c6ec431dc8eab,supported).
node(n776,refuted) :- status(o_d1e1786c6ec431dc8eab,refuted).
node(n776,unknown) :- status(o_d1e1786c6ec431dc8eab,unknown).
node(n777,supported) :- status(o_765c3babdecde637c01f,supported).
node(n777,refuted) :- status(o_765c3babdecde637c01f,refuted).
node(n777,unknown) :- status(o_765c3babdecde637c01f,unknown).
node(n774,supported) :- node(n775,supported), node(n776,supported), node(n777,supported).
node(n774,refuted) :- node(n775,refuted).
node(n774,refuted) :- node(n776,refuted).
node(n774,refuted) :- node(n777,refuted).
node(n774,unknown) :- \+ node(n774,supported), \+ node(n774,refuted).
node(n769,refuted) :- node(n770,refuted), node(n774,refuted), node(n9,refuted).
node(n769,supported) :- node(n770,supported).
node(n769,supported) :- node(n774,supported).
node(n769,supported) :- node(n9,supported).
node(n769,unknown) :- \+ node(n769,supported), \+ node(n769,refuted).
verdict(c_6821ebf78a2860b0,supported) :- node(n769,supported).
query(verdict(c_6821ebf78a2860b0,supported)).
verdict(c_6821ebf78a2860b0,refuted) :- node(n769,refuted).
query(verdict(c_6821ebf78a2860b0,refuted)).
verdict(c_6821ebf78a2860b0,unknown) :- node(n769,unknown).
query(verdict(c_6821ebf78a2860b0,unknown)).
node(n780,supported) :- status(o_d0ebebdbd3b10f345c66,supported).
node(n780,refuted) :- status(o_d0ebebdbd3b10f345c66,refuted).
node(n780,unknown) :- status(o_d0ebebdbd3b10f345c66,unknown).
node(n779,supported) :- node(n771,supported), node(n772,supported), node(n780,supported), node(n773,supported).
node(n779,refuted) :- node(n771,refuted).
node(n779,refuted) :- node(n772,refuted).
node(n779,refuted) :- node(n780,refuted).
node(n779,refuted) :- node(n773,refuted).
node(n779,unknown) :- \+ node(n779,supported), \+ node(n779,refuted).
node(n782,supported) :- status(o_60cd1e3d78ad39dacf25,supported).
node(n782,refuted) :- status(o_60cd1e3d78ad39dacf25,refuted).
node(n782,unknown) :- status(o_60cd1e3d78ad39dacf25,unknown).
node(n781,supported) :- node(n775,supported), node(n776,supported), node(n782,supported), node(n777,supported).
node(n781,refuted) :- node(n775,refuted).
node(n781,refuted) :- node(n776,refuted).
node(n781,refuted) :- node(n782,refuted).
node(n781,refuted) :- node(n777,refuted).
node(n781,unknown) :- \+ node(n781,supported), \+ node(n781,refuted).
node(n778,refuted) :- node(n779,refuted), node(n781,refuted), node(n9,refuted).
node(n778,supported) :- node(n779,supported).
node(n778,supported) :- node(n781,supported).
node(n778,supported) :- node(n9,supported).
node(n778,unknown) :- \+ node(n778,supported), \+ node(n778,refuted).
verdict(c_f6f7192231dd7018,supported) :- node(n778,supported).
query(verdict(c_f6f7192231dd7018,supported)).
verdict(c_f6f7192231dd7018,refuted) :- node(n778,refuted).
query(verdict(c_f6f7192231dd7018,refuted)).
verdict(c_f6f7192231dd7018,unknown) :- node(n778,unknown).
query(verdict(c_f6f7192231dd7018,unknown)).
node(n785,supported) :- status(o_d2d85c7e4cab2bfa8055,supported).
node(n785,refuted) :- status(o_d2d85c7e4cab2bfa8055,refuted).
node(n785,unknown) :- status(o_d2d85c7e4cab2bfa8055,unknown).
node(n786,supported) :- status(o_4d736a643b5273861977,supported).
node(n786,refuted) :- status(o_4d736a643b5273861977,refuted).
node(n786,unknown) :- status(o_4d736a643b5273861977,unknown).
node(n787,supported) :- status(o_285f931438bbb688b6dd,supported).
node(n787,refuted) :- status(o_285f931438bbb688b6dd,refuted).
node(n787,unknown) :- status(o_285f931438bbb688b6dd,unknown).
node(n784,supported) :- node(n785,supported), node(n786,supported), node(n787,supported).
node(n784,refuted) :- node(n785,refuted).
node(n784,refuted) :- node(n786,refuted).
node(n784,refuted) :- node(n787,refuted).
node(n784,unknown) :- \+ node(n784,supported), \+ node(n784,refuted).
node(n789,supported) :- status(o_edcc957c1a724bfff80c,supported).
node(n789,refuted) :- status(o_edcc957c1a724bfff80c,refuted).
node(n789,unknown) :- status(o_edcc957c1a724bfff80c,unknown).
node(n790,supported) :- status(o_55b6ef454f27363f3017,supported).
node(n790,refuted) :- status(o_55b6ef454f27363f3017,refuted).
node(n790,unknown) :- status(o_55b6ef454f27363f3017,unknown).
node(n791,supported) :- status(o_54747b64333c8705917b,supported).
node(n791,refuted) :- status(o_54747b64333c8705917b,refuted).
node(n791,unknown) :- status(o_54747b64333c8705917b,unknown).
node(n788,supported) :- node(n789,supported), node(n790,supported), node(n791,supported).
node(n788,refuted) :- node(n789,refuted).
node(n788,refuted) :- node(n790,refuted).
node(n788,refuted) :- node(n791,refuted).
node(n788,unknown) :- \+ node(n788,supported), \+ node(n788,refuted).
node(n783,refuted) :- node(n784,refuted), node(n788,refuted), node(n9,refuted).
node(n783,supported) :- node(n784,supported).
node(n783,supported) :- node(n788,supported).
node(n783,supported) :- node(n9,supported).
node(n783,unknown) :- \+ node(n783,supported), \+ node(n783,refuted).
verdict(c_9e9827c459d1d489,supported) :- node(n783,supported).
query(verdict(c_9e9827c459d1d489,supported)).
verdict(c_9e9827c459d1d489,refuted) :- node(n783,refuted).
query(verdict(c_9e9827c459d1d489,refuted)).
verdict(c_9e9827c459d1d489,unknown) :- node(n783,unknown).
query(verdict(c_9e9827c459d1d489,unknown)).
node(n794,supported) :- status(o_b1cbcc15186303e65d12,supported).
node(n794,refuted) :- status(o_b1cbcc15186303e65d12,refuted).
node(n794,unknown) :- status(o_b1cbcc15186303e65d12,unknown).
node(n793,supported) :- node(n785,supported), node(n786,supported), node(n794,supported), node(n787,supported).
node(n793,refuted) :- node(n785,refuted).
node(n793,refuted) :- node(n786,refuted).
node(n793,refuted) :- node(n794,refuted).
node(n793,refuted) :- node(n787,refuted).
node(n793,unknown) :- \+ node(n793,supported), \+ node(n793,refuted).
node(n796,supported) :- status(o_f3ba6319577988a5eec0,supported).
node(n796,refuted) :- status(o_f3ba6319577988a5eec0,refuted).
node(n796,unknown) :- status(o_f3ba6319577988a5eec0,unknown).
node(n795,supported) :- node(n789,supported), node(n790,supported), node(n796,supported), node(n791,supported).
node(n795,refuted) :- node(n789,refuted).
node(n795,refuted) :- node(n790,refuted).
node(n795,refuted) :- node(n796,refuted).
node(n795,refuted) :- node(n791,refuted).
node(n795,unknown) :- \+ node(n795,supported), \+ node(n795,refuted).
node(n792,refuted) :- node(n793,refuted), node(n795,refuted), node(n9,refuted).
node(n792,supported) :- node(n793,supported).
node(n792,supported) :- node(n795,supported).
node(n792,supported) :- node(n9,supported).
node(n792,unknown) :- \+ node(n792,supported), \+ node(n792,refuted).
verdict(c_a5b39d603b77d788,supported) :- node(n792,supported).
query(verdict(c_a5b39d603b77d788,supported)).
verdict(c_a5b39d603b77d788,refuted) :- node(n792,refuted).
query(verdict(c_a5b39d603b77d788,refuted)).
verdict(c_a5b39d603b77d788,unknown) :- node(n792,unknown).
query(verdict(c_a5b39d603b77d788,unknown)).
node(n799,supported) :- status(o_0bb25e513cc714113aa2,supported).
node(n799,refuted) :- status(o_0bb25e513cc714113aa2,refuted).
node(n799,unknown) :- status(o_0bb25e513cc714113aa2,unknown).
node(n800,supported) :- status(o_a861a84daf7bf7442aa1,supported).
node(n800,refuted) :- status(o_a861a84daf7bf7442aa1,refuted).
node(n800,unknown) :- status(o_a861a84daf7bf7442aa1,unknown).
node(n801,supported) :- status(o_e985aa974e7a96cfa0e9,supported).
node(n801,refuted) :- status(o_e985aa974e7a96cfa0e9,refuted).
node(n801,unknown) :- status(o_e985aa974e7a96cfa0e9,unknown).
node(n798,supported) :- node(n799,supported), node(n800,supported), node(n801,supported).
node(n798,refuted) :- node(n799,refuted).
node(n798,refuted) :- node(n800,refuted).
node(n798,refuted) :- node(n801,refuted).
node(n798,unknown) :- \+ node(n798,supported), \+ node(n798,refuted).
node(n803,supported) :- status(o_9818e77fc95dc64d61a3,supported).
node(n803,refuted) :- status(o_9818e77fc95dc64d61a3,refuted).
node(n803,unknown) :- status(o_9818e77fc95dc64d61a3,unknown).
node(n804,supported) :- status(o_f7e156383510e9dfb240,supported).
node(n804,refuted) :- status(o_f7e156383510e9dfb240,refuted).
node(n804,unknown) :- status(o_f7e156383510e9dfb240,unknown).
node(n805,supported) :- status(o_152f51e19cbe552645b1,supported).
node(n805,refuted) :- status(o_152f51e19cbe552645b1,refuted).
node(n805,unknown) :- status(o_152f51e19cbe552645b1,unknown).
node(n802,supported) :- node(n803,supported), node(n804,supported), node(n805,supported).
node(n802,refuted) :- node(n803,refuted).
node(n802,refuted) :- node(n804,refuted).
node(n802,refuted) :- node(n805,refuted).
node(n802,unknown) :- \+ node(n802,supported), \+ node(n802,refuted).
node(n797,refuted) :- node(n798,refuted), node(n802,refuted), node(n9,refuted).
node(n797,supported) :- node(n798,supported).
node(n797,supported) :- node(n802,supported).
node(n797,supported) :- node(n9,supported).
node(n797,unknown) :- \+ node(n797,supported), \+ node(n797,refuted).
verdict(c_456cbfb73f9e47a0,supported) :- node(n797,supported).
query(verdict(c_456cbfb73f9e47a0,supported)).
verdict(c_456cbfb73f9e47a0,refuted) :- node(n797,refuted).
query(verdict(c_456cbfb73f9e47a0,refuted)).
verdict(c_456cbfb73f9e47a0,unknown) :- node(n797,unknown).
query(verdict(c_456cbfb73f9e47a0,unknown)).
node(n808,supported) :- status(o_837bc04c8c3e200fc177,supported).
node(n808,refuted) :- status(o_837bc04c8c3e200fc177,refuted).
node(n808,unknown) :- status(o_837bc04c8c3e200fc177,unknown).
node(n807,supported) :- node(n799,supported), node(n800,supported), node(n808,supported), node(n801,supported).
node(n807,refuted) :- node(n799,refuted).
node(n807,refuted) :- node(n800,refuted).
node(n807,refuted) :- node(n808,refuted).
node(n807,refuted) :- node(n801,refuted).
node(n807,unknown) :- \+ node(n807,supported), \+ node(n807,refuted).
node(n810,supported) :- status(o_a1d564c8d71011994ec5,supported).
node(n810,refuted) :- status(o_a1d564c8d71011994ec5,refuted).
node(n810,unknown) :- status(o_a1d564c8d71011994ec5,unknown).
node(n809,supported) :- node(n803,supported), node(n804,supported), node(n810,supported), node(n805,supported).
node(n809,refuted) :- node(n803,refuted).
node(n809,refuted) :- node(n804,refuted).
node(n809,refuted) :- node(n810,refuted).
node(n809,refuted) :- node(n805,refuted).
node(n809,unknown) :- \+ node(n809,supported), \+ node(n809,refuted).
node(n806,refuted) :- node(n807,refuted), node(n809,refuted), node(n9,refuted).
node(n806,supported) :- node(n807,supported).
node(n806,supported) :- node(n809,supported).
node(n806,supported) :- node(n9,supported).
node(n806,unknown) :- \+ node(n806,supported), \+ node(n806,refuted).
verdict(c_726ea15c133b3f7c,supported) :- node(n806,supported).
query(verdict(c_726ea15c133b3f7c,supported)).
verdict(c_726ea15c133b3f7c,refuted) :- node(n806,refuted).
query(verdict(c_726ea15c133b3f7c,refuted)).
verdict(c_726ea15c133b3f7c,unknown) :- node(n806,unknown).
query(verdict(c_726ea15c133b3f7c,unknown)).
node(n813,supported) :- status(o_8f89266ed6586f14ff07,supported).
node(n813,refuted) :- status(o_8f89266ed6586f14ff07,refuted).
node(n813,unknown) :- status(o_8f89266ed6586f14ff07,unknown).
node(n814,supported) :- status(o_6e3cfaffc8186d1b0bbe,supported).
node(n814,refuted) :- status(o_6e3cfaffc8186d1b0bbe,refuted).
node(n814,unknown) :- status(o_6e3cfaffc8186d1b0bbe,unknown).
node(n815,supported) :- status(o_e937e4dc1a700fc9adec,supported).
node(n815,refuted) :- status(o_e937e4dc1a700fc9adec,refuted).
node(n815,unknown) :- status(o_e937e4dc1a700fc9adec,unknown).
node(n812,supported) :- node(n813,supported), node(n814,supported), node(n815,supported).
node(n812,refuted) :- node(n813,refuted).
node(n812,refuted) :- node(n814,refuted).
node(n812,refuted) :- node(n815,refuted).
node(n812,unknown) :- \+ node(n812,supported), \+ node(n812,refuted).
node(n817,supported) :- status(o_52a3a0dffca894bba6d6,supported).
node(n817,refuted) :- status(o_52a3a0dffca894bba6d6,refuted).
node(n817,unknown) :- status(o_52a3a0dffca894bba6d6,unknown).
node(n818,supported) :- status(o_058860153206f2e9dfcc,supported).
node(n818,refuted) :- status(o_058860153206f2e9dfcc,refuted).
node(n818,unknown) :- status(o_058860153206f2e9dfcc,unknown).
node(n819,supported) :- status(o_577f9eda53efd92de539,supported).
node(n819,refuted) :- status(o_577f9eda53efd92de539,refuted).
node(n819,unknown) :- status(o_577f9eda53efd92de539,unknown).
node(n816,supported) :- node(n817,supported), node(n818,supported), node(n819,supported).
node(n816,refuted) :- node(n817,refuted).
node(n816,refuted) :- node(n818,refuted).
node(n816,refuted) :- node(n819,refuted).
node(n816,unknown) :- \+ node(n816,supported), \+ node(n816,refuted).
node(n811,refuted) :- node(n812,refuted), node(n816,refuted), node(n9,refuted).
node(n811,supported) :- node(n812,supported).
node(n811,supported) :- node(n816,supported).
node(n811,supported) :- node(n9,supported).
node(n811,unknown) :- \+ node(n811,supported), \+ node(n811,refuted).
verdict(c_668b36acb92a46c6,supported) :- node(n811,supported).
query(verdict(c_668b36acb92a46c6,supported)).
verdict(c_668b36acb92a46c6,refuted) :- node(n811,refuted).
query(verdict(c_668b36acb92a46c6,refuted)).
verdict(c_668b36acb92a46c6,unknown) :- node(n811,unknown).
query(verdict(c_668b36acb92a46c6,unknown)).
node(n822,supported) :- status(o_067e2819627a57195566,supported).
node(n822,refuted) :- status(o_067e2819627a57195566,refuted).
node(n822,unknown) :- status(o_067e2819627a57195566,unknown).
node(n821,supported) :- node(n813,supported), node(n814,supported), node(n822,supported), node(n815,supported).
node(n821,refuted) :- node(n813,refuted).
node(n821,refuted) :- node(n814,refuted).
node(n821,refuted) :- node(n822,refuted).
node(n821,refuted) :- node(n815,refuted).
node(n821,unknown) :- \+ node(n821,supported), \+ node(n821,refuted).
node(n824,supported) :- status(o_2292f7ff9597d888312e,supported).
node(n824,refuted) :- status(o_2292f7ff9597d888312e,refuted).
node(n824,unknown) :- status(o_2292f7ff9597d888312e,unknown).
node(n823,supported) :- node(n817,supported), node(n818,supported), node(n824,supported), node(n819,supported).
node(n823,refuted) :- node(n817,refuted).
node(n823,refuted) :- node(n818,refuted).
node(n823,refuted) :- node(n824,refuted).
node(n823,refuted) :- node(n819,refuted).
node(n823,unknown) :- \+ node(n823,supported), \+ node(n823,refuted).
node(n820,refuted) :- node(n821,refuted), node(n823,refuted), node(n9,refuted).
node(n820,supported) :- node(n821,supported).
node(n820,supported) :- node(n823,supported).
node(n820,supported) :- node(n9,supported).
node(n820,unknown) :- \+ node(n820,supported), \+ node(n820,refuted).
verdict(c_310bc5dc6d86a398,supported) :- node(n820,supported).
query(verdict(c_310bc5dc6d86a398,supported)).
verdict(c_310bc5dc6d86a398,refuted) :- node(n820,refuted).
query(verdict(c_310bc5dc6d86a398,refuted)).
verdict(c_310bc5dc6d86a398,unknown) :- node(n820,unknown).
query(verdict(c_310bc5dc6d86a398,unknown)).
node(n827,supported) :- status(o_36b2dbd9f2bc80d0d708,supported).
node(n827,refuted) :- status(o_36b2dbd9f2bc80d0d708,refuted).
node(n827,unknown) :- status(o_36b2dbd9f2bc80d0d708,unknown).
node(n828,supported) :- status(o_c620ef08f3c6e92e7234,supported).
node(n828,refuted) :- status(o_c620ef08f3c6e92e7234,refuted).
node(n828,unknown) :- status(o_c620ef08f3c6e92e7234,unknown).
node(n829,supported) :- status(o_1a10759b6ce32873e5cc,supported).
node(n829,refuted) :- status(o_1a10759b6ce32873e5cc,refuted).
node(n829,unknown) :- status(o_1a10759b6ce32873e5cc,unknown).
node(n826,supported) :- node(n827,supported), node(n828,supported), node(n829,supported).
node(n826,refuted) :- node(n827,refuted).
node(n826,refuted) :- node(n828,refuted).
node(n826,refuted) :- node(n829,refuted).
node(n826,unknown) :- \+ node(n826,supported), \+ node(n826,refuted).
node(n831,supported) :- status(o_f7fcaa37851f7cbed69f,supported).
node(n831,refuted) :- status(o_f7fcaa37851f7cbed69f,refuted).
node(n831,unknown) :- status(o_f7fcaa37851f7cbed69f,unknown).
node(n832,supported) :- status(o_effdd62922efadc0a661,supported).
node(n832,refuted) :- status(o_effdd62922efadc0a661,refuted).
node(n832,unknown) :- status(o_effdd62922efadc0a661,unknown).
node(n833,supported) :- status(o_1ee7c863e0b340d611f7,supported).
node(n833,refuted) :- status(o_1ee7c863e0b340d611f7,refuted).
node(n833,unknown) :- status(o_1ee7c863e0b340d611f7,unknown).
node(n830,supported) :- node(n831,supported), node(n832,supported), node(n833,supported).
node(n830,refuted) :- node(n831,refuted).
node(n830,refuted) :- node(n832,refuted).
node(n830,refuted) :- node(n833,refuted).
node(n830,unknown) :- \+ node(n830,supported), \+ node(n830,refuted).
node(n825,refuted) :- node(n826,refuted), node(n830,refuted), node(n9,refuted).
node(n825,supported) :- node(n826,supported).
node(n825,supported) :- node(n830,supported).
node(n825,supported) :- node(n9,supported).
node(n825,unknown) :- \+ node(n825,supported), \+ node(n825,refuted).
verdict(c_a66de1b0f86ffb95,supported) :- node(n825,supported).
query(verdict(c_a66de1b0f86ffb95,supported)).
verdict(c_a66de1b0f86ffb95,refuted) :- node(n825,refuted).
query(verdict(c_a66de1b0f86ffb95,refuted)).
verdict(c_a66de1b0f86ffb95,unknown) :- node(n825,unknown).
query(verdict(c_a66de1b0f86ffb95,unknown)).
node(n836,supported) :- status(o_5dcf2050f78a23e17baa,supported).
node(n836,refuted) :- status(o_5dcf2050f78a23e17baa,refuted).
node(n836,unknown) :- status(o_5dcf2050f78a23e17baa,unknown).
node(n835,supported) :- node(n827,supported), node(n828,supported), node(n836,supported), node(n829,supported).
node(n835,refuted) :- node(n827,refuted).
node(n835,refuted) :- node(n828,refuted).
node(n835,refuted) :- node(n836,refuted).
node(n835,refuted) :- node(n829,refuted).
node(n835,unknown) :- \+ node(n835,supported), \+ node(n835,refuted).
node(n838,supported) :- status(o_1e30d3abfd6bc3fa23db,supported).
node(n838,refuted) :- status(o_1e30d3abfd6bc3fa23db,refuted).
node(n838,unknown) :- status(o_1e30d3abfd6bc3fa23db,unknown).
node(n837,supported) :- node(n831,supported), node(n832,supported), node(n838,supported), node(n833,supported).
node(n837,refuted) :- node(n831,refuted).
node(n837,refuted) :- node(n832,refuted).
node(n837,refuted) :- node(n838,refuted).
node(n837,refuted) :- node(n833,refuted).
node(n837,unknown) :- \+ node(n837,supported), \+ node(n837,refuted).
node(n834,refuted) :- node(n835,refuted), node(n837,refuted), node(n9,refuted).
node(n834,supported) :- node(n835,supported).
node(n834,supported) :- node(n837,supported).
node(n834,supported) :- node(n9,supported).
node(n834,unknown) :- \+ node(n834,supported), \+ node(n834,refuted).
verdict(c_9d251b79d19b62bc,supported) :- node(n834,supported).
query(verdict(c_9d251b79d19b62bc,supported)).
verdict(c_9d251b79d19b62bc,refuted) :- node(n834,refuted).
query(verdict(c_9d251b79d19b62bc,refuted)).
verdict(c_9d251b79d19b62bc,unknown) :- node(n834,unknown).
query(verdict(c_9d251b79d19b62bc,unknown)).
node(n841,supported) :- status(o_3dc719635cbee4f9209d,supported).
node(n841,refuted) :- status(o_3dc719635cbee4f9209d,refuted).
node(n841,unknown) :- status(o_3dc719635cbee4f9209d,unknown).
node(n842,supported) :- status(o_75b800a72091c280603b,supported).
node(n842,refuted) :- status(o_75b800a72091c280603b,refuted).
node(n842,unknown) :- status(o_75b800a72091c280603b,unknown).
node(n843,supported) :- status(o_24b6ee12cd71ce15dac9,supported).
node(n843,refuted) :- status(o_24b6ee12cd71ce15dac9,refuted).
node(n843,unknown) :- status(o_24b6ee12cd71ce15dac9,unknown).
node(n840,supported) :- node(n841,supported), node(n842,supported), node(n843,supported).
node(n840,refuted) :- node(n841,refuted).
node(n840,refuted) :- node(n842,refuted).
node(n840,refuted) :- node(n843,refuted).
node(n840,unknown) :- \+ node(n840,supported), \+ node(n840,refuted).
node(n845,supported) :- status(o_d47c60ab7ffe0336bb1e,supported).
node(n845,refuted) :- status(o_d47c60ab7ffe0336bb1e,refuted).
node(n845,unknown) :- status(o_d47c60ab7ffe0336bb1e,unknown).
node(n846,supported) :- status(o_1867e86911f21c8cdb17,supported).
node(n846,refuted) :- status(o_1867e86911f21c8cdb17,refuted).
node(n846,unknown) :- status(o_1867e86911f21c8cdb17,unknown).
node(n847,supported) :- status(o_aa09cc56431805dbf5f0,supported).
node(n847,refuted) :- status(o_aa09cc56431805dbf5f0,refuted).
node(n847,unknown) :- status(o_aa09cc56431805dbf5f0,unknown).
node(n844,supported) :- node(n845,supported), node(n846,supported), node(n847,supported).
node(n844,refuted) :- node(n845,refuted).
node(n844,refuted) :- node(n846,refuted).
node(n844,refuted) :- node(n847,refuted).
node(n844,unknown) :- \+ node(n844,supported), \+ node(n844,refuted).
node(n839,refuted) :- node(n840,refuted), node(n844,refuted), node(n9,refuted).
node(n839,supported) :- node(n840,supported).
node(n839,supported) :- node(n844,supported).
node(n839,supported) :- node(n9,supported).
node(n839,unknown) :- \+ node(n839,supported), \+ node(n839,refuted).
verdict(c_e215934e44b9655c,supported) :- node(n839,supported).
query(verdict(c_e215934e44b9655c,supported)).
verdict(c_e215934e44b9655c,refuted) :- node(n839,refuted).
query(verdict(c_e215934e44b9655c,refuted)).
verdict(c_e215934e44b9655c,unknown) :- node(n839,unknown).
query(verdict(c_e215934e44b9655c,unknown)).
node(n850,supported) :- status(o_70ee7ff2b945257f7138,supported).
node(n850,refuted) :- status(o_70ee7ff2b945257f7138,refuted).
node(n850,unknown) :- status(o_70ee7ff2b945257f7138,unknown).
node(n849,supported) :- node(n841,supported), node(n842,supported), node(n850,supported), node(n843,supported).
node(n849,refuted) :- node(n841,refuted).
node(n849,refuted) :- node(n842,refuted).
node(n849,refuted) :- node(n850,refuted).
node(n849,refuted) :- node(n843,refuted).
node(n849,unknown) :- \+ node(n849,supported), \+ node(n849,refuted).
node(n852,supported) :- status(o_af3c0f52a89aa928e33a,supported).
node(n852,refuted) :- status(o_af3c0f52a89aa928e33a,refuted).
node(n852,unknown) :- status(o_af3c0f52a89aa928e33a,unknown).
node(n851,supported) :- node(n845,supported), node(n846,supported), node(n852,supported), node(n847,supported).
node(n851,refuted) :- node(n845,refuted).
node(n851,refuted) :- node(n846,refuted).
node(n851,refuted) :- node(n852,refuted).
node(n851,refuted) :- node(n847,refuted).
node(n851,unknown) :- \+ node(n851,supported), \+ node(n851,refuted).
node(n848,refuted) :- node(n849,refuted), node(n851,refuted), node(n9,refuted).
node(n848,supported) :- node(n849,supported).
node(n848,supported) :- node(n851,supported).
node(n848,supported) :- node(n9,supported).
node(n848,unknown) :- \+ node(n848,supported), \+ node(n848,refuted).
verdict(c_9579480121205f3c,supported) :- node(n848,supported).
query(verdict(c_9579480121205f3c,supported)).
verdict(c_9579480121205f3c,refuted) :- node(n848,refuted).
query(verdict(c_9579480121205f3c,refuted)).
verdict(c_9579480121205f3c,unknown) :- node(n848,unknown).
query(verdict(c_9579480121205f3c,unknown)).
node(n855,supported) :- status(o_6e2294cf3b1f0eb8808f,supported).
node(n855,refuted) :- status(o_6e2294cf3b1f0eb8808f,refuted).
node(n855,unknown) :- status(o_6e2294cf3b1f0eb8808f,unknown).
node(n856,supported) :- status(o_d69f69360c70ad5a8bcb,supported).
node(n856,refuted) :- status(o_d69f69360c70ad5a8bcb,refuted).
node(n856,unknown) :- status(o_d69f69360c70ad5a8bcb,unknown).
node(n857,supported) :- status(o_2e976143865b741ab025,supported).
node(n857,refuted) :- status(o_2e976143865b741ab025,refuted).
node(n857,unknown) :- status(o_2e976143865b741ab025,unknown).
node(n854,supported) :- node(n855,supported), node(n856,supported), node(n857,supported).
node(n854,refuted) :- node(n855,refuted).
node(n854,refuted) :- node(n856,refuted).
node(n854,refuted) :- node(n857,refuted).
node(n854,unknown) :- \+ node(n854,supported), \+ node(n854,refuted).
node(n859,supported) :- status(o_dfd30d8cc785ba014691,supported).
node(n859,refuted) :- status(o_dfd30d8cc785ba014691,refuted).
node(n859,unknown) :- status(o_dfd30d8cc785ba014691,unknown).
node(n860,supported) :- status(o_fd58f4d4dffe33849075,supported).
node(n860,refuted) :- status(o_fd58f4d4dffe33849075,refuted).
node(n860,unknown) :- status(o_fd58f4d4dffe33849075,unknown).
node(n861,supported) :- status(o_3b0d9e9515285e6ea157,supported).
node(n861,refuted) :- status(o_3b0d9e9515285e6ea157,refuted).
node(n861,unknown) :- status(o_3b0d9e9515285e6ea157,unknown).
node(n858,supported) :- node(n859,supported), node(n860,supported), node(n861,supported).
node(n858,refuted) :- node(n859,refuted).
node(n858,refuted) :- node(n860,refuted).
node(n858,refuted) :- node(n861,refuted).
node(n858,unknown) :- \+ node(n858,supported), \+ node(n858,refuted).
node(n853,refuted) :- node(n854,refuted), node(n858,refuted), node(n9,refuted).
node(n853,supported) :- node(n854,supported).
node(n853,supported) :- node(n858,supported).
node(n853,supported) :- node(n9,supported).
node(n853,unknown) :- \+ node(n853,supported), \+ node(n853,refuted).
verdict(c_7f868a82729ec72a,supported) :- node(n853,supported).
query(verdict(c_7f868a82729ec72a,supported)).
verdict(c_7f868a82729ec72a,refuted) :- node(n853,refuted).
query(verdict(c_7f868a82729ec72a,refuted)).
verdict(c_7f868a82729ec72a,unknown) :- node(n853,unknown).
query(verdict(c_7f868a82729ec72a,unknown)).
node(n864,supported) :- status(o_23c3b989771dd7b30fb1,supported).
node(n864,refuted) :- status(o_23c3b989771dd7b30fb1,refuted).
node(n864,unknown) :- status(o_23c3b989771dd7b30fb1,unknown).
node(n863,supported) :- node(n855,supported), node(n856,supported), node(n864,supported), node(n857,supported).
node(n863,refuted) :- node(n855,refuted).
node(n863,refuted) :- node(n856,refuted).
node(n863,refuted) :- node(n864,refuted).
node(n863,refuted) :- node(n857,refuted).
node(n863,unknown) :- \+ node(n863,supported), \+ node(n863,refuted).
node(n866,supported) :- status(o_5d1219a9d345299a68a6,supported).
node(n866,refuted) :- status(o_5d1219a9d345299a68a6,refuted).
node(n866,unknown) :- status(o_5d1219a9d345299a68a6,unknown).
node(n865,supported) :- node(n859,supported), node(n860,supported), node(n866,supported), node(n861,supported).
node(n865,refuted) :- node(n859,refuted).
node(n865,refuted) :- node(n860,refuted).
node(n865,refuted) :- node(n866,refuted).
node(n865,refuted) :- node(n861,refuted).
node(n865,unknown) :- \+ node(n865,supported), \+ node(n865,refuted).
node(n862,refuted) :- node(n863,refuted), node(n865,refuted), node(n9,refuted).
node(n862,supported) :- node(n863,supported).
node(n862,supported) :- node(n865,supported).
node(n862,supported) :- node(n9,supported).
node(n862,unknown) :- \+ node(n862,supported), \+ node(n862,refuted).
verdict(c_cbc2995484280ded,supported) :- node(n862,supported).
query(verdict(c_cbc2995484280ded,supported)).
verdict(c_cbc2995484280ded,refuted) :- node(n862,refuted).
query(verdict(c_cbc2995484280ded,refuted)).
verdict(c_cbc2995484280ded,unknown) :- node(n862,unknown).
query(verdict(c_cbc2995484280ded,unknown)).
node(n869,supported) :- status(o_3a95662b5a7b3831334b,supported).
node(n869,refuted) :- status(o_3a95662b5a7b3831334b,refuted).
node(n869,unknown) :- status(o_3a95662b5a7b3831334b,unknown).
node(n870,supported) :- status(o_05c145946acc27ed1a62,supported).
node(n870,refuted) :- status(o_05c145946acc27ed1a62,refuted).
node(n870,unknown) :- status(o_05c145946acc27ed1a62,unknown).
node(n871,supported) :- status(o_642264a48f7aec5c30e2,supported).
node(n871,refuted) :- status(o_642264a48f7aec5c30e2,refuted).
node(n871,unknown) :- status(o_642264a48f7aec5c30e2,unknown).
node(n868,supported) :- node(n869,supported), node(n870,supported), node(n871,supported).
node(n868,refuted) :- node(n869,refuted).
node(n868,refuted) :- node(n870,refuted).
node(n868,refuted) :- node(n871,refuted).
node(n868,unknown) :- \+ node(n868,supported), \+ node(n868,refuted).
node(n873,supported) :- status(o_4b0a9bcf7d2044dea776,supported).
node(n873,refuted) :- status(o_4b0a9bcf7d2044dea776,refuted).
node(n873,unknown) :- status(o_4b0a9bcf7d2044dea776,unknown).
node(n874,supported) :- status(o_b6973840e1186cf278ae,supported).
node(n874,refuted) :- status(o_b6973840e1186cf278ae,refuted).
node(n874,unknown) :- status(o_b6973840e1186cf278ae,unknown).
node(n875,supported) :- status(o_15479461b6845627923e,supported).
node(n875,refuted) :- status(o_15479461b6845627923e,refuted).
node(n875,unknown) :- status(o_15479461b6845627923e,unknown).
node(n872,supported) :- node(n873,supported), node(n874,supported), node(n875,supported).
node(n872,refuted) :- node(n873,refuted).
node(n872,refuted) :- node(n874,refuted).
node(n872,refuted) :- node(n875,refuted).
node(n872,unknown) :- \+ node(n872,supported), \+ node(n872,refuted).
node(n867,refuted) :- node(n868,refuted), node(n872,refuted), node(n9,refuted).
node(n867,supported) :- node(n868,supported).
node(n867,supported) :- node(n872,supported).
node(n867,supported) :- node(n9,supported).
node(n867,unknown) :- \+ node(n867,supported), \+ node(n867,refuted).
verdict(c_8d40d78df2e2d2a0,supported) :- node(n867,supported).
query(verdict(c_8d40d78df2e2d2a0,supported)).
verdict(c_8d40d78df2e2d2a0,refuted) :- node(n867,refuted).
query(verdict(c_8d40d78df2e2d2a0,refuted)).
verdict(c_8d40d78df2e2d2a0,unknown) :- node(n867,unknown).
query(verdict(c_8d40d78df2e2d2a0,unknown)).
node(n878,supported) :- status(o_f14d89ddace4ab765e94,supported).
node(n878,refuted) :- status(o_f14d89ddace4ab765e94,refuted).
node(n878,unknown) :- status(o_f14d89ddace4ab765e94,unknown).
node(n877,supported) :- node(n869,supported), node(n870,supported), node(n878,supported), node(n871,supported).
node(n877,refuted) :- node(n869,refuted).
node(n877,refuted) :- node(n870,refuted).
node(n877,refuted) :- node(n878,refuted).
node(n877,refuted) :- node(n871,refuted).
node(n877,unknown) :- \+ node(n877,supported), \+ node(n877,refuted).
node(n880,supported) :- status(o_ddcf482ea0de97b9bd79,supported).
node(n880,refuted) :- status(o_ddcf482ea0de97b9bd79,refuted).
node(n880,unknown) :- status(o_ddcf482ea0de97b9bd79,unknown).
node(n879,supported) :- node(n873,supported), node(n874,supported), node(n880,supported), node(n875,supported).
node(n879,refuted) :- node(n873,refuted).
node(n879,refuted) :- node(n874,refuted).
node(n879,refuted) :- node(n880,refuted).
node(n879,refuted) :- node(n875,refuted).
node(n879,unknown) :- \+ node(n879,supported), \+ node(n879,refuted).
node(n876,refuted) :- node(n877,refuted), node(n879,refuted), node(n9,refuted).
node(n876,supported) :- node(n877,supported).
node(n876,supported) :- node(n879,supported).
node(n876,supported) :- node(n9,supported).
node(n876,unknown) :- \+ node(n876,supported), \+ node(n876,refuted).
verdict(c_33668910afaaee49,supported) :- node(n876,supported).
query(verdict(c_33668910afaaee49,supported)).
verdict(c_33668910afaaee49,refuted) :- node(n876,refuted).
query(verdict(c_33668910afaaee49,refuted)).
verdict(c_33668910afaaee49,unknown) :- node(n876,unknown).
query(verdict(c_33668910afaaee49,unknown)).
node(n883,supported) :- status(o_6eee66a36d1bfc59e677,supported).
node(n883,refuted) :- status(o_6eee66a36d1bfc59e677,refuted).
node(n883,unknown) :- status(o_6eee66a36d1bfc59e677,unknown).
node(n884,supported) :- status(o_0b506808665499301698,supported).
node(n884,refuted) :- status(o_0b506808665499301698,refuted).
node(n884,unknown) :- status(o_0b506808665499301698,unknown).
node(n885,supported) :- status(o_58ae1cb619f437dd76c7,supported).
node(n885,refuted) :- status(o_58ae1cb619f437dd76c7,refuted).
node(n885,unknown) :- status(o_58ae1cb619f437dd76c7,unknown).
node(n882,supported) :- node(n883,supported), node(n884,supported), node(n885,supported).
node(n882,refuted) :- node(n883,refuted).
node(n882,refuted) :- node(n884,refuted).
node(n882,refuted) :- node(n885,refuted).
node(n882,unknown) :- \+ node(n882,supported), \+ node(n882,refuted).
node(n887,supported) :- status(o_df6a6a49655e1e74555f,supported).
node(n887,refuted) :- status(o_df6a6a49655e1e74555f,refuted).
node(n887,unknown) :- status(o_df6a6a49655e1e74555f,unknown).
node(n888,supported) :- status(o_c59980b0c637bd3a1d59,supported).
node(n888,refuted) :- status(o_c59980b0c637bd3a1d59,refuted).
node(n888,unknown) :- status(o_c59980b0c637bd3a1d59,unknown).
node(n889,supported) :- status(o_2c84bf08d2b036d66898,supported).
node(n889,refuted) :- status(o_2c84bf08d2b036d66898,refuted).
node(n889,unknown) :- status(o_2c84bf08d2b036d66898,unknown).
node(n886,supported) :- node(n887,supported), node(n888,supported), node(n889,supported).
node(n886,refuted) :- node(n887,refuted).
node(n886,refuted) :- node(n888,refuted).
node(n886,refuted) :- node(n889,refuted).
node(n886,unknown) :- \+ node(n886,supported), \+ node(n886,refuted).
node(n881,refuted) :- node(n882,refuted), node(n886,refuted), node(n9,refuted).
node(n881,supported) :- node(n882,supported).
node(n881,supported) :- node(n886,supported).
node(n881,supported) :- node(n9,supported).
node(n881,unknown) :- \+ node(n881,supported), \+ node(n881,refuted).
verdict(c_409b19da5526ffe1,supported) :- node(n881,supported).
query(verdict(c_409b19da5526ffe1,supported)).
verdict(c_409b19da5526ffe1,refuted) :- node(n881,refuted).
query(verdict(c_409b19da5526ffe1,refuted)).
verdict(c_409b19da5526ffe1,unknown) :- node(n881,unknown).
query(verdict(c_409b19da5526ffe1,unknown)).
node(n892,supported) :- status(o_584b435ed4cfd0f7dedb,supported).
node(n892,refuted) :- status(o_584b435ed4cfd0f7dedb,refuted).
node(n892,unknown) :- status(o_584b435ed4cfd0f7dedb,unknown).
node(n891,supported) :- node(n883,supported), node(n884,supported), node(n892,supported), node(n885,supported).
node(n891,refuted) :- node(n883,refuted).
node(n891,refuted) :- node(n884,refuted).
node(n891,refuted) :- node(n892,refuted).
node(n891,refuted) :- node(n885,refuted).
node(n891,unknown) :- \+ node(n891,supported), \+ node(n891,refuted).
node(n894,supported) :- status(o_c5a0f3d78b2dcc0d5cfe,supported).
node(n894,refuted) :- status(o_c5a0f3d78b2dcc0d5cfe,refuted).
node(n894,unknown) :- status(o_c5a0f3d78b2dcc0d5cfe,unknown).
node(n893,supported) :- node(n887,supported), node(n888,supported), node(n894,supported), node(n889,supported).
node(n893,refuted) :- node(n887,refuted).
node(n893,refuted) :- node(n888,refuted).
node(n893,refuted) :- node(n894,refuted).
node(n893,refuted) :- node(n889,refuted).
node(n893,unknown) :- \+ node(n893,supported), \+ node(n893,refuted).
node(n890,refuted) :- node(n891,refuted), node(n893,refuted), node(n9,refuted).
node(n890,supported) :- node(n891,supported).
node(n890,supported) :- node(n893,supported).
node(n890,supported) :- node(n9,supported).
node(n890,unknown) :- \+ node(n890,supported), \+ node(n890,refuted).
verdict(c_e59b836265e9ed95,supported) :- node(n890,supported).
query(verdict(c_e59b836265e9ed95,supported)).
verdict(c_e59b836265e9ed95,refuted) :- node(n890,refuted).
query(verdict(c_e59b836265e9ed95,refuted)).
verdict(c_e59b836265e9ed95,unknown) :- node(n890,unknown).
query(verdict(c_e59b836265e9ed95,unknown)).
node(n897,supported) :- status(o_5291ecff22d470a8116b,supported).
node(n897,refuted) :- status(o_5291ecff22d470a8116b,refuted).
node(n897,unknown) :- status(o_5291ecff22d470a8116b,unknown).
node(n898,supported) :- status(o_e8e78395f987c1477061,supported).
node(n898,refuted) :- status(o_e8e78395f987c1477061,refuted).
node(n898,unknown) :- status(o_e8e78395f987c1477061,unknown).
node(n899,supported) :- status(o_b4356c30b901a27e41b0,supported).
node(n899,refuted) :- status(o_b4356c30b901a27e41b0,refuted).
node(n899,unknown) :- status(o_b4356c30b901a27e41b0,unknown).
node(n896,supported) :- node(n897,supported), node(n898,supported), node(n899,supported).
node(n896,refuted) :- node(n897,refuted).
node(n896,refuted) :- node(n898,refuted).
node(n896,refuted) :- node(n899,refuted).
node(n896,unknown) :- \+ node(n896,supported), \+ node(n896,refuted).
node(n901,supported) :- status(o_1bedfa209fa9024a96b9,supported).
node(n901,refuted) :- status(o_1bedfa209fa9024a96b9,refuted).
node(n901,unknown) :- status(o_1bedfa209fa9024a96b9,unknown).
node(n902,supported) :- status(o_796cca04ae13beb5056a,supported).
node(n902,refuted) :- status(o_796cca04ae13beb5056a,refuted).
node(n902,unknown) :- status(o_796cca04ae13beb5056a,unknown).
node(n903,supported) :- status(o_0db1095447975839ff73,supported).
node(n903,refuted) :- status(o_0db1095447975839ff73,refuted).
node(n903,unknown) :- status(o_0db1095447975839ff73,unknown).
node(n900,supported) :- node(n901,supported), node(n902,supported), node(n903,supported).
node(n900,refuted) :- node(n901,refuted).
node(n900,refuted) :- node(n902,refuted).
node(n900,refuted) :- node(n903,refuted).
node(n900,unknown) :- \+ node(n900,supported), \+ node(n900,refuted).
node(n895,refuted) :- node(n896,refuted), node(n900,refuted), node(n9,refuted).
node(n895,supported) :- node(n896,supported).
node(n895,supported) :- node(n900,supported).
node(n895,supported) :- node(n9,supported).
node(n895,unknown) :- \+ node(n895,supported), \+ node(n895,refuted).
verdict(c_ba5e29f627084d26,supported) :- node(n895,supported).
query(verdict(c_ba5e29f627084d26,supported)).
verdict(c_ba5e29f627084d26,refuted) :- node(n895,refuted).
query(verdict(c_ba5e29f627084d26,refuted)).
verdict(c_ba5e29f627084d26,unknown) :- node(n895,unknown).
query(verdict(c_ba5e29f627084d26,unknown)).
node(n906,supported) :- status(o_1beb39eed0efe9fbf9ed,supported).
node(n906,refuted) :- status(o_1beb39eed0efe9fbf9ed,refuted).
node(n906,unknown) :- status(o_1beb39eed0efe9fbf9ed,unknown).
node(n905,supported) :- node(n897,supported), node(n898,supported), node(n906,supported), node(n899,supported).
node(n905,refuted) :- node(n897,refuted).
node(n905,refuted) :- node(n898,refuted).
node(n905,refuted) :- node(n906,refuted).
node(n905,refuted) :- node(n899,refuted).
node(n905,unknown) :- \+ node(n905,supported), \+ node(n905,refuted).
node(n908,supported) :- status(o_734af3776dcf8b1fdb49,supported).
node(n908,refuted) :- status(o_734af3776dcf8b1fdb49,refuted).
node(n908,unknown) :- status(o_734af3776dcf8b1fdb49,unknown).
node(n907,supported) :- node(n901,supported), node(n902,supported), node(n908,supported), node(n903,supported).
node(n907,refuted) :- node(n901,refuted).
node(n907,refuted) :- node(n902,refuted).
node(n907,refuted) :- node(n908,refuted).
node(n907,refuted) :- node(n903,refuted).
node(n907,unknown) :- \+ node(n907,supported), \+ node(n907,refuted).
node(n904,refuted) :- node(n905,refuted), node(n907,refuted), node(n9,refuted).
node(n904,supported) :- node(n905,supported).
node(n904,supported) :- node(n907,supported).
node(n904,supported) :- node(n9,supported).
node(n904,unknown) :- \+ node(n904,supported), \+ node(n904,refuted).
verdict(c_ac7fc84f0c89595a,supported) :- node(n904,supported).
query(verdict(c_ac7fc84f0c89595a,supported)).
verdict(c_ac7fc84f0c89595a,refuted) :- node(n904,refuted).
query(verdict(c_ac7fc84f0c89595a,refuted)).
verdict(c_ac7fc84f0c89595a,unknown) :- node(n904,unknown).
query(verdict(c_ac7fc84f0c89595a,unknown)).
node(n911,supported) :- status(o_b10425345588ad700a70,supported).
node(n911,refuted) :- status(o_b10425345588ad700a70,refuted).
node(n911,unknown) :- status(o_b10425345588ad700a70,unknown).
node(n912,supported) :- status(o_46fa8574cbc3841b84e1,supported).
node(n912,refuted) :- status(o_46fa8574cbc3841b84e1,refuted).
node(n912,unknown) :- status(o_46fa8574cbc3841b84e1,unknown).
node(n913,supported) :- status(o_a5f4b27a7bded40186de,supported).
node(n913,refuted) :- status(o_a5f4b27a7bded40186de,refuted).
node(n913,unknown) :- status(o_a5f4b27a7bded40186de,unknown).
node(n910,supported) :- node(n911,supported), node(n912,supported), node(n913,supported).
node(n910,refuted) :- node(n911,refuted).
node(n910,refuted) :- node(n912,refuted).
node(n910,refuted) :- node(n913,refuted).
node(n910,unknown) :- \+ node(n910,supported), \+ node(n910,refuted).
node(n915,supported) :- status(o_6a5e555e4daa7914c677,supported).
node(n915,refuted) :- status(o_6a5e555e4daa7914c677,refuted).
node(n915,unknown) :- status(o_6a5e555e4daa7914c677,unknown).
node(n916,supported) :- status(o_b8ab0e8b5899754bc649,supported).
node(n916,refuted) :- status(o_b8ab0e8b5899754bc649,refuted).
node(n916,unknown) :- status(o_b8ab0e8b5899754bc649,unknown).
node(n917,supported) :- status(o_ddf687e9e4b9cac3ea36,supported).
node(n917,refuted) :- status(o_ddf687e9e4b9cac3ea36,refuted).
node(n917,unknown) :- status(o_ddf687e9e4b9cac3ea36,unknown).
node(n914,supported) :- node(n915,supported), node(n916,supported), node(n917,supported).
node(n914,refuted) :- node(n915,refuted).
node(n914,refuted) :- node(n916,refuted).
node(n914,refuted) :- node(n917,refuted).
node(n914,unknown) :- \+ node(n914,supported), \+ node(n914,refuted).
node(n909,refuted) :- node(n910,refuted), node(n914,refuted), node(n9,refuted).
node(n909,supported) :- node(n910,supported).
node(n909,supported) :- node(n914,supported).
node(n909,supported) :- node(n9,supported).
node(n909,unknown) :- \+ node(n909,supported), \+ node(n909,refuted).
verdict(c_3242a79f3f00ce0b,supported) :- node(n909,supported).
query(verdict(c_3242a79f3f00ce0b,supported)).
verdict(c_3242a79f3f00ce0b,refuted) :- node(n909,refuted).
query(verdict(c_3242a79f3f00ce0b,refuted)).
verdict(c_3242a79f3f00ce0b,unknown) :- node(n909,unknown).
query(verdict(c_3242a79f3f00ce0b,unknown)).
node(n920,supported) :- status(o_d6f47e33fcbfb6a4d1d3,supported).
node(n920,refuted) :- status(o_d6f47e33fcbfb6a4d1d3,refuted).
node(n920,unknown) :- status(o_d6f47e33fcbfb6a4d1d3,unknown).
node(n919,supported) :- node(n911,supported), node(n912,supported), node(n920,supported), node(n913,supported).
node(n919,refuted) :- node(n911,refuted).
node(n919,refuted) :- node(n912,refuted).
node(n919,refuted) :- node(n920,refuted).
node(n919,refuted) :- node(n913,refuted).
node(n919,unknown) :- \+ node(n919,supported), \+ node(n919,refuted).
node(n922,supported) :- status(o_f1fb0d85003d55b85afb,supported).
node(n922,refuted) :- status(o_f1fb0d85003d55b85afb,refuted).
node(n922,unknown) :- status(o_f1fb0d85003d55b85afb,unknown).
node(n921,supported) :- node(n915,supported), node(n916,supported), node(n922,supported), node(n917,supported).
node(n921,refuted) :- node(n915,refuted).
node(n921,refuted) :- node(n916,refuted).
node(n921,refuted) :- node(n922,refuted).
node(n921,refuted) :- node(n917,refuted).
node(n921,unknown) :- \+ node(n921,supported), \+ node(n921,refuted).
node(n918,refuted) :- node(n919,refuted), node(n921,refuted), node(n9,refuted).
node(n918,supported) :- node(n919,supported).
node(n918,supported) :- node(n921,supported).
node(n918,supported) :- node(n9,supported).
node(n918,unknown) :- \+ node(n918,supported), \+ node(n918,refuted).
verdict(c_4f7a645ec16fa7ea,supported) :- node(n918,supported).
query(verdict(c_4f7a645ec16fa7ea,supported)).
verdict(c_4f7a645ec16fa7ea,refuted) :- node(n918,refuted).
query(verdict(c_4f7a645ec16fa7ea,refuted)).
verdict(c_4f7a645ec16fa7ea,unknown) :- node(n918,unknown).
query(verdict(c_4f7a645ec16fa7ea,unknown)).
node(n925,supported) :- status(o_b1a7fb8e32e341df1f36,supported).
node(n925,refuted) :- status(o_b1a7fb8e32e341df1f36,refuted).
node(n925,unknown) :- status(o_b1a7fb8e32e341df1f36,unknown).
node(n926,supported) :- status(o_ad198bdcb579bc4ac533,supported).
node(n926,refuted) :- status(o_ad198bdcb579bc4ac533,refuted).
node(n926,unknown) :- status(o_ad198bdcb579bc4ac533,unknown).
node(n927,supported) :- status(o_39a8c8ef1979ccaeef61,supported).
node(n927,refuted) :- status(o_39a8c8ef1979ccaeef61,refuted).
node(n927,unknown) :- status(o_39a8c8ef1979ccaeef61,unknown).
node(n924,supported) :- node(n925,supported), node(n926,supported), node(n927,supported).
node(n924,refuted) :- node(n925,refuted).
node(n924,refuted) :- node(n926,refuted).
node(n924,refuted) :- node(n927,refuted).
node(n924,unknown) :- \+ node(n924,supported), \+ node(n924,refuted).
node(n929,supported) :- status(o_efc4b8402db4955ec763,supported).
node(n929,refuted) :- status(o_efc4b8402db4955ec763,refuted).
node(n929,unknown) :- status(o_efc4b8402db4955ec763,unknown).
node(n930,supported) :- status(o_666172dbc2614927985f,supported).
node(n930,refuted) :- status(o_666172dbc2614927985f,refuted).
node(n930,unknown) :- status(o_666172dbc2614927985f,unknown).
node(n931,supported) :- status(o_5c003abdd94b198d7228,supported).
node(n931,refuted) :- status(o_5c003abdd94b198d7228,refuted).
node(n931,unknown) :- status(o_5c003abdd94b198d7228,unknown).
node(n928,supported) :- node(n929,supported), node(n930,supported), node(n931,supported).
node(n928,refuted) :- node(n929,refuted).
node(n928,refuted) :- node(n930,refuted).
node(n928,refuted) :- node(n931,refuted).
node(n928,unknown) :- \+ node(n928,supported), \+ node(n928,refuted).
node(n923,refuted) :- node(n924,refuted), node(n928,refuted), node(n9,refuted).
node(n923,supported) :- node(n924,supported).
node(n923,supported) :- node(n928,supported).
node(n923,supported) :- node(n9,supported).
node(n923,unknown) :- \+ node(n923,supported), \+ node(n923,refuted).
verdict(c_9e82887acf773c86,supported) :- node(n923,supported).
query(verdict(c_9e82887acf773c86,supported)).
verdict(c_9e82887acf773c86,refuted) :- node(n923,refuted).
query(verdict(c_9e82887acf773c86,refuted)).
verdict(c_9e82887acf773c86,unknown) :- node(n923,unknown).
query(verdict(c_9e82887acf773c86,unknown)).
node(n934,supported) :- status(o_9a8c105a20daacb8d5da,supported).
node(n934,refuted) :- status(o_9a8c105a20daacb8d5da,refuted).
node(n934,unknown) :- status(o_9a8c105a20daacb8d5da,unknown).
node(n933,supported) :- node(n925,supported), node(n926,supported), node(n934,supported), node(n927,supported).
node(n933,refuted) :- node(n925,refuted).
node(n933,refuted) :- node(n926,refuted).
node(n933,refuted) :- node(n934,refuted).
node(n933,refuted) :- node(n927,refuted).
node(n933,unknown) :- \+ node(n933,supported), \+ node(n933,refuted).
node(n936,supported) :- status(o_4388ba497a6b1fcfe362,supported).
node(n936,refuted) :- status(o_4388ba497a6b1fcfe362,refuted).
node(n936,unknown) :- status(o_4388ba497a6b1fcfe362,unknown).
node(n935,supported) :- node(n929,supported), node(n930,supported), node(n936,supported), node(n931,supported).
node(n935,refuted) :- node(n929,refuted).
node(n935,refuted) :- node(n930,refuted).
node(n935,refuted) :- node(n936,refuted).
node(n935,refuted) :- node(n931,refuted).
node(n935,unknown) :- \+ node(n935,supported), \+ node(n935,refuted).
node(n932,refuted) :- node(n933,refuted), node(n935,refuted), node(n9,refuted).
node(n932,supported) :- node(n933,supported).
node(n932,supported) :- node(n935,supported).
node(n932,supported) :- node(n9,supported).
node(n932,unknown) :- \+ node(n932,supported), \+ node(n932,refuted).
verdict(c_8894dc50011bb516,supported) :- node(n932,supported).
query(verdict(c_8894dc50011bb516,supported)).
verdict(c_8894dc50011bb516,refuted) :- node(n932,refuted).
query(verdict(c_8894dc50011bb516,refuted)).
verdict(c_8894dc50011bb516,unknown) :- node(n932,unknown).
query(verdict(c_8894dc50011bb516,unknown)).
node(n939,supported) :- status(o_2348673ae2c21fd301fa,supported).
node(n939,refuted) :- status(o_2348673ae2c21fd301fa,refuted).
node(n939,unknown) :- status(o_2348673ae2c21fd301fa,unknown).
node(n940,supported) :- status(o_e7c465b2b9628c60bc2c,supported).
node(n940,refuted) :- status(o_e7c465b2b9628c60bc2c,refuted).
node(n940,unknown) :- status(o_e7c465b2b9628c60bc2c,unknown).
node(n941,supported) :- status(o_6d1c86657356599bbb62,supported).
node(n941,refuted) :- status(o_6d1c86657356599bbb62,refuted).
node(n941,unknown) :- status(o_6d1c86657356599bbb62,unknown).
node(n938,supported) :- node(n939,supported), node(n940,supported), node(n941,supported).
node(n938,refuted) :- node(n939,refuted).
node(n938,refuted) :- node(n940,refuted).
node(n938,refuted) :- node(n941,refuted).
node(n938,unknown) :- \+ node(n938,supported), \+ node(n938,refuted).
node(n943,supported) :- status(o_50b819a41b5a1f8449e8,supported).
node(n943,refuted) :- status(o_50b819a41b5a1f8449e8,refuted).
node(n943,unknown) :- status(o_50b819a41b5a1f8449e8,unknown).
node(n944,supported) :- status(o_206c7645fd2a570c31b3,supported).
node(n944,refuted) :- status(o_206c7645fd2a570c31b3,refuted).
node(n944,unknown) :- status(o_206c7645fd2a570c31b3,unknown).
node(n945,supported) :- status(o_094350b43c7453be0e63,supported).
node(n945,refuted) :- status(o_094350b43c7453be0e63,refuted).
node(n945,unknown) :- status(o_094350b43c7453be0e63,unknown).
node(n942,supported) :- node(n943,supported), node(n944,supported), node(n945,supported).
node(n942,refuted) :- node(n943,refuted).
node(n942,refuted) :- node(n944,refuted).
node(n942,refuted) :- node(n945,refuted).
node(n942,unknown) :- \+ node(n942,supported), \+ node(n942,refuted).
node(n937,refuted) :- node(n938,refuted), node(n942,refuted), node(n9,refuted).
node(n937,supported) :- node(n938,supported).
node(n937,supported) :- node(n942,supported).
node(n937,supported) :- node(n9,supported).
node(n937,unknown) :- \+ node(n937,supported), \+ node(n937,refuted).
verdict(c_e50bcb82f3cb6b6e,supported) :- node(n937,supported).
query(verdict(c_e50bcb82f3cb6b6e,supported)).
verdict(c_e50bcb82f3cb6b6e,refuted) :- node(n937,refuted).
query(verdict(c_e50bcb82f3cb6b6e,refuted)).
verdict(c_e50bcb82f3cb6b6e,unknown) :- node(n937,unknown).
query(verdict(c_e50bcb82f3cb6b6e,unknown)).
node(n948,supported) :- status(o_fc2e2391ee64e5b1be81,supported).
node(n948,refuted) :- status(o_fc2e2391ee64e5b1be81,refuted).
node(n948,unknown) :- status(o_fc2e2391ee64e5b1be81,unknown).
node(n947,supported) :- node(n939,supported), node(n940,supported), node(n948,supported), node(n941,supported).
node(n947,refuted) :- node(n939,refuted).
node(n947,refuted) :- node(n940,refuted).
node(n947,refuted) :- node(n948,refuted).
node(n947,refuted) :- node(n941,refuted).
node(n947,unknown) :- \+ node(n947,supported), \+ node(n947,refuted).
node(n950,supported) :- status(o_533e9538d86e08d0687c,supported).
node(n950,refuted) :- status(o_533e9538d86e08d0687c,refuted).
node(n950,unknown) :- status(o_533e9538d86e08d0687c,unknown).
node(n949,supported) :- node(n943,supported), node(n944,supported), node(n950,supported), node(n945,supported).
node(n949,refuted) :- node(n943,refuted).
node(n949,refuted) :- node(n944,refuted).
node(n949,refuted) :- node(n950,refuted).
node(n949,refuted) :- node(n945,refuted).
node(n949,unknown) :- \+ node(n949,supported), \+ node(n949,refuted).
node(n946,refuted) :- node(n947,refuted), node(n949,refuted), node(n9,refuted).
node(n946,supported) :- node(n947,supported).
node(n946,supported) :- node(n949,supported).
node(n946,supported) :- node(n9,supported).
node(n946,unknown) :- \+ node(n946,supported), \+ node(n946,refuted).
verdict(c_693dda55f14571a0,supported) :- node(n946,supported).
query(verdict(c_693dda55f14571a0,supported)).
verdict(c_693dda55f14571a0,refuted) :- node(n946,refuted).
query(verdict(c_693dda55f14571a0,refuted)).
verdict(c_693dda55f14571a0,unknown) :- node(n946,unknown).
query(verdict(c_693dda55f14571a0,unknown)).
node(n953,supported) :- status(o_8509ef55adc33bf673e0,supported).
node(n953,refuted) :- status(o_8509ef55adc33bf673e0,refuted).
node(n953,unknown) :- status(o_8509ef55adc33bf673e0,unknown).
node(n954,supported) :- status(o_217eee88d6f48a693fa1,supported).
node(n954,refuted) :- status(o_217eee88d6f48a693fa1,refuted).
node(n954,unknown) :- status(o_217eee88d6f48a693fa1,unknown).
node(n955,supported) :- status(o_ce471059f3edb76ec69e,supported).
node(n955,refuted) :- status(o_ce471059f3edb76ec69e,refuted).
node(n955,unknown) :- status(o_ce471059f3edb76ec69e,unknown).
node(n952,supported) :- node(n953,supported), node(n954,supported), node(n955,supported).
node(n952,refuted) :- node(n953,refuted).
node(n952,refuted) :- node(n954,refuted).
node(n952,refuted) :- node(n955,refuted).
node(n952,unknown) :- \+ node(n952,supported), \+ node(n952,refuted).
node(n957,supported) :- status(o_9faab04386fc89f65ed1,supported).
node(n957,refuted) :- status(o_9faab04386fc89f65ed1,refuted).
node(n957,unknown) :- status(o_9faab04386fc89f65ed1,unknown).
node(n958,supported) :- status(o_837ad0acca3f476f0e0e,supported).
node(n958,refuted) :- status(o_837ad0acca3f476f0e0e,refuted).
node(n958,unknown) :- status(o_837ad0acca3f476f0e0e,unknown).
node(n959,supported) :- status(o_70865af1be6f3e96a862,supported).
node(n959,refuted) :- status(o_70865af1be6f3e96a862,refuted).
node(n959,unknown) :- status(o_70865af1be6f3e96a862,unknown).
node(n956,supported) :- node(n957,supported), node(n958,supported), node(n959,supported).
node(n956,refuted) :- node(n957,refuted).
node(n956,refuted) :- node(n958,refuted).
node(n956,refuted) :- node(n959,refuted).
node(n956,unknown) :- \+ node(n956,supported), \+ node(n956,refuted).
node(n951,refuted) :- node(n952,refuted), node(n956,refuted), node(n9,refuted).
node(n951,supported) :- node(n952,supported).
node(n951,supported) :- node(n956,supported).
node(n951,supported) :- node(n9,supported).
node(n951,unknown) :- \+ node(n951,supported), \+ node(n951,refuted).
verdict(c_3f99d938a1fd97e4,supported) :- node(n951,supported).
query(verdict(c_3f99d938a1fd97e4,supported)).
verdict(c_3f99d938a1fd97e4,refuted) :- node(n951,refuted).
query(verdict(c_3f99d938a1fd97e4,refuted)).
verdict(c_3f99d938a1fd97e4,unknown) :- node(n951,unknown).
query(verdict(c_3f99d938a1fd97e4,unknown)).
node(n962,supported) :- status(o_a1cacc5a8516f0025956,supported).
node(n962,refuted) :- status(o_a1cacc5a8516f0025956,refuted).
node(n962,unknown) :- status(o_a1cacc5a8516f0025956,unknown).
node(n961,supported) :- node(n953,supported), node(n954,supported), node(n962,supported), node(n955,supported).
node(n961,refuted) :- node(n953,refuted).
node(n961,refuted) :- node(n954,refuted).
node(n961,refuted) :- node(n962,refuted).
node(n961,refuted) :- node(n955,refuted).
node(n961,unknown) :- \+ node(n961,supported), \+ node(n961,refuted).
node(n964,supported) :- status(o_b5469a9631104dd67b04,supported).
node(n964,refuted) :- status(o_b5469a9631104dd67b04,refuted).
node(n964,unknown) :- status(o_b5469a9631104dd67b04,unknown).
node(n963,supported) :- node(n957,supported), node(n958,supported), node(n964,supported), node(n959,supported).
node(n963,refuted) :- node(n957,refuted).
node(n963,refuted) :- node(n958,refuted).
node(n963,refuted) :- node(n964,refuted).
node(n963,refuted) :- node(n959,refuted).
node(n963,unknown) :- \+ node(n963,supported), \+ node(n963,refuted).
node(n960,refuted) :- node(n961,refuted), node(n963,refuted), node(n9,refuted).
node(n960,supported) :- node(n961,supported).
node(n960,supported) :- node(n963,supported).
node(n960,supported) :- node(n9,supported).
node(n960,unknown) :- \+ node(n960,supported), \+ node(n960,refuted).
verdict(c_5acaa957173ccbf0,supported) :- node(n960,supported).
query(verdict(c_5acaa957173ccbf0,supported)).
verdict(c_5acaa957173ccbf0,refuted) :- node(n960,refuted).
query(verdict(c_5acaa957173ccbf0,refuted)).
verdict(c_5acaa957173ccbf0,unknown) :- node(n960,unknown).
query(verdict(c_5acaa957173ccbf0,unknown)).
node(n967,supported) :- status(o_50971347455099471fdc,supported).
node(n967,refuted) :- status(o_50971347455099471fdc,refuted).
node(n967,unknown) :- status(o_50971347455099471fdc,unknown).
node(n968,supported) :- status(o_cee4d72d02c6d9ca6ea1,supported).
node(n968,refuted) :- status(o_cee4d72d02c6d9ca6ea1,refuted).
node(n968,unknown) :- status(o_cee4d72d02c6d9ca6ea1,unknown).
node(n969,supported) :- status(o_f1e6893f088760188f97,supported).
node(n969,refuted) :- status(o_f1e6893f088760188f97,refuted).
node(n969,unknown) :- status(o_f1e6893f088760188f97,unknown).
node(n966,supported) :- node(n967,supported), node(n968,supported), node(n969,supported).
node(n966,refuted) :- node(n967,refuted).
node(n966,refuted) :- node(n968,refuted).
node(n966,refuted) :- node(n969,refuted).
node(n966,unknown) :- \+ node(n966,supported), \+ node(n966,refuted).
node(n971,supported) :- status(o_14fef005a694e0ee7732,supported).
node(n971,refuted) :- status(o_14fef005a694e0ee7732,refuted).
node(n971,unknown) :- status(o_14fef005a694e0ee7732,unknown).
node(n972,supported) :- status(o_e3ed2d883b167f5d2873,supported).
node(n972,refuted) :- status(o_e3ed2d883b167f5d2873,refuted).
node(n972,unknown) :- status(o_e3ed2d883b167f5d2873,unknown).
node(n973,supported) :- status(o_09b238a23fe4af8cacd1,supported).
node(n973,refuted) :- status(o_09b238a23fe4af8cacd1,refuted).
node(n973,unknown) :- status(o_09b238a23fe4af8cacd1,unknown).
node(n970,supported) :- node(n971,supported), node(n972,supported), node(n973,supported).
node(n970,refuted) :- node(n971,refuted).
node(n970,refuted) :- node(n972,refuted).
node(n970,refuted) :- node(n973,refuted).
node(n970,unknown) :- \+ node(n970,supported), \+ node(n970,refuted).
node(n965,refuted) :- node(n966,refuted), node(n970,refuted), node(n9,refuted).
node(n965,supported) :- node(n966,supported).
node(n965,supported) :- node(n970,supported).
node(n965,supported) :- node(n9,supported).
node(n965,unknown) :- \+ node(n965,supported), \+ node(n965,refuted).
verdict(c_374140956894c9ee,supported) :- node(n965,supported).
query(verdict(c_374140956894c9ee,supported)).
verdict(c_374140956894c9ee,refuted) :- node(n965,refuted).
query(verdict(c_374140956894c9ee,refuted)).
verdict(c_374140956894c9ee,unknown) :- node(n965,unknown).
query(verdict(c_374140956894c9ee,unknown)).
node(n976,supported) :- status(o_7e6d1e9d390d01146f61,supported).
node(n976,refuted) :- status(o_7e6d1e9d390d01146f61,refuted).
node(n976,unknown) :- status(o_7e6d1e9d390d01146f61,unknown).
node(n975,supported) :- node(n967,supported), node(n968,supported), node(n976,supported), node(n969,supported).
node(n975,refuted) :- node(n967,refuted).
node(n975,refuted) :- node(n968,refuted).
node(n975,refuted) :- node(n976,refuted).
node(n975,refuted) :- node(n969,refuted).
node(n975,unknown) :- \+ node(n975,supported), \+ node(n975,refuted).
node(n978,supported) :- status(o_98225b54cc668445b322,supported).
node(n978,refuted) :- status(o_98225b54cc668445b322,refuted).
node(n978,unknown) :- status(o_98225b54cc668445b322,unknown).
node(n977,supported) :- node(n971,supported), node(n972,supported), node(n978,supported), node(n973,supported).
node(n977,refuted) :- node(n971,refuted).
node(n977,refuted) :- node(n972,refuted).
node(n977,refuted) :- node(n978,refuted).
node(n977,refuted) :- node(n973,refuted).
node(n977,unknown) :- \+ node(n977,supported), \+ node(n977,refuted).
node(n974,refuted) :- node(n975,refuted), node(n977,refuted), node(n9,refuted).
node(n974,supported) :- node(n975,supported).
node(n974,supported) :- node(n977,supported).
node(n974,supported) :- node(n9,supported).
node(n974,unknown) :- \+ node(n974,supported), \+ node(n974,refuted).
verdict(c_48ac78b100182f37,supported) :- node(n974,supported).
query(verdict(c_48ac78b100182f37,supported)).
verdict(c_48ac78b100182f37,refuted) :- node(n974,refuted).
query(verdict(c_48ac78b100182f37,refuted)).
verdict(c_48ac78b100182f37,unknown) :- node(n974,unknown).
query(verdict(c_48ac78b100182f37,unknown)).
node(n981,supported) :- status(o_4bca52c95c013cb5b8ab,supported).
node(n981,refuted) :- status(o_4bca52c95c013cb5b8ab,refuted).
node(n981,unknown) :- status(o_4bca52c95c013cb5b8ab,unknown).
node(n982,supported) :- status(o_f5886bd2162651b8f351,supported).
node(n982,refuted) :- status(o_f5886bd2162651b8f351,refuted).
node(n982,unknown) :- status(o_f5886bd2162651b8f351,unknown).
node(n983,supported) :- status(o_bef7109ddbb42cd4b312,supported).
node(n983,refuted) :- status(o_bef7109ddbb42cd4b312,refuted).
node(n983,unknown) :- status(o_bef7109ddbb42cd4b312,unknown).
node(n980,supported) :- node(n981,supported), node(n982,supported), node(n983,supported).
node(n980,refuted) :- node(n981,refuted).
node(n980,refuted) :- node(n982,refuted).
node(n980,refuted) :- node(n983,refuted).
node(n980,unknown) :- \+ node(n980,supported), \+ node(n980,refuted).
node(n985,supported) :- status(o_863ac15c051c41c6fb0e,supported).
node(n985,refuted) :- status(o_863ac15c051c41c6fb0e,refuted).
node(n985,unknown) :- status(o_863ac15c051c41c6fb0e,unknown).
node(n986,supported) :- status(o_4c5c44c26ad6679b527c,supported).
node(n986,refuted) :- status(o_4c5c44c26ad6679b527c,refuted).
node(n986,unknown) :- status(o_4c5c44c26ad6679b527c,unknown).
node(n987,supported) :- status(o_eb5dbc2db32db19535e4,supported).
node(n987,refuted) :- status(o_eb5dbc2db32db19535e4,refuted).
node(n987,unknown) :- status(o_eb5dbc2db32db19535e4,unknown).
node(n984,supported) :- node(n985,supported), node(n986,supported), node(n987,supported).
node(n984,refuted) :- node(n985,refuted).
node(n984,refuted) :- node(n986,refuted).
node(n984,refuted) :- node(n987,refuted).
node(n984,unknown) :- \+ node(n984,supported), \+ node(n984,refuted).
node(n979,refuted) :- node(n980,refuted), node(n984,refuted), node(n9,refuted).
node(n979,supported) :- node(n980,supported).
node(n979,supported) :- node(n984,supported).
node(n979,supported) :- node(n9,supported).
node(n979,unknown) :- \+ node(n979,supported), \+ node(n979,refuted).
verdict(c_ab7d72e561a7b8ca,supported) :- node(n979,supported).
query(verdict(c_ab7d72e561a7b8ca,supported)).
verdict(c_ab7d72e561a7b8ca,refuted) :- node(n979,refuted).
query(verdict(c_ab7d72e561a7b8ca,refuted)).
verdict(c_ab7d72e561a7b8ca,unknown) :- node(n979,unknown).
query(verdict(c_ab7d72e561a7b8ca,unknown)).
node(n990,supported) :- status(o_1c102ea19fa41cc6f7b5,supported).
node(n990,refuted) :- status(o_1c102ea19fa41cc6f7b5,refuted).
node(n990,unknown) :- status(o_1c102ea19fa41cc6f7b5,unknown).
node(n989,supported) :- node(n981,supported), node(n982,supported), node(n990,supported), node(n983,supported).
node(n989,refuted) :- node(n981,refuted).
node(n989,refuted) :- node(n982,refuted).
node(n989,refuted) :- node(n990,refuted).
node(n989,refuted) :- node(n983,refuted).
node(n989,unknown) :- \+ node(n989,supported), \+ node(n989,refuted).
node(n992,supported) :- status(o_bcf23991d5b6948b8f4c,supported).
node(n992,refuted) :- status(o_bcf23991d5b6948b8f4c,refuted).
node(n992,unknown) :- status(o_bcf23991d5b6948b8f4c,unknown).
node(n991,supported) :- node(n985,supported), node(n986,supported), node(n992,supported), node(n987,supported).
node(n991,refuted) :- node(n985,refuted).
node(n991,refuted) :- node(n986,refuted).
node(n991,refuted) :- node(n992,refuted).
node(n991,refuted) :- node(n987,refuted).
node(n991,unknown) :- \+ node(n991,supported), \+ node(n991,refuted).
node(n988,refuted) :- node(n989,refuted), node(n991,refuted), node(n9,refuted).
node(n988,supported) :- node(n989,supported).
node(n988,supported) :- node(n991,supported).
node(n988,supported) :- node(n9,supported).
node(n988,unknown) :- \+ node(n988,supported), \+ node(n988,refuted).
verdict(c_78ad70a2f478aa40,supported) :- node(n988,supported).
query(verdict(c_78ad70a2f478aa40,supported)).
verdict(c_78ad70a2f478aa40,refuted) :- node(n988,refuted).
query(verdict(c_78ad70a2f478aa40,refuted)).
verdict(c_78ad70a2f478aa40,unknown) :- node(n988,unknown).
query(verdict(c_78ad70a2f478aa40,unknown)).
node(n995,supported) :- status(o_a000b1a83a8285c61c3a,supported).
node(n995,refuted) :- status(o_a000b1a83a8285c61c3a,refuted).
node(n995,unknown) :- status(o_a000b1a83a8285c61c3a,unknown).
node(n996,supported) :- status(o_4bbe840db4065bfc6c84,supported).
node(n996,refuted) :- status(o_4bbe840db4065bfc6c84,refuted).
node(n996,unknown) :- status(o_4bbe840db4065bfc6c84,unknown).
node(n997,supported) :- status(o_729d639a8e4320e8ebe8,supported).
node(n997,refuted) :- status(o_729d639a8e4320e8ebe8,refuted).
node(n997,unknown) :- status(o_729d639a8e4320e8ebe8,unknown).
node(n994,supported) :- node(n995,supported), node(n996,supported), node(n997,supported).
node(n994,refuted) :- node(n995,refuted).
node(n994,refuted) :- node(n996,refuted).
node(n994,refuted) :- node(n997,refuted).
node(n994,unknown) :- \+ node(n994,supported), \+ node(n994,refuted).
node(n993,refuted) :- node(n994,refuted), node(n9,refuted).
node(n993,supported) :- node(n994,supported).
node(n993,supported) :- node(n9,supported).
node(n993,unknown) :- \+ node(n993,supported), \+ node(n993,refuted).
verdict(c_f0a74aa9b5829501,supported) :- node(n993,supported).
query(verdict(c_f0a74aa9b5829501,supported)).
verdict(c_f0a74aa9b5829501,refuted) :- node(n993,refuted).
query(verdict(c_f0a74aa9b5829501,refuted)).
verdict(c_f0a74aa9b5829501,unknown) :- node(n993,unknown).
query(verdict(c_f0a74aa9b5829501,unknown)).
node(n1000,supported) :- status(o_c249d16667f4761fac5d,supported).
node(n1000,refuted) :- status(o_c249d16667f4761fac5d,refuted).
node(n1000,unknown) :- status(o_c249d16667f4761fac5d,unknown).
node(n999,supported) :- node(n995,supported), node(n996,supported), node(n1000,supported), node(n997,supported).
node(n999,refuted) :- node(n995,refuted).
node(n999,refuted) :- node(n996,refuted).
node(n999,refuted) :- node(n1000,refuted).
node(n999,refuted) :- node(n997,refuted).
node(n999,unknown) :- \+ node(n999,supported), \+ node(n999,refuted).
node(n998,refuted) :- node(n999,refuted), node(n9,refuted).
node(n998,supported) :- node(n999,supported).
node(n998,supported) :- node(n9,supported).
node(n998,unknown) :- \+ node(n998,supported), \+ node(n998,refuted).
verdict(c_72937407fa549517,supported) :- node(n998,supported).
query(verdict(c_72937407fa549517,supported)).
verdict(c_72937407fa549517,refuted) :- node(n998,refuted).
query(verdict(c_72937407fa549517,refuted)).
verdict(c_72937407fa549517,unknown) :- node(n998,unknown).
query(verdict(c_72937407fa549517,unknown)).
node(n1003,supported) :- status(o_8074d8c8add830483027,supported).
node(n1003,refuted) :- status(o_8074d8c8add830483027,refuted).
node(n1003,unknown) :- status(o_8074d8c8add830483027,unknown).
node(n1004,supported) :- status(o_79382d61888a85fc7ba0,supported).
node(n1004,refuted) :- status(o_79382d61888a85fc7ba0,refuted).
node(n1004,unknown) :- status(o_79382d61888a85fc7ba0,unknown).
node(n1005,supported) :- status(o_acfa28449ce40418c684,supported).
node(n1005,refuted) :- status(o_acfa28449ce40418c684,refuted).
node(n1005,unknown) :- status(o_acfa28449ce40418c684,unknown).
node(n1002,supported) :- node(n1003,supported), node(n1004,supported), node(n1005,supported).
node(n1002,refuted) :- node(n1003,refuted).
node(n1002,refuted) :- node(n1004,refuted).
node(n1002,refuted) :- node(n1005,refuted).
node(n1002,unknown) :- \+ node(n1002,supported), \+ node(n1002,refuted).
node(n1001,refuted) :- node(n1002,refuted), node(n9,refuted).
node(n1001,supported) :- node(n1002,supported).
node(n1001,supported) :- node(n9,supported).
node(n1001,unknown) :- \+ node(n1001,supported), \+ node(n1001,refuted).
verdict(c_381edcb9c7c7c7e4,supported) :- node(n1001,supported).
query(verdict(c_381edcb9c7c7c7e4,supported)).
verdict(c_381edcb9c7c7c7e4,refuted) :- node(n1001,refuted).
query(verdict(c_381edcb9c7c7c7e4,refuted)).
verdict(c_381edcb9c7c7c7e4,unknown) :- node(n1001,unknown).
query(verdict(c_381edcb9c7c7c7e4,unknown)).
node(n1008,supported) :- status(o_fdd34cba933e30603ae3,supported).
node(n1008,refuted) :- status(o_fdd34cba933e30603ae3,refuted).
node(n1008,unknown) :- status(o_fdd34cba933e30603ae3,unknown).
node(n1007,supported) :- node(n1003,supported), node(n1004,supported), node(n1008,supported), node(n1005,supported).
node(n1007,refuted) :- node(n1003,refuted).
node(n1007,refuted) :- node(n1004,refuted).
node(n1007,refuted) :- node(n1008,refuted).
node(n1007,refuted) :- node(n1005,refuted).
node(n1007,unknown) :- \+ node(n1007,supported), \+ node(n1007,refuted).
node(n1006,refuted) :- node(n1007,refuted), node(n9,refuted).
node(n1006,supported) :- node(n1007,supported).
node(n1006,supported) :- node(n9,supported).
node(n1006,unknown) :- \+ node(n1006,supported), \+ node(n1006,refuted).
verdict(c_8d65096f9d931fc0,supported) :- node(n1006,supported).
query(verdict(c_8d65096f9d931fc0,supported)).
verdict(c_8d65096f9d931fc0,refuted) :- node(n1006,refuted).
query(verdict(c_8d65096f9d931fc0,refuted)).
verdict(c_8d65096f9d931fc0,unknown) :- node(n1006,unknown).
query(verdict(c_8d65096f9d931fc0,unknown)).
node(n1011,supported) :- status(o_cc3b8c84f2cfab7e78ba,supported).
node(n1011,refuted) :- status(o_cc3b8c84f2cfab7e78ba,refuted).
node(n1011,unknown) :- status(o_cc3b8c84f2cfab7e78ba,unknown).
node(n1012,supported) :- status(o_267b5b0b56834cb3c2f5,supported).
node(n1012,refuted) :- status(o_267b5b0b56834cb3c2f5,refuted).
node(n1012,unknown) :- status(o_267b5b0b56834cb3c2f5,unknown).
node(n1013,supported) :- status(o_c6bb737d309959d1de9c,supported).
node(n1013,refuted) :- status(o_c6bb737d309959d1de9c,refuted).
node(n1013,unknown) :- status(o_c6bb737d309959d1de9c,unknown).
node(n1010,supported) :- node(n1011,supported), node(n1012,supported), node(n1013,supported).
node(n1010,refuted) :- node(n1011,refuted).
node(n1010,refuted) :- node(n1012,refuted).
node(n1010,refuted) :- node(n1013,refuted).
node(n1010,unknown) :- \+ node(n1010,supported), \+ node(n1010,refuted).
node(n1015,supported) :- status(o_6fe268939122920fc664,supported).
node(n1015,refuted) :- status(o_6fe268939122920fc664,refuted).
node(n1015,unknown) :- status(o_6fe268939122920fc664,unknown).
node(n1016,supported) :- status(o_b4ea2d93469199ed9d0b,supported).
node(n1016,refuted) :- status(o_b4ea2d93469199ed9d0b,refuted).
node(n1016,unknown) :- status(o_b4ea2d93469199ed9d0b,unknown).
node(n1017,supported) :- status(o_a3a88c8517287f14d09f,supported).
node(n1017,refuted) :- status(o_a3a88c8517287f14d09f,refuted).
node(n1017,unknown) :- status(o_a3a88c8517287f14d09f,unknown).
node(n1014,supported) :- node(n1015,supported), node(n1016,supported), node(n1017,supported).
node(n1014,refuted) :- node(n1015,refuted).
node(n1014,refuted) :- node(n1016,refuted).
node(n1014,refuted) :- node(n1017,refuted).
node(n1014,unknown) :- \+ node(n1014,supported), \+ node(n1014,refuted).
node(n1009,refuted) :- node(n1010,refuted), node(n1014,refuted), node(n9,refuted).
node(n1009,supported) :- node(n1010,supported).
node(n1009,supported) :- node(n1014,supported).
node(n1009,supported) :- node(n9,supported).
node(n1009,unknown) :- \+ node(n1009,supported), \+ node(n1009,refuted).
verdict(c_784d157fd66ee963,supported) :- node(n1009,supported).
query(verdict(c_784d157fd66ee963,supported)).
verdict(c_784d157fd66ee963,refuted) :- node(n1009,refuted).
query(verdict(c_784d157fd66ee963,refuted)).
verdict(c_784d157fd66ee963,unknown) :- node(n1009,unknown).
query(verdict(c_784d157fd66ee963,unknown)).
node(n1020,supported) :- status(o_ef9eaadfe73950a55feb,supported).
node(n1020,refuted) :- status(o_ef9eaadfe73950a55feb,refuted).
node(n1020,unknown) :- status(o_ef9eaadfe73950a55feb,unknown).
node(n1019,supported) :- node(n1011,supported), node(n1012,supported), node(n1020,supported), node(n1013,supported).
node(n1019,refuted) :- node(n1011,refuted).
node(n1019,refuted) :- node(n1012,refuted).
node(n1019,refuted) :- node(n1020,refuted).
node(n1019,refuted) :- node(n1013,refuted).
node(n1019,unknown) :- \+ node(n1019,supported), \+ node(n1019,refuted).
node(n1022,supported) :- status(o_0c90bca29a4e311111cd,supported).
node(n1022,refuted) :- status(o_0c90bca29a4e311111cd,refuted).
node(n1022,unknown) :- status(o_0c90bca29a4e311111cd,unknown).
node(n1021,supported) :- node(n1015,supported), node(n1016,supported), node(n1022,supported), node(n1017,supported).
node(n1021,refuted) :- node(n1015,refuted).
node(n1021,refuted) :- node(n1016,refuted).
node(n1021,refuted) :- node(n1022,refuted).
node(n1021,refuted) :- node(n1017,refuted).
node(n1021,unknown) :- \+ node(n1021,supported), \+ node(n1021,refuted).
node(n1018,refuted) :- node(n1019,refuted), node(n1021,refuted), node(n9,refuted).
node(n1018,supported) :- node(n1019,supported).
node(n1018,supported) :- node(n1021,supported).
node(n1018,supported) :- node(n9,supported).
node(n1018,unknown) :- \+ node(n1018,supported), \+ node(n1018,refuted).
verdict(c_bfe59da6ef073530,supported) :- node(n1018,supported).
query(verdict(c_bfe59da6ef073530,supported)).
verdict(c_bfe59da6ef073530,refuted) :- node(n1018,refuted).
query(verdict(c_bfe59da6ef073530,refuted)).
verdict(c_bfe59da6ef073530,unknown) :- node(n1018,unknown).
query(verdict(c_bfe59da6ef073530,unknown)).
node(n1025,supported) :- status(o_c71fc8a56ea3c02c3252,supported).
node(n1025,refuted) :- status(o_c71fc8a56ea3c02c3252,refuted).
node(n1025,unknown) :- status(o_c71fc8a56ea3c02c3252,unknown).
node(n1026,supported) :- status(o_b8414827f35113e9dffd,supported).
node(n1026,refuted) :- status(o_b8414827f35113e9dffd,refuted).
node(n1026,unknown) :- status(o_b8414827f35113e9dffd,unknown).
node(n1027,supported) :- status(o_2b9644fae39bbf492314,supported).
node(n1027,refuted) :- status(o_2b9644fae39bbf492314,refuted).
node(n1027,unknown) :- status(o_2b9644fae39bbf492314,unknown).
node(n1024,supported) :- node(n1025,supported), node(n1026,supported), node(n1027,supported).
node(n1024,refuted) :- node(n1025,refuted).
node(n1024,refuted) :- node(n1026,refuted).
node(n1024,refuted) :- node(n1027,refuted).
node(n1024,unknown) :- \+ node(n1024,supported), \+ node(n1024,refuted).
node(n1029,supported) :- status(o_89498c0173051a3cfa1d,supported).
node(n1029,refuted) :- status(o_89498c0173051a3cfa1d,refuted).
node(n1029,unknown) :- status(o_89498c0173051a3cfa1d,unknown).
node(n1030,supported) :- status(o_5ee2f790fea281a947ed,supported).
node(n1030,refuted) :- status(o_5ee2f790fea281a947ed,refuted).
node(n1030,unknown) :- status(o_5ee2f790fea281a947ed,unknown).
node(n1031,supported) :- status(o_4383f569be8bbd298ec9,supported).
node(n1031,refuted) :- status(o_4383f569be8bbd298ec9,refuted).
node(n1031,unknown) :- status(o_4383f569be8bbd298ec9,unknown).
node(n1028,supported) :- node(n1029,supported), node(n1030,supported), node(n1031,supported).
node(n1028,refuted) :- node(n1029,refuted).
node(n1028,refuted) :- node(n1030,refuted).
node(n1028,refuted) :- node(n1031,refuted).
node(n1028,unknown) :- \+ node(n1028,supported), \+ node(n1028,refuted).
node(n1023,refuted) :- node(n1024,refuted), node(n1028,refuted), node(n9,refuted).
node(n1023,supported) :- node(n1024,supported).
node(n1023,supported) :- node(n1028,supported).
node(n1023,supported) :- node(n9,supported).
node(n1023,unknown) :- \+ node(n1023,supported), \+ node(n1023,refuted).
verdict(c_2828f6537ac8335d,supported) :- node(n1023,supported).
query(verdict(c_2828f6537ac8335d,supported)).
verdict(c_2828f6537ac8335d,refuted) :- node(n1023,refuted).
query(verdict(c_2828f6537ac8335d,refuted)).
verdict(c_2828f6537ac8335d,unknown) :- node(n1023,unknown).
query(verdict(c_2828f6537ac8335d,unknown)).
node(n1034,supported) :- status(o_a9970893fae10dea967c,supported).
node(n1034,refuted) :- status(o_a9970893fae10dea967c,refuted).
node(n1034,unknown) :- status(o_a9970893fae10dea967c,unknown).
node(n1033,supported) :- node(n1025,supported), node(n1026,supported), node(n1034,supported), node(n1027,supported).
node(n1033,refuted) :- node(n1025,refuted).
node(n1033,refuted) :- node(n1026,refuted).
node(n1033,refuted) :- node(n1034,refuted).
node(n1033,refuted) :- node(n1027,refuted).
node(n1033,unknown) :- \+ node(n1033,supported), \+ node(n1033,refuted).
node(n1036,supported) :- status(o_02598e26aba3f04f7414,supported).
node(n1036,refuted) :- status(o_02598e26aba3f04f7414,refuted).
node(n1036,unknown) :- status(o_02598e26aba3f04f7414,unknown).
node(n1035,supported) :- node(n1029,supported), node(n1030,supported), node(n1036,supported), node(n1031,supported).
node(n1035,refuted) :- node(n1029,refuted).
node(n1035,refuted) :- node(n1030,refuted).
node(n1035,refuted) :- node(n1036,refuted).
node(n1035,refuted) :- node(n1031,refuted).
node(n1035,unknown) :- \+ node(n1035,supported), \+ node(n1035,refuted).
node(n1032,refuted) :- node(n1033,refuted), node(n1035,refuted), node(n9,refuted).
node(n1032,supported) :- node(n1033,supported).
node(n1032,supported) :- node(n1035,supported).
node(n1032,supported) :- node(n9,supported).
node(n1032,unknown) :- \+ node(n1032,supported), \+ node(n1032,refuted).
verdict(c_e13bd59aa8fd7233,supported) :- node(n1032,supported).
query(verdict(c_e13bd59aa8fd7233,supported)).
verdict(c_e13bd59aa8fd7233,refuted) :- node(n1032,refuted).
query(verdict(c_e13bd59aa8fd7233,refuted)).
verdict(c_e13bd59aa8fd7233,unknown) :- node(n1032,unknown).
query(verdict(c_e13bd59aa8fd7233,unknown)).
node(n1039,supported) :- status(o_d66a466f6baa370526cc,supported).
node(n1039,refuted) :- status(o_d66a466f6baa370526cc,refuted).
node(n1039,unknown) :- status(o_d66a466f6baa370526cc,unknown).
node(n1040,supported) :- status(o_d6336b584fbc3a69eaa1,supported).
node(n1040,refuted) :- status(o_d6336b584fbc3a69eaa1,refuted).
node(n1040,unknown) :- status(o_d6336b584fbc3a69eaa1,unknown).
node(n1041,supported) :- status(o_fb48c389cd39727c9307,supported).
node(n1041,refuted) :- status(o_fb48c389cd39727c9307,refuted).
node(n1041,unknown) :- status(o_fb48c389cd39727c9307,unknown).
node(n1038,supported) :- node(n1039,supported), node(n1040,supported), node(n1041,supported).
node(n1038,refuted) :- node(n1039,refuted).
node(n1038,refuted) :- node(n1040,refuted).
node(n1038,refuted) :- node(n1041,refuted).
node(n1038,unknown) :- \+ node(n1038,supported), \+ node(n1038,refuted).
node(n1037,refuted) :- node(n1038,refuted), node(n9,refuted).
node(n1037,supported) :- node(n1038,supported).
node(n1037,supported) :- node(n9,supported).
node(n1037,unknown) :- \+ node(n1037,supported), \+ node(n1037,refuted).
verdict(c_da18ee0d8a977215,supported) :- node(n1037,supported).
query(verdict(c_da18ee0d8a977215,supported)).
verdict(c_da18ee0d8a977215,refuted) :- node(n1037,refuted).
query(verdict(c_da18ee0d8a977215,refuted)).
verdict(c_da18ee0d8a977215,unknown) :- node(n1037,unknown).
query(verdict(c_da18ee0d8a977215,unknown)).
node(n1044,supported) :- status(o_5de500d84c14aa36d180,supported).
node(n1044,refuted) :- status(o_5de500d84c14aa36d180,refuted).
node(n1044,unknown) :- status(o_5de500d84c14aa36d180,unknown).
node(n1043,supported) :- node(n1039,supported), node(n1040,supported), node(n1044,supported), node(n1041,supported).
node(n1043,refuted) :- node(n1039,refuted).
node(n1043,refuted) :- node(n1040,refuted).
node(n1043,refuted) :- node(n1044,refuted).
node(n1043,refuted) :- node(n1041,refuted).
node(n1043,unknown) :- \+ node(n1043,supported), \+ node(n1043,refuted).
node(n1042,refuted) :- node(n1043,refuted), node(n9,refuted).
node(n1042,supported) :- node(n1043,supported).
node(n1042,supported) :- node(n9,supported).
node(n1042,unknown) :- \+ node(n1042,supported), \+ node(n1042,refuted).
verdict(c_9579a49d35782ac6,supported) :- node(n1042,supported).
query(verdict(c_9579a49d35782ac6,supported)).
verdict(c_9579a49d35782ac6,refuted) :- node(n1042,refuted).
query(verdict(c_9579a49d35782ac6,refuted)).
verdict(c_9579a49d35782ac6,unknown) :- node(n1042,unknown).
query(verdict(c_9579a49d35782ac6,unknown)).
node(n1047,supported) :- status(o_9ea8f089ba0e5881a538,supported).
node(n1047,refuted) :- status(o_9ea8f089ba0e5881a538,refuted).
node(n1047,unknown) :- status(o_9ea8f089ba0e5881a538,unknown).
node(n1048,supported) :- status(o_6f339ef01849b86af0ba,supported).
node(n1048,refuted) :- status(o_6f339ef01849b86af0ba,refuted).
node(n1048,unknown) :- status(o_6f339ef01849b86af0ba,unknown).
node(n1049,supported) :- status(o_bf4b91d72c479726340a,supported).
node(n1049,refuted) :- status(o_bf4b91d72c479726340a,refuted).
node(n1049,unknown) :- status(o_bf4b91d72c479726340a,unknown).
node(n1046,supported) :- node(n1047,supported), node(n1048,supported), node(n1049,supported).
node(n1046,refuted) :- node(n1047,refuted).
node(n1046,refuted) :- node(n1048,refuted).
node(n1046,refuted) :- node(n1049,refuted).
node(n1046,unknown) :- \+ node(n1046,supported), \+ node(n1046,refuted).
node(n1045,refuted) :- node(n1046,refuted), node(n9,refuted).
node(n1045,supported) :- node(n1046,supported).
node(n1045,supported) :- node(n9,supported).
node(n1045,unknown) :- \+ node(n1045,supported), \+ node(n1045,refuted).
verdict(c_1ac68d9c586ae735,supported) :- node(n1045,supported).
query(verdict(c_1ac68d9c586ae735,supported)).
verdict(c_1ac68d9c586ae735,refuted) :- node(n1045,refuted).
query(verdict(c_1ac68d9c586ae735,refuted)).
verdict(c_1ac68d9c586ae735,unknown) :- node(n1045,unknown).
query(verdict(c_1ac68d9c586ae735,unknown)).
node(n1052,supported) :- status(o_0d41988d33bb0f0a7147,supported).
node(n1052,refuted) :- status(o_0d41988d33bb0f0a7147,refuted).
node(n1052,unknown) :- status(o_0d41988d33bb0f0a7147,unknown).
node(n1051,supported) :- node(n1047,supported), node(n1048,supported), node(n1052,supported), node(n1049,supported).
node(n1051,refuted) :- node(n1047,refuted).
node(n1051,refuted) :- node(n1048,refuted).
node(n1051,refuted) :- node(n1052,refuted).
node(n1051,refuted) :- node(n1049,refuted).
node(n1051,unknown) :- \+ node(n1051,supported), \+ node(n1051,refuted).
node(n1050,refuted) :- node(n1051,refuted), node(n9,refuted).
node(n1050,supported) :- node(n1051,supported).
node(n1050,supported) :- node(n9,supported).
node(n1050,unknown) :- \+ node(n1050,supported), \+ node(n1050,refuted).
verdict(c_853c57322191bc82,supported) :- node(n1050,supported).
query(verdict(c_853c57322191bc82,supported)).
verdict(c_853c57322191bc82,refuted) :- node(n1050,refuted).
query(verdict(c_853c57322191bc82,refuted)).
verdict(c_853c57322191bc82,unknown) :- node(n1050,unknown).
query(verdict(c_853c57322191bc82,unknown)).
node(n1055,supported) :- status(o_2b1db21bbc723dc42d7c,supported).
node(n1055,refuted) :- status(o_2b1db21bbc723dc42d7c,refuted).
node(n1055,unknown) :- status(o_2b1db21bbc723dc42d7c,unknown).
node(n1056,supported) :- status(o_b62d5c50944b561f115b,supported).
node(n1056,refuted) :- status(o_b62d5c50944b561f115b,refuted).
node(n1056,unknown) :- status(o_b62d5c50944b561f115b,unknown).
node(n1057,supported) :- status(o_fe94407da10c20b74e32,supported).
node(n1057,refuted) :- status(o_fe94407da10c20b74e32,refuted).
node(n1057,unknown) :- status(o_fe94407da10c20b74e32,unknown).
node(n1054,supported) :- node(n1055,supported), node(n1056,supported), node(n1057,supported).
node(n1054,refuted) :- node(n1055,refuted).
node(n1054,refuted) :- node(n1056,refuted).
node(n1054,refuted) :- node(n1057,refuted).
node(n1054,unknown) :- \+ node(n1054,supported), \+ node(n1054,refuted).
node(n1059,supported) :- status(o_96167a7123b6c2e9f0ec,supported).
node(n1059,refuted) :- status(o_96167a7123b6c2e9f0ec,refuted).
node(n1059,unknown) :- status(o_96167a7123b6c2e9f0ec,unknown).
node(n1060,supported) :- status(o_b0e8bca2d14335cf2d09,supported).
node(n1060,refuted) :- status(o_b0e8bca2d14335cf2d09,refuted).
node(n1060,unknown) :- status(o_b0e8bca2d14335cf2d09,unknown).
node(n1061,supported) :- status(o_4367edc539cfc7d0475a,supported).
node(n1061,refuted) :- status(o_4367edc539cfc7d0475a,refuted).
node(n1061,unknown) :- status(o_4367edc539cfc7d0475a,unknown).
node(n1058,supported) :- node(n1059,supported), node(n1060,supported), node(n1061,supported).
node(n1058,refuted) :- node(n1059,refuted).
node(n1058,refuted) :- node(n1060,refuted).
node(n1058,refuted) :- node(n1061,refuted).
node(n1058,unknown) :- \+ node(n1058,supported), \+ node(n1058,refuted).
node(n1053,refuted) :- node(n1054,refuted), node(n1058,refuted), node(n9,refuted).
node(n1053,supported) :- node(n1054,supported).
node(n1053,supported) :- node(n1058,supported).
node(n1053,supported) :- node(n9,supported).
node(n1053,unknown) :- \+ node(n1053,supported), \+ node(n1053,refuted).
verdict(c_cf8dd306852c7564,supported) :- node(n1053,supported).
query(verdict(c_cf8dd306852c7564,supported)).
verdict(c_cf8dd306852c7564,refuted) :- node(n1053,refuted).
query(verdict(c_cf8dd306852c7564,refuted)).
verdict(c_cf8dd306852c7564,unknown) :- node(n1053,unknown).
query(verdict(c_cf8dd306852c7564,unknown)).
node(n1064,supported) :- status(o_cff621ae48eb4f0c9a97,supported).
node(n1064,refuted) :- status(o_cff621ae48eb4f0c9a97,refuted).
node(n1064,unknown) :- status(o_cff621ae48eb4f0c9a97,unknown).
node(n1063,supported) :- node(n1055,supported), node(n1056,supported), node(n1064,supported), node(n1057,supported).
node(n1063,refuted) :- node(n1055,refuted).
node(n1063,refuted) :- node(n1056,refuted).
node(n1063,refuted) :- node(n1064,refuted).
node(n1063,refuted) :- node(n1057,refuted).
node(n1063,unknown) :- \+ node(n1063,supported), \+ node(n1063,refuted).
node(n1066,supported) :- status(o_ea66860c2e940d9cd5b6,supported).
node(n1066,refuted) :- status(o_ea66860c2e940d9cd5b6,refuted).
node(n1066,unknown) :- status(o_ea66860c2e940d9cd5b6,unknown).
node(n1065,supported) :- node(n1059,supported), node(n1060,supported), node(n1066,supported), node(n1061,supported).
node(n1065,refuted) :- node(n1059,refuted).
node(n1065,refuted) :- node(n1060,refuted).
node(n1065,refuted) :- node(n1066,refuted).
node(n1065,refuted) :- node(n1061,refuted).
node(n1065,unknown) :- \+ node(n1065,supported), \+ node(n1065,refuted).
node(n1062,refuted) :- node(n1063,refuted), node(n1065,refuted), node(n9,refuted).
node(n1062,supported) :- node(n1063,supported).
node(n1062,supported) :- node(n1065,supported).
node(n1062,supported) :- node(n9,supported).
node(n1062,unknown) :- \+ node(n1062,supported), \+ node(n1062,refuted).
verdict(c_e6161446469e0abb,supported) :- node(n1062,supported).
query(verdict(c_e6161446469e0abb,supported)).
verdict(c_e6161446469e0abb,refuted) :- node(n1062,refuted).
query(verdict(c_e6161446469e0abb,refuted)).
verdict(c_e6161446469e0abb,unknown) :- node(n1062,unknown).
query(verdict(c_e6161446469e0abb,unknown)).
node(n1069,supported) :- status(o_1738467a933739f96632,supported).
node(n1069,refuted) :- status(o_1738467a933739f96632,refuted).
node(n1069,unknown) :- status(o_1738467a933739f96632,unknown).
node(n1070,supported) :- status(o_a1c6c4f3d6f09b403b85,supported).
node(n1070,refuted) :- status(o_a1c6c4f3d6f09b403b85,refuted).
node(n1070,unknown) :- status(o_a1c6c4f3d6f09b403b85,unknown).
node(n1071,supported) :- status(o_f0efb8bed3b0ad472d2b,supported).
node(n1071,refuted) :- status(o_f0efb8bed3b0ad472d2b,refuted).
node(n1071,unknown) :- status(o_f0efb8bed3b0ad472d2b,unknown).
node(n1068,supported) :- node(n1069,supported), node(n1070,supported), node(n1071,supported).
node(n1068,refuted) :- node(n1069,refuted).
node(n1068,refuted) :- node(n1070,refuted).
node(n1068,refuted) :- node(n1071,refuted).
node(n1068,unknown) :- \+ node(n1068,supported), \+ node(n1068,refuted).
node(n1073,supported) :- status(o_8582954a008614b11285,supported).
node(n1073,refuted) :- status(o_8582954a008614b11285,refuted).
node(n1073,unknown) :- status(o_8582954a008614b11285,unknown).
node(n1074,supported) :- status(o_94688c8225449e6c6486,supported).
node(n1074,refuted) :- status(o_94688c8225449e6c6486,refuted).
node(n1074,unknown) :- status(o_94688c8225449e6c6486,unknown).
node(n1075,supported) :- status(o_079ffb8014e36063f7f1,supported).
node(n1075,refuted) :- status(o_079ffb8014e36063f7f1,refuted).
node(n1075,unknown) :- status(o_079ffb8014e36063f7f1,unknown).
node(n1072,supported) :- node(n1073,supported), node(n1074,supported), node(n1075,supported).
node(n1072,refuted) :- node(n1073,refuted).
node(n1072,refuted) :- node(n1074,refuted).
node(n1072,refuted) :- node(n1075,refuted).
node(n1072,unknown) :- \+ node(n1072,supported), \+ node(n1072,refuted).
node(n1067,refuted) :- node(n1068,refuted), node(n1072,refuted), node(n9,refuted).
node(n1067,supported) :- node(n1068,supported).
node(n1067,supported) :- node(n1072,supported).
node(n1067,supported) :- node(n9,supported).
node(n1067,unknown) :- \+ node(n1067,supported), \+ node(n1067,refuted).
verdict(c_0bf5055da2c5348e,supported) :- node(n1067,supported).
query(verdict(c_0bf5055da2c5348e,supported)).
verdict(c_0bf5055da2c5348e,refuted) :- node(n1067,refuted).
query(verdict(c_0bf5055da2c5348e,refuted)).
verdict(c_0bf5055da2c5348e,unknown) :- node(n1067,unknown).
query(verdict(c_0bf5055da2c5348e,unknown)).
node(n1078,supported) :- status(o_278fdadbcbf76b23bee6,supported).
node(n1078,refuted) :- status(o_278fdadbcbf76b23bee6,refuted).
node(n1078,unknown) :- status(o_278fdadbcbf76b23bee6,unknown).
node(n1077,supported) :- node(n1069,supported), node(n1070,supported), node(n1078,supported), node(n1071,supported).
node(n1077,refuted) :- node(n1069,refuted).
node(n1077,refuted) :- node(n1070,refuted).
node(n1077,refuted) :- node(n1078,refuted).
node(n1077,refuted) :- node(n1071,refuted).
node(n1077,unknown) :- \+ node(n1077,supported), \+ node(n1077,refuted).
node(n1080,supported) :- status(o_c6ee13107df8ad8c2234,supported).
node(n1080,refuted) :- status(o_c6ee13107df8ad8c2234,refuted).
node(n1080,unknown) :- status(o_c6ee13107df8ad8c2234,unknown).
node(n1079,supported) :- node(n1073,supported), node(n1074,supported), node(n1080,supported), node(n1075,supported).
node(n1079,refuted) :- node(n1073,refuted).
node(n1079,refuted) :- node(n1074,refuted).
node(n1079,refuted) :- node(n1080,refuted).
node(n1079,refuted) :- node(n1075,refuted).
node(n1079,unknown) :- \+ node(n1079,supported), \+ node(n1079,refuted).
node(n1076,refuted) :- node(n1077,refuted), node(n1079,refuted), node(n9,refuted).
node(n1076,supported) :- node(n1077,supported).
node(n1076,supported) :- node(n1079,supported).
node(n1076,supported) :- node(n9,supported).
node(n1076,unknown) :- \+ node(n1076,supported), \+ node(n1076,refuted).
verdict(c_9c517c8ca0a15f42,supported) :- node(n1076,supported).
query(verdict(c_9c517c8ca0a15f42,supported)).
verdict(c_9c517c8ca0a15f42,refuted) :- node(n1076,refuted).
query(verdict(c_9c517c8ca0a15f42,refuted)).
verdict(c_9c517c8ca0a15f42,unknown) :- node(n1076,unknown).
query(verdict(c_9c517c8ca0a15f42,unknown)).
node(n1083,supported) :- status(o_554bfd6c154be204b5f6,supported).
node(n1083,refuted) :- status(o_554bfd6c154be204b5f6,refuted).
node(n1083,unknown) :- status(o_554bfd6c154be204b5f6,unknown).
node(n1084,supported) :- status(o_6450ff128c268e222c8b,supported).
node(n1084,refuted) :- status(o_6450ff128c268e222c8b,refuted).
node(n1084,unknown) :- status(o_6450ff128c268e222c8b,unknown).
node(n1085,supported) :- status(o_b01ab74324e6cb68c66a,supported).
node(n1085,refuted) :- status(o_b01ab74324e6cb68c66a,refuted).
node(n1085,unknown) :- status(o_b01ab74324e6cb68c66a,unknown).
node(n1082,supported) :- node(n1083,supported), node(n1084,supported), node(n1085,supported).
node(n1082,refuted) :- node(n1083,refuted).
node(n1082,refuted) :- node(n1084,refuted).
node(n1082,refuted) :- node(n1085,refuted).
node(n1082,unknown) :- \+ node(n1082,supported), \+ node(n1082,refuted).
node(n1087,supported) :- status(o_7a358bd719284660b76c,supported).
node(n1087,refuted) :- status(o_7a358bd719284660b76c,refuted).
node(n1087,unknown) :- status(o_7a358bd719284660b76c,unknown).
node(n1088,supported) :- status(o_1c48799d98d6ddb371fc,supported).
node(n1088,refuted) :- status(o_1c48799d98d6ddb371fc,refuted).
node(n1088,unknown) :- status(o_1c48799d98d6ddb371fc,unknown).
node(n1089,supported) :- status(o_04be10164d619f9eaf96,supported).
node(n1089,refuted) :- status(o_04be10164d619f9eaf96,refuted).
node(n1089,unknown) :- status(o_04be10164d619f9eaf96,unknown).
node(n1086,supported) :- node(n1087,supported), node(n1088,supported), node(n1089,supported).
node(n1086,refuted) :- node(n1087,refuted).
node(n1086,refuted) :- node(n1088,refuted).
node(n1086,refuted) :- node(n1089,refuted).
node(n1086,unknown) :- \+ node(n1086,supported), \+ node(n1086,refuted).
node(n1081,refuted) :- node(n1082,refuted), node(n1086,refuted), node(n9,refuted).
node(n1081,supported) :- node(n1082,supported).
node(n1081,supported) :- node(n1086,supported).
node(n1081,supported) :- node(n9,supported).
node(n1081,unknown) :- \+ node(n1081,supported), \+ node(n1081,refuted).
verdict(c_40199fa58fb27f88,supported) :- node(n1081,supported).
query(verdict(c_40199fa58fb27f88,supported)).
verdict(c_40199fa58fb27f88,refuted) :- node(n1081,refuted).
query(verdict(c_40199fa58fb27f88,refuted)).
verdict(c_40199fa58fb27f88,unknown) :- node(n1081,unknown).
query(verdict(c_40199fa58fb27f88,unknown)).
node(n1092,supported) :- status(o_b517a77ee1450f94492d,supported).
node(n1092,refuted) :- status(o_b517a77ee1450f94492d,refuted).
node(n1092,unknown) :- status(o_b517a77ee1450f94492d,unknown).
node(n1091,supported) :- node(n1083,supported), node(n1084,supported), node(n1092,supported), node(n1085,supported).
node(n1091,refuted) :- node(n1083,refuted).
node(n1091,refuted) :- node(n1084,refuted).
node(n1091,refuted) :- node(n1092,refuted).
node(n1091,refuted) :- node(n1085,refuted).
node(n1091,unknown) :- \+ node(n1091,supported), \+ node(n1091,refuted).
node(n1094,supported) :- status(o_e648cc0dd3f0c19db09d,supported).
node(n1094,refuted) :- status(o_e648cc0dd3f0c19db09d,refuted).
node(n1094,unknown) :- status(o_e648cc0dd3f0c19db09d,unknown).
node(n1093,supported) :- node(n1087,supported), node(n1088,supported), node(n1094,supported), node(n1089,supported).
node(n1093,refuted) :- node(n1087,refuted).
node(n1093,refuted) :- node(n1088,refuted).
node(n1093,refuted) :- node(n1094,refuted).
node(n1093,refuted) :- node(n1089,refuted).
node(n1093,unknown) :- \+ node(n1093,supported), \+ node(n1093,refuted).
node(n1090,refuted) :- node(n1091,refuted), node(n1093,refuted), node(n9,refuted).
node(n1090,supported) :- node(n1091,supported).
node(n1090,supported) :- node(n1093,supported).
node(n1090,supported) :- node(n9,supported).
node(n1090,unknown) :- \+ node(n1090,supported), \+ node(n1090,refuted).
verdict(c_c076a8312465fd17,supported) :- node(n1090,supported).
query(verdict(c_c076a8312465fd17,supported)).
verdict(c_c076a8312465fd17,refuted) :- node(n1090,refuted).
query(verdict(c_c076a8312465fd17,refuted)).
verdict(c_c076a8312465fd17,unknown) :- node(n1090,unknown).
query(verdict(c_c076a8312465fd17,unknown)).
node(n1097,supported) :- status(o_68829cac35bb3a925898,supported).
node(n1097,refuted) :- status(o_68829cac35bb3a925898,refuted).
node(n1097,unknown) :- status(o_68829cac35bb3a925898,unknown).
node(n1098,supported) :- status(o_276b7db7f222c96a70ac,supported).
node(n1098,refuted) :- status(o_276b7db7f222c96a70ac,refuted).
node(n1098,unknown) :- status(o_276b7db7f222c96a70ac,unknown).
node(n1099,supported) :- status(o_5f3315cd38dc9be35e4d,supported).
node(n1099,refuted) :- status(o_5f3315cd38dc9be35e4d,refuted).
node(n1099,unknown) :- status(o_5f3315cd38dc9be35e4d,unknown).
node(n1096,supported) :- node(n1097,supported), node(n1098,supported), node(n1099,supported).
node(n1096,refuted) :- node(n1097,refuted).
node(n1096,refuted) :- node(n1098,refuted).
node(n1096,refuted) :- node(n1099,refuted).
node(n1096,unknown) :- \+ node(n1096,supported), \+ node(n1096,refuted).
node(n1101,supported) :- status(o_8089345792f1e7f0c3cf,supported).
node(n1101,refuted) :- status(o_8089345792f1e7f0c3cf,refuted).
node(n1101,unknown) :- status(o_8089345792f1e7f0c3cf,unknown).
node(n1102,supported) :- status(o_8e738396ab0d068c07b0,supported).
node(n1102,refuted) :- status(o_8e738396ab0d068c07b0,refuted).
node(n1102,unknown) :- status(o_8e738396ab0d068c07b0,unknown).
node(n1103,supported) :- status(o_b4aaaa12aba945e12f4a,supported).
node(n1103,refuted) :- status(o_b4aaaa12aba945e12f4a,refuted).
node(n1103,unknown) :- status(o_b4aaaa12aba945e12f4a,unknown).
node(n1100,supported) :- node(n1101,supported), node(n1102,supported), node(n1103,supported).
node(n1100,refuted) :- node(n1101,refuted).
node(n1100,refuted) :- node(n1102,refuted).
node(n1100,refuted) :- node(n1103,refuted).
node(n1100,unknown) :- \+ node(n1100,supported), \+ node(n1100,refuted).
node(n1095,refuted) :- node(n1096,refuted), node(n1100,refuted), node(n9,refuted).
node(n1095,supported) :- node(n1096,supported).
node(n1095,supported) :- node(n1100,supported).
node(n1095,supported) :- node(n9,supported).
node(n1095,unknown) :- \+ node(n1095,supported), \+ node(n1095,refuted).
verdict(c_dc8243527cbba467,supported) :- node(n1095,supported).
query(verdict(c_dc8243527cbba467,supported)).
verdict(c_dc8243527cbba467,refuted) :- node(n1095,refuted).
query(verdict(c_dc8243527cbba467,refuted)).
verdict(c_dc8243527cbba467,unknown) :- node(n1095,unknown).
query(verdict(c_dc8243527cbba467,unknown)).
node(n1106,supported) :- status(o_091ad2efd73a5142bb9c,supported).
node(n1106,refuted) :- status(o_091ad2efd73a5142bb9c,refuted).
node(n1106,unknown) :- status(o_091ad2efd73a5142bb9c,unknown).
node(n1105,supported) :- node(n1097,supported), node(n1098,supported), node(n1106,supported), node(n1099,supported).
node(n1105,refuted) :- node(n1097,refuted).
node(n1105,refuted) :- node(n1098,refuted).
node(n1105,refuted) :- node(n1106,refuted).
node(n1105,refuted) :- node(n1099,refuted).
node(n1105,unknown) :- \+ node(n1105,supported), \+ node(n1105,refuted).
node(n1108,supported) :- status(o_e3af0da140a95525e467,supported).
node(n1108,refuted) :- status(o_e3af0da140a95525e467,refuted).
node(n1108,unknown) :- status(o_e3af0da140a95525e467,unknown).
node(n1107,supported) :- node(n1101,supported), node(n1102,supported), node(n1108,supported), node(n1103,supported).
node(n1107,refuted) :- node(n1101,refuted).
node(n1107,refuted) :- node(n1102,refuted).
node(n1107,refuted) :- node(n1108,refuted).
node(n1107,refuted) :- node(n1103,refuted).
node(n1107,unknown) :- \+ node(n1107,supported), \+ node(n1107,refuted).
node(n1104,refuted) :- node(n1105,refuted), node(n1107,refuted), node(n9,refuted).
node(n1104,supported) :- node(n1105,supported).
node(n1104,supported) :- node(n1107,supported).
node(n1104,supported) :- node(n9,supported).
node(n1104,unknown) :- \+ node(n1104,supported), \+ node(n1104,refuted).
verdict(c_633850cb1ee03c2b,supported) :- node(n1104,supported).
query(verdict(c_633850cb1ee03c2b,supported)).
verdict(c_633850cb1ee03c2b,refuted) :- node(n1104,refuted).
query(verdict(c_633850cb1ee03c2b,refuted)).
verdict(c_633850cb1ee03c2b,unknown) :- node(n1104,unknown).
query(verdict(c_633850cb1ee03c2b,unknown)).
node(n1111,supported) :- status(o_d6c1af468a7d92b046ec,supported).
node(n1111,refuted) :- status(o_d6c1af468a7d92b046ec,refuted).
node(n1111,unknown) :- status(o_d6c1af468a7d92b046ec,unknown).
node(n1112,supported) :- status(o_7eee86f9ab30f79637a5,supported).
node(n1112,refuted) :- status(o_7eee86f9ab30f79637a5,refuted).
node(n1112,unknown) :- status(o_7eee86f9ab30f79637a5,unknown).
node(n1113,supported) :- status(o_1ae7fd9f5588216a2256,supported).
node(n1113,refuted) :- status(o_1ae7fd9f5588216a2256,refuted).
node(n1113,unknown) :- status(o_1ae7fd9f5588216a2256,unknown).
node(n1110,supported) :- node(n1111,supported), node(n1112,supported), node(n1113,supported).
node(n1110,refuted) :- node(n1111,refuted).
node(n1110,refuted) :- node(n1112,refuted).
node(n1110,refuted) :- node(n1113,refuted).
node(n1110,unknown) :- \+ node(n1110,supported), \+ node(n1110,refuted).
node(n1115,supported) :- status(o_d065ca5871f90679237c,supported).
node(n1115,refuted) :- status(o_d065ca5871f90679237c,refuted).
node(n1115,unknown) :- status(o_d065ca5871f90679237c,unknown).
node(n1116,supported) :- status(o_3ebb7cc6fd3b9bf0da57,supported).
node(n1116,refuted) :- status(o_3ebb7cc6fd3b9bf0da57,refuted).
node(n1116,unknown) :- status(o_3ebb7cc6fd3b9bf0da57,unknown).
node(n1117,supported) :- status(o_14c281143258c71d61cf,supported).
node(n1117,refuted) :- status(o_14c281143258c71d61cf,refuted).
node(n1117,unknown) :- status(o_14c281143258c71d61cf,unknown).
node(n1114,supported) :- node(n1115,supported), node(n1116,supported), node(n1117,supported).
node(n1114,refuted) :- node(n1115,refuted).
node(n1114,refuted) :- node(n1116,refuted).
node(n1114,refuted) :- node(n1117,refuted).
node(n1114,unknown) :- \+ node(n1114,supported), \+ node(n1114,refuted).
node(n1109,refuted) :- node(n1110,refuted), node(n1114,refuted), node(n9,refuted).
node(n1109,supported) :- node(n1110,supported).
node(n1109,supported) :- node(n1114,supported).
node(n1109,supported) :- node(n9,supported).
node(n1109,unknown) :- \+ node(n1109,supported), \+ node(n1109,refuted).
verdict(c_7eb10dd7a060ff1c,supported) :- node(n1109,supported).
query(verdict(c_7eb10dd7a060ff1c,supported)).
verdict(c_7eb10dd7a060ff1c,refuted) :- node(n1109,refuted).
query(verdict(c_7eb10dd7a060ff1c,refuted)).
verdict(c_7eb10dd7a060ff1c,unknown) :- node(n1109,unknown).
query(verdict(c_7eb10dd7a060ff1c,unknown)).
node(n1120,supported) :- status(o_da11a3406ccbf7b7bf78,supported).
node(n1120,refuted) :- status(o_da11a3406ccbf7b7bf78,refuted).
node(n1120,unknown) :- status(o_da11a3406ccbf7b7bf78,unknown).
node(n1119,supported) :- node(n1111,supported), node(n1112,supported), node(n1120,supported), node(n1113,supported).
node(n1119,refuted) :- node(n1111,refuted).
node(n1119,refuted) :- node(n1112,refuted).
node(n1119,refuted) :- node(n1120,refuted).
node(n1119,refuted) :- node(n1113,refuted).
node(n1119,unknown) :- \+ node(n1119,supported), \+ node(n1119,refuted).
node(n1122,supported) :- status(o_8dd5253489bebc0b1eaa,supported).
node(n1122,refuted) :- status(o_8dd5253489bebc0b1eaa,refuted).
node(n1122,unknown) :- status(o_8dd5253489bebc0b1eaa,unknown).
node(n1121,supported) :- node(n1115,supported), node(n1116,supported), node(n1122,supported), node(n1117,supported).
node(n1121,refuted) :- node(n1115,refuted).
node(n1121,refuted) :- node(n1116,refuted).
node(n1121,refuted) :- node(n1122,refuted).
node(n1121,refuted) :- node(n1117,refuted).
node(n1121,unknown) :- \+ node(n1121,supported), \+ node(n1121,refuted).
node(n1118,refuted) :- node(n1119,refuted), node(n1121,refuted), node(n9,refuted).
node(n1118,supported) :- node(n1119,supported).
node(n1118,supported) :- node(n1121,supported).
node(n1118,supported) :- node(n9,supported).
node(n1118,unknown) :- \+ node(n1118,supported), \+ node(n1118,refuted).
verdict(c_59c25f59daa7243e,supported) :- node(n1118,supported).
query(verdict(c_59c25f59daa7243e,supported)).
verdict(c_59c25f59daa7243e,refuted) :- node(n1118,refuted).
query(verdict(c_59c25f59daa7243e,refuted)).
verdict(c_59c25f59daa7243e,unknown) :- node(n1118,unknown).
query(verdict(c_59c25f59daa7243e,unknown)).
node(n1125,supported) :- status(o_6853eeb3d0cbbcba5e5f,supported).
node(n1125,refuted) :- status(o_6853eeb3d0cbbcba5e5f,refuted).
node(n1125,unknown) :- status(o_6853eeb3d0cbbcba5e5f,unknown).
node(n1126,supported) :- status(o_5946bbada845f2842d11,supported).
node(n1126,refuted) :- status(o_5946bbada845f2842d11,refuted).
node(n1126,unknown) :- status(o_5946bbada845f2842d11,unknown).
node(n1127,supported) :- status(o_093ff53a11755a57e8fc,supported).
node(n1127,refuted) :- status(o_093ff53a11755a57e8fc,refuted).
node(n1127,unknown) :- status(o_093ff53a11755a57e8fc,unknown).
node(n1124,supported) :- node(n1125,supported), node(n1126,supported), node(n1127,supported).
node(n1124,refuted) :- node(n1125,refuted).
node(n1124,refuted) :- node(n1126,refuted).
node(n1124,refuted) :- node(n1127,refuted).
node(n1124,unknown) :- \+ node(n1124,supported), \+ node(n1124,refuted).
node(n1129,supported) :- status(o_13cf9f36c7c53248fc6e,supported).
node(n1129,refuted) :- status(o_13cf9f36c7c53248fc6e,refuted).
node(n1129,unknown) :- status(o_13cf9f36c7c53248fc6e,unknown).
node(n1130,supported) :- status(o_3a21de68f73d3b421a84,supported).
node(n1130,refuted) :- status(o_3a21de68f73d3b421a84,refuted).
node(n1130,unknown) :- status(o_3a21de68f73d3b421a84,unknown).
node(n1131,supported) :- status(o_e87f9d3b8e655f1b7951,supported).
node(n1131,refuted) :- status(o_e87f9d3b8e655f1b7951,refuted).
node(n1131,unknown) :- status(o_e87f9d3b8e655f1b7951,unknown).
node(n1128,supported) :- node(n1129,supported), node(n1130,supported), node(n1131,supported).
node(n1128,refuted) :- node(n1129,refuted).
node(n1128,refuted) :- node(n1130,refuted).
node(n1128,refuted) :- node(n1131,refuted).
node(n1128,unknown) :- \+ node(n1128,supported), \+ node(n1128,refuted).
node(n1123,refuted) :- node(n1124,refuted), node(n1128,refuted), node(n9,refuted).
node(n1123,supported) :- node(n1124,supported).
node(n1123,supported) :- node(n1128,supported).
node(n1123,supported) :- node(n9,supported).
node(n1123,unknown) :- \+ node(n1123,supported), \+ node(n1123,refuted).
verdict(c_7cff58e460399694,supported) :- node(n1123,supported).
query(verdict(c_7cff58e460399694,supported)).
verdict(c_7cff58e460399694,refuted) :- node(n1123,refuted).
query(verdict(c_7cff58e460399694,refuted)).
verdict(c_7cff58e460399694,unknown) :- node(n1123,unknown).
query(verdict(c_7cff58e460399694,unknown)).
node(n1134,supported) :- status(o_213800c7847d4f4dc72b,supported).
node(n1134,refuted) :- status(o_213800c7847d4f4dc72b,refuted).
node(n1134,unknown) :- status(o_213800c7847d4f4dc72b,unknown).
node(n1133,supported) :- node(n1125,supported), node(n1126,supported), node(n1134,supported), node(n1127,supported).
node(n1133,refuted) :- node(n1125,refuted).
node(n1133,refuted) :- node(n1126,refuted).
node(n1133,refuted) :- node(n1134,refuted).
node(n1133,refuted) :- node(n1127,refuted).
node(n1133,unknown) :- \+ node(n1133,supported), \+ node(n1133,refuted).
node(n1136,supported) :- status(o_7b4c13fd26340f116903,supported).
node(n1136,refuted) :- status(o_7b4c13fd26340f116903,refuted).
node(n1136,unknown) :- status(o_7b4c13fd26340f116903,unknown).
node(n1135,supported) :- node(n1129,supported), node(n1130,supported), node(n1136,supported), node(n1131,supported).
node(n1135,refuted) :- node(n1129,refuted).
node(n1135,refuted) :- node(n1130,refuted).
node(n1135,refuted) :- node(n1136,refuted).
node(n1135,refuted) :- node(n1131,refuted).
node(n1135,unknown) :- \+ node(n1135,supported), \+ node(n1135,refuted).
node(n1132,refuted) :- node(n1133,refuted), node(n1135,refuted), node(n9,refuted).
node(n1132,supported) :- node(n1133,supported).
node(n1132,supported) :- node(n1135,supported).
node(n1132,supported) :- node(n9,supported).
node(n1132,unknown) :- \+ node(n1132,supported), \+ node(n1132,refuted).
verdict(c_c0bc0615c034e8cd,supported) :- node(n1132,supported).
query(verdict(c_c0bc0615c034e8cd,supported)).
verdict(c_c0bc0615c034e8cd,refuted) :- node(n1132,refuted).
query(verdict(c_c0bc0615c034e8cd,refuted)).
verdict(c_c0bc0615c034e8cd,unknown) :- node(n1132,unknown).
query(verdict(c_c0bc0615c034e8cd,unknown)).
node(n1139,supported) :- status(o_ea1e565e27a63343135a,supported).
node(n1139,refuted) :- status(o_ea1e565e27a63343135a,refuted).
node(n1139,unknown) :- status(o_ea1e565e27a63343135a,unknown).
node(n1140,supported) :- status(o_4edcb702012cf5cd4928,supported).
node(n1140,refuted) :- status(o_4edcb702012cf5cd4928,refuted).
node(n1140,unknown) :- status(o_4edcb702012cf5cd4928,unknown).
node(n1141,supported) :- status(o_94f261b8fa32bc37ab16,supported).
node(n1141,refuted) :- status(o_94f261b8fa32bc37ab16,refuted).
node(n1141,unknown) :- status(o_94f261b8fa32bc37ab16,unknown).
node(n1138,supported) :- node(n1139,supported), node(n1140,supported), node(n1141,supported).
node(n1138,refuted) :- node(n1139,refuted).
node(n1138,refuted) :- node(n1140,refuted).
node(n1138,refuted) :- node(n1141,refuted).
node(n1138,unknown) :- \+ node(n1138,supported), \+ node(n1138,refuted).
node(n1143,supported) :- status(o_09f56b988afeba1515ca,supported).
node(n1143,refuted) :- status(o_09f56b988afeba1515ca,refuted).
node(n1143,unknown) :- status(o_09f56b988afeba1515ca,unknown).
node(n1144,supported) :- status(o_94f6be4ebb1742c9b932,supported).
node(n1144,refuted) :- status(o_94f6be4ebb1742c9b932,refuted).
node(n1144,unknown) :- status(o_94f6be4ebb1742c9b932,unknown).
node(n1145,supported) :- status(o_2490396a075eca9e2a74,supported).
node(n1145,refuted) :- status(o_2490396a075eca9e2a74,refuted).
node(n1145,unknown) :- status(o_2490396a075eca9e2a74,unknown).
node(n1142,supported) :- node(n1143,supported), node(n1144,supported), node(n1145,supported).
node(n1142,refuted) :- node(n1143,refuted).
node(n1142,refuted) :- node(n1144,refuted).
node(n1142,refuted) :- node(n1145,refuted).
node(n1142,unknown) :- \+ node(n1142,supported), \+ node(n1142,refuted).
node(n1137,refuted) :- node(n1138,refuted), node(n1142,refuted), node(n9,refuted).
node(n1137,supported) :- node(n1138,supported).
node(n1137,supported) :- node(n1142,supported).
node(n1137,supported) :- node(n9,supported).
node(n1137,unknown) :- \+ node(n1137,supported), \+ node(n1137,refuted).
verdict(c_d4d7685b0467fe5a,supported) :- node(n1137,supported).
query(verdict(c_d4d7685b0467fe5a,supported)).
verdict(c_d4d7685b0467fe5a,refuted) :- node(n1137,refuted).
query(verdict(c_d4d7685b0467fe5a,refuted)).
verdict(c_d4d7685b0467fe5a,unknown) :- node(n1137,unknown).
query(verdict(c_d4d7685b0467fe5a,unknown)).
node(n1148,supported) :- status(o_0ab84c0c657cadb3f157,supported).
node(n1148,refuted) :- status(o_0ab84c0c657cadb3f157,refuted).
node(n1148,unknown) :- status(o_0ab84c0c657cadb3f157,unknown).
node(n1147,supported) :- node(n1139,supported), node(n1140,supported), node(n1148,supported), node(n1141,supported).
node(n1147,refuted) :- node(n1139,refuted).
node(n1147,refuted) :- node(n1140,refuted).
node(n1147,refuted) :- node(n1148,refuted).
node(n1147,refuted) :- node(n1141,refuted).
node(n1147,unknown) :- \+ node(n1147,supported), \+ node(n1147,refuted).
node(n1150,supported) :- status(o_759afe6441f2303c28b6,supported).
node(n1150,refuted) :- status(o_759afe6441f2303c28b6,refuted).
node(n1150,unknown) :- status(o_759afe6441f2303c28b6,unknown).
node(n1149,supported) :- node(n1143,supported), node(n1144,supported), node(n1150,supported), node(n1145,supported).
node(n1149,refuted) :- node(n1143,refuted).
node(n1149,refuted) :- node(n1144,refuted).
node(n1149,refuted) :- node(n1150,refuted).
node(n1149,refuted) :- node(n1145,refuted).
node(n1149,unknown) :- \+ node(n1149,supported), \+ node(n1149,refuted).
node(n1146,refuted) :- node(n1147,refuted), node(n1149,refuted), node(n9,refuted).
node(n1146,supported) :- node(n1147,supported).
node(n1146,supported) :- node(n1149,supported).
node(n1146,supported) :- node(n9,supported).
node(n1146,unknown) :- \+ node(n1146,supported), \+ node(n1146,refuted).
verdict(c_72d15eab5844091b,supported) :- node(n1146,supported).
query(verdict(c_72d15eab5844091b,supported)).
verdict(c_72d15eab5844091b,refuted) :- node(n1146,refuted).
query(verdict(c_72d15eab5844091b,refuted)).
verdict(c_72d15eab5844091b,unknown) :- node(n1146,unknown).
query(verdict(c_72d15eab5844091b,unknown)).
node(n1153,supported) :- status(o_d8cc7dd61697e469867a,supported).
node(n1153,refuted) :- status(o_d8cc7dd61697e469867a,refuted).
node(n1153,unknown) :- status(o_d8cc7dd61697e469867a,unknown).
node(n1154,supported) :- status(o_52cbde1248def674a8f0,supported).
node(n1154,refuted) :- status(o_52cbde1248def674a8f0,refuted).
node(n1154,unknown) :- status(o_52cbde1248def674a8f0,unknown).
node(n1155,supported) :- status(o_10e8a46673ae84f365cf,supported).
node(n1155,refuted) :- status(o_10e8a46673ae84f365cf,refuted).
node(n1155,unknown) :- status(o_10e8a46673ae84f365cf,unknown).
node(n1152,supported) :- node(n1153,supported), node(n1154,supported), node(n1155,supported).
node(n1152,refuted) :- node(n1153,refuted).
node(n1152,refuted) :- node(n1154,refuted).
node(n1152,refuted) :- node(n1155,refuted).
node(n1152,unknown) :- \+ node(n1152,supported), \+ node(n1152,refuted).
node(n1157,supported) :- status(o_f38fd8f6a7740e88a6f5,supported).
node(n1157,refuted) :- status(o_f38fd8f6a7740e88a6f5,refuted).
node(n1157,unknown) :- status(o_f38fd8f6a7740e88a6f5,unknown).
node(n1158,supported) :- status(o_fa38eb0be12aee6aa93c,supported).
node(n1158,refuted) :- status(o_fa38eb0be12aee6aa93c,refuted).
node(n1158,unknown) :- status(o_fa38eb0be12aee6aa93c,unknown).
node(n1159,supported) :- status(o_ff5dd9e930964d939c3a,supported).
node(n1159,refuted) :- status(o_ff5dd9e930964d939c3a,refuted).
node(n1159,unknown) :- status(o_ff5dd9e930964d939c3a,unknown).
node(n1156,supported) :- node(n1157,supported), node(n1158,supported), node(n1159,supported).
node(n1156,refuted) :- node(n1157,refuted).
node(n1156,refuted) :- node(n1158,refuted).
node(n1156,refuted) :- node(n1159,refuted).
node(n1156,unknown) :- \+ node(n1156,supported), \+ node(n1156,refuted).
node(n1151,refuted) :- node(n1152,refuted), node(n1156,refuted), node(n9,refuted).
node(n1151,supported) :- node(n1152,supported).
node(n1151,supported) :- node(n1156,supported).
node(n1151,supported) :- node(n9,supported).
node(n1151,unknown) :- \+ node(n1151,supported), \+ node(n1151,refuted).
verdict(c_dbb2a9688549cdae,supported) :- node(n1151,supported).
query(verdict(c_dbb2a9688549cdae,supported)).
verdict(c_dbb2a9688549cdae,refuted) :- node(n1151,refuted).
query(verdict(c_dbb2a9688549cdae,refuted)).
verdict(c_dbb2a9688549cdae,unknown) :- node(n1151,unknown).
query(verdict(c_dbb2a9688549cdae,unknown)).
node(n1162,supported) :- status(o_fc4cd149b7981ae5e396,supported).
node(n1162,refuted) :- status(o_fc4cd149b7981ae5e396,refuted).
node(n1162,unknown) :- status(o_fc4cd149b7981ae5e396,unknown).
node(n1161,supported) :- node(n1153,supported), node(n1154,supported), node(n1162,supported), node(n1155,supported).
node(n1161,refuted) :- node(n1153,refuted).
node(n1161,refuted) :- node(n1154,refuted).
node(n1161,refuted) :- node(n1162,refuted).
node(n1161,refuted) :- node(n1155,refuted).
node(n1161,unknown) :- \+ node(n1161,supported), \+ node(n1161,refuted).
node(n1164,supported) :- status(o_9f4d3a3a00a6d6c8d19f,supported).
node(n1164,refuted) :- status(o_9f4d3a3a00a6d6c8d19f,refuted).
node(n1164,unknown) :- status(o_9f4d3a3a00a6d6c8d19f,unknown).
node(n1163,supported) :- node(n1157,supported), node(n1158,supported), node(n1164,supported), node(n1159,supported).
node(n1163,refuted) :- node(n1157,refuted).
node(n1163,refuted) :- node(n1158,refuted).
node(n1163,refuted) :- node(n1164,refuted).
node(n1163,refuted) :- node(n1159,refuted).
node(n1163,unknown) :- \+ node(n1163,supported), \+ node(n1163,refuted).
node(n1160,refuted) :- node(n1161,refuted), node(n1163,refuted), node(n9,refuted).
node(n1160,supported) :- node(n1161,supported).
node(n1160,supported) :- node(n1163,supported).
node(n1160,supported) :- node(n9,supported).
node(n1160,unknown) :- \+ node(n1160,supported), \+ node(n1160,refuted).
verdict(c_55618898e0f0435b,supported) :- node(n1160,supported).
query(verdict(c_55618898e0f0435b,supported)).
verdict(c_55618898e0f0435b,refuted) :- node(n1160,refuted).
query(verdict(c_55618898e0f0435b,refuted)).
verdict(c_55618898e0f0435b,unknown) :- node(n1160,unknown).
query(verdict(c_55618898e0f0435b,unknown)).
node(n1167,supported) :- status(o_813c68fa7c9f6f54e2f9,supported).
node(n1167,refuted) :- status(o_813c68fa7c9f6f54e2f9,refuted).
node(n1167,unknown) :- status(o_813c68fa7c9f6f54e2f9,unknown).
node(n1168,supported) :- status(o_62344e839b3bb75a04d6,supported).
node(n1168,refuted) :- status(o_62344e839b3bb75a04d6,refuted).
node(n1168,unknown) :- status(o_62344e839b3bb75a04d6,unknown).
node(n1169,supported) :- status(o_e2ac0dec45f9fc5d6649,supported).
node(n1169,refuted) :- status(o_e2ac0dec45f9fc5d6649,refuted).
node(n1169,unknown) :- status(o_e2ac0dec45f9fc5d6649,unknown).
node(n1166,supported) :- node(n1167,supported), node(n1168,supported), node(n1169,supported).
node(n1166,refuted) :- node(n1167,refuted).
node(n1166,refuted) :- node(n1168,refuted).
node(n1166,refuted) :- node(n1169,refuted).
node(n1166,unknown) :- \+ node(n1166,supported), \+ node(n1166,refuted).
node(n1171,supported) :- status(o_116cf17b18dcec48ebc4,supported).
node(n1171,refuted) :- status(o_116cf17b18dcec48ebc4,refuted).
node(n1171,unknown) :- status(o_116cf17b18dcec48ebc4,unknown).
node(n1172,supported) :- status(o_fff85f6daeee8d2fda36,supported).
node(n1172,refuted) :- status(o_fff85f6daeee8d2fda36,refuted).
node(n1172,unknown) :- status(o_fff85f6daeee8d2fda36,unknown).
node(n1173,supported) :- status(o_78545cbec07cdef331fb,supported).
node(n1173,refuted) :- status(o_78545cbec07cdef331fb,refuted).
node(n1173,unknown) :- status(o_78545cbec07cdef331fb,unknown).
node(n1170,supported) :- node(n1171,supported), node(n1172,supported), node(n1173,supported).
node(n1170,refuted) :- node(n1171,refuted).
node(n1170,refuted) :- node(n1172,refuted).
node(n1170,refuted) :- node(n1173,refuted).
node(n1170,unknown) :- \+ node(n1170,supported), \+ node(n1170,refuted).
node(n1165,refuted) :- node(n1166,refuted), node(n1170,refuted), node(n9,refuted).
node(n1165,supported) :- node(n1166,supported).
node(n1165,supported) :- node(n1170,supported).
node(n1165,supported) :- node(n9,supported).
node(n1165,unknown) :- \+ node(n1165,supported), \+ node(n1165,refuted).
verdict(c_dfacfc4efce2ecbd,supported) :- node(n1165,supported).
query(verdict(c_dfacfc4efce2ecbd,supported)).
verdict(c_dfacfc4efce2ecbd,refuted) :- node(n1165,refuted).
query(verdict(c_dfacfc4efce2ecbd,refuted)).
verdict(c_dfacfc4efce2ecbd,unknown) :- node(n1165,unknown).
query(verdict(c_dfacfc4efce2ecbd,unknown)).
node(n1176,supported) :- status(o_5a4107cc4ed2530df561,supported).
node(n1176,refuted) :- status(o_5a4107cc4ed2530df561,refuted).
node(n1176,unknown) :- status(o_5a4107cc4ed2530df561,unknown).
node(n1175,supported) :- node(n1167,supported), node(n1168,supported), node(n1176,supported), node(n1169,supported).
node(n1175,refuted) :- node(n1167,refuted).
node(n1175,refuted) :- node(n1168,refuted).
node(n1175,refuted) :- node(n1176,refuted).
node(n1175,refuted) :- node(n1169,refuted).
node(n1175,unknown) :- \+ node(n1175,supported), \+ node(n1175,refuted).
node(n1178,supported) :- status(o_8bbb40edd8fdd15f34b1,supported).
node(n1178,refuted) :- status(o_8bbb40edd8fdd15f34b1,refuted).
node(n1178,unknown) :- status(o_8bbb40edd8fdd15f34b1,unknown).
node(n1177,supported) :- node(n1171,supported), node(n1172,supported), node(n1178,supported), node(n1173,supported).
node(n1177,refuted) :- node(n1171,refuted).
node(n1177,refuted) :- node(n1172,refuted).
node(n1177,refuted) :- node(n1178,refuted).
node(n1177,refuted) :- node(n1173,refuted).
node(n1177,unknown) :- \+ node(n1177,supported), \+ node(n1177,refuted).
node(n1174,refuted) :- node(n1175,refuted), node(n1177,refuted), node(n9,refuted).
node(n1174,supported) :- node(n1175,supported).
node(n1174,supported) :- node(n1177,supported).
node(n1174,supported) :- node(n9,supported).
node(n1174,unknown) :- \+ node(n1174,supported), \+ node(n1174,refuted).
verdict(c_cef7c61d4eaa966d,supported) :- node(n1174,supported).
query(verdict(c_cef7c61d4eaa966d,supported)).
verdict(c_cef7c61d4eaa966d,refuted) :- node(n1174,refuted).
query(verdict(c_cef7c61d4eaa966d,refuted)).
verdict(c_cef7c61d4eaa966d,unknown) :- node(n1174,unknown).
query(verdict(c_cef7c61d4eaa966d,unknown)).
node(n1181,supported) :- status(o_789746893159446ba4b5,supported).
node(n1181,refuted) :- status(o_789746893159446ba4b5,refuted).
node(n1181,unknown) :- status(o_789746893159446ba4b5,unknown).
node(n1182,supported) :- status(o_61e6aff881f1083d539d,supported).
node(n1182,refuted) :- status(o_61e6aff881f1083d539d,refuted).
node(n1182,unknown) :- status(o_61e6aff881f1083d539d,unknown).
node(n1183,supported) :- status(o_a3a80f5b35f8c45d1509,supported).
node(n1183,refuted) :- status(o_a3a80f5b35f8c45d1509,refuted).
node(n1183,unknown) :- status(o_a3a80f5b35f8c45d1509,unknown).
node(n1180,supported) :- node(n1181,supported), node(n1182,supported), node(n1183,supported).
node(n1180,refuted) :- node(n1181,refuted).
node(n1180,refuted) :- node(n1182,refuted).
node(n1180,refuted) :- node(n1183,refuted).
node(n1180,unknown) :- \+ node(n1180,supported), \+ node(n1180,refuted).
node(n1185,supported) :- status(o_5f1df02afdbe6bee9105,supported).
node(n1185,refuted) :- status(o_5f1df02afdbe6bee9105,refuted).
node(n1185,unknown) :- status(o_5f1df02afdbe6bee9105,unknown).
node(n1186,supported) :- status(o_f67e07f893ed4e6105f8,supported).
node(n1186,refuted) :- status(o_f67e07f893ed4e6105f8,refuted).
node(n1186,unknown) :- status(o_f67e07f893ed4e6105f8,unknown).
node(n1187,supported) :- status(o_5460f7ef36cb23c4075c,supported).
node(n1187,refuted) :- status(o_5460f7ef36cb23c4075c,refuted).
node(n1187,unknown) :- status(o_5460f7ef36cb23c4075c,unknown).
node(n1184,supported) :- node(n1185,supported), node(n1186,supported), node(n1187,supported).
node(n1184,refuted) :- node(n1185,refuted).
node(n1184,refuted) :- node(n1186,refuted).
node(n1184,refuted) :- node(n1187,refuted).
node(n1184,unknown) :- \+ node(n1184,supported), \+ node(n1184,refuted).
node(n1179,refuted) :- node(n1180,refuted), node(n1184,refuted), node(n9,refuted).
node(n1179,supported) :- node(n1180,supported).
node(n1179,supported) :- node(n1184,supported).
node(n1179,supported) :- node(n9,supported).
node(n1179,unknown) :- \+ node(n1179,supported), \+ node(n1179,refuted).
verdict(c_13c6db76244af41f,supported) :- node(n1179,supported).
query(verdict(c_13c6db76244af41f,supported)).
verdict(c_13c6db76244af41f,refuted) :- node(n1179,refuted).
query(verdict(c_13c6db76244af41f,refuted)).
verdict(c_13c6db76244af41f,unknown) :- node(n1179,unknown).
query(verdict(c_13c6db76244af41f,unknown)).
node(n1190,supported) :- status(o_9e3901a97ecb32b80ef2,supported).
node(n1190,refuted) :- status(o_9e3901a97ecb32b80ef2,refuted).
node(n1190,unknown) :- status(o_9e3901a97ecb32b80ef2,unknown).
node(n1189,supported) :- node(n1181,supported), node(n1182,supported), node(n1190,supported), node(n1183,supported).
node(n1189,refuted) :- node(n1181,refuted).
node(n1189,refuted) :- node(n1182,refuted).
node(n1189,refuted) :- node(n1190,refuted).
node(n1189,refuted) :- node(n1183,refuted).
node(n1189,unknown) :- \+ node(n1189,supported), \+ node(n1189,refuted).
node(n1192,supported) :- status(o_3545bc8aec28e257d5b7,supported).
node(n1192,refuted) :- status(o_3545bc8aec28e257d5b7,refuted).
node(n1192,unknown) :- status(o_3545bc8aec28e257d5b7,unknown).
node(n1191,supported) :- node(n1185,supported), node(n1186,supported), node(n1192,supported), node(n1187,supported).
node(n1191,refuted) :- node(n1185,refuted).
node(n1191,refuted) :- node(n1186,refuted).
node(n1191,refuted) :- node(n1192,refuted).
node(n1191,refuted) :- node(n1187,refuted).
node(n1191,unknown) :- \+ node(n1191,supported), \+ node(n1191,refuted).
node(n1188,refuted) :- node(n1189,refuted), node(n1191,refuted), node(n9,refuted).
node(n1188,supported) :- node(n1189,supported).
node(n1188,supported) :- node(n1191,supported).
node(n1188,supported) :- node(n9,supported).
node(n1188,unknown) :- \+ node(n1188,supported), \+ node(n1188,refuted).
verdict(c_0f8dec54c0f4ed50,supported) :- node(n1188,supported).
query(verdict(c_0f8dec54c0f4ed50,supported)).
verdict(c_0f8dec54c0f4ed50,refuted) :- node(n1188,refuted).
query(verdict(c_0f8dec54c0f4ed50,refuted)).
verdict(c_0f8dec54c0f4ed50,unknown) :- node(n1188,unknown).
query(verdict(c_0f8dec54c0f4ed50,unknown)).
node(n1195,supported) :- status(o_6d1b54fe5d1ae2c36c58,supported).
node(n1195,refuted) :- status(o_6d1b54fe5d1ae2c36c58,refuted).
node(n1195,unknown) :- status(o_6d1b54fe5d1ae2c36c58,unknown).
node(n1196,supported) :- status(o_f92a43a4b7026f2e16f6,supported).
node(n1196,refuted) :- status(o_f92a43a4b7026f2e16f6,refuted).
node(n1196,unknown) :- status(o_f92a43a4b7026f2e16f6,unknown).
node(n1197,supported) :- status(o_eb0bb2d3a610e269cb09,supported).
node(n1197,refuted) :- status(o_eb0bb2d3a610e269cb09,refuted).
node(n1197,unknown) :- status(o_eb0bb2d3a610e269cb09,unknown).
node(n1194,supported) :- node(n1195,supported), node(n1196,supported), node(n1197,supported).
node(n1194,refuted) :- node(n1195,refuted).
node(n1194,refuted) :- node(n1196,refuted).
node(n1194,refuted) :- node(n1197,refuted).
node(n1194,unknown) :- \+ node(n1194,supported), \+ node(n1194,refuted).
node(n1193,refuted) :- node(n1194,refuted), node(n9,refuted).
node(n1193,supported) :- node(n1194,supported).
node(n1193,supported) :- node(n9,supported).
node(n1193,unknown) :- \+ node(n1193,supported), \+ node(n1193,refuted).
verdict(c_5e66f31199a55a6c,supported) :- node(n1193,supported).
query(verdict(c_5e66f31199a55a6c,supported)).
verdict(c_5e66f31199a55a6c,refuted) :- node(n1193,refuted).
query(verdict(c_5e66f31199a55a6c,refuted)).
verdict(c_5e66f31199a55a6c,unknown) :- node(n1193,unknown).
query(verdict(c_5e66f31199a55a6c,unknown)).
node(n1200,supported) :- status(o_09d3b514598d1c4af582,supported).
node(n1200,refuted) :- status(o_09d3b514598d1c4af582,refuted).
node(n1200,unknown) :- status(o_09d3b514598d1c4af582,unknown).
node(n1199,supported) :- node(n1195,supported), node(n1196,supported), node(n1200,supported), node(n1197,supported).
node(n1199,refuted) :- node(n1195,refuted).
node(n1199,refuted) :- node(n1196,refuted).
node(n1199,refuted) :- node(n1200,refuted).
node(n1199,refuted) :- node(n1197,refuted).
node(n1199,unknown) :- \+ node(n1199,supported), \+ node(n1199,refuted).
node(n1198,refuted) :- node(n1199,refuted), node(n9,refuted).
node(n1198,supported) :- node(n1199,supported).
node(n1198,supported) :- node(n9,supported).
node(n1198,unknown) :- \+ node(n1198,supported), \+ node(n1198,refuted).
verdict(c_18f6dc6a7a67c38a,supported) :- node(n1198,supported).
query(verdict(c_18f6dc6a7a67c38a,supported)).
verdict(c_18f6dc6a7a67c38a,refuted) :- node(n1198,refuted).
query(verdict(c_18f6dc6a7a67c38a,refuted)).
verdict(c_18f6dc6a7a67c38a,unknown) :- node(n1198,unknown).
query(verdict(c_18f6dc6a7a67c38a,unknown)).
node(n1203,supported) :- status(o_e32f5aa0459586499220,supported).
node(n1203,refuted) :- status(o_e32f5aa0459586499220,refuted).
node(n1203,unknown) :- status(o_e32f5aa0459586499220,unknown).
node(n1204,supported) :- status(o_e1d10f284f7ecc28d155,supported).
node(n1204,refuted) :- status(o_e1d10f284f7ecc28d155,refuted).
node(n1204,unknown) :- status(o_e1d10f284f7ecc28d155,unknown).
node(n1205,supported) :- status(o_94102236461d358ea7a8,supported).
node(n1205,refuted) :- status(o_94102236461d358ea7a8,refuted).
node(n1205,unknown) :- status(o_94102236461d358ea7a8,unknown).
node(n1202,supported) :- node(n1203,supported), node(n1204,supported), node(n1205,supported).
node(n1202,refuted) :- node(n1203,refuted).
node(n1202,refuted) :- node(n1204,refuted).
node(n1202,refuted) :- node(n1205,refuted).
node(n1202,unknown) :- \+ node(n1202,supported), \+ node(n1202,refuted).
node(n1201,refuted) :- node(n1202,refuted), node(n9,refuted).
node(n1201,supported) :- node(n1202,supported).
node(n1201,supported) :- node(n9,supported).
node(n1201,unknown) :- \+ node(n1201,supported), \+ node(n1201,refuted).
verdict(c_4514799b42a7020d,supported) :- node(n1201,supported).
query(verdict(c_4514799b42a7020d,supported)).
verdict(c_4514799b42a7020d,refuted) :- node(n1201,refuted).
query(verdict(c_4514799b42a7020d,refuted)).
verdict(c_4514799b42a7020d,unknown) :- node(n1201,unknown).
query(verdict(c_4514799b42a7020d,unknown)).
node(n1208,supported) :- status(o_e22698c89a850753537b,supported).
node(n1208,refuted) :- status(o_e22698c89a850753537b,refuted).
node(n1208,unknown) :- status(o_e22698c89a850753537b,unknown).
node(n1207,supported) :- node(n1203,supported), node(n1204,supported), node(n1208,supported), node(n1205,supported).
node(n1207,refuted) :- node(n1203,refuted).
node(n1207,refuted) :- node(n1204,refuted).
node(n1207,refuted) :- node(n1208,refuted).
node(n1207,refuted) :- node(n1205,refuted).
node(n1207,unknown) :- \+ node(n1207,supported), \+ node(n1207,refuted).
node(n1206,refuted) :- node(n1207,refuted), node(n9,refuted).
node(n1206,supported) :- node(n1207,supported).
node(n1206,supported) :- node(n9,supported).
node(n1206,unknown) :- \+ node(n1206,supported), \+ node(n1206,refuted).
verdict(c_8186bd57efe04fba,supported) :- node(n1206,supported).
query(verdict(c_8186bd57efe04fba,supported)).
verdict(c_8186bd57efe04fba,refuted) :- node(n1206,refuted).
query(verdict(c_8186bd57efe04fba,refuted)).
verdict(c_8186bd57efe04fba,unknown) :- node(n1206,unknown).
query(verdict(c_8186bd57efe04fba,unknown)).
node(n1211,supported) :- status(o_7b689f0c8711deefb48b,supported).
node(n1211,refuted) :- status(o_7b689f0c8711deefb48b,refuted).
node(n1211,unknown) :- status(o_7b689f0c8711deefb48b,unknown).
node(n1212,supported) :- status(o_3d5e970a0f2d371e11f0,supported).
node(n1212,refuted) :- status(o_3d5e970a0f2d371e11f0,refuted).
node(n1212,unknown) :- status(o_3d5e970a0f2d371e11f0,unknown).
node(n1213,supported) :- status(o_f679bbba7f76f9b70a9c,supported).
node(n1213,refuted) :- status(o_f679bbba7f76f9b70a9c,refuted).
node(n1213,unknown) :- status(o_f679bbba7f76f9b70a9c,unknown).
node(n1210,supported) :- node(n1211,supported), node(n1212,supported), node(n1213,supported).
node(n1210,refuted) :- node(n1211,refuted).
node(n1210,refuted) :- node(n1212,refuted).
node(n1210,refuted) :- node(n1213,refuted).
node(n1210,unknown) :- \+ node(n1210,supported), \+ node(n1210,refuted).
node(n1209,refuted) :- node(n1210,refuted), node(n9,refuted).
node(n1209,supported) :- node(n1210,supported).
node(n1209,supported) :- node(n9,supported).
node(n1209,unknown) :- \+ node(n1209,supported), \+ node(n1209,refuted).
verdict(c_bfcf70d08951db7c,supported) :- node(n1209,supported).
query(verdict(c_bfcf70d08951db7c,supported)).
verdict(c_bfcf70d08951db7c,refuted) :- node(n1209,refuted).
query(verdict(c_bfcf70d08951db7c,refuted)).
verdict(c_bfcf70d08951db7c,unknown) :- node(n1209,unknown).
query(verdict(c_bfcf70d08951db7c,unknown)).
node(n1216,supported) :- status(o_abbf600a16b903392499,supported).
node(n1216,refuted) :- status(o_abbf600a16b903392499,refuted).
node(n1216,unknown) :- status(o_abbf600a16b903392499,unknown).
node(n1215,supported) :- node(n1211,supported), node(n1212,supported), node(n1216,supported), node(n1213,supported).
node(n1215,refuted) :- node(n1211,refuted).
node(n1215,refuted) :- node(n1212,refuted).
node(n1215,refuted) :- node(n1216,refuted).
node(n1215,refuted) :- node(n1213,refuted).
node(n1215,unknown) :- \+ node(n1215,supported), \+ node(n1215,refuted).
node(n1214,refuted) :- node(n1215,refuted), node(n9,refuted).
node(n1214,supported) :- node(n1215,supported).
node(n1214,supported) :- node(n9,supported).
node(n1214,unknown) :- \+ node(n1214,supported), \+ node(n1214,refuted).
verdict(c_1d2d754e8da238b2,supported) :- node(n1214,supported).
query(verdict(c_1d2d754e8da238b2,supported)).
verdict(c_1d2d754e8da238b2,refuted) :- node(n1214,refuted).
query(verdict(c_1d2d754e8da238b2,refuted)).
verdict(c_1d2d754e8da238b2,unknown) :- node(n1214,unknown).
query(verdict(c_1d2d754e8da238b2,unknown)).
node(n1219,supported) :- status(o_88df8c090a5a7f3c3d3a,supported).
node(n1219,refuted) :- status(o_88df8c090a5a7f3c3d3a,refuted).
node(n1219,unknown) :- status(o_88df8c090a5a7f3c3d3a,unknown).
node(n1220,supported) :- status(o_e38c4a5259a61b77728b,supported).
node(n1220,refuted) :- status(o_e38c4a5259a61b77728b,refuted).
node(n1220,unknown) :- status(o_e38c4a5259a61b77728b,unknown).
node(n1221,supported) :- status(o_9a6280fbb0269d385b43,supported).
node(n1221,refuted) :- status(o_9a6280fbb0269d385b43,refuted).
node(n1221,unknown) :- status(o_9a6280fbb0269d385b43,unknown).
node(n1218,supported) :- node(n1219,supported), node(n1220,supported), node(n1221,supported).
node(n1218,refuted) :- node(n1219,refuted).
node(n1218,refuted) :- node(n1220,refuted).
node(n1218,refuted) :- node(n1221,refuted).
node(n1218,unknown) :- \+ node(n1218,supported), \+ node(n1218,refuted).
node(n1217,refuted) :- node(n1218,refuted), node(n9,refuted).
node(n1217,supported) :- node(n1218,supported).
node(n1217,supported) :- node(n9,supported).
node(n1217,unknown) :- \+ node(n1217,supported), \+ node(n1217,refuted).
verdict(c_4d715fb9167c472e,supported) :- node(n1217,supported).
query(verdict(c_4d715fb9167c472e,supported)).
verdict(c_4d715fb9167c472e,refuted) :- node(n1217,refuted).
query(verdict(c_4d715fb9167c472e,refuted)).
verdict(c_4d715fb9167c472e,unknown) :- node(n1217,unknown).
query(verdict(c_4d715fb9167c472e,unknown)).
node(n1224,supported) :- status(o_b75f0a1d43ebd8c864e5,supported).
node(n1224,refuted) :- status(o_b75f0a1d43ebd8c864e5,refuted).
node(n1224,unknown) :- status(o_b75f0a1d43ebd8c864e5,unknown).
node(n1223,supported) :- node(n1219,supported), node(n1220,supported), node(n1224,supported), node(n1221,supported).
node(n1223,refuted) :- node(n1219,refuted).
node(n1223,refuted) :- node(n1220,refuted).
node(n1223,refuted) :- node(n1224,refuted).
node(n1223,refuted) :- node(n1221,refuted).
node(n1223,unknown) :- \+ node(n1223,supported), \+ node(n1223,refuted).
node(n1222,refuted) :- node(n1223,refuted), node(n9,refuted).
node(n1222,supported) :- node(n1223,supported).
node(n1222,supported) :- node(n9,supported).
node(n1222,unknown) :- \+ node(n1222,supported), \+ node(n1222,refuted).
verdict(c_4581eee77409504e,supported) :- node(n1222,supported).
query(verdict(c_4581eee77409504e,supported)).
verdict(c_4581eee77409504e,refuted) :- node(n1222,refuted).
query(verdict(c_4581eee77409504e,refuted)).
verdict(c_4581eee77409504e,unknown) :- node(n1222,unknown).
query(verdict(c_4581eee77409504e,unknown)).
node(n1227,supported) :- status(o_b283f14827e32875a668,supported).
node(n1227,refuted) :- status(o_b283f14827e32875a668,refuted).
node(n1227,unknown) :- status(o_b283f14827e32875a668,unknown).
node(n1228,supported) :- status(o_112c56a5876082625cab,supported).
node(n1228,refuted) :- status(o_112c56a5876082625cab,refuted).
node(n1228,unknown) :- status(o_112c56a5876082625cab,unknown).
node(n1229,supported) :- status(o_06b67517fb89dbac98b8,supported).
node(n1229,refuted) :- status(o_06b67517fb89dbac98b8,refuted).
node(n1229,unknown) :- status(o_06b67517fb89dbac98b8,unknown).
node(n1226,supported) :- node(n1227,supported), node(n1228,supported), node(n1229,supported).
node(n1226,refuted) :- node(n1227,refuted).
node(n1226,refuted) :- node(n1228,refuted).
node(n1226,refuted) :- node(n1229,refuted).
node(n1226,unknown) :- \+ node(n1226,supported), \+ node(n1226,refuted).
node(n1225,refuted) :- node(n1226,refuted), node(n9,refuted).
node(n1225,supported) :- node(n1226,supported).
node(n1225,supported) :- node(n9,supported).
node(n1225,unknown) :- \+ node(n1225,supported), \+ node(n1225,refuted).
verdict(c_0bcbfa2b0b5b90ec,supported) :- node(n1225,supported).
query(verdict(c_0bcbfa2b0b5b90ec,supported)).
verdict(c_0bcbfa2b0b5b90ec,refuted) :- node(n1225,refuted).
query(verdict(c_0bcbfa2b0b5b90ec,refuted)).
verdict(c_0bcbfa2b0b5b90ec,unknown) :- node(n1225,unknown).
query(verdict(c_0bcbfa2b0b5b90ec,unknown)).
node(n1232,supported) :- status(o_2dd8d437c786e7f1c4f1,supported).
node(n1232,refuted) :- status(o_2dd8d437c786e7f1c4f1,refuted).
node(n1232,unknown) :- status(o_2dd8d437c786e7f1c4f1,unknown).
node(n1231,supported) :- node(n1227,supported), node(n1228,supported), node(n1232,supported), node(n1229,supported).
node(n1231,refuted) :- node(n1227,refuted).
node(n1231,refuted) :- node(n1228,refuted).
node(n1231,refuted) :- node(n1232,refuted).
node(n1231,refuted) :- node(n1229,refuted).
node(n1231,unknown) :- \+ node(n1231,supported), \+ node(n1231,refuted).
node(n1230,refuted) :- node(n1231,refuted), node(n9,refuted).
node(n1230,supported) :- node(n1231,supported).
node(n1230,supported) :- node(n9,supported).
node(n1230,unknown) :- \+ node(n1230,supported), \+ node(n1230,refuted).
verdict(c_0e7843d522801a6b,supported) :- node(n1230,supported).
query(verdict(c_0e7843d522801a6b,supported)).
verdict(c_0e7843d522801a6b,refuted) :- node(n1230,refuted).
query(verdict(c_0e7843d522801a6b,refuted)).
verdict(c_0e7843d522801a6b,unknown) :- node(n1230,unknown).
query(verdict(c_0e7843d522801a6b,unknown)).
node(n1235,supported) :- status(o_bd79a8afeeee8d42a7d6,supported).
node(n1235,refuted) :- status(o_bd79a8afeeee8d42a7d6,refuted).
node(n1235,unknown) :- status(o_bd79a8afeeee8d42a7d6,unknown).
node(n1236,supported) :- status(o_fa066b66d698c70c7011,supported).
node(n1236,refuted) :- status(o_fa066b66d698c70c7011,refuted).
node(n1236,unknown) :- status(o_fa066b66d698c70c7011,unknown).
node(n1237,supported) :- status(o_7fb080887d485a88d449,supported).
node(n1237,refuted) :- status(o_7fb080887d485a88d449,refuted).
node(n1237,unknown) :- status(o_7fb080887d485a88d449,unknown).
node(n1234,supported) :- node(n1235,supported), node(n1236,supported), node(n1237,supported).
node(n1234,refuted) :- node(n1235,refuted).
node(n1234,refuted) :- node(n1236,refuted).
node(n1234,refuted) :- node(n1237,refuted).
node(n1234,unknown) :- \+ node(n1234,supported), \+ node(n1234,refuted).
node(n1233,refuted) :- node(n1234,refuted), node(n9,refuted).
node(n1233,supported) :- node(n1234,supported).
node(n1233,supported) :- node(n9,supported).
node(n1233,unknown) :- \+ node(n1233,supported), \+ node(n1233,refuted).
verdict(c_1998cb833ab6206a,supported) :- node(n1233,supported).
query(verdict(c_1998cb833ab6206a,supported)).
verdict(c_1998cb833ab6206a,refuted) :- node(n1233,refuted).
query(verdict(c_1998cb833ab6206a,refuted)).
verdict(c_1998cb833ab6206a,unknown) :- node(n1233,unknown).
query(verdict(c_1998cb833ab6206a,unknown)).
node(n1240,supported) :- status(o_ac15488f0ff53b9b43c6,supported).
node(n1240,refuted) :- status(o_ac15488f0ff53b9b43c6,refuted).
node(n1240,unknown) :- status(o_ac15488f0ff53b9b43c6,unknown).
node(n1239,supported) :- node(n1235,supported), node(n1236,supported), node(n1240,supported), node(n1237,supported).
node(n1239,refuted) :- node(n1235,refuted).
node(n1239,refuted) :- node(n1236,refuted).
node(n1239,refuted) :- node(n1240,refuted).
node(n1239,refuted) :- node(n1237,refuted).
node(n1239,unknown) :- \+ node(n1239,supported), \+ node(n1239,refuted).
node(n1238,refuted) :- node(n1239,refuted), node(n9,refuted).
node(n1238,supported) :- node(n1239,supported).
node(n1238,supported) :- node(n9,supported).
node(n1238,unknown) :- \+ node(n1238,supported), \+ node(n1238,refuted).
verdict(c_83f4c88a1d490750,supported) :- node(n1238,supported).
query(verdict(c_83f4c88a1d490750,supported)).
verdict(c_83f4c88a1d490750,refuted) :- node(n1238,refuted).
query(verdict(c_83f4c88a1d490750,refuted)).
verdict(c_83f4c88a1d490750,unknown) :- node(n1238,unknown).
query(verdict(c_83f4c88a1d490750,unknown)).
node(n1243,supported) :- status(o_bf6c260396eebb3ee297,supported).
node(n1243,refuted) :- status(o_bf6c260396eebb3ee297,refuted).
node(n1243,unknown) :- status(o_bf6c260396eebb3ee297,unknown).
node(n1244,supported) :- status(o_eb1abd2431ddf7d6b62b,supported).
node(n1244,refuted) :- status(o_eb1abd2431ddf7d6b62b,refuted).
node(n1244,unknown) :- status(o_eb1abd2431ddf7d6b62b,unknown).
node(n1245,supported) :- status(o_3f0a0d697ec759914a33,supported).
node(n1245,refuted) :- status(o_3f0a0d697ec759914a33,refuted).
node(n1245,unknown) :- status(o_3f0a0d697ec759914a33,unknown).
node(n1242,supported) :- node(n1243,supported), node(n1244,supported), node(n1245,supported).
node(n1242,refuted) :- node(n1243,refuted).
node(n1242,refuted) :- node(n1244,refuted).
node(n1242,refuted) :- node(n1245,refuted).
node(n1242,unknown) :- \+ node(n1242,supported), \+ node(n1242,refuted).
node(n1241,refuted) :- node(n1242,refuted), node(n9,refuted).
node(n1241,supported) :- node(n1242,supported).
node(n1241,supported) :- node(n9,supported).
node(n1241,unknown) :- \+ node(n1241,supported), \+ node(n1241,refuted).
verdict(c_c3383c1a152ceba0,supported) :- node(n1241,supported).
query(verdict(c_c3383c1a152ceba0,supported)).
verdict(c_c3383c1a152ceba0,refuted) :- node(n1241,refuted).
query(verdict(c_c3383c1a152ceba0,refuted)).
verdict(c_c3383c1a152ceba0,unknown) :- node(n1241,unknown).
query(verdict(c_c3383c1a152ceba0,unknown)).
node(n1248,supported) :- status(o_b3db7ce52ed5148415de,supported).
node(n1248,refuted) :- status(o_b3db7ce52ed5148415de,refuted).
node(n1248,unknown) :- status(o_b3db7ce52ed5148415de,unknown).
node(n1247,supported) :- node(n1243,supported), node(n1244,supported), node(n1248,supported), node(n1245,supported).
node(n1247,refuted) :- node(n1243,refuted).
node(n1247,refuted) :- node(n1244,refuted).
node(n1247,refuted) :- node(n1248,refuted).
node(n1247,refuted) :- node(n1245,refuted).
node(n1247,unknown) :- \+ node(n1247,supported), \+ node(n1247,refuted).
node(n1246,refuted) :- node(n1247,refuted), node(n9,refuted).
node(n1246,supported) :- node(n1247,supported).
node(n1246,supported) :- node(n9,supported).
node(n1246,unknown) :- \+ node(n1246,supported), \+ node(n1246,refuted).
verdict(c_ed612970e6084c49,supported) :- node(n1246,supported).
query(verdict(c_ed612970e6084c49,supported)).
verdict(c_ed612970e6084c49,refuted) :- node(n1246,refuted).
query(verdict(c_ed612970e6084c49,refuted)).
verdict(c_ed612970e6084c49,unknown) :- node(n1246,unknown).
query(verdict(c_ed612970e6084c49,unknown)).
node(n1251,supported) :- status(o_f84333ca8e71d6da24ab,supported).
node(n1251,refuted) :- status(o_f84333ca8e71d6da24ab,refuted).
node(n1251,unknown) :- status(o_f84333ca8e71d6da24ab,unknown).
node(n1252,supported) :- status(o_dc123f9776c5f251e931,supported).
node(n1252,refuted) :- status(o_dc123f9776c5f251e931,refuted).
node(n1252,unknown) :- status(o_dc123f9776c5f251e931,unknown).
node(n1253,supported) :- status(o_7aea84e92ef7f5d0dbb5,supported).
node(n1253,refuted) :- status(o_7aea84e92ef7f5d0dbb5,refuted).
node(n1253,unknown) :- status(o_7aea84e92ef7f5d0dbb5,unknown).
node(n1250,supported) :- node(n1251,supported), node(n1252,supported), node(n1253,supported).
node(n1250,refuted) :- node(n1251,refuted).
node(n1250,refuted) :- node(n1252,refuted).
node(n1250,refuted) :- node(n1253,refuted).
node(n1250,unknown) :- \+ node(n1250,supported), \+ node(n1250,refuted).
node(n1249,refuted) :- node(n1250,refuted), node(n9,refuted).
node(n1249,supported) :- node(n1250,supported).
node(n1249,supported) :- node(n9,supported).
node(n1249,unknown) :- \+ node(n1249,supported), \+ node(n1249,refuted).
verdict(c_b8d54692e16d26f8,supported) :- node(n1249,supported).
query(verdict(c_b8d54692e16d26f8,supported)).
verdict(c_b8d54692e16d26f8,refuted) :- node(n1249,refuted).
query(verdict(c_b8d54692e16d26f8,refuted)).
verdict(c_b8d54692e16d26f8,unknown) :- node(n1249,unknown).
query(verdict(c_b8d54692e16d26f8,unknown)).
node(n1256,supported) :- status(o_0ac2ad204bcbb831e6fc,supported).
node(n1256,refuted) :- status(o_0ac2ad204bcbb831e6fc,refuted).
node(n1256,unknown) :- status(o_0ac2ad204bcbb831e6fc,unknown).
node(n1255,supported) :- node(n1251,supported), node(n1252,supported), node(n1256,supported), node(n1253,supported).
node(n1255,refuted) :- node(n1251,refuted).
node(n1255,refuted) :- node(n1252,refuted).
node(n1255,refuted) :- node(n1256,refuted).
node(n1255,refuted) :- node(n1253,refuted).
node(n1255,unknown) :- \+ node(n1255,supported), \+ node(n1255,refuted).
node(n1254,refuted) :- node(n1255,refuted), node(n9,refuted).
node(n1254,supported) :- node(n1255,supported).
node(n1254,supported) :- node(n9,supported).
node(n1254,unknown) :- \+ node(n1254,supported), \+ node(n1254,refuted).
verdict(c_18704b54e6e9a23c,supported) :- node(n1254,supported).
query(verdict(c_18704b54e6e9a23c,supported)).
verdict(c_18704b54e6e9a23c,refuted) :- node(n1254,refuted).
query(verdict(c_18704b54e6e9a23c,refuted)).
verdict(c_18704b54e6e9a23c,unknown) :- node(n1254,unknown).
query(verdict(c_18704b54e6e9a23c,unknown)).
node(n1259,supported) :- status(o_1fe0b77a2ad953872a1d,supported).
node(n1259,refuted) :- status(o_1fe0b77a2ad953872a1d,refuted).
node(n1259,unknown) :- status(o_1fe0b77a2ad953872a1d,unknown).
node(n1260,supported) :- status(o_c93d9a77d40c39cbe0b4,supported).
node(n1260,refuted) :- status(o_c93d9a77d40c39cbe0b4,refuted).
node(n1260,unknown) :- status(o_c93d9a77d40c39cbe0b4,unknown).
node(n1261,supported) :- status(o_82a4042b418ec673ede4,supported).
node(n1261,refuted) :- status(o_82a4042b418ec673ede4,refuted).
node(n1261,unknown) :- status(o_82a4042b418ec673ede4,unknown).
node(n1258,supported) :- node(n1259,supported), node(n1260,supported), node(n1261,supported).
node(n1258,refuted) :- node(n1259,refuted).
node(n1258,refuted) :- node(n1260,refuted).
node(n1258,refuted) :- node(n1261,refuted).
node(n1258,unknown) :- \+ node(n1258,supported), \+ node(n1258,refuted).
node(n1257,refuted) :- node(n1258,refuted), node(n9,refuted).
node(n1257,supported) :- node(n1258,supported).
node(n1257,supported) :- node(n9,supported).
node(n1257,unknown) :- \+ node(n1257,supported), \+ node(n1257,refuted).
verdict(c_c91aa1ef07f6aa93,supported) :- node(n1257,supported).
query(verdict(c_c91aa1ef07f6aa93,supported)).
verdict(c_c91aa1ef07f6aa93,refuted) :- node(n1257,refuted).
query(verdict(c_c91aa1ef07f6aa93,refuted)).
verdict(c_c91aa1ef07f6aa93,unknown) :- node(n1257,unknown).
query(verdict(c_c91aa1ef07f6aa93,unknown)).
node(n1264,supported) :- status(o_f38f2cd83b5b77899ffd,supported).
node(n1264,refuted) :- status(o_f38f2cd83b5b77899ffd,refuted).
node(n1264,unknown) :- status(o_f38f2cd83b5b77899ffd,unknown).
node(n1263,supported) :- node(n1259,supported), node(n1260,supported), node(n1264,supported), node(n1261,supported).
node(n1263,refuted) :- node(n1259,refuted).
node(n1263,refuted) :- node(n1260,refuted).
node(n1263,refuted) :- node(n1264,refuted).
node(n1263,refuted) :- node(n1261,refuted).
node(n1263,unknown) :- \+ node(n1263,supported), \+ node(n1263,refuted).
node(n1262,refuted) :- node(n1263,refuted), node(n9,refuted).
node(n1262,supported) :- node(n1263,supported).
node(n1262,supported) :- node(n9,supported).
node(n1262,unknown) :- \+ node(n1262,supported), \+ node(n1262,refuted).
verdict(c_e8b9f3e8643512ed,supported) :- node(n1262,supported).
query(verdict(c_e8b9f3e8643512ed,supported)).
verdict(c_e8b9f3e8643512ed,refuted) :- node(n1262,refuted).
query(verdict(c_e8b9f3e8643512ed,refuted)).
verdict(c_e8b9f3e8643512ed,unknown) :- node(n1262,unknown).
query(verdict(c_e8b9f3e8643512ed,unknown)).
node(n1267,supported) :- status(o_898b1f53a472641e6346,supported).
node(n1267,refuted) :- status(o_898b1f53a472641e6346,refuted).
node(n1267,unknown) :- status(o_898b1f53a472641e6346,unknown).
node(n1268,supported) :- status(o_c50fbffad84f3ff1c3d6,supported).
node(n1268,refuted) :- status(o_c50fbffad84f3ff1c3d6,refuted).
node(n1268,unknown) :- status(o_c50fbffad84f3ff1c3d6,unknown).
node(n1269,supported) :- status(o_eaa7decac125953dee1a,supported).
node(n1269,refuted) :- status(o_eaa7decac125953dee1a,refuted).
node(n1269,unknown) :- status(o_eaa7decac125953dee1a,unknown).
node(n1266,supported) :- node(n1267,supported), node(n1268,supported), node(n1269,supported).
node(n1266,refuted) :- node(n1267,refuted).
node(n1266,refuted) :- node(n1268,refuted).
node(n1266,refuted) :- node(n1269,refuted).
node(n1266,unknown) :- \+ node(n1266,supported), \+ node(n1266,refuted).
node(n1265,refuted) :- node(n1266,refuted), node(n9,refuted).
node(n1265,supported) :- node(n1266,supported).
node(n1265,supported) :- node(n9,supported).
node(n1265,unknown) :- \+ node(n1265,supported), \+ node(n1265,refuted).
verdict(c_ae2fc6cfcfec0da0,supported) :- node(n1265,supported).
query(verdict(c_ae2fc6cfcfec0da0,supported)).
verdict(c_ae2fc6cfcfec0da0,refuted) :- node(n1265,refuted).
query(verdict(c_ae2fc6cfcfec0da0,refuted)).
verdict(c_ae2fc6cfcfec0da0,unknown) :- node(n1265,unknown).
query(verdict(c_ae2fc6cfcfec0da0,unknown)).
node(n1272,supported) :- status(o_028ccbfd684f18456ef9,supported).
node(n1272,refuted) :- status(o_028ccbfd684f18456ef9,refuted).
node(n1272,unknown) :- status(o_028ccbfd684f18456ef9,unknown).
node(n1271,supported) :- node(n1267,supported), node(n1268,supported), node(n1272,supported), node(n1269,supported).
node(n1271,refuted) :- node(n1267,refuted).
node(n1271,refuted) :- node(n1268,refuted).
node(n1271,refuted) :- node(n1272,refuted).
node(n1271,refuted) :- node(n1269,refuted).
node(n1271,unknown) :- \+ node(n1271,supported), \+ node(n1271,refuted).
node(n1270,refuted) :- node(n1271,refuted), node(n9,refuted).
node(n1270,supported) :- node(n1271,supported).
node(n1270,supported) :- node(n9,supported).
node(n1270,unknown) :- \+ node(n1270,supported), \+ node(n1270,refuted).
verdict(c_f535062aa9777046,supported) :- node(n1270,supported).
query(verdict(c_f535062aa9777046,supported)).
verdict(c_f535062aa9777046,refuted) :- node(n1270,refuted).
query(verdict(c_f535062aa9777046,refuted)).
verdict(c_f535062aa9777046,unknown) :- node(n1270,unknown).
query(verdict(c_f535062aa9777046,unknown)).
node(n1275,supported) :- status(o_51c0fc64d79cad130828,supported).
node(n1275,refuted) :- status(o_51c0fc64d79cad130828,refuted).
node(n1275,unknown) :- status(o_51c0fc64d79cad130828,unknown).
node(n1276,supported) :- status(o_78ea6efaa4bd8715a358,supported).
node(n1276,refuted) :- status(o_78ea6efaa4bd8715a358,refuted).
node(n1276,unknown) :- status(o_78ea6efaa4bd8715a358,unknown).
node(n1277,supported) :- status(o_10a8db2f2e7019906595,supported).
node(n1277,refuted) :- status(o_10a8db2f2e7019906595,refuted).
node(n1277,unknown) :- status(o_10a8db2f2e7019906595,unknown).
node(n1274,supported) :- node(n1275,supported), node(n1276,supported), node(n1277,supported).
node(n1274,refuted) :- node(n1275,refuted).
node(n1274,refuted) :- node(n1276,refuted).
node(n1274,refuted) :- node(n1277,refuted).
node(n1274,unknown) :- \+ node(n1274,supported), \+ node(n1274,refuted).
node(n1273,refuted) :- node(n1274,refuted), node(n9,refuted).
node(n1273,supported) :- node(n1274,supported).
node(n1273,supported) :- node(n9,supported).
node(n1273,unknown) :- \+ node(n1273,supported), \+ node(n1273,refuted).
verdict(c_65497c194b05ff2f,supported) :- node(n1273,supported).
query(verdict(c_65497c194b05ff2f,supported)).
verdict(c_65497c194b05ff2f,refuted) :- node(n1273,refuted).
query(verdict(c_65497c194b05ff2f,refuted)).
verdict(c_65497c194b05ff2f,unknown) :- node(n1273,unknown).
query(verdict(c_65497c194b05ff2f,unknown)).
node(n1280,supported) :- status(o_289ed5d7dede9e57bf46,supported).
node(n1280,refuted) :- status(o_289ed5d7dede9e57bf46,refuted).
node(n1280,unknown) :- status(o_289ed5d7dede9e57bf46,unknown).
node(n1279,supported) :- node(n1275,supported), node(n1276,supported), node(n1280,supported), node(n1277,supported).
node(n1279,refuted) :- node(n1275,refuted).
node(n1279,refuted) :- node(n1276,refuted).
node(n1279,refuted) :- node(n1280,refuted).
node(n1279,refuted) :- node(n1277,refuted).
node(n1279,unknown) :- \+ node(n1279,supported), \+ node(n1279,refuted).
node(n1278,refuted) :- node(n1279,refuted), node(n9,refuted).
node(n1278,supported) :- node(n1279,supported).
node(n1278,supported) :- node(n9,supported).
node(n1278,unknown) :- \+ node(n1278,supported), \+ node(n1278,refuted).
verdict(c_62ff68e46b401b87,supported) :- node(n1278,supported).
query(verdict(c_62ff68e46b401b87,supported)).
verdict(c_62ff68e46b401b87,refuted) :- node(n1278,refuted).
query(verdict(c_62ff68e46b401b87,refuted)).
verdict(c_62ff68e46b401b87,unknown) :- node(n1278,unknown).
query(verdict(c_62ff68e46b401b87,unknown)).
node(n1283,supported) :- status(o_b8f4f9b5c5dd653fc3b8,supported).
node(n1283,refuted) :- status(o_b8f4f9b5c5dd653fc3b8,refuted).
node(n1283,unknown) :- status(o_b8f4f9b5c5dd653fc3b8,unknown).
node(n1284,supported) :- status(o_15ccaaab8c8fe1a8c83d,supported).
node(n1284,refuted) :- status(o_15ccaaab8c8fe1a8c83d,refuted).
node(n1284,unknown) :- status(o_15ccaaab8c8fe1a8c83d,unknown).
node(n1285,supported) :- status(o_e50e39cf75e68990c526,supported).
node(n1285,refuted) :- status(o_e50e39cf75e68990c526,refuted).
node(n1285,unknown) :- status(o_e50e39cf75e68990c526,unknown).
node(n1282,supported) :- node(n1283,supported), node(n1284,supported), node(n1285,supported).
node(n1282,refuted) :- node(n1283,refuted).
node(n1282,refuted) :- node(n1284,refuted).
node(n1282,refuted) :- node(n1285,refuted).
node(n1282,unknown) :- \+ node(n1282,supported), \+ node(n1282,refuted).
node(n1281,refuted) :- node(n1282,refuted), node(n9,refuted).
node(n1281,supported) :- node(n1282,supported).
node(n1281,supported) :- node(n9,supported).
node(n1281,unknown) :- \+ node(n1281,supported), \+ node(n1281,refuted).
verdict(c_67688e6bb1fcd24c,supported) :- node(n1281,supported).
query(verdict(c_67688e6bb1fcd24c,supported)).
verdict(c_67688e6bb1fcd24c,refuted) :- node(n1281,refuted).
query(verdict(c_67688e6bb1fcd24c,refuted)).
verdict(c_67688e6bb1fcd24c,unknown) :- node(n1281,unknown).
query(verdict(c_67688e6bb1fcd24c,unknown)).
node(n1288,supported) :- status(o_b5fad5d1aa0ba1d00523,supported).
node(n1288,refuted) :- status(o_b5fad5d1aa0ba1d00523,refuted).
node(n1288,unknown) :- status(o_b5fad5d1aa0ba1d00523,unknown).
node(n1287,supported) :- node(n1283,supported), node(n1284,supported), node(n1288,supported), node(n1285,supported).
node(n1287,refuted) :- node(n1283,refuted).
node(n1287,refuted) :- node(n1284,refuted).
node(n1287,refuted) :- node(n1288,refuted).
node(n1287,refuted) :- node(n1285,refuted).
node(n1287,unknown) :- \+ node(n1287,supported), \+ node(n1287,refuted).
node(n1286,refuted) :- node(n1287,refuted), node(n9,refuted).
node(n1286,supported) :- node(n1287,supported).
node(n1286,supported) :- node(n9,supported).
node(n1286,unknown) :- \+ node(n1286,supported), \+ node(n1286,refuted).
verdict(c_c8129a31cef18101,supported) :- node(n1286,supported).
query(verdict(c_c8129a31cef18101,supported)).
verdict(c_c8129a31cef18101,refuted) :- node(n1286,refuted).
query(verdict(c_c8129a31cef18101,refuted)).
verdict(c_c8129a31cef18101,unknown) :- node(n1286,unknown).
query(verdict(c_c8129a31cef18101,unknown)).
node(n1291,supported) :- status(o_903d3c5d25ed624913ca,supported).
node(n1291,refuted) :- status(o_903d3c5d25ed624913ca,refuted).
node(n1291,unknown) :- status(o_903d3c5d25ed624913ca,unknown).
node(n1292,supported) :- status(o_a53f289362ec1bbcd8b7,supported).
node(n1292,refuted) :- status(o_a53f289362ec1bbcd8b7,refuted).
node(n1292,unknown) :- status(o_a53f289362ec1bbcd8b7,unknown).
node(n1293,supported) :- status(o_986a15a0a84721a1f9b5,supported).
node(n1293,refuted) :- status(o_986a15a0a84721a1f9b5,refuted).
node(n1293,unknown) :- status(o_986a15a0a84721a1f9b5,unknown).
node(n1290,supported) :- node(n1291,supported), node(n1292,supported), node(n1293,supported).
node(n1290,refuted) :- node(n1291,refuted).
node(n1290,refuted) :- node(n1292,refuted).
node(n1290,refuted) :- node(n1293,refuted).
node(n1290,unknown) :- \+ node(n1290,supported), \+ node(n1290,refuted).
node(n1289,refuted) :- node(n1290,refuted), node(n9,refuted).
node(n1289,supported) :- node(n1290,supported).
node(n1289,supported) :- node(n9,supported).
node(n1289,unknown) :- \+ node(n1289,supported), \+ node(n1289,refuted).
verdict(c_fc606b14f227c928,supported) :- node(n1289,supported).
query(verdict(c_fc606b14f227c928,supported)).
verdict(c_fc606b14f227c928,refuted) :- node(n1289,refuted).
query(verdict(c_fc606b14f227c928,refuted)).
verdict(c_fc606b14f227c928,unknown) :- node(n1289,unknown).
query(verdict(c_fc606b14f227c928,unknown)).
node(n1296,supported) :- status(o_05d6e4c2285b76e8f4ae,supported).
node(n1296,refuted) :- status(o_05d6e4c2285b76e8f4ae,refuted).
node(n1296,unknown) :- status(o_05d6e4c2285b76e8f4ae,unknown).
node(n1295,supported) :- node(n1291,supported), node(n1292,supported), node(n1296,supported), node(n1293,supported).
node(n1295,refuted) :- node(n1291,refuted).
node(n1295,refuted) :- node(n1292,refuted).
node(n1295,refuted) :- node(n1296,refuted).
node(n1295,refuted) :- node(n1293,refuted).
node(n1295,unknown) :- \+ node(n1295,supported), \+ node(n1295,refuted).
node(n1294,refuted) :- node(n1295,refuted), node(n9,refuted).
node(n1294,supported) :- node(n1295,supported).
node(n1294,supported) :- node(n9,supported).
node(n1294,unknown) :- \+ node(n1294,supported), \+ node(n1294,refuted).
verdict(c_da8464b3ad35733f,supported) :- node(n1294,supported).
query(verdict(c_da8464b3ad35733f,supported)).
verdict(c_da8464b3ad35733f,refuted) :- node(n1294,refuted).
query(verdict(c_da8464b3ad35733f,refuted)).
verdict(c_da8464b3ad35733f,unknown) :- node(n1294,unknown).
query(verdict(c_da8464b3ad35733f,unknown)).
node(n1299,supported) :- status(o_1c3761a1c0db66722da2,supported).
node(n1299,refuted) :- status(o_1c3761a1c0db66722da2,refuted).
node(n1299,unknown) :- status(o_1c3761a1c0db66722da2,unknown).
node(n1300,supported) :- status(o_204a348fd9d52a41ce05,supported).
node(n1300,refuted) :- status(o_204a348fd9d52a41ce05,refuted).
node(n1300,unknown) :- status(o_204a348fd9d52a41ce05,unknown).
node(n1301,supported) :- status(o_d8aa131ede849d4ad4a6,supported).
node(n1301,refuted) :- status(o_d8aa131ede849d4ad4a6,refuted).
node(n1301,unknown) :- status(o_d8aa131ede849d4ad4a6,unknown).
node(n1298,supported) :- node(n1299,supported), node(n1300,supported), node(n1301,supported).
node(n1298,refuted) :- node(n1299,refuted).
node(n1298,refuted) :- node(n1300,refuted).
node(n1298,refuted) :- node(n1301,refuted).
node(n1298,unknown) :- \+ node(n1298,supported), \+ node(n1298,refuted).
node(n1297,refuted) :- node(n1298,refuted), node(n9,refuted).
node(n1297,supported) :- node(n1298,supported).
node(n1297,supported) :- node(n9,supported).
node(n1297,unknown) :- \+ node(n1297,supported), \+ node(n1297,refuted).
verdict(c_d5a04c7320e0bba2,supported) :- node(n1297,supported).
query(verdict(c_d5a04c7320e0bba2,supported)).
verdict(c_d5a04c7320e0bba2,refuted) :- node(n1297,refuted).
query(verdict(c_d5a04c7320e0bba2,refuted)).
verdict(c_d5a04c7320e0bba2,unknown) :- node(n1297,unknown).
query(verdict(c_d5a04c7320e0bba2,unknown)).
node(n1304,supported) :- status(o_940420087e1c9625160f,supported).
node(n1304,refuted) :- status(o_940420087e1c9625160f,refuted).
node(n1304,unknown) :- status(o_940420087e1c9625160f,unknown).
node(n1303,supported) :- node(n1299,supported), node(n1300,supported), node(n1304,supported), node(n1301,supported).
node(n1303,refuted) :- node(n1299,refuted).
node(n1303,refuted) :- node(n1300,refuted).
node(n1303,refuted) :- node(n1304,refuted).
node(n1303,refuted) :- node(n1301,refuted).
node(n1303,unknown) :- \+ node(n1303,supported), \+ node(n1303,refuted).
node(n1302,refuted) :- node(n1303,refuted), node(n9,refuted).
node(n1302,supported) :- node(n1303,supported).
node(n1302,supported) :- node(n9,supported).
node(n1302,unknown) :- \+ node(n1302,supported), \+ node(n1302,refuted).
verdict(c_4de9d4b1d065d20c,supported) :- node(n1302,supported).
query(verdict(c_4de9d4b1d065d20c,supported)).
verdict(c_4de9d4b1d065d20c,refuted) :- node(n1302,refuted).
query(verdict(c_4de9d4b1d065d20c,refuted)).
verdict(c_4de9d4b1d065d20c,unknown) :- node(n1302,unknown).
query(verdict(c_4de9d4b1d065d20c,unknown)).
node(n1307,supported) :- status(o_7ab202ac62c8fdee8969,supported).
node(n1307,refuted) :- status(o_7ab202ac62c8fdee8969,refuted).
node(n1307,unknown) :- status(o_7ab202ac62c8fdee8969,unknown).
node(n1308,supported) :- status(o_4d28b89477c7f6aea0c9,supported).
node(n1308,refuted) :- status(o_4d28b89477c7f6aea0c9,refuted).
node(n1308,unknown) :- status(o_4d28b89477c7f6aea0c9,unknown).
node(n1309,supported) :- status(o_b0978ff4ff104df4cc09,supported).
node(n1309,refuted) :- status(o_b0978ff4ff104df4cc09,refuted).
node(n1309,unknown) :- status(o_b0978ff4ff104df4cc09,unknown).
node(n1306,supported) :- node(n1307,supported), node(n1308,supported), node(n1309,supported).
node(n1306,refuted) :- node(n1307,refuted).
node(n1306,refuted) :- node(n1308,refuted).
node(n1306,refuted) :- node(n1309,refuted).
node(n1306,unknown) :- \+ node(n1306,supported), \+ node(n1306,refuted).
node(n1311,supported) :- status(o_44ccc51ad29ebcf095fa,supported).
node(n1311,refuted) :- status(o_44ccc51ad29ebcf095fa,refuted).
node(n1311,unknown) :- status(o_44ccc51ad29ebcf095fa,unknown).
node(n1312,supported) :- status(o_b5f7d6cec7ba9d902819,supported).
node(n1312,refuted) :- status(o_b5f7d6cec7ba9d902819,refuted).
node(n1312,unknown) :- status(o_b5f7d6cec7ba9d902819,unknown).
node(n1313,supported) :- status(o_a332867ed37ac3c0a6fd,supported).
node(n1313,refuted) :- status(o_a332867ed37ac3c0a6fd,refuted).
node(n1313,unknown) :- status(o_a332867ed37ac3c0a6fd,unknown).
node(n1310,supported) :- node(n1311,supported), node(n1312,supported), node(n1313,supported).
node(n1310,refuted) :- node(n1311,refuted).
node(n1310,refuted) :- node(n1312,refuted).
node(n1310,refuted) :- node(n1313,refuted).
node(n1310,unknown) :- \+ node(n1310,supported), \+ node(n1310,refuted).
node(n1305,refuted) :- node(n1306,refuted), node(n1310,refuted), node(n9,refuted).
node(n1305,supported) :- node(n1306,supported).
node(n1305,supported) :- node(n1310,supported).
node(n1305,supported) :- node(n9,supported).
node(n1305,unknown) :- \+ node(n1305,supported), \+ node(n1305,refuted).
verdict(c_76d3cff98c3cd47d,supported) :- node(n1305,supported).
query(verdict(c_76d3cff98c3cd47d,supported)).
verdict(c_76d3cff98c3cd47d,refuted) :- node(n1305,refuted).
query(verdict(c_76d3cff98c3cd47d,refuted)).
verdict(c_76d3cff98c3cd47d,unknown) :- node(n1305,unknown).
query(verdict(c_76d3cff98c3cd47d,unknown)).
node(n1316,supported) :- status(o_863ed4e97bf651e1e44c,supported).
node(n1316,refuted) :- status(o_863ed4e97bf651e1e44c,refuted).
node(n1316,unknown) :- status(o_863ed4e97bf651e1e44c,unknown).
node(n1315,supported) :- node(n1307,supported), node(n1308,supported), node(n1316,supported), node(n1309,supported).
node(n1315,refuted) :- node(n1307,refuted).
node(n1315,refuted) :- node(n1308,refuted).
node(n1315,refuted) :- node(n1316,refuted).
node(n1315,refuted) :- node(n1309,refuted).
node(n1315,unknown) :- \+ node(n1315,supported), \+ node(n1315,refuted).
node(n1318,supported) :- status(o_4d902c8529fc6baca58e,supported).
node(n1318,refuted) :- status(o_4d902c8529fc6baca58e,refuted).
node(n1318,unknown) :- status(o_4d902c8529fc6baca58e,unknown).
node(n1317,supported) :- node(n1311,supported), node(n1312,supported), node(n1318,supported), node(n1313,supported).
node(n1317,refuted) :- node(n1311,refuted).
node(n1317,refuted) :- node(n1312,refuted).
node(n1317,refuted) :- node(n1318,refuted).
node(n1317,refuted) :- node(n1313,refuted).
node(n1317,unknown) :- \+ node(n1317,supported), \+ node(n1317,refuted).
node(n1314,refuted) :- node(n1315,refuted), node(n1317,refuted), node(n9,refuted).
node(n1314,supported) :- node(n1315,supported).
node(n1314,supported) :- node(n1317,supported).
node(n1314,supported) :- node(n9,supported).
node(n1314,unknown) :- \+ node(n1314,supported), \+ node(n1314,refuted).
verdict(c_d327805eae33696f,supported) :- node(n1314,supported).
query(verdict(c_d327805eae33696f,supported)).
verdict(c_d327805eae33696f,refuted) :- node(n1314,refuted).
query(verdict(c_d327805eae33696f,refuted)).
verdict(c_d327805eae33696f,unknown) :- node(n1314,unknown).
query(verdict(c_d327805eae33696f,unknown)).
node(n1321,supported) :- status(o_762baed664fd7c851e4f,supported).
node(n1321,refuted) :- status(o_762baed664fd7c851e4f,refuted).
node(n1321,unknown) :- status(o_762baed664fd7c851e4f,unknown).
node(n1322,supported) :- status(o_7eb2a2dd2fb0feb7bca4,supported).
node(n1322,refuted) :- status(o_7eb2a2dd2fb0feb7bca4,refuted).
node(n1322,unknown) :- status(o_7eb2a2dd2fb0feb7bca4,unknown).
node(n1323,supported) :- status(o_0de7272c2832a9a75113,supported).
node(n1323,refuted) :- status(o_0de7272c2832a9a75113,refuted).
node(n1323,unknown) :- status(o_0de7272c2832a9a75113,unknown).
node(n1320,supported) :- node(n1321,supported), node(n1322,supported), node(n1323,supported).
node(n1320,refuted) :- node(n1321,refuted).
node(n1320,refuted) :- node(n1322,refuted).
node(n1320,refuted) :- node(n1323,refuted).
node(n1320,unknown) :- \+ node(n1320,supported), \+ node(n1320,refuted).
node(n1325,supported) :- status(o_0347fab024a2d2e2f3d1,supported).
node(n1325,refuted) :- status(o_0347fab024a2d2e2f3d1,refuted).
node(n1325,unknown) :- status(o_0347fab024a2d2e2f3d1,unknown).
node(n1326,supported) :- status(o_8589bd1f91c4cf7ea773,supported).
node(n1326,refuted) :- status(o_8589bd1f91c4cf7ea773,refuted).
node(n1326,unknown) :- status(o_8589bd1f91c4cf7ea773,unknown).
node(n1327,supported) :- status(o_e39ee433e673e56782c4,supported).
node(n1327,refuted) :- status(o_e39ee433e673e56782c4,refuted).
node(n1327,unknown) :- status(o_e39ee433e673e56782c4,unknown).
node(n1324,supported) :- node(n1325,supported), node(n1326,supported), node(n1327,supported).
node(n1324,refuted) :- node(n1325,refuted).
node(n1324,refuted) :- node(n1326,refuted).
node(n1324,refuted) :- node(n1327,refuted).
node(n1324,unknown) :- \+ node(n1324,supported), \+ node(n1324,refuted).
node(n1319,refuted) :- node(n1320,refuted), node(n1324,refuted), node(n9,refuted).
node(n1319,supported) :- node(n1320,supported).
node(n1319,supported) :- node(n1324,supported).
node(n1319,supported) :- node(n9,supported).
node(n1319,unknown) :- \+ node(n1319,supported), \+ node(n1319,refuted).
verdict(c_d625d67129d74097,supported) :- node(n1319,supported).
query(verdict(c_d625d67129d74097,supported)).
verdict(c_d625d67129d74097,refuted) :- node(n1319,refuted).
query(verdict(c_d625d67129d74097,refuted)).
verdict(c_d625d67129d74097,unknown) :- node(n1319,unknown).
query(verdict(c_d625d67129d74097,unknown)).
node(n1330,supported) :- status(o_c706f70be5bc06928d1f,supported).
node(n1330,refuted) :- status(o_c706f70be5bc06928d1f,refuted).
node(n1330,unknown) :- status(o_c706f70be5bc06928d1f,unknown).
node(n1329,supported) :- node(n1321,supported), node(n1322,supported), node(n1330,supported), node(n1323,supported).
node(n1329,refuted) :- node(n1321,refuted).
node(n1329,refuted) :- node(n1322,refuted).
node(n1329,refuted) :- node(n1330,refuted).
node(n1329,refuted) :- node(n1323,refuted).
node(n1329,unknown) :- \+ node(n1329,supported), \+ node(n1329,refuted).
node(n1332,supported) :- status(o_a8bdfd4aee684bc7a893,supported).
node(n1332,refuted) :- status(o_a8bdfd4aee684bc7a893,refuted).
node(n1332,unknown) :- status(o_a8bdfd4aee684bc7a893,unknown).
node(n1331,supported) :- node(n1325,supported), node(n1326,supported), node(n1332,supported), node(n1327,supported).
node(n1331,refuted) :- node(n1325,refuted).
node(n1331,refuted) :- node(n1326,refuted).
node(n1331,refuted) :- node(n1332,refuted).
node(n1331,refuted) :- node(n1327,refuted).
node(n1331,unknown) :- \+ node(n1331,supported), \+ node(n1331,refuted).
node(n1328,refuted) :- node(n1329,refuted), node(n1331,refuted), node(n9,refuted).
node(n1328,supported) :- node(n1329,supported).
node(n1328,supported) :- node(n1331,supported).
node(n1328,supported) :- node(n9,supported).
node(n1328,unknown) :- \+ node(n1328,supported), \+ node(n1328,refuted).
verdict(c_7a18a4d2bcdefc11,supported) :- node(n1328,supported).
query(verdict(c_7a18a4d2bcdefc11,supported)).
verdict(c_7a18a4d2bcdefc11,refuted) :- node(n1328,refuted).
query(verdict(c_7a18a4d2bcdefc11,refuted)).
verdict(c_7a18a4d2bcdefc11,unknown) :- node(n1328,unknown).
query(verdict(c_7a18a4d2bcdefc11,unknown)).
node(n1335,supported) :- status(o_1398aa96f0a0ce1058ab,supported).
node(n1335,refuted) :- status(o_1398aa96f0a0ce1058ab,refuted).
node(n1335,unknown) :- status(o_1398aa96f0a0ce1058ab,unknown).
node(n1336,supported) :- status(o_510820d653cee6d3b321,supported).
node(n1336,refuted) :- status(o_510820d653cee6d3b321,refuted).
node(n1336,unknown) :- status(o_510820d653cee6d3b321,unknown).
node(n1337,supported) :- status(o_ba6cbb6148cb84b02cd5,supported).
node(n1337,refuted) :- status(o_ba6cbb6148cb84b02cd5,refuted).
node(n1337,unknown) :- status(o_ba6cbb6148cb84b02cd5,unknown).
node(n1334,supported) :- node(n1335,supported), node(n1336,supported), node(n1337,supported).
node(n1334,refuted) :- node(n1335,refuted).
node(n1334,refuted) :- node(n1336,refuted).
node(n1334,refuted) :- node(n1337,refuted).
node(n1334,unknown) :- \+ node(n1334,supported), \+ node(n1334,refuted).
node(n1339,supported) :- status(o_8e82df60feb90809d347,supported).
node(n1339,refuted) :- status(o_8e82df60feb90809d347,refuted).
node(n1339,unknown) :- status(o_8e82df60feb90809d347,unknown).
node(n1340,supported) :- status(o_9ef7603bd61a3cd1162b,supported).
node(n1340,refuted) :- status(o_9ef7603bd61a3cd1162b,refuted).
node(n1340,unknown) :- status(o_9ef7603bd61a3cd1162b,unknown).
node(n1341,supported) :- status(o_d27800b9078c2bcfa0fd,supported).
node(n1341,refuted) :- status(o_d27800b9078c2bcfa0fd,refuted).
node(n1341,unknown) :- status(o_d27800b9078c2bcfa0fd,unknown).
node(n1338,supported) :- node(n1339,supported), node(n1340,supported), node(n1341,supported).
node(n1338,refuted) :- node(n1339,refuted).
node(n1338,refuted) :- node(n1340,refuted).
node(n1338,refuted) :- node(n1341,refuted).
node(n1338,unknown) :- \+ node(n1338,supported), \+ node(n1338,refuted).
node(n1333,refuted) :- node(n1334,refuted), node(n1338,refuted), node(n9,refuted).
node(n1333,supported) :- node(n1334,supported).
node(n1333,supported) :- node(n1338,supported).
node(n1333,supported) :- node(n9,supported).
node(n1333,unknown) :- \+ node(n1333,supported), \+ node(n1333,refuted).
verdict(c_69599ac032d3ddc4,supported) :- node(n1333,supported).
query(verdict(c_69599ac032d3ddc4,supported)).
verdict(c_69599ac032d3ddc4,refuted) :- node(n1333,refuted).
query(verdict(c_69599ac032d3ddc4,refuted)).
verdict(c_69599ac032d3ddc4,unknown) :- node(n1333,unknown).
query(verdict(c_69599ac032d3ddc4,unknown)).
node(n1344,supported) :- status(o_3a466d2fc15cf77dbf8b,supported).
node(n1344,refuted) :- status(o_3a466d2fc15cf77dbf8b,refuted).
node(n1344,unknown) :- status(o_3a466d2fc15cf77dbf8b,unknown).
node(n1343,supported) :- node(n1335,supported), node(n1336,supported), node(n1344,supported), node(n1337,supported).
node(n1343,refuted) :- node(n1335,refuted).
node(n1343,refuted) :- node(n1336,refuted).
node(n1343,refuted) :- node(n1344,refuted).
node(n1343,refuted) :- node(n1337,refuted).
node(n1343,unknown) :- \+ node(n1343,supported), \+ node(n1343,refuted).
node(n1346,supported) :- status(o_00ad64f51dae10718060,supported).
node(n1346,refuted) :- status(o_00ad64f51dae10718060,refuted).
node(n1346,unknown) :- status(o_00ad64f51dae10718060,unknown).
node(n1345,supported) :- node(n1339,supported), node(n1340,supported), node(n1346,supported), node(n1341,supported).
node(n1345,refuted) :- node(n1339,refuted).
node(n1345,refuted) :- node(n1340,refuted).
node(n1345,refuted) :- node(n1346,refuted).
node(n1345,refuted) :- node(n1341,refuted).
node(n1345,unknown) :- \+ node(n1345,supported), \+ node(n1345,refuted).
node(n1342,refuted) :- node(n1343,refuted), node(n1345,refuted), node(n9,refuted).
node(n1342,supported) :- node(n1343,supported).
node(n1342,supported) :- node(n1345,supported).
node(n1342,supported) :- node(n9,supported).
node(n1342,unknown) :- \+ node(n1342,supported), \+ node(n1342,refuted).
verdict(c_30a9690ff1c9e3b8,supported) :- node(n1342,supported).
query(verdict(c_30a9690ff1c9e3b8,supported)).
verdict(c_30a9690ff1c9e3b8,refuted) :- node(n1342,refuted).
query(verdict(c_30a9690ff1c9e3b8,refuted)).
verdict(c_30a9690ff1c9e3b8,unknown) :- node(n1342,unknown).
query(verdict(c_30a9690ff1c9e3b8,unknown)).
node(n1349,supported) :- status(o_5412b6dea82c96a289a6,supported).
node(n1349,refuted) :- status(o_5412b6dea82c96a289a6,refuted).
node(n1349,unknown) :- status(o_5412b6dea82c96a289a6,unknown).
node(n1350,supported) :- status(o_a1ff27aeb67294210c2c,supported).
node(n1350,refuted) :- status(o_a1ff27aeb67294210c2c,refuted).
node(n1350,unknown) :- status(o_a1ff27aeb67294210c2c,unknown).
node(n1351,supported) :- status(o_d6d5fd3b5eaf8444639c,supported).
node(n1351,refuted) :- status(o_d6d5fd3b5eaf8444639c,refuted).
node(n1351,unknown) :- status(o_d6d5fd3b5eaf8444639c,unknown).
node(n1348,supported) :- node(n1349,supported), node(n1350,supported), node(n1351,supported).
node(n1348,refuted) :- node(n1349,refuted).
node(n1348,refuted) :- node(n1350,refuted).
node(n1348,refuted) :- node(n1351,refuted).
node(n1348,unknown) :- \+ node(n1348,supported), \+ node(n1348,refuted).
node(n1353,supported) :- status(o_77e05eb57f599270bea5,supported).
node(n1353,refuted) :- status(o_77e05eb57f599270bea5,refuted).
node(n1353,unknown) :- status(o_77e05eb57f599270bea5,unknown).
node(n1354,supported) :- status(o_41ac68c1d660e1bb05ae,supported).
node(n1354,refuted) :- status(o_41ac68c1d660e1bb05ae,refuted).
node(n1354,unknown) :- status(o_41ac68c1d660e1bb05ae,unknown).
node(n1355,supported) :- status(o_a63b26eec5ba7afe02b2,supported).
node(n1355,refuted) :- status(o_a63b26eec5ba7afe02b2,refuted).
node(n1355,unknown) :- status(o_a63b26eec5ba7afe02b2,unknown).
node(n1352,supported) :- node(n1353,supported), node(n1354,supported), node(n1355,supported).
node(n1352,refuted) :- node(n1353,refuted).
node(n1352,refuted) :- node(n1354,refuted).
node(n1352,refuted) :- node(n1355,refuted).
node(n1352,unknown) :- \+ node(n1352,supported), \+ node(n1352,refuted).
node(n1347,refuted) :- node(n1348,refuted), node(n1352,refuted), node(n9,refuted).
node(n1347,supported) :- node(n1348,supported).
node(n1347,supported) :- node(n1352,supported).
node(n1347,supported) :- node(n9,supported).
node(n1347,unknown) :- \+ node(n1347,supported), \+ node(n1347,refuted).
verdict(c_08b002999a59b635,supported) :- node(n1347,supported).
query(verdict(c_08b002999a59b635,supported)).
verdict(c_08b002999a59b635,refuted) :- node(n1347,refuted).
query(verdict(c_08b002999a59b635,refuted)).
verdict(c_08b002999a59b635,unknown) :- node(n1347,unknown).
query(verdict(c_08b002999a59b635,unknown)).
node(n1358,supported) :- status(o_e2e359456fc51a027542,supported).
node(n1358,refuted) :- status(o_e2e359456fc51a027542,refuted).
node(n1358,unknown) :- status(o_e2e359456fc51a027542,unknown).
node(n1357,supported) :- node(n1349,supported), node(n1350,supported), node(n1358,supported), node(n1351,supported).
node(n1357,refuted) :- node(n1349,refuted).
node(n1357,refuted) :- node(n1350,refuted).
node(n1357,refuted) :- node(n1358,refuted).
node(n1357,refuted) :- node(n1351,refuted).
node(n1357,unknown) :- \+ node(n1357,supported), \+ node(n1357,refuted).
node(n1360,supported) :- status(o_7e88fec1c93fd306ec6d,supported).
node(n1360,refuted) :- status(o_7e88fec1c93fd306ec6d,refuted).
node(n1360,unknown) :- status(o_7e88fec1c93fd306ec6d,unknown).
node(n1359,supported) :- node(n1353,supported), node(n1354,supported), node(n1360,supported), node(n1355,supported).
node(n1359,refuted) :- node(n1353,refuted).
node(n1359,refuted) :- node(n1354,refuted).
node(n1359,refuted) :- node(n1360,refuted).
node(n1359,refuted) :- node(n1355,refuted).
node(n1359,unknown) :- \+ node(n1359,supported), \+ node(n1359,refuted).
node(n1356,refuted) :- node(n1357,refuted), node(n1359,refuted), node(n9,refuted).
node(n1356,supported) :- node(n1357,supported).
node(n1356,supported) :- node(n1359,supported).
node(n1356,supported) :- node(n9,supported).
node(n1356,unknown) :- \+ node(n1356,supported), \+ node(n1356,refuted).
verdict(c_c6bb3db0105526c6,supported) :- node(n1356,supported).
query(verdict(c_c6bb3db0105526c6,supported)).
verdict(c_c6bb3db0105526c6,refuted) :- node(n1356,refuted).
query(verdict(c_c6bb3db0105526c6,refuted)).
verdict(c_c6bb3db0105526c6,unknown) :- node(n1356,unknown).
query(verdict(c_c6bb3db0105526c6,unknown)).
node(n1363,supported) :- status(o_d246b22a2ae198ed84cb,supported).
node(n1363,refuted) :- status(o_d246b22a2ae198ed84cb,refuted).
node(n1363,unknown) :- status(o_d246b22a2ae198ed84cb,unknown).
node(n1364,supported) :- status(o_7664e13e53630bb96e10,supported).
node(n1364,refuted) :- status(o_7664e13e53630bb96e10,refuted).
node(n1364,unknown) :- status(o_7664e13e53630bb96e10,unknown).
node(n1365,supported) :- status(o_3c78a94bc648b2496d91,supported).
node(n1365,refuted) :- status(o_3c78a94bc648b2496d91,refuted).
node(n1365,unknown) :- status(o_3c78a94bc648b2496d91,unknown).
node(n1362,supported) :- node(n1363,supported), node(n1364,supported), node(n1365,supported).
node(n1362,refuted) :- node(n1363,refuted).
node(n1362,refuted) :- node(n1364,refuted).
node(n1362,refuted) :- node(n1365,refuted).
node(n1362,unknown) :- \+ node(n1362,supported), \+ node(n1362,refuted).
node(n1367,supported) :- status(o_673fee03e493346b746e,supported).
node(n1367,refuted) :- status(o_673fee03e493346b746e,refuted).
node(n1367,unknown) :- status(o_673fee03e493346b746e,unknown).
node(n1368,supported) :- status(o_ca39965b176b9773d7ec,supported).
node(n1368,refuted) :- status(o_ca39965b176b9773d7ec,refuted).
node(n1368,unknown) :- status(o_ca39965b176b9773d7ec,unknown).
node(n1369,supported) :- status(o_0c9965e9d630899ba817,supported).
node(n1369,refuted) :- status(o_0c9965e9d630899ba817,refuted).
node(n1369,unknown) :- status(o_0c9965e9d630899ba817,unknown).
node(n1366,supported) :- node(n1367,supported), node(n1368,supported), node(n1369,supported).
node(n1366,refuted) :- node(n1367,refuted).
node(n1366,refuted) :- node(n1368,refuted).
node(n1366,refuted) :- node(n1369,refuted).
node(n1366,unknown) :- \+ node(n1366,supported), \+ node(n1366,refuted).
node(n1361,refuted) :- node(n1362,refuted), node(n1366,refuted), node(n9,refuted).
node(n1361,supported) :- node(n1362,supported).
node(n1361,supported) :- node(n1366,supported).
node(n1361,supported) :- node(n9,supported).
node(n1361,unknown) :- \+ node(n1361,supported), \+ node(n1361,refuted).
verdict(c_e55cb49dae8bc29d,supported) :- node(n1361,supported).
query(verdict(c_e55cb49dae8bc29d,supported)).
verdict(c_e55cb49dae8bc29d,refuted) :- node(n1361,refuted).
query(verdict(c_e55cb49dae8bc29d,refuted)).
verdict(c_e55cb49dae8bc29d,unknown) :- node(n1361,unknown).
query(verdict(c_e55cb49dae8bc29d,unknown)).
node(n1372,supported) :- status(o_3b275837263ec2f1f5c2,supported).
node(n1372,refuted) :- status(o_3b275837263ec2f1f5c2,refuted).
node(n1372,unknown) :- status(o_3b275837263ec2f1f5c2,unknown).
node(n1371,supported) :- node(n1363,supported), node(n1364,supported), node(n1372,supported), node(n1365,supported).
node(n1371,refuted) :- node(n1363,refuted).
node(n1371,refuted) :- node(n1364,refuted).
node(n1371,refuted) :- node(n1372,refuted).
node(n1371,refuted) :- node(n1365,refuted).
node(n1371,unknown) :- \+ node(n1371,supported), \+ node(n1371,refuted).
node(n1374,supported) :- status(o_36e53627d4fe36d9d282,supported).
node(n1374,refuted) :- status(o_36e53627d4fe36d9d282,refuted).
node(n1374,unknown) :- status(o_36e53627d4fe36d9d282,unknown).
node(n1373,supported) :- node(n1367,supported), node(n1368,supported), node(n1374,supported), node(n1369,supported).
node(n1373,refuted) :- node(n1367,refuted).
node(n1373,refuted) :- node(n1368,refuted).
node(n1373,refuted) :- node(n1374,refuted).
node(n1373,refuted) :- node(n1369,refuted).
node(n1373,unknown) :- \+ node(n1373,supported), \+ node(n1373,refuted).
node(n1370,refuted) :- node(n1371,refuted), node(n1373,refuted), node(n9,refuted).
node(n1370,supported) :- node(n1371,supported).
node(n1370,supported) :- node(n1373,supported).
node(n1370,supported) :- node(n9,supported).
node(n1370,unknown) :- \+ node(n1370,supported), \+ node(n1370,refuted).
verdict(c_a473a263971f633c,supported) :- node(n1370,supported).
query(verdict(c_a473a263971f633c,supported)).
verdict(c_a473a263971f633c,refuted) :- node(n1370,refuted).
query(verdict(c_a473a263971f633c,refuted)).
verdict(c_a473a263971f633c,unknown) :- node(n1370,unknown).
query(verdict(c_a473a263971f633c,unknown)).
node(n1377,supported) :- status(o_d42ec88ea5d8ee19a503,supported).
node(n1377,refuted) :- status(o_d42ec88ea5d8ee19a503,refuted).
node(n1377,unknown) :- status(o_d42ec88ea5d8ee19a503,unknown).
node(n1378,supported) :- status(o_38f770423f4fadb0e38b,supported).
node(n1378,refuted) :- status(o_38f770423f4fadb0e38b,refuted).
node(n1378,unknown) :- status(o_38f770423f4fadb0e38b,unknown).
node(n1379,supported) :- status(o_29dc598ecfd4000498ba,supported).
node(n1379,refuted) :- status(o_29dc598ecfd4000498ba,refuted).
node(n1379,unknown) :- status(o_29dc598ecfd4000498ba,unknown).
node(n1376,supported) :- node(n1377,supported), node(n1378,supported), node(n1379,supported).
node(n1376,refuted) :- node(n1377,refuted).
node(n1376,refuted) :- node(n1378,refuted).
node(n1376,refuted) :- node(n1379,refuted).
node(n1376,unknown) :- \+ node(n1376,supported), \+ node(n1376,refuted).
node(n1381,supported) :- status(o_acb7df52b1aac321db9c,supported).
node(n1381,refuted) :- status(o_acb7df52b1aac321db9c,refuted).
node(n1381,unknown) :- status(o_acb7df52b1aac321db9c,unknown).
node(n1382,supported) :- status(o_d1d6a93949512537e120,supported).
node(n1382,refuted) :- status(o_d1d6a93949512537e120,refuted).
node(n1382,unknown) :- status(o_d1d6a93949512537e120,unknown).
node(n1383,supported) :- status(o_9769c3e96d7113c579ae,supported).
node(n1383,refuted) :- status(o_9769c3e96d7113c579ae,refuted).
node(n1383,unknown) :- status(o_9769c3e96d7113c579ae,unknown).
node(n1380,supported) :- node(n1381,supported), node(n1382,supported), node(n1383,supported).
node(n1380,refuted) :- node(n1381,refuted).
node(n1380,refuted) :- node(n1382,refuted).
node(n1380,refuted) :- node(n1383,refuted).
node(n1380,unknown) :- \+ node(n1380,supported), \+ node(n1380,refuted).
node(n1375,refuted) :- node(n1376,refuted), node(n1380,refuted), node(n9,refuted).
node(n1375,supported) :- node(n1376,supported).
node(n1375,supported) :- node(n1380,supported).
node(n1375,supported) :- node(n9,supported).
node(n1375,unknown) :- \+ node(n1375,supported), \+ node(n1375,refuted).
verdict(c_efed2748424909dd,supported) :- node(n1375,supported).
query(verdict(c_efed2748424909dd,supported)).
verdict(c_efed2748424909dd,refuted) :- node(n1375,refuted).
query(verdict(c_efed2748424909dd,refuted)).
verdict(c_efed2748424909dd,unknown) :- node(n1375,unknown).
query(verdict(c_efed2748424909dd,unknown)).
node(n1386,supported) :- status(o_9e488ab794c3ecc9d519,supported).
node(n1386,refuted) :- status(o_9e488ab794c3ecc9d519,refuted).
node(n1386,unknown) :- status(o_9e488ab794c3ecc9d519,unknown).
node(n1385,supported) :- node(n1377,supported), node(n1378,supported), node(n1386,supported), node(n1379,supported).
node(n1385,refuted) :- node(n1377,refuted).
node(n1385,refuted) :- node(n1378,refuted).
node(n1385,refuted) :- node(n1386,refuted).
node(n1385,refuted) :- node(n1379,refuted).
node(n1385,unknown) :- \+ node(n1385,supported), \+ node(n1385,refuted).
node(n1388,supported) :- status(o_1e2f8ae673d92cb792c1,supported).
node(n1388,refuted) :- status(o_1e2f8ae673d92cb792c1,refuted).
node(n1388,unknown) :- status(o_1e2f8ae673d92cb792c1,unknown).
node(n1387,supported) :- node(n1381,supported), node(n1382,supported), node(n1388,supported), node(n1383,supported).
node(n1387,refuted) :- node(n1381,refuted).
node(n1387,refuted) :- node(n1382,refuted).
node(n1387,refuted) :- node(n1388,refuted).
node(n1387,refuted) :- node(n1383,refuted).
node(n1387,unknown) :- \+ node(n1387,supported), \+ node(n1387,refuted).
node(n1384,refuted) :- node(n1385,refuted), node(n1387,refuted), node(n9,refuted).
node(n1384,supported) :- node(n1385,supported).
node(n1384,supported) :- node(n1387,supported).
node(n1384,supported) :- node(n9,supported).
node(n1384,unknown) :- \+ node(n1384,supported), \+ node(n1384,refuted).
verdict(c_df9fd0a9d842608e,supported) :- node(n1384,supported).
query(verdict(c_df9fd0a9d842608e,supported)).
verdict(c_df9fd0a9d842608e,refuted) :- node(n1384,refuted).
query(verdict(c_df9fd0a9d842608e,refuted)).
verdict(c_df9fd0a9d842608e,unknown) :- node(n1384,unknown).
query(verdict(c_df9fd0a9d842608e,unknown)).
node(n1391,supported) :- status(o_468be3babf641307d972,supported).
node(n1391,refuted) :- status(o_468be3babf641307d972,refuted).
node(n1391,unknown) :- status(o_468be3babf641307d972,unknown).
node(n1392,supported) :- status(o_9ee589f86c1d037995ef,supported).
node(n1392,refuted) :- status(o_9ee589f86c1d037995ef,refuted).
node(n1392,unknown) :- status(o_9ee589f86c1d037995ef,unknown).
node(n1393,supported) :- status(o_489efec430fd0fa66716,supported).
node(n1393,refuted) :- status(o_489efec430fd0fa66716,refuted).
node(n1393,unknown) :- status(o_489efec430fd0fa66716,unknown).
node(n1390,supported) :- node(n1391,supported), node(n1392,supported), node(n1393,supported).
node(n1390,refuted) :- node(n1391,refuted).
node(n1390,refuted) :- node(n1392,refuted).
node(n1390,refuted) :- node(n1393,refuted).
node(n1390,unknown) :- \+ node(n1390,supported), \+ node(n1390,refuted).
node(n1395,supported) :- status(o_c38257176a64045332c2,supported).
node(n1395,refuted) :- status(o_c38257176a64045332c2,refuted).
node(n1395,unknown) :- status(o_c38257176a64045332c2,unknown).
node(n1396,supported) :- status(o_d11c1a177ee12190fc24,supported).
node(n1396,refuted) :- status(o_d11c1a177ee12190fc24,refuted).
node(n1396,unknown) :- status(o_d11c1a177ee12190fc24,unknown).
node(n1397,supported) :- status(o_05929e27873600e36733,supported).
node(n1397,refuted) :- status(o_05929e27873600e36733,refuted).
node(n1397,unknown) :- status(o_05929e27873600e36733,unknown).
node(n1394,supported) :- node(n1395,supported), node(n1396,supported), node(n1397,supported).
node(n1394,refuted) :- node(n1395,refuted).
node(n1394,refuted) :- node(n1396,refuted).
node(n1394,refuted) :- node(n1397,refuted).
node(n1394,unknown) :- \+ node(n1394,supported), \+ node(n1394,refuted).
node(n1389,refuted) :- node(n1390,refuted), node(n1394,refuted), node(n9,refuted).
node(n1389,supported) :- node(n1390,supported).
node(n1389,supported) :- node(n1394,supported).
node(n1389,supported) :- node(n9,supported).
node(n1389,unknown) :- \+ node(n1389,supported), \+ node(n1389,refuted).
verdict(c_66651debf95379b5,supported) :- node(n1389,supported).
query(verdict(c_66651debf95379b5,supported)).
verdict(c_66651debf95379b5,refuted) :- node(n1389,refuted).
query(verdict(c_66651debf95379b5,refuted)).
verdict(c_66651debf95379b5,unknown) :- node(n1389,unknown).
query(verdict(c_66651debf95379b5,unknown)).
node(n1400,supported) :- status(o_309baf1c9fe60620599b,supported).
node(n1400,refuted) :- status(o_309baf1c9fe60620599b,refuted).
node(n1400,unknown) :- status(o_309baf1c9fe60620599b,unknown).
node(n1399,supported) :- node(n1391,supported), node(n1392,supported), node(n1400,supported), node(n1393,supported).
node(n1399,refuted) :- node(n1391,refuted).
node(n1399,refuted) :- node(n1392,refuted).
node(n1399,refuted) :- node(n1400,refuted).
node(n1399,refuted) :- node(n1393,refuted).
node(n1399,unknown) :- \+ node(n1399,supported), \+ node(n1399,refuted).
node(n1402,supported) :- status(o_fc95ca510d87dd43e20f,supported).
node(n1402,refuted) :- status(o_fc95ca510d87dd43e20f,refuted).
node(n1402,unknown) :- status(o_fc95ca510d87dd43e20f,unknown).
node(n1401,supported) :- node(n1395,supported), node(n1396,supported), node(n1402,supported), node(n1397,supported).
node(n1401,refuted) :- node(n1395,refuted).
node(n1401,refuted) :- node(n1396,refuted).
node(n1401,refuted) :- node(n1402,refuted).
node(n1401,refuted) :- node(n1397,refuted).
node(n1401,unknown) :- \+ node(n1401,supported), \+ node(n1401,refuted).
node(n1398,refuted) :- node(n1399,refuted), node(n1401,refuted), node(n9,refuted).
node(n1398,supported) :- node(n1399,supported).
node(n1398,supported) :- node(n1401,supported).
node(n1398,supported) :- node(n9,supported).
node(n1398,unknown) :- \+ node(n1398,supported), \+ node(n1398,refuted).
verdict(c_cc3b47501bcf939c,supported) :- node(n1398,supported).
query(verdict(c_cc3b47501bcf939c,supported)).
verdict(c_cc3b47501bcf939c,refuted) :- node(n1398,refuted).
query(verdict(c_cc3b47501bcf939c,refuted)).
verdict(c_cc3b47501bcf939c,unknown) :- node(n1398,unknown).
query(verdict(c_cc3b47501bcf939c,unknown)).
node(n1405,supported) :- status(o_901a7085deb40c961140,supported).
node(n1405,refuted) :- status(o_901a7085deb40c961140,refuted).
node(n1405,unknown) :- status(o_901a7085deb40c961140,unknown).
node(n1406,supported) :- status(o_dade2534a3b2b718ab50,supported).
node(n1406,refuted) :- status(o_dade2534a3b2b718ab50,refuted).
node(n1406,unknown) :- status(o_dade2534a3b2b718ab50,unknown).
node(n1407,supported) :- status(o_2db814643b3ef700e36d,supported).
node(n1407,refuted) :- status(o_2db814643b3ef700e36d,refuted).
node(n1407,unknown) :- status(o_2db814643b3ef700e36d,unknown).
node(n1404,supported) :- node(n1405,supported), node(n1406,supported), node(n1407,supported).
node(n1404,refuted) :- node(n1405,refuted).
node(n1404,refuted) :- node(n1406,refuted).
node(n1404,refuted) :- node(n1407,refuted).
node(n1404,unknown) :- \+ node(n1404,supported), \+ node(n1404,refuted).
node(n1409,supported) :- status(o_630034cdf9f5fc94069c,supported).
node(n1409,refuted) :- status(o_630034cdf9f5fc94069c,refuted).
node(n1409,unknown) :- status(o_630034cdf9f5fc94069c,unknown).
node(n1410,supported) :- status(o_170d0ee7dce62ae44a31,supported).
node(n1410,refuted) :- status(o_170d0ee7dce62ae44a31,refuted).
node(n1410,unknown) :- status(o_170d0ee7dce62ae44a31,unknown).
node(n1411,supported) :- status(o_69611b50a1e65ec70e3f,supported).
node(n1411,refuted) :- status(o_69611b50a1e65ec70e3f,refuted).
node(n1411,unknown) :- status(o_69611b50a1e65ec70e3f,unknown).
node(n1408,supported) :- node(n1409,supported), node(n1410,supported), node(n1411,supported).
node(n1408,refuted) :- node(n1409,refuted).
node(n1408,refuted) :- node(n1410,refuted).
node(n1408,refuted) :- node(n1411,refuted).
node(n1408,unknown) :- \+ node(n1408,supported), \+ node(n1408,refuted).
node(n1403,refuted) :- node(n1404,refuted), node(n1408,refuted), node(n9,refuted).
node(n1403,supported) :- node(n1404,supported).
node(n1403,supported) :- node(n1408,supported).
node(n1403,supported) :- node(n9,supported).
node(n1403,unknown) :- \+ node(n1403,supported), \+ node(n1403,refuted).
verdict(c_abec9ec32debacd7,supported) :- node(n1403,supported).
query(verdict(c_abec9ec32debacd7,supported)).
verdict(c_abec9ec32debacd7,refuted) :- node(n1403,refuted).
query(verdict(c_abec9ec32debacd7,refuted)).
verdict(c_abec9ec32debacd7,unknown) :- node(n1403,unknown).
query(verdict(c_abec9ec32debacd7,unknown)).
node(n1414,supported) :- status(o_7ae5fc7a8b2e4a33a87d,supported).
node(n1414,refuted) :- status(o_7ae5fc7a8b2e4a33a87d,refuted).
node(n1414,unknown) :- status(o_7ae5fc7a8b2e4a33a87d,unknown).
node(n1413,supported) :- node(n1405,supported), node(n1406,supported), node(n1414,supported), node(n1407,supported).
node(n1413,refuted) :- node(n1405,refuted).
node(n1413,refuted) :- node(n1406,refuted).
node(n1413,refuted) :- node(n1414,refuted).
node(n1413,refuted) :- node(n1407,refuted).
node(n1413,unknown) :- \+ node(n1413,supported), \+ node(n1413,refuted).
node(n1416,supported) :- status(o_8f5e5f3725a73e3d21df,supported).
node(n1416,refuted) :- status(o_8f5e5f3725a73e3d21df,refuted).
node(n1416,unknown) :- status(o_8f5e5f3725a73e3d21df,unknown).
node(n1415,supported) :- node(n1409,supported), node(n1410,supported), node(n1416,supported), node(n1411,supported).
node(n1415,refuted) :- node(n1409,refuted).
node(n1415,refuted) :- node(n1410,refuted).
node(n1415,refuted) :- node(n1416,refuted).
node(n1415,refuted) :- node(n1411,refuted).
node(n1415,unknown) :- \+ node(n1415,supported), \+ node(n1415,refuted).
node(n1412,refuted) :- node(n1413,refuted), node(n1415,refuted), node(n9,refuted).
node(n1412,supported) :- node(n1413,supported).
node(n1412,supported) :- node(n1415,supported).
node(n1412,supported) :- node(n9,supported).
node(n1412,unknown) :- \+ node(n1412,supported), \+ node(n1412,refuted).
verdict(c_c0e1cc242e4622b7,supported) :- node(n1412,supported).
query(verdict(c_c0e1cc242e4622b7,supported)).
verdict(c_c0e1cc242e4622b7,refuted) :- node(n1412,refuted).
query(verdict(c_c0e1cc242e4622b7,refuted)).
verdict(c_c0e1cc242e4622b7,unknown) :- node(n1412,unknown).
query(verdict(c_c0e1cc242e4622b7,unknown)).
node(n1419,supported) :- status(o_5e492fe8162d57aadf78,supported).
node(n1419,refuted) :- status(o_5e492fe8162d57aadf78,refuted).
node(n1419,unknown) :- status(o_5e492fe8162d57aadf78,unknown).
node(n1420,supported) :- status(o_4bd273288a69a1575e33,supported).
node(n1420,refuted) :- status(o_4bd273288a69a1575e33,refuted).
node(n1420,unknown) :- status(o_4bd273288a69a1575e33,unknown).
node(n1421,supported) :- status(o_c3d5b580e815a1798d83,supported).
node(n1421,refuted) :- status(o_c3d5b580e815a1798d83,refuted).
node(n1421,unknown) :- status(o_c3d5b580e815a1798d83,unknown).
node(n1418,supported) :- node(n1419,supported), node(n1420,supported), node(n1421,supported).
node(n1418,refuted) :- node(n1419,refuted).
node(n1418,refuted) :- node(n1420,refuted).
node(n1418,refuted) :- node(n1421,refuted).
node(n1418,unknown) :- \+ node(n1418,supported), \+ node(n1418,refuted).
node(n1423,supported) :- status(o_d20a3b8edef1feef8322,supported).
node(n1423,refuted) :- status(o_d20a3b8edef1feef8322,refuted).
node(n1423,unknown) :- status(o_d20a3b8edef1feef8322,unknown).
node(n1424,supported) :- status(o_d15b07d6a3b5f11628e6,supported).
node(n1424,refuted) :- status(o_d15b07d6a3b5f11628e6,refuted).
node(n1424,unknown) :- status(o_d15b07d6a3b5f11628e6,unknown).
node(n1425,supported) :- status(o_464aecc4ce5a1844d124,supported).
node(n1425,refuted) :- status(o_464aecc4ce5a1844d124,refuted).
node(n1425,unknown) :- status(o_464aecc4ce5a1844d124,unknown).
node(n1422,supported) :- node(n1423,supported), node(n1424,supported), node(n1425,supported).
node(n1422,refuted) :- node(n1423,refuted).
node(n1422,refuted) :- node(n1424,refuted).
node(n1422,refuted) :- node(n1425,refuted).
node(n1422,unknown) :- \+ node(n1422,supported), \+ node(n1422,refuted).
node(n1417,refuted) :- node(n1418,refuted), node(n1422,refuted), node(n9,refuted).
node(n1417,supported) :- node(n1418,supported).
node(n1417,supported) :- node(n1422,supported).
node(n1417,supported) :- node(n9,supported).
node(n1417,unknown) :- \+ node(n1417,supported), \+ node(n1417,refuted).
verdict(c_0b4f469f774a0326,supported) :- node(n1417,supported).
query(verdict(c_0b4f469f774a0326,supported)).
verdict(c_0b4f469f774a0326,refuted) :- node(n1417,refuted).
query(verdict(c_0b4f469f774a0326,refuted)).
verdict(c_0b4f469f774a0326,unknown) :- node(n1417,unknown).
query(verdict(c_0b4f469f774a0326,unknown)).
node(n1428,supported) :- status(o_c107783c00ca77d9b4f7,supported).
node(n1428,refuted) :- status(o_c107783c00ca77d9b4f7,refuted).
node(n1428,unknown) :- status(o_c107783c00ca77d9b4f7,unknown).
node(n1427,supported) :- node(n1419,supported), node(n1420,supported), node(n1428,supported), node(n1421,supported).
node(n1427,refuted) :- node(n1419,refuted).
node(n1427,refuted) :- node(n1420,refuted).
node(n1427,refuted) :- node(n1428,refuted).
node(n1427,refuted) :- node(n1421,refuted).
node(n1427,unknown) :- \+ node(n1427,supported), \+ node(n1427,refuted).
node(n1430,supported) :- status(o_815231a2d896d5b78c95,supported).
node(n1430,refuted) :- status(o_815231a2d896d5b78c95,refuted).
node(n1430,unknown) :- status(o_815231a2d896d5b78c95,unknown).
node(n1429,supported) :- node(n1423,supported), node(n1424,supported), node(n1430,supported), node(n1425,supported).
node(n1429,refuted) :- node(n1423,refuted).
node(n1429,refuted) :- node(n1424,refuted).
node(n1429,refuted) :- node(n1430,refuted).
node(n1429,refuted) :- node(n1425,refuted).
node(n1429,unknown) :- \+ node(n1429,supported), \+ node(n1429,refuted).
node(n1426,refuted) :- node(n1427,refuted), node(n1429,refuted), node(n9,refuted).
node(n1426,supported) :- node(n1427,supported).
node(n1426,supported) :- node(n1429,supported).
node(n1426,supported) :- node(n9,supported).
node(n1426,unknown) :- \+ node(n1426,supported), \+ node(n1426,refuted).
verdict(c_c14c96edb65607f8,supported) :- node(n1426,supported).
query(verdict(c_c14c96edb65607f8,supported)).
verdict(c_c14c96edb65607f8,refuted) :- node(n1426,refuted).
query(verdict(c_c14c96edb65607f8,refuted)).
verdict(c_c14c96edb65607f8,unknown) :- node(n1426,unknown).
query(verdict(c_c14c96edb65607f8,unknown)).
node(n1433,supported) :- status(o_b2cf84aadfd92e4de12f,supported).
node(n1433,refuted) :- status(o_b2cf84aadfd92e4de12f,refuted).
node(n1433,unknown) :- status(o_b2cf84aadfd92e4de12f,unknown).
node(n1434,supported) :- status(o_d2965574aa889d612dd7,supported).
node(n1434,refuted) :- status(o_d2965574aa889d612dd7,refuted).
node(n1434,unknown) :- status(o_d2965574aa889d612dd7,unknown).
node(n1435,supported) :- status(o_efb95c5c392d6190bf37,supported).
node(n1435,refuted) :- status(o_efb95c5c392d6190bf37,refuted).
node(n1435,unknown) :- status(o_efb95c5c392d6190bf37,unknown).
node(n1432,supported) :- node(n1433,supported), node(n1434,supported), node(n1435,supported).
node(n1432,refuted) :- node(n1433,refuted).
node(n1432,refuted) :- node(n1434,refuted).
node(n1432,refuted) :- node(n1435,refuted).
node(n1432,unknown) :- \+ node(n1432,supported), \+ node(n1432,refuted).
node(n1437,supported) :- status(o_428c52bfe6beb5064445,supported).
node(n1437,refuted) :- status(o_428c52bfe6beb5064445,refuted).
node(n1437,unknown) :- status(o_428c52bfe6beb5064445,unknown).
node(n1438,supported) :- status(o_7379ff4abb0f4c918400,supported).
node(n1438,refuted) :- status(o_7379ff4abb0f4c918400,refuted).
node(n1438,unknown) :- status(o_7379ff4abb0f4c918400,unknown).
node(n1439,supported) :- status(o_dc1b54e58c217ad4c91b,supported).
node(n1439,refuted) :- status(o_dc1b54e58c217ad4c91b,refuted).
node(n1439,unknown) :- status(o_dc1b54e58c217ad4c91b,unknown).
node(n1436,supported) :- node(n1437,supported), node(n1438,supported), node(n1439,supported).
node(n1436,refuted) :- node(n1437,refuted).
node(n1436,refuted) :- node(n1438,refuted).
node(n1436,refuted) :- node(n1439,refuted).
node(n1436,unknown) :- \+ node(n1436,supported), \+ node(n1436,refuted).
node(n1431,refuted) :- node(n1432,refuted), node(n1436,refuted), node(n9,refuted).
node(n1431,supported) :- node(n1432,supported).
node(n1431,supported) :- node(n1436,supported).
node(n1431,supported) :- node(n9,supported).
node(n1431,unknown) :- \+ node(n1431,supported), \+ node(n1431,refuted).
verdict(c_477f2a339ccebe55,supported) :- node(n1431,supported).
query(verdict(c_477f2a339ccebe55,supported)).
verdict(c_477f2a339ccebe55,refuted) :- node(n1431,refuted).
query(verdict(c_477f2a339ccebe55,refuted)).
verdict(c_477f2a339ccebe55,unknown) :- node(n1431,unknown).
query(verdict(c_477f2a339ccebe55,unknown)).
node(n1442,supported) :- status(o_310aab1a432ee8220650,supported).
node(n1442,refuted) :- status(o_310aab1a432ee8220650,refuted).
node(n1442,unknown) :- status(o_310aab1a432ee8220650,unknown).
node(n1441,supported) :- node(n1433,supported), node(n1434,supported), node(n1442,supported), node(n1435,supported).
node(n1441,refuted) :- node(n1433,refuted).
node(n1441,refuted) :- node(n1434,refuted).
node(n1441,refuted) :- node(n1442,refuted).
node(n1441,refuted) :- node(n1435,refuted).
node(n1441,unknown) :- \+ node(n1441,supported), \+ node(n1441,refuted).
node(n1444,supported) :- status(o_83d6e086f1e6f591cd80,supported).
node(n1444,refuted) :- status(o_83d6e086f1e6f591cd80,refuted).
node(n1444,unknown) :- status(o_83d6e086f1e6f591cd80,unknown).
node(n1443,supported) :- node(n1437,supported), node(n1438,supported), node(n1444,supported), node(n1439,supported).
node(n1443,refuted) :- node(n1437,refuted).
node(n1443,refuted) :- node(n1438,refuted).
node(n1443,refuted) :- node(n1444,refuted).
node(n1443,refuted) :- node(n1439,refuted).
node(n1443,unknown) :- \+ node(n1443,supported), \+ node(n1443,refuted).
node(n1440,refuted) :- node(n1441,refuted), node(n1443,refuted), node(n9,refuted).
node(n1440,supported) :- node(n1441,supported).
node(n1440,supported) :- node(n1443,supported).
node(n1440,supported) :- node(n9,supported).
node(n1440,unknown) :- \+ node(n1440,supported), \+ node(n1440,refuted).
verdict(c_0fdca7998a2dc8d6,supported) :- node(n1440,supported).
query(verdict(c_0fdca7998a2dc8d6,supported)).
verdict(c_0fdca7998a2dc8d6,refuted) :- node(n1440,refuted).
query(verdict(c_0fdca7998a2dc8d6,refuted)).
verdict(c_0fdca7998a2dc8d6,unknown) :- node(n1440,unknown).
query(verdict(c_0fdca7998a2dc8d6,unknown)).
node(n1447,supported) :- status(o_5320cd848352bc38e08f,supported).
node(n1447,refuted) :- status(o_5320cd848352bc38e08f,refuted).
node(n1447,unknown) :- status(o_5320cd848352bc38e08f,unknown).
node(n1448,supported) :- status(o_1c4d720ea7ef876005ef,supported).
node(n1448,refuted) :- status(o_1c4d720ea7ef876005ef,refuted).
node(n1448,unknown) :- status(o_1c4d720ea7ef876005ef,unknown).
node(n1449,supported) :- status(o_5f28285bb8f6675ce263,supported).
node(n1449,refuted) :- status(o_5f28285bb8f6675ce263,refuted).
node(n1449,unknown) :- status(o_5f28285bb8f6675ce263,unknown).
node(n1446,supported) :- node(n1447,supported), node(n1448,supported), node(n1449,supported).
node(n1446,refuted) :- node(n1447,refuted).
node(n1446,refuted) :- node(n1448,refuted).
node(n1446,refuted) :- node(n1449,refuted).
node(n1446,unknown) :- \+ node(n1446,supported), \+ node(n1446,refuted).
node(n1445,refuted) :- node(n1446,refuted), node(n9,refuted).
node(n1445,supported) :- node(n1446,supported).
node(n1445,supported) :- node(n9,supported).
node(n1445,unknown) :- \+ node(n1445,supported), \+ node(n1445,refuted).
verdict(c_5bf9c9a6a1da28cd,supported) :- node(n1445,supported).
query(verdict(c_5bf9c9a6a1da28cd,supported)).
verdict(c_5bf9c9a6a1da28cd,refuted) :- node(n1445,refuted).
query(verdict(c_5bf9c9a6a1da28cd,refuted)).
verdict(c_5bf9c9a6a1da28cd,unknown) :- node(n1445,unknown).
query(verdict(c_5bf9c9a6a1da28cd,unknown)).
node(n1452,supported) :- status(o_f413e52d14f0ddea856b,supported).
node(n1452,refuted) :- status(o_f413e52d14f0ddea856b,refuted).
node(n1452,unknown) :- status(o_f413e52d14f0ddea856b,unknown).
node(n1451,supported) :- node(n1447,supported), node(n1448,supported), node(n1452,supported), node(n1449,supported).
node(n1451,refuted) :- node(n1447,refuted).
node(n1451,refuted) :- node(n1448,refuted).
node(n1451,refuted) :- node(n1452,refuted).
node(n1451,refuted) :- node(n1449,refuted).
node(n1451,unknown) :- \+ node(n1451,supported), \+ node(n1451,refuted).
node(n1450,refuted) :- node(n1451,refuted), node(n9,refuted).
node(n1450,supported) :- node(n1451,supported).
node(n1450,supported) :- node(n9,supported).
node(n1450,unknown) :- \+ node(n1450,supported), \+ node(n1450,refuted).
verdict(c_4f770107f08ca6de,supported) :- node(n1450,supported).
query(verdict(c_4f770107f08ca6de,supported)).
verdict(c_4f770107f08ca6de,refuted) :- node(n1450,refuted).
query(verdict(c_4f770107f08ca6de,refuted)).
verdict(c_4f770107f08ca6de,unknown) :- node(n1450,unknown).
query(verdict(c_4f770107f08ca6de,unknown)).
node(n1455,supported) :- status(o_81d6792452dfb5223419,supported).
node(n1455,refuted) :- status(o_81d6792452dfb5223419,refuted).
node(n1455,unknown) :- status(o_81d6792452dfb5223419,unknown).
node(n1456,supported) :- status(o_4cfe86e56e553ff656b9,supported).
node(n1456,refuted) :- status(o_4cfe86e56e553ff656b9,refuted).
node(n1456,unknown) :- status(o_4cfe86e56e553ff656b9,unknown).
node(n1457,supported) :- status(o_a8542fbc1961c95928dc,supported).
node(n1457,refuted) :- status(o_a8542fbc1961c95928dc,refuted).
node(n1457,unknown) :- status(o_a8542fbc1961c95928dc,unknown).
node(n1454,supported) :- node(n1455,supported), node(n1456,supported), node(n1457,supported).
node(n1454,refuted) :- node(n1455,refuted).
node(n1454,refuted) :- node(n1456,refuted).
node(n1454,refuted) :- node(n1457,refuted).
node(n1454,unknown) :- \+ node(n1454,supported), \+ node(n1454,refuted).
node(n1453,refuted) :- node(n1454,refuted), node(n9,refuted).
node(n1453,supported) :- node(n1454,supported).
node(n1453,supported) :- node(n9,supported).
node(n1453,unknown) :- \+ node(n1453,supported), \+ node(n1453,refuted).
verdict(c_8b59f396cd47c7fc,supported) :- node(n1453,supported).
query(verdict(c_8b59f396cd47c7fc,supported)).
verdict(c_8b59f396cd47c7fc,refuted) :- node(n1453,refuted).
query(verdict(c_8b59f396cd47c7fc,refuted)).
verdict(c_8b59f396cd47c7fc,unknown) :- node(n1453,unknown).
query(verdict(c_8b59f396cd47c7fc,unknown)).
node(n1460,supported) :- status(o_16329f89fa27dbece70e,supported).
node(n1460,refuted) :- status(o_16329f89fa27dbece70e,refuted).
node(n1460,unknown) :- status(o_16329f89fa27dbece70e,unknown).
node(n1459,supported) :- node(n1455,supported), node(n1456,supported), node(n1460,supported), node(n1457,supported).
node(n1459,refuted) :- node(n1455,refuted).
node(n1459,refuted) :- node(n1456,refuted).
node(n1459,refuted) :- node(n1460,refuted).
node(n1459,refuted) :- node(n1457,refuted).
node(n1459,unknown) :- \+ node(n1459,supported), \+ node(n1459,refuted).
node(n1458,refuted) :- node(n1459,refuted), node(n9,refuted).
node(n1458,supported) :- node(n1459,supported).
node(n1458,supported) :- node(n9,supported).
node(n1458,unknown) :- \+ node(n1458,supported), \+ node(n1458,refuted).
verdict(c_8724fd6c6c9a12ad,supported) :- node(n1458,supported).
query(verdict(c_8724fd6c6c9a12ad,supported)).
verdict(c_8724fd6c6c9a12ad,refuted) :- node(n1458,refuted).
query(verdict(c_8724fd6c6c9a12ad,refuted)).
verdict(c_8724fd6c6c9a12ad,unknown) :- node(n1458,unknown).
query(verdict(c_8724fd6c6c9a12ad,unknown)).
node(n1463,supported) :- status(o_5ed964c5cb9a7faefe37,supported).
node(n1463,refuted) :- status(o_5ed964c5cb9a7faefe37,refuted).
node(n1463,unknown) :- status(o_5ed964c5cb9a7faefe37,unknown).
node(n1464,supported) :- status(o_f7f0d7b2186d8fe0fef9,supported).
node(n1464,refuted) :- status(o_f7f0d7b2186d8fe0fef9,refuted).
node(n1464,unknown) :- status(o_f7f0d7b2186d8fe0fef9,unknown).
node(n1465,supported) :- status(o_624ffa0d0bd1f7f92cd4,supported).
node(n1465,refuted) :- status(o_624ffa0d0bd1f7f92cd4,refuted).
node(n1465,unknown) :- status(o_624ffa0d0bd1f7f92cd4,unknown).
node(n1462,supported) :- node(n1463,supported), node(n1464,supported), node(n1465,supported).
node(n1462,refuted) :- node(n1463,refuted).
node(n1462,refuted) :- node(n1464,refuted).
node(n1462,refuted) :- node(n1465,refuted).
node(n1462,unknown) :- \+ node(n1462,supported), \+ node(n1462,refuted).
node(n1461,refuted) :- node(n1462,refuted), node(n9,refuted).
node(n1461,supported) :- node(n1462,supported).
node(n1461,supported) :- node(n9,supported).
node(n1461,unknown) :- \+ node(n1461,supported), \+ node(n1461,refuted).
verdict(c_c61f35631b4adfd4,supported) :- node(n1461,supported).
query(verdict(c_c61f35631b4adfd4,supported)).
verdict(c_c61f35631b4adfd4,refuted) :- node(n1461,refuted).
query(verdict(c_c61f35631b4adfd4,refuted)).
verdict(c_c61f35631b4adfd4,unknown) :- node(n1461,unknown).
query(verdict(c_c61f35631b4adfd4,unknown)).
node(n1468,supported) :- status(o_a456230c045faf540dde,supported).
node(n1468,refuted) :- status(o_a456230c045faf540dde,refuted).
node(n1468,unknown) :- status(o_a456230c045faf540dde,unknown).
node(n1467,supported) :- node(n1463,supported), node(n1464,supported), node(n1468,supported), node(n1465,supported).
node(n1467,refuted) :- node(n1463,refuted).
node(n1467,refuted) :- node(n1464,refuted).
node(n1467,refuted) :- node(n1468,refuted).
node(n1467,refuted) :- node(n1465,refuted).
node(n1467,unknown) :- \+ node(n1467,supported), \+ node(n1467,refuted).
node(n1466,refuted) :- node(n1467,refuted), node(n9,refuted).
node(n1466,supported) :- node(n1467,supported).
node(n1466,supported) :- node(n9,supported).
node(n1466,unknown) :- \+ node(n1466,supported), \+ node(n1466,refuted).
verdict(c_f53b9ae641d18b2b,supported) :- node(n1466,supported).
query(verdict(c_f53b9ae641d18b2b,supported)).
verdict(c_f53b9ae641d18b2b,refuted) :- node(n1466,refuted).
query(verdict(c_f53b9ae641d18b2b,refuted)).
verdict(c_f53b9ae641d18b2b,unknown) :- node(n1466,unknown).
query(verdict(c_f53b9ae641d18b2b,unknown)).
node(n1471,supported) :- status(o_c1a15dcd8af3a9d1ab00,supported).
node(n1471,refuted) :- status(o_c1a15dcd8af3a9d1ab00,refuted).
node(n1471,unknown) :- status(o_c1a15dcd8af3a9d1ab00,unknown).
node(n1472,supported) :- status(o_4974ccb7f09d177acb73,supported).
node(n1472,refuted) :- status(o_4974ccb7f09d177acb73,refuted).
node(n1472,unknown) :- status(o_4974ccb7f09d177acb73,unknown).
node(n1473,supported) :- status(o_34ab18ffb1400ec03c65,supported).
node(n1473,refuted) :- status(o_34ab18ffb1400ec03c65,refuted).
node(n1473,unknown) :- status(o_34ab18ffb1400ec03c65,unknown).
node(n1470,supported) :- node(n1471,supported), node(n1472,supported), node(n1473,supported).
node(n1470,refuted) :- node(n1471,refuted).
node(n1470,refuted) :- node(n1472,refuted).
node(n1470,refuted) :- node(n1473,refuted).
node(n1470,unknown) :- \+ node(n1470,supported), \+ node(n1470,refuted).
node(n1469,refuted) :- node(n1470,refuted), node(n9,refuted).
node(n1469,supported) :- node(n1470,supported).
node(n1469,supported) :- node(n9,supported).
node(n1469,unknown) :- \+ node(n1469,supported), \+ node(n1469,refuted).
verdict(c_64e205c2a260226d,supported) :- node(n1469,supported).
query(verdict(c_64e205c2a260226d,supported)).
verdict(c_64e205c2a260226d,refuted) :- node(n1469,refuted).
query(verdict(c_64e205c2a260226d,refuted)).
verdict(c_64e205c2a260226d,unknown) :- node(n1469,unknown).
query(verdict(c_64e205c2a260226d,unknown)).
node(n1476,supported) :- status(o_042c59d5f551c076a221,supported).
node(n1476,refuted) :- status(o_042c59d5f551c076a221,refuted).
node(n1476,unknown) :- status(o_042c59d5f551c076a221,unknown).
node(n1475,supported) :- node(n1471,supported), node(n1472,supported), node(n1476,supported), node(n1473,supported).
node(n1475,refuted) :- node(n1471,refuted).
node(n1475,refuted) :- node(n1472,refuted).
node(n1475,refuted) :- node(n1476,refuted).
node(n1475,refuted) :- node(n1473,refuted).
node(n1475,unknown) :- \+ node(n1475,supported), \+ node(n1475,refuted).
node(n1474,refuted) :- node(n1475,refuted), node(n9,refuted).
node(n1474,supported) :- node(n1475,supported).
node(n1474,supported) :- node(n9,supported).
node(n1474,unknown) :- \+ node(n1474,supported), \+ node(n1474,refuted).
verdict(c_7136dfe318bf29b8,supported) :- node(n1474,supported).
query(verdict(c_7136dfe318bf29b8,supported)).
verdict(c_7136dfe318bf29b8,refuted) :- node(n1474,refuted).
query(verdict(c_7136dfe318bf29b8,refuted)).
verdict(c_7136dfe318bf29b8,unknown) :- node(n1474,unknown).
query(verdict(c_7136dfe318bf29b8,unknown)).
node(n1479,supported) :- status(o_12040c1eda66a2928b74,supported).
node(n1479,refuted) :- status(o_12040c1eda66a2928b74,refuted).
node(n1479,unknown) :- status(o_12040c1eda66a2928b74,unknown).
node(n1480,supported) :- status(o_f152bef1705394970e0d,supported).
node(n1480,refuted) :- status(o_f152bef1705394970e0d,refuted).
node(n1480,unknown) :- status(o_f152bef1705394970e0d,unknown).
node(n1481,supported) :- status(o_ee96f668af800e35740e,supported).
node(n1481,refuted) :- status(o_ee96f668af800e35740e,refuted).
node(n1481,unknown) :- status(o_ee96f668af800e35740e,unknown).
node(n1478,supported) :- node(n1479,supported), node(n1480,supported), node(n1481,supported).
node(n1478,refuted) :- node(n1479,refuted).
node(n1478,refuted) :- node(n1480,refuted).
node(n1478,refuted) :- node(n1481,refuted).
node(n1478,unknown) :- \+ node(n1478,supported), \+ node(n1478,refuted).
node(n1477,refuted) :- node(n1478,refuted), node(n9,refuted).
node(n1477,supported) :- node(n1478,supported).
node(n1477,supported) :- node(n9,supported).
node(n1477,unknown) :- \+ node(n1477,supported), \+ node(n1477,refuted).
verdict(c_e5ee7a83ef32647c,supported) :- node(n1477,supported).
query(verdict(c_e5ee7a83ef32647c,supported)).
verdict(c_e5ee7a83ef32647c,refuted) :- node(n1477,refuted).
query(verdict(c_e5ee7a83ef32647c,refuted)).
verdict(c_e5ee7a83ef32647c,unknown) :- node(n1477,unknown).
query(verdict(c_e5ee7a83ef32647c,unknown)).
node(n1484,supported) :- status(o_6b16873a1dc74e54c5dd,supported).
node(n1484,refuted) :- status(o_6b16873a1dc74e54c5dd,refuted).
node(n1484,unknown) :- status(o_6b16873a1dc74e54c5dd,unknown).
node(n1483,supported) :- node(n1479,supported), node(n1480,supported), node(n1484,supported), node(n1481,supported).
node(n1483,refuted) :- node(n1479,refuted).
node(n1483,refuted) :- node(n1480,refuted).
node(n1483,refuted) :- node(n1484,refuted).
node(n1483,refuted) :- node(n1481,refuted).
node(n1483,unknown) :- \+ node(n1483,supported), \+ node(n1483,refuted).
node(n1482,refuted) :- node(n1483,refuted), node(n9,refuted).
node(n1482,supported) :- node(n1483,supported).
node(n1482,supported) :- node(n9,supported).
node(n1482,unknown) :- \+ node(n1482,supported), \+ node(n1482,refuted).
verdict(c_f124799dc0d8ca08,supported) :- node(n1482,supported).
query(verdict(c_f124799dc0d8ca08,supported)).
verdict(c_f124799dc0d8ca08,refuted) :- node(n1482,refuted).
query(verdict(c_f124799dc0d8ca08,refuted)).
verdict(c_f124799dc0d8ca08,unknown) :- node(n1482,unknown).
query(verdict(c_f124799dc0d8ca08,unknown)).
node(n1487,supported) :- status(o_0f9dd195f20580cedc72,supported).
node(n1487,refuted) :- status(o_0f9dd195f20580cedc72,refuted).
node(n1487,unknown) :- status(o_0f9dd195f20580cedc72,unknown).
node(n1488,supported) :- status(o_414bd271e9205058cbf8,supported).
node(n1488,refuted) :- status(o_414bd271e9205058cbf8,refuted).
node(n1488,unknown) :- status(o_414bd271e9205058cbf8,unknown).
node(n1489,supported) :- status(o_c661faf7a37e2a505db1,supported).
node(n1489,refuted) :- status(o_c661faf7a37e2a505db1,refuted).
node(n1489,unknown) :- status(o_c661faf7a37e2a505db1,unknown).
node(n1486,supported) :- node(n1487,supported), node(n1488,supported), node(n1489,supported).
node(n1486,refuted) :- node(n1487,refuted).
node(n1486,refuted) :- node(n1488,refuted).
node(n1486,refuted) :- node(n1489,refuted).
node(n1486,unknown) :- \+ node(n1486,supported), \+ node(n1486,refuted).
node(n1485,refuted) :- node(n1486,refuted), node(n9,refuted).
node(n1485,supported) :- node(n1486,supported).
node(n1485,supported) :- node(n9,supported).
node(n1485,unknown) :- \+ node(n1485,supported), \+ node(n1485,refuted).
verdict(c_7ceb89a4cc25dfe1,supported) :- node(n1485,supported).
query(verdict(c_7ceb89a4cc25dfe1,supported)).
verdict(c_7ceb89a4cc25dfe1,refuted) :- node(n1485,refuted).
query(verdict(c_7ceb89a4cc25dfe1,refuted)).
verdict(c_7ceb89a4cc25dfe1,unknown) :- node(n1485,unknown).
query(verdict(c_7ceb89a4cc25dfe1,unknown)).
node(n1492,supported) :- status(o_6187e5789daf90932631,supported).
node(n1492,refuted) :- status(o_6187e5789daf90932631,refuted).
node(n1492,unknown) :- status(o_6187e5789daf90932631,unknown).
node(n1491,supported) :- node(n1487,supported), node(n1488,supported), node(n1492,supported), node(n1489,supported).
node(n1491,refuted) :- node(n1487,refuted).
node(n1491,refuted) :- node(n1488,refuted).
node(n1491,refuted) :- node(n1492,refuted).
node(n1491,refuted) :- node(n1489,refuted).
node(n1491,unknown) :- \+ node(n1491,supported), \+ node(n1491,refuted).
node(n1490,refuted) :- node(n1491,refuted), node(n9,refuted).
node(n1490,supported) :- node(n1491,supported).
node(n1490,supported) :- node(n9,supported).
node(n1490,unknown) :- \+ node(n1490,supported), \+ node(n1490,refuted).
verdict(c_30a6c46b9a2d6ee2,supported) :- node(n1490,supported).
query(verdict(c_30a6c46b9a2d6ee2,supported)).
verdict(c_30a6c46b9a2d6ee2,refuted) :- node(n1490,refuted).
query(verdict(c_30a6c46b9a2d6ee2,refuted)).
verdict(c_30a6c46b9a2d6ee2,unknown) :- node(n1490,unknown).
query(verdict(c_30a6c46b9a2d6ee2,unknown)).
node(n1495,supported) :- status(o_1cdfcf4bd6b2a11ae04d,supported).
node(n1495,refuted) :- status(o_1cdfcf4bd6b2a11ae04d,refuted).
node(n1495,unknown) :- status(o_1cdfcf4bd6b2a11ae04d,unknown).
node(n1496,supported) :- status(o_5fecb3b1ecec92f01d33,supported).
node(n1496,refuted) :- status(o_5fecb3b1ecec92f01d33,refuted).
node(n1496,unknown) :- status(o_5fecb3b1ecec92f01d33,unknown).
node(n1497,supported) :- status(o_93a517dea00ddf3bb51f,supported).
node(n1497,refuted) :- status(o_93a517dea00ddf3bb51f,refuted).
node(n1497,unknown) :- status(o_93a517dea00ddf3bb51f,unknown).
node(n1494,supported) :- node(n1495,supported), node(n1496,supported), node(n1497,supported).
node(n1494,refuted) :- node(n1495,refuted).
node(n1494,refuted) :- node(n1496,refuted).
node(n1494,refuted) :- node(n1497,refuted).
node(n1494,unknown) :- \+ node(n1494,supported), \+ node(n1494,refuted).
node(n1493,refuted) :- node(n1494,refuted), node(n9,refuted).
node(n1493,supported) :- node(n1494,supported).
node(n1493,supported) :- node(n9,supported).
node(n1493,unknown) :- \+ node(n1493,supported), \+ node(n1493,refuted).
verdict(c_e6b44b67e4a74aaa,supported) :- node(n1493,supported).
query(verdict(c_e6b44b67e4a74aaa,supported)).
verdict(c_e6b44b67e4a74aaa,refuted) :- node(n1493,refuted).
query(verdict(c_e6b44b67e4a74aaa,refuted)).
verdict(c_e6b44b67e4a74aaa,unknown) :- node(n1493,unknown).
query(verdict(c_e6b44b67e4a74aaa,unknown)).
node(n1500,supported) :- status(o_c8ca54c1023c47b9da78,supported).
node(n1500,refuted) :- status(o_c8ca54c1023c47b9da78,refuted).
node(n1500,unknown) :- status(o_c8ca54c1023c47b9da78,unknown).
node(n1499,supported) :- node(n1495,supported), node(n1496,supported), node(n1500,supported), node(n1497,supported).
node(n1499,refuted) :- node(n1495,refuted).
node(n1499,refuted) :- node(n1496,refuted).
node(n1499,refuted) :- node(n1500,refuted).
node(n1499,refuted) :- node(n1497,refuted).
node(n1499,unknown) :- \+ node(n1499,supported), \+ node(n1499,refuted).
node(n1498,refuted) :- node(n1499,refuted), node(n9,refuted).
node(n1498,supported) :- node(n1499,supported).
node(n1498,supported) :- node(n9,supported).
node(n1498,unknown) :- \+ node(n1498,supported), \+ node(n1498,refuted).
verdict(c_f0da04f19a165c5f,supported) :- node(n1498,supported).
query(verdict(c_f0da04f19a165c5f,supported)).
verdict(c_f0da04f19a165c5f,refuted) :- node(n1498,refuted).
query(verdict(c_f0da04f19a165c5f,refuted)).
verdict(c_f0da04f19a165c5f,unknown) :- node(n1498,unknown).
query(verdict(c_f0da04f19a165c5f,unknown)).
node(n1503,supported) :- status(o_5541a92daebb236774b9,supported).
node(n1503,refuted) :- status(o_5541a92daebb236774b9,refuted).
node(n1503,unknown) :- status(o_5541a92daebb236774b9,unknown).
node(n1504,supported) :- status(o_c0b9f9cc36c1a4fdf237,supported).
node(n1504,refuted) :- status(o_c0b9f9cc36c1a4fdf237,refuted).
node(n1504,unknown) :- status(o_c0b9f9cc36c1a4fdf237,unknown).
node(n1505,supported) :- status(o_890a32d7b2641f32c5ec,supported).
node(n1505,refuted) :- status(o_890a32d7b2641f32c5ec,refuted).
node(n1505,unknown) :- status(o_890a32d7b2641f32c5ec,unknown).
node(n1502,supported) :- node(n1503,supported), node(n1504,supported), node(n1505,supported).
node(n1502,refuted) :- node(n1503,refuted).
node(n1502,refuted) :- node(n1504,refuted).
node(n1502,refuted) :- node(n1505,refuted).
node(n1502,unknown) :- \+ node(n1502,supported), \+ node(n1502,refuted).
node(n1501,refuted) :- node(n1502,refuted), node(n9,refuted).
node(n1501,supported) :- node(n1502,supported).
node(n1501,supported) :- node(n9,supported).
node(n1501,unknown) :- \+ node(n1501,supported), \+ node(n1501,refuted).
verdict(c_dd05ef539df7c385,supported) :- node(n1501,supported).
query(verdict(c_dd05ef539df7c385,supported)).
verdict(c_dd05ef539df7c385,refuted) :- node(n1501,refuted).
query(verdict(c_dd05ef539df7c385,refuted)).
verdict(c_dd05ef539df7c385,unknown) :- node(n1501,unknown).
query(verdict(c_dd05ef539df7c385,unknown)).
node(n1508,supported) :- status(o_1e3a95c264ceff711b50,supported).
node(n1508,refuted) :- status(o_1e3a95c264ceff711b50,refuted).
node(n1508,unknown) :- status(o_1e3a95c264ceff711b50,unknown).
node(n1507,supported) :- node(n1503,supported), node(n1504,supported), node(n1508,supported), node(n1505,supported).
node(n1507,refuted) :- node(n1503,refuted).
node(n1507,refuted) :- node(n1504,refuted).
node(n1507,refuted) :- node(n1508,refuted).
node(n1507,refuted) :- node(n1505,refuted).
node(n1507,unknown) :- \+ node(n1507,supported), \+ node(n1507,refuted).
node(n1506,refuted) :- node(n1507,refuted), node(n9,refuted).
node(n1506,supported) :- node(n1507,supported).
node(n1506,supported) :- node(n9,supported).
node(n1506,unknown) :- \+ node(n1506,supported), \+ node(n1506,refuted).
verdict(c_a2116e213721d012,supported) :- node(n1506,supported).
query(verdict(c_a2116e213721d012,supported)).
verdict(c_a2116e213721d012,refuted) :- node(n1506,refuted).
query(verdict(c_a2116e213721d012,refuted)).
verdict(c_a2116e213721d012,unknown) :- node(n1506,unknown).
query(verdict(c_a2116e213721d012,unknown)).
node(n1511,supported) :- status(o_83d936f13cdca3e59e6c,supported).
node(n1511,refuted) :- status(o_83d936f13cdca3e59e6c,refuted).
node(n1511,unknown) :- status(o_83d936f13cdca3e59e6c,unknown).
node(n1512,supported) :- status(o_cdf694541ca7147e7b2c,supported).
node(n1512,refuted) :- status(o_cdf694541ca7147e7b2c,refuted).
node(n1512,unknown) :- status(o_cdf694541ca7147e7b2c,unknown).
node(n1513,supported) :- status(o_c6948330fa57b57a2ed8,supported).
node(n1513,refuted) :- status(o_c6948330fa57b57a2ed8,refuted).
node(n1513,unknown) :- status(o_c6948330fa57b57a2ed8,unknown).
node(n1510,supported) :- node(n1511,supported), node(n1512,supported), node(n1513,supported).
node(n1510,refuted) :- node(n1511,refuted).
node(n1510,refuted) :- node(n1512,refuted).
node(n1510,refuted) :- node(n1513,refuted).
node(n1510,unknown) :- \+ node(n1510,supported), \+ node(n1510,refuted).
node(n1509,refuted) :- node(n1510,refuted), node(n9,refuted).
node(n1509,supported) :- node(n1510,supported).
node(n1509,supported) :- node(n9,supported).
node(n1509,unknown) :- \+ node(n1509,supported), \+ node(n1509,refuted).
verdict(c_f5f81b936e31802f,supported) :- node(n1509,supported).
query(verdict(c_f5f81b936e31802f,supported)).
verdict(c_f5f81b936e31802f,refuted) :- node(n1509,refuted).
query(verdict(c_f5f81b936e31802f,refuted)).
verdict(c_f5f81b936e31802f,unknown) :- node(n1509,unknown).
query(verdict(c_f5f81b936e31802f,unknown)).
node(n1516,supported) :- status(o_21cbac8973411012256d,supported).
node(n1516,refuted) :- status(o_21cbac8973411012256d,refuted).
node(n1516,unknown) :- status(o_21cbac8973411012256d,unknown).
node(n1515,supported) :- node(n1511,supported), node(n1512,supported), node(n1516,supported), node(n1513,supported).
node(n1515,refuted) :- node(n1511,refuted).
node(n1515,refuted) :- node(n1512,refuted).
node(n1515,refuted) :- node(n1516,refuted).
node(n1515,refuted) :- node(n1513,refuted).
node(n1515,unknown) :- \+ node(n1515,supported), \+ node(n1515,refuted).
node(n1514,refuted) :- node(n1515,refuted), node(n9,refuted).
node(n1514,supported) :- node(n1515,supported).
node(n1514,supported) :- node(n9,supported).
node(n1514,unknown) :- \+ node(n1514,supported), \+ node(n1514,refuted).
verdict(c_50caea61055247ff,supported) :- node(n1514,supported).
query(verdict(c_50caea61055247ff,supported)).
verdict(c_50caea61055247ff,refuted) :- node(n1514,refuted).
query(verdict(c_50caea61055247ff,refuted)).
verdict(c_50caea61055247ff,unknown) :- node(n1514,unknown).
query(verdict(c_50caea61055247ff,unknown)).
node(n1519,supported) :- status(o_a664dd21ffd4c146c946,supported).
node(n1519,refuted) :- status(o_a664dd21ffd4c146c946,refuted).
node(n1519,unknown) :- status(o_a664dd21ffd4c146c946,unknown).
node(n1520,supported) :- status(o_0c793e3b0f72451b42ef,supported).
node(n1520,refuted) :- status(o_0c793e3b0f72451b42ef,refuted).
node(n1520,unknown) :- status(o_0c793e3b0f72451b42ef,unknown).
node(n1521,supported) :- status(o_679d0a6bc23073b0925d,supported).
node(n1521,refuted) :- status(o_679d0a6bc23073b0925d,refuted).
node(n1521,unknown) :- status(o_679d0a6bc23073b0925d,unknown).
node(n1518,supported) :- node(n1519,supported), node(n1520,supported), node(n1521,supported).
node(n1518,refuted) :- node(n1519,refuted).
node(n1518,refuted) :- node(n1520,refuted).
node(n1518,refuted) :- node(n1521,refuted).
node(n1518,unknown) :- \+ node(n1518,supported), \+ node(n1518,refuted).
node(n1517,refuted) :- node(n1518,refuted), node(n9,refuted).
node(n1517,supported) :- node(n1518,supported).
node(n1517,supported) :- node(n9,supported).
node(n1517,unknown) :- \+ node(n1517,supported), \+ node(n1517,refuted).
verdict(c_0f53eb5a80b488ec,supported) :- node(n1517,supported).
query(verdict(c_0f53eb5a80b488ec,supported)).
verdict(c_0f53eb5a80b488ec,refuted) :- node(n1517,refuted).
query(verdict(c_0f53eb5a80b488ec,refuted)).
verdict(c_0f53eb5a80b488ec,unknown) :- node(n1517,unknown).
query(verdict(c_0f53eb5a80b488ec,unknown)).
node(n1524,supported) :- status(o_3fe166d91c3df56103db,supported).
node(n1524,refuted) :- status(o_3fe166d91c3df56103db,refuted).
node(n1524,unknown) :- status(o_3fe166d91c3df56103db,unknown).
node(n1523,supported) :- node(n1519,supported), node(n1520,supported), node(n1524,supported), node(n1521,supported).
node(n1523,refuted) :- node(n1519,refuted).
node(n1523,refuted) :- node(n1520,refuted).
node(n1523,refuted) :- node(n1524,refuted).
node(n1523,refuted) :- node(n1521,refuted).
node(n1523,unknown) :- \+ node(n1523,supported), \+ node(n1523,refuted).
node(n1522,refuted) :- node(n1523,refuted), node(n9,refuted).
node(n1522,supported) :- node(n1523,supported).
node(n1522,supported) :- node(n9,supported).
node(n1522,unknown) :- \+ node(n1522,supported), \+ node(n1522,refuted).
verdict(c_2fb4c9616d19f45c,supported) :- node(n1522,supported).
query(verdict(c_2fb4c9616d19f45c,supported)).
verdict(c_2fb4c9616d19f45c,refuted) :- node(n1522,refuted).
query(verdict(c_2fb4c9616d19f45c,refuted)).
verdict(c_2fb4c9616d19f45c,unknown) :- node(n1522,unknown).
query(verdict(c_2fb4c9616d19f45c,unknown)).
node(n1527,supported) :- status(o_a9c3d4b5a6a78fc0c800,supported).
node(n1527,refuted) :- status(o_a9c3d4b5a6a78fc0c800,refuted).
node(n1527,unknown) :- status(o_a9c3d4b5a6a78fc0c800,unknown).
node(n1528,supported) :- status(o_fb8f4bb93e7d143d0497,supported).
node(n1528,refuted) :- status(o_fb8f4bb93e7d143d0497,refuted).
node(n1528,unknown) :- status(o_fb8f4bb93e7d143d0497,unknown).
node(n1529,supported) :- status(o_96069de593c1d7fdae19,supported).
node(n1529,refuted) :- status(o_96069de593c1d7fdae19,refuted).
node(n1529,unknown) :- status(o_96069de593c1d7fdae19,unknown).
node(n1526,supported) :- node(n1527,supported), node(n1528,supported), node(n1529,supported).
node(n1526,refuted) :- node(n1527,refuted).
node(n1526,refuted) :- node(n1528,refuted).
node(n1526,refuted) :- node(n1529,refuted).
node(n1526,unknown) :- \+ node(n1526,supported), \+ node(n1526,refuted).
node(n1525,refuted) :- node(n1526,refuted), node(n9,refuted).
node(n1525,supported) :- node(n1526,supported).
node(n1525,supported) :- node(n9,supported).
node(n1525,unknown) :- \+ node(n1525,supported), \+ node(n1525,refuted).
verdict(c_bc0ba4410e4c9ed9,supported) :- node(n1525,supported).
query(verdict(c_bc0ba4410e4c9ed9,supported)).
verdict(c_bc0ba4410e4c9ed9,refuted) :- node(n1525,refuted).
query(verdict(c_bc0ba4410e4c9ed9,refuted)).
verdict(c_bc0ba4410e4c9ed9,unknown) :- node(n1525,unknown).
query(verdict(c_bc0ba4410e4c9ed9,unknown)).
node(n1532,supported) :- status(o_831e848ea1787e7f0d40,supported).
node(n1532,refuted) :- status(o_831e848ea1787e7f0d40,refuted).
node(n1532,unknown) :- status(o_831e848ea1787e7f0d40,unknown).
node(n1531,supported) :- node(n1527,supported), node(n1528,supported), node(n1532,supported), node(n1529,supported).
node(n1531,refuted) :- node(n1527,refuted).
node(n1531,refuted) :- node(n1528,refuted).
node(n1531,refuted) :- node(n1532,refuted).
node(n1531,refuted) :- node(n1529,refuted).
node(n1531,unknown) :- \+ node(n1531,supported), \+ node(n1531,refuted).
node(n1530,refuted) :- node(n1531,refuted), node(n9,refuted).
node(n1530,supported) :- node(n1531,supported).
node(n1530,supported) :- node(n9,supported).
node(n1530,unknown) :- \+ node(n1530,supported), \+ node(n1530,refuted).
verdict(c_0879bdde8deb6b4b,supported) :- node(n1530,supported).
query(verdict(c_0879bdde8deb6b4b,supported)).
verdict(c_0879bdde8deb6b4b,refuted) :- node(n1530,refuted).
query(verdict(c_0879bdde8deb6b4b,refuted)).
verdict(c_0879bdde8deb6b4b,unknown) :- node(n1530,unknown).
query(verdict(c_0879bdde8deb6b4b,unknown)).
node(n1535,supported) :- status(o_0de6d9f1e5f55090b2c0,supported).
node(n1535,refuted) :- status(o_0de6d9f1e5f55090b2c0,refuted).
node(n1535,unknown) :- status(o_0de6d9f1e5f55090b2c0,unknown).
node(n1536,supported) :- status(o_6964896e981a9ecc7347,supported).
node(n1536,refuted) :- status(o_6964896e981a9ecc7347,refuted).
node(n1536,unknown) :- status(o_6964896e981a9ecc7347,unknown).
node(n1537,supported) :- status(o_4143c39b6b2c1555f7bf,supported).
node(n1537,refuted) :- status(o_4143c39b6b2c1555f7bf,refuted).
node(n1537,unknown) :- status(o_4143c39b6b2c1555f7bf,unknown).
node(n1534,supported) :- node(n1535,supported), node(n1536,supported), node(n1537,supported).
node(n1534,refuted) :- node(n1535,refuted).
node(n1534,refuted) :- node(n1536,refuted).
node(n1534,refuted) :- node(n1537,refuted).
node(n1534,unknown) :- \+ node(n1534,supported), \+ node(n1534,refuted).
node(n1533,refuted) :- node(n1534,refuted), node(n9,refuted).
node(n1533,supported) :- node(n1534,supported).
node(n1533,supported) :- node(n9,supported).
node(n1533,unknown) :- \+ node(n1533,supported), \+ node(n1533,refuted).
verdict(c_846b2290c3cdb70a,supported) :- node(n1533,supported).
query(verdict(c_846b2290c3cdb70a,supported)).
verdict(c_846b2290c3cdb70a,refuted) :- node(n1533,refuted).
query(verdict(c_846b2290c3cdb70a,refuted)).
verdict(c_846b2290c3cdb70a,unknown) :- node(n1533,unknown).
query(verdict(c_846b2290c3cdb70a,unknown)).
node(n1540,supported) :- status(o_78a0a99e73395c0c8674,supported).
node(n1540,refuted) :- status(o_78a0a99e73395c0c8674,refuted).
node(n1540,unknown) :- status(o_78a0a99e73395c0c8674,unknown).
node(n1539,supported) :- node(n1535,supported), node(n1536,supported), node(n1540,supported), node(n1537,supported).
node(n1539,refuted) :- node(n1535,refuted).
node(n1539,refuted) :- node(n1536,refuted).
node(n1539,refuted) :- node(n1540,refuted).
node(n1539,refuted) :- node(n1537,refuted).
node(n1539,unknown) :- \+ node(n1539,supported), \+ node(n1539,refuted).
node(n1538,refuted) :- node(n1539,refuted), node(n9,refuted).
node(n1538,supported) :- node(n1539,supported).
node(n1538,supported) :- node(n9,supported).
node(n1538,unknown) :- \+ node(n1538,supported), \+ node(n1538,refuted).
verdict(c_da1dc63662c82aaa,supported) :- node(n1538,supported).
query(verdict(c_da1dc63662c82aaa,supported)).
verdict(c_da1dc63662c82aaa,refuted) :- node(n1538,refuted).
query(verdict(c_da1dc63662c82aaa,refuted)).
verdict(c_da1dc63662c82aaa,unknown) :- node(n1538,unknown).
query(verdict(c_da1dc63662c82aaa,unknown)).
node(n1543,supported) :- status(o_01ff1e8d0f4aa7a71943,supported).
node(n1543,refuted) :- status(o_01ff1e8d0f4aa7a71943,refuted).
node(n1543,unknown) :- status(o_01ff1e8d0f4aa7a71943,unknown).
node(n1544,supported) :- status(o_91f192664ecf4a3fba34,supported).
node(n1544,refuted) :- status(o_91f192664ecf4a3fba34,refuted).
node(n1544,unknown) :- status(o_91f192664ecf4a3fba34,unknown).
node(n1545,supported) :- status(o_ab78405154f59670a15b,supported).
node(n1545,refuted) :- status(o_ab78405154f59670a15b,refuted).
node(n1545,unknown) :- status(o_ab78405154f59670a15b,unknown).
node(n1542,supported) :- node(n1543,supported), node(n1544,supported), node(n1545,supported).
node(n1542,refuted) :- node(n1543,refuted).
node(n1542,refuted) :- node(n1544,refuted).
node(n1542,refuted) :- node(n1545,refuted).
node(n1542,unknown) :- \+ node(n1542,supported), \+ node(n1542,refuted).
node(n1541,refuted) :- node(n1542,refuted), node(n9,refuted).
node(n1541,supported) :- node(n1542,supported).
node(n1541,supported) :- node(n9,supported).
node(n1541,unknown) :- \+ node(n1541,supported), \+ node(n1541,refuted).
verdict(c_84bf3736f3a943b8,supported) :- node(n1541,supported).
query(verdict(c_84bf3736f3a943b8,supported)).
verdict(c_84bf3736f3a943b8,refuted) :- node(n1541,refuted).
query(verdict(c_84bf3736f3a943b8,refuted)).
verdict(c_84bf3736f3a943b8,unknown) :- node(n1541,unknown).
query(verdict(c_84bf3736f3a943b8,unknown)).
node(n1548,supported) :- status(o_4abdbe95c42e70b6cdbb,supported).
node(n1548,refuted) :- status(o_4abdbe95c42e70b6cdbb,refuted).
node(n1548,unknown) :- status(o_4abdbe95c42e70b6cdbb,unknown).
node(n1547,supported) :- node(n1543,supported), node(n1544,supported), node(n1548,supported), node(n1545,supported).
node(n1547,refuted) :- node(n1543,refuted).
node(n1547,refuted) :- node(n1544,refuted).
node(n1547,refuted) :- node(n1548,refuted).
node(n1547,refuted) :- node(n1545,refuted).
node(n1547,unknown) :- \+ node(n1547,supported), \+ node(n1547,refuted).
node(n1546,refuted) :- node(n1547,refuted), node(n9,refuted).
node(n1546,supported) :- node(n1547,supported).
node(n1546,supported) :- node(n9,supported).
node(n1546,unknown) :- \+ node(n1546,supported), \+ node(n1546,refuted).
verdict(c_c4c4133053defaf8,supported) :- node(n1546,supported).
query(verdict(c_c4c4133053defaf8,supported)).
verdict(c_c4c4133053defaf8,refuted) :- node(n1546,refuted).
query(verdict(c_c4c4133053defaf8,refuted)).
verdict(c_c4c4133053defaf8,unknown) :- node(n1546,unknown).
query(verdict(c_c4c4133053defaf8,unknown)).
node(n1551,supported) :- status(o_c7195516e858f0529c83,supported).
node(n1551,refuted) :- status(o_c7195516e858f0529c83,refuted).
node(n1551,unknown) :- status(o_c7195516e858f0529c83,unknown).
node(n1552,supported) :- status(o_68e499ae33b6472996f5,supported).
node(n1552,refuted) :- status(o_68e499ae33b6472996f5,refuted).
node(n1552,unknown) :- status(o_68e499ae33b6472996f5,unknown).
node(n1553,supported) :- status(o_d7061b54444afbbf957c,supported).
node(n1553,refuted) :- status(o_d7061b54444afbbf957c,refuted).
node(n1553,unknown) :- status(o_d7061b54444afbbf957c,unknown).
node(n1550,supported) :- node(n1551,supported), node(n1552,supported), node(n1553,supported).
node(n1550,refuted) :- node(n1551,refuted).
node(n1550,refuted) :- node(n1552,refuted).
node(n1550,refuted) :- node(n1553,refuted).
node(n1550,unknown) :- \+ node(n1550,supported), \+ node(n1550,refuted).
node(n1549,refuted) :- node(n1550,refuted), node(n9,refuted).
node(n1549,supported) :- node(n1550,supported).
node(n1549,supported) :- node(n9,supported).
node(n1549,unknown) :- \+ node(n1549,supported), \+ node(n1549,refuted).
verdict(c_9d69e905cb3eba56,supported) :- node(n1549,supported).
query(verdict(c_9d69e905cb3eba56,supported)).
verdict(c_9d69e905cb3eba56,refuted) :- node(n1549,refuted).
query(verdict(c_9d69e905cb3eba56,refuted)).
verdict(c_9d69e905cb3eba56,unknown) :- node(n1549,unknown).
query(verdict(c_9d69e905cb3eba56,unknown)).
node(n1556,supported) :- status(o_29d60681a30a1a2eef60,supported).
node(n1556,refuted) :- status(o_29d60681a30a1a2eef60,refuted).
node(n1556,unknown) :- status(o_29d60681a30a1a2eef60,unknown).
node(n1555,supported) :- node(n1551,supported), node(n1552,supported), node(n1556,supported), node(n1553,supported).
node(n1555,refuted) :- node(n1551,refuted).
node(n1555,refuted) :- node(n1552,refuted).
node(n1555,refuted) :- node(n1556,refuted).
node(n1555,refuted) :- node(n1553,refuted).
node(n1555,unknown) :- \+ node(n1555,supported), \+ node(n1555,refuted).
node(n1554,refuted) :- node(n1555,refuted), node(n9,refuted).
node(n1554,supported) :- node(n1555,supported).
node(n1554,supported) :- node(n9,supported).
node(n1554,unknown) :- \+ node(n1554,supported), \+ node(n1554,refuted).
verdict(c_027c3402a6943df1,supported) :- node(n1554,supported).
query(verdict(c_027c3402a6943df1,supported)).
verdict(c_027c3402a6943df1,refuted) :- node(n1554,refuted).
query(verdict(c_027c3402a6943df1,refuted)).
verdict(c_027c3402a6943df1,unknown) :- node(n1554,unknown).
query(verdict(c_027c3402a6943df1,unknown)).
node(n1559,supported) :- status(o_ad270d0bba0f02906684,supported).
node(n1559,refuted) :- status(o_ad270d0bba0f02906684,refuted).
node(n1559,unknown) :- status(o_ad270d0bba0f02906684,unknown).
node(n1560,supported) :- status(o_ecfedabe6ce1e9e563bf,supported).
node(n1560,refuted) :- status(o_ecfedabe6ce1e9e563bf,refuted).
node(n1560,unknown) :- status(o_ecfedabe6ce1e9e563bf,unknown).
node(n1561,supported) :- status(o_000730c96e06a0d8eb8f,supported).
node(n1561,refuted) :- status(o_000730c96e06a0d8eb8f,refuted).
node(n1561,unknown) :- status(o_000730c96e06a0d8eb8f,unknown).
node(n1558,supported) :- node(n1559,supported), node(n1560,supported), node(n1561,supported).
node(n1558,refuted) :- node(n1559,refuted).
node(n1558,refuted) :- node(n1560,refuted).
node(n1558,refuted) :- node(n1561,refuted).
node(n1558,unknown) :- \+ node(n1558,supported), \+ node(n1558,refuted).
node(n1557,refuted) :- node(n1558,refuted), node(n9,refuted).
node(n1557,supported) :- node(n1558,supported).
node(n1557,supported) :- node(n9,supported).
node(n1557,unknown) :- \+ node(n1557,supported), \+ node(n1557,refuted).
verdict(c_5f7165ae55e5a87b,supported) :- node(n1557,supported).
query(verdict(c_5f7165ae55e5a87b,supported)).
verdict(c_5f7165ae55e5a87b,refuted) :- node(n1557,refuted).
query(verdict(c_5f7165ae55e5a87b,refuted)).
verdict(c_5f7165ae55e5a87b,unknown) :- node(n1557,unknown).
query(verdict(c_5f7165ae55e5a87b,unknown)).
node(n1564,supported) :- status(o_7f434f93751d75eba66f,supported).
node(n1564,refuted) :- status(o_7f434f93751d75eba66f,refuted).
node(n1564,unknown) :- status(o_7f434f93751d75eba66f,unknown).
node(n1563,supported) :- node(n1559,supported), node(n1560,supported), node(n1564,supported), node(n1561,supported).
node(n1563,refuted) :- node(n1559,refuted).
node(n1563,refuted) :- node(n1560,refuted).
node(n1563,refuted) :- node(n1564,refuted).
node(n1563,refuted) :- node(n1561,refuted).
node(n1563,unknown) :- \+ node(n1563,supported), \+ node(n1563,refuted).
node(n1562,refuted) :- node(n1563,refuted), node(n9,refuted).
node(n1562,supported) :- node(n1563,supported).
node(n1562,supported) :- node(n9,supported).
node(n1562,unknown) :- \+ node(n1562,supported), \+ node(n1562,refuted).
verdict(c_371b5e9ca8b10be8,supported) :- node(n1562,supported).
query(verdict(c_371b5e9ca8b10be8,supported)).
verdict(c_371b5e9ca8b10be8,refuted) :- node(n1562,refuted).
query(verdict(c_371b5e9ca8b10be8,refuted)).
verdict(c_371b5e9ca8b10be8,unknown) :- node(n1562,unknown).
query(verdict(c_371b5e9ca8b10be8,unknown)).
node(n1567,supported) :- status(o_70bcbaec205a0d0cc30a,supported).
node(n1567,refuted) :- status(o_70bcbaec205a0d0cc30a,refuted).
node(n1567,unknown) :- status(o_70bcbaec205a0d0cc30a,unknown).
node(n1568,supported) :- status(o_ffb3956df782ee078548,supported).
node(n1568,refuted) :- status(o_ffb3956df782ee078548,refuted).
node(n1568,unknown) :- status(o_ffb3956df782ee078548,unknown).
node(n1569,supported) :- status(o_c8870fd758d22405687e,supported).
node(n1569,refuted) :- status(o_c8870fd758d22405687e,refuted).
node(n1569,unknown) :- status(o_c8870fd758d22405687e,unknown).
node(n1566,supported) :- node(n1567,supported), node(n1568,supported), node(n1569,supported).
node(n1566,refuted) :- node(n1567,refuted).
node(n1566,refuted) :- node(n1568,refuted).
node(n1566,refuted) :- node(n1569,refuted).
node(n1566,unknown) :- \+ node(n1566,supported), \+ node(n1566,refuted).
node(n1565,refuted) :- node(n1566,refuted), node(n9,refuted).
node(n1565,supported) :- node(n1566,supported).
node(n1565,supported) :- node(n9,supported).
node(n1565,unknown) :- \+ node(n1565,supported), \+ node(n1565,refuted).
verdict(c_eba8acdf7cdf71ed,supported) :- node(n1565,supported).
query(verdict(c_eba8acdf7cdf71ed,supported)).
verdict(c_eba8acdf7cdf71ed,refuted) :- node(n1565,refuted).
query(verdict(c_eba8acdf7cdf71ed,refuted)).
verdict(c_eba8acdf7cdf71ed,unknown) :- node(n1565,unknown).
query(verdict(c_eba8acdf7cdf71ed,unknown)).
node(n1572,supported) :- status(o_0eab514c6a8e357e7162,supported).
node(n1572,refuted) :- status(o_0eab514c6a8e357e7162,refuted).
node(n1572,unknown) :- status(o_0eab514c6a8e357e7162,unknown).
node(n1571,supported) :- node(n1567,supported), node(n1568,supported), node(n1572,supported), node(n1569,supported).
node(n1571,refuted) :- node(n1567,refuted).
node(n1571,refuted) :- node(n1568,refuted).
node(n1571,refuted) :- node(n1572,refuted).
node(n1571,refuted) :- node(n1569,refuted).
node(n1571,unknown) :- \+ node(n1571,supported), \+ node(n1571,refuted).
node(n1570,refuted) :- node(n1571,refuted), node(n9,refuted).
node(n1570,supported) :- node(n1571,supported).
node(n1570,supported) :- node(n9,supported).
node(n1570,unknown) :- \+ node(n1570,supported), \+ node(n1570,refuted).
verdict(c_0f8f6f42427de952,supported) :- node(n1570,supported).
query(verdict(c_0f8f6f42427de952,supported)).
verdict(c_0f8f6f42427de952,refuted) :- node(n1570,refuted).
query(verdict(c_0f8f6f42427de952,refuted)).
verdict(c_0f8f6f42427de952,unknown) :- node(n1570,unknown).
query(verdict(c_0f8f6f42427de952,unknown)).
node(n1575,supported) :- status(o_b889a587d55becc59e30,supported).
node(n1575,refuted) :- status(o_b889a587d55becc59e30,refuted).
node(n1575,unknown) :- status(o_b889a587d55becc59e30,unknown).
node(n1576,supported) :- status(o_66bd7d087c86af0550dd,supported).
node(n1576,refuted) :- status(o_66bd7d087c86af0550dd,refuted).
node(n1576,unknown) :- status(o_66bd7d087c86af0550dd,unknown).
node(n1577,supported) :- status(o_37d7ad41426bf255b761,supported).
node(n1577,refuted) :- status(o_37d7ad41426bf255b761,refuted).
node(n1577,unknown) :- status(o_37d7ad41426bf255b761,unknown).
node(n1574,supported) :- node(n1575,supported), node(n1576,supported), node(n1577,supported).
node(n1574,refuted) :- node(n1575,refuted).
node(n1574,refuted) :- node(n1576,refuted).
node(n1574,refuted) :- node(n1577,refuted).
node(n1574,unknown) :- \+ node(n1574,supported), \+ node(n1574,refuted).
node(n1579,supported) :- status(o_1074e465ebfb67ae40c2,supported).
node(n1579,refuted) :- status(o_1074e465ebfb67ae40c2,refuted).
node(n1579,unknown) :- status(o_1074e465ebfb67ae40c2,unknown).
node(n1580,supported) :- status(o_12a5d326e6f06090caa9,supported).
node(n1580,refuted) :- status(o_12a5d326e6f06090caa9,refuted).
node(n1580,unknown) :- status(o_12a5d326e6f06090caa9,unknown).
node(n1581,supported) :- status(o_7e470dd82029c2c3181b,supported).
node(n1581,refuted) :- status(o_7e470dd82029c2c3181b,refuted).
node(n1581,unknown) :- status(o_7e470dd82029c2c3181b,unknown).
node(n1578,supported) :- node(n1579,supported), node(n1580,supported), node(n1581,supported).
node(n1578,refuted) :- node(n1579,refuted).
node(n1578,refuted) :- node(n1580,refuted).
node(n1578,refuted) :- node(n1581,refuted).
node(n1578,unknown) :- \+ node(n1578,supported), \+ node(n1578,refuted).
node(n1573,refuted) :- node(n1574,refuted), node(n1578,refuted), node(n9,refuted).
node(n1573,supported) :- node(n1574,supported).
node(n1573,supported) :- node(n1578,supported).
node(n1573,supported) :- node(n9,supported).
node(n1573,unknown) :- \+ node(n1573,supported), \+ node(n1573,refuted).
verdict(c_f7ef5e702cb58caa,supported) :- node(n1573,supported).
query(verdict(c_f7ef5e702cb58caa,supported)).
verdict(c_f7ef5e702cb58caa,refuted) :- node(n1573,refuted).
query(verdict(c_f7ef5e702cb58caa,refuted)).
verdict(c_f7ef5e702cb58caa,unknown) :- node(n1573,unknown).
query(verdict(c_f7ef5e702cb58caa,unknown)).
node(n1584,supported) :- status(o_38aaedabf761c64ff28c,supported).
node(n1584,refuted) :- status(o_38aaedabf761c64ff28c,refuted).
node(n1584,unknown) :- status(o_38aaedabf761c64ff28c,unknown).
node(n1583,supported) :- node(n1575,supported), node(n1576,supported), node(n1584,supported), node(n1577,supported).
node(n1583,refuted) :- node(n1575,refuted).
node(n1583,refuted) :- node(n1576,refuted).
node(n1583,refuted) :- node(n1584,refuted).
node(n1583,refuted) :- node(n1577,refuted).
node(n1583,unknown) :- \+ node(n1583,supported), \+ node(n1583,refuted).
node(n1586,supported) :- status(o_8705912f65db6960a7da,supported).
node(n1586,refuted) :- status(o_8705912f65db6960a7da,refuted).
node(n1586,unknown) :- status(o_8705912f65db6960a7da,unknown).
node(n1585,supported) :- node(n1579,supported), node(n1580,supported), node(n1586,supported), node(n1581,supported).
node(n1585,refuted) :- node(n1579,refuted).
node(n1585,refuted) :- node(n1580,refuted).
node(n1585,refuted) :- node(n1586,refuted).
node(n1585,refuted) :- node(n1581,refuted).
node(n1585,unknown) :- \+ node(n1585,supported), \+ node(n1585,refuted).
node(n1582,refuted) :- node(n1583,refuted), node(n1585,refuted), node(n9,refuted).
node(n1582,supported) :- node(n1583,supported).
node(n1582,supported) :- node(n1585,supported).
node(n1582,supported) :- node(n9,supported).
node(n1582,unknown) :- \+ node(n1582,supported), \+ node(n1582,refuted).
verdict(c_b0f07ba738677687,supported) :- node(n1582,supported).
query(verdict(c_b0f07ba738677687,supported)).
verdict(c_b0f07ba738677687,refuted) :- node(n1582,refuted).
query(verdict(c_b0f07ba738677687,refuted)).
verdict(c_b0f07ba738677687,unknown) :- node(n1582,unknown).
query(verdict(c_b0f07ba738677687,unknown)).
node(n1589,supported) :- status(o_211a230140a143765b19,supported).
node(n1589,refuted) :- status(o_211a230140a143765b19,refuted).
node(n1589,unknown) :- status(o_211a230140a143765b19,unknown).
node(n1590,supported) :- status(o_4b339f8cc33e3c309bda,supported).
node(n1590,refuted) :- status(o_4b339f8cc33e3c309bda,refuted).
node(n1590,unknown) :- status(o_4b339f8cc33e3c309bda,unknown).
node(n1591,supported) :- status(o_e82bdad67e81fab8153b,supported).
node(n1591,refuted) :- status(o_e82bdad67e81fab8153b,refuted).
node(n1591,unknown) :- status(o_e82bdad67e81fab8153b,unknown).
node(n1588,supported) :- node(n1589,supported), node(n1590,supported), node(n1591,supported).
node(n1588,refuted) :- node(n1589,refuted).
node(n1588,refuted) :- node(n1590,refuted).
node(n1588,refuted) :- node(n1591,refuted).
node(n1588,unknown) :- \+ node(n1588,supported), \+ node(n1588,refuted).
node(n1593,supported) :- status(o_2d33407197aa16c0cc54,supported).
node(n1593,refuted) :- status(o_2d33407197aa16c0cc54,refuted).
node(n1593,unknown) :- status(o_2d33407197aa16c0cc54,unknown).
node(n1594,supported) :- status(o_8754a2eb6f1632d3894e,supported).
node(n1594,refuted) :- status(o_8754a2eb6f1632d3894e,refuted).
node(n1594,unknown) :- status(o_8754a2eb6f1632d3894e,unknown).
node(n1595,supported) :- status(o_5e71380d8ee2db992e9c,supported).
node(n1595,refuted) :- status(o_5e71380d8ee2db992e9c,refuted).
node(n1595,unknown) :- status(o_5e71380d8ee2db992e9c,unknown).
node(n1592,supported) :- node(n1593,supported), node(n1594,supported), node(n1595,supported).
node(n1592,refuted) :- node(n1593,refuted).
node(n1592,refuted) :- node(n1594,refuted).
node(n1592,refuted) :- node(n1595,refuted).
node(n1592,unknown) :- \+ node(n1592,supported), \+ node(n1592,refuted).
node(n1587,refuted) :- node(n1588,refuted), node(n1592,refuted), node(n9,refuted).
node(n1587,supported) :- node(n1588,supported).
node(n1587,supported) :- node(n1592,supported).
node(n1587,supported) :- node(n9,supported).
node(n1587,unknown) :- \+ node(n1587,supported), \+ node(n1587,refuted).
verdict(c_4f8a0c891003613d,supported) :- node(n1587,supported).
query(verdict(c_4f8a0c891003613d,supported)).
verdict(c_4f8a0c891003613d,refuted) :- node(n1587,refuted).
query(verdict(c_4f8a0c891003613d,refuted)).
verdict(c_4f8a0c891003613d,unknown) :- node(n1587,unknown).
query(verdict(c_4f8a0c891003613d,unknown)).
node(n1598,supported) :- status(o_8ee67e7ec9d1900cc0ab,supported).
node(n1598,refuted) :- status(o_8ee67e7ec9d1900cc0ab,refuted).
node(n1598,unknown) :- status(o_8ee67e7ec9d1900cc0ab,unknown).
node(n1597,supported) :- node(n1589,supported), node(n1590,supported), node(n1598,supported), node(n1591,supported).
node(n1597,refuted) :- node(n1589,refuted).
node(n1597,refuted) :- node(n1590,refuted).
node(n1597,refuted) :- node(n1598,refuted).
node(n1597,refuted) :- node(n1591,refuted).
node(n1597,unknown) :- \+ node(n1597,supported), \+ node(n1597,refuted).
node(n1600,supported) :- status(o_42712c9a896856e135a9,supported).
node(n1600,refuted) :- status(o_42712c9a896856e135a9,refuted).
node(n1600,unknown) :- status(o_42712c9a896856e135a9,unknown).
node(n1599,supported) :- node(n1593,supported), node(n1594,supported), node(n1600,supported), node(n1595,supported).
node(n1599,refuted) :- node(n1593,refuted).
node(n1599,refuted) :- node(n1594,refuted).
node(n1599,refuted) :- node(n1600,refuted).
node(n1599,refuted) :- node(n1595,refuted).
node(n1599,unknown) :- \+ node(n1599,supported), \+ node(n1599,refuted).
node(n1596,refuted) :- node(n1597,refuted), node(n1599,refuted), node(n9,refuted).
node(n1596,supported) :- node(n1597,supported).
node(n1596,supported) :- node(n1599,supported).
node(n1596,supported) :- node(n9,supported).
node(n1596,unknown) :- \+ node(n1596,supported), \+ node(n1596,refuted).
verdict(c_7c8264affb6c32bc,supported) :- node(n1596,supported).
query(verdict(c_7c8264affb6c32bc,supported)).
verdict(c_7c8264affb6c32bc,refuted) :- node(n1596,refuted).
query(verdict(c_7c8264affb6c32bc,refuted)).
verdict(c_7c8264affb6c32bc,unknown) :- node(n1596,unknown).
query(verdict(c_7c8264affb6c32bc,unknown)).
node(n1603,supported) :- status(o_12cda33193bc97021ac5,supported).
node(n1603,refuted) :- status(o_12cda33193bc97021ac5,refuted).
node(n1603,unknown) :- status(o_12cda33193bc97021ac5,unknown).
node(n1604,supported) :- status(o_35af888d6b2099f8d460,supported).
node(n1604,refuted) :- status(o_35af888d6b2099f8d460,refuted).
node(n1604,unknown) :- status(o_35af888d6b2099f8d460,unknown).
node(n1605,supported) :- status(o_ae956e35ebe3ab49ed4f,supported).
node(n1605,refuted) :- status(o_ae956e35ebe3ab49ed4f,refuted).
node(n1605,unknown) :- status(o_ae956e35ebe3ab49ed4f,unknown).
node(n1602,supported) :- node(n1603,supported), node(n1604,supported), node(n1605,supported).
node(n1602,refuted) :- node(n1603,refuted).
node(n1602,refuted) :- node(n1604,refuted).
node(n1602,refuted) :- node(n1605,refuted).
node(n1602,unknown) :- \+ node(n1602,supported), \+ node(n1602,refuted).
node(n1607,supported) :- status(o_8245c9557609075d1254,supported).
node(n1607,refuted) :- status(o_8245c9557609075d1254,refuted).
node(n1607,unknown) :- status(o_8245c9557609075d1254,unknown).
node(n1608,supported) :- status(o_8990b558b754924c8135,supported).
node(n1608,refuted) :- status(o_8990b558b754924c8135,refuted).
node(n1608,unknown) :- status(o_8990b558b754924c8135,unknown).
node(n1609,supported) :- status(o_b9e706ab190a594eb146,supported).
node(n1609,refuted) :- status(o_b9e706ab190a594eb146,refuted).
node(n1609,unknown) :- status(o_b9e706ab190a594eb146,unknown).
node(n1606,supported) :- node(n1607,supported), node(n1608,supported), node(n1609,supported).
node(n1606,refuted) :- node(n1607,refuted).
node(n1606,refuted) :- node(n1608,refuted).
node(n1606,refuted) :- node(n1609,refuted).
node(n1606,unknown) :- \+ node(n1606,supported), \+ node(n1606,refuted).
node(n1601,refuted) :- node(n1602,refuted), node(n1606,refuted), node(n9,refuted).
node(n1601,supported) :- node(n1602,supported).
node(n1601,supported) :- node(n1606,supported).
node(n1601,supported) :- node(n9,supported).
node(n1601,unknown) :- \+ node(n1601,supported), \+ node(n1601,refuted).
verdict(c_a21288c6a238beaf,supported) :- node(n1601,supported).
query(verdict(c_a21288c6a238beaf,supported)).
verdict(c_a21288c6a238beaf,refuted) :- node(n1601,refuted).
query(verdict(c_a21288c6a238beaf,refuted)).
verdict(c_a21288c6a238beaf,unknown) :- node(n1601,unknown).
query(verdict(c_a21288c6a238beaf,unknown)).
node(n1612,supported) :- status(o_bd84b91f8391005dc64f,supported).
node(n1612,refuted) :- status(o_bd84b91f8391005dc64f,refuted).
node(n1612,unknown) :- status(o_bd84b91f8391005dc64f,unknown).
node(n1611,supported) :- node(n1603,supported), node(n1604,supported), node(n1612,supported), node(n1605,supported).
node(n1611,refuted) :- node(n1603,refuted).
node(n1611,refuted) :- node(n1604,refuted).
node(n1611,refuted) :- node(n1612,refuted).
node(n1611,refuted) :- node(n1605,refuted).
node(n1611,unknown) :- \+ node(n1611,supported), \+ node(n1611,refuted).
node(n1614,supported) :- status(o_55ad6c431d2f2e4f4dba,supported).
node(n1614,refuted) :- status(o_55ad6c431d2f2e4f4dba,refuted).
node(n1614,unknown) :- status(o_55ad6c431d2f2e4f4dba,unknown).
node(n1613,supported) :- node(n1607,supported), node(n1608,supported), node(n1614,supported), node(n1609,supported).
node(n1613,refuted) :- node(n1607,refuted).
node(n1613,refuted) :- node(n1608,refuted).
node(n1613,refuted) :- node(n1614,refuted).
node(n1613,refuted) :- node(n1609,refuted).
node(n1613,unknown) :- \+ node(n1613,supported), \+ node(n1613,refuted).
node(n1610,refuted) :- node(n1611,refuted), node(n1613,refuted), node(n9,refuted).
node(n1610,supported) :- node(n1611,supported).
node(n1610,supported) :- node(n1613,supported).
node(n1610,supported) :- node(n9,supported).
node(n1610,unknown) :- \+ node(n1610,supported), \+ node(n1610,refuted).
verdict(c_50dbf7bf30d010ad,supported) :- node(n1610,supported).
query(verdict(c_50dbf7bf30d010ad,supported)).
verdict(c_50dbf7bf30d010ad,refuted) :- node(n1610,refuted).
query(verdict(c_50dbf7bf30d010ad,refuted)).
verdict(c_50dbf7bf30d010ad,unknown) :- node(n1610,unknown).
query(verdict(c_50dbf7bf30d010ad,unknown)).
node(n1617,supported) :- status(o_e8ea77c46182071a51fb,supported).
node(n1617,refuted) :- status(o_e8ea77c46182071a51fb,refuted).
node(n1617,unknown) :- status(o_e8ea77c46182071a51fb,unknown).
node(n1618,supported) :- status(o_85ecace8c89fbf09d844,supported).
node(n1618,refuted) :- status(o_85ecace8c89fbf09d844,refuted).
node(n1618,unknown) :- status(o_85ecace8c89fbf09d844,unknown).
node(n1619,supported) :- status(o_52976f59be312c9da9b3,supported).
node(n1619,refuted) :- status(o_52976f59be312c9da9b3,refuted).
node(n1619,unknown) :- status(o_52976f59be312c9da9b3,unknown).
node(n1616,supported) :- node(n1617,supported), node(n1618,supported), node(n1619,supported).
node(n1616,refuted) :- node(n1617,refuted).
node(n1616,refuted) :- node(n1618,refuted).
node(n1616,refuted) :- node(n1619,refuted).
node(n1616,unknown) :- \+ node(n1616,supported), \+ node(n1616,refuted).
node(n1621,supported) :- status(o_e16cad632c00b7ee3920,supported).
node(n1621,refuted) :- status(o_e16cad632c00b7ee3920,refuted).
node(n1621,unknown) :- status(o_e16cad632c00b7ee3920,unknown).
node(n1622,supported) :- status(o_522091bddd09e36906b0,supported).
node(n1622,refuted) :- status(o_522091bddd09e36906b0,refuted).
node(n1622,unknown) :- status(o_522091bddd09e36906b0,unknown).
node(n1623,supported) :- status(o_c9ab649646aaad534d09,supported).
node(n1623,refuted) :- status(o_c9ab649646aaad534d09,refuted).
node(n1623,unknown) :- status(o_c9ab649646aaad534d09,unknown).
node(n1620,supported) :- node(n1621,supported), node(n1622,supported), node(n1623,supported).
node(n1620,refuted) :- node(n1621,refuted).
node(n1620,refuted) :- node(n1622,refuted).
node(n1620,refuted) :- node(n1623,refuted).
node(n1620,unknown) :- \+ node(n1620,supported), \+ node(n1620,refuted).
node(n1615,refuted) :- node(n1616,refuted), node(n1620,refuted), node(n9,refuted).
node(n1615,supported) :- node(n1616,supported).
node(n1615,supported) :- node(n1620,supported).
node(n1615,supported) :- node(n9,supported).
node(n1615,unknown) :- \+ node(n1615,supported), \+ node(n1615,refuted).
verdict(c_988cbb51f6103599,supported) :- node(n1615,supported).
query(verdict(c_988cbb51f6103599,supported)).
verdict(c_988cbb51f6103599,refuted) :- node(n1615,refuted).
query(verdict(c_988cbb51f6103599,refuted)).
verdict(c_988cbb51f6103599,unknown) :- node(n1615,unknown).
query(verdict(c_988cbb51f6103599,unknown)).
node(n1626,supported) :- status(o_ddad557680f0c457eb29,supported).
node(n1626,refuted) :- status(o_ddad557680f0c457eb29,refuted).
node(n1626,unknown) :- status(o_ddad557680f0c457eb29,unknown).
node(n1625,supported) :- node(n1617,supported), node(n1618,supported), node(n1626,supported), node(n1619,supported).
node(n1625,refuted) :- node(n1617,refuted).
node(n1625,refuted) :- node(n1618,refuted).
node(n1625,refuted) :- node(n1626,refuted).
node(n1625,refuted) :- node(n1619,refuted).
node(n1625,unknown) :- \+ node(n1625,supported), \+ node(n1625,refuted).
node(n1628,supported) :- status(o_dd75eefdcba5cc3a1d6e,supported).
node(n1628,refuted) :- status(o_dd75eefdcba5cc3a1d6e,refuted).
node(n1628,unknown) :- status(o_dd75eefdcba5cc3a1d6e,unknown).
node(n1627,supported) :- node(n1621,supported), node(n1622,supported), node(n1628,supported), node(n1623,supported).
node(n1627,refuted) :- node(n1621,refuted).
node(n1627,refuted) :- node(n1622,refuted).
node(n1627,refuted) :- node(n1628,refuted).
node(n1627,refuted) :- node(n1623,refuted).
node(n1627,unknown) :- \+ node(n1627,supported), \+ node(n1627,refuted).
node(n1624,refuted) :- node(n1625,refuted), node(n1627,refuted), node(n9,refuted).
node(n1624,supported) :- node(n1625,supported).
node(n1624,supported) :- node(n1627,supported).
node(n1624,supported) :- node(n9,supported).
node(n1624,unknown) :- \+ node(n1624,supported), \+ node(n1624,refuted).
verdict(c_93b4a937e66a9308,supported) :- node(n1624,supported).
query(verdict(c_93b4a937e66a9308,supported)).
verdict(c_93b4a937e66a9308,refuted) :- node(n1624,refuted).
query(verdict(c_93b4a937e66a9308,refuted)).
verdict(c_93b4a937e66a9308,unknown) :- node(n1624,unknown).
query(verdict(c_93b4a937e66a9308,unknown)).
node(n1631,supported) :- status(o_116556a461efcae85586,supported).
node(n1631,refuted) :- status(o_116556a461efcae85586,refuted).
node(n1631,unknown) :- status(o_116556a461efcae85586,unknown).
node(n1632,supported) :- status(o_8879f1449daf661265ba,supported).
node(n1632,refuted) :- status(o_8879f1449daf661265ba,refuted).
node(n1632,unknown) :- status(o_8879f1449daf661265ba,unknown).
node(n1633,supported) :- status(o_70b9ee27084195915155,supported).
node(n1633,refuted) :- status(o_70b9ee27084195915155,refuted).
node(n1633,unknown) :- status(o_70b9ee27084195915155,unknown).
node(n1630,supported) :- node(n1631,supported), node(n1632,supported), node(n1633,supported).
node(n1630,refuted) :- node(n1631,refuted).
node(n1630,refuted) :- node(n1632,refuted).
node(n1630,refuted) :- node(n1633,refuted).
node(n1630,unknown) :- \+ node(n1630,supported), \+ node(n1630,refuted).
node(n1635,supported) :- status(o_3e5b5ebb25c63596c8b9,supported).
node(n1635,refuted) :- status(o_3e5b5ebb25c63596c8b9,refuted).
node(n1635,unknown) :- status(o_3e5b5ebb25c63596c8b9,unknown).
node(n1636,supported) :- status(o_186bead0f48e9193133f,supported).
node(n1636,refuted) :- status(o_186bead0f48e9193133f,refuted).
node(n1636,unknown) :- status(o_186bead0f48e9193133f,unknown).
node(n1637,supported) :- status(o_9b2ba101eedc382abc28,supported).
node(n1637,refuted) :- status(o_9b2ba101eedc382abc28,refuted).
node(n1637,unknown) :- status(o_9b2ba101eedc382abc28,unknown).
node(n1634,supported) :- node(n1635,supported), node(n1636,supported), node(n1637,supported).
node(n1634,refuted) :- node(n1635,refuted).
node(n1634,refuted) :- node(n1636,refuted).
node(n1634,refuted) :- node(n1637,refuted).
node(n1634,unknown) :- \+ node(n1634,supported), \+ node(n1634,refuted).
node(n1629,refuted) :- node(n1630,refuted), node(n1634,refuted), node(n9,refuted).
node(n1629,supported) :- node(n1630,supported).
node(n1629,supported) :- node(n1634,supported).
node(n1629,supported) :- node(n9,supported).
node(n1629,unknown) :- \+ node(n1629,supported), \+ node(n1629,refuted).
verdict(c_0a1a9cf8cea40737,supported) :- node(n1629,supported).
query(verdict(c_0a1a9cf8cea40737,supported)).
verdict(c_0a1a9cf8cea40737,refuted) :- node(n1629,refuted).
query(verdict(c_0a1a9cf8cea40737,refuted)).
verdict(c_0a1a9cf8cea40737,unknown) :- node(n1629,unknown).
query(verdict(c_0a1a9cf8cea40737,unknown)).
node(n1640,supported) :- status(o_6ba663ee66a3a824c2c2,supported).
node(n1640,refuted) :- status(o_6ba663ee66a3a824c2c2,refuted).
node(n1640,unknown) :- status(o_6ba663ee66a3a824c2c2,unknown).
node(n1639,supported) :- node(n1631,supported), node(n1632,supported), node(n1640,supported), node(n1633,supported).
node(n1639,refuted) :- node(n1631,refuted).
node(n1639,refuted) :- node(n1632,refuted).
node(n1639,refuted) :- node(n1640,refuted).
node(n1639,refuted) :- node(n1633,refuted).
node(n1639,unknown) :- \+ node(n1639,supported), \+ node(n1639,refuted).
node(n1642,supported) :- status(o_d26303da72c9399c63fd,supported).
node(n1642,refuted) :- status(o_d26303da72c9399c63fd,refuted).
node(n1642,unknown) :- status(o_d26303da72c9399c63fd,unknown).
node(n1641,supported) :- node(n1635,supported), node(n1636,supported), node(n1642,supported), node(n1637,supported).
node(n1641,refuted) :- node(n1635,refuted).
node(n1641,refuted) :- node(n1636,refuted).
node(n1641,refuted) :- node(n1642,refuted).
node(n1641,refuted) :- node(n1637,refuted).
node(n1641,unknown) :- \+ node(n1641,supported), \+ node(n1641,refuted).
node(n1638,refuted) :- node(n1639,refuted), node(n1641,refuted), node(n9,refuted).
node(n1638,supported) :- node(n1639,supported).
node(n1638,supported) :- node(n1641,supported).
node(n1638,supported) :- node(n9,supported).
node(n1638,unknown) :- \+ node(n1638,supported), \+ node(n1638,refuted).
verdict(c_6d78fe95a363bd56,supported) :- node(n1638,supported).
query(verdict(c_6d78fe95a363bd56,supported)).
verdict(c_6d78fe95a363bd56,refuted) :- node(n1638,refuted).
query(verdict(c_6d78fe95a363bd56,refuted)).
verdict(c_6d78fe95a363bd56,unknown) :- node(n1638,unknown).
query(verdict(c_6d78fe95a363bd56,unknown)).
node(n1645,supported) :- status(o_caced41357c98a580312,supported).
node(n1645,refuted) :- status(o_caced41357c98a580312,refuted).
node(n1645,unknown) :- status(o_caced41357c98a580312,unknown).
node(n1646,supported) :- status(o_c24e97ffc3157f12ff91,supported).
node(n1646,refuted) :- status(o_c24e97ffc3157f12ff91,refuted).
node(n1646,unknown) :- status(o_c24e97ffc3157f12ff91,unknown).
node(n1647,supported) :- status(o_6636bbb02daeb3468e6d,supported).
node(n1647,refuted) :- status(o_6636bbb02daeb3468e6d,refuted).
node(n1647,unknown) :- status(o_6636bbb02daeb3468e6d,unknown).
node(n1644,supported) :- node(n1645,supported), node(n1646,supported), node(n1647,supported).
node(n1644,refuted) :- node(n1645,refuted).
node(n1644,refuted) :- node(n1646,refuted).
node(n1644,refuted) :- node(n1647,refuted).
node(n1644,unknown) :- \+ node(n1644,supported), \+ node(n1644,refuted).
node(n1649,supported) :- status(o_108e8350667af0064d16,supported).
node(n1649,refuted) :- status(o_108e8350667af0064d16,refuted).
node(n1649,unknown) :- status(o_108e8350667af0064d16,unknown).
node(n1650,supported) :- status(o_23d0cd703da387a2c543,supported).
node(n1650,refuted) :- status(o_23d0cd703da387a2c543,refuted).
node(n1650,unknown) :- status(o_23d0cd703da387a2c543,unknown).
node(n1651,supported) :- status(o_7e65df3825f3ca00bb59,supported).
node(n1651,refuted) :- status(o_7e65df3825f3ca00bb59,refuted).
node(n1651,unknown) :- status(o_7e65df3825f3ca00bb59,unknown).
node(n1648,supported) :- node(n1649,supported), node(n1650,supported), node(n1651,supported).
node(n1648,refuted) :- node(n1649,refuted).
node(n1648,refuted) :- node(n1650,refuted).
node(n1648,refuted) :- node(n1651,refuted).
node(n1648,unknown) :- \+ node(n1648,supported), \+ node(n1648,refuted).
node(n1643,refuted) :- node(n1644,refuted), node(n1648,refuted), node(n9,refuted).
node(n1643,supported) :- node(n1644,supported).
node(n1643,supported) :- node(n1648,supported).
node(n1643,supported) :- node(n9,supported).
node(n1643,unknown) :- \+ node(n1643,supported), \+ node(n1643,refuted).
verdict(c_8117ba01f361cde3,supported) :- node(n1643,supported).
query(verdict(c_8117ba01f361cde3,supported)).
verdict(c_8117ba01f361cde3,refuted) :- node(n1643,refuted).
query(verdict(c_8117ba01f361cde3,refuted)).
verdict(c_8117ba01f361cde3,unknown) :- node(n1643,unknown).
query(verdict(c_8117ba01f361cde3,unknown)).
node(n1654,supported) :- status(o_f20500244c95629065aa,supported).
node(n1654,refuted) :- status(o_f20500244c95629065aa,refuted).
node(n1654,unknown) :- status(o_f20500244c95629065aa,unknown).
node(n1653,supported) :- node(n1645,supported), node(n1646,supported), node(n1654,supported), node(n1647,supported).
node(n1653,refuted) :- node(n1645,refuted).
node(n1653,refuted) :- node(n1646,refuted).
node(n1653,refuted) :- node(n1654,refuted).
node(n1653,refuted) :- node(n1647,refuted).
node(n1653,unknown) :- \+ node(n1653,supported), \+ node(n1653,refuted).
node(n1656,supported) :- status(o_4e32f1f77278f61b3b1d,supported).
node(n1656,refuted) :- status(o_4e32f1f77278f61b3b1d,refuted).
node(n1656,unknown) :- status(o_4e32f1f77278f61b3b1d,unknown).
node(n1655,supported) :- node(n1649,supported), node(n1650,supported), node(n1656,supported), node(n1651,supported).
node(n1655,refuted) :- node(n1649,refuted).
node(n1655,refuted) :- node(n1650,refuted).
node(n1655,refuted) :- node(n1656,refuted).
node(n1655,refuted) :- node(n1651,refuted).
node(n1655,unknown) :- \+ node(n1655,supported), \+ node(n1655,refuted).
node(n1652,refuted) :- node(n1653,refuted), node(n1655,refuted), node(n9,refuted).
node(n1652,supported) :- node(n1653,supported).
node(n1652,supported) :- node(n1655,supported).
node(n1652,supported) :- node(n9,supported).
node(n1652,unknown) :- \+ node(n1652,supported), \+ node(n1652,refuted).
verdict(c_94d384a6c7c98a99,supported) :- node(n1652,supported).
query(verdict(c_94d384a6c7c98a99,supported)).
verdict(c_94d384a6c7c98a99,refuted) :- node(n1652,refuted).
query(verdict(c_94d384a6c7c98a99,refuted)).
verdict(c_94d384a6c7c98a99,unknown) :- node(n1652,unknown).
query(verdict(c_94d384a6c7c98a99,unknown)).
node(n1659,supported) :- status(o_1b9a463f96b4838dc620,supported).
node(n1659,refuted) :- status(o_1b9a463f96b4838dc620,refuted).
node(n1659,unknown) :- status(o_1b9a463f96b4838dc620,unknown).
node(n1660,supported) :- status(o_7e140e58dcd1ffabe966,supported).
node(n1660,refuted) :- status(o_7e140e58dcd1ffabe966,refuted).
node(n1660,unknown) :- status(o_7e140e58dcd1ffabe966,unknown).
node(n1661,supported) :- status(o_96102c5d08ec4802912a,supported).
node(n1661,refuted) :- status(o_96102c5d08ec4802912a,refuted).
node(n1661,unknown) :- status(o_96102c5d08ec4802912a,unknown).
node(n1658,supported) :- node(n1659,supported), node(n1660,supported), node(n1661,supported).
node(n1658,refuted) :- node(n1659,refuted).
node(n1658,refuted) :- node(n1660,refuted).
node(n1658,refuted) :- node(n1661,refuted).
node(n1658,unknown) :- \+ node(n1658,supported), \+ node(n1658,refuted).
node(n1663,supported) :- status(o_e81c15ba688783c6c9c2,supported).
node(n1663,refuted) :- status(o_e81c15ba688783c6c9c2,refuted).
node(n1663,unknown) :- status(o_e81c15ba688783c6c9c2,unknown).
node(n1664,supported) :- status(o_95082c8251807b896d1e,supported).
node(n1664,refuted) :- status(o_95082c8251807b896d1e,refuted).
node(n1664,unknown) :- status(o_95082c8251807b896d1e,unknown).
node(n1665,supported) :- status(o_3a60c8d2435113b637e6,supported).
node(n1665,refuted) :- status(o_3a60c8d2435113b637e6,refuted).
node(n1665,unknown) :- status(o_3a60c8d2435113b637e6,unknown).
node(n1662,supported) :- node(n1663,supported), node(n1664,supported), node(n1665,supported).
node(n1662,refuted) :- node(n1663,refuted).
node(n1662,refuted) :- node(n1664,refuted).
node(n1662,refuted) :- node(n1665,refuted).
node(n1662,unknown) :- \+ node(n1662,supported), \+ node(n1662,refuted).
node(n1657,refuted) :- node(n1658,refuted), node(n1662,refuted), node(n9,refuted).
node(n1657,supported) :- node(n1658,supported).
node(n1657,supported) :- node(n1662,supported).
node(n1657,supported) :- node(n9,supported).
node(n1657,unknown) :- \+ node(n1657,supported), \+ node(n1657,refuted).
verdict(c_e6f359fb38183ea9,supported) :- node(n1657,supported).
query(verdict(c_e6f359fb38183ea9,supported)).
verdict(c_e6f359fb38183ea9,refuted) :- node(n1657,refuted).
query(verdict(c_e6f359fb38183ea9,refuted)).
verdict(c_e6f359fb38183ea9,unknown) :- node(n1657,unknown).
query(verdict(c_e6f359fb38183ea9,unknown)).
node(n1668,supported) :- status(o_e3e7b682d79edaf1d3aa,supported).
node(n1668,refuted) :- status(o_e3e7b682d79edaf1d3aa,refuted).
node(n1668,unknown) :- status(o_e3e7b682d79edaf1d3aa,unknown).
node(n1667,supported) :- node(n1659,supported), node(n1660,supported), node(n1668,supported), node(n1661,supported).
node(n1667,refuted) :- node(n1659,refuted).
node(n1667,refuted) :- node(n1660,refuted).
node(n1667,refuted) :- node(n1668,refuted).
node(n1667,refuted) :- node(n1661,refuted).
node(n1667,unknown) :- \+ node(n1667,supported), \+ node(n1667,refuted).
node(n1670,supported) :- status(o_c6c52942ef307e707bec,supported).
node(n1670,refuted) :- status(o_c6c52942ef307e707bec,refuted).
node(n1670,unknown) :- status(o_c6c52942ef307e707bec,unknown).
node(n1669,supported) :- node(n1663,supported), node(n1664,supported), node(n1670,supported), node(n1665,supported).
node(n1669,refuted) :- node(n1663,refuted).
node(n1669,refuted) :- node(n1664,refuted).
node(n1669,refuted) :- node(n1670,refuted).
node(n1669,refuted) :- node(n1665,refuted).
node(n1669,unknown) :- \+ node(n1669,supported), \+ node(n1669,refuted).
node(n1666,refuted) :- node(n1667,refuted), node(n1669,refuted), node(n9,refuted).
node(n1666,supported) :- node(n1667,supported).
node(n1666,supported) :- node(n1669,supported).
node(n1666,supported) :- node(n9,supported).
node(n1666,unknown) :- \+ node(n1666,supported), \+ node(n1666,refuted).
verdict(c_1ae6046847c0bfb1,supported) :- node(n1666,supported).
query(verdict(c_1ae6046847c0bfb1,supported)).
verdict(c_1ae6046847c0bfb1,refuted) :- node(n1666,refuted).
query(verdict(c_1ae6046847c0bfb1,refuted)).
verdict(c_1ae6046847c0bfb1,unknown) :- node(n1666,unknown).
query(verdict(c_1ae6046847c0bfb1,unknown)).
node(n1673,supported) :- status(o_a2c17c89266c5946d2f0,supported).
node(n1673,refuted) :- status(o_a2c17c89266c5946d2f0,refuted).
node(n1673,unknown) :- status(o_a2c17c89266c5946d2f0,unknown).
node(n1674,supported) :- status(o_9f6593e389bfdab5f963,supported).
node(n1674,refuted) :- status(o_9f6593e389bfdab5f963,refuted).
node(n1674,unknown) :- status(o_9f6593e389bfdab5f963,unknown).
node(n1675,supported) :- status(o_f03e0105113b8fbdc217,supported).
node(n1675,refuted) :- status(o_f03e0105113b8fbdc217,refuted).
node(n1675,unknown) :- status(o_f03e0105113b8fbdc217,unknown).
node(n1672,supported) :- node(n1673,supported), node(n1674,supported), node(n1675,supported).
node(n1672,refuted) :- node(n1673,refuted).
node(n1672,refuted) :- node(n1674,refuted).
node(n1672,refuted) :- node(n1675,refuted).
node(n1672,unknown) :- \+ node(n1672,supported), \+ node(n1672,refuted).
node(n1677,supported) :- status(o_a443ab6f8b75c4009ed5,supported).
node(n1677,refuted) :- status(o_a443ab6f8b75c4009ed5,refuted).
node(n1677,unknown) :- status(o_a443ab6f8b75c4009ed5,unknown).
node(n1678,supported) :- status(o_6cebf5b5294eecf6659a,supported).
node(n1678,refuted) :- status(o_6cebf5b5294eecf6659a,refuted).
node(n1678,unknown) :- status(o_6cebf5b5294eecf6659a,unknown).
node(n1679,supported) :- status(o_661290ccae6ac5396e8e,supported).
node(n1679,refuted) :- status(o_661290ccae6ac5396e8e,refuted).
node(n1679,unknown) :- status(o_661290ccae6ac5396e8e,unknown).
node(n1676,supported) :- node(n1677,supported), node(n1678,supported), node(n1679,supported).
node(n1676,refuted) :- node(n1677,refuted).
node(n1676,refuted) :- node(n1678,refuted).
node(n1676,refuted) :- node(n1679,refuted).
node(n1676,unknown) :- \+ node(n1676,supported), \+ node(n1676,refuted).
node(n1671,refuted) :- node(n1672,refuted), node(n1676,refuted), node(n9,refuted).
node(n1671,supported) :- node(n1672,supported).
node(n1671,supported) :- node(n1676,supported).
node(n1671,supported) :- node(n9,supported).
node(n1671,unknown) :- \+ node(n1671,supported), \+ node(n1671,refuted).
verdict(c_0944ec4a10fef568,supported) :- node(n1671,supported).
query(verdict(c_0944ec4a10fef568,supported)).
verdict(c_0944ec4a10fef568,refuted) :- node(n1671,refuted).
query(verdict(c_0944ec4a10fef568,refuted)).
verdict(c_0944ec4a10fef568,unknown) :- node(n1671,unknown).
query(verdict(c_0944ec4a10fef568,unknown)).
node(n1682,supported) :- status(o_27a8f0181a1a862419d4,supported).
node(n1682,refuted) :- status(o_27a8f0181a1a862419d4,refuted).
node(n1682,unknown) :- status(o_27a8f0181a1a862419d4,unknown).
node(n1681,supported) :- node(n1673,supported), node(n1674,supported), node(n1682,supported), node(n1675,supported).
node(n1681,refuted) :- node(n1673,refuted).
node(n1681,refuted) :- node(n1674,refuted).
node(n1681,refuted) :- node(n1682,refuted).
node(n1681,refuted) :- node(n1675,refuted).
node(n1681,unknown) :- \+ node(n1681,supported), \+ node(n1681,refuted).
node(n1684,supported) :- status(o_b376ab0435aa7657dfa7,supported).
node(n1684,refuted) :- status(o_b376ab0435aa7657dfa7,refuted).
node(n1684,unknown) :- status(o_b376ab0435aa7657dfa7,unknown).
node(n1683,supported) :- node(n1677,supported), node(n1678,supported), node(n1684,supported), node(n1679,supported).
node(n1683,refuted) :- node(n1677,refuted).
node(n1683,refuted) :- node(n1678,refuted).
node(n1683,refuted) :- node(n1684,refuted).
node(n1683,refuted) :- node(n1679,refuted).
node(n1683,unknown) :- \+ node(n1683,supported), \+ node(n1683,refuted).
node(n1680,refuted) :- node(n1681,refuted), node(n1683,refuted), node(n9,refuted).
node(n1680,supported) :- node(n1681,supported).
node(n1680,supported) :- node(n1683,supported).
node(n1680,supported) :- node(n9,supported).
node(n1680,unknown) :- \+ node(n1680,supported), \+ node(n1680,refuted).
verdict(c_47cfe7061d55c927,supported) :- node(n1680,supported).
query(verdict(c_47cfe7061d55c927,supported)).
verdict(c_47cfe7061d55c927,refuted) :- node(n1680,refuted).
query(verdict(c_47cfe7061d55c927,refuted)).
verdict(c_47cfe7061d55c927,unknown) :- node(n1680,unknown).
query(verdict(c_47cfe7061d55c927,unknown)).
node(n1687,supported) :- status(o_38e2ad15775b0f2959c8,supported).
node(n1687,refuted) :- status(o_38e2ad15775b0f2959c8,refuted).
node(n1687,unknown) :- status(o_38e2ad15775b0f2959c8,unknown).
node(n1688,supported) :- status(o_34150bb5f882b79c353c,supported).
node(n1688,refuted) :- status(o_34150bb5f882b79c353c,refuted).
node(n1688,unknown) :- status(o_34150bb5f882b79c353c,unknown).
node(n1689,supported) :- status(o_d25f245dc586ee58e9e4,supported).
node(n1689,refuted) :- status(o_d25f245dc586ee58e9e4,refuted).
node(n1689,unknown) :- status(o_d25f245dc586ee58e9e4,unknown).
node(n1686,supported) :- node(n1687,supported), node(n1688,supported), node(n1689,supported).
node(n1686,refuted) :- node(n1687,refuted).
node(n1686,refuted) :- node(n1688,refuted).
node(n1686,refuted) :- node(n1689,refuted).
node(n1686,unknown) :- \+ node(n1686,supported), \+ node(n1686,refuted).
node(n1691,supported) :- status(o_d7af19569aeb6110cb07,supported).
node(n1691,refuted) :- status(o_d7af19569aeb6110cb07,refuted).
node(n1691,unknown) :- status(o_d7af19569aeb6110cb07,unknown).
node(n1692,supported) :- status(o_9805547594a986be76df,supported).
node(n1692,refuted) :- status(o_9805547594a986be76df,refuted).
node(n1692,unknown) :- status(o_9805547594a986be76df,unknown).
node(n1693,supported) :- status(o_238947f1af294ba162d8,supported).
node(n1693,refuted) :- status(o_238947f1af294ba162d8,refuted).
node(n1693,unknown) :- status(o_238947f1af294ba162d8,unknown).
node(n1690,supported) :- node(n1691,supported), node(n1692,supported), node(n1693,supported).
node(n1690,refuted) :- node(n1691,refuted).
node(n1690,refuted) :- node(n1692,refuted).
node(n1690,refuted) :- node(n1693,refuted).
node(n1690,unknown) :- \+ node(n1690,supported), \+ node(n1690,refuted).
node(n1685,refuted) :- node(n1686,refuted), node(n1690,refuted), node(n9,refuted).
node(n1685,supported) :- node(n1686,supported).
node(n1685,supported) :- node(n1690,supported).
node(n1685,supported) :- node(n9,supported).
node(n1685,unknown) :- \+ node(n1685,supported), \+ node(n1685,refuted).
verdict(c_e85eba56a89a1bfc,supported) :- node(n1685,supported).
query(verdict(c_e85eba56a89a1bfc,supported)).
verdict(c_e85eba56a89a1bfc,refuted) :- node(n1685,refuted).
query(verdict(c_e85eba56a89a1bfc,refuted)).
verdict(c_e85eba56a89a1bfc,unknown) :- node(n1685,unknown).
query(verdict(c_e85eba56a89a1bfc,unknown)).
node(n1696,supported) :- status(o_7932a9e3c3cff51e4d66,supported).
node(n1696,refuted) :- status(o_7932a9e3c3cff51e4d66,refuted).
node(n1696,unknown) :- status(o_7932a9e3c3cff51e4d66,unknown).
node(n1695,supported) :- node(n1687,supported), node(n1688,supported), node(n1696,supported), node(n1689,supported).
node(n1695,refuted) :- node(n1687,refuted).
node(n1695,refuted) :- node(n1688,refuted).
node(n1695,refuted) :- node(n1696,refuted).
node(n1695,refuted) :- node(n1689,refuted).
node(n1695,unknown) :- \+ node(n1695,supported), \+ node(n1695,refuted).
node(n1698,supported) :- status(o_3381c08b4d591e2913dd,supported).
node(n1698,refuted) :- status(o_3381c08b4d591e2913dd,refuted).
node(n1698,unknown) :- status(o_3381c08b4d591e2913dd,unknown).
node(n1697,supported) :- node(n1691,supported), node(n1692,supported), node(n1698,supported), node(n1693,supported).
node(n1697,refuted) :- node(n1691,refuted).
node(n1697,refuted) :- node(n1692,refuted).
node(n1697,refuted) :- node(n1698,refuted).
node(n1697,refuted) :- node(n1693,refuted).
node(n1697,unknown) :- \+ node(n1697,supported), \+ node(n1697,refuted).
node(n1694,refuted) :- node(n1695,refuted), node(n1697,refuted), node(n9,refuted).
node(n1694,supported) :- node(n1695,supported).
node(n1694,supported) :- node(n1697,supported).
node(n1694,supported) :- node(n9,supported).
node(n1694,unknown) :- \+ node(n1694,supported), \+ node(n1694,refuted).
verdict(c_c8190667c466f530,supported) :- node(n1694,supported).
query(verdict(c_c8190667c466f530,supported)).
verdict(c_c8190667c466f530,refuted) :- node(n1694,refuted).
query(verdict(c_c8190667c466f530,refuted)).
verdict(c_c8190667c466f530,unknown) :- node(n1694,unknown).
query(verdict(c_c8190667c466f530,unknown)).
node(n1701,supported) :- status(o_160ff53d9bd1ce576a08,supported).
node(n1701,refuted) :- status(o_160ff53d9bd1ce576a08,refuted).
node(n1701,unknown) :- status(o_160ff53d9bd1ce576a08,unknown).
node(n1702,supported) :- status(o_9bd7f7fd4458d8537db8,supported).
node(n1702,refuted) :- status(o_9bd7f7fd4458d8537db8,refuted).
node(n1702,unknown) :- status(o_9bd7f7fd4458d8537db8,unknown).
node(n1703,supported) :- status(o_fa8b5ae6b60ab04fcffe,supported).
node(n1703,refuted) :- status(o_fa8b5ae6b60ab04fcffe,refuted).
node(n1703,unknown) :- status(o_fa8b5ae6b60ab04fcffe,unknown).
node(n1700,supported) :- node(n1701,supported), node(n1702,supported), node(n1703,supported).
node(n1700,refuted) :- node(n1701,refuted).
node(n1700,refuted) :- node(n1702,refuted).
node(n1700,refuted) :- node(n1703,refuted).
node(n1700,unknown) :- \+ node(n1700,supported), \+ node(n1700,refuted).
node(n1705,supported) :- status(o_3cdd0ef40a74ebbfa5b3,supported).
node(n1705,refuted) :- status(o_3cdd0ef40a74ebbfa5b3,refuted).
node(n1705,unknown) :- status(o_3cdd0ef40a74ebbfa5b3,unknown).
node(n1706,supported) :- status(o_d55bb7692344559e3c9c,supported).
node(n1706,refuted) :- status(o_d55bb7692344559e3c9c,refuted).
node(n1706,unknown) :- status(o_d55bb7692344559e3c9c,unknown).
node(n1707,supported) :- status(o_bd021a8e3581ee1f79ee,supported).
node(n1707,refuted) :- status(o_bd021a8e3581ee1f79ee,refuted).
node(n1707,unknown) :- status(o_bd021a8e3581ee1f79ee,unknown).
node(n1704,supported) :- node(n1705,supported), node(n1706,supported), node(n1707,supported).
node(n1704,refuted) :- node(n1705,refuted).
node(n1704,refuted) :- node(n1706,refuted).
node(n1704,refuted) :- node(n1707,refuted).
node(n1704,unknown) :- \+ node(n1704,supported), \+ node(n1704,refuted).
node(n1699,refuted) :- node(n1700,refuted), node(n1704,refuted), node(n9,refuted).
node(n1699,supported) :- node(n1700,supported).
node(n1699,supported) :- node(n1704,supported).
node(n1699,supported) :- node(n9,supported).
node(n1699,unknown) :- \+ node(n1699,supported), \+ node(n1699,refuted).
verdict(c_a5b149f5e13e947c,supported) :- node(n1699,supported).
query(verdict(c_a5b149f5e13e947c,supported)).
verdict(c_a5b149f5e13e947c,refuted) :- node(n1699,refuted).
query(verdict(c_a5b149f5e13e947c,refuted)).
verdict(c_a5b149f5e13e947c,unknown) :- node(n1699,unknown).
query(verdict(c_a5b149f5e13e947c,unknown)).
node(n1710,supported) :- status(o_95238e269fc803ada4b4,supported).
node(n1710,refuted) :- status(o_95238e269fc803ada4b4,refuted).
node(n1710,unknown) :- status(o_95238e269fc803ada4b4,unknown).
node(n1709,supported) :- node(n1701,supported), node(n1702,supported), node(n1710,supported), node(n1703,supported).
node(n1709,refuted) :- node(n1701,refuted).
node(n1709,refuted) :- node(n1702,refuted).
node(n1709,refuted) :- node(n1710,refuted).
node(n1709,refuted) :- node(n1703,refuted).
node(n1709,unknown) :- \+ node(n1709,supported), \+ node(n1709,refuted).
node(n1712,supported) :- status(o_5a8d90fdb110cafe06ef,supported).
node(n1712,refuted) :- status(o_5a8d90fdb110cafe06ef,refuted).
node(n1712,unknown) :- status(o_5a8d90fdb110cafe06ef,unknown).
node(n1711,supported) :- node(n1705,supported), node(n1706,supported), node(n1712,supported), node(n1707,supported).
node(n1711,refuted) :- node(n1705,refuted).
node(n1711,refuted) :- node(n1706,refuted).
node(n1711,refuted) :- node(n1712,refuted).
node(n1711,refuted) :- node(n1707,refuted).
node(n1711,unknown) :- \+ node(n1711,supported), \+ node(n1711,refuted).
node(n1708,refuted) :- node(n1709,refuted), node(n1711,refuted), node(n9,refuted).
node(n1708,supported) :- node(n1709,supported).
node(n1708,supported) :- node(n1711,supported).
node(n1708,supported) :- node(n9,supported).
node(n1708,unknown) :- \+ node(n1708,supported), \+ node(n1708,refuted).
verdict(c_651afba4e57240ba,supported) :- node(n1708,supported).
query(verdict(c_651afba4e57240ba,supported)).
verdict(c_651afba4e57240ba,refuted) :- node(n1708,refuted).
query(verdict(c_651afba4e57240ba,refuted)).
verdict(c_651afba4e57240ba,unknown) :- node(n1708,unknown).
query(verdict(c_651afba4e57240ba,unknown)).
node(n1715,supported) :- status(o_ecc201056cb590f6f64a,supported).
node(n1715,refuted) :- status(o_ecc201056cb590f6f64a,refuted).
node(n1715,unknown) :- status(o_ecc201056cb590f6f64a,unknown).
node(n1716,supported) :- status(o_0cd26ca4a5bc930651ec,supported).
node(n1716,refuted) :- status(o_0cd26ca4a5bc930651ec,refuted).
node(n1716,unknown) :- status(o_0cd26ca4a5bc930651ec,unknown).
node(n1717,supported) :- status(o_0efbd94f2fbf1b375633,supported).
node(n1717,refuted) :- status(o_0efbd94f2fbf1b375633,refuted).
node(n1717,unknown) :- status(o_0efbd94f2fbf1b375633,unknown).
node(n1714,supported) :- node(n1715,supported), node(n1716,supported), node(n1717,supported).
node(n1714,refuted) :- node(n1715,refuted).
node(n1714,refuted) :- node(n1716,refuted).
node(n1714,refuted) :- node(n1717,refuted).
node(n1714,unknown) :- \+ node(n1714,supported), \+ node(n1714,refuted).
node(n1719,supported) :- status(o_0b21c24297026375629d,supported).
node(n1719,refuted) :- status(o_0b21c24297026375629d,refuted).
node(n1719,unknown) :- status(o_0b21c24297026375629d,unknown).
node(n1720,supported) :- status(o_220d684cb55d13711edb,supported).
node(n1720,refuted) :- status(o_220d684cb55d13711edb,refuted).
node(n1720,unknown) :- status(o_220d684cb55d13711edb,unknown).
node(n1721,supported) :- status(o_0176f303990cb1a43f5f,supported).
node(n1721,refuted) :- status(o_0176f303990cb1a43f5f,refuted).
node(n1721,unknown) :- status(o_0176f303990cb1a43f5f,unknown).
node(n1718,supported) :- node(n1719,supported), node(n1720,supported), node(n1721,supported).
node(n1718,refuted) :- node(n1719,refuted).
node(n1718,refuted) :- node(n1720,refuted).
node(n1718,refuted) :- node(n1721,refuted).
node(n1718,unknown) :- \+ node(n1718,supported), \+ node(n1718,refuted).
node(n1713,refuted) :- node(n1714,refuted), node(n1718,refuted), node(n9,refuted).
node(n1713,supported) :- node(n1714,supported).
node(n1713,supported) :- node(n1718,supported).
node(n1713,supported) :- node(n9,supported).
node(n1713,unknown) :- \+ node(n1713,supported), \+ node(n1713,refuted).
verdict(c_42fc7e1b9d57a2d1,supported) :- node(n1713,supported).
query(verdict(c_42fc7e1b9d57a2d1,supported)).
verdict(c_42fc7e1b9d57a2d1,refuted) :- node(n1713,refuted).
query(verdict(c_42fc7e1b9d57a2d1,refuted)).
verdict(c_42fc7e1b9d57a2d1,unknown) :- node(n1713,unknown).
query(verdict(c_42fc7e1b9d57a2d1,unknown)).
node(n1724,supported) :- status(o_2d850f1da22f76248283,supported).
node(n1724,refuted) :- status(o_2d850f1da22f76248283,refuted).
node(n1724,unknown) :- status(o_2d850f1da22f76248283,unknown).
node(n1723,supported) :- node(n1715,supported), node(n1716,supported), node(n1724,supported), node(n1717,supported).
node(n1723,refuted) :- node(n1715,refuted).
node(n1723,refuted) :- node(n1716,refuted).
node(n1723,refuted) :- node(n1724,refuted).
node(n1723,refuted) :- node(n1717,refuted).
node(n1723,unknown) :- \+ node(n1723,supported), \+ node(n1723,refuted).
node(n1726,supported) :- status(o_60f4d140724633210c01,supported).
node(n1726,refuted) :- status(o_60f4d140724633210c01,refuted).
node(n1726,unknown) :- status(o_60f4d140724633210c01,unknown).
node(n1725,supported) :- node(n1719,supported), node(n1720,supported), node(n1726,supported), node(n1721,supported).
node(n1725,refuted) :- node(n1719,refuted).
node(n1725,refuted) :- node(n1720,refuted).
node(n1725,refuted) :- node(n1726,refuted).
node(n1725,refuted) :- node(n1721,refuted).
node(n1725,unknown) :- \+ node(n1725,supported), \+ node(n1725,refuted).
node(n1722,refuted) :- node(n1723,refuted), node(n1725,refuted), node(n9,refuted).
node(n1722,supported) :- node(n1723,supported).
node(n1722,supported) :- node(n1725,supported).
node(n1722,supported) :- node(n9,supported).
node(n1722,unknown) :- \+ node(n1722,supported), \+ node(n1722,refuted).
verdict(c_f64062f4a6e93d97,supported) :- node(n1722,supported).
query(verdict(c_f64062f4a6e93d97,supported)).
verdict(c_f64062f4a6e93d97,refuted) :- node(n1722,refuted).
query(verdict(c_f64062f4a6e93d97,refuted)).
verdict(c_f64062f4a6e93d97,unknown) :- node(n1722,unknown).
query(verdict(c_f64062f4a6e93d97,unknown)).
node(n1729,supported) :- status(o_6b098069cb53a4d561b8,supported).
node(n1729,refuted) :- status(o_6b098069cb53a4d561b8,refuted).
node(n1729,unknown) :- status(o_6b098069cb53a4d561b8,unknown).
node(n1730,supported) :- status(o_fa9fcdce03ef829a9373,supported).
node(n1730,refuted) :- status(o_fa9fcdce03ef829a9373,refuted).
node(n1730,unknown) :- status(o_fa9fcdce03ef829a9373,unknown).
node(n1731,supported) :- status(o_8455cf13ff83602b8d7a,supported).
node(n1731,refuted) :- status(o_8455cf13ff83602b8d7a,refuted).
node(n1731,unknown) :- status(o_8455cf13ff83602b8d7a,unknown).
node(n1728,supported) :- node(n1729,supported), node(n1730,supported), node(n1731,supported).
node(n1728,refuted) :- node(n1729,refuted).
node(n1728,refuted) :- node(n1730,refuted).
node(n1728,refuted) :- node(n1731,refuted).
node(n1728,unknown) :- \+ node(n1728,supported), \+ node(n1728,refuted).
node(n1733,supported) :- status(o_677e2547b5a54995c384,supported).
node(n1733,refuted) :- status(o_677e2547b5a54995c384,refuted).
node(n1733,unknown) :- status(o_677e2547b5a54995c384,unknown).
node(n1734,supported) :- status(o_7777262499d19cfc9d75,supported).
node(n1734,refuted) :- status(o_7777262499d19cfc9d75,refuted).
node(n1734,unknown) :- status(o_7777262499d19cfc9d75,unknown).
node(n1735,supported) :- status(o_c8605cd44710e8fd1d4b,supported).
node(n1735,refuted) :- status(o_c8605cd44710e8fd1d4b,refuted).
node(n1735,unknown) :- status(o_c8605cd44710e8fd1d4b,unknown).
node(n1732,supported) :- node(n1733,supported), node(n1734,supported), node(n1735,supported).
node(n1732,refuted) :- node(n1733,refuted).
node(n1732,refuted) :- node(n1734,refuted).
node(n1732,refuted) :- node(n1735,refuted).
node(n1732,unknown) :- \+ node(n1732,supported), \+ node(n1732,refuted).
node(n1727,refuted) :- node(n1728,refuted), node(n1732,refuted), node(n9,refuted).
node(n1727,supported) :- node(n1728,supported).
node(n1727,supported) :- node(n1732,supported).
node(n1727,supported) :- node(n9,supported).
node(n1727,unknown) :- \+ node(n1727,supported), \+ node(n1727,refuted).
verdict(c_84992942ecd5da5c,supported) :- node(n1727,supported).
query(verdict(c_84992942ecd5da5c,supported)).
verdict(c_84992942ecd5da5c,refuted) :- node(n1727,refuted).
query(verdict(c_84992942ecd5da5c,refuted)).
verdict(c_84992942ecd5da5c,unknown) :- node(n1727,unknown).
query(verdict(c_84992942ecd5da5c,unknown)).
node(n1738,supported) :- status(o_d826f1bf8341711aa2b1,supported).
node(n1738,refuted) :- status(o_d826f1bf8341711aa2b1,refuted).
node(n1738,unknown) :- status(o_d826f1bf8341711aa2b1,unknown).
node(n1737,supported) :- node(n1729,supported), node(n1730,supported), node(n1738,supported), node(n1731,supported).
node(n1737,refuted) :- node(n1729,refuted).
node(n1737,refuted) :- node(n1730,refuted).
node(n1737,refuted) :- node(n1738,refuted).
node(n1737,refuted) :- node(n1731,refuted).
node(n1737,unknown) :- \+ node(n1737,supported), \+ node(n1737,refuted).
node(n1740,supported) :- status(o_6ef5f6b21c0a02d7649f,supported).
node(n1740,refuted) :- status(o_6ef5f6b21c0a02d7649f,refuted).
node(n1740,unknown) :- status(o_6ef5f6b21c0a02d7649f,unknown).
node(n1739,supported) :- node(n1733,supported), node(n1734,supported), node(n1740,supported), node(n1735,supported).
node(n1739,refuted) :- node(n1733,refuted).
node(n1739,refuted) :- node(n1734,refuted).
node(n1739,refuted) :- node(n1740,refuted).
node(n1739,refuted) :- node(n1735,refuted).
node(n1739,unknown) :- \+ node(n1739,supported), \+ node(n1739,refuted).
node(n1736,refuted) :- node(n1737,refuted), node(n1739,refuted), node(n9,refuted).
node(n1736,supported) :- node(n1737,supported).
node(n1736,supported) :- node(n1739,supported).
node(n1736,supported) :- node(n9,supported).
node(n1736,unknown) :- \+ node(n1736,supported), \+ node(n1736,refuted).
verdict(c_c80ac50f424e4d60,supported) :- node(n1736,supported).
query(verdict(c_c80ac50f424e4d60,supported)).
verdict(c_c80ac50f424e4d60,refuted) :- node(n1736,refuted).
query(verdict(c_c80ac50f424e4d60,refuted)).
verdict(c_c80ac50f424e4d60,unknown) :- node(n1736,unknown).
query(verdict(c_c80ac50f424e4d60,unknown)).
node(n1743,supported) :- status(o_fcd4bd69e38e07fd54f8,supported).
node(n1743,refuted) :- status(o_fcd4bd69e38e07fd54f8,refuted).
node(n1743,unknown) :- status(o_fcd4bd69e38e07fd54f8,unknown).
node(n1744,supported) :- status(o_af663c4cce7eee55ceee,supported).
node(n1744,refuted) :- status(o_af663c4cce7eee55ceee,refuted).
node(n1744,unknown) :- status(o_af663c4cce7eee55ceee,unknown).
node(n1745,supported) :- status(o_b26e9c91a61e4acd664f,supported).
node(n1745,refuted) :- status(o_b26e9c91a61e4acd664f,refuted).
node(n1745,unknown) :- status(o_b26e9c91a61e4acd664f,unknown).
node(n1742,supported) :- node(n1743,supported), node(n1744,supported), node(n1745,supported).
node(n1742,refuted) :- node(n1743,refuted).
node(n1742,refuted) :- node(n1744,refuted).
node(n1742,refuted) :- node(n1745,refuted).
node(n1742,unknown) :- \+ node(n1742,supported), \+ node(n1742,refuted).
node(n1747,supported) :- status(o_7158d7fcec3492c63471,supported).
node(n1747,refuted) :- status(o_7158d7fcec3492c63471,refuted).
node(n1747,unknown) :- status(o_7158d7fcec3492c63471,unknown).
node(n1748,supported) :- status(o_8bf56445f49d06603852,supported).
node(n1748,refuted) :- status(o_8bf56445f49d06603852,refuted).
node(n1748,unknown) :- status(o_8bf56445f49d06603852,unknown).
node(n1749,supported) :- status(o_dfcb1b94635ba602bdd7,supported).
node(n1749,refuted) :- status(o_dfcb1b94635ba602bdd7,refuted).
node(n1749,unknown) :- status(o_dfcb1b94635ba602bdd7,unknown).
node(n1746,supported) :- node(n1747,supported), node(n1748,supported), node(n1749,supported).
node(n1746,refuted) :- node(n1747,refuted).
node(n1746,refuted) :- node(n1748,refuted).
node(n1746,refuted) :- node(n1749,refuted).
node(n1746,unknown) :- \+ node(n1746,supported), \+ node(n1746,refuted).
node(n1741,refuted) :- node(n1742,refuted), node(n1746,refuted), node(n9,refuted).
node(n1741,supported) :- node(n1742,supported).
node(n1741,supported) :- node(n1746,supported).
node(n1741,supported) :- node(n9,supported).
node(n1741,unknown) :- \+ node(n1741,supported), \+ node(n1741,refuted).
verdict(c_6971d7eb826fa84e,supported) :- node(n1741,supported).
query(verdict(c_6971d7eb826fa84e,supported)).
verdict(c_6971d7eb826fa84e,refuted) :- node(n1741,refuted).
query(verdict(c_6971d7eb826fa84e,refuted)).
verdict(c_6971d7eb826fa84e,unknown) :- node(n1741,unknown).
query(verdict(c_6971d7eb826fa84e,unknown)).
node(n1752,supported) :- status(o_69ab1a8196e6ce11ec89,supported).
node(n1752,refuted) :- status(o_69ab1a8196e6ce11ec89,refuted).
node(n1752,unknown) :- status(o_69ab1a8196e6ce11ec89,unknown).
node(n1751,supported) :- node(n1743,supported), node(n1744,supported), node(n1752,supported), node(n1745,supported).
node(n1751,refuted) :- node(n1743,refuted).
node(n1751,refuted) :- node(n1744,refuted).
node(n1751,refuted) :- node(n1752,refuted).
node(n1751,refuted) :- node(n1745,refuted).
node(n1751,unknown) :- \+ node(n1751,supported), \+ node(n1751,refuted).
node(n1754,supported) :- status(o_753e010ec4f8d2aa3097,supported).
node(n1754,refuted) :- status(o_753e010ec4f8d2aa3097,refuted).
node(n1754,unknown) :- status(o_753e010ec4f8d2aa3097,unknown).
node(n1753,supported) :- node(n1747,supported), node(n1748,supported), node(n1754,supported), node(n1749,supported).
node(n1753,refuted) :- node(n1747,refuted).
node(n1753,refuted) :- node(n1748,refuted).
node(n1753,refuted) :- node(n1754,refuted).
node(n1753,refuted) :- node(n1749,refuted).
node(n1753,unknown) :- \+ node(n1753,supported), \+ node(n1753,refuted).
node(n1750,refuted) :- node(n1751,refuted), node(n1753,refuted), node(n9,refuted).
node(n1750,supported) :- node(n1751,supported).
node(n1750,supported) :- node(n1753,supported).
node(n1750,supported) :- node(n9,supported).
node(n1750,unknown) :- \+ node(n1750,supported), \+ node(n1750,refuted).
verdict(c_2eef0136e335d5ae,supported) :- node(n1750,supported).
query(verdict(c_2eef0136e335d5ae,supported)).
verdict(c_2eef0136e335d5ae,refuted) :- node(n1750,refuted).
query(verdict(c_2eef0136e335d5ae,refuted)).
verdict(c_2eef0136e335d5ae,unknown) :- node(n1750,unknown).
query(verdict(c_2eef0136e335d5ae,unknown)).
node(n1757,supported) :- status(o_9b35d21ef720404483ac,supported).
node(n1757,refuted) :- status(o_9b35d21ef720404483ac,refuted).
node(n1757,unknown) :- status(o_9b35d21ef720404483ac,unknown).
node(n1758,supported) :- status(o_b6abde984791764baf26,supported).
node(n1758,refuted) :- status(o_b6abde984791764baf26,refuted).
node(n1758,unknown) :- status(o_b6abde984791764baf26,unknown).
node(n1759,supported) :- status(o_ac494f7e5861f20da9aa,supported).
node(n1759,refuted) :- status(o_ac494f7e5861f20da9aa,refuted).
node(n1759,unknown) :- status(o_ac494f7e5861f20da9aa,unknown).
node(n1756,supported) :- node(n1757,supported), node(n1758,supported), node(n1759,supported).
node(n1756,refuted) :- node(n1757,refuted).
node(n1756,refuted) :- node(n1758,refuted).
node(n1756,refuted) :- node(n1759,refuted).
node(n1756,unknown) :- \+ node(n1756,supported), \+ node(n1756,refuted).
node(n1761,supported) :- status(o_8d356fc40911012e5651,supported).
node(n1761,refuted) :- status(o_8d356fc40911012e5651,refuted).
node(n1761,unknown) :- status(o_8d356fc40911012e5651,unknown).
node(n1762,supported) :- status(o_bc644de20b847e0d9548,supported).
node(n1762,refuted) :- status(o_bc644de20b847e0d9548,refuted).
node(n1762,unknown) :- status(o_bc644de20b847e0d9548,unknown).
node(n1763,supported) :- status(o_be174e5182e3090c52ec,supported).
node(n1763,refuted) :- status(o_be174e5182e3090c52ec,refuted).
node(n1763,unknown) :- status(o_be174e5182e3090c52ec,unknown).
node(n1760,supported) :- node(n1761,supported), node(n1762,supported), node(n1763,supported).
node(n1760,refuted) :- node(n1761,refuted).
node(n1760,refuted) :- node(n1762,refuted).
node(n1760,refuted) :- node(n1763,refuted).
node(n1760,unknown) :- \+ node(n1760,supported), \+ node(n1760,refuted).
node(n1755,refuted) :- node(n1756,refuted), node(n1760,refuted), node(n9,refuted).
node(n1755,supported) :- node(n1756,supported).
node(n1755,supported) :- node(n1760,supported).
node(n1755,supported) :- node(n9,supported).
node(n1755,unknown) :- \+ node(n1755,supported), \+ node(n1755,refuted).
verdict(c_802a40c63abea607,supported) :- node(n1755,supported).
query(verdict(c_802a40c63abea607,supported)).
verdict(c_802a40c63abea607,refuted) :- node(n1755,refuted).
query(verdict(c_802a40c63abea607,refuted)).
verdict(c_802a40c63abea607,unknown) :- node(n1755,unknown).
query(verdict(c_802a40c63abea607,unknown)).
node(n1766,supported) :- status(o_ddabadcf5e9ca752ce36,supported).
node(n1766,refuted) :- status(o_ddabadcf5e9ca752ce36,refuted).
node(n1766,unknown) :- status(o_ddabadcf5e9ca752ce36,unknown).
node(n1765,supported) :- node(n1757,supported), node(n1758,supported), node(n1766,supported), node(n1759,supported).
node(n1765,refuted) :- node(n1757,refuted).
node(n1765,refuted) :- node(n1758,refuted).
node(n1765,refuted) :- node(n1766,refuted).
node(n1765,refuted) :- node(n1759,refuted).
node(n1765,unknown) :- \+ node(n1765,supported), \+ node(n1765,refuted).
node(n1768,supported) :- status(o_4ae5d13a86d7c5e68e12,supported).
node(n1768,refuted) :- status(o_4ae5d13a86d7c5e68e12,refuted).
node(n1768,unknown) :- status(o_4ae5d13a86d7c5e68e12,unknown).
node(n1767,supported) :- node(n1761,supported), node(n1762,supported), node(n1768,supported), node(n1763,supported).
node(n1767,refuted) :- node(n1761,refuted).
node(n1767,refuted) :- node(n1762,refuted).
node(n1767,refuted) :- node(n1768,refuted).
node(n1767,refuted) :- node(n1763,refuted).
node(n1767,unknown) :- \+ node(n1767,supported), \+ node(n1767,refuted).
node(n1764,refuted) :- node(n1765,refuted), node(n1767,refuted), node(n9,refuted).
node(n1764,supported) :- node(n1765,supported).
node(n1764,supported) :- node(n1767,supported).
node(n1764,supported) :- node(n9,supported).
node(n1764,unknown) :- \+ node(n1764,supported), \+ node(n1764,refuted).
verdict(c_b51eed064c38bc36,supported) :- node(n1764,supported).
query(verdict(c_b51eed064c38bc36,supported)).
verdict(c_b51eed064c38bc36,refuted) :- node(n1764,refuted).
query(verdict(c_b51eed064c38bc36,refuted)).
verdict(c_b51eed064c38bc36,unknown) :- node(n1764,unknown).
query(verdict(c_b51eed064c38bc36,unknown)).
node(n1771,supported) :- status(o_db53cf1ff805e50cd252,supported).
node(n1771,refuted) :- status(o_db53cf1ff805e50cd252,refuted).
node(n1771,unknown) :- status(o_db53cf1ff805e50cd252,unknown).
node(n1772,supported) :- status(o_ca254481495c5bf916e8,supported).
node(n1772,refuted) :- status(o_ca254481495c5bf916e8,refuted).
node(n1772,unknown) :- status(o_ca254481495c5bf916e8,unknown).
node(n1773,supported) :- status(o_15dd3003b07c3406c3d9,supported).
node(n1773,refuted) :- status(o_15dd3003b07c3406c3d9,refuted).
node(n1773,unknown) :- status(o_15dd3003b07c3406c3d9,unknown).
node(n1770,supported) :- node(n1771,supported), node(n1772,supported), node(n1773,supported).
node(n1770,refuted) :- node(n1771,refuted).
node(n1770,refuted) :- node(n1772,refuted).
node(n1770,refuted) :- node(n1773,refuted).
node(n1770,unknown) :- \+ node(n1770,supported), \+ node(n1770,refuted).
node(n1775,supported) :- status(o_8fbff6ccea84adc7ed12,supported).
node(n1775,refuted) :- status(o_8fbff6ccea84adc7ed12,refuted).
node(n1775,unknown) :- status(o_8fbff6ccea84adc7ed12,unknown).
node(n1776,supported) :- status(o_dce5ad48dbd95e41c5e8,supported).
node(n1776,refuted) :- status(o_dce5ad48dbd95e41c5e8,refuted).
node(n1776,unknown) :- status(o_dce5ad48dbd95e41c5e8,unknown).
node(n1777,supported) :- status(o_f2aa9ec1f54dc7d43ce9,supported).
node(n1777,refuted) :- status(o_f2aa9ec1f54dc7d43ce9,refuted).
node(n1777,unknown) :- status(o_f2aa9ec1f54dc7d43ce9,unknown).
node(n1774,supported) :- node(n1775,supported), node(n1776,supported), node(n1777,supported).
node(n1774,refuted) :- node(n1775,refuted).
node(n1774,refuted) :- node(n1776,refuted).
node(n1774,refuted) :- node(n1777,refuted).
node(n1774,unknown) :- \+ node(n1774,supported), \+ node(n1774,refuted).
node(n1769,refuted) :- node(n1770,refuted), node(n1774,refuted), node(n9,refuted).
node(n1769,supported) :- node(n1770,supported).
node(n1769,supported) :- node(n1774,supported).
node(n1769,supported) :- node(n9,supported).
node(n1769,unknown) :- \+ node(n1769,supported), \+ node(n1769,refuted).
verdict(c_ce9997d773e909d3,supported) :- node(n1769,supported).
query(verdict(c_ce9997d773e909d3,supported)).
verdict(c_ce9997d773e909d3,refuted) :- node(n1769,refuted).
query(verdict(c_ce9997d773e909d3,refuted)).
verdict(c_ce9997d773e909d3,unknown) :- node(n1769,unknown).
query(verdict(c_ce9997d773e909d3,unknown)).
node(n1780,supported) :- status(o_9826c61f999beb568501,supported).
node(n1780,refuted) :- status(o_9826c61f999beb568501,refuted).
node(n1780,unknown) :- status(o_9826c61f999beb568501,unknown).
node(n1779,supported) :- node(n1771,supported), node(n1772,supported), node(n1780,supported), node(n1773,supported).
node(n1779,refuted) :- node(n1771,refuted).
node(n1779,refuted) :- node(n1772,refuted).
node(n1779,refuted) :- node(n1780,refuted).
node(n1779,refuted) :- node(n1773,refuted).
node(n1779,unknown) :- \+ node(n1779,supported), \+ node(n1779,refuted).
node(n1782,supported) :- status(o_71dc35bc325aa3663e39,supported).
node(n1782,refuted) :- status(o_71dc35bc325aa3663e39,refuted).
node(n1782,unknown) :- status(o_71dc35bc325aa3663e39,unknown).
node(n1781,supported) :- node(n1775,supported), node(n1776,supported), node(n1782,supported), node(n1777,supported).
node(n1781,refuted) :- node(n1775,refuted).
node(n1781,refuted) :- node(n1776,refuted).
node(n1781,refuted) :- node(n1782,refuted).
node(n1781,refuted) :- node(n1777,refuted).
node(n1781,unknown) :- \+ node(n1781,supported), \+ node(n1781,refuted).
node(n1778,refuted) :- node(n1779,refuted), node(n1781,refuted), node(n9,refuted).
node(n1778,supported) :- node(n1779,supported).
node(n1778,supported) :- node(n1781,supported).
node(n1778,supported) :- node(n9,supported).
node(n1778,unknown) :- \+ node(n1778,supported), \+ node(n1778,refuted).
verdict(c_a82551b9bab7fc91,supported) :- node(n1778,supported).
query(verdict(c_a82551b9bab7fc91,supported)).
verdict(c_a82551b9bab7fc91,refuted) :- node(n1778,refuted).
query(verdict(c_a82551b9bab7fc91,refuted)).
verdict(c_a82551b9bab7fc91,unknown) :- node(n1778,unknown).
query(verdict(c_a82551b9bab7fc91,unknown)).
node(n1785,supported) :- status(o_b111b45648a53c82e655,supported).
node(n1785,refuted) :- status(o_b111b45648a53c82e655,refuted).
node(n1785,unknown) :- status(o_b111b45648a53c82e655,unknown).
node(n1786,supported) :- status(o_e6142a8630fa8df5dfab,supported).
node(n1786,refuted) :- status(o_e6142a8630fa8df5dfab,refuted).
node(n1786,unknown) :- status(o_e6142a8630fa8df5dfab,unknown).
node(n1787,supported) :- status(o_539a76c120556250747f,supported).
node(n1787,refuted) :- status(o_539a76c120556250747f,refuted).
node(n1787,unknown) :- status(o_539a76c120556250747f,unknown).
node(n1784,supported) :- node(n1785,supported), node(n1786,supported), node(n1787,supported).
node(n1784,refuted) :- node(n1785,refuted).
node(n1784,refuted) :- node(n1786,refuted).
node(n1784,refuted) :- node(n1787,refuted).
node(n1784,unknown) :- \+ node(n1784,supported), \+ node(n1784,refuted).
node(n1789,supported) :- status(o_9db8c84379d107580a2e,supported).
node(n1789,refuted) :- status(o_9db8c84379d107580a2e,refuted).
node(n1789,unknown) :- status(o_9db8c84379d107580a2e,unknown).
node(n1790,supported) :- status(o_24cc5560bbaac5f07481,supported).
node(n1790,refuted) :- status(o_24cc5560bbaac5f07481,refuted).
node(n1790,unknown) :- status(o_24cc5560bbaac5f07481,unknown).
node(n1791,supported) :- status(o_c8149288d612034b7975,supported).
node(n1791,refuted) :- status(o_c8149288d612034b7975,refuted).
node(n1791,unknown) :- status(o_c8149288d612034b7975,unknown).
node(n1788,supported) :- node(n1789,supported), node(n1790,supported), node(n1791,supported).
node(n1788,refuted) :- node(n1789,refuted).
node(n1788,refuted) :- node(n1790,refuted).
node(n1788,refuted) :- node(n1791,refuted).
node(n1788,unknown) :- \+ node(n1788,supported), \+ node(n1788,refuted).
node(n1783,refuted) :- node(n1784,refuted), node(n1788,refuted), node(n9,refuted).
node(n1783,supported) :- node(n1784,supported).
node(n1783,supported) :- node(n1788,supported).
node(n1783,supported) :- node(n9,supported).
node(n1783,unknown) :- \+ node(n1783,supported), \+ node(n1783,refuted).
verdict(c_58de767d97c15495,supported) :- node(n1783,supported).
query(verdict(c_58de767d97c15495,supported)).
verdict(c_58de767d97c15495,refuted) :- node(n1783,refuted).
query(verdict(c_58de767d97c15495,refuted)).
verdict(c_58de767d97c15495,unknown) :- node(n1783,unknown).
query(verdict(c_58de767d97c15495,unknown)).
node(n1794,supported) :- status(o_228911afb332cccb7a06,supported).
node(n1794,refuted) :- status(o_228911afb332cccb7a06,refuted).
node(n1794,unknown) :- status(o_228911afb332cccb7a06,unknown).
node(n1793,supported) :- node(n1785,supported), node(n1786,supported), node(n1794,supported), node(n1787,supported).
node(n1793,refuted) :- node(n1785,refuted).
node(n1793,refuted) :- node(n1786,refuted).
node(n1793,refuted) :- node(n1794,refuted).
node(n1793,refuted) :- node(n1787,refuted).
node(n1793,unknown) :- \+ node(n1793,supported), \+ node(n1793,refuted).
node(n1796,supported) :- status(o_d11319c86f48ea287feb,supported).
node(n1796,refuted) :- status(o_d11319c86f48ea287feb,refuted).
node(n1796,unknown) :- status(o_d11319c86f48ea287feb,unknown).
node(n1795,supported) :- node(n1789,supported), node(n1790,supported), node(n1796,supported), node(n1791,supported).
node(n1795,refuted) :- node(n1789,refuted).
node(n1795,refuted) :- node(n1790,refuted).
node(n1795,refuted) :- node(n1796,refuted).
node(n1795,refuted) :- node(n1791,refuted).
node(n1795,unknown) :- \+ node(n1795,supported), \+ node(n1795,refuted).
node(n1792,refuted) :- node(n1793,refuted), node(n1795,refuted), node(n9,refuted).
node(n1792,supported) :- node(n1793,supported).
node(n1792,supported) :- node(n1795,supported).
node(n1792,supported) :- node(n9,supported).
node(n1792,unknown) :- \+ node(n1792,supported), \+ node(n1792,refuted).
verdict(c_63fa166f07c46511,supported) :- node(n1792,supported).
query(verdict(c_63fa166f07c46511,supported)).
verdict(c_63fa166f07c46511,refuted) :- node(n1792,refuted).
query(verdict(c_63fa166f07c46511,refuted)).
verdict(c_63fa166f07c46511,unknown) :- node(n1792,unknown).
query(verdict(c_63fa166f07c46511,unknown)).
node(n1799,supported) :- status(o_95009ef7d75cf3937cb7,supported).
node(n1799,refuted) :- status(o_95009ef7d75cf3937cb7,refuted).
node(n1799,unknown) :- status(o_95009ef7d75cf3937cb7,unknown).
node(n1800,supported) :- status(o_f9fcc8d8663b60758d8a,supported).
node(n1800,refuted) :- status(o_f9fcc8d8663b60758d8a,refuted).
node(n1800,unknown) :- status(o_f9fcc8d8663b60758d8a,unknown).
node(n1801,supported) :- status(o_9773d5107f8b856a1adb,supported).
node(n1801,refuted) :- status(o_9773d5107f8b856a1adb,refuted).
node(n1801,unknown) :- status(o_9773d5107f8b856a1adb,unknown).
node(n1798,supported) :- node(n1799,supported), node(n1800,supported), node(n1801,supported).
node(n1798,refuted) :- node(n1799,refuted).
node(n1798,refuted) :- node(n1800,refuted).
node(n1798,refuted) :- node(n1801,refuted).
node(n1798,unknown) :- \+ node(n1798,supported), \+ node(n1798,refuted).
node(n1797,refuted) :- node(n1798,refuted), node(n9,refuted).
node(n1797,supported) :- node(n1798,supported).
node(n1797,supported) :- node(n9,supported).
node(n1797,unknown) :- \+ node(n1797,supported), \+ node(n1797,refuted).
verdict(c_d2ebacd0ddda3699,supported) :- node(n1797,supported).
query(verdict(c_d2ebacd0ddda3699,supported)).
verdict(c_d2ebacd0ddda3699,refuted) :- node(n1797,refuted).
query(verdict(c_d2ebacd0ddda3699,refuted)).
verdict(c_d2ebacd0ddda3699,unknown) :- node(n1797,unknown).
query(verdict(c_d2ebacd0ddda3699,unknown)).
node(n1804,supported) :- status(o_e0f03769bf1492c04f00,supported).
node(n1804,refuted) :- status(o_e0f03769bf1492c04f00,refuted).
node(n1804,unknown) :- status(o_e0f03769bf1492c04f00,unknown).
node(n1803,supported) :- node(n1799,supported), node(n1800,supported), node(n1804,supported), node(n1801,supported).
node(n1803,refuted) :- node(n1799,refuted).
node(n1803,refuted) :- node(n1800,refuted).
node(n1803,refuted) :- node(n1804,refuted).
node(n1803,refuted) :- node(n1801,refuted).
node(n1803,unknown) :- \+ node(n1803,supported), \+ node(n1803,refuted).
node(n1802,refuted) :- node(n1803,refuted), node(n9,refuted).
node(n1802,supported) :- node(n1803,supported).
node(n1802,supported) :- node(n9,supported).
node(n1802,unknown) :- \+ node(n1802,supported), \+ node(n1802,refuted).
verdict(c_ede50cc174a80b15,supported) :- node(n1802,supported).
query(verdict(c_ede50cc174a80b15,supported)).
verdict(c_ede50cc174a80b15,refuted) :- node(n1802,refuted).
query(verdict(c_ede50cc174a80b15,refuted)).
verdict(c_ede50cc174a80b15,unknown) :- node(n1802,unknown).
query(verdict(c_ede50cc174a80b15,unknown)).
node(n1807,supported) :- status(o_7acb591d47f0c59bfcd5,supported).
node(n1807,refuted) :- status(o_7acb591d47f0c59bfcd5,refuted).
node(n1807,unknown) :- status(o_7acb591d47f0c59bfcd5,unknown).
node(n1808,supported) :- status(o_707e927e077d4854b711,supported).
node(n1808,refuted) :- status(o_707e927e077d4854b711,refuted).
node(n1808,unknown) :- status(o_707e927e077d4854b711,unknown).
node(n1809,supported) :- status(o_0b66e0c6ab80da20bc0d,supported).
node(n1809,refuted) :- status(o_0b66e0c6ab80da20bc0d,refuted).
node(n1809,unknown) :- status(o_0b66e0c6ab80da20bc0d,unknown).
node(n1806,supported) :- node(n1807,supported), node(n1808,supported), node(n1809,supported).
node(n1806,refuted) :- node(n1807,refuted).
node(n1806,refuted) :- node(n1808,refuted).
node(n1806,refuted) :- node(n1809,refuted).
node(n1806,unknown) :- \+ node(n1806,supported), \+ node(n1806,refuted).
node(n1805,refuted) :- node(n1806,refuted), node(n9,refuted).
node(n1805,supported) :- node(n1806,supported).
node(n1805,supported) :- node(n9,supported).
node(n1805,unknown) :- \+ node(n1805,supported), \+ node(n1805,refuted).
verdict(c_f61bb861c2974e86,supported) :- node(n1805,supported).
query(verdict(c_f61bb861c2974e86,supported)).
verdict(c_f61bb861c2974e86,refuted) :- node(n1805,refuted).
query(verdict(c_f61bb861c2974e86,refuted)).
verdict(c_f61bb861c2974e86,unknown) :- node(n1805,unknown).
query(verdict(c_f61bb861c2974e86,unknown)).
node(n1812,supported) :- status(o_b1a091d1b7e890a84d71,supported).
node(n1812,refuted) :- status(o_b1a091d1b7e890a84d71,refuted).
node(n1812,unknown) :- status(o_b1a091d1b7e890a84d71,unknown).
node(n1811,supported) :- node(n1807,supported), node(n1808,supported), node(n1812,supported), node(n1809,supported).
node(n1811,refuted) :- node(n1807,refuted).
node(n1811,refuted) :- node(n1808,refuted).
node(n1811,refuted) :- node(n1812,refuted).
node(n1811,refuted) :- node(n1809,refuted).
node(n1811,unknown) :- \+ node(n1811,supported), \+ node(n1811,refuted).
node(n1810,refuted) :- node(n1811,refuted), node(n9,refuted).
node(n1810,supported) :- node(n1811,supported).
node(n1810,supported) :- node(n9,supported).
node(n1810,unknown) :- \+ node(n1810,supported), \+ node(n1810,refuted).
verdict(c_20147ca0e3c02642,supported) :- node(n1810,supported).
query(verdict(c_20147ca0e3c02642,supported)).
verdict(c_20147ca0e3c02642,refuted) :- node(n1810,refuted).
query(verdict(c_20147ca0e3c02642,refuted)).
verdict(c_20147ca0e3c02642,unknown) :- node(n1810,unknown).
query(verdict(c_20147ca0e3c02642,unknown)).
node(n1815,supported) :- status(o_2bcf0f4261f6e40cc071,supported).
node(n1815,refuted) :- status(o_2bcf0f4261f6e40cc071,refuted).
node(n1815,unknown) :- status(o_2bcf0f4261f6e40cc071,unknown).
node(n1816,supported) :- status(o_fe210805d494555d3cfd,supported).
node(n1816,refuted) :- status(o_fe210805d494555d3cfd,refuted).
node(n1816,unknown) :- status(o_fe210805d494555d3cfd,unknown).
node(n1817,supported) :- status(o_d5084105f491e2bf2be7,supported).
node(n1817,refuted) :- status(o_d5084105f491e2bf2be7,refuted).
node(n1817,unknown) :- status(o_d5084105f491e2bf2be7,unknown).
node(n1814,supported) :- node(n1815,supported), node(n1816,supported), node(n1817,supported).
node(n1814,refuted) :- node(n1815,refuted).
node(n1814,refuted) :- node(n1816,refuted).
node(n1814,refuted) :- node(n1817,refuted).
node(n1814,unknown) :- \+ node(n1814,supported), \+ node(n1814,refuted).
node(n1813,refuted) :- node(n1814,refuted), node(n9,refuted).
node(n1813,supported) :- node(n1814,supported).
node(n1813,supported) :- node(n9,supported).
node(n1813,unknown) :- \+ node(n1813,supported), \+ node(n1813,refuted).
verdict(c_adf1c3cfa09e8371,supported) :- node(n1813,supported).
query(verdict(c_adf1c3cfa09e8371,supported)).
verdict(c_adf1c3cfa09e8371,refuted) :- node(n1813,refuted).
query(verdict(c_adf1c3cfa09e8371,refuted)).
verdict(c_adf1c3cfa09e8371,unknown) :- node(n1813,unknown).
query(verdict(c_adf1c3cfa09e8371,unknown)).
node(n1820,supported) :- status(o_d438df36e2dd2c1df23e,supported).
node(n1820,refuted) :- status(o_d438df36e2dd2c1df23e,refuted).
node(n1820,unknown) :- status(o_d438df36e2dd2c1df23e,unknown).
node(n1819,supported) :- node(n1815,supported), node(n1816,supported), node(n1820,supported), node(n1817,supported).
node(n1819,refuted) :- node(n1815,refuted).
node(n1819,refuted) :- node(n1816,refuted).
node(n1819,refuted) :- node(n1820,refuted).
node(n1819,refuted) :- node(n1817,refuted).
node(n1819,unknown) :- \+ node(n1819,supported), \+ node(n1819,refuted).
node(n1818,refuted) :- node(n1819,refuted), node(n9,refuted).
node(n1818,supported) :- node(n1819,supported).
node(n1818,supported) :- node(n9,supported).
node(n1818,unknown) :- \+ node(n1818,supported), \+ node(n1818,refuted).
verdict(c_e76d47d75c0b734c,supported) :- node(n1818,supported).
query(verdict(c_e76d47d75c0b734c,supported)).
verdict(c_e76d47d75c0b734c,refuted) :- node(n1818,refuted).
query(verdict(c_e76d47d75c0b734c,refuted)).
verdict(c_e76d47d75c0b734c,unknown) :- node(n1818,unknown).
query(verdict(c_e76d47d75c0b734c,unknown)).
node(n1823,supported) :- status(o_2e98414894506cac07f0,supported).
node(n1823,refuted) :- status(o_2e98414894506cac07f0,refuted).
node(n1823,unknown) :- status(o_2e98414894506cac07f0,unknown).
node(n1824,supported) :- status(o_d1af824111d09e18ad95,supported).
node(n1824,refuted) :- status(o_d1af824111d09e18ad95,refuted).
node(n1824,unknown) :- status(o_d1af824111d09e18ad95,unknown).
node(n1825,supported) :- status(o_646f7fbcefb7786adad1,supported).
node(n1825,refuted) :- status(o_646f7fbcefb7786adad1,refuted).
node(n1825,unknown) :- status(o_646f7fbcefb7786adad1,unknown).
node(n1822,supported) :- node(n1823,supported), node(n1824,supported), node(n1825,supported).
node(n1822,refuted) :- node(n1823,refuted).
node(n1822,refuted) :- node(n1824,refuted).
node(n1822,refuted) :- node(n1825,refuted).
node(n1822,unknown) :- \+ node(n1822,supported), \+ node(n1822,refuted).
node(n1821,refuted) :- node(n1822,refuted), node(n9,refuted).
node(n1821,supported) :- node(n1822,supported).
node(n1821,supported) :- node(n9,supported).
node(n1821,unknown) :- \+ node(n1821,supported), \+ node(n1821,refuted).
verdict(c_12ee1402294b5504,supported) :- node(n1821,supported).
query(verdict(c_12ee1402294b5504,supported)).
verdict(c_12ee1402294b5504,refuted) :- node(n1821,refuted).
query(verdict(c_12ee1402294b5504,refuted)).
verdict(c_12ee1402294b5504,unknown) :- node(n1821,unknown).
query(verdict(c_12ee1402294b5504,unknown)).
node(n1828,supported) :- status(o_629dc282f430be00ec55,supported).
node(n1828,refuted) :- status(o_629dc282f430be00ec55,refuted).
node(n1828,unknown) :- status(o_629dc282f430be00ec55,unknown).
node(n1827,supported) :- node(n1823,supported), node(n1824,supported), node(n1828,supported), node(n1825,supported).
node(n1827,refuted) :- node(n1823,refuted).
node(n1827,refuted) :- node(n1824,refuted).
node(n1827,refuted) :- node(n1828,refuted).
node(n1827,refuted) :- node(n1825,refuted).
node(n1827,unknown) :- \+ node(n1827,supported), \+ node(n1827,refuted).
node(n1826,refuted) :- node(n1827,refuted), node(n9,refuted).
node(n1826,supported) :- node(n1827,supported).
node(n1826,supported) :- node(n9,supported).
node(n1826,unknown) :- \+ node(n1826,supported), \+ node(n1826,refuted).
verdict(c_a2c582455696d172,supported) :- node(n1826,supported).
query(verdict(c_a2c582455696d172,supported)).
verdict(c_a2c582455696d172,refuted) :- node(n1826,refuted).
query(verdict(c_a2c582455696d172,refuted)).
verdict(c_a2c582455696d172,unknown) :- node(n1826,unknown).
query(verdict(c_a2c582455696d172,unknown)).
node(n1831,supported) :- status(o_9f3628d5487121818b7e,supported).
node(n1831,refuted) :- status(o_9f3628d5487121818b7e,refuted).
node(n1831,unknown) :- status(o_9f3628d5487121818b7e,unknown).
node(n1832,supported) :- status(o_fa3447bb9429caee23e0,supported).
node(n1832,refuted) :- status(o_fa3447bb9429caee23e0,refuted).
node(n1832,unknown) :- status(o_fa3447bb9429caee23e0,unknown).
node(n1833,supported) :- status(o_fbfd1ecc8996c0d6ed75,supported).
node(n1833,refuted) :- status(o_fbfd1ecc8996c0d6ed75,refuted).
node(n1833,unknown) :- status(o_fbfd1ecc8996c0d6ed75,unknown).
node(n1830,supported) :- node(n1831,supported), node(n1832,supported), node(n1833,supported).
node(n1830,refuted) :- node(n1831,refuted).
node(n1830,refuted) :- node(n1832,refuted).
node(n1830,refuted) :- node(n1833,refuted).
node(n1830,unknown) :- \+ node(n1830,supported), \+ node(n1830,refuted).
node(n1829,refuted) :- node(n1830,refuted), node(n9,refuted).
node(n1829,supported) :- node(n1830,supported).
node(n1829,supported) :- node(n9,supported).
node(n1829,unknown) :- \+ node(n1829,supported), \+ node(n1829,refuted).
verdict(c_86ba030695677f63,supported) :- node(n1829,supported).
query(verdict(c_86ba030695677f63,supported)).
verdict(c_86ba030695677f63,refuted) :- node(n1829,refuted).
query(verdict(c_86ba030695677f63,refuted)).
verdict(c_86ba030695677f63,unknown) :- node(n1829,unknown).
query(verdict(c_86ba030695677f63,unknown)).
node(n1836,supported) :- status(o_d3599bdec4ede12fc6ea,supported).
node(n1836,refuted) :- status(o_d3599bdec4ede12fc6ea,refuted).
node(n1836,unknown) :- status(o_d3599bdec4ede12fc6ea,unknown).
node(n1835,supported) :- node(n1831,supported), node(n1832,supported), node(n1836,supported), node(n1833,supported).
node(n1835,refuted) :- node(n1831,refuted).
node(n1835,refuted) :- node(n1832,refuted).
node(n1835,refuted) :- node(n1836,refuted).
node(n1835,refuted) :- node(n1833,refuted).
node(n1835,unknown) :- \+ node(n1835,supported), \+ node(n1835,refuted).
node(n1834,refuted) :- node(n1835,refuted), node(n9,refuted).
node(n1834,supported) :- node(n1835,supported).
node(n1834,supported) :- node(n9,supported).
node(n1834,unknown) :- \+ node(n1834,supported), \+ node(n1834,refuted).
verdict(c_0ee9f7f411d294f3,supported) :- node(n1834,supported).
query(verdict(c_0ee9f7f411d294f3,supported)).
verdict(c_0ee9f7f411d294f3,refuted) :- node(n1834,refuted).
query(verdict(c_0ee9f7f411d294f3,refuted)).
verdict(c_0ee9f7f411d294f3,unknown) :- node(n1834,unknown).
query(verdict(c_0ee9f7f411d294f3,unknown)).
node(n1839,supported) :- status(o_5bb731a25da57997cd4b,supported).
node(n1839,refuted) :- status(o_5bb731a25da57997cd4b,refuted).
node(n1839,unknown) :- status(o_5bb731a25da57997cd4b,unknown).
node(n1840,supported) :- status(o_f0f2adcd016a4375f59e,supported).
node(n1840,refuted) :- status(o_f0f2adcd016a4375f59e,refuted).
node(n1840,unknown) :- status(o_f0f2adcd016a4375f59e,unknown).
node(n1841,supported) :- status(o_895158f28f17fb1a505b,supported).
node(n1841,refuted) :- status(o_895158f28f17fb1a505b,refuted).
node(n1841,unknown) :- status(o_895158f28f17fb1a505b,unknown).
node(n1838,supported) :- node(n1839,supported), node(n1840,supported), node(n1841,supported).
node(n1838,refuted) :- node(n1839,refuted).
node(n1838,refuted) :- node(n1840,refuted).
node(n1838,refuted) :- node(n1841,refuted).
node(n1838,unknown) :- \+ node(n1838,supported), \+ node(n1838,refuted).
node(n1837,refuted) :- node(n1838,refuted), node(n9,refuted).
node(n1837,supported) :- node(n1838,supported).
node(n1837,supported) :- node(n9,supported).
node(n1837,unknown) :- \+ node(n1837,supported), \+ node(n1837,refuted).
verdict(c_5789579c33c21ca6,supported) :- node(n1837,supported).
query(verdict(c_5789579c33c21ca6,supported)).
verdict(c_5789579c33c21ca6,refuted) :- node(n1837,refuted).
query(verdict(c_5789579c33c21ca6,refuted)).
verdict(c_5789579c33c21ca6,unknown) :- node(n1837,unknown).
query(verdict(c_5789579c33c21ca6,unknown)).
node(n1844,supported) :- status(o_d58345f480df44560e94,supported).
node(n1844,refuted) :- status(o_d58345f480df44560e94,refuted).
node(n1844,unknown) :- status(o_d58345f480df44560e94,unknown).
node(n1843,supported) :- node(n1839,supported), node(n1840,supported), node(n1844,supported), node(n1841,supported).
node(n1843,refuted) :- node(n1839,refuted).
node(n1843,refuted) :- node(n1840,refuted).
node(n1843,refuted) :- node(n1844,refuted).
node(n1843,refuted) :- node(n1841,refuted).
node(n1843,unknown) :- \+ node(n1843,supported), \+ node(n1843,refuted).
node(n1842,refuted) :- node(n1843,refuted), node(n9,refuted).
node(n1842,supported) :- node(n1843,supported).
node(n1842,supported) :- node(n9,supported).
node(n1842,unknown) :- \+ node(n1842,supported), \+ node(n1842,refuted).
verdict(c_e9766ab22850a652,supported) :- node(n1842,supported).
query(verdict(c_e9766ab22850a652,supported)).
verdict(c_e9766ab22850a652,refuted) :- node(n1842,refuted).
query(verdict(c_e9766ab22850a652,refuted)).
verdict(c_e9766ab22850a652,unknown) :- node(n1842,unknown).
query(verdict(c_e9766ab22850a652,unknown)).
node(n1847,supported) :- status(o_6accc46dc260687c5818,supported).
node(n1847,refuted) :- status(o_6accc46dc260687c5818,refuted).
node(n1847,unknown) :- status(o_6accc46dc260687c5818,unknown).
node(n1848,supported) :- status(o_67476fac70e4de2de21c,supported).
node(n1848,refuted) :- status(o_67476fac70e4de2de21c,refuted).
node(n1848,unknown) :- status(o_67476fac70e4de2de21c,unknown).
node(n1849,supported) :- status(o_99bef5e590b9a7457e9d,supported).
node(n1849,refuted) :- status(o_99bef5e590b9a7457e9d,refuted).
node(n1849,unknown) :- status(o_99bef5e590b9a7457e9d,unknown).
node(n1846,supported) :- node(n1847,supported), node(n1848,supported), node(n1849,supported).
node(n1846,refuted) :- node(n1847,refuted).
node(n1846,refuted) :- node(n1848,refuted).
node(n1846,refuted) :- node(n1849,refuted).
node(n1846,unknown) :- \+ node(n1846,supported), \+ node(n1846,refuted).
node(n1845,refuted) :- node(n1846,refuted), node(n9,refuted).
node(n1845,supported) :- node(n1846,supported).
node(n1845,supported) :- node(n9,supported).
node(n1845,unknown) :- \+ node(n1845,supported), \+ node(n1845,refuted).
verdict(c_a0e41c49a55902fa,supported) :- node(n1845,supported).
query(verdict(c_a0e41c49a55902fa,supported)).
verdict(c_a0e41c49a55902fa,refuted) :- node(n1845,refuted).
query(verdict(c_a0e41c49a55902fa,refuted)).
verdict(c_a0e41c49a55902fa,unknown) :- node(n1845,unknown).
query(verdict(c_a0e41c49a55902fa,unknown)).
node(n1852,supported) :- status(o_179d5f2131acb24ee0f8,supported).
node(n1852,refuted) :- status(o_179d5f2131acb24ee0f8,refuted).
node(n1852,unknown) :- status(o_179d5f2131acb24ee0f8,unknown).
node(n1851,supported) :- node(n1847,supported), node(n1848,supported), node(n1852,supported), node(n1849,supported).
node(n1851,refuted) :- node(n1847,refuted).
node(n1851,refuted) :- node(n1848,refuted).
node(n1851,refuted) :- node(n1852,refuted).
node(n1851,refuted) :- node(n1849,refuted).
node(n1851,unknown) :- \+ node(n1851,supported), \+ node(n1851,refuted).
node(n1850,refuted) :- node(n1851,refuted), node(n9,refuted).
node(n1850,supported) :- node(n1851,supported).
node(n1850,supported) :- node(n9,supported).
node(n1850,unknown) :- \+ node(n1850,supported), \+ node(n1850,refuted).
verdict(c_5eb564393ef8eb30,supported) :- node(n1850,supported).
query(verdict(c_5eb564393ef8eb30,supported)).
verdict(c_5eb564393ef8eb30,refuted) :- node(n1850,refuted).
query(verdict(c_5eb564393ef8eb30,refuted)).
verdict(c_5eb564393ef8eb30,unknown) :- node(n1850,unknown).
query(verdict(c_5eb564393ef8eb30,unknown)).
node(n1855,supported) :- status(o_bc63e8dac77512358da1,supported).
node(n1855,refuted) :- status(o_bc63e8dac77512358da1,refuted).
node(n1855,unknown) :- status(o_bc63e8dac77512358da1,unknown).
node(n1856,supported) :- status(o_c70a09badf34c22b49e4,supported).
node(n1856,refuted) :- status(o_c70a09badf34c22b49e4,refuted).
node(n1856,unknown) :- status(o_c70a09badf34c22b49e4,unknown).
node(n1857,supported) :- status(o_cc2701322facf86a8f9f,supported).
node(n1857,refuted) :- status(o_cc2701322facf86a8f9f,refuted).
node(n1857,unknown) :- status(o_cc2701322facf86a8f9f,unknown).
node(n1854,supported) :- node(n1855,supported), node(n1856,supported), node(n1857,supported).
node(n1854,refuted) :- node(n1855,refuted).
node(n1854,refuted) :- node(n1856,refuted).
node(n1854,refuted) :- node(n1857,refuted).
node(n1854,unknown) :- \+ node(n1854,supported), \+ node(n1854,refuted).
node(n1853,refuted) :- node(n1854,refuted), node(n9,refuted).
node(n1853,supported) :- node(n1854,supported).
node(n1853,supported) :- node(n9,supported).
node(n1853,unknown) :- \+ node(n1853,supported), \+ node(n1853,refuted).
verdict(c_05590a982fb6ffef,supported) :- node(n1853,supported).
query(verdict(c_05590a982fb6ffef,supported)).
verdict(c_05590a982fb6ffef,refuted) :- node(n1853,refuted).
query(verdict(c_05590a982fb6ffef,refuted)).
verdict(c_05590a982fb6ffef,unknown) :- node(n1853,unknown).
query(verdict(c_05590a982fb6ffef,unknown)).
node(n1860,supported) :- status(o_fdf425be58da49361244,supported).
node(n1860,refuted) :- status(o_fdf425be58da49361244,refuted).
node(n1860,unknown) :- status(o_fdf425be58da49361244,unknown).
node(n1859,supported) :- node(n1855,supported), node(n1856,supported), node(n1860,supported), node(n1857,supported).
node(n1859,refuted) :- node(n1855,refuted).
node(n1859,refuted) :- node(n1856,refuted).
node(n1859,refuted) :- node(n1860,refuted).
node(n1859,refuted) :- node(n1857,refuted).
node(n1859,unknown) :- \+ node(n1859,supported), \+ node(n1859,refuted).
node(n1858,refuted) :- node(n1859,refuted), node(n9,refuted).
node(n1858,supported) :- node(n1859,supported).
node(n1858,supported) :- node(n9,supported).
node(n1858,unknown) :- \+ node(n1858,supported), \+ node(n1858,refuted).
verdict(c_e73db1544b78a4b7,supported) :- node(n1858,supported).
query(verdict(c_e73db1544b78a4b7,supported)).
verdict(c_e73db1544b78a4b7,refuted) :- node(n1858,refuted).
query(verdict(c_e73db1544b78a4b7,refuted)).
verdict(c_e73db1544b78a4b7,unknown) :- node(n1858,unknown).
query(verdict(c_e73db1544b78a4b7,unknown)).
node(n1863,supported) :- status(o_6e62e3e89e4305da18d4,supported).
node(n1863,refuted) :- status(o_6e62e3e89e4305da18d4,refuted).
node(n1863,unknown) :- status(o_6e62e3e89e4305da18d4,unknown).
node(n1864,supported) :- status(o_9d214bcfea904b0f2580,supported).
node(n1864,refuted) :- status(o_9d214bcfea904b0f2580,refuted).
node(n1864,unknown) :- status(o_9d214bcfea904b0f2580,unknown).
node(n1865,supported) :- status(o_6532d7ec3efa3f8c6015,supported).
node(n1865,refuted) :- status(o_6532d7ec3efa3f8c6015,refuted).
node(n1865,unknown) :- status(o_6532d7ec3efa3f8c6015,unknown).
node(n1862,supported) :- node(n1863,supported), node(n1864,supported), node(n1865,supported).
node(n1862,refuted) :- node(n1863,refuted).
node(n1862,refuted) :- node(n1864,refuted).
node(n1862,refuted) :- node(n1865,refuted).
node(n1862,unknown) :- \+ node(n1862,supported), \+ node(n1862,refuted).
node(n1861,refuted) :- node(n1862,refuted), node(n9,refuted).
node(n1861,supported) :- node(n1862,supported).
node(n1861,supported) :- node(n9,supported).
node(n1861,unknown) :- \+ node(n1861,supported), \+ node(n1861,refuted).
verdict(c_94ef7c3220ec8db7,supported) :- node(n1861,supported).
query(verdict(c_94ef7c3220ec8db7,supported)).
verdict(c_94ef7c3220ec8db7,refuted) :- node(n1861,refuted).
query(verdict(c_94ef7c3220ec8db7,refuted)).
verdict(c_94ef7c3220ec8db7,unknown) :- node(n1861,unknown).
query(verdict(c_94ef7c3220ec8db7,unknown)).
node(n1868,supported) :- status(o_d7b148d73e64c16452f0,supported).
node(n1868,refuted) :- status(o_d7b148d73e64c16452f0,refuted).
node(n1868,unknown) :- status(o_d7b148d73e64c16452f0,unknown).
node(n1867,supported) :- node(n1863,supported), node(n1864,supported), node(n1868,supported), node(n1865,supported).
node(n1867,refuted) :- node(n1863,refuted).
node(n1867,refuted) :- node(n1864,refuted).
node(n1867,refuted) :- node(n1868,refuted).
node(n1867,refuted) :- node(n1865,refuted).
node(n1867,unknown) :- \+ node(n1867,supported), \+ node(n1867,refuted).
node(n1866,refuted) :- node(n1867,refuted), node(n9,refuted).
node(n1866,supported) :- node(n1867,supported).
node(n1866,supported) :- node(n9,supported).
node(n1866,unknown) :- \+ node(n1866,supported), \+ node(n1866,refuted).
verdict(c_efebe980d1eb8b8e,supported) :- node(n1866,supported).
query(verdict(c_efebe980d1eb8b8e,supported)).
verdict(c_efebe980d1eb8b8e,refuted) :- node(n1866,refuted).
query(verdict(c_efebe980d1eb8b8e,refuted)).
verdict(c_efebe980d1eb8b8e,unknown) :- node(n1866,unknown).
query(verdict(c_efebe980d1eb8b8e,unknown)).
node(n1871,supported) :- status(o_a64a4ede3b0eb99550bd,supported).
node(n1871,refuted) :- status(o_a64a4ede3b0eb99550bd,refuted).
node(n1871,unknown) :- status(o_a64a4ede3b0eb99550bd,unknown).
node(n1872,supported) :- status(o_1e68d38c9134d9179c77,supported).
node(n1872,refuted) :- status(o_1e68d38c9134d9179c77,refuted).
node(n1872,unknown) :- status(o_1e68d38c9134d9179c77,unknown).
node(n1873,supported) :- status(o_cd5f8407c5e8e647ad1f,supported).
node(n1873,refuted) :- status(o_cd5f8407c5e8e647ad1f,refuted).
node(n1873,unknown) :- status(o_cd5f8407c5e8e647ad1f,unknown).
node(n1870,supported) :- node(n1871,supported), node(n1872,supported), node(n1873,supported).
node(n1870,refuted) :- node(n1871,refuted).
node(n1870,refuted) :- node(n1872,refuted).
node(n1870,refuted) :- node(n1873,refuted).
node(n1870,unknown) :- \+ node(n1870,supported), \+ node(n1870,refuted).
node(n1869,refuted) :- node(n1870,refuted), node(n9,refuted).
node(n1869,supported) :- node(n1870,supported).
node(n1869,supported) :- node(n9,supported).
node(n1869,unknown) :- \+ node(n1869,supported), \+ node(n1869,refuted).
verdict(c_cb072776d491a02a,supported) :- node(n1869,supported).
query(verdict(c_cb072776d491a02a,supported)).
verdict(c_cb072776d491a02a,refuted) :- node(n1869,refuted).
query(verdict(c_cb072776d491a02a,refuted)).
verdict(c_cb072776d491a02a,unknown) :- node(n1869,unknown).
query(verdict(c_cb072776d491a02a,unknown)).
node(n1876,supported) :- status(o_c7b7b6942e1e116397fc,supported).
node(n1876,refuted) :- status(o_c7b7b6942e1e116397fc,refuted).
node(n1876,unknown) :- status(o_c7b7b6942e1e116397fc,unknown).
node(n1875,supported) :- node(n1871,supported), node(n1872,supported), node(n1876,supported), node(n1873,supported).
node(n1875,refuted) :- node(n1871,refuted).
node(n1875,refuted) :- node(n1872,refuted).
node(n1875,refuted) :- node(n1876,refuted).
node(n1875,refuted) :- node(n1873,refuted).
node(n1875,unknown) :- \+ node(n1875,supported), \+ node(n1875,refuted).
node(n1874,refuted) :- node(n1875,refuted), node(n9,refuted).
node(n1874,supported) :- node(n1875,supported).
node(n1874,supported) :- node(n9,supported).
node(n1874,unknown) :- \+ node(n1874,supported), \+ node(n1874,refuted).
verdict(c_9916851cd10117e4,supported) :- node(n1874,supported).
query(verdict(c_9916851cd10117e4,supported)).
verdict(c_9916851cd10117e4,refuted) :- node(n1874,refuted).
query(verdict(c_9916851cd10117e4,refuted)).
verdict(c_9916851cd10117e4,unknown) :- node(n1874,unknown).
query(verdict(c_9916851cd10117e4,unknown)).
node(n1879,supported) :- status(o_e0148433680edb0ed27a,supported).
node(n1879,refuted) :- status(o_e0148433680edb0ed27a,refuted).
node(n1879,unknown) :- status(o_e0148433680edb0ed27a,unknown).
node(n1880,supported) :- status(o_487bf05f6123fea6f67b,supported).
node(n1880,refuted) :- status(o_487bf05f6123fea6f67b,refuted).
node(n1880,unknown) :- status(o_487bf05f6123fea6f67b,unknown).
node(n1881,supported) :- status(o_498b72a46f1580476d79,supported).
node(n1881,refuted) :- status(o_498b72a46f1580476d79,refuted).
node(n1881,unknown) :- status(o_498b72a46f1580476d79,unknown).
node(n1878,supported) :- node(n1879,supported), node(n1880,supported), node(n1881,supported).
node(n1878,refuted) :- node(n1879,refuted).
node(n1878,refuted) :- node(n1880,refuted).
node(n1878,refuted) :- node(n1881,refuted).
node(n1878,unknown) :- \+ node(n1878,supported), \+ node(n1878,refuted).
node(n1883,supported) :- status(o_a1cad329f5c1cf4ffc48,supported).
node(n1883,refuted) :- status(o_a1cad329f5c1cf4ffc48,refuted).
node(n1883,unknown) :- status(o_a1cad329f5c1cf4ffc48,unknown).
node(n1884,supported) :- status(o_40b6701dc274d888d09c,supported).
node(n1884,refuted) :- status(o_40b6701dc274d888d09c,refuted).
node(n1884,unknown) :- status(o_40b6701dc274d888d09c,unknown).
node(n1885,supported) :- status(o_a60f64901ce66b1dbe1e,supported).
node(n1885,refuted) :- status(o_a60f64901ce66b1dbe1e,refuted).
node(n1885,unknown) :- status(o_a60f64901ce66b1dbe1e,unknown).
node(n1882,supported) :- node(n1883,supported), node(n1884,supported), node(n1885,supported).
node(n1882,refuted) :- node(n1883,refuted).
node(n1882,refuted) :- node(n1884,refuted).
node(n1882,refuted) :- node(n1885,refuted).
node(n1882,unknown) :- \+ node(n1882,supported), \+ node(n1882,refuted).
node(n1877,refuted) :- node(n1878,refuted), node(n1882,refuted), node(n9,refuted).
node(n1877,supported) :- node(n1878,supported).
node(n1877,supported) :- node(n1882,supported).
node(n1877,supported) :- node(n9,supported).
node(n1877,unknown) :- \+ node(n1877,supported), \+ node(n1877,refuted).
verdict(c_4713da9e23efcec8,supported) :- node(n1877,supported).
query(verdict(c_4713da9e23efcec8,supported)).
verdict(c_4713da9e23efcec8,refuted) :- node(n1877,refuted).
query(verdict(c_4713da9e23efcec8,refuted)).
verdict(c_4713da9e23efcec8,unknown) :- node(n1877,unknown).
query(verdict(c_4713da9e23efcec8,unknown)).
node(n1888,supported) :- status(o_516021b852b3c39b4a39,supported).
node(n1888,refuted) :- status(o_516021b852b3c39b4a39,refuted).
node(n1888,unknown) :- status(o_516021b852b3c39b4a39,unknown).
node(n1887,supported) :- node(n1879,supported), node(n1880,supported), node(n1888,supported), node(n1881,supported).
node(n1887,refuted) :- node(n1879,refuted).
node(n1887,refuted) :- node(n1880,refuted).
node(n1887,refuted) :- node(n1888,refuted).
node(n1887,refuted) :- node(n1881,refuted).
node(n1887,unknown) :- \+ node(n1887,supported), \+ node(n1887,refuted).
node(n1890,supported) :- status(o_4f838aae2dddccf14152,supported).
node(n1890,refuted) :- status(o_4f838aae2dddccf14152,refuted).
node(n1890,unknown) :- status(o_4f838aae2dddccf14152,unknown).
node(n1889,supported) :- node(n1883,supported), node(n1884,supported), node(n1890,supported), node(n1885,supported).
node(n1889,refuted) :- node(n1883,refuted).
node(n1889,refuted) :- node(n1884,refuted).
node(n1889,refuted) :- node(n1890,refuted).
node(n1889,refuted) :- node(n1885,refuted).
node(n1889,unknown) :- \+ node(n1889,supported), \+ node(n1889,refuted).
node(n1886,refuted) :- node(n1887,refuted), node(n1889,refuted), node(n9,refuted).
node(n1886,supported) :- node(n1887,supported).
node(n1886,supported) :- node(n1889,supported).
node(n1886,supported) :- node(n9,supported).
node(n1886,unknown) :- \+ node(n1886,supported), \+ node(n1886,refuted).
verdict(c_694138822246f9c1,supported) :- node(n1886,supported).
query(verdict(c_694138822246f9c1,supported)).
verdict(c_694138822246f9c1,refuted) :- node(n1886,refuted).
query(verdict(c_694138822246f9c1,refuted)).
verdict(c_694138822246f9c1,unknown) :- node(n1886,unknown).
query(verdict(c_694138822246f9c1,unknown)).
node(n1893,supported) :- status(o_fd5ce9e04ccbd3385b3a,supported).
node(n1893,refuted) :- status(o_fd5ce9e04ccbd3385b3a,refuted).
node(n1893,unknown) :- status(o_fd5ce9e04ccbd3385b3a,unknown).
node(n1894,supported) :- status(o_e58a954d226c34f1b35a,supported).
node(n1894,refuted) :- status(o_e58a954d226c34f1b35a,refuted).
node(n1894,unknown) :- status(o_e58a954d226c34f1b35a,unknown).
node(n1895,supported) :- status(o_c32a1844e6b38d8955c7,supported).
node(n1895,refuted) :- status(o_c32a1844e6b38d8955c7,refuted).
node(n1895,unknown) :- status(o_c32a1844e6b38d8955c7,unknown).
node(n1892,supported) :- node(n1893,supported), node(n1894,supported), node(n1895,supported).
node(n1892,refuted) :- node(n1893,refuted).
node(n1892,refuted) :- node(n1894,refuted).
node(n1892,refuted) :- node(n1895,refuted).
node(n1892,unknown) :- \+ node(n1892,supported), \+ node(n1892,refuted).
node(n1897,supported) :- status(o_9e4d77a4f5c14166f0de,supported).
node(n1897,refuted) :- status(o_9e4d77a4f5c14166f0de,refuted).
node(n1897,unknown) :- status(o_9e4d77a4f5c14166f0de,unknown).
node(n1898,supported) :- status(o_894ed44e00af1de02d98,supported).
node(n1898,refuted) :- status(o_894ed44e00af1de02d98,refuted).
node(n1898,unknown) :- status(o_894ed44e00af1de02d98,unknown).
node(n1899,supported) :- status(o_df5f39882c13a979fe59,supported).
node(n1899,refuted) :- status(o_df5f39882c13a979fe59,refuted).
node(n1899,unknown) :- status(o_df5f39882c13a979fe59,unknown).
node(n1896,supported) :- node(n1897,supported), node(n1898,supported), node(n1899,supported).
node(n1896,refuted) :- node(n1897,refuted).
node(n1896,refuted) :- node(n1898,refuted).
node(n1896,refuted) :- node(n1899,refuted).
node(n1896,unknown) :- \+ node(n1896,supported), \+ node(n1896,refuted).
node(n1891,refuted) :- node(n1892,refuted), node(n1896,refuted), node(n9,refuted).
node(n1891,supported) :- node(n1892,supported).
node(n1891,supported) :- node(n1896,supported).
node(n1891,supported) :- node(n9,supported).
node(n1891,unknown) :- \+ node(n1891,supported), \+ node(n1891,refuted).
verdict(c_2e45ba50b5d45ab4,supported) :- node(n1891,supported).
query(verdict(c_2e45ba50b5d45ab4,supported)).
verdict(c_2e45ba50b5d45ab4,refuted) :- node(n1891,refuted).
query(verdict(c_2e45ba50b5d45ab4,refuted)).
verdict(c_2e45ba50b5d45ab4,unknown) :- node(n1891,unknown).
query(verdict(c_2e45ba50b5d45ab4,unknown)).
node(n1902,supported) :- status(o_c4027eadbe7b8affdfbf,supported).
node(n1902,refuted) :- status(o_c4027eadbe7b8affdfbf,refuted).
node(n1902,unknown) :- status(o_c4027eadbe7b8affdfbf,unknown).
node(n1901,supported) :- node(n1893,supported), node(n1894,supported), node(n1902,supported), node(n1895,supported).
node(n1901,refuted) :- node(n1893,refuted).
node(n1901,refuted) :- node(n1894,refuted).
node(n1901,refuted) :- node(n1902,refuted).
node(n1901,refuted) :- node(n1895,refuted).
node(n1901,unknown) :- \+ node(n1901,supported), \+ node(n1901,refuted).
node(n1904,supported) :- status(o_d451a624944cbfac7fb9,supported).
node(n1904,refuted) :- status(o_d451a624944cbfac7fb9,refuted).
node(n1904,unknown) :- status(o_d451a624944cbfac7fb9,unknown).
node(n1903,supported) :- node(n1897,supported), node(n1898,supported), node(n1904,supported), node(n1899,supported).
node(n1903,refuted) :- node(n1897,refuted).
node(n1903,refuted) :- node(n1898,refuted).
node(n1903,refuted) :- node(n1904,refuted).
node(n1903,refuted) :- node(n1899,refuted).
node(n1903,unknown) :- \+ node(n1903,supported), \+ node(n1903,refuted).
node(n1900,refuted) :- node(n1901,refuted), node(n1903,refuted), node(n9,refuted).
node(n1900,supported) :- node(n1901,supported).
node(n1900,supported) :- node(n1903,supported).
node(n1900,supported) :- node(n9,supported).
node(n1900,unknown) :- \+ node(n1900,supported), \+ node(n1900,refuted).
verdict(c_b90bf8ff3fdde884,supported) :- node(n1900,supported).
query(verdict(c_b90bf8ff3fdde884,supported)).
verdict(c_b90bf8ff3fdde884,refuted) :- node(n1900,refuted).
query(verdict(c_b90bf8ff3fdde884,refuted)).
verdict(c_b90bf8ff3fdde884,unknown) :- node(n1900,unknown).
query(verdict(c_b90bf8ff3fdde884,unknown)).
node(n1907,supported) :- status(o_24a13cb94c06f178b089,supported).
node(n1907,refuted) :- status(o_24a13cb94c06f178b089,refuted).
node(n1907,unknown) :- status(o_24a13cb94c06f178b089,unknown).
node(n1908,supported) :- status(o_c163174454ecf4f02c39,supported).
node(n1908,refuted) :- status(o_c163174454ecf4f02c39,refuted).
node(n1908,unknown) :- status(o_c163174454ecf4f02c39,unknown).
node(n1909,supported) :- status(o_bbeaa2bcaa24e37600e3,supported).
node(n1909,refuted) :- status(o_bbeaa2bcaa24e37600e3,refuted).
node(n1909,unknown) :- status(o_bbeaa2bcaa24e37600e3,unknown).
node(n1906,supported) :- node(n1907,supported), node(n1908,supported), node(n1909,supported).
node(n1906,refuted) :- node(n1907,refuted).
node(n1906,refuted) :- node(n1908,refuted).
node(n1906,refuted) :- node(n1909,refuted).
node(n1906,unknown) :- \+ node(n1906,supported), \+ node(n1906,refuted).
node(n1911,supported) :- status(o_25e747be1c2660bb459a,supported).
node(n1911,refuted) :- status(o_25e747be1c2660bb459a,refuted).
node(n1911,unknown) :- status(o_25e747be1c2660bb459a,unknown).
node(n1912,supported) :- status(o_dab1a2687cf1b9f4d58b,supported).
node(n1912,refuted) :- status(o_dab1a2687cf1b9f4d58b,refuted).
node(n1912,unknown) :- status(o_dab1a2687cf1b9f4d58b,unknown).
node(n1913,supported) :- status(o_36b2a1e1e14cb348ad04,supported).
node(n1913,refuted) :- status(o_36b2a1e1e14cb348ad04,refuted).
node(n1913,unknown) :- status(o_36b2a1e1e14cb348ad04,unknown).
node(n1910,supported) :- node(n1911,supported), node(n1912,supported), node(n1913,supported).
node(n1910,refuted) :- node(n1911,refuted).
node(n1910,refuted) :- node(n1912,refuted).
node(n1910,refuted) :- node(n1913,refuted).
node(n1910,unknown) :- \+ node(n1910,supported), \+ node(n1910,refuted).
node(n1905,refuted) :- node(n1906,refuted), node(n1910,refuted), node(n9,refuted).
node(n1905,supported) :- node(n1906,supported).
node(n1905,supported) :- node(n1910,supported).
node(n1905,supported) :- node(n9,supported).
node(n1905,unknown) :- \+ node(n1905,supported), \+ node(n1905,refuted).
verdict(c_584580cc38eb5c71,supported) :- node(n1905,supported).
query(verdict(c_584580cc38eb5c71,supported)).
verdict(c_584580cc38eb5c71,refuted) :- node(n1905,refuted).
query(verdict(c_584580cc38eb5c71,refuted)).
verdict(c_584580cc38eb5c71,unknown) :- node(n1905,unknown).
query(verdict(c_584580cc38eb5c71,unknown)).
node(n1916,supported) :- status(o_da2dec6deb9958294f83,supported).
node(n1916,refuted) :- status(o_da2dec6deb9958294f83,refuted).
node(n1916,unknown) :- status(o_da2dec6deb9958294f83,unknown).
node(n1915,supported) :- node(n1907,supported), node(n1908,supported), node(n1916,supported), node(n1909,supported).
node(n1915,refuted) :- node(n1907,refuted).
node(n1915,refuted) :- node(n1908,refuted).
node(n1915,refuted) :- node(n1916,refuted).
node(n1915,refuted) :- node(n1909,refuted).
node(n1915,unknown) :- \+ node(n1915,supported), \+ node(n1915,refuted).
node(n1918,supported) :- status(o_87c6f779d2bf9d67f12f,supported).
node(n1918,refuted) :- status(o_87c6f779d2bf9d67f12f,refuted).
node(n1918,unknown) :- status(o_87c6f779d2bf9d67f12f,unknown).
node(n1917,supported) :- node(n1911,supported), node(n1912,supported), node(n1918,supported), node(n1913,supported).
node(n1917,refuted) :- node(n1911,refuted).
node(n1917,refuted) :- node(n1912,refuted).
node(n1917,refuted) :- node(n1918,refuted).
node(n1917,refuted) :- node(n1913,refuted).
node(n1917,unknown) :- \+ node(n1917,supported), \+ node(n1917,refuted).
node(n1914,refuted) :- node(n1915,refuted), node(n1917,refuted), node(n9,refuted).
node(n1914,supported) :- node(n1915,supported).
node(n1914,supported) :- node(n1917,supported).
node(n1914,supported) :- node(n9,supported).
node(n1914,unknown) :- \+ node(n1914,supported), \+ node(n1914,refuted).
verdict(c_81581e729bcc12f8,supported) :- node(n1914,supported).
query(verdict(c_81581e729bcc12f8,supported)).
verdict(c_81581e729bcc12f8,refuted) :- node(n1914,refuted).
query(verdict(c_81581e729bcc12f8,refuted)).
verdict(c_81581e729bcc12f8,unknown) :- node(n1914,unknown).
query(verdict(c_81581e729bcc12f8,unknown)).
node(n1921,supported) :- status(o_df5756f4bde87495fe6f,supported).
node(n1921,refuted) :- status(o_df5756f4bde87495fe6f,refuted).
node(n1921,unknown) :- status(o_df5756f4bde87495fe6f,unknown).
node(n1922,supported) :- status(o_9ea3ad69f29464758cb4,supported).
node(n1922,refuted) :- status(o_9ea3ad69f29464758cb4,refuted).
node(n1922,unknown) :- status(o_9ea3ad69f29464758cb4,unknown).
node(n1923,supported) :- status(o_4f6c07a8b2375285bbfc,supported).
node(n1923,refuted) :- status(o_4f6c07a8b2375285bbfc,refuted).
node(n1923,unknown) :- status(o_4f6c07a8b2375285bbfc,unknown).
node(n1920,supported) :- node(n1921,supported), node(n1922,supported), node(n1923,supported).
node(n1920,refuted) :- node(n1921,refuted).
node(n1920,refuted) :- node(n1922,refuted).
node(n1920,refuted) :- node(n1923,refuted).
node(n1920,unknown) :- \+ node(n1920,supported), \+ node(n1920,refuted).
node(n1925,supported) :- status(o_610e409cc34287fab3d1,supported).
node(n1925,refuted) :- status(o_610e409cc34287fab3d1,refuted).
node(n1925,unknown) :- status(o_610e409cc34287fab3d1,unknown).
node(n1926,supported) :- status(o_443a780d1a947cf61f25,supported).
node(n1926,refuted) :- status(o_443a780d1a947cf61f25,refuted).
node(n1926,unknown) :- status(o_443a780d1a947cf61f25,unknown).
node(n1927,supported) :- status(o_466f7b5469f19dcd8595,supported).
node(n1927,refuted) :- status(o_466f7b5469f19dcd8595,refuted).
node(n1927,unknown) :- status(o_466f7b5469f19dcd8595,unknown).
node(n1924,supported) :- node(n1925,supported), node(n1926,supported), node(n1927,supported).
node(n1924,refuted) :- node(n1925,refuted).
node(n1924,refuted) :- node(n1926,refuted).
node(n1924,refuted) :- node(n1927,refuted).
node(n1924,unknown) :- \+ node(n1924,supported), \+ node(n1924,refuted).
node(n1919,refuted) :- node(n1920,refuted), node(n1924,refuted), node(n9,refuted).
node(n1919,supported) :- node(n1920,supported).
node(n1919,supported) :- node(n1924,supported).
node(n1919,supported) :- node(n9,supported).
node(n1919,unknown) :- \+ node(n1919,supported), \+ node(n1919,refuted).
verdict(c_c1675538899a3553,supported) :- node(n1919,supported).
query(verdict(c_c1675538899a3553,supported)).
verdict(c_c1675538899a3553,refuted) :- node(n1919,refuted).
query(verdict(c_c1675538899a3553,refuted)).
verdict(c_c1675538899a3553,unknown) :- node(n1919,unknown).
query(verdict(c_c1675538899a3553,unknown)).
node(n1930,supported) :- status(o_06e06b4b8d8f22815c4a,supported).
node(n1930,refuted) :- status(o_06e06b4b8d8f22815c4a,refuted).
node(n1930,unknown) :- status(o_06e06b4b8d8f22815c4a,unknown).
node(n1929,supported) :- node(n1921,supported), node(n1922,supported), node(n1930,supported), node(n1923,supported).
node(n1929,refuted) :- node(n1921,refuted).
node(n1929,refuted) :- node(n1922,refuted).
node(n1929,refuted) :- node(n1930,refuted).
node(n1929,refuted) :- node(n1923,refuted).
node(n1929,unknown) :- \+ node(n1929,supported), \+ node(n1929,refuted).
node(n1932,supported) :- status(o_aa54a5c1bc11ed054e90,supported).
node(n1932,refuted) :- status(o_aa54a5c1bc11ed054e90,refuted).
node(n1932,unknown) :- status(o_aa54a5c1bc11ed054e90,unknown).
node(n1931,supported) :- node(n1925,supported), node(n1926,supported), node(n1932,supported), node(n1927,supported).
node(n1931,refuted) :- node(n1925,refuted).
node(n1931,refuted) :- node(n1926,refuted).
node(n1931,refuted) :- node(n1932,refuted).
node(n1931,refuted) :- node(n1927,refuted).
node(n1931,unknown) :- \+ node(n1931,supported), \+ node(n1931,refuted).
node(n1928,refuted) :- node(n1929,refuted), node(n1931,refuted), node(n9,refuted).
node(n1928,supported) :- node(n1929,supported).
node(n1928,supported) :- node(n1931,supported).
node(n1928,supported) :- node(n9,supported).
node(n1928,unknown) :- \+ node(n1928,supported), \+ node(n1928,refuted).
verdict(c_e59c46bff5106c7e,supported) :- node(n1928,supported).
query(verdict(c_e59c46bff5106c7e,supported)).
verdict(c_e59c46bff5106c7e,refuted) :- node(n1928,refuted).
query(verdict(c_e59c46bff5106c7e,refuted)).
verdict(c_e59c46bff5106c7e,unknown) :- node(n1928,unknown).
query(verdict(c_e59c46bff5106c7e,unknown)).
node(n1935,supported) :- status(o_d27cda058d9fc24ab3e5,supported).
node(n1935,refuted) :- status(o_d27cda058d9fc24ab3e5,refuted).
node(n1935,unknown) :- status(o_d27cda058d9fc24ab3e5,unknown).
node(n1936,supported) :- status(o_16ad8aedbec72e5f6d85,supported).
node(n1936,refuted) :- status(o_16ad8aedbec72e5f6d85,refuted).
node(n1936,unknown) :- status(o_16ad8aedbec72e5f6d85,unknown).
node(n1937,supported) :- status(o_caf5d136e54d491f273c,supported).
node(n1937,refuted) :- status(o_caf5d136e54d491f273c,refuted).
node(n1937,unknown) :- status(o_caf5d136e54d491f273c,unknown).
node(n1934,supported) :- node(n1935,supported), node(n1936,supported), node(n1937,supported).
node(n1934,refuted) :- node(n1935,refuted).
node(n1934,refuted) :- node(n1936,refuted).
node(n1934,refuted) :- node(n1937,refuted).
node(n1934,unknown) :- \+ node(n1934,supported), \+ node(n1934,refuted).
node(n1939,supported) :- status(o_94f99dcbc4a137dbb4df,supported).
node(n1939,refuted) :- status(o_94f99dcbc4a137dbb4df,refuted).
node(n1939,unknown) :- status(o_94f99dcbc4a137dbb4df,unknown).
node(n1940,supported) :- status(o_90b2e6464fe6a7762bc5,supported).
node(n1940,refuted) :- status(o_90b2e6464fe6a7762bc5,refuted).
node(n1940,unknown) :- status(o_90b2e6464fe6a7762bc5,unknown).
node(n1941,supported) :- status(o_f8e5ef4099cfcfdcaccd,supported).
node(n1941,refuted) :- status(o_f8e5ef4099cfcfdcaccd,refuted).
node(n1941,unknown) :- status(o_f8e5ef4099cfcfdcaccd,unknown).
node(n1938,supported) :- node(n1939,supported), node(n1940,supported), node(n1941,supported).
node(n1938,refuted) :- node(n1939,refuted).
node(n1938,refuted) :- node(n1940,refuted).
node(n1938,refuted) :- node(n1941,refuted).
node(n1938,unknown) :- \+ node(n1938,supported), \+ node(n1938,refuted).
node(n1933,refuted) :- node(n1934,refuted), node(n1938,refuted), node(n9,refuted).
node(n1933,supported) :- node(n1934,supported).
node(n1933,supported) :- node(n1938,supported).
node(n1933,supported) :- node(n9,supported).
node(n1933,unknown) :- \+ node(n1933,supported), \+ node(n1933,refuted).
verdict(c_8047ca6088c9d1e3,supported) :- node(n1933,supported).
query(verdict(c_8047ca6088c9d1e3,supported)).
verdict(c_8047ca6088c9d1e3,refuted) :- node(n1933,refuted).
query(verdict(c_8047ca6088c9d1e3,refuted)).
verdict(c_8047ca6088c9d1e3,unknown) :- node(n1933,unknown).
query(verdict(c_8047ca6088c9d1e3,unknown)).
node(n1944,supported) :- status(o_467a6bf0b446f87730d3,supported).
node(n1944,refuted) :- status(o_467a6bf0b446f87730d3,refuted).
node(n1944,unknown) :- status(o_467a6bf0b446f87730d3,unknown).
node(n1943,supported) :- node(n1935,supported), node(n1936,supported), node(n1944,supported), node(n1937,supported).
node(n1943,refuted) :- node(n1935,refuted).
node(n1943,refuted) :- node(n1936,refuted).
node(n1943,refuted) :- node(n1944,refuted).
node(n1943,refuted) :- node(n1937,refuted).
node(n1943,unknown) :- \+ node(n1943,supported), \+ node(n1943,refuted).
node(n1946,supported) :- status(o_e9d0790131dd175ce6bb,supported).
node(n1946,refuted) :- status(o_e9d0790131dd175ce6bb,refuted).
node(n1946,unknown) :- status(o_e9d0790131dd175ce6bb,unknown).
node(n1945,supported) :- node(n1939,supported), node(n1940,supported), node(n1946,supported), node(n1941,supported).
node(n1945,refuted) :- node(n1939,refuted).
node(n1945,refuted) :- node(n1940,refuted).
node(n1945,refuted) :- node(n1946,refuted).
node(n1945,refuted) :- node(n1941,refuted).
node(n1945,unknown) :- \+ node(n1945,supported), \+ node(n1945,refuted).
node(n1942,refuted) :- node(n1943,refuted), node(n1945,refuted), node(n9,refuted).
node(n1942,supported) :- node(n1943,supported).
node(n1942,supported) :- node(n1945,supported).
node(n1942,supported) :- node(n9,supported).
node(n1942,unknown) :- \+ node(n1942,supported), \+ node(n1942,refuted).
verdict(c_112e8cd276cd98be,supported) :- node(n1942,supported).
query(verdict(c_112e8cd276cd98be,supported)).
verdict(c_112e8cd276cd98be,refuted) :- node(n1942,refuted).
query(verdict(c_112e8cd276cd98be,refuted)).
verdict(c_112e8cd276cd98be,unknown) :- node(n1942,unknown).
query(verdict(c_112e8cd276cd98be,unknown)).
node(n1949,supported) :- status(o_179679f64f422ac72616,supported).
node(n1949,refuted) :- status(o_179679f64f422ac72616,refuted).
node(n1949,unknown) :- status(o_179679f64f422ac72616,unknown).
node(n1950,supported) :- status(o_b1468347bd908ffb7f58,supported).
node(n1950,refuted) :- status(o_b1468347bd908ffb7f58,refuted).
node(n1950,unknown) :- status(o_b1468347bd908ffb7f58,unknown).
node(n1951,supported) :- status(o_22e9ead9db7eeb1571be,supported).
node(n1951,refuted) :- status(o_22e9ead9db7eeb1571be,refuted).
node(n1951,unknown) :- status(o_22e9ead9db7eeb1571be,unknown).
node(n1948,supported) :- node(n1949,supported), node(n1950,supported), node(n1951,supported).
node(n1948,refuted) :- node(n1949,refuted).
node(n1948,refuted) :- node(n1950,refuted).
node(n1948,refuted) :- node(n1951,refuted).
node(n1948,unknown) :- \+ node(n1948,supported), \+ node(n1948,refuted).
node(n1953,supported) :- status(o_c4ae29fcad8293dd32ad,supported).
node(n1953,refuted) :- status(o_c4ae29fcad8293dd32ad,refuted).
node(n1953,unknown) :- status(o_c4ae29fcad8293dd32ad,unknown).
node(n1954,supported) :- status(o_a5d49525956c8bb07c82,supported).
node(n1954,refuted) :- status(o_a5d49525956c8bb07c82,refuted).
node(n1954,unknown) :- status(o_a5d49525956c8bb07c82,unknown).
node(n1955,supported) :- status(o_7fe29d277fa55cae5fc6,supported).
node(n1955,refuted) :- status(o_7fe29d277fa55cae5fc6,refuted).
node(n1955,unknown) :- status(o_7fe29d277fa55cae5fc6,unknown).
node(n1952,supported) :- node(n1953,supported), node(n1954,supported), node(n1955,supported).
node(n1952,refuted) :- node(n1953,refuted).
node(n1952,refuted) :- node(n1954,refuted).
node(n1952,refuted) :- node(n1955,refuted).
node(n1952,unknown) :- \+ node(n1952,supported), \+ node(n1952,refuted).
node(n1947,refuted) :- node(n1948,refuted), node(n1952,refuted), node(n9,refuted).
node(n1947,supported) :- node(n1948,supported).
node(n1947,supported) :- node(n1952,supported).
node(n1947,supported) :- node(n9,supported).
node(n1947,unknown) :- \+ node(n1947,supported), \+ node(n1947,refuted).
verdict(c_07039e35351c3265,supported) :- node(n1947,supported).
query(verdict(c_07039e35351c3265,supported)).
verdict(c_07039e35351c3265,refuted) :- node(n1947,refuted).
query(verdict(c_07039e35351c3265,refuted)).
verdict(c_07039e35351c3265,unknown) :- node(n1947,unknown).
query(verdict(c_07039e35351c3265,unknown)).
node(n1958,supported) :- status(o_b6da0934c57b4722a45d,supported).
node(n1958,refuted) :- status(o_b6da0934c57b4722a45d,refuted).
node(n1958,unknown) :- status(o_b6da0934c57b4722a45d,unknown).
node(n1957,supported) :- node(n1949,supported), node(n1950,supported), node(n1958,supported), node(n1951,supported).
node(n1957,refuted) :- node(n1949,refuted).
node(n1957,refuted) :- node(n1950,refuted).
node(n1957,refuted) :- node(n1958,refuted).
node(n1957,refuted) :- node(n1951,refuted).
node(n1957,unknown) :- \+ node(n1957,supported), \+ node(n1957,refuted).
node(n1960,supported) :- status(o_01ad4330f5406c237312,supported).
node(n1960,refuted) :- status(o_01ad4330f5406c237312,refuted).
node(n1960,unknown) :- status(o_01ad4330f5406c237312,unknown).
node(n1959,supported) :- node(n1953,supported), node(n1954,supported), node(n1960,supported), node(n1955,supported).
node(n1959,refuted) :- node(n1953,refuted).
node(n1959,refuted) :- node(n1954,refuted).
node(n1959,refuted) :- node(n1960,refuted).
node(n1959,refuted) :- node(n1955,refuted).
node(n1959,unknown) :- \+ node(n1959,supported), \+ node(n1959,refuted).
node(n1956,refuted) :- node(n1957,refuted), node(n1959,refuted), node(n9,refuted).
node(n1956,supported) :- node(n1957,supported).
node(n1956,supported) :- node(n1959,supported).
node(n1956,supported) :- node(n9,supported).
node(n1956,unknown) :- \+ node(n1956,supported), \+ node(n1956,refuted).
verdict(c_34086a01205f8df5,supported) :- node(n1956,supported).
query(verdict(c_34086a01205f8df5,supported)).
verdict(c_34086a01205f8df5,refuted) :- node(n1956,refuted).
query(verdict(c_34086a01205f8df5,refuted)).
verdict(c_34086a01205f8df5,unknown) :- node(n1956,unknown).
query(verdict(c_34086a01205f8df5,unknown)).
node(n1963,supported) :- status(o_979841b6f049d5e81c68,supported).
node(n1963,refuted) :- status(o_979841b6f049d5e81c68,refuted).
node(n1963,unknown) :- status(o_979841b6f049d5e81c68,unknown).
node(n1964,supported) :- status(o_58619889581c02348863,supported).
node(n1964,refuted) :- status(o_58619889581c02348863,refuted).
node(n1964,unknown) :- status(o_58619889581c02348863,unknown).
node(n1965,supported) :- status(o_15c705588fdbdd88fce7,supported).
node(n1965,refuted) :- status(o_15c705588fdbdd88fce7,refuted).
node(n1965,unknown) :- status(o_15c705588fdbdd88fce7,unknown).
node(n1962,supported) :- node(n1963,supported), node(n1964,supported), node(n1965,supported).
node(n1962,refuted) :- node(n1963,refuted).
node(n1962,refuted) :- node(n1964,refuted).
node(n1962,refuted) :- node(n1965,refuted).
node(n1962,unknown) :- \+ node(n1962,supported), \+ node(n1962,refuted).
node(n1967,supported) :- status(o_2dc8ba914e1f52414287,supported).
node(n1967,refuted) :- status(o_2dc8ba914e1f52414287,refuted).
node(n1967,unknown) :- status(o_2dc8ba914e1f52414287,unknown).
node(n1968,supported) :- status(o_f66e167540304469dcdb,supported).
node(n1968,refuted) :- status(o_f66e167540304469dcdb,refuted).
node(n1968,unknown) :- status(o_f66e167540304469dcdb,unknown).
node(n1969,supported) :- status(o_006408ef8c0395cba831,supported).
node(n1969,refuted) :- status(o_006408ef8c0395cba831,refuted).
node(n1969,unknown) :- status(o_006408ef8c0395cba831,unknown).
node(n1966,supported) :- node(n1967,supported), node(n1968,supported), node(n1969,supported).
node(n1966,refuted) :- node(n1967,refuted).
node(n1966,refuted) :- node(n1968,refuted).
node(n1966,refuted) :- node(n1969,refuted).
node(n1966,unknown) :- \+ node(n1966,supported), \+ node(n1966,refuted).
node(n1961,refuted) :- node(n1962,refuted), node(n1966,refuted), node(n9,refuted).
node(n1961,supported) :- node(n1962,supported).
node(n1961,supported) :- node(n1966,supported).
node(n1961,supported) :- node(n9,supported).
node(n1961,unknown) :- \+ node(n1961,supported), \+ node(n1961,refuted).
verdict(c_c95a5b3fd54ac065,supported) :- node(n1961,supported).
query(verdict(c_c95a5b3fd54ac065,supported)).
verdict(c_c95a5b3fd54ac065,refuted) :- node(n1961,refuted).
query(verdict(c_c95a5b3fd54ac065,refuted)).
verdict(c_c95a5b3fd54ac065,unknown) :- node(n1961,unknown).
query(verdict(c_c95a5b3fd54ac065,unknown)).
node(n1972,supported) :- status(o_2766f5fcbb03d17fa84f,supported).
node(n1972,refuted) :- status(o_2766f5fcbb03d17fa84f,refuted).
node(n1972,unknown) :- status(o_2766f5fcbb03d17fa84f,unknown).
node(n1971,supported) :- node(n1963,supported), node(n1964,supported), node(n1972,supported), node(n1965,supported).
node(n1971,refuted) :- node(n1963,refuted).
node(n1971,refuted) :- node(n1964,refuted).
node(n1971,refuted) :- node(n1972,refuted).
node(n1971,refuted) :- node(n1965,refuted).
node(n1971,unknown) :- \+ node(n1971,supported), \+ node(n1971,refuted).
node(n1974,supported) :- status(o_6e30eb83c838330d2c4b,supported).
node(n1974,refuted) :- status(o_6e30eb83c838330d2c4b,refuted).
node(n1974,unknown) :- status(o_6e30eb83c838330d2c4b,unknown).
node(n1973,supported) :- node(n1967,supported), node(n1968,supported), node(n1974,supported), node(n1969,supported).
node(n1973,refuted) :- node(n1967,refuted).
node(n1973,refuted) :- node(n1968,refuted).
node(n1973,refuted) :- node(n1974,refuted).
node(n1973,refuted) :- node(n1969,refuted).
node(n1973,unknown) :- \+ node(n1973,supported), \+ node(n1973,refuted).
node(n1970,refuted) :- node(n1971,refuted), node(n1973,refuted), node(n9,refuted).
node(n1970,supported) :- node(n1971,supported).
node(n1970,supported) :- node(n1973,supported).
node(n1970,supported) :- node(n9,supported).
node(n1970,unknown) :- \+ node(n1970,supported), \+ node(n1970,refuted).
verdict(c_c16d1f9c72790245,supported) :- node(n1970,supported).
query(verdict(c_c16d1f9c72790245,supported)).
verdict(c_c16d1f9c72790245,refuted) :- node(n1970,refuted).
query(verdict(c_c16d1f9c72790245,refuted)).
verdict(c_c16d1f9c72790245,unknown) :- node(n1970,unknown).
query(verdict(c_c16d1f9c72790245,unknown)).
node(n1977,supported) :- status(o_9691d99a8c76e81bf837,supported).
node(n1977,refuted) :- status(o_9691d99a8c76e81bf837,refuted).
node(n1977,unknown) :- status(o_9691d99a8c76e81bf837,unknown).
node(n1978,supported) :- status(o_b9b8fd2fae99ad091ba6,supported).
node(n1978,refuted) :- status(o_b9b8fd2fae99ad091ba6,refuted).
node(n1978,unknown) :- status(o_b9b8fd2fae99ad091ba6,unknown).
node(n1979,supported) :- status(o_e9bbb82a77438c525095,supported).
node(n1979,refuted) :- status(o_e9bbb82a77438c525095,refuted).
node(n1979,unknown) :- status(o_e9bbb82a77438c525095,unknown).
node(n1976,supported) :- node(n1977,supported), node(n1978,supported), node(n1979,supported).
node(n1976,refuted) :- node(n1977,refuted).
node(n1976,refuted) :- node(n1978,refuted).
node(n1976,refuted) :- node(n1979,refuted).
node(n1976,unknown) :- \+ node(n1976,supported), \+ node(n1976,refuted).
node(n1981,supported) :- status(o_5c632d30d38144eed6c2,supported).
node(n1981,refuted) :- status(o_5c632d30d38144eed6c2,refuted).
node(n1981,unknown) :- status(o_5c632d30d38144eed6c2,unknown).
node(n1982,supported) :- status(o_8a018336087166fa1fcb,supported).
node(n1982,refuted) :- status(o_8a018336087166fa1fcb,refuted).
node(n1982,unknown) :- status(o_8a018336087166fa1fcb,unknown).
node(n1983,supported) :- status(o_6fd10b2ac9221a9ab4a7,supported).
node(n1983,refuted) :- status(o_6fd10b2ac9221a9ab4a7,refuted).
node(n1983,unknown) :- status(o_6fd10b2ac9221a9ab4a7,unknown).
node(n1980,supported) :- node(n1981,supported), node(n1982,supported), node(n1983,supported).
node(n1980,refuted) :- node(n1981,refuted).
node(n1980,refuted) :- node(n1982,refuted).
node(n1980,refuted) :- node(n1983,refuted).
node(n1980,unknown) :- \+ node(n1980,supported), \+ node(n1980,refuted).
node(n1975,refuted) :- node(n1976,refuted), node(n1980,refuted), node(n9,refuted).
node(n1975,supported) :- node(n1976,supported).
node(n1975,supported) :- node(n1980,supported).
node(n1975,supported) :- node(n9,supported).
node(n1975,unknown) :- \+ node(n1975,supported), \+ node(n1975,refuted).
verdict(c_97ba3c061f472092,supported) :- node(n1975,supported).
query(verdict(c_97ba3c061f472092,supported)).
verdict(c_97ba3c061f472092,refuted) :- node(n1975,refuted).
query(verdict(c_97ba3c061f472092,refuted)).
verdict(c_97ba3c061f472092,unknown) :- node(n1975,unknown).
query(verdict(c_97ba3c061f472092,unknown)).
node(n1986,supported) :- status(o_b375d832440f77cc9142,supported).
node(n1986,refuted) :- status(o_b375d832440f77cc9142,refuted).
node(n1986,unknown) :- status(o_b375d832440f77cc9142,unknown).
node(n1985,supported) :- node(n1977,supported), node(n1978,supported), node(n1986,supported), node(n1979,supported).
node(n1985,refuted) :- node(n1977,refuted).
node(n1985,refuted) :- node(n1978,refuted).
node(n1985,refuted) :- node(n1986,refuted).
node(n1985,refuted) :- node(n1979,refuted).
node(n1985,unknown) :- \+ node(n1985,supported), \+ node(n1985,refuted).
node(n1988,supported) :- status(o_070ddd3fc6f996b4b5de,supported).
node(n1988,refuted) :- status(o_070ddd3fc6f996b4b5de,refuted).
node(n1988,unknown) :- status(o_070ddd3fc6f996b4b5de,unknown).
node(n1987,supported) :- node(n1981,supported), node(n1982,supported), node(n1988,supported), node(n1983,supported).
node(n1987,refuted) :- node(n1981,refuted).
node(n1987,refuted) :- node(n1982,refuted).
node(n1987,refuted) :- node(n1988,refuted).
node(n1987,refuted) :- node(n1983,refuted).
node(n1987,unknown) :- \+ node(n1987,supported), \+ node(n1987,refuted).
node(n1984,refuted) :- node(n1985,refuted), node(n1987,refuted), node(n9,refuted).
node(n1984,supported) :- node(n1985,supported).
node(n1984,supported) :- node(n1987,supported).
node(n1984,supported) :- node(n9,supported).
node(n1984,unknown) :- \+ node(n1984,supported), \+ node(n1984,refuted).
verdict(c_4ad9ca8d1341ab7d,supported) :- node(n1984,supported).
query(verdict(c_4ad9ca8d1341ab7d,supported)).
verdict(c_4ad9ca8d1341ab7d,refuted) :- node(n1984,refuted).
query(verdict(c_4ad9ca8d1341ab7d,refuted)).
verdict(c_4ad9ca8d1341ab7d,unknown) :- node(n1984,unknown).
query(verdict(c_4ad9ca8d1341ab7d,unknown)).
node(n1991,supported) :- status(o_50ead26e45ebd4c332dc,supported).
node(n1991,refuted) :- status(o_50ead26e45ebd4c332dc,refuted).
node(n1991,unknown) :- status(o_50ead26e45ebd4c332dc,unknown).
node(n1992,supported) :- status(o_d6f980618c081bea65ce,supported).
node(n1992,refuted) :- status(o_d6f980618c081bea65ce,refuted).
node(n1992,unknown) :- status(o_d6f980618c081bea65ce,unknown).
node(n1993,supported) :- status(o_4e3cfe1e783f7853fcf4,supported).
node(n1993,refuted) :- status(o_4e3cfe1e783f7853fcf4,refuted).
node(n1993,unknown) :- status(o_4e3cfe1e783f7853fcf4,unknown).
node(n1990,supported) :- node(n1991,supported), node(n1992,supported), node(n1993,supported).
node(n1990,refuted) :- node(n1991,refuted).
node(n1990,refuted) :- node(n1992,refuted).
node(n1990,refuted) :- node(n1993,refuted).
node(n1990,unknown) :- \+ node(n1990,supported), \+ node(n1990,refuted).
node(n1995,supported) :- status(o_547f458e637c4c57d2fc,supported).
node(n1995,refuted) :- status(o_547f458e637c4c57d2fc,refuted).
node(n1995,unknown) :- status(o_547f458e637c4c57d2fc,unknown).
node(n1996,supported) :- status(o_9e597c41be33369f1ca2,supported).
node(n1996,refuted) :- status(o_9e597c41be33369f1ca2,refuted).
node(n1996,unknown) :- status(o_9e597c41be33369f1ca2,unknown).
node(n1997,supported) :- status(o_23e3f5736d6b690880ce,supported).
node(n1997,refuted) :- status(o_23e3f5736d6b690880ce,refuted).
node(n1997,unknown) :- status(o_23e3f5736d6b690880ce,unknown).
node(n1994,supported) :- node(n1995,supported), node(n1996,supported), node(n1997,supported).
node(n1994,refuted) :- node(n1995,refuted).
node(n1994,refuted) :- node(n1996,refuted).
node(n1994,refuted) :- node(n1997,refuted).
node(n1994,unknown) :- \+ node(n1994,supported), \+ node(n1994,refuted).
node(n1989,refuted) :- node(n1990,refuted), node(n1994,refuted), node(n9,refuted).
node(n1989,supported) :- node(n1990,supported).
node(n1989,supported) :- node(n1994,supported).
node(n1989,supported) :- node(n9,supported).
node(n1989,unknown) :- \+ node(n1989,supported), \+ node(n1989,refuted).
verdict(c_94f2fd80e19bf408,supported) :- node(n1989,supported).
query(verdict(c_94f2fd80e19bf408,supported)).
verdict(c_94f2fd80e19bf408,refuted) :- node(n1989,refuted).
query(verdict(c_94f2fd80e19bf408,refuted)).
verdict(c_94f2fd80e19bf408,unknown) :- node(n1989,unknown).
query(verdict(c_94f2fd80e19bf408,unknown)).
node(n2000,supported) :- status(o_fc2a7d9023c3179aeab6,supported).
node(n2000,refuted) :- status(o_fc2a7d9023c3179aeab6,refuted).
node(n2000,unknown) :- status(o_fc2a7d9023c3179aeab6,unknown).
node(n1999,supported) :- node(n1991,supported), node(n1992,supported), node(n2000,supported), node(n1993,supported).
node(n1999,refuted) :- node(n1991,refuted).
node(n1999,refuted) :- node(n1992,refuted).
node(n1999,refuted) :- node(n2000,refuted).
node(n1999,refuted) :- node(n1993,refuted).
node(n1999,unknown) :- \+ node(n1999,supported), \+ node(n1999,refuted).
node(n2002,supported) :- status(o_f8947ca704c3a19cd4a6,supported).
node(n2002,refuted) :- status(o_f8947ca704c3a19cd4a6,refuted).
node(n2002,unknown) :- status(o_f8947ca704c3a19cd4a6,unknown).
node(n2001,supported) :- node(n1995,supported), node(n1996,supported), node(n2002,supported), node(n1997,supported).
node(n2001,refuted) :- node(n1995,refuted).
node(n2001,refuted) :- node(n1996,refuted).
node(n2001,refuted) :- node(n2002,refuted).
node(n2001,refuted) :- node(n1997,refuted).
node(n2001,unknown) :- \+ node(n2001,supported), \+ node(n2001,refuted).
node(n1998,refuted) :- node(n1999,refuted), node(n2001,refuted), node(n9,refuted).
node(n1998,supported) :- node(n1999,supported).
node(n1998,supported) :- node(n2001,supported).
node(n1998,supported) :- node(n9,supported).
node(n1998,unknown) :- \+ node(n1998,supported), \+ node(n1998,refuted).
verdict(c_652c3816b95fc268,supported) :- node(n1998,supported).
query(verdict(c_652c3816b95fc268,supported)).
verdict(c_652c3816b95fc268,refuted) :- node(n1998,refuted).
query(verdict(c_652c3816b95fc268,refuted)).
verdict(c_652c3816b95fc268,unknown) :- node(n1998,unknown).
query(verdict(c_652c3816b95fc268,unknown)).
node(n2005,supported) :- status(o_380c40bfe3409b206be3,supported).
node(n2005,refuted) :- status(o_380c40bfe3409b206be3,refuted).
node(n2005,unknown) :- status(o_380c40bfe3409b206be3,unknown).
node(n2006,supported) :- status(o_9fb586b2b673b5832def,supported).
node(n2006,refuted) :- status(o_9fb586b2b673b5832def,refuted).
node(n2006,unknown) :- status(o_9fb586b2b673b5832def,unknown).
node(n2007,supported) :- status(o_ffa8445aaa77c1e56ac2,supported).
node(n2007,refuted) :- status(o_ffa8445aaa77c1e56ac2,refuted).
node(n2007,unknown) :- status(o_ffa8445aaa77c1e56ac2,unknown).
node(n2004,supported) :- node(n2005,supported), node(n2006,supported), node(n2007,supported).
node(n2004,refuted) :- node(n2005,refuted).
node(n2004,refuted) :- node(n2006,refuted).
node(n2004,refuted) :- node(n2007,refuted).
node(n2004,unknown) :- \+ node(n2004,supported), \+ node(n2004,refuted).
node(n2009,supported) :- status(o_2601b953080415fcfe17,supported).
node(n2009,refuted) :- status(o_2601b953080415fcfe17,refuted).
node(n2009,unknown) :- status(o_2601b953080415fcfe17,unknown).
node(n2010,supported) :- status(o_97a0c04e32f0f1927307,supported).
node(n2010,refuted) :- status(o_97a0c04e32f0f1927307,refuted).
node(n2010,unknown) :- status(o_97a0c04e32f0f1927307,unknown).
node(n2011,supported) :- status(o_492292701bc2126d5a87,supported).
node(n2011,refuted) :- status(o_492292701bc2126d5a87,refuted).
node(n2011,unknown) :- status(o_492292701bc2126d5a87,unknown).
node(n2008,supported) :- node(n2009,supported), node(n2010,supported), node(n2011,supported).
node(n2008,refuted) :- node(n2009,refuted).
node(n2008,refuted) :- node(n2010,refuted).
node(n2008,refuted) :- node(n2011,refuted).
node(n2008,unknown) :- \+ node(n2008,supported), \+ node(n2008,refuted).
node(n2003,refuted) :- node(n2004,refuted), node(n2008,refuted), node(n9,refuted).
node(n2003,supported) :- node(n2004,supported).
node(n2003,supported) :- node(n2008,supported).
node(n2003,supported) :- node(n9,supported).
node(n2003,unknown) :- \+ node(n2003,supported), \+ node(n2003,refuted).
verdict(c_bd56352383b9ea5f,supported) :- node(n2003,supported).
query(verdict(c_bd56352383b9ea5f,supported)).
verdict(c_bd56352383b9ea5f,refuted) :- node(n2003,refuted).
query(verdict(c_bd56352383b9ea5f,refuted)).
verdict(c_bd56352383b9ea5f,unknown) :- node(n2003,unknown).
query(verdict(c_bd56352383b9ea5f,unknown)).
node(n2014,supported) :- status(o_39005afb97f8a829d7d1,supported).
node(n2014,refuted) :- status(o_39005afb97f8a829d7d1,refuted).
node(n2014,unknown) :- status(o_39005afb97f8a829d7d1,unknown).
node(n2013,supported) :- node(n2005,supported), node(n2006,supported), node(n2014,supported), node(n2007,supported).
node(n2013,refuted) :- node(n2005,refuted).
node(n2013,refuted) :- node(n2006,refuted).
node(n2013,refuted) :- node(n2014,refuted).
node(n2013,refuted) :- node(n2007,refuted).
node(n2013,unknown) :- \+ node(n2013,supported), \+ node(n2013,refuted).
node(n2016,supported) :- status(o_0bf97da4374af873874f,supported).
node(n2016,refuted) :- status(o_0bf97da4374af873874f,refuted).
node(n2016,unknown) :- status(o_0bf97da4374af873874f,unknown).
node(n2015,supported) :- node(n2009,supported), node(n2010,supported), node(n2016,supported), node(n2011,supported).
node(n2015,refuted) :- node(n2009,refuted).
node(n2015,refuted) :- node(n2010,refuted).
node(n2015,refuted) :- node(n2016,refuted).
node(n2015,refuted) :- node(n2011,refuted).
node(n2015,unknown) :- \+ node(n2015,supported), \+ node(n2015,refuted).
node(n2012,refuted) :- node(n2013,refuted), node(n2015,refuted), node(n9,refuted).
node(n2012,supported) :- node(n2013,supported).
node(n2012,supported) :- node(n2015,supported).
node(n2012,supported) :- node(n9,supported).
node(n2012,unknown) :- \+ node(n2012,supported), \+ node(n2012,refuted).
verdict(c_1a60252e3166d471,supported) :- node(n2012,supported).
query(verdict(c_1a60252e3166d471,supported)).
verdict(c_1a60252e3166d471,refuted) :- node(n2012,refuted).
query(verdict(c_1a60252e3166d471,refuted)).
verdict(c_1a60252e3166d471,unknown) :- node(n2012,unknown).
query(verdict(c_1a60252e3166d471,unknown)).
node(n2019,supported) :- status(o_ba1ad09e558610f37c26,supported).
node(n2019,refuted) :- status(o_ba1ad09e558610f37c26,refuted).
node(n2019,unknown) :- status(o_ba1ad09e558610f37c26,unknown).
node(n2020,supported) :- status(o_083cbd9d5b0dc69706a0,supported).
node(n2020,refuted) :- status(o_083cbd9d5b0dc69706a0,refuted).
node(n2020,unknown) :- status(o_083cbd9d5b0dc69706a0,unknown).
node(n2021,supported) :- status(o_84faafa5cb57bea66a95,supported).
node(n2021,refuted) :- status(o_84faafa5cb57bea66a95,refuted).
node(n2021,unknown) :- status(o_84faafa5cb57bea66a95,unknown).
node(n2018,supported) :- node(n2019,supported), node(n2020,supported), node(n2021,supported).
node(n2018,refuted) :- node(n2019,refuted).
node(n2018,refuted) :- node(n2020,refuted).
node(n2018,refuted) :- node(n2021,refuted).
node(n2018,unknown) :- \+ node(n2018,supported), \+ node(n2018,refuted).
node(n2023,supported) :- status(o_cacee04898d5fefa5d0e,supported).
node(n2023,refuted) :- status(o_cacee04898d5fefa5d0e,refuted).
node(n2023,unknown) :- status(o_cacee04898d5fefa5d0e,unknown).
node(n2024,supported) :- status(o_94899b7b31651c05575e,supported).
node(n2024,refuted) :- status(o_94899b7b31651c05575e,refuted).
node(n2024,unknown) :- status(o_94899b7b31651c05575e,unknown).
node(n2025,supported) :- status(o_e30c248f492214e2b81a,supported).
node(n2025,refuted) :- status(o_e30c248f492214e2b81a,refuted).
node(n2025,unknown) :- status(o_e30c248f492214e2b81a,unknown).
node(n2022,supported) :- node(n2023,supported), node(n2024,supported), node(n2025,supported).
node(n2022,refuted) :- node(n2023,refuted).
node(n2022,refuted) :- node(n2024,refuted).
node(n2022,refuted) :- node(n2025,refuted).
node(n2022,unknown) :- \+ node(n2022,supported), \+ node(n2022,refuted).
node(n2017,refuted) :- node(n2018,refuted), node(n2022,refuted), node(n9,refuted).
node(n2017,supported) :- node(n2018,supported).
node(n2017,supported) :- node(n2022,supported).
node(n2017,supported) :- node(n9,supported).
node(n2017,unknown) :- \+ node(n2017,supported), \+ node(n2017,refuted).
verdict(c_719d32a9eaf9e26f,supported) :- node(n2017,supported).
query(verdict(c_719d32a9eaf9e26f,supported)).
verdict(c_719d32a9eaf9e26f,refuted) :- node(n2017,refuted).
query(verdict(c_719d32a9eaf9e26f,refuted)).
verdict(c_719d32a9eaf9e26f,unknown) :- node(n2017,unknown).
query(verdict(c_719d32a9eaf9e26f,unknown)).
node(n2028,supported) :- status(o_1656c3e7ffe312946de8,supported).
node(n2028,refuted) :- status(o_1656c3e7ffe312946de8,refuted).
node(n2028,unknown) :- status(o_1656c3e7ffe312946de8,unknown).
node(n2027,supported) :- node(n2019,supported), node(n2020,supported), node(n2028,supported), node(n2021,supported).
node(n2027,refuted) :- node(n2019,refuted).
node(n2027,refuted) :- node(n2020,refuted).
node(n2027,refuted) :- node(n2028,refuted).
node(n2027,refuted) :- node(n2021,refuted).
node(n2027,unknown) :- \+ node(n2027,supported), \+ node(n2027,refuted).
node(n2030,supported) :- status(o_5ea03014ecb5e885f832,supported).
node(n2030,refuted) :- status(o_5ea03014ecb5e885f832,refuted).
node(n2030,unknown) :- status(o_5ea03014ecb5e885f832,unknown).
node(n2029,supported) :- node(n2023,supported), node(n2024,supported), node(n2030,supported), node(n2025,supported).
node(n2029,refuted) :- node(n2023,refuted).
node(n2029,refuted) :- node(n2024,refuted).
node(n2029,refuted) :- node(n2030,refuted).
node(n2029,refuted) :- node(n2025,refuted).
node(n2029,unknown) :- \+ node(n2029,supported), \+ node(n2029,refuted).
node(n2026,refuted) :- node(n2027,refuted), node(n2029,refuted), node(n9,refuted).
node(n2026,supported) :- node(n2027,supported).
node(n2026,supported) :- node(n2029,supported).
node(n2026,supported) :- node(n9,supported).
node(n2026,unknown) :- \+ node(n2026,supported), \+ node(n2026,refuted).
verdict(c_b1ce33c9cdbd5de7,supported) :- node(n2026,supported).
query(verdict(c_b1ce33c9cdbd5de7,supported)).
verdict(c_b1ce33c9cdbd5de7,refuted) :- node(n2026,refuted).
query(verdict(c_b1ce33c9cdbd5de7,refuted)).
verdict(c_b1ce33c9cdbd5de7,unknown) :- node(n2026,unknown).
query(verdict(c_b1ce33c9cdbd5de7,unknown)).
node(n2033,supported) :- status(o_df617d8d384572a26b43,supported).
node(n2033,refuted) :- status(o_df617d8d384572a26b43,refuted).
node(n2033,unknown) :- status(o_df617d8d384572a26b43,unknown).
node(n2034,supported) :- status(o_cbce5f11faab4a46ecad,supported).
node(n2034,refuted) :- status(o_cbce5f11faab4a46ecad,refuted).
node(n2034,unknown) :- status(o_cbce5f11faab4a46ecad,unknown).
node(n2035,supported) :- status(o_9c0bc07f26c7673adcbd,supported).
node(n2035,refuted) :- status(o_9c0bc07f26c7673adcbd,refuted).
node(n2035,unknown) :- status(o_9c0bc07f26c7673adcbd,unknown).
node(n2032,supported) :- node(n2033,supported), node(n2034,supported), node(n2035,supported).
node(n2032,refuted) :- node(n2033,refuted).
node(n2032,refuted) :- node(n2034,refuted).
node(n2032,refuted) :- node(n2035,refuted).
node(n2032,unknown) :- \+ node(n2032,supported), \+ node(n2032,refuted).
node(n2037,supported) :- status(o_618616a7183903773cb2,supported).
node(n2037,refuted) :- status(o_618616a7183903773cb2,refuted).
node(n2037,unknown) :- status(o_618616a7183903773cb2,unknown).
node(n2038,supported) :- status(o_5f750d902446ac7d3632,supported).
node(n2038,refuted) :- status(o_5f750d902446ac7d3632,refuted).
node(n2038,unknown) :- status(o_5f750d902446ac7d3632,unknown).
node(n2039,supported) :- status(o_b374fb746bec73cde178,supported).
node(n2039,refuted) :- status(o_b374fb746bec73cde178,refuted).
node(n2039,unknown) :- status(o_b374fb746bec73cde178,unknown).
node(n2036,supported) :- node(n2037,supported), node(n2038,supported), node(n2039,supported).
node(n2036,refuted) :- node(n2037,refuted).
node(n2036,refuted) :- node(n2038,refuted).
node(n2036,refuted) :- node(n2039,refuted).
node(n2036,unknown) :- \+ node(n2036,supported), \+ node(n2036,refuted).
node(n2031,refuted) :- node(n2032,refuted), node(n2036,refuted), node(n9,refuted).
node(n2031,supported) :- node(n2032,supported).
node(n2031,supported) :- node(n2036,supported).
node(n2031,supported) :- node(n9,supported).
node(n2031,unknown) :- \+ node(n2031,supported), \+ node(n2031,refuted).
verdict(c_7694f5bb8c1cb065,supported) :- node(n2031,supported).
query(verdict(c_7694f5bb8c1cb065,supported)).
verdict(c_7694f5bb8c1cb065,refuted) :- node(n2031,refuted).
query(verdict(c_7694f5bb8c1cb065,refuted)).
verdict(c_7694f5bb8c1cb065,unknown) :- node(n2031,unknown).
query(verdict(c_7694f5bb8c1cb065,unknown)).
node(n2042,supported) :- status(o_5985f74ffd642d018f0c,supported).
node(n2042,refuted) :- status(o_5985f74ffd642d018f0c,refuted).
node(n2042,unknown) :- status(o_5985f74ffd642d018f0c,unknown).
node(n2041,supported) :- node(n2033,supported), node(n2034,supported), node(n2042,supported), node(n2035,supported).
node(n2041,refuted) :- node(n2033,refuted).
node(n2041,refuted) :- node(n2034,refuted).
node(n2041,refuted) :- node(n2042,refuted).
node(n2041,refuted) :- node(n2035,refuted).
node(n2041,unknown) :- \+ node(n2041,supported), \+ node(n2041,refuted).
node(n2044,supported) :- status(o_f4abca3ab03b7732f812,supported).
node(n2044,refuted) :- status(o_f4abca3ab03b7732f812,refuted).
node(n2044,unknown) :- status(o_f4abca3ab03b7732f812,unknown).
node(n2043,supported) :- node(n2037,supported), node(n2038,supported), node(n2044,supported), node(n2039,supported).
node(n2043,refuted) :- node(n2037,refuted).
node(n2043,refuted) :- node(n2038,refuted).
node(n2043,refuted) :- node(n2044,refuted).
node(n2043,refuted) :- node(n2039,refuted).
node(n2043,unknown) :- \+ node(n2043,supported), \+ node(n2043,refuted).
node(n2040,refuted) :- node(n2041,refuted), node(n2043,refuted), node(n9,refuted).
node(n2040,supported) :- node(n2041,supported).
node(n2040,supported) :- node(n2043,supported).
node(n2040,supported) :- node(n9,supported).
node(n2040,unknown) :- \+ node(n2040,supported), \+ node(n2040,refuted).
verdict(c_1695b09b01d52a92,supported) :- node(n2040,supported).
query(verdict(c_1695b09b01d52a92,supported)).
verdict(c_1695b09b01d52a92,refuted) :- node(n2040,refuted).
query(verdict(c_1695b09b01d52a92,refuted)).
verdict(c_1695b09b01d52a92,unknown) :- node(n2040,unknown).
query(verdict(c_1695b09b01d52a92,unknown)).
node(n2047,supported) :- status(o_cf8b8d0103995873b1e3,supported).
node(n2047,refuted) :- status(o_cf8b8d0103995873b1e3,refuted).
node(n2047,unknown) :- status(o_cf8b8d0103995873b1e3,unknown).
node(n2048,supported) :- status(o_f6181481a4896d3a6bd4,supported).
node(n2048,refuted) :- status(o_f6181481a4896d3a6bd4,refuted).
node(n2048,unknown) :- status(o_f6181481a4896d3a6bd4,unknown).
node(n2049,supported) :- status(o_3b5220bffac1abcbb055,supported).
node(n2049,refuted) :- status(o_3b5220bffac1abcbb055,refuted).
node(n2049,unknown) :- status(o_3b5220bffac1abcbb055,unknown).
node(n2046,supported) :- node(n2047,supported), node(n2048,supported), node(n2049,supported).
node(n2046,refuted) :- node(n2047,refuted).
node(n2046,refuted) :- node(n2048,refuted).
node(n2046,refuted) :- node(n2049,refuted).
node(n2046,unknown) :- \+ node(n2046,supported), \+ node(n2046,refuted).
node(n2051,supported) :- status(o_8279128e56b6913bde0e,supported).
node(n2051,refuted) :- status(o_8279128e56b6913bde0e,refuted).
node(n2051,unknown) :- status(o_8279128e56b6913bde0e,unknown).
node(n2052,supported) :- status(o_4c204b82679f5c16048c,supported).
node(n2052,refuted) :- status(o_4c204b82679f5c16048c,refuted).
node(n2052,unknown) :- status(o_4c204b82679f5c16048c,unknown).
node(n2053,supported) :- status(o_7ab054b366cbc1de9ae0,supported).
node(n2053,refuted) :- status(o_7ab054b366cbc1de9ae0,refuted).
node(n2053,unknown) :- status(o_7ab054b366cbc1de9ae0,unknown).
node(n2050,supported) :- node(n2051,supported), node(n2052,supported), node(n2053,supported).
node(n2050,refuted) :- node(n2051,refuted).
node(n2050,refuted) :- node(n2052,refuted).
node(n2050,refuted) :- node(n2053,refuted).
node(n2050,unknown) :- \+ node(n2050,supported), \+ node(n2050,refuted).
node(n2045,refuted) :- node(n2046,refuted), node(n2050,refuted), node(n9,refuted).
node(n2045,supported) :- node(n2046,supported).
node(n2045,supported) :- node(n2050,supported).
node(n2045,supported) :- node(n9,supported).
node(n2045,unknown) :- \+ node(n2045,supported), \+ node(n2045,refuted).
verdict(c_1192b9cfd7539bf1,supported) :- node(n2045,supported).
query(verdict(c_1192b9cfd7539bf1,supported)).
verdict(c_1192b9cfd7539bf1,refuted) :- node(n2045,refuted).
query(verdict(c_1192b9cfd7539bf1,refuted)).
verdict(c_1192b9cfd7539bf1,unknown) :- node(n2045,unknown).
query(verdict(c_1192b9cfd7539bf1,unknown)).
node(n2056,supported) :- status(o_7596a40616fd56b8ea9e,supported).
node(n2056,refuted) :- status(o_7596a40616fd56b8ea9e,refuted).
node(n2056,unknown) :- status(o_7596a40616fd56b8ea9e,unknown).
node(n2055,supported) :- node(n2047,supported), node(n2048,supported), node(n2056,supported), node(n2049,supported).
node(n2055,refuted) :- node(n2047,refuted).
node(n2055,refuted) :- node(n2048,refuted).
node(n2055,refuted) :- node(n2056,refuted).
node(n2055,refuted) :- node(n2049,refuted).
node(n2055,unknown) :- \+ node(n2055,supported), \+ node(n2055,refuted).
node(n2058,supported) :- status(o_5b06b30206d25196f22d,supported).
node(n2058,refuted) :- status(o_5b06b30206d25196f22d,refuted).
node(n2058,unknown) :- status(o_5b06b30206d25196f22d,unknown).
node(n2057,supported) :- node(n2051,supported), node(n2052,supported), node(n2058,supported), node(n2053,supported).
node(n2057,refuted) :- node(n2051,refuted).
node(n2057,refuted) :- node(n2052,refuted).
node(n2057,refuted) :- node(n2058,refuted).
node(n2057,refuted) :- node(n2053,refuted).
node(n2057,unknown) :- \+ node(n2057,supported), \+ node(n2057,refuted).
node(n2054,refuted) :- node(n2055,refuted), node(n2057,refuted), node(n9,refuted).
node(n2054,supported) :- node(n2055,supported).
node(n2054,supported) :- node(n2057,supported).
node(n2054,supported) :- node(n9,supported).
node(n2054,unknown) :- \+ node(n2054,supported), \+ node(n2054,refuted).
verdict(c_42af9ac069689865,supported) :- node(n2054,supported).
query(verdict(c_42af9ac069689865,supported)).
verdict(c_42af9ac069689865,refuted) :- node(n2054,refuted).
query(verdict(c_42af9ac069689865,refuted)).
verdict(c_42af9ac069689865,unknown) :- node(n2054,unknown).
query(verdict(c_42af9ac069689865,unknown)).
node(n2061,supported) :- status(o_c2ebff65bcdfa7e88354,supported).
node(n2061,refuted) :- status(o_c2ebff65bcdfa7e88354,refuted).
node(n2061,unknown) :- status(o_c2ebff65bcdfa7e88354,unknown).
node(n2062,supported) :- status(o_10de2c256708a7718cf7,supported).
node(n2062,refuted) :- status(o_10de2c256708a7718cf7,refuted).
node(n2062,unknown) :- status(o_10de2c256708a7718cf7,unknown).
node(n2063,supported) :- status(o_6498afbe5c01020df025,supported).
node(n2063,refuted) :- status(o_6498afbe5c01020df025,refuted).
node(n2063,unknown) :- status(o_6498afbe5c01020df025,unknown).
node(n2060,supported) :- node(n2061,supported), node(n2062,supported), node(n2063,supported).
node(n2060,refuted) :- node(n2061,refuted).
node(n2060,refuted) :- node(n2062,refuted).
node(n2060,refuted) :- node(n2063,refuted).
node(n2060,unknown) :- \+ node(n2060,supported), \+ node(n2060,refuted).
node(n2065,supported) :- status(o_f3badbe5371d1a6eaf14,supported).
node(n2065,refuted) :- status(o_f3badbe5371d1a6eaf14,refuted).
node(n2065,unknown) :- status(o_f3badbe5371d1a6eaf14,unknown).
node(n2066,supported) :- status(o_2a34f8118e578ebd1bca,supported).
node(n2066,refuted) :- status(o_2a34f8118e578ebd1bca,refuted).
node(n2066,unknown) :- status(o_2a34f8118e578ebd1bca,unknown).
node(n2067,supported) :- status(o_8afa94d64229ee7194e7,supported).
node(n2067,refuted) :- status(o_8afa94d64229ee7194e7,refuted).
node(n2067,unknown) :- status(o_8afa94d64229ee7194e7,unknown).
node(n2064,supported) :- node(n2065,supported), node(n2066,supported), node(n2067,supported).
node(n2064,refuted) :- node(n2065,refuted).
node(n2064,refuted) :- node(n2066,refuted).
node(n2064,refuted) :- node(n2067,refuted).
node(n2064,unknown) :- \+ node(n2064,supported), \+ node(n2064,refuted).
node(n2059,refuted) :- node(n2060,refuted), node(n2064,refuted), node(n9,refuted).
node(n2059,supported) :- node(n2060,supported).
node(n2059,supported) :- node(n2064,supported).
node(n2059,supported) :- node(n9,supported).
node(n2059,unknown) :- \+ node(n2059,supported), \+ node(n2059,refuted).
verdict(c_c897b2a79a9ec21a,supported) :- node(n2059,supported).
query(verdict(c_c897b2a79a9ec21a,supported)).
verdict(c_c897b2a79a9ec21a,refuted) :- node(n2059,refuted).
query(verdict(c_c897b2a79a9ec21a,refuted)).
verdict(c_c897b2a79a9ec21a,unknown) :- node(n2059,unknown).
query(verdict(c_c897b2a79a9ec21a,unknown)).
node(n2070,supported) :- status(o_0bcdc91913f2c7419c4f,supported).
node(n2070,refuted) :- status(o_0bcdc91913f2c7419c4f,refuted).
node(n2070,unknown) :- status(o_0bcdc91913f2c7419c4f,unknown).
node(n2069,supported) :- node(n2061,supported), node(n2062,supported), node(n2070,supported), node(n2063,supported).
node(n2069,refuted) :- node(n2061,refuted).
node(n2069,refuted) :- node(n2062,refuted).
node(n2069,refuted) :- node(n2070,refuted).
node(n2069,refuted) :- node(n2063,refuted).
node(n2069,unknown) :- \+ node(n2069,supported), \+ node(n2069,refuted).
node(n2072,supported) :- status(o_58651adc8b8045305295,supported).
node(n2072,refuted) :- status(o_58651adc8b8045305295,refuted).
node(n2072,unknown) :- status(o_58651adc8b8045305295,unknown).
node(n2071,supported) :- node(n2065,supported), node(n2066,supported), node(n2072,supported), node(n2067,supported).
node(n2071,refuted) :- node(n2065,refuted).
node(n2071,refuted) :- node(n2066,refuted).
node(n2071,refuted) :- node(n2072,refuted).
node(n2071,refuted) :- node(n2067,refuted).
node(n2071,unknown) :- \+ node(n2071,supported), \+ node(n2071,refuted).
node(n2068,refuted) :- node(n2069,refuted), node(n2071,refuted), node(n9,refuted).
node(n2068,supported) :- node(n2069,supported).
node(n2068,supported) :- node(n2071,supported).
node(n2068,supported) :- node(n9,supported).
node(n2068,unknown) :- \+ node(n2068,supported), \+ node(n2068,refuted).
verdict(c_37d23893f2245d3f,supported) :- node(n2068,supported).
query(verdict(c_37d23893f2245d3f,supported)).
verdict(c_37d23893f2245d3f,refuted) :- node(n2068,refuted).
query(verdict(c_37d23893f2245d3f,refuted)).
verdict(c_37d23893f2245d3f,unknown) :- node(n2068,unknown).
query(verdict(c_37d23893f2245d3f,unknown)).
