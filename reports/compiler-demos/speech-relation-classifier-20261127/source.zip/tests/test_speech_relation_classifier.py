from math import isclose

import numpy as np
from scipy.special import expit

from evaluate_speech_relation_classifier import support
from train_speech_relation_classifier import fit_logistic, learn_standardizer, predict, temperature


def test_regularized_classifier_and_temperature_preserve_score_order():
    x = np.array([[-2.],[-1.],[1.],[2.]])
    y = np.array([0.,0.,1.,1.])
    weights = np.full(len(y),0.25)
    mean, scale = learn_standardizer(x,weights)
    params,_ = fit_logistic((x-mean)/scale,y,weights)
    logits = predict(dict(params,mean=mean,scale=scale),x)
    assert np.array_equal(logits>0,y.astype(bool))
    t = temperature(logits,y,weights)
    assert t>0 and np.all(np.diff(expit(logits/t))>0)


def test_learned_support_uses_whole_claim_from_the_same_eligible_window():
    windows = [dict(checks=dict(speaker=True,time=True),scores=dict(whole_claim=0.75)),
               dict(checks=dict(speaker=False,time=True),scores=dict(whole_claim=1.)),
               dict(checks=dict(speaker=True,time=False),scores=dict(whole_claim=1.))]
    assert isclose(support(windows,[0.4,1.,1.],combine=True),0.3)
    assert isclose(support(windows,[0.4,1.,1.],combine=False),0.4)
