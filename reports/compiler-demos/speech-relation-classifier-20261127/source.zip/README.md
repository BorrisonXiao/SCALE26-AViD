# Logistic and neural classifiers for speech relations

## Design

We first fit regularized logistic regression on the prepared transcript and stated-relation vectors. We then fit a multilayer perceptron (MLP) with one 64-unit hidden layer on the same vectors. Both heads read the 768 values from the frozen DeBERTa encoder's pooled representation of the text pair. These values encode the transcript and claim together. The logistic model uses one set of weights. The MLP can learn nonlinear interactions. We also fit logistic regression on the transcript paired with the full claim, and a claim-only control with an empty transcript paired with the stated relation. [Dataset and feature preparation](https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#speech-training-examples)

The fit uses 104 examples from three related recordings. Each original report group contributes the same total weight. Standardization parameters come from training features. Logistic regression uses a fixed L2 penalty of 0.02 on the mean logistic loss. The MLP uses five defined seeds, full-batch AdamW for 80 updates, learning rate 0.003, weight decay 0.02, and GELU activation. The primary neural test reports seed 17. All five runs are reported. For each head we fit one temperature on 62 examples from two other recordings. It divides the raw log-odds by a positive number before conversion to probability. This preserves score order and makes large scores less extreme when the temperature exceeds one. The fitting range is 0.1 to 20.

The 86 held-out queries use the existing AMI benchmark. They were previously used to describe the frozen baseline, and all were reserved from this training and calibration. The inference pipeline uses manual transcripts, annotated speaker and time spans, and manually specified options. The benchmark contains replacement proposals in addition to explicit preferences, and contains inserted denials. These forms broaden the relation wording beyond the small training set. For the combined test, the relation score and frozen DeBERTa whole-claim entailment must hold in the same candidate span. The implementation multiplies the two observations under an independence assumption. The direct test uses just the relation score with the same metadata checks. The claim-only control also uses the same metadata at inference.

## Results

| Method | Correct, direct | Correct, combined | Valid accepted, combined | False support, combined |
| --- | ---: | ---: | ---: | ---: |
| Frozen whole claim | 71/86 | 71/86 | 18/20 | 13/66 |
| Frozen Qwen relation | 73/86 | 80/86 | 18/20 | 4/66 |
| Logistic, stated relation | 69/86 | 77/86 | 17/20 | 6/66 |
| Logistic, full claim | 73/86 | 76/86 | 17/20 | 7/66 |
| Logistic, claim only | 49/86 | — | — | — |
| MLP, stated relation, seed 17 | 68/86 | 77/86 | 16/20 | 5/66 |

The five MLP runs give 76–77/86 with the whole-claim check. All fit 104/104 training examples, compared with 103/104 for the main logistic classifier. Calibration accuracy for the MLP is 39–42/62. Four MLP runs reach the upper temperature limit; the other fits 19.37. The main logistic temperature is 7.11. Using calibration increases the main combined logistic score from 76/86 to 77/86 and the primary MLP from 75/86 to 77/86. Held-out mean squared error for the frozen combination is 0.060, compared with 0.090 for the logistic combination and 0.090 for the first neural run. The natural-claim logistic model ties frozen Qwen on direct decisions and has lower mean squared error on those direct scores (0.104 versus 0.133). The evidence favors continuing to use the frozen combination as the main baseline.

Relative to the frozen combination, the main logistic model fixes one decision and introduces four errors, and the first neural run fixes two and introduces five. Both learned heads reject a remark about a cat facing the other way. Both miss the valid volume-down replacement and accept an audio jingle that the speaker never mentions. The MLP rejects a mistaken design description that the frozen baseline accepts. Across all 20 changed-option cases, the frozen combination and the primary MLP each accept three, and the main logistic model accepts four. Among the valid reports, the additional false negatives account for the primary MLP's gap.

Six calibration pairs keep the claim and speaker fixed and vary the transcript excerpt. The structured logistic model ranks four pairs correctly, and the MLP and full-claim logistic model rank six. The two labels are both correct on two, three, and four pairs respectively. The claim-only model gives equal scores to both excerpts in all six. These comparisons use the calibration recordings. The absolute scores and benchmark errors distinguish using evidence from using it accurately across topics. All 344 exact DeepProbLog support probabilities agree with the separate calculation. All 715 project tests pass.

## Next steps

- Expand the training sources and independently check the difficult benchmark edits. The goal is to distinguish limits of the small data split from limits of the heads, especially for additions mistaken for alternatives and valid paraphrases.
- Compare a component that explicitly aligns the two options with frozen transcript tokens, keeping the logistic model and frozen combination as baselines. The goal is to test whether access to the words and roles recovers distinctions that one pooled vector loses. A multimodal adapter would need paired audio or visual supervision to answer the broader paper question.

## Reproduce

This archive includes the frozen feature caches, both fitted heads and score metadata, the train and calibration labels, the reserved benchmark as used, and the generated logic programs. Saved arrays contain numeric weights and training standardization constants. Model indices and reported temperatures are in the accompanying JSON. The replay uses cached features and needs no GPU or model downloads. Use Python 3.12, NumPy 2.2.6, SciPy 1.17.1, PyTorch 2.10.0 and the bundled requirements.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python scripts/train_speech_relation_classifier.py logistic
python scripts/evaluate_speech_relation_classifier.py logistic
python scripts/train_speech_relation_classifier.py mlp
python scripts/evaluate_speech_relation_classifier.py all
python scripts/speech_relation_classifier_report.py
python -m pytest -q tests/test_speech_relation_classifier.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/speech_relation_classifier_20261127')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```
