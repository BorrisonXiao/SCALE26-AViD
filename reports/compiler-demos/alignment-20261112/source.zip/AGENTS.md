# AViD project guidance

## Current alignment and full-corpus result —12 November2026

Read docs/split_alignment_20261112.md. The user authorized sentences-only generation plus separate original-mention alignment and a fixed evaluation/full-corpus rate. This completed experiment does not authorize unrestricted automatic fallback or new learning. One frozen Qwen prompt on the same31 direct failures returns only action/sentences; a separate module aligns unique original noun/event mentions and refuses ambiguous/unsupported cases. The38 direct-compiler files stay frozen.

Fresh2375 originals exactly reproduce1924 content-check passes (81.01%) and2103 candidates (88.55%). Two reviewed automatic outputs (Trump/image and police officers) in the fixed sentences-only condition yield1926/2375 passes (81.09%),2105 candidates (88.63%),449 failures. These are development compilation counts, not whole-corpus semantic accuracy. No manual clauses counted. The earlier1927 is a separate single-sentence diagnostic, not a cumulative production count.

Old sentences+new alignment recover2 (officers/robot); new sentences-only+alignment recover2 (Trump/officers), with different membership. Do not union best outputs across prompts. The new prompt still invents narration/construction and expands quotes; quantity/source/reference limitations remain. All62 comparisons are assistant reviewed, not independent gold.42 focused tests; source/browser/publication evidence logged separately. Next proposals: bounded participant-ID/source-frame handling, then typed measurement/absence contracts and another full census before expanded evaluation or DeepProbLog training.


## Sentence splitting fallback — user clarification12 November2026

The intended rewrite is split-and-rephrase: break a difficult claim into simpler subclaims while retaining meaning, shared entities/events and depiction/speech/OCR or other context links. The earlier one-sentence restriction was too narrow and is historical. Keep direct compilation first and never rewrite a passing original. No automatic scale-up is enabled.

Read docs/claim_split_20261112.md and the report Sentence splitting tab. One frozen Qwen prompt on31 previously inspected failures produces65/77 passing clauses and20 all-component passes, but0 approved complete automatic results. Seven selected assistant-written splits give18/18 component passes and4 faithful linked compositions; an eighth no-audio guard is refused. These are compiler-author diagnostics, not model gains, independent gold or corpus accuracy. Frozen38 direct-compiler files stay unchanged. New adapter preserves context and shared mentions; original corpus counts stay2103/1924. No new media/native inference/training. Proposed next: simplify generation/reference alignment, then repeat a fixed fidelity evaluation before scale-up.


## Current paper direction — accepted 2026-10-14

Follow ADR-023 in docs/project_notes/decisions.md: probabilistic parsing for multimodal claim verification. Compile claims into probabilistic logic, keep media models frozen, and learn small relation classifiers. Predefined and learned functions are interchangeable; inference considers alternative evidence assignments. An existing DeepProbLog-like backend is a valid implementation choice.

The user selected this as the paper direction, likely finalized. Earlier tree-CRF and temporal-only proposals are historical comparisons. Experimental results can refine the design; do not automatically reopen the paper direction from old notes.

Read site/proposals/probabilistic-verification.html or its generator scripts/build_probabilistic_verification_proposal.py for the current design. Logistic regression and a small MLP are the initial classifiers; frozen BERT-style features are optional. Decoder-only models remain frozen evidence/parsing modules or baselines.

## Terminology and memory

- Read docs/project_notes/terminology.md and CLAUDE.md before writing documentation or implementation.
- Use standard NLP terms and plain language. Define semantic roles, logical forms, neural predicates, and calibration when needed. Do not invent labels or acronyms for familiar components.
- Check decisions.md before architecture changes, key_facts.md before experiments, and bugs.md when diagnosing known failures. Log significant work in issues.md.
- Keep supported/refuted/insufficient evidence distinct, preserve evidence-route meaning, and distinguish source assertions from direct event evidence.
- Keep proposed methods and resource estimates separate from completed experiments. Never infer new accuracy results from this design page.
- Preserve existing evaluation annotations and artifacts. Use separate training/calibration data and split by source video.

## Rewrite fallback — confirmed12 November2026

Compile the original claim first. Only a strict unsupported result may trigger rewriting; this includes a diagnostic candidate rejected by content checks. A compiled original must be returned unchanged, without loading/querying the rewriter. A separate semantic concern is not a trigger when direct compilation passes. Historical passing-control/guard model probes are diagnostic records, not exceptions to this policy. Keep exact prompts, model settings, raw responses and failure reasons inspectable.
