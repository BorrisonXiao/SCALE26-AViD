# Work Log — AViD Phase 1
_Terminology follows docs/project_notes/terminology.md._

### 2026-06-17 — Phase 1 infrastructure: hypergraph + annotation units

- **Status**: Completed
- **Description**: Built lexical dependency hypergraph from 761 claims → 4,919 annotation units (`annotation_units.tsv`). Ran the rule-based modality-need pass (`affordance_rules.py`, espnet env) — text-only labeling of which evidence channel each claim part needs — for all versions.
- **Output**: `exp/phase1/hypergraph.jsonl`, `exp/phase1/reports/annotation_units.tsv`

### 2026-06-17 — v0: baseline flat 6-class LLM modality-need labeling (job 350326)

- **Status**: Completed (frozen, do not re-run)
- **Description**: First LLM pass using flat 6-class MCQ (A–F), Qwen3-30B-A3B on H100. Established baseline. Known issues: `na` (not applicable — a unit carrying no standalone probe) over-prediction (11.1%), stale `not_annotatable` key in output.
- **Output**: `exp/v0/`

### 2026-06-18 — 2-pass architecture refactor + experiment directory reorganization

- **Status**: Completed
- **Description**: Rewrote `affordance_llm.py` to support `--pass {0,1,2}`; added `build_affordance_annotation.py` to merge rules + LLM outputs into 12-column annotation TSV. Created parallel `exp/v{0,1,2}/` directories with READMEs.
- **Key files**: `scripts/affordance_llm.py`, `scripts/build_affordance_annotation.py`, `scripts/run_affordance_v1.slurm`, `scripts/run_affordance_v2.slurm`

### 2026-06-21 — v1: 4-class coarse LLM modality-need labeling, revised `na` (job 357532)

- **Status**: Completed
- **Description**: Pass-1 (4-class coarse) with broad `na` definition. First attempt (job 357515, narrow na) archived; re-ran with revised prompt (job 357532). Final: 4,016 visual (84.2%), 494 audio (10.4%), 154 unverifiable (3.2%), 104 na (2.2%).
- **Output**: `exp/v1/affordance_annotation.tsv` (4,919 rows); original run in `exp/v1/archive/`

### 2026-06-21 — v2: 2-pass fine-grained 6-class LLM modality-need labeling (job 357533)

- **Status**: Completed
- **Description**: Pass-1 (cached from v1) + pass-2 fine-grained split. Final 6-class: visual_other 58.1%, visual_ocr 26.1%, audio_speech 8.1%, audio_other 2.2%, unverifiable 3.2%, na 2.2%.
- **Output**: `exp/v2/affordance_annotation.tsv` (4,919 rows), `exp/v2/affordance_llm_pass1.jsonl`, `exp/v2/affordance_llm_pass2.jsonl`

### 2026-06-22 — Phase 2 infrastructure: media extraction + verification scripts

- **Status**: COMPLETE
- **Description**: Implemented full Phase 2 pipeline:
  - `extract_media.py`: 1fps / 672×378 frames + 16kHz WAV for 122 chunks → `exp/phase2/media_cache_1fps/`
  - `verify_support.py --modality {visual,audio}`: 2-pass blind multimodal verification via vLLM
  - `build_support_annotation.py`: merges verify_visual + verify_audio → support_annotation.tsv
  - `affordance_vs_support.py`: blind join + P/R/F1 + breakdown by modality-need class
  - `full_claim_support.tsv`: 733-row annotation export (verifiable full-claim rows only)
- **Slurm jobs**:
  - 359161 (failed: logprobs=30 > V1 limit)
  - 359190 (failed: VL 24683 > max_model_len=16384)
  - 359197 (failed: 4K clips at native res exceed 32768 tokens)
  - 359929 (cancelled: L40S TP=4 NCCL deadlock in torch.compile/CUDA graph capture)
  - 359941 (DONE: audio verification, H200 TP=1, 4815 rows)
  - 360188 (failed: claim token length 32810 > max_model_len=32768; stale cache)
  - **360301 (DONE: visual verification + merge + report, H200 TP=1, max_model_len=65536)**
- **Final output**: `exp/phase2/verify_v2/full_claim_support.tsv` — 733 verifiable full-claim rows

### 2026-06-23 — unverifiable filter: briefly added, then REVERTED (2026-06-24)

- **Status**: Reverted — `verify_support.py` excludes only `pred_llm == "na"`, NOT `"unverifiable"`.
- **History**: Briefly extended the skip set to `{"na", "unverifiable"}`, but per user direction
  unverifiable units **should** be verified (the model attempts verification even when no single
  channel dominates). Only `na` is excluded. `load_na_set` is back to `== "na"` only.

### 2026-06-23 — full_claim_support.tsv cleanup

- **Status**: Done
- **Description**: Regenerated with: `claim_text` and `no_video` columns removed; `claim_highlighted` added; unverifiable rows filtered out; column order cleaned up. 750 → 733 rows (16 unverifiable + 1 empty-label dropped).

---

### 2026-06-24 — deterministic unit-filtering suite + prompt extraction

- **Status**: Done (scripts ready; awaiting re-run to apply)
- **Filtering** (`scripts/unit_filters.py`, doc `docs/project_notes/unit_filtering.md`): six
  deterministic rules — na, pronoun, empty, negation (subsumption-guarded), light_verb
  (subsumption-guarded), duplicate (punct-normalized). Net 4,919 → 4,382. Negation/light fragments
  dropped only when a larger surviving unit contains their span (all empirically covered). `say`
  excluded from light set. Wired into `verify_support.py` step `[2]`; `load_pron_set` consolidated
  into `unit_filters`.
- **Prompts** (`scripts/prompts_phase2.py`): six prompt pairs extracted, v1 archived / v2 active
  (no `Claim:` anchor). `key_facts.md` points to the file instead of inlining text.

### 2026-06-24 — Phase 2 prompt redesign + prompt-variant ablation (jobs 361354–361357)

- **Status**: Submitted (queued DAG; results land overnight). Supersedes TODO-4.
- **Binary pass-2** (`prompts_phase2.py` v3, ADR-006): replaced the two independent yes/no/unknown
  sub-probes with ONE symmetric forced-choice MCQ per modality (visual: on-screen text vs other
  visual; audio: speech vs other audio); subtypes mutually exclusive. Motivation: v2 two-probe
  over-fired "both" on 38.9% (visual) / 50.9% (audio) of pass-1=yes units, inflating audio_other
  (Gold=835 vs modality-need Pred=106, R=0.066).
- **UUID filter** (`unit_filters.py` rule 4): drops 13 UUID-only units. Net 4,919 → 4,369.
- **Prompt ablation** (ADR-007, `--prompt-variant base,r1,r2,r3`): base=v2 stem, r1=de-jargoned,
  r2=node_type-aware, r3=LLM-verbalized referent (`verbalize_units.py`). Model loaded once per job.
- **New scripts**: `verbalize_units.py`, `compare_prompt_variants.py`; rewrote `verify_support.py`
  (binary pass-2 + multi-variant loop) and `prompts_phase2.py` (builders); 4 slurm wrappers
  (`run_phase2_verbalize.slurm`, `run_phase2_ablation_{audio,visual,aggregate}.slurm`).
- **Queued DAG** (all H200; job IDs in `exp/phase2/prompt_ablation/.job_ids`):
  - 361354 verbalize (H200) → `verbalized_units.jsonl`
  - 361355 audio (H200 TP=1, batch 32) — afterok 361354
  - 361356 visual (H200 TP=1, 250 frames) — afterok 361354
  - 361357 aggregate (cpu) — afterok 361355:361356
  - *(first attempt 361349–352 failed: verbalize on H100 rack3n06 → vLLM EngineCore CUDA-init
    error; node-specific, moved to H200 — see bugs.md.)*
- **Outputs**: `exp/phase2/prompt_ablation/{base,r1,r2,r3}/` + `.../reports/variant_comparison.{tsv,md}`,
  `variant_per_unit.tsv`. CPU smoke-tested (prompt rendering, A/B→channel mapping, summarize).
- **Caveat**: no human gold yet — comparison is variant-vs-variant + variant-vs-modality-need; gold pilot
  (TODO-5) still required to *select* a winner. CC: do not over-tune prompts before the pilot.

### 2026-06-24 — v4 ablation DAG submitted (jobs 361884–361890)

- **Status**: Queued (all dependencies correct; results land overnight).
- **What changed from the superseded 361354–361357 run:**
  - r3 deprecated (ADR-008); replaced by r4 (type-aware, no context) and r5 (LLM-formulated question).
  - De-news genericization of pass-2 option examples (ADR-009).
  - r5 formulation split into two independent single-modality calls.
  - Unit filtering expanded: 4,919 → 4,382 (6 rules including negation/light_verb subsumption).
  - `formulate_questions.py` now writes both `formulated_questions.jsonl` AND `formulated_questions.tsv` (human-readable).
  - `compare_prompt_variants.py` now accepts `--formulated` and includes `visual_question`/`audio_question` columns in `variant_per_unit.tsv`.
- **DAG (H200 unless noted):**
  | Job | Name | Dependency | Purpose |
  |---|---|---|---|
  | 361884 | avid-p2-formulate | — | r5 pre-pass → `formulated_questions.{jsonl,tsv}` |
  | 361885 | avid-p2abl-visual | — | visual base/r1/r2 (parallel with formulate) |
  | 361886 | avid-p2abl-audio | — | audio base/r1/r2 (parallel with formulate) |
  | 361887 | avid-p2abl-vis-r4r5 | afterok:361884 | visual r4/r5 |
  | 361888 | avid-p2abl-aud-r4r5 | afterok:361884 | audio r4/r5 |
  | 361889 | avid-p2abl-agg (cpu) | afterok:361885:361886 | merge + per-variant report (base/r1/r2) |
  | 361890 | avid-p2abl-agg-r4r5 (cpu) | afterok:361887:361888:361889 | merge r4/r5 + 5-way compare |
- **Expected outputs**: `exp/phase2/prompt_ablation/{base,r1,r2,r4,r5}/support_annotation.tsv`;
  `reports/variant_comparison.{tsv,md}`, `reports/variant_per_unit.tsv` (includes formulated questions).

### 2026-06-25 — readable support view (tooling)
- Added `scripts/make_readable_support.py`: distills a variant's `support_annotation.tsv`
  into a glance-able TSV. Drops ids/types, unmarked `claim_text`, and all `*_prob` columns;
  collapses the 4 channel verdicts → 2 per-modality cells (lossless under ADR-006 exclusivity):
  `visual ∈ {text,other,no,unknown,no_video}`, `audio ∈ {speech,other,no,unknown,no_video}`.
  For r5, joins the LLM-formulated `visual_q`/`audio_q`. Narrow prediction columns kept left.
  Output: `exp/phase2/prompt_ablation/r5/support_readable.tsv` (4,369 rows, 8 cols).

### 2026-06-25 — r5e: answer-first explanation variant (code only; ADR-010)
- **Status**: Implemented, NOT yet run (user will launch). Answers "can r5 justify like probing?".
- Letter-FIRST + ≤15-word reason in one `generate`; verdicts still from `logprobs[0]` (r5 frozen).
- Edits: `prompts_phase2.py` (`r5e` in PROMPT_VARIANTS, `EXPLAIN_VARIANTS`, `*_SYSTEM_EXPLAIN`,
  `_EXPLAIN_TAIL`, `explain=` on builders); `verify_support.py` (`--explain-max-tokens` def 48,
  per-variant sampling, `_clean_reason`, capture `pass1/pass2_explanation`); `make_readable_support.py`
  (`--verify-visual/--verify-audio` → `visual_why`/`audio_why`).
- Launch: `sbatch run_phase2_r5e_visual.slurm` + `run_phase2_r5e_audio.slurm`, then
  `run_phase2_r5e_aggregate.slurm` (afterok) → `exp/phase2/prompt_ablation/r5e/support_readable.tsv`.
- Verified: r5 readable byte-identical; r5e why-join simulated OK; all scripts compile.

### 2026-06-25 — r5 context-leak fix + `na` triage (code only; ADR-011)
- **Status**: Implemented, NOT yet run (regenerating formulated_questions needs GPU; user launches).
- Fixes two issues in r5 question formulation: (1) atomic-unit questions leaked claim context
  (e.g. "a man" → "…near the tracks"); (2) non-pointable units (e.g. "leaves"="produces") got
  degenerate questions instead of being rejected.
- Edits: `prompts_phase2.py` (anti-leak `_FORMULATE_RULES` + examples; new `TRIAGE_SYSTEM`/
  `TRIAGE_USER_TMPL`); `formulate_questions.py` (two-sweep: na triage → formulate; `na`/`na_reason`
  in output; writes `na_units_r5.{txt,tsv}`); `verify_support.py` (r5/r5e skip empty-formulated/na
  units). na surfacing = minimal (recorded + filtered; user choice).
- Re-run: `sbatch run_phase2_formulate_r5.slurm` → then r5/r5e verify (existing slurm). The new
  formulated questions supersede the current ones, so existing r5 results must be regenerated.
- Verified (CPU): parse_triage cases; end-to-end formulation with pre-seeded cache (na unit → empty
  questions + reason in na_units_r5.tsv; probe units keep questions); all scripts compile.

### 2026-06-25 — r5 audio formulation: sound|speech dual-route (code only; ADR-012)
- Every audio question now covers BOTH a characteristic sound AND the unit being mentioned in speech
  (e.g. "a man" → "…or does anyone mention a man in speech?"). Edit: `FORMULATE_AUD_SYSTEM` rule +
  examples (added a no-sound `Emmonak` case). Visual unchanged. Folded into v2 (not yet run).
- Verified v2 formulation cache does not exist yet (8,738 old unversioned entries; no `|v2|`, no
  na_units_r5.tsv) → next formulate run regenerates fresh with all v2 prompts.

### 2026-06-25 — RUN: r5e experiment (formulate v3 + verify DAG)
- **GPU choice**: used the interactive `gpu_hold` allocation (job 363784, 2× H100 `rack3n06`) for the
  lightweight text formulation; the held alloc has only 8 CPU / 16 GB RAM, too small for the
  250-frame visual verify, so verifies went to `sbatch` (64 GB / H100 each) — proper GPU choice.
- **Formulate**: ran on held H100. First pass (v2) over-fired na (48%!); audited, fixed triage
  (atoms-only + conservative, ADR-011 update), bumped to **v3**. v3: **na=301/4369 (6.9%)**, factors
  all probed, anti-leak clean, audio dual-route 100% (4068/4068). Output regenerated.
- **Verify DAG (sbatch)**: `364141` r5e-vis (h100), `364142` r5e-aud (h100), `364143` r5e-agg
  (cpu, afterok) → all COMPLETED.
- **BUG caught + fixed (Omni preamble)**: first audio r5e run had 33% rows where Qwen3-Omni emitted
  `"Assistant: "` before the letter → `logprobs[0]` read the preamble, corrupting verdicts (5%
  contradictions). Fixed `verify_support.py::_verdict_logprobs` (scan first ~10 positions for the
  letter; VL/1-token unchanged) + `_clean_reason` role strip. Cleared audio cache, re-ran audio
  (`364158`) + agg (`364159`). Re-audit: **0 preamble, 0 contradictions**. See key_facts quirk note.
- **RESULT** (4,068 units): supported 64.9% / unsupported 15.0% / unknown 20.1%; audio speech 25.1%.
  Final: `exp/phase2/prompt_ablation/r5e/support_readable.tsv` (+ `na_units_r5.tsv`, 301 na).
  Results row added to key_facts (exp-r5e). **Experiment COMPLETE.**

### 2026-06-26 — r5e no_video patch + re-run (jobs 365211–365214)

- **Status**: COMPLETED (but with wrong prompt version — see below).
- **Fix**: Claim-index misalignment bug (see bugs.md 2026-06-26). 41 claims falsely had no_video=True; built `manifest_avid.jsonl`, migrated r5e cache, dropped stale entries.
- **Result**: All 4 jobs completed. However, 365212/365213 ran against the v5 cache (PROMPT_VERSION="v5") because the scripts were modified to the v6 prompt (binary yes/no) AFTER the jobs ran (12:10-12:13) vs edits at 12:45-12:46. Output still shows 867 visual unknowns + 24 audio unknowns. Not the expected outcome.
- **DAG**: 365211 COMPLETED (extract) / 365212 COMPLETED (r5e-vis, v5 prompts) / 365213 COMPLETED (r5e-aud, v5 prompts) / 365214 COMPLETED (agg).

### 2026-06-26 — r5e v6 binary re-run (jobs 365243–365245)

- **Status**: COMPLETED (all 3 jobs, rack3n05 H200).
- **What changed from 365212/365213**:
  - `PROMPT_VERSION = "v6"`: binary A=yes / B=no only; C=unknown removed (ADR-014).
  - v6 cache started empty → full fresh inference for all 4,068 units (vis: 31 min, aud: 11 min).
  - Slurm scripts updated: `--gres gpu:h100:1` → `--gres gpu:h200:1`.
  - `make_readable_support.py::load_explanations` retroactive fallback for missing explanations.
- **Result**: supported 64.8% / unsupported 34.6% / unknown 0.5% (21 no_video rows only).
  Zero model-generated unknowns. Zero empty visual_why / audio_why. Output: `r5e/support_readable.tsv`.

### 2026-06-26 — FATAL data lineage fix: full rebuild from current reference.json

- **Status**: RUNNING (DAG submitted, CPU job 365403 active on rack2n11).
- **Root cause**: `reference.json` was updated 2026-06-18 (UUID anonymization, text edits, new claims), but `hypergraph.jsonl` was built 2026-06-15 from the old version. `annotation_units.tsv` was regenerated 2026-06-22 from the stale hypergraph. Result: 11 topics with mismatched claim texts (4 categories: trailing whitespace, UUID→real-name, shortened texts, absent claims). 29 phase-2 units verified against wrong texts; 4 claims unable to match any video (no_video=True in v6 results).
- **Fix**: Option A — full rebuild from current step1 manifest (which uses current reference.json).
  - Killed stale 192-thread login-node parse_claims.py (PID 269524, 20+ min stalled on first stanza call).
  - Created `scripts/run_rebuild_cpu.slurm` (CPU partition, 8 CPUs, thread-limited via OMP/MKL vars).
  - Cleared all stale LLM/formulation/verify caches.
  - Reverted `DEFAULT_MANIFEST` in `verify_support.py` and `extract_media.py` from `manifest_avid.jsonl` back to step1 manifest.
- **Full DAG** (submitted, all pending on dependency chain):
  | Job | Name | Status | Purpose |
  |---|---|---|---|
  | 365403 | avid-rebuild (cpu) | RUNNING | parse → annotation_units → affordance_rules (v1+v2) |
  | 365404 | avid-v1-pass1 (gpu) | Pending(365403) | LLM modality-need pass-1 |
  | 365405 | avid-v2-pass2 (gpu) | Pending(365404) | LLM modality-need pass-2 |
  | 365406 | avid-p2-formulate (gpu) | Pending(365405) | r5 question formulation |
  | 365407 | avid-p2-r5e-vis (gpu) | Pending(365406) | r5e visual verify |
  | 365408 | avid-p2-r5e-aud (gpu) | Pending(365406) | r5e audio verify |
  | 365409 | avid-p2-r5e-agg (cpu) | Pending(365407:365408) | aggregate + readable TSV |
- **Actual outcome (all 7 jobs completed 2026-06-26)**:
  - `hypergraph.jsonl`: 2375 claims (3.12× more than 761 — reference.json added new topics)
  - `annotation_units.tsv`: 17,813 rows (was 4,919)
  - `affordance_rules.jsonl` (v1+v2): 2375 claims each
  - `formulated_questions.jsonl`: 16,848 rows (15,239 non-na verified)
  - `support_readable.tsv`: 15,239 rows, **BUT** invalid — media cache only covered 124/200 chunks (original 761 claims). New 1,614 claims had no frames/WAV → verify defaulted to "no" for everything → 83.4% visual-no / 91.8% audio-no.
- **Fix stage 1** (2026-06-28): Extract job 369569 (55 min) extracted 76 missing chunks. All 200 chunks now cached; 0 no-video claims.
- **Stale cache bug** (2026-06-29): Verify re-ran but hit v6 cache (17,763 visual / 16,481 audio entries) from the invalid run. Results identical to before (2 min runtime = cache-only). Cleared v6 cache.
- **Fix stage 2** (2026-06-29): Re-submitted `vis(370558) ∥ aud(370559) → agg(370560)` with empty cache. All COMPLETED. Final valid results: 15,239 rows, supported=77.1%, unsupported=22.9%, unknown=0, no_video=0, UUID claims=0. vis: other=38.9% text=16.8% no=44.4%. aud: speech=46.5% other=2.7% no=50.7%.

### 2026-06-30 — Phase 3 design: tree-verification feasibility + framing + compositional invariants

- **Status**: Design/framing captured (no code yet).
- **Framing converged** (faithful-by-construction explanation): goal = claim verdict + a
  modality-attributed parse-tree explanation that is *consistent* (sub-units compose to the claim
  verdict); method = **joint constrained inference** over the tree (bottom-up/top-down is a false
  choice — two halves of one exact computation); consistency enforced by a rule family (hard:
  negation/coordination/existence; soft: modality-traceability/agreement); consistency doubles as an
  **eval axis** (faithfulness) and **gold-light supervision** (natural-claims-true + perturbed-false +
  cross-level consistency). Child→parent **double-check** = a requiredness-gated, all-channel-absence,
  calibration-weighted existence veto (rescue & veto are one mechanism). Calibration is a prerequisite.
  RQ + invariants in `docs/project_notes/compositional_verification_design.md`.
- Feasibility report written: `docs/plans/avid_phase3_compositional_tree_verification_v1.md` (reframe
  CKY/inside-outside → two-pass sum-product on a *fixed* parse tree; novelty = per-subtree modality
  posterior + outside-pass-as-scope; nearest competitor DSG (ICLR'24) → needs a baseline; data audit:
  verifier probs saturated (75–78% ≈1.00), hypergraph factors are flat (0/12441 nest)).
- **Design invariants captured**: `docs/project_notes/compositional_verification_design.md` —
  (1) **negation** (flat is actively wrong; tree flip edge-potential on a structural-`na` node; scope =
  tree) and (2) **asymmetric composition** (the "a man is dancing" decoy: parts present never *confirm* a
  binding; children veto down, never up; the composed node's own emission `e_v` (its direct probe of the whole span) is the binding authority; recovery only via redundant
  same-binding probes). Keep both in mind at every aggregation-rule design step (see the checklist there).
- **Planned controlled experiments** (perturbation set, proposal §10 — natural data is all affirmative):
  **negation injection** ("a man is dancing" → "…is **not** dancing") and **binding decoys** (parts
  present, binding absent). Both manufacture gold compositional labels cheaply.

### 2026-07-01 — Phase 3 implementation plan written

- **Status**: Plan ready (no code yet). `docs/plans/avid_phase3_tree_crf_implementation_v1.md`.
- **Method** (neat core): two independent per-modality **tree-CRFs** (3 states each) over the UD parse;
  each node's emission (unary factor) = calibrated r5e probe; each edge = a deterministic per-relation-class transition (pairwise factor) with 2 knobs
  (`λ`, the necessity-edge strength, and `T`, the calibration temperature); exact belief propagation (sum-product marginals + max-product MAP) → consistent
  modality-attributed decomposition; root = verdict. Negation = unary flip. Cross-modal coupling /
  learned potentials / latent-forest = deferred.
- **Key integration**: emit tree nodes in the **exact annotation-units 9-col schema** → the entire r5e
  probe pipeline (`formulate_questions.py` + `verify_support.py` + `prompts_phase2.py`) runs **unchanged**.
  No prompt/verify edits for v1.
- **Build order (gated)**: M0 POC on cached r5e (CPU, no GPU) — gate: negation flips, cart-veto works,
  dancing-decoy holds → M1 perturbations → M2 (per-node probing) GPU re-probe + calibration (H200) → M3 (tree-CRF inference) + eval →
  M4 learned+constituency → M5 figures. Only M2 uses GPU.
- **Eval**: 5 splits (natural + negation/binding/removal decoys + pilot); metrics = verdict acc /
  decomposition faithfulness / modality attribution; baselines flat-r5e + flat-atomic + DSG-style;
  ablation grid (UD/const, λ=0/det/learned, full-BP/one-pass, calibrated/raw).

### 2026-07-02 — Phase 3 transition-design settled; HANDOFF + design doc refreshed

- Transition (edge) potentials clarified in plain language: small **compatibility tables** (which
  parent/child support combos to discourage), driven by **one strictness knob `λ`** on the *required*
  edges the parser identifies. Spectrum: **deterministic (v1)** → **learned** (fit the few scalars by
  grid-search/gradient on the CRF likelihood — **not** a neural net; the multimodal model stays the emission source) →
  **typed edges** (a text-only LLM types each edge factual/hedged/modal → deterministic `λ`; nuance-only
  extension). Meta: transitions are ~90%-there deterministic; **emission calibration is the real
  bottleneck**. Constituency needs head-rules / const→dep to recover required/optional. → design-doc §2b.
- Impl plan M4/§10/§2.2 updated; **HANDOFF.md** now surfaces the Phase-3 direction + M0 next step.

---

## Open Items / TODOs (in priority order)

See HANDOFF.md for full details on each item.

- **[TODO] Pass-2 subtype probing on the checkable-unit tree T\* (NOT yet run — flagged 2026-07-23).** Phase-3 M2 is 3-way pass-1
  only (yes/no/can't-tell); the CRF's `{no,ocr,other}`/`{no,speech,other}` unaries split `P(yes)` 50/50
  across subtypes (`calibrate_m2.py` L326–339) — a placeholder, so OCR-vs-other-visual and speech-vs-other-
  audio are **not measured** on the current units. Run binary pass-2 forced-choice (ADR-006) on pass-1=yes
  units → feed measured A/B split into the unaries. Blocks sub-channel claims + `visual_ocr` analysis.
- **[TODO] SRL validation of PN-2 (parse-normalization) roles (2026-07-23).** Trained-SRL agreement vs LLM adjunct roles (headline:
  MNR/INS precision = the case-keep linchpin). Plan `docs/plans/avid_phase3_srl_validation_v1.md`; env
  `envs/srl-eval` (AllenNLP BERT-SRL) installing; scripts `run_srl_baseline.py` + `srl_agreement.py` to write.

- **[TODO-1] DONE** — `claim_text` anchor removed from all prompts (v2 in `prompts_phase2.py`).
- **[TODO-2] DONE (expanded)** — pronoun filter + full deterministic filtering suite (`unit_filters.py`).
- **[TODO-3] DONE** — prompts extracted to `prompts_phase2.py`; documented via pointer.
- **[TODO-4] IN PROGRESS** — v4 ablation DAG running (jobs 361884–361890). Variants: base/r1/r2/r4/r5.

2. **[TODO-5] Pilot annotation** — 25-claim gold pilot in `exp/phase2/gold_pilot/`. Annotate
   after TODO-4 re-run is complete to compare against corrected model verdicts.

3. **visual_ocr rate (26.1%)** — may be legitimate (protest-sign cluster); defer until after re-run.

7. **Human structure-flag column** (pronoun / function-word / wrong-span) — needs design decision.

---

### 2026-07-02 — Phase 3 M0 POC: tree-CRF built and running

- **Status**: Completed
- **Description**: Implemented M0 milestone (all CPU, no GPU spend): `build_tree.py` + `tree_crf.py` + `run_crf_inference.py`. All three M0 gates pass.
- **Scripts**: `scripts/build_tree.py`, `scripts/tree_crf.py`, `scripts/run_crf_inference.py`
- **Outputs**:
  - `exp/phase3/trees/trees_ud.jsonl` — 2,375 claims, 18,511 nodes (7.8 MB)
  - `exp/phase3/nodes/tree_units_ud.tsv` — 13,771 probed nodes in annotation-units schema (3.6 MB)
  - `exp/phase3/crf/decomp_ud.jsonl` — marginals + MAP for all 2,375 claims (5.6 MB)
- **Verdicts (λ=3.0, r5e unaries)**: supported=61.4%, partially_supported=19.0%, unsupported=19.5%
- **Gate results**:
  1. **Negation flip** ✅ — "Waves crashing" (0.997 supported) → negated (0.148 unsupported)
  2. **Cart-removal veto** ✅ — core-arg child absent: 0.948→0.567 (verdict changes at λ=3; full flip at λ=10; saturated r5e probs limit the effect — calibration needed for M2+)
  3. **Dancing-decoy** ✅ — parts present, binding absent: root=0.001 (unsupported) — correctly NOT rescued by part-existence
- **Known issues fixed**:
  - `find_head_token_idx` bug: merged nodes containing the parse root token (head==self, self in group) → fallback returned wrong token, creating self-loop parent. Fixed by checking for root token first.
  - Mutual cycles in parse (4/2375 claims) where two tokens in a group point to each other → cycle-safe BP (missing messages treated as uniform, isolated cyclic nodes get uniform beliefs).
- **Next step (M1)**: `make_perturbations.py` — negation injection + binding/removal decoys + gold labels

### 2026-07-04 — M1: Perturbation set + programmatic gold (`make_perturbations.py`)

- **Status**: Completed
- **Script**: `scripts/make_perturbations.py`
- **Outputs** (`exp/phase3/perturb/`):
  - `perturbed_claims.jsonl` — 5,771 records (1,815 neg + 1,978 bind + 1,978 rem)
  - `perturbed_trees.jsonl` — 5,771 modified tree records (input to run_crf_inference.py)
  - `perturbed_units.tsv` — 23,024 rows for decoy probe calls only (annotation-units schema)
  - `gold.jsonl` — claim-level + node-level programmatic gold labels
  - `sanity_sample.tsv` — 21-row gate check (7 per type)
- **Gate result**: ✅ sanity check passed — all three perturbation types grammatically sound; gold labels correct by construction
- **Key design decisions**:
  - Negation injection: insert "not" after last auxiliary before verb (or before verb if no aux). Only applied when root.head_upos ∈ {VERB, AUX} to avoid merged noun+verb root nodes producing bad insertions.
  - Negation injection does NOT add rows to perturbed_units.tsv — reuses original probe scores + CRF unary flip at inference time (isolates structural negation handling from direct LLM judgment).
  - Binding decoy: cross-video entity swap (from entity pool keyed by video_id). Ensures replacement entity is not in the target video.
  - Removal decoy: UPOS-typed placeholder text ("[unidentified person/place]", "[unspecified object]", etc.)
  - Gold claim verdict = "unsupported" for all three types (by construction). Node gold: target node = "unsupported" (reason: negation_flip / entity_absent); root = "unsupported" for decoys with reason "core_arg_veto"; siblings = "supported" (distant label).
- **Known limitation**: Two passive-voice negations produce "being not Xed" instead of "not being Xed" — grammatically awkward but semantically clear. Acceptable for programmatic gold.
- **Next step (M2)**: Run vLLM verifier on `tree_units_ud.tsv` (natural) + `perturbed_units.tsv` (decoys). Then run `calibrate_unaries.py` to fix saturation.

### 2026-07-13 — Gold-pilot viewer: inline CRF parse-tree visualization

- **Status**: Completed
- **Scripts**: `scripts/tree_viz.py` (NEW, pure SVG renderer) + `scripts/build_gold_viewer.py` (wired in)
- **What**: Each of the 200 gold-pilot claims now renders its CRF **merged-tree** (from `trees_ud.jsonl`) as a self-contained inline SVG in the annotation UI, in a panel above the node-gold table.
- **Why**: annotator asked to see the parse structure of what they're labeling. Chose the **merged CRF tree** (not the token-level UD arc diagram in `generate_parse_tree_report.py`) because its node IDs + spans map 1:1 to the annotation rows.
- **Design**:
  - Function words (case/cc/mark/det/aux/cop) contract into their content head as ‹by›-style markers (matches CRF contraction; those nodes aren't annotated).
  - Edge style encodes CRF semantics: **solid blue** = necessity/veto-capable (`core-arg`, `coordination-*`); **dashed grey** = decoupled (`modifier`, `oblique`, `root`).
  - Root ringed (green); negated node → orange border + ⊘ (reinforces "annotate existence, CRF flips polarity").
  - na/unprobeable node → dashed grey box. **Click a tree node → scrolls to + flashes its table row** (delegated listener; rows carry `id="row-{claim}-{node}"`, SVG `<g>` carries `data-node`, wrapper `data-claim`).
- **Layout**: simple tidy-tree in `tree_viz._layout` (BFS depth = y, post-order mean-of-children = x), cycle-safe (guards for the 4/2375 merged-token cycles). Wide trees scroll horizontally in `.treewrap`.
- **Validation**: 200/200 trees embedded, 0 missing; DATA parses; all SVGs round-trip to valid XML; JS syntax OK (`node --check`); **0 broken click targets, 0 orphan rows, 0 na-flag disagreements** between tree (`probed`) and table (`node_kind_pred`). Visually verified 5 claims (negation, na, coordination, 28-node tree) via rsvg-convert.
- **Size**: `index.html` 265 KB → 1036 KB (1160 nodes / 960 edges across 200 trees). Acceptable for a self-contained tool.
- **Rebuild**: `python scripts/build_gold_viewer.py`

### 2026-07-13 — Phase-3 pivot: parse-normalization layer (PN) + eval upgrade + advcl/light-verb misfire

- **Direction (ADR-016):** insert a **parse-normalization map `PN`** between the UD parse and the tree-CRF —
  a **resolve-once** pipeline `PN_llm∘PN_srl∘PN_det` over a closed edit algebra (`MERGE/REATTACH/TYPE/ROLE/DROP`)
  that rewrites raw UD tokens into checkable verification units. Formal math spec (objects, UD–SRL alignment,
  `F_k`-resolvability, edit algebra, worked example): `docs/project_notes/parse_normalization_design.md`.
- **`obl` refinement (user):** a manner/instrument adjunct is a *checkable assertion* ("operated by hand vs
  automated"), so it is **promoted + probed (relation) + soft-gated** (`verif-mod`), NOT ignored with a flat transition (the all-ones pairwise table, ψ=1).
  Supersedes impl-plan §2.2's uniform "obl/advcl → ψ=1".
- **advcl/light-verb-root misfire (diagnosed):** for "The tram driver **gets** out … **to change** the switch
  …", the raw parse makes light-verb "gets" the (na, uniform) root and files the main action under `advcl`
  (→ ψ=1), so the main action's bottom-up support **never reaches the claim verdict** (verdict ≈ "is a tram
  driver visible?"). Not intended — a structural misfire (syntax ≠ semantic importance), same root cause as
  "hand" vs "by hand". Fix: re-root onto the content predicate + treat main-content purpose clauses
  (`advcl:purpose`/SRL `ARGM-PRP`) as `core` (binding).
- **Eval upgrade (now impl-plan §8):** per-node label correctness on the *verifiable* subset (`na` excluded,
  VeriScore-style) + faithfulness (drop-a-node / corrupt-a-node sensitivity), reported separately from
  claim-verdict accuracy.
- **Pilot PAUSED:** `PN` changes the units → the frozen 200-claim pilot (ADR-015) is regenerated from `T*`
  after `PN` is built (still free; none started).
- **Lit backing:** `research/LITERATURE.md` 2026-07-13 axis — PredPatt, Direct Semantic Splitting/UCCA, SRL
  ARGM roles, AMR empty-token normalization, ProoFVer typed-edit faithfulness, PARSEME MWE-reliability caveat.
- **Next:** build `scripts/normalize_parse.py` (PN, resolve-once, released `T*`); pick an SRL model (must align
  to UD spans); define the LLM edit schema (closed algebra, validated JSON); set `λ_soft` for `verif-mod`.

### 2026-07-15 — 3-way pass-1 (yes/no/can't-tell, ADR-017) + REF/NEI-separation study

- **Decision (ADR-017):** pass-1 verdict → **3-way {A=yes/SUP, B=no/REF, C=can't-tell/NEI}**, reversing the
  v6 binary (ADR-014). Binary forced "can't tell" to masquerade as "absent", so unverifiable units became
  spurious evidence-against; REF and NEI must aggregate oppositely (REF→veto, NEI→abstain). Makes the
  child→parent veto **label-driven** (replaces the confidence-gated veto of design-doc §5).
- **Prompt (v7, `prompts_phase2.py`):** plain "yes / no / can't tell" (not technical "supported/refuted/NEI"
  — VLMs read plain tokens better; Audio-Entailment prompts "yes/no/maybe"). B worded strongly (FOLIO: models
  under-pick false/unknown); C fenced to genuine view/audio unavailability (Reliable-VQA). Selected via
  `pass1_user(three_way=True)`; default stays v6 until the study passes. Refs: SNLI-VE, VizWiz,
  Audio-Entailment, FEVER, ADR-013. Render-checked ✓.
- **Gate study (does REF/NEI separate?) — `scripts/study_3way_probe.py`:** re-probe a small sample under
  **controlled input ablations** with the 3-way prompt; ground truth by construction (no human gold):
  - `normal + present` (natural units) → expect **A**;
  - `normal + absent` (removal-decoy units, `perturb/`) → expect **B** (verifiably absent, clip clear);
  - `blacked frames` (visual) / `muted audio` (audio) → expect **C** (view/audio unavailable).
  **Success = C spikes ONLY under ablation, and B (not C) fires for clear-absence decoys** (REF≠NEI).
  Failure (C never used; or C fires for clear-absence; or A/B unchanged under ablation) → fall back to
  binary + upstream abstain. Metrics: per-condition {A,B,C} rate; C-rate(ablated) − C-rate(normal); B-vs-C on decoys.
- **Calibration replan:** the binary-calibration plan is superseded — calibrate the **3-way** distribution
  (multi-class) AFTER this study + the re-probe. The saved v6 dists cannot be un-collapsed.
- **Study RESULT (2026-07-15, jobs 399673 visual / 399674 audio, A100):** split verdict —
  **audio PASS** (muted→90% can't-tell, mismatch→75% no; S≈0.78), **visual FAIL-but-confounded**
  (black frames→97% "no", 3% can't-tell). REF fires for both (mismatch→"no"≈0.75); the split is only in
  NEI-under-ablation. The **black-frame ablation is confounded** (viewable-but-black vs no-view), so
  visual is *inconclusive*, not a clean fail. Matches the pattern: Omni calibrated, 8B-VL overconfident.
  Reports: `exp/phase3/reports/study_3way_{visual,audio}.md`.
- **GPU note:** H200 is **not** in QoS `cxiao_8gpu_tier` (hard `QOSMaxGRESPerUser` stall); use A100
  (visual 40gb / audio 80gb, Omni needs 80gb), `--exclude rack3n06` (Omni CUDA-init bug). HANDOFF/key_facts
  "H200 target" is stale.
- **Systematic resolution → `docs/plans/avid_phase3_nei_elicitation_v1.md`:** pre-registered, staged
  protocol (proper ablation ladder incl. blur; wording W0–W3; elicitation E0–E3 incl. a decomposed
  usability gate; real-NEI human slice) with a fixed per-modality decision rule (3-way iff S≥0.5 ∧ R>0 ∧
  U≤0.2 ∧ real-NEI≥0.5, else binary+upstream-abstain; asymmetric per-modality allowed). Settles ADR-017
  before the M2 re-probe + 3-way calibration.

### 2026-07-15 — NEI elicitation Stage A submitted (jobs 399896 visual / 399897 audio, A100)

- **Status**: RUNNING (queued at submit; Priority state).
- **What**: Implemented full `avid_phase3_nei_elicitation_v1` Stage A. Extended `study_3way_probe.py`
  with the complete ablation ladder; added W1/W2/W3 wording variants to `prompts_phase2.py`.
- **Visual** (job 399896, A100-40gb): sweeps `{normal, mismatch, blank, blur_heavy, blur_med,
  pixelate, cropaway}` × W0/E0, N=40 units, 280 requests. Resolves the black-frame confound —
  expected result: `blur_heavy` → high C (can't-tell), confirming 3-way is fine for visual.
- **Audio** (job 399897, A100-80gb): sweeps `{normal, mismatch, mute, noise, lowpass, clip_short}`
  × W0/E0, N=40 units, 240 requests. Audio already passed the one-off study; this adds rungs.
- **New scripts**: `study_3way_probe.py` (fully extended); `nei_study_summary.py` (aggregator);
  `run_nei_stage_a_{visual,audio}.slurm`. Wording variants W1/W2/W3 + `get_3way_opts()` /
  `get_p1_system()` helpers added to `prompts_phase2.py`.
- **Expected outputs**: `exp/phase3/reports/nei_study/visual__w0__forced.{jsonl,__summary.json}`;
  `audio__w0__forced.{jsonl,__summary.json}`; run `python scripts/nei_study_summary.py` after
  both complete → `nei_study/summary.md`.
- **Next decision** (per stage_a_gate field):
  - PASS for visual → 3-way accepted; proceed to PN (parse normalization) + M2 re-probe.
  - FAIL for visual → Stage B wording sweep (W1–W3, already coded in `prompts_phase2.py`):
    `sbatch scripts/run_nei_stage_a_visual.slurm` with `--wording w1` (or w2/w3).

### 2026-07-15 — NEI literature review + decomposed availability GATE (E2) designed (plan v1.1)

- **Status**: Prompts DONE (frozen in `prompts_phase2.py`); study code path is the next execution-agent task.
- **Why**: user flagged the NEI test as ambiguous between "no" and "can't tell". A focused, web-verified
  literature scan (`research/LITERATURE.md` 2026-07-15) confirms it: the single forced-choice 3-way is the
  **least**-supported NEI elicitation (SNLI-VE neutral ~31% mislabeled / 54% human agreement; FOLIO
  under-picks Unknown; POPE ~99%-"yes" presence bias; black-image hallucination). The Stage-A visual result
  (black frames → 97% "no", **C dropped 0.17→0.03**) is a blindness-non-recognition failure, so **fencing C
  harder (W1) is counterproductive**. Literature-preferred fix = a **decomposed availability gate**
  (answerability ⟂ veracity: Kadavath P(IK); Kamath 2020; Read+Verify; AVeriTeC keeps NEI separate from REF).
- **Done this session**:
  - `research/LITERATURE.md`: added the dated "NEI/REF elicitation for VLM probes" review (23-row table,
    verified refs, ADR-017 rationale correction, preprint flags).
  - `prompts_phase2.py`: **E2 gate prompts FROZEN** — `gate_user(modality, {"gate","content"})`,
    `get_gate_system()`, `GATE_VERDICTS=["can_judge","cant_tell"]`. Two binary calls; chain-rule 3-way dist.
    Compiled + render-checked (visual & audio, gate + content) ✓.
  - `docs/plans/avid_phase3_nei_elicitation_v1.md`: **Revision v1.1** — E2 elevated to primary for visual;
    staging reordered (Stage B′ = gate before the demoted wording sweep); code contract for the execution
    agent; abstention-aware metrics (Effective Reliability + risk–coverage); external-detector fallback.
  - `decisions.md`: ADR-017 **Refinement (2026-07-15)** — records the E2 primacy + the plain-vs-technical
    rationale correction; the go/no-go gate itself is unchanged.
- **NEXT / TODO (execution agent)**: wire `--elicit gate` into `study_3way_probe.py` per plan v1.1 §R4
  (2 calls / same ablated media / compose per R3 / reuse `summarize`), CPU `--dry-run`, then
  `sbatch run_nei_stage_a_{visual,audio}.slurm --elicit gate` (A100; visual 40gb / audio 80gb;
  `--exclude rack3n06`). Run **after** the Stage-A blur ladder (job 400314) lands — the gate is the fix
  regardless of the blur outcome. Then Stage D real-NEI slice for the surviving config per modality.

### 2026-07-15 (later) — Stage-A visual blur ladder LANDED: PASS → reframes E2 (primary-fix → hedge)

- Job 400314 (visual, A100) completed 14:38. **Stage A PASSES for visual:** blur_heavy/blur_med/pixelate →
  **97.5% can't-tell (S=0.80)**, cropaway → 75% (S=0.575), normal C=0.17, mismatch → 75% "no" (R=0.60),
  U=0.175, gate=**PASS**. Only `blank` (black frames) → 85% "no" (C=0.15): the black-frame stimulus is
  *viewable-but-empty* (an ill-posed NEI probe — a clear black frame legitimately has no X), **not** a
  general visual-blindness failure — exactly the confound plan §0 hypothesized. Result:
  `exp/phase3/reports/nei_study/visual__w0__forced__summary.json`.
- **Reframe (docs updated this session):** single-call 3-way (W0) now passes Stage A for **both** modalities
  → **W0 is the provisional default.** **E2 gate repositioned from "primary visual fix" → "ready hedge +
  calibration-friendly chain-rule emission,"** to be run **head-to-head with W0 on the Stage-D real-NEI
  slice** (now the deciding gate; the one residual risk is viewable-but-target-absent / real occlusion,
  which resembles blank/cropaway). Edits: plan v1.1 R1/R2/R6; ADR-017 Refinement (points 1–2); HANDOFF
  header + step 1; LITERATURE.md implications. The E2 prompt design + lit review stand unchanged (still the
  right hedge; the earlier "visual fails" framing was written before this job landed).

### 2026-07-15 (later) — NEI closed → effort → Parse Normalization (PN); dedicated plan + prompt + prune + rename

- **NEI CLOSED** (user call): claims are ~100% verifiable → genuine node-level NEI is rare, so the
  real-NEI slice + E2 head-to-head are **deferred** (E2 stays frozen as fallback). W0 single-call 3-way
  committed both modalities. Recorded in HANDOFF step 1, ADR-017 Status, plan v1.1 banner, memory.
- **Dedicated PN plan written:** `docs/plans/avid_phase3_parse_normalization_implementation_v1.md`
  (staged PN-1 deterministic → PN-2 LLM-SRL role → PN-3 deferred; code contracts; eval upgrade; repro).
- **PN-2 role prompt FROZEN** in `prompts_phase2.py`: `SRL_ROLE_SYSTEM` + `srl_role_user()` +
  `SRL_ROLE_LABELS` (MNR/INS/PRP/TMP/LOC/DIR/CAU/CORE/OTHER) + `SRL_ROLE_PROMPT_VERSION="v1"`. Role
  signal = **LLM-SRL (Qwen3-30B)** — no SRL lib installed; reuses r5 model, frozen + validated JSON.
  Compiled + render-checked; gate/E2/three_way prompts intact.
- **Parse-surface finding (informs PN scope):** parser emits `obl:tmod`/`nmod:tmod` (temporal, F₀) but
  **no `advcl:purpose` / manner subtype** → the headline fixes ("by hand" manner, purpose re-root) need
  the role signal (PN-2, φ₂); PN-1 is unit-cleanup + free wins only.
- **Plans pruned:** archived `avid_phase1_parsing_ablation_v1.md` + `avid_phase2_implementation_plan_v1.md`
  → `docs/plans/archive/` (both zero-inbound-reference + superseded: constituency ablation lives in
  tree-CRF impl §8; phase-2 per-unit architecture replaced by the CRF). Foundational phase-1 plans KEPT
  (cited by `annotation_units.py` + `parsing_and_unit_generation.md`). Reversible (not a git repo).
- **Rename Φ→PN** across all working docs + memory (`sed`, docs-only; lowercase `φ_k` feature-maps and
  code untouched); 0 residual capital-Φ. Handle "PN" = parse normalization (ASCII, typeable).
- **Next (execution):** build PN-1 in `scripts/normalize_parse.py` (CPU) → diff + M0 gate → PN-2 role pass.

### 2026-07-15 — Parse Normalization PN-1 + PN-2 complete; T* v1 released

- **Status**: Complete
- **PN-1 (normalize_parse.py, CPU):**
  - TYPE: 53 temporal adjuncts (obl:tmod/nmod:tmod) → inert-mod/na/probed=False
  - MERGE: 2,894 obl/nmod with case/mark child → pn_unit_text = subtree_text (full PP; e.g. "hand"→"by hand")
  - REATTACH: 31 light-verb roots → re-rooted onto content predicate (rel_class=modifier for CRF)
  - Output: T* v0 (trees_ud_star.jsonl), pn_edits.jsonl; 13,527 probed TSV rows (was 13,580)
  - M0 gate ✅: CRF verdicts stable (62.0/18.7/19.4 ≈ 61.3/19.0/19.6)
- **PN-2 (run_pn2_srl.py, Qwen3-30B, job 400840, A100-80gb, ~11 min):**
  - 3,253 adjunct edges role-typed: LOC=1160, TMP=501, PRP=440, CORE=369, DIR=325, CAU=202, INS=131, MNR=100, OTHER=25
  - verif-mod edges: 231 (MNR+INS); wire: tree_crf.py edge_potential handles "verif-mod" + λ_soft
  - TMP residue: 501 more temporal adjuncts caught (PN-1 only caught subtype-labeled obl:tmod/nmod:tmod)
  - Output: T* v1 (overwrites trees_ud_star.jsonl), pn_roles.jsonl; 13,027 TSV rows
  - Gates ✅: "change by hand"→verif-mod ✓; PRP/advcl→core ✓; TMP residue ✓; M0 no-regression (59.5/20.1/20.3) ✓
- **OOM bug (bugs.md 2026-07-15):** Qwen3-30B-A3B OOMs on A100-40gb (job 400805); needs A100-80gb
- **Next:** M2 re-probe — probe T* v1's 13,027 units with W0 3-way prompt on Qwen3-Omni (A100-80gb)

### 2026-07-15 — M2 re-probe jobs submitted (jobs 401213/401214)

- **Status**: Running (queued, Priority state)
- **Description**: Submitted M2 3-way W0 re-probe on T* v1 units (13,027 probed rows).
  - Visual (job 401213): `run_m2_visual.slurm`, A100-40gb, Qwen3-VL-8B
  - Audio (job 401214): `run_m2_audio.slurm`, A100-80gb, Qwen3-Omni-30B
  - Script: `scripts/run_m2_probe.py` — 3-way W0 single-call pass-1, simple template question,
    cache at `exp/phase3/nodes/m2_cache_{modality}.jsonl`, output at `verify_{vis,aud}_star.jsonl`
- **After completion:** verify row count = 13,027 per modality; check C%  (~17.5% expected for visual);
  then proceed to 3-way calibration (step 4 in roadmap).

### 2026-07-16 — M2 complete; 3-way calibration + M3 CRF done

- **Status**: Complete
- **M2 re-probe (jobs 401213/401214):** 13,026 units each; visual 50.9%Y/35.1%N/13.9%C (C% < 17.5% Stage A expectation — OK); audio 40.4%Y/50.9%N/8.7%C
- **Calibration (calibrate_m2.py):** T_vis=3.0, T_aud=2.0 (conservative; dev optima T=7/10 were near-uniform). NLL improvements: vis -1.34, aud -0.59. ECE: vis 0.30→0.15, aud 0.26→0.14.
- **M3 CRF:** `decomp_m3.jsonl` — 56.4%/24.3%/19.3% (supported/partial/unsupported); 41% claim verdict changes vs r5e-binary baseline
- **Next options:** (a) eval on perturbation set + baselines [step 7]; (b) gold pilot annotation [step 5]; (c) better calibration with perturbed-unit re-probe [step 4 improvement]

### 2026-07-16 — PN-3 F₃ checkability (PN_llm) built + tight-unit fix + gold_pilot_v3 (re-root rejected)

- **Status**: Complete (ADR-018)
- **Trigger**: regenerated pilot still showed bare "hand"/"correct" probeable → found (a) build scripts read the pre-PN `content_subtree_text` not `pn_unit_text`; (b) the design's F₃ `PN_llm` was unbuilt; (c) ~1,334 clause-length units (content_subtree over-capture + PN-1 MERGE full-subtree). bugs.md 2026-07-16 ×3.
- **PN-3 F₃ (PN_llm)**: new `run_pn3_check.py` + `CHECKABLE_*` prompt (`prompts_phase2.py`, **v2**) + `run_pn3_check.slurm` (A100-80gb Qwen3-30B, temp 0, cached). Resolve-once over 10,274 PN-1-provisional probeable content nodes; NA→role=na. v1 (job 402236) over-flipped named/concrete entities (`Typhoon Halong`) → prompt v2 (concrete phenomena + named entities = CHECKABLE, `« »`-marked full-claim context). Final: 13.5% na (1,391); 293 v1 over-flips rescued; normatives still na.
- **Tight-unit fix**: `build_tree.py` `UNIT_BOUNDARY_DEPRELS` (non-events → head phrase; events keep proposition) + PN-1 MERGE folds case marker only. Clause-units 1,334 → 147.
- **Re-root REJECTED**: reviewed all 13 `advcl:PRP` candidates — demotes checkable motion/appearance matrix events; design §6 tram example is a mis-analysis. Skipped.
- **gold_pilot_v3**: `exp/phase3/gold_pilot_v3/` (200 claims, seed 20260704; 927 probed + 225 na rows). Verified `by hand`✓, `correct→na`✓.
- **Reproducible**: `scripts/run_pn_regen.slurm` (full regen job 402377, 12m26s, A100-80gb): build_tree → PN-1 → PN-2 (fresh) → PN-3 → gold_pilot_v3 → verify.
- ⚠️ **STALE**: downstream M2/M3 (`decomp_m3.jsonl`, `verify_*_star.jsonl`, calibration) were computed on the OLD units — re-run on T* v2 before using M3 verdicts. Gold pilot is independent (human-annotated).
- **Next**: annotate `gold_pilot_v3` (step 5); OR re-run M2/M3 on corrected T* (steps 4/6).

### 2026-07-20 — PN unit-surface refinement (ADR-019): proposition-roots + bare-modifier suppression + case-merge + TMP-clause

- **Status**: Complete (ADR-019)
- **Trigger**: corpus-wide review of the ADR-018 pilot (user flagged `Successful liftoff of rocket`, `Rocket launch with clear skies`, `Smoke visible as rocket lands`, and `1` in `Blue Ghost Mission 1`). Found 4 patterns, not isolated cases.
- **Fixes**: (1) events + root use the full subtree — repaired **1,375 truncated propositions** (`build_tree` cssp=ssp for event/root); root-covers-claim 48%→96%. (2) suppress non-root `amod`/`advmod`/`nummod` **by deprel** (`build_tree.MODIFIER_NOPROBE_DEPRELS`) — the first attempt scoped by node_type=attribute and MISSED `nummod` (`1`); 1,512/1,788 attribute units were nested-redundant. (3) case marker kept only for MNR/INS (`run_pn2_srl` reverts others to bare content NP); SRL prompt **v2** (weather≠TMP). (4) `TMP→na` only non-clausal (`_subtree_has_verb`).
- **Verified**: `by hand`✓ (survived — MNR), `clear skies`✓ (SRL now OTHER), `1`/`clear`→na✓, `Successful liftoff of rocket`→full-claim root✓. probed 11,628→**9,774**; F₃ 10.6% na; non-root clause-like 1,334→66 (residual = quotes/appositives/long names).
- **Limitation**: parser-mis-grouped temporal clauses (verb absorbed into a noun node, `rocket lands`) not detected as clausal → still na; mitigated by proposition-root capture. Parse-layer issue, out of PN scope.
- **GPU**: H100/H200 QoS-capped at 0 (`cxiao_8gpu_tier`; no `normal` QoS); A100-80gb full ~1 day → ran on **2× A100-40gb tp=2** (job 413160, ~16 min). `run_pn_regen.slurm` now `--tp 0`. See bugs.md 2026-07-20 + memory `gpu-qos-a100-only`.
- **gold_pilot_v3 rebuilt** (refresh http://localhost:9000, served in tmux `html:v3`). ⚠️ M2/M3 STILL STALE vs this T*.

### 2026-07-25 — AViD poster assembled (SCALE poster deadline)

- **Status**: Complete (draft; awaiting the user's author/contact edits + gold-annotation overlay).
- **Deliverable**: `slides/poster/AVID_Poster.pptx` (JHU HLTCOE template, 24×36 portrait). Preview: `slides/poster/AVID_Poster_preview.jpg`. Pristine template backed up as `AVID_Poster.template.pptx`.
- **Reproducible build**: `slides/poster/build_poster.py` (scale26 env, python-pptx 1.0.2) fills the template from the backup — edits text runs in place (preserves Lato/scheme colors), swaps in figures via `add_fit` (aspect-preserving), deletes the template's Potemkin mock / Sources-LLM-Raven diagram / metric table / native bar chart. Re-run to regenerate.
- **Framing**: method-first. Title "**Compositional Audio-Visual Claim Verification** / via Parser-Grounded Decomposition". Sections: Introduction (Motivation/Problem/Worked example + worked-example modality tree), Main-takeaway band, Method (framing + pipeline figure), Per-unit grounding (headline + grounding charts), Compositional verification (faithfulness + verdict charts). Featured worked example = `TQKCK6-tRaoE_665` ("Huge crowd standing together chanting"): crowd=BOTH, standing=VIDEO, chanting=AUDIO.
- **Figures** (`slides/figures/`): `pipeline.png` (`gen_pipeline.py` → SVG → `rsvg-convert -w 3600` → PIL autocrop to content bbox; `pipeline.drawio` also emitted for the user to edit), `modality_tree_chanting.png` (rendered from the user's **FROZEN** `modality_tree_chanting.drawio.svg` — do NOT edit the SVG), 4 charts from `gen_poster_charts.py` (**calm-probe** env — matplotlib is NOT in scale26/vllm-omni).
- **Palette unified** to the frozen tree's drawio pastels: **VISUAL `#6C8EBF`, AUDIO `#D79B00` (gold), BOTH `#82B366`, NEITHER `#AEB4BB`** — set in both `gen_pipeline.py` and `gen_poster_charts.py` so modality = color is consistent poster-wide (was Vega bright-orange audio → mismatched the tree's gold).
- **Corrected faithfulness framing (2026-07-29 parent-text fix)**: on lenient detection, CRF vs flat
  whole-claim baseline is **84% vs 63% overall**, **93% vs 76% on binding**, and
  **71% vs 31% on core-argument removal**. The earlier binding/removal comparison was invalid because
  edited node text did not propagate to ancestor/root probes; see `bugs.md` (2026-07-29).
- **QA**: two fresh-eyes subagent rounds (pptx skill). Fixed: pipeline legibility (rsvg `feDropShadow` bug → bugs.md 2026-07-25; bumped fonts + single-word stage titles + tight crop), unified audio color, full-bleed takeaway band, white title, enlarged tree + balanced columns. Content QA: zero leftover template placeholders.
- **Render/QA tooling**: portable LibreOffice `envs/libreoffice-portable/root/opt/libreoffice26.2/program/soffice --headless --convert-to pdf` → `pdftoppm -jpeg` (set `HOME` to a writable dir). See memory `pptx-rendering-tooling`.
- **Pending (user)**: (1) edit author list + `<contact_email>` (intentional placeholders in `AVID_Poster.pptx` shape #22); (2) overlay the chanting-claim GOLD annotation onto the tree once annotated; (3) optional constituency+trained-SRL A/B annotation site (`gold_v2_const/`, deferred, not poster-blocking).

### 2026-07-29 — AViD poster readability + ACL/NLP language revision

- **Status**: Complete.
- **Deliverables updated**: `slides/poster/AVID_Poster.pptx` and
  `slides/poster/AVID_Poster_preview.jpg`; reproducible sources remain
  `build_poster.py`, `gen_pipeline.py`, and `gen_poster_charts.py`.
- **Readability fixes**: both navy takeaway bands now use explicit white text;
  section headers and takeaway copy use the restored 1.3-inch left inset; the
  introduction uses the restored labeled multi-paragraph layout with explicit
  no-bullet formatting; the bottom-right verdict-chart percentages were reduced
  from 24 pt to 15 pt.
- **User wording preserved**: rebuilt from the user's latest edits in
  `build_poster.py` (including “Claims extracted from videos…” and
  “compositional relationships”); corrected only the typo “exttracted.”
- **Rollback**: at the user's request, restored the earlier visual iteration
  (1.3-inch band insets and labeled intro) while retaining
  the revised content language. Restored the earlier title:
  “Compositional Audio-Visual Claim Verification” / “via Parser-Grounded
  Decomposition.”
- **Header refinement**: reduced all four light-blue section headers uniformly
  from 48 pt to 46 pt after confirming the apparent margin problem was specific
  to VS Code's PowerPoint rendering.
- **Language revision**: reframed the poster with ACL/NLP-familiar terms including
  *subclaim*, *evidence modality*, *claim-level label*, *structured aggregation*,
  and *meaning-changing perturbation*. The pipeline is now Parse → Decompose →
  Verify → Aggregate, with exact inference in a tree-structured CRF.
- **QA**: rebuilt all modified charts/pipeline assets; validated the PPTX ZIP;
  rendered the 24×36 poster through LibreOffice; content QA found no template
  placeholders; the visual fix-and-verify pass caught and repaired a wrapped final
  section header. Final render has no observed overlaps, clipping, or low-contrast
  text.

### 2026-07-30 — Poster perturbation refresh + cross-modal readout correction

- **Status**: Complete.
- **Perturbation metric**: replaced the earlier unpaired comparison with a paired
  downgrade metric on the 2,936 edits whose unedited source is `supported` for
  both AViD and the flat baseline. An edit is detected when its verdict leaves the
  `supported` class. Updated poster results: negation 83.7% vs. 81.2%
  (`N=944`), binding 87.9% vs. 65.8% (`N=996`), argument deletion 48.7% vs.
  7.8% (`N=996`), and overall 73.2% vs. 51.1% (`N=2,936`).
- **Readout correction**: documented that the visual and audio tree CRFs run
  independently. For modality `M`, support mass is
  `s_M = 1 - P_M(no)` (the sum of the two supportive subtype states); the scalar
  verdict score is `max(s_visual, s_audio)`. `VIDEO`/`AUDIO`/`BOTH` is a separate
  grounding attribution from the retained local visual/audio probe decisions,
  not a CRF state and not the argmax channel.
- **Figures/deck**: redesigned the poster pipeline and week-7 example sequence so
  all belief-propagation arrows stay within one modality. Visual/audio marginals
  are paired only in the final per-node readout, which reports both the verdict
  and grounding attribution.
- **Deliverables**: refreshed `slides/poster/AVID_Poster.pptx`,
  `AVID_Poster.pdf`, `AVID_Poster_preview.jpg`, the week-7 deck/PDF/JPG renders,
  and all reproducible figure-generation sources.

### 2026-07-30 — Poster/chart overflow and example-sequence simplification

- **Status**: Complete.
- Reduced and respaced the poster perturbation-chart typography so all paired
  value labels remain distinct; shortened the pipeline output pill to
  `GROUNDING · BOTH`.
- Simplified slides 10–11 by removing the redundant in-figure modality banners
  and `VISUAL/AUDIO EVIDENCE` tags. Color now carries the modality while node
  outputs use `YES` or `CANNOT TELL`.
- Simplified slide 12 to `VERDICT: SUPPORTED`, `BOTH`, `VIDEO`, and `AUDIO`;
  removed the detailed final-readout formula card. Reduced remaining numeric
  annotations and enlarged their wrappers to prevent renderer-specific overflow.
- Rebuilt poster/deck PPTX files, PDFs, previews, all slide JPGs, and editable
  SVG sources. LibreOffice render plus fresh-eyes QA found no remaining overlap
  or clipping.

### 2026-07-30 — Collision-proof perturbation labels + qualitative pipeline outputs

- **Status**: Complete.
- Moved perturbation percentages inside their corresponding bars (except the
  7.8% label above its short bar), eliminating the negation-label collision even
  under renderer font substitution.
- Recovered the earlier qualitative pipeline output design from the archived
  round-0 deck. The current output card now contains only:
  `CLAIM · SUPPORTED · BOTH`, `SUBTREE · BOTH`,
  `UNIT · standing · VIDEO`, and `UNIT · chanting · AUDIO`.
  Removed all example marginal/probability numbers from the overview pipeline.
- Synced the restored pipeline and chart into the poster and week-7 deck;
  rebuilt and rendered every PPTX/PDF/JPG artifact. Fresh-eyes QA confirmed no
  collision or output-card overflow.

### 2026-07-31 — CRF node/emission semantics formalization
- **Status**: Under review
- **What**: Formalized the current model as a parse-indexed, span-conditioned tree CRF: lexical
  anchors index variables, while the multimodal model's unaries (emissions) condition on possibly larger/overlapping proposition
  surfaces. Defined the implemented unary mapping, edge matrices, belief propagation, and root readout.
- **Review note**: `docs/project_notes/crf_semantics_review_2026-07-31.md`
- **Open concern**: final T* does not guarantee semantic-span coverage when a node is marked `na`.
  Additionally, uniform `[1/3,1/3,1/3]` has support mass `2/3`, so 94 unprobed roots are currently
  labeled supported at the evidence-free baseline. Root/coverage/state-space invariants require
  review before freezing results.
- **2026-08-04 revision**: rewrote the review note with a complete symbol table, rendered LaTeX,
  step-by-step numerical examples, and a clearly separated proposed `{SUP, REF, NEI}` correction.

### 2026-08-08 — One-page SCALE 2026 report draft
- **Status**: Draft complete (compiles to 2 pages)
- **What**: Drafted the SCALE 2026 report from the provided template
  (`docs/report/My_One_Page_SCALE_2026_Report/`). Sections: Motivation (MiRAGE bridge →
  full-claim modality redundancy from the MicroVENT pilot), Method (parse → PN → 3-way probe →
  per-modality tree-CRF), Results (2 tables), Future Directions, Planned Papers (AViD paper +
  abstract, venue ACL 2026/ARR).
- **Numbers** (all from `key_facts.md` / recomputed live): grounding visual-only 34.3 / audio-only
  16.6 / both 25.8 / neither 23.3 (%); verdicts 56.5 / 27.5 / 16.0; paired perturbation faithfulness
  AViD vs flat — neg 83.7/81.2, binding 87.9/65.8, arg-deletion 48.7/7.8, ALL 73.2/51.1 (paired
  N=2,936; matches the user's `gen_poster_charts.py` methodology).
- **Files**: `main.tex`, `table_grounding.tex`, `table_faithfulness.tex`, `biblio.bib` (+FEVER,
  FActScore), `main_preview.pdf`. Fit to 2 pages via `\parskip` 0.3em, tight lists, `\bibsep` 3pt,
  and floating Table 1 to the bottom of page 1 (`[b]`, declared early).
- **Note**: this cluster's TeX lacks `bold-extra`/`lipsum`/`titling`/`multirow`; the local preview
  used stubs. Real build (e.g. Overleaf) has them — only affects the title's bold small-caps.

### 2026-08-13 — Conjunct-local semantic factor-tree implementation and gold-v3 pilot

- **Status:** Simplified pilot served; `sfq-v4` model rewrite cache pending a local GPU or explicit external-processing authorization.

### 2026-08-20 — Unit-quality fixes in the semantic factor tree (by hand / get out / position)

- **Status:** DONE, deterministic, in the builder. Regenerated `semantic_factor_trees.jsonl`
  (backup `semantic_factor_trees.pre_unitfix.jsonl`) and built a **new** site `exp/phase3/gold_v4/`
  (the live `gold_v3` the annotator is mid-pass on is untouched; promote when reviewed).
- **Three fixes in `semantic_factor_tree.py`** (all id-preserving → existing annotations stay aligned;
  the multimodal-model reference column goes stale for changed nodes, re-probe optional):
  1. **"get out of" (particle-only surface):** an event with a directional-particle child folds *only*
     the particle into its surface ("getting" → "getting out"); the argument ("the tram") stays its own
     node and the binding factor "getting out of tram" is untouched. Restricted to true intransitive
     particles `{out,up,down,off,away,back,apart,aside}` — folding transitive prepositions gave dangling
     "crashing into?", so those verbs stay bare. 21 events corpus-wide.
  2. **"by hand" (Fix A):** abstain the bare object of a manner PP — but *only* SRL role `MNR` ∧ head ∈
     `{hand,hands,foot,feet,part}`. The blanket MNR rule over-fired on SRL noise ("wind gust", "30 mph"),
     so it was gated to a manner-noun set. The manner factor "changing by hand" still carries the phrase.
     3 abstains (hand/part).
  3. **"position" (Fix C):** abstain single-word abstract/relational nouns (`ABSTRACT_NOUNS`: position,
     situation, condition(s), way, role, sense, status, tendency, respect, manner, …). Single-token only,
     so concrete compounds ("entry way", "Narco state") are not dropped. 30 abstains.
- **Tree viz** (`semantic_factor_tree_viz.py`): abstained (`na`) content nodes now render muted-amber /
  dashed with an "na" subtitle (+ legend entry) so PN's drop decisions are visible for analysis.
- **Why deterministic, not the LLM gate:** an LLM check-worthiness probe (codex, gpt-5.6-sol) was run
  head-to-head with the rule on a mixed set — it agreed on clear cases but correctly *kept* concrete
  instruments/locations the blanket rule dropped (school buses, charger, entry way). The shipped rules are
  the high-precision safe subset; the LLM gate remains the higher-recall option for the residue.
- **PredPatt check (2026-08-20):** ran `hltcoe/PredPatt` (throwaway venv `envs/predpatt-tmp`) on the T\*
  parses — with UD v2 it gives clean predicate-argument frames but no roles, leaves "hand" bare, and is
  fragile on verbless fragments → validates ADR-016 (UD + SRL-roles + LLM-residue). Useful only as the
  backbone-ablation arm, not a fix.
- **Trigger:** Interior emissions probed overlapping subtrees. Follow-up discussion established the intended split: local variables are probed independently, while edges carry binding questions; factors combine immediate endpoints and receive subtree evidence through messages.
- **Implemented:** canonical three-stage prompt families in `prompts_phase2.py`; deterministic compiler/audits in `semantic_factor_tree.py`; generic hyphenated-lexeme repair; versioned external/local text-pass runners; synthetic prompt audit; revised public proposal; simplified gold-v3 builder and package.
- **Check-worthiness gate — local vs external (2026-08-20):** ran the gate two ways over 166 gold entity units with the same prompt — local **Qwen3-30B** (vLLM, A100-80gb; `run_checkworthiness_qwen.py/.slurm`) vs external **codex / gpt-5.6-sol**. **84% agreement** (140/166; 46 both-abstain, 94 both-keep); the 26 disagreements are the subjective middle (codex drops policy/abstract nouns e.g. tariffs/calculus; Qwen drops quantities/times + a few concrete-ish e.g. lane/night). **DECISION: use the local Qwen gate for all current + future experiments** — reproducible, no external API, claim text stays on-cluster; codex is a sanity check only. vLLM gotcha: the first Qwen job died on **rack10n07** (`/scratch` perms → `FXGraphCacheMiss`); fixed with `--exclude=rack3n06,rack10n07` on all vLLM slurms + `enforce_eager=True`.
- **Promoted gold_v3 + re-probed model defaults (DAG 526614→526620):** finalize (Qwen gate ∪ deterministic B/A/C → regen trees → build gold_v3) → M2 visual/audio re-probe → source passes → rebuild. gold_v3 now **439 probeable + 68 na**; model-reference predictions refreshed; `human_annotations.json` preserved (id-preserving promote). Backup `.gold_backups/gold_v3-pre-promote-*`. Correction (2026-08-20): pass-1 already probes the **natural question** (runner updated Aug 13; verify entries carry "getting out?", zero legacy phrasings). The subtype/source pass was then updated to match — `pass2_user(formulated=…)` adds the natural question as context, `SOURCE_PROMPT_VERSION …-r5-v2`, source caches cleared and re-probed (jobs 526846/847, all 439 entries `…-r5-v2`) → `gold_v3` rebuilt (526848). The **whole M2 now uses the natural questions**; subtype values unchanged (independent of the particle), annotations preserved.
- **Public site:** added `site/reports/pipeline.html` — end-to-end pipeline + the gate ablation as an "ablation" section (Figure 1 flow, Table 1 fixes, Table 2 gate agreement); nav = Home | Pipeline & ablations | Tree-CRF verifier | Proposals. Pushed to github `BorrisonXiao/SCALE26-AViD`.
- **Display-label fix (2026-08-26):** the particle now also folds into the event node's `display_text` (`gets` → label **`gets out`**) so the tree/viewer label matches the probe question ("getting out?"). `unit_text`/id stay the bare anchor `gets` → **display-only**: no id churn, no cache invalidation, no re-probe; predictions + `human_annotations.json` unchanged. `semantic_factor_tree.py` ~L654 (gated on `event_particle`); gold_v3 rebuilt (CPU).
- **Annotation evidence-subtypes (2026-08-26):** the gold_v3 viewer now collects the *evidence subtype* per unit, not just yes/no. Visual dropdown → `no / ocr / other_visual / both / cannot_tell`; audio → `no / speech / other_audio / both / cannot_tell` (`both` = two subtypes co-occur: captioned sign = OCR + other-visual, chant = speech + other-audio). Names match the model's `source_pred` space (ocr/other_visual/speech/other_audio) so human↔model is a direct set-membership comparison; realizes the ADR-015 (2026-07-06) `both` refinement in the UI. **Back-compat verified:** same localStorage key (`avid_gold_v3_simple_v4`); `opts()` now renders any value not in the list, so existing `yes` annotations survive as a selected `yes (pick subtype)` option to refine (disk file had 16 items / 20 `yes` values — preserved, mtime unchanged after rebuild). Export + template bumped `semantic-human-annotation-v4 → v5`; the `visual_gold`/`audio_gold` TSV columns carry the subtype unchanged. Edits in `build_semantic_annotation.py` (EV_VIS/EV_AUD consts, `label` map, `opts` legacy-render, intro rules 2–3). JS re-validated with `node --check`. **Follow-up (same day):** after all 20 legacy `yes` rows were relabeled to real subtypes (disk: 0 `yes` remaining), removed the transitional `opts()` legacy-render and the `yes:'yes (pick subtype)'` label entry — the latter had also leaked into the read-only model-reference line (`pv`→`label`), so `label('yes')` now correctly renders `"yes"` there. Dropdown options are now strictly the canonical per-channel list.
- **Dual-route visual questions — ADR-022 (2026-08-26):** added the on-screen-text (OCR) route to every visual pass-1 question (`semantic_factor_tree.py` `_node_questions`/`_factor_questions`, strict append-only; `FORMULATE_VIS_SYSTEM`; `SOURCE_PROMPT_VERSION → -r5-v3`), reversing ADR-012's "visual unchanged" clause. Trees regenerated (0 node-set changes / id-preserving across 2,375 claims; 99.9% coverage), gold_v3 rebuilt (annotations untouched), gold visual re-probed twice on A100 (jobs 549701/551771 pass-1, 549702/551772 source; first pass had an agent/theme rewording confound, fixed by append-only). **Result: negative/neutral** — yes-rate fell 56.0%→50.8% (OCR +12 no→yes vs compound-question −31 yes→no −12 ct→no); accuracy on the 24 human-annotated visual nodes **unchanged (79%=79%)**. On the Apollo 11 example (`T2G_ACMxR_I4_1111`) the model's `no` on the agent-binding is **expected** — the on-screen text is just **not captured by the model's OCR** (a VL capability limit), per the annotator. This is likely why the dual-route was neutral: the question invites OCR, but the model's weak on-screen-text reading is the bottleneck. (The `Apollo 11` entity=yes is a separate model FP.) Full analysis in ADR-022 (Empirical result). Keep/revert/system-prompt-pivot **pending user decision**.
- **Tense-aware OCR route (2026-08-27):** per user, the real gap was **tense** — the templates hard-gerundized (`_gerund`) so past claims ("landed") were asked as present ("landing"). Fixed: OCR/text route now uses the claim's **surface form** (finite tense) while depiction keeps the gerund — event/agent/theme/manner/eventive-loc-dir, via new `_ps` helper in `semantic_factor_tree.py` (parse `node_text` carries tense, so no conjugation table). e.g. agent → "Is Apollo 11 the one landing in the video, or does on-screen text state that Apollo 11 **landed**?". id-preserving, 99.9% coverage, gold_v3 rebuilt (annotations untouched), re-probed (jobs 567607/567608). **Result:** yes-rate 49.9% (≈ present-dual 50.8%, still < 56% baseline), accuracy vs the 24 gold nodes **unchanged 79%**, Apollo agent still `no` — the model's **OCR capture** is the bottleneck, not tense. The questions are now correct (esp. for human annotation); model behavior is OCR-capture-bound. Full detail in ADR-022.
- **ASR coverage gap (2026-08-26, diagnosis):** the gold_v3 viewer shows "No ASR transcript" for **29/43 claims** because the upstream ASR JSON is simply **absent** for those video chunks — not a viewer bug. Example: claim `T2G_ACMxR_I4_1111` ("Apollo 11 landed on the moon") → chunk `mN-IA2q2qzs3ViUj_0000.mp4`, and no `asr/{whisperxlargev3,qwen3asr1p7b}/mN-IA2q2qzs3ViUj_0000.asr_*.json` exists. `load_asr()` (build_semantic_annotation.py L115) silently returns `[]` when the file is missing. **Scope (corpus-wide):** 78/200 AViD manifest chunks (**39%**) lack ASR; **all 78 have their source video present** in `data/extracted/microvent/videos/`, and the missing stems are absent from the ASR dir entirely (not a naming mismatch). **Cause:** ASR is produced by an upstream pipeline (full schema: `diarization/vad/embeddings/qc_flags/asr_backend`; producer is NOT in AViD — appears to be a separate `unasr`/`rubasr` project) that transcribed 852 videos by ~2026-05-30 but never covered these chunks (coverage gap, likely videos added to the AViD manifest after that ASR run). **Fix options (pending user):** (1) re-run the upstream ASR pipeline on the 78 missing videos → JSONs into `asr/{system}/` → rebuild gold_v3 (full fidelity); (2) AViD-local whisperX/Qwen3-ASR stopgap writing just `transcript.segments[].text` (all the viewer needs).
- **Prompt selection:** `sfu-v3`, `sf-v3`, and revised natural-language `sfq-v4` are selected. The question audit scores v1/v2/v3/v4 = 0.825/0.850/0.925/1.000. No AViD claim content was sent to the external judge. The unchanged gold-v2 sample was excluded from selection and reused only as the new annotation surface.
- **Validation:** full corpus 2,375 claims; factor topology passes throughout; four overspanned parser units remain explicit locality warnings. Gold-v3: 43 claims, 507 human-visible targets; composition/fixed operators are hidden; normalization gold is binary `not_na`/`na`; quality and relation-class gold are removed. Five-page public site and annotation HTML pass the HTML-report validator; inline JavaScript and server Python compile.
- **Serving:** replaced the old gold-v2 process in `c1:pilotv3`; gold-v3 is live on localhost port 9000 with verified HTML and MP4 range responses.
- **Operational limitation:** `sinfo` returned `Unable to contact slurm controller`; a cached Qwen3-0.6B CPU sample was too slow to scale. External AViD processing was blocked pending explicit user authorization, so no AViD content left the machine. Gold-v3 currently uses checked deterministic natural wording; the LLM rewrite remains a transparent pending cache, not a hidden claim.

### 2026-10-01 — Learning-component research scan (data, verifier fine-tuning, binding, learning through the tree, joint embeddings)
- **Status:** Research complete; no experiments launched; decision pending (user).
- **What:** four parallel web-verified literature scans + direct re-checks; digest appended to
  `research/LITERATURE.md` ("Update (2026-10-01)") and `research/literature.json` (+26 papers, gaps G6–G10).
  Backups: `research/.LITERATURE.md.bak-2026-10-01`, `research/.literature.json.bak-2026-10-01`.
- **New competitors:** OmniHallu (EMNLP 2026 Findings; learned, abstaining verifier over atomic claims with
  modality experts) and Bonsai (Sanders & Van Durme, JHU; training-free probabilistic trees over multimodal
  evidence incl. video/audio) — both must be cited; Bonsai belongs in the baseline set next to BTProp.
  **Name collision:** an AV-inconsistency benchmark "AVID" (arXiv:2604.13593).
- **Novelty check:** BTProp learns nothing through its tree (node-labelled emission histograms, hand-set
  transitions). Training probes + relation-typed transitions through the exact tree-CRF from claim-level +
  perturbation labels for AV claims was not found (closest: FGVE image MIL; LASER CLIP video scene graphs).
- **"JEV":** most plausibly TypeSafe AI's *Jev* (calibrated typed-decision model, Sep 2026; Visual Jev = shared
  context + batched questions + answer-supervised post-training). No joint-embedding method of that name.
- **Status snapshot at scan time:** full-corpus M2/M3 still on the ADR-019 `T*` surface; the ADR-021 semantic
  factor tree is probed only on the 42-claim gold subset; gold_v3 on disk = 4/43 claims (44 items, 2026-09-24);
  only the flat whole-claim baseline is built (BTProp / DEFAME / DSG / Bonsai not yet).
- **⚠️ Storage:** `/exp/cxiao` at **96% (229 GB free)** — below the 10% threshold; any dataset download needs
  user sign-off first.


### 2026-10-08 — Save annotations on example completion

- Updated the active `exp/phase3/gold_v3/index.html` and its generator,
  `scripts/build_semantic_annotation.py`. A complete example requires both claim
  verdicts and all target annotations (NA, or applicable with visual/audio labels).
  The transition to complete sends one save request. Later corrections and notes
  use the example's **Save example** button.
- Field edits remain in tab memory. Browser storage and cluster writes occur only
  when complete examples are saved. Each request starts from the persisted snapshot
  and replaces only completed examples, preserving existing partial annotations and
  excluding new drafts from other examples. Page loading sends no save request.
  JSON/TSV downloads still include drafts; leaving the page with unsaved edits warns.
- Applicability edits update only the affected row, avoiding full page rebuilds and
  interruptions to video/audio playback. Save requests run sequentially; failures
  retain the completed browser copy and expose **Retry save**.
- Validation: Python/JavaScript syntax, generator/live HTML agreement, and temporary
  Node checks for completion, partial fields, unrelated drafts, existing data,
  explicit corrections, serialized requests, failed-save retry, unload warnings,
  and applicability edits without rerendering all passed. Existing annotation file
  unchanged: 4 claim entries / 44 item entries; SHA256
  `ef8a453e56b4660bb9ee10a80faa19f7b8945a894e514f6351e52b42c4326f59`.
- Serving in tmux **`c1:3`** (window **`annotation`**) on
  `http://127.0.0.1:9000/`. Live HTTP 200 and completion-save controls verified;
  saved annotation SHA256 remained unchanged after restart.


### 2026-10-08 — Independent paper-direction review and temporal-binding proposal

- **Status:** Research/recommendation complete; no new model inference, training, dataset download, or architecture change.
- **Artifacts:** `research/2026-10-08/{RECOMMENDATION.md,PROJECT_REVIEW.md,LITERATURE.md,literature.json,source_index.md,evidence_audit.json,audit_current_status.py}`. Existing research digest and experiment/annotation files preserved.
- **Independent audit:** Recomputed 2,375 natural outputs and paired detection totals (N=2,936; CRF 2,150, flat 1,500). Historical binding edits are cross-video entity replacements; placeholder removal and negation probe reuse limit interpretation. Latest semantic probes = 439 targets / 42 claims per channel; saved human labels = 4 claims / 44 targets. Current graph has 22,939 observable targets before modality expansion.
- **Fresh primary-source survey:** 23 verified entries. Newly consequential competitors include OmniHalluc-L/MPRC, RECAP, Relation-Orbit, FV-Action, TFVTG, HERBench, and SG-PVR. Synthetic swaps, frozen calibration, and tree aggregation alone are insufficient novelty claims. VELOCITI is explicitly test-only and gated; OmniHalluc-L full data is not yet in its public repository.
- **User's temporal-confinement follow-up incorporated:** Prioritize 40–50 validated binding pairs comparing full-clip, joint-tuple, oracle-window, parent/child-union, and automatic shared-event verification. Union is a proposal baseline; disconnected evidence does not certify binding. Count localization budget and control frame density. Keep frozen backbones; a small selector/scorer is optional if local features contain signal. Three-week scope with an early oracle-to-automatic go/no-go gate; CRF remains an ablation rather than a required centerpiece.
- **Validation:** Offline audit executed; JSON schemas/unique bibliography IDs, local Markdown links, and recomputed paired totals checked. Recommendations are provisional research hypotheses, not achieved method results or accepted architecture decisions.

### 2026-10-14 — Probabilistic evidence-parsing methods formulation

- **Status:** Independent literature/formulation review complete; no new model inference, training, downloads, publication, annotation edits, or architecture changes.
- **Artifacts:** `research/2026-10-14/{README.md,METHOD_FORMULATION.md,REVIEW_QUESTIONS.md,LITERATURE.md,literature.json,source_index.md}`. The questions document contains twelve drafting/review questions; the method document compares the October 8 temporal recommendation and current code with the proposed framework.
- **User-confirmed direction:** Typed support from depiction, sound, speech, or OCR; inference over alternative evidence alignments; interchangeable predefined and learned binding functions. Deterministic rules can be point-mass conditional kernels. “Explicit binding semantics” specifies the variables/proposition being judged, rather than requiring fixed functions.
- **Recommendation:** A restricted claim-conditioned evidence recognizer with shared entity/event candidates, typed kernel interface, and S/R/U semantics; temporal constraints become an extension. General module interchange or a renamed parse/CRF is insufficient novelty. The proposed algorithm carries boundary grounding assignments during composition; no new recognizer has been implemented.
- **Primary-source comparison:** Seventeen verified papers, including semiring parsing, neural modules, DeepProbLog, Scallop, DSG, BTProp, Bonsai, OmniHallu, Proof-of-Perception, and SG-PVR. Probabilistic composition, shared-variable logic, and modular uncertainty all have close precedents. Proof-of-Perception's official record/repository were verified, but full venue paper access returned 403; detailed guarantees remain unassessed.
- **Current evidence:** Saved human coverage rechecked at 4 claims / 44 targets. Existing uniform `{no,A,B}` support mass is 2/3 versus the 0.65 threshold; final root takes a maximum of separate audio/visual support. These motivate state/combination semantics review without establishing that all prior outputs are wrong.
- **Feasibility gate:** Begin with 40–60 validated pairs and unknown/paraphrase/duplicate controls. Compare identical-observation composition and equal-budget end-to-end methods, fixed versus small learned kernels, and one perception-module replacement. Keep the total project near three weeks; return to the temporal story if crops explain all benefit, and stop expanding aggregation if oracle-grounded complete-relation queries lack signal.
- **Validation:** Bibliography JSON, seventeen unique verified IDs, user clarifications, twelve sequential questions, and all local Markdown links checked. No claimed accuracy gains or proved new guarantees.

### 2026-10-14 — Adopt paper direction, draft HTML design, and persist memory

- **User decision:** Probabilistic parsing for multimodal claim verification is the chosen paper direction, likely finalized. Recorded as ADR-023, amending the earlier mandatory training-free tree-CRF headline and immediate-endpoint/fixed-tree constraints. Existing evaluation gold and old artifacts remain preserved.
- **HTML:** site/proposals/probabilistic-verification.html; reproducible generator scripts/build_probabilistic_verification_proposal.py. Covers claim compilation, shared variables, typed evidence, alternative assignments, fixed/learned functions, explicit supported/refuted/unknown states, learning through probabilistic inference, temporal constraints, data construction, and evaluation.
- **Parameterization:** Linear classifier control and one-hidden-layer MLP as the initial relation model; 64 hidden units proposed. Optional frozen BERT-style features; BERT cross-encoder comparison when justified. Decoder-only models remain frozen parsing/evidence modules or baselines. A small categorical scorer can learn competing evidence assignments. No multimodal LLM fine-tuning.
- **Navigation:** Added the current proposal to the collection and home page; labeled earlier tree-CRF results historical and qualified their distant-label interpretation. Updated site README and marked the dated review as historical background to the accepted direction.
- **Project memory:** Updated decisions.md, key_facts.md, terminology.md, project/root CLAUDE.md, and project/root AGENTS.md. Standard NLP terminology and clear plain language are a vital user preference; no invented component names or acronyms.
- **Global memory:** Saved the preference and project-scoped pointer to /home/hltcoe/cxiao/.codex/AGENTS.md, appended the writing preference to /home/hltcoe/cxiao/.claude/CLAUDE.md, and saved project continuation memory to /home/hltcoe/cxiao/.claude/projects/-exp-cxiao-scale26-avid/memory/MEMORY.md. Verified the saved files. Global Codex guidance was subsequently loaded into the session.
- **Validation:** Single-page and complete 7-page site HTML/link validation passed. Checked Python syntax without bytecode output, five equations and MathJax delimiters, six numbered tables, two numbered figures, anchors, JavaScript syntax, eight interactive binding/coverage cases, UI update behavior, exact illustrative parameter arithmetic, and reproducible HTML generation. No browser was available for visual viewport inspection.
- **Scope:** Documentation and memory only. No model training/inference, downloads, commits, or publication. The new design's empirical performance remains unmeasured.

### 2026-10-14 — Prioritize data preparation, baselines, and a probabilistic-learning prototype

- **Artifact:** research/2026-10-14/IMPLEMENTATION_PLAN.md, linked from the research README. This is a recommendation under ADR-023, not an experiment launch or a revised paper direction.
- **Read-only inventory:** 2,375 semantic claim records map to 189 source-video IDs. Existing phase-3 gold*/claims.tsv packages select 239 unique claims from 102 videos; all IDs matched the source manifest. Reserving those videos provisionally leaves 87 structured-claim videos for new development candidates. Selected examples are not equivalent to completed gold labels.
- **Reusable observations:** Whole-claim files contain 7,931 rows per modality across original/edited claims. Current semantic observations remain 439 targets / 42 claims per modality; saved gold_v3 labels remain 4 claims / 44 targets, with no separate saved gold_v4 annotations.
- **Reuse with changes:** run_m2_probe.py supports target TSVs and three-way scores. The flat postprocessor merges unknown with unsupported, the old edit generator uses cross-video replacements/placeholders, and the calibration script fits CRF pseudo-labels with a claim-level split. Recommend new independent-label calibration, source-video partitions, explicit observation/cache metadata, and a common three-way evaluator.
- **Recommended work order:** source-video inventory/splits and a 40–60-pair claim/relation annotation pilot; common whole-claim/full-relation/fixed-program baseline interface; CPU checks for categorical states, shared-event composition, duplicate evidence, and gradient updates; then linear/MLP learning on binding-sensitive cached features. Defer BERT sweeps, full-corpus inference, and large synthetic datasets.
- **Backend check:** Current official DeepProbLog README also points to DeepLog from the same group. Neither backend nor ProbLog was present in the inspected vllm-omni package directories. Recommend a time-limited isolated environment/API check; no packages were installed. VELOCITI's official test-only condition was rechecked; it is a possible later external evaluation, not training data.
- **Scope:** No model inference/training, new data generation, annotation edits, downloads, or split creation. Plan local links and inventory arithmetic validated.

### 2026-10-15 — Add preparation tasks and LLM-assisted data/baseline workflow to the webpage

- **Page:** site/proposals/probabilistic-verification.html now includes first-week deliverables, data/split preparation, assistant-supervised local-model generation and media review, initial baseline configurations, and automatic versus independently reviewed labels. Adoption remains 2026-10-14; page update is dated 2026-10-15.
- **Workflow:** Propose 10 checked seed claims and at most three variants each before expanding. Use the local text model for edits/paraphrases and visual/audio models for standalone media review; keep paired claims, edit type, and proposed labels hidden from the review request. The assistant maintains prompts/code and inspects failures, while deterministic code handles splits, metadata, normalization, and evaluation.
- **Quality:** Automatic/silver training labels require auditing; a small independently checked final test remains separate. Model agreement and a review of generated descriptions alone do not establish media truth. Include disagreements, unknown cases, fluent positives, and text-only shortcut checks.
- **Prepared code:** Added opt-in generation/review/direct-verification prompt drafts and JSON user-prompt builders to scripts/prompts_phase2.py, version verification-preparation-v1. The page displays the canonical strings directly. No runner integration or model batch has been executed; existing PROMPT_VERSION and inference defaults are unchanged.
- **Supporting docs:** Updated the implementation checklist, proposal collection, site README, key facts, and source index. Verified primary Self-Instruct, SugarCrepe, and LLM-as-a-judge sources; no claimed label-quality or labor-saving percentage.
- **Validation:** Python syntax, JSON/Unicode round-trip, standalone-review fields and rejection of a proposed-label argument, legacy default, exact HTML prompt excerpts, sixteen section numbers/anchors, nine table captions, five equations, adoption/update dates, reproducible page generation, local document links, JavaScript syntax, and all seven site pages passed. Browser rendering was not available.
- **Scope:** Page, prompt drafts, and memory only. No training, model inference, data generation, annotation edits, downloads, or publication.

### 2026-10-15 — Execute local generation, inspect samples, revise prompts, and run baselines

- **Status:** Five small GPU jobs completed; larger-model generation and dependent baselines queued.
- **Completed:** Three prompt-development runs on the same ten source-disjoint development videos; assistant inspection of all 71 admitted claims; two explicit attribute-swap plans producing five further claims; checked-form diagnostic. Jobs 1028631/1028656/1028666/1028679/1028700 all completed successfully. Total 19m52s allocated L40S time and 702 new requests, with no training or downloads.
- **Quality:** Free-form v1/v2/v3 yielded 0/0/1 clean binding negatives. Explicit assignments yielded two faithful negatives and one usable positive paraphrase. A duplicate was dropped. Full-resolution inspection corrected a chair-location seed and left another clothing description uncertain; both were removed from the next input list. Raw inputs, proposed labels, assistant corrections, failures, and model disagreements are preserved.
- **Baseline finding:** Whole-claim support falls sharply for the two checked color swaps, but both three-way verdicts are unknown rather than refuted. Atomic controls cannot separate pairs when components are held fixed. Complete-relation conjunction does not establish an advantage. No probabilistic backend, classifier learning, audio evaluation, or independent paper accuracy was run.
- **Implementation:** New pilot runner/evaluator, versioned canonical prompts, generation/visual/small/guided Slurm scripts, interactive sample report generator. Frame/model/prompt/configuration hashes and token/timing costs recorded; model review hides construction labels. Text-only missing-media controls are assessed for abstention.
- **Next queued jobs:** 1028682 (Qwen3-30B generation, eight eligible videos, A100-80GB); 1028694 (dependent visual review/baselines, A100-40GB). Earlier pending v1 jobs 1028628/1028629 canceled to avoid obsolete-prompt inference. Inspect the existing jobs and outputs before relaunching.
- **Recommendation:** Ground a small fact list, make specified argument/attribute swaps in code, use local LLMs for fluent realization, and audit against full-resolution media. Preserve an independent final test and compare whole-claim calibration before attributing gains to the chosen framework. ADR-023 remains the direction.
- **Artifacts:** exp/probabilistic_verification/pilot_20261015/, site/reports/verification-pilot.html, proposal section 17. Detailed results are in key_facts.md and per-run summary.json files.
- **Validation:** All eight site pages pass HTML/link validation; inline report JavaScript and all four Slurm scripts pass syntax checks. Both HTML artifacts rebuild identically. Checked 528 normalized score records (including reused records), 702 new requests, hidden construction labels in media requests, source-video reservation separation, identical component requests within checked pairs, and explicit unknown/refutation aggregation behavior. No browser was available for viewport rendering.

### 2026-10-15 — Publish generated examples on the paper-design page

- **Status:** Published and verified live.
- **Content:** Added section 18 with five saved examples: two accepted attribute-swap negatives, a supported paraphrase, a rejected clause reordering, and a rejected negative that remains supported under another participant assignment. Included source frames, exact seed/generated sentences, assistant review labels, model scores, and links to the complete records. Human gold remains distinct from assistant checks.
- **Code:** scripts/build_verification_examples.py supplies the selected examples from saved JSONL records; the proposal and sample-report generators add anchors and cross-links. The full report explicitly covers the five inspected L40S configurations. Later A100 outputs are not silently added to the audited counts.
- **Publication:** The independent site repository is rooted at avid/site, remote git@github.com:BorrisonXiao/SCALE26-AViD.git. Pushed main commit 1452d8f0b6007db9c8b97122cd58ea0c7905dcf7. GitHub Pages workflow 38764262158 completed successfully. Four live URLs returned HTTP 200 and their SHA-256 hashes matched the validated local files.
- **Links:** https://borrisonxiao.github.io/SCALE26-AViD/proposals/probabilistic-verification.html#generated-examples ; https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pilot.html
- **Validation:** Eight site pages pass HTML/link validation; proposal/report inline JavaScript passes syntax checks; all five exact sample anchors resolve; five numbered figures on the main design page. No browser was available for viewport rendering.
- **Job-status correction:** 1028682 completed successfully in 00:13:31; 1028694 completed successfully in 00:05:51. Automatic outputs exist for eight seeds / 32 claims in exp/probabilistic_verification/pilot_20261015/v3/. Their sample-quality review is pending; no new label-quality or paper-performance claim is made. Updated the published stale queue wording.

### 2026-10-21 — Clarify DeepProbLog learning, parameterization, and training cost

- **Status:** Source-based explanation; no implementation or training experiment. ADR-023 remains unchanged.
- **Verified implementation:** The official DeepProbLog [training loop](https://github.com/ML-KULeuven/deepproblog/blob/master/src/deepproblog/train.py) is Python. Its neural-network wrapper accepts PyTorch modules and optimizers; the current graph-semiring loss calls PyTorch backward. Exact-engine examples enable circuit caching and neural batching. These features do not establish efficient large-model training for our workload.
- **Modeling clarification:** DeepProbLog provides probabilistic inference at training and prediction time, plus gradients from query-level supervision. Our compiler supplies shared entity/event variables and rules; a neural relation classifier learns evidence-sensitive probabilities. Weak claim labels alone may not identify which local relation failed. Binary unsupported labels do not separately identify refutation and insufficient evidence.
- **Parameterization and data:** The initial plan remains a linear classifier/small MLP on cached, candidate-specific observations from frozen perception models; real media with verified synthetic claim edits and positive controls. Presence-only features cannot recover missing argument associations. LoRA would be an additional design choice, not the current initial implementation.
- **PEFT and efficiency:** Compatibility is plausible from the PyTorch interfaces and PEFT's support for custom training loops, but has not been integration-tested. Adapter training requires differentiable model probabilities and fresh training forward passes; cached JSON/inference outputs cannot train the producing adapter. Cache frozen observations and fixed logical circuits separately; recompute trainable classifier outputs each update. Bound candidate combinations and measure grounding/compilation/evaluation/backward costs before scaling.
- **Sources:** [DeepProbLog paper, sections 4–5](https://papers.nips.cc/paper/7632-deepproblog-neural-probabilistic-logic-programming.pdf), [network wrapper](https://github.com/ML-KULeuven/deepproblog/blob/master/src/deepproblog/network.py), [graph-semiring loss](https://github.com/ML-KULeuven/deepproblog/blob/master/src/deepproblog/semiring/graph_semiring.py), [solver cache](https://github.com/ML-KULeuven/deepproblog/blob/master/src/deepproblog/solver.py), [PEFT custom-model guide](https://github.com/huggingface/peft/blob/main/docs/source/developer_guides/custom_models.md).

### 2026-10-21 — Map existing parsing and role typing to the logical-form compiler

- **Status:** Read-only code audit and design clarification under ADR-023; no implementation, training, or new architecture decision.
- **Reuse:** Dependency parsing, normalized claim spans, entity/event/state types, semantic relation labels, and selected question-generation code supply the text front end. Semantic role typing describes the relation asserted by the claim; the learned evidence classifier judges whether a candidate media assignment supports it. Freeze the text front end initially; claim-level gradients do not update its discrete decisions automatically.
- **Required extension:** Existing semantic_factor_tree.py emits a fixed tree with immediate-endpoint relations. Claim-node identifiers do not identify media instances. The restricted logical-form compiler must preserve shared variables, argument order, attachment and scope, then connect them to bounded candidate evidence assignments and complete-relation observations as needed. The old CRF topology and composition rules are not requirements of the new design.
- **Audit point:** Existing normalization includes temporal-to-na filtering and coarse modifier rules. Reuse these selectively; absence of an independent probe must not delete a condition from the claim's meaning. Role labels can select classifier inputs or rules without requiring a separate network for each label.
- **Evidence:** scripts/parse_claims.py, build_tree.py, normalize_parse.py, run_pn2_srl.py, semantic_factor_tree.py (especially default_relation and compile_tree), and the current proposal generator. Correct logical-form translation and candidate coverage remain unmeasured requirements, rather than capabilities established by tree topology checks.

### 2026-10-22 — Implement restricted claim compilation, DeepProbLog inference, and sample training

- **Status:** Implemented, executed, published, and verified live with an Implementation sub-tab. ADR-023 is unchanged. This is a tentative prototype, not held-out method validation.
- **Code:** scripts/probabilistic_verification/ separates source-linked logical forms, deterministic UD compilation, frozen Stanza parsing, bounded candidate assignment, categorical logic generation, and the actual DeepProbLog backend. compile_verification_claim.py accepts raw text or existing UD JSON. run_verification_pipeline.py replays all examples from cached inputs; instructions are in docs/probabilistic_verification_implementation.md.
- **Semantics:** Complete ordered event/participant tuples; shared variables; branch-local entity references; event existence inside negation; explicit supported/refuted/unknown outcomes; canonical observation reuse; incomplete candidate inventories and missing observations remain unknown. Unhandled content is rejected with source-word diagnostics.
- **Execution:** Reused six real frozen Qwen3-VL-8B observations from October 15 and parsed shorter aircraft/bus color claims automatically. Native DeepProbLog sample training fits a 643-parameter score classifier on two assistant-labeled development claims from one video, with no local supervision. Three constructed event cases separately test same-event and reversed-role behavior. No new GPU requests, model downloads, audio inference, or multimodal-model training.
- **Validation:** 23 semantic/probability/training tests pass, including independent categorical-world enumeration, duplicate/shared proof paths, negation, same-event candidates, and finite nonzero gradients. The automatic parser/compiler has 15/18 expected hand-selected outcomes: 7 intended claims compile, 8 unsupported cases are rejected, and 3 waves-as-noun parses remain visible rejections. Fixed near-identity probability simplification in the pinned DeepProbLog interface; distributions conserve mass without renormalization.
- **Report:** site/reports/verification-pipeline.html, generated from saved traces. Four views cover real media, same-event diagnostics, native sample training, and compiler checks. Includes 14 numbered figures, 27 numbered tables, exact predicate/observation/query mappings, raw programs/scores, failure diagnostics, and downloadable source with cached inputs. Main proposal, home, collection, and October 15 report link to the new page.
- **Browser review:** Chromium checks passed for tabs, case selectors, keyboard navigation, equations, and 390-pixel mobile layout, including dark mode; no page errors. Manual screenshot inspection found and corrected Graphviz's escaped Unicode arrow labels. All nine HTML pages and inline JavaScript validate.
- **Reproduction:** Extracted the downloadable source ZIP into a fresh temporary directory and replayed the full compiler/inference/training runner using only its cached inputs. Every displayed verdict distribution reproduced within 1e-12; no parser/model download or GPU was needed.
- **Publication:** Pushed site commit 9526dae761eb8088d983be8ca2b9d14edcbafdcf. Pages workflow 39723271163 completed successfully. Six live URLs, including the implementation page, parent navigation, source ZIP, traces, and learned program, returned HTTP 200 with exact local SHA-256 matches. Link: https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html . Site worktree is clean. Standalone compiler CLI checks also passed for compiled and unsupported inputs.
- **Limits:** Manually specified real-media referents; frozen scores modeled as independent except exact reuse; score calibration rather than learned visual perception; the same two claims are used before/after training; no independent paper accuracy. Larger October 15 A100 outputs still require a separate quality review.


### 2026-10-22 — Inspect frozen features and separate visual/audio trees

- **Status:** Initial feature pilot and two-source inference prototype completed;
  publication verification follows. Five-step checklist added with completed and
  pending items; larger data preparation and feature-head training remain pending.
- **Implemented:** Real pre-answer representations, matched/unrelated/blank/text
  controls, independent ASR/audio description, per-modality edit reviews, separate
  trees, predicate-level source combination, missing-input separation, and conflict
  diagnostics. Ten claims/control traces from one development source, not a benchmark.
- **Found:** Caption-to-speech leakage (silent-frame Alaska mention support 99.68%)
  and severe audio music priors on silence/text-only controls. Revised audio chat
  template and generation settings repair the unusable description but leave the
  music control failure. Preserve raw initial and final outputs.
- **Review boundary:** Images inspected directly; audio cannot be directly heard
  through this interface. All audio-dependent labels remain provisional and no
  cases are eligible for training yet. Do not infer instrumental music solely from
  no intelligible words. The published WAV supports user review.
- **Validation:** 28 automated tests pass; 30 backend distributions match the
  independent probability oracle. Fresh-source replay reproduces probabilities,
  feature diagnostics and feature hashes exactly. Nine pages validate; six tabs,
  equations, desktop/mobile/dark rendering and local audio links pass browser checks.
- **Next:** Human audio confirmation, multi-video feature utility checks including
  missing/mismatched controls, then linear/MLP classifiers and source-video splits.
  Automatic cross-modal identity matching and source/content scope remain open.

- **Published and verified:** site commit
  **54a666ef827f8592d6a5a87925c9df6e7583df32**; Pages workflow
  **39853278600** succeeded. Eight live report/artifact URLs returned HTTP 200
  with exact local SHA-256 matches, including the audio WAV and source ZIP.
  The site worktree is clean. Main links:
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#audiovisual
  and the same page at `#next-steps`. Publication details:
  exp/probabilistic_verification/av_features_20261022/publication.json.

### 2026-10-28 — Explain dependency-tree compilation in the implementation report

- **Status:** Report/documentation update pushed on 28 October at the user’s
  request. No new perception requests, training run, annotation change, or
  architecture change.
- **Reviewed:** ADR-023, current implementation notes, October 22 compiler/training
  results and frozen visual/audio feature audit, and the compiler, representation,
  grounding, multimodal, and backend interfaces. Feature-based classifiers and
  held-out evaluation remain pending.
- **Added:** Compilation walkthrough tab at
  `site/reports/verification-pipeline.html#compilation-guide`. Plain-language
  explanations distinguish AND/OR/NOT/EXISTS from entity, attribute, event,
  possession, and complete action predicates, plus the separate two-source
  evidence operation. Walkthrough covers UD rules, active/passive roles, scoped
  negation, OR-local references, shared names, complete/incomplete candidate
  inventories, canonical observation reuse, generated ProbLog, and rejections.
- **Reproducibility:** `scripts/build_compilation_guide.py` reruns eight examples
  and eight diagnostic cases from cached/explicitly supplied parses. Automatic
  versus hand-specified inputs are labeled. Exact inputs/outputs and grounding
  trace are downloadable as `verification-pipeline/compilation_guide.json`;
  source ZIP includes the guide generator. The main report generator and
  `docs/probabilistic_verification_implementation.md` document the new view.
- **Validation:** All 28 existing compiler/inference/multimodal tests pass;
  current compiler outputs match cached successful logical forms; all eight
  unsupported examples still reject. Updated page and all nine site pages pass
  HTML/link validation. No new accuracy or generalization result is claimed.
- **Browser review:** Seven-tab navigation, direct guide hash, expandable examples,
  keyboard navigation, desktop and 390-pixel dark-mode layout pass Chromium checks;
  no page errors or horizontal page overflow. Chromium required execution outside
  the filesystem/network sandbox because the sandbox denies its socket operations.

- **User preference (2026-10-28):** Push completed, validated changes by default;
  verify report deployment and provide the live link. Persisted in the project-root
  `AGENTS.md`. Site commit: `e8bc4a384ea6e3a695e814fa8a1921f83da6f16a`.
- **Publication verified:** Pages workflow `40734011613` succeeded. The live
  report, guide JSON, and source ZIP each returned HTTP 200 and matched the
  committed local files byte-for-byte. Site worktree is clean. Live tab:
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#compilation-guide
  Verification record:
  `exp/probabilistic_verification/compiler_20261022/compilation_guide_publication_20261028.json`.


### 2026-10-28 — Reprioritize compiler audit and document temporal support

- **Requested:** Update the TODO checklist after accepting a compiler-first audit;
  explain whether landed/is landing are currently distinguished.
- **Changed:** Checklist now leads with real-claim auditing, semantic parsing
  including tense/aspect, and contrastive tests. Completed feature/source pilots
  remain recorded. Added a temporal status note, measured six-sentence diagnostic
  and proposed support requirements with source references. No compiler behavior
  changed and no full dataset audit or classifier training was launched.
- **Found:** Four spacecraft tense/aspect forms compile identically. Both Apollo
  11 examples reject on the number-in-name/counting guard. The main verb’s token
  tense cannot supply clause tense by itself; auxiliaries must be interpreted.
- **Artifacts:** temporal_audit_20261028/current_behavior.json; updated
  build_av_feature_sections.py and report generator; implementation docs and
  project memory reflect confirmed priorities and the unimplemented temporal gap.

- **Validation/publication:** All nine site pages pass HTML/link checks. Chromium
  verifies seven tabs, eight ordered priorities, six measured diagnostic cases,
  sequential table captions, and desktop/mobile/dark layouts with no page errors
  or document overflow. Site commit e98f415ef3ab552a769fb883bdae897371afe9dd;
  Pages workflow 40740248036 succeeded. Five live page/data/archive URLs return
  HTTP 200 and match committed bytes. Site worktree is clean. Live checklist:
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#next-steps
  Details: exp/probabilistic_verification/temporal_audit_20261028/publication.json.


### 2026-10-28 — Complete the real-claim compilation audit

- **Status:** Census and semantic review complete; checklist synchronized at freeze,
  census, review and analysis milestones. The compiler remains unchanged.
- **Measured:** Current parser pipeline compiles 78/2,375 (3.28%), with 2,268 compiler
  rejections and 29 parser refusals; stored parses compile 79. Both accept 76 with
  identical literal logical forms. No unexpected census exceptions.
- **Reviewed:** 50 random development claims + 20 diagnostics + 9 additional
  accepted cases, covering all 20 accepted development programs. Assistant core
  judgments: 11 adequate restricted cores, 2 meaning errors, 7 unresolved contracts.
  These are not independent human gold, full-meaning accuracy, or media labels.
- **Findings:** Ordinary obliques/locations are unsupported; numeric identifiers
  can trip the count guard. Genitives and compound modifiers can compile with the
  wrong relation/attachment. Source/content and abstract-entity meanings require
  contracts. Tense/aspect remain unencoded. Diagnostics identify first guards and
  should not be treated as complete semantic categories.
- **Validation:** Full frozen-input replay, source/inventory fingerprints, adapter
  checks, fixed-seed sample reproduction, reserved-source exclusion, and fresh
  source-archive replay using system Python with ML imports blocked. New report
  tab and downloadable census/review/source artifacts prepared for publication.
- **Next:** Semantic parsing/representation and contrastive tests before additional
  feature expansion or classifier training. Preserve this frozen baseline for
  comparison; no compiler rule changed during the audit.

- **Report validation/publication:** Updated item and all nine site pages pass
  HTML/link checks. Chromium verifies eight tabs, all 79 review cases and filter
  counts, all four completed audit checklist items, 55 sequential table captions,
  desktop/mobile/dark layouts and no page errors or document overflow. Original
  input-file and compiler fingerprints still match the frozen manifest.
- **Published:** site commit 279021f3d3acc4b658c897e7b5ffdd3e56947caa;
  Pages workflow 40747004834 succeeded. Seven live page/data/archive URLs return
  HTTP 200 with exact local byte matches. Site worktree is clean. Links:
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#compilation-audit
  and the same page at #next-steps. Publication checks are saved in
  exp/probabilistic_verification/compilation_audit_20261028/publication.json.


### 2026-10-28 — Implement and audit the opt-in semantic compiler

- Implemented a frozen-text-model semantic representation plus deterministic
  compilation, complete role tuples, source/content scope, logged normalization,
  and executable tense/aspect checks. Preserve v1 and its entire frozen audit.
- Ran 79 reviewed development claims and 21 constructed contrasts with the frozen
  8B model; tested seven diagnostics with the frozen 30B model. Prompt 2 is still
  unreliable: 11/79 and 3/7 checked programs respectively. Larger model alone does
  not fix source scope or genitives. Revised source prompt plus checked removal
  of unused inner annotations compiles three known failures; without that removal,
  none compile. These are separate development conditions, not accuracy results.
- Reviewed all accepted primary programs and the targeted alternatives. Kept
  failed model outputs and ambiguity in home-run/event/type/role interpretations.
  No world facts are inferred merely because a photo/text/speaker states content.
- 64 tests pass; 16 actual CPU DeepProbLog temporal controls use constructed
  metadata and scores. Baseline replay and source fingerprints remain unchanged.
- Peak four V100s, 2.4022 GPU hours including loading/generation, all jobs complete.
  No new media inference, feature classifier, LLM training or held-out evaluation.
- Artifacts: semantic_compiler_20261028/. Report has a new Compiler improvements
  tab, full logical forms, diagrams, prompts, refusals, reviewed source examples,
  temporal controls, CPU replay and updated checklist. Keep opt-in; validate the
  revised parser on development claims and independent sources before adoption.


- **Final validation:** Nine site pages pass HTML/link validation. Chromium checks
  nine tabs, 100 primary cases and search, 26 reviewed examples, 25 sequential
  figure captions and 62 sequential tables, desktop/mobile/dark layouts, no page
  errors and no document overflow. Mobile diagrams retain readable type and center
  their main branch while allowing horizontal scrolling.
- **Archive replay:** Fresh extraction reproduces 109 saved compiler outcomes
  and validates one recorded parser refusal with Torch/Stanza/Transformers/
  DeepProbLog/vLLM imports blocked. All 64 tests also pass inside the extracted
  archive. Canonical combined generation records remove dependence on worker
  files; the old controlled-evidence helper is included for legacy regressions.
  Details and exact archive hash: semantic_compiler_20261028/archive_verification.json.


- **Published:** site commit 29e58c27e3c991aa6510cd592f4f9e956f1d62bf.
  GitHub Pages workflow 40764894640 completed successfully. All 19 changed live
  page/data/archive URLs return HTTP 200 and match local committed bytes. Site
  worktree is clean. Live result:
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#semantic-compiler
  Checklist: the same page at #next-steps. Exact publication and live hashes:
  semantic_compiler_20261028/publication.json.
- **Publication review resolved:** Automatic review initially withheld the push
  pending data-disclosure evidence. Read-only checks confirmed the prior public
  audit archive by live SHA256, exact unchanged baseline data files, all 78 real
  model-input claims/parses and all 102 reserved memberships already public, and
  no media/model weights in the new archive. The evidence-backed retry was
  approved; this finding applies to this payload, not arbitrary future data.
  Evidence: semantic_compiler_20261028/publication_data_check.json.


### 2026-10-28 — Discuss regression and recover the existing SRL baseline

- Rechecked the trained AllenNLP BERT-SRL cache: all 2,375 current claims aligned;
  76 of 79 reviewed claims have some predicate/argument output. Availability is
  not accuracy. Several examples rejected by the custom front end already have
  useful cached frames. Earlier SRL work chiefly validated role labels rather
  than replacing the mandatory UD backbone.
- Paired v2 comparison loses 12 accepted claims and gains 3. Confirmed a spurious
  lemma-consistency rejection for People are shouting. Compiler tests are not an
  end-to-end semantic parsing evaluation.
- Recommendation for discussion: stop expanding bespoke tree-to-logic parsing;
  make syntax optional, reuse trained SRL, retain semantic bindings/scope and
  existing probabilistic inference. Test the method with reviewed structures
  before further parser tuning. No replacement decision or code/report change.


### 2026-10-28 — Compilation-first comparison and revised plan

Researched primary syntax-to-logic, SRL/AMR and recent NL-to-FOL methods. Ran a
fixed-input comparison on 79 real development claims and 21 controls, with trained
SRL, pretrained BART AMR and direct/assisted frozen 8B graph generation. Implemented
a shared restricted graph compiler and corrected written-content scope after
inspection. All 400 outcomes replay; 77 regression tests pass. Coverage and focused
assistant meaning reviews are separate. No replacement parser selected and no
media-verification expansion or new relation training. Added Compilation approaches
report tab and updated the canonical checklist. Full semantic reference review,
common schema fixes and a bounded clause-level neural alternative remain planned.
See compilation_methods_20261028 in key_facts.md and docs/compilation_methods.md.

Published and verified at https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#compilation-methods (site 4d10b40; 21 live files byte-matched). Source archive independently replayed all 400 outcomes and passed all 77 regression checks.


### 2026-10-28 — Accepted compilation plan and logical-form implementation

Recorded the explicit no-rewriting constraint and clarified representation/interface.
Implemented a common JSON logical form and compiler, recursive source content,
SRL/AMR adapters and a bounded frozen neural comparison. Added 46 assistant reference
cases, reviewed new-source outputs, fixed shared-head/nominal-parent defects, then
froze for ten additional source-disjoint claims. Eight compile under the selection
policy, but qualitative review still finds wrong scope and missing context; keep
opt-in. All 96 regression checks and cached CPU replay pass. No media verification,
new relation training or sentence rewriting. Current report/checklist updated.

Published and verified at https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#compilation-methods (site fd2849f; 34 live files byte-matched). Project memory records both the accepted choices and the explicit prohibition on implementing sentence rewriting yet.

### 2026-10-29 — Full 2,375-claim compiler implementation and census
- **Status:** Experiment and full-corpus run completed; semantic reliability remains open.
- **Work:** Implemented the opt-in v2 compiler and SRL/neural routes; ran all original claims, retained per-claim results and refusals, inspected 100 development cases plus 20 fresh paired cases, and added source/type/scope fixes. No sentence rewriting or media verification/training.
- **Measured:** 1,934 compiled / 441 refused versus 1,544 previously. Fresh twenty: 4 faithful (one mention), 7 partial, 6 incorrect, 3 refused. All 134 tests and full CPU replay pass; 17/19 bounded native checks finish, two time out including startup. Peak 4 GPUs, 1.866111 allocated GPU hours.
- **Review:** See reports/claim-compilation.html for the searchable census, explicit limitations and artifacts. Do not treat acceptance as correctness or start training from unchecked compiled outputs. Publication commit/deployment verification follows below.

- **Publication verified:** Site commit 772a7df9849df88ab4531b63d3beccd15f7ef6a4; Pages workflow 40880365246 succeeded. All 15 changed live files byte-match local artifacts, including every report download and source ZIP. The independently extracted archive reproduces all 2,375 selected outcomes and passes all 134 tests. Browser checks cover all filters, desktop/mobile and dark mode with no page errors or overflow. All six historical source archives remain unchanged. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-compilation.html. Evidence: full_compilation_20261029/publication.json, archive_verification.json and browser_checks.json.

### 2026-10-29 — SRL-only compiler and concise parse-editing comparison

- **Status:** Full 2,375-input SRL run and fixed 48-case editor comparison complete; semantic reliability remains open.
- **User steering:** Avoid per-claim parser selection as the method. Prefer SRL improvement or revision of supplied parses; remove model-facing schema-version metadata and shorten prompts.
- **Completed:** One SRL/dependency frame graph; separate syntax and syntax+AMR minimal editors; 24-case paired assistant review across all four conditions; source-token/schema validation; 148 regression tests; cached replay. No sentence rewriting or media verification/training.
- **Measured:** 1,997 accepted SRL outputs (1,819 claims, 178 nominal descriptions); earlier SRL 1,344. Both editor conditions have seven faithful outputs on the same 24-case review, equal to the new SRL graph. One editor introduces the wrong performer in a robot-watching claim. Keep the experimental compiler opt-in.
- **Next:** Nominal source scope/participial attachment; structured copular/spatial complements and identity; controllers of embedded predicates. Review complete logical-form references before selecting a default.
- **Artifacts:** exp/probabilistic_verification/srl_revision_20261029/ and site/reports/srl-compilation.html. Deployment verification follows below.

- **Publication verified:** Site commit 1bba0d4e3528b5776922196f6254181389903f25; Pages workflow 40946208147 succeeded. All 13 changed live files byte-match local artifacts, including every download. The independently extracted source ZIP reproduces all 2,375 SRL outcomes and both 48-case editor conditions and passes all 148 tests. Two new native DeepProbLog checks finish with expected unknown probabilities. Browser: seven tables/five figures, working example links and explicit not-run states, desktop/mobile/dark mode, no errors or overflow. All seven historical archives remain unchanged; experiment GPUs are released. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/srl-compilation.html. Evidence: srl_revision_20261029/publication.json, archive_verification.json, native_checks.json and browser_checks.json.


### 2026-10-29 — Semantic SRL compiler revision and completion-report preference

- **Status:** Bounded implementation/evaluation complete, pushed, deployed and verified live.
- **Completed:** Reserved20 fresh IDs, wrote24 manual development reference readings, fixed selected source/predication/spatial/controller constructions, froze hashes, ran all2,375 inputs and reviewed44 paired cases. Revised2,042 compiled; development13 faithful versus7, fresh8 versus7; fresh incorrect2 versus4. No corpus accuracy claim.
- **Checks:**156 tests; full revised CPU replay;16 constructed logical checks; legacy2,375+48+48 replay preserved. Native2 pass/1 timeout30sec. No GPU/LLM/media/training. All8 earlier source ZIPs preserved.
- **Memory:** User preference saved in /home/hltcoe/cxiao/.codex/AGENTS.md: completion reports must list concrete next steps and intended goals, separate from completed results. Current root AGENTS.md also carries it.
- **Proposed next work:** Event-nominal/mass-noun/duration structure, missing/wrong SRL frames, separate backend cost profiling, then independent new-source review. Rewriting remains unimplemented; ADR-023 unchanged.
- **Artifacts:** exp/probabilistic_verification/srl_semantics_20261029/; docs/semantic_srl_compilation.md; site/reports/semantic-compilation.html. Deployment proof follows below.

- **Publication verified:** Site commit 6b831b3a0ea7d1a7f292e2a46cb2b0594feab4ad; Pages workflow 40999113136 succeeded. All15 changed live files byte-match local artifacts, including the12MB case viewer data and6MB source archive. Independent extracted replay and156 tests pass; desktop/mobile/dark browser checks pass with no errors/overflow. All8 historical ZIPs are unchanged. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/semantic-compilation.html. Evidence: srl_semantics_20261029/publication.json, archive_verification.json and browser_checks.json.


### 2026-10-30 — Compiler follow-up and separate source/model review

- **Status:** Implementation/evaluation complete, pushed, deployed and verified live.
- **Completed:** Narrow event reference sharing, bare predication, typed/executable durations, dependency-licensed frame recovery, resource-subject correction and equivalent explicit-state backend. Full2,375 rerun accepts2,108. New-source assistant faithful11→12; separate model18→17; targeted10 new accepts2 faithful/7 partial/1 incorrect. Preserve disagreements and limitations.
- **Validation:**167 tests; full new and previous cached replay; three probability/one gradient comparisons; four native binding checks; earlier native timeout completes.9 historical archives preserved. GPU review complete and released;0.404722 GPU-hours including failed smoke check. No media/new relation-training experiment or sentence rewriting.
- **Proposed next steps/goals:** Fix media-description/quoted-label scope to prevent added world predicates; add threshold/OR/omitted-time checks to reduce partial programs; get bounded human references to test the review criteria. The compiler stays experimental.
- **Artifacts:** exp/probabilistic_verification/compiler_followup_20261030/; docs/compiler_followup.md; site/reports/compiler-followup.html. Publication proof follows below.

- **Publication verified:** Site commit 9ea536418fbb4cf8fda0a0b5bdc20f37217ed80d; Pages workflow 41007156938 succeeded. All19 changed live files byte-match local artifacts, including all per-claim data, raw model reviews and the16MB source archive. Independent extracted archive replay covers current and previous semantic outputs;167 tests pass. Desktop/mobile/dark browser checks pass, with74 reviewed cases and both review reasons visible.9 historical source archives remain unchanged; all GPUs released. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-followup.html. Evidence: compiler_followup_20261030/publication.json, archive_verification.json and browser_checks.json.


### 2026-11-01 — Scoped compilation and human-review packet

- **Status:** Compiler implementation/census and review preparation complete, pushed, deployed and verified live; actual human evaluation remains pending.
- **Completed:** Reserved20 claims before changes, implemented source/label and claim-condition rules, froze source/template/membership, reran all2,375 claims.2,095 compiled/280 refused, with15 prior accepts now refused and2 additions.187 tests and both current/previous full extracted-archive replays pass. Ten historical archives are unchanged; no GPU/LLM/media/new training experiment.
- **Human work pending:** Empty intended-reading form and anonymous A/B comparisons prepared. Saves locally, exports/restores JSON; importer rejects wrong packet/claim hashes and invalid rating types. Zero actual human readings/comparisons received. Reviewer assignment was asked asynchronously; generic reviewer-ID field supports user or colleague without inventing an assignment. Synthetic browser checks do not populate project reference data.
- **Next steps and goals:** Return the reserved human reviews to provide actual semantic references; audit15 lost accepts to identify useful versus false refusals; then fix supported patterns with fresh evaluation sources. No semantic accuracy improvement is claimed from reduced coverage.
- **Artifacts:** exp/probabilistic_verification/scope_compilation_20261101/; docs/scoped_srl_compilation.md; site/reports/scope-compilation.html; site/reports/claim-review.html. Publication proof follows below.

- **Publication verified:** Site commit 63ada836e0e30a7966ad225922de6d8a4807dab6; Pages workflow 41282955246 succeeded. All17 changed live files byte-match validated local artifacts, including the report, human-review page, empty reference template/status and replay archive. Current and previous full compilation replay plus187 tests pass from an independent extraction;16 HTML pages validate. Browser checks cover source examples, all filters, desktop/mobile/dark mode, empty review defaults, reading-before-comparison, anonymous outputs, local persistence and JSON export/restore. Synthetic browser data remains in /tmp only; zero actual human readings/comparisons received. Ten historical source ZIPs remain unchanged. Report: https://borrisonxiao.github.io/SCALE26-AViD/reports/scope-compilation.html; form: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-review.html. Evidence: scope_compilation_20261101/publication.json, archive_verification.json and browser_checks.json.


### 2026-11-01 — Independent agent draft for user review

- **Status:** Twenty independent agent drafts complete, pushed, deployed and verified live; user review pending.
- **Completed:** User-requested GPT-6 Astra/xhigh review with claim-only readings frozen before anonymous output assessment. Concise answers, original records, editable draft page and explicit user confirmations. Importer retains assisted-review provenance and rejects raw agent drafts. Compiler unchanged; no new media/training experiment.
- **Human status:** Zero actual readings/comparisons received. Generated drafts, opening the page and synthetic browser tests do not count. The user-assisted route is separate from the blank form.
- **Next steps/goals:** User edits/confirms answers to establish their readings; return the export to record feedback; use confirmed errors to choose compiler changes.
- **Artifacts:** exp/probabilistic_verification/agent_review_20261101/; docs/agent_claim_review.md; site/reports/claim-review-draft.html.

- **Validation completed:**17 HTML pages;5 importer checks; full20-case browser field/rating checks and valid confirmation/export behavior; desktop/mobile/dark mode; independent byte-exact source rebuild. All11 historical archives and compiler hashes unchanged. Site push complete; deployment verification follows.

- **Publication verified:** Site commit 6a9c6605ca1e29d16920532c020aef3f7e99c3c5; Pages workflow 41339627916 succeeded. All14 changed live files byte-match validated local artifacts, including the editable review, raw agent answers and source archive. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-review-draft.html. Human readings/comparisons remain zero; user review is next. Evidence: agent_review_20261101/publication.json, validation.json, browser_checks.json and archive_verification.json.


### 2026-11-04 — Make compiler outputs visible and readable in review forms

- **Status:** Display revision complete, pushed, deployed and verified live.
- **User feedback:** A/B ratings were visible while the actual outputs were hidden as predicates/JSON and hard to review.
- **Completed:** Both forms now show event/state boxes connected to participants, literal text, modifiers and nested source content before the rating. Time conditions use frozen compiler metadata matched by program hash and exact logical form. The draft form explains A/B, marks identical outputs and moves extra reading fields into expandable details. Raw predicates remain available.
- **Validation:** All20 cases/40 outputs (34 compiled,6 refused) checked in browser; every saved event/entity/time condition renders. Known omissions and wrong role attachments remain visible. Review persistence, confirmation reset, exports, blank-form reading gate, mobile/dark mode and17-page HTML validation pass. Source archive independently reproduces HTML and itself byte-for-byte;12 earlier archives and packet/draft IDs remain unchanged. Human counts remain0.
- **Next steps/goals:** User reviews the visible structures to confirm intended meanings; returned review establishes which compiler errors to fix. No compiler experiment was run.
- **Artifacts:** exp/probabilistic_verification/review_display_20261104/; scripts/claim_output_view.py and scripts/report_assets/claim_output_view.js/.css; site/reports/claim-review-draft.html and claim-review.html.

- **Publication verified:** Commit 9e7a3a042e4440622012df95ccca15df4836d1c4; Pages workflow 41931056734 succeeded. All3 changed live files match validated local bytes, including both review forms and source-20261104.zip. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-review-draft.html#outputs. Review IDs, original suggestions, compiler outputs and all12 prior archives are preserved; actual human feedback remains0. Evidence: review_display_20261104/publication.json, browser_checks.json and archive_verification.json.


### 2026-11-04 — Remove duplicate and folded reading panels

- **Status:** Simplified form implemented, validated, pushed and verified live.
- **User feedback:** “More reading details” and “Original agent reading” repeated the same initial content and were folded. The form now has one complete editable reading with all5 fields visible. Duplicate original-assessment panels are removed too; originals remain in exported review JSON and the original draft download. Jump links reach the reading and compiler outputs.
- **Validation:** All20 cases have all5 fields visible without expansion. Saved edits restore, exports validate and retain the original draft, outputs remain visible, mobile/dark checks pass and17 HTML pages validate. Source rebuild is byte-exact; packet/draft IDs and13 earlier archives are preserved. Human counts remain0.
- **Next step/goal:** User reviews the single reading and visible outputs to confirm meaning, then returns feedback for compiler changes.
- **Artifacts:** exp/probabilistic_verification/review_form_20261104/; site/reports/claim-review-draft.html; source-readings-20261104.zip.

- **Publication verified:** Commit 9aa4c9e7aa9411b41e39443bdfdbb5a99d2103b9; Pages workflow 41932572109 succeeded. Both changed live files byte-match local validation. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-review-draft.html. All reading fields are open once; originals remain in exports, saved edits remain compatible, and human counts remain0.


### 2026-11-04 — User reports completion of all twenty reviews

- **Status:** User reports reviewing all20 cases. The exported answers have not been received in the project; do not ask the user to redo the review or infer their ratings from the agent draft. The static form stores answers in the user's browser until exported and returned.
- **Proposed next steps/goals:** Receive/validate the exported JSON and summarize anonymous paired judgments; unblind to identify improvements, regressions and false refusals. Trace confirmed errors to upstream parsing versus logical-form conversion; select a bounded set of general fixes. Reserve a fresh review sample before changes, turn reviewed cases into development checks, rerun all2,375 inputs and evaluate meaning separately from acceptance. Review results before starting media verification or relation training. No compiler change is implemented by this planning update.


### 2026-11-04 — Prepare the authorized compiler revision while awaiting the review export

- **Status:** Independent preparation complete, pushed and verified live; actual review analysis and fixes await the returned answers. User review itself is reported complete.
- **Completed:** Frozen20 new review cases across21 source videos, excluding129 recorded review sources;273 eligible claims after source/ID/text exclusions. Saved current baseline outputs/source hashes. Implemented paired review analysis and a failure ledger;6 meaningful checks pass. Source extraction/rebuild,17-page HTML and browser/checklist/download validation pass.14 historical archives preserved; no compiler change or new corpus run.
- **Next steps/goals:** Obtain the export to use the user's actual judgments; unblind and inspect disagreements/failure causes; fix at most3 recurring patterns; rerun2,375 claims and review the reserved sample to assess generalization. No rewrite, media verification or relation training performed.
- **Artifacts:** exp/probabilistic_verification/review_followup_20261104/; scripts/prepare_review_followup.py; scripts/analyze_claim_review.py; docs/review_followup.md. Checklist and preparation downloads updated; publication verification follows.

- **Publication verified:** Commit 83b55742e9ab32dbe4681fdb3ff13d2b9ec544b1; Pages workflow 41969601623 succeeded. All7 changed live files byte-match validated local artifacts. Checklist: https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#next-steps. Six analysis/sampling checks, source-archive reconstruction and browser/download checks pass. Twenty fresh cases across21 source videos reserved; no actual human answers imported or compiler changes made. Export or explicit confirmation that all original agent answers were accepted unchanged is still required to obtain the user's actual judgments.


### 2026-11-05 — Import returned review and complete bounded compiler revision

- **Status:** Implementation, full census, fresh assistant review, regression checks and report complete; publication verification follows.
- **Completed:** Moved exact returned JSON to the experiment's received_review folder, imported all20 confirmations, analyzed actual user edits and traced8 problem cases into3 bounded families. Implemented opt-in reviewed_srl, reran2,375 original inputs, retained first/final freezes and guarded unsafe names/controllers. Added full-corpus readable before/after viewer and updated the canonical checklist.
- **Results:**2,099 compiled/276 refused;4 additions,0 old accepts lost,29 changed programs. Three unnecessary refusals now compile; all11 user-faithful programs unchanged.207 tests pass. All20 fresh outputs unchanged,13 faithful/4 partial/3 incorrect assistant judgments; no fresh gain. Native4 pass/1 timeout at25s.
- **Validation:**18 HTML pages; browser desktop/mobile/dark and download-byte checks; independent extracted-source207 checks and byte-exact report/archive rebuild.15 historical source ZIPs unchanged. Full-record replay evidence is stored separately.
- **Next steps/goals:** Fix nominal/question-content scope to prevent asserting embedded content; check original predicate/identifier coverage to stop omissions; profile/bound larger native programs to establish practical inference. These remain proposed. No LLM rewrite, media inference or new relation-training experiment.
- **Artifacts:** exp/probabilistic_verification/compiler_revision_20261105/; docs/reviewed_srl_compilation.md; site/reports/reviewed-compilation.html. Original returned file: review_followup_20261104/received_review/20261105-1a3a8fd47e72a50f4943.json.

- **Publication verified:** Site commit 36ce92f3d6d607934182e8d4a86b12db356e9245; Pages workflow 41980896469 succeeded. All46 changed live files byte-match validated local artifacts, including24 case chunks and the reproducible source ZIP. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/reviewed-compilation.html. Evidence: compiler_revision_20261105/publication.json, archive_verification.json, replay_verification.json and browser_checks.json. Proposed next work remains scope, original-text coverage and native cost.


### 2026-11-05 — Complete scope/content repairs and full-corpus audit

- **Status:** Code, full census, fresh/alert reviews, report and checklist complete; publication verification follows.
- **Completed:** Scoped preparation/investigation/question content; recovered dolly/creak and complete names/identifiers; strict lexical coverage gate retains rejected candidates. Source/input immutability and earlier default output preservation checked. All2,375 rerun,11 programs changed.2,099 candidates;1,839 coverage-passing,260 alerts,276 earlier refusals.228 tests pass; exact dual full replay and byte-exact report/archive rebuild from extraction.19 HTML pages and all4,750 browser-rendered outputs validate.16 historical archives preserved.
- **Limits:** Fresh20 unchanged9 faithful/5 partial/2 incorrect/4 refused assistant judgments; no gain.12 sampled alerts have real omissions but all260 precision unknown. It/they unresolved; opaque clauses, source/label and role errors remain. Native cost remains pending; no rewrite/media/training experiment.
- **Next steps/goals:** Repair recurring apposition/number/nominal omissions to recover coverage; fix opaque clauses/source-label boundaries to prevent structurally wrong passes; resolve references and profile large programs before media training.
- **Artifacts:** exp/probabilistic_verification/scope_coverage_20261105/; docs/scope_coverage_compilation.md; site/reports/scope-coverage.html; current checklist stage14 complete for bounded scope/content and stage15 pending.

- **Publication verified:** Site commit acfa916533b01c0bbebd4ccde60f7cbf7c28c577; Pages workflow 41987567903 succeeded. All41 changed live files byte-match validated local artifacts, including24 output chunks and the reproducible source ZIP. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/scope-coverage.html. Evidence: scope_coverage_20261105/publication.json, archive_verification.json, replay_verification.json and browser_checks.json. Current checklist/memory are synchronized; further alert recovery, structural scope/reference work and native cost remain proposed.


### 2026-11-05 — Content recovery and28 compiler demos

- **Status:** Compiler revision, full census, reviews, source replay and demo page complete; browser/publication verification follows.
- **Completed:** Appositive/numeric content, finite temporal clauses, printed/depicted routes, text fragments and label boundaries. Current/old outputs preserved, residual clauses/lists explicit.28 plain-language demos with historical comparisons, actual saved structures and native OCR controls. Checklist keeps references/profiling/rewrite deferred.
- **Results:**1,866 pass vs1,839;2,103 executable vs2,099;35 newly pass and8 newly flagged;80 program hashes change.259 checks; all11 user-faithful programs unchanged. New20 review unchanged17/2/1 assistant judgments; one prior diagnostic marked. Twelve recovery examples10 faithful/2 partial, not human gold/all-case accuracy.
- **Validation:** Independent extracted259 checks and dual full2,375-record replay; byte-exact39 report/download files including archive;17 historical ZIPs unchanged;20 HTML pages validate. First/final source chronology and2 old-demo false-alert corrections preserved. Browser evidence recorded separately.
- **Next goals:** Review residual numeric/apposition alerts to choose a bounded next set; expose remaining8 hidden clauses/2 lists or refuse explicitly. References, native profiling and rewriting remain deferred.
- **Artifacts:** exp/probabilistic_verification/content_recovery_20261105/; docs/content_recovery_compilation.md; site/reports/compiler-demos.html.

- **Publication verified:** Site commit b3a64054bd86f00050c3837d7bb31994e99adf13; Pages workflow 42085890498 succeeded. All42 changed live files byte-match validated local artifacts, including24 output chunks and the reproducible source ZIP. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html. Browser checks pass for28 demos, historical comparisons,3 native controls, all4,750 displayed outputs, downloads and mobile/dark mode. Evidence: content_recovery_20261105/publication.json, browser_checks.json, archive_verification.json and replay_verification.json. References, native profiling and rewriting remain deferred; next work stays on remaining omissions and hidden clauses/lists.


### 2026-11-05 — Next omission/clause repairs and linked daily log

- **Status:** Implementation, full census and targeted review complete; extracted-source and browser/publication checks follow separately.
- **Completed:** Declared numeric labels, scaled values, explicit ranges and bounded appositions; both leader lists plus selected how/where clauses. All 2,375 rerun:1,924 pass versus1,866;58 recoveries,0 losses;2,103 candidates unchanged.67 program hashes change.290 regression checks pass.
- **Limits:** Twelve sampled recoveries retain local targets; older whole-claim errors remain. No human accuracy or held-out gain claim.173 lexical alerts,6 clauses and272 compiler refusals remain. No rewrite, references, profiling, new model/media inference or relation training.
- **Report:**41 demos and five tabs, including Latest changes and a linked Daily log. Earlier log entries are selected reconstructed milestones. Checklist updated.
- **Next goals:** Review recovered meanings with user; inspect remaining measurements and mixed noun/clause objects for a bounded repair set.
- **Artifacts:** exp/probabilistic_verification/content_relations_20261105/; docs/content_relations_compilation.md; site/reports/compiler-demos.html.

- **Final code-audit follow-up:** Added an AND-only guard for newly recovered nominal lists/appositions; OR alternatives remain unresolved.291 tests pass. The final source follows the12-case diagnostic review; pre_guard_frozen preserves the earlier38-file/290-test freeze. Both full-record replays verify that every corpus output and prior judgment remains unchanged. A reporting-only category order was stabilized for byte-exact rebuild. See guard_followup.json and archive/replay proofs; this supersedes earlier statements that no code change followed review.

- **Final validation:** Independent release extraction passes291 tests and exactly replays both2,375-record inventories. All40 report/download files including the source ZIP rebuild byte-for-byte;18 historical archives unchanged. All20 HTML pages validate. Browser checks41 demos, historical baselines,3 native controls,9 dated daily sections, hash links, filters, downloads and mobile/dark mode with no page errors. The final4750-output rendering result reuses the earlier complete rendering check only after byte comparison of all26 unchanged viewer JSON files. Publication verification follows.

- **Hosting retry:** Workflow42094574276 built/uploaded successfully but failed in deploy with the annotation “Timeout reached, aborting!”. Triggered one empty-commit retry at03566ddf2c6f41c2bc09301817e6478ed3ad286b. Its tree is exactly identical to content commit c98299eec492df19d2cb8e7ceab9b9b0fdcca16c. No compiler/report files changed and no tests need repeating. Publication verification is pending for the retry.

- **Publication verified:** Content commit c98299eec492df19d2cb8e7ceab9b9b0fdcca16c; identical-tree retry commit 03566ddf2c6f41c2bc09301817e6478ed3ad286b. Pages workflow 42097102905 succeeded after the first deployment timed out. All43 changed live files byte-match validated local artifacts, including the source ZIP and prior original archive. Live report: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html; daily log: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#daily-progress. Evidence: content_relations_20261105/publication.json, browser_checks.json, archive_verification.json and replay_verification.json. Final291 tests, exact full replays and40-file byte rebuild pass. Code/report work and publication are complete; only the documented next proposals remain.


### 2026-11-11 — Clarify counts, review alerts and assess rewrite readiness

- **Status:** Diagnostic review and report implementation complete; source-rebuild/browser/publication verification follows. Compiler unchanged.
- **Completed:** Recounted four full saved inventories and preserved all original2099 candidate IDs. Reviewed179 alerts (166 apparent gaps/5 overstrict/8 context-dependent),34 no-program cases and23 passing controls. Targeted22-case clause-literal review reveals missed structures despite word coverage. Counts remain2103 generated/1924 content-check passes.
- **Limits:** Assistant judgments, no independent human gold, corpus accuracy or rewrite success. No model/GPU/compiler/training/inference run. The291 regression result is historical.
- **Next goals:** Prepare40 fixed rewrite comparison cases; implement minimal checked rewriting and review original/rewrite/predicate triples before new relation learning or DeepProbLog experiments. Broad grammar frozen for comparison; basic source/quote/type defects separately maintained.
- **Artifacts:** compiler_alert_review_20261111; docs/compiler_alert_review_20261111.md; compiler-demos.html Alert review / Results / Daily log; canonical docs/project_notes/daily_log.json.

- **Final validation/publication:** Complete. Source-overlay extraction rebuilds 11 artifacts byte-exactly; 20 HTML pages validate; browser checks cover all 258 review entries, existing demos, navigation, downloads and mobile/dark layouts. The 19 original ZIPs and 26 viewer JSONs are unchanged. Site commit fcc3775012ffa38178cb31c49a237f8ff792e8d6; successful Pages workflow 43146978641; all 14 changed live files verified against local bytes. No hosting retry required. Proofs are in compiler_alert_review_20261111/{archive_verification,browser_checks,publication}.json.


###2026-11-11 —Checked rewrite pilot and full corpus replay

- **Complete:**40 frozen cases, two text-only Qwen prompt conditions, reparsing with the existing Stanza/BERT-SRL models, all80 semantic reviews. Initial/revised faithful target recoveries1/24→2/24, revised exact-quote guard1. Two revised controls regress; review blocks both. Both pilot gates fail. No automatic expansion or training.
- **Counts:** Original2375 full records reproduce2103 generated/1924 passes exactly. Full rerun with three reviewed revised-prompt replacements gives2105/1927,448 strict refusals. No initial-prompt successes mixed in; not a semantic-accuracy estimate or clean training-set size.38 compiler files unchanged;13 new tests pass;20 historical archives/26 viewer JSONs unchanged.
- **Resource:** Jobs1225132/1225198 complete on one80GB A100 in sequence; no live task allocation. H1001225122 canceled while queued. Model generation16.57/17.88seconds; initialization dominates first allocation. No media inference, new native DeepProbLog inference or relation training.
- **Review/report:** Added Rewrite pilot tab with both prompt texts/reviews per case, compiled structures, summary table, failure patterns and decision; checklist and canonical daily log synchronized. Source-rebuild/browser/publication proofs follow separately.
- **Next goals:** Review retained triples/rejections; bound quantity/negation contract changes or a separate stronger-model experiment; repeat fidelity review before scale-up/learning.

- **Final validation/publication:** Complete. Site commit 51cac587d9657b46e8b5d29babd5eaf4a012a217; Pages workflow 43155809347 succeeded. All17 changed live files match validated local bytes. Isolated source extraction exactly replays2375 originals,40 diagnostic proposals and2375 reviewed-corpus rows;14 report/download artifacts rebuild byte-exactly, including source.zip.13 new tests pass;20 HTML pages validate; browser covers all40 cases/both reviews,41 earlier demos,7 tabs, deep links, daily log, downloads and mobile/dark layouts with no page errors.20 historical ZIPs/26 viewer JSONs unchanged. Evidence: claim_rewrite_20261111/{publication,archive_verification,browser_checks}.json. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#rewrite-pilot. The bounded pilot/publication are complete; both gates fail and automatic expansion/new learning remain deferred.


###2026-11-12 —Failure-only rewrite trigger and visible failed requests

- **Complete:** Compile-first generation filter (31 failures eligible/9 passes skipped), zero-model all-passing check,17 tests, and failed-case inspector showing both exact saved prompts/responses/model settings.21 prior archives and frozen experiment records unchanged. No new model experiment.
- **Validation:** All80 request comparisons, five failed examples, filters/deep links/mobile and20 HTML pages pass. Source overlay reproduces9 artifacts exactly; no model runtime imported during routing replay. Publication verification follows separately.
- **Artifacts:** rewrite_inspection_20261112; docs/rewrite_inspection_20261112.md; compiler-demos.html#rewrite-routing and #rewrite-failed-examples. Daily log/checklist updated.
- **Next goals:** Inspect the failed text/compiled relationships and prompts; choose a bounded fix at the responsible stage before further generation or learning.

- **Publication verified:** Commit 512f4c93ea8b7e7c38a0c6c450381597bb0192f1; Pages workflow 43167008692 succeeded. All11 changed live files match local bytes. Source extraction reproduces9 artifacts including source.zip and both no-model routing checks;80 exact requests,5 example links,17 tests and20 HTML pages validate.21 historical archives/26 viewer files remain unchanged. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#rewrite-failed-examples. This routing/inspection update is complete; no new model run or semantic/compiler optimization.


###2026-11-12 —Sentence splitting development experiment

Implemented and ran31 failed-original automatic splits and8 clearly labeled assistant-written diagnostics. Updated Sentence splitting tab, checklist19 and Daily log; preserved frozen core compiler and earlier artifacts. Automatic0 complete recoveries; controlled4 faithful linked programs. Quantity/event/reference and tagging failures remain. Source, browser and publication validation follow before completion. See docs/claim_split_20261112.md.

Validation:32 focused tests,20 HTML pages,39 browser case views and isolated source replay pass. Prior22 archives/26 viewer files preserved. Deployment pending final push/verification.

- Publication verified: commit 341dde09435b11ddb6865d69de190879aaad9449; Pages workflow 43174956447 succeeded. All15 changed live files match local bytes, including the source bundle. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#sentence-splitting. This bounded experiment/report is complete; automatic expansion and new training are not enabled. Evidence: claim_split_20261112/publication.json.


###2026-11-12 —Original-mention alignment comparison and full census

Completed fixed31-case generation/alignment experiments and42 focused checks. Direct census1924/2375; two reviewed automatic fallbacks1926/2375 (81.09%). Updated report/checklist20/Daily log. Automatic scale-up and new learning deferred; source/browser/publication validation follows. See docs/split_alignment_20261112.md.

- Validation completed:42 focused tests pass;20 HTML pages validate. Browser checks cover all62 comparisons/exact requests,8 tabs,5 example links,41 historical demos,2375 original outputs and mobile/dark layouts with no page errors. Isolated source replay reproduces62 comparisons and2375 combined rows;17 report/download artifacts including source.zip match byte-for-byte. All23 prior ZIPs/26 viewer JSONs and38 compiler files remain unchanged. Publication proof follows separately.
