"""Original-mention alignment invariants, independent of the 31-case outputs."""
import copy
import pytest
from probabilistic_verification.split_alignment import align,compose_aligned
from probabilistic_verification.split_composition import CompositionError
from probabilistic_verification.sentence_simplification import to_proposal
from test_claim_split import components,proposal


def original():
    rows=components()
    # Use a single original photo / Alice / cup with distinct token positions.
    tokens=list(copy.deepcopy(rows['c1']['compilation']['tokens']))
    tokens.extend(dict(t,id=t['id']+5,head=t['head']+5 if t['head']else 0)for t in rows['c2']['compilation']['tokens']if t['text']!='Alice')
    return dict(text='A photo depicts Alice holding a blue cup.',tokens=tokens)


def test_original_unique_mentions_replace_model_identity_groups():
    p,_,trace,_=align(original(),proposal()['clauses'],components())
    assert len(p['shared'])==1
    assert all(m['text']=='Alice'for m in p['shared'][0]['mentions'])
    assert len({e['original_token']for e in trace['entities']})==3


def test_aligned_content_keeps_photo_context():
    c,_,_=compose_aligned('test',original(),proposal()['clauses'],components())
    assert next(e for e in c.metadata['events'].values()if e['predicate']=='hold')['route']=='visual_depiction'


def test_ambiguous_same_name_is_not_guessed():
    r=original();r['tokens'].append(dict(r['tokens'][3],id=100))
    with pytest.raises(CompositionError,match='ambiguous'):align(r,proposal()['clauses'],components())


def test_absent_noun_is_not_mapped_to_nearest_entity():
    r=original();r['tokens']=[t for t in r['tokens']if t['text']!='cup']
    with pytest.raises(CompositionError,match='absent'):align(r,proposal()['clauses'],components())


def test_source_cannot_be_discarded():
    rows=components();rows['c1']['compilation']['metadata']['logical_form']['formula']['predicate']='hold'
    with pytest.raises(CompositionError,match='source sentence'):align(original(),proposal()['clauses'],rows)


def test_generation_has_no_identity_or_context_fields():
    data=dict(action='split',sentences=['A photo depicts Alice.','Alice holds a blue cup.'])
    assert to_proposal(data)['shared']==[]
    data['shared']=[]
    with pytest.raises(Exception):to_proposal(data)


def test_one_sentence_cannot_be_labeled_split():
    with pytest.raises(ValueError):to_proposal(dict(action='split',sentences=['Alice holds a cup.']))
