"""Measured rewrite-pilot section inside the established compiler report."""
import json,shutil
from html import escape as esc
from pathlib import Path
from build_reviewed_compilation_report import slim
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/claim_rewrite_20261111'
def load(n):return json.loads((RUN/n).read_text())
def link(href,text):return '<a href="'+esc(href,quote=True)+'">'+esc(text)+'</a>'
def latest_html():
 s=load('summary.json')
 return '<section><h2>11 November: checked rewrite pilot completed</h2><p>One frozen text model proposed minimal rewrites for 24 failed targets, eight passing controls and eight difficult guard cases. <b>'+str(s['faithful_target_recoveries'])+' of 24 targets have reviewed faithful compiled rewrites.</b> '+str(s['rewritten_targets_pass_checks'])+' rewritten targets pass automatic checks; the two counts measure different things.</p><p>'+esc(s['decision'])+' '+link('#rewrite-pilot','Inspect the original → rewrite → compiled structure comparisons')+'. The underlying compiler is unchanged; the earlier 2,103/1,924 figures describe original text only.</p></section>'
def html():
 s=load('summary.json');h='<h2>Does minimal rewriting help the fixed compiler?</h2><p>We froze 24 failed targets, eight passing controls and eight guard cases before generation. Original-claim readings were recorded first. All are development examples from previously inspected claims; this is not an unseen accuracy test. Seven other original-video groups were reserved from prompt tuning.</p>'
 h+='<figure><div class="flow"><div><b>1. Original claim</b><small>Keep the unedited text and its baseline.</small></div><div><b>2. Rewrite proposal</b><small>One frozen Qwen text model; keep or refuse allowed.</small></div><div><b>3. Same compiler</b><small>Reparse with Stanza and BERT semantic-role labeling.</small></div><div><b>4. Review both steps</b><small>Check rewrite meaning and compiled relationships.</small></div></div><figcaption>Figure 3. The implemented rewrite experiment. No truth labels or media enter the rewriter. No relation training or new DeepProbLog inference is performed.</figcaption></figure>'
 h+='<div class="table-wrap"><table><caption>Table 6. Fixed development pilot. Semantic judgments are by the compiler-author assistant, not independent human gold.</caption><thead><tr><th>Measure</th><th>Result</th><th>Interpretation</th></tr></thead><tbody>'
 for label,val,meaning in [
  ('Faithful target recoveries',str(s['faithful_target_recoveries'])+'/24','Rewrite and compiled structure both preserve the original meaning.'),
  ('Rewritten targets passing automatic checks',str(s['rewritten_targets_pass_checks'])+'/24','Passing word/structure checks alone is insufficient.'),
  ('Accepted critical changes',s['accepted_critical_changes'],'Changes to participants, quantities, time, polarity, modality, quotations or source scope.'),
  ('Model proposals with critical meaning changes',s['model_proposed_critical_changes'],'Judged from original text and proposal, before review-based acceptance.'),
  ('Passing-control regressions',str(s['control_regressions'])+'/8','Reviewed pipeline use, with unchanged controls retained.'),
  ('Guard cases accepted after rewriting',str(s['guard_acceptances'])+'/8','Ambiguous or unsupported meanings must not be forced into acceptance.'),
  ('Original full-corpus replay','2,375 exact saved records','2,103 programs generated; 1,924 pass the original content checks.')]:
  h+='<tr><td>'+esc(str(label))+'</td><td>'+esc(str(val))+'</td><td>'+esc(str(meaning))+'</td></tr>'
 h+='</tbody></table></div>'
 comparison=load('prompt_comparison.json')
 h+='<h3>One prompt revision, with both runs retained</h3><p>The first prompt asked for clearer syntax. After inspecting its unchanged outputs and unintended name correction, we revised it to include the compiler’s error message. This is a text compilation diagnostic, not a truth label. Both conditions use the same 40 cases, frozen model and compiler. No prompt is selected separately for each claim.</p><div class="table-wrap"><table><caption>Table 7. Two complete development conditions. Recovery requires both faithful text and faithful compiled structure.</caption><thead><tr><th>Prompt</th><th>Actual text edits /40</th><th>Targets passing checks /24</th><th>Faithful targets /24</th><th>Faithful guards /8</th><th>Proposed control regressions /8</th><th>Rewrite action with unchanged text</th></tr></thead><tbody>'
 for c in comparison['conditions']:
  h+='<tr>'+''.join('<td>'+esc(str(v))+'</td>'for v in [c['label'],c['actual_text_changes'],c['rewritten_targets_pass_checks'],c['faithful_target_recoveries'],c['guard_acceptances'],c['control_regressions'],c['identical_rewrite_actions']])+'</tr>'
 h+='</tbody></table></div><p>The initial prompt recovers the explicit three-judge group, while the revised prompt keeps three-judge as a coarse compound property. The revised condition recovers different cases; the headline counts do not combine the two prompts’ successes.</p><h3 id="rewrite-decision">Decision</h3><p><b>'+esc(s['decision'])+'</b></p><p>'+esc(s['interpretation'])+'</p><p>The proposed development gates were at least 12/24 faithful recoveries, zero passing-control regressions and zero accepted critical changes. These small-set gates do not establish statistical reliability. Surface checks reject obvious name, number, quotation and modality changes. They cannot detect all role swaps, lost tense or changed scope. Acceptance requires a saved review of the original claim, rewrite and predicates.</p>'
 h+='<p>A full rerun with only the three reviewed diagnostic-prompt replacements yields <b>2,105 generated programs and 1,927 passing content checks across 2,375 claims</b>; 448 still fail strict compilation. This is a diagnostic corpus with three reviewed replacements, not a corpus of 1,927 certified faithful claims. The original-text baseline remains 2,103/1,924. No unreviewed rewrite or initial-prompt success is added to this result.</p>'
 h+='''<div class="box"><h3>Inspect every pilot case</h3><label for="rewrite-group">Subset</label><select id="rewrite-group"><option value="all">All 40 cases</option><option value="target">24 failed targets</option><option value="control">8 passing controls</option><option value="guard">8 difficult guard cases</option><option value="accepted">Reviewed faithful recoveries</option></select><p id="rewrite-count" role="status"></p><label for="rewrite-case">Claim</label><select id="rewrite-case"></select><p id="rewrite-id" class="muted"></p><h3>Original claim</h3><blockquote id="rewrite-original"></blockquote><p><b>Reading recorded before generation:</b> <span id="rewrite-reading"></span></p><h3>Initial prompt proposal</h3><p id="rewrite-initial-text"></p><p id="rewrite-initial-review"></p><h3>Revised prompt proposal</h3><blockquote id="rewrite-text"></blockquote><p id="rewrite-model-reason"></p><h3>Review of the revised result</h3><p id="rewrite-judgment" class="note"></p><p id="rewrite-review"></p><p id="rewrite-checks"></p><figure><div id="rewrite-graphs" class="output-grid"></div><figcaption>Figure 4. Saved original and revised-prompt structures. Nested boxes show source or event context; repeated participant IDs show shared identity. A displayed candidate may still be refused or judged unfaithful. Exact predicates are optional below each structure.</figcaption></figure><details><summary>Initial prompt: exact predicates and logical form</summary><pre id="rewrite-initial-predicates"></pre></details></div>'''
 h+='<h3>Failure patterns</h3><ul>'+''.join('<li>'+esc(t)+'</li>' for t in s['failure_patterns'])+'</ul><h3>Next steps and intended goals</h3><ol>'+''.join('<li>'+esc(t)+'</li>' for t in s['next_steps'])+'</ol><p>Original words, cached parses, old compiler outputs and historical source archives are preserved. The 40 comparisons and judgments are all available below; no accepted-count increase is presented as a media-verification result.</p><p>'
 folder='compiler-demos/rewrite-20261111/'
 h+=' · '.join(link(folder+n,label) for n,label in [('summary.json','Statistics'),('prompt_comparison.json','Both prompt conditions'),('pilot_cases.json','All readable comparisons'),('pilot_manifest.json','Frozen membership and readings'),('semantic_review.json','Semantic judgments'),('pilot_raw.jsonl','Revised prompts and raw responses'),('initial_prompt_raw.jsonl','Initial prompts and raw responses'),('README.md','Method and reproduction'),('source.zip','Source and saved experiment')])+'</p>'
 return h
def write_downloads():
 folder=ROOT/'site/reports/compiler-demos/rewrite-20261111';folder.mkdir(parents=True,exist_ok=True)
 rows=list(map(json.loads,(RUN/'pilot_compilation.jsonl').read_text().splitlines()));manifest={r['claim_id']:r for r in load('pilot_manifest.json')['cases']};reviews={r['claim_id']:r for r in load('semantic_review.json')['cases']};cases=[]
 initial={r['claim_id']:r for r in map(json.loads,(RUN/'initial_prompt/pilot_compilation.jsonl').read_text().splitlines())};initial_reviews={r['claim_id']:r for r in load('initial_prompt/semantic_review.json')['cases']}
 for row in rows:
  cid=row['claim_id'];r=reviews[cid];views={}
  for side in ['original','rewritten']:
   out=row[side];views[side]=dict(view=slim(dict(out,status='compiled') if 'program'in out else out),status=out['status'],code=out.get('code'),reason=out.get('reason'))
  first=initial[cid];old=first['rewritten']
  cases.append(dict(manifest[cid],proposal=row['proposal'],surface_issues=row['surface_issues'],review=r,outputs=views,initial_proposal=first['proposal'],initial_review=initial_reviews[cid],initial_output=slim(dict(old,status='compiled')if 'program'in old else old)))
 (RUN/'pilot_cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
 for name in ['summary.json','pilot_cases.json','pilot_manifest.json','semantic_review.json','pilot_raw.jsonl','pilot_raw.config.json','baseline_replay.json','prompt_comparison.json','reviewed_corpus_replay.json']:
  shutil.copy2(RUN/name,folder/name)
 shutil.copy2(ROOT/'docs/claim_rewrite_pilot_20261111.md',folder/'README.md')
 shutil.copy2(RUN/'initial_prompt/pilot_raw.jsonl',folder/'initial_prompt_raw.jsonl')
