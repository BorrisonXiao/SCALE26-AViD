"""Checks for destructive rewrite proposals and review-based acceptance."""
import pytest
from probabilistic_verification.claim_rewrite import messages,surface_checks,reviewed_acceptance,review_key

def record(text):
 return dict(text=text,tokens=[dict(id=1,text='Alice',upos='PROPN',head=0,deprel='root')],srl=dict(frames=[]),verdict='FALSE',claim_id='hidden',reading='hidden')
def proposal(text,action='rewrite'):return dict(action=action,text=text,reason='Test')

def test_prompt_excludes_labels_and_review():
 m=messages(record('Alice landed in 1968.'));assert 'FALSE' not in str(m) and 'hidden' not in str(m)
 assert 'even if the claim is false' in m[0]['content']

@pytest.mark.parametrize('old,new,issue',[
 ('Alice landed in 1968.','Alice landed in 1969.','numeric_surface_changed'),
 ('Alice did not land.','Alice landed.','polarity_or_modality_changed:not'),
 ('Alice might land.','Alice will land.','polarity_or_modality_changed:might'),
 ('Alice says "No landing".','Alice says "Landing".','quotation_changed'),
 ('Alice lands.','Bob lands.','proper_name_missing:Alice'),
 ('Alice paid -52.','Alice paid 52.','numeric_surface_changed'),
 ('Alice moves at 20-25 km/h.','Alice moves at 20 km/h.','numeric_surface_changed'),
])
def test_surface_rejections(old,new,issue):assert issue in surface_checks(record(old),proposal(new))

def test_unchanged_quote_and_apostrophe():
 old=record('Alice\x27s sign reads "No landing".');assert surface_checks(old,proposal(old['text'],'keep'))==[]

def test_keep_cannot_change_text():assert 'changed_keep_or_refusal' in surface_checks(record('Alice lands.'),proposal('Alice runs.','keep'))

def test_parse_success_is_insufficient():
 old=record('Alice hugs Bob.');p=proposal('Bob hugs Alice.');compiled=dict(status='compiled')
 assert surface_checks(old,p)==[] # Surface checks cannot detect a role swap.
 assert not reviewed_acceptance(old,p,compiled,{})
 assert not reviewed_acceptance(old,p,compiled,dict(rewrite_faithful=False,compiled_faithful=True,critical_change=True))

def test_acceptance_requires_all_fidelity_checks():
 old=record('Alice waves and runs.');p=proposal('Alice runs and waves.');compiled=dict(status='compiled')
 review=dict(rewrite_faithful=True,compiled_faithful=True,critical_change=False,artifact_sha256=review_key(old,p,compiled))
 assert reviewed_acceptance(old,p,compiled,review)
 assert not reviewed_acceptance(old,p,dict(status='unsupported'),review)

def test_review_cannot_attach_to_another_proposal():
 old=record('Alice hugs Bob.');p=proposal('Bob is hugged by Alice.');compiled=dict(status='compiled')
 review=dict(rewrite_faithful=True,compiled_faithful=True,critical_change=False,artifact_sha256=review_key(old,p,compiled))
 assert not reviewed_acceptance(old,proposal('Bob hugs Alice.'),compiled,review)
