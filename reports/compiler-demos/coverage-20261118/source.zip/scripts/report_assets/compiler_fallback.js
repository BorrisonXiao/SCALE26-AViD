(() => {
 const el = id => document.getElementById(id), esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 if (!el('fallback-case')) return;
 const base='compiler-demos/fallback-20261118/'; let inventory=[], current='', active=null, ticket=0;const chunks=new Map();
 function describe(c,v){const x=c.variables.find(x=>x.name===v);if(x)return v+' ('+x.description+')';if(typeof v==='string'&&v.startsWith('{')){try{const t=JSON.parse(v);if(t.value!==undefined)return (t.kind==='verbatim_text'?'exact text ':'')+'“'+t.value+'”'+(t.unit?' '+t.unit:'');}catch(e){}}return v;}
 function conditions(c){
  const by=Object.fromEntries(c.atoms.map(a=>[a.id,a]));
  function atom(a){const args=a.arguments;let end=-1;args.forEach((v,i)=>{if(v==='scope')end=i;});const v=end<0?args:args.slice(0,end),scope=end<0?'world':args[end+1],route=args.includes('route')?args[args.lastIndexOf('route')+1]:'unspecified';let text;
   if(a.predicate==='referent')text=describe(c,v[0])+' must match “'+v[1]+'”';
   else if(a.predicate==='source_term')text=v[0]+' is “'+v[1]+'” ('+v[2]+')';
   else if(a.predicate==='dependency'||a.predicate==='source_modifier')text=describe(c,v[0])+' — '+v[1]+' → '+describe(c,v[2]);
   else if(a.predicate==='source_quote')text=describe(c,v[0])+' has the exact quote “'+v[1]+'”';
   else if(a.predicate==='source_root')text=describe(c,v[0])+' is a dependency root';
   else if(a.predicate==='concept')text=describe(c,v[0])+' must match '+v[1];
   else if(a.predicate==='name')text=describe(c,v[0])+' has name “'+v[1]+'”';
   else if(a.predicate==='written_text')text=describe(c,v[0])+' contains the written text “'+v[1]+'”';
   else if(a.predicate==='qualification')text='The following content has '+v[0]+' qualification: '+v[1];
   else if(a.predicate==='proposition')text=describe(c,v[0])+' has '+v.slice(1,4).join(' / ')+' content';
   else if(a.predicate==='temporal')text=describe(c,v[0])+': tense '+v[1]+', aspect '+v[2];
   else if(a.predicate==='reference')text='Use the same '+describe(c,v[0])+' in this context';
   else if(a.predicate==='role'||a.predicate==='entity_relation')text=describe(c,v[0])+' — '+v[1]+' → '+describe(c,v[2]);
   else if(a.predicate==='grammatical_number')text=describe(c,v[0])+' is '+v[1];
   else if(a.predicate==='property'||a.predicate==='literal'||a.predicate==='quantity'||a.predicate==='group_quantity')text=describe(c,v[0])+': '+v.slice(1).join(' = ');
   else {const terms=[];for(let i=1;i<v.length;i+=2)terms.push(v[i]+': '+describe(c,v[i+1]));text=a.predicate+' '+describe(c,v[0])+(terms.length?' — '+terms.join('; '):'');}
   return '<p class="amr-condition">'+esc(text)+' <small>['+esc(scope)+'; '+esc(route)+']</small></p>';
  }
  function formula(x){if(x.op==='atom')return atom(by[x.atom_id]);if(x.op==='constant')return '<p>'+esc(x.state)+'</p>';if(x.op==='exists')return formula(x.children[0]);if(x.op==='not')return '<div class="box amr-negative"><b>NOT: no matching assignment satisfies these conditions</b>'+formula(x.children[0])+'</div>';if(x.op==='or')return '<div class="box"><b>OR: at least one branch</b>'+x.children.map((x,i)=>'<div class="box"><b>Branch '+(i+1)+'</b>'+formula(x)+'</div>').join('')+'</div>';return x.children.map(formula).join('');}
  const scopes=Object.entries(c.metadata.scopes||{});return '<p>Conditions are required together unless an OR/NOT box says otherwise. Repeated IDs are shared participants. Numbered roles are specific to their predicate; ARG0 does not always mean agent. “world” names the outer claim, not a truth certificate.</p>'+ (scopes.length?'<ul>'+scopes.map(([id,s])=>'<li>'+esc(id+': '+s.kind+(s.operator?' / '+s.operator:'')+'; parent '+s.parent+'; source route '+s.route)+'</li>').join('')+'</ul>':'<p>No embedded context.</p>')+formula(c.expression);
 }
 window.renderFallbackConditions = conditions;
 function renderStage(save=false){if(!active)return;const stage=el('fallback-stage').value,a=active.attempts.find(a=>a.stage===stage);if(!a)return;
  const issues=[...(a.errors||[]),...(a.shared_checks||[])];if(a.status!=='compiled'&&a.reason&&!issues.some(x=>x.reason===a.reason))issues.unshift({code:a.code,reason:a.reason});
  el('fallback-errors').innerHTML=issues.length?'<ul>'+issues.map(x=>'<li><b>'+esc((x.code||'check').replaceAll('_',' '))+':</b> '+esc(x.reason)+(x.text?' ['+esc(x.text)+']':'')+'</li>').join('')+'</ul>':'<p>No automatic flag. This is not a certificate of faithful meaning.</p>';
  el('fallback-conditions').innerHTML=a.compilation?conditions(a.compilation):'<p>No complete logical form was generated at this stage.</p>';
  el('fallback-exact').textContent=(a.compilation?.logical_form||'No complete logical form')+'\n\n'+(a.program||'No program')+'\n\n'+JSON.stringify(a.compilation?.metadata||a,null,2);
  const rewrite=active.attempts.find(a=>a.stage==='rewrite');if(!rewrite)el('fallback-rewrite').innerHTML='<p>Skipped: an earlier compiler passed. No rewrite is requested for this claim.</p>';
  else {const raw=active.rewrite_request;el('fallback-rewrite').innerHTML=(active.rewrite_review?'<p><b>Rewrite-text review:</b> '+esc(active.rewrite_review.rewrite_meaning.replaceAll('_',' '))+'. '+esc(active.rewrite_review.reason)+' This review does not control routing.</p>':'')+(rewrite.proposal?'<h4>Simplification proposal</h4><pre>'+esc(JSON.stringify(rewrite.proposal,null,2))+'</pre>':'')+(rewrite.components?'<h4>Component results</h4><ul>'+rewrite.components.map(c=>'<li>'+esc(c.text)+': '+esc(c.result.status==='compiled'?'checks pass':c.result.reason||c.result.code)+'</li>').join('')+'</ul>':'')+(raw?'<p>Frozen local Qwen3-30B-A3B-Instruct-2507; greedy decoding, one response. <a href="'+base+'rewrite_config.json">Model configuration</a>.</p><h4>Actual model response</h4><pre>'+esc(raw.raw)+'</pre><details><summary>Exact prompt sent to the model</summary><pre>'+esc(raw.messages.map(m=>m.role.toUpperCase()+':\n'+m.content).join('\n\n'))+'</pre></details>':'<p>No model response is available. The saved stage record above states why; this is not evidence that a new rewrite was tried and failed.</p>');}
  const u=new URL(location);u.searchParams.set('fallback_claim',active.claim_id);u.searchParams.set('fallback_stage',stage);u.hash='fallback-inspector';el('fallback-share').href=u.pathname+u.search+u.hash;if(save){history.replaceState(null,'',u);window.dispatchEvent(new Event('hashchange'));}
 }
 async function show(cid){current=cid;const token=++ticket,meta=inventory.find(x=>x.claim_id===cid);if(!meta)return;el('fallback-case').value=cid;el('fallback-text').textContent=meta.text;el('fallback-outcome').textContent='Loading the saved compilation trace…';
  if(!chunks.has(meta.chunk))chunks.set(meta.chunk,fetch(base+meta.chunk).then(r=>{if(!r.ok)throw Error('Could not load trace');return r.json();}));
  try{const data=await chunks.get(meta.chunk);if(token!==ticket)return;active=data.find(r=>r.claim_id===cid);const r=active;el('fallback-outcome').textContent=r.parsing_status==='compiled'?'Program selected from '+r.selected_stage.toUpperCase()+' after automatic checks. Media verification was not run.':'Parsing abstention: all available stages failed their checks. No evidence verdict or probability distribution is produced.';
   const review=r.review;el('fallback-review').textContent=review?'Selected-program review: '+review.whole_reading.replaceAll('_',' ')+'. '+review.provenance:'This selected program has not received a fresh whole-reading review in this experiment.';
   el('fallback-review-reason').textContent=review?review.reason:r.baseline_review?'Original AMR diagnostic review: '+r.baseline_review.whole_reading.replaceAll('_',' ')+'. '+r.baseline_review.reason:'Automatic checks and source fidelity must be assessed separately.';
   el('fallback-stages').innerHTML='<ol>'+r.attempts.map(a=>'<li><b>'+esc(a.stage.toUpperCase())+'</b>: '+esc(a.status==='compiled'?'checks pass; selected':a.reason||a.code||a.status)+'</li>').join('')+'</ol>';
   el('fallback-stage').innerHTML=r.attempts.map(a=>'<option value="'+esc(a.stage)+'">'+esc(a.stage.toUpperCase()+(a.status==='compiled'?' — selected':' — not accepted'))+'</option>').join('');const query=new URLSearchParams(location.search),requested=query.get('fallback_claim')===r.claim_id?query.get('fallback_stage'):null;el('fallback-stage').value=r.attempts.some(a=>a.stage===requested)?requested:r.selected_stage||r.attempts.at(-1).stage;
   el('fallback-source-note').textContent='These are actual saved stages. Review labels never select the parser. A rejected stage can retain a diagnostic candidate; an earlier pass skips later stages.';renderStage();
  }catch(e){el('fallback-outcome').textContent=e.message;}
 }
 function filter(){const mode=el('fallback-filter').value,q=el('fallback-search').value.toLowerCase();const visible=inventory.filter(r=>(mode==='all'||mode==='audited'&&r.audited||r.selected===mode)&&(!q||(r.claim_id+' '+r.text).toLowerCase().includes(q)));el('fallback-count').textContent=visible.length+' of '+inventory.length+' claims';el('fallback-case').innerHTML=visible.map(r=>'<option value="'+esc(r.claim_id)+'">'+esc(r.claim_id+' · '+r.text)+'</option>').join('');if(visible.length)show(visible.some(x=>x.claim_id===current)?current:visible[0].claim_id);else el('fallback-outcome').textContent='No matching claim.';}
 fetch(base+'index.json').then(r=>r.json()).then(data=>{inventory=data;const q=new URLSearchParams(location.search);current=q.get('fallback_claim')||q.get('claim')||'TFOEIehBwT8Q_535';filter();window.dispatchEvent(new Event('hashchange'));}).catch(e=>el('fallback-outcome').textContent=e.message);
 el('fallback-filter').addEventListener('change',filter);el('fallback-search').addEventListener('input',filter);el('fallback-case').addEventListener('change',e=>{show(e.target.value).then(()=>renderStage(true));});el('fallback-stage').addEventListener('change',()=>renderStage(true));
})();
