(() => {
    const get = id => document.getElementById(id);
    const cases = get('coverage-case');
    if (!cases) return;
    const filter = get('coverage-filter');
    function option(value, text) {
        return new Option(text, value);
    }
    function display(rows) {
        const row = rows.find(row => row.claim_id === cases.value);
        if (!row) return;
        get('coverage-text').textContent = row.text;
        get('coverage-status').textContent = row.label;
        get('coverage-review').textContent = row.review || '';
        get('coverage-strict').href = '?fallback_claim=' + encodeURIComponent(row.claim_id) + '#fallback-inspector';
        const output = row.compilation;
        const conditions = get('coverage-conditions');
        conditions.replaceChildren();
        if (output && typeof window.renderFallbackConditions === 'function') {
            conditions.innerHTML = window.renderFallbackConditions(output);
        } else if (!output) {
            conditions.textContent = 'No complete program was generated.';
        }
        get('coverage-exact').textContent = (output?.logical_form || 'No logical form') + '\n\n'
            + (row.program || 'No program');
        const stages = get('coverage-attempts');
        stages.replaceChildren();
        for (const attempt of row.alerts) {
            const item = document.createElement('li');
            const alerts = [...new Set([attempt.reason, ...(attempt.errors || []).map(a => a.reason),
                ...(attempt.shared_checks || []).map(a => a.reason)].filter(Boolean))];
            item.textContent = attempt.stage.replaceAll('_', ' ') + ' · '
                + (alerts.join(' / ') || attempt.status);
            stages.append(item);
        }
    }
    fetch('compiler-demos/coverage-20261118/cases.json').then(response => {
        if (!response.ok) throw new Error('Could not open saved coverage results.');
        return response.json();
    }).then(rows => {
        const requested = new URLSearchParams(location.search).get('coverage_claim');
        const categories = new Map(rows.map(row => [row.category, row.label]));
        for (const [category, label] of categories) filter.add(option(category, label));
        function update(wanted) {
            const subset = rows.filter(row => filter.value === 'all' || row.category === filter.value);
            cases.replaceChildren(...subset.map(row => option(row.claim_id, row.claim_id + ' · ' + row.text)));
            cases.value = subset.some(row => row.claim_id === wanted) ? wanted : subset[0].claim_id;
            display(rows);
        }
        cases.addEventListener('change', () => display(rows));
        filter.addEventListener('change', () => update(cases.value));
        update(requested);
    }).catch(error => { get('coverage-status').textContent = error.message; });
})();
