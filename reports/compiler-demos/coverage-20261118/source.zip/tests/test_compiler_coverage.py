"""Regressions for unsupported scope and the review boundary."""
import penman
import pytest

from probabilistic_verification.compiler_coverage import (
    normalize_annotated_coordination, normalize_sentence_mode, request_scope_warning,
    review_only, verify_coverage, written_quote_conditions,
)
from probabilistic_verification.compiler_fallback import serialize
from probabilistic_verification.logical_form import LogicalFormError


def test_long_quoted_text_stays_literal_with_visible_carrier():
    text = 'Video overlay reading "No one was injured. All shops closed." is visible.'
    claim = written_quote_conditions({'claim_id': 'quote', 'text': text})
    quote = next(a for a in claim.atoms if a.predicate == 'written_text')
    assert quote.arguments[:2] == ('X1', 'No one was injured. All shops closed.')
    assert claim.metadata['allowed_routes'][quote.id] == ['ocr_assertion']
    assert any(a.predicate == 'property' and a.arguments[:3] == ('X1', 'visible', 'true')
               for a in claim.atoms)
    assert all(a.predicate in {'referent', 'property', 'written_text'} for a in claim.atoms)
    serialize(claim)


def test_quote_repair_leaves_extra_clause_unresolved():
    with pytest.raises(LogicalFormError, match='Unresolved outer claim'):
        written_quote_conditions({
            'claim_id': 'quote', 'text': 'A sign says "Run" and Maya turns away.',
        })


def test_polar_question_stays_under_a_truth_value_node():
    raw = '(k / know-01 :polarity - :ARG1 (a / arrive-01 :polarity (t / truth-value)))'
    output, trace = normalize_sentence_mode(raw)
    graph = penman.decode(output)
    assert ('k', ':polarity', '-') in graph.triples
    assert ('k', ':ARG1', 't') in graph.triples
    assert ('t', ':content', 'a') in graph.triples
    assert ('a', ':polarity', 't') not in graph.triples
    assert trace[0]['polar_questions'] == [('a', 't')]


def test_annotation_on_disjunction_keeps_alternatives_and_purpose():
    raw = '(o / or :op1 (c / crouch-01) :op2 (s / sit-01) :purpose (t / stable-03))'
    output, trace = normalize_annotated_coordination(raw)
    graph = penman.decode(output)
    choice, = [v for s, r, v in graph.triples if (s, r) == ('o', ':content')]
    assert (choice, ':instance', 'or') in graph.triples
    assert (choice, ':op1', 'c') in graph.triples and (choice, ':op2', 's') in graph.triples
    assert ('o', ':purpose', 't') in graph.triples
    assert trace


def test_provisional_output_keeps_structure_and_cannot_call_verifier():
    claim = written_quote_conditions({'claim_id': 'w', 'text': 'A sign says "Closed".'})
    out = review_only(claim.to_dict(), 'source warning')
    assert out.expression == claim.expression
    assert all(routes == [] for routes in out.metadata['allowed_routes'].values())
    result = verify_coverage({'claim_id': 'w', 'category': 'advisory_checks', 'output': {'status': 'review_required'}},
                             lambda _: pytest.fail('Provisional parse entered the verifier.'))
    assert result == dict(claim_id='w', verdict='abstain', reason='parse_review_required', distribution=None)


def test_request_audit_preserves_existing_request_context():
    source = {'text': 'Analysts called for a boycott.'}
    assert request_scope_warning(source, {})['code'] == 'request_scope'
    assert request_scope_warning(source, {'metadata': {'scopes': {'p': {'kind': 'request'}}}}) is None
