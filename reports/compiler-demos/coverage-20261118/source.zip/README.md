# Compilation coverage with advisory checks

The coverage experiment produces 2,354/2,375 semantic programs (99.12%). 21 more claims produce only dependency analyses. Earlier strict checks pass 2,177, and targeted repairs bring that count to 2,183. Allowing already generated programs with warnings alone gives 2,280. Advisory outputs require review before evidence inference.

## Conditions compared

The experiment starts with the saved strict SRL → AMR → rewrite results. On its 198
abstentions, it attempts source-licensed repairs and can reuse a previously rejected
program when the program itself is executable. It then attempts structured AMR
repairs and an earlier SRL converter, using the same cached annotations.

- Exact quotations attach to a visible overlay, written carrier or depicted tweet. The
  quoted words stay literal. The model had parsed some of those words as independent events.
- A source-linked “imply that” keeps an implied proposition under the original frame.
  An omitted or passive subject in a media description can still introduce a visual context.
- An unresolved AMR complement retains its parent, role and embedded content.
  Annotated AND/OR groups keep their shared conditions on the whole group. Explicit
  graph references may point to an event introduced in an enclosing scope.
- Questions keep the AMR truth-value context and commands keep directive scope.
  The representation of polar questions follows the [AMR annotation guidelines](https://github.com/amrisi/amr-guidelines/blob/master/amr.md).
- The earlier SRL converter yields two provisional programs for cases still unresolved.
  Its pier/terminal example demonstrates the cost of relaxing requirements: OR is lost.
- A dependency analysis preserves source words and grammatical attachments for the final
  21 claims. Subjects, objects and modifiers still need semantic interpretation.

The 2,354 count measures predicate and argument program generation. It includes
171 provisional programs. The 2,375 count that includes dependency analyses measures
availability of an inspectable structure. Fidelity is assessed in the example review. The earlier
retained pool is preserved in History. No empirical training or media evaluation took place.

## Review and preparation

The audit contains 14 inspected examples and a separate diagnosis
of each of the 21 remaining failures. Reentry across event scopes is the most common final
stop. Negation, duplicate roles and coordination account for other cases. Some AMR graphs omit
conditions or introduce incorrect relations even when their programs execute.

An advisory rule for a missing request context flags one case in the existing 20-text
external diagnostic and zero in the corpus. The flagged external case says someone called
for a boycott. The selected SRL output lacks an explicit request. The rule does not alter routing.

The preparation export contains 54 forms reviewed against their source wording across 36
source groups. It carries the exact form and hash and leaves evidence labels for later inspection.
The automatic test inventory includes all 2,375 claims. These groups can guide source-disjoint
selection before training.

## Validation and reproduction

All 198 newly selected programs load and ground in ProbLog
with placeholder evidence. The 3 exact quotation
programs were also evaluated with no observations and return unknown.
192 provisional selections skip evidence inference in the coverage
adapter. All 2,177 original strict selections retain their saved
program hashes. The run uses CPU and cached parser and rewrite annotations.

From the extracted source bundle with the existing compiler Python dependencies and WordNet data:

```bash
python scripts/run_compiler_coverage.py
python scripts/audit_compiler_coverage.py
python scripts/validate_compiler_coverage.py
PYTHONPATH=scripts:tests python -m pytest -q tests/test_compiler_coverage.py
```

Compare regenerated artifacts with `REPLAY_SHA256.json`. Unchanged strict selections refer to
the published prior run, and the bundle carries the required fields for this comparison.

## Next work

1. Resolve nested event references and branch-specific conditions to recover more of
   the remaining semantic programs.
2. Review provisional programs by source group and construction to estimate meaning
   preservation and improve warnings on misleading primary parses.
3. Inspect evidence labels and prepare source-disjoint binding contrasts to test the small
   relation models once training is ready.
