"""Exact output regression for unchanged default compilers."""
import hashlib
import json
import logging
import shutil
from run_amr_contexts import ROOT, RUN, BASE, rows, dump
from run_amr_types import inspect


def main():
    logging.getLogger('penman').setLevel(logging.ERROR)
    records={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')}
    old=rows(BASE/'corpus.jsonl')
    for r in old:
        assert json.loads(json.dumps(inspect(records[r['claim_id']],r['raw'])))==r,r['claim_id']
    legacy=ROOT/'exp/probabilistic_verification/amr_correction_20261114/legacy_regression.json'
    shutil.copy2(legacy,RUN/'legacy_regression.json')
    frozen=json.loads((RUN/'frozen_external_evaluation/external_outputs.json').read_text())
    after=json.loads((RUN/'external_outputs.json').read_text())
    assert len(frozen)==len(after)==20
    for a,b in zip(frozen,after):
        assert a['claim_id']==b['claim_id']
        for name in ['before','after']:
            assert (a[name].get('program'),a[name]['status'])==(b[name].get('program'),b[name]['status']),a['claim_id']
    dump(RUN/'external_equivalence.json',dict(all_20_programs_and_statuses_unchanged=True,
        reason='Two validator corrections developed from old corpus examples after the first external inspection. No external wording or error was repaired.',
        policy='External text-only diagnostic, not an independent held-out accuracy estimate.'))
    dump(RUN/'default_regression.json',dict(typed_default_cases=len(old),typed_default_exact=True,
        legacy_proof_sha256=hashlib.sha256(legacy.read_bytes()).hexdigest(),external_unchanged=True))
    print('All 2,375 default typed outputs exact; 20 external programs/statuses unchanged; legacy proof copied.')

if __name__=='__main__':main()
