"""Review provenance, corpus deltas and readable remaining failures."""
from collections import Counter
import hashlib
import json

from run_amr_types import ROOT, RUN, BASE, rows, dump, canonical_meaning


def same_meaning(a, b):
    if 'compilation' not in a or 'compilation' not in b:
        return False
    def kinds(r):
        c = r['compilation']
        variables = {v['name']: v['kind'] for v in c['variables']}
        return {n: variables[v] for n, v in c['metadata']['node_variables'].items()}
    return canonical_meaning(a['compilation']) == canonical_meaning(b['compilation']) and kinds(a) == kinds(b)


def main():
    old = {r['claim_id']: r for r in rows(BASE / 'corpus.jsonl')}
    current = {r['claim_id']: r for r in rows(RUN / 'corpus.jsonl')}
    references = json.loads((RUN / 'references.json').read_text())
    prior = {r['claim_id']: r for r in json.loads((ROOT / 'exp/probabilistic_verification/amr_refinement_20261114/reviewed_cases.json').read_text())}
    manual = json.loads((RUN / 'manual_reviews.json').read_text())
    cases = []
    for ref in references:
        cid = ref['claim_id']; after = current[cid]; before = old[cid]
        if 'program' not in after:
            review = dict(whole_reading='not_compiled', reason=after['errors'][-1]['reason'], provenance='automatic refusal')
        elif cid in manual:
            review = dict(manual[cid], provenance='fresh assistant inspection of graph and conditions')
        else:
            assert cid in prior and same_meaning(after, before), cid
            review = dict(prior[cid]['review'], provenance='previous reading reused only for identical conditions modulo identifiers, variable kinds and sharing')
        cases.append(dict(claim_id=cid, text=after['text'], reference=ref, before=before, after=after, review=review))
    dump(RUN / 'reviewed_cases.json', cases)
    summary = json.loads((RUN / 'summary.json').read_text())
    summary['reference_review'] = dict(total=len(cases), counts=dict(Counter(r['review']['whole_reading'] for r in cases)),
                                     fresh=sum(r['review']['provenance'].startswith('fresh') for r in cases),
                                     reused=sum(r['review']['provenance'].startswith('previous') for r in cases),
                                     policy='Fixed development readings, not independent gold or corpus accuracy.')
    summary['reference_groups'] = {}
    for name, subset in [('earlier92', cases[:92]), ('followup24', cases[92:])]:
        summary['reference_groups'][name] = dict(total=len(subset), reviews=dict(Counter(r['review']['whole_reading'] for r in subset)),
                                                check_pass=sum(r['after']['status'] == 'compiled' for r in subset))
    failed = [r for r in current.values() if r['status'] != 'compiled']
    summary['remaining'] = dict(total=len(failed), no_program=sum('program' not in r for r in failed),
                               flagged_programs=sum('program' in r for r in failed),
                               first_stop=dict(Counter(r['errors'][0]['code'] for r in failed)),
                               converted_flags=dict(Counter(e['code'] for r in failed if 'program' in r for e in r['errors'])))
    dump(RUN / 'summary.json', summary)
    dump(RUN / 'remaining.json', [dict(claim_id=r['claim_id'], text=r['text'], errors=r['errors'], has_program='program' in r) for r in failed])
    dump(RUN / 'review_routing.json', {name: [r['claim_id'] for r in cases if r['review']['provenance'].startswith(prefix)] for name, prefix in [('fresh','fresh'),('reused','previous'),('refused','automatic')]})
    # Inspect additional recoveries after the full run. This is an explicitly
    # post-selection development diagnostic, not an independent test sample.
    reference_ids = {r['claim_id'] for r in references}
    selected = sorted((r for r in current.values() if r['claim_id'] not in reference_ids and r['status'] == 'compiled' and old[r['claim_id']]['status'] != 'compiled'), key=lambda r: hashlib.sha256(r['claim_id'].encode()).hexdigest())[:16]
    dump(RUN / 'additional_gains.json', selected)
    if (RUN / 'additional_reviews.json').exists():
        extra = json.loads((RUN / 'additional_reviews.json').read_text())
        assert [r['claim_id'] for r in extra] == [r['claim_id'] for r in selected]
        summary['additional_review'] = dict(total=len(extra), counts=dict(Counter(r['whole_reading'] for r in extra)),
                                            policy='Selected by claim-ID hash among new passes after the full run; development diagnosis, not held-out accuracy.')
        dump(RUN / 'summary.json', summary)
    print(json.dumps(dict(review=summary['reference_review'], groups=summary['reference_groups'], remaining=summary['remaining']), indent=2))


if __name__ == '__main__':
    main()
