"""Current type/scope experiment in the consolidated compiler report."""
import json
from html import escape
import shutil

from run_amr_types import ROOT, RUN, BASE, rows

URL = 'compiler-demos/amr-types-20261115/'


def load(name):
    return json.loads((RUN / name).read_text())


def status_html():
    return '<b>The separate AMR compiler now passes automatic checks on 1,559/2,375 claims (65.64%).</b> These are not verified meanings. The older retained pool stays 1,981/2,375 (83.41%); the methods are not pooled.'


def next_html():
    return '''<ol><li><b>Keep definitions, missions and requests in the correct context.</b> Goal: prevent an event noun from becoming an assertion that the event actually occurred.</li><li><b>Distinguish event nouns from objects and results.</b> Goal: handle a drill as a tool and a ruling as a decision when that is the source meaning.</li><li><b>Evaluate one compiler on new-source references.</b> Goal: measure faithful compilation and false passes before adding more retries or starting relation training.</li></ol>'''


def overview_html():
    from compiler_structural_report import table
    s = load('summary.json')
    h = '<h2 id="remaining-failures">More graphs compile; meaning errors still limit the result</h2><p>Source-based predicate types distinguish properties and event nouns from clauses. Audio-source and purpose contexts retain their content, while verified aliases and linked unit structures reduce false refusals. One cached AMR parser and one fixed compiler process all 2,375 originals. No model requests, GPU allocation, external judge, media inference or training.</p><p>' + status_html() + '</p>'
    h += table('All 2,375 originals, with the same cached AMRs. Automatic conversion is separate from meaning review.', ['Measurement', 'Before', 'After'], [
        ('A program is generated', '1,589', '1,785 (75.16%)'),
        ('Program also passes source/semantic checks', '1,397 (58.82%)', '1,559 (65.64%)'),
        ('Previously failing claims now pass', '—', '163'),
        ('Previously passing claims now flagged', '—', '1: a speed range lost its time unit'),
        ('No program / flagged program', '786 / 192', '590 / 226'),
    ])
    h += '<p>The net increase is <b>162 automatic passes</b>. No earlier graph-conversion pass is lost. <b>816 claims still fail automatic checks:</b> 590 have no program and 226 have a flagged program. The new rate check flags “20–25 km/h” because its graph contains kilometres but no hourly denominator; its railway interpretation of Wipha is also wrong. More refusals from a necessary check can reveal an old error.</p>'
    h += table('Meaning review against development readings. The implementing assistant reviewed changed cases; no new human approvals or independent accuracy estimate.', ['Set', 'Whole-reading matches', 'Important limit'], [
        ('Same earlier 92 readings', '30 before → 31 after', 'Most new executions are incomplete or wrong, not new full readings.'),
        ('24 existing follow-up readings', '2 after', 'Selected earlier; not a new-source test. No comparable complete baseline review.'),
        ('All 116 references', '33 matches; 27 partial; 19 incorrect; 7 context-needed; 30 no program', '28 freshly inspected; 58 reused only for identical conditions, sharing and variable types.'),
        ('16 additional new automatic passes', '5 matches; 7 partial; 4 incorrect', 'Chosen after this run for diagnosis; not held-out accuracy.'),
    ])
    h += '<p><b>The quality gain is much smaller than the execution gain.</b> Fireworks sound and unspecified seconds now have plausible full readings. Closer footage and the recovery-operation goal now compile but remain partial. A valid program can still turn a definition or mission into an actual event. No new AMR candidate is promoted to the older retained pool.</p><p><b>581 tests pass.</b> Default AMR outputs and the earlier 2,375-original/449-rewrite paths reproduce exactly. Native inference checks use constructed observations, not media predictions.</p><p><a href="#amr-types-example">Inspect examples, types and conditions</a> · <a href="#amr-types-failures">Remaining failure patterns</a> · <a href="' + URL + 'summary.json">Exact statistics</a>.</p><h3>Proposed next steps and goals</h3>' + next_html()
    return h


def examples_html():
    from compiler_structural_report import table
    links = [('TQKCK6-tRaoE_662', 'Fireworks sound'), ('TW4OYA3RN-Hw_1821', 'Closer footage'),
             ('TbJqMFkNxARY_172', 'Recovery goal'), ('TgR_u37mCoQ4_1989', 'Unspecified seconds'),
             ('TFgw4IaR9R8s_1570', 'SCOTUS alias'), ('TzzhcBIczf_M_2109', 'Definition error')]
    h = '<section id="amr-types-example"><h2>Inspect what changed and what remains wrong</h2><p>' + ' · '.join('<a href="?typed_claim=' + cid + '#amr-types-example">' + label + '</a>' for cid, label in links) + '</p><label for="typed-case">Saved example</label><select id="typed-case"></select><blockquote id="typed-text"></blockquote><h3>Reference reading</h3><p id="typed-reference"></p><p id="typed-verdict" class="note"></p><p id="typed-reason"></p><p id="typed-provenance" class="muted"></p><figure><div id="typed-graph" class="amr-graph"></div><figcaption>Figure 1. The actual source-normalized AMR. Its nodes and roles are unchanged by predicate typing; incorrect roles and missing information remain visible.</figcaption></figure><label for="typed-condition">Compilation</label><select id="typed-condition"><option value="after">After source-based typing</option><option value="before">Before this change</option></select><h3>Automatic checks</h3><div id="typed-checks"></div><h3>Predicate types and normalization</h3><div id="typed-types"></div><h3>Compiled conditions</h3><div id="typed-conditions"></div><p><a id="typed-share" href="#amr-types-example">Link to this case</a></p><details><summary>Exact AMR, logical form and emitted program</summary><pre id="typed-exact"></pre></details></section>'
    h += '<section id="amr-types-design"><h2>How the changes work</h2><figure><div class="flow"><div><b>Original claim + one AMR</b><small>Reuse source words and dependency links.</small></div><div><b>Predicate types</b><small>Separate properties, event nouns and clauses.</small></div><div><b>Context and value checks</b><small>Keep audio/purpose scope; check names and units.</small></div><div><b>Existing logic backend</b><small>Emit the conditions and review meaning separately.</small></div></div><figcaption>Figure 2. One fixed compilation path. None of these stages trains or selects a parser.</figcaption></figure>'
    h += table('Implemented changes and their limits.', ['Change', 'What it does', 'Limit'], [
        ('Predicate types', 'An aligned adjective can be a property; an event expressed as a noun can be a nominal event. AMR degree/rate structures are relationships, not ordinary clauses.', 'Part of speech does not resolve event/object/result senses.'),
        ('Nominal alignment', 'WordNet derivational links connect event senses such as shaking/flight to shake/fly when one source anchor is available.', 'Artifact/person noun senses are excluded from derivational matching; exact noun matches can still have the wrong sense.'),
        ('Audio and purpose', 'Sound content receives audio_event scope. A purpose relation keeps its goal inside a purpose context. Existing outer event nouns can be referenced inside that context.', 'References cannot escape belief into the outer claim or cross unrelated contexts. More non-factual noun contexts remain unsupported.'),
        ('Aliases', 'A small, explicit identity list accepts SCOTUS/full court name and US/USA/full country names, with compatible entity types.', 'No fuzzy-name repair or general entity linker. Phillies/Phillipines stays rejected.'),
        ('Units', 'A per-second/per-hour denominator of one is licensed only with a linked matching numerator and unit. Multiple one-second units may represent unspecified plural seconds.', 'No guessed exact duration, rate range repair, or general unit conversion.'),
    ])
    h += '<p>A <b>predicate</b> describes an event, property or relationship. A <b>nominal event</b> is an event expressed by a noun, such as shaking. <b>Scope</b> records how content is presented: a goal is not its achievement, and sound evidence does not require visual evidence. ARG numbers depend on the AMR frame; ARG0 is not always an agent. The <a href="https://github.com/amrisi/amr-guidelines/blob/master/amr.md#nouns-that-invoke-predicates">AMR specification</a> explicitly uses predicates for nouns and adjectives. These are standard distinctions, not new paper terminology.</p>'
    if (RUN / 'native_checks.json').exists():
        h += table('Native DeepProbLog on four actual new programs. Constructed independent observations and placeholder candidates; one run each, not a throughput or media experiment.', ['Claim', 'Observation input', 'Observations', 'First solve', 'Analytic check'], [
            (escape(r['claim_id']), '0.90 / 0.05 / 0.05' if r['mixed'] else 'All unknown', r['observations'], f"{r['seconds']:.3f}s", 'Matches') for r in load('native_checks.json')['rows']])
    h += '</section><section id="amr-types-failures"><h2>Remaining failure patterns</h2><p><b>816 claims still fail automatic checks:</b> 590 have no generated program and 226 have a program flagged for review. The categories below are software stops, not a complete linguistic error taxonomy. Some checks remain overstrict. Incorrect meanings also occur among automatic passes.</p>'
    h += table('First graph-conversion stop among 590 refusals. Source flags on 226 generated programs are separate and can overlap.', ['Stop', 'Claims'], [(escape(k.replace('_', ' ')), v) for k, v in sorted(load('summary.json')['graph_refusals'].items(), key=lambda x: -x[1])])
    h += table('Concrete remaining problems, including incorrect automatic passes.', ['Claim', 'Pattern and current result'], [
        ('Scientists work with complex manufacturing tools to build the spacecraft.', 'Missing purpose interpretation: work ARG1 build still has no supported clause-scope rule. Compilation refuses.'),
        ('SCOTUS is skeptical … tendency to call everything an attack/emergency/incursion/rebellion.', 'The alias is now accepted, but tendency/calling scope still refuses. Fixing a name check does not fix the sentence.'),
        ('“Qian Dan” refers to the expulsion of a monk …', 'Incorrect automatic pass: a definition becomes world expulsion conditions. Event-noun alignment is insufficient.'),
        ('Blue Ghost Mission 1 is a lunar landing mission.', 'Incorrect automatic pass: a mission becomes an actual landing. The noun describes a goal/type of mission.'),
        ('It’s almost the Phillies fan son’s birthday.', 'Wrong neural name: Phillies becomes Phillipines. The identity check correctly refuses this program.'),
        ('2021 map shows more Bloc Québécois seats … not as much red.', 'The graph changes year/name and loses the comparative negation reading. Typing cannot restore omitted meaning.'),
        ('Wipha is moving northwest at a speed of 20–25 km/h.', 'Newly flagged old pass: the graph has distances but no hourly denominator, and Wipha is a railway line.'),
        ('Protestors hold a sign … “Carlos Manzo lives!”', 'Incorrect automatic pass: quoted content becomes a real living event. The written-text construction is not recognized.'),
    ])
    h += '<p>The last two types of problem explain why a high execution rate alone cannot establish a working semantic compiler. A better next step is context and word-sense fidelity on checked readings, rather than another large retry sweep.</p><h3>Proposed next steps and goals</h3>' + next_html() + '<h3>Downloads</h3><p>'
    h += ' · '.join('<a href="' + URL + name + '">' + label + '</a>' for name, label in [('source.zip','Source and cached replay'), ('README.md','Design and results'), ('summary.json','Statistics'), ('remaining.json','All 816 automatic failures'), ('cases.json','All shown examples'), ('manual_reviews.json','Fresh reference reviews'), ('additional_reviews.json','16 additional reviews'), ('native_checks.json','Native inference'), ('legacy_regression.json','Unchanged legacy outputs'), ('tests.xml','581 tests'), ('archive_verification.json','Clean replay'), ('browser_checks.json','Browser checks')]) + '</p></section>'
    return h


def write_downloads():
    from amr_composition_report import graph_svg
    target = ROOT / 'site/reports' / URL
    target.mkdir(parents=True, exist_ok=True)
    for name in ['summary.json', 'remaining.json', 'manual_reviews.json', 'additional_reviews.json', 'native_checks.json', 'legacy_regression.json', 'tests.xml', 'archive_verification.json', 'browser_checks.json']:
        if (RUN / name).exists():
            shutil.copy2(RUN / name, target / name)
    shutil.copy2(ROOT / 'docs/amr_types_20261115.md', target / 'README.md')
    cases = load('reviewed_cases.json')
    old = {r['claim_id']: r for r in rows(BASE / 'corpus.jsonl')}
    extra_reviews = {r['claim_id']: r for r in load('additional_reviews.json')}
    for r in load('additional_gains.json'):
        cases.append(dict(claim_id=r['claim_id'], text=r['text'], reference=dict(meaning='Original wording shown above; no separately frozen reference for this post-selection diagnostic.'), before=old[r['claim_id']], after=r, review=dict(extra_reviews[r['claim_id']], provenance='Additional post-selection assistant inspection; not held-out.')))
    current = {r['claim_id']: r for r in rows(RUN / 'corpus.jsonl')}
    cid = 'Txf2EdqOg1SQ_2350'
    cases.append(dict(claim_id=cid, text=current[cid]['text'], reference=dict(meaning='Wipha moves northwest at a speed between 20 and 25 kilometres per hour.'), before=old[cid], after=current[cid], review=dict(whole_reading='incorrect', reason='The hourly denominator is missing and Wipha is typed as a railway line.', provenance='Targeted assistant inspection of the one newly flagged old pass.')))
    for i, r in enumerate(cases):
        r['svg'] = graph_svg(dict(raw=r['after'].get('normalised_amr', r['after']['raw'])), 'types_' + str(i))
    (target / 'cases.json').write_text(json.dumps(cases, ensure_ascii=False, separators=(',', ':')) + '\n')
