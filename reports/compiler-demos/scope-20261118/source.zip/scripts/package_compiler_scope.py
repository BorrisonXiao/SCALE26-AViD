"""Package the cached scope experiments and checked label manifest for replay."""
import hashlib
import json
import zipfile

from run_compiler_scope_repairs import RUN, COVERAGE, AMR, INPUTS, rows
from prepare_compiler_fallback import ROOT

STAGES = ['run_compiler_scope_repairs.py', 'sample_compiler_scope_review.py',
          'review_compiler_scope.py', 'prepare_binding_contrasts.py', 'validate_compiler_scope.py']
OUTPUTS = ['summary.json', 'repairs.json', 'sample.json', 'fidelity.json',
           'binding_contrasts.json', 'test_inventory.json', 'validation.json']


def main():
    names = {str(INPUTS.relative_to(ROOT)), 'tests/test_compiler_scope_repairs.py',
             'docs/compiler_scope_20261118.md'}
    for relative in ('scripts', 'scripts/probabilistic_verification', 'scripts/probabilistic_verification/resources'):
        names.update(str(p.relative_to(ROOT)) for p in (ROOT / relative).glob('*')
                     if p.is_file() and p.suffix in {'.py', '.json'})
    names.update(str((COVERAGE / name).relative_to(ROOT))
                 for name in ('corpus.jsonl', 'summary.json', 'audit.json', 'checked_forms.json', 'test_inventory.json'))
    names.update(str((RUN / name).relative_to(ROOT)) for name in ('media_manifest.json', 'tests.xml', *OUTPUTS))
    data = {name: (ROOT / name).read_bytes() for name in names}
    baseline = rows(COVERAGE / 'corpus.jsonl')
    failed = {r['claim_id'] for r in baseline if r['category'] == 'dependencies'}
    graph_input = [dict(claim_id=r['claim_id'], raw=r['raw'])
                   for r in rows(AMR / 'corpus.jsonl') if r['claim_id'] in failed]
    assert len(graph_input) == len(failed) == 21
    data[str((AMR / 'corpus.jsonl').relative_to(ROOT))] = ''.join(
        json.dumps(r, ensure_ascii=False) + '\n' for r in graph_input
    ).encode()
    data['REPLAY_SHA256.json'] = json.dumps(
        {name: hashlib.sha256((RUN / name).read_bytes()).hexdigest() for name in OUTPUTS},
        indent=2,
    ).encode()
    data['README.md'] = (ROOT / 'docs/compiler_scope_20261118.md').read_bytes()
    target = ROOT / 'site/reports/compiler-demos/scope-20261118/source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in sorted(data.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
    print(f'Bundled {len(data)} files in {target.stat().st_size / 2**20:.2f} MiB.')


if __name__ == '__main__':
    main()
