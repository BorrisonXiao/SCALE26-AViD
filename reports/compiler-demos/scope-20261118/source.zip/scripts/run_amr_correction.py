"""Failure-only local AMR correction, sharing the first attempt across controls."""
import argparse,copy,hashlib,importlib.metadata,json,logging,os,time
from pathlib import Path
from prepare_amr_correction import ROOT,RUN,BASE,rows,dump
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.amr_correction import inspect,request,evaluate,graph_data

def write(p,data):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in data))
def prepare(run=RUN):
 selection=json.loads((run/'selection.json').read_text());ids=selection['development_ids']+selection['followup_ids']
 records={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')if r['claim_id']in ids}
 amrs={r['claim_id']:r for r in rows(BASE/'corpus.jsonl')if r['claim_id']in ids};initial={};routing=[]
 for cid in ids:
  record=records[cid];direct=compile_one(record)
  if direct['status']=='compiled':routing.append(dict(claim_id=cid,request=False,reason='Original strict direct pass; no correction.'));continue
  out=inspect(record,amrs[cid]['raw']);routing.append(dict(claim_id=cid,request=out['status']!='compiled',reason='AMR check failure'if out['status']!='compiled'else'AMR automatic pass; no correction.'))
  initial[cid]=dict(claim_id=cid,text=record['text'],cohort='followup'if cid in selection['followup_ids']else'development',original_direct_error={k:direct.get(k)for k in ['code','reason']},original_graph=graph_data(out['normalised_amr']),output=out)
 write(run/'before.jsonl',list(initial.values()));dump(run/'routing.json',routing)
 return records,initial

def main():
 logging.getLogger('penman').setLevel(logging.ERROR)
 p=argparse.ArgumentParser();p.add_argument('--prepare-only',action='store_true');p.add_argument('--run',type=Path,default=RUN);a=p.parse_args();run=a.run.resolve()
 if(run/'compiler_freeze.json').exists():
  frozen=json.loads((run/'compiler_freeze.json').read_text())
  for name,digest in frozen['source_hashes'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,'Source changed after freeze: '+name
 records,initial=prepare(run)
 manifest=json.loads((run/'reference_manifest.json').read_text());assert hashlib.sha256((run/'followup_references.json').read_bytes()).hexdigest()==manifest['sha256']
 current={cid:dict(row,**row['output'])for cid,row in initial.items()};eligible={cid:r for cid,r in current.items()if r['status']!='compiled'}
 if a.prepare_only or not eligible:
  for cid,r in eligible.items():request(records[cid],initial[cid],r)
  dump(run/'plan.json',dict(records=len(current),eligible=len(eligible),model_called=False,policy='No model import for prepare-only or an all-passing cohort.'))
  print('Prepared',len(current),'cases;',len(eligible),'requests; no model loaded.');return
 os.environ.setdefault('VLLM_WORKER_MULTIPROC_METHOD','spawn')
 import torch
 from transformers import AutoTokenizer
 from vllm import LLM,SamplingParams
 from vllm.sampling_params import StructuredOutputsParams
 path='/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507';tokenizer=AutoTokenizer.from_pretrained(path,local_files_only=True);torch.set_num_threads(4)
 tensor_parallel=int(os.getenv('SLURM_GPUS_ON_NODE','1'))
 model=LLM(model=path,tokenizer=path,dtype='float16',tensor_parallel_size=tensor_parallel,gpu_memory_utilization=0.90,max_model_len=16384,max_num_seqs=4,enable_prefix_caching=True,seed=0)
 dump(run/'config.json',dict(model=path,backend='vllm+xgrammar',dtype='float16',temperature=0,seed=0,tensor_parallel=tensor_parallel,max_new_tokens=1536,max_model_len=16384,batch_size=4,max_edits=8,max_retries=2,shared_first=True,original_direct_error_in_both_branches=True,labels_in_messages=False,job_id=os.getenv('SLURM_JOB_ID'),vllm=importlib.metadata.version('vllm'),torch=torch.__version__,gpus=[torch.cuda.get_device_name(i)for i in range(torch.cuda.device_count())]))
 def generate(previous,folder,guided):
  folder.mkdir(exist_ok=True);saved=rows(folder/'responses.jsonl')if(folder/'responses.jsonl').exists()else[];done={r['claim_id']for r in saved};pending=[r for r in previous.values()if r['status']!='compiled'and r.get('code')!='model_refuse'and r['claim_id']not in done]
  for start in range(0,len(pending),4):
   batch=pending[start:start+4];messages=[];params=[]
   for r in batch:
    cid=r['claim_id'];ms,sc=request(records[cid],initial[cid],r,previous=r.get('response_raw'),feedback=guided);messages.append(ms);params.append(SamplingParams(temperature=0,max_tokens=1536,structured_outputs=StructuredOutputsParams(json=sc,disable_any_whitespace=True)))
   prompts=[tokenizer.apply_chat_template(m,tokenize=False,add_generation_prompt=True)for m in messages];t=time.perf_counter();outputs=model.generate(prompts,params,use_tqdm=False);elapsed=time.perf_counter()-t
   for old,ms,result in zip(batch,messages,outputs):
    q=result.outputs[0];cid=old['claim_id'];out=evaluate(records[cid],old,q.text,original_graph=initial[cid]['original_graph']);saved.append(dict(claim_id=cid,text=old['text'],cohort=old['cohort'],messages=ms,response_raw=q.text,output=out,previous_graph=graph_data(old['normalised_amr']),output_tokens=len(q.token_ids),finish_reason=q.finish_reason,batch_seconds=elapsed))
   write(folder/'responses.jsonl',saved);print(folder.name,len(saved),'complete',sum(r['output']['status']=='compiled'for r in saved),flush=True)
  return {r['claim_id']:{**previous[r['claim_id']],**r['output'],'output':r['output'],'response_raw':r['response_raw']}for r in saved}
 first=copy.deepcopy(current);first.update(generate(first,run/'first',True));write(run/'first_final.jsonl',list(first.values()))
 for branch in ['feedback','generic']:
  final=copy.deepcopy(first)
  for i in[1,2]:final.update(generate(final,run/(branch+'_'+str(i)),branch=='feedback'))
  write(run/(branch+'_final.jsonl'),list(final.values()))
 print('Completed both fixed branches.',flush=True)
if __name__=='__main__':main()
