"""Evaluate a fixed repair pass on the dependency-only cases and retain all IDs."""
import json
import logging
from collections import Counter

from problog.engine import DefaultEngine
from problog.program import PrologString

from run_compiler_coverage import RUN as COVERAGE, AMR, INPUTS, rows, dump, diagnostic
from probabilistic_verification.compiler_fallback import check_output, serialize
from probabilistic_verification.compiler_coverage import review_only
from probabilistic_verification.compiler_scope_repairs import repair_program
from run_amr_types import inspect

RUN = COVERAGE.with_name('compiler_scope_20261118')


def main():
    logging.getLogger('penman').setLevel(logging.ERROR)
    inputs = {r['claim_id']: r for r in rows(INPUTS)}
    raw = {r['claim_id']: r['raw'] for r in rows(AMR / 'corpus.jsonl')}
    original = rows(COVERAGE / 'corpus.jsonl')
    results = []
    for row in original:
        if row['category'] != 'dependencies':
            continue
        cid = row['claim_id']
        record = inputs[cid]
        result = diagnostic(record, 'source_scope_repair',
                            lambda: check_output(record, repair_program(record, raw[cid], inspect)))
        if 'compilation' in result and result.get('program'):
            claim = review_only(result['compilation'], 'scope_repair')
            result = dict(result, **serialize(claim), status='review_required')
            terms = DefaultEngine().ground_all(PrologString(result['program']))
            assert {str(q.args[-1]) for q, _ in terms.queries()} == {'supported', 'refuted', 'unknown'}
        results.append(dict(
            claim_id=cid, text=row['text'], source_videos=record['source_videos'],
            before='dependencies', after='semantic_program' if result.get('program') else 'dependencies',
            result=result,
        ))
    assert len(original) == 2375 and len(results) == 21
    stats = json.loads((COVERAGE / 'summary.json').read_text())
    gained = sum(r['after'] == 'semantic_program' for r in results)
    summary = dict(total=2375, tried=len(results), recovered=gained,
                   previous_semantic=stats['semantic_programs'],
                   current_semantic=stats['semantic_programs'] + gained,
                   dependency_only=len(results) - gained,
                   strict_after_repairs=stats['strict_after_repairs'],
                   failure_codes=Counter(r['result'].get('code') for r in results
                                         if r['after'] == 'dependencies'))
    dump(RUN / 'repairs.json', results)
    dump(RUN / 'summary.json', summary)
    print(json.dumps(summary, indent=2))
    for r in results:
        if r['result'].get('source_repairs') or r['after'] == 'semantic_program':
            print(r['claim_id'], r['after'], r['result'].get('code'),
                  r['result'].get('reason'), [x['kind'] for x in r['result']['source_repairs']])


if __name__ == '__main__':
    main()
