"""Separate automatic status, prior reference judgments and fresh inspections."""
from collections import Counter
import json
from run_amr_contexts import ROOT,RUN,BASE,rows,dump
from analyze_amr_types import same_meaning


def prepare_reviews():
    current={r['claim_id']:r for r in rows(RUN/'corpus.jsonl')}
    old={r['claim_id']:r for r in rows(BASE/'corpus.jsonl')}
    refs=json.loads((BASE/'reviewed_cases.json').read_text())
    additions={r['claim_id']:r for r in json.loads((BASE/'additional_reviews.json').read_text())}
    for r in json.loads((BASE/'additional_gains.json').read_text()):
        refs.append(dict(claim_id=r['claim_id'],text=r['text'],after=r,
                         reference=dict(meaning=r['text'],origin='Additional development diagnostic; original text plus prior review, no separate frozen reading.'),
                         review=additions[r['claim_id']]))
    pending=[];reused=[];refused=[]
    for i,r in enumerate(refs):
        cid=r['claim_id'];after=current[cid]
        if'program'not in after:refused.append(cid)
        elif same_meaning(after,old[cid]):reused.append(cid)
        else:pending.append(dict(index=i,claim_id=cid,text=r['text'],reference=r['reference'],old_review=r['review'],before=old[cid],after=after))
    dump(RUN/'review_routing.json',dict(pending=[r['claim_id']for r in pending],reused=reused,refused=refused))
    dump(RUN/'review_inputs.json',pending)
    lines=[]
    for i,r in enumerate(pending):
        c=r['after']['compilation']
        lines+=['\nCASE '+str(i)+' '+r['claim_id']+' '+r['text'],'REF '+r['reference']['meaning'],
                'OLD '+r['old_review']['whole_reading']+': '+r['old_review']['reason'],
                'CHECKS '+str(r['after']['errors']),'GRAPH '+r['after']['normalised_amr'],
                'SCOPES '+str(c['metadata']['scopes']),'CHANGES '+str(c['metadata']['source_alignment']['normalisations'])]
    (RUN/'review_input.txt').write_text('\n'.join(lines)+'\n')
    print('Reference reviews pending',len(pending),'reused',len(reused),'no program',len(refused),flush=True)


def summarize():
    manual=json.loads((RUN/'manual_reviews.json').read_text())
    current={r['claim_id']:r for r in rows(RUN/'corpus.jsonl')}
    old={r['claim_id']:r for r in rows(BASE/'corpus.jsonl')}
    refs=json.loads((BASE/'reviewed_cases.json').read_text())
    prior_extra={r['claim_id']:r for r in json.loads((BASE/'additional_reviews.json').read_text())}
    for r in json.loads((BASE/'additional_gains.json').read_text()):
        refs.append(dict(claim_id=r['claim_id'],text=r['text'],after=r,reference=dict(meaning=r['text'],origin='Additional development diagnosis; no separate frozen reading.'),review=prior_extra[r['claim_id']]))
    cases=[]
    for i,r in enumerate(refs):
        cid=r['claim_id'];after=current[cid]
        if'program'not in after:review=dict(whole_reading='not_compiled',reason=after['errors'][-1]['reason'],provenance='automatic refusal')
        elif cid in manual:review=dict(manual[cid],provenance='fresh implementing-assistant inspection')
        else:
            assert same_meaning(after,old[cid]),cid
            review=dict(r['review'],provenance='prior judgment reused only for identical conditions, variable kinds and sharing')
        cases.append(dict(claim_id=cid,text=r['text'],reference=r['reference'],before=old[cid],after=after,review=review,
                          previous_review=r['review'],cohort='earlier92'if i<92 else'followup24'if i<116 else'additional16'))
    dump(RUN/'reviewed_cases.json',cases)
    s=json.loads((RUN/'summary.json').read_text())
    s['reviews']={}
    for label in ['earlier92','followup24','additional16']:
        subset=[r for r in cases if r['cohort']==label]
        s['reviews'][label]=dict(total=len(subset),before=dict(Counter(r['previous_review']['whole_reading']for r in subset)),
                                after=dict(Counter(r['review']['whole_reading']for r in subset)),
                                check_pass=sum(r['after']['status']=='compiled'for r in subset))
    s['review_provenance']=dict(fresh=sum(r['review']['provenance'].startswith('fresh')for r in cases),
                                reused=sum(r['review']['provenance'].startswith('prior')for r in cases),
                                no_program=sum('program'not in r['after']for r in cases))
    external=json.loads((RUN/'external_outputs.json').read_text());judgments=json.loads((RUN/'external_reviews.json').read_text());by={r['claim_id']:r for r in judgments}
    for r in external:r['reference']=next(x for x in json.loads((RUN/'external_references.json').read_text())if x['claim_id']==r['claim_id']);r['review']=by[r['claim_id']]
    dump(RUN/'external_cases.json',external)
    s['external']={name:dict(total=20,generated=sum('program'in r[name]for r in external),passing=sum(r[name]['status']=='compiled'for r in external),
                             meanings=dict(Counter(r['review'][name]['whole_reading']for r in external)))for name in ['before','after']}
    remaining=[r for r in current.values()if r['status']!='compiled']
    s['remaining']=dict(total=len(remaining),no_program=sum('program'not in r for r in remaining),flagged=sum('program'in r for r in remaining))
    dump(RUN/'remaining.json',[dict(claim_id=r['claim_id'],text=r['text'],errors=r['errors'],has_program='program'in r)for r in remaining])
    dump(RUN/'summary.json',s)
    print(json.dumps(dict(reviews=s['reviews'],provenance=s['review_provenance'],external=s['external'],remaining=s['remaining']),indent=2))


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--summarize',action='store_true');a=p.parse_args()
    summarize()if a.summarize else prepare_reviews()
