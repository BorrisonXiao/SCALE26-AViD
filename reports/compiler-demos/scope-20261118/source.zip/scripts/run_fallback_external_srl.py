"""Frozen BERT SRL on the existing 20 external text diagnostics; CPU only."""
import hashlib,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_fallback_20261118';BASE=ROOT/'exp/probabilistic_verification/amr_contexts_20261118'
def main():
    import torch
    from allennlp.predictors.predictor import Predictor
    from run_srl_baseline import bio_to_spans
    torch.set_num_threads(2)
    metadata=next(json.loads(p.read_text())for p in Path('/home/hltcoe/cxiao/.allennlp/cache').glob('*.json')if 'structured-prediction-srl-bert'in p.read_text())
    model=Path(metadata['cached_path']);predictor=Predictor.from_path(str(model),cuda_device=-1)
    rows=[json.loads(x)for x in(BASE/'external_inputs.jsonl').read_text().splitlines()];start=time.perf_counter()
    for offset in range(0,len(rows),8):
        batch=rows[offset:offset+8];outputs=predictor.predict_batch_json([dict(sentence=r['text'])for r in batch])
        for row,out in zip(batch,outputs):
            frames=[]
            for v in out['verbs']:
                spans=bio_to_spans(v['tags']);verb=next(([s,e]for role,s,e in spans if role=='V'),None)
                frames.append(dict(verb=v['verb'],verb_span=verb,args=[dict(role=role,start=s,end=e,text=' '.join(out['words'][s:e+1]))for role,s,e in spans if role!='V']))
            row['srl']=dict(claim_id=row['claim_id'],words=out['words'],frames=frames)
        print('SRL',min(offset+8,len(rows)),'/20',flush=True)
    (RUN/'external_inputs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
    (RUN/'external_srl.json').write_text(json.dumps(dict(model_metadata=metadata,model_sha256=hashlib.sha256(model.read_bytes()).hexdigest(),device='cpu',torch=torch.__version__,claims=20,seconds=time.perf_counter()-start,training=False),indent=2)+'\n')
if __name__=='__main__':main()
