"""Recompute earlier default outputs while preserving their original artifacts."""
import json,logging
from prepare_compiler_fallback import ROOT,RUN,BASE,rows,dump
import check_amr_refinement_regression as legacy
from run_amr_types import inspect

def main():
    logging.getLogger('penman').setLevel(logging.ERROR)
    legacy.RUN=RUN;legacy.main()
    inputs={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')}
    old=rows(ROOT/'exp/probabilistic_verification/amr_types_20261115/corpus.jsonl')
    for r in old:assert json.loads(json.dumps(inspect(inputs[r['claim_id']],r['raw'])))==r,r['claim_id']
    proof=json.loads((RUN/'legacy_regression.json').read_text());proof.update(default_typed_claims=2375,default_typed_exact=True)
    dump(RUN/'default_regression.json',proof);print('All default typed2375, originalAMR2375 and SRL2375/rewrite449 exact.')
if __name__=='__main__':main()
