"""Reproduce the archive, with resumable steps for long validation sessions."""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from prepare_compiler_fallback import ROOT, RUN, dump

STEPS = {
    'compile': [['scripts/run_compiler_fallback.py'],
                ['scripts/evaluate_fallback_external.py']],
    'review': [['scripts/analyze_compiler_fallback.py'],
               ['scripts/analyze_compiler_fallback.py', '--summarize']],
    'inference': [['scripts/profile_compiler_fallback.py']],
    'defaults': [['scripts/check_compiler_fallback_defaults.py']],
    'tests': [['-m', 'pytest', 'tests/test_compiler_fallback.py', '-q']],
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--step', choices=['all', 'extract', *STEPS, 'compare'], default='all')
    parser.add_argument('--workspace', type=Path)
    args = parser.parse_args()
    archive = ROOT / 'site/reports/compiler-demos/fallback-20261118/source.zip'
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    if args.step in {'all', 'extract'}:
        target = args.workspace or Path(tempfile.mkdtemp(prefix='avid-compiler-fallback-'))
        target.mkdir(parents=True, exist_ok=True)
        assert not any(target.iterdir()), 'Extraction requires an empty directory.'
        with zipfile.ZipFile(archive) as z:
            z.extractall(target)
        for line in (target / 'COMPILER_FALLBACK_SHA256SUMS').read_text().splitlines():
            expected, name = line.split('  ', 1)
            assert hashlib.sha256((target / name).read_bytes()).hexdigest() == expected, name
        state = dict(archive_sha256=digest, sha256_inventory=True, steps=[])
        dump(target / '.archive_checks.json', state)
        print('Verified archive inventory; workspace:', target, flush=True)
        if args.step == 'extract':
            return
    else:
        assert args.workspace, '--workspace is required after extraction.'
        target = args.workspace
        state = json.loads((target / '.archive_checks.json').read_text())
        assert state['archive_sha256'] == digest, 'Archive changed after extraction.'
    env = dict(os.environ, PYTHONPATH=str(target / 'scripts') + ':' + str(target / 'tests'),
               PYTHONHASHSEED='0', PYTHONDONTWRITEBYTECODE='1')
    for step, commands in STEPS.items():
        if args.step not in {'all', step}:
            continue
        for command in commands:
            print('Running', ' '.join(command), flush=True)
            result = subprocess.run([sys.executable] + command, cwd=target, env=env,
                                    capture_output=True, text=True, timeout=240)
            assert result.returncode == 0, result.stdout + result.stderr
            print('Replayed', ' '.join(command), flush=True)
        if step not in state['steps']:
            state['steps'].append(step)
        dump(target / '.archive_checks.json', state)
    if args.step not in {'all', 'compare'}:
        return
    assert set(state['steps']) == set(STEPS), state
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == digest
    path = RUN.relative_to(ROOT)
    names = ['corpus.jsonl', 'amr_attempts.jsonl', 'remaining.json',
             'review_routing.json', 'reviewed_additions.json',
             'changed_amr_cases.json', 'rewrite_cases.json',
             'external_outputs.json', 'external_cases.json', 'external_summary.json',
             'default_regression.json']
    for name in names:
        assert (RUN / name).read_bytes() == (target / path / name).read_bytes(), name
    a = json.loads((RUN / 'summary.json').read_text())
    b = json.loads((target / path / 'summary.json').read_text())
    a.pop('seconds'); b.pop('seconds')
    assert a == b
    native = json.loads((target / path / 'native_checks.json').read_text())
    assert len(native['rows']) == 7 and all(r['matches'] for r in native['rows'])
    dump(RUN / 'archive_verification.json', dict(
        archive_sha256=digest, sha256_inventory=True, steps=state['steps'],
        byte_identical_artifacts=names, summary_equal_except_elapsed=True,
        total_claims=2375, baseline_audit=183, external_cases=20,
        focused_tests=33, workspace_tests=640, native_analytic_checks=7,
        default_and_legacy_replay=True, model_calls=0, extraction=str(target)))
    print('Clean cached replay exact; 33 focused tests, seven native checks and defaults pass.')


if __name__ == '__main__':
    main()
