"""Controlled native DeepProbLog checks: same programs, different variable order."""
import argparse,dataclasses,hashlib,json,math,os,platform,subprocess,sys,time
from prepare_amr_correction import ROOT,RUN,BASE,rows,dump

def worker(case,mode,ordered,domain=1):
 import torch
 from probabilistic_verification.amr_refinement import compile_refined
 from probabilistic_verification.logic import Evidence,ground,Observation,GroundProgram
 from probabilistic_verification.representation import Expression as E
 from probabilistic_verification.direct_backend import DirectVerifier
 from probabilistic_verification.compact_backend import compact_prolog_program
 from probabilistic_verification.ordered_circuit import OrderedSolver
 from problog.logic import Term,Var
 from deepproblog.query import Query
 torch.set_num_threads(2);expected=None
 if case.startswith('conjunction'):
  n=int(case.removeprefix('conjunction'));oset=[Observation('o'+str(i),(.9,.05,.05),mode=='gradient','o',available=True)for i in range(n)];gp=GroundProgram(case,E.combine('and',[E.atom(o.id)for o in oset]),{o.id:o for o in oset},[],[])
 else:
  source=next(r for r in rows(BASE/'corpus.jsonl')if r['claim_id']==case);record=next(r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')if r['claim_id']==case);c=compile_refined(record,source['raw'])
  evidence=Evidence('compilation_only',{v.name:[f'placeholder:{v.name}:{i}'for i in range(domain if v.kind=='entity'else 1)]for v in c.variables},{v.name:True for v in c.variables},{})
  gp=ground(c,evidence,max_expansions=10000)
  gp.observations={k:dataclasses.replace(o,distribution=(.9,.05,.05),available=True,trainable=mode=='gradient')for k,o in gp.observations.items()}
 if mode=='unknown':gp.observations={k:dataclasses.replace(o,distribution=(0.,0.,1.),trainable=False)for k,o in gp.observations.items()};expected=dict(supported=0.,refuted=0.,unknown=1.)
 elif domain==1:
  def conjunction(e):return e.op=='atom'or e.op=='and'and all(conjunction(x)for x in e.children)
  if conjunction(gp.expression):
   n=len(gp.observations);expected=dict(supported=.9**n,refuted=1-.95**n,unknown=.95**n-.9**n)
 started=time.perf_counter();v=DirectVerifier([gp],learned=mode=='gradient',program_builder=compact_prolog_program,solver_class=OrderedSolver if ordered else None);setup=time.perf_counter()-started
 q=Query(Term('verdict',Term(v.claim_names[gp.claim_id]),Var('State')));t=time.perf_counter();result=v.model.solve([q])[0];elapsed=time.perf_counter()-t
 values={str(k.args[1]):z for k,z in result.result.items()};scores={s:float(values.get(s,0.))for s in ['supported','refuted','unknown']}
 assert math.isclose(sum(scores.values()),1.,abs_tol=1e-9),scores
 if expected:assert all(math.isclose(scores[s],expected[s],abs_tol=1e-9)for s in scores),(scores,expected)
 grad=None
 if mode=='gradient':
  (-values['unknown'].log()).backward();grad=float(v.classifier.layers[-1].weight.grad.norm());assert grad>0
 t=time.perf_counter();v.model.solve([q]);cached=time.perf_counter()-t
 print(json.dumps(dict(case=case,mode=mode,ordered=ordered,entity_domain=domain,observations=len(gp.observations),program_sha256=hashlib.sha256(v.program.encode()).hexdigest(),setup_seconds=setup,first_solve_seconds=elapsed,cached_seconds=cached,ground_seconds=result.ground_time,compile_seconds=result.compile_time,evaluate_seconds=result.eval_time,distribution=scores,expected=expected,gradient_norm=grad,proof_nodes=len(v.model.solver.cache.get(q).proof))),flush=True)

def main():
 p=argparse.ArgumentParser();p.add_argument('--worker',action='store_true');p.add_argument('--case');p.add_argument('--mode',default='mixed');p.add_argument('--ordered',action='store_true');p.add_argument('--domain',type=int,default=1);a=p.parse_args()
 if a.worker:worker(a.case,a.mode,a.ordered,a.domain);return
 cases=[('Txf2EdqOg1SQ_2176','unknown',1),('Txf2EdqOg1SQ_2176','mixed',1),('Tg0UxWYuPeJ0_323','mixed',1),('T1JQ-aG78Zuc_796','mixed',1),('Txf2EdqOg1SQ_2176','unknown',2),('Tg0UxWYuPeJ0_323','unknown',2),('conjunction32','mixed',1),('conjunction64','mixed',1),('Txf2EdqOg1SQ_2176','gradient',1)]
 output=[]
 for case,mode,domain in cases:
  for ordered in [False,True]:
   t=time.perf_counter();cmd=[sys.executable,__file__,'--worker','--case',case,'--mode',mode,'--domain',str(domain)]+(['--ordered']if ordered else[])
   try:
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=12,env=dict(os.environ,PYTHONHASHSEED='0'));data=[json.loads(s)for s in r.stdout.splitlines()if s.startswith('{')];row=dict(status='completed'if r.returncode==0 else'error',result=data[-1]if data else None,stdout=r.stdout,stderr=r.stderr,returncode=r.returncode)
   except subprocess.TimeoutExpired as e:row=dict(status='time_limit',limit_seconds=12,stdout=(e.stdout or b'').decode()if isinstance(e.stdout,bytes)else e.stdout,stderr=(e.stderr or b'').decode()if isinstance(e.stderr,bytes)else e.stderr)
   row.update(case=case,mode=mode,entity_domain=domain,ordered=ordered,process_seconds=time.perf_counter()-t);output.append(row);dump(RUN/'inference_profile.json',dict(rows=output,platform=platform.platform(),policy='Native DeepProbLog; unchanged serialized programs/probabilities; fresh process12s including imports; PYTHONHASHSEED=0; two CPU threads; one diagnostic run per condition, not a broad throughput benchmark. Constructed observations and score-calibrator gradients only; no media training.'))
   print(case,mode,domain,ordered,row['status'],flush=True)
if __name__=='__main__':main()
