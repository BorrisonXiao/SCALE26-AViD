"""Record development readings and inventory the full automatic test set."""
import json
from collections import Counter

from prepare_compiler_fallback import rows, dump
from run_compiler_coverage import RUN, STRICT, INPUTS
from probabilistic_verification.compiler_coverage import request_scope_warning

# Source text, exact saved predicate arguments and scope were inspected.
EXAMPLES = {
    'Tsuk2uoYj-kc_628': ('One overlay, one exact quote', 'matches_reference',
        'The same overlay is visible and carries the exact string. The old AMR treated the two travel times as events inside the graph. The new program asks for visual support for the overlay and OCR support for its text.'),
    'TgR_u37mCoQ4_1878': ('A long quote begins in the middle of a sentence', 'matches_reference',
        'The source says some on-screen text is cut off. The new program keeps that property and the literal quote together. The casualties, dates and other details stay inside the written text.'),
    'TQEmEycTI0RQ_898': ('An image of a tweet with a named author', 'matches_reference',
        'The program links the image depiction, exact tweet text and named author. The quote contains requests and hypothetical events, and the program keeps their wording inside the OCR condition.'),
    'Txf2EdqOg1SQ_2343': ('Depiction of a reporter wearing a raincoat', 'partial',
        'The program links the same wearer and white raincoat to the depiction in Zhuhai, Guangdong. AMR also represents the reporter through a reporting event. The source gives a profession and does not require a reporting event in the clip.'),
    'TInVWzp25aIM_12': ('A question about whether someone is missing', 'partial',
        'Both the question and the uncertainty refer to the AMR truth-value node. The new nested conditions preserve the question reading. The formula still needs a check of variable binding across the negated clarity clause before it can settle the claim.'),
    'TQEmEycTI0RQ_983': ('Majority and minority remain alternatives within a question', 'partial',
        'The AMR polarity node now encloses the OR alternatives within question scope. The form still lacks a clear future qualification for “will.”'),
    'Txf2EdqOg1SQ_2173': ('Crouching or sitting shares a purpose', 'partial',
        'The two actions remain alternatives using one people variable. The purpose condition applies to the coordination as a whole, and the ground condition stays attached to sitting. The generated scope still requires a compatible evidence function.'),
    'TQEmEycTI0RQ_976': ('A shared local lead does not fix the vote-count meaning', 'partial',
        'The graph now keeps “locally” linked to the same leading event and preserves names and numbers. It also encodes the reported vote count through an AMR causal relation and leaves later counts underspecified.'),
    'TgR_u37mCoQ4_1884': ('The four establishments share a location', 'partial',
        'The selected program keeps the content beneath “imply” and retains four names and the location. The location is attached to a generic establishments description, so a check should connect it to each listed member under a shared implied context.'),
    'TzzhcBIczf_M_2111': ('An implication has content and an owner', 'matches_reference',
        'The allegations own the implied clause. Shi Yongxin is linked to the Abbot position, and the illegitimate obtaining stays inside that clause.'),
    'Txf2EdqOg1SQ_2166': ('Earlier SRL can compile a phrase while losing its OR', 'incorrect',
        'The earlier converter produces a program but treats pier and terminal area as members of a group. The source allows either place. The program also analyzes the idiom “takes place” as a literal take predicate.'),
    'TQEmEycTI0RQ_806': ('Negation over all votes', 'dependency_only',
        '“Not all” narrows the claim to a quantified subset. The AMR graph gives a negated argument but leaves its projection unresolved, so the output contains grammatical links only.'),
    'TQEmEycTI0RQ_871': ('Voting alternatives with a condition on one branch', 'dependency_only',
        'The source links being outside the country to the mail-in alternative. The AMR graph shares an alternative across contexts, and the compiler leaves its scope for review.'),
    'TFgw4IaR9R8s_1739': ('An otherwise clause needs context', 'dependency_only',
        'The graph contains an unlinked minus-valued argument. The preceding condition is implicit in “otherwise.” A dependency analysis keeps the surface attachments and does not infer an antecedent.'),
}

REMAINING = {
    'TFOEIehBwT8Q_467': 'Several quoted utterances include directives, uncertainty and anomalous coordination edges.',
    'TQEmEycTI0RQ_806': 'Negation scopes over the “all” quantifier within reported content.',
    'TQEmEycTI0RQ_867': 'A pictured website embeds several actions, alternatives and descriptive conditions with event reentry.',
    'TQEmEycTI0RQ_871': 'The mail-in branch has a condition and an alternative is referenced outside the choice.',
    'TQEmEycTI0RQ_916': 'Comparative chart trends share events across clusters with different scopes.',
    'TQEmEycTI0RQ_918': 'A trend comparison and narrative time qualifiers cross graph contexts.',
    'TQEmEycTI0RQ_960': 'The alternative alliance is linked to a hypothetical seat majority and another event context.',
    'TQEmEycTI0RQ_972': 'Seat counts and a majority threshold have graph nodes the translation cannot reach.',
    'TQEmEycTI0RQ_975': 'The graph repeats a core role for vote totals and a named candidate.',
    'TFgw4IaR9R8s_1547': 'The legal result combines alternative predicates, negation and a near-universal tariff group.',
    'TFgw4IaR9R8s_1586': 'The image depicts signing while the object identity is a likelihood qualifier.',
    'TFgw4IaR9R8s_1634': 'The source combines reported content with “not just ... but” and a universal clause.',
    'TFgw4IaR9R8s_1639': 'The ruling is both the main referent and an argument to the unless clause.',
    'TFgw4IaR9R8s_1655': 'The view of a past period is nested in a claim that another speaker calls a fantasy.',
    'TFgw4IaR9R8s_1657': 'The market response and possible recession also have source and depiction links that are not all translated.',
    'TFgw4IaR9R8s_1724': 'The headline and subheading attach several graph participants to a repeated core role.',
    'TFgw4IaR9R8s_1726': 'Another website description has multiple actions and cross-context references.',
    'TFgw4IaR9R8s_1730': 'Another voting-method description shares an OR alternative with a clause outside its branch.',
    'TFgw4IaR9R8s_1731': 'An instructions clause occurs inside a list of depicted ballot items, with a node left unvisited.',
    'TFgw4IaR9R8s_1739': 'An otherwise clause depends on the preceding discourse and the AMR contains a malformed argument.',
    'Txf2EdqOg1SQ_2289': 'The graph links one actor to an OR clause and has an incomplete coordination structure.',
    'TQEmEycTI0RQ_898': 'The long written quotation is split into graph sentences with unresolved disjunction and quote boundaries.',
}


def main():
    outputs = rows(RUN / 'corpus.jsonl')
    baseline = rows(STRICT / 'corpus.jsonl')
    inputs = rows(INPUTS)
    assert [r['claim_id'] for r in outputs] == [r['claim_id'] for r in inputs]
    examples = []
    remaining = []
    inventory = []
    checked = []
    previous_reviews = {r['claim_id']: r['review'] for r in
                        json.loads((STRICT / 'reviewed_additions.json').read_text())}
    request_alerts = []
    for record, row, old in zip(inputs, outputs, baseline):
        cid = row['claim_id']
        category = row['category']
        output = row.get('output') or old.get('output')
        if category == 'strict_baseline':
            assert row['program_sha256'] == old['output']['program_sha256']
            alert = request_scope_warning(record, output['compilation'])
            if alert:
                request_alerts.append(dict(claim_id=cid, text=row['text'], stage=row['chosen_stage'], **alert))
        if cid in EXAMPLES:
            title, judgment, finding = EXAMPLES[cid]
            if cid == 'TQEmEycTI0RQ_898' and category != 'source_repair':
                title, judgment, finding = ('A long image quotation', 'dependency_only', REMAINING[cid])
            if category == 'dependencies':
                judgment = 'dependency_only'
            examples.append(dict(claim_id=cid, category=category, title=title, judgment=judgment,
                                 text=row['text'], finding=finding))
        if category == 'dependencies':
            assert cid in REMAINING, cid
            remaining.append(dict(claim_id=cid, text=row['text'], diagnosis=REMAINING[cid],
                                  stages=[{k: a.get(k) for k in ('stage', 'status', 'reason', 'errors')}
                                          for a in row['attempts']]))
        source_videos = record.get('source_videos') or [cid.rsplit('_', 1)[0]]
        inventory.append(dict(claim_id=cid, source_videos=source_videos, category=category,
                              stage=row['chosen_stage'], program_sha256=row.get('program_sha256')))
        previous_check = category == 'strict_baseline' and previous_reviews.get(cid, {}).get('whole_reading') == 'matches_reference'
        new_check = category == 'source_repair' and cid in EXAMPLES and EXAMPLES[cid][1] == 'matches_reference'
        if previous_check or new_check:
            checked.append(dict(claim_id=cid, text=row['text'], source_videos=source_videos,
                                compilation=output['compilation'], program_sha256=row['program_sha256'],
                                provenance='Previous exact development review' if previous_check else 'Current inspection of the exact source and compiled form'))
    external = json.loads((STRICT / 'external_cases.json').read_text())
    external_alerts = []
    for row in external:
        output = row['fallback'].get('output')
        alert = request_scope_warning(row, output['compilation']) if output else None
        if alert:
            external_alerts.append(dict(claim_id=row['claim_id'], text=row['text'], **alert))
    dump(RUN / 'audit.json', dict(
        examples=examples, reviewed_example_count=len(examples), remaining=remaining,
        request_check=dict(corpus_alerts=request_alerts, external_alerts=external_alerts,
                           policy='Advisory diagnostic only. It does not select a parser or estimate all wrong passes.'),
        checked_forms=len(checked), checked_source_groups=len({v for r in checked for v in r['source_videos']}),
        policy='Implementing-assistant development review. No truth labels or media. Exact forms are candidates for preparation and require separate evidence labels.',
    ))
    dump(RUN / 'checked_forms.json', checked)
    dump(RUN / 'test_inventory.json', inventory)
    print('Reviewed', len(examples), 'examples and', len(remaining), 'remaining failures.')
    print('Prepared', len(checked), 'previously or currently reviewed forms, and', len(inventory), 'test IDs.')
    print('Advisory request alerts', len(request_alerts), 'corpus,', len(external_alerts), 'external.')
    print('Example judgments:', dict(Counter(r['judgment'] for r in examples)))


if __name__ == '__main__':
    main()
