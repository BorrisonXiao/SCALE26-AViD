"""Replay the strict baseline and measure each additional way to generate logic."""
import json
import logging
from collections import Counter

from prepare_compiler_fallback import ROOT, RUN as STRICT, BASE as AMR, rows, dump, verify_freeze
from probabilistic_verification.compiler_coverage import (
    CoordinationScopePolicy, SourceScopePolicy, UnresolvedComplementPolicy,
    compile_reentrant_amr, dependency_conditions, normalize_annotated_coordination,
    normalize_sentence_mode, repair_srl_implication, review_only, written_quote_conditions,
)
from probabilistic_verification.compiler_fallback import check_output, serialize
from probabilistic_verification.amr_types import compile_typed
from probabilistic_verification.fallback_amr import prepare_fallback
from run_amr_types import inspect
from run_semantic_srl_census import compile_one as compile_earlier_srl

RUN = STRICT.with_name('compiler_coverage_20261118')
INPUTS = ROOT / 'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl'


def amr_candidate(record, raw, policy):
    result = inspect(
        record, raw, prepare=prepare_fallback,
        compiler=lambda record, raw, **kwargs: compile_typed(
            record, raw, scope_policy=policy(record), **kwargs,
        ),
    )
    checked = check_output(record, result)
    scopes = checked.get('compilation', {}).get('metadata', {}).get('scopes', {})
    if result['status'] == 'compiled' and any(s.get('kind') == 'implication' for s in scopes.values()):
        from probabilistic_verification.fallback_semantics import source_triggers
        triggers = source_triggers(record)['conditional_tokens']
        if triggers and all(t['lemma'] == 'imply' for t in triggers):
            checked['shared_checks'] = [
                issue for issue in checked.get('shared_checks', []) if issue['code'] != 'conditional_scope'
            ]
            if not checked['shared_checks']:
                checked['status'] = 'compiled'
                checked.pop('code', None)
                checked.pop('reason', None)
    return checked


def coordination_candidate(record, raw):
    normalized, trace = normalize_annotated_coordination(raw)
    if not trace:
        return dict(status='unsupported', code='coordination_not_applicable',
                    reason='No supported coordination annotation to normalize.')
    result = amr_candidate(record, normalized, CoordinationScopePolicy)
    return dict(result, coordination_changes=trace)


def quote_candidate(record):
    return check_output(record, dict(status='compiled', **serialize(written_quote_conditions(record))))


def diagnostic(record, kind, function):
    try:
        result = function()
    except Exception as error:
        result = dict(status='unsupported', code=getattr(error, 'code', type(error).__name__), reason=str(error))
    return dict(result, stage=kind)


def strongest_candidate(attempts, stages):
    return next((a for a in attempts if a['stage'] in stages and a.get('program') and a.get('compilation')), None)


def resolve(record, baseline, raw):
    initial = baseline['attempts']
    analyses = []
    if baseline['parsing_status'] == 'compiled':
        return dict(claim_id=record['claim_id'], text=record['text'], category='strict_baseline',
                    chosen_stage=baseline['selected_stage'], program_sha256=baseline['output']['program_sha256'])

    # Source-licensed repair is also tried on warned candidates to measure whether
    # it improves ability to produce a program that passes the original checks.
    repair = diagnostic(record, 'source_scope', lambda: amr_candidate(record, raw, SourceScopePolicy))
    analyses.append(repair)
    quotation = diagnostic(record, 'written_quote', lambda: quote_candidate(record))
    analyses.append(quotation)
    implication = repair_srl_implication(record, initial[0])
    if implication:
        analyses.append(dict(stage='srl_implication', status='compiled', **serialize(implication)))
    choice = next((a for a in analyses if a['status'] == 'compiled'), None)
    category = 'source_repair'
    if choice is None:
        choice = strongest_candidate(initial, {'srl', 'amr', 'rewrite'})
        category = 'advisory_checks'
    if choice is None:
        choice = strongest_candidate(analyses, {'source_scope'})
        category = 'source_repair_with_warnings'
    if choice is None:
        complement = diagnostic(
            record, 'unresolved_complement',
            lambda: amr_candidate(record, raw, UnresolvedComplementPolicy),
        )
        analyses.append(complement)
        choice = strongest_candidate(analyses, {'unresolved_complement'})
        category = 'amr_unresolved_complement'
    if choice is None:
        coordination = diagnostic(record, 'annotated_coordination', lambda: coordination_candidate(record, raw))
        analyses.append(coordination)
        choice = strongest_candidate(analyses, {'annotated_coordination'})
        category = 'amr_annotated_coordination'
    if choice is None:
        def reentrant():
            normalized, mode_changes = normalize_sentence_mode(raw)
            normalized, trace = normalize_annotated_coordination(normalized)
            output = inspect(record, normalized, compiler=compile_reentrant_amr, prepare=prepare_fallback)
            return dict(check_output(record, output), coordination_changes=trace, mode_changes=mode_changes)
        analyses.append(diagnostic(record, 'reentrant_amr', reentrant))
        choice = strongest_candidate(analyses, {'reentrant_amr'})
        category = 'amr_reentrancy'
    if choice is None:
        earlier = diagnostic(record, 'earlier_srl', lambda: check_output(record, compile_earlier_srl(record)))
        analyses.append(earlier)
        choice = strongest_candidate(analyses, {'earlier_srl'})
        category = 'earlier_srl'
    if choice is None:
        def dependency():
            return dict(status='diagnostic', **serialize(dependency_conditions(record)))
        analyses.append(diagnostic(record, 'dependencies', dependency))
        choice = strongest_candidate(analyses, {'dependencies'})
        category = 'dependencies'
    result = dict(claim_id=record['claim_id'], text=record['text'],
                  category=category if choice else 'no_program',
                  chosen_stage=choice['stage'] if choice else None,
                  baseline_attempts=[{k: a.get(k) for k in ('stage', 'code', 'reason', 'status')}
                                     for a in initial],
                  attempts=analyses)
    if choice:
        if category == 'source_repair':
            result['output'] = choice
        else:
            claim = review_only(choice['compilation'], category)
            result['output'] = dict(choice, **serialize(claim), status='review_required')
        result['program_sha256'] = result['output']['program_sha256']
    return result


def summarize(results, strict_attempts):
    counts = Counter(r['category'] for r in results)
    raw_executable = sum(
        r['category'] == 'strict_baseline' or any(a.get('program') for a in attempts)
        for r, attempts in zip(results, strict_attempts)
    )
    strict = counts['strict_baseline'] + counts['source_repair']
    semantic = strict + sum(counts[k] for k in (
        'advisory_checks', 'source_repair_with_warnings', 'amr_unresolved_complement',
        'amr_annotated_coordination', 'amr_reentrancy', 'earlier_srl',
    ))
    return {
        'total': len(results), 'strict_baseline': counts['strict_baseline'],
        'advisory_only_ablation': raw_executable, 'strict_after_repairs': strict,
        'semantic_programs': semantic, 'programs_including_dependencies': semantic + counts['dependencies'],
        'categories': dict(counts),
        'unresolved_semantic': dict(Counter(
            (next((a.get('errors', [{}])[-1].get('code') if a.get('errors') else a.get('code')
                   for a in r['attempts'] if a['stage'] == 'reentrant_amr'), None) or 'unknown')
            for r in results if r['category'] in {'dependencies', 'no_program'}
        )),
        'no_program': counts['no_program'],
    }


def main():
    logging.getLogger('penman').setLevel(logging.ERROR)
    verify_freeze()
    RUN.mkdir(exist_ok=True)
    original = rows(STRICT / 'corpus.jsonl')
    amr = {r['claim_id']: r['raw'] for r in rows(AMR / 'corpus.jsonl')}
    records = rows(INPUTS)
    assert [r['claim_id'] for r in original] == [r['claim_id'] for r in records]
    results = [resolve(record, baseline, amr.get(record['claim_id']))
               for record, baseline in zip(records, original)]
    with (RUN / 'corpus.jsonl').open('w') as file:
        for row in results:
            file.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
    summary = summarize(results, [r['attempts'] for r in original])
    dump(RUN / 'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
