"""Verify the full-corpus overlay, review provenance and evidence separation."""
import hashlib
import json
import re
from collections import Counter

from run_compiler_scope_repairs import RUN, COVERAGE, dump


def main():
    def read(path):
        return json.loads(path.read_text())

    summary = read(RUN / 'summary.json')
    previous = read(COVERAGE / 'test_inventory.json')
    reviewed = read(RUN / 'fidelity.json')
    repaired = {r['claim_id']: r for r in reviewed['repairs'] if r['after'] == 'semantic_program'}
    assert len(repaired) == summary['recovered'] == 4
    check_hashes = {r['claim_id']: r['program_sha256'] for r in read(RUN / 'sample.json')['sample']
                    if 'program_sha256' in r}
    # The sampled outputs use the saved reviewed program exactly.
    check_hashes.update({r['claim_id']: r['output']['program_sha256'] for r in read(RUN / 'sample.json')['sample']})
    assert all(check_hashes[r['claim_id']] == r['program_sha256'] for r in reviewed['reviews'])
    inventory = []
    for row in previous:
        addition = repaired.get(row['claim_id'])
        if addition:
            assert row['category'] == 'dependencies'
            result = addition['result']
            assert hashlib.sha256(result['program'].encode()).hexdigest() == result['program_sha256']
            assert result['status'] == 'review_required'
            compilation = result['compilation']
            assert not any(compilation['metadata']['allowed_routes'].values())
            assert not any(atom['trainable'] for atom in compilation['atoms'])
            row = dict(row, category='scope_repair', stage=result['stage'],
                       program_sha256=result['program_sha256'])
        inventory.append(row)
    assert len(inventory) == len({r['claim_id'] for r in inventory}) == summary['total'] == 2375
    categories = Counter(r['category'] for r in inventory)
    assert categories['dependencies'] == summary['dependency_only'] == 17
    assert len(inventory) - categories['dependencies'] == summary['current_semantic'] == 2358
    assert sum(categories[x] for x in ('strict_baseline', 'source_repair')) == summary['strict_after_repairs'] == 2183
    ruling = repaired['TFgw4IaR9R8s_1639']['result']['compilation']
    assert ruling['metadata']['ancestor_bindings_preserved'] == [ruling['metadata']['node_variables']['r']]
    assert any(s['kind'] == 'condition' for s in ruling['metadata']['scopes'].values())
    duplicate = [repaired[c]['text'] for c in ('TQEmEycTI0RQ_871', 'TFgw4IaR9R8s_1730')]
    assert duplicate[0] == duplicate[1]

    contrast = read(RUN / 'binding_contrasts.json')
    for pair in contrast['pairs']:
        original, swapped = pair['examples']
        assert original['bindings'][0][0] == swapped['bindings'][0][0]
        assert [b[1] for b in original['bindings']] == [b[1] for b in swapped['bindings']][::-1]
        def bag(text):
            return Counter(re.findall(r'\w+|[^\w\s]', text.casefold()))
        assert bag(original['claim']) == bag(swapped['claim'])
        for example in pair['examples']:
            assert example['logic_control'][example['label']] == 1.0
    assert set(contrast['groups']['development']).isdisjoint(contrast['groups']['reserved'])
    dump(RUN / 'test_inventory.json', inventory)
    dump(RUN / 'validation.json', dict(
        original_claims=len(inventory), strict_programs=2183, provisional_semantic_programs=175,
        recovered_grounded_programs=len(repaired), previous_selections_preserved=len(inventory) - len(repaired),
        dependency_analyses=17, reviewed_programs=len(reviewed['reviews']), checked_ruling_binding=True,
        paired_logic_controls=2 * len(contrast['pairs']), source_disjoint=True,
        frozen_feature_extractions=0, status='passed',
    ))
    print('Verified 2,375 outcomes, four grounded additions, 32 hash-linked reviews and ten logic controls.')


if __name__ == '__main__':
    main()
