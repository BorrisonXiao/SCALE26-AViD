"""Package the coverage experiment with the exact cached inputs it reads."""
import hashlib
import json
import zipfile
from pathlib import Path

from prepare_compiler_fallback import rows, BASE as AMR
from run_compiler_coverage import RUN, ROOT, STRICT, INPUTS


def jsonl(values):
    return ''.join(json.dumps(r, ensure_ascii=False, separators=(',', ':')) + '\n' for r in values).encode()


def main():
    names = set(json.loads((STRICT / 'compiler_freeze.json').read_text()))
    for folder, pattern in [('scripts', '*.py'), ('scripts/probabilistic_verification', '*.py'),
                            ('scripts/probabilistic_verification/resources', '*.json'),
                            ('scripts/report_assets', '*')]:
        names.update(str(p.relative_to(ROOT)) for p in (ROOT / folder).glob(pattern) if p.is_file())
    extra = [INPUTS, STRICT / 'compiler_freeze.json', ROOT / 'docs/compiler_coverage_20261118.md',
             ROOT / 'tests/test_compiler_coverage.py',
             *(RUN / name for name in ('summary.json', 'audit.json', 'validation.json', 'tests.xml',
                                       'checked_forms.json', 'test_inventory.json', 'initial_summary.json',
                                       'coordination_summary.json', 'reentrancy_summary.json',
                                       'sentence_mode_summary.json', 'earlier_srl_summary.json'))]
    names.update(str(p.relative_to(ROOT)) for p in extra)
    data = {name: (ROOT / name).read_bytes() for name in names}
    previous = rows(STRICT / 'corpus.jsonl')
    failures = {row['claim_id'] for row in previous if row['parsing_status'] != 'compiled'}
    prior_reviews = [{k: row[k] for k in ('claim_id', 'review')}
                     for row in json.loads((STRICT / 'reviewed_additions.json').read_text())]
    reviewed = {row['claim_id'] for row in prior_reviews
                if row['review']['whole_reading'] == 'matches_reference'}
    compact_previous = []
    for row in previous:
        if row['claim_id'] in failures:
            compact_previous.append(row)
            continue
        output = row['output']
        if row['claim_id'] not in reviewed:
            output = dict(program_sha256=output['program_sha256'],
                          compilation={'metadata': {'scopes': output['compilation']['metadata'].get('scopes', {})}})
        compact_previous.append(dict(row, attempts=[], output=output))
    data[str((STRICT / 'corpus.jsonl').relative_to(ROOT))] = jsonl(compact_previous)
    data[str((STRICT / 'reviewed_additions.json').relative_to(ROOT))] = json.dumps(prior_reviews).encode()
    external = json.loads((STRICT / 'external_cases.json').read_text())
    data[str((STRICT / 'external_cases.json').relative_to(ROOT))] = json.dumps([
        dict(claim_id=r['claim_id'], text=r['text'], fallback={'output': r['fallback'].get('output')})
        for r in external
    ]).encode()
    data[str((AMR / 'corpus.jsonl').relative_to(ROOT))] = jsonl(
        dict(claim_id=r['claim_id'], raw=r['raw'])
        for r in rows(AMR / 'corpus.jsonl') if r['claim_id'] in failures
    )
    expected = {name: hashlib.sha256((RUN / name).read_bytes()).hexdigest()
                for name in ('corpus.jsonl', 'summary.json', 'audit.json', 'validation.json',
                             'checked_forms.json', 'test_inventory.json')}
    data['REPLAY_SHA256.json'] = json.dumps(expected, indent=2).encode()
    data['README.md'] = (ROOT / 'docs/compiler_coverage_20261118.md').read_bytes()
    dest = ROOT / 'site/reports/compiler-demos/coverage-20261118/source.zip'
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in sorted(data.items()):
            entry = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, content)
    print(f'{len(data)} files, {dest.stat().st_size / 2**20:.2f} MiB')


if __name__ == '__main__':
    main()
