"""Full cached corpus and a separately frozen external text-only evaluation."""
from collections import Counter
import hashlib
import json
import logging
from pathlib import Path
import time

from run_amr_types import inspect, canonical_meaning
from probabilistic_verification.amr_contexts import compile_contextual, prepare_contextual

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/amr_contexts_20261118'
BASE=ROOT/'exp/probabilistic_verification/amr_types_20261115'


def rows(path):
    return [json.loads(s) for s in path.read_text().splitlines() if s.strip()]


def dump(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')


def evaluate(record,raw):
    return inspect(record,raw,compiler=compile_contextual,prepare=prepare_contextual)


def verify_freeze():
    frozen=json.loads((RUN/'compiler_freeze.json').read_text())
    for name,digest in frozen.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name


def corpus():
    verify_freeze()
    inputs=rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')
    old={r['claim_id']:r for r in rows(BASE/'corpus.jsonl')};start=time.perf_counter()
    outputs=[evaluate(r,old[r['claim_id']]['raw']) for r in inputs]
    (RUN/'corpus.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in outputs))
    summary=dict(total=len(outputs),generated=sum('program'in r for r in outputs),passing=sum(r['status']=='compiled'for r in outputs),
                 previous_generated=1785,previous_passing=1559,
                 gained=[r['claim_id']for r in outputs if r['status']=='compiled'and old[r['claim_id']]['status']!='compiled'],
                 lost=[r['claim_id']for r in outputs if r['status']!='compiled'and old[r['claim_id']]['status']=='compiled'],
                 generation_lost=[r['claim_id']for r in outputs if'program'not in r and'program'in old[r['claim_id']]],
                 changed_programs=sum(r.get('program_sha256')!=old[r['claim_id']].get('program_sha256')for r in outputs),
                 graph_refusals=dict(Counter(r['errors'][-1]['code']for r in outputs if'program'not in r)),
                 converted_flags=dict(Counter(e['code']for r in outputs if'program'in r for e in r['errors'])),
                 seconds=time.perf_counter()-start,retained_pool=1981,promotions=0)
    dump(RUN/'summary.json',summary)
    dump(RUN/'changes.json',[dict(claim_id=r['claim_id'],text=r['text'],before=old[r['claim_id']]['status'],after=r['status'],errors=r['errors'])for r in outputs if r.get('program_sha256')!=old[r['claim_id']].get('program_sha256')or r['status']!=old[r['claim_id']]['status']])
    print(json.dumps({k:len(v)if isinstance(v,list)else v for k,v in summary.items()},indent=2),flush=True)


def external():
    verify_freeze()
    refs=RUN/'external_references.json';manifest=json.loads((RUN/'external_reference_manifest.json').read_text())
    assert hashlib.sha256(refs.read_bytes()).hexdigest()==manifest['sha256']
    graphs={r['request']['task']['claim_id']:r for r in rows(RUN/'external_amr_raw.jsonl')}
    inputs=rows(RUN/'external_inputs.jsonl');assert len(graphs)==len(inputs)==20
    from run_amr_types import inspect as before_inspect
    results=[dict(claim_id=r['claim_id'],text=r['text'],source_url=r['source_url'],
                  before=before_inspect(r,graphs[r['claim_id']]['raw']),
                  after=evaluate(r,graphs[r['claim_id']]['raw']))for r in inputs]
    dump(RUN/'external_outputs.json',results)
    print('Completed 20 frozen external evaluations; no truth labels or media.',flush=True)


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--external',action='store_true');args=p.parse_args()
    logging.getLogger('penman').setLevel(logging.ERROR)
    external()if args.external else corpus()
