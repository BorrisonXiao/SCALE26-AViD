"""Audit every fallback addition; never use reviews in runtime routing."""
from collections import Counter
import json
from prepare_compiler_fallback import ROOT,RUN,BASE,rows,dump

def same_meaning(a,b):
    ca=a.get('compilation');cb=b.get('compilation')
    return bool(ca and cb and ca['logical_form']==cb['logical_form']and [(v['kind'],v['description'])for v in ca['variables']]==[(v['kind'],v['description'])for v in cb['variables']]and ca['metadata'].get('allowed_routes')==cb['metadata'].get('allowed_routes'))

def prepare():
    baseline={r['claim_id']:r for r in json.loads((RUN/'audit_inputs.json').read_text())}
    old_reviews={r['claim_id']:r['review']for r in json.loads((RUN/'baseline_reviews.json').read_text())}
    outputs=rows(RUN/'corpus.jsonl');pending=[];reused={}
    for r in outputs:
        if r['selected_stage']!='amr':continue
        cid=r['claim_id'];old=baseline.get(cid)
        if old and same_meaning(r['output'],old['amr']):reused[cid]=old_reviews[cid]
        else:pending.append(r)
    rewrites=[r for r in outputs if r['selected_stage']=='rewrite']
    dump(RUN/'review_routing.json',dict(amr_pending=[r['claim_id']for r in pending],amr_reused=list(reused),rewrites_pending=[r['claim_id']for r in rewrites]))
    dump(RUN/'changed_amr_cases.json',pending);dump(RUN/'rewrite_cases.json',rewrites)
    print('Selected AMR fresh',len(pending),'reused',len(reused),'rewrite fresh',len(rewrites))

def summarize():
    baseline={r['claim_id']:r for r in json.loads((RUN/'audit_inputs.json').read_text())};reviews={r['claim_id']:r['review']for r in json.loads((RUN/'baseline_reviews.json').read_text())}
    final=json.loads((RUN/'final_reviews.json').read_text());outputs=rows(RUN/'corpus.jsonl');shown=[]
    for r in outputs:
        if r['selected_stage']not in{'amr','rewrite'}:continue
        cid=r['claim_id']
        if cid in final:review=final[cid]
        else:
            assert r['selected_stage']=='amr'and cid in baseline and same_meaning(r['output'],baseline[cid]['amr']),cid
            review=dict(reviews[cid],provenance='Baseline audit reused only for identical logical conditions, variable kinds and allowed routes.')
        shown.append(dict(claim_id=cid,text=r['text'],selected_stage=r['selected_stage'],review=review,output=r['output'],attempts=r['attempts'],baseline=baseline.get(cid),baseline_review=reviews.get(cid)))
    dump(RUN/'reviewed_additions.json',shown)
    stats=json.loads((RUN/'summary.json').read_text())
    stats['baseline_audit']=dict(total=183,whole_readings=dict(Counter(r['whole_reading']for r in reviews.values())),fresh=145,reused=38)
    stats['addition_reviews']={stage:dict(total=sum(r['selected_stage']==stage for r in shown),whole_readings=dict(Counter(r['review']['whole_reading']for r in shown if r['selected_stage']==stage)))for stage in ['amr','rewrite']}
    stats['meaning_review_limit']='Implementing-assistant development audit. Existing SRL passes are not fully reviewed; no end-to-end semantic accuracy or new human approval.'
    external=json.loads((RUN/'external_outputs.json').read_text());extrev=json.loads((RUN/'external_reviews.json').read_text());ext=[]
    for r in external:
        r['reviews']=extrev[r['claim_id']];ext.append(r)
    dump(RUN/'external_cases.json',ext)
    estats=json.loads((RUN/'external_summary.json').read_text());estats['meaning_reviews']={method:dict(Counter(r['reviews'][method]['whole_reading']for r in ext))for method in ['srl','amr','fallback']};dump(RUN/'external_summary.json',estats)
    stats['external']=estats;dump(RUN/'summary.json',stats)
    print(json.dumps(dict(additions=stats['addition_reviews'],external=estats),indent=2))
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--summarize',action='store_true');a=p.parse_args();summarize()if a.summarize else prepare()
