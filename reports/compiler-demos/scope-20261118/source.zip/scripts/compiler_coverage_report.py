"""Coverage comparison and browsable traces for the existing compiler report."""
import json
from html import escape

from compiler_fallback_report import table
from run_compiler_coverage import RUN, ROOT, rows

URL = 'compiler-demos/coverage-20261118/'
LABELS = {
    'source_repair': 'Source repair passes checks',
    'advisory_checks': 'Earlier program with warnings',
    'source_repair_with_warnings': 'Source repair with warnings',
    'amr_unresolved_complement': 'AMR with unresolved clause scope',
    'amr_annotated_coordination': 'AMR with explicit coordination',
    'amr_reentrancy': 'AMR with additional scope and reference handling',
    'earlier_srl': 'Earlier SRL conversion with warnings',
    'dependencies': 'Dependency analysis only',
    'no_program': 'No program',
}


def load(name):
    return json.loads((RUN / name).read_text())


def numbers(count, total):
    return f'{count:,}/{total:,} ({100 * count / total:.2f}%)'


def status_html():
    stats = load('summary.json')
    return (f'<b>{numbers(stats["semantic_programs"], stats["total"])} produce semantic programs with '
            f'advisory checks.</b> {stats["strict_after_repairs"]:,} pass the compiler checks in this '
            'comparison. Dependency analyses are available for additional claims.')


def overview_html():
    stats = load('summary.json')
    total = stats['total']
    strict = stats['strict_after_repairs']
    semantic = stats['semantic_programs']
    source_only = stats['programs_including_dependencies'] - semantic
    h = ('<h2 id="remaining-failures">Compilation coverage with advisory checks</h2><p>'
         + status_html() + '</p><p>Source checks become warnings for a coverage experiment. '
         'A program must still have linked predicates and load in ProbLog. The earlier '
         'strict sequence supplies the starting point on the same 2,375 originals. '
         'Warnings stay attached to the outputs and all provisional forms require review before use.</p>')
    h += table('All 2,375 original claims appear in each row of this comparison.',
               ['Condition', 'Programs', 'Cases without this level of output'], [
                   ('Previous strict compiler', numbers(stats['strict_baseline'], total), total - stats['strict_baseline']),
                   ('Allow earlier flagged programs', numbers(stats['advisory_only_ablation'], total), total - stats['advisory_only_ablation']),
                   ('Programs passing checks after targeted source repairs', numbers(strict, total), total - strict),
                   ('Semantic programs including provisional SRL/AMR', numbers(semantic, total), total - semantic),
                   ('Also include source dependency analyses', numbers(semantic + source_only, total), stats['no_program']),
               ])
    h += '<p>The 99% semantic compilation target requires 2,352 programs. '
    if semantic >= 2352:
        h += f'This run clears it by {semantic - 2352} programs.</p>'
    else:
        h += f'This run is {2352 - semantic} programs short.</p>'
    h += ('<p>SRL means semantic role labeling. AMR means Abstract Meaning Representation. '
          'A semantic program retains predicate and argument conditions. Some AMR clauses retain their '
          'parent and role while leaving the exact scope unresolved. The dependency form records grammatical '
          'links such as subject and object, which still need semantic interpretation. The last row includes those forms.</p>')
    h += table('Outcomes for the 198 previous parsing abstentions.',
               ['Selected result', 'Claims'], [
                   (name, stats['categories'].get(key, 0))
                   for key, name in LABELS.items()
               ])
    h += ('<p><a href="#coverage-examples">See repairs and failure patterns</a> · '
          '<a href="#coverage-cases">Inspect all 198 changed or unresolved cases</a> · '
          '<a href="#strict-fallback-overview">See the earlier strict comparison</a> · '
          '<a href="verification-pipeline.html#next-steps">Project checklist</a>.</p>')
    return h


def examples_html():
    review = load('audit.json')
    h = ('<section id="coverage-examples"><h2>What the extra programs preserve</h2>'
         '<p>These development examples show where the changes recover a relationship and where a valid program '
         'still leaves the meaning incomplete. All selected forms retain their actual stage and source checks.</p>')
    for row in review['examples']:
        h += (f'<article class="box"><h3>{escape(row["title"])}</h3>'
              f'<blockquote>{escape(row["text"])}</blockquote><p>{escape(row["finding"])}</p>'
              f'<p><a href="?coverage_claim={escape(row["claim_id"])}#coverage-cases">Inspect the saved form</a>.</p></article>')
    checks = review['request_check']
    h += ('<p>The advisory request check flags '
          f'{len(checks["corpus_alerts"])} earlier selections in the corpus and '
          f'{len(checks["external_alerts"])} in the existing external diagnostic. '
          'It catches the boycott example: the selected SRL form misses a request context. '
          'The check leaves parser selection as recorded.</p>')
    stats = load('summary.json')
    h += '<h3>Remaining semantic compilation failures</h3>'
    h += table('Last AMR obstacle before the dependency analysis. One code per case.',
               ['Last obstacle', 'Claims'],
               [(escape(k.replace('_', ' ')), v) for k, v in stats['unresolved_semantic'].items()])
    h += ('<p>Current programs often preserve difficult language without settling what it means. '
          'Priority examples include nested negation, clause or group attachments around OR, and '
          'ambiguous AMR event references. The test denominator includes every claim.</p>'
          f'<p>The preparation export contains {review["checked_forms"]} exact development forms '
          f'from {review["checked_source_groups"]} source groups. The automatic test inventory includes '
          'every claim, and the reviewed forms still need evidence labels before binding training.</p>'
          '<h3>Next steps</h3><ol>'
          '<li>Resolve references across nested scopes and bind conditions to the right OR branch to recover the remaining semantic programs.</li>'
          '<li>Review provisional programs by source group and construction to measure how often warnings flag real meaning errors.</li>'
          '<li>Prepare evidence-labeled binding contrasts on a source-disjoint set to test the learned relations.</li></ol>'
          '<h3>Review and replay</h3><p>'
          + ' · '.join(f'<a href="{URL}{path}">{label}</a>' for path, label in [
              ('source.zip', 'Source and saved inputs'), ('summary.json', 'Full counts'),
              ('audit.json', 'Self-review with diagnoses'), ('tests.xml', 'Tests'),
              ('validation.json', 'Native checks and replay hashes'),
              ('checked_forms.json', 'Checked forms with source groups'),
              ('test_inventory.json', 'All 2,375 automatic test inputs'),
          ]) + '</p></section>')
    return h


def inspector_html():
    return '''
<section id="coverage-cases">
<h2>Coverage experiment on the 198 earlier abstentions</h2>
<p>Choose a claim to read the selected conditions and every attempted repair. The full strict viewer below
also includes passing inputs and the original rewrite requests.</p>
<label for="coverage-filter">Outcome</label>
<select id="coverage-filter"><option value="all">All 198 claims</option></select>
<label for="coverage-case">Claim</label><select id="coverage-case"></select>
<blockquote id="coverage-text"></blockquote><p class="note" id="coverage-status" role="status"></p>
<p id="coverage-review"></p>
<h3>Selected conditions</h3><div id="coverage-conditions"></div>
<h3>Attempted stages</h3><ol id="coverage-attempts"></ol>
<details><summary>Exact logical form and ProbLog program</summary><pre id="coverage-exact"></pre></details>
<p><a id="coverage-strict" href="#fallback-inspector">Open the earlier strict trace</a></p>
</section>
'''


def write_downloads():
    import shutil

    target = ROOT / 'site/reports' / URL
    target.mkdir(parents=True, exist_ok=True)
    for name in ['summary.json', 'audit.json', 'tests.xml', 'validation.json',
                 'checked_forms.json', 'test_inventory.json']:
        if (RUN / name).exists():
            shutil.copy2(RUN / name, target / name)
    audit = load('audit.json')
    review = {r['claim_id']: r['diagnosis'] for r in audit['remaining']}
    review.update({r['claim_id']: r['finding'] for r in audit['examples']})
    data = []
    for row in rows(RUN / 'corpus.jsonl'):
        if row['category'] == 'strict_baseline':
            continue
        output = row.get('output', {})
        compilation = output.get('compilation')
        item = {k: row[k] for k in ('claim_id', 'text', 'category', 'chosen_stage')}
        item['review'] = review.get(row['claim_id'])
        item['label'] = LABELS[row['category']]
        item['alerts'] = [{k: a.get(k) for k in ('stage', 'status', 'code', 'reason', 'errors', 'shared_checks')}
                          for a in [*row['baseline_attempts'], *row['attempts']]]
        item['compilation'] = compilation
        item['program'] = output.get('program')
        item['selected_warnings'] = output.get('shared_checks', [])
        data.append(item)
    (target / 'cases.json').write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')) + '\n')
