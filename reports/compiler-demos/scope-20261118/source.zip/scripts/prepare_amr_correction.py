"""Paths and frozen original-text readings for the bounded AMR correction trial."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/amr_correction_20261114'
BASE=ROOT/'exp/probabilistic_verification/amr_refinement_20261114'
def rows(p):return list(map(json.loads,p.read_text().splitlines()))
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

READINGS=[
('The2021 map depicts more Bloc Québécois seats, associated with blue, and comparatively less red. Preserve the comparative reading; not as much red does not mean no red.','The comparison baseline and red party identity are not explicit.'),
('SCOTUS is skeptical of the administration tendency to describe things as an attack, emergency, incursion or rebellion. Preserve skepticism and description scope; do not assert the described events as real attacks.','Everything is an overgeneralised reported tendency, not a list of actual events.'),
('Scientists use complex manufacturing tools for the purpose of building the spacecraft. Scientists are tool users and intended builders; complex modifies tools.','Do not assert completion of the spacecraft.'),
('The birthday of the son of the Phillies fan is almost here. Preserve son-of-fan possession and almost timing.','The fragment does not supply a date or name; do not invent them.'),
('People surround the robot and wait to watch what the robot can do. The people are watchers; the robot is the performer of the possible actions.','The actions are unspecified and not asserted to occur.'),
('A Mexico City security chief reports20arrests for theft and assault. Keep source attribution, count and alleged crimes inside the report.','No exact speaker name or speech/audio route is given; quoted wording is an attribution.'),
('Shi Yongxin led warrior monks on tours whose purpose was performing Kung Fu abroad. Preserve the leader, monks, tours, performance purpose and foreign location.','Do not silently turn a performance purpose into a completed performance.'),
('The video depicts a scene on a large open paved pier or terminal area. Keep the location alternative and its modifiers in depicted content.','Pier versus terminal area remains an alternative; no actual video-as-physical-location reading.'),
('The phone signal belonging to Rinderknecht was attested seconds after the flames erupted. Preserve the attestation and relative time between it and eruption.','No precise number of seconds or attester is stated.'),
('The tram driver accidentally requested a rightward switch at an intersection, although the tram needs to continue straight. Preserve the accidental request, opposite directions and requirement scope.','The requested switch need not have happened.'),
('Flow speed over central Texas increased overnight on the3rd into the4th, from10–20knots to25–30knots. Preserve both ranges, speed unit, increase, time span and location.','Knots of flow is awkward wording; do not invent a month, year or measured object.'),
('Closer footage depicts a government building on fire, with spectators watching and filming. Preserve depiction, building type, fire state and both spectator activities.','The comparison for closer and object of filming are implicit.'),
('The area that experienced violent shaking is heavily populated. Preserve past shaking in that same area and the present population condition.','Violent modifies shaking; heavily modifies populated.'),
('Commenters ask whether anyone is missing, and it is unclear whether anyone is. Preserve the question and uncertainty rather than asserting a missing person.','The pronoun/ellipsis is resolved only to the missing-person question, not a specific person.'),
('Keeping the port open was the goal of the recovery operation. Preserve purpose and continuing open state, without asserting goal achievement.','No named port or time is supplied.'),
('A flight-test fragment names Staship and gives T-13 until liftoff. Preserve the supplied spelling and countdown without guessing units.','Staship may be a typo; the source does not license silently replacing it. T-13 field units are unspecified.'),
('The claim describes what driving into a haboob is like. Preserve driving, entering direction and the haboob; do not invent a named driver or particular completed trip.','This is is deictic and may refer to depicted footage; the fragment alone does not resolve it.'),
('Multiple additional police officers near the police van are helping and clearing space. Preserve plurality, additional status, immediate location and shared officers across both activities.','The recipient of help is unspecified.'),
('An explosion of fireworks is heard. Preserve sound support and fireworks as the source of the explosions.','Do not require visual depiction or a stated count.'),
('Carney may have difficulty; Carney is slightly right of Trudeau, NDP is left of Liberals, and the outcome depends on the new NDP leader. Preserve possibility, political-position comparisons and dependence.','The political-position sense is strongly suggested; no particular election outcome is asserted.'),
('A pause on a ruling will restore the earlier conditions, explained as permitting tariffs to resume as before. Preserve the future/conditional prediction and permission, rather than asserting a present resumption.','The text marks the tariff explanation as an inference.'),
('A picture depicts a voter-information page with district finding, a map/profile, postal-code entry plus Go search, and an alternative link to find a district without a postal code. Preserve the depicted interface, alternatives and capability rather than asserting actual user actions.','The example list is open-ended; do not invent user identity or results.'),
('Reported Peterborough riding results put Liberal Emma Harrison first with2740votes, Conservative Michelle Ferreri next with1932and an increasing tally, and NDP Heather Ray with137. Preserve every party/name/count binding and reported ranking.','These are reported partial results, not certified final vote totals.'),
('With96percent counted, the projected seat figures are Liberals48.1percent/166seats and Conservatives42.9percent/146seats, from343total. Preserve each percentage/count/party binding and projection scope.','The supplied percentages/counts need not be arithmetically reconciled; do not change the source numbers.')]

def freeze_readings():
 records=rows(RUN/'followup_inputs.jsonl');assert len(records)==len(READINGS)==24
 refs=[dict(claim_id=r['claim_id'],text=r['text'],meaning=m,ambiguity=a,origin='Assistant original-text reading frozen before new checks/correction outputs; no independent gold.')for r,(m,a)in zip(records,READINGS)]
 p=RUN/'followup_references.json';assert not p.exists(),'Never overwrite frozen readings.';dump(p,refs)
 dump(RUN/'reference_manifest.json',dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),policy='Frozen before new semantic-check or model outputs; same project videos, not new-source test.'))
if __name__=='__main__':freeze_readings()
