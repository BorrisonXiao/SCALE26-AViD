"""Record a claim-by-claim inspection of the frozen provisional sample."""
import json
from collections import Counter, defaultdict

from run_compiler_scope_repairs import RUN, COVERAGE, INPUTS, rows, dump
from probabilistic_verification.compiler_scope_repairs import explicit_or_warning

# Each judgment is tied to the exact claim ID and reviewed compiled program hash.
REVIEWS = {
    'Txf2EdqOg1SQ_2166': ('incorrect', 'coordination',
        'Pier and terminal area become two group members instead of alternative locations. “Takes place” is also broken into take and place.'),
    'TQEmEycTI0RQ_935': ('incorrect', 'numeric binding',
        'The form drops several percentages and the Quebec qualifier. It treats Trudeau as the subject of a visual show event.'),
    'TW4OYA3RN-Hw_1812': ('partial', 'source routing',
        'The form links chants, singing and the same unknown language to the timestamp. It does not route the sounds to audio, and annotates language uncertainty twice.'),
    'TFgw4IaR9R8s_1569': ('incorrect', 'reported scope',
        'The two local negations survive, but the opinion is a relation to a group of predicates. The content no longer sits under an opinion context.'),
    'TgR_u37mCoQ4_1976': ('partial', 'participant binding',
        'The man and blue blazer are linked. The alternatives remain under the coordination associated with presumption, but neither branch explicitly classifies that same wearer.'),
    'TgPh_fzHTCm4_1513': ('partial', 'participant binding',
        'Most wind directions and the ridge remain. The northerly-flow item attaches through an op3 relation outside the other wind descriptions, and the ridge-side link is reversed.'),
    'TjHepwuhkYFA_1070': ('incorrect', 'qualification',
        'The fall stays in depiction, but Bangkok becomes a depicted location and “inferred” is represented by a separate refer event.'),
    'TInVWzp25aIM_12': ('partial', 'reference binding',
        'The truth-value proposition represents the question. The same variable is locally rebound within the negated clarity clause, weakening the identity link.'),
    'T2G_ACMxR_I4_1467': ('matches_reference', 'quantity warning',
        'Two people are linked to the high-five and the reaction, with the landing as its target. The numerical warning fires even though quantity two is present.'),
    'TQEmEycTI0RQ_976': ('partial', 'numeric binding',
        'The candidates and counts appear, but the first count becomes a cause of leading and the counts of the other two participants have uneven bindings.'),
    'TFgw4IaR9R8s_1713': ('partial', 'reference binding',
        'The size, count, yellow +5 and top-right location appear. The antecedent of “them” and the relation between the +5 label and the dots remain unresolved.'),
    'Txf2EdqOg1SQ_2316': ('partial', 'qualification',
        'Rain, wind and landfall stay inside the likely-holder context. The graph reverses the part-of relation between the coast and Guangdong.'),
    'TgR_u37mCoQ4_1889': ('incorrect', 'negation',
        'The graph puts the fire touch and broad causal description under one negation. The possible protection relation also appears as a positive world condition.'),
    'TLO3smKI67PM_556': ('incorrect', 'entity identity',
        'The graph uses Phillips in place of Phillies and introduces a separate running event for the baseball noun phrase “home run.”'),
    'TFOEIehBwT8Q_530': ('partial', 'reported scope',
        'The lady and exiled group are linked to criticism. Not standing up appears in nested content, with the reason for criticism left as an unresolved argument.'),
    'TzzhcBIczf_M_2058': ('incorrect', 'qualification',
        'The reporter and Abbot roles survive, but “would” is missing. A future-in-the-past request becomes an unqualified request inside the report.'),
    'T2EE72iNELEs_181': ('incorrect', 'numeric binding',
        'T-13 becomes an aircraft type and the same aircraft is the participant in lifting. It is a countdown offset relative to liftoff.'),
    'TzF9M4kZ3Pys_284': ('incorrect', 'entity identity',
        'The dust storm is turned into a car make named Hambob and incorrectly occupies a core argument of driving.'),
    'TjHepwuhkYFA_1021': ('partial', 'negation',
        'The program retains negation and separates music from original sound. Completeness of the audio inventory and the contrast with overlaid music are underspecified.'),
    'TzzhcBIczf_M_2029': ('partial', 'purpose',
        'The monks tour and perform abroad within a complement. The graph leaves the performance as an unresolved complement instead of the purpose of the tour.'),
    'Tg0UxWYuPeJ0_421': ('incorrect', 'numeric binding',
        '100m is interpreted as 100 million participants instead of the distance of the race.'),
    'TbJqMFkNxARY_161': ('incorrect', 'condition scope',
        'The absence and the timing proposition both appear, but there is no implication relating them. The source allows a tentative conclusion from absence.'),
    'TMrQshDs8aH0_733': ('partial', 'condition scope',
        'Negation survives on the two clauses, while the causal link expressed by “so” and the temporal attachment of “currently” remain unrepresented.'),
    'T3HTSBW42QaY_779': ('partial', 'literal content',
        'Large boat, reminder and safety are linked. “First” and the complete safety-first content are missing.'),
    'T2G_ACMxR_I4_1234': ('incorrect', 'participant binding',
        'The form keeps both purposes but loses the lander as the object to keep cool. “Off” becomes a direction and the paired cycling states are lost.'),
    'TFOEIehBwT8Q_495': ('incorrect', 'literal content',
        'The program retains Mexico alone and drops the date. The input is a quoted fragment that also needs its carrier or another source context.'),
    'Tg0UxWYuPeJ0_342': ('incorrect', 'purpose',
        'The two robots are retained, but signaling collapses into a give event and sparring is also asserted separately. The source gives a signal to start, without asserting the robots start.'),
    'TW4OYA3RN-Hw_1800': ('incorrect', 'numeric binding',
        'The one room becomes an isolated referent called “1.” Exclusivity and the links between they, them and the rooms are missing.'),
    'TgPh_fzHTCm4_1471': ('partial', 'omission',
        'Both speed ranges, their order and the overnight timing are preserved. Central Texas is missing.'),
    'TInVWzp25aIM_68': ('incorrect', 'participant binding',
        'Portable is modeled as a participant in charge. It should describe the charger used by Angupaul1.'),
    'TLO3smKI67PM_580': ('incorrect', 'entity identity',
        'The baseball team becomes Phillipines. The birthday and almost modifier survive, but the family link refers to the wrong fan.'),
    'TQEmEycTI0RQ_827': ('incorrect', 'numeric binding',
        'The map date is encoded as February 2002 instead of 2021, and the party-status change is underspecified.'),
}

REPAIRS = {
    'TQEmEycTI0RQ_871': ('partial', 'All three voting branches share one actor. The condition is limited to the ballot branch. The graph still expresses Canadians indirectly and leaves the time of more information under-specified.'),
    'TFgw4IaR9R8s_1730': ('partial', 'Same text and repaired scope as the other voting-method row. This is one construction represented by two claim IDs.'),
    'TFgw4IaR9R8s_1586': ('matches_reference', 'The image contains the signing. “Likely executive orders” qualifies that same signed object and does not require the depicted signing to be only likely.'),
    'TFgw4IaR9R8s_1639': ('partial', 'The same ruling is the introduced referent and object of overturn inside the unless clause. The form keeps the Congress trip under a requirement and setting tariffs as its purpose. Future timing and the Administration identity still need review.'),
}


def main():
    selected = json.loads((RUN / 'sample.json').read_text())
    population = rows(COVERAGE / 'corpus.jsonl')
    inputs = {r['claim_id']: r for r in rows(INPUTS)}
    sample = selected['sample']
    assert {row['claim_id'] for row in sample} == REVIEWS.keys()
    by_stage = defaultdict(Counter)
    warnings_split = defaultdict(Counter)
    values = []
    for row in sample:
        cid = row['claim_id']
        outcome, category, note = REVIEWS[cid]
        output = row['output']
        flagged = bool(output.get('code') or output.get('errors') or output.get('shared_checks'))
        warning = explicit_or_warning(inputs[cid], output['compilation'])
        by_stage[row['category']][outcome] += 1
        warnings_split['existing warning' if flagged else 'no existing warning'][outcome] += 1
        values.append(dict(claim_id=cid, text=row['text'], source_videos=row['source_videos'],
                           stage=row['stage'], category=row['category'], judgment=outcome,
                           issue=category, reason=note, explicit_or_warning=warning,
                           existing_warning=flagged, program_sha256=output['program_sha256']))
    repairs = json.loads((RUN / 'repairs.json').read_text())
    assert {r['claim_id'] for r in repairs if r['after'] == 'semantic_program'} == REPAIRS.keys()
    for row in repairs:
        if row['claim_id'] in REPAIRS:
            row['judgment'], row['reason'] = REPAIRS[row['claim_id']]
    warnings = [r['claim_id'] for r in population if r['category'] in selected['quotas']
                and explicit_or_warning(inputs[r['claim_id']], r['output']['compilation'])]
    dump(RUN / 'fidelity.json', dict(
        sample_size=len(values), source_groups=selected['source_groups'],
        categories=dict(Counter(r['judgment'] for r in values)), by_stage=dict(by_stage),
        existing_warning=dict(warnings_split), issue_counts=dict(Counter(r['issue'] for r in values)),
        provisional_population=sum(selected['population'].values()),
        explicit_or_alerts=warnings, sample_alerts=[r['claim_id'] for r in values if r['explicit_or_warning']],
        reviews=values, repairs=repairs,
        policy='Stratified development sample, one priority per source group. No corpus semantic-accuracy estimate.',
    ))
    print('Judgments', Counter(r['judgment'] for r in values), 'source groups', selected['source_groups'])
    print('Existing warnings', dict(warnings_split))
    print('Explicit OR warning', len(warnings), 'in provisional population.')


if __name__ == '__main__':
    main()
