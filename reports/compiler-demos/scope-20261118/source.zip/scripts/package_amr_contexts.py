"""Source/data overlay for the context and historical count experiment."""
import hashlib,json,zipfile
from run_amr_contexts import ROOT,RUN,dump

def main():
    names=set()
    for folder,pattern in [('scripts','*.py'),('scripts/probabilistic_verification','*.py'),('scripts/probabilistic_verification/resources','*.json'),('scripts/report_assets','*'),('tests','*.py'),('tests/fixtures','*.json'),('docs/project_notes','*')]:
        names.update(str(p.relative_to(ROOT))for p in (ROOT/folder).glob(pattern)if p.is_file())
    names.update(['AGENTS.md','CLAUDE.md','docs/amr_contexts_20261118.md','exp/probabilistic_verification/av_features_20261022/checklist.json'])
    excluded={'source_manifest.json','archive_verification.json','browser_checks.json','publication.json'}
    names.update(str(p.relative_to(ROOT))for p in RUN.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.name not in excluded and p.suffix in{'.py','.json','.jsonl','.xml','.md','.txt','.log','.sha256'})
    needed=['amr_types_20261115/corpus.jsonl','amr_types_20261115/reviewed_cases.json','amr_types_20261115/additional_reviews.json','amr_types_20261115/additional_gains.json',
            'amr_correction_20261114/legacy_regression.json','amr_correction_20261114/corpus.jsonl','amr_refinement_20261114/reviewed_cases.json','amr_composition_20261114/corpus.jsonl',
            'content_relations_20261105/inputs.jsonl','content_relations_20261105/results.jsonl','compiler_revision_20261105/results.jsonl','scope_coverage_20261105/results.jsonl',
            'rewrite_all_20261112/inputs.jsonl','rewrite_all_20261112/parsed.jsonl','compiler_structural_20261113/direct_all.jsonl','compiler_structural_20261113/cached_pipeline.jsonl','compiler_structural_20261113/corpus_reviewed.jsonl']
    needed+=['full_compilation_20261029/amr_'+str(i)+'_raw.jsonl'for i in range(4)]
    names.update('exp/probabilistic_verification/'+n for n in needed)
    preserved=json.loads((RUN/'preserved_files.json').read_text());assert len(preserved)==61
    for name,digest in preserved.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    data={n:(ROOT/n).read_bytes()for n in sorted(names)}
    dump(RUN/'source_manifest.json',{n:hashlib.sha256(b).hexdigest()for n,b in data.items()})
    data[str((RUN/'source_manifest.json').relative_to(ROOT))]=(RUN/'source_manifest.json').read_bytes()
    data['README_AMR_CONTEXTS.md']=(ROOT/'docs/amr_contexts_20261118.md').read_bytes()
    data['AMR_CONTEXTS_SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+n+'\n'for n,b in sorted(data.items())).encode()
    target=ROOT/'site/reports/compiler-demos/amr-contexts-20261118/source.zip';target.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED)as z:
        for name,content in sorted(data.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,content)
    assert target.stat().st_size<100_000_000
    print('Packaged',len(data),'files;',round(target.stat().st_size/1048576,2),'MiB;35 older ZIPs/26 viewers unchanged.')
if __name__=='__main__':main()
