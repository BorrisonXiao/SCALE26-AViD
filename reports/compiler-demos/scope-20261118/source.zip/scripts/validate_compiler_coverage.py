"""Validate full-corpus counts, generated programs and evidence routing."""
import hashlib
import json

from problog import get_evaluatable
from problog.engine import DefaultEngine
from problog.program import PrologString

from prepare_compiler_fallback import rows, dump, verify_freeze
from probabilistic_verification.compiler_coverage import verify_coverage
from run_compiler_coverage import RUN, STRICT, summarize


def main():
    verify_freeze()
    results = rows(RUN / 'corpus.jsonl')
    baseline = rows(STRICT / 'corpus.jsonl')
    assert len(results) == len({r['claim_id'] for r in results}) == 2375
    assert [r['claim_id'] for r in results] == [r['claim_id'] for r in baseline]
    counts = summarize(results, [r['attempts'] for r in baseline])
    assert counts == json.loads((RUN / 'summary.json').read_text())

    def unexpected_predict(_):
        raise AssertionError('An unresolved parse reached evidence inference.')

    validated = 0
    inferred = 0
    review_required = 0
    engine = DefaultEngine()
    for row, old in zip(results, baseline):
        if row['category'] == 'strict_baseline':
            assert row['program_sha256'] == old['output']['program_sha256']
            continue
        output = row.get('output')
        if output is None:
            assert verify_coverage(row, unexpected_predict)['reason'] == 'parsing_failure'
            continue
        program_hash = hashlib.sha256(output['program'].encode()).hexdigest()
        assert program_hash == output['program_sha256'] == row['program_sha256']
        prolog = PrologString(output['program'])
        grounded = engine.ground_all(prolog)
        queries = {str(name.args[-1]) for name, _ in grounded.queries()}
        assert queries == {'supported', 'refuted', 'unknown'}, row['claim_id']
        # Evaluate the short, exact quote cases under the same placeholder
        # evidence. Large AMR circuits need a separate cost measurement.
        if output['stage'] == 'written_quote':
            result = get_evaluatable(name='sdd').create_from(grounded).evaluate()
            distribution = {str(term.args[-1]): prob for term, prob in result.items()}
            assert distribution == {'supported': 0.0, 'refuted': 0.0, 'unknown': 1.0}, row['claim_id']
            inferred += 1
        if output['status'] == 'review_required':
            verdict = verify_coverage(row, unexpected_predict)
            assert verdict['reason'] == 'parse_review_required' and verdict['distribution'] is None
            claim = output['compilation']
            assert not any(claim['metadata']['allowed_routes'].values())
            assert not any(atom['trainable'] for atom in claim['atoms'])
            review_required += 1
        validated += 1

    first = results[0]
    before = baseline[0]['output']
    verdict = verify_coverage(first, lambda _: {'supported': 0.0, 'refuted': 0.0, 'unknown': 1.0},
                              baseline_output=before)
    assert verdict['verdict'] == 'insufficient_evidence'
    proof = dict(
        strict_program_hashes_match=counts['strict_baseline'], newly_grounded_programs=validated,
        quote_programs_unknown_with_no_observations=inferred, review_required_skip_verifier=review_required,
        full_corpus_unique_ids=len(results), status='passed',
    )
    dump(RUN / 'validation.json', proof)
    print(json.dumps(proof, indent=2))


if __name__ == '__main__':
    main()
