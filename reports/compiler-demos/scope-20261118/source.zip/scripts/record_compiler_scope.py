"""Record scope, fidelity and binding preparation results in project memory."""
import json

from prepare_compiler_fallback import ROOT, dump
from run_compiler_scope_repairs import RUN


def main():
    summary = json.loads((RUN / 'summary.json').read_text())
    audit = json.loads((RUN / 'fidelity.json').read_text())
    contrast = json.loads((RUN / 'binding_contrasts.json').read_text())
    count = summary['current_semantic']
    percent = 100 * count / summary['total']
    measure = (f'The scope repair pass recovers {summary["recovered"]} provisional programs '
               f'and raises coverage to {count:,}/2,375 ({percent:.2f}%). '
               f'The remaining {summary["dependency_only"]} claims have dependency analyses.')
    review = ('The 32-program development sample spans 33 source videos. It contains one full match, '
              '13 partial readings and 18 incorrect readings. All 15 sampled outputs without a warning '
              'have a meaning problem. An explicit OR warning flags four of the 171 provisional programs.')
    evidence = ('Five reviewed frame-based pairs supply ten examples. Three development clips and '
                'two reserved clips have disjoint source IDs and video hashes. Three pairs use visual '
                'attributes and two use OCR. Ten ProbLog checks with manual assignments return the '
                'expected labels. No frozen features were extracted for this protocol.')
    doc = f"""# Scope repairs, provisional review and binding preparation

{measure} 2,183 programs pass the prior compiler checks. The other 175 semantic programs
need meaning review, including the four new ones.

## Scope repairs

The repair was applied to all 21 prior dependency-only records using the existing dependency
annotations and AMR graphs. Four outputs cover three different texts. The two identical
voting rows are counted separately in the corpus.

- The voting alternatives share one actor. The if clause belongs to the last, mail-in branch.
- The signing stays inside image depiction. The likely qualification concerns the type of the
  signed object. The same object variable is used by both conditions.
- The ruling is introduced once and reused inside the unless clause. A graph declaration move
  leaves every semantic edge intact and puts the overturn condition under the requirement.
  The explicit reference keeps its enclosing variable under negation. Future timing and the
  Administration identity still need review.

The signing example fully matches its source reading. The other three are partial. The
remaining 17 inputs include nested descriptions, scope over quantified groups, malformed
graph roles and ambiguous discourse references. See the examples and exact traces in the report.

## Provisional program review

{review}

The sample uses fixed quotas by compiler path and prioritizes separate source clips and topics.
This development sample does not supply an accuracy estimate for the corpus. The exact
program hashes, case IDs and per-case reasons are recorded. The OR warning is advisory
and has reviewed examples of a missing disjunction. Many unflagged cases still have wrong
names, quantities, modality or attachment.

## Binding data

{evidence}

Each pair uses two hypotheses with the same lexical inventory and only the assignment changed.
The task supplies two candidate referents or regions and their exact frame times. A feature
model can receive the source frames and candidate descriptions without label or variant IDs.
The label concerns the supplied frame evidence. The prepared programs come from the declared
bindings and test predicate composition with those assignments.

A translated overlay is excluded from exact OCR supervision. Its Arabic pixels do not literally
contain the English claim. The robot's referenced number and the existing music labels still
need direct review. Several other candidates were held back when the required relationship
was not identifiable from the sampled frames. The local frame manifest records source hashes,
frame positions and image hashes. Raw source media stays local. There is no model inference
or empirical training result in this pilot.

## Reproduction

Run the following from the source bundle with the existing project dependencies. The cached
frame manifest suffices to reproduce the labeled data and logic controls. The raw videos
are needed to reproduce frame extraction and inspect the labels in the pixels.

```bash
python scripts/run_compiler_scope_repairs.py
python scripts/sample_compiler_scope_review.py
python scripts/review_compiler_scope.py
python scripts/prepare_binding_contrasts.py
python scripts/validate_compiler_scope.py
PYTHONPATH=scripts:tests python -m pytest -q tests/test_compiler_scope_repairs.py
```

## Next steps

1. Prepare a larger meaning-reviewed batch and improve checks for wrong entity, numeric
   and source-scope bindings. This will provide a valid compiler input for training.
2. Extract frozen features for both assignments with the same frames and candidate regions.
   This will make it possible to train on claim labels without leaking the answer.
3. Add reviewed speech and audio pairs from separate sources. Compare the binding model
   with a baseline that sees the same entities and attributes independently.
"""
    (ROOT / 'docs/compiler_scope_20261118.md').write_text(doc)
    path = ROOT / 'exp/probabilistic_verification/av_features_20261022/checklist.json'
    checklist = json.loads(path.read_text())
    checklist['compiler_scope_run'] = str(RUN.relative_to(ROOT))
    for step in checklist['steps']:
        if step['id'] == 36:
            step['status'] = 'scope experiment and binding pilot complete'
            step['items'] = [dict(text=text, done=True) for text in (measure, review, evidence)]
    if not any(step['id'] == 37 for step in checklist['steps']):
        checklist['steps'].append(dict(id=37, title='Prepare features and a binding baseline',
                                       status='planned', items=[
            'Review complete forms and add entity, number and source checks. Goal is to avoid training on wrong bindings.',
            'Extract frozen features for both assignments. Goal is to use identical evidence with no variant or label leakage.',
            'Add speech and audio pairs and compare the binding model with a no-binding baseline. Goal is to isolate binding gains.',
        ]))
    dump(path, checklist)
    path = ROOT / 'docs/project_notes/daily_log.json'
    log = json.loads(path.read_text())
    day = next(d for d in log['days'] if d['date'] == '2026-11-18')
    day['items'] = [r for r in day['items'] if not r.get('scope_repair_entry')]
    for item in day['items']:
        if item.get('coverage_entry') and item['href'] == '#remaining-failures':
            item['href'] = '#earlier-coverage'
    day['items'] += [
        dict(text=measure, href='#scope-repair-examples', label='Scope repairs', scope_repair_entry=True),
        dict(text=review, href='#scope-fidelity', label='Fidelity audit', scope_repair_entry=True),
        dict(text=evidence, href='#binding-contrasts', label='Binding contrasts', scope_repair_entry=True),
    ]
    dump(path, log)

    title = '## Scope repairs and binding preparation — 18 November 2026'
    memory = (f'{measure} {review} {evidence} Full test inventory retains all 2,375 inputs. '
              'The 2,183 check passes remain separate from 175 provisional programs. No empirical training. '
              'See docs/compiler_scope_20261118.md. Next work is checked binding forms, frozen feature '
              'extraction, and source-disjoint audio/speech and no-binding comparisons.')
    for name in ('AGENTS.md', 'CLAUDE.md'):
        path = ROOT / name
        text = path.read_text()
        if title not in text:
            header, rest = text.split('\n', maxsplit=1)
            path.write_text(header + f'\n\n{title}\n\n{memory}\n' + rest)
    for name in ('key_facts.md', 'issues.md'):
        path = ROOT / 'docs/project_notes' / name
        if title not in path.read_text():
            with path.open('a') as file:
                file.write(f'\n{title}\n\n{memory}\n')
    path = ROOT / 'docs/project_notes/bugs.md'
    heading = '### 2026-11-18 — Cross-scope condition declaration and variable binding'
    if heading not in path.read_text():
        with path.open('a') as file:
            file.write(f'\n{heading}\n\n'
                       'PENMAN can declare a condition under a noun through an inverse edge even when its '
                       'semantic owner is a nested clause. Move the declaration to the condition edge and '
                       'check exact graph equality. Keep explicit ancestor references free inside a '
                       'local negation so they bind to the already introduced entity.\n')
    assert audit['sample_size'] == 32 and len(contrast['pairs']) == 5
    print(measure)


if __name__ == '__main__':
    main()
