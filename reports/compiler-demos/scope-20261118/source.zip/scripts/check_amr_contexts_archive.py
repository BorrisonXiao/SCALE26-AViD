"""Clean extracted replay with no parser generation, network or GPU."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from run_amr_contexts import ROOT,RUN,dump

def main():
    archive=ROOT/'site/reports/compiler-demos/amr-contexts-20261118/source.zip'
    target=Path(tempfile.mkdtemp(prefix='avid-amr-contexts-'))
    with zipfile.ZipFile(archive)as z:z.extractall(target)
    for line in(target/'AMR_CONTEXTS_SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1);assert hashlib.sha256((target/name).read_bytes()).hexdigest()==digest,name
    env=dict(os.environ,PYTHONPATH=str(target/'scripts')+':'+str(target/'tests'),PYTHONHASHSEED='0',PYTHONDONTWRITEBYTECODE='1')
    commands=[['scripts/audit_compiler_counts.py'],['scripts/run_amr_contexts.py'],['scripts/run_amr_contexts.py','--external'],['scripts/analyze_amr_contexts.py'],['scripts/analyze_amr_contexts.py','--summarize'],['scripts/profile_amr_contexts.py'],['scripts/replay_amr_correction_legacy.py'],['scripts/replay_amr_contexts_defaults.py'],['-m','pytest','tests/test_amr_contexts.py','-q']]
    for command in commands:
        result=subprocess.run([sys.executable]+command,cwd=target,env=env,capture_output=True,text=True,timeout=180)
        assert result.returncode==0,result.stdout+result.stderr
        print('Replayed',' '.join(command),flush=True)
    path=RUN.relative_to(ROOT)
    names=['corpus.jsonl','changes.json','review_routing.json','reviewed_cases.json','external_outputs.json','external_cases.json','remaining.json','count_history.json','default_regression.json','external_equivalence.json']
    for name in names:assert(RUN/name).read_bytes()==(target/path/name).read_bytes(),name
    a=json.loads((RUN/'summary.json').read_text());b=json.loads((target/path/'summary.json').read_text());a.pop('seconds');b.pop('seconds');assert a==b
    dump(RUN/'archive_verification.json',dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),sha256_inventory=True,byte_identical_artifacts=names,summary_equal_except_elapsed=True,total_claims=2375,development_reviews=132,external_cases=20,focused_tests=26,workspace_tests=607,native_analytic_checks=11,default_and_legacy_replay=True,model_calls=0,extraction=str(target)))
    print('Clean source replay exact;26 focused tests,11 native controls and default/legacy replay pass.')
if __name__=='__main__':main()
