"""Collect fixed conditions, replayable attempts and all complete-program reviews."""
import hashlib,json
from collections import Counter
from prepare_amr_correction import ROOT,RUN,BASE,rows,dump

def main():
 before=rows(RUN/'before.jsonl');initial={r['claim_id']:r for r in before};refs={r['claim_id']:r['reference']for r in json.loads((BASE/'reviewed_cases.json').read_text())};refs.update({r['claim_id']:r for r in json.loads((RUN/'followup_references.json').read_text())})
 old_reviews={r['claim_id']:r['review']for r in json.loads((BASE/'reviewed_cases.json').read_text())}
 conditions={'before':{r['claim_id']:r['output']for r in before}}
 for n in ['first','feedback','generic']:conditions[n]={r['claim_id']:r['output']for r in rows(RUN/(n+'_final.jsonl'))}
 attempts={cid:[]for cid in initial}
 for folder in ['first','feedback_1','feedback_2','generic_1','generic_2']:
  path=RUN/folder/'responses.jsonl'
  if path.exists():
   for r in rows(path):attempts[r['claim_id']].append(dict(condition=folder,**r))
 # Reviews are bound to exact programs. Old judgments may be reused only for
 # byte-identical programs; changed programs always need new inspection.
 manual=json.loads((RUN/'manual_reviews.json').read_text())if(RUN/'manual_reviews.json').exists()else{}
 unique={};cases=[]
 for cid,original in initial.items():
  outputs={name:rs[cid]for name,rs in conditions.items()}
  for name,r in outputs.items():
   if'program'not in r:continue
   key=cid+':'+r['program_sha256']
   prior=old_reviews.get(cid)
   if prior and prior.get('program_sha256')==r['program_sha256']:
    review=dict(whole_reading=prior['whole_reading'],reason=prior['reason'],origin='Reused assistant judgment of byte-identical previous program; not new human approval.')
   elif key in manual:review=manual[key]
   elif r['status']!='compiled':review=dict(whole_reading='not_established',reason=r.get('reason','Automatic checks refuse this candidate; its meaning is not approved.'),origin='No complete accepted program; no model judge.')
   else:review=dict(whole_reading='pending',reason='Pending implementing-assistant review.',origin='No model judge.')
   r['review']=review
   if r['status']=='compiled'and key not in unique:unique[key]=dict(claim_id=cid,text=original['text'],cohort=original['cohort'],program_sha256=r['program_sha256'],first_condition=name,reference=refs[cid],output=r,review=review)
  cases.append(dict(claim_id=cid,text=original['text'],cohort=original['cohort'],reference=refs[cid],original_direct_error=original['original_direct_error'],outputs=outputs,attempts=attempts[cid]))
 stats={}
 for name,rs in conditions.items():
  groups={}
  for cohort,ids in [('all',list(initial)),('development',[cid for cid,r in initial.items()if r['cohort']=='development']),('followup',[cid for cid,r in initial.items()if r['cohort']=='followup'])]:
   xs=[rs[cid]for cid in ids];new=[rs[cid]for cid in ids if initial[cid]['output']['status']!='compiled'and rs[cid]['status']=='compiled'];groups[cohort]=dict(total=len(xs),automatic_pass=sum(r['status']=='compiled'for r in xs),new_passes=len(new),new_pass_review_counts=dict(Counter(r.get('review',{}).get('whole_reading','pending')for r in new)),remaining=dict(Counter(r.get('code','unknown')for r in xs if r['status']!='compiled')))
  stats[name]=groups
 summary=dict(corpus=json.loads((RUN/'corpus_summary.json').read_text()),conditions=stats,unique_complete_programs=len(unique),complete_review_counts=dict(Counter(r['review']['whole_reading']for r in unique.values())),model_requests=sum(len(a)for a in attempts.values()),initial_eligible=sum(r['output']['status']!='compiled'for r in initial.values()),initial_skipped=sum(r['output']['status']=='compiled'for r in initial.values()),retained_pool=1981,excluded=394,promotions=0,review_policy='Implementing assistant only; references do not enter messages or retry triggers. Final follow-up original-text readings were frozen before outputs; same project videos, not independent gold or corpus accuracy.')
 dump(RUN/'summary.json',summary);dump(RUN/'cases.json',cases);dump(RUN/'complete_programs.json',list(unique.values()));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
