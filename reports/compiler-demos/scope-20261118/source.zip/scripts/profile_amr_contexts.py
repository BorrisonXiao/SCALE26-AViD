"""Native inference controls on actual programs with constructed observations."""
import argparse
from dataclasses import replace
import json
import subprocess
import sys
import time
from run_amr_contexts import ROOT,RUN,rows,dump
CASES=['TzzhcBIczf_M_2109','T2G_ACMxR_I4_1312','T2G_ACMxR_I4_1351','TFgw4IaR9R8s_1626']

def worker(cid,mode):
    from probabilistic_verification.amr_contexts import compile_contextual
    from probabilistic_verification.logic import Evidence,ground
    from probabilistic_verification.direct_backend import DirectVerifier
    from probabilistic_verification.compact_backend import compact_prolog_program
    from probabilistic_verification.ordered_circuit import OrderedSolver
    records={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')}
    current={r['claim_id']:r for r in rows(RUN/'corpus.jsonl')}
    claim=compile_contextual(records[cid],current[cid]['raw'])
    evidence=Evidence('constructed',{v.name:['placeholder:'+v.name]for v in claim.variables},{v.name:True for v in claim.variables},{})
    p=ground(claim,evidence,max_expansions=3000)
    if mode=='mixed':p.observations={k:replace(o,distribution=(.9,.05,.05),available=True)for k,o in p.observations.items()}
    if mode=='outer_only':
        # Scope is the explicit field in each compiled atom.
        atom_context={a.id:a.arguments[a.arguments.index('scope')+1]for a in claim.atoms}
        observation_context={o['observation_id']:atom_context[o['atom_id']]for o in p.occurrences}
        p.observations={k:replace(o,distribution=(1.,0.,0.),available=True)if observation_context[k]=='world'else o for k,o in p.observations.items()}
    v=DirectVerifier([p],learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver)
    start=time.perf_counter();actual=v.predict()[0]['distribution'];n=len(p.observations)
    expected=dict(supported=.9**n,refuted=1-.95**n,unknown=.95**n-.9**n)if mode=='mixed'else dict(supported=0.,refuted=0.,unknown=1.)
    assert all(abs(actual[k]-expected[k])<1e-9 for k in expected),(actual,expected)
    print(json.dumps(dict(claim_id=cid,mode=mode,observations=n,seconds=time.perf_counter()-start,distribution=actual,analytic=expected,matches=True)))

def main():
    p=argparse.ArgumentParser();p.add_argument('--worker');p.add_argument('--mode',default='unknown');a=p.parse_args()
    if a.worker:worker(a.worker,a.mode);return
    out=[]
    for cid in CASES:
        for mode in ['unknown','mixed']+(['outer_only']if cid!=CASES[-1]else[]):
            r=subprocess.run([sys.executable,__file__,'--worker',cid,'--mode',mode],cwd=ROOT,capture_output=True,text=True,timeout=20)
            assert r.returncode==0,r.stdout+r.stderr
            out.append(json.loads(next(s for s in reversed(r.stdout.splitlines())if s.startswith('{'))))
    dump(RUN/'native_checks.json',dict(rows=out,policy='Constructed observations and one placeholder candidate per variable. No real evidence, model inference or training. Outer-only controls leave embedded context observations unknown.'))
    print('All',len(out),'native distributions match analytic controls.')
if __name__=='__main__':main()
