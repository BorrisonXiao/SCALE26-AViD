"""Recompute historical counts and paired coverage from actual saved programs."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT/'exp/probabilistic_verification/amr_contexts_20261118'
BASE = ROOT/'exp/probabilistic_verification'


def load(path):
    return [json.loads(s) for s in path.read_text().splitlines()]


def main():
    paths = [('Earlier SRL, syntax checks', 'compiler_revision_20261105/results.jsonl'),
             ('Same SRL plus source-word coverage', 'scope_coverage_20261105/results.jsonl'),
             ('Later SRL plus content/relationship checks', 'content_relations_20261105/results.jsonl'),
             ('Current SRL direct path', 'compiler_structural_20261113/direct_all.jsonl'),
             ('Current retained pool with reviewed fallback', 'compiler_structural_20261113/corpus_reviewed.jsonl'),
             ('AMR before context fixes', 'amr_types_20261115/corpus.jsonl'),
             ('AMR after context fixes', 'amr_contexts_20261118/corpus.jsonl')]
    inventories = {}; stages = []; texts = None
    for label, name in paths:
        path = BASE/name; data = load(path); by = {r['claim_id']: r for r in data}
        assert len(by) == len(data) == 2375
        current_texts = {cid:r['text'] for cid,r in by.items()}
        if texts is None:
            texts = current_texts
        assert current_texts == texts, name
        generated = {cid for cid,r in by.items() if r.get('program')}
        passing = {cid for cid,r in by.items() if r['status'] == 'compiled'}
        assert passing <= generated
        inventories[label] = dict(generated=generated, passing=passing)
        stages.append(dict(method=label, source=name, source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                           total=2375, generated=len(generated), passing=len(passing),
                           generated_but_flagged=len(generated-passing), no_program=2375-len(generated)))
    old = inventories[paths[0][0]]['generated']; srl = inventories[paths[3][0]]['generated']; amr = inventories[paths[5][0]]['generated']
    assert not old-srl
    paired = dict(srl_and_amr=len(srl&amr), srl_only=len(srl-amr), amr_only=len(amr-srl), neither=2375-len(srl|amr),
                  old_2099_missing_from_current_srl=0, current_srl_additions=len(srl-old),
                  policy='Descriptive paired coverage only. Do not union methods or interpret generation as faithful meaning.')
    data = dict(stages=stages, paired_generated=paired,
                explanation='The historical 2,099 is SRL program generation. Current SRL still generates 2,146. AMR generated 1,785 before these fixes; this is a different frontend and supported fragment. Source checks and meaning review are separate.',
                paired_after_generated=dict(srl_and_amr=len(srl & inventories[paths[6][0]]['generated']),srl_only=len(srl-inventories[paths[6][0]]['generated']),amr_only=len(inventories[paths[6][0]]['generated']-srl),neither=2375-len(srl|inventories[paths[6][0]]['generated'])),
                review='Implementing-assistant evidence audit; no external judge.')
    (RUN/'count_history.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(data,indent=2))


if __name__ == '__main__':
    main()
