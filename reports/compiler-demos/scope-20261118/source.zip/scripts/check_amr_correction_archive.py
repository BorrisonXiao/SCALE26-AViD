"""Clean extraction replay, with no model import, network or GPU allocation."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from prepare_amr_correction import ROOT,RUN,dump
def main():
 archive=ROOT/'site/reports/compiler-demos/amr-correction-20261114/source.zip';target=Path(tempfile.mkdtemp(prefix='avid-amr-correction-'))
 with zipfile.ZipFile(archive)as z:z.extractall(target)
 for line in(target/'AMR_CORRECTION_SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256((target/n).read_bytes()).hexdigest()==h,n
 env=dict(os.environ,PYTHONPATH=str(target/'scripts'),PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0')
 for script in ['run_amr_checked_corpus.py','replay_amr_correction.py','analyze_amr_correction.py','diagnose_duplicate_amr_edits.py','replay_numbered_amr.py','replay_amr_correction_legacy.py']:
  r=subprocess.run([sys.executable,'scripts/'+script],cwd=target,env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr;print('Replayed',script,flush=True)
 names=['corpus.jsonl','before.jsonl','cases.json','complete_programs.json','duplicate_diagnostic.json','legacy_regression.json']
 for n in names:assert(RUN/n).read_bytes()==(target/RUN.relative_to(ROOT)/n).read_bytes(),n
 for n in ['corpus_summary.json','summary.json']:
  a=json.loads((RUN/n).read_text());b=json.loads((target/RUN.relative_to(ROOT)/n).read_text())
  if n=='summary.json':a['corpus'].pop('seconds');b['corpus'].pop('seconds')
  else:a.pop('seconds');b.pop('seconds')
  assert a==b,n
 r=subprocess.run([sys.executable,'-m','pytest','tests/test_amr_correction.py','tests/test_amr_semantic_checks.py','tests/test_ordered_circuit.py','-q'],cwd=target,env=env,capture_output=True,text=True,timeout=45);assert r.returncode==0,r.stdout+r.stderr;assert'26 passed'in r.stdout
 r=subprocess.run([sys.executable,'scripts/profile_ordered_inference.py','--worker','--case','Txf2EdqOg1SQ_2176','--mode','mixed','--ordered'],cwd=target,env=env,capture_output=True,text=True,timeout=12);assert r.returncode==0,r.stdout+r.stderr
 result=[json.loads(s)for s in r.stdout.splitlines()if s.startswith('{')][-1];assert result['observations']==19 and result['expected']and abs(sum(result['distribution'].values())-1)<1e-9
 dump(RUN/'archive_verification.json',dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),sha256_inventory=True,byte_identical_artifacts=names,summaries_equal_except_elapsed=True,originals=2375,pilot_cases=70,all_saved_messages_replayed=True,focused_tests=26,full_workspace_tests=564,native_wind_mixed=result['distribution'],model_calls=0,extraction=str(target)));print('Clean replay exact;26focused tests and native19-observation wind passed.')
if __name__=='__main__':main()
