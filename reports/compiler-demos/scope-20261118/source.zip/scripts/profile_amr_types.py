"""Native DeepProbLog on actual new programs, using constructed observations."""
import argparse
from dataclasses import replace
import json
import subprocess
import sys
import time

from run_amr_types import ROOT, RUN, rows, dump

CASES = ['TQKCK6-tRaoE_662', 'TW4OYA3RN-Hw_1821', 'TbJqMFkNxARY_172', 'T2G_ACMxR_I4_1441']


def worker(cid, mixed):
    from probabilistic_verification.amr_types import compile_typed
    from probabilistic_verification.logic import Evidence, ground
    from probabilistic_verification.direct_backend import DirectVerifier
    from probabilistic_verification.compact_backend import compact_prolog_program
    from probabilistic_verification.ordered_circuit import OrderedSolver
    records = {r['claim_id']: r for r in rows(ROOT / 'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')}
    current = {r['claim_id']: r for r in rows(RUN / 'corpus.jsonl')}
    claim = compile_typed(records[cid], current[cid]['raw'])
    evidence = Evidence('constructed', {v.name: ['placeholder:' + v.name] for v in claim.variables},
                        {v.name: True for v in claim.variables}, {})
    program = ground(claim, evidence, max_expansions=3000)
    if mixed:
        program.observations = {k: replace(o, distribution=(.9, .05, .05), available=True) for k, o in program.observations.items()}
    verifier = DirectVerifier([program], learned=False, program_builder=compact_prolog_program, solver_class=OrderedSolver)
    start = time.perf_counter()
    actual = verifier.predict()[0]['distribution']
    n = len(program.observations)
    expected = dict(supported=.9**n, refuted=1-.95**n, unknown=.95**n-.9**n) if mixed else dict(supported=0., refuted=0., unknown=1.)
    assert all(abs(actual[k]-expected[k]) < 1e-9 for k in expected), (actual, expected)
    print(json.dumps(dict(claim_id=cid, observations=n, mixed=mixed, seconds=time.perf_counter()-start,
                          distribution=actual, analytic=expected, matches=True)))


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--worker'); parser.add_argument('--mixed', action='store_true')
    args = parser.parse_args()
    if args.worker:
        worker(args.worker, args.mixed); return
    outputs = []
    for cid in CASES:
        for mixed in [False, True]:
            command = [sys.executable, __file__, '--worker', cid] + (['--mixed'] if mixed else [])
            result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=15)
            assert result.returncode == 0, result.stdout + result.stderr
            outputs.append(json.loads(next(s for s in reversed(result.stdout.splitlines()) if s.startswith('{'))))
    dump(RUN / 'native_checks.json', dict(rows=outputs, policy='Grouped native inference; single-run diagnostics with constructed scores and placeholder candidates, no media evidence or training.'))
    print('All eight native outputs match their analytic distributions.')


if __name__ == '__main__':
    main()
