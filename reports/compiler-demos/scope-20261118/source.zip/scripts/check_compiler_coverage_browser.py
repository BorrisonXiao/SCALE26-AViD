"""Verify the coverage viewer and the preserved strict inspector."""
import functools
import http.server
import json
import threading

from playwright.sync_api import sync_playwright

from run_compiler_coverage import ROOT, RUN


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


def main():
    site = ROOT / 'site'
    inputs = json.loads((site / 'reports/compiler-demos/coverage-20261118/cases.json').read_text())
    server = http.server.ThreadingHTTPServer(
        ('127.0.0.1', 0), functools.partial(QuietHandler, directory=str(site)),
    )
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = f'http://127.0.0.1:{server.server_port}/reports/'
    errors = []
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True, args=['--no-sandbox'])
            page = browser.new_page(viewport={'width': 1420, 'height': 960})
            page.on('pageerror', lambda err: errors.append(str(err)))
            page.goto(url + 'compiler-demos.html#remaining-failures', wait_until='networkidle')
            expected = json.loads((RUN / 'summary.json').read_text())
            assert f"{expected['semantic_programs']:,}" in page.locator('#current-work').inner_text()
            assert page.locator('[role=tab]').count() == 5
            page.screenshot(path=str(RUN / 'coverage-overview.png'))
            page.goto(url + 'compiler-demos.html#coverage-cases', wait_until='networkidle')
            assert page.locator('#coverage-case option').count() == len(inputs) == 198
            views = page.evaluate('''inputs => {
              let views = 0;
              const select = document.getElementById('coverage-case');
              for (const row of inputs) {
                select.value = row.claim_id;
                select.dispatchEvent(new Event('change'));
                if (document.getElementById('coverage-text').textContent !== row.text) throw Error(row.claim_id);
                if (document.getElementById('coverage-status').textContent !== row.label) throw Error(row.claim_id);
                if (!document.getElementById('coverage-exact').textContent.includes(row.program)) throw Error(row.claim_id);
                if (document.getElementById('coverage-attempts').childElementCount !== row.alerts.length) throw Error(row.claim_id);
                views++;
              }
              return views;
            }''', inputs)
            assert views == 198
            page.select_option('#coverage-filter', 'dependencies')
            assert page.locator('#coverage-case option').count() == expected['categories']['dependencies']
            page.goto(url + 'compiler-demos.html?coverage_claim=Tsuk2uoYj-kc_628#coverage-cases', wait_until='networkidle')
            assert 'written text' in page.locator('#coverage-conditions').inner_text()
            page.screenshot(path=str(RUN / 'coverage-viewer.png'))
            page.locator('#coverage-strict').click()
            page.wait_for_function('document.getElementById("fallback-text").textContent.includes("Last year")')
            assert page.locator('#fallback-case option').count() == 2375
            page.goto(url + 'compiler-demos.html#strict-fallback-overview', wait_until='networkidle')
            assert page.locator('#history').is_visible()
            page.set_viewport_size({'width': 390, 'height': 844})
            page.emulate_media(color_scheme='dark')
            for fragment in ('remaining-failures', 'coverage-examples', 'coverage-cases'):
                page.goto(url + 'compiler-demos.html#' + fragment, wait_until='networkidle')
                assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'), fragment
            page.goto(url + 'verification-pipeline.html#next-steps', wait_until='networkidle')
            assert f"{expected['semantic_programs']:,}" in page.locator('#next-steps').inner_text()
            page.goto(url, wait_until='networkidle')
            assert page.locator('.card-link').count() == 2
            assert not errors, errors
            browser.close()
        print('All 198 new case views, the 2,375-case strict inspector, and desktop/mobile navigation pass.')
    finally:
        server.shutdown()


if __name__ == '__main__':
    main()
