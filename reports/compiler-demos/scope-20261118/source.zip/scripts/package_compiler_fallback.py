"""Package the fixed fallback and saved inputs for model-free reproduction."""
import hashlib
import json
import zipfile
from prepare_compiler_fallback import ROOT, RUN, BASE, dump


def main():
    names = set()
    patterns = [('scripts', '*.py'), ('scripts', '*fallback*.slurm'),
                ('scripts/probabilistic_verification', '*.py'),
                ('scripts/probabilistic_verification/resources', '*.json'),
                ('scripts/report_assets', '*'), ('tests', '*.py'),
                ('tests/fixtures', '*.json'), ('docs/project_notes', '*')]
    for folder, pattern in patterns:
        names.update(str(p.relative_to(ROOT)) for p in (ROOT / folder).glob(pattern)
                     if p.is_file())
    names.update(['AGENTS.md', 'CLAUDE.md', 'docs/compiler_fallback_20261118.md',
                  'docs/amr_contexts_20261118.md',
                  'exp/probabilistic_verification/av_features_20261022/checklist.json'])
    excluded = {'source_manifest.json', 'archive_verification.json',
                'browser_checks.json', 'publication.json'}
    suffixes = {'.py', '.json', '.jsonl', '.xml', '.md', '.txt', '.log',
                '.sha256', '.out', '.err', '.slurm'}
    names.update(str(p.relative_to(ROOT)) for p in RUN.rglob('*')
                 if p.is_file() and '__pycache__' not in p.parts
                 and 'legacy_replay' not in p.parts
                 and p.name not in excluded and p.suffix in suffixes)
    required = [
        'amr_contexts_20261118/corpus.jsonl',
        'amr_contexts_20261118/reviewed_cases.json',
        'amr_contexts_20261118/external_manifest.json',
        'amr_contexts_20261118/external_amr_raw.jsonl',
        'amr_contexts_20261118/external_references.json',
        'amr_types_20261115/corpus.jsonl',
        'amr_composition_20261114/corpus.jsonl',
        'amr_refinement_20261114/reviewed_cases.json',
        'amr_correction_20261114/corpus.jsonl',
        'content_relations_20261105/inputs.jsonl',
        'content_relations_20261105/results.jsonl',
        'compiler_revision_20261105/results.jsonl',
        'scope_coverage_20261105/results.jsonl',
        'compiler_structural_20261113/direct_all.jsonl',
        'compiler_structural_20261113/cached_pipeline.jsonl',
        'rewrite_all_20261112/inputs.jsonl',
        'rewrite_all_20261112/parsed.jsonl',
        'rewrite_all_20261112/raw.jsonl',
        'rewrite_all_20261112/model_config.json',
    ]
    required += [f'full_compilation_20261029/amr_{i}_raw.jsonl' for i in range(4)]
    names.update('exp/probabilistic_verification/' + n for n in required)
    preserved = json.loads((RUN / 'preserved_files.json').read_text())
    for name, digest in preserved.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    data = {name: (ROOT / name).read_bytes() for name in sorted(names)}
    dump(RUN / 'source_manifest.json',
         {name: hashlib.sha256(b).hexdigest() for name, b in data.items()})
    data[str((RUN / 'source_manifest.json').relative_to(ROOT))] = (RUN / 'source_manifest.json').read_bytes()
    data['README_COMPILER_FALLBACK.md'] = (ROOT / 'docs/compiler_fallback_20261118.md').read_bytes()
    data['COMPILER_FALLBACK_SHA256SUMS'] = ''.join(
        hashlib.sha256(b).hexdigest() + '  ' + name + '\n'
        for name, b in sorted(data.items())).encode()
    target = ROOT / 'site/reports/compiler-demos/fallback-20261118/source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, content in sorted(data.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, content)
    assert target.stat().st_size < 100_000_000
    print(f'Packaged {len(data)} files; {target.stat().st_size / 1048576:.2f} MiB; '
          f'{len(preserved)} historical archives/viewers unchanged.')


if __name__ == '__main__':
    main()
