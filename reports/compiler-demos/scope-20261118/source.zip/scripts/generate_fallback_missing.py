"""One fixed local rewrite request for each genuinely uncached strict failure."""
import hashlib,importlib.metadata,json,os,time
from prepare_compiler_fallback import ROOT,RUN,rows,dump,verify_freeze

def main():
    verify_freeze();target=RUN/'missing_rewrites';target.mkdir(exist_ok=True)
    source={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')}
    results=rows(RUN/'corpus.jsonl');pending=[r for r in results if r['parsing_status']=='abstained'and r['attempts'][-1].get('code')=='rewrite_uncached']
    assert all(len(r['attempts'])==3 and all(a['status']!='compiled'for a in r['attempts'][:2])for r in pending)
    routing=[dict(claim_id=r['claim_id'],previous_stages=[dict(stage=a['stage'],code=a.get('code'),reason=a.get('reason'))for a in r['attempts'][:2]])for r in pending]
    dump(target/'routing.json',routing)
    if not pending:return
    assert not(target/'raw.jsonl').exists(),'Do not overwrite model responses.'
    from probabilistic_verification.full_rewrite import SCHEMA,messages
    import torch
    from vllm import LLM,SamplingParams
    from vllm.sampling_params import StructuredOutputsParams
    model=__import__('pathlib').Path('/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507')
    requests=[messages(source[r['claim_id']],dict(stages=route['previous_stages']))for r,route in zip(pending,routing)]
    # Identical system prompt/schema/model/decoding to the historical condition;
    # diagnostic input reflects the actual current failures, without reviews.
    config=dict(model=str(model),dtype='float16',temperature=0,seed=42,max_tokens=3072,max_model_len=32768,eligible=len(pending),job_id=os.getenv('SLURM_JOB_ID'),gpu_names=[torch.cuda.get_device_name(i)for i in range(torch.cuda.device_count())],vllm=importlib.metadata.version('vllm'),system_prompt=requests[0][0]['content'],system_prompt_sha256=hashlib.sha256(requests[0][0]['content'].encode()).hexdigest(),model_config_sha256=hashlib.sha256((model/'config.json').read_bytes()).hexdigest(),policy='Only uncached cases after both strict checks fail. One response, no retries, no meaning-review labels.')
    dump(target/'model_config.json',config)
    llm=LLM(model=str(model),dtype='float16',tensor_parallel_size=1,max_model_len=32768,max_num_seqs=16,gpu_memory_utilization=.90,enforce_eager=True,enable_prefix_caching=True,seed=42)
    tok=llm.get_tokenizer();prompts=[tok.apply_chat_template(m,tokenize=False,add_generation_prompt=True)for m in requests]
    params=SamplingParams(temperature=0,seed=42,max_tokens=3072,structured_outputs=StructuredOutputsParams(json=SCHEMA));start=time.perf_counter();outputs=llm.generate(prompts,params,use_tqdm=False);seconds=time.perf_counter()-start
    data=[]
    for row,request,out in zip(pending,requests,outputs):
        answer=out.outputs[0];data.append(dict(claim_id=row['claim_id'],messages=request,raw=answer.text,finish_reason=answer.finish_reason,input_tokens=len(out.prompt_token_ids),output_tokens=len(answer.token_ids),batch_seconds=seconds,batch_size=len(pending)))
    (target/'raw.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in data));print('Saved',len(data),'failure-only responses in',seconds,'seconds.',flush=True)
if __name__=='__main__':main()
