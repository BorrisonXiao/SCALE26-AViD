"""Paired SRL/AMR/fallback replay on the existing 20 external diagnostics."""
import json,logging
from collections import Counter
from prepare_compiler_fallback import ROOT,RUN,BASE,rows,dump,verify_freeze
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.compiler_fallback import compile_claim,check_output
from probabilistic_verification.fallback_amr import compile_fallback_amr,prepare_fallback
from run_amr_types import inspect

def main():
    verify_freeze();logging.getLogger('penman').setLevel(logging.ERROR)
    graphs={r['request']['task']['claim_id']:r['raw']for r in rows(BASE/'external_amr_raw.jsonl')}
    refs={r['claim_id']:r for r in json.loads((BASE/'external_references.json').read_text())}
    outputs=[]
    for record in rows(RUN/'external_inputs.jsonl'):
        srl=compile_one(record);amr=inspect(record,graphs[record['claim_id']],compiler=compile_fallback_amr,prepare=prepare_fallback)
        # Paired diagnostic saves both candidates. The actual routing function
        # still receives lazy callbacks and selects SRL first on check success.
        fallback=compile_claim(record,srl=lambda _:srl,amr=lambda _:amr,rewrite=None)
        outputs.append(dict(claim_id=record['claim_id'],text=record['text'],reference=refs[record['claim_id']],srl=check_output(record,srl),amr=check_output(record,amr),fallback=fallback))
    dump(RUN/'external_outputs.json',outputs)
    summary=dict(total=20,srl_generated=sum(bool(r['srl'].get('program'))for r in outputs),srl_passing=sum(r['srl']['status']=='compiled'for r in outputs),amr_generated=sum(bool(r['amr'].get('program'))for r in outputs),amr_passing=sum(r['amr']['status']=='compiled'for r in outputs),fallback_selected=dict(Counter(r['fallback']['selected_stage']or'abstained'for r in outputs)),rewrite_responses=0,policy='Previously selected external diagnostic; frozen references, compiler fixed before these outputs, no new rewrite requests or truth labels.')
    dump(RUN/'external_summary.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
