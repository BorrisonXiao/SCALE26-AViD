"""Prepare same-word binding contrasts from individually inspected source frames."""
import hashlib
import json
import re
from collections import Counter
from dataclasses import dataclass

from problog import get_evaluatable
from problog.program import PrologString

from run_compiler_scope_repairs import RUN, COVERAGE, dump
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.logical_form_v2 import ScopedClaim
from probabilistic_verification.representation import Atom, Expression, Variable


@dataclass(frozen=True)
class FramePair:
    name: str
    source: str
    split: str
    route: str
    times: tuple[float, float]
    targets: tuple[str, str]
    values: tuple[str, str]
    template: str
    rationale: str


PAIRS = (
    FramePair('vehicle_colors', 'zlD_zgNiYJkRV1PS', 'development', 'visual_depiction',
              (2.0, 5.0), ('cargo aircraft', 'school bus'), ('gray', 'yellow'),
              'The cargo aircraft is {} and the school bus is {}.',
              'The 2.00 s frame shows the gray fuselage and engines. The 5.00 s frame shows the yellow school bus.'),
    FramePair('road_dates', 'M2dVSDPilbnrmb73', 'development', 'ocr_assertion',
              (57.92, 57.92), ('left panel date label', 'right panel date label'),
              ('APRIL 21, 2020', 'JANUARY 23, 2025'),
              'The left panel is labeled "{}" and the right panel is labeled "{}".',
              'In the side-by-side view, the two dates are printed directly above their respective road panels.'),
    FramePair('sails_and_caption', 'gzD8zHnzVeSzQ0lX', 'development', 'visual_depiction',
              (34.77, 34.77), ('large rectangular sails', 'bottom username'),
              ('red', 'white'), 'The large rectangular sails are {} and the bottom username is {}.',
              'The prominent rectangular sails are lit red. The bottom username @rt_russian is rendered white. The target property is the displayed color.'),
    FramePair('tie_colors', 'J2vYKin5lPXfBgGb', 'reserved', 'visual_depiction',
              (4.2, 32.43), ('Mark Carney tie', 'Donald Trump tie'), ('blue', 'red'),
              'Mark Carney has a {} tie and Donald Trump has a {} tie.',
              'The Carney lower-third and dark blue tie are visible at 4.20 s. The Trump photo shows a red tie at 32.43 s. The two frames supply separate observations.'),
    FramePair('corner_logos', 'AHROLHmgvOS9veQ2', 'reserved', 'ocr_assertion',
              (0.8, 0.8), ('upper left logo', 'upper right logo'),
              ('7 NEWS .com.au', 'sunrise'),
              'The upper left logo displays "{}" and the upper right logo displays "{}".',
              'The red 7 and NEWS.com.au are in a stacked logo on the left. The orange sunrise wordmark is on the right. Whitespace between stacked lines is normalized.'),
)

REJECTED = [
    {'source_video': 'tRXmuOpb4QD84JAu', 'claim_id': 'Tsuk2uoYj-kc_628',
     'reason': 'The fixed frames show Arabic overlay text. The English claim is a translation, so it cannot supervise an exact English inscription.'},
    {'source_video': 'c0zHs25t-Ied7wyr', 'claim_id': 'Tg0UxWYuPeJ0_425',
     'reason': 'A robot falls near the ropes, but the inspected frames did not clearly establish its numeric identity.'},
    {'source_video': 'nbLGyE4eZpvwO22t', 'claim_id': 'Txf2EdqOg1SQ_2236',
     'reason': 'The reviewed sequence includes a boat clip and other scenes. A clean role swap requires jointly identified alternatives within the same segment.'},
    {'source_video': 'zlD_zgNiYJkRV1PS', 'claim_id': 'earlier_music_attribute',
     'reason': 'The earlier instrumental versus vocal label comes from a model readout and needs an audio review. It is excluded from this frame-labeled set.'},
    {'source_video': 'J2vYKin5lPXfBgGb', 'claim_id': 'TQEmEycTI0RQ_836',
     'reason': 'The inspected frames show Carney at the lectern and a Trump cutaway. They suffice for the tie contrast and leave the Trump–Musk handshake unverified.'},
]


def instantiate(pair, frames, flipped):
    requested = pair.values[::-1] if flipped else pair.values
    variant = 'swapped' if flipped else 'observed'
    text = pair.template.format(*requested)
    variables = tuple(Variable(f'X{i + 1}', 'entity', target, ()) for i, target in enumerate(pair.targets))
    atoms = []
    scope_details = {}
    for i in range(len(variables)):
        var, frame = variables[i], frames[i]
        scope = f'{pair.source}_frame_{frame["frame_index"]}'
        scope_details[scope] = dict(parent='world', kind='frame', route=pair.route,
                                    frame_seconds=frame['frame_seconds'])
        args = (var.name, requested[i]) if pair.route == 'ocr_assertion' else (var.name, 'color', requested[i])
        predicate = 'written_text' if pair.route == 'ocr_assertion' else 'property'
        atoms.append(Atom(f'a{i + 1}', predicate, (*args, 'scope', scope, 'route', pair.route),
                          'property', (), requested[i], (), True))
    expression = Expression.exists([v.name for v in variables], Expression.combine(
        'and', [Expression.atom(a.id) for a in atoms],
    ))
    claim = ScopedClaim(
        f'{pair.name}:{variant}', text, (), variables, tuple(atoms), expression, (),
        metadata=dict(scopes=scope_details,
                      allowed_routes={a.id: [pair.route] for a in atoms},
                      kind='claim', supplied_candidates=True),
    )
    # This runs the logic against the inspected assignments as a control. The
    # observed attributes are labels, never input features for a learned module.
    assignment = {v.name: description for v, description in zip(variables, pair.targets)}
    supplied = Evidence(pair.source, {k: [v] for k, v in assignment.items()},
                        {k: True for k in assignment}, {}, route=pair.route)
    for i, atom in enumerate(atoms):
        key = canonical_key(supplied.media_id, atom, assignment, supplied.route)
        supported = requested[i] == pair.values[i]
        supplied.observations[key] = Observation(key, (1., 0., 0.) if supported else (0., 1., 0.),
                                                 False, 'Inspected frame assignment')
    grounded = ground(claim, supplied)
    program = compact_prolog_program([grounded], learned=False)[0]
    evaluated = get_evaluatable(name='sdd').create_from(PrologString(program)).evaluate()
    target_label = 'refuted' if flipped else 'supported'
    actual = {str(k.args[-1]): v for k, v in evaluated.items()}
    assert actual[target_label] == 1.0
    return dict(variant=variant, claim=text, label=target_label, paired_route=pair.route,
                audio_event='unknown', speech_assertion='unknown', bindings=list(zip(pair.targets, requested)),
                logical_form=claim.to_dict(), program_sha256=hashlib.sha256(program.encode()).hexdigest(),
                logic_control=actual)


def main():
    frames = json.loads((RUN / 'media_manifest.json').read_text())
    indexed = {(r['source_video'], r['requested_seconds']): r for r in frames}
    checked = json.loads((COVERAGE / 'checked_forms.json').read_text())
    sources = {r['source_video']: set() for r in frames}
    for item in checked:
        for src in item['source_videos']:
            if src in sources:
                sources[src].add(item['claim_id'])
    results = []
    split_sources = {'development': set(), 'reserved': set()}
    for pair in PAIRS:
        chosen_frames = [indexed[(pair.source, t)] for t in pair.times]
        for frame in chosen_frames:
            path = RUN / 'media' / frame['image']
            if path.is_file():
                assert hashlib.sha256(path.read_bytes()).hexdigest() == frame['image_sha256']
        outputs = [instantiate(pair, chosen_frames, flipped) for flipped in (False, True)]
        tokens = lambda text: Counter(re.findall(r'\w+|[^\w\s]', text.casefold()))
        assert tokens(outputs[0]['claim']) == tokens(outputs[1]['claim'])
        split_sources[pair.split].add(pair.source)
        results.append(dict(pair_id=pair.name, split=pair.split, media_route=pair.route,
                            source_video=pair.source, frames=chosen_frames, candidates=pair.targets,
                            review=pair.rationale, examples=outputs, vocabulary_matched=True,
                            prior_checked_claim_ids=sorted(sources[pair.source])))
    assert split_sources['development'].isdisjoint(split_sources['reserved'])
    video_hashes = {split: {f['video_sha256'] for p in results if p['split'] == split for f in p['frames']}
                    for split in split_sources}
    assert video_hashes['development'].isdisjoint(video_hashes['reserved'])
    dump(RUN / 'binding_contrasts.json', dict(
        pairs=results, rejected=REJECTED, groups={k: sorted(v) for k, v in split_sources.items()},
        label_provenance='Assistant reviewed fixed original-resolution frames. One label per hypothesis on the supplied frame candidates.',
        scope='Pilot with supplied candidate identity and timestamps. Template-built logical forms. No trained verifier or test accuracy.',
        feature_status='Frame and source references recorded. Frozen features still need extraction for this pair protocol.',
    ))
    print(len(results), 'pairs on', sum(len(s) for s in split_sources.values()),
          'source clips. All ten manual-evidence logic controls agree.')


if __name__ == '__main__':
    main()
