"""Post-hoc CPU diagnostic only: ignore identical AMR triples, not conflicting ones.

Saved generation-time checks/messages are unchanged. These counts do not predict
what a retry loop using the relaxed adapter would have generated.
"""
import json,re
from collections import Counter
import jsonschema
from prepare_amr_correction import RUN,ROOT,rows,dump
from probabilistic_verification.amr_correction import output_schema,inspect,graph_data,edit_source_checks

def evaluate_as_set(record,graph,raw,initial):
 import penman
 from penman.models.amr import model
 try:
  result=json.loads(raw);jsonschema.validate(result,output_schema(graph));changes={};added=[]
  if not result['edits']:raise ValueError('No edits proposed.')
  for e in result['edits']:
   if e['op']=='add':added.append(tuple(e['triple']));continue
   i=e['index']
   if i in changes:raise ValueError('One original index was edited twice.')
   changes[i]=None if e['op']=='remove'else tuple(e['triple'])
  proposed=[changes.get(i,tuple(t))for i,t in enumerate(graph['triples'])if changes.get(i,tuple(t))is not None]+added;triples=list(dict.fromkeys(proposed));removed=len(proposed)-len(triples)
  instances=[(s,t)for s,r,t in triples if r==':instance'];nodes=dict(instances)
  if len(nodes)!=len(instances):raise ValueError('Conflicting concept declarations remain.')
  if result['top']not in nodes:raise ValueError('Root is undeclared.')
  for s,r,t in triples:
   if s not in nodes or not model.has_role(r):raise ValueError('Undeclared source or unsupported role.')
   if r==':instance':
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*',t):raise ValueError('Invalid concept.')
   elif t not in nodes and not(t.startswith('"')and t.endswith('"')or re.fullmatch(r'[-+]?\d+(?:\.\d+)?|[-+]',t)):raise ValueError('Undeclared target: '+t)
  amr=penman.encode(penman.Graph(triples,top=result['top']),model=model);out=inspect(record,amr);extra=edit_source_checks(record,initial,graph_data(amr))
  if extra:out.update(status='unsupported',errors=out['errors']+extra)
  return dict(output=out,identical_triples_removed=removed)
 except Exception as e:return dict(output=dict(status='unsupported',code='postprocessing_error',reason=str(e)),identical_triples_removed=0)

def main():
 records={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')};initial={r['claim_id']:r['original_graph']for r in rows(RUN/'before.jsonl')};out=[]
 for folder in ['first','feedback_1','feedback_2','generic_1','generic_2']:
  p=RUN/folder/'responses.jsonl'
  if not p.exists():continue
  for r in rows(p):out.append(dict(claim_id=r['claim_id'],cohort=r['cohort'],condition=folder,raw=r['response_raw'],generation_status=r['output']['status'],**evaluate_as_set(records[r['claim_id']],r['previous_graph'],r['response_raw'],initial[r['claim_id']])))
 dump(RUN/'duplicate_diagnostic.json',dict(policy=__doc__,attempts=out,automatic_pass=sum(r['output']['status']=='compiled'for r in out),pass_by_condition=dict(Counter(r['condition']for r in out if r['output']['status']=='compiled')),attempts_with_duplicates_removed=sum(r['identical_triples_removed']>0 for r in out)))
 print(len(out),'cached attempts;',sum(r['output']['status']=='compiled'for r in out),'post-hoc automatic passes')
if __name__=='__main__':main()
