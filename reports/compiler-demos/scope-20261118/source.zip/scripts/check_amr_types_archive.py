"""Extract and replay the published source without model calls or GPUs."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

from run_amr_types import ROOT, RUN, dump


def main():
    archive=ROOT/'site/reports/compiler-demos/amr-types-20261115/source.zip'
    target=Path(tempfile.mkdtemp(prefix='avid-amr-types-'))
    with zipfile.ZipFile(archive) as z:
        z.extractall(target)
    for line in (target/'AMR_TYPES_SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256((target/name).read_bytes()).hexdigest()==digest,name
    env=dict(os.environ,PYTHONPATH=str(target/'scripts')+':'+str(target/'tests'),PYTHONHASHSEED='0',PYTHONDONTWRITEBYTECODE='1')
    for script in ['run_amr_types.py','analyze_amr_types.py','profile_amr_types.py','replay_amr_correction_legacy.py']:
        result=subprocess.run([sys.executable,'scripts/'+script],cwd=target,env=env,capture_output=True,text=True,timeout=180)
        assert result.returncode==0,result.stdout+result.stderr
        print('Replayed',script,flush=True)
    path=RUN.relative_to(ROOT)
    names=['corpus.jsonl','changed.json','reviewed_cases.json','review_routing.json','remaining.json','additional_gains.json']
    for name in names:
        assert (RUN/name).read_bytes()==(target/path/name).read_bytes(),name
    before=json.loads((RUN/'summary.json').read_text());after=json.loads((target/path/'summary.json').read_text())
    before.pop('seconds');after.pop('seconds');assert before==after
    result=subprocess.run([sys.executable,'-m','pytest','tests/test_amr_types.py','-q'],cwd=target,env=env,capture_output=True,text=True,timeout=45)
    assert result.returncode==0 and '17 passed' in result.stdout,result.stdout+result.stderr
    dump(RUN/'archive_verification.json',dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
         sha256_inventory=True,byte_identical_artifacts=names,summary_equal_except_elapsed=True,
         total_claims=2375,reference_cases=116,additional_reviews=16,focused_tests=17,
         workspace_tests=581,native_analytic_checks=8,legacy_replay=True,model_calls=0,extraction=str(target)))
    print('Clean replay exact; 17 focused tests, eight native analytic checks and legacy replay pass.')


if __name__=='__main__':
    main()
