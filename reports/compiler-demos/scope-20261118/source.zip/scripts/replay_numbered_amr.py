"""Replay the paired input-layout pilot without loading its model."""
import copy,json
from collections import Counter
from prepare_amr_correction import ROOT,RUN,rows,dump
from probabilistic_verification.amr_correction import request,evaluate,graph_data

def main():
 run=RUN/'numbered_pilot';ids=json.loads((run/'selection.json').read_text())['ids'];initial={r['claim_id']:r for r in rows(RUN/'before.jsonl')if r['claim_id']in ids};records={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')if r['claim_id']in ids};stats={};case_rows={cid:dict(claim_id=cid,attempts=[])for cid in ids}
 for layout in ['implicit','explicit']:
  current={cid:dict(r,**r['output'])for cid,r in initial.items()}
  for round in[0,1]:
   name=layout+'_'+str(round);path=run/name/'responses.jsonl';saved=rows(path)if path.exists()else[];previous=copy.deepcopy(current)
   for r in saved:
    cid=r['claim_id'];old=previous[cid];ms,sc=request(records[cid],initial[cid],old,previous=old.get('response_raw'),feedback=True)
    if layout=='explicit':
     data=json.loads(ms[1]['content']);data['graph']['triples']=[dict(index=i,triple=t)for i,t in enumerate(data['graph']['triples'])];ms[1]['content']=json.dumps(data,ensure_ascii=False,separators=(',',':'))
    assert ms==r['messages'],(name,cid,'message');out=evaluate(records[cid],old,r['response_raw'],original_graph=initial[cid]['original_graph']);assert json.loads(json.dumps(out))==r['output'],(name,cid,'output');current[cid]={**old,**out,'output':out,'response_raw':r['response_raw']};case_rows[cid]['attempts'].append(dict(condition=name,**r))
   assert json.loads(json.dumps(list(current.values())))==rows(run/(name+'_final.jsonl')),name
   stats[name]=dict(total=12,requests=len(saved),automatic_pass=sum(r['status']=='compiled'for r in current.values()),duplicate_errors=sum(r.get('reason')=='Repeated node declarations or repeated triples.'for r in current.values()),remaining=dict(Counter(r.get('code')for r in current.values()if r['status']!='compiled')))
 dump(run/'summary.json',dict(conditions=stats,model_requests=sum(x['requests']for x in stats.values()),policy='Paired development12, same model/system prompt, one retry; explicit index annotations are the only input-format change. No expansion or parser pooling.'))
 dump(run/'cases.json',list(case_rows.values()));print('All48pilot messages/results replay exactly; explicit indices produce0newpasses.')
if __name__=='__main__':main()
