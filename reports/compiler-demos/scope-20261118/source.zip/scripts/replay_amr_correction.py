"""Recreate every message/edit/result from frozen local responses, without an LLM."""
import copy,json
from prepare_amr_correction import RUN,rows
from run_amr_correction import prepare
from probabilistic_verification.amr_correction import request,evaluate,graph_data

def main():
 expected=(RUN/'before.jsonl').read_bytes();records,initial=prepare();assert expected==(RUN/'before.jsonl').read_bytes()
 base={cid:dict(r,**r['output'])for cid,r in initial.items()}
 def replay(previous,name,guided):
  out=copy.deepcopy(previous);path=RUN/name/'responses.jsonl'
  if not path.exists():return out
  for r in rows(path):
   cid=r['claim_id'];old=previous[cid];assert old['status']!='compiled'and old.get('code')!='model_refuse'
   messages,schema=request(records[cid],initial[cid],old,previous=old.get('response_raw'),feedback=guided);assert messages==r['messages'],(name,cid,'message');assert graph_data(old['normalised_amr'])==r['previous_graph']
   actual=evaluate(records[cid],old,r['response_raw'],original_graph=initial[cid]['original_graph']);assert json.loads(json.dumps(actual))==r['output'],(name,cid,'output')
   out[cid]={**old,**actual,'output':actual,'response_raw':r['response_raw']}
  return out
 first=replay(base,'first',True);assert json.loads(json.dumps(list(first.values())))==rows(RUN/'first_final.jsonl')
 for branch in ['feedback','generic']:
  final=copy.deepcopy(first)
  for i in[1,2]:final=replay(final,branch+'_'+str(i),branch=='feedback')
  assert json.loads(json.dumps(list(final.values())))==rows(RUN/(branch+'_final.jsonl')),branch
 print('All saved messages, graph edits, checks and final conditions reproduce exactly; zero model calls.')
if __name__=='__main__':main()
