"""Choose a reproducible audit of provisional parses with source diversity."""
import hashlib
import json
from collections import Counter, defaultdict

from run_compiler_coverage import RUN as COVERAGE, INPUTS, rows, dump

RUN = COVERAGE.with_name('compiler_scope_20261118')
QUOTAS = {
    'advisory_checks': 12, 'amr_unresolved_complement': 7,
    'amr_reentrancy': 7, 'amr_annotated_coordination': 4, 'earlier_srl': 2,
}


def main():
    corpus = rows(COVERAGE / 'corpus.jsonl')
    inputs = {r['claim_id']: r for r in rows(INPUTS)}
    strata = defaultdict(list)
    for row in corpus:
        if row['category'] in QUOTAS:
            strata[row['category']].append(row)
    selected = []
    video_counts = Counter()
    topics = Counter()
    for category in reversed(QUOTAS):
        candidates = strata[category].copy()
        for _ in range(QUOTAS[category]):
            def key(row):
                cid = row['claim_id']
                active = inputs[cid]['source_videos']
                return (sum(video_counts[v] for v in active), topics[cid.rsplit('_', 1)[0]],
                        hashlib.sha256(f'scope-audit-v1:{cid}'.encode()).hexdigest())
            row = min(candidates, key=key)
            candidates.remove(row)
            cid = row['claim_id']
            selected.append(dict(
                claim_id=cid, text=row['text'], category=category, stage=row['chosen_stage'],
                source_videos=inputs[cid]['source_videos'], output=row['output'],
                baseline_attempts=row['baseline_attempts'],
            ))
            video_counts.update(inputs[cid]['source_videos'])
            topics[cid.rsplit('_', 1)[0]] += 1
    RUN.mkdir(exist_ok=True)
    dump(RUN / 'sample.json', dict(
        quotas=QUOTAS, population={k: len(v) for k, v in strata.items()},
        seed='scope-audit-v1', source_groups=len(video_counts), sample=selected,
    ))
    for n, row in enumerate(selected, 1):
        output = row['output']
        print(n, row['claim_id'], row['category'], row['text'])
        print(' checks', output.get('code'), [e['code'] for e in output.get('errors', []) + output.get('shared_checks', [])])
        form = output['compilation']
        print(' scopes', [(n, v['kind']) for n, v in form['metadata'].get('scopes', {}).items()])
        for atom in form['atoms']:
            args = atom['arguments']
            scope = args[args.index('scope') + 1] if 'scope' in args else '?'
            end = min([args.index(k) for k in ('scope', 'context_owner', 'route') if k in args] or [len(args)])
            if atom['predicate'] in {'reference', 'temporal', 'grammatical_number'}: continue
            print(' ', scope, atom['predicate'], ', '.join(args[:end]))
        print()


if __name__ == '__main__':
    main()
