"""Extract fixed source frames for manual verification of binding edits."""
import hashlib
import json

import cv2

from run_compiler_scope_repairs import RUN
from prepare_compiler_fallback import ROOT

VIDEO_DIR = ROOT.parent / 'data/extracted/microvent/videos'
TIMES = {
    'AHROLHmgvOS9veQ2': [0.8],
    'J2vYKin5lPXfBgGb': [4.20, 32.43],
    'M2dVSDPilbnrmb73': [57.92],
    'gzD8zHnzVeSzQ0lX': [34.77],
    'c0zHs25t-Ied7wyr': [3.87, 6.87, 12.83],
    'zlD_zgNiYJkRV1PS': [2.0, 5.0],
}


def main():
    folder = RUN / 'media'
    folder.mkdir(parents=True, exist_ok=True)
    entries = []
    for source, times in TIMES.items():
        path = VIDEO_DIR / f'{source}_0000.mp4'
        assert path.exists(), path
        with path.open('rb') as media_file:
            video_sha = hashlib.file_digest(media_file, 'sha256').hexdigest()
        cap = cv2.VideoCapture(str(path))
        try:
            fps = cap.get(cv2.CAP_PROP_FPS)
            assert fps > 0, source
            for time in times:
                index = round(time * fps)
                cap.set(cv2.CAP_PROP_POS_FRAMES, index)
                success, frame = cap.read()
                assert success, (source, time)
                filename = f'{source}_{time:.2f}.png'
                assert cv2.imwrite(str(folder / filename), frame)
                digest = hashlib.sha256((folder / filename).read_bytes()).hexdigest()
                entries.append(dict(source_video=source, clip=path.name, video_sha256=video_sha,
                                    requested_seconds=time, frame_index=index,
                                    frame_seconds=round(index / fps, 5), image=filename, image_sha256=digest))
        finally:
            cap.release()
    (RUN / 'media_manifest.json').write_text(json.dumps(entries, indent=2) + '\n')
    print('Extracted', len(entries), 'fixed, hashed reference frames.')


if __name__ == '__main__':
    main()
