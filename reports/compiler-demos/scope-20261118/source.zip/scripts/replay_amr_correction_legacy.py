"""Run the unchanged default AMR and legacy original/rewrite regressions."""
from prepare_amr_correction import RUN
import check_amr_refinement_regression as regression
if __name__=='__main__':
 regression.RUN=RUN
 regression.main()
