"""Parse the frozen external texts; compiler evaluation is deliberately separate."""
import hashlib
import json
from pathlib import Path
import sys

from probabilistic_verification.parsing import DependencyParser

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT/'exp/probabilistic_verification/amr_contexts_20261118'


def main():
    refs = RUN/'external_references.json'
    manifest = json.loads((RUN/'external_reference_manifest.json').read_text())
    assert hashlib.sha256(refs.read_bytes()).hexdigest() == manifest['sha256']
    records = json.loads((RUN/'external_claims.json').read_text())
    parser = DependencyParser()
    for r in records:
        doc = parser.pipeline(r['text']); tokens = []; offset = 0
        for sentence in doc.sentences:
            tokens += [dict(id=w.id+offset, text=w.text, lemma=w.lemma, upos=w.upos,
                           head=w.head+offset if w.head else 0, deprel=w.deprel,
                           start_char=w.start_char, end_char=w.end_char, feats=w.feats)
                       for w in sentence.words]
            offset += len(sentence.words)
        r.update(tokens=tokens, sentences=len(doc.sentences))
    (RUN/'external_inputs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records))
    (RUN/'external_parser.json').write_text(json.dumps(parser.provenance,indent=2)+'\n')
    print('Prepared 20 dependency parses; no compiler output inspected.',flush=True)


if __name__ == '__main__':
    main()
