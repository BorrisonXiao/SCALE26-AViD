"""Actual selected programs, constructed evidence, and explicit parse abstention."""
import argparse,json,subprocess,sys,time
from dataclasses import replace
from prepare_compiler_fallback import ROOT,RUN,rows,dump
from probabilistic_verification.compiler_fallback import restore,verify
CASES=[('Tg0UxWYuPeJ0_385','unknown'),('TFOEIehBwT8Q_535','unknown'),('TFOEIehBwT8Q_535','ocr'),('TFOEIehBwT8Q_535','speech'),('TFgw4IaR9R8s_1664','missing_modal'),('TFgw4IaR9R8s_1664','scoped_support'),('T3HTSBW42QaY_760','unknown')]

def worker(cid,mode):
    from probabilistic_verification.logic import Evidence,Observation,ground
    from probabilistic_verification.direct_backend import DirectVerifier
    from probabilistic_verification.compact_backend import compact_prolog_program
    from probabilistic_verification.ordered_circuit import OrderedSolver
    from probabilistic_verification.multimodal import eligible_evidence
    result=next(r for r in rows(RUN/'corpus.jsonl')if r['claim_id']==cid);assert result['parsing_status']=='compiled'
    claim=restore(result['output']['compilation']);route='ocr_assertion'if mode=='ocr'else'speech_assertion'if mode=='speech'else'unspecified'
    e=Evidence('constructed',{v.name:['placeholder:'+v.name]for v in claim.variables},{v.name:True for v in claim.variables},{},route)
    initial=ground(claim,e,max_expansions=3000);atoms={a.id:a for a in claim.atoms};obs={}
    for occurrence in initial.occurrences:
        old=initial.observations[occurrence['observation_id']];atom=atoms[occurrence['atom_id']]
        support=mode!='unknown'and not(mode=='missing_modal'and atom.predicate=='qualification')
        obs[old.key]=replace(old,distribution=(1.,0.,0.)if support else(0.,0.,1.),available=support)
    e=replace(e,observations=obs)
    if mode in{'ocr','speech'}:
        # Generic untyped conditions permit either source here; exact written
        # strings retain their declared OCR-only policy.
        allowed={a.id:({'ocr_assertion','speech_assertion'}if claim.metadata['allowed_routes'].get(a.id)==['unspecified']else set(claim.metadata['allowed_routes'][a.id]))for a in claim.atoms}
        e=eligible_evidence(claim,e,allowed)
    gp=ground(claim,e,max_expansions=3000);model=DirectVerifier([gp],learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver)
    start=time.perf_counter();actual=model.predict()[0]['distribution'];expected=dict(supported=1.,refuted=0.,unknown=0.)if mode in{'ocr','scoped_support'}else dict(supported=0.,refuted=0.,unknown=1.)
    assert all(abs(actual[k]-expected[k])<1e-9 for k in expected),(cid,mode,actual,expected)
    print(json.dumps(dict(claim_id=cid,stage=result['selected_stage'],mode=mode,native=True,observations=len(gp.observations),program_sha256=result['output']['program_sha256'],seconds=time.perf_counter()-start,distribution=actual,expected=expected,matches=True)))

def main():
    p=argparse.ArgumentParser();p.add_argument('--worker');p.add_argument('--mode');a=p.parse_args()
    if a.worker:worker(a.worker,a.mode);return
    outputs=[]
    for cid,mode in CASES:
        result=subprocess.run([sys.executable,__file__,'--worker',cid,'--mode',mode],cwd=ROOT,capture_output=True,text=True,timeout=25)
        assert result.returncode==0,result.stdout+result.stderr
        outputs.append(json.loads(next(s for s in reversed(result.stdout.splitlines())if s.startswith('{'))))
    failed=next(r for r in rows(RUN/'corpus.jsonl')if r['parsing_status']=='abstained')
    def forbidden(_):raise AssertionError('No evidence inference may run without a program.')
    abstention=verify(failed,forbidden);assert abstention['verdict']=='abstain'and abstention['distribution']is None
    dump(RUN/'native_checks.json',dict(rows=outputs,parse_policy=abstention,policy='Seven native controls on four actual programs, constructed observations and placeholder candidates. One separate parsing-abstention policy check. No real media or training.'))
    print('Seven native controls and separate parsing-abstention policy pass.')
if __name__=='__main__':main()
