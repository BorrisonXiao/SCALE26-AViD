"""Record the coverage milestone in the existing checklist and project memory."""
import json

from prepare_compiler_fallback import dump
from run_compiler_coverage import ROOT, RUN


def append_once(path, heading, body):
    current = path.read_text()
    if heading not in current:
        path.write_text(current.rstrip() + f'\n\n{heading}\n\n{body}\n')


def main():
    stats = json.loads((RUN / 'summary.json').read_text())
    review = json.loads((RUN / 'audit.json').read_text())
    semantic = stats['semantic_programs']
    missing = stats['total'] - semantic
    percent = 100 * semantic / stats['total']
    strict = stats['strict_after_repairs']
    checked = review['checked_forms']
    groups = review['checked_source_groups']
    proof = json.loads((RUN / 'validation.json').read_text())
    run_name = RUN.relative_to(ROOT)

    measurement = (f'The coverage experiment produces {semantic:,}/2,375 semantic programs ({percent:.2f}%). '
                   f'{missing} more claims produce only dependency analyses. Earlier strict checks pass 2,177, '
                   f'and targeted repairs bring that count to {strict:,}. Allowing already generated programs '
                   'with warnings alone gives 2,280. Advisory outputs require review before evidence inference.')
    notes = f"""# Compilation coverage with advisory checks

{measurement}

## Conditions compared

The experiment starts with the saved strict SRL → AMR → rewrite results. On its 198
abstentions, it attempts source-licensed repairs and can reuse a previously rejected
program when the program itself is executable. It then attempts structured AMR
repairs and an earlier SRL converter, using the same cached annotations.

- Exact quotations attach to a visible overlay, written carrier or depicted tweet. The
  quoted words stay literal. The model had parsed some of those words as independent events.
- A source-linked “imply that” keeps an implied proposition under the original frame.
  An omitted or passive subject in a media description can still introduce a visual context.
- An unresolved AMR complement retains its parent, role and embedded content.
  Annotated AND/OR groups keep their shared conditions on the whole group. Explicit
  graph references may point to an event introduced in an enclosing scope.
- Questions keep the AMR truth-value context and commands keep directive scope.
  The representation of polar questions follows the [AMR annotation guidelines](https://github.com/amrisi/amr-guidelines/blob/master/amr.md).
- The earlier SRL converter yields two provisional programs for cases still unresolved.
  Its pier/terminal example demonstrates the cost of relaxing requirements: OR is lost.
- A dependency analysis preserves source words and grammatical attachments for the final
  {missing} claims. Subjects, objects and modifiers still need semantic interpretation.

The {semantic:,} count measures predicate and argument program generation. It includes
{semantic - strict} provisional programs. The 2,375 count that includes dependency analyses measures
availability of an inspectable structure. Fidelity is assessed in the example review. The earlier
retained pool is preserved in History. No empirical training or media evaluation took place.

## Review and preparation

The audit contains {review['reviewed_example_count']} inspected examples and a separate diagnosis
of each of the {missing} remaining failures. Reentry across event scopes is the most common final
stop. Negation, duplicate roles and coordination account for other cases. Some AMR graphs omit
conditions or introduce incorrect relations even when their programs execute.

An advisory rule for a missing request context flags one case in the existing 20-text
external diagnostic and zero in the corpus. The flagged external case says someone called
for a boycott. The selected SRL output lacks an explicit request. The rule does not alter routing.

The preparation export contains {checked} forms reviewed against their source wording across {groups}
source groups. It carries the exact form and hash and leaves evidence labels for later inspection.
The automatic test inventory includes all 2,375 claims. These groups can guide source-disjoint
selection before training.

## Validation and reproduction

All {proof['newly_grounded_programs']} newly selected programs load and ground in ProbLog
with placeholder evidence. The {proof['quote_programs_unknown_with_no_observations']} exact quotation
programs were also evaluated with no observations and return unknown.
{proof['review_required_skip_verifier']} provisional selections skip evidence inference in the coverage
adapter. All {proof['strict_program_hashes_match']:,} original strict selections retain their saved
program hashes. The run uses CPU and cached parser and rewrite annotations.

From the extracted source bundle with the existing compiler Python dependencies and WordNet data:

```bash
python scripts/run_compiler_coverage.py
python scripts/audit_compiler_coverage.py
python scripts/validate_compiler_coverage.py
PYTHONPATH=scripts:tests python -m pytest -q tests/test_compiler_coverage.py
```

Compare regenerated artifacts with `REPLAY_SHA256.json`. Unchanged strict selections refer to
the published prior run, and the bundle carries the required fields for this comparison.

## Next work

1. Resolve nested event references and branch-specific conditions to recover more of
   the remaining semantic programs.
2. Review provisional programs by source group and construction to estimate meaning
   preservation and improve warnings on misleading primary parses.
3. Inspect evidence labels and prepare source-disjoint binding contrasts to test the small
   relation models once training is ready.
"""
    (ROOT / 'docs/compiler_coverage_20261118.md').write_text(notes)
    checklist_path = ROOT / 'exp/probabilistic_verification/av_features_20261022/checklist.json'
    checklist = json.loads(checklist_path.read_text())
    checklist['compiler_coverage_run'] = str(run_name)
    for step in checklist['steps']:
        if step['id'] == 35:
            step['status'] = 'coverage experiment complete'
            step['items'] = [
                dict(text=measurement, done=True),
                dict(text=f'Reviewed all {missing} remaining semantic failures and {review["reviewed_example_count"]} examples. '
                          'Tested a narrow advisory check on requests.', done=True),
                dict(text=f'Exported {checked} reviewed logical forms with source groups and the full 2,375-claim test inventory.', done=True),
            ]
    if not any(step['id'] == 36 for step in checklist['steps']):
        checklist['steps'].append(dict(id=36, title='Resolve remaining scopes and prepare binding evidence',
                                       status='planned', items=[
            'Resolve event references and OR branches. Goal: compile more of the remaining claims with the correct scope.',
            'Review warnings by source group. Goal: estimate meaning preservation and catch misleading primary passes.',
            'Inspect source-disjoint evidence labels and binding edits. Goal: prepare controls for relation learning.',
        ]))
    dump(checklist_path, checklist)
    log_path = ROOT / 'docs/project_notes/daily_log.json'
    log = json.loads(log_path.read_text())
    day = next(day for day in log['days'] if day['date'] == '2026-11-18')
    day['items'] = [item for item in day['items'] if not item.get('coverage_entry')]
    day['items'] += [
        dict(text=measurement, href='#remaining-failures', label='Coverage comparison', coverage_entry=True),
        dict(text=f'Audited all {missing} remaining semantic failures and prepared {checked} reviewed forms plus the full test inventory.',
             href='#coverage-examples', label='Repairs and failure patterns', coverage_entry=True),
    ]
    dump(log_path, log)

    title = '## Advisory compilation checks — 18 November 2026'
    entry = ('The user prioritized executable compilation coverage of at least 99% and authorized relaxing '
             'automatic checks and testing repairs directly. ' + measurement +
             f' Reviewed {review["reviewed_example_count"]} examples and all {missing} remaining failures. '
             f'Exported {checked} development-reviewed forms in {groups} source groups and the complete test inventory. '
             'Cached annotations only. No training. Read docs/compiler_coverage_20261118.md.')
    for name in ('AGENTS.md', 'CLAUDE.md'):
        path = ROOT / name
        text = path.read_text()
        if title not in text:
            headed, rest = text.split('\n', maxsplit=1)
            path.write_text(headed + f'\n\n{title}\n\n{entry}\n' + rest)
    heading = '### 2026-11-18 — Advisory compilation checks and wider program coverage'
    for name in ('decisions.md', 'key_facts.md', 'issues.md'):
        append_once(ROOT / 'docs/project_notes' / name, heading,
                    entry + f' Outputs at `{run_name}`. Next work is cross-context scope repairs, '
                    'fidelity review of provisional programs, and source-disjoint evidence labels.')
    append_once(ROOT / 'docs/project_notes/bugs.md',
                '### 2026-11-18 — Quotation boundaries and AMR polarity questions',
                'Punctuation inside a long quotation made the parser treat quoted clauses as separate claims. '
                'For explicit written carriers, preserve the entire exact source span and retain any visible/cut-off condition. '
                'An AMR truth-value node in the polarity role denotes a question reading. '
                'Compile it as embedded content and preserve ordinary negative polarity separately.')
    print(measurement)


if __name__ == '__main__':
    main()
