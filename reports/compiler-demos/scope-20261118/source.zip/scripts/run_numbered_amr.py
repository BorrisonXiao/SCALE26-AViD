"""Small paired input-format diagnostic; original source and prompt are unchanged."""
import copy,hashlib,importlib.metadata,json,os,time
from prepare_amr_correction import ROOT,RUN,rows,dump
from probabilistic_verification.amr_correction import request,evaluate,graph_data

def write(p,data):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in data))
def main():
 os.environ.setdefault('VLLM_WORKER_MULTIPROC_METHOD','spawn');run=RUN/'numbered_pilot';run.mkdir(exist_ok=True)
 initial={r['claim_id']:r for r in rows(RUN/'before.jsonl')if r['cohort']=='development'and r['output']['status']!='compiled'};initial=dict(list(initial.items())[:12]);assert len(initial)==12
 dump(run/'selection.json',dict(ids=list(initial),policy='First12 eligible known development failures; no follow-up expansion. Compare implicit array indices with explicit indices under the same model/system prompt, one first attempt plus one feedback retry. No per-claim selection.'))
 records={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')if r['claim_id']in initial}
 import torch
 from transformers import AutoTokenizer
 from vllm import LLM,SamplingParams
 from vllm.sampling_params import StructuredOutputsParams
 torch.set_num_threads(4);path='/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507';tok=AutoTokenizer.from_pretrained(path,local_files_only=True);model=LLM(model=path,tokenizer=path,dtype='float16',tensor_parallel_size=2,gpu_memory_utilization=0.90,max_model_len=16384,max_num_seqs=4,enable_prefix_caching=True,seed=0)
 dump(run/'config.json',dict(model=path,dtype='float16',temperature=0,seed=0,tensor_parallel=2,max_new_tokens=1536,max_edits=8,max_retries=1,system_prompt_unchanged=True,job_id=os.getenv('SLURM_JOB_ID'),vllm=importlib.metadata.version('vllm'),gpus=[torch.cuda.get_device_name(i)for i in range(torch.cuda.device_count())]))
 for numbered in [False,True]:
  label='explicit'if numbered else'implicit';current={cid:dict(r,**r['output'])for cid,r in initial.items()}
  for round in[0,1]:
   folder=run/(label+'_'+str(round));folder.mkdir(exist_ok=True);saved=[];pending=[r for r in current.values()if r['status']!='compiled'and r.get('code')!='model_refuse']
   for start in range(0,len(pending),4):
    batch=pending[start:start+4];messages=[];params=[]
    for old in batch:
     cid=old['claim_id'];ms,sc=request(records[cid],initial[cid],old,previous=old.get('response_raw'),feedback=True)
     if numbered:
      data=json.loads(ms[1]['content']);data['graph']['triples']=[dict(index=i,triple=t)for i,t in enumerate(data['graph']['triples'])];ms[1]['content']=json.dumps(data,ensure_ascii=False,separators=(',',':'))
     messages.append(ms);params.append(SamplingParams(temperature=0,max_tokens=1536,structured_outputs=StructuredOutputsParams(json=sc,disable_any_whitespace=True)))
    prompts=[tok.apply_chat_template(m,tokenize=False,add_generation_prompt=True)for m in messages];t=time.perf_counter();outs=model.generate(prompts,params,use_tqdm=False);elapsed=time.perf_counter()-t
    for old,ms,z in zip(batch,messages,outs):
     q=z.outputs[0];cid=old['claim_id'];out=evaluate(records[cid],old,q.text,original_graph=initial[cid]['original_graph']);saved.append(dict(claim_id=cid,text=old['text'],messages=ms,response_raw=q.text,previous_graph=graph_data(old['normalised_amr']),output=out,output_tokens=len(q.token_ids),finish_reason=q.finish_reason,batch_seconds=elapsed));current[cid]={**old,**out,'output':out,'response_raw':q.text}
    write(folder/'responses.jsonl',saved);print(label,round,len(saved),'passes',sum(r['status']=='compiled'for r in current.values()),flush=True)
   write(run/(label+'_'+str(round)+'_final.jsonl'),list(current.values()))
 print('Completed paired12-case input-format pilot.',flush=True)
if __name__=='__main__':main()
