"""Rerun all2,375 cached originals with the opt-in source/semantic checks."""
import json,logging,time
from collections import Counter
from prepare_amr_correction import ROOT,RUN,BASE,rows,dump
from probabilistic_verification.amr_correction import inspect

def main():
 logging.getLogger('penman').setLevel(logging.ERROR)
 records=rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl');old={r['claim_id']:r for r in rows(BASE/'corpus.jsonl')};out=[];start=time.perf_counter()
 for r in records:
  x=inspect(r,old[r['claim_id']]['raw']);out.append(x)
  if'program'in x:assert x['program']==old[r['claim_id']]['program'],r['claim_id']
  else:assert old[r['claim_id']]['status']!='compiled',r['claim_id']
 (RUN/'corpus.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n'for r in out))
 s=dict(total=2375,graphs_converted=sum('program'in r for r in out),checks_pass=sum(r['status']=='compiled'for r in out),source_only_previous_pass=1406,new_semantic_flags_on_source_pass=sum('program'in r and not r['compilation']['metadata']['source_checks']and bool(r['compilation']['metadata']['semantic_checks'])for r in out),semantic_issue_counts=dict(Counter(i['code']for r in out if'program'in r for i in r['compilation']['metadata']['semantic_checks'])),conversion_refusals=dict(Counter(r['errors'][-1]['code']for r in out if'program'not in r)),seconds=time.perf_counter()-start,retained_pool=1981,excluded=394,promotions=0,policy='One fixed cached AMR frontend; new checks only. Every generated program is byte-identical to the preceding refined compiler. Checks are not semantic accuracy; no per-claim parser selection.')
 dump(RUN/'corpus_summary.json',s);print(json.dumps(s,indent=2))
if __name__=='__main__':main()
