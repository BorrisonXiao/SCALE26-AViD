"""Record completed measurements and keep proposed work separate."""
import json
from prepare_compiler_fallback import ROOT, RUN


def append_once(path, marker, text):
    value = path.read_text()
    if marker not in value:
        path.write_text(value.rstrip() + '\n\n' + text.strip() + '\n')


def main():
    s = json.loads((RUN / 'summary.json').read_text())
    selected = s['selected']; ar = s['addition_reviews']; n = s['automatic_compiled']
    completed = f'''Completed: {n:,}/2,375 automatic check passes, {s['parsing_abstentions']} parsing abstentions; selected {selected['srl']:,} SRL/{selected['amr']} AMR/{selected['rewrite']} rewrites. All 183 original AMR candidates audited:42 full matches / 83 partial / 45 incorrect / 13 context-needed. Final AMR additions: {ar['amr']['whole_readings']}; rewrite additions: {ar['rewrite']['whole_readings']}. These are self-reviewed development readings, not whole-corpus accuracy; existing SRL passes are not fully reviewed. No review-based routing or pool promotion. Eight previously uncached failure-only Qwen responses completed on one A100-80GB; all jobs ended (883 GPU seconds including cancelled loading, peak 1).640 tests, seven native controls and default typed/originalAMR/SRL/rewrite regressions pass. Parsing abstention never invokes media inference and is distinct from insufficient evidence. No empirical training. Main report: compiler-demos.html; old retained 1,981 pool under History. Next proposed: participant/noun-binding repairs; checks for incorrect primary passes; checked logical forms plus a complete automatic test before relation training. See docs/compiler_fallback_20261118.md.'''
    for name in ['AGENTS.md', 'CLAUDE.md']:
        path = ROOT / name; text = path.read_text()
        old = 'Current work: `compiler_fallback_20261118`. Baseline 183 potential AMR recoveries audited: 42 matches, 83 partial, 45 incorrect, 13 context-needed; 145 fresh assistant inspections plus 38 exact-output prior reviews. These are development judgments, not independent gold or full-corpus accuracy. Final implementation/results/publication will be recorded when validated.'
        assert old in text or completed in text
        path.write_text(text.replace(old, completed))
    heading = '### 2026-11-18 — Fixed SRL/AMR fallback, full audit and parsing abstention'
    text = f'''{heading}

| Run | Inputs | Automatic check passes | Selected SRL / AMR / rewrite | Parsing abstentions | Validation |
|---|---|---|---|---|---|
| compiler_fallback_20261118 |2,375 originals;20 external diagnostics |{n:,}/2,375 ({100*n/2375:.2f}%) |{selected['srl']:,} / {selected['amr']} / {selected['rewrite']} |{s['parsing_abstentions']} |640 tests;7 native controls;defaults exact |

**Scope and fidelity:** Accepted fixed failure-only sequence supersedes prior no-pooling comparison restriction; ADR-023 unchanged. Runtime uses automatic checks, never review labels/media/gold. Baseline183 self-reviews:42 matches / 83 partial / 45 incorrect / 13 context-needed (145 fresh, 38 exact-output reuse). Final AMR {ar['amr']['whole_readings']}; final rewrite {ar['rewrite']['whole_readings']}. Existing SRL passes not fully reviewed; this is not semantic accuracy or human approval. Previously seen 20 AVeriTeC texts yield 13 automatic selected programs/four whole matches; source labels/evidence unused. Retained 1,981 pool stays unchanged, zero promotions.

**Changes:** Exact carrier-bound written quotations including inverse-role modifiers; source-qualified would without guessed subtype; explicit generic/universal/implication guards; official frame/source sense rules and better named/person-role number alignment. Bounded rewrite only after both strict failures. Every input retained in evaluation; parse abstention has no program/evidence distribution and never calls verifier. Unknown media evidence remains a different outcome.

**Preparation/cost:** Eight fresh Qwen3-30B-A3B-Instruct-2507 responses under same frozen historical prompt/schema/settings, then25 CPU dependency/SRL component parses. Fresh CPU frozen BERT-SRL on 20 external texts. One A100-80GB peak;883allocated GPU seconds=0.2453hours including cancelled loading;8actual responses;all project jobs ended. Primary corpus replay calls no models. No GPTjudge/retraining/media inference/empirical relation training.

**Reproduction:** docs/compiler_fallback_20261118.md; exp/probabilistic_verification/compiler_fallback_20261118 includes exact183reviews, all final additions, failed8responses/reviews, both original stage errors, native/check proofs,75-filecompiler freeze and input hashes. Clean archive/browser/publication proofs recorded separately after validation. Old default typed2,375/originalAMR 2,375/SRL 2,375/rewrite 449 exact. Preserve all 64 old ZIP/viewer files. Five views/two cards; All claims now fixed sequence, old retained pool under History.

**Analysis and proposed next goals:** Automatic fallback recovers detected failures but cannot replace a semantically wrong primary pass. Shared participant/noun senses and qualified contexts remain major weaknesses; generic quantification needs a real representation, not removed guards. Improve faithful bindings and primary checks before relation training; prepare checked forms while all automatic test claims remain counted.
'''
    append_once(ROOT / 'docs/project_notes/key_facts.md', heading, text)
    append_once(ROOT / 'docs/project_notes/bugs.md', '### 2026-11-18 — Source qualification and quotation normalization', '''### 2026-11-18 — Source qualification and quotation normalization
- **Issue:** AMR could turn written slogans into actual return/state events, lose main-clause would, and borrow plurality from unrelated people for named Trump/narrator entities.
- **Cause:** Quoted subtree traversal omitted inverse-role modifiers; source-only qualification was not retained; person matching preceded exact-name/role alignment. Treating any quotation as an inscription also overrejected ordinary quoted statements.
- **Fix:** Opt-in fallback normalizes uniquely linked written carriers using source spans plus declared graph subtree, includes inverse roles, protects literals, retains would context and rejects ambiguous embedded scope. Exact names/role nouns take priority. Generic/implication checks prevent unsupported existential/AND replacements.
- **Validation/limits:**640 tests (33fallback/source), seven native controls, unchanged defaults. Caller passes/errors and meaning reviews remain separate. Eight new rewrites still reveal duplication, range misreadings and unresolved proposition references. General quantifiers, arbitrary noun senses and faithful neural parsing remain unresolved.
''')
    append_once(ROOT / 'docs/project_notes/issues.md', heading, f'''{heading}
- **Status:** Implementation and experiments complete; publication verification recorded separately. {n:,}/2,375 automatic passes; {s['parsing_abstentions']} explicit parsing abstentions.640 tests/seven native controls/defaults pass. See docs/compiler_fallback_20261118.md.
- **Remaining:** Incorrect automatic primary passes block fallback; extra AMR/rewrite outputs often partial. No end-to-end semantic accuracy or training readiness claim. All eight previously uncached rewrites attempted; inspect exact requests/responses and failed components in All claims.
- **Next proposed:** Participant/noun-binding repairs to recover meaning; primary-output checks to expose false passes; checked logical forms and full automatic test to separate learning from parsing coverage. No empirical relation training yet.
''')
    print('Recorded completed results, limits, resources and proposed goals.')


if __name__ == '__main__':
    main()
