"""Regression coverage for graph declaration order and conditional scope."""
from collections import Counter

import penman
from penman.models.amr import model

from probabilistic_verification.compiler_scope_repairs import (
    place_condition_declaration, preserve_ancestor_bindings, source_scope_graph,
)
from probabilistic_verification.logical_form_v2 import ScopedClaim
from probabilistic_verification.representation import Atom, Expression as E, Variable


def test_declaration_move_preserves_all_roles():
    raw = '(a / mean-01 :ARG1 (r / ruling :ARG1-of (o / overturn-01 :polarity -)) :implication (n / need-01 :condition o))'
    changed, trace = place_condition_declaration(raw)
    assert ':condition (o / overturn-01' in changed
    assert trace == [{'condition': 'o', 'owner': 'n', 'referent': 'r', 'role': ':ARG1'}]
    assert Counter(penman.decode(raw, model=model).triples) == Counter(penman.decode(changed, model=model).triples)


def test_nested_negation_uses_bound_referent():
    atom = Atom('a1', 'reference', ('X1', 'scope', 'c1', 'route', 'unspecified'),
                'reference', (), '', (), False)
    claim = ScopedClaim('id', '', (), (Variable('X1', 'entity', 'ruling', ()),), (atom,),
                        E.exists(['X1'], E.negate(E.exists(['X1'], E.atom('a1')))), ())
    result = preserve_ancestor_bindings(claim)
    assert result.expression == E.exists(['X1'], E.negate(E.atom('a1')))
    assert result.metadata['ancestor_bindings_preserved'] == ['X1']


def test_branch_condition_preserves_alternatives_and_actor():
    raw = '''(n / note-01 :ARG1 (p / possible-01
                :ARG1 (v / vote-01 :ARG0 (c / citizen)
                        :time (o / or :op1 (d / day) :op2 (b / ballot :mod (m / mail))))
                :condition (g / outside :ARG1 c)))'''
    tokens = [dict(id=1, lemma='ballot', deprel='conj', head=0),
              dict(id=2, lemma='or', deprel='cc', head=1),
              dict(id=3, lemma='outside', deprel='advcl', head=1),
              dict(id=4, lemma='if', deprel='mark', head=3)]
    output, edits = source_scope_graph(dict(text='People may vote today or by mail-in ballot if outside.', tokens=tokens), raw)
    graph = penman.decode(output, model=model)
    assert edits[0]['kind'] == 'condition on final alternative'
    assert ('v', ':time', 'd') in graph.triples
    assert ('voption1', ':instrument', 'b') in graph.triples
    assert ('voption1', ':condition', 'g') in graph.triples
    assert {s for s, r, t in graph.triples if r == ':condition'} == {'voption1'}
    assert {s for s, r, t in graph.triples if (r, t) == (':ARG0', 'c')} == {'v', 'voption1'}
