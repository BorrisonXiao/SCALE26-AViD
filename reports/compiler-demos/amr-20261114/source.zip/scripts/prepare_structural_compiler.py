"""Freeze a balanced 40-case structural-repair diagnostic before model outputs."""
import copy,hashlib,json
from collections import Counter
from pathlib import Path
from prepare_compiler_feedback import ROOT,freeze
from probabilistic_verification.compiler_feedback import current_form
from probabilistic_verification.partial_parse import capture
RUN=ROOT/'exp/probabilistic_verification/compiler_structural_20261113'
OLD=ROOT/'exp/probabilistic_verification/compiler_feedback_20261112'
def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def main():
 RUN.mkdir(parents=True,exist_ok=True)
 (RUN/'preserved_archives.json').write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in(ROOT/'site').rglob('*.zip')},indent=2)+'\n')
 direct=read(OLD/'direct_all.jsonl');inputs={r['claim_id']:r for r in read(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')};remaining={r['claim_id']for r in json.loads((OLD/'remaining_cases.json').read_text())};rows=[];groups={'existing_draft':[],'partial_capture':[]};absent=[]
 for row in direct:
  if row['claim_id']not in remaining or row['status']=='compiled':continue
  r=copy.deepcopy(row);draft=current_form(r)
  if draft:r['draft_source']='existing_draft'
  else:
   r.update(capture(inputs[r['claim_id']]));draft=r['partial_form'];r['draft_source']='partial_capture'
  if draft:groups[r['draft_source']].append(r)
  else:absent.append(r['claim_id'])
  rows.append(r)
 write(RUN/'failed_drafts.jsonl',rows)
 selected=[]
 motivating=['Tg0UxWYuPeJ0_433','Tg0UxWYuPeJ0_378','TFOEIehBwT8Q_517','TQEmEycTI0RQ_822','TMrQshDs8aH0_745','Txf2EdqOg1SQ_2176','Txf2EdqOg1SQ_2168','TInVWzp25aIM_68']
 for name,group in groups.items():
  picked=[r for cid in motivating for r in group if r['claim_id']==cid]
  buckets={}
  for r in group:
   if r in picked:continue
   buckets.setdefault(r.get('code'),[]).append(r)
  for bucket in buckets.values():bucket.sort(key=lambda r:hashlib.sha256(r['claim_id'].encode()).hexdigest())
  while len(picked)<min(20,len(group)):
   for code in sorted(buckets):
    if buckets[code]and len(picked)<20:picked.append(buckets[code].pop(0))
  selected+=picked
 write(RUN/'selected_drafts.jsonl',selected);write(RUN/'inputs.jsonl',[inputs[r['claim_id']]for r in selected])
 summary=dict(total=2375,baseline_retained=1981,excluded=394,strict_failures=len(rows),existing_drafts=len(groups['existing_draft']),new_partial_drafts=len(groups['partial_capture']),still_without_draft=len(absent),no_draft_ids=absent,selected=len(selected),selected_groups=dict(Counter(r['draft_source']for r in selected)),selection='Eight named motivating failures where available, then deterministic round-robin by direct error code within each draft group,20 per group. Fixed before model outputs; development diagnostic, not a random accuracy sample.',policy='Strict original failure only. New partial forms always require a model correction; they are never accepted as compiler passes. Up to4 typed edits including logical-subtree replacement; shared first attempt then at most2 feedback/generic retries. No pooling control or previous methods.')
 (RUN/'selection.json').write_text(json.dumps(summary,indent=2)+'\n');freeze(RUN);print(summary,flush=True)
if __name__=='__main__':main()
