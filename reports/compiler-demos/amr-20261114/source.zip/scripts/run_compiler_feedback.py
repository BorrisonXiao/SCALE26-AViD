"""Fixed logical-form correction with compiler-feedback and generic-retry branches."""
import argparse,copy,hashlib,importlib.metadata,json,os,time
from pathlib import Path
import torch,xgrammar as xgr
from transformers import AutoTokenizer,AutoModelForCausalLM
from probabilistic_verification.compiler_feedback import SYSTEM,schema,current_form,request,inspect
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.schema_logits import SchemaLogitsProcessor

def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def main():
 os.environ.setdefault('VLLM_WORKER_MULTIPROC_METHOD','spawn')
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--backend',choices=['transformers','vllm'],default='transformers');p.add_argument('--semantic-checks',action='store_true');p.add_argument('--detailed-feedback',action='store_true');p.add_argument('--control',action='store_true');p.add_argument('--max-retries',type=int,default=2);a=p.parse_args();run=a.run.resolve();root=a.root.resolve();run.mkdir(exist_ok=True,parents=True)
 records=read(a.input);direct={r['claim_id']:compile_one(r)for r in records};eligible=[r for r in records if direct[r['claim_id']]['status']!='compiled'];write(run/'routing.jsonl',[dict(claim_id=r['claim_id'],status=direct[r['claim_id']]['status'],code=direct[r['claim_id']].get('code'))for r in records]);write(run/'inputs.jsonl',eligible)
 if not eligible:return
 amrs={r['request']['task']['claim_id']:r['raw']for i in range(4)for r in read(root/f'exp/probabilistic_verification/full_compilation_20261029/amr_{i}_raw.jsonl')}
 path=Path('/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507');tok=AutoTokenizer.from_pretrained(path,local_files_only=True,padding_side='left');tok.pad_token=tok.eos_token;torch.set_num_threads(4);cfg=json.loads((path/'config.json').read_text())
 grammar=xgr.GrammarCompiler(xgr.TokenizerInfo.from_huggingface(tok,vocab_size=cfg['vocab_size']));schemas={r['claim_id']:schema(r,current_form(direct[r['claim_id']]))for r in eligible};grammars={k:grammar.compile_json_schema(v,any_whitespace=False,separators=(',',':'))for k,v in schemas.items()}
 if a.backend=='vllm':
  from vllm import LLM,SamplingParams
  from vllm.sampling_params import StructuredOutputsParams
  model=LLM(model=str(path),tokenizer=str(path),dtype='float16',tensor_parallel_size=1,gpu_memory_utilization=0.90,max_model_len=32768,max_num_seqs=4,enforce_eager=False,enable_prefix_caching=True,seed=0)
 else:model=AutoModelForCausalLM.from_pretrained(path,local_files_only=True,dtype=torch.float16,attn_implementation='sdpa',device_map='auto',max_memory={0:'74GiB'}).eval()
 config=dict(model=str(path),backend=a.backend+'+xgrammar',dtype='float16',do_sample=False,max_new_tokens=3072,batch_size=2,max_feedback_retries=a.max_retries,control=a.control,detailed_feedback=a.detailed_feedback,semantic_checks=a.semantic_checks,text_only=True,gpus=[torch.cuda.get_device_name(i)for i in range(torch.cuda.device_count())],job_id=os.getenv('SLURM_JOB_ID'),torch=torch.__version__,transformers=importlib.metadata.version('transformers'),model_config_sha256=hashlib.sha256((path/'config.json').read_bytes()).hexdigest(),source=str(Path(__file__).resolve()),eligible=len(eligible),vllm=importlib.metadata.version('vllm')if a.backend=='vllm'else None)
 (run/'config.json').write_text(json.dumps(config,indent=2)+'\n')
 def generate(rows,folder,previous=None,guided=True):
  folder.mkdir(parents=True,exist_ok=True);saved=read(folder/'responses.jsonl')if(folder/'responses.jsonl').exists()else[];done={r['claim_id']for r in saved};rows=[r for r in rows if r['claim_id']not in done]
  for start in range(0,len(rows),2):
   batch=rows[start:start+2];messages=[]
   for record in batch:
    cid=record['claim_id'];prior=previous.get(cid)if previous else None
    data=request(record,direct[cid],schemas[cid],amrs.get(cid),previous=prior['raw']if prior else None,feedback=prior['feedback']if prior and guided else None)
    if prior and not guided:data.pop('compiler_feedback',None);data['instruction']='The previous output failed a compiler check. Revise it carefully while preserving the original claim.'
    messages.append([dict(role='system',content=SYSTEM),dict(role='user',content=json.dumps(data,ensure_ascii=False,separators=(',',':')))])
   text=[tok.apply_chat_template(m,tokenize=False,add_generation_prompt=True)for m in messages];started=time.perf_counter()
   if a.backend=='vllm':
    params=[SamplingParams(temperature=0,max_tokens=3072,structured_outputs=StructuredOutputsParams(json=schemas[r['claim_id']],disable_any_whitespace=True))for r in batch]
    generated=model.generate(text,params,use_tqdm=False);sequences=[(g.outputs[0].text,list(g.outputs[0].token_ids),g.outputs[0].finish_reason)for g in generated]
   else:
    inputs=tok(text,padding=True,return_tensors='pt').to(model.get_input_embeddings().weight.device)
    with torch.inference_mode():outputs=model.generate(**inputs,do_sample=False,num_beams=1,max_new_tokens=3072,logits_processor=[SchemaLogitsProcessor([grammars[r['claim_id']]for r in batch])],pad_token_id=tok.pad_token_id)
    sequences=[]
    for ids in outputs[:,inputs.input_ids.shape[1]:]:
     tokens=ids.tolist()
     if tok.eos_token_id in tokens:tokens=tokens[:tokens.index(tok.eos_token_id)]
     sequences.append((tok.decode(tokens,skip_special_tokens=True),tokens,'length'if len(tokens)>=3072 else'stop'))
   elapsed=time.perf_counter()-started
   for record,m,(raw,tokens,finish)in zip(batch,messages,sequences):
    output,feedback=inspect(record,raw,schemas[record['claim_id']],detailed=a.detailed_feedback,semantic_checks=a.semantic_checks);saved.append(dict(claim_id=record['claim_id'],text=record['text'],messages=m,raw=raw,output=output,feedback=feedback,finish_reason=finish,output_tokens=len(tokens),batch_seconds=elapsed))
   write(folder/'responses.jsonl',saved);print(folder.name,len(saved),'compiled',sum(r['output']['status']=='compiled'for r in saved),'batch_seconds',round(elapsed,2),flush=True)
  return {r['claim_id']:r for r in saved}
 first=generate(eligible,run/'initial');by_record={r['claim_id']:r for r in eligible}
 for branch in ['feedback','generic']if a.control else['feedback']:
  final=copy.deepcopy(first)
  for attempt in range(1,a.max_retries+1):
   failed={cid:r for cid,r in final.items()if r['output']['status']!='compiled'and r['output'].get('code')!='model_refuse'}
   if not failed:break
   result=generate([by_record[cid]for cid in failed],run/(branch+'_'+str(attempt)),failed,guided=branch=='feedback');final.update(result)
  write(run/(branch+'_final.jsonl'),list(final.values()))
 print('Completed all fixed branches.',flush=True)
if __name__=='__main__':main()
