"""CPU replay with each condition's frozen generation-time checker."""
import argparse,copy,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_structural_20261113'
p=argparse.ArgumentParser();p.add_argument('--condition',choices=['development','strict'],required=True);args=p.parse_args();BASE=RUN if args.condition=='development'else RUN/'strict'
sys.path.insert(0,str(BASE/'model_source/scripts'))
from run_structural_compiler import prepare
from probabilistic_verification.structural_edits import evaluate

def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def main():
 names=['before.jsonl','first/responses.jsonl','first_final.jsonl','feedback_final.jsonl','generic_final.jsonl']+[b+'_'+str(i)+'/responses.jsonl'for b in['feedback','generic']for i in[1,2]];old={n:(BASE/n).read_bytes()for n in names};records,initial,schemas=prepare(BASE)
 def replay(folder,previous):
  rows=read(BASE/folder/'responses.jsonl')
  for row in rows:
   cid=row['claim_id'];assert previous[cid]['output']['status']!='compiled';f,out,feedback=evaluate(records[cid],previous[cid]['current_form'],row['raw'],schemas[cid]);row.update(current_form=f,output=out,feedback=feedback)
  write(BASE/folder/'responses.jsonl',rows);return {r['claim_id']:r for r in rows}
 first=copy.deepcopy(initial);first.update(replay('first',first));write(BASE/'first_final.jsonl',list(first.values()))
 for branch in['feedback','generic']:
  final=copy.deepcopy(first)
  for i in[1,2]:final.update(replay(branch+'_'+str(i),final))
  write(BASE/(branch+'_final.jsonl'),list(final.values()))
 for n,data in old.items():assert(BASE/n).read_bytes()==data,n
 proof=dict(condition=args.condition,cases=len(initial),frozen_source=str((BASE/'model_source').relative_to(ROOT)),byte_identical_files=list(old),no_gpu=True)
 if args.condition=='strict':
  from neural_faithfulness_diagnostic import messages
  source={r['artifact_sha256']:r for r in read(BASE/'neural_diagnostic_inputs.jsonl')};rows=read(BASE/'neural_diagnostic_outputs.jsonl')
  for row in rows:assert messages(source[row['artifact_sha256']])==row['messages'];assert json.loads(row['raw'])==row['prediction'];assert source[row['artifact_sha256']]['gold']==row['gold']
  proof['neural_messages_checked']=len(rows)
 (RUN/('replay_'+args.condition+'.json')).write_text(json.dumps(proof,indent=2)+'\n');print(proof)
if __name__=='__main__':main()
