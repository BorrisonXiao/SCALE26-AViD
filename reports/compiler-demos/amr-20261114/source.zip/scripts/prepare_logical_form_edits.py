"""Freeze all remaining failures with an existing draft; no model-based selection."""
import json
from prepare_compiler_feedback import ROOT,RUN,OLD,freeze

def main():
 read=lambda p:list(map(json.loads,p.read_text().splitlines()))
 direct={r['claim_id']:r for r in read(RUN/'direct_all.jsonl')};inputs={r['claim_id']:r for r in read(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')};remaining=json.loads((OLD/'remaining_cases.json').read_text());selected=[r for r in remaining if direct[r['claim_id']]['status']!='compiled'and direct[r['claim_id']].get('proposed_form')]
 target=RUN/'edits';target.mkdir(exist_ok=True);(target/'inputs.jsonl').write_text(''.join(json.dumps(inputs[r['claim_id']],ensure_ascii=False)+'\n'for r in selected));(target/'selection.json').write_text(json.dumps(dict(total=len(selected),remaining=403,strict_direct_failures=376,without_draft=218,skipped_automatic_direct_passes=27,policy='All158 remaining strict failures with a draft; no sampling or best-of-model selection. Current1972 retained programs are preserved. At most8 field edits per attempt, first attempt shared by detailed/generic retry branches, then at most2 retries. No whole-form replacement.'),indent=2)+'\n');freeze(target);print('Prepared',len(selected))
if __name__=='__main__':main()
