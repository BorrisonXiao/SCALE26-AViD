"""A fixed source-conditioned text classifier, not multimodal fact checking."""
import json
from pathlib import Path
SYSTEM='''Does this logical form preserve the original sentence's meaning? Check who does what to whom, modifier attachment, numbers, negation, uncertainty, and quotation/source scope. Every condition must be licensed by the sentence. Words copied into unrelated fields do not preserve relationships. Judge the translation, not whether the original sentence is true in the world. Return faithful=true or false, and one short reason. Do not infer missing participants or relationships that the logical form does not express.'''
SCHEMA=dict(type='object',properties=dict(faithful=dict(type='boolean'),reason=dict(type='string')),required=['faithful','reason'],additionalProperties=False)

def messages(record):
 data=dict(claim=record['text'],logical_form=record['form'])
 if'metadata'in record:data['compiler_metadata']=record['metadata']
 return [dict(role='system',content=SYSTEM),dict(role='user',content=json.dumps(data,ensure_ascii=False,separators=(',',':')))]

def run(model,tokenizer,run_dir):
 from vllm import SamplingParams
 from vllm.sampling_params import StructuredOutputsParams
 folder=Path(run_dir);records=list(map(json.loads,(folder/'neural_diagnostic_inputs.jsonl').read_text().splitlines()));rows=[]
 for start in range(0,len(records),4):
  batch=records[start:start+4];prompts=[messages(r)for r in batch];text=[tokenizer.apply_chat_template(m,tokenize=False,add_generation_prompt=True)for m in prompts];params=SamplingParams(temperature=0,max_tokens=256,structured_outputs=StructuredOutputsParams(json=SCHEMA,disable_any_whitespace=True));outputs=model.generate(text,params,use_tqdm=False)
  for r,m,o in zip(batch,prompts,outputs):
   raw=o.outputs[0].text
   try:prediction=json.loads(raw)
   except ValueError:prediction=None
   rows.append(dict(artifact_sha256=r['artifact_sha256'],claim_id=r['claim_id'],messages=m,raw=raw,prediction=prediction,gold=r['gold'],finish_reason=o.outputs[0].finish_reason))
  (folder/'neural_diagnostic_outputs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows));print('neural_diagnostic',len(rows),flush=True)
 # This is agreement with compiler-author development labels, not accuracy.
 tp=sum(r['prediction']is not None and r['prediction']['faithful']and r['gold']for r in rows);fp=sum(r['prediction']is not None and r['prediction']['faithful']and not r['gold']for r in rows);fn=sum(r['prediction']is None or not r['prediction']['faithful']for r in rows if r['gold']);tn=sum(r['prediction']is not None and not r['prediction']['faithful']and not r['gold']for r in rows)
 summary=dict(total=len(rows),true_positive=tp,false_positive=fp,false_negative=fn,true_negative=tn,invalid=sum(r['prediction']is None for r in rows),precision=tp/(tp+fp)if tp+fp else None,recall=tp/(tp+fn)if tp+fn else None,positive_labels=sum(r['gold']for r in rows),negative_labels=sum(not r['gold']for r in rows),note='Frozen generator model reused as a text-only faithfulness classifier. No training, no independent reference accuracy, no held-out evaluation and no automatic corpus promotion. The model never receives gold labels.')
 (folder/'neural_diagnostic_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary,flush=True)
