"""Separate structural validity, meaning review, and the unchanged prior pool."""
import hashlib,json
from collections import Counter
from pathlib import Path
from prepare_structural_compiler import ROOT,RUN,OLD,read,write
from build_reviewed_compilation_report import slim
from analyze_semantic_components import form

def artifact(r):return hashlib.sha256(json.dumps(dict(form=form(r['output']),program=r['output'].get('program')),sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def gather():
 result=[]
 for name,base,prefix in [('Permissive structural edits',RUN,'development'),('Strict literal types + structural edits',RUN/'strict','structural')]:
  before={r['claim_id']:r for r in read(base/'before.jsonl')}
  for branch in['generic','feedback']:
   if not(base/(branch+'_final.jsonl')).exists():continue
   rounds=[read(base/'first_final.jsonl')]+[read(base/(branch+'_'+str(i))/'responses.jsonl')for i in[1,2]]
   result.append(dict(id=prefix+'_'+branch,title=name+' / '+('compiler feedback'if branch=='feedback'else'generic retry'),base=base,before=before,rows=read(base/(branch+'_final.jsonl')),rounds=rounds))
 return result

def candidates():
 unique={}
 for c in gather():
  for r in c['rows']:
   if r['output']['status']!='compiled':continue
   key=artifact(r);unique.setdefault(key,dict(hash=key,claim_id=r['claim_id'],text=r['text'],conditions=[],draft_source=r['draft_source'],current_form=r['current_form'],output=slim(r['output'])))['conditions'].append(c['id'])
 (RUN/'review_candidates.json').write_text(json.dumps(list(unique.values()),ensure_ascii=False,indent=2)+'\n');print('Unique final programs:',len(unique))

def main():
 judgments=json.loads((RUN/'judgments.json').read_text());conditions=[];reviews=[];primary=None
 for c in gather():
  cases=[]
  for r in c['rows']:
   cid=r['claim_id'];key=artifact(r);complete=r['output']['status']=='compiled';ok=judgments[key]['faithful']if complete else False;reason=judgments[key]['reason']if complete else'No complete program.';attempts=[]
   for i,rows in enumerate(c['rounds']):
    a=next((x for x in rows if x['claim_id']==cid),None)
    if a:attempts.append(dict(attempt=i,raw=a.get('raw',''),messages=a.get('messages',[]),output=slim(a['output']),current_form=a['current_form'],feedback=a['feedback'],finish_reason=a.get('finish_reason')))
   cases.append(dict(claim_id=cid,text=r['text'],compiled=complete,approved=ok,review=reason,artifact_sha256=key,draft_source=r['draft_source'],original_form=c['before'][cid]['current_form'],partial_details=c['before'][cid].get('partial_details'),attempts=attempts));reviews.append(dict(condition=c['id'],claim_id=cid,compiled=complete,faithful=ok,reason=reason,artifact_sha256=key))
  stats=dict(id=c['id'],title=c['title'],total=len(cases),initial_compiled=sum(r['output']['status']=='compiled'for r in c['rounds'][0]),final_compiled=sum(r['compiled']for r in cases),approved=sum(r['approved']for r in cases),new_approved=sum(r['approved']for r in cases),requests_by_round=[len(rows)for rows in c['rounds']],failures=dict(Counter(r['output'].get('code')for r in c['rows']if r['output']['status']!='compiled')),config=json.loads((c['base']/'config.json').read_text()),cases=cases);conditions.append(stats)
  if c['id']=='structural_feedback':primary=(c,cases)
 assert primary is not None
 c,cs=primary;outputs={r['claim_id']:r for r in c['rows']};cases={r['claim_id']:r for r in cs};old_pool=read(OLD/'corpus_reviewed.jsonl');old_remaining={r['claim_id']:r for r in json.loads((OLD/'remaining_cases.json').read_text())};pool=[];ledger=[];new=[]
 for old in old_pool:
  cid=old['claim_id'];r=old
  if cid in cases:
   assert old['status']!='compiled';r=dict(outputs[cid]['output'],claim_id=cid,text=old['text'])
   if cases[cid]['approved']:new.append(cid);r['acceptance']='Compiler-author development meaning review of the fixed strict structural-feedback condition; not independent accuracy or media labels.'
   else:
    r['status']='unsupported'
    if cases[cid]['compiled']:r.update(code='meaning_review',reason=cases[cid]['review'])
  pool.append(r)
  if r['status']!='compiled':ledger.append(dict(claim_id=cid,text=r['text'],stage='meaning_review'if cases[cid]['compiled']else'structural_compilation',code=r.get('code'),reason=r.get('reason'),previous_failure=old_remaining[cid],diagnostic_output=slim(outputs[cid]['output']),tested=True)if cid in cases else dict(old_remaining[cid],tested=False))
 write(RUN/'corpus_reviewed.jsonl',pool);(RUN/'remaining_cases.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n');(RUN/'cases.json').write_text(json.dumps(dict(note='Same40 fixed failures. Development condition not pooled; primary strict structural-feedback condition only.',conditions=conditions),ensure_ascii=False,separators=(',',':'))+'\n');(RUN/'semantic_review.json').write_text(json.dumps(dict(unique_programs=len(judgments),cases=reviews,provenance='Compiler-author development judgments, not independent reference accuracy.'),ensure_ascii=False,indent=2)+'\n')
 count=sum(r['status']=='compiled'for r in pool);summary=dict(corpus=dict(total=2375,before=1981,accepted=count,rate=count/2375,remaining=len(ledger),new_approved=len(new),new_ids=new),selection=json.loads((RUN/'selection.json').read_text()),conditions=[{k:v for k,v in s.items()if k!='cases'}for s in conditions],unique_programs_reviewed=len(judgments),old_retained_unchanged=sum(a['status']=='compiled'and a==b for a,b in zip(old_pool,pool)),remaining_stages=dict(Counter(r['stage']for r in ledger)),training='Deferred. No new media inference or SRL training.');(RUN/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in{'selection','conditions'}},indent=2))
if __name__=='__main__':
 import sys
 candidates()if'--candidates'in sys.argv else main()
