"""Check the unchanged 2,375 originals and 449 cached cases after tracing hooks."""
import hashlib,json
from prepare_structural_compiler import ROOT,RUN,OLD
import run_compiler_repairs as runner

def main():
 runner.RUN=RUN;runner.corpus();runner.replay('cached_pipeline.jsonl',ROOT/'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl',ROOT/'exp/probabilistic_verification/rewrite_all_20261112/inputs.jsonl')
 files={}
 for n in['direct_all.jsonl','cached_pipeline.jsonl']:
  a=(RUN/n).read_bytes();assert a==(OLD/n).read_bytes(),n;files[n]=hashlib.sha256(a).hexdigest()
 proof=dict(originals=2375,cached=449,byte_identical_to_previous=files,default_tracing=False);(RUN/'direct_regression.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
if __name__=='__main__':main()
