"""Replay source/logic results from an isolated extraction, without model calls."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from prepare_amr_composition import ROOT,RUN,dump
def main():
 archive=ROOT/'site/reports/compiler-demos/amr-20261114/source.zip';target=Path(tempfile.mkdtemp(prefix='avid-amr-composition-'))
 with zipfile.ZipFile(archive)as z:z.extractall(target)
 for line in(target/'AMR_COMPOSITION_SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256((target/n).read_bytes()).hexdigest()==h,n
 env=dict(os.environ,PYTHONPATH=str(target/'scripts'),PYTHONDONTWRITEBYTECODE='1')
 for script in ['run_amr_composition.py','review_amr_composition.py','replay_amr_legacy.py']:
  r=subprocess.run([sys.executable,'scripts/'+script],cwd=target,env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr;print('Replayed',script,flush=True)
 names=['corpus.jsonl','cases.json','reviews.json','reviewed_cases.json','confidence_data.json','failure_patterns.json','legacy_regression.json']
 for n in names:assert(RUN/n).read_bytes()==(target/RUN.relative_to(ROOT)/n).read_bytes(),n
 a=json.loads((RUN/'summary.json').read_text());b=json.loads((target/RUN.relative_to(ROOT)/'summary.json').read_text());a.pop('seconds');b.pop('seconds');assert a==b
 r=subprocess.run([sys.executable,'scripts/run_amr_native_checks.py','--case','Tg0UxWYuPeJ0_323'],cwd=target,env=env,capture_output=True,text=True,timeout=20);assert r.returncode==0,r.stderr;assert json.loads(r.stdout.strip().splitlines()[-1])=={'unknown':1.0}
 dump(RUN/'archive_verification.json',dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),sha256_inventory=True,byte_identical_artifacts=names,summary_equal_except_elapsed_seconds=True,amr_originals=2375,reference_cases=60,legacy_originals=2375,legacy_cached=449,native_race_unknown=1.0,model_calls=0,extraction=str(target)));print('Isolated replay exact; native race check passed.')
if __name__=='__main__':main()
