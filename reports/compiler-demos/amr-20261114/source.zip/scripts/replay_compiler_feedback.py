"""Replay unchanged direct/cached compilation in the new run, preserving baseline files."""
import hashlib,json
from prepare_compiler_feedback import RUN,OLD
import run_compiler_repairs as runner

def main():
 runner.RUN=RUN
 expected={n:(OLD/n).read_bytes()for n in ['direct_all.jsonl','cached_pipeline.jsonl']}
 runner.corpus();runner.replay('cached_pipeline.jsonl',runner.ROOT/'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl',runner.ROOT/'exp/probabilistic_verification/rewrite_all_20261112/inputs.jsonl')
 for n,b in expected.items():assert (RUN/n).read_bytes()==b,n
 proof=dict(originals=2375,cached_cohort=449,byte_identical_to_previous={n:hashlib.sha256(b).hexdigest()for n,b in expected.items()})
 (RUN/'direct_regression.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
if __name__=='__main__':main()
