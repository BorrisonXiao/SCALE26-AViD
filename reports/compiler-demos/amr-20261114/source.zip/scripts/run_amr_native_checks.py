"""Bounded native inference; distinguish completed unknown from a time limit."""
import argparse,hashlib,json,subprocess,sys,time
from prepare_amr_composition import RUN,dump
CASES=['Tg0UxWYuPeJ0_323','Txf2EdqOg1SQ_2176','T1JQ-aG78Zuc_796']
def worker(cid):
 from deepproblog.model import Model
 from deepproblog.engines import ExactEngine
 from deepproblog.query import Query
 from problog.logic import Term
 r=next(x for x in json.loads((RUN/'reviewed_cases.json').read_text())if x['claim_id']==cid)
 m=Model(r['program'],[],load=False);m.set_engine(ExactEngine(m));name='c_'+hashlib.sha256(cid.encode()).hexdigest()[:16]
 result=m.solve([Query(Term('verdict',Term(name),Term('unknown')))])[0]
 scores={str(k.args[1]):float(v)for k,v in result.result.items()};assert scores.get('unknown')==1.0
 print(json.dumps(scores),flush=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--case');a=p.parse_args()
 if a.case:worker(a.case);return
 out=[]
 for cid in CASES:
  started=time.monotonic()
  try:
   r=subprocess.run([sys.executable,__file__,'--case',cid],capture_output=True,text=True,timeout=10)
   row=dict(claim_id=cid,status='completed'if r.returncode==0 else'error',returncode=r.returncode,stderr=r.stderr)
   if r.returncode==0:row['distribution']=json.loads(r.stdout.strip().splitlines()[-1])
   else:row['stdout']=r.stdout
  except subprocess.TimeoutExpired:row=dict(claim_id=cid,status='time_limit',limit_seconds=10,distribution=None)
  row['seconds']=round(time.monotonic()-started,3);row['interpretation']='No media observations; only unknown queried. A time limit is not a verdict.';out.append(row);dump(RUN/'native_checks.json',out);print(row,flush=True)
if __name__=='__main__':main()
