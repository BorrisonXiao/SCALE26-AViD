"""Reproduce all failed-original partial drafts; never freeze/overwrite model snapshots."""
import copy,json
from prepare_structural_compiler import ROOT,RUN,OLD,read,write
from probabilistic_verification.compiler_feedback import current_form
from probabilistic_verification.partial_parse import capture

def main():
 records={r['claim_id']:r for r in read(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')};excluded={r['claim_id']for r in json.loads((OLD/'remaining_cases.json').read_text())};rows=[]
 for original in read(RUN/'direct_all.jsonl'):
  if original['claim_id']not in excluded or original['status']=='compiled':continue
  row=copy.deepcopy(original)
  if current_form(row):row['draft_source']='existing_draft'
  else:row.update(capture(records[row['claim_id']]));row['draft_source']='partial_capture'
  rows.append(row)
 old=(RUN/'failed_drafts.jsonl').read_bytes();write(RUN/'failed_drafts.jsonl',rows);assert(RUN/'failed_drafts.jsonl').read_bytes()==old
 print('Replayed',len(rows),'strict failures; exact partial-draft records.')
if __name__=='__main__':main()
