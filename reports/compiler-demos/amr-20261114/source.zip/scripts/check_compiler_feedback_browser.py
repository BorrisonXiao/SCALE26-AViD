"""Check all final field-edit attempts, exclusions, corpus counts and legacy navigation."""
import functools,http.server,json,threading
from playwright.sync_api import sync_playwright
from prepare_compiler_feedback import ROOT,RUN

def main():
 class Handler(http.server.SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'site')));threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
 with sync_playwright()as p:
  browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(base+'/reports/',wait_until='networkidle');assert page.locator('.card-link').count()==2
  page.goto(base+'/reports/compiler-demos.html#remaining-failures',wait_until='networkidle');page.wait_for_function('document.querySelector("#feedback-case").options.length===158')
  assert page.locator('[role="tab"]').all_text_contents()==['Overview','Examples','All claims','Daily log','History']
  assert all(x in page.locator('#current-work').inner_text()for x in ['1,981','83.41%','394','466','218'])
  page.screenshot(path=str(RUN/'overview_desktop.png'))
  data=json.loads((RUN/'cases.json').read_text());checked=0;attempts=0
  page.goto(base+'/reports/compiler-demos.html#feedback-example',wait_until='networkidle')
  for c in data['conditions']:
   page.select_option('#feedback-condition',c['id'])
   result=page.evaluate('''rows=>{let attempts=0;for(const r of rows){const s=document.querySelector('#feedback-case');s.value=r.claim_id;s.dispatchEvent(new Event('change'));if(document.querySelector('#feedback-text').textContent!==r.text)throw Error(r.claim_id+' text');const content=document.querySelector('#feedback-attempts').textContent;const sections=[...document.querySelectorAll('#feedback-attempts > section')];for(const [i,a] of r.attempts.entries()){if(!content.includes(a.raw))throw Error(r.claim_id+' missing exact raw');const messages=JSON.parse(sections[i].querySelector('details pre').textContent);if(JSON.stringify(messages)!==JSON.stringify(a.messages))throw Error(r.claim_id+' missing prompt');attempts++;}if(!document.querySelector('#feedback-original .cv-figure'))throw Error(r.claim_id+' original');if(document.querySelector('#feedback-original details'))throw Error('original folded');if(document.querySelector('#feedback-original').textContent.includes('[object Object]'))throw Error(r.claim_id+' unreadable');}return {cases:rows.length,attempts};}''',c['cases'])
   checked+=result['cases'];attempts+=result['attempts']
  ledger=json.loads((RUN/'remaining_cases.json').read_text());count=page.evaluate('''rows=>{for(const r of rows){const s=document.querySelector('#feedback-failure');s.value=r.claim_id;s.dispatchEvent(new Event('change'));if(document.querySelector('#feedback-failure-text').textContent!==r.text||!document.querySelector('#feedback-failure-reason').textContent.endsWith(r.reason))throw Error(r.claim_id);}return rows.length;}''',ledger)
  page.fill('#feedback-search','Txf2EdqOg1SQ_2176');assert page.locator('#feedback-failure option').count()==1
  page.goto(base+'/reports/compiler-demos.html?feedback=edits_feedback&feedback_claim=TjHepwuhkYFA_1022#feedback-example',wait_until='networkidle');assert page.locator('#feedback-case').input_value()=='TjHepwuhkYFA_1022';assert 'storyful'in page.locator('#feedback-attempts').inner_text();assert 'Retained'in page.locator('#feedback-note').inner_text();page.screenshot(path=str(RUN/'logo_example.png'))
  page.goto(base+'/reports/compiler-demos.html?feedback=edits_feedback&feedback_claim=Tg0UxWYuPeJ0_378#feedback-example',wait_until='networkidle');assert 'rejected'in page.locator('#feedback-note').inner_text();assert 'nummod'in page.locator('#feedback-attempts').inner_text()
  page.goto(base+'/reports/compiler-demos.html#outputs',wait_until='networkidle');page.select_option('#all-filter','accepted');page.wait_for_timeout(300);assert page.locator('#all-select option').count()==1981
  page.select_option('#all-filter','recovered');page.wait_for_timeout(200);assert page.locator('#all-select option').count()==9
  for fragment,panel in [('repair-example','history'),('repair-model','history'),('repairs-before-feedback','history'),('readiness-example','history'),('component-example','history'),('full-rewrite-example','history'),('syntax-demos','walkthroughs'),('components-before-readiness','history'),('full-rewrite-before-components','history'),('alignment-example','history'),('outputs','outputs'),('daily-progress','daily-progress')]:
   page.goto(base+'/reports/compiler-demos.html#'+fragment,wait_until='networkidle');assert page.locator('#'+panel).is_visible(),fragment
  assert page.locator('#repair-select option').count()==13 and page.locator('#component-select option').count()==47 and page.locator('#full-case option').count()==449 and page.locator('#demo-select option').count()==41
  page.goto(base+'/reports/compiler-demos.html?feedback=edits_feedback&feedback_claim=Txf2EdqOg1SQ_2283#feedback-example',wait_until='networkidle');page.set_viewport_size({'width':390,'height':844});page.emulate_media(color_scheme='dark');assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');page.screenshot(path=str(RUN/'example_mobile_dark.png'))
  page.goto(base+'/reports/verification-pipeline.html#next-steps',wait_until='networkidle');assert '1,981'in page.locator('#next-steps').inner_text();assert '218'in page.locator('#next-steps').inner_text()
  for n in ['summary.json','cases.json','semantic_review.json','remaining_cases.json','edit_replay.json','tests.xml','README.md','source.zip']:assert page.request.get(base+'/reports/compiler-demos/feedback-20261113/'+n).ok,n
  assert not errors,errors;proof=dict(condition_cases=checked,attempts=attempts,exclusions=count,retained_viewer=1981,recoveries_viewer=9,main_reports=2,views=5,old_repairs=13,old_components=47,old_model_cases=449,old_demos=41,mobile_overflow=False,page_errors=errors);(RUN/'browser_checks.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof);browser.close()
 server.shutdown()
if __name__=='__main__':main()
