"""Recompute unchanged corpus outputs, every typed-edit round and the reviewed pool offline."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from prepare_compiler_feedback import ROOT,RUN

def main():
 target=Path(tempfile.mkdtemp(prefix='avid-compiler-feedback-'));archive=ROOT/'site/reports/compiler-demos/feedback-20261113/source.zip'
 with zipfile.ZipFile(archive)as z:z.extractall(target)
 for line in(target/'COMPILER_FEEDBACK_SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256((target/n).read_bytes()).hexdigest()==h,n
 env=dict(os.environ,PYTHONPATH=str(target/'scripts'),PYTHONDONTWRITEBYTECODE='1')
 for args in [('scripts/replay_compiler_feedback.py',),('scripts/replay_typed_edits.py',),('scripts/analyze_typed_edits.py',)]:
  r=subprocess.run([sys.executable,*args],cwd=target,env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr;print('Replayed',args,flush=True)
 names=['direct_all.jsonl','cached_pipeline.jsonl','direct_regression.json','edit_replay.json','summary.json','corpus_reviewed.jsonl','semantic_review.json','remaining_cases.json','cases.json']
 for n in names:assert (RUN/n).read_bytes()==(target/RUN.relative_to(ROOT)/n).read_bytes(),n
 proof=dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),extraction=str(target),sha256_inventory=True,originals=2375,cached_cohort=449,typed_edit_cases=158,byte_identical_artifacts=names,prior_retained_exact=1972)
 (RUN/'archive_verification.json').write_text(json.dumps(proof,indent=2)+'\n');print('Verified nine byte-identical outputs plus all saved edit rounds.')
if __name__=='__main__':main()
