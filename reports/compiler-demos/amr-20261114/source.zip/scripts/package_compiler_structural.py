"""Deterministic source/data overlay; preserve all 30 historical ZIPs."""
import hashlib,json,zipfile
from prepare_structural_compiler import ROOT,RUN,OLD

def main():
 names=set()
 for folder,pattern in [('scripts','*.py'),('scripts/probabilistic_verification','*.py'),('scripts/report_assets','*'),('tests','*.py'),('tests/fixtures','*.json')]:names.update(str(p.relative_to(ROOT))for p in(ROOT/folder).glob(pattern)if p.is_file())
 names.update(['AGENTS.md','CLAUDE.md','docs/compiler_structural_20261113.md','docs/compiler_feedback_20261113.md']+[str(p.relative_to(ROOT))for p in(ROOT/'docs/project_notes').glob('*')if p.is_file()])
 inputs={'content_relations_20261105':['inputs.jsonl','results.jsonl'],'rewrite_all_20261112':['parsed.jsonl','inputs.jsonl'],'compiler_feedback_20261112':['direct_all.jsonl','cached_pipeline.jsonl','corpus_reviewed.jsonl','remaining_cases.json','cases.json','edit_review_candidates.json','edit_judgments.json','pilot_inputs.jsonl'],'compiler_repairs_20261112':['pilot_inputs.jsonl'],'av_features_20261022':['checklist.json','visual_features.pt','visual_features.json','reviewed_claims.json','av_parses.json']}
 for folder,files in inputs.items():names.update('exp/probabilistic_verification/'+folder+'/'+n for n in files)
 excluded={'archive_verification.json','browser_checks.json','publication.json','source_manifest.json'}
 for folder in[RUN,ROOT/'research/compiler_alternatives_20261113']:
  names.update(str(p.relative_to(ROOT))for p in folder.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.name not in excluded and p.suffix in{'.json','.jsonl','.xml','.py','.pl','.log','.out','.err','.txt','.sh','.md'})
 data={n:(ROOT/n).read_bytes()for n in sorted(names)}
 for n,h in json.loads((RUN/'preserved_archives.json').read_text()).items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
 for n,h in json.loads((ROOT/'exp/probabilistic_verification/claim_rewrite_20261111/viewer_sha256.json').read_text()).items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
 (RUN/'source_manifest.json').write_text(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in data.items()},indent=2)+'\n');data[str((RUN/'source_manifest.json').relative_to(ROOT))]=(RUN/'source_manifest.json').read_bytes();data['README_COMPILER_STRUCTURAL.md']=(ROOT/'docs/compiler_structural_20261113.md').read_bytes();data['COMPILER_STRUCTURAL_SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+n+'\n'for n,b in sorted(data.items())).encode();target=ROOT/'site/reports/compiler-demos/structural-20261113/source.zip'
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in sorted(data.items()):
   info=zipfile.ZipInfo(n,date_time=(2026,11,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
 assert target.stat().st_size<100_000_000;print('Packaged',len(data),'files;',round(target.stat().st_size/1048576,2),'MiB; all30 historical ZIPs/26 original viewers unchanged.')
if __name__=='__main__':main()
