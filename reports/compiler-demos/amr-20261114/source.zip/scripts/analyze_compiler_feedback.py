"""Hash-bound meaning review and one fixed feedback method's corpus accounting."""
import hashlib,json
from collections import Counter
from pathlib import Path
from prepare_compiler_feedback import ROOT,RUN,OLD
from build_reviewed_compilation_report import slim
from analyze_semantic_components import form

def read(p):return list(map(json.loads,p.read_text().splitlines()))
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def artifact(row):return digest(dict(form=form(row['output']),program=row['output'].get('program')))
CONDITIONS=[('generic','Generic retry',RUN/'compact','generic'),('basic','Compiler error and existing token diagnostics',RUN/'compact','feedback'),('detailed','Detailed compiler feedback',RUN/'enriched','feedback'),('extension','Earlier checks: detailed feedback on72 additional cases',RUN/'extension','feedback'),('semantic_generic','New source/scope checks + generic retry',RUN/'semantic','generic'),('semantic','New source/scope checks + detailed feedback',RUN/'semantic','feedback')]
def gather():
 out=[]
 for key,title,base,branch in CONDITIONS:
  p=base/(branch+'_final.jsonl')
  if not p.exists():continue
  rounds=[read(base/'initial/responses.jsonl')]+[read(base/(branch+'_'+str(i))/'responses.jsonl')if(base/(branch+'_'+str(i))/'responses.jsonl').exists()else[]for i in[1,2]]
  out.append(dict(id=key,title=title,base=base,branch=branch,rows=read(p),rounds=rounds))
 return out

def candidates():
 unique={}
 for condition in gather():
  for r in condition['rows']:
   if r['output']['status']=='compiled':
    key=artifact(r);unique.setdefault(key,dict(hash=key,claim_id=r['claim_id'],text=r['text'],conditions=[],output=slim(r['output']),raw=r['raw']))['conditions'].append(condition['id'])
 (RUN/'review_candidates.json').write_text(json.dumps(list(unique.values()),ensure_ascii=False,indent=2)+'\n');print('Complete candidates:',len(unique))

def main():
 judgments=json.loads((RUN/'judgments.json').read_text());conditions=[];by_condition={};reviews=[];needed=set()
 baseline=read(OLD/'corpus_reviewed.jsonl');baseline_by={r['claim_id']:r for r in baseline}
 for c in gather():
  cases=[]
  for row in c['rows']:
   cid=row['claim_id'];key=artifact(row);passing=row['output']['status']=='compiled';approved=False;reason='No complete program.'
   if passing:needed.add(key);approved=judgments[key]['faithful'];reason=judgments[key]['reason']
   attempts=[]
   for i,round_rows in enumerate(c['rounds']):
    r=next((r for r in round_rows if r['claim_id']==cid),None)
    if r:attempts.append(dict(attempt=i,raw=r['raw'],messages=r['messages'],output=slim(r['output']),feedback=r['feedback'],finish_reason=r['finish_reason']))
   case=dict(claim_id=cid,text=row['text'],compiled=passing,approved=approved,review=reason,artifact_sha256=key,attempts=attempts)
   cases.append(case);reviews.append(dict(condition=c['id'],claim_id=cid,compiled=passing,faithful=approved,reason=reason,artifact_sha256=key))
  condition=dict(id=c['id'],title=c['title'],total=len(c['rows']),initial_compiled=sum(r['output']['status']=='compiled'for r in c['rounds'][0]),final_compiled=sum(r['compiled']for r in cases),approved=sum(r['approved']for r in cases),new_approved=sum(r['approved']and baseline_by[r['claim_id']]['status']!='compiled'for r in cases),requests_by_round=[len(x)for x in c['rounds']],config=json.loads((c['base']/'config.json').read_text()),failures=dict(Counter(r['output'].get('code')for r in c['rows']if r['output']['status']!='compiled')),cases=cases)
  conditions.append(condition);by_condition[c['id']]=c
 assert len(conditions)==6
 assert needed<=set(judgments),needed-set(judgments)
 primary={r['claim_id']:r for key in ['semantic']for r in by_condition[key]['rows']};primary_reviews={r['claim_id']:r for r in reviews if r['condition']=='semantic'}
 pool=[];additions=[];old_ledger={r['claim_id']:r for r in json.loads((OLD/'remaining_cases.json').read_text())};ledger=[]
 for old in baseline:
  cid=old['claim_id'];r=old
  if cid in primary:
   result=primary[cid]['output'];review=primary_reviews[cid]
   if review['faithful']and old['status']!='compiled':
    r=dict(result,claim_id=cid,text=old['text'],acceptance='Compiler-author development review of the fixed detailed-feedback condition; not independent gold or a media truth label.')
    if old['status']!='compiled':additions.append(cid)
   elif old['status']!='compiled':
    r=dict(result,claim_id=cid,text=old['text'],status='unsupported')
    if result['status']=='compiled':r.update(code='meaning_review',reason=review['reason'])
  pool.append(r)
  if r['status']!='compiled':
   if cid in primary:
    review=primary_reviews[cid];result=primary[cid]['output'];ledger.append(dict(claim_id=cid,text=r['text'],stage='meaning_review'if result['status']=='compiled'else'feedback_compilation',code=r.get('code'),reason=r.get('reason'),previous_failure=old_ledger.get(cid),diagnostic_output=slim(result),tested=True))
   else:ledger.append(dict(old_ledger[cid],tested=False))
 for name,data in [('corpus_reviewed.jsonl',pool)]: (RUN/name).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in data))
 (RUN/'cases.json').write_text(json.dumps(dict(note='Same24 initial outputs for the three pilot branches. All responses are development diagnostics. Detailed feedback with the new source/scope checks is the only promoted method; no best-of-branch selection.',conditions=conditions),ensure_ascii=False,indent=2)+'\n')
 (RUN/'semantic_review.json').write_text(json.dumps(dict(provenance='Compiler-author review of every unique complete program in all final branches; identical program/form judgments reused by hash. Earlier retained claims preserve previous judgments.',unique_programs=len(needed),cases=reviews),ensure_ascii=False,indent=2)+'\n')
 (RUN/'remaining_cases.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
 summary=dict(corpus=dict(total=len(pool),before=1972,accepted=sum(r['status']=='compiled'for r in pool),rate=sum(r['status']=='compiled'for r in pool)/len(pool),remaining=len(ledger),new_approved=len(additions),new_ids=additions),direct=dict(total=2375,compiled=1983,unchanged=True),cached=dict(total=449,programs=114,unchanged=True),conditions=[{k:v for k,v in c.items()if k!='cases'}for c in conditions],unique_programs_reviewed=len(needed),primary_cases=len(primary),old_retained_unchanged=sum(old['status']=='compiled'and old==new for old,new in zip(baseline,pool)),remaining_stages=dict(Counter(r['stage']for r in ledger)),remaining_tested=sum(r['tested']for r in ledger),training='Deferred. No new media inference or parser training.')
 (RUN/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='conditions'},indent=2))
if __name__=='__main__':
 import sys
 candidates()if'--candidates'in sys.argv else main()
