"""Prove the opt-in AMR experiment leaves existing original/cached results exact."""
import hashlib,json
from prepare_amr_composition import ROOT,RUN,OLD,dump
import run_compiler_repairs as runner
def main():
 target=RUN/'legacy_replay';target.mkdir(exist_ok=True);runner.RUN=target
 runner.corpus();runner.replay('cached_pipeline.jsonl',ROOT/'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl',ROOT/'exp/probabilistic_verification/rewrite_all_20261112/inputs.jsonl')
 hashes={}
 for n in ['direct_all.jsonl','cached_pipeline.jsonl']:
  assert(target/n).read_bytes()==(OLD/n).read_bytes(),n
  hashes[n]=hashlib.sha256((target/n).read_bytes()).hexdigest()
 dump(RUN/'legacy_regression.json',dict(originals=2375,cached=449,byte_identical=hashes,retained=1981,excluded=394,opt_in_amr=True));print('Legacy2375/449exact.')
if __name__=='__main__':main()
