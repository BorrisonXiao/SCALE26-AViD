"""Replay the frozen edit validator and backend without loading a language model."""
import copy,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_feedback_20261112';BASE=RUN/'typed_edits'
sys.path.insert(0,str(BASE/'model_source/scripts'))
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.compiler_feedback import current_form,schema,inspect
from probabilistic_verification.logical_form_edits import clean,evaluate

def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def main():
 originals={r['claim_id']:r for r in read(BASE/'inputs.jsonl')};initial={};schemas={};names=['before.jsonl','first/responses.jsonl','first_final.jsonl','feedback_final.jsonl','generic_final.jsonl']+[b+'_'+str(i)+'/responses.jsonl'for b in['feedback','generic']for i in[1,2]];old={n:(BASE/n).read_bytes()for n in names if(BASE/n).exists()}
 for cid,r in originals.items():
  direct=compile_one(r);assert direct['status']!='compiled';f=clean(current_form(direct));schemas[cid]=schema(r,current_form(direct));out,feedback=inspect(r,dict(f,action='repair'),schemas[cid],detailed=True,semantic_checks=True);initial[cid]=dict(claim_id=cid,text=r['text'],current_form=f,output=out,feedback=feedback)
 write(BASE/'before.jsonl',list(initial.values()))
 def round(folder,previous):
  p=BASE/folder/'responses.jsonl'
  if not p.exists():return {}
  rows=read(p)
  for row in rows:
   cid=row['claim_id'];assert previous[cid]['output']['status']!='compiled'
   f,out,feedback=evaluate(originals[cid],previous[cid]['current_form'],row['raw'],schemas[cid]);row.update(current_form=f,output=out,feedback=feedback)
  write(p,rows);return {r['claim_id']:r for r in rows}
 first=copy.deepcopy(initial);first.update(round('first',first));write(BASE/'first_final.jsonl',list(first.values()))
 for branch in ['feedback','generic']:
  final=copy.deepcopy(first)
  for i in[1,2]:final.update(round(branch+'_'+str(i),final))
  write(BASE/(branch+'_final.jsonl'),list(final.values()))
 for name,data in old.items():assert (BASE/name).read_bytes()==data,name
 proof=dict(cases=len(originals),source='Frozen typed_edits/model_source',no_gpu=True,byte_identical_files=list(old));(RUN/'edit_replay.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
if __name__=='__main__':main()
