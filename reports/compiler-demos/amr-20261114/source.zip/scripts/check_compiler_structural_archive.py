"""Isolated cached replay using the archive's current and frozen source."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from prepare_structural_compiler import ROOT,RUN

def main():
 archive=ROOT/'site/reports/compiler-demos/structural-20261113/source.zip';target=Path(tempfile.mkdtemp(prefix='avid-compiler-structural-'))
 with zipfile.ZipFile(archive)as z:z.extractall(target)
 for line in(target/'COMPILER_STRUCTURAL_SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256((target/n).read_bytes()).hexdigest()==h,n
 env=dict(os.environ,PYTHONPATH=str(target/'scripts'),PYTHONDONTWRITEBYTECODE='1')
 for args in [('scripts/replay_structural_corpus.py',),('scripts/replay_partial_capture.py',),('scripts/replay_structural_outputs.py','--condition','development'),('scripts/replay_structural_outputs.py','--condition','strict'),('scripts/run_parse_mixture_examples.py',),('scripts/analyze_structural_compiler.py',)]:
  r=subprocess.run([sys.executable,*args],cwd=target,env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr;print('Replayed',args,flush=True)
 names=['direct_all.jsonl','cached_pipeline.jsonl','direct_regression.json','failed_drafts.jsonl','summary.json','corpus_reviewed.jsonl','semantic_review.json','remaining_cases.json','cases.json','parse_mixture_examples.json','replay_development.json','replay_strict.json']
 for n in names:assert(RUN/n).read_bytes()==(target/RUN.relative_to(ROOT)/n).read_bytes(),n
 proof=dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),extraction=str(target),sha256_inventory=True,originals=2375,cached_cohort=449,strict_failures=367,partial_forms=189,model_conditions=2,model_cases_per_condition=40,neural_messages_checked=63,prior_retained_exact=1981,byte_identical_artifacts=names);(RUN/'archive_verification.json').write_text(json.dumps(proof,indent=2)+'\n');print('Verified12 exact artifacts, all saved correction rounds and63 neural messages.')
if __name__=='__main__':main()
