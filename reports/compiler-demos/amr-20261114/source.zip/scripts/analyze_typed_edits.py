"""Account for one fixed typed-edit method; keep generic retries as a control."""
import json,hashlib
from collections import Counter
from prepare_compiler_feedback import ROOT,RUN,OLD
from build_reviewed_compilation_report import slim
from analyze_semantic_components import form
from probabilistic_verification.compiler_feedback import current_form

def read(p):return list(map(json.loads,p.read_text().splitlines()))
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def artifact(r):return digest(dict(form=form(r['output']),program=r['output'].get('program')))
def gather():
 base=RUN/'typed_edits';before={r['claim_id']:r for r in read(base/'before.jsonl')};out=[]
 for branch,title in [('generic','Field edits + generic retry'),('feedback','Field edits + compiler feedback')]:
  p=base/(branch+'_final.jsonl')
  if not p.exists():continue
  rounds=[read(base/'first_final.jsonl')]+[read(base/(branch+'_'+str(i))/'responses.jsonl')if(base/(branch+'_'+str(i))/'responses.jsonl').exists()else[]for i in[1,2]]
  out.append(dict(id='edits_'+branch,title=title,rows=read(p),rounds=rounds,before=before))
 return out

def candidates():
 unique={}
 for c in gather():
  for r in c['rows']:
   if r['output']['status']=='compiled':
    key=artifact(r);unique.setdefault(key,dict(hash=key,claim_id=r['claim_id'],text=r['text'],conditions=[],output=slim(r['output']),original_form=c['before'][r['claim_id']]['current_form'],current_form=r['current_form'],last_edits=r.get('raw'),artifact_sha256=key))['conditions'].append(c['id'])
 (RUN/'edit_review_candidates.json').write_text(json.dumps(list(unique.values()),ensure_ascii=False,indent=2)+'\n');print('Unique complete edit outputs:',len(unique))

def main():
 judgments=json.loads((RUN/'edit_judgments.json').read_text());conditions=[];reviews=[];needed=set();saved=gather();assert len(saved)==2
 for c in saved:
  cases=[]
  for row in c['rows']:
   cid=row['claim_id'];key=artifact(row);passing=row['output']['status']=='compiled';ok=False;reason='No complete program.'
   if passing:needed.add(key);ok=judgments[key]['faithful'];reason=judgments[key]['reason']
   attempts=[]
   for i,rr in enumerate(c['rounds']):
    r=next((r for r in rr if r['claim_id']==cid),None)
    if r:attempts.append(dict(attempt=i,raw=r.get('raw',''),messages=r.get('messages',[]),output=slim(r['output']),current_form=r['current_form'],feedback=r['feedback'],finish_reason=r.get('finish_reason','not_requested')))
   cases.append(dict(claim_id=cid,text=row['text'],compiled=passing,approved=ok,review=reason,artifact_sha256=key,original_form=c['before'][cid]['current_form'],attempts=attempts))
   reviews.append(dict(condition=c['id'],claim_id=cid,compiled=passing,faithful=ok,reason=reason,artifact_sha256=key))
  conditions.append(dict(id=c['id'],title=c['title'],total=len(c['rows']),before_compiled=sum(r['output']['status']=='compiled'for r in c['before'].values()),initial_compiled=sum(r['output']['status']=='compiled'for r in c['rounds'][0]),final_compiled=sum(r['compiled']for r in cases),approved=sum(r['approved']for r in cases),new_approved=sum(r['approved']for r in cases),requests_by_round=[sum('raw'in r for r in c['rounds'][0])]+[len(x)for x in c['rounds'][1:]],config=json.loads((RUN/'typed_edits/config.json').read_text()),failures=dict(Counter(r['output'].get('code')for r in c['rows']if r['output']['status']!='compiled')),cases=cases))
 assert needed<=set(judgments)
 primary={r['claim_id']:r for r in saved[1]['rows']};primary_review={r['claim_id']:r for r in reviews if r['condition']=='edits_feedback'};baseline=read(OLD/'corpus_reviewed.jsonl');old_ledger={r['claim_id']:r for r in json.loads((OLD/'remaining_cases.json').read_text())};pool=[];ledger=[];new=[]
 for old in baseline:
  cid=old['claim_id'];r=old
  if cid in primary:
   assert old['status']!='compiled';out=primary[cid]['output'];v=primary_review[cid];r=dict(out,claim_id=cid,text=old['text'])
   if v['faithful']:new.append(cid);r['acceptance']='Compiler-author development review of the fixed typed-edit feedback method; not independent gold, claim truth or training eligibility.'
   else:
    r['status']='unsupported'
    if out['status']=='compiled':r.update(code='meaning_review',reason=v['reason'])
  pool.append(r)
  if r['status']!='compiled':
   if cid in primary:ledger.append(dict(claim_id=cid,text=r['text'],stage='meaning_review'if primary[cid]['output']['status']=='compiled'else'edit_compilation',code=r.get('code'),reason=r.get('reason'),previous_failure=old_ledger[cid],diagnostic_output=slim(primary[cid]['output']),tested=True))
   else:ledger.append(dict(old_ledger[cid],tested=False))
 (RUN/'corpus_reviewed.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in pool))
 (RUN/'cases.json').write_text(json.dumps(dict(note='All158 remaining strict failures with drafts. One shared first edit attempt; generic versus compiler-guided retries with the same limits. Only the feedback condition updates the corpus pool.',conditions=conditions),ensure_ascii=False,separators=(',',':'))+'\n')
 (RUN/'semantic_review.json').write_text(json.dumps(dict(provenance='Compiler-author development review of every unique complete final edit program; identical program/form judgments reused by hash. Every earlier retained program remains unchanged.',unique_programs=len(needed),cases=reviews),ensure_ascii=False,indent=2)+'\n');(RUN/'remaining_cases.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
 no_draft=[r for r in read(RUN/'direct_all.jsonl')if r['claim_id']in old_ledger and r['status']!='compiled'and not current_form(r)]
 count=sum(r['status']=='compiled'for r in pool);stats=dict(corpus=dict(total=len(pool),before=1972,accepted=count,rate=count/len(pool),remaining=len(ledger),new_approved=len(new),new_ids=new),direct=dict(total=2375,compiled=1983,unchanged=True),cached=dict(total=449,programs=114,unchanged=True),conditions=[{k:v for k,v in c.items()if k!='cases'}for c in conditions],unique_programs_reviewed=len(needed),primary_cases=len(primary),old_retained_unchanged=sum(old['status']=='compiled'and old==now for old,now in zip(baseline,pool)),remaining_stages=dict(Counter(r['stage']for r in ledger)),remaining_tested=sum(r['tested']for r in ledger),without_draft=len(no_draft),no_draft_codes=dict(Counter(r.get('code')for r in no_draft)),skipped_direct_passes=27,training='Deferred; no new media inference or parser training.')
 (RUN/'summary.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps({k:v for k,v in stats.items()if k!='conditions'},indent=2))
if __name__=='__main__':
 import sys
 candidates()if'--candidates'in sys.argv else main()
