"""Check all new cases and preserved named inspectors at desktop/mobile sizes."""
import functools,http.server,json,threading
from playwright.sync_api import sync_playwright
from prepare_amr_composition import ROOT,RUN,dump
def main():
 class Handler(http.server.SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'site')));threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
 with sync_playwright()as p:
  b=p.chromium.launch(headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(base+'/reports/',wait_until='networkidle');assert page.locator('.card-link').count()==2
  page.goto(base+'/reports/compiler-demos.html#remaining-failures',wait_until='networkidle');assert page.locator('[role="tab"]').all_text_contents()==['Overview','Examples','All claims','Daily log','History']
  assert all(t in page.locator('#current-work').inner_text()for t in ['1,425','950','1,981','13','60','505','841/950']);page.screenshot(path=str(RUN/'overview.png'))
  page.goto(base+'/reports/compiler-demos.html#amr-compiler-example',wait_until='networkidle');page.wait_for_function('document.querySelector("#amr-case").options.length===60')
  data=json.loads((ROOT/'site/reports/compiler-demos/amr-20261114/cases.json').read_text())
  count=page.evaluate('''rows=>{for(const r of rows){const s=document.querySelector('#amr-case');s.value=r.claim_id;s.dispatchEvent(new Event('change'));if(document.querySelector('#amr-text').textContent!==r.text)throw Error('claim');if(document.querySelector('#amr-reference').textContent!==r.reference.meaning)throw Error('reference');if(document.querySelector('#amr-reason').textContent!==r.review.reason)throw Error('review');if(document.querySelectorAll('#amr-graph svg').length!==1)throw Error('graph');const raw=document.querySelector('#amr-exact').textContent;if(!raw.includes(r.raw)||(r.program&&!raw.includes(r.program)))throw Error('exact');if(r.status!=='compiled'&&!document.querySelector('#amr-conditions').textContent.includes(r.reason))throw Error('failure');}return rows.length;}''',data);assert count==60
  page.goto(base+'/reports/compiler-demos.html?amr_claim=Tg0UxWYuPeJ0_323#amr-compiler-example',wait_until='networkidle');assert page.locator('#amr-case').input_value()=='Tg0UxWYuPeJ0_323';assert 'time'in page.locator('#amr-conditions').inner_text();page.screenshot(path=str(RUN/'race_example.png'))
  page.select_option('#amr-case','T1JQ-aG78Zuc_796');assert 'NOT:'in page.locator('#amr-conditions').inner_text()
  page.goto(base+'/reports/compiler-demos.html?amr_claim=Txf2EdqOg1SQ_2176#amr-compiler-example',wait_until='networkidle');assert all(t in page.locator('#amr-conditions').inner_text()for t in ['appearance','sufficiency','result']);page.screenshot(path=str(RUN/'wind_example.png'))
  old=json.loads((ROOT/'site/reports/compiler-demos/structural-20261113/cases.json').read_text());page.goto(base+'/reports/compiler-demos.html#feedback-example',wait_until='networkidle');assert page.locator('#history').is_visible();old_count=0;attempts=0
  for c in old['conditions']:
   page.select_option('#feedback-condition',c['id']);n=page.evaluate('''rows=>{let attempts=0;for(const r of rows){const s=document.querySelector('#feedback-case');s.value=r.claim_id;s.dispatchEvent(new Event('change'));if(document.querySelector('#feedback-text').textContent!==r.text)throw Error('old claim');const content=document.querySelector('#feedback-attempts').textContent;for(const a of r.attempts){if(!content.includes(a.raw))throw Error('old raw');attempts++;}}return{cases:rows.length,attempts};}''',c['cases']);old_count+=n['cases'];attempts+=n['attempts']
  assert old_count==476 and attempts==1204;assert page.locator('#neural-case option').count()==63
  for fragment,panel in [('partial-before-amr','history'),('parse-uncertainty','history'),('amr-evidence','history'),('compiler-alternatives','history'),('repair-example','history'),('ready-example','history'),('syntax-demos','walkthroughs'),('amr-compiler-design','walkthroughs'),('daily-progress','daily-progress')]:
   page.goto(base+'/reports/compiler-demos.html#'+fragment,wait_until='networkidle');assert page.locator('#'+panel).is_visible(),fragment
  assert page.locator('#repair-select option').count()==13 and page.locator('#ready-select option').count()==38 and page.locator('#component-select option').count()==47 and page.locator('#full-case option').count()==449 and page.locator('#demo-select option').count()==41
  page.goto(base+'/reports/compiler-demos.html#outputs',wait_until='networkidle');page.select_option('#all-filter','accepted');assert page.locator('#all-select option').count()==1981
  page.set_viewport_size({'width':390,'height':844});page.emulate_media(color_scheme='dark')
  for url in ['#remaining-failures','?amr_claim=Txf2EdqOg1SQ_2176#amr-compiler-example','?amr_claim=TFgw4IaR9R8s_1676#amr-compiler-example','#amr-compiler-design']:
   page.goto(base+'/reports/compiler-demos.html'+url,wait_until='networkidle');assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),url
  page.goto(base+'/reports/compiler-demos.html?amr_claim=Tg0UxWYuPeJ0_323#amr-compiler-example',wait_until='networkidle');page.screenshot(path=str(RUN/'mobile_dark.png'))
  page.goto(base+'/reports/verification-pipeline.html#next-steps',wait_until='networkidle');assert all(x in page.locator('#next-steps').inner_text()for x in['1,425','505','13 matches','10-second']);assert not errors,errors
  dump(RUN/'browser_checks.json',dict(new_cases=count,old_cases=old_count,old_attempts=attempts,old_neural=63,views=5,main_reports=2,pool_retained=1981,new_pool_promotions=0,mobile_overflow=False,page_errors=errors));print('Checked60new/476old cases,1204old attempts; legacy links/mobile/dark pass.');b.close()
 server.shutdown()
if __name__=='__main__':main()
