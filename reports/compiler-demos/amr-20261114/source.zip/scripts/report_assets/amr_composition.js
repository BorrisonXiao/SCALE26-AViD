(()=>{
 const el=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 if(!el('amr-case'))return;let rows=[];
 function show(save=false){
  const r=rows.find(x=>x.claim_id===el('amr-case').value);if(!r)return;
  el('amr-text').textContent=r.text;el('amr-reference').textContent=r.reference.meaning;
  el('amr-reference-origin').textContent=r.reference.origin==='human_confirmed_reading'?'Reference: your earlier confirmed reading. New program review: assistant only.':'Reference: assistant reading frozen before converter execution; development case.';
  el('amr-verdict').textContent=r.review.whole_reading.replaceAll('_',' ')+(r.status==='compiled'?' · graph converted':' · no program');
  el('amr-reason').textContent=r.review.reason;el('amr-graph').innerHTML=r.svg;
  if(r.compilation){
   const c=r.compilation,m=c.metadata,by=Object.fromEntries(c.atoms.map(a=>[a.id,a]));
   const describe=v=>{const d=c.variables.find(x=>x.name===v);return v+(d?' ('+d.description+')':'');};
   function sentence(a){const v=a.arguments,scope=v[v.length-3];let text;
    if(a.predicate==='concept')text=describe(v[0])+' must match concept '+v[1];
    else if(a.predicate==='role')text=describe(v[0])+' — '+v[1]+' → '+describe(v[2]);
    else if(a.predicate==='name')text=describe(v[0])+' must have name “'+v[1]+'”';
    else if(a.predicate==='reference')text='Use the same '+describe(v[0])+' in this context';
    else if(a.predicate==='proposition')text=describe(v[0])+' has '+v[1]+' in '+v[2]+' context '+v[3];
    else if(a.predicate==='temporal')text=describe(v[0])+': '+({pres:'present',past:'past'}[v[1]]||v[1])+' tense; '+v[2]+' aspect';
    else text=describe(v[0])+': '+v[1]+' = '+v[2];
    return '<p class="amr-condition">'+esc(text)+' <small>['+esc(scope)+']</small></p>';
   }
   function formula(e){
    if(e.op==='atom')return sentence(by[e.atom_id]);
    if(e.op==='constant')return '<p>'+esc(e.state)+'</p>';
    if(e.op==='exists')return formula(e.children[0]);
    if(e.op==='not')return '<div class="box amr-negative"><b>NOT: no matching assignment satisfies the following conditions</b>'+formula(e.children[0])+'</div>';
    if(e.op==='or')return '<div class="box"><b>OR: at least one branch must hold</b>'+e.children.map((x,i)=>'<div class="box"><b>Branch '+(i+1)+'</b>'+formula(x)+'</div>').join('')+'</div>';
    return e.children.map(formula).join('');
   }
   const contexts=Object.entries(m.scopes).map(([id,s])=>'<li>'+esc(id+': '+s.kind+'; owner '+s.owner+' / '+m.concepts[s.owner]+'; parent '+s.parent+'; evidence route '+s.route)+'</li>').join('');
   el('amr-conditions').innerHTML='<p>Same ID means the same candidate. All conditions are required together unless an OR/NOT box says otherwise. Candidates are existentially quantified; their full quantifier placement is preserved in the exact predicates below.</p><p><b>Contexts:</b> world = outer claim.</p>'+(contexts?'<ul>'+contexts+'</ul>':'<p>No embedded context.</p>')+formula(c.expression);
   el('amr-notes').textContent=c.warnings.join(' ');el('amr-exact').textContent=r.raw+'\n\nCOMPILED LOGIC\n'+c.logical_form+'\n\nPROBLOG PROGRAM (placeholder candidates; no media evidence)\n'+r.program;
  }else{
   el('amr-conditions').textContent='The converter refused: '+r.code+' — '+r.reason;el('amr-notes').textContent='No program is accepted from this graph. The cached parse above remains inspectable.';el('amr-exact').textContent=r.raw+'\n\n'+r.code+': '+r.reason;
  }
  const u=new URL(location);u.searchParams.set('amr_claim',r.claim_id);u.hash='amr-compiler-example';el('amr-share').href=u.pathname+u.search+u.hash;
  if(save){history.replaceState(null,'',u);window.dispatchEvent(new Event('hashchange'));}
 }
 fetch('compiler-demos/amr-20261114/cases.json').then(r=>r.json()).then(data=>{rows=data;for(const r of rows){const o=document.createElement('option');o.value=r.claim_id;o.textContent=r.claim_id+' · '+r.review.whole_reading.replaceAll('_',' ')+' · '+r.text;el('amr-case').append(o);}const q=new URLSearchParams(location.search).get('amr_claim');el('amr-case').value=rows.some(r=>r.claim_id===q)?q:'Tg0UxWYuPeJ0_323';show();window.dispatchEvent(new Event('hashchange'));}).catch(e=>el('amr-verdict').textContent=e.message);
 el('amr-case').addEventListener('change',()=>show(true));
})();
