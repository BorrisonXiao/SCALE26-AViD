(()=>{
 const el=id=>document.getElementById(id);let rows=[];
 function show(){const r=rows.find(r=>r.artifact_sha256===el('neural-case').value);if(!r)return;el('neural-text').textContent=r.text;el('neural-verdict').textContent='Frozen model: '+(r.prediction.faithful?'accepts':'rejects')+'. '+r.prediction.reason;el('neural-review').textContent='Compiler-author development review: '+(r.gold?'retained':'not retained')+'. '+r.review;el('neural-graph').innerHTML=ClaimOutputView.render({status:'compiled',form:r.form,metadata:r.metadata},r.metadata,6);el('neural-exact').textContent=JSON.stringify({messages:r.messages,response:r.raw},null,2);}
 el('neural-case').addEventListener('change',show);
 fetch('compiler-demos/structural-20261113/neural_check.json').then(r=>r.json()).then(data=>{rows=data;const s=el('neural-case');for(const r of rows){const o=document.createElement('option');o.value=r.artifact_sha256;o.textContent=r.claim_id+' · '+r.text;s.append(o);}const first=rows.find(r=>r.prediction.faithful&&!r.gold);if(first)s.value=first.artifact_sha256;show();window.dispatchEvent(new Event('hashchange'));}).catch(e=>el('neural-verdict').textContent=e.message);
})();
