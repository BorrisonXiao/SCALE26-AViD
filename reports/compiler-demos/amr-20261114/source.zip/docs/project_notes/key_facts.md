# Key Facts — AViD (Audio-Visual claim Disentanglement)
_Terminology follows docs/project_notes/terminology.md._

## Current Paper Direction — accepted 2026-10-14

- **Authority:** ADR-023 in decisions.md; selected by the user as the direction of the paper, likely finalized. Earlier CRF and temporal-only positioning is historical.
- **Method:** Compile NLP-derived claim structure into probabilistic logic, retain shared entity/event variables and alternative evidence assignments, and use interchangeable predefined or learned relation functions. Existing DeepProbLog-like inference is a valid backend.
- **Learning:** Freeze visual/audio models. Start with logistic regression and a one-hidden-layer MLP for relation probabilities; optional frozen BERT-style text features. Decoder-only models remain frozen parsing/evidence modules or baselines. Train small functions from claim labels; no large multimodal LLM fine-tuning or synthetic-media corpus.
- **Semantics:** Typed depiction/sound/speech/OCR support; distinguish assertions from depicted events; supported/refuted/insufficient evidence. Candidate IDs are identifiers, not predictive features.
- **Design:** [HTML proposal](../../site/proposals/probabilistic-verification.html); generator scripts/build_probabilistic_verification_proposal.py. Temporal constraints are an extension; interval union is a baseline.
- **Evaluation:** Small validated claim edits and paraphrases, source-video splits, independent final test, equal-budget baselines. Existing gold remains evaluation data. No new method result has been measured.
- **Writing:** Standard NLP terms and plain explanations are a vital user preference. Do not invent terminology or acronyms; see terminology.md.
- **Preparation update, 2026-10-15:** The HTML page now includes first-week tasks and a proposed assistant-supervised local-LLM workflow for data generation, media review, and baselines. Opt-in prompt drafts in scripts/prompts_phase2.py use verification-preparation-v1; existing inference defaults are unchanged. Automatic/silver training labels remain distinct from independently checked test labels. No generation/baseline batch has run under these drafts.

## Project Configuration

**Cluster / Paths:**
- Project root (source): `/home/hltcoe/cxiao/scale26/avid/` (scripts, configs, docs)
- Project root (experiments): `/exp/cxiao/scale26/avid/` (data, outputs, envs, logs)
- Canonical annotation surface: `exp/phase1/reports/annotation_units.tsv` (4,919 rows, 761 claims; re-emitted with proper CSV quoting 2026-06-22 — 4,920 lines, no phantom rows)
- Hypergraph: `exp/phase1/hypergraph.jsonl`
- Rule-based lexicons: `scripts/affordance_rules.py`
- **Heuristics reference**: parse→hypergraph→units rules in
  `docs/project_notes/parsing_and_unit_generation.md`; Phase-2 verification filters in
  `docs/project_notes/unit_filtering.md`.

**Phase 2 Paths:**
- Manifest: `/exp/cxiao/scale26/probing/exp/step1/manifests/manifest.jsonl` (2447 claims, 200 chunks; 716 of 761 AU claims have video)
- Videos: `/exp/cxiao/scale26/data/extracted/microvent/videos/` (933 mp4, 122 needed for AU claims)
- Media cache (frames + WAV): `exp/phase2/media_cache/` (~400 MB; 122 chunks × 12 frames + WAV; EXTRACTED 2026-06-22)
- No-video claims: `exp/phase2/media_cache/no_video_claims.txt` (45 claims)
- Gold pilot: `exp/phase2/gold_pilot/` (25 claims, 152 units; HTML annotation package; GENERATED 2026-06-22)

**Conda Environments:**
- LLM inference (vLLM): `/exp/cxiao/calm/tools/miniforge3/envs/vllm-omni`
- Rule-based text-only modality prior (which evidence channel a unit would need, judged from text alone; called affordance in the code and file names): `espnet` (requires WordNet / supersense lexicons)

**Phase 1 Model (text-only modality prior):**
- `Qwen3-30B-A3B-Instruct` (MoE, ~60 GB bf16)
- Local path: `/home/hltcoe/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507`
- vLLM settings: `gpu_memory_utilization=0.90`, `dtype=bfloat16`, `max_model_len=4096`, `seed=42`
- Inference: `temperature=0.0`, `max_tokens=1`, `logprobs=20`; first-token logprobs → renormalized soft distribution

**Phase 2 Models (verification):**
- Visual (VL): `Qwen3-VL-8B-Instruct` — `/home/hltcoe/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct`
  - vLLM: `max_model_len=16384` (needs room for image tokens), `limit_mm_per_prompt={"image": 12}`
  - Chat template: use `enable_thinking=False` → produces clean `<|im_start|>assistant\n` prefix (no thinking block)
  - Multi-modal data key: `"image"` → `List[PIL.Image]`
- Audio (Omni): `Qwen3-Omni-30B-A3B-Instruct` — `/home/hltcoe/cxiao/calm/downloads/models/qwen3-omni/30B-A3B-Instruct`
  - vLLM: `max_model_len=4096`, `limit_mm_per_prompt={"audio": 1}`
  - Chat template: use `enable_thinking=False` via **AutoProcessor** (NOT AutoTokenizer) → inserts `<think>\n\n</think>\n\n` prefix so model generates answer directly
  - Multi-modal data key: `"audio"` → `List[Tuple[np.ndarray, float]]` i.e. `[(wav_array, sample_rate)]`
  - Architecture: `Qwen3OmniMoeForConditionalGeneration` (vLLM 0.18 supported)

**Target GPU:**
- ⚠️ **2026-07-15: H200 is NOT in the QoS `cxiao_8gpu_tier`** — `gpu:h200` jobs hard-stall on
  `QOSMaxGRESPerUser` (bugs.md 2026-07-15). **Use A100**: VL-8B → 40gb; **Omni-30B → 80gb**
  (`--gres=gpu:a100:1 --constraint=80gb`); always `--exclude rack3n06` (Omni CUDA-init bug).
  The H200/H100 lines below are historical.
- H200 (rack3n05, 141 GB VRAM) — minimum for single-GPU Qwen3-30B-A3B
- SBATCH flag: `--gres gpu:h200:1`  *(← stalls under current QoS; override to `--gres=gpu:a100:1 --constraint=80gb`)*
- H100 nodes (rack3n06, rack7n07) also sufficient but frequently occupied

---

## Experiment Label Spaces

| Version | Label space | n-class | Script flag |
|---|---|---|---|
| v0 | `visual_other`, `visual_ocr`, `audio_speech`, `audio_other`, `unverifiable`, `na` (flat 6-class) | 6 | `--pass 0` |
| v1 | `visual`, `audio`, `unverifiable`, `na` (coarse 4-class) | 4 | `--pass 1` |
| v2 | `visual_other`, `visual_ocr`, `audio_speech`, `audio_other`, `unverifiable`, `na` (2-pass fine-grained) | 6 | `--pass 1` then `--pass 2` |

---

## LLM Prompts

### Pass 0 — Flat 6-class (v0 only; deprecated)

**System:** `You are a precise media analysis assistant. Answer each question with exactly one letter (A, B, C, D, E, or F).`

**User template** (fields: `{claim_text}`, `{unit_text}`, `{marked_context}`):
```
Claim: "{claim_text}"

Target unit: "{unit_text}"
Context (unit marked with **): "{marked_context}"

Which single evidence channel is most likely needed to verify this unit?

A) visual_other      — visible objects, people, actions, scenes, locations
B) visual_ocr        — on-screen text, signs, captions, titles, numbers
C) audio_speech      — spoken words, dialogue, speech, announcements
D) audio_other       — non-speech sounds (music, noise, environmental audio)
E) unverifiable      — intent, cause, subjective judgment, background knowledge
F) na   — unit is relational or incomplete; cannot be verified in
                       isolation without its arguments (e.g. bare "causing", "is",
                       "involving"; expletive "there" or "it")

Answer:
```

### Pass 1 — Coarse 4-class (v1 & v2 step A)

**System:** `You are a precise media analysis assistant. Answer each question with exactly one letter (A, B, C, or D).`

**User template:**
```
Claim: "{claim_text}"

Target unit: "{unit_text}"
Context (unit marked with **): "{marked_context}"

Which single evidence channel is most likely needed to verify this unit?

A) visual       — any visible thing: a specific object, person, action, scene,
                  location, on-screen text, sign, or caption that can be pointed
                  to in a video frame
B) audio        — any audible thing: speech, dialogue, announcement, sound, music,
                  or environmental audio that can be heard in the recording
C) unverifiable — a specific, identifiable referent exists, but what is claimed
                  about it cannot be confirmed from audio-visual evidence alone:
                  internal states ("scared", "determined"), motives, subjective
                  judgments, background knowledge ("is a veteran")
D) na           — unit is NOT a useful annotation target. Use na for:
                  (1) relational/functional words: "is", "are", "caused",
                      "affecting", "involving", "resulting in", expletive
                      "there", pleonastic "it"
                  (2) vague or underspecified referents that do not identify a
                      specific locatable thing — indefinite pronouns ("anyone",
                      "someone", "everyone", "something", "those" without clear
                      antecedent), and vague nouns ("the conditions", "the
                      situation", "the matter", "a role", "things",
                      "circumstances", "what happened")
                  TEST: can an annotator point to a specific object, person,
                  sound, or moment in the video to verify this unit? If not → na.
                  NEVER na for specific named entities or concrete objects
                  ("the typhoon", "Alaska", "the protesters", "the fire").

Answer:
```

### Pass 2 — Fine-grained visual split (v2 only)

**System:** `You are a precise media analysis assistant. Answer each question with exactly one letter (A or B).`

**User template** (only for units where pass-1 top label = `visual`):
```
Claim: "{claim_text}"

Target unit: "{unit_text}"
Context (unit marked with **): "{marked_context}"

This unit requires visual evidence. Which specific type?

A) visual_other  — visible objects, people, actions, scenes, locations
B) visual_ocr    — on-screen text, signs, captions, titles, numbers

Answer:
```

### Pass 2 — Fine-grained audio split (v2 only)

**System:** `You are a precise media analysis assistant. Answer each question with exactly one letter (A or B).`

**User template** (only for units where pass-1 top label = `audio`):
```
Claim: "{claim_text}"

Target unit: "{unit_text}"
Context (unit marked with **): "{marked_context}"

This unit requires audio evidence. Which specific type?

A) audio_speech  — spoken words, dialogue, speech, announcements
B) audio_other   — non-speech sounds (music, noise, environmental audio)

Answer:
```

---

## Phase 2 Findings (2026-06-23)

### The claim-anchor collapse (81% rate — root cause: claim_text anchor)

After running jobs 359941 (audio) + 360301 (visual), analysis of `support_annotation.tsv` found:
- **81% of multi-unit claims have ALL units receiving identical status** (supported/unsupported/unknown)
- Example: claim "A man is laying very close to the tracks" — all 5 units (full claim, "close to the
  tracks", "laying", "A man", "the tracks") each get P(no)=1.0000 across every channel

**Root cause:** Every prompt template in `verify_support.py` includes `Claim: "{claim_text}"` above
the target unit. The model anchors on the overall claim's truth value and applies it uniformly to
all sub-units. It does not reason independently about each unit.

**Fix:** Remove the `Claim:` line from all six prompt templates. The `marked_context` field (which
bolds the unit inside the full claim string) already provides enough context without anchoring.
See HANDOFF TODO-1.

### Deterministic unit filtering (na / pronoun / empty / uuid / negation / light-verb / duplicate)

Full catalogue with real examples: **`docs/project_notes/unit_filtering.md`**.
Code: `scripts/unit_filters.py` (`filter_units`), consumed by `verify_support.py` before any model call.

Net effect: **4,919 → 4,369 units** (na −104, pronoun −154, empty −135, uuid −13, negation −20,
light_verb −83, duplicate −41). The `uuid` rule (added 2026-06-24) drops units whose text is *only*
an anonymization UUID (e.g. `83eda40e-…`); UUID-containing but contentful units are kept.
Negation/light-verb drops are subsumption-guarded — a fragment is
removed only if a larger surviving unit (predicate_argument/full_claim) contains its span, so the
content is still verified. All such fragments are empirically covered. `say` is excluded from the
light-verb set (speech act → audio-verifiable). Transcript-claims `TFOEIehBwT8Q_483/_486` are NOT
dropped (decision: keep).

### Phase 2 current results (pre-fix baseline)

Output: `exp/phase2/verify_v2/reports/affordance_vs_support.md`

| Modality-prior class | n | supported | unsupported | unknown |
|---|---|---|---|---|
| visual_other | 2772 | 51% | 41% | 8% |
| visual_ocr | 1244 | 48% | 39% | 14% |
| audio_speech | 388 | 68% | 28% | 4% |
| audio_other | 106 | 52% | 42% | 6% |
| unverifiable | 154 | 60% | 26% | 14% |

Note: these numbers are unreliable for sub-unit analysis due to the claim_text anchor issue above.
Full-claim-level results (full_claim_support.tsv, 749 rows) are valid as claim-level verdicts.

### Phase 2 prompt-variant ablation (queued 2026-06-24 — jobs 361354–361357)

First run on the **v3** design (binary pass-2 + UUID filter, 4,369 units). Compares pass-1 stems
base/r1/r2/r3. DAG (all H200; Slurm serializes on the free GPU): 361354 verbalize → 361355 audio
∥ 361356 visual → 361357 aggregate (cpu). (First attempt 361349–352 had verbalize on H100 rack3n06,
which failed at vLLM EngineCore CUDA-init — node-specific; moved to H200. See bugs.md.) Results land in:
- `exp/phase2/prompt_ablation/{base,r1,r2,r3}/{verify_*.jsonl,support_annotation.tsv,reports/}`
- `exp/phase2/prompt_ablation/reports/variant_comparison.{tsv,md}` + `variant_per_unit.tsv`
Caveat: no human gold yet → variant-vs-variant + vs-modality-prior only; gold pilot still selects the winner.

---

## Phase 2 Verification Prompts

**Source of truth:** `scripts/prompts_phase2.py` — builders `pass1_user()` / `pass2_user()`.
`verify_support.py` imports them; edit prompts there, not in `verify_support.py`.

**Phase-3 additions (`prompts_phase2.py`, 2026-07-15):**
- **NEI (can't-tell / not-enough-info):** 3-way pass-1 `pass1_user(three_way=True, wording="w0")` — **W0 committed** for both modalities
  (ADR-017). E2 decomposed gate (`gate_user`/`get_gate_system`/`GATE_VERDICTS`) frozen as a **fallback**
  (deferred; NEI closed 2026-07-15).
- **Parse Normalization (PN, formerly Φ):** PN-2 LLM-SRL adjunct role prompt —
  `SRL_ROLE_SYSTEM` + `srl_role_user()` + `SRL_ROLE_LABELS` (MNR/INS/PRP/TMP/LOC/DIR/CAU/CORE/OTHER),
  `SRL_ROLE_PROMPT_VERSION="v1"`. Role signal = LLM-SRL (Qwen3-30B, frozen, validated JSON). Build plan:
  `docs/plans/avid_phase3_parse_normalization_implementation_v1.md`; math spec
  `docs/project_notes/parse_normalization_design.md` (ADR-016).

**Active version:** v4 (2026-06-24) — **binary pass-2** (ADR-006) + **pass-1 stem variants**
(ADR-007/008: active set base/r1/r2/r4/r5; r3 deprecated) + **de-news genericization & split r5
formulation** (ADR-009). Archived: v2 (two-probe pass-2 — over-fired "both"), v1 (`Claim:` anchor,
81% claim-anchor collapse; jobs 359941/360301).

**Genericization (ADR-009, 2026-06-24):** prompt wording is channel-neutral, NOT broadcast-news —
the media is arbitrary user/social video. Pass-2 option examples were de-news-ified (dropped
chyrons/banners/announcements/quoted-statements; added phone screens, handwriting, shouting,
machine/animal noise). `base` stem is unchanged (ablation control); pass-2 options are held
constant across all variants (so the stem comparison stays valid).

**Two-pass structure (per modality):**
- **Pass-1** (yes/no/unknown, letters A/B/C): union question — supported in this modality at all?
- **Pass-2** (BINARY, letters A/B; only when pass-1=yes): single symmetric forced-choice MCQ.
  visual → A=`visual_ocr` | B=`visual_other`; audio → A=`audio_speech` | B=`audio_other`.
  Subtypes mutually exclusive. Routing: pass-1=no→both no; pass-1=unknown→both unknown;
  pass-1=yes→exactly one subtype yes (A/B argmax; A/B margin kept as uncertainty signal).

**Pass-1 stem variants** (`--prompt-variant`, model loaded once, all arms in sequence):
| Variant | Pass-1 stem | Pass-2 |
|---|---|---|
| `base` | v2 union stem (control; **unchanged**) | binary MCQ |
| `r1`   | de-jargoned ("show visual evidence for the marked part") | binary MCQ |
| `r2`   | node_type-aware (entity / event / situation), WITH context line | binary MCQ |
| `r4`   | node_type-aware (r2 routing), NO context line — unit text only | binary MCQ |
| `r5`   | LLM-formulated per-unit per-modality question, NO context line (see `formulate_questions.py`) | binary MCQ |
| ~~`r3`~~ | DEPRECATED (ADR-008): LLM-verbalized referent collapsed to full-claim paraphrase | — |

**r5 pre-pass (ADR-009):** `formulate_questions.py` writes the per-unit question via **two
independent single-modality Qwen3-30B calls** (`FORMULATE_VIS_SYSTEM` / `FORMULATE_AUD_SYSTEM`,
shared `FORMULATE_USER_TMPL`) in one vLLM sweep — independence prevents the visual/audio questions
from anchoring on each other and keeps the formulator blind to modality fit. Design = R5-A
("existence-first", grounded in proposal §7). Output schema (`visual_question`/`audio_question`)
and cache (`claim|unit|modality`) feed `verify_support.py` unchanged.

**Template vars:** `unit_text`, `marked_context`, `node_type`, `unit_type`, `verbalized`, `formulated`.
**Output schema unchanged:** `{channel}_verdict` / `{channel}_dist` ∈ {yes,no,unknown} per channel
(exactly one subtype yes when pass-1=yes) — so `build_support_annotation.py` is untouched.

---

## Experimental Results

### Group: LLM Modality-Prior Inference — Label Space & Prompt Ablation

*Goal: determine the best label space and prompting strategy for per-unit text-only modality priors over annotation_units.tsv.*

| ID | Date | Version / Config | Units | visual(_other) | visual_ocr | audio(_speech) | audio_other | unverifiable | na | Output |
|---|---|---|---|---|---|---|---|---|---|---|
| exp-001 | 2026-06-17 | v0: pass-0, flat 6-class, Qwen3-30B-A3B | 4,768 | 68.8% | 8.3% | 9.5% | 2.0% | 0.3% | 11.1%* | `exp/v0/` |
| exp-002 | 2026-06-21 | v1-narrow: pass-1 4-class, narrow `na` (job 357515) | 4,919 | 87.0% | — | 8.9% | — | 1.9% | 0.1% | `exp/v1/archive/` |
| exp-003 | 2026-06-21 | v1-revised: pass-1 4-class, broad `na` (job 357532) | 4,919 | 84.2% | — | 10.4% | — | 3.2% | 2.2% | `exp/v1/` |
| exp-004 | 2026-06-21 | v2: 2-pass, broad `na` (pass-1 job 357532 → pass-2 job 357533) | 4,919 | 58.1% | 26.1% | 8.1% | 2.2% | 3.2% | 2.2% | `exp/v2/` |

*v0 `na` stored as stale key `not_annotatable` in raw jsonl; `affordance_annotation.tsv` not regenerated for v0.*
*v0 used 4,768 units (older annotation_units.tsv snapshot); v1/v2 use current 4,919-row version.*

### Group: Phase 2 Support Verification (multimodal — measured AV support)

*Goal: measure per-unit AV support (not the text-only prior). VL-8B for visual, Omni-30B for audio; verdicts from first-token logprobs.*

| ID | Date | Variant / Config | Units | supported | unsupported | unknown | vis other/text/no | aud speech/other/no | Output |
|---|---|---|---|---|---|---|---|---|---|
| exp-r5e | 2026-06-26 | r5e v6: binary pass-1 (A=yes/B=no, no unknown; ADR-014) + manifest patch (41 claims fixed) | 4,068† | 64.8% | 34.6% | 0.5%‡ | 47.8 / 6.9 / 44.8 | 21.4 / 6.7 / 71.3 | SUPERSEDED — stale annotation |
| exp-r5e-v2 | 2026-06-29 | r5e v6: full rebuild from current reference.json (2375 claims, data-lineage fix) | 15,239§ | 77.1% | 22.9% | 0 | 38.9 / 16.8 / 44.4 | 46.5 / 2.7 / 50.7 | `exp/phase2/prompt_ablation/r5e/` |

*†4,369 verifiable units − 301 formulation-`na` (6.9%, atoms only — ADR-011). SUPERSEDED — annotation built from stale reference.json (pre-Jun-18 update); 4 UUID-named claims caused spurious no_video=True.*
*‡21 unknown rows = 4 truly unmatched claims (no_video=True). Zero model-generated unknowns.*
*§17,813 annotation rows − 1,609 formulation-`na` (9.0%) = 15,239 verified; 2375 unique claims (3.12× expansion from reference.json update). Zero unknown, zero no_video, zero UUID claims. Jobs 370558–370560 on rack3n05 H200. Readable view: `r5e/support_readable.tsv` (10 cols incl. visual_why/audio_why; zero empty why columns).*

### Group: Phase-3 Parse Normalization (PN) — the checkable-unit tree (T*) + F₃ checkability (ADR-016/018)

*Goal: rewrite the raw UD parse into checkable verification units (T*) before the tree-CRF. Pipeline `PN_llm ∘ PN_srl ∘ PN_det`; released as `exp/phase3/trees/trees_ud_star.jsonl` + `exp/phase3/nodes/tree_units_ud.tsv`.*

| Stage | Script | Job | Output |
|---|---|---|---|
| PN-1 det | `normalize_parse.py` | CPU | tight-unit + case-only MERGE; T* v0 |
| PN-2 SRL | `run_pn2_srl.py` | 400840 | adjunct roles (MNR/INS→verif-mod, PRP→core, TMP→na); T* v1 |
| PN-3 F₃ | `run_pn3_check.py` | 402236 (v1) / 402377 (v2) | checkability na (normative/subjective/abstract); **T* v2 FINAL** |

- **F₃ (PN_llm)**: 10,274 targets → **1,391 na (13.5%)** [entity 342 · attribute 629 · event 417 · card 3]. Prompt `CHECKABLE_*` (`prompts_phase2.py`, **v2**), Qwen3-30B, temp 0, `« »`-marked full-claim context. v2 fixed v1 over-flip of named/concrete phenomena (293 rescued; proper-noun entity na 168→64); normatives still na.
- **Tight units** (ADR-018): non-event unit = head phrase (`UNIT_BOUNDARY_DEPRELS` children excluded); events keep proposition. Clause-length units 1,334 → 147.
- **`gold_pilot_v3`**: `exp/phase3/gold_pilot_v3/` — 200 claims, 1,152 rows (927 probed / 225 na). Reproducible regen: **`scripts/run_pn_regen.slurm`**.
- **ADR-019 refinement (2026-07-20, FINAL surface):** 4 fixes — (1) events+root use full subtree (proposition; root-covers-claim 48%→96%, truncation 1,375→0); (2) suppress bare `amod`/`advmod`/`nummod` by deprel (`clear`/`still`/`1`); (3) case marker only for MNR/INS (`clear skies` not `with clear skies`; `by hand` kept); (4) `TMP→na` only non-clausal + SRL prompt **v2**. Result: **probed 9,774**, F₃ **828 na (10.6%)**, `gold_pilot_v3` 775 probed / 377 na. Ran on **2× A100-40gb tp=2** (job 413160). Limitation: mis-grouped temporal clauses (verb absorbed, `rocket lands`) still na → mitigated by proposition-root.
- ✅ **M2/M3 (per-node probing then tree-CRF inference) RE-RUN on the final ADR-019 T\* (2026-07-22, jobs 416684/685/686)** — STALE flag cleared.
  M3 claim verdict (n=2375): **supported 56.5% / partially 27.5% / unsupported 16.0%**. Per-unit grounding:
  visual-only 34.3% · audio-only **16.6%** · both 25.8% · neither 23.3% (audio uniquely grounds 16.6% of
  units vs <1% of whole claims in the pilot). Cache cleared first (key = claim_id|unit_id, no unit text);
  calibrate+CRF chained via `scripts/run_m2_finalize.slurm`. Stale artifacts in `.pre_adr019_stale_20260722/`.

---

### Analysis Notes

#### 2026-07-29 — Corrected compositional faithfulness: ancestor-aware perturbations give AViD a clear edge on lenient detection

Perturbation set: 5,556 false-by-construction claims (1,796 negation / 1,880 entity-swap "binding" /
1,880 argument-removal; gold=unsupported). Tree-CRF (`decomp_m3_perturb_parentfix`) vs a flat
whole-claim multimodal-model baseline (`flat_verdicts_parentfix`). Detection = fraction labelled NOT supported;
the primary lenient metric counts `partially_supported` as detected. Results independently
re-derived and recorded in `reports/faithfulness_parentfix/table.tsv`:

| split | n | CRF strict | CRF lenient (incl. partial) | flat |
|---|--:|--:|--:|--:|
| negation | 1796 | 53.5% | 88.1% | 84.4% |
| binding | 1880 | 71.4% | 93.0% | 75.5% |
| removal | 1880 | 24.2% | 71.1% | 31.1% |
| **ALL** | 5556 | **49.7%** | **84.0%** | **63.3%** |
| natural (want LOW hard-flag) | 2375 | 16.0% | (43.5% incl. partial) | 25.0% |

- **Read:** on the primary lenient metric, AViD beats the whole-claim baseline on every perturbation
  type: negation **88.1% vs 84.4%**, binding **93.0% vs 75.5%**, and argument removal
  **71.1% vs 31.1%**. Overall: **84.0% vs 63.3%** (+20.7 points).
- The strict metric remains a different operating point: AViD is slightly lower on strict binding
  (71.4% vs 75.5%) and strict removal (24.2% vs 31.1%) because many detected errors are assigned
  `partially_supported`, not hard `unsupported`. State clearly that the poster reports lenient
  detection.
- **Bug invalidating the 2026-07-24 binding/removal comparison:** perturbation generation changed only
  the edited node while ancestor/root `subtree_text` stayed natural. M2 probes use `unit_text`, so AViD
  saw an unedited root while the flat baseline saw the edited whole claim. The fixed generator
  propagates the span-anchored edit through every ancestor and remaps spans. The corrected run
  re-probed 3,087 changed prompts and reused 13,022 byte-identical prompts.
- Artifacts: `perturb_parentfix/{perturbed_trees.jsonl,perturbed_units.tsv,gpu_delta_manifest.json,`
  `unaries_perturb.jsonl,decomp_m3_perturb.jsonl}`,
  `baseline_parentfix/flat_verdicts.jsonl`, and `reports/faithfulness_parentfix/`.
  Jobs 429036/429037/429038 completed successfully; zero missing rows.

#### 2026-07-23 — PN-3 verif-mod ablation: real unit cleanup, but leaves verdicts unchanged (= CRF robustness result)

Closing the PN-3 precedence gap (checkability also vets `verif-mod` pn2 nodes; `run_pn3_check.py
--also-verif-mod`, ablation job 418821, H100, 8m59s):
- **23 of 218 verif-mod units → na** — correctly weak manner/instrument fragments (`in part`, `in a big
  way`, `in the best way`, `of-its-kind`, `very clear`). Probed rows 9,775 → 9,752.
- **Downstream M3 (CRF on the ablated tree): verdict dist unchanged** (56.5/27.5/16.0); **1/2375 claims
  changed (0.04%)** (`TzzhcBIczf_M_2094` partial→supported — removing a spurious soft-gate).
- **Interpretation:** doubles as the ADR-015 **CRF-insensitivity-to-na-errors** robustness result —
  unit-level role/na errors (incl. the LLM-vs-trained-SRL MNR/INS disagreement, exp SRL-agreement) are
  **downstream-inert**. This is the empirical defense for the SRL-agreement reviewer concern: even a 24%
  MNR/INS precision moves claim verdicts by 0.04%. Adopt the change (correct + ~free); trained SRL stays a
  one-shot validation, not a pipeline component.
- Artifacts: `exp/phase3/ablation/{trees_ud_star_vm.jsonl, tree_units_vm.tsv, pn3_checks_vm.jsonl, decomp_m3_vm.jsonl}`.


#### 2026-07-16 — PN unit surface: the sidecar-field trap + content-subtree over-capture

- **Sidecar trap**: PN wrote its decisions to *new* fields (`pn_unit_text`/`role`/`comp`) without mutating the base `content_subtree_text`. Readers that kept reading the base field silently showed **pre-PN** units ("hand" not "by hand") even though "PN ran". Lesson: when a pass uses sidecar fields, audit *every* downstream reader.
- **Over-capture**: `content_subtree_span` folded ALL content descendants → clause-length "entity" units (a copular root swallows its subject). A probe unit must be the node's LOCAL head phrase; nested arguments/obliques/clauses are their own nodes. **Events are the exception** (proposition-level probe).
- **F₃ is context-dependent**: the same word flips ("right" = direction vs correctness; "leaves" = foliage vs produces) → it must be an LLM residue pass seeing the full claim, not a lexicon. Keep examples domain-neutral; verify BOTH directions (normatives stay NA, concrete phenomena stay CHECKABLE) on-corpus before freezing.

#### 2026-06-21 — `na` rate is highly sensitive to option wording

- v0 (flat 6-class): 11.1% `na` — over-prediction from ambiguous F wording ("cannot be verified in isolation without its arguments") applied to any context-dependent unit, including clear entities.
- v1-narrow (first pass-1 attempt): 0.1% `na` (5 units) — definition too restrictive ("never a noun or noun phrase").
- v1-revised (broad `na`): 2.2% (104 units) — added two explicit criteria: relational/functional words AND vague/underspecified referents with a pointability test.
- **Lesson**: `na` wording needs both a positive description of what qualifies AND a "NEVER na" guard for concrete entities. The pointability test ("can an annotator point to a specific object/person/sound?") is the clearest heuristic.

#### 2026-06-21 — visual_ocr rate (26.1% in v2) driven by protest-sign claim cluster

- v2 pass-2 produced 26.1% `visual_ocr`, vs v0's 8.3% (from single 6-class prompt).
- Root cause: the dataset contains a dense cluster of protest/demonstration claims where sign text is the primary verifiable element ("a sign that says X", "holds a sign reading Y"). Pass-2 correctly identifies these as `visual_ocr`.
- One concern: some functional words within sign-related claims (e.g. relative pronoun "that" in "sign **that** says") also receive `visual_ocr` rather than `na`. ~50 cases have exactly 0.500 visual_other/visual_ocr confidence — genuine ambiguities.
- **For annotation**: the high `visual_ocr` rate is largely legitimate; no corrective action needed unless the annotation task specifically excludes sign text.

#### 2026-06-21 — Audio is almost entirely speech

- v2: audio_speech mean confidence ≈ 0.998; audio_other is 2.2% of all units (106 units).
- This makes sense for news/social-media claims: claims are about what people say, not ambient sound.
- Pass-2 adds almost no ambiguity for audio — if pass-1 says `audio`, it's overwhelmingly `audio_speech`.

#### 2026-06-25 — vLLM/model QUIRK: Qwen3-Omni emits a role preamble in explain mode

- In the r5e answer-first explain mode, **Qwen3-Omni-30B (audio)** frequently prepends
  `"Assistant: "` before the verdict letter (e.g. `"Assistant: B) no — …"`) — seen in **33%** of
  audio rows. **Qwen3-VL-8B (visual) does not** (answers letter-first, 0% preamble).
- Impact: reading `logprobs[0]` for the verdict then lands on the preamble token, **not** the letter,
  corrupting the calibrated distribution (caught via 5% verdict↔text contradictions in the first r5e
  audio run). The non-explain (`max_tokens=1`) path is unaffected — the model answers letter-first
  when not asked to explain.
- **Fix** (`verify_support.py::_verdict_logprobs`): scan the first ~10 generated positions for the
  position whose argmax decodes to an option letter, and read the distribution there; falls back to
  position 0 (so the 1-token path and VL are unchanged). `_clean_reason` also strips a leading role
  echo. After the fix the audio re-run had **0 preamble, 0 contradictions**.
- **Lesson**: for any future explain/generative logprob read, do NOT assume the answer token is at
  position 0 — scan for it; different model families differ.

#### 2026-06-26 — r5e qualitative review: 4 patterns (drives ADR-013 + open items)

Review of `exp/phase2/prompt_ablation/r5e/support_readable.tsv` (+ `na_units_r5.tsv`):

1. **Visual `unknown` = mislabeled absence (→ ADR-013).** 26% of units are visual `unknown`; **91%**
   of those reasons contain a negation ("no luggage visible"). The 8B VL model logs *absence* as
   *indeterminate*, pushing units `unsupported → unknown`. Audio `unknown` is only 6% (30B Omni
   commits) → the 4× gap is a model artifact, not data. Fix = sharpened B/no vs C/unknown wording.
2. **Audio `audio_speech`=yes is weakly grounded.** Of 1,021 speech-yes units, only **43% cite actual
   speech** (quote/"says"/"mentions"); **15% have an empty reason**; **6% parrot the option label**
   ("yes — the audio contains clear evidence for this"). Consistent with the ADR-012 dual-route
   ("…or does anyone mention X?") being leading. audio_other groundings, by contrast, are strong
   (ocean→"crashing waves", tram→"rumbling and clanking").
3. **Mention-route dilutes disentanglement.** **626 units (15%)** are yes on BOTH visual and
   audio_speech — largely visible things a narrator also names. For a *modality-needed* probe this
   erodes the audio channel's discriminativeness. Reassuring counter-evidence: when a unit is NOT
   named, the route does say no (e.g. "Kipnuk, Alaska" audio = no). Consider reporting the two audio
   routes (named-in-speech vs characteristic-sound) separately.
4. **na-triage (v3) residual errors.** 301 na look mostly right (function words, light verbs,
   abstractions), but a few perceptible units are wrongly rejected — "struggling" (cars struggling
   through floodwater), "screen", "says" (street-sign text → should anchor OCR; note the deterministic
   filter KEEPS "say" as a speech act, so triage and the lexical filter disagree on it). And some
   abstract units are kept that arguably should be na — "want" → degenerate visual question "Is
   someone shown expressing a desire?". Also: UUID anonymization strings leak into a few formulated
   questions on full-claim units ("…near a specific location marked 832a2cfc-…").

---

## Phase 3 — Parse Normalization Artifacts (2026-07-15)

### T* v1 (FINAL normalized tree surface)

| Artifact | Path | Description |
|---|---|---|
| T* v0 (PN-1) | `exp/phase3/trees/trees_ud_star.jsonl` | Intermediate; overwritten by PN-2 |
| **T* v1 (FINAL)** | `exp/phase3/trees/trees_ud_star.jsonl` | 2,375 claims, 18,511 nodes; comp/role/pn_unit_text/pn_stage fields |
| PN-1 edit log | `exp/phase3/trees/pn_edits.jsonl` | Per-claim: TYPE/MERGE/REATTACH edits |
| PN-2 role log | `exp/phase3/trees/pn_roles.jsonl` | Per-edge SRL role labels (3,253 edges) |
| PN-2 cache | `exp/phase3/trees/pn2_cache.jsonl` | Resumable Qwen3-30B SRL call cache |
| **Probe TSV (T* v1)** | `exp/phase3/nodes/tree_units_ud.tsv` | **13,027 probed rows** (−53 PN-1 temporal, −500 PN-2 temporal) |

### PN-1 stats (normalize_parse.py)
- Input: 13,580 probed nodes → Output: 13,527 (−53 temporal adjuncts TYPE'd → inert-mod/na)
- MERGE: 2,894 obl/nmod nodes → pn_unit_text = subtree_text (full PP)
- REATTACH: 31 light-verb roots → re-rooted onto content predicate

### PN-2 stats (run_pn2_srl.py, Qwen3-30B, job 400840, A100-80gb)
- Input: 3,253 adjunct edges (obl=1696, nmod=1253, advcl=304)
- Role distribution: LOC=1160, TMP=501, PRP=440, CORE=369, DIR=325, CAU=202, INS=131, MNR=100, OTHER=25
- verif-mod edges added: **231** (MNR=100, INS=131; soft necessity strength λ_soft=1.0 in the CRF)
- TMP residue caught by PN-2 (missed by PN-1): **501** → now na, not probed
- Net TSV: 13,527 → **13,027** rows (−500 from TMP)

### CRF with verif-mod (2026-07-15)
- `tree_crf.py`: `edge_potential` now handles `verif-mod` — the soft necessity gate (λ_soft, default=lam/3), a relaxed version of the necessity-edge strength that discourages a supported parent whose required child is absent
- `run_crf_inference.py`: reads `comp` field from T* nodes; `--lambda-soft` arg
- CRF on T* v1 (r5e unaries, λ=3.0, λ_soft=1.0): supported=59.5%, partial=20.1%, unsup=20.3%
- CRF on T* v0 (no verif-mod): supported=62.0%, partial=18.7%, unsup=19.4%
- CRF on raw T: supported=61.3%, partial=19.0%, unsup=19.6%
- verif-mod soft-gate: 22 claims shifted toward partial/unsupported; negation flip intact (23.0% unsup in negated vs 20.3% overall)

### M2 Re-probe + Calibration + M3 CRF (2026-07-16)

| Artifact | Path | Description |
|---|---|---|
| M2 visual | `exp/phase3/nodes/verify_visual_star.jsonl` | 13,026 rows, 3-way W0 (yes/no/cant_tell) |
| M2 audio | `exp/phase3/nodes/verify_audio_star.jsonl` | 13,026 rows, 3-way W0 |
| M2 cache vis | `exp/phase3/nodes/m2_cache_visual.jsonl` | Resumable cache, prompt v6-m2-w0 |
| M2 cache aud | `exp/phase3/nodes/m2_cache_audio.jsonl` | Resumable cache |
| Calibrated vis | `exp/phase3/nodes/calibrated_visual_star.jsonl` | 13,026 rows, T=3.0 applied |
| Calibrated aud | `exp/phase3/nodes/calibrated_audio_star.jsonl` | 13,026 rows, T=2.0 applied |
| **CRF unaries** | `exp/phase3/nodes/unaries_ud_star.jsonl` | Combined vis+aud in CRF format {no,ocr,other}/{no,speech,other} |
| **M3 decomp** | `exp/phase3/crf/decomp_m3.jsonl` | CRF verdicts with calibrated 3-way unaries |

**M2 raw distribution stats:**
- Visual (jobs 401213, A100-40gb, 1h27m): 50.9%Y / 35.1%N / 13.9%C; 43% entropy<0.1 (saturated)
- Audio (job 401214, A100-80gb, 19m): 40.4%Y / 50.9%N / 8.7%C; 11.4% entropy<0.1

**Temperature calibration (calibrate_m2.py, CPU):**
- Dev set: 1415 root nodes, gold = CRF verdict (supported→yes, unsupported→no)
- T_vis=3.0: NLL 2.45→1.11 (Δ-1.34); ECE 0.30→0.15; frac<0.1 43%→4.5%
- T_aud=2.0: NLL 1.90→1.32 (Δ-0.59); ECE 0.26→0.14; frac<0.1 11%→10.6%
- Note: dev-set NLL optima were T=7.0/10.0 but led to near-uniform dists (entropy→0.95/1.01);
  T=3.0/2.0 chosen as conservative values preserving CRF signal while reducing worst saturation
- NEI→CRF mapping (per-node emission): φ[NO]=P(no)+P(ct)/3; φ[A]=P(yes)/2+P(ct)/3; φ[B]=P(yes)/2+P(ct)/3

**M3 CRF verdicts** (λ=3.0, λ_soft=1.0):
- ⚠️ SUPERSEDED (computed on pre-ADR-019 units): supported=56.4% / partially=24.3% / unsupported=19.3%
- **VALID (2026-07-22, final T\*, n=2375): supported=56.5% (1342) / partially=27.5% (653) / unsupported=16.0% (380)**
  — refresh moved ~3.5pt unsupported→partial (proposition-roots capture more per claim).
- Per-unit M2 (W0 3-way): visual 60.1%Y/27.2%N/12.7%C · audio 42.4%Y/49.9%N/7.7%C.
- Per-unit grounding cross-tab: visual-only 34.3% · audio-only 16.6% · both 25.8% · neither 23.3%.

### M3 readout semantics + paired perturbation result (2026-07-30)

- The model contains **two independent tree CRFs**, one visual and one audio.
  There is no cross-modal edge or cross-channel belief-propagation message.
- Per modality, the 3-state marginal is over evidence subtypes:
  visual `{no, ocr, other}` and audio `{no, speech, other}`. Support mass is
  therefore `s_visual=P(ocr)+P(other)=1-P_visual(no)` and
  `s_audio=P(speech)+P(other)=1-P_audio(no)`. Do not take the largest single
  entry of either 3-way distribution.
- The current scalar verdict readout is
  `score=max(s_visual,s_audio)` followed by supported/partial/unsupported
  thresholds. This `max` produces a verdict score, **not** a modality label.
- `VIDEO`/`AUDIO`/`BOTH`/`NEITHER` is a separate grounding attribution computed
  from the retained local visual/audio probe decisions. Thus a root can have
  `score=max(.715,.861)=.861 → supported` and still be labeled `BOTH` because
  both local root probes say yes.
- Fair paired edit detection keeps only perturbations whose unedited source is
  supported by both AViD and the flat baseline. On that shared subset:

| split | paired N | AViD downgrade | flat downgrade |
|---|---:|---:|---:|
| negation | 944 | 83.7% | 81.2% |
| binding | 996 | 87.9% | 65.8% |
| argument deletion | 996 | 48.7% | 7.8% |
| **ALL** | **2,936** | **73.2%** | **51.1%** |

### Semantic factor-tree v1 + gold-v3 pilot (2026-08-13)

- **Representation:** `T_UD` remains the dependency scaffold; `T*` is the normalized parser-traceable unit tree; `G*` is the executable bipartite semantic factor tree. Local entity/event/state variables are probed independently; property and binding relations are explicit factors; `y:claim` is latent and never directly probed.
- **Full-corpus compile:** 2,375 claims → **11,741 local variables**, **9,356 edge factors**, **2,714 local property/logic factors** (`exp/phase3/semantic_v1/semantic_factor_trees.jsonl`). All factor graphs pass connected/acyclic topology checks. Four records have upstream overspanned local units and are explicitly flagged; no claim-ID exceptions were added. Literal hyphen chains are repaired generically before compilation (`close-up`, `before-and-after`).
- **Prompt audit:** frozen rule `0.8 × behavior + 0.2 × required-instruction coverage`, shorter exact tie. Selected **`sfu-v3` / `sf-v3` / `sfq-v4`**. The revised question scores are v1/v2/v3/v4 = `0.825/0.850/0.925/1.000`; v4 uniquely covers natural display phrases, possessives, and minimal grammatical context while preserving independent/local targets. Fixtures were domain-neutral; stable-hash AViD shapes stayed local and **zero AViD claims were sent to the external judge**. Latest question report: `exp/phase3/semantic_v1/prompt_audit_v4b/report_question.json`.
- **Gold-v3 annotation package:** **43 claims / 507 human-visible targets**, the same still-unannotated sample as gold-v2 for direct comparison. Artifacts: `exp/phase3/gold_v3/{index.html,claims.tsv,semantic_units.tsv,build_manifest.json,serve.py}`. The UI hides latent composition/fixed operators and internal relation labels; the only normalization gold is binary `not_na`/`na`. There is no question-quality field.
- **Annotation server:** `c1:pilotv3` now serves gold-v3 on `http://127.0.0.1:9000`; verified HTML `200` and MP4 byte-range `206` on 2026-08-13.
- **Local text-model status:** selected prompts + validated batch runners implemented in `scripts/run_semantic_text_pass.py` and `scripts/run_semantic_question_local.py`. Slurm was unreachable; a cached Qwen3-0.6B CPU trial was impractically slow. No external service received AViD content. The served pilot uses checked deterministic natural-language fallbacks; the `sfq-v4` rewrite cache is still pending a local GPU or explicit external-processing authorization.
- **Proposal:** `site/proposals/semantic-factor-tree.html`; decision: ADR-021.

### Group: ADR-023 local-model data preparation and baselines — 2026-10-15

**Artifacts:** `exp/probabilistic_verification/pilot_20261015/`; inspection page
`site/reports/verification-pilot.html`, linked from section 17 of the accepted
proposal. This is development work, not held-out paper accuracy. All labels are
proposed/model-produced or assistant frame reviews; there is no new human gold.

| Run | Job | Frozen model / input | Completed outputs | Inspected candidate quality |
|---|---|---|---|---|
| Free-form v1 | 1028631 | Qwen3-VL-8B; text descriptions for generation, eight frames for visual verification; 10 videos | 21 claims, 232 requests; 00:09:41 L40S | 11 proposed/admitted variants; 0 clean binding negatives, 4 usable positive controls |
| Free-form v2 | 1028656 | Same ten inputs/model; revised generation/decomposition/review prompts | 17 claims, 152 requests; 00:03:32 L40S | 10 proposed, 7 admitted variants; 0 clean binding negatives, 3 usable positive controls |
| Free-form v3 | 1028666 | Same ten inputs/model; explicit intentional-negative instruction | 33 claims, 252 requests; 00:04:50 L40S | 29 proposed, 23 admitted variants; 1 clean binding negative, 5 usable positive controls; separate easy negative |
| Specified attribute swaps | 1028679 | Same frozen model; two full-resolution-checked fact plans | 5 claims, 46 requests; 00:01:08 L40S | 4 proposed, 3 admitted variants; 2 clean negatives and 1 usable paraphrase; duplicate dropped |
| Checked decomposition diagnostic | 1028700 | Same two plans and cached whole-claim/review/text-only observations; manually specified relations and matched atoms | 20 new part requests; 00:00:41 L40S | Diagnostic logical forms, not automatic-parser performance |

Total allocated GPU time: **00:19:52 (1192 seconds, about 0.33 GPU-hours)** on one
L40S per job, including startup. **702 new model requests**; 15 observations reused
by the checked-form diagnostic. These are repeated development inputs, not five
independent datasets. New artifacts were about 5.5 MB before final report updates;
no model downloads, dependency installs, audio inference, or model training.

The clothing swap preserves the red hood and swaps only the woman/man outer-shirt
colors. Whole-claim support changes **0.999795 → 0.0000213**. Aircraft/bus color
swap: **0.9999997 → 0.0000101**. Both edited claims receive unknown rather than
refuted from the letter-score baseline, despite the JSON reviewer choosing refuted.
Checked component questions have identical inputs within each pair and cannot
separate them; this is an expected representation control. Complete-relation
conjunction does not establish a gain over whole claims and introduces uncertain
local evidence on the clothing seed. Do not report these two cases as method gains.

**Analysis:** Free-form outputs reorder clauses but label them role swaps, refuse
intentional negatives, change extra properties, or remain true under another
participant assignment. Automatic decomposition can add relations, drop bindings,
or retain disputed attributes in atomic questions. Current recommendation: check a
small fact list, swap specified arguments/properties in code, then use the LLM for
surface realization (writing those facts fluently). This refines preparation under
ADR-023; it does not change the paper direction or demonstrate inference/learning.

**Seed corrections:** Full-resolution frame_099 for PxRXEWfLiL3w_E7y_0000 places
chair stacks on the road, correcting the assistant's initial sidewalk description.
Shorts versus cropped trousers in 12Nvpg23obr7TIhT_0000 remains ambiguous. Inputs and
later corrections are preserved separately; both sources are excluded from the
larger-model generation list. `seeds_eligible.jsonl` has eight videos, all outside
the existing 102-video reservation. This is not a final duplicate-checked split.

**Current queued work:** Qwen3-30B generation **1028682**, one A100-80GB, version v3
on the eight eligible seeds; dependent visual review/baselines **1028694**, one
A100-40GB. Both pending at the last check. They replace canceled pending v1 jobs
1028628/1028629. Check `logs/`, `v3/`, and scheduler accounting before claiming
completion or submitting duplicates. `run_verification_pilot.py` prefers
`seeds_eligible.jsonl` when present and logs the chosen input path.

**Implementation:** Canonical v1/v2/v3 generation/decomposition/review prompts and
specified-fact realization prompt are in `scripts/prompts_phase2.py`. New runner:
`scripts/run_verification_pilot.py`; evaluator: `scripts/evaluate_verification_pilot.py`.
Exact prompts/configuration/frame hashes, raw outputs, costs, proposed labels, and
assistant reviews are separate. Baselines preserve supported/refuted/unknown;
missing scores are errors. Scores are uncalibrated A/B/C token probabilities.
No-media text-only controls are evaluated for expected unknown, not against
full-media labels. Do not use these labels as an independent final test.

### Site publication and larger-model status update — 2026-10-15

- The publishing Git repository is **avid/site/**, not avid/. Its origin is
  git@github.com:BorrisonXiao/SCALE26-AViD.git; branch main serves GitHub Pages.
  Empty parent Git metadata does not mean the nested site cannot be pushed.
- Published commit **1452d8f0b6007db9c8b97122cd58ea0c7905dcf7**, Pages workflow
  **38764262158** succeeded. Main design section 18 contains five real generated
  examples with evidence and source-record links. All four checked live pages
  returned HTTP 200 and matched their local SHA-256 hashes.
- Direct URL: https://borrisonxiao.github.io/SCALE26-AViD/proposals/probabilistic-verification.html#generated-examples
- New generator: scripts/build_verification_examples.py. Source records remain in
  the pilot directory; rebuild the proposal/report with their existing generators.
  The report is explicitly limited to the five inspected L40S configurations.
- **Supersedes the pending-job status above:** 1028682 and 1028694 both completed,
  elapsed 00:13:31 / 00:05:51 respectively. Their v3/ output has 32 claims from eight
  eligible seeds, with automatic review/baseline files. Separate sample-quality
  inspection remains pending; do not treat those outputs as independent gold or
  include them in the earlier 702-request / 0.33-L40S-GPU-hour pilot totals.

### Group: Restricted compiler and native DeepProbLog training — 2026-10-22

*Goal: implement source-linked claim compilation and verify bounded inference and
claim-level gradients before larger data preparation or model training.*

| Run | Data and configuration | Measured result | Scope | Artifacts |
|---|---|---|---|---|
| compiler_20261022 | Frozen cached Stanza English parser; restricted UD-to-logic compiler; DeepProbLog 2.0.6 / ProbLog 2.3.0 / PySDD 1.0.6; CPU | 23 semantic/probability/training tests pass. Automatic parsing: 7 intended claims compile, 8 out-of-fragment cases are rejected, 3 intended claims require parse review (15/18 expected outcomes). | Hand-selected regression checks, not a representative parser benchmark | exp/probabilistic_verification/compiler_20261022/ |
| Sample relation training | Two paired color claims from one development video; six real frozen Qwen3-VL-8B observations from October 15; 6 → 64 → 3 residual MLP, 643 parameters; Adam 0.01, 40 epochs, seed 7 | Mean training loss 4.225400781 → 0.000000115190211; 80 finite classifier gradient calls; weight change L2 3.102411689. CPU training 1.029 seconds in the recorded run. | Same training examples shown before/after. Assistant development labels; no independent test or generalization claim. | training.json, traces.json, relation_classifier.pt |

- Real supported claim: The aircraft is gray and the school buses are yellow.
  Fixed-logic S/R/U = 0.9999952600 / 0.0000000704630 / 0.000004669506.
  Swapped claim: S/R/U = 0.000000000102596 / 0.000203837540 / 0.999796162358;
  after sample training, refutation = 0.999999994435 on that same training claim.
- An explicit no-media control remains unknown with probability 1 before/after
  training and is excluded from training. No model output is invented for it.
- Three controlled event cases use stipulated probabilities, not model outputs:
  Alice hugs Bob and Carol hugs Dave. Matching Alice/Bob support is 0.93158505;
  Alice/Dave or reversed Bob/Alice support is 0.01950399, refutation 0.92238204.
  Complete tuples retain a shared event candidate; roles cannot select different events.
- Real candidates are manually specified depicted aircraft/bus referents, not
  automatically detected tracks. Entity variables bind at their shared scope;
  event existence stays inside negation. Unsupported syntax yields diagnostics.
- Fixed entity observations and logic do not train. The initial MLP is mainly
  score calibration on relation-sensitive frozen observations; it does not learn
  visual perception or discover semantic roles in this demonstration.
- Uses an isolated env at envs/probabilistic-verification with existing PyTorch
  2.10.0+cu128 exposed through system-site-packages. No base environment changes,
  model downloads, new perception requests, GPU allocation, or audio evaluation.
- DeepProbLog's near-identity simplification required a local compatibility
  override and double precision. All root distributions are checked within 1e-9
  of total mass 1; independent enumeration checks include high-confidence scores.
- Code: scripts/probabilistic_verification/, compile_verification_claim.py,
  run_verification_pipeline.py, build_verification_pipeline_report.py. Tests:
  tests/test_probabilistic_verification.py. Instructions:
  docs/probabilistic_verification_implementation.md. HTML:
  site/reports/verification-pipeline.html, linked by the Implementation sub-tab.
- **Published:** site commit 9526dae761eb8088d983be8ca2b9d14edcbafdcf;
  Pages workflow 39723271163 succeeded. Six live page/artifact URLs returned 200
  and matched local bytes. The downloadable source/cached-input replay reproduces
  every displayed verdict distribution within 1e-12.
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html


### Group: Frozen visual/audio features and separate evidence trees — 2026-10-22

- **User request:** Put the recommended steps in the HTML checklist and carefully
  start feature inspection and separate visual/audio trees. ADR-023 remains the
  direction. No new feature-based classifier training or held-out evaluation.
- **Run:** `exp/probabilistic_verification/av_features_20261022/`. One main
  development video (aircraft/buses, first 12 seconds), one clothing/stadium clip
  as an unrelated-media control, 12 proposition probes × four conditions × two
  modalities = **96 final feature forward passes**. Ten claim/control traces and
  **30 actual DeepProbLog verdict distributions**. Do not count propositions as
  independent source videos or use proposed labels to report accuracy.
- **Features:** Frozen Qwen3-VL-8B (4,096 dimensions) and Qwen3-Omni-30B-A3B
  thinker (2,048 dimensions); final prompt-token decoder state before any answer.
  Inputs contain a full proposition plus frames/audio; no paired claim or target
  label. Visual frames 0/5/10 resized to 252 × 448; exact mono 16 kHz WAVs are
  12 seconds. Matched/mismatched/blank inputs have equal shapes and token IDs.
  Text-only removes media placeholders. Features are finite and respond to media
  changes, but useful generalization has not been tested. They are global
  clip/proposition vectors, not localized object/speaker tracks.
- **Important failures:** Final visual model gives “The narrator mentions Alaska”
  **0.9968250712 support from silent frames**, apparently using the printed caption.
  Exact-word claims cannot use depiction as speech evidence. The audio model
  gives “Music is audible” support **0.9999145421 matched**, **0.9970450061 silence**,
  **0.9997182083 text-only**. The default chat template improves the description
  but does not fix these control failures. Do not treat its labels as gold.
- **Audio review limits:** Direct listening is unavailable in the assistant
  interface. Independent Qwen3-ASR-1.7B returns Chinese “啊。” for the main clip,
  no usable sentence. The final audio-only Omni description says music and no
  intelligible speech. This does not independently establish absence of sung or
  hummed vocals. Instrumental/vocal labels are provisional proposals from the
  same verifier; all cases are marked `eligible_for_training=false` pending
  independent review. The exact WAV is on the report for user listening.
- **Trees:** `multimodal.py` creates independent source trees with aligned manual
  candidate IDs. Ineligible observations are unknown while raw scores remain
  saved. Combine observations of the same grounded predicate before claim logic;
  unknown contributes no evidence and support/refutation disagreement becomes
  unknown with a conflict diagnostic. This prototype routes depicted colors to
  visual evidence and music properties to non-speech sound. It is a declared rule,
  not a learned modality classifier. Source assertions do not certify world truth.
- **Measured example:** For “The aircraft is gray and the music is instrumental,”
  visual root unknown **0.999999974876**, audio root unknown **0.999919880983**,
  combined support **0.999746298473**. These are uncalibrated model-derived
  probabilities, not certified truth. The clauses concern different referents;
  automatic audio-visual entity identity and alternative real assignments are
  not demonstrated. Explicit missing media yields unknown **1** in all trees.
- **Semantics correction:** Reject `mention` with other source/content scope
  predicates. The generic event compiler incorrectly required a mentioned place
  to be physically present. Quoted/mentioned-content compilation remains pending.
  Missing-input controls have a separate observation context ID so they cannot
  overwrite the matched-media observation with the same canonical predicate.
- **Checks:** **28 tests pass**, including complementary predicates, source
  exclusion with raw outputs retained, conflicts, and candidate alignment. All
  30 roots match independent enumeration within 1e-10 and conserve mass within
  1e-9. A fresh cached-source replay reproduces all 30 distributions exactly,
  along with feature diagnostics and hashes. No GPU/model download for replay.
- **Jobs:** Final visual **1122572** (1 A100-40GB, 26 s Slurm wall time); final
  audio **1122577** (2 A100-40GB, 157 s). Independent ASR **1122563** (1 L40S,
  89 s). Initial/revision runs and setup failures are retained in execution.json:
  total allocation ≈0.477 GPU-hours, including failed/cold-start runs. Final
  feature scripts use native Transformers; no base environment changes.
- **Code/report:** run_av_features.py, run_av_audio_review.py,
  analyze_av_features.py, build_av_feature_sections.py, canonical prompts in
  prompts_phase2.py; `verification-pipeline.html#audiovisual` and `#next-steps`.
  Core inference below still uses frozen A/B/C scores; new vectors are cached for
  the later feature classifier. The earlier 643-parameter score calibrator is a
  separate historical demonstration, not the new learned media model.

- **Published and verified:** site commit
  **54a666ef827f8592d6a5a87925c9df6e7583df32**; Pages workflow
  **39853278600** succeeded. Eight live report/artifact URLs returned HTTP 200
  with exact local SHA-256 matches, including the audio WAV and source ZIP.
  The site worktree is clean. Main links:
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#audiovisual
  and the same page at `#next-steps`. Publication details:
  exp/probabilistic_verification/av_features_20261022/publication.json.


### Group: Compiler priorities and tense/aspect diagnostic — 2026-10-28

- **User accepted:** Prioritize real-claim compilation coverage and meaning
  preservation, semantic parsing comparison, and contrastive tests before more
  feature work or relation training. Report checklist preserves completed pilot
  work and places it after the new compiler priorities. Temporal handling is a
  planned requirement, not a completed implementation.
- **Dataset audit context:** Current annotation_units.tsv has 17,813 rows / 2,375
  unique claim IDs with one text per ID. Current trees_ud.jsonl and
  semantic_factor_trees.jsonl each match all 2,375 current texts exactly. Older
  annotation/claims.jsonl has 761 records; 698 IDs overlap the current table and
  454 overlapping IDs have different text. Do not join that older file to current
  parses using only claim ID. The full compilation census has not yet run.
- **Measured diagnostic:** Six actual CPU Stanza parses fed to the unchanged
  ClaimCompiler. Both “Apollo 11 landed on the moon” and “Apollo 11 is landing on
  the moon” reject as quantification: 11 is tagged nummod and the guard treats it
  as a count. Four supported spacecraft clauses—landed, is landing, was landing,
  has landed—compile to exactly the same entity/event/land logical form.
- **Why:** Tokens retain Tense and VerbForm. The main landing participle has
  Tense=Pres even in “was landing”; the finite auxiliary has Tense=Past. The
  compiler lemmatizes land and marks be/have auxiliaries functional without
  propagating their tense/aspect into constraints or canonical evidence keys.
- **Scope:** Diagnostic only; no compiler fix, temporal inference, dataset-wide
  success rate, perception request, GPU allocation or training. Full parses,
  outputs, parser versions/model hashes and compiler hash are in
  exp/probabilistic_verification/temporal_audit_20261028/current_behavior.json.
- **Proposal:** Parse the full verb/auxiliary sequence; retain tense/aspect and a
  contextual reference time; carry them through logic, evidence identity and
  scoring. Progressive does not guarantee completion. The ordinary completed
  reading of affirmative landed depends on event meaning, not past tense alone.
  Narrative time is distinct from wall-clock now and from media-window selection.
- **Checklist:** exp/probabilistic_verification/av_features_20261022/checklist.json
  now contains the current dated plan; stable old step IDs retain their meaning
  while display order expresses the new priorities. The report includes actual
  temporal diagnostics and clearly marked proposed requirements.

- **Validation/publication:** All nine site pages pass HTML/link checks. Chromium
  verifies seven tabs, eight ordered priorities, six measured diagnostic cases,
  sequential table captions, and desktop/mobile/dark layouts with no page errors
  or document overflow. Site commit e98f415ef3ab552a769fb883bdae897371afe9dd;
  Pages workflow 40740248036 succeeded. Five live page/data/archive URLs return
  HTTP 200 and match committed bytes. Site worktree is clean. Live checklist:
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#next-steps
  Details: exp/probabilistic_verification/temporal_audit_20261028/publication.json.


### Group: Real-claim compilation audit — 2026-10-28

- **Stage completed:** The first checklist stage, Audit compilation on real dataset
  claims, is complete. No compiler fix, new semantic parser, perception inference,
  GPU allocation or classifier training. Next stage remains semantic parsing and
  contrastive checks, including the planned tense/aspect extension under ADR-023.
- **Frozen run:** exp/probabilistic_verification/compilation_audit_20261028/.
  Inventory 2,375 distinct current claim IDs / 17,813 annotation rows. Exact text
  hashes, source-video links, input-file hashes, compiler-package source snapshots,
  Python/package versions and fresh Stanza model hashes are recorded. Current
  source code matches the frozen compiler hashes. Old 761-claim file is not used.
- **Two input conditions:** Existing phase1 hypergraph raw UD records convert
  zero-based indices to one-based IDs/root 0; omit seven SpaCy SPACE-only records,
  preserving raw records and lexical IDs. No lexical/dependency repair. Original
  cached parser runtime/model version is not stored. Primary current condition
  reparses exact original text with the unchanged CPU Stanza 1.10.1 wrapper.
- **Measured census:** Stored parses compile **79/2,375 (3.33%)**, reject 2,296.
  Current pipeline compiles **78/2,375 (3.28%)**, has **2,268 compiler rejections**
  and **29 parser refusals** (multi-sentence input). No unexpected exception in
  either frozen census. Both accept 76 claims and emit identical literal logical
  forms on those 76; current parsing loses 3 accepted cases and gains 2. These are
  coverage outcomes, not semantic accuracy or media verification results.
- **Current first diagnostics:** unhandled_content 1,060; quantification 487;
  subject 238; modality 145; scope 94; intensional_predicate 88; reference 66;
  coordinated_arguments 52; predicate 31; sentence_count 29; coordination 3;
  duplicate_role 3; negative_indefinite 1. Guards stop at the first issue; the
  histogram is not a full linguistic taxonomy. Example if in an embedded question
  is labeled by the broad scope guard, not correctly classified as a conditional.
- **Derived structural counts:** 91 quantity-guard cases have a NUM trigger
  attached to a PROPN head. This is not 91 independently verified name errors.
  74 accepted inputs contain finite Tense morphology; the compiler adds no
  explicit tense/aspect conditions. Unhandled ADP count 1,462 is a token count,
  not a count of location-error claims.
- **Review selection:** 494 claims have no overlap with the 102 reserved source
  videos. Uniformly sample 50 of those claim IDs (seed 20261028), add 20 purposive
  diagnostics, and supplement 9 remaining accepted development programs. Total
  **79 assistant reviews**, covering all **20 accepted development programs**.
  Random sample: 1 accepted, 49 rejected. Diagnostic sample: 10 accepted, 9 compiler
  rejections, 1 parser refusal. Never pool these cohorts for accuracy estimation.
- **Semantic review (inferred, not human gold):** Among all 20 accepted development
  programs: 11 adequate core structures within the tense-agnostic fragment, 2 core
  meaning errors, 7 unresolved semantic contracts. No full temporal-faithfulness
  claim. Confirmed artifact examples support the assistant's interpretation:
  earthquake's impact becomes possess(earthquake,impact) with owner/possession
  roles; martial law troops becomes law_troops plus attribute(martial). Photo
  depiction, abstract nouns and home-run idiom require explicit source/type
  contracts; they are marked ambiguous rather than automatically called wrong.
- **Representative coverage gaps:** The earthquake occurred in Myanmar rejects
  the location. IM-1 landed on the moon rejects the split numeral and location;
  another IM-1 sentence hits quantification. Fragment/metadata inputs and ordinary
  oblique complements are common. The current parser also reads transitions as a
  noun in one reviewed verbal clause. All review cases are source-linked and retain
  original texts and exact parses. No factual-support label was assigned.
- **Validation:** Independently replay **4,721 compiler outcomes**, separately check
  **29 recorded parser refusals**, verify full inventory coverage and adapter
  invariants, reconstruct the random sample from its frozen seed, and verify no
  reserved sources enter semantic review. A fresh archive replay with system Python
  reproduces the whole analysis. Replay also succeeds with imports of Torch,
  Stanza, Transformers and DeepProbLog explicitly blocked. Parser refusals are
  validated as recorded outputs, not reproduced by rerunning Stanza in this replay.
- **Scope/cost:** No GPU. Fresh per-record parse+compile sum 459.700 seconds, excluding
  model loading; stored-parse compilation sum 0.189 seconds. These represent
  different work and are not a fair parser-speed comparison. Semantic labels come
  from the same assistant that worked on the prototype and need independent
  adjudication before use as a benchmark.
- **Code/report:** run_compilation_audit.py, analyze_compilation_audit.py,
  build_compilation_audit_report.py. Real-claim audit tab at
  verification-pipeline.html#compilation-audit; checklist audit items checked.
  Full census, reviews, evidence-tiered findings, source snapshots and CPU replay
  are available in verification-pipeline/audit/ downloads.

- **Report validation/publication:** Updated item and all nine site pages pass
  HTML/link checks. Chromium verifies eight tabs, all 79 review cases and filter
  counts, all four completed audit checklist items, 55 sequential table captions,
  desktop/mobile/dark layouts and no page errors or document overflow. Original
  input-file and compiler fingerprints still match the frozen manifest.
- **Published:** site commit 279021f3d3acc4b658c897e7b5ffdd3e56947caa;
  Pages workflow 40747004834 succeeded. Seven live page/data/archive URLs return
  HTTP 200 with exact local byte matches. Site worktree is clean. Links:
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#compilation-audit
  and the same page at #next-steps. Publication checks are saved in
  exp/probabilistic_verification/compilation_audit_20261028/publication.json.


### Group: Semantic compiler prototype and parsing comparison — 2026-10-28

- **Status:** First compiler-improvement prototype implemented, tested and reviewed.
  Keep it opt-in; the text parser is not validated as a replacement. No change to
  ADR-023, original annotations, reserved sources, or frozen v1 compiler modules.
- **Code:** scripts/probabilistic_verification/semantic.py defines a constrained
  semantic representation and deterministic SemanticCompiler; temporal.py applies
  explicit time annotations and source-route eligibility before existing grounding.
  compile_verification_claim.py accepts optional --semantic-json; default remains v1.
  Prompts are centralized in scripts/prompts_phase2.py. New dependency jsonschema
  4.26.0. Full artifact run: exp/probabilistic_verification/semantic_compiler_20261028/.
- **Representation:** Complete event role tuples carry role labels and prepositions
  as executable arguments; the v1 observation-key function cannot collapse agent-only
  and theme-only frames in this representation. Shared referents retain one ID;
  event existence stays inside local negation. Concepts need no physical candidate.
  Small fixed frame/type/scope/word-span checks do not certify semantic correctness.
- **Source scope:** A source binds to its exact content, route and assertion/
  question/depiction act. Content must cover a complete dependency complement;
  its inner propositions are retained as text, not recursively compiled. Unused
  annotations entirely inside that content can be removed from the outer entity
  list, with a log. Referenced inner world predicates still cause rejection.
  Raw proposals and every normalization remain available. Normalization also
  accounts for attached auxiliaries/prepositions, punctuation and numeric IDs;
  it does not invent roles, predicates or source boundaries.
- **Temporal implementation:** Full auxiliary chain -> finite tense and aspect;
  landed / is landing / was landing / has landed emit different conditions.
  A caller supplies one discourse reference context (T0), included in evidence keys;
  no wall-clock anchor is assumed. Completion is a separate lexical condition.
  The fixed checker covers narrow episodic intervals, explicit completion and
  perfect relevance, preserving unknown for missing metadata/context. Empty context
  inventories cannot establish refutation. Video-time extraction/localization and
  temporal features from frozen media models remain unimplemented.
- **Broad measured comparison:** Same 79 audited development claims, no overlap
  with 102 reserved source videos. Frozen Qwen3-VL-8B-Instruct in text-only float16
  mode with Transformers, prompt 2: **11 compiled, 67 refused, 1 inherited parser
  refusal**, versus **20 compiled for v1** on this selected set. All 11 are decomposed
  world claims, no scoped source program passes in this condition. Random 50:
  4 compiled vs 1 v1; diagnostic 20: 4 vs 10; additional accepted 9: 3 vs 9.
  Typhoon claim is a prompt demonstration, not independent evidence. Compilation
  coverage is not semantic accuracy and this selected mixture is not a corpus estimate.
- **Generated contrasts:** 21 constructed inputs, 8 compiled / 13 refused by the
  frozen 8B parser + checked compiler. Passive, perfect and source paraphrases can
  still fail despite hand-authored IR tests passing. No held-out parser accuracy.
- **Prompt/model iteration:** Initial 4-claim prompt pilot compiles 1/4 under the
  final compiler; revised prompt compiles 4/4. Same revised prompt with frozen
  Qwen3-30B-A3B-Instruct-2507, float16 layers split across four V100s: **3/7** selected
  diagnostics compile. Larger model still mishandles source scope and omits the
  earthquake/impact relation. A third prompt adds synthetic source examples. Its
  three known source cases compile **3/3 with checked unused-annotation removal,
  0/3 without it**. Do not attribute this solely to prompting, pool with the 79-claim
  result, or infer generalization. Models only generate text, with no media/fact labels.
- **Semantic review (inferred):** All 11 accepted broad 8B programs, all 7 larger-model
  diagnostics, 3 source-prompt programs, and 5 additional refusals inspected by the
  same assistant that implemented the compiler. Complete location/name/compound
  examples improve; home-run idiom and some weather/event/role contracts remain
  unresolved. Larger model is not sufficient for source-contract compliance.
  Scope guards catch disconnected location and media/world-content errors.
- **Validation:** **64 tests pass**, including observed model-error regressions,
  active/passive equivalence, role/attribute edits, source isolation, name handling,
  context identity, and actual CPU DeepProbLog temporal inference. **16 constructed
  temporal controls** use completed/ongoing/interrupted/unannotated events and
  non-temporal scores fixed to support; they are not media predictions. Original
  baseline still replays **4,721 outcomes + 29 recorded parser refusals**, with
  unchanged frozen code hashes. No feature-based relation-classifier training.
- **Resources:** Peak **4 V100s**, **2.4022 allocated GPU hours** including model
  loading and generation. A100 request cancelled before allocation because of
  next-day queue estimate. All started jobs completed; none remain running/queued.
  No model weights downloaded or trained. Exact requests, model configs, hashes,
  split checks, source, scripts, test records and resource accounting are retained.
- **Report/checklist:** New Compiler improvements tab at
  verification-pipeline.html#semantic-compiler; Next steps reflects completed
  prototype work and remaining parser review, development re-evaluation and held-out
  evaluation. The old temporal diagnostic is explicitly historical v1 behavior.
  Details and limits: docs/semantic_compiler.md. New report source archive supports
  CPU compiler replay (jsonschema required) without importing ML libraries.


- **Final validation:** Nine site pages pass HTML/link validation. Chromium checks
  nine tabs, 100 primary cases and search, 26 reviewed examples, 25 sequential
  figure captions and 62 sequential tables, desktop/mobile/dark layouts, no page
  errors and no document overflow. Mobile diagrams retain readable type and center
  their main branch while allowing horizontal scrolling.
- **Archive replay:** Fresh extraction reproduces 109 saved compiler outcomes
  and validates one recorded parser refusal with Torch/Stanza/Transformers/
  DeepProbLog/vLLM imports blocked. All 64 tests also pass inside the extracted
  archive. Canonical combined generation records remove dependence on worker
  files; the old controlled-evidence helper is included for legacy regressions.
  Details and exact archive hash: semantic_compiler_20261028/archive_verification.json.


- **Published:** site commit 29e58c27e3c991aa6510cd592f4f9e956f1d62bf.
  GitHub Pages workflow 40764894640 completed successfully. All 19 changed live
  page/data/archive URLs return HTTP 200 and match local committed bytes. Site
  worktree is clean. Live result:
  https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#semantic-compiler
  Checklist: the same page at #next-steps. Exact publication and live hashes:
  semantic_compiler_20261028/publication.json.
- **Publication review resolved:** Automatic review initially withheld the push
  pending data-disclosure evidence. Read-only checks confirmed the prior public
  audit archive by live SHA256, exact unchanged baseline data files, all 78 real
  model-input claims/parses and all 102 reserved memberships already public, and
  no media/model weights in the new archive. The evidence-backed retry was
  approved; this finding applies to this payload, not arbitrary future data.
  Evidence: semantic_compiler_20261028/publication_data_check.json.


### Group: Recheck existing semantic-role parser — 2026-10-28 discussion

- **Measured cached-data inspection:** scripts/run_srl_baseline.py uses trained
  AllenNLP BERT PropBank SRL, with cached outputs in
  exp/phase3/srl_baseline/srl_frames.jsonl. There are 2,375 unique current claim
  IDs. All upstream tree claim_text fields match the current inventory exactly;
  joining SRL words reproduces each current claim after removing whitespace.
  2,225/2,375 claims have at least one frame with arguments, including 76/79 of
  the reviewed development claims. These are availability counts, not semantic
  accuracy, complete-claim coverage or successful ProbLog compilation.
- **Inspected examples:** Cached frames retain IM-1 as one argument plus on the
  moon as ARGM-LOC; whistling/shouting with People as ARG0; martial law troops as
  a complete argument phrase; Photos / damaged buildings as show's two arguments.
  The genitive/attribute example retains earthquake's impact as a whole phrase
  under a copular frame; it does not explicitly resolve that genitive relation.
  Reporting scope, coreference, nominal predicates and tense/aspect still require
  checks. Do not assume ARG0 universally means an intentional agent.
- **Measured paired comparison:** Across the same 79 development cases, v2 loses
  12 v1 accepted programs, gains 3 and retains 8; 55 are refused by both and one
  inherited parser refusal remains. Thus usable coverage regresses. No independent
  semantic precision improvement has been established. The 64 tests establish
  compiler/inference behavior, not real-claim parsing accuracy.
- **Confirmed brittle guard:** People are shouting is refused because current UD
  lemma shouting differs from generated predicate shout. The trained SRL cache
  already extracts the expected predicate/participant. A dependency analysis must
  not be treated as infallible semantic ground truth.
- **Proposal for discussion, not an adopted replacement:** Remove the mandatory UD
  backbone, reuse existing trained SRL as a front end to a small event/argument
  representation, retain shared references and logical/source scope, and compile
  that to the existing probabilistic backend. UD may assist spans/auxiliary
  analysis. First test binding benefit on reviewed representations and reviewed
  media; then measure automatic parsing separately. This fits ADR-023, which no
  longer requires the old fixed-tree CRF. AMR is an optional comparison, not an
  automatic fix: standard AMR needs additional tense/aspect information.
- **Sources checked:** AllenNLP srl_bert documentation; AMR (Banarescu et al.,
  2013, https://aclanthology.org/W13-2322/); tense/aspect extension (Donatelli et
  al., 2018, https://aclanthology.org/W18-4912/); DeepProbLog 2018; ProgramFC
  (https://aclanthology.org/2023.acl-long.386/). Program execution alone is not a
  novel contribution. No new parser inference, GPU allocation or pipeline change.


### Compilation approaches — compilation_methods_20261028

- **Scope:** User explicitly prioritized compilation over media verification.
  Same 79 previously reviewed development claims + 21 constructed controls;
  no held-out parser-accuracy result. Cached trained BERT-SRL reused for real
  claims; the actual cached public AllenNLP checkpoint was run on CPU for controls.
- **Routes:** Trained SRL + dependency-assisted rules, pretrained amrlib
  parse_xfm BART-large (checkpoint v0.1.0, not SPRING weights), direct frozen
  Qwen3-VL-8B text-only graph generation, and the same model with UD/SRL context.
  New deterministic `PredicateCompiler` is shared by all four. PENMAN is the
  graph serialization; SRL graphs are not full AMRs. Legacy v1/v2 unchanged.
- **Measured real-claim valid-graph / compiled counts:** SRL 72/79 and 68/79;
  AMR 79/79 and 46/79; direct 8B 44/79 and 33/79; assisted 8B 37/79 and 30/79.
  Constructed-control compiled counts: 19/21, 20/21, 15/21 and 11/21 respectively.
  Different decomposition detail and supported fragments prevent interpreting
  these counts as semantic-accuracy gains over historical v1=20/79 or v2=11/79.
- **Execution evidence:** All 242 compiled outputs parse as ProbLog. Eighteen
  selected compiled cases execute in actual DeepProbLog under isolated 10-second
  subprocess limits, using artificial unknown observations. This checks execution,
  not media support. An initial unrestricted backend sweep was interrupted after a
  slow case and is not a completed backend coverage or speed result.
- **Quality review:** Ten selected examples × four routes have assistant
  qualitative notes, not human gold accuracy. Neural outputs can assign wrong
  land/arrest/collapse roles or invent negation; AMR changes Phillies to Phillips,
  types Haboob as a city, and has a dropped Alaskan-coast relation recorded as an
  untranslated edge. SRL preserves phrases but does not expose all internal bindings.
  Full reference review of the selected 25 real diagnostics + 21 controls is pending.
- **Implemented fixes:** Inverse AMR roles, shared-variable scope, branch-local
  witnesses, negative event existence, explicit role labels in executable arguments,
  duplicate-role refusal, event-complement guards and read-01's ARG1-source /
  ARG3-content distinction. The latter was caught by inspecting cached trained SRL
  and AMR outputs and added to regression tests. Source contents remain opaque,
  not recursively compiled. Predicate sense merging and some entity graph edges
  remain unresolved. New four-argument temporal atoms are compilation outputs,
  not connected to the older five-argument interval checker.
- **Checks:** 77 passed (original 64 + 13 new); CPU replay reproduces all 400
  compilation outcomes/programs without loading models. Source archive excludes
  weights/media. Artifacts include exact requests/responses, hashes, model versions,
  quality_review.json, summary.json, tests.xml and resource_usage.json.
- **Resources:** Five completed 1×V100 jobs 1146314, 1146317, 1146318, 1146319,
  1146320; peak 4 V100s, 0.333611 allocated GPU hours including loading. Frozen
  parser inference only. No new media verification or relation-model training.
- **Research:** Verified primary-source digest in
  research/2026-10-28-compilation/LITERATURE.md and literature.json. Boxer,
  ccg2lambda, AMR-FOL, tense/aspect AMR, constrained generation, CLOVER,
  Code4Logic and NL2LOGIC inform the next plan. Parser/compiler separation is
  established prior art, not the paper's novelty by itself.
- **Next proposal:** Finish reference review; freeze/fix one common logical form
  and scope/sense/temporal interfaces; retain SRL and AMR baselines; test one small
  clause-level logical-form generator with deterministic serialization; freeze
  before evaluating compilation on unseen sources. No clause-level neural AST
  condition is implemented yet. Report anchor: #compilation-methods.

- **Publication verified:** Site commit 4d10b409f0ee098a61ff3dc8a51975f7c6b220a1; Pages workflow 40784120697 succeeded. All 21 changed/live files match local bytes, including the report and source archive. Browser checks: 10 tabs, 10 examples across 40 route views, 26 figures, 67 tables, no page errors or mobile overflow. Historical archives preserved. Live report: https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#compilation-methods. Details: compilation_methods_20261028/publication.json and archive_verification.json.


### Common logical form — logical_form_20261028

- **User accepted choices:** Implement the reference review, common logical form,
  deterministic compiler, trained SRL/AMR and one bounded neural alternative,
  then frozen compilation checks. LLM sentence rewriting is explicitly reserved
  as a last resort and must NOT be implemented yet. No rewrite code/prompt/call added.
- **Terms:** Representation = explicit claim logical form (not embeddings).
  Interface = specified component inputs/outputs and their meanings. Definitions
  and JSON example: docs/logical_form_interface.md.
- **Implemented:** logical_form.py plus logical_form_adapters.py and
  compile_logical_form.py. Recursive source contents carry the source-event
  variable/route; modifiers and entity relations are explicit; inverse relations
  and duplicate atoms are canonicalized; known senses enter executable keys;
  event/tense/aspect/context/completion fields share one format. Local negative
  event existence stays under NOT, with participants outside that local negation.
  Cross-source reference interpretations remain refused rather than silently cloned.
- **Reference set:** 25 real development diagnostics + 21 constructed controls.
  Five uncertain readings are excluded from definite counts (21 real + 20 controls).
  Requirements are assistant-authored role/attachment/polarity/scope/time checks,
  not full semantic equivalence or independent human accuracy. Expected controls
  include three refusals (counting, modality, unresolved reference).
- **Neural experiment:** 100 original inputs, direct and trained-SRL-assisted
  Qwen3-VL-8B text-only JSON logical-form generation; 200 saved requests/responses,
  greedy, float16, no fine-tuning. One call per claim, not a multi-call implementation
  of CLOVER/NL2LOGIC. Some inline arguments are linked to exact source mentions and
  logged; missing names are not invented. Redundant temporal fields are checked.
- **Final development selection:** Fixed policy prefers SRL without opaque phrases,
  then AMR, then partial SRL. It compiles 57/79 real and 18/21 controls; specified
  diagnostic requirements pass 21/21 real and 20/20 controls, including expected
  refusals. This policy uses no reference labels and makes no extra model call.
  Passing these selected development requirements is not a semantic-accuracy result.
- **First source-disjoint check:** 20 claims from source videos absent from the 79
  reviewed claims; no reserved videos. Original frozen policy compiled 14/20, but
  inspection exposed overlapping SRL mention identities and omitted AMR nominal
  parents. Preserve first_iteration/frozen_source and original results. These 20
  informed fixes and are now development diagnostics, not independent final tests.
- **Structural fixes:** Bind overlapping SRL argument mentions by their original
  noun-phrase head; retain nominal parent conditions and links to attached event/
  state modifiers; refuse unsupported group quantification and some directives.
  Final frozen source and prompt hashes are in frozen_manifest.json.
- **Fresh source-disjoint check:** Ten further claims, with no source overlap with
  the original 79 or first 20. Compiler/prompt frozen before inference and unchanged
  after review. SRL 6/10, AMR 5/10, direct neural 0/10 and fixed selection 8/10 compile.
  Review finds an incorrect criticism/reason/standing translation, unclear nominal
  media scope, partial noun alternatives and bare labels requiring context. These
  eight are NOT eight faithful parses. No independent human accuracy score exists.
- **Checks:** 96 regression tests pass (prior 77 + 19 new). Includes actual
  DeepProbLog execution with artificial unknown inputs, not media verdicts.
  CPU replay reproduces 400 development outcomes, 90 source-front-end attempts
  and 30 source-selection outputs without model loading. WordNet lexical data is
  required for replay; see archive README. No new relation model was trained.
- **Resources:** Eight completed 1×V100 jobs 1146518–1146521, 1146534–1146535,
  1146542–1146543; peak four GPUs; 0.678889 allocated GPU hours including loading.
  Reused cached real SRL and development AMR; new AMR only for 20 + 10 source checks.
- **Current recommendation:** Keep opt-in. Require complete original-claim coverage,
  handle nonveridical/reporting/criticism scopes and nominal media descriptions,
  define context requirements for bare labels/omitted subjects/measurements, and
  repeat frozen source checks after changes. Do not use rewriting yet, and do not
  start media verification/training from these accepted programs automatically.
- **Artifacts:** logical_form_20261028; updated report #compilation-methods and
  canonical av_features_20261022/checklist.json. Source archive includes both
  frozen code snapshots, raw inputs/outputs, reference requirements and review notes.

- **Publication verified:** fd2849f179aa72b078d700000ca79636483ca546 / Pages workflow 40803029938 succeeded; all 34 changed live files byte-match the validated site. Source archive independently replays the cached outcomes and passes all 96 checks. All 52 accepted source-check/selection records also serialize and parse as ProbLog. Browser: ten tabs, 27 figures, 71 tables, no page errors or mobile overflow. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#compilation-methods.

#### Group: Full original-claim compilation

*Goal: increase faithful claim compilation over the complete annotation inventory and expose failure reasons before media verification or relation training.*

| ID | Date | Model / Config | Dataset / Split | Result | Notes | Output |
|---|---|---|---|---|---|---|
| full_compilation_20261029 | 2026-10-29 | Cached trained SRL; amrlib BART-large AMR; frozen Qwen3-30B-A3B-Instruct-2507, vLLM 0.18.0, greedy JSON-schema output, one bounded reparse; v2 compiler | All 2,375 original texts, within-corpus development; no media/truth labels | Final 1,934 compiled, 441 refused; previous fixed SRL/AMR policy 1,544 compiled | Acceptance is not semantic accuracy. Fresh 20: 4 faithful (one mention), 7 partial, 6 incorrect, 3 refused; prior 1/5/6/8. | exp/probabilistic_verification/full_compilation_20261029/ |

#### 2026-10-29 — Full compilation census: coverage improves, meaning remains the bottleneck

- **Inventory:** All 2,375 original claim texts exactly match the already-public audit/source.zip inventory. Cached SRL covers all IDs; trained AMR now covers all, with 109 reused and 2,266 new parses. Twenty-nine empty dependency inputs were repaired by retaining every sentence and original offsets. No sentence rewriting, media calls, verifier training or truth/evidence-label use.
- **Implementation:** `logical_form_v2.py`, `normalize_form_v2.py`, `source_checks_v2.py`, `srl_form_v2.py`, `compilation_checks_v2.py`; CLI `compile_scoped_claim.py`. Typed literal values, proposition/source contexts, explicit modal qualifiers, noun-phrase relations, scoped references, numeric-identifier handling, measurement ranges, and source-matched temporal/preposition handling. Generic no-NP negative existentials are deliberately refused; no general quantifier/modal theorem prover is implemented. Missing new evidence functions yield unknown.
- **Measured outcomes:** Final SRL/neural selection compiles **1,934/2,375 (81.4%)**, versus **1,544/2,375 (65.0%)** previously. Of the final compiled outputs, **1,907** have claim kind and **27** are standalone mentions; **167** require context and **1,389** have no diagnostic flags. None of these counts certifies meaning. Read `results.summary.json`, `analysis.json` and the complete per-claim ledger.
- **Neural conditions:** The AMR-assisted 30B condition was stopped after 128 completed outputs because it copied absent concepts and produced invalid structures. The original-text/schema-constrained condition ran on every claim, plus **1,180** bounded reparses. The native-bfloat16 24-case pilot did not remove observed errors; no precision-quality gain is claimed. Exact requests/responses and prompt versions live in the run directory and source archive. All prompts remain in `scripts/prompts_phase2.py`.
- **Review:** One hundred uniformly sampled IDs became development diagnostics. Twenty additional claim IDs, disjoint from those 100 and the initial 24-claim pilot, received paired assistant reviews: **4 faithful (one mention), 7 partial, 6 incorrect, 3 refused**; prior policy **1 faithful, 5 partial, 6 incorrect, 8 refused**. Of six newly compiled fresh cases, three are partial and three incorrect; none is fully faithful. The same assistant judged text/logical forms, with no independent human gold; source videos overlap, and all text is development material. These are descriptive checks, not corpus semantic accuracy.
- **Final cleanup:** A development quote exposed a dead-entity declaration graph bug after the fresh review. The fix removes only unreachable declarations whose every source mention lies inside a retained exact quote. All twenty fresh statuses, program hashes and diagnostics were rechecked unchanged (`fresh_recheck_after_quote_cleanup.json`).
- **Context cache fix:** Local c1/q1 IDs previously aliased different source/modal contexts across claims. Scope IDs now include the claim ID; these are cache lookup identities, not neural features. All 2,375 statuses, diagnostics and selections are unchanged. Removing only the namespace reproduces all 1,934 prior single-claim program hashes and all 17 fresh compiled structures; 648 raw hashes change by design. A native two-claim regression test verifies separate probabilities for may/will contexts. See scope_namespace_recheck.json.
- **Checks:** **134 tests pass**. Every one of the **1,934** compiled programs parses as ProbLog. Exact CPU replay reproduces all **2,375** selected outcomes, diagnostics and program hashes. Of **19** bounded native DeepProbLog checks on small programs, **17** finish with unknown probability one and **2** exceed the 15-second end-to-end subprocess limit; startup overhead is included, so this does not isolate solver performance. An earlier unrestricted-size native sample was interrupted after a slow case. Whole-corpus inference throughput is unmeasured.
- **Compute:** Nine allocated GPU jobs plus one cancelled pending request; **1.866111 allocated GPU hours**, including loading/cancellations, peak **4** concurrent GPUs. Jobs 1147467–1147470, 1147477, 1147479, 1147489, 1147493, 1147513, 1147515. No model weights or media are published.
- **Interpretation:** Source/modal scope, participant roles, opaque noun phrases, scalar/identifier types, quantifier attachment and event phases remain frequent errors, including unflagged accepted cases. More word overlap or serialized output cannot certify meaning. Next: complete reference logical forms and stronger semantic parsing, then separate loading/grounding/inference profiling. Keep media verification and relation training deferred; do not reopen ADR-023 from old CRF notes.
- **Report:** site/reports/claim-compilation.html; source and cached CPU replay at site/reports/claim-compilation/source.zip. Publication verification is recorded after deployment.

- **Publication verified:** Site commit 772a7df9849df88ab4531b63d3beccd15f7ef6a4; Pages workflow 40880365246 succeeded. All 15 changed live files byte-match local artifacts, including every report download and source ZIP. The independently extracted archive reproduces all 2,375 selected outcomes and passes all 134 tests. Browser checks cover all filters, desktop/mobile and dark mode with no page errors or overflow. All six historical source archives remain unchanged. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-compilation.html. Evidence: full_compilation_20261029/publication.json, archive_verification.json and browser_checks.json.

#### Group: SRL compilation and constrained parse post-editing — 2026-10-29

| ID | Date | Model / Config | Dataset / Split | Result | Notes | Output |
|---|---|---|---|---|---|---|
| srl_revision_20261029 | 2026-10-29 | Trained SRL + dependency frame graph; optional frozen Qwen3-30B-A3B-Instruct-2507 minimal span edits, Transformers/XGrammar float16 | All 2,375 original texts for SRL; same 48 inputs per editor, including 24 random reviewed IDs; within-corpus development | Earlier SRL 1,344 accepted; new SRL 1,997. Fixed 48: editor 37 accepted; AMR-assisted editor 38. | 24-case paired faithful counts: earlier SRL 5, new SRL 7, both editors 7. Not semantic accuracy. | exp/probabilistic_verification/srl_revision_20261029/ |

- **Architecture:** One path through `srl_graph_form` and the deterministic logic compiler. Existing trained frames are linked using dependency clause relations. Nominal relations, groups, copulas, repeated times, quotations, quantities and modal contexts have explicit handling. `relative`/`complement` contexts retain parent identities; evidence functions are still untrained/missing and return unknown. No automatic condition selection, sentence rewriting or media calls.
- **Full census:** **1,997/2,375 (84.1%)** accepted: **1,819 claim-kind outputs and 178 nominal descriptions**, **378 refused**. Main checks: unresolved_clause 148, missing_predicate 82, missing_srl 53, duplicate_role 52, modal_scope 17, negative_quantifier 10. Transitions versus earlier SRL: both accepted 1,280; new only 717; previous only 64; both refused 314. Acceptance is not meaning preservation.
- **Model comparison:** A complete-SRL-regeneration pilot stopped after 12 saved outputs because it renumbered correct roles and invented a TV predicate for a bare label. The replacement returns span edits, removals and missing frames. Existing roles cannot be renamed; empty edits preserve the exact original record. Both editor conditions process the same 48 inputs. All **96** responses are valid schema-constrained JSON; **95** have valid edit references, with one AMR-assisted argument-index error explicitly refused. Syntax/SRL editor: **37/48** accepted; syntax/SRL/AMR editor: **38/48** accepted. Mean output tokens **46.6875 / 47.6875**. System prompt **150 words**, versus the old free-logical-form prompt's **491** (whitespace-separated); versions/hashes are stored outside model messages. In syntax/SRL, **72 of 90** proposed span edits repeat an unchanged span.
- **Meaning review:** Same 24 randomly sampled IDs, excluding the development pilot and earlier reviewed IDs. Earlier SRL **5 faithful, 7 partial, 2 incorrect, 10 refused**. New SRL and both editor conditions each **7 faithful, 9 partial, 4 incorrect, 4 refused**. The graph was frozen before random-case inspection; the editor interface followed a separate 12-output pilot. All comparisons are within-corpus development, same assistant, no media/truth labels, no independent human gold/source-disjoint accuracy. On the six newly accepted SRL cases in this review, two are faithful, two partial and two incorrect.
- **Examples:** New SRL preserves possible spacecraft-route descriptions and the six-floor/bottom-floor inclusion. The syntax editor adds perform(People) for people watching a robot perform. Predicted rain/participial source scope, copular vessel identity, idioms, names and spatial text complements remain errors or incomplete structures. Token references and JSON shape do not certify semantics.
- **Checks and resources:** **148 tests pass**. All accepted programs parse as ProbLog; cached replay reproduces all 2,375 SRL outputs and both 48-case editor outputs. No full-corpus media inference/learning claim. Peak **3 V100-32GB GPUs**, **1.746667 allocated GPU hours**, including failed/cancelled jobs. Jobs 1148388/1148405 cancelled pending (zero allocation); 1148440 failed (579 sec × 3), 1148475 stopped after pilot (369 sec × 3), 1148488 completed (1,148 sec × 3). Source snapshots and complete requests are retained.
- **Recommendation:** One SRL/dependency compiler as the main baseline. No observed benefit justifies the editor in the main path yet. Next address nominal source scope, participial modifiers, structured copular/spatial complements, shared referents and event controllers. The paper's contribution should remain probabilistic binding verification, not parser selection/prompt engineering.
- **Report:** site/reports/srl-compilation.html. Publication verification follows after deployment.

- **Publication verified:** Site commit 1bba0d4e3528b5776922196f6254181389903f25; Pages workflow 40946208147 succeeded. All 13 changed live files byte-match local artifacts, including every download. The independently extracted source ZIP reproduces all 2,375 SRL outcomes and both 48-case editor conditions and passes all 148 tests. Two new native DeepProbLog checks finish with expected unknown probabilities. Browser: seven tables/five figures, working example links and explicit not-run states, desktop/mobile/dark mode, no errors or overflow. All seven historical archives remain unchanged; experiment GPUs are released. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/srl-compilation.html. Evidence: srl_revision_20261029/publication.json, archive_verification.json, native_checks.json and browser_checks.json.


### Group: Meaning preservation in semantic SRL compilation — 2026-10-29

*Goal: test whether bounded scope/reference/controller corrections preserve meaning beyond development examples, while checking reference-to-logic separately.*

| ID | Date | Model / Config | Dataset / Split | Compilation | Meaning review / limits | Output |
|---|---|---|---|---|---|---|
| srl_semantics_20261029 | 2026-10-29 | Cached trained SRL + dependency annotations; deterministic semantic pass; unchanged scoped compiler/backend | All 2,375 original inputs; 24 development references; 20 IDs reserved before changes | Prior 1,997 compiled; revised 2,042 (1,870 claims, 172 nominal descriptions), 333 refused | Development prior 7/9/4/4 vs revised 13/7/1/3; fresh prior 7/4/4/5 vs revised 8/5/2/5 (faithful/partial/incorrect/refused). Same-assistant, within-corpus descriptive review, not semantic accuracy. | exp/probabilistic_verification/srl_semantics_20261029/ |

- **Protocol:** Source/reference hashes frozen before inspecting fresh outputs. Twenty-four manual reference readings are development specifications with explicit ambiguities, not independent human gold. Reference 21 requires event/nominal damage identity still absent from automatic output, marked partial. No media/truth labels used.
- **Transitions:** Both compiled 1,971; both refused 307; newly compiled 71; previously compiled now refused 26. Acceptance does not imply correctness. Refusals: unresolved_clause112, missing_predicate71, missing_srl52, duplicate_role51, modal_scope17, negative_quantifier11, predicate_type8, mention_alignment4, quantity_type3, polarity_omission2, unresolved_controller2.
- **Checks:** 156 tests pass; CPU replay matches all 2,375 outcomes, program hashes and diagnostics plus 24 reference compilations. All 16 point-mass logical checks pass (four cases × parsed/reference × matching/misleading facts). Three prior graphs accept misleading combinations. Native DeepProbLog robot/vessel negative checks pass (backend wall ~0.26/1.93 sec); image/damage exceeds a 30-second subprocess limit including startup. Logical checks do not substitute for this missing native result or establish learned/calibrated probability performance.
- **Resources:** Zero GPUs/LLM calls; cached census loop15.3 sec CPU, excluding upstream parsing/loading. No media inference or training. Whole-corpus native inference and weak-label training throughput unmeasured.
- **Remaining:** Fresh imagery/study actor and mast/location attachment are still incorrect; event-nominal links, bare mass nouns and duration/endpoints remain partial. No previously faithful fresh output regressed. Larger development gains do not establish generalization.
- **Artifacts:** docs/semantic_srl_compilation.md; scripts/replay_semantic_srl.py; site/reports/semantic-compilation.html; 44 paired judgments and all outputs. All eight earlier source ZIPs are byte-identical; prior cached replay reproduces2,375+48+48 outputs. Deployment verification follows separately.

#### 2026-10-29 — Scope/reference fixes help selected cases but do not repair existing SRL semantics
- The source/identity changes improve development faithful outputs from7 to13, but fresh faithful outputs only from7 to8 (incorrect4 to2). Fresh errors include an existing SRL actor label and an upstream location attachment. Evidence: srl_semantics_20261029.
- Next work should target explicit remaining relationships and parser errors, while profiling native nested-context inference. Avoid expanding acceptance or training on unchecked graphs. Proposed follow-up remains separate from completed work.

- **Publication verified:** Site commit 6b831b3a0ea7d1a7f292e2a46cb2b0594feab4ad; Pages workflow 40999113136 succeeded. All15 changed live files byte-match local artifacts, including the12MB case viewer data and6MB source archive. Independent extracted replay and156 tests pass; desktop/mobile/dark browser checks pass with no errors/overflow. All8 historical ZIPs are unchanged. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/semantic-compilation.html. Evidence: srl_semantics_20261029/publication.json, archive_verification.json and browser_checks.json.


### Group: Compiler follow-up, native inference and source review — 2026-10-30

*Goal: preserve event/nominal identity and duration constraints, recover selected SRL gaps, address the native timeout and evaluate after freezing.*

| ID | Date | Configuration | Dataset / split | Acceptance | Meaning / limit | Output |
|---|---|---|---|---|---|---|
| compiler_followup_20261030 | 2026-10-30 | One opt-in SRL/dependency compiler; explicit-state DeepProbLog encoding; separate frozen Qwen3-30B-A3B-Instruct-2507 reviewer | All2,375 cached texts;44 development cases;20 actual source videos absent from86 sources in saved prior reviews;10 newly accepted diagnostic cases | Prior2,042; revised2,108 (1,934 claims +174 nominal descriptions),267 refused;66 additions, no prior accept lost | Assistant new-source faithful11→12; separate model18→17. Targeted10 additions:2 faithful/7 partial/1 incorrect. Not corpus semantic accuracy or fully held-out data. | exp/probabilistic_verification/compiler_followup_20261030/ |

- **Implementation:** New compilation_followup.py/direct_backend.py preserve old modules. A unique earlier matching event and definite event noun share an executable candidate variable with quantifiers rebound. Bare adjective-modified common-noun predication can share its subject. Durations retain numeric bounds, units, approximation and total/remaining interpretation. Fixed function returns unknown without required approximation/calendar policy. New dependency frames retain grammatical nsubj/obj labels; a resource-subject help construction leaves the actor unspecified rather than assigning imagery as the researcher. No general event coreference or arbitrary SRL repair.
- **Counts:** All66 additions remain separate from correctness.69 recovered frames appear in accepted outputs;7 bare predications,5 durations,1 event reference and1 implicit-subject correction. Refusals: unresolved_clause110, duplicate_role59, missing_predicate37, modal_scope17, missing_srl13, negative_quantifier11, predicate_type8, mention_alignment5, quantity_type3, polarity_omission2, unresolved_controller2.
- **Manual review:** Development44 prior21/12/3/8 versus revised24/10/2/8. New-source20 prior11/5/2/2 versus revised12/4/2/2 (faithful/partial/incorrect/refused), including two faithful nominal descriptions.20 IDs and their source groups fixed before changes; all corpus texts were previously processed, so this is not a fully held-out corpus. Source membership uses source_videos, not claim-ID prefix. Ten newly accepted outputs were separately sampled post-freeze:2/7/1/0. All prior/new annotations and selection protocols are saved.
- **Separate review:** Frozen Qwen sees randomized anonymous A/B logical forms and original text, with no assistant labels.20 valid JSON outputs/40 ratings; assistant/model agree24/40. Model rates prior18 faithful/0 partial/1 incorrect/1 refused; revised17/1/1/1. It misses quoted-label and footage-scope errors, says an absent enough-seats condition is retained, and mislabels one explicit refusal in both conditions. Raw disagreements remain separate; no automatic reference-label replacement. This review does not confirm the assistant’s small gain.
- **Inference checks:** Prior image/damage exceeds35s subprocess limit after initialization; revised explicit-state encoding finishes with~0.135s inference and8.62s total. Robot/vessel revised inference~0.054/1.035s versus prior~0.247/1.915s. Small point-mass comparison, not full-corpus inference/training throughput. Same categorical sharing and unknown logic retained, no probability pruning. Three mixed-probability checks match exhaustive worlds with repeated observations; one neural-gradient comparison matches prior. Four native identity/duration checks agree with an independent logical evaluation.
- **Validation/resources:**167 tests pass. Frozen CPU replay matches all2,375 outcomes, hashes, diagnostics and changes; previous semantic replay remains exact. Cached census24.4s excluding upstream parsing/loading. H100 request1150080 cancelled while pending; L40S1150081 failed CUDA smoke check before weights (97s ×2 GPUs); V1001150087 completed20 reviews (421s ×3). Total1,457 GPU-seconds =0.404722 GPU-hours; peak3, all released. No media calls/model downloads/new relation-training experiment.
- **Remaining:** Media descriptions can escape scope, label words become predicates, enough-seat thresholds disappear, and newly recovered frames omit exact times, parenthetical detail, temporal scope or obligation. Keep frontend experimental. Proposed next work: those scope/omission checks, then bounded human reference judgments including reviewer disagreements.9 historical source ZIPs preserved; ADR-023 unchanged; rewriting remains unimplemented. Deployment proof follows separately.

- **Publication verified:** Site commit 9ea536418fbb4cf8fda0a0b5bdc20f37217ed80d; Pages workflow 41007156938 succeeded. All19 changed live files byte-match local artifacts, including all per-claim data, raw model reviews and the16MB source archive. Independent extracted archive replay covers current and previous semantic outputs;167 tests pass. Desktop/mobile/dark browser checks pass, with74 reviewed cases and both review reasons visible.9 historical source archives remain unchanged; all GPUs released. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-followup.html. Evidence: compiler_followup_20261030/publication.json, archive_verification.json and browser_checks.json.


### Group: Source scope, claim conditions and human-reference preparation — 2026-11-01

*Goal: preserve depicted/textual content and explicit claim conditions, while preparing actual human judgments before asserting semantic reliability.*

| ID | Date | Configuration | Inventory / review | Compilation outcomes | Human evidence | Output |
|---|---|---|---|---|---|---|
| scope_compilation_20261101 | 2026-11-01 | Opt-in scoped SRL; original cached parses; balanced/observation-ordered AND/OR | All2,375 original inputs;212 earlier review IDs for development;20 pre-reserved human cases from20 source groups | Previous2,108 compiled/267 refused; revised2,095/280 (1,924 claims +171 nominal descriptions). Both compiled2,093; both refused265;15 lost accepts;2 additions. | Zero human readings/comparisons received. No semantic accuracy/gain measured. | exp/probabilistic_verification/scope_compilation_20261101/ |

- **Implemented:** Media descriptions retain depicted events and viewpoint text; preceding source predicates prevent false nominal conversion. Quoted labels retain exact strings and suppress internal predicate recovery. Printed labels can use OCR; names/titles do not automatically do so. A following participle uses an explicit described-entity reading that remains a context/review requirement. Affirmative enough-NP plus one infinitival goal retains seats/threshold/goal in sufficiency context without inventing a numeric threshold. Binary nominal OR uses inclusive alternatives; mixed, multiply referenced or unsupported cases can refuse. Leading shared-subject dates and exact nominal clocks are preserved; a second explicit date is not overwritten.
- **Counts:** Accepted outputs record64 depiction-route assignments,10 protected labels,8 nominal clocks,7 nominal alternatives,3 nominal-media conversions,1 sufficiency goal,1 shared date and2 label-modifier readings. There can be several changes per output. Refusals: unresolved_clause109, duplicate_role59, missing_predicate37, modal_scope16, nominal_disjunction11, missing_srl12, negative_quantifier10, predicate_type8, mention_alignment4, quantity_type3, threshold_scope2, polarity_omission2, temporal_scope2, unresolved_controller2, media_modifier3. No unexpected Python exceptions. New refusals are not automatically correct refusals.
- **Native check:**19-observation sufficiency fixture returns unknown when contextual sufficiency evidence is missing. Previous direct-state expression times out at30s during unknown-query compilation; balanced/observation-ordered expression completes all states in9.02s process,~0.14s native stages. This is a small stipulated comparison. Balancing, identical-node elimination and ordering were not separately ablated.187 tests pass, including mixed-probability analytical conjunction, shared-neural gradients, incomplete inventory/conflicts, depiction versus world, alternatives, dates, exact clocks, protected quoted OR and names. No whole-corpus native throughput claim.
- **Human protocol:**20 claims reserved before changes from20 source groups absent from109 in saved prior reviews/pilots;7 targeted text-pattern cases and13 random, not a uniform or fully held-out/new-topic sample. Original corpus text was already processed earlier. Frozen membership/template/source/input hashes are saved. reference_readings_template.json fields are empty. The form requires an intended reading before comparisons, uses anonymous randomized A/B, assesses refusal separately, saves locally and exports JSON. Human entries are not collected by the static site. Zero actual readings/ratings received; no assistant/model ratings substituted.
- **Review data:** build_claim_review.py preserves already received status data on rebuild and ties packet IDs to sample+freeze hashes. import_claim_review.py validates membership, text/freeze hashes, judgment types and reading-before-rating. It preserves partial responses; source status remains pending until an actual export is returned. Browser validation used a clearly marked synthetic entry in /tmp only; no real human-response files were written or counted.
- **Reproduction/resources:** Cached census24.76s CPU loop excluding upstream parsing/loading; no GPU allocation, LLM requests, model downloads, media/truth labels or new relation-training experiment. Current and prior full CPU replays plus187 tests pass from independently extracted archive. Ten earlier published ZIPs remain byte-identical. Report and review form: site/reports/scope-compilation.html and site/reports/claim-review.html. Publication verification follows separately.
- **Interpretation:** Targeted logical properties now execute as intended; semantic equivalence still requires actual human readings. Audit15 newly refused cases for false refusals before calling the coverage decrease useful. Keep frontend experimental and media/training deferred; no sentence rewriting.

- **Publication verified:** Site commit 63ada836e0e30a7966ad225922de6d8a4807dab6; Pages workflow 41282955246 succeeded. All17 changed live files byte-match validated local artifacts, including the report, human-review page, empty reference template/status and replay archive. Current and previous full compilation replay plus187 tests pass from an independent extraction;16 HTML pages validate. Browser checks cover source examples, all filters, desktop/mobile/dark mode, empty review defaults, reading-before-comparison, anonymous outputs, local persistence and JSON export/restore. Synthetic browser data remains in /tmp only; zero actual human readings/comparisons received. Ten historical source ZIPs remain unchanged. Report: https://borrisonxiao.github.io/SCALE26-AViD/reports/scope-compilation.html; form: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-review.html. Evidence: scope_compilation_20261101/publication.json, archive_verification.json and browser_checks.json.


### Group: Independent agent draft for user review — 2026-11-01

*Goal: reduce the effort of reviewing the twenty reserved claims while preserving the distinction between generated suggestions and human feedback.*

| ID | Date | Agent configuration | Inputs | Completed output | Human evidence | Artifacts |
|---|---|---|---|---|---|---|
| agent_review_20261101 | 2026-11-01 | GPT-6 Astra; xhigh; fresh context | Twenty original claims, then anonymous A/B forms and predicates; no previous reviews or method identities | Twenty five-field readings and forty A/B assessments, with concise reasons | Zero actual human readings/comparisons received | exp/probabilistic_verification/agent_review_20261101/ |

- **Protocol:** Claim-only readings SHA256 `13fdea660093a8705bec64a5a8c8a0ceb2df9bb44a061d56acdf7eda32a9772d`, frozen before phase2. The agent read only the isolated claims, its saved readings and anonymous outputs. Raw responses are unchanged; a later concern about ridge/anti-cyclone alternatives is explicit rather than silently rewriting the initial answer.
- **Draft opinion:** Flags missing fire-label time, Karen proximity, dancing and progressive aspect; wrong reciprocal facing and report-topic attachment; some unnecessary refusals. These are model judgments for user review, not new semantic accuracy or gain measurements. Method identities remain anonymous in the draft.
- **Review page:** site/reports/claim-review-draft.html. Editable answers start prefilled but unconfirmed. An explicit per-case confirmation is required; edits clear that confirmation. Downloads retain original agent answers and provenance, keep unconfirmed work separate, and label returned human feedback agent-assisted. The separate blank form remains empty. The importer rejects raw agent drafts and unconfirmed assisted readings.
- **Scope:** No compiler modification/rerun, media calls, relation training or sentence rewriting. Five importer checks pass. Browser and publication evidence will be recorded separately; no synthetic test data enters human-response files.
- **Next steps/goals:** User corrects/confirms drafts to establish human feedback; return an export to record it; use confirmed failures to prioritize compiler fixes and another evaluation.

- **Validation completed:** All17 site pages validate. Browser checks cover all20 verbatim readings/assessments, initial0 confirmations, edit-clears-confirmation, local persistence, separate empty blank form, original-answer retention and valid downloads; desktop/mobile/dark mode have no page errors or overflow. Five importer checks pass, including rejection of raw agent drafts and unconfirmed assisted readings. Independently extracted source rebuilds both HTML and source ZIP byte-for-byte. All11 earlier source archives and frozen compiler hashes are unchanged. Synthetic exports remain only in /tmp; zero actual human feedback received.

- **Publication verified:** Site commit 6a9c6605ca1e29d16920532c020aef3f7e99c3c5; Pages workflow 41339627916 succeeded. All14 changed live files byte-match validated local artifacts, including the editable review, raw agent answers and source archive. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-review-draft.html. Human readings/comparisons remain zero; user review is next. Evidence: agent_review_20261101/publication.json, validation.json, browser_checks.json and archive_verification.json.


#### 2026-11-04 — Readable output display for claim review

- Both review forms display saved compiler structures before ratings. Boxes show events/states, numbered or named semantic roles, entity relations/properties, quoted text, source scope and compiled tense/aspect. Rendering uses only frozen output data; it neither paraphrases the input claim nor repairs compiler omissions.
- Frozen metadata for20 cases is matched by exact program hash/logical form. Browser checks cover34 compiled and6 refused outputs, all event/entity IDs/time conditions, known errors, original answers, review persistence/export and desktop/mobile/dark layout.17 HTML pages validate. Actual human feedback remains0; compiler and agent judgments are unchanged.
- Presentation artifacts: review_display_20261104. The new source-20261104.zip reproduces the current draft HTML and itself byte-for-byte; all12 prior archives are preserved. Next: user reviews structures and returns confirmed feedback to guide compiler work.

- **Publication verified:** Commit 9e7a3a042e4440622012df95ccca15df4836d1c4; Pages workflow 41931056734 succeeded. All3 changed live files match validated local bytes, including both review forms and source-20261104.zip. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-review-draft.html#outputs. Review IDs, original suggestions, compiler outputs and all12 prior archives are preserved; actual human feedback remains0. Evidence: review_display_20261104/publication.json, browser_checks.json and archive_verification.json.


#### 2026-11-04 — Single visible reading in the review form

- Following user feedback, the draft form now shows all5 editable reading fields once, without folding. The original-reading and original-assessment duplicates were removed from the UI. Original agent answers remain in the download. This supersedes the earlier decision to fold the extra reading fields.
- All20 cases checked; saved edits/export and visible output diagrams preserved. Packet/draft IDs unchanged,13 earlier archives preserved,17 HTML pages validate, source rebuild byte-exact. Human feedback remains0. Artifacts: review_form_20261104. Next: user confirms intended meanings to guide compiler work.

- **Publication verified:** Commit 9aa4c9e7aa9411b41e39443bdfdbb5a99d2103b9; Pages workflow 41932572109 succeeded. Both changed live files byte-match local validation. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/claim-review-draft.html. All reading fields are open once; originals remain in exports, saved edits remain compatible, and human counts remain0.


#### 2026-11-04 — Preparation for the authorized compiler revision

- User reports reviewing all20 cases and approved the proposed next cycle. The exported answers have not reached the shared project; do not infer ratings from the agent draft. Actual received counts remain0.
- `review_followup_20261104`:20 reserved cases,21 actual source videos,0 overlap with129 recorded prior review sources and0 pairwise source overlap. Seed202611041;273 eligible claims after excluding recorded review IDs/sources and normalized duplicate texts. All2,375 texts had already been processed, so this is a fresh review sample rather than a fully held-out/uniform corpus sample. Selected cached baseline outputs and compiler source hashes are frozen before fixes; no fresh semantic review performed.
- `analyze_claim_review.py`: validates the returned packet, unblinds per-case A/B, compares human and agent answers, produces condition counts/paired outcomes and an unassigned failure ledger. Refusals and uncertainty remain separate; conflicting ratings of identical outputs require resolution. Missing/unconfirmed answers are not filled. It does not import data or update received-review counts by itself.
- Six checks pass; an extracted source archive runs them and rebuilds byte-exactly. A synthetic CLI smoke test remains only in /tmp and was never imported.17 HTML pages validate, browser checklist/download checks pass,14 historical ZIPs are preserved. The compiler and2,095/2,375 census remain unchanged.
- Next steps/goals: receive the JSON to analyze actual user judgments; trace confirmed failures to parsing/conversion and select at most3 patterns; implement focused checks/fixes, rerun all2,375, review the frozen sample and decide whether to proceed to binding experiments. Checklist updated; publication proof follows.

- **Publication verified:** Commit 83b55742e9ab32dbe4681fdb3ff13d2b9ec544b1; Pages workflow 41969601623 succeeded. All7 changed live files byte-match validated local artifacts. Checklist: https://borrisonxiao.github.io/SCALE26-AViD/reports/verification-pipeline.html#next-steps. Six analysis/sampling checks, source-archive reconstruction and browser/download checks pass. Twenty fresh cases across21 source videos reserved; no actual human answers imported or compiler changes made. Export or explicit confirmation that all original agent answers were accepted unchanged is still required to obtain the user's actual judgments.


### Group: Returned human review and bounded compiler revision — 2026-11-05

| Run | Date | Scope | Measured outcome | Evidence |
|---|---|---|---|---|
| compiler_revision_20261105 | 2026-11-05 | Returned20-case agent-assisted human review; one deterministic SRL/dependency revision; full2,375 cached original inputs; reserved20-case assistant review |2,099 compiled/276 refused;4 additions,0 old accepts lost,29 programs changed;207 tests pass. All11 current user-faithful programs unchanged. Fresh programs unchanged with13 faithful/4 partial/3 incorrect assistant judgments. Native4 pass/1 timeout at25s. | exp/probabilistic_verification/compiler_revision_20261105/; docs/reviewed_srl_compilation.md; reports/reviewed-compilation.html |

- Original review moved byte-for-byte from the project root to `review_followup_20261104/received_review/20261105-1a3a8fd47e72a50f4943.json`; SHA256 `1a3a8fd47e72a50f4943c10ae129608b8e6187d57547810921716509f02d2e20`. Canonical importer and raw-export recount agree:20 readings,20 comparisons,20 explicit confirmations.
- User ratings:30 October11 faithful/6 partial/1 incorrect/2 refused (1 appropriate,1 inappropriate);1 November11/4/1/4 (1 appropriate,3 inappropriate).16 jointly compiled cases tie;2 partial cases become unnecessary refusals. Six ratings and8 ambiguity fields differ from the original agent suggestions. This is assisted human review, not unaided gold.
- `compile_reviewed_srl` refines copied cached annotations. Three families: argument/modifier retention; coordination/controllers/reciprocals; nominal alternatives/apposition. No new LLM calls, parser selector, sentence rewriting, GPU/media inference or relation training. Earlier compiler sources are unchanged.
- Final full run:1,926 claim structures+173 nominal descriptions=2,099 accepted.25.98s cached CPU loop excludes upstream parsing/input read. Three of the earlier15 lost accepts restored;12 remain refused (8 nominal disjunction,3 media modifier,1 temporal scope).29 changed programs are not29 human-confirmed corrections.
- New argument contracts: `reciprocal` requires same-event group evidence; `noun_phrase` keeps the exact unresolved phrase with internal relations unexposed. Native missing-evidence behavior and reciprocal supported/refuted/unknown checks pass; no trained media capability is implied. The comma-or appositive reading is explicitly contextual.
- Fresh20 reserved before changes across21 actual videos, excluding129 recorded review sources;273 eligible claims, nonuniform sampling, all texts previously parsed. Compiler-author assistant readings precede output inspection. Every final fresh program is byte-identical to1 November and the first freeze.13/4/3 judgments become12/5/3 if the tolerated passive-progressive case is partial. No independent human labels or fresh improvement.
- Preserve chronology: first204-test freeze/census retained; post-freeze changed-case audit found tool-purpose controllers and nonadjacent names could introduce false bindings. Two restrictions and3 checks yield final207-test freeze. None of the20 fresh programs/readings changes; do not describe the final source as untouched before all fresh inspection.
- Remaining fresh errors: landing projected out of preparation/video scope; alleged violation asserted as person-relative content; dialogue question projected to a world assertion; creaking/dolly clause and label identifiers omitted. Refusal counts: unresolved clause109, duplicate role59, missing predicate37, modal scope16, missing SRL12, negative quantifier10, nominal disjunction8, predicate type8, mention alignment4, media modifier3, quantity type3, threshold scope2, polarity omission2, temporal scope2, unresolved controller1.
- Four native unknown-evidence checks finish, long protest/controller check times out at25s. All2,099 programs parse as ProbLog; full-corpus inference/training throughput remains unmeasured. Preserve this distinction from207 passing regression checks.
- HTML validation18 pages; browser inventory/graphs/ratings/downloads/mobile/dark checks pass. Independent extraction passes207 tests and byte-exact report/source rebuild; full-record replay is recorded separately. All15 historical archives unchanged. Source/report generators and evidence are in the new source ZIP.
- Proposed next steps/goals: prevent nominal/question content from becoming world assertions; require original predicate/identifier coverage; establish practical inference bounds. No further media/training expansion is completed by this round.

- **Publication verified:** Site commit 36ce92f3d6d607934182e8d4a86b12db356e9245; Pages workflow 41980896469 succeeded. All46 changed live files byte-match validated local artifacts, including24 case chunks and the reproducible source ZIP. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/reviewed-compilation.html. Evidence: compiler_revision_20261105/publication.json, archive_verification.json, replay_verification.json and browser_checks.json. Proposed next work remains scope, original-text coverage and native cost.


### Group: Scope repairs and source-content coverage — 2026-11-05

| Run | Date | Inputs | Completed results | Evidence |
|---|---|---|---|---|
| scope_coverage_20261105 | 2026-11-05 | All2,375 original cached parses; six discussed development examples; a new pre-reserved20-case assistant sample |2,099 executable candidates unchanged;1,839 pass coverage;260 alerts;276 earlier refusals.11 changed programs.228 tests pass. Fresh outputs/statuses unchanged:9 faithful/5 partial/2 incorrect/4 refused. | exp/probabilistic_verification/scope_coverage_20261105/; docs/scope_coverage_compilation.md; site/reports/scope-coverage.html |

- **Implementation:** `scope_coverage.py` uses limited lexical/prepositional/dependency patterns to move landing under prepare-purpose/depiction, violation under investigation-content, and the WH clause under dialogue-question content. Existing scoped kinds/aggregation are reused. A narrow noun-to-finite-root correction restores dolly/creak/small/while; it stays unresolved. Proper-name expansion preserves complete earlier spans; news76/highway120 retain identifiers without redundant Apollo11 constraints.
- **Interface:** One optional `transform_form` callback in `compile_reviewed_srl` shares existing duration/reference handling. Default full-record outputs exactly equal all2,375 preceding rows. This changes one current historical module's source, but earlier frozen source copies and all16 published ZIPs are unchanged. No parser ensemble or per-claim model selection.
- **Coverage:** Original nouns, names, predicates, adjectives/adverbs and numbers are compared with reachable translated values, allowing inflection and existing numeric operators. IDs, warning strings and unused declarations do not count. `coverage_omission` refuses strict compilation while retaining a diagnostic candidate; the census saves its exact missing tokens and program. Passing is not semantic accuracy; opaque strings and wrong bindings can pass, while unrecognized paraphrases can be flagged.
- **Counts:** Candidate claim-ID sets identical before/after. Eleven hashes change: six discussed cases, four Sagaing Fault cases and one highway identifier in a source group excluded from development. All11 user-faithful programs unchanged and accepted. Candidate count2,099; coverage-passing1,839=1,698 claims+141 nominal descriptions;260 alerts;276 unchanged earlier refusals. Alerts contain nouns106, modifiers100, names93, numbers78, predicates6 (overlapping claim categories). No unexpected exceptions. CPU loop28.01s excludes parsing/input loading.
- **Validation:**228 selected checks pass, including3 native goal supported/refuted/unknown tests with independently absent world landing evidence. These are stipulated evidence tests, not perception results. Earlier probability/gradient regressions pass. Independent extracted source passes228 checks, exactly replays both2,375-record runs and rebuilds all38 report/download files includingZIP byte-for-byte. Final analysis/report-only category ordering was stabilized; compiler/test/input/output files are identical to the tested extraction.19 HTML pages validate; browser renders all4,750 output graphs, distinguishes diagnostic candidates from accepted programs, and verifies filters/downloads/mobile/dark mode.
- **Evaluation protocol:** Seed202611052 reserves20 cases before changes, excluding150 recorded review sources, priorIDs and normalized duplicate texts;150 eligible claims, mutually disjoint selected actual source videos. All corpus texts were parsed earlier; the sample is nonuniform, not fully held-out. Compiler-author assistant claim-only readings frozen before output inspection. All20 programs/statuses unchanged:9 faithful/5 partial/2 incorrect/4 refused in both conditions. No new human labels, no fresh semantic gain. Do not compare this9 with13 on the previous, different20-case sample.
- **Alert inspection:** Seed202611053 selects12 of260 alerts for post-freeze assistant diagnosis. All12 show real omissions, including dates, ranges, participants, outer attribution, place names and approximation. This does not establish alert precision or recall. No compiler changes follow fresh/alert inspection. Development earlier caught name expansion shortening Blue Ghost Mission1/LBHP Boat1; fixed and tested before freeze.
- **Limits:** Dolly/it and dialogue/they unresolved; timelapse content, personal-name/label mixing, rocket landing hidden in a time literal, wrong aftermath role and highway speech/OCR route remain. Native whole-corpus cost is unmeasured; earlier25s protest timeout was not retested/solved. No new GPU/model request, media inference, sentence rewriting or relation-training experiment.
- **Proposed next steps/goals:** Recover coverage on recurring apposition/numeric/nominal alerts; repair opaque-clause/source-label boundaries; resolve local pronouns and establish practical inference cost. Current bounded work is complete, not a guarantee of general compilation reliability.

- **Publication verified:** Site commit acfa916533b01c0bbebd4ccde60f7cbf7c28c577; Pages workflow 41987567903 succeeded. All41 changed live files byte-match validated local artifacts, including24 output chunks and the reproducible source ZIP. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/scope-coverage.html. Evidence: scope_coverage_20261105/publication.json, archive_verification.json, replay_verification.json and browser_checks.json. Current checklist/memory are synchronized; further alert recovery, structural scope/reference work and native cost remain proposed.


### Group: Content recovery and plain-language compiler demos — 2026-11-05

| Run | Date | Scope | Measured outcome | Evidence |
|---|---|---|---|---|
| content_recovery_20261105 | 2026-11-05 | All2,375 original cached claims; appositions/numbers, opaque clauses and source-label boundaries;28 demos including14 earlier cases |1,866 passing vs1,839;2,103 executable vs2,099;35 newly pass,8 new structural flags;80 changed programs;259 tests pass. Fresh20 unchanged17/2/1 assistant judgments. | exp/probabilistic_verification/content_recovery_20261105/; docs/content_recovery_compilation.md; site/reports/compiler-demos.html |

- **User priority:** Focus on omission recovery and clause/source boundaries. Reference resolution and larger native profiling are deferred. A future rewrite is a proposal, not an implementation or guarantee. No new GPU/model call/media inference/training/rewrite.
- **Repairs:** Explicit grammatical apposition retains location/description qualifiers without hard-coded equality. Reattach a noun conjunct through a name to retain two participants. Preserve range endpoints, signs, approximation, units and attached locations; bound elliptical120 and retain its100-officer subset. Recover selected finite temporal clauses using marked slots/subjects and verb lexicon. Recognize timelapse content, printed source routes, missing banner-reading frames, restricted on-screen text fragments, printed numeric rows and separate personal-name/predicative-label spans. Column meanings remain unspecified.
- **Guards/tests:** Times are not group quantities, body parts are not distances, negative signs survive, label parentheses remain, ordinary speech stays speech, old unsafe name/controller examples remain blocked. A later old-demo audit correction credits only source-anchored actual grammatical relations; next-to was already translated. Generic IDs/warnings still cannot hide omissions. Structural alerts expose finite clauses hidden in strings and names hidden in a colon-list group name.
- **Final census:**1,866=1,724 claim structures+142 nominal descriptions;2,103 executable candidates;0 old candidates lost.35 new accepts and8 earlier accepts now flagged (net+27).80 program hashes change, not80 certified corrections.227 lexical alerts,8 opaque-clause alerts,2 incomplete lists,272 earlier-style parser/compiler refusals. Earlier260 lexical alerts become32 passing,226 still lexical,2 list alerts;1 new executable candidate still has a lexical alert. All11 user-faithful programs unchanged/accepted. No unexpected exceptions. Cached full loop29.58s excludes parsing/input loading, not native cost profiling.
- **Qualitative evidence:** New20 reserved before changes, excluding170 recorded review sources;60 eligible claims. Assistant readings precede current paired inspection; all texts processed before and Tsuk2uoYj-kc_621 was a prior diagnostic. Both conditions17 faithful/2 partial/1 incorrect; other19 give16/2/1. No fresh programs/statuses change and no generalization gain is demonstrated. Twelve sampled first-freeze recoveries retain targeted omissions, but whole-claim assistant judgments10 faithful/2 partial; not human gold or all35 precision. Remaining group-distribution/matrix-scope defects and prepositional reciprocal are explicit.
- **Chronology:** First41-file freeze/census and258 tests preserved. During old-demo QA, two false lexical alerts were corrected (TLO3smKI67PM_554 and585); no program hashes change and no fresh review evidence prompted the correction. Final259 tests/freeze recorded. Do not claim the final source was untouched before all review. Optional callbacks in scope_coverage and the census preserve all2,375 preceding default records exactly. Earlier source copies and17 historical ZIPs unchanged.
- **Report:**28 simple claim→failure→repair→conditions walkthroughs, exact historical-baseline selectors, all2,375 full saved outputs, raw predicates optional,3-state native OCR demo. Native controls use constructed evidence; supported speech cannot verify the printed row. The compiler still needs matching fixed/learned evidence functions. Source bundle includes inputs, first/final freezes, all outputs, reviews and deterministic generators.
- **Validation:**259 selected checks pass; independent extraction repeats them and exactly replays both2,375-record inventories. Report/archive byte rebuild and20-page HTML validation pass. Browser evidence is recorded separately after checking28 demos, historical baselines,3 controls,4,750 display outputs, downloads and desktop/mobile/dark mode. Publication verification follows separately.
- **Next proposals/goals:** Review remaining numerical/appositive alerts to choose a bounded repair set; expose remaining hidden-clause/list relationships or refuse explicitly. Keep references, native profiling and any rewrite deferred per user instruction.

- **Publication verified:** Site commit b3a64054bd86f00050c3837d7bb31994e99adf13; Pages workflow 42085890498 succeeded. All42 changed live files byte-match validated local artifacts, including24 output chunks and the reproducible source ZIP. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html. Browser checks pass for28 demos, historical comparisons,3 native controls, all4,750 displayed outputs, downloads and mobile/dark mode. Evidence: content_recovery_20261105/publication.json, browser_checks.json, archive_verification.json and replay_verification.json. References, native profiling and rewriting remain deferred; next work stays on remaining omissions and hidden clauses/lists.


### Group: Numbers, appositions, explicit lists and content clauses — 2026-11-05

| Run | Scope | Measured outcome | Evidence |
|---|---|---|---|
| content_relations_20261105 | User-authorized next two compiler steps; all 2,375 original cached claims | 1,924 pass checks versus 1,866; 58 recoveries, 0 earlier passes lost; 2,103 executable candidates unchanged; 67 changed programs; 290 tests pass | exp/probabilistic_verification/content_relations_20261105/; docs/content_relations_compilation.md; site/reports/compiler-demos.html |

- **Implementation:** One deterministic SRL/dependency translation. Explicit label nouns/joined names retain numeric identifiers; scaled counts/amounts, approximation and ranges stay typed. Bounded comma/parenthesis appositions retain local nominal relations. Both leader lists have all six names, local parties and a two-person co-leader subgroup. Restricted present where clauses expose event/location binding; existing finite how frames attach under describe/explain/investigate.
- **Development restriction:** A broad postposed-number rule labeled a date and tally as identifiers. Restricted to declared labels/joined names before final 38-file freeze. First exploratory output retained; no compiler change follows the post-freeze 12-case review.
- **Census:** 54 prior lexical alerts and 4 structural alerts recover. 173 lexical alerts, 6 opaque clauses and 272 parser/compiler refusals remain. All 11 user-faithful programs unchanged. Remaining missing-token categories overlap: nouns 86, adverbs 52, proper names 49, numbers 45, adjectives 39, verbs 7. Zero unexpected exceptions. Cached loop 30.96s excludes parsing/input loading; not native cost profiling.
- **Review limits:** Twelve seeded newly passing cases outside 18 explicit development IDs retain all 12 local targets. Compiler-author diagnosis finds other defects (transition as noun, opaque back-up phrase, nominal suspicion semantics); no independent human labels, whole-claim precision or held-out semantic gain. Six residual clause cases include attachment, mixed nominal/clausal objects, comparative and conditional scope; saved diagnoses do not force acceptance.
- **Tests:** 290 selected tests pass, including actual DeepProbLog count-bound controls on supplied 70/80/unavailable counts and earlier probability/gradient/OCR regressions. No new media model or relation training. Full-record replay, archive and browser/publication proofs are stored separately.
- **Report:** 41 demos retain all 28 earlier cases and 13 new cases with exact historical baselines. New Latest changes and Daily log tabs; recent dates first, links opening the appropriate step/tab/example, and earlier entries explicitly selected reconstructed milestones. Preserve the previous source ZIP at compiler-demos/history/content-recovery-20261105-source.zip; 18 prior ZIP hashes unchanged.
- **Next proposals/goals:** Obtain user review of recovered conditions; inspect remaining measurements and mixed noun/clause objects to choose bounded repairs or retain refusals. References, larger-program profiling and rewriting remain deferred.

- **Final code-audit follow-up:** Added an AND-only guard for newly recovered nominal lists/appositions; OR alternatives remain unresolved.291 tests pass. The final source follows the12-case diagnostic review; pre_guard_frozen preserves the earlier38-file/290-test freeze. Both full-record replays verify that every corpus output and prior judgment remains unchanged. A reporting-only category order was stabilized for byte-exact rebuild. See guard_followup.json and archive/replay proofs; this supersedes earlier statements that no code change followed review.

- **Final validation:** Independent release extraction passes291 tests and exactly replays both2,375-record inventories. All40 report/download files including the source ZIP rebuild byte-for-byte;18 historical archives unchanged. All20 HTML pages validate. Browser checks41 demos, historical baselines,3 native controls,9 dated daily sections, hash links, filters, downloads and mobile/dark mode with no page errors. The final4750-output rendering result reuses the earlier complete rendering check only after byte comparison of all26 unchanged viewer JSON files. Publication verification follows.

- **Publication verified:** Content commit c98299eec492df19d2cb8e7ceab9b9b0fdcca16c; identical-tree retry commit 03566ddf2c6f41c2bc09301817e6478ed3ad286b. Pages workflow 42097102905 succeeded after the first deployment timed out. All43 changed live files byte-match validated local artifacts, including the source ZIP and prior original archive. Live report: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html; daily log: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#daily-progress. Evidence: content_relations_20261105/publication.json, browser_checks.json, archive_verification.json and replay_verification.json. Final291 tests, exact full replays and40-file byte rebuild pass. Code/report work and publication are complete; only the documented next proposals remain.


### Group: Compiler alert review and rewrite readiness — 2026-11-11

| Run | Evidence | Outcome |
|---|---|---|
| compiler_alert_review_20261111 | All 2,375 saved rows across four stages; 179 candidate alerts; 34 stratified no-program cases; 23 one-per-original-video passing controls; 22 targeted clause-literal hits | Compiler unchanged: 2,103 generated/1,924 current content-check passes. Local alert judgments 166 apparent gaps/5 likely overstrict/8 uncertain. Passing controls 18 faithful/4 partial/1 context-dependent. |

- **Metrics:** Original 2,099 candidates all remain. Four more now generate; one of those is flagged. Generation is schema/syntax success, not semantic accuracy or full native throughput. Earlier content checks changed; display their definitions separately in history.
- **Review provenance:** Compiler-author diagnostic judgments, no independent human gold or corpus accuracy. All texts processed before; passing controls cover 23 original-video prefixes rather than segment tuples. Five overstrict word alerts do not imply five faithful outputs; Example/338Canada and In/job-title cases retain other concerns.
- **Refusals:** 34 sampled cases: 19 possible rewrite targets, 6 basic source/quote/type issues, 9 reference/unsupported-meaning cases. Do not extrapolate suitability to all 272 no-program claims.
- **Missed structures:** A targeted 22-case literal search has 5 identified binding/source gaps, 2 review cases, 15 ordinary references. Music plays while robot runs passes by retaining its second clause as time text. The search is diagnostic, not a corpus failure-rate estimate.
- **Recommendation, not implementation:** Freeze broad grammar expansion now; use a fixed compiler versus a small checked rewrite pilot next. 451 strict refusals are 19.0%, not proven harmless outliers. No diminishing-return curve measured; the preceding repair batch recovered 58 checks. Keep basic source/quote/type corrections separate.
- **Pilot proposal:** 24 failed targets+ 8 unchanged controls+ 8 semantic guards (40). One frozen text model sees claim/parses, no labels/media; preserve false claims, exact quotes, roles/shared identities, number ownership, time/aspect, polarity, modality and source scope. Proposed gates 12/24 faithful recoveries, 0 control regressions, 0 accepted critical changes; refusals allowed. Not measured results or a statistical guarantee. Train only on checked triples after preparation freezes.
- **Artifacts:** exp/probabilistic_verification/compiler_alert_review_20261111/; docs/compiler_alert_review_20261111.md; report Alert review / Results / Daily log. Canonical daily entries now live in docs/project_notes/daily_log.json. All 38 compiler/runner/test files and baseline input/output hashes unchanged. No new compiler run, model/GPU, media, training or inference experiment. The 291 regression result belongs to the earlier frozen compiler. Report-source overlay preserves original archives and 26 viewer JSON files.

- **Publication verified:** Site commit fcc3775012ffa38178cb31c49a237f8ff792e8d6; Pages workflow 43146978641 succeeded. All 14 changed live files byte-match local artifacts. Source-overlay extraction reproduces 11 report/download artifacts exactly; 20 HTML pages and all 258 review-inspector entries pass browser checks. All 19 preexisting ZIPs and 26 original viewer JSON files remain unchanged. Evidence: compiler_alert_review_20261111/publication.json, archive_verification.json and browser_checks.json. Live review: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#alert-review. The audit and publication are complete; the checked rewrite pilot remains proposed, not implemented.


### Group: Checked text rewrite pilot —2026-11-11

- **Authorization/design:** User approved40-case pilot,24 targets/8 controls/8 guards. Membership/readings frozen before generation; same38-file compiler freeze and one frozen Qwen3-30B-A3B-Instruct-2507 model. Seven original-video groups reserved from prompt tuning; all texts prior development context. No truth labels, media or reference readings in prompts. One revised prompt adds original compiler error code/message, not a truth label; both complete conditions retained, no per-claim selection.
- **Measured initial/revised:** Actual edits9/29; target automatic passes3/10; reviewed faithful target recoveries1/2; faithful guards0/1; proposed control regressions1/2; unchanged text labeled rewrite7/4. Revised proposals have11 assistant-identified critical changes, none accepted. Both predeclared gates fail. All80 triples reviewed by compiler-author assistant, no independent human gold or unseen-test estimate. Three-judge compound in revised condition is coarse retained content, not counted as the explicit cardinality binding; initial panel-of-three case is a separate success.
- **Full reruns:** All2375 originals reproduce saved records exactly,2103 generated/1924 passes. A second full2375-record run with only revised-prompt reviewed replacements (TMrQshDs8aH0_750, TzF9M4kZ3Pys_223, TFOEIehBwT8Q_504) gives2105 generated/1927 content-check passes,448 strict refusals. Full-record agreement with the reviewed-replacement inventory. Not1927 semantically certified training examples; original automatic passes can remain wrong. Initial-prompt success is not mixed into revised corpus.
- **Why no automatic scale-up:** Diagnostics induce invented signers, mission/controller context and previous-year comparisons. Clearer wording can still yield sweep as kicking actor, track as running actor, rate units as counted objects and narration/audio existence outside negation. Exact name/quote controls change. No more prompt tuning this round; broad grammar and both prompts frozen. This is a result of this model/protocol, not proof that all rewriting methods fail.
- **Implementation/validation:** claim_rewrite.py provides text-only requests, conservative surface checks and review hashes bound to exact artifacts.13 new tests pass, including role-swap counterexample and stale-review protection. Source/input/compiler hashes verified.20 historical ZIPs and26 original viewer JSONs preserved. Two model jobs1225132/1225198 completed sequentially on one80GB A100 (644/103 allocated seconds;16.57/17.88 generation seconds); queued H1001225122 canceled. No new media, relation training or native DeepProbLog inference experiment.
- **Artifacts/report:** exp/probabilistic_verification/claim_rewrite_20261111/; docs/claim_rewrite_pilot_20261111.md; scripts/{prepare_claim_rewrite_pilot,run_claim_rewrite_model,parse_claim_rewrites,compile_claim_rewrite_pilot,analyze_claim_rewrite_pilot}.py. Report compiler-demos.html#rewrite-pilot exposes original/initial/revised text, all80 reviews, compiled structures and optional raw predicates. Checklist18 complete as a bounded pilot, gates not met; training held. Source-rebuild/browser/publication proofs follow separately.
- **Next proposals/goals:** User review of retained/rejected triples to check assistant judgments; bounded quantity/negation contract work or a separate stronger-rewriter comparison to address failures; repeat fidelity gates before corpus-wide rewriting/new DeepProbLog learning.

- **Final validation/publication:** Complete. Site commit 51cac587d9657b46e8b5d29babd5eaf4a012a217; Pages workflow 43155809347 succeeded. All17 changed live files match validated local bytes. Isolated source extraction exactly replays2375 originals,40 diagnostic proposals and2375 reviewed-corpus rows;14 report/download artifacts rebuild byte-exactly, including source.zip.13 new tests pass;20 HTML pages validate; browser covers all40 cases/both reviews,41 earlier demos,7 tabs, deep links, daily log, downloads and mobile/dark layouts with no page errors.20 historical ZIPs/26 viewer JSONs unchanged. Evidence: claim_rewrite_20261111/{publication,archive_verification,browser_checks}.json. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#rewrite-pilot. The bounded pilot/publication are complete; both gates fail and automatic expansion/new learning remain deferred.


### Group: Failure-only rewrite routing and request inspection —2026-11-12

- **Implemented:** Generation compiles original inputs and skips all compiled results before importing/loading a model; unknown statuses/mismatched IDs fail validation. The earlier full-corpus replacement path already skipped passes. Historical8 controls plus1 passing ambiguous guard are diagnostic probes outside this fallback.
- **Measured CPU checks:** Same40 inputs:31 eligible failures/9 skipped passes. All-passing8 inputs with no plan-only flag return zero planned requests and model_called=false. Isolated source replay confirms vLLM is never imported in either no-model check.17 tests pass. Among31 historical fallback cases: initial1 recovery/30 rejected, revised3/28. Original metrics/judgments unchanged; no new model/GPU/media/inference/training experiment.
- **Report:** Five failure examples; default failure-only subset;28 rejected-proposal filter; exact system/user messages, raw response and model configuration for all80 saved requests, unfolded, with prompt-condition deep links. Distinguish changed rewrite meaning from wrong compiled roles/units/negation and unchanged outputs. Evidence: rewrite_inspection_20261112/{inspection.json,routing_summary.json,plan_raw.routing.json,passing_only_raw.routing.json,tests.xml}. New dated source overlay preserves21 old ZIPs,26 original viewer JSONs and frozen pilot artifacts.
- **Validation:**20 HTML pages, all80 exact prompt/response comparisons and five example links checked; default31/rejected28/skipped9 filters; mobile/dark layouts; no browser errors. Isolated extraction reproduces9 report/download artifacts byte-exactly, including the source ZIP and routing behavior. Publication proof follows separately.
- **Next goals:** User inspection of failed triples/prompts to confirm failure locations; choose one bounded semantic or rewriting change based on that review, without restarting broad grammar work or training yet.

- **Publication verified:** Commit 512f4c93ea8b7e7c38a0c6c450381597bb0192f1; Pages workflow 43167008692 succeeded. All11 changed live files match local bytes. Source extraction reproduces9 artifacts including source.zip and both no-model routing checks;80 exact requests,5 example links,17 tests and20 HTML pages validate.21 historical archives/26 viewer files remain unchanged. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#rewrite-failed-examples. This routing/inspection update is complete; no new model run or semantic/compiler optimization.


### Group: Sentence splitting with context links —2026-11-12

- User intent: split a complex failed claim into simpler subclaims without changing meaning; prior one-sentence restriction was too narrow. Compile first; all passing originals bypass the model.
- Model run:31 previously inspected strict failures, one fixed Qwen3-30B-A3B-Instruct-2507 text-only prompt, temp0,seed42,max2048,float16,vLLM0.18.0. One H100 job1225328 completed672 allocated seconds/40.17 generation seconds; released. No truth labels/media/reference readings in requests.
- Automatic:77 clauses,65 component passes;20 cases have at least2/all clauses pass;6 linked programs generated;0 complete results approved by compiler-author review. Wrong identity links, scoped descriptions, quantities and quotation/negation changes remain. Some texts are useful, including Trump, but adapter contracts can still refuse them.
- Selected assistant-written diagnostic after proposal inspection:8 cases,7 splits/1 guard refusal;18/18 component passes;6 linked programs;4 faithful linked versus2 faithful flat conjunctions. Trump and second-shot vehicle recover only with source context; police and exact sign quote work with shared-participant conjunction too. Building houses mistagging and rainfall/speed quantity/event errors remain. Not an automatic gain, held-out estimate or independent human gold.
- Implementation: separate clause composition adapter reuses existing source/relative/temporal operators, explicit shared mentions, scoped route inheritance and conservative refusal. Initial/generation/final source history retained; post-inspection changes documented.38 core compiler hashes unchanged; original2375 baseline stays2103 generated/1924 passing. No new corpus rerun, media inference, native DeepProbLog run or relation learning.
- Evidence: claim_split_20261112/{raw,results,semantic_review,summary,cases} plus supervised subfolder and source snapshots; docs/claim_split_20261112.md.15 new composition tests; integration/publication proofs recorded separately. Report compiler-demos.html#sentence-splitting and updated checklist19/Daily log.
- Next proposals/goals: review clean versus automatic clauses; separate sentence generation from reference resolution using original entity/event mentions to reduce wrong links; repeat fixed full-meaning checks before corpus-wide fallback or new DeepProbLog training.

- Validation completed:32 focused tests pass (15 composition/17 rewrite),20 HTML pages validate; all39 case views/31 exact requests,8 tabs,41 historical demos,2,375 original outputs and mobile/dark layout checked with no page errors. Isolated cached-source replay reproduces39 cases and16 report/download artifacts, including the deterministic source ZIP. All22 prior ZIPs/26 original viewer JSON files and38 core compiler files remain unchanged. Publication proof follows separately.

- Publication verified: commit 341dde09435b11ddb6865d69de190879aaad9449; Pages workflow 43174956447 succeeded. All15 changed live files match local bytes, including the source bundle. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#sentence-splitting. This bounded experiment/report is complete; automatic expansion and new training are not enabled. Evidence: claim_split_20261112/publication.json.


### Group: Sentences-only generation and original-mention alignment —2026-11-12

- Run: exp/probabilistic_verification/split_alignment_20261112; docs/split_alignment_20261112.md. Same31 previously inspected strict failures; no passing-original generation. Frozen Qwen3-30B-A3B-Instruct-2507,float16,temp0,seed42,max2048. H100 job1226662 completed207 allocated seconds/7.54 generation seconds, resources released. No media/labels/reference readings in requests.
- New module matches unique original noun heads; shares their identities, preserves a simple source context and records original event anchors. Compatible original-noun properties can merge; ambiguous nouns, unsupported source frames and conflicting/time-unsafe event alignment are refused.38 direct compiler hashes unchanged. Initial sources/freeze and two later general fixes retained.
- Comparison: previous model links0/31 faithful; exact same old77 sentences/new alignment65 component passes,20 all-component passes,4 programs,2 faithful (officers/robot). New sentences-only prompt86 clauses,71 passes,18 all-component passes,4 programs,2 faithful (Trump/officers). No evidence of higher recovery count from the new prompt. All62 compiler-author reviews are hash-bound; not independent gold or unseen testing.
- Full fresh2375 originals reproduce exact JSON-normalized records:1924/2375=81.01% pass checks;2103/2375=88.55% candidates. Only2 reviewed new automatic splits replace failures:1926/2375=81.09% pass;2105/2375=88.63% candidates;449 remain. Gain0.08 percentage points. No manual clauses or best-of-prompts union. Historical1927 belongs to the separate single-sentence diagnostic; counts are not cumulative production accuracy.
- Failure review:12 component refusals,10 entity-alignment,3 source-alignment,2 conflicting descriptions,2 reviewed rejects. Magnitude remains untyped; no-narration becomes contradiction; construction is invented; quotes become world events. Typed quantities and quantified absence remain semantic tasks, not prompt fixes.
- Validation:42 focused tests; full record equality; browser/source/publication proofs follow.23 historical archives/26 original viewer files preserved. Report Sentence splitting/current-corpus-rate and checklist20/Daily log updated.
- Next proposals/goals: bound participant-ID/source-frame handling to reduce false refusals; define measurement/absence contracts; recheck corpus and complete meaning before expanded failure evaluation or new DeepProbLog learning.

- Validation completed:42 focused tests pass;20 HTML pages validate. Browser checks cover all62 comparisons/exact requests,8 tabs,5 example links,41 historical demos,2375 original outputs and mobile/dark layouts with no page errors. Isolated source replay reproduces62 comparisons and2375 combined rows;17 report/download artifacts including source.zip match byte-for-byte. All23 prior ZIPs/26 viewer JSONs and38 compiler files remain unchanged. Publication proof follows separately.

- Publication verified: commit f7a47454291e285429b81b8294c8da6de79740d1; Pages workflow 43264909763 succeeded. All16 changed live files match local bytes, including7.08MiB source.zip. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#split-alignment. The bounded experiment, fresh census, report and publication are complete; automatic corpus-wide fallback/new learning remain deferred. Evidence: split_alignment_20261112/publication.json.


### Group: Remaining-claim diagnosis and report consolidation —2026-11-12

- User confirmed both fewer website pages/tabs and fewer interim updates. Main Reports entries13→2; compiler views8→5: Overview, Examples, All claims, Daily log, History. Earlier report/case URLs and all archives retained; no new report page. Current rate1926/2375=81.09% unchanged.
- Recomputed from saved corpus_reviewed:449 remaining=29 tested unrecovered+420 never rewritten;31 total rewrites/2 recoveries. First-check groups227 predicate formation (109 unresolved clauses,59 duplicate roles,34 missing predicates,11 missing SRL,8 predicate type,6 opaque clauses),173 omitted-content,43 operator/type,6 explicit reference/controller/media. Not a complete semantic root-cause taxonomy or rewrite success estimate.
-179 flagged candidate IDs exactly match the earlier local alert review (166 gaps/5 overstrict/8 uncertain).270 failures have no program. Simple truck/dock/ship directions expose entity-valued repeated-role restrictions; no-audio/units need semantic implementation; identifiers/source frames expose conservative alignment; model also invents narration/construction or projects quotes. No new semantic gold, model/GPU/compiler run or training.
- Evidence: report_cleanup_20261112/{failure_audit,remaining}.json, docs/compiler_report_consolidation_20261112.md, analyze_remaining_claims.py and current Overview. Counts preserve first-failure distinctions and unknowns. Source/browser/publication proofs follow.
- Proposed next goals: audit repeated adjuncts/explicit IDs; define measurement/absence semantics; then test a stratified sample of420 untested failures before finalizing rewriting.

- Validation/publication complete:20 HTML pages validate; two Reports entries/five compiler views,11 old report URLs,13 legacy fragments, current/historical inspectors,41 demos,8 manual cases and mobile/dark layout pass with no page errors. Source replay reproduces8 artifacts including source.zip;24 prior archives,26 original viewer JSONs,all frozen split/alignment JSON artifacts and38 compiler files remain unchanged. Commit 38ab98b45a67505057e1d439a76a9803ee099864; Pages workflow 43268288461 succeeded; all9 changed live files match local bytes. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#remaining-failures. No new model/compiler experiment.


### Group: Complete449-case rewrite and compilation —2026-11-12

- User authorized bounded role/identifier, measurement/absence work and all449 previous rejects. Run rewrite_all_20261112; docs/rewrite_all_20261112.md. New opt-in compiler extensions preserve all2375 historical default outputs exactly; current5corefileschanged,38-filebaseline snapshot preserved.360 tests pass.
- Final Qwen3-30B-A3B-Instruct-2507,temp0,seed42,float16,max3072/context32768:30directpasses bypassmodel,419requests,1437clauses,1140componentpasses,210allcomponentpasses. Stages207component/142alignment/14composition/2refuse/54composed. One final prompt; initial418requests completed but excluded; final419used. Sequential H100jobs1226788(133s)/1226791(134s),bothreleased; finalgeneration84.29s.
- All84programs (30direct+54rewritten) hash-bound compiler-author assistant review:27faithful=14direct+13rewrite;57partial/incorrect/uncertain not approved. Other365 have failurediagnostics, not blanket semantic judgments. Previous1926rows exact:1953/2375=82.23%,422remaining. Automatic2010=84.63% includes bad meaning; neither number is independent semantic accuracy. Earlier1926notall re-reviewed.
- Main first codes119entityalignment,96coverageomission,62unresolvedclause. Complete programs still lose class-reference bindings, OR/while scope, quoted/source context. Fixedprompt/generationalone not the main next step. Actual3nativeabsence runs use constructed inventories; incompleteempty→unknown. No empirical media/relationtraining experiment.
- Current report keeps5views/2Reportsentries; all449 examples/exactrequests/logic/reviews; earlier31-case results inHistory. Proposed next:preserve originaloperators/sourcecontext; resolve classdescription and richer originalspan/group references; replaycached419 and reviewnewprograms beforeanother modelrun/training. Source/browser/publication proofs follow separately.


- **Validation/publication verified:** Commit 995cb98141c7e765cd1ffed13b331c34f4550e7b; Pages workflow 43281413186 succeeded. All18 changed live files match validated local bytes. Source extraction replays449 outcomes and2375 final records;23 artifacts including source.zip match byte-for-byte.360 tests;20 HTML pages;all449 case views/419 exact requests/30 model skips/84 programs;5 compiler views/2 main Reports cards,13 legacy fragments,11 earlier pages,41 demos and mobile/dark layout pass with zero page errors.25 earlier archives/26 viewer files and38 baseline-source hashes preserved. Current compiler source has opt-in extensions; default2375outputs remain identical. Evidence rewrite_all_20261112/{publication,archive_verification,browser_checks}.json. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#remaining-failures . Experiment/report complete; next work remains proposed.


### 2026-11-12 — Missing-content diagnosis for terrain/timestamps
- Saved449-case analysis only; no compiler/prompt/output/site changes or new model run. TjHepwuhkYFA_1016: direct parse loses shift event; rewritten c1 loses calendar date while nominal clock survives; c5/c6 lose relative in relative to; c3/c4 pass lexical coverage with shifts misread as a noun.
- Across current422remaining:96 first coverage failures;104 unique claims have any bad rewritten component,135 clauses. Calendar date/year/month omissions9claims/10clauses (contexts inspected); exact relative omission1claim/2clauses; exact ISO-date omission same1claim. Groups overlap. Not an estimate of recoverable claims.
- Evidence exp/probabilistic_verification/coverage_diagnosis_20261112/{analysis.py,analysis.json,README.md}. Proposed: complete date/time preservation bound to event, multiword relation/reference handling, main-event/binding checks; then replay fixed cached clauses. Avoid suppressing the coverage check or claiming a recovered full program from two local repairs.


### 2026-11-12 — Generality of missing-content repairs: literature comparison
- Focused primary-source check: SUTime (https://aclanthology.org/L12-1122/), TimeML/TimeBank (https://catalog.ldc.upenn.edu/docs/LDC2006T08/timebank.html), preposition supersenses/SNACS (https://aclanthology.org/P18-1018/), AMR (https://aclanthology.org/W13-2322.pdf), neural graph parsing (https://aclanthology.org/D19-1392/), PICARD (https://aclanthology.org/2021.emnlp-main.779/).
- Interpretation/proposal: general date/time normalization plus event linking; contextual phrase/relation interpretation rather than a relative-to-only patch; semantic-event checks must allow nominal events. Track original spans alongside normalized values/relations and separately check bindings/scope. Grammar-valid structure does not establish claim faithfulness. Standard AMR omits tense; earlier project AMR/constrained-editor failures remain relevant.
- No implementation/model/site changes or measured improvement. Proposed bounded follow-up uses existing logical form and one parser path, with new paraphrase/contrast tests plus cached419 replay. Avoid open-ended lexical patches/parser ensembles; compiler preparation is not the claimed paper novelty. Details appended to coverage_diagnosis_20261112/README.md.


### Group: Shared values, phrase relations and semantic checks —2026-11-12
- Completed bounded experiment; docs/semantic_components_20261112.md, RUNsemantic_components_20261112. No new model/GPU/media/empirical training.36 authorprobes savedbeforecode; actual CPU Stanza/BERT-SRL; notindependentgold. Target10/36→34/36; remainingambiguousinrelationto/nominalcollapse. Same1437cachedclauses1140→1147passes; valuesonly1148/phrases1150 beforestricterchecks.
- Final449:33direct/54composed=87programs;203component/144alignment/13composition/2refuse.30approved(previous27),57notapproved;9new/changedprograms inspected,78exactprogram/form reviewsreused. Three newdate/time cases755/1521/2324 approved. Three earlier legacy passes1831/1908/1924withdrawn afternewstructuralreview. Revisedpool1953/2375=82.23%,422remaining, no netgain; no independentsemanticaccuracy. Retain old artifacts, not falseclaimalloldpassesunchanged.
- Full2375DIRECTautomaticprevious1953/new1953,3gains3refusals123programchanges. Numericalcoincidence withcombinedpoolbutdifferentmembers/criteria.385testspass(25new,2controllednativebinding);historicaldefault2375exact. Sharednormalizer preserves completevalues/typedrepeatedadjuncts/timezones; ambiguoustime scales notguessed. Sourcealignmentcredit requires survivingtypedcondition/relation. Boundedphraseinventory, notfullsemanticparser.
- Developmentcorrections disclosed: initialcheckerquotedevents/alternateIDs/normalizationmissingoverstrict; sharedrepeatedtimeflattening/clockelapsedmistakes corrected; allconditionsrerun, outputs/sourcesretained. Terrainlocaldate/referencefixesworkbutwholeclaimunresolvedtime/eventreference. Proposednext: event/intervalcoreference, boundednominaleventcases, thenfreezeandnewclaimchecks beforeexpansion/training. Publicationvalidationproofsfollowseparately.


- **Validation/publication complete:** Commit 14433b26549e798ffe81f65d1ac5397b872662af; Pages workflow 43302959132 succeeded. All14 changed live files match validated local bytes, including the39.67MiB source overlay. Isolated nine-bundle extraction replays36probes,1437cachedclauses,449fallbackcases and2375originals;20artifacts including source.zip match byte-for-byte.385tests pass;2375historicaldefaultoutputs exact. Browser covers47comparisons,5views/2Reportscards,41earlierdemos/449oldcases,10legacyfragments/deeplinks andmobile/dark withzero pageerrors.26olderZIPs/26originalviewerfiles andall frozenoldinputs preserved. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#semantic-components . New components remain opt-in; no netreviewedcoveragegain, no independentaccuracy claim.

## Latest compiler stopping-point experiment — 12 November 2026

Read docs/compiler_readiness_20261112.md and exp/probabilistic_verification/compiler_readiness_20261112/summary.json. ADR-023 and failure-only rewriting remain unchanged. Proposed stopping point: freeze broad compiler optimization and begin a small, audited relation-learning experiment. Universal parsing and empirical training readiness are not established.

Completed: all 2,375 originals rerun. Direct automatic passes improve from 1,953 to 1,978 (83.28%); auxiliary filtering alone gives 1,960. Replaying the entire cached 449-case cohort gives 108 complete programs versus 87 (58 direct, 50 composed). All 25 changed complete programs were inspected: 12 retained, including two replacements of already accepted splits. Ten additions result; 83 exact program/form judgments are reused. The retained combined pool is 1,963/2,375 (82.65%), with 412 excluded. Most old passes were not re-reviewed. These are development judgments, not semantic accuracy, media labels or training eligibility.

General repairs filter duplicate auxiliary frames only with an existing lexical-head frame, retain attached adverbs as explicit conditions, and resolve a unique parent interval on an existing event. Scope-sensitive adverbs are excluded from the repair; missing events still cause refusal, including the whole focal terrain claim. Same-day omitted end dates are supported; midnight rollover is refused. Nominal event variables/event_type work on authored collapse checks, but WordNet typing confuses electoral riding and camera shot. Therefore nominals=False by default, excluded from the corpus gains; this is not a trained nominal SRL parser.

First stopping stages among 412 exclusions: component compilation 179, alignment 148 (including 126 noun-head failures), meaning review 68, composition 13, model refusal 1, uncached legacy cases 3. A concise new prompt is proposed but untested. H100 job1227635 and A100 job1227636 were cancelled while pending; the latter was estimated to start the next day. No new model or media requests ran. All 419 earlier responses were replayed with one fixed condition, without per-claim prompt selection.

Native DeepProbLog training was checked on four assistant-inspected color clauses from one development clip, using actual 4,096-dimensional frozen visual features and a 270,595-parameter MLP with 64 hidden units. Thirty CPU epochs use claim labels only; features and old eligibility flags remain unchanged. This is an engineering check that fits four examples, not held-out evidence. Referents, non-color conditions and time are stipulated; no audio or evidence-alignment learning. Initial fixture-sharing errors are preserved in development/ and excluded. All 411 tests pass; the 2,375 historical default outputs remain JSON-identical.

Keep work in the existing compiler-demos Overview, Examples, All claims, Daily log and History. The All claims viewer now shows the updated pool; historical archives/viewer JSONs remain unchanged. Proposed next: audit source-disjoint claims and evidence labels; create checked binding edits and cache features; then compare small classifiers against frozen-model and simple aggregation baselines on held-out videos. Do not wait for 100% parsing. Reopen compiler work for demonstrated experiment blockers, and continue to list concrete next steps and goals in completion reports.



### Compiler repairs and bounded feedback — 12 November 2026

Compiler correctness remains the priority; no empirical training/media inference/SRL retraining. Read docs/compiler_repairs_20261112.md and exp/probabilistic_verification/compiler_repairs_20261112/summary.json. Existing Stanza/AMR already preserve the motivating adjective/reflexive; conversion was defective. Repairs add source-attached missing adjectives, local reflexive identity, unique derivational event references, explicit nested AND/OR, simple likelihood scope, qualified absence and bound speech/OCR quotes. Ambiguous references/missing events still refuse. Rewrite only after strict direct failure.

Completed corpus rerun:1983 direct automatic passes vs1978, no lost statuses. Cached449 yield114 programs (63direct/51composed),13 changed programs inspected:9accepted/4rejected;101exact reviews reused. Seven previously retained changes receive targeted repair review. Retained pool1972/2375=83.03%,403excluded; most older passes not fully re-reviewed. First stops178components/143alignment/65meaning/13composition/1modelrefusal/3uncached. These are development compilation judgments, not accuracy/media labels.438tests pass; historical2375defaultoutputs exact.

Model pilots separate:24 fixed strict failures, maxone compiler-error retry; conservativeQwen30B first0/final1, none faithful; revisedQwenVL8B text-only first3/final3, shotsORexplosions accepted, implication/logo attachments rejected. Model+prompt+compiler snapshots differ, not causal prompt evidence.30Bjob1228116 timed out after completed rewrite rounds, before direct responses.8Bdirect initial prompt lacked format explanation and returned12refusals; separate guided comparison supplies format/example:2/12 pass existing checks, both rejected for purpose/argument representation. Exact prompts/configs/errors and snapshots preserved. Do not pool pilots into full-corpus coverage.

Keep latest results in compiler-demos Overview/Examples/Allclaims/Dailylog, earlier experiments in History; preserve all28 oldZIPs/original26viewers. Next proposed: improve event/mention/source composition; evaluate one fixed guided model condition on remaining failures; review changed programs/source-disjoint claims before relation learning.


## 2026-11-13 — Typed edits with compiler feedback

Compiler correctness remains the priority; ADR-023 unchanged. Read docs/compiler_feedback_20261113.md and exp/probabilistic_verification/compiler_feedback_20261112/summary.json. All2375 original/449cached outputs remain byte-identical to compiler_repairs_20261112:1983direct passes/114cached programs. Of403exclusions,376strictly fail;158have drafts(all tested),218lack drafts(no edit request);27direct passes receive no request.

Final fixed method: frozen text-only Qwen3-30B-A3B-Instruct-2507, dependency/SRL/draft input, typed JSON Patch add/replace/remove, max8operations/1536tokens, greedy, shared first attempt then at most2 feedback or generic retries. No whole-form replacement, AMR/model ensemble, per-claim branch selection or meaning-review-triggered retry. Finaljob1228934 completed19m36s on1H100;605unique requests; allresources released.

Sharedfirst41complete/5approved; generic46/8; feedback61/9. Before-model2passes both rejected. All63unique complete final programs inspected by compiler author; not independent gold. Onlyfeedback9 additions enter pool:1981/2375=83.41%,394excluded; all1972oldretained exact. One addition is context-dependent mention Beijing recently, not a complete event/training example. Most old passes not re-reviewed. Feedback improves automatic passes far more than faithful outputs; don't claim20faithful recoveries or merge older whole-form trials.

466tests pass. Frozen158-case CPU replay exact, including all retry files. Typed values prevent malformed shapes, not incorrect roles/scope/numbers. Source grammar checks can reinforce wrong parses(sweep as Robot-kick subject); local edits cannot easily repair root structure. Wind-speed case still fails; authored3-addition fixture is not a model recovery. All earlier trial snapshots/outputs preserved. Existing five report views/two Reports cards/29historical ZIPs/26original viewers preserved. Next proposed: partial forms for218no-draft failures; joint participant/scope/noun checks; bounded structural correction and source-disjoint review. Training/media/SRL retraining remain deferred.



- **Publication verified (2026-11-13):** Site commit d1e92a0d80ade0481839c5f5b54f4782761582d5; Pages deployment succeeded. All 43 changed live files match local SHA256 bytes, including the 43.89 MiB source overlay. Archive replay reproduces nine primary artifacts plus all saved edit rounds; a later README clarification changes only four documentation/inventory ZIP members, with all executable code and replay data unchanged. Browser checks cover 316 condition/case views, 765 displayed attempts, 394 exclusions, five views/two report cards and legacy navigation, with no page errors or mobile overflow. All 29 historical ZIPs/26 original viewer files remain unchanged. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html?v=d1e92a0#remaining-failures . Publication proof: exp/probabilistic_verification/compiler_feedback_20261112/publication.json.


## Partial parses and neural alternatives — 13 November 2026

Compiler priority and ADR-023 remain unchanged. Read docs/compiler_structural_20261113.md, exp/probabilistic_verification/compiler_structural_20261113/summary.json and research/compiler_alternatives_20261113/RECOMMENDATIONS.md. Full 2,375 original/449 cached outputs remain byte-identical: 1,983 direct passes and 114 cached programs. Retained pool stays 1,981/2,375 (83.41%), with 394 excluded; every old retained program is unchanged. No new training/media inference/SRL retraining.

Partial capture preserves actual compiler state for 189 of 218 no-draft failures, leaving 29; these are not new passes. Among current exclusions, 367 strict failures include 149 existing drafts + 189 newly captured partial forms; 27 automatic direct passes receive no request. A fixed 40-case diagnostic (20 existing/20 partial) permits at most four typed edits and subtree replacement. Permissive development first4/generic6/feedback8 complete; strict literal types first5/generic5/feedback7. All 13 unique complete outputs inspected; none retained. The robot/during-race near-case is withheld for temporal/location typing, not declared an unambiguously unrelated reading. Do not extrapolate 189 draft captures or seven programs to faithful recoveries. No per-claim method pooling.

Both new branches explicitly retain the original error. Corrected an earlier report statement: saved generic messages in the preceding typed-edit trial did not explicitly retain it. Its numerical results are unchanged; historical ZIPs remain immutable. New controls share their first attempt and allow two retries; meaning review never triggers requests.

A local frozen Qwen meaning check on 63 prior programs gives 6 matching approvals/4 disputed approvals/3 missed retained/50 matching rejections (60% precision, 66.7% recall relative to compiler-author development judgments). No labels enter model messages, no confidence model is trained, and these are not independent gold/accuracy/calibration. Native DeepProbLog tests implement categorical parse choices and separate parser abstention from evidence unknown; all supplied probabilities are constructed, not learned. 484 tests pass. Jobs1230471/1230713 completed sequentially on one H100 (8m05s/5m15s);359 compiler +63 local neural requests, peak one GPU, no resources left allocated.

Research verifies 17 primary works and records 11 alternatives. Cached AMR already supplies wind-speed causality and Sheinbaum attribution, but robot/charger AMRs still contain errors. Proposed next: checked reference meanings; one fixed neural semantic-parser frontend with compositional logic conversion; then source-conditioned ranking/candidate coverage before calibrated parse mixtures. P3/NL2Logic already cover key parser/probabilistic-program infrastructure, so frontend design alone is not the paper novelty. External GPT-5.5 idea review was rejected by automatic approval for unpublished payload disclosure and never ran; local assessment is explicitly not independent. Keep work in existing compiler-demos views/history, preserving 30 historical ZIPs and 26 original viewer files.



- **Publication verified (2026-11-13):** Site commit 10065989801f56efc72efe573153034bbadfba05; Pages workflow 43548045329 succeeded. All 54 changed live files match validated local SHA256 bytes, including the 30.26 MiB source/data overlay. Isolated clean extraction reproduces 12 primary artifacts exactly, all 2,375 originals/449 cached cases, 367 failed-draft records, both 40-case generation-time checks and all 63 saved neural messages. Browser checks cover 476 condition/case views, 1,204 attempts, 394 exclusions, 63 neural checks, four AMR examples, five views/two Reports cards and all preserved case inspectors; no page errors or mobile overflow. All 30 historical ZIPs/26 original viewer files remain unchanged. All 484 tests pass. Retained pool remains 1,981/2,375 (83.41%), with 394 excluded; no new faithful recovery is claimed. Live: https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html?v=1006598#remaining-failures . Proof: exp/probabilistic_verification/compiler_structural_20261113/publication.json.


## Fixed AMR comparison and review preference — 14 November 2026

The user says not to use GPT for review; use self-review unless this is changed. No external/model judge is authorized for this comparison. See docs/amr_composition_20261114.md and exp/probabilistic_verification/amr_composition_20261114/summary.json. ADR-023 and compiler priority remain unchanged.

One cached BART AMR frontend, one opt-in converter on all 2,375 originals: 1,425 graphs convert, 950 refuse; these are graph-contract counts, not semantic accuracy. Frozen references: 20 earlier human-confirmed readings plus 40 assistant readings. Self-review of all 60: 13 matches (7/20 and 6/40), 11 partial, 9 incorrect, 4 context-needed, 23 refused. Narrower relationship/scope matches 20 must not replace 13 whole-reading matches. No new human approval, held-out evaluation, model calls, GPU allocation, media inference or training. Retained pool stays 1,981/2,375 (83.41%),394 excluded; no parser pooling/promotions.

The converter normalises inverse roles before composition, includes complete context-owner assignments, preserves shared actors/names and explicitly refuses unsupported complements/coordination/projection. Bare AMR loses source details and can hallucinate names/counts/bindings. Development snapshots are excluded. All 505 tests pass; fresh legacy 2,375/449 replay exact.22 development confidence pairs (13 positive/9 incorrect) prepared; no learned ranker/calibration, only one candidate per sentence. Current results stay in compiler-demos; earlier inspectors move to History, preserving 31 oldZIPs/26 original viewers. Proposed next: source alignments/value preservation, shared coordination/scope operators, then new-source review before confidence training.


- Native diagnostic: race/cloud unknown=1; nested wind exceeds10-second per-process budget. Earlier large attempts are preserved and excluded from successes.505tests pass after adding reentrant content references. Profile encoding/backend before training.
