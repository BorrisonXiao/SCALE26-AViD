"""Run one frozen AMR conversion on all2,375 cached original claims, CPU only."""
import hashlib,json,logging,shutil,time
from collections import Counter
from pathlib import Path
from prepare_amr_composition import ROOT,RUN,OLD,rows,dump
from probabilistic_verification.amr_composition import AMRCompiler
from probabilistic_verification.logic import Evidence,ground,prolog_program

def main():
 logging.getLogger('penman').setLevel(logging.ERROR)
 reference_bytes=(RUN/'references.json').read_bytes();selection=json.loads((RUN/'selection.json').read_text())
 assert hashlib.sha256(reference_bytes).hexdigest()==selection['references_sha256']
 refs={r['claim_id']:r for r in json.loads(reference_bytes)['references']}
 inputs=rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl');assert len(inputs)==2375
 amrs={};sources={}
 for i in range(4):
  path=ROOT/f'exp/probabilistic_verification/full_compilation_20261029/amr_{i}_raw.jsonl';sources[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
  for a in rows(path):
   cid=a['request']['task']['claim_id'];assert cid not in amrs;amrs[cid]=(a,str(path.relative_to(ROOT)))
 assert len(amrs)==2375
 frozen=RUN/'source/scripts/probabilistic_verification';frozen.mkdir(parents=True,exist_ok=True)
 for p in(ROOT/'scripts/probabilistic_verification').glob('*.py'):shutil.copy2(p,frozen/p.name)
 for n in ['run_amr_composition.py','prepare_amr_composition.py']:shutil.copy2(ROOT/'scripts'/n,frozen.parent/n)
 out=[];start=time.perf_counter()
 for r in inputs:
  cid=r['claim_id'];a,path=amrs[cid];assert a['request']['task']['text']==r['text']
  row=dict(claim_id=cid,text=r['text'],raw=a['raw'],request_hash=a['request_hash'],source_file=path,status='unsupported')
  try:
   c=AMRCompiler().compile(cid,r['text'],a['raw'],r['tokens']);row['compilation']=c.to_dict()
   e=Evidence('compilation_only',{v.name:['placeholder:'+v.name]for v in c.variables},{v.name:True for v in c.variables},{})
   program=prolog_program([ground(c,e,max_expansions=2000)],learned=False)[0]
   from problog.program import PrologString
   list(PrologString(program));row.update(status='compiled',program=program,program_sha256=hashlib.sha256(program.encode()).hexdigest(),graph_conditions=len(c.metadata['translations']))
  except Exception as error:row.update(code=getattr(error,'code',type(error).__name__),reason=str(error))
  if cid in refs:row['reference']=refs[cid]
  out.append(row)
 (RUN/'corpus.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n'for r in out))
 cases=[next(r for r in out if r['claim_id']==cid)for cid in refs];dump(RUN/'cases.json',cases)
 compiled=[r for r in out if r['status']=='compiled']
 summary=dict(total=2375,graphs_converted=len(compiled),refused=2375-len(compiled),reference_cases=60,reference_converted=sum(r['status']=='compiled'for r in cases),refusals=dict(Counter(r['code']for r in out if r['status']!='compiled')),reference_refusals=dict(Counter(r['code']for r in cases if r['status']!='compiled')),seconds=round(time.perf_counter()-start,3),cache_sources=sources,reference_sha256=selection['references_sha256'],retained_pool_before=1981,retained_pool_after=1981,promotions=0,scope_policies='scripts/probabilistic_verification/amr_composition.py',model_calls=0,review='Pending assistant review. Graph conversion is not source faithfulness. Existing human readings are references, not human judgments of new outputs.')
 dump(RUN/'summary.json',summary);dump(RUN/'input_manifest.json',dict(cache_sources=sources,inputs_sha256=hashlib.sha256((ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl').read_bytes()).hexdigest(),model_config=next(iter(amrs.values()))[0]['request']['config']))
 print(summary,flush=True)
if __name__=='__main__':main()
