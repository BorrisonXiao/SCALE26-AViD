"""Bounded source/structure checks for neural corrections, not equivalence proof."""
import re
from .scoped_srl import SourceSyntax,quoted_spans
from .logical_form_v2 import normalized

def issues(record,form):
 s=SourceSyntax(record);quotes=quoted_spans(record['text']);entities={e['id']:e for e in form.get('entities',[])};out=[];events=[]
 def quoted(token):return any(lo<=token['start_char']<hi for lo,hi,_ in quotes)
 def visit(v,p='$',contexts=()):
  if isinstance(v,list):
   for i,item in enumerate(v):visit(item,p+'['+str(i)+']',contexts)
  elif isinstance(v,dict):
   if v.get('op')=='event':events.append((v,p,contexts))
   if v.get('kind')and re.fullmatch(r'[xe]\d+',str(v.get('value','')))and not re.search(r'\b'+re.escape(str(v['value']))+r'\b',record['text'],re.I):
    out.append(dict(code='id_as_literal',path=p,message='A generated ID is not a literal source value. Entity arguments use a declared string ID; embedded event content uses a proposition body.'))
   if v.get('kind')=='verbatim_text':
    value=str(v.get('value',''));matching=[(lo,hi)for lo,hi,text in quotes if value in text]
    if not matching:
     # Unquoted indirect speech is an embedded clause, not an invented quote.
     out.append(dict(code='unquoted_verbatim',path=p,message='This wording is not quoted in the source. Represent an ordinary clause with events/negation and its original context; do not use verbatim_text to hide it.'))
   if v.get('kind')in{'time','date','duration','measurement'}:
    raw=str(v.get('text')or v.get('value',''));start=record['text'].lower().find(raw.lower())
    tokens=[t for t in s.tokens if start>=0 and start<=t['start_char']and t['end_char']<=start+len(raw)]
    if any(t['upos']in{'VERB','AUX'}for t in tokens):out.append(dict(code='clause_as_value',path=p,message='This value contains a source clause. Represent it as an attached event/proposition, preserving whether it is a condition or a time clause.'))
   for k,item in v.items():
    child_context=contexts
    if k=='body'and v.get('kind')in{'purpose','condition','complement','assertion','depiction','temporal','relative','belief','question','sufficiency'}:child_context=contexts+(v['kind'],)
    if isinstance(item,(dict,list)):visit(item,p+'.'+k,child_context)
 visit(form)
 for event,p,contexts in events:
  anchors=[t for t in s.tokens if t['text'].lower()==event.get('anchor','').lower()]
  if len(anchors)!=1:continue
  token=anchors[0]
  if event['predicate'].lower()!=token.get('lemma',token['text']).lower():
   out.append(dict(code='predicate_anchor',path=p+'.predicate',message='Predicate and anchor refer to different source words.',expected_predicate=token.get('lemma',token['text']),anchor=token['text']))
  if quoted(token):continue
  subjects=[t for t in s.children[token['id']]if t['deprel'].startswith('nsubj')and t['upos']in{'NOUN','PROPN','PRON'}]
  if len(subjects)==1:
   subject=subjects[0];matches={eid for eid,e in entities.items()if re.search(r'\b'+re.escape(subject['text'])+r'\b',e['text'],re.I)}
   core=[v for role,v in event.get('arguments',{}).items()if re.fullmatch(r'ARG[0-5A]|nsubj|obj|iobj',role)and isinstance(v,str)]
   if not any(v in matches for v in core)and(matches or subject['upos']in{'NOUN','PROPN'}):
    out.append(dict(code='subject_binding',path=p+'.arguments',message='The overt grammatical subject must be a core participant, not only an adjunct or separate proposition.',source_subject={k:subject.get(k)for k in['id','text','head','deprel']},matching_entities=sorted(matches)))
  purpose=token['deprel']=='advcl'and any(t['deprel']=='mark'and t['lemma'].lower()=='to'for t in s.children[token['id']])and s.by_id.get(token['head'],{}).get('upos')=='VERB'
  if purpose and not contexts:
   out.append(dict(code='purpose_scope',path=p,message='This infinitival adjunct describes a goal of the parent event. Keep it in an attached purpose clause; do not assert it independently.',source_head=s.by_id[token['head']]['text']))
 return out
