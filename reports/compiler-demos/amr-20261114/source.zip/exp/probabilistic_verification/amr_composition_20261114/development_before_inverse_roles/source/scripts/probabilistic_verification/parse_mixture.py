"""Native DeepProbLog inference over a categorical logical-form choice.

Weights are supplied, not learned or claimed to be calibrated. Unparsed mass is
reported separately from insufficient evidence for a known logical form.
"""
import math

def infer(parse_weights,observations,uses,*,unparsed=0.0):
 from deepproblog.model import Model
 from deepproblog.engines import ExactEngine
 from deepproblog.query import Query
 from problog.logic import Term
 if set(parse_weights)!=set(uses):raise ValueError('Each parse needs exactly one observation assignment.')
 values=[*parse_weights.values(),unparsed]
 if any(not math.isfinite(v)or v<0for v in values)or abs(sum(values)-1)>1e-9:raise ValueError('Parse choices and unparsed mass must sum to one.')
 for distribution in observations.values():
  if len(distribution)!=3 or any(not math.isfinite(v)or v<0for v in distribution)or abs(sum(distribution)-1)>1e-9:raise ValueError('Observation states must partition probability mass.')
 if not set(uses.values())<=set(observations):raise ValueError('Missing observation distribution.')
 pids={p:'p'+str(i)for i,p in enumerate(parse_weights)};oids={o:'o'+str(i)for i,o in enumerate(observations)};lines=[]
 choices=[f'{v:.16g}::reading({pids[p]})'for p,v in parse_weights.items()if v>0]
 if unparsed>0:choices.append(f'{unparsed:.16g}::reading(none)')
 lines.append('; '.join(choices)+'.')
 for oid,distribution in observations.items():lines.append('; '.join(f'{v:.16g}::observation({oids[oid]},{state})'for v,state in zip(distribution,['supported','refuted','unknown'])if v>0)+'.')
 for pid,oid in uses.items():lines.append(f'uses({pids[pid]},{oids[oid]}).')
 lines+=['uses(_,_) :- fail.','observation(_,_) :- fail.','answer(Y) :- reading(P), uses(P,O), observation(O,Y).','answer(parsing_abstention) :- reading(none).','any_supported :- observation(O,supported).']
 program='\n'.join(lines)+'\n';model=Model(program,[],load=False);model.set_engine(ExactEngine(model),cache=True);model.eval()
 probabilities={}
 for state in['supported','refuted','unknown','parsing_abstention']:
  query=Query(Term('answer',Term(state)));result=model.solve([query])[0];probabilities[state]=float(result.result.get(query.query,0.))
 query=Query(Term('any_supported'));result=model.solve([query])[0];or_probability=float(result.result.get(query.query,0.))
 if abs(sum(probabilities.values())-1)>1e-9:raise ArithmeticError(probabilities)
 return dict(distribution=probabilities,or_of_observations=or_probability,program=program,weights_supplied=True,learned_parser=False)
