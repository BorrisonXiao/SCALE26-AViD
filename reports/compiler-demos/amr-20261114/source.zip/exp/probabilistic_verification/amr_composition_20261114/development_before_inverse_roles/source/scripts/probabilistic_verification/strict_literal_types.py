"""Discriminated literal types and standard argument roles for neural output.

This is an opt-in decoder/checker schema, not a new language representation.
"""
import copy
from .compiler_feedback import schema

ROLES=[*(f'ARG{i}'for i in range(6)),'ARGA','nsubj','nsubj:pass','obj','iobj','obl','csubj','csubj:pass']
ROLES += [prefix+'ARG'+str(i)for prefix in['C-','R-']for i in range(6)]
ADJUNCTS=['ARGM-'+r for r in['LOC','TMP','MNR','DIR','GOL','CAU','PRP','PNC','ADV','EXT','PRD','DIS','NEG','MOD','COM','REC','ADJ','LVB','DSP']]

def typed_schema(record,form):
 out=schema(record,form)
 event=out['$defs']['node']['anyOf'][0]
 old=event['properties']['arguments']['additionalProperties']
 literal=old['anyOf'][1];variants=[]
 simple=['text','verbatim_text','manner','direction','ordinal','frequency','comparison']
 for kind in simple+['time','date','duration','measurement']:
  fields={'kind':dict(type='string',enum=[kind]),'value':dict(type='string')}
  if kind in{'time','date'}:fields.update(text=dict(type='string'),timezone=dict(type='string'))
  if kind in{'duration','measurement'}:
   fields.update(unit=dict(type='string'),text=dict(type='string'),operator=dict(type='string',enum=['exact','range','more_than','less_than','at_least','at_most','approx']),lower=dict(type='string'),upper=dict(type='string'))
  if kind=='measurement':fields['attribute']=dict(type='string')
  variants.append(dict(type='object',properties=fields,required=['kind','value'],additionalProperties=False))
 value={'$ref':'#/$defs/argument_value'}
 out['$defs']['argument_value']=dict(anyOf=[copy.deepcopy(old['anyOf'][0]),*variants])
 event['properties']['arguments']=dict(type='object',properties={r:copy.deepcopy(value)for r in ROLES+ADJUNCTS},additionalProperties=False)
 event['properties']['adjuncts']['items']['properties']['target']=copy.deepcopy(value)
 event['properties']['adjuncts']['items']['properties']['role']=dict(type='string',enum=ADJUNCTS)
 return out
