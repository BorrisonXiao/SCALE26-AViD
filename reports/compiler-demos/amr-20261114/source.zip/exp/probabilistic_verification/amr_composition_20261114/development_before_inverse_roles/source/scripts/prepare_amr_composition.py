"""Freeze texts and reference readings before running the new AMR converter."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/amr_composition_20261114'
OLD=ROOT/'exp/probabilistic_verification/compiler_structural_20261113'
HUMAN=ROOT/'exp/probabilistic_verification/scope_compilation_20261101/human_responses/1a3a8fd47e72a50f4943.json'
def rows(p):return list(map(json.loads,p.read_text().splitlines()))
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 RUN.mkdir(parents=True,exist_ok=True)
 inputs={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')}
 refs=[]
 for r in json.loads(HUMAN.read_text())['cases']:
  assert r['human_confirmed'] and r['claim']==inputs[r['claim_id']]['text']
  refs.append(dict(claim_id=r['claim_id'],text=r['claim'],origin='human_confirmed_reading',meaning=r['intended_meaning'],relationships=r['participants_and_relations'],source_context=r['source_context'],quantity_and_time=r['quantity_and_time'],ambiguity=r['ambiguity']))
 meanings=[
 'Robot 1 kicks Robot 2 using a sweep kick. Sweep is a kind or manner of kick, not a separate event with Robot 1 as patient.',
 'The robot in lane three finishes second. Lane three identifies its lane; second identifies its finishing position.',
 'The quoted fragment attributes to Sheinbaum the assertion that a movement against our government is promoted from abroad. It does not assert she promoted it or determine speech versus written text.',
 'A 2025 Montreal map depicts a large amount of Liberal red. Keep the year, place, party/color description and depiction source.',
 'A car drives onto the curb with the purpose of getting around both a police car and oncoming traffic. The same car has that purpose; successful evasion is not independently asserted.',
 'Wind speed appears sufficient to force adults to crawl. Wind speed is the causer of force; adults would crawl. Appearance and sufficiency do not establish actual crawling.',
 'An unspecified source claims Trump said Canada is not a real country. Keep both attribution levels and the negated real-country description.',
 'Mare Crisium is a large basin formed by ancient asteroid impact and volcanic eruptions, and filled with basaltic lava about three billion years ago. The attachment of which event filled it is linguistically awkward; do not infer a new actor.',
 'The video depicts an update titled Palisades Incident Operations Update, dated January 12, 2025. The date is the update date, not an inferred date of the fire.',
 'Qian Dan denotes expelling a monk from a monastery for violation of religious vows. This is a definition, not an assertion that a particular expulsion occurred.',
 'Trading partners will consider engagement and retaliation; these countries know that increasing retaliation increases harm to their own economies. Keep future thinking, the whether alternative, comparative dependency, ownership and knowledge scope.',
 'Additional heatmap footage depicts fire growth on January 8, 2025. Growth and its date belong to the depicted content.',
 'The video cuts to Trump speaking without a chart about the disproportionate and unfair numbers. The number descriptions are inside the topic of his talk; without restricts the chart.',
 'The video contains compiled short scenes and images with a broadcaster\'s audio description, also rendered as overlaid text. Audio and text describe the same material; neither channel may be silently dropped.',
 'The map depicts fire spread over the interval from January 6 at 6:00am to January 12 at 12:00am. Do not substitute map creation time for spread time.',
 'A quoted fragment gives Mexico and November 15, with no stated event or year. Keep it as a context-dependent mention, without inventing an occurrence.',
 'Quoted text asserts police fire smoke bombs and tear gas while protesters hurl stones. Keep the concurrent events, each actor, and the quoted source; no channel is specified.',
 'Footage depicts burned debris and cars that are both overturned and burned. Properties must remain attached to the correct objects.',
 'Color-filled areas correspond to locations of atmospheric spin. It is a correspondence/location description, not a person filling something or spin being the color.',
 'The video contains the logo for 7 News.com.au. Preserve the complete identifier and logo/source relationship.',
 'Extremely high winds are visible and blow mist or rain horizontally across the screen. Keep the alternative mist/rain, degree, manner and visible content.',
 'Angupaul1 relies on a portable charger for the purpose of livestreaming. Portable modifies charger; Angupaul1 is the livestreamer. Actual successful livestreaming is not independently asserted.',
 'The video depicts still images of Pete\'s Seafood, a restaurant at Topanga Beach; the restaurant has survived many fires. Preserve the business identity and relative clause.',
 'An image depicts Trump signing something, probably executive orders. Signing is depicted; the identity of the signed object is only likely.',
 'Robot 1 paces up behind the man. The missing space is a typographical issue; preserve Robot 1 and the behind relationship.',
 'A coastal row of homes appears untouched by fire, possibly because a concrete rock wall across the street protected them. Preserve evidential uncertainty and the possible causal explanation.',
 'Firefly said the lander would gradually return to full power when surface temperature dropped. Keep reported future/conditional timing, gradual change and degree; do not assert actual restoration.',
 'The weather is sunny at midday and there are no clouds. Cloud absence is scoped absence, not the existence of a no-cloud object.',
 'The blue-blazer man is presumed to be either a lawyer or a law-enforcement member. Preserve the clothing attachment, uncertainty and OR.',
 'There is little visible spin before the third. The omitted month/year and referent of spin need context; do not invent an event or full date.',
 'The woman asserts that the current time is 7:00 PM on July 21 in Vietnam time. This is her asserted local time, not the system clock or the utterance date.',
 'She reports Trump\'s desire for America to return to a late-19th-century tax/spending system; Rachana calls this a fantasy. Keep desire, historical context, negation and both attributed judgments.',
 'Text at the screen\'s top left identifies the location as Washington, DC. Preserve text/OCR attribution and the top-left position.',
 'A robot slams into a man during a race. Race restricts event time, not event location.',
 'Muted footage depicts Trump speaking in Washington, DC this afternoon. Speaking is visually depicted; audible speech is not established. Afternoon needs a reference date.',
 'Blue Ghost targets approximately 100 kilograms of payload. This is a target amount, not a count of 100 objects or a completed delivery.',
 'Images show engine-plume disturbance on the surface matching a disturbance in landing video when regolith was blown outward. Keep depiction sources, the match and outward motion; exact referents need context.',
 'A protester holds a sign bearing the quoted statement about silencing my voice and awakening all Mexico\'s voice. Keep the statement under written-sign attribution, its negation and figurative wording.',
 'The setting is a dark, calm night with no notable weather. Absence is qualified by notable, not an assertion that no atmospheric conditions exist.',
 'An opinion exemplifies skepticism: the US immigration situation is neither an invasion nor an incursion and does not justify invoking the Alien Enemies Act. Keep opinion scope, both negations and legal-act identity.'
 ]
 selected=rows(OLD/'inputs.jsonl');assert len(selected)==len(meanings)==40
 for r,m in zip(selected,meanings):refs.append(dict(claim_id=r['claim_id'],text=r['text'],origin='assistant_reading_before_converter',meaning=m,ambiguity='See reading; not independent gold.'))
 assert len({r['claim_id']for r in refs})==60
 dump(RUN/'references.json',dict(author='20 earlier human-confirmed readings plus40 assistant readings frozen before converter execution. Prior development and four AMRs were already inspected. No independent or held-out accuracy claim.',source=str(HUMAN.relative_to(ROOT)),source_sha256=hashlib.sha256(HUMAN.read_bytes()).hexdigest(),references=refs))
 dump(RUN/'selection.json',dict(total=60,human=20,previous_failures=40,policy='One cached BART AMR frontend for all claims. No parser selection, rewrite, new model calls, external/GPT review, or automatic promotion into the retained pool.',references_sha256=hashlib.sha256((RUN/'references.json').read_bytes()).hexdigest()))
 dump(RUN/'preserved_archives.json',{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in(ROOT/'site').rglob('*.zip')})
 print('Frozen60 reference readings; no converter outputs inspected in this preparation.')
if __name__=='__main__':main()
