"""Keep unfinished compiler structures for diagnostics, never as accepted claims.

The collector is opt-in and local to the current context. Ordinary compilation
does not change its return values or its error policy.
"""
import copy
from contextvars import ContextVar
from dataclasses import dataclass, field


@dataclass
class PartialParse:
    form: dict | None = None
    stage: str | None = None
    fragments: list = field(default_factory=list)
    links: dict = field(default_factory=dict)
    incomplete_events: list = field(default_factory=list)


_collector = ContextVar("partial_parse_collector", default=None)


def remember_form(form, stage="srl"):
    collector = _collector.get()
    if collector is not None:
        # Later compiler transforms mutate this same form. A snapshot is made
        # only when the outer attempt finishes, including when it raises.
        collector.form = form
        collector.stage = stage


def remember_failure(entities, events, roots, links):
    collector = _collector.get()
    if collector is None:
        return
    def node(state):
        result = copy.deepcopy(state['node'])
        if state['negative']:
            result = dict(op='not', child=result)
        if state['modal']:
            result = dict(op='qualified', operator=state['modal'][1], body=result)
        return result
    available = {fid: node(state) for fid, state in events.items()}
    # An unfinished embedded clause is a fragment, not a world assertion.
    top = [available[fid] for fid in roots if fid in available]
    if top:
        formula = top[0] if len(top) == 1 else dict(op='and', children=top)
        collector.form = dict(version='logical-form-v2', kind='claim',
                              entities=list(entities.values()), formula=formula)
    collector.stage = 'unfinished_srl_graph'
    collector.fragments = [dict(source_id=fid, body=body,
                                complete=events[fid]['complete'])
                           for fid, body in available.items()]
    collector.links = dict(links)
    collector.incomplete_events = [fid for fid, s in events.items() if not s['complete']]


def capture(record):
    """Return a failed attempt's available AST and diagnostics without accepting it."""
    from .compiler_repairs import compile_repaired
    collector = PartialParse()
    token = _collector.set(collector)
    try:
        claim, _ = compile_repaired(copy.deepcopy(record), strict=False)
        collector.form = claim.metadata['logical_form']
        error = None
    except Exception as exc:
        error = dict(code=getattr(exc, 'code', type(exc).__name__), reason=str(exc))
    finally:
        _collector.reset(token)
    return dict(partial_form=copy.deepcopy(collector.form),
                partial_details=dict(stage=collector.stage, error=error,
                                     fragments=copy.deepcopy(collector.fragments),
                                     links=copy.deepcopy(collector.links),
                                     incomplete_events=collector.incomplete_events,
                                     requires_repair=True))
