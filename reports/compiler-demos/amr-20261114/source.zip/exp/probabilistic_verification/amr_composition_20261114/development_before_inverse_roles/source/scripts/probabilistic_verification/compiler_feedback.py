"""Source-constrained logical-form repair and structured compiler diagnostics.

This opt-in path revises a failed parse. It does not change source annotations,
train a parser, or treat compilation as proof of semantic equivalence.
"""
import copy,json,re
from dataclasses import replace
import jsonschema
from .logical_form_schema_v2 import SCHEMA as BASE
from .logical_form_v2 import ScopedCompiler,parse_form
from .logical_form import LogicalFormError
from .semantic_components import normalize_values,valid_alignment,semantic_alerts
from .scope_coverage import audit_content_coverage
from .compilation_checks_v2 import meaning_diagnostics
from .scoped_srl import quoted_spans

SYSTEM='''Repair the claim's logical form so it compiles and preserves the original meaning. The original claim is authoritative; syntax, SRL, AMR and the current form may contain errors. Keep names, modifiers, roles, numbers, tense, negation, uncertainty, quotations and source context. Make the smallest adequate correction. Omit optional fields that do not apply; never invent quantities or event references. If no current form exists, construct it from the supplied annotations.
Return compact JSON without formatting whitespace, matching output_format: action=repair, kind=claim/mention, entities, formula. Use the supplied source IDs. A string argument is a DECLARED entity ID; ordinary values must be typed objects {kind,value}. Each event has its source token ID, lemma predicate, original-word anchor and role-to-value arguments. Do not copy the claim or a clause into a text argument to evade parsing.
Use properties for noun modifiers; entity relations for noun attachments; propositions for embedded clauses. Link every proposition with role, kind, route and body. Keep goals under purpose, uncertainty under qualified, speech/OCR content under its source, and conditions/time clauses attached to the event they constrain. Do not turn these into independent world events. For repeated roles use adjuncts only for ARGM-*; do not discard participants. Each shared entity has one ID. Quotes use verbatim_text and retain their complete words and source_route. AND/OR preserve the original scope and counts. NOT EXISTS negates the existence of entities satisfying its entire body, including modifiers.
Read every diagnostic. On retry, fix the indicated paths/references while retaining the original content. Refuse only when the meaning cannot be represented faithfully: action=refuse, kind=claim, entities=[], formula=null.'''

SYSTEM += '\nWorked format examples (use the actual claim words/IDs in your answer):\n"Maya uses a battery to broadcast." -> {"action":"repair","kind":"claim","entities":[{"id":"x1","text":"Maya","type":"entity"},{"id":"x4","text":"battery","type":"entity"}],"formula":{"op":"event","id":"e2","predicate":"use","anchor":"uses","arguments":{"ARG0":"x1","ARG1":"x4"},"propositions":[{"role":"ARGM-PRP","kind":"purpose","route":"unspecified","body":{"op":"event","id":"e6","predicate":"broadcast","anchor":"broadcast","arguments":{"ARG0":"x1"}}}]}}\n"An image shows a dog running." -> {"action":"repair","kind":"claim","entities":[{"id":"x2","text":"image","type":"entity"},{"id":"x5","text":"dog","type":"entity"}],"formula":{"op":"event","id":"e3","predicate":"show","anchor":"shows","arguments":{"ARG0":"x2"},"propositions":[{"role":"ARG1","kind":"depiction","route":"visual_depiction","body":{"op":"event","id":"e6","predicate":"run","anchor":"running","arguments":{"ARG0":"x5"}}}]}}'


def current_form(row):
    return copy.deepcopy(row.get('proposed_form')or row.get('compilation',{}).get('metadata',{}).get('logical_form'))


def schema(record,candidate=None):
    """Constrain references and predicate vocabulary to this source, not a demo."""
    out=copy.deepcopy(BASE);out['properties'].pop('version');out['required'].remove('version')
    for key in ['status','reason','requires_context','warnings']:out['properties'].pop(key,None)
    out['properties']['action']=dict(type='string',enum=['repair','refuse']);out['required'].append('action')
    entity_ids=sorted({'x'+str(t['id'])for t in record['tokens']}|{e['id']for e in(candidate or{}).get('entities',[])})
    event_ids=['e'+str(t['id'])for t in record['tokens']]
    entity=out['properties']['entities']['items'];entity['properties']['id']=dict(type='string',enum=entity_ids)
    entity['properties'].pop('event_ref',None)
    if not any(t['upos']=='NUM'or t.get('lemma','').lower()in{'all','some','many','most','no','multiple','several','few','each','every'}for t in record['tokens']):entity['properties'].pop('quantity',None)
    entity['properties']['relations']['items']['properties']['target']=dict(type='string',enum=entity_ids)
    entity['properties']['properties']['items']['properties']['value']=dict(type='string')
    node=out['$defs']['node'];event=node['anyOf'][0]
    event['properties']['id']=dict(type='string',enum=event_ids)
    event['properties']['predicate']=dict(type='string',enum=sorted({t.get('lemma',t['text']).lower()for t in record['tokens']if t['upos']not in{'PUNCT','DET','ADP'}}))
    event['properties']['anchor']=dict(type='string',enum=sorted({t['text']for t in record['tokens']}))
    literal=event['properties']['arguments']['additionalProperties']['anyOf'][1]
    literal['properties'].update(operator=dict(type='string'),lower=dict(type='string'),upper=dict(type='string'),attribute=dict(type='string'),text=dict(type='string'),timezone=dict(type='string'))
    event['properties']['arguments']['additionalProperties']['anyOf'][0]=dict(type='string',enum=entity_ids)
    event['properties']['adjuncts']=dict(type='array',items=dict(type='object',properties=dict(role=dict(type='string'),target=dict(anyOf=[dict(type='string',enum=entity_ids),copy.deepcopy(literal)]),preposition=dict(type='string')),required=['role','target','preposition'],additionalProperties=False))
    for proposition in [entity['properties']['propositions']['items'],event['properties']['propositions']['items']]:
        proposition['properties']['kind']['enum']=sorted(set(proposition['properties']['kind']['enum'])|{'complement','relative','sufficiency'})
    node['anyOf'][1]['properties']['ref']=dict(type='string',enum=entity_ids)
    node['anyOf'].append(dict(type='object',properties=dict(op=dict(type='string',enum=['not_exists']),entities=dict(type='array',items=dict(type='string',enum=entity_ids),minItems=1),body={'$ref':'#/$defs/node'}),required=['op','entities','body'],additionalProperties=False))
    out['properties']['formula']=dict(anyOf=[{'$ref':'#/$defs/node'},dict(type='null')])
    return out


def path(parts):return '$'+''.join('['+str(v)+']'if isinstance(v,int)else'.'+str(v)for v in parts)


def reference_errors(form):
    declared={e['id']for e in form.get('entities',[])};errors=[]
    def check(value,p):
        if value not in declared:errors.append(dict(code='unknown_entity',path=path(p),message='Undeclared entity ID '+value,allowed=sorted(declared),repair='Declare a source-grounded entity with this ID, or use the correct existing ID. Literal values must be typed objects.'))
    def visit(node,p=()):
        if isinstance(node,list):
            for i,v in enumerate(node):visit(v,p+(i,))
        elif isinstance(node,dict):
            for role,value in node.get('arguments',{}).items():
                if isinstance(value,str):check(value,p+('arguments',role))
            if node.get('op')=='entity':check(node['ref'],p+('ref',))
            if node.get('op')=='not_exists':
                for i,v in enumerate(node['entities']):check(v,p+('entities',i))
            for i,r in enumerate(node.get('relations',[])):check(r['target'],p+('relations',i,'target'))
            for i,r in enumerate(node.get('adjuncts',[])):
                if isinstance(r['target'],str):check(r['target'],p+('adjuncts',i,'target'))
            for k,v in node.items():
                if isinstance(v,(dict,list)):visit(v,p+(k,))
    visit(form);return errors


def inspect(record,data,output_schema,*,detailed=False,semantic_checks=False):
    """Return native compilation plus actionable, structured failures."""
    from run_scope_coverage_census import compile_one
    issues=[]
    try:
        if isinstance(data,str):data=parse_form(data)
        errors=list(jsonschema.Draft202012Validator(output_schema).iter_errors(data))
        if errors:
            return dict(status='unsupported',code='schema',reason='Response does not match the source-specific schema.'),[dict(code='schema',path=path(e.absolute_path),message=e.message[:600])for e in errors[:12]]
        if data['action']=='refuse':return dict(status='unsupported',code='model_refuse',reason='Model declined a faithful logical form.'),[]
        if data['formula']is None:raise LogicalFormError('empty','Repair needs a non-null formula.')
        form={k:copy.deepcopy(v)for k,v in data.items()if k!='action'};form['version']='logical-form-v2'
        issues=reference_errors(form)
        if semantic_checks:
            from .feedback_semantics import issues as semantic_issues
            issues.extend(semantic_issues(record,form))
        if issues:return dict(status='unsupported',code=issues[0]['code'],reason=issues[0]['message'],proposed_form=form),issues
        preview_alignments=[]
        def compile(r,strict=False):
            notes=[];alignments=[]
            # Preserve evidence that an already-normalized value matches one
            # exact source span, rather than counting canonical spelling as loss.
            from .semantic_components import value_spans
            from .semantic_values import normalized_literal
            spans=value_spans(r)
            def source_values(v):
                if isinstance(v,dict):
                    if v.get('kind')in{'date','time','duration','measurement'}and 'value'in v and not v.get('text'):
                        target={k:item for k,item in v.items()if k!='text'};matches=[]
                        for span in spans:
                            parsed=normalized_literal(span['text'],temporal=v['kind']in{'date','time'})
                            if parsed:
                                parsed.pop('text',None)
                                if parsed==target:matches.append(span)
                        if len(matches)==1:v['text']=matches[0]['text']
                    for item in list(v.values()):source_values(item)
                elif isinstance(v,list):
                    for item in v:source_values(item)
            source_values(form)
            normalize_values(r,form,notes,alignments)
            preview_alignments.extend(alignments)
            claim=ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],form,additional_proposition_kinds=('complement','relative','sufficiency'))
            f=claim.metadata['logical_form'];alignments=[a for a in alignments if valid_alignment(f,a)];coverage=audit_content_coverage(r,f)
            credited={t['id']for a in alignments for t in r['tokens']if a['start']<=t['start_char']and t['end_char']<=a['end']}
            coverage['missing']=[t for t in coverage['missing']if t['id']not in credited];coverage['complete']=not coverage['missing']
            alerts=semantic_alerts(r,f,alignments)
            from .compilation_followup import walk_events
            events=list(walk_events(f));represented={str(e.get('anchor','')).lower()for e in events}
            protected=quoted_spans(r['text'])
            for t in r['tokens']:
                if t['upos']=='VERB'and t['deprel']in{'xcomp','ccomp','acl','acl:relcl','advcl','conj'}and t['text'].lower()not in represented and not any(lo<=t['start_char']<hi for lo,hi,_ in protected):
                    alerts.append(dict(code='missing_clause_event',reason='Represent the attached source verb as an event in its original context: '+t['text']))
            quoted=[]
            def literals(v):
                if isinstance(v,dict):
                    if v.get('kind')=='verbatim_text':quoted.append(v['value'])
                    for item in v.values():literals(item)
                elif isinstance(v,list):
                    for item in v:literals(item)
            literals(f)
            source_verbs={'say','tell','shout','exclaim','write','print','state','report','claim','ask'}
            if any(t.get('lemma','').lower()in source_verbs and not any(lo<=t['start_char']<hi for lo,hi,_ in protected)for t in r['tokens']):
                for lo,hi,text in protected:
                    if text not in quoted:alerts.append(dict(code='quote_omission',reason='Preserve the complete quoted content as verbatim_text: '+text))
            for d in meaning_diagnostics(r,f,claim):
                if d['code']in{'clause_in_entity','long_literal','source_content_missing','qualification_missing','quote_omission'}:
                    alerts.append(dict(code=d['code'],reason=str(d['details'])))
            return replace(claim,metadata=dict(claim.metadata,content_coverage=coverage,structural_alerts=alerts)),notes
        output=compile_one(record,compiler=compile)
        if output['status']!='compiled':
            issues.append(dict(code=output.get('code'),path='$.formula',message=output.get('reason')))
            for t in output.get('coverage',{}).get('missing',[]):issues.append(dict(code='missing_content',path='$.formula',source_token=t,repair='Represent this source word as a predicate, modifier, relation or typed value attached to its original referent. Do not paste the whole clause into a string.'))
            for a in output.get('structural_alerts',[]):issues.append(dict(code=a['code'],path='$.formula',message=a.get('reason',str(a))))
        if detailed and output['status']!='compiled':
            declared={e['id']:e for e in form['entities']};used=set()
            def visit(v):
                if isinstance(v,list):
                    for item in v:visit(item)
                elif isinstance(v,dict):
                    refs=[x for x in v.get('arguments',{}).values()if isinstance(x,str)]
                    refs += [v['ref']]if v.get('op')=='entity'else[]
                    refs += v.get('entities',[])if v.get('op')=='not_exists'else[]
                    refs += [x['target']for x in v.get('adjuncts',[])if isinstance(x.get('target'),str)]
                    refs += [x['target']for x in v.get('relations',[])]
                    for ref in refs:
                        if ref in declared and ref not in used:used.add(ref);visit(declared[ref])
                    for k,item in v.items():
                        if k not in{'arguments','relations','adjuncts'}and isinstance(item,(dict,list)):visit(item)
            visit(form['formula'])
            for i,e in enumerate(form['entities']):
                if e['id']not in used:
                    words=[t for t in record['tokens']if t['text'].lower()in e['text'].lower().split()]
                    issues.append(dict(code='unused_entity',path='$.entities['+str(i)+']',entity=e,source_links=[{k:t.get(k)for k in['id','text','head','deprel']}for t in words],repair='Connect this mention to its correct event or noun relation. If it duplicates words already inside another complete name, remove only the redundant declaration. Preserve every original condition.'))
            coverage=audit_content_coverage(record,form)
            credited={t['id']for a in preview_alignments if valid_alignment(form,a)for t in record['tokens']if a['start']<=t['start_char']and t['end_char']<=a['end']}
            existing={e.get('source_token',{}).get('id')for e in issues}
            for t in coverage['missing']:
                if t['id']not in credited and t['id']not in existing:issues.append(dict(code='missing_content',path='$.formula',source_token=t,repair='This source token is not represented in the current form. Attach its meaning to the correct entity/event; do not merely copy the sentence into a string.'))
        return output,issues
    except Exception as e:
        return dict(status='unsupported',code=getattr(e,'code',type(e).__name__),reason=str(e)),[dict(code=getattr(e,'code',type(e).__name__),path='$',message=str(e))]


OUTPUT_FORMAT={
 'root':'{action:repair/refuse, kind:claim/mention, entities:[entity objects], formula:node}. Refusal uses entities=[] and formula=null.',
 'entity':'{id:xN, text:exact source noun phrase, type:entity/group/pronoun/context/event}. Optional properties:[{role,value}], relations:[{role,target:entity ID}], quantity:{operator,value}, propositions:[embedded clauses]. Omit fields that do not apply.',
 'event':'{op:event,id:eN,predicate:source lemma,anchor:source word,arguments:{role:entity ID or typed literal}}. Optional properties, propositions, adjuncts:[{role:ARGM-*,target:entity ID or typed literal,preposition:source preposition}].',
 'literal':'{kind:text/verbatim_text/date/time/duration/measurement/manner/direction/ordinal/frequency/comparison,value:string}; optional unit,operator,lower,upper,attribute,text,timezone.',
 'nodes':'{op:entity,ref:entity ID}; {op:and/or,children:[nodes]}; {op:not,child:node}; {op:not_exists,entities:[entity IDs],body:node}; {op:qualified,operator:possible/likely/future/obligation/ability/condition/uncertain,body:node}.',
 'proposition':'{role:string,kind:assertion/depiction/question/reason/purpose/belief/condition/temporal/complement/relative/sufficiency,route:unspecified/speech_assertion/ocr_assertion/visual_depiction/audio_event,body:node}.'}

def request(record,direct,output_schema,amr=None,previous=None,feedback=None):
    candidate=current_form(direct)
    if candidate:
        for key in ['version','warnings','status','reason','requires_context']:candidate.pop(key,None)
    data=dict(claim=record['text'],syntax=[{k:t.get(k)for k in['id','text','lemma','upos','head','deprel','feats']}for t in record['tokens']],srl=record.get('srl',{}).get('frames',[]),amr=amr,current_form=candidate,direct_compiler_error={k:direct.get(k)for k in['code','reason']},output_format=OUTPUT_FORMAT)
    if previous is not None:data.update(previous_output=previous,compiler_feedback=feedback)
    return data
