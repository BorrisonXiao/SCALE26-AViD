"""A restricted compositional AMR converter using the existing logic backend.

Concepts and roles are executable conditions, not opaque noun phrases. Explicit
policy entries put non-factual complements in separate contexts. The converter
does not certify the neural parse, resolve general scope, or select a parser.
"""
from __future__ import annotations
from dataclasses import dataclass,field
import re
from .representation import Atom,CompiledClaim,Expression as E,Variable
from .logical_form import bind_variables
from .predicate_compilation import PredicateError,clean_graph,literal
from .semantic import temporal_features

# PropBank senses matter. This is an explicit supported fragment, not a claim
# that every ARG1 is asserted content or every ARG0 is a human agent.
COMPLEMENTS={
 'say-01':{'ARG1':'assertion'},'claim-01':{'ARG1':'assertion'},
 'report-01':{'ARG1':'assertion'},'tell-01':{'ARG2':'assertion'},
 'ask-01':{'ARG1':'question'},'believe-01':{'ARG1':'belief'},
 'think-01':{'ARG1':'belief'},'want-01':{'ARG1':'desire'},
 'hope-01':{'ARG1':'desire'},'plan-01':{'ARG1':'plan'},
 'intend-01':{'ARG1':'intention'},'try-01':{'ARG1':'attempt'},
 'appear-02':{'ARG1':'appearance'},'seem-01':{'ARG1':'appearance'},
 'suffice-01':{'ARG1':'sufficiency'},'possible-01':{'ARG1':'possibility'},
 'obligate-01':{'ARG2':'obligation'},'recommend-01':{'ARG1':'recommendation'},
 'force-01':{'ARG2':'result'},'rely-01':{'ARG2':'purpose'},
 'see-01':{'ARG1':'perception'},'hear-01':{'ARG1':'perception'},
 'start-01':{'ARG1':'aspect'},'begin-01':{'ARG1':'aspect'},
}
ASSERTED={'cause-01','cause-02','create-01','affect-01','destroy-01'}
SCOPED_ROLES={'purpose':'purpose','condition':'condition','concession':'concession'}
MEDIA={'image','photo','photograph','video','footage','imagery','still','timelapse','time-lapse','map','diagram','chart','drawing','picture','portrait'}
WRITTEN={'text','sign','caption','overlay','headline'}
EVENT=re.compile(r'-\d\d$')

@dataclass(frozen=True)
class AMRClaim(CompiledClaim):
 version:str='amr-composition-v1'
 metadata:dict=field(default_factory=dict)

class AMRCompiler:
 def compile(self,claim_id,text,graph_text,tokens=()):
  import penman
  from penman.models.amr import model
  def fail(code,message):raise PredicateError(code,message)
  try:
   graphs=list(penman.iterparse(clean_graph(graph_text)))
   if len(graphs)!=1:fail('graph_count','Expected one graph.')
   tree=graphs[0];graph=penman.decode(penman.format(tree),model=model)
  except PredicateError:raise
  except Exception as e:fail('graph_syntax',str(e))
  declarations={}
  def index(node):
   n,bs=node
   if n in declarations:fail('duplicate_node','Repeated AMR declaration: '+n)
   declarations[n]=bs
   for _,t in bs:
    if isinstance(t,tuple):index(t)
  index(tree.node)
  concepts={n:next((str(t)for r,t in bs if r=='/'),None)for n,bs in declarations.items()}
  if any(v is None for v in concepts.values()):fail('missing_concept','Every node needs a concept.')
  if len(concepts)>250:fail('graph_size','More than250 concepts.')
  original={n:[(r[1:],t[0]if isinstance(t,tuple)else str(t))for r,t in bs if r!='/']for n,bs in declarations.items()}
  edges={n:[]for n in concepts};origins={}
  for n,rs in original.items():
   for r,t in rs:
    s,role,target=model.deinvert((n,':'+r,t))if t in concepts else(n,':'+r,t)
    key=(s,role[1:],target);edges[s].append((role[1:],target));origins.setdefault(key,[]).append((n,r,t))
  for n,rs in edges.items():
   roles=[r for r,_ in rs if re.fullmatch(r'ARG\d',r)]
   if len(roles)!=len(set(roles)):fail('duplicate_roles','Repeated core role at '+n)
   if concepts[n]=='amr-unknown' or any(r=='mode'and t in {'interrogative','imperative'}for r,t in rs):fail('sentence_mode','Question/imperative interpretation is not implemented.')
   if any(r=='quant'and literal(t)in{'all','every','each','most'}for r,t in rs):fail('quantifier_scope','Generalized quantifier scope is not implemented.')
  atoms=[];variables=[];cache={};seen={};translations=[];scopes={};node_vars={};temporal={};warnings=[];walk=[]
  def var(n):
   if n not in node_vars:
    v=('E'if EVENT.search(concepts[n])else'X')+str(len(node_vars)+1);node_vars[n]=v
    variables.append(Variable(v,'event'if EVENT.search(concepts[n])else'entity',concepts[n],()))
   return node_vars[n]
  def atom(pred,args,scope,route,kind='relation',trainable=True):
   # A context label alone cannot identify whose assertion/belief is checked.
   # Carry every owning event/entity so grounding conditions on its assignment.
   owners=[];context=scope
   while context!='world':
    owners +=['context_owner',var(scopes[context]['owner'])]
    context=scopes[context]['parent']
   args=tuple(map(str,args))+tuple(owners)+('scope',scope,'route',route);key=(pred,args)
   if key not in cache:
    a=Atom('a'+str(len(atoms)+1),pred,args,kind,(),pred,(),trainable);atoms.append(a);cache[key]=a.id
   return E.atom(cache[key])
  def mark(n,r,t,scope,how):
   for s,k,v in ([(n,r,t)]if r=='instance'else origins[(n,r,t)]):
    translations.append(dict(source=s,role=k,target=v,scope=scope,translation=how))
  def is_event(n):return n in concepts and bool(EVENT.search(concepts[n]))
  def source_matches(n):
   stem=re.sub(r'-\d\d$','',concepts[n])
   return[t for t in tokens if t.get('lemma','').casefold()==stem]
  def nominal(n):
   # PropBank predicates also describe nouns. A sense suffix alone does not
   # turn "promote a movement" into a clause-valued complement.
   ts=source_matches(n)
   return bool(ts)and all(t.get('upos')in{'NOUN','PROPN'}for t in ts)
  def route_for(n,kind):
   if kind=='depiction':return 'visual_depiction'
   if concepts[n]=='see-01':return 'visual_depiction'
   if concepts[n]=='hear-01':return 'audio_event'
   actor=next((t for r,t in edges[n]if r=='ARG0'),None)
   if actor in concepts and concepts[actor]in WRITTEN:return 'ocr_assertion'
   return 'unspecified'
  def boundary(n,r,t):
   if r in SCOPED_ROLES:return SCOPED_ROLES[r]
   p=concepts[n]
   if p in MEDIA and r=='topic'and t in concepts:return 'depiction'
   if p in {'show-01','depict-01','display-01'}and r=='ARG1':
    actor=next((v for k,v in edges[n]if k=='ARG0'),None)
    if actor in concepts and concepts[actor]in MEDIA:return 'depiction'
   return COMPLEMENTS.get(p,{}).get(r)
  def name_value(n):
   rs=edges[n]
   if concepts[n]!='name'or any(not re.fullmatch(r'op\d+',r)for r,_ in rs):fail('name_structure','Unexpected name graph.')
   return ' '.join(literal(t)for r,t in sorted(rs,key=lambda z:int(z[0][2:])))
  def visit(n,scope='world',route='unspecified',*,position='formula'):
   if n not in concepts:fail('unresolved_reference','Undeclared node: '+n)
   if n in seen:
    if seen[n]!=scope and is_event(n):fail('event_scope_reentry','An event is referenced from two contexts: '+n)
    if seen[n]!=scope:return atom('reference',[var(n)],scope,route,'reference',False)
    return E.constant('supported')
   seen[n]=scope;walk.append(n);p=concepts[n];rs=edges[n]
   if p in {'and','or','multi-sentence'}:
    if position=='argument':fail('argument_coordination','Coordinated participants need a group/distributive interpretation, not clause conjunction.')
    pattern=r'snt\d+'if p=='multi-sentence'else r'op\d+'
    if any(not re.fullmatch(pattern,r)and r!='wiki'for r,_ in rs):fail('coordination_scope','An annotated coordination needs explicit scope.')
    members=[(r,t)for r,t in rs if re.fullmatch(pattern,r)]
    if len(members)<2:fail('coordination_size','Coordination needs at least two members.')
    mark(n,'instance',p,scope,'logical_operator')
    children=[]
    for r,t in members:
     mark(n,r,t,scope,'logical_branch');children.append(visit(t,scope,route))
    walk.pop();return E.combine('or'if p=='or'else'and',children)
   x=var(n);conditions=[atom('concept',[x,p],scope,route,'entity',False)];mark(n,'instance',p,scope,'concept')
   # Process ordinary participants before scoped complements, independent of
   # where PENMAN first declares a shared actor or its name.
   for r,t in sorted(rs,key=lambda z:bool(boundary(n,*z))):
    if r=='wiki':mark(n,r,t,scope,'provenance_only');continue
    if r=='polarity':
     if t!='-':fail('polarity_value','Unsupported polarity value: '+t)
     mark(n,r,t,scope,'negation');continue
    if r=='name'and t in concepts:
     value=name_value(t)
     conditions.append(atom('name',[x,value],scope,route,'property',False));mark(n,r,t,scope,'name')
     if t not in seen:
      seen[t]=scope;mark(t,'instance',concepts[t],scope,'name')
      for k,v in edges[t]:mark(t,k,v,scope,'name')
     continue
    kind=boundary(n,r,t)
    if p in MEDIA|WRITTEN and r=='mod'and is_event(t):
     fail('media_modifier_scope','A predicative media modifier needs attribute-versus-content interpretation.')
    if kind:
     if t not in concepts:fail('literal_complement','A source/context complement must be a graph, not an opaque text literal.')
     if r.endswith('-of'):fail('inverse_scope','An inverse scoped relationship needs explicit projection.')
     c='c'+str(len(scopes)+1);cr=route_for(n,kind)
     scopes[c]=dict(parent=scope,owner=n,role=r,kind=kind,route=cr,target=t)
     conditions +=[atom('proposition',[x,r,kind,c],scope,route,'scope'),visit(t,c,cr)]
     mark(n,r,t,scope,'proposition');continue
    if t in concepts:
     if ('polarity','-')in edges[t]:fail('negative_argument_scope','A negated argument needs scope projection over its governing relation.')
     if is_event(t)and not nominal(t)and re.fullmatch(r'ARG\d',r)and p not in ASSERTED:
      fail('unhandled_complement','No scope policy for '+p+' :'+r+' '+concepts[t])
     if t not in seen:conditions.append(visit(t,scope,route,position='argument'))
     elif is_event(t)and seen[t]!=scope:fail('event_scope_reentry','Cross-context event argument: '+t)
     # PENMAN's model distinguishes inverse roles from names such as consist-of.
     s,role,target=model.deinvert((n,':'+r,t))
     conditions.append(atom('role',[var(s),role[1:],var(target)],scope,route))
     mark(n,r,t,scope,'role')
    else:
     if re.fullmatch(r'ARG\d(?:-of)?',r)and not(t.startswith('"')or re.fullmatch(r'[-+]?\d+(?:\.\d+)?',t)):
      fail('unresolved_reference','A core argument names an undeclared node: '+t)
     pred='quantity'if r=='quant'else'literal'
     conditions.append(atom(pred,[x,r,literal(t)],scope,route,'quantity'if r=='quant'else'property',r!='quant'))
     mark(n,r,t,scope,pred)
   # An inverse edge is surface notation. Its condition was emitted by the
   # canonical source above, so a negated predicate keeps all its own roles
   # inside NOT. Expand its relative predicate here without another role atom.
   for r,t in original[n]:
    if t in concepts and model.deinvert((n,':'+r,t))[0]==t and t not in seen:
     conditions.append(visit(t,scope,route,position='relative'))
   if is_event(n):
    matches=source_matches(n)
    if len(matches)==1:
     tf=temporal_features(tokens,matches[0]['id']);temporal[x]=tf
     if tf['tense']!='unspecified'or tf['aspect']!='simple':
      if not any(v.name=='T0'for v in variables):variables.append(Variable('T0','context','Reference time supplied by caller',()))
      conditions.append(atom('temporal',[x,tf['tense'],tf['aspect'],'T0'],scope,route,'temporal',False))
    elif any('Tense='in(t.get('feats')or'')for t in tokens):warnings.append('No unique source tense/aspect alignment for '+n+' / '+p)
   result=E.combine('and',conditions)
   if ('polarity','-')in rs:
    # Default AMR subtree scope, not a general presupposition/projection solver.
    names={v.name for v in variables};ids={a.id:a for a in atoms}
    def used(e):return(set(ids[e.atom_id].arguments)&names)if e.op=='atom'else set().union(*(used(c)for c in e.children))
    local=used(result)-{var(z)for z in walk[:-1]}
    result=E.negate(E.exists(sorted(local),result));warnings.append('Negation uses local AMR subtree scope; source quantifier/projection review remains necessary.')
   walk.pop();return result
  expression=visit(tree.node[0])
  if set(seen)!=set(concepts):fail('untranslated_nodes','Not all AMR nodes were visited.')
  expected={(n,'instance',c)for n,c in concepts.items()}|{(n,r,t)for n,rs in original.items()for r,t in rs}
  actual={(x['source'],x['role'],x['target'])for x in translations}
  if expected!=actual:fail('untranslated_edges','Some graph conditions have no translation.')
  expression=bind_variables(expression,atoms,variables)
  metadata=dict(amr=graph_text,concepts=concepts,edges=edges,node_variables=node_vars,node_scopes=seen,scopes=scopes,temporal=temporal,translations=translations,
   compiler_fragment='Concepts, explicit roles/literals/names, clause AND/OR, local AMR negation and declared proposition policies. Argument coordination and general quantifier/projection scope refuse.',
   evidence_functions='Concept/name/quantity/time functions and media-conditioned role/context functions are required; no new media function is implemented.',
   source_faithfulness='Not certified. Neural AMR omissions, invented roles, tense alignment and scope require separate review.',
   allowed_routes={a.id:[a.arguments[-1]]for a in atoms})
  return AMRClaim(str(claim_id),text,tuple(tokens),tuple(variables),tuple(atoms),expression,(),tuple(dict.fromkeys(warnings)),metadata=metadata)
