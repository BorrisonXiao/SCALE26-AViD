"""Source exclusion and report boundaries under the active fallback compiler."""
import json
from pathlib import Path

import pytest

from probabilistic_verification.compiler_fallback import check_output, restore
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.disjunction_semantics import explicit_exclusion
from probabilistic_verification.fallback_amr import compile_fallback_amr, prepare_fallback
from probabilistic_verification.logic import Evidence, ground
from run_amr_types import inspect


@pytest.fixture(scope='module')
def inputs():
    root = Path(__file__).resolve().parents[1]
    folder = root / 'exp/probabilistic_verification/disjunction_evaluation_20261119/benchmark'
    source = {r['claim_id']: dict(r['clauses'][0]['record'], claim_id=r['claim_id'])
              for r in map(json.loads, (folder / 'parsed.jsonl').read_text().splitlines())}
    graphs = {r['request']['task']['claim_id']: r['raw']
              for r in map(json.loads, (folder / 'amr.jsonl').read_text().splitlines())}
    return source, graphs


def test_explicit_exclusion_ignores_quotes_and_unrelated_exact_quantities():
    assert explicit_exclusion('The sign says “Exactly one of these doors is open.”') is None
    assert explicit_exclusion('The drawing has exactly one boat.') is None
    assert explicit_exclusion('Either door was open.') is None
    assert explicit_exclusion('A or B, but not both.')[0] == 'but not both'
    assert explicit_exclusion('A or B, but not both, at noon.')[0] == 'embedded exclusion'


@pytest.mark.parametrize('cid', ['or_exclusion_1','or_exclusion_2','or_exclusion_3'])
def test_explicit_exclusion_has_a_shared_outer_binding(inputs, cid):
    source, _ = inputs
    output = check_output(source[cid], compile_one(source[cid]))
    assert output['status'] == 'compiled'
    claim = restore(output['compilation'])
    assert claim.metadata['exclusion']
    assert claim.expression.op == 'exists'
    def walk(node):
        yield node
        for child in node.children:
            yield from walk(child)
    inverse = [c for c in walk(claim.expression) if c.op == 'not']
    assert len(inverse) == 1 and inverse[0].children[0].op == 'and'
    if cid == 'or_exclusion_2':
        events = [a for a in claim.atoms if a.predicate == 'show']
        assert len(events) == 2
        assert len({a.arguments[a.arguments.index('ARGM-TMP')+1] for a in events}) == 1


def test_named_pair_binds_distinct_candidates(inputs):
    source, _ = inputs
    claim = restore(compile_one(source['or_exclusion_3'])['compilation'])
    domains = {'X1':['the same candidate'], 'X2':['the same candidate'], 'T0':['shared time']}
    program = ground(claim, Evidence('probe', domains, dict.fromkeys(domains,True), {}))
    assert program.expression.children[0].state == 'refuted'


def test_report_body_becomes_full_content_evidence(inputs):
    source, graphs = inputs
    record = source['or_report_1']
    raw = inspect(record, graphs['or_report_1'], compiler=compile_fallback_amr, prepare=prepare_fallback)
    output = check_output(record, raw)
    claim = restore(output['compilation'])
    report = [a for a in claim.atoms if a.predicate == 'reported_disjunction']
    assert len(report) == 1
    assert claim.metadata['allowed_routes'][report[0].id] == ['speech_assertion']
    assert not any(a.predicate=='concept' and a.arguments[1]=='close-01' for a in claim.atoms)
    assert claim.metadata['reported_disjunctions'][0]['logical_form']
    assert check_output(record, output)['program_sha256'] == output['program_sha256']


def test_top_level_or_between_reports_stays_an_or(inputs):
    source, graphs = inputs
    record = source['or_report_4']
    raw = inspect(record, graphs['or_report_4'], compiler=compile_fallback_amr, prepare=prepare_fallback)
    output = check_output(record, raw)
    assert ' OR ' in output['compilation']['logical_form']
    assert 'reported_disjunction' not in output['compilation']['logical_form']
