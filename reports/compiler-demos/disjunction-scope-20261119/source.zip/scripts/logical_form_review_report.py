"""Render the text-to-logical-form benchmark review inside the compiler report."""
import json
from html import escape
from shutil import copy2

from compiler_fallback_report import table
from sample_logical_form_review import ROOT, RUN

URL = 'compiler-demos/logical-form-review-20261118/'
VERDICTS = {'matches_reference': 'Full match', 'partial': 'Partial',
            'incorrect': 'Incorrect', 'needs_context': 'Needs context'}
DOWNLOADS = ['summary.json', 'sample.json', 'warnings_frozen.json',
             'benchmark.json', 'warning_queue.json', 'tests.xml']


def load(name):
    return json.loads((RUN / name).read_text())


def status_html():
    s = load('summary.json')
    return (f'<b>{s["total"]} saved logical forms reviewed across {s["source_groups"]} source videos.</b> '
            'The review checks whether the compiled predicates preserve the meaning of the claim.')


def overview_html():
    s = load('summary.json')
    buckets = s['by_bucket']
    groups = [('Strict SRL pass', buckets['strict_srl']), ('Provisional program', buckets['provisional']),
              ('Total', s['judgments'])]
    rows = [(name, sum(counts.values()), *(counts.get(key, 0) for key in VERDICTS))
            for name, counts in groups]
    counts_table = table('Meaning review of saved programs. The sample favors diverse sources and selected constructions.',
                         ['Program group', 'Reviewed', *VERDICTS.values()], rows)
    return (
        '<h2 id="remaining-failures">Logical-form benchmark review</h2>'
        '<p>We sampled new claims after excluding earlier reviewed IDs and repeated text. '
        'The strict sample covers names, quantities, qualifiers, source scope and coordination, '
        'with six general cases. The provisional sample covers advisory checks and '
        'unresolved AMR structures. These judgments come from an assistant development review.</p>'
        + counts_table
        + '<p>A full match preserves the required participants, relations and qualifiers. '
        'A partial form retains the main reading with a missing or under-specified condition. '
        'An incorrect form materially changes the reading. Two claims need context to settle the intended reading. '
        'The selected sample supports error analysis. Corpus-wide accuracy and media support require separate evaluation.</p>'
        '<p>Numeric bindings and units account for eight primary issues. Participant bindings account for six, '
        'and missing qualification accounts for five. A qualification tells us how to read the '
        'proposition, for example as likely, reported or inferred.</p>'
        '<h3 id="benchmark-warnings">Advisory checks</h3>'
        '<p>The checks look for missing name components or handles, numeric values with their units and range bounds, '
        'explicit alternatives and missing qualifiers. They flagged seven sampled programs. '
        'Inspection confirmed the named issue in each one, including six strict SRL passes. '
        'The rules were developed during this audit, so this comparison measures their behavior on development cases.</p>'
        f'<p>The same rules flagged {s["flagged_corpus_programs"]} of {s["checked_corpus_programs"]:,} '
        'saved programs for follow-up. Those flags are review leads. Program generation covers '
        '2,358 of all 2,375 claims, with 17 dependency analyses. Warnings leave the compiler output and routing intact.</p>'
        '<h3>Benchmark and feature design</h3>'
        '<p>The reviewed logical forms and the five frame-based binding pairs are reserved for evaluation development. '
        'The binding pairs test whether the same video frames support different assignments of the same words. '
        'For a later feature comparison, use uniform frame sampling as a baseline, then compare keyframe selection '
        'for long clips and attention scores where the frozen model exposes them. '
        'Use time-local audio and speaker-aligned transcript spans for speech and sound. '
        'Keep the selected evidence fixed across both versions of each pair. '
        'Plan source-disjoint training data separately. These feature choices are proposals.</p>'
        '<p><a href="#logical-form-benchmark">Read all 60 claims and exact forms</a> · '
        '<a href="#binding-contrasts">Inspect the five binding pairs</a> · '
        '<a href="#earlier-scope-repair">Earlier scope repairs</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}benchmark.json">Benchmark records</a> · '
        f'<a href="{URL}warning_queue.json">{s["flagged_corpus_programs"]} flagged programs</a> · '
        f'<a href="{URL}summary.json">Review counts</a> · '
        f'<a href="{URL}source.zip">Source and replay</a> · <a href="{URL}tests.xml">Tests</a></p>'
    )


def examples_html():
    records = load('benchmark.json')['records']
    cases = []
    for record in records:
        claim, reading, reason = (escape(record[key]) for key in ('text', 'reading', 'reason'))
        verdict = VERDICTS[record['judgment']]
        route = 'Strict SRL' if record['bucket'] == 'strict_srl' else 'Provisional'
        issue = record['issue']
        result = f'<strong>{verdict}</strong>' + (f' · {escape(issue)}' if issue != 'none' else '')
        alert = record['alert_review']
        warning = f'<p><strong>New warning.</strong> {escape(alert)}</p>' if alert else ''
        form = escape(record['compilation']['logical_form'])
        cid = escape(record['claim_id'])
        cases.append(
            f'<article class="box benchmark-case" id="benchmark-{cid}">'
            f'<h3>{result}</h3><p class="muted">{route} · {cid}</p><blockquote>{claim}</blockquote>'
            f'<p><strong>Reference reading.</strong> {reading}</p>'
            f'<p><strong>Finding.</strong> {reason}</p>{warning}'
            f'<details><summary>Exact logical form and program</summary><pre>{form}</pre>'
            f'<pre>{escape(record["program"])}</pre></details></article>'
        )
    return (
        '<section id="logical-form-benchmark"><h2>All 60 logical-form reviews</h2>'
        '<p>Read each source claim beside its intended meaning and the finding. '
        'Expand a case to see the saved formula and Prolog program. The program is the compiler output under review. '
        'Media evidence was outside this review.</p><div class="benchmark-cases">'
        + ''.join(cases) + '</div></section>'
    )


def write_downloads():
    target = ROOT / 'site/reports' / URL
    target.mkdir(parents=True, exist_ok=True)
    for name in DOWNLOADS:
        copy2(RUN / name, target / name)
    copy2(ROOT / 'docs/logical_form_review_20261118.md', target / 'README.md')
