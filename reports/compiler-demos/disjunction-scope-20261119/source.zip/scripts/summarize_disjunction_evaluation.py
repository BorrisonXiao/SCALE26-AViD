"""Join the frozen evaluation readings, exact traces, and human-readable findings."""
from collections import Counter, defaultdict
import hashlib
import json

from generate_disjunction_rewrites import RUN
from prepare_compiler_fallback import dump
from probabilistic_verification.split_composition import nodes


def load(path):
    return json.loads((RUN / path).read_text())


def main():
    benchmarks = load('benchmark/compilation.json')
    reviews = load('benchmark/reviews.json')
    provenance = load('benchmark/dependency_provenance.json')
    assert hashlib.sha256((RUN / 'benchmark/references.json').read_bytes()).hexdigest() == provenance['reference_sha256']
    assert {r['claim_id'] for r in benchmarks} == reviews.keys()
    benchmark_stats = defaultdict(Counter)
    for row in benchmarks:
        row.update(reviews[row['claim_id']])
        stat = benchmark_stats[row['category']]
        stat[row['judgment']] += 1
        passed = bool(row['fixed']['output'])
        assert passed == (row['judgment'] != 'no_program')
        stat['auto_pass'] += passed
        stat['total'] += 1

    rewrites = load('rewrite/compilation.json')
    reviews = load('rewrite/reviews.json')
    assert {r['claim_id'] for r in rewrites} == reviews.keys()
    for row in rewrites:
        row['finding'] = reviews[row['claim_id']]
        response = json.loads(row['response']['raw'])
        row['model_proposal'] = response
        row['emitted_or'] = any(n.get('op') == 'or' for n in nodes(response['formula']))
        row['strict_pass'] = bool(row['result']['output'])
    config = load('model_config.json')
    assert hashlib.sha256((RUN / 'requests.json').read_bytes()).hexdigest() == config['requests_sha256']
    assert hashlib.sha256(config['system_prompt'].encode()).hexdigest() == config['prompt_sha256']
    stats = dict(rewrites=len(rewrites), explicit_or=sum(r['emitted_or'] for r in rewrites),
                 rewrite_passes=sum(r['strict_pass'] for r in rewrites),
                 rewrite_stops=dict(Counter(r['result']['attempts'][-1].get('code', 'compiled')
                                            for r in rewrites)),
                 benchmark=dict(benchmark_stats), total_benchmark=sum(benchmark_stats.values(), Counter()),
                 native_reference_controls=len(load('native_controls.json')),
                 native_compiled_controls=len(load('compiled_controls.json')),
                 generation=load('generation.json'), resources=load('resources.json'))
    dump(RUN / 'summary.json', stats)
    dump(RUN / 'evaluation.json', dict(stats=stats, benchmarks=benchmarks, rewrites=rewrites,
                                      reference_controls=load('native_controls.json'),
                                      compiled_controls=load('compiled_controls.json')))
    print(json.dumps(stats, indent=2))


if __name__ == '__main__':
    main()
