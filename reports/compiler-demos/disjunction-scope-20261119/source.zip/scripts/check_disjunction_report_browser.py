"""Verify the OR report and the earlier views on desktop and mobile."""
from functools import partial
from http.server import ThreadingHTTPServer
import threading

from playwright.sync_api import sync_playwright
from check_compiler_scope_browser import QuietHandler
from disjunction_repairs_report import ROOT, RUN


def main():
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=ROOT / 'site'))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f'http://127.0.0.1:{server.server_port}/reports/'
    try:
        with sync_playwright() as driver:
            browser = driver.chromium.launch(args=['--no-sandbox'])
            page = browser.new_page(viewport={'width': 1360, 'height': 920})
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto(base + 'compiler-demos.html#remaining-failures', wait_until='networkidle')
            assert page.get_by_role('tab').count() == 5
            assert '2,178 / 2,375' in page.locator('#current-work').inner_text()
            page.get_by_role('link', name='Pier and terminal example').click()
            demo = page.locator('#parallel-or-demo')
            demo.wait_for(state='visible')
            assert demo.locator('tbody tr').count() == 8
            demo.locator('summary').click()
            assert 'be-located-at-91' in demo.locator('pre').nth(1).inner_text()
            assert 'query(' in demo.locator('pre').nth(2).inner_text()

            page.goto(base + 'compiler-demos.html#benchmark-warnings', wait_until='networkidle')
            assert page.locator('#history').is_visible()
            page.goto(base + 'compiler-demos.html#logical-form-benchmark', wait_until='networkidle')
            assert page.locator('.benchmark-case').count() == 60
            page.goto(base + 'compiler-demos.html#daily-progress', wait_until='networkidle')
            assert '2026-11-19' in page.locator('#daily-progress').inner_text()
            page.goto(base + 'verification-pipeline.html#next-steps', wait_until='networkidle')
            assert 'Preserve explicit alternatives' in page.locator('#next-steps').inner_text()
            page.goto(base, wait_until='networkidle')
            assert page.locator('.card-link').count() == 2

            page.set_viewport_size({'width': 390, 'height': 844})
            page.emulate_media(color_scheme='dark')
            for section in ('remaining-failures', 'parallel-or-demo', 'rewrite-or-control'):
                page.goto(base + 'compiler-demos.html#' + section, wait_until='networkidle')
                assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'), section
            page.goto(base + 'compiler-demos.html#parallel-or-demo', wait_until='networkidle')
            page.screenshot(path=str(RUN / 'or-report-mobile.png'))
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()
    print('OR report, eight controls, prior review and mobile view passed.')


if __name__ == '__main__':
    main()
