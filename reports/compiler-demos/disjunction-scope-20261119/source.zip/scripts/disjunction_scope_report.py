"""Render the OR scope repairs and the paired evaluation."""
from collections import Counter
from html import escape
import json
from shutil import copy2

from compiler_fallback_report import table
from evaluate_disjunction_scope import EVALUATION, ROOT, RUN
from prepare_compiler_fallback import dump

URL = 'compiler-demos/disjunction-scope-20261119/'
LABELS = {'matches_reference': 'Full match', 'partial': 'Partial', 'incorrect': 'Incorrect',
          'no_program': 'No program'}


def read(path, root=RUN):
    return json.loads((root / path).read_text())


def summarize():
    cases = read('benchmark.json')
    before = read('benchmark/reviews.json', EVALUATION)
    reviews = read('reviews.json')
    assert {c['claim_id'] for c in cases} == before.keys() == reviews.keys()
    for case in cases:
        cid = case['claim_id']
        case['previous_judgment'] = before[cid]['judgment']
        case['judgment'], case['finding'] = reviews[cid]
        assert (case['judgment'] != 'no_program') == bool(case['fixed']['output'])
    previous = dict(Counter(c['previous_judgment'] for c in cases))
    current = dict(Counter(c['judgment'] for c in cases))
    summary = dict(total=len(cases), previous=previous, current=current,
                   native=len(read('native.json')), corpus=read('comparison.json')['counts'])
    dump(RUN / 'evaluation.json', dict(summary=summary, cases=cases, controls=read('native.json'),
                                      shared=read('shared_control.json'), corpus=read('comparison.json')))


def status_html():
    s = read('evaluation.json')['summary']
    return (f'<b>All {s["total"]} evaluation claims now compile. '
            f'{s["current"]["matches_reference"]} match their reference readings.</b> '
            'The repairs cover explicit exclusion, shared conditions, and the full content of reports.')


def overview_html():
    s = read('evaluation.json')['summary']
    c = s['corpus']
    rows = [(label, *(v.get(key, 0) for key in LABELS))
            for label, v in [('Before', s['previous']), ('After', s['current'])]]
    return (
        '<h2 id="remaining-failures">Exclusion, shared conditions, and reported OR</h2>'
        '<p>The same twelve authored claims were used to develop and check the repairs. '
        'The two remaining partial matches concern the reference of “it” and the time of a state inside a report.</p>'
        + table('Meaning review against the same frozen reference readings.',
                ['Version', *LABELS.values()], rows)
        + f'<p>The {c["before"]:,} earlier corpus programs are byte-identical. '
        f'Automatic passes rise from {c["before"]:,} to {c["after"]:,} of 2,375. '
        'The new pass keeps “for stability” as the purpose of crouching or sitting. '
        'The strong-wind rewrite is still refused because the source parse leaves the subject of “carrying” unresolved.</p>'
        f'<p>All {s["native"]} exact inference controls on compiled programs passed. '
        'The speech condition uses supplied observations for an utterance that expresses the full OR. '
        'The report preserves the parsed content so the condition can later be connected to transcript evidence.</p>'
        '<p><a href="#or-scope-cases">All twelve cases</a> · <a href="#or-shared-context">Shared-condition rewrite</a> · '
        '<a href="#or-scope-controls">Evidence controls</a> · <a href="#earlier-or-evaluation">Previous evaluation</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}evaluation.json">Exact outputs and controls</a> · '
        f'<a href="{URL}source.zip">Source and replay</a> · <a href="{URL}tests.xml">Tests</a></p>'
    )


def examples_html():
    result = read('evaluation.json')
    cards = []
    for case in result['cases']:
        output = case['fixed']['output']
        form = output['compilation']['logical_form']
        source = f'<p class="muted">Selected parser {case["fixed"]["selected_stage"].upper()}</p>'
        cards.append(
            f'<article class="box benchmark-case" id="scope-{escape(case["claim_id"])}">'
            f'<h3>{escape(case["category"])} · {LABELS[case["previous_judgment"]]} to {LABELS[case["judgment"]]}</h3>'
            f'<blockquote>{escape(case["text"])}</blockquote>{source}'
            f'<p><strong>Reference reading.</strong> {escape(case["reference"])}</p>'
            f'<p><strong>Finding.</strong> {escape(case["finding"])}</p>'
            f'<details><summary>Exact logical form and program</summary><pre>{escape(form)}</pre>'
            f'<pre>{escape(output["program"])}</pre></details></article>'
        )
    shared = result['shared']
    sentences = ''.join(f'<li>{escape(c)}</li>' for c in shared['rewritten']['sentences'])
    program = shared['result']['output']
    recovered = result['corpus']['changes'][0]
    wind = next(c for c in result['corpus']['rewrite_cases'] if c['claim_id']=='Txf2EdqOg1SQ_2289')
    selected = [r for r in result['controls'] if r['claim_id'] in
                {'or_exclusion_3','or_report_1','or_shared_relative'}]
    return (
        '<section id="or-scope-cases"><h2>Twelve compiled examples</h2>'
        '<p>The before and after labels use the same source readings. Expand each case to inspect the actual program.</p>'
        '<div class="benchmark-cases">' + ''.join(cards) + '</div></section>'
        '<section id="or-shared-context"><h2>One shared condition over two alternatives</h2>'
        f'<blockquote>{escape(shared["result"]["text"])}</blockquote><ol>{sentences}</ol>'
        '<p>The formula joins sentence 1 OR sentence 2 with sentence 3. We ran the rewrite path with controlled direct '
        'refusals. The compiler keeps one attempt with two possible contents and requires the truck next to '
        'the hikers to be the truck that blocks the path. It refuses the version that gives the blocking action to the hikers.</p>'
        f'<details><summary>Exact shared logical form and program</summary><pre>{escape(program["compilation"]["logical_form"])}</pre>'
        f'<pre>{escape(program["program"])}</pre></details>'
        f'<h3>New corpus pass</h3><blockquote>{escape(recovered["text"])}</blockquote>'
        '<p>The same people appear in both actions and in the shared purpose. The program keeps the purpose '
        'outside the action alternatives.</p>'
        f'<details><summary>Exact recovered logical form</summary><pre>{escape(recovered["new_output"]["compilation"]["logical_form"])}</pre></details>'
        f'<h3>Remaining attachment problem</h3><blockquote>{escape(wind["text"])}</blockquote>'
        '<p>The rewrite makes the wind the subject of “carrying.” The source dependency analysis attaches that '
        'predicate to walking, so it does not establish the link to wind. The compiler leaves this case unresolved.</p></section>'
        '<section id="or-scope-controls"><h2>Exact inference with supplied evidence</h2>'
        '<p>These controls run the compiled programs with fixed evidence states. A complete utterance asserting one '
        'alternative refutes the full-content condition. An incomplete transcript leaves it unknown. '
        'The two-truck case checks that two separate candidates cannot jointly satisfy one shared condition.</p>'
        + table('Selected controls from the 26 exact inference runs.',
                ['Claim', 'Observation', 'Verdict'],
                [(dict(or_exclusion_3='Exactly one door', or_report_1='Guide report',
                       or_shared_relative='Shared truck')[r['claim_id']],
                  r['case'], r['expected'].capitalize()) for r in selected])
        + '</section>'
    )


def write_downloads():
    target = ROOT / 'site/reports' / URL
    target.mkdir(parents=True, exist_ok=True)
    for name in ('evaluation.json', 'tests.xml'):
        copy2(RUN / name, target / name)
    copy2(ROOT / 'docs/disjunction_scope_20261119.md', target / 'README.md')


if __name__ == '__main__':
    summarize()
