"""Render the OR rewrite attempts and authored evaluation in the existing report."""
from html import escape
import json
from shutil import copy2

from compiler_fallback_report import table
from generate_disjunction_rewrites import ROOT, RUN

URL = 'compiler-demos/disjunction-evaluation-20261119/'
VERDICTS = {'matches_reference': 'Full match', 'partial': 'Partial',
            'incorrect': 'Incorrect', 'no_program': 'No program'}


def load(name='evaluation.json'):
    return json.loads((RUN / name).read_text())


def status_html():
    stats = load('summary.json')
    return (f'<b>Qwen supplied OR in {stats["explicit_or"]} of {stats["rewrites"]} rewrites. '
            f'{stats["rewrite_passes"]} passed compilation.</b> The twelve evaluation claims expose '
            'a missed exclusion and a gap in reported speech.')


def overview_html():
    s = load('summary.json')
    groups = [*s['benchmark'].items(), ('All claims', s['total_benchmark'])]
    rows = [(name, v['auto_pass'], *(v.get(key, 0) for key in VERDICTS))
            for name, v in groups]
    return (
        '<h2 id="remaining-failures">Where the OR compiler still fails</h2>'
        '<p>The five updated Qwen rewrites include explicit operators. Three hit the scope checks, '
        'one contains a component that fails to compile, and one repeats a sentence in its formula. '
        'The remaining problems include which clauses are alternatives and what each qualifier governs.</p>'
        + table('Twelve authored development claims with reference readings frozen before parsing. '
                'Automatic passes and reviewed meaning are separate columns.',
                ['Category', 'Automatic passes', *VERDICTS.values()], rows)
        + '<p><strong>“Exactly one” is a false pass.</strong> The compiled form mentions “one” and “doors” '
        'without checking the states of two distinct doors. Both “but not both” cases abstain. '
        'The inclusive door control works.</p>'
        '<p><strong>A report requires evidence of what the speaker said.</strong> In one compiled example '
        'we gave the report condition a supported value and left a condition in one branch unknown. '
        'The program returned support. A reference form that checks whether the utterance expresses the '
        'full disjunction distinguishes a complete report from a transcript containing only one alternative.</p>'
        '<p>All 26 controls on supplied logical forms matched their expected results. Two additional '
        'controls ran actual compiled programs. The 12 inputs and control observations are for evaluation.</p>'
        '<p><a href="#or-rewrite-results">All five Qwen rewrites</a> · '
        '<a href="#or-evaluation-cases">All twelve evaluation cases</a> · '
        '<a href="#or-evidence-controls">Exact inference controls</a> · '
        '<a href="#earlier-or-repair">Earlier pier repair</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}evaluation.json">Exact outputs and reviews</a> · '
        f'<a href="{URL}requests.json">Prompt and requests</a> · '
        f'<a href="{URL}source.zip">Source and replay</a> · <a href="{URL}tests.xml">Tests</a></p>'
    )


def formula_text(node):
    if isinstance(node, int):
        return f'Sentence {node}'
    return '(' + f' {node["op"].upper()} '.join(formula_text(c) for c in node['children']) + ')'


def rewrites_html(report):
    cards = []
    labels = {'rewrite_or_scope': 'Scope check refused the split',
              'rewrite_component': 'One sentence failed to compile',
              'invalid_model_output': 'Invalid formula'}
    for row in report['rewrites']:
        response = row['model_proposal']
        last = row['result']['attempts'][-1]
        sentences = ''.join(f'<li>{escape(text)}</li>' for text in response['sentences'])
        cards.append(
            f'<article class="box benchmark-case" id="or-rewrite-{escape(row["claim_id"])}">'
            f'<h3>{labels[last["code"]]}</h3><blockquote>{escape(row["text"])}</blockquote>'
            f'<ol>{sentences}</ol><p><strong>Proposed formula.</strong> {escape(formula_text(response["formula"]))}</p>'
            f'<p><strong>Reading.</strong> {escape(row["finding"])}</p>'
            f'<p><strong>Compiler message.</strong> {escape(last["reason"])}</p></article>'
        )
    return (
        '<section id="or-rewrite-results"><h2>Five failure-only rewrites</h2>'
        '<p>Qwen3-30B-A3B-Instruct-2507 received one fixed request per claim after SRL and AMR failed. '
        'The 14-second batch ran on one A100. The full job took 310 seconds with model loading. '
        'The sentences and formula below are the returned proposals.</p>'
        '<div class="benchmark-cases">' + ''.join(cards) + '</div></section>'
    )


def benchmarks_html(report):
    cards = []
    for row in report['benchmarks']:
        fixed = row['fixed']
        cid = escape(row['claim_id'])
        if fixed['output']:
            form = fixed['output']['compilation']['logical_form']
            details = f'<details><summary>Exact logical form and program</summary><pre>{escape(form)}</pre>'
            details += f'<pre>{escape(fixed["output"]["program"])}</pre></details>'
        else:
            details = '<ul>' + ''.join(
                f'<li>{stage.upper()}. {escape(row[stage]["reason"])}</li>' for stage in ('srl', 'amr')
            ) + '</ul>'
        cards.append(
            f'<article class="box benchmark-case" id="{cid}">'
            f'<h3>{VERDICTS[row["judgment"]]} · {escape(row["category"])}</h3>'
            f'<blockquote>{escape(row["text"])}</blockquote>'
            f'<p><strong>Reference reading.</strong> {escape(row["reference"])}</p>'
            f'<p><strong>Finding.</strong> {escape(row["finding"])}</p>{details}</article>'
        )
    return (
        '<section id="or-evaluation-cases"><h2>Twelve evaluation claims</h2>'
        '<p>The authored readings were frozen before parsing. The first automatic pass selects '
        'the reviewed program. When both parsers fail, the case shows their reasons.</p>'
        '<div class="benchmark-cases">' + ''.join(cards) + '</div></section>'
    )


def examples_html():
    data = load()
    compiled = data['compiled_controls']
    reference = data['reference_controls']
    included = [
        r for r in reference
        if r['case'] in {'A supported, B supported', 'A supported, B unknown',
                         'Incomplete transcript with A only', 'Complete utterance only asserts A',
                         'Both vehicles with swapped colors', 'Matching red truck with wrong time'}
    ]
    return (
        rewrites_html(data) + benchmarks_html(data)
        + '<section id="or-evidence-controls"><h2>DeepProbLog evidence controls</h2>'
        '<p>Reference-form controls use manually specified predicates and evidence states. '
        'The second table runs exact inference on the selected compiled programs.</p>'
        + table('Selected results from the 26 tests of the intended logical forms.',
                ['Condition', 'Supplied evidence', 'Verdict'],
                [(r['group'], r['case'], r['expected'].capitalize()) for r in included])
        + table('Both controls on compiled programs.',
                ['Evidence condition', 'Observed verdict'],
                [(r['case'], r['expected'].capitalize()) for r in compiled])
        + '</section>'
    )


def write_downloads():
    target = ROOT / 'site/reports' / URL
    target.mkdir(parents=True, exist_ok=True)
    for name in ('summary.json', 'evaluation.json', 'requests.json', 'tests.xml'):
        copy2(RUN / name, target / name)
    copy2(ROOT / 'docs/disjunction_evaluation_20261119.md', target / 'README.md')
