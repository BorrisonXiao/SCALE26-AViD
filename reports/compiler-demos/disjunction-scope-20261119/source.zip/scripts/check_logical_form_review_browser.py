"""Check the benchmark and its links inside the consolidated compiler report."""
from functools import partial
from http.server import ThreadingHTTPServer
import threading

from playwright.sync_api import sync_playwright
from check_compiler_scope_browser import QuietHandler
from sample_logical_form_review import ROOT, RUN


def main():
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=ROOT / 'site'))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f'http://127.0.0.1:{server.server_port}/reports/'
    report = base + 'compiler-demos.html#'
    try:
        with sync_playwright() as driver:
            browser = driver.chromium.launch(args=['--no-sandbox'])
            page = browser.new_page(viewport={'width': 1400, 'height': 960})
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto(report + 'remaining-failures', wait_until='networkidle')
            assert page.get_by_role('tab').count() == 5
            assert page.locator('#current-work tbody tr').last.inner_text().split() == [
                'Total', '60', '22', '20', '16', '2']
            assert '106 of 2,358' in page.locator('#current-work').inner_text()
            page.get_by_role('link', name='Read all 60 claims and exact forms').click()
            page.locator('#walkthroughs').wait_for(state='visible')
            assert page.locator('.benchmark-case').count() == 60
            case = page.locator('#benchmark-T2EE72iNELEs_183')
            assert '384 mph' in case.inner_text()
            case.locator('summary').click()
            assert 'EXISTS' in case.locator('pre').first.inner_text()
            assert 'query(' in case.locator('pre').last.inner_text()
            page.goto(report + 'earlier-scope-repair', wait_until='networkidle')
            assert page.locator('#history').is_visible()
            assert '2,358/2,375' in page.locator('#history').inner_text()
            page.goto(report + 'binding-contrasts', wait_until='networkidle')
            assert page.locator('#binding-contrasts tbody tr').count() == 5
            page.goto(report + 'daily-progress', wait_until='networkidle')
            assert 'All 60 logical-form reviews' in page.locator('#daily-progress').inner_text()
            page.goto(base + 'verification-pipeline.html#next-steps', wait_until='networkidle')
            assert 'Expand the logical-form benchmark review' in page.locator('#next-steps').inner_text()
            assert 'Design features and training data separately' in page.locator('#next-steps').inner_text()
            page.goto(base, wait_until='networkidle')
            assert page.locator('.card-link').count() == 2

            page.set_viewport_size({'width': 390, 'height': 844})
            page.emulate_media(color_scheme='dark')
            for fragment in ('remaining-failures', 'benchmark-T2EE72iNELEs_183', 'binding-contrasts'):
                page.goto(report + fragment, wait_until='networkidle')
                assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'), fragment
            page.goto(report + 'benchmark-T2EE72iNELEs_183', wait_until='networkidle')
            case.locator('summary').click()
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')
            page.screenshot(path=str(RUN / 'benchmark-report-mobile.png'))
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()
    print('The 60 reviews, exact programs, historical comparison, five binding pairs, checklist and mobile view pass.')


if __name__ == '__main__':
    main()
