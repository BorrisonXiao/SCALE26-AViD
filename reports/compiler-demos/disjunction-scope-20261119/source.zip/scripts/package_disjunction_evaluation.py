"""Package the frozen inputs and evaluated outputs for cached reproducibility."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from disjunction_evaluation_report import ROOT, RUN, URL
from generate_disjunction_rewrites import PREVIOUS
from prepare_compiler_fallback import rows
from sample_logical_form_review import INPUTS

REPLAY = (
    'benchmark/compilation.json', 'rewrite/compilation.json',
    'native_controls.json', 'compiled_controls.json', 'summary.json', 'evaluation.json',
)


def subset(path, ids):
    return ''.join(json.dumps(r, ensure_ascii=False) + '\n'
                   for r in rows(path) if r['claim_id'] in ids).encode()


def main():
    paths = [RUN / name for name in (
        'requests.json', 'resources.json', 'model_config.json', 'generation.json',
        'benchmark/references.json', 'benchmark/dependency_provenance.json',
        'benchmark/srl_provenance.json', 'benchmark/parsed.jsonl', 'benchmark/amr.jsonl',
        'benchmark/reviews.json', 'rewrite/parsed.jsonl', 'rewrite/reviews.json',
        'rewrite/raw.jsonl', 'rewrite/dependency_provenance.json',
        'rewrite/srl_provenance.json', *REPLAY)]
    paths.extend((PREVIOUS / 'comparison.json', ROOT / 'docs/disjunction_evaluation_20261119.md'))
    for folder in ('scripts', 'scripts/probabilistic_verification', 'scripts/probabilistic_verification/resources'):
        paths.extend(p for p in (ROOT / folder).glob('*')
                     if p.is_file() and p.suffix in {'.py', '.json'})
    bundle = {str(p.relative_to(ROOT)): p.read_bytes() for p in paths}
    ids = {r['claim_id'] for r in json.loads((RUN / 'requests.json').read_text())}
    legacy = ROOT / 'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl'
    for source in (INPUTS, PREVIOUS / 'corpus.jsonl', legacy):
        bundle[str(source.relative_to(ROOT))] = subset(source, ids)
    bundle['README.md'] = (ROOT / 'docs/disjunction_evaluation_20261119.md').read_bytes()
    bundle['REPLAY_SHA256.json'] = json.dumps(
        {name: sha256((RUN / name).read_bytes()).hexdigest() for name in REPLAY}, indent=2).encode()
    target = ROOT / 'site/reports' / URL / 'source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(target, 'w', compression=ZIP_DEFLATED) as archive:
        for name, data in sorted(bundle.items()):
            member = ZipInfo(name, date_time=(2026, 11, 19, 0, 0, 0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, data)
    print(f'Bundled {len(bundle)} cached input and source files.')


if __name__ == '__main__':
    main()
