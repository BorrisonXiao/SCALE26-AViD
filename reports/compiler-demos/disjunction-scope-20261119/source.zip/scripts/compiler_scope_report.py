"""Publish scope repairs, the provisional audit and binding data in the existing report."""
import json
from html import escape
from shutil import copy2

from compiler_fallback_report import table
from run_compiler_scope_repairs import RUN, COVERAGE
from prepare_compiler_fallback import ROOT

URL = 'compiler-demos/scope-20261118/'


def load(name):
    return json.loads((RUN / name).read_text())


def status_html():
    s = load('summary.json')
    return (f'<b>{s["current_semantic"]:,}/{s["total"]:,} claims produce semantic programs '
            f'({100 * s["current_semantic"]/s["total"]:.2f}%).</b> The new pass recovers '
            f'{s["recovered"]} provisional programs and leaves {s["dependency_only"]} dependency analyses.')


def overview_html():
    s = load('summary.json')
    review = load('fidelity.json')
    counts = review['categories']
    pairs = load('binding_contrasts.json')
    return (
        '<h2 id="remaining-failures">Scope repairs and preparation for binding experiments</h2><p>'
        + status_html() + '</p>'
        + f'<p>The accepted compiler checks cover {s["strict_after_repairs"]:,} claims. The '
        f'other {s["current_semantic"] - s["strict_after_repairs"]} semantic programs require meaning review. '
        f'The sample of {review["sample_size"]} provisional programs from {review["source_groups"]} '
        f'source groups yielded {counts["matches_reference"]} full match, '
        f'{counts["partial"]} partial and {counts["incorrect"]} incorrect readings. '
        'The sample balances repair paths and source groups. It is a development diagnostic.</p>'
        f'<p>The pilot contains {len(pairs["pairs"])} frame-reviewed binding pairs. Each pair keeps the same '
        'words and exchanges two assignments on the same supplied frames. The development and reserved sets '
        'use separate source clips.</p>'
        '<p><a href="#scope-repair-examples">Scope repair examples</a> · '
        '<a href="#scope-fidelity">Full provisional audit</a> · '
        '<a href="#binding-contrasts">Same-word binding examples</a> · '
        '<a href="#earlier-coverage">Earlier coverage experiment</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
    )


def examples_html():
    review = load('fidelity.json')
    contrasts = load('binding_contrasts.json')
    h = ('<section id="scope-repair-examples"><h2>What the new scope repairs preserve</h2>'
         '<p>The fixed repair pass examines all 21 previous dependency-only claims. It produced four programs '
         'on three distinct texts. Each adds an inspectable semantic form and stays available for review.</p>')
    repairs = review['repairs']
    for row in repairs:
        if row['after'] != 'semantic_program':
            continue
        cid = escape(row['claim_id'])
        output = row['result']
        h += (f'<article class="box"><h3>{cid}</h3><blockquote>{escape(row["text"])}</blockquote>'
              f'<p>{escape(row["reason"])}</p>')
        alerts = [e['reason'] for e in output.get('errors', []) + output.get('shared_checks', [])]
        if alerts:
            h += '<p>Warnings remain on this program. ' + escape(' '.join(alerts)) + '</p>'
        h += ('<details><summary>Compiled conditions and ProbLog program</summary>'
              f'<pre>{escape(output["compilation"]["logical_form"])}</pre><pre>{escape(output["program"])}</pre></details>'
              f'<p><a href="?coverage_claim={cid}#coverage-cases">Open the earlier trace</a>.</p></article>')
    older = {r['claim_id']: r for r in json.loads((COVERAGE / 'audit.json').read_text())['remaining']}
    h += '<h3>Remaining cases</h3>'
    h += table('The 17 cases outside the supported repair patterns.', ['Claim', 'Diagnosis'], [
        (f'<a href="?coverage_claim={escape(r["claim_id"])}#coverage-cases">'
         f'{escape(r["text"])}</a>', escape(older[r['claim_id']]['diagnosis']))
        for r in repairs if r['after'] == 'dependencies'
    ])
    h += '</section><section id="scope-fidelity"><h2>Review of provisional outputs</h2>'
    h += table('Review by compiler path. The sample prioritizes different source videos and topics.',
               ['Path', 'Complete', 'Partial', 'Incorrect'], [
        (escape(name.replace('_', ' ')), *(counts.get(label, 0)
          for label in ('matches_reference', 'partial', 'incorrect')))
        for name, counts in review['by_stage'].items()
    ])
    h += ('<p>All 15 sampled programs without an existing warning had a meaning problem. '
          'The new OR check finds an explicit coordination marker without an OR in the formula. It flagged '
          f'{len(review["explicit_or_alerts"])} of the 171 previous provisional programs, including the pier or '
          'terminal example. Missing qualifiers and changed names or numbers still require more checks.</p>')
    h += table('All 32 completed readings.', ['Claim', 'Review', 'Reason'], [
        (f'<a href="?coverage_claim={escape(r["claim_id"])}#coverage-cases">{escape(r["text"])}</a>',
         escape(r['judgment'].replace('_', ' ')), escape(r['reason'])) for r in review['reviews']
    ])
    h += ('</section><section id="binding-contrasts"><h2>Binding contrasts with reviewed frame evidence</h2>'
          '<p>Each pair supplies the same candidate regions or objects, the same frame times, and the same '
          'words. Only the assignment changes. OCR refers to text read from the frame. The visual route '
          'handles displayed colors. Source groups and clip hashes are disjoint across the two splits.</p>')
    h += table('Five source clips, with three development and two reserved pairs.',
               ['Split and evidence', 'Observed assignment', 'Swapped assignment', 'Frame review'], [
        (escape(p['split']) + ' · ' + ('OCR' if p['media_route'] == 'ocr_assertion' else 'visual'),
         escape(p['examples'][0]['claim']), escape(p['examples'][1]['claim']),
         escape(p['review'])) for p in contrasts['pairs']
    ])
    h += ('<p>We built and evaluated ten logic programs using the inspected assignments as input. All '
          'return the expected label under that control. The supplied identities and exact time points simplify '
          'grounding. Feature extraction and model evaluation remain later steps.</p>'
          '<p>One English overlay claim could not serve as exact OCR supervision because the displayed text is Arabic. '
          'The robot contrast was also withheld because the numeric identity of the fallen robot could not be established. '
          'The earlier music labels need listening review.</p>'
          '<p>These five pairs are reserved for benchmark development. '
          '<a href="verification-pipeline.html#next-steps">See the feature and training design checklist</a>.</p><p>')
    h += ' · '.join(f'<a href="{URL}{path}">{label}</a>' for path, label in [
        ('source.zip', 'Source and cached inputs'), ('README.md', 'Design and results'),
        ('summary.json', 'Coverage counts'), ('fidelity.json', 'Full review and repairs'),
        ('binding_contrasts.json', 'Binding labels and logic programs'), ('test_inventory.json', 'All 2,375 outcomes'),
        ('tests.xml', 'Automated tests'), ('validation.json', 'Replay and evidence checks'),
    ])
    return h + '</p></section>'


def write_downloads():
    target = ROOT / 'site/reports' / URL
    target.mkdir(parents=True, exist_ok=True)
    for name in ('summary.json', 'fidelity.json', 'binding_contrasts.json', 'test_inventory.json',
                 'tests.xml', 'validation.json'):
        if (RUN / name).exists():
            copy2(RUN / name, target / name)
    copy2(ROOT / 'docs/compiler_scope_20261118.md', target / 'README.md')
