"""Check the five attempts, twelve case records, and preserved report navigation."""
from functools import partial
from http.server import ThreadingHTTPServer
import threading

from playwright.sync_api import sync_playwright

from check_compiler_scope_browser import QuietHandler
from disjunction_evaluation_report import ROOT, RUN


def main():
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=ROOT / 'site'))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    root = f'http://127.0.0.1:{server.server_port}/reports/'
    url = root + 'compiler-demos.html#'
    try:
        with sync_playwright() as driver:
            browser = driver.chromium.launch(args=['--no-sandbox'])
            page = browser.new_page(viewport={'width': 1360, 'height': 920})
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto(url + 'remaining-failures', wait_until='networkidle')
            assert page.get_by_role('tab').count() == 5
            assert 'Exactly one' in page.locator('#current-work').inner_text()
            assert page.locator('#current-work tbody tr').last.inner_text().split() == [
                'All', 'claims', '8', '4', '3', '1', '4']
            page.get_by_role('link', name='All five Qwen rewrites').click()
            rewrites = page.locator('#or-rewrite-results')
            rewrites.wait_for(state='visible')
            assert rewrites.locator('article').count() == 5
            assert 'Sentence 1 OR Sentence 2' in rewrites.inner_text()

            page.goto(url + 'or-evaluation-cases', wait_until='networkidle')
            cases = page.locator('#or-evaluation-cases')
            assert cases.locator('article').count() == 12
            assert 'Incorrect' in page.locator('#or_exclusion_3 h3').inner_text()
            page.locator('#or_exclusion_3 summary').click()
            assert 'referent(X1, one' in page.locator('#or_exclusion_3 pre').first.inner_text()
            page.goto(url + 'or-evidence-controls', wait_until='networkidle')
            assert page.locator('#or-evidence-controls tbody tr').count() == 10

            page.goto(url + 'earlier-or-repair', wait_until='networkidle')
            assert page.locator('#history').is_visible()
            assert '2,178 / 2,375' in page.locator('#history').inner_text()
            page.goto(url + 'daily-progress', wait_until='networkidle')
            assert 'Twelve evaluation cases' in page.locator('#daily-progress').inner_text()
            page.goto(root + 'verification-pipeline.html#next-steps', wait_until='networkidle')
            assert 'Handle exclusion and preserve scope across alternatives' in page.locator('#next-steps').inner_text()
            page.goto(root, wait_until='networkidle')
            assert page.locator('.card-link').count() == 2

            page.set_viewport_size({'width': 390, 'height': 844})
            page.emulate_media(color_scheme='dark')
            for section in ('or-rewrite-results', 'or-evaluation-cases', 'or-evidence-controls'):
                page.goto(url + section, wait_until='networkidle')
                assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'), section
            page.goto(url + 'or_exclusion_3', wait_until='networkidle')
            page.locator('#or_exclusion_3 summary').click()
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')
            page.screenshot(path=str(RUN / 'or-evaluation-mobile.png'))
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()
    print('Five rewrites, twelve evaluation cases, prior report, checklist and mobile view passed.')


if __name__ == '__main__':
    main()
