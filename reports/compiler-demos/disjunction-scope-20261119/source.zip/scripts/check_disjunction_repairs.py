"""Compare the cached fallback outputs and check both paths on the pier claim."""
import copy
import hashlib
import json

from prepare_compiler_fallback import ROOT, RUN as STRICT, rows, dump
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.compiler_fallback import compile_claim, restore
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.representation import STATES
from run_compiler_fallback import cached_rewrite
from sample_logical_form_review import INPUTS

RUN = STRICT.with_name('disjunction_repairs_20261119')
AUDIT = STRICT.with_name('compiler_or_audit_20261119')
PIER = 'Txf2EdqOg1SQ_2166'


def index(path):
    return {row['claim_id']: row for row in rows(path)}


def signature(row):
    return row['selected_stage'], (row['output'] or {}).get('program_sha256')


def attempt_codes(row):
    return {a['stage']: a.get('code') or a['status'] for a in row['attempts']}


def unsupported(_):
    return dict(status='unsupported', code='controlled_failure', reason='Simulated direct refusal.')


def probe_native(compilation):
    claim = restore(compilation)
    variables = {v.name: 'candidate:' + v.name for v in claim.variables}
    evidence = Evidence('fixed-control', {v: [x] for v, x in variables.items()},
                        {v: True for v in variables}, {})
    conditions = (
        ('pier only', 'supported', 'refuted', 'supported', 'supported'),
        ('terminal only', 'refuted', 'supported', 'unknown', 'supported'),
        ('both labels supported', 'supported', 'supported', 'supported', 'supported'),
        ('missing paved evidence', 'supported', 'refuted', 'unknown', 'unknown'),
        ('both labels refuted', 'refuted', 'refuted', 'supported', 'refuted'),
    )
    results = []
    for label, pier, terminal, paved, expected in conditions:
        states = {'pier': pier, 'area': terminal, 'pave-01': paved}
        for atom in claim.atoms:
            key = canonical_key(evidence.media_id, atom, variables, evidence.route)
            state = states.get(atom.arguments[1], 'supported') if atom.predicate == 'concept' else 'supported'
            evidence.observations[key] = Observation(key, tuple(float(s == state) for s in STATES),
                                                     False, atom.text)
        actual = DirectVerifier([ground(claim, evidence)], learned=False,
                                program_builder=compact_prolog_program).predict()[0]['distribution']
        assert actual[expected] > 1 - 1e-10, (label, actual)
        results.append(dict(case=label, expected=expected, distribution=actual))
    return results


def main():
    before = index(STRICT / 'corpus.jsonl')
    after = index(RUN / 'corpus.jsonl')
    assert before.keys() == after.keys() and len(after) == 2375
    case = after[PIER]
    assert case['selected_stage'] == 'amr'
    assert [a['stage'] for a in case['attempts']] == ['srl', 'amr']
    for row in after.values():
        output = row['output']
        if output:
            assert hashlib.sha256(output['program'].encode()).hexdigest() == output['program_sha256']

    source = index(INPUTS)[PIER]
    corrected = index(RUN / 'control/parsed.jsonl')[PIER]
    old_rewrites = ROOT / 'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl'
    legacy = index(old_rewrites)[PIER]
    legacy_explicit = copy.deepcopy(legacy)
    legacy_explicit['proposal']['formula'] = dict(op='or', children=[1, 2])
    wrong_operator = copy.deepcopy(corrected)
    wrong_operator['proposal']['formula']['op'] = 'and'
    probes = []
    for label, rewrite, expected in (
        ('Source-aligned subclaims with OR', corrected, 'compiled'),
        ('Same subclaims with AND', wrong_operator, 'rewrite_or_required'),
        ('Legacy subclaims with OR and copied adjectives', legacy_explicit, 'rewrite_or_alignment'),
    ):
        result = compile_claim(source, srl=unsupported, amr=unsupported,
                               rewrite=lambda r, _: cached_rewrite(r, rewrite))
        outcome = 'compiled' if result['output'] else result['attempts'][-1]['code']
        assert outcome == expected, (label, result['attempts'])
        probes.append(dict(label=label, sentences=[c['text'] for c in rewrite['clauses']],
                           formula=rewrite['proposal']['formula'], outcome=outcome,
                           reason=result['attempts'][-1].get('reason'), output=result['output']))

    changes = [dict(claim_id=cid, text=b['text'], before=signature(before[cid]), after=signature(b))
               for cid, b in after.items() if signature(before[cid]) != signature(b)]
    diagnostics = [dict(claim_id=cid, text=b['text'], before=attempt_codes(before[cid]),
                        after=attempt_codes(b)) for cid, b in after.items()
                   if not b['output'] and attempt_codes(before[cid]) != attempt_codes(b)]
    counts = dict(before=sum(bool(r['output']) for r in before.values()),
                  after=sum(bool(r['output']) for r in after.values()), total=len(after),
                  earlier_programs_identical=sum(bool(a['output']) and signature(a)==signature(after[cid])
                                                 for cid, a in before.items()))
    or_ids = [r['claim_id'] for r in json.loads((AUDIT / 'audit.json').read_text())['rows']]
    counts['explicit_or_claims'] = len(or_ids)
    counts['explicit_or_before'] = sum(bool(before[cid]['output']) for cid in or_ids)
    counts['explicit_or_after'] = sum(bool(after[cid]['output']) for cid in or_ids)
    result = dict(counts=counts, changed_programs=changes, changed_abstentions=diagnostics,
                  pier=dict(before=attempt_codes(before[PIER]), after=attempt_codes(case),
                            raw_amr=index(STRICT / 'amr_attempts.jsonl')[PIER]['raw'], output=case['output']),
                  rewrite_controls=probes, native_controls=probe_native(case['output']['compilation']))
    dump(RUN / 'comparison.json', result)
    print(json.dumps(counts, indent=2))


if __name__ == '__main__':
    main()
