"""Request one structured rewrite for each of the five saved strict refusals."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import time

from prepare_compiler_fallback import ROOT, RUN as STRICT, dump, rows
from probabilistic_verification.structured_rewrite import REVISED_SYSTEM, SCHEMA, request
from sample_logical_form_review import INPUTS

PREVIOUS = STRICT.with_name('disjunction_repairs_20261119')
RUN = STRICT.with_name('disjunction_evaluation_20261119')
MODEL = Path('/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507')


def freeze_requests():
    comparison = json.loads((PREVIOUS / 'comparison.json').read_text())
    ids = {r['claim_id'] for r in comparison['changed_abstentions']
           if r['after']['rewrite'] == 'rewrite_or_required'}
    source = {r['claim_id']: r for r in rows(INPUTS) if r['claim_id'] in ids}
    assert len(source) == len(ids) == 5
    records = []
    for row in rows(PREVIOUS / 'corpus.jsonl'):
        cid = row['claim_id']
        if cid not in ids:
            continue
        assert row['parsing_status'] == 'abstained'
        srl, amr, rewrite = row['attempts']
        assert all(a['status'] != 'compiled' for a in (srl, amr))
        assert rewrite['code'] == 'rewrite_or_required'
        data = request(source[cid], amr.get('raw'))
        data['direct_compiler_error'] = [
            {key: a.get(key) for key in ('stage', 'code', 'reason')} for a in (srl, amr)
        ]
        data['compiler_feedback'] = {key: rewrite[key] for key in ('code', 'reason')}
        messages = [dict(role='system', content=REVISED_SYSTEM),
                    dict(role='user', content=json.dumps(data, ensure_ascii=False, separators=(',', ':')))]
        records.append(dict(claim_id=cid, text=row['text'], messages=messages,
                            diagnostics=data['direct_compiler_error'] + [data['compiler_feedback']]))
    return records


def main():
    import argparse

    cli = argparse.ArgumentParser()
    cli.add_argument('--freeze', action='store_true')
    args = cli.parse_args()
    RUN.mkdir(parents=True, exist_ok=True)
    manifest = RUN / 'requests.json'
    if args.freeze:
        assert not manifest.exists(), 'The request manifest is already frozen.'
        dump(manifest, freeze_requests())
        return

    jobs = json.loads(manifest.read_text())
    assert jobs == freeze_requests()
    folder = RUN / 'rewrite'
    folder.mkdir(exist_ok=True)
    target = folder / 'raw.jsonl'
    assert not target.exists(), 'The experiment already has model responses.'

    import torch
    from vllm import LLM, SamplingParams
    from vllm.sampling_params import StructuredOutputsParams

    config = dict(model=str(MODEL), dtype='float16', temperature=0, seed=42, max_tokens=1024,
                  max_model_len=4096, eligible=len(jobs), job_id=os.getenv('SLURM_JOB_ID'),
                  gpu_names=[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())],
                  vllm=importlib.metadata.version('vllm'), system_prompt=REVISED_SYSTEM,
                  prompt_sha256=hashlib.sha256(REVISED_SYSTEM.encode()).hexdigest(),
                  requests_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
                  model_config_sha256=hashlib.sha256((MODEL / 'config.json').read_bytes()).hexdigest())
    dump(RUN / 'model_config.json', config)
    engine = LLM(model=str(MODEL), dtype=config['dtype'], tensor_parallel_size=1,
                 max_model_len=config['max_model_len'], max_num_seqs=len(jobs),
                 gpu_memory_utilization=.90, enforce_eager=True, seed=config['seed'])
    tokenizer = engine.get_tokenizer()
    prompts = [tokenizer.apply_chat_template(row['messages'], tokenize=False, add_generation_prompt=True)
               for row in jobs]
    settings = SamplingParams(temperature=0, seed=config['seed'], max_tokens=config['max_tokens'],
                              structured_outputs=StructuredOutputsParams(json=SCHEMA))
    started = time.perf_counter()
    outputs = engine.generate(prompts, settings, use_tqdm=False)
    elapsed = time.perf_counter() - started
    responses = []
    for row, output in zip(jobs, outputs, strict=True):
        sample = output.outputs[0]
        responses.append(dict(claim_id=row['claim_id'], raw=sample.text, finish_reason=sample.finish_reason,
                              input_tokens=len(output.prompt_token_ids), output_tokens=len(sample.token_ids)))
    temp = target.with_suffix('.tmp')
    temp.write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in responses))
    temp.replace(target)
    dump(RUN / 'generation.json', dict(seconds=elapsed, responses=len(responses)))
    print(f'Saved {len(responses)} structured rewrites in {elapsed:.1f} seconds.', flush=True)


if __name__ == '__main__':
    main()
