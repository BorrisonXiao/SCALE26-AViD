"""Show the direct AMR repair and parallel rewrite controls in the compiler report."""
from html import escape
import json
from shutil import copy2

from compiler_fallback_report import table
from prepare_compiler_fallback import ROOT, RUN as STRICT

RUN = STRICT.with_name('disjunction_repairs_20261119')
URL = 'compiler-demos/disjunction-repairs-20261119/'


def load():
    return json.loads((RUN / 'comparison.json').read_text())


def status_html():
    c = load()['counts']
    return (f'<b>{c["after"]:,} of {c["total"]:,} claims pass the fixed compiler checks.</b> '
            'The pier or terminal area claim is the new pass.')


def overview_html():
    c = load()['counts']
    return (
        '<h2 id="remaining-failures">Compiling parallel alternatives</h2>'
        '<p>The AMR parser already found the alternatives in the pier claim. The converter now keeps '
        'the modifiers inside the pier branch and binds both branches to the same location argument. '
        'Inclusive OR allows either description or both.</p>'
        + table('Automatic checks on the same saved inputs.',
                ['Saved claims', 'Earlier passes', 'After the repair'],
                [('All original claims', f'{c["before"]:,} / {c["total"]:,}', f'{c["after"]:,} / {c["total"]:,}'),
                 ('Claims with standalone “or” outside quotes',
                  f'{c["explicit_or_before"]} / {c["explicit_or_claims"]}',
                  f'{c["explicit_or_after"]} / {c["explicit_or_claims"]}')])
        + f'<p>All {c["earlier_programs_identical"]:,} earlier programs are byte-identical. '
        'The fallback now requires an explicit OR for parallel alternatives and checks each branch against the source. '
        'A controlled rewrite passes with the right operator and modifiers. Five prior abstentions now identify a '
        'missing OR in the cached rewrite. The counts measure automatic compilation.</p>'
        '<p><a href="#parallel-or-demo">Pier and terminal example</a> · '
        '<a href="#rewrite-or-control">Rewrite controls</a> · '
        '<a href="#earlier-benchmark-review">Previous logical-form benchmark review</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}comparison.json">Saved programs and comparison</a> · '
        f'<a href="{URL}source.zip">Source and replay</a> · <a href="{URL}tests.xml">Tests</a></p>'
    )


def examples_html():
    report = load()
    claim = report['changed_programs'][0]['text']
    direct = report['pier']
    rewrites = report['rewrite_controls']
    examples = rewrites[0]['sentences']
    native = report['native_controls']
    outcome = {'compiled': 'Compiled', 'rewrite_or_required': 'OR missing',
               'rewrite_or_alignment': 'Modifiers assigned to the wrong branch'}
    return (
        '<section id="parallel-or-demo"><h2>The pier or terminal area claim</h2>'
        f'<blockquote>{escape(claim)}</blockquote>'
        '<p>Previously the converter refused the AMR because the modifier edges pointed to <em>pier</em>. '
        'The repaired form keeps the two location descriptions separate.</p>'
        f'<ol><li>{escape(examples[0])}</li><li>{escape(examples[1])}</li></ol>'
        '<p>The compiled OR accepts either branch. These two descriptions can both apply to one location.</p>'
        f'<details><summary>Exact AMR, logical form and program</summary><pre>{escape(direct["raw_amr"])}</pre>'
        f'<pre>{escape(direct["output"]["compilation"]["logical_form"])}</pre>'
        f'<pre>{escape(direct["output"]["program"])}</pre></details>'
        + table('DeepProbLog results on the repaired program with supplied observations.',
                ['Supplied evidence', 'Verdict'], [(r['case'].capitalize(), r['expected'].capitalize()) for r in native])
        + '<h3 id="rewrite-or-control">What happens after direct compilation fails</h3>'
        '<p>For these controls, both direct stages are set to refuse. We then feed the fallback '
        'the same two simple clauses with different operators, and a legacy rewrite that moves the adjectives. '
        'The source-aligned clauses were written for this control and parsed with Stanza and BERT-SRL.</p>'
        + table('Rewrite results. OR denotes the proposed operator between the clauses.',
                ['Proposal', 'Outcome'], [(r['label'], outcome[r['outcome']]) for r in rewrites])
        + '</section>'
    )


def write_downloads():
    target = ROOT / 'site/reports' / URL
    target.mkdir(parents=True, exist_ok=True)
    for name in ('comparison.json', 'summary.json', 'tests.xml'):
        copy2(RUN / name, target / name)
    copy2(ROOT / 'docs/disjunction_repairs_20261119.md', target / 'README.md')
