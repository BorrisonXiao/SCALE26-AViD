"""Attach source-meaning reviews to exact benchmark audit outputs."""
import hashlib
import json
from collections import Counter, defaultdict

from prepare_compiler_fallback import rows, dump
from probabilistic_verification.benchmark_warnings import warnings
from sample_logical_form_review import RUN, ROOT, COVERAGE, INPUTS, SCOPE, STRICT

# Readings judge preservation of the claim text. They say nothing about whether
# the claims are true or whether their modalities supply sufficient evidence.
REVIEWS = {
    'TQEmEycTI0RQ_900': ('partial', 'numeric binding',
        'The bar graph uses light red for 2021 and dark red for 2025. Its 2025 data is current at the stated time in two time zones.',
        'The colors are attached to two years, but both clock values and both zones sit on one node without their pairings.'),
    'TFgw4IaR9R8s_1646': ('partial', 'source scope',
        'Muted footage depicts Trump speaking in Washington DC this afternoon.',
        'The actor, time, place and mute condition survive. The speech is in a generic complement of tape rather than a visual depiction route.'),
    'TgPh_fzHTCm4_1511': ('incorrect', 'unit',
        'On July 2 the circulation dissipated and drifted slowly north, with southerly 10–20 knot flow at a 500 mb pressure level.',
        'The pressure level is treated as 500 megabytes. The wind range does not fix the incompatible unit binding.'),
    'TgR_u37mCoQ4_2003': ('partial', 'entity binding',
        'Rinderknecht repeatedly listened to a French rap song about fire before the Lachman Fire.',
        'The listening, repetition, topic and time survive. An untyped country modifier for France leaves the French-language or style reading unresolved.'),
    'T2G_ACMxR_I4_1263': ('partial', 'qualification',
        'Elytra is expected to stay in lunar orbit to supply communications relay and support RF calibration for NASA telescopes.',
        'The two purposes are represented, but the remaining event lacks a future marker.'),
    'TzzhcBIczf_M_2127': ('partial', 'clause scope',
        'The way Shi Yongxin ran the temple diverged from his role as a monk.',
        'The same actor is attached to running and deviating, but the temple-running clause has an unresolved complement instead of an explicit respect or manner relation.'),
    'Txf2EdqOg1SQ_2234': ('matches_reference', 'none',
        'Tourists made the decision to go to sea because those tourists had paid already.',
        'Payment is past perfect and causes the decision. The intended sea trip is embedded under decide.'),
    'TW4OYA3RN-Hw_1826': ('partial', 'participant binding',
        'Two boys arrange for another person to photograph them on the bridge, with fire and smoke visible behind.',
        'The subject group and photographer stay distinct. The picture location and background perception survive, but the causative force of have is left generic.'),
    'TFgw4IaR9R8s_1717': ('partial', 'reported scope',
        'The source notes a 172-seat requirement for a majority, with a contrast that a minority can form below that threshold.',
        'The threshold and comparison share the seats variable. The concession leaves the minority clause in an outer complement, so the speaker attribution remains uncertain.'),
    'TQEmEycTI0RQ_883': ('partial', 'reported scope',
        'An unspecified speaker asserts that change is needed and emphasizes that change is difficult.',
        'Both parts are retained. The second reported proposition has no explicit assertion scope under emphasize.'),
    'TFOEIehBwT8Q_496': ('incorrect', 'predicate omission',
        'Police fire smoke bombs and tear gas while protesters throw stones.',
        'The firing predicate is lost and police, fire and smoke become modifiers of bombs.'),
    'TjHepwuhkYFA_1066': ('incorrect', 'comparative scope',
        'For earthquakes, shallower depth is associated with greater damage.',
        'Only the location comparison survives. The output lacks the damage comparison and their dependency.'),
    'TInVWzp25aIM_11': ('partial', 'participant binding',
        'People online pray during the typhoon for other people to be safe.',
        'The prayer, time and safety object survive, but safety has no beneficiary or possessor.'),
    'Tg0UxWYuPeJ0_318': ('incorrect', 'question scope',
        'A bystander’s friend checks whether he is okay. The pronoun needs an antecedent.',
        'The question is compiled as depiction of being okay, which changes what the friend is checking.'),
    'TMrQshDs8aH0_732': ('incorrect', 'participant binding',
        'Many chairs are stacked on one another and ready for loading into a large truck.',
        'The truck is bound as the object being loaded. In the claim it is the destination for the chairs.'),
    'Txf2EdqOg1SQ_2185': ('matches_reference', 'none',
        'Meishan Township in Chiayi had the day’s highest accumulation and received 149.0 millimeters.',
        'The accumulation, location, daily comparison and measured amount are associated with the same township.'),
    'TgR_u37mCoQ4_1875': ('partial', 'temporal scope',
        'The later footage shows a road covered with traffic cones and vegetation that appears burnt.',
        'The cone and appearance conditions survive. The restriction to the later footage is absent.'),
    'TzzhcBIczf_M_2068': ('incorrect', 'condition scope',
        'Shi Yongxin claims he is unafraid of criticism provided that his conscience is clear.',
        'The condition becomes temporal and the pronouns for the two inner clauses are not connected to the speaker.'),
    'T2G_ACMxR_I4_1148': ('incorrect', 'numeric binding',
        'Blue Ghost made three and one half elliptical orbits around Earth.',
        'The program states an exact count of three and loses the half orbit.'),
    'TFOEIehBwT8Q_468': ('matches_reference', 'none',
        'Visual evidence shows police suddenly attacking the same protester who holds the Mexican flag.',
        'The protester is linked to both holding and the patient of the observed attack, with police as its actor.'),
    'TgPh_fzHTCm4_1470': ('incorrect', 'unit',
        'Flow of 10–20 knots at the 850 mb pressure level would persist through the day on the third.',
        'The range and would context survive, but 850 mb is compiled as an information quantity in megabytes.'),
    'Tg0UxWYuPeJ0_373': ('incorrect', 'unit',
        'The nominal description identifies a robot sprint at the 100 meter distance.',
        'The generated measurement is 100 miles.'),
    'TjHepwuhkYFA_1016': ('incorrect', 'predicate omission',
        'During the displayed 12:46:35–12:46:37 window, the midground and background move relative to the foreground.',
        'The time anchors are emitted without a shift event or any of the terrain relationships.'),
    'Txf2EdqOg1SQ_2371': ('incorrect', 'entity identity',
        'Closing on-screen text names the upcoming storm Typhoon No. 8, Co-May.',
        'The graph only assigns the class Typhoon. It loses both the ordinal identifier and Co-May.'),
    'TKCfkoNUssZI_723': ('partial', 'reported scope',
        'A woman using a microphone speaks about President Yoon opening a building.',
        'The roles and nested speech survive, but “about” is replaced by a relative clause on something within an assertion rather than an explicit topic.'),
    'Tsuk2uoYj-kc_611': ('matches_reference', 'none',
        'The named Hajj and Umrah Services Association and pilgrims hand drinks to the public.',
        'The association remains one named member and the pilgrims another. The recipient and handed-out drinks attach to one event.'),
    'TLO3smKI67PM_555': ('matches_reference', 'none',
        'The Philadelphia Phillies are playing the Miami Marlins.',
        'Both named teams fill opposing participant slots in one ongoing play event.'),
    'TbJqMFkNxARY_154': ('matches_reference', 'none',
        'The disaster began during the interval 16:00–17:00 UTC on 9 September 2025.',
        'The date and both UTC bounds are attached to the same beginning event.'),
    'TzF9M4kZ3Pys_282': ('incorrect', 'entity identity',
        'The label associates Tik Tok with the exact account name misswong_1204.',
        'Only the platform remains. The named account has no predicate argument.'),
    'TQKCK6-tRaoE_649': ('matches_reference', 'none',
        'People gathered in front of Kazan Cathedral.',
        'The gathering event has a named location and keeps the front-of relation.'),
    'T3HTSBW42QaY_769': ('matches_reference', 'none',
        'The cargo crane comes back for the second time at 9:20:33 in the morning.',
        'The return phrase, recurrence and normalized morning time all attach to the same crane event.'),
    'T2EE72iNELEs_183': ('incorrect', 'numeric binding',
        'The rocket attains a maximum speed of 384 mph at the video cutoff.',
        'The value is expressed as a count of an entity called mph, with no speed measurement.'),
    'T8u81WMIyj18_755': ('matches_reference', 'none',
        'The car is parked at 1:53 a.m. on 19 August 2025.',
        'The car, parked condition, normalized time and date are linked in one predicate.'),
    'TMrQshDs8aH0_740': ('partial', 'qualification',
        'Cars have to alternate through the only lane that is open.',
        'The lane, exact count and taking-turns event survive. A generic have complement leaves the necessity of taking turns under-specified.'),
    'TKCfkoNUssZI_693': ('matches_reference', 'none',
        'The written street sign places highway 120 toward Inchon to the left and Shinchon Rotary to the right.',
        'The two directions are bound to distinct referents inside the sign’s OCR assertion.'),
    'TInVWzp25aIM_105': ('partial', 'participant binding',
        'Conditions remain somewhat windy a week after Typhoon Halong.',
        'The time reference survives, but the windy property is assigned to a dummy pronoun rather than a weather condition.'),
    'TzF9M4kZ3Pys_256': ('matches_reference', 'none',
        'Flights might be cancelled because of the dust storm.',
        'The flight cancellation carries possibility, with the storm bound as its reason.'),
    'T3HTSBW42QaY_775': ('partial', 'qualification',
        'The conditions are likely too hazardous for ships to dock safely.',
        'The dock event and hazard text survive. Likely appears as a literal adjunct without a scope for the hazard assessment.'),
    'TInVWzp25aIM_54': ('matches_reference', 'none',
        'Akiak may regain electricity on the following weekend.',
        'The location, electricity, return and weekend are retained within a possibility context.'),
    'TjHepwuhkYFA_1027': ('partial', 'qualification',
        'An unseen crowd reacts audibly to the collapse. Thai is a likely language, with uncertainty.',
        'The reaction is routed to audio. The likely language is a text adjunct instead of a qualification specific to language.'),
    'TzF9M4kZ3Pys_216': ('matches_reference', 'none',
        'A dust storm could affect electric service in the area.',
        'The effect and affected service stay within possibility. The affected-area phrase stays attached to the service.'),
    'TFgw4IaR9R8s_1746': ('partial', 'qualification',
        'The appeals are expected, with uncertainty, to proceed to the referred-to Supreme Court.',
        'Future scope attaches to the event, but likely is plain text. The holder of the court also stays unresolved.'),
    'T2EE72iNELEs_179': ('needs_context', 'reported wording',
        'A child says the phrase “to infinity and beyond” in Spanish.',
        'It is unclear whether the English quote is a translation. The program asks for those exact English words plus Spanish.'),
    'TW4OYA3RN-Hw_1787': ('matches_reference', 'none',
        'An Instagram video shows footage of a hotel building on fire.',
        'The media source owns the depiction, and the fire condition is attached to the hotel building within it.'),
    'Tsuk2uoYj-kc_642': ('needs_context', 'source scope',
        'A QR code helps show locations on a map.',
        'The code is treated as the visual carrier of the map. A destination reached by scanning would require a different relation.'),
    'TLO3smKI67PM_566': ('incorrect', 'reference binding',
        'Karen tells the Phillies fan father that the ball is hers and that he took it from her hands, on the likely reported reading.',
        'The taking is unconditionally asserted outside the report, with he, it and her left as fresh variables.'),
    'TQKCK6-tRaoE_656': ('matches_reference', 'none',
        'One visible banner contains the exact quoted words.',
        'The full string is grounded in OCR and the visible entity is the same banner.'),
    'Tg0UxWYuPeJ0_438': ('matches_reference', 'none',
        'White printed text contains the full comment attributed to netizens.',
        'The white modifier and exact OCR string share one text entity. The wording inside the quote stays literal.'),
    'TbJqMFkNxARY_173': ('matches_reference', 'none',
        'The affected containers held imported goods including clothing, electronics and furniture.',
        'The goods and their examples are associated with one event involving the affected containers.'),
    'TQEmEycTI0RQ_835': ('partial', 'participant binding',
        'The speaker attributes Canada’s described crisis to Trump’s trade actions and threats to Canadian sovereignty.',
        'The declaration scope is kept. The sovereignty relation attaches to actions rather than threats, losing a causal argument detail.'),
    'TW4OYA3RN-Hw_1799': ('incorrect', 'participant binding',
        'The images depict protesters covering or surrounding a truck and raising batons and Nepali flags.',
        'Truck, batons and flags become one group argument for both cover and raise.'),
    'T2G_ACMxR_I4_1446': ('incorrect', 'numeric binding',
        'Blue Ghost’s speed is 135 km/h at 103 seconds before landing.',
        'The speed becomes a count of km/h entities and the offset becomes a group of time-unit members.'),
    'T3HTSBW42QaY_787': ('partial', 'temporal binding',
        'At 12:12:57 the crane lifts the same large white container from the boat onto the pier.',
        'The source, destination, lifted entity and event time survive. The clock is also incorrectly attached as a property of the pier.'),
    'TgPh_fzHTCm4_1493': ('partial', 'numeric binding',
        'Precipitable water values keep exceeding the threshold of 2 on July 4 and 5.',
        'The date phrase and exceed event survive, but the threshold is encoded as an entity named 2 without a numeric comparison value.'),
    'T1JQ-aG78Zuc_800': ('partial', 'reference binding',
        'The same tram approaches a man lying by the tracks while slowing substantially.',
        'The approach and slowdown are linked in time. The approach participant it is a different unresolved variable from the tram.'),
    'T1JQ-aG78Zuc_792': ('matches_reference', 'none',
        'The tram driver had the option of requesting a change manually via the board computer.',
        'Possibility and perfect aspect remain. The driver, change, manner and means are associated with the request.'),
    'T2EE72iNELEs_203': ('matches_reference', 'none',
        'The rocket decelerates into a calculated landing on the ocean.',
        'Deceleration leads into the described landing, which retains the ocean attachment.'),
    'TzzhcBIczf_M_2043': ('matches_reference', 'none',
        'The source claim as written assigns the described relationship to Shi Yongxin and says the group is numerous.',
        'The named participant and many modifier survive the translation. This judgment addresses wording only.'),
    'Tsuk2uoYj-kc_612': ('matches_reference', 'none',
        'The people in the description are climbing up a hill.',
        'Climb has the same people as actor and retains the hill and upward movement.'),
    'TgR_u37mCoQ4_1850': ('matches_reference', 'none',
        'On-screen text contains the quoted wildfire headline.',
        'The quote remains exact and is assigned to the OCR route without an independent fire event.'),
}

ALERT_REVIEWS = {
    'Tg0UxWYuPeJ0_373': 'The source distance 100m is encoded with mile as the unit.',
    'TzF9M4kZ3Pys_282': 'The account handle is absent.',
    'T2EE72iNELEs_183': 'The value and unit appear as a counted entity instead of a speed.',
    'T3HTSBW42QaY_775': 'Likely is a plain text adjunct without scope over the hazard.',
    'TjHepwuhkYFA_1027': 'Likely does not qualify the language in the program.',
    'TFgw4IaR9R8s_1746': 'Future is explicit and likelihood appears only as text.',
    'T2G_ACMxR_I4_1446': 'The number is represented as a count of km/h entities.',
}


def main():
    manifest = json.loads((RUN / 'sample.json').read_text())
    frozen = json.loads((RUN / 'warnings_frozen.json').read_text())
    assert hashlib.sha256((RUN / 'sample.json').read_bytes()).hexdigest() == frozen['sample_sha256']
    assert hashlib.sha256((ROOT / 'scripts/probabilistic_verification/benchmark_warnings.py').read_bytes()).hexdigest() == frozen['rule_sha256']
    sample = manifest['sample']
    assert {row['claim_id'] for row in sample} == REVIEWS.keys()
    assert set(frozen['alerts']) == ALERT_REVIEWS.keys()
    records = {r['claim_id']: r for r in rows(INPUTS)}
    by_bucket = defaultdict(Counter)
    by_issue = Counter()
    diagnostic_counts = Counter()
    reviewed = []
    for row in sample:
        cid = row['claim_id']
        output = row['output']
        assert hashlib.sha256(output['program'].encode()).hexdigest() == output['program_sha256']
        assert warnings(records[cid], output['compilation']) == frozen['alerts'].get(cid, [])
        verdict, issue, reading, reason = REVIEWS[cid]
        by_bucket[row['bucket']][verdict] += 1
        by_issue[issue] += 1
        old_warning = bool(output.get('code') or output.get('errors') or output.get('shared_checks'))
        diagnostic_counts['prior_flagged'] += old_warning
        if cid in frozen['alerts']:
            diagnostic_counts['sample_alerts'] += 1
            diagnostic_counts['sample_alerts_new_to_existing_checks'] += not old_warning
        reviewed.append(dict(
            claim_id=cid, text=row['text'], source_videos=row['source_videos'], stratum=row['stratum'],
            bucket=row['bucket'], stage=row['stage'], reading=reading, judgment=verdict, issue=issue,
            reason=reason, old_warning=old_warning, alerts=frozen['alerts'].get(cid, []),
            alert_review=ALERT_REVIEWS.get(cid), program_sha256=output['program_sha256'],
            compilation=output['compilation'], program=output['program'],
        ))
    strict = {r['claim_id']: r['output'] for r in rows(STRICT / 'corpus.jsonl')
              if r['parsing_status'] == 'compiled'}
    repairs = {r['claim_id']: r['result'] for r in json.loads((SCOPE / 'repairs.json').read_text())
               if r['after'] == 'semantic_program'}
    corpus_alerts = []
    num_checked = 0
    for row in rows(COVERAGE / 'corpus.jsonl'):
        cid = row['claim_id']
        if row['category'] == 'strict_baseline':
            output = strict[cid]
        elif cid in repairs:
            output = repairs[cid]
        elif row['category'] != 'dependencies':
            output = row['output']
        else:
            continue
        found = warnings(records[cid], output['compilation'])
        num_checked += 1
        if found:
            category = 'scope_repair' if cid in repairs else row['category']
            stage = 'source_scope_repair' if cid in repairs else row['chosen_stage']
            corpus_alerts.append(dict(claim_id=cid, text=row['text'], category=category,
                                      stage=stage, alerts=found))
    assert num_checked == 2358
    summary = dict(
        total=len(reviewed), source_groups=manifest['source_groups'], topics=manifest['topics'],
        judgments=dict(Counter(row['judgment'] for row in reviewed)), by_bucket=dict(by_bucket),
        issues=dict(by_issue), diagnostics=dict(diagnostic_counts), checked_corpus_programs=num_checked,
        flagged_corpus_programs=len(corpus_alerts),
        corpus_alert_codes=dict(Counter(alert['code'] for r in corpus_alerts for alert in r['alerts'])),
        policy='Source-diverse development benchmark audit. These are self-reviewed reference readings and saved candidate programs.',
        routing='Advisory only. No program or routing change. Keep the 2,375-claim evaluation inventory.',
    )
    dump(RUN / 'summary.json', summary)
    dump(RUN / 'benchmark.json', dict(
        use='Evaluation and benchmark development', label_kind='compiler meaning preservation',
        independence='Assistant review on a construction-stratified development sample.',
        media_truth_labels=False, records=reviewed,
    ))
    dump(RUN / 'warning_queue.json', corpus_alerts)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
