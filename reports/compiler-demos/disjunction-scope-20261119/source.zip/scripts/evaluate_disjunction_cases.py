"""Evaluate the frozen disjunction benchmarks and the five failure-only rewrites."""
import argparse
from itertools import product
import json

from generate_disjunction_rewrites import PREVIOUS, RUN
from prepare_compiler_fallback import ROOT, dump, rows
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.compiler_fallback import check_output, compile_claim, restore
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.fallback_amr import compile_fallback_amr, prepare_fallback
from probabilistic_verification.logic import Evidence, GroundProgram, Observation, canonical_key, ground
from probabilistic_verification.representation import STATES, Expression as Expr
from run_amr_types import inspect
from run_compiler_fallback import cached_rewrite
from sample_logical_form_review import INPUTS


def index(path):
    return {r['claim_id']: r for r in rows(path)}


def evaluate_compilers():
    folder = RUN / 'benchmark'
    references = json.loads((folder / 'references.json').read_text())
    records = index(folder / 'parsed.jsonl')
    amrs = {r['request']['task']['claim_id']: r['raw'] for r in rows(folder / 'amr.jsonl')}
    assert set(records) == set(amrs) == {r['claim_id'] for r in references}
    outputs = []
    for reference in references:
        cid = reference['claim_id']
        record = records[cid]['clauses'][0]['record']
        record = dict(record, claim_id=cid)
        assert reference['text'] == record['text']
        srl = check_output(record, compile_one(record))
        amr = check_output(record, inspect(record, amrs[cid], compiler=compile_fallback_amr,
                                           prepare=prepare_fallback))
        fixed = compile_claim(record, srl=lambda _: srl, amr=lambda _: amr)
        outputs.append(dict(reference, srl=srl, amr=amr, fixed=fixed))
    dump(folder / 'compilation.json', outputs)


def evaluate_rewrites():
    folder = RUN / 'rewrite'
    plan = json.loads((RUN / 'requests.json').read_text())
    ids = {r['claim_id'] for r in plan}
    source = {r['claim_id']: r for r in rows(INPUTS) if r['claim_id'] in ids}
    before = {r['claim_id']: r for r in rows(PREVIOUS / 'corpus.jsonl') if r['claim_id'] in ids}
    legacy = {r['claim_id']: r for r in rows(ROOT / 'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl')
              if r['claim_id'] in ids}
    parsed = index(folder / 'parsed.jsonl')
    generated = index(folder / 'raw.jsonl')
    assert set(parsed) == set(generated) == ids
    outputs = []
    for row in plan:
        cid = row['claim_id']
        record = source[cid]
        prior = before[cid]
        raw_graph = prior['attempts'][1]['raw']
        result = compile_claim(
            record, srl=compile_one,
            amr=lambda r: inspect(r, raw_graph, compiler=compile_fallback_amr, prepare=prepare_fallback),
            rewrite=lambda r, _: cached_rewrite(r, parsed[cid]),
        )
        assert len(result['attempts']) == 3
        assert [a.get('code') for a in result['attempts'][:2]] == [a.get('code') for a in prior['attempts'][:2]]
        earlier_sentences = [c['text'] for c in legacy.get(cid, {}).get('clauses', [])]
        outputs.append(dict(claim_id=cid, text=row['text'], prior_code=prior['attempts'][-1]['code'],
                            legacy_sentences=earlier_sentences, response=generated[cid],
                            proposal=parsed[cid]['proposal'], result=result))
    dump(folder / 'compilation.json', outputs)


def _at(key):
    return Expr.atom(key)


def _and(*args):
    return Expr.combine('and', args)


def _or(*args):
    return Expr.combine('or', args)


def native_checks():
    """Run supplied logical forms to check evidence behavior independently of parsing."""
    results = []

    def run(group, name, expression, states, expected):
        observations = {k: Observation(k, tuple(float(s == state) for s in STATES), False, k)
                        for k, state in states.items()}
        def replace_atoms(e):
            if e.op == 'atom':
                return Expr.atom(observations[e.atom_id].id)
            return Expr(e.op, tuple(replace_atoms(x) for x in e.children))
        program = GroundProgram(group + '-' + str(len(results)), replace_atoms(expression),
                                {o.id: o for o in observations.values()}, [], [])
        actual = DirectVerifier([program], learned=False,
                                program_builder=compact_prolog_program).predict()[0]['distribution']
        assert actual[expected] > 1 - 1e-10, (name, actual)
        results.append(dict(group=group, case=name, stipulated_evidence=states,
                            expected=expected, distribution=actual))

    a, b = _at('A'), _at('B')
    for exclusive, expression in (
        (False, _or(a, b)),
        (True, _and(_or(a, b), Expr.negate(_and(a, b)))),
    ):
        for left, right in product(STATES, repeat=2):
            if exclusive:
                expected = ('unknown' if 'unknown' in (left, right) else
                            'supported' if left != right else 'refuted')
            else:
                expected = ('supported' if 'supported' in (left, right) else
                            'refuted' if left == right == 'refuted' else 'unknown')
            run('Exclusion' if exclusive else 'Inclusive OR', f'A {left}, B {right}', expression,
                dict(A=left, B=right), expected)

    scope = _and(_at('guide spoke'), _at('utterance expresses the full disjunction'))
    for name, content_state, expected in (
        ('Full disjunction in the utterance', 'supported', 'supported'),
        ('Complete utterance only asserts A', 'refuted', 'refuted'),
        ('Incomplete transcript with A only', 'unknown', 'unknown'),
    ):
        run('Reported speech', name, scope,
            {'guide spoke': 'supported', 'utterance expresses the full disjunction': content_state},
            expected)

    shared = _and(_at('standing at noon'), _or(
        _and(_at('beside the truck'), _at('truck is red')),
        _and(_at('beside the van'), _at('van is blue'))))
    for name, time, red, blue, expected in (
        ('Red truck only at noon', 'supported', 'supported', 'refuted', 'supported'),
        ('Blue van only at noon', 'supported', 'refuted', 'supported', 'supported'),
        ('Both vehicles with swapped colors', 'supported', 'refuted', 'refuted', 'refuted'),
        ('Matching red truck with wrong time', 'refuted', 'supported', 'refuted', 'refuted'),
        ('Matching blue van with unknown time', 'unknown', 'refuted', 'supported', 'unknown'),
    ):
        run('Modifiers', name, shared,
            {'standing at noon': time, 'beside the truck': 'supported', 'truck is red': red,
             'beside the van': 'supported', 'van is blue': blue}, expected)
    dump(RUN / 'native_controls.json', results)
    print(f'{len(results)} native reference-form controls matched expected results.')


def compiled_controls():
    """Evaluate two actual compiled forms under constructed evidence."""
    cases = {r['claim_id']: r['fixed']['output']['compilation']
             for r in json.loads((RUN / 'benchmark/compilation.json').read_text())
             if r['claim_id'] in {'or_report_1', 'or_modifier_2'}}
    results = []
    for cid, label, predicate, state, expect in (
        ('or_report_1', 'Report condition supported, bridge clause unknown',
         lambda a: a.predicate == 'concept' and a.arguments[1] == 'close-01', 'unknown', 'supported'),
        ('or_modifier_2', 'Standing at noon unavailable in either branch',
         lambda a: a.predicate == 'stand' and any('At noon' in v for v in a.arguments), 'unknown', 'unknown'),
    ):
        claim = restore(cases[cid])
        values = {v.name: 'candidate:' + v.name for v in claim.variables}
        evidence = Evidence('constructed', {v: [x] for v, x in values.items()},
                            {v: True for v in values}, {})
        changed = 0
        for atom in claim.atoms:
            key = canonical_key(evidence.media_id, atom, values, evidence.route)
            hold = predicate(atom)
            changed += hold
            verdict = state if hold else 'supported'
            evidence.observations[key] = Observation(key, tuple(float(x == verdict) for x in STATES),
                                                     False, atom.text)
        assert changed > 0
        actual = DirectVerifier([ground(claim, evidence)], learned=False,
                                program_builder=compact_prolog_program).predict()[0]['distribution']
        assert actual[expect] > 1 - 1e-10, (label, actual)
        results.append(dict(claim_id=cid, case=label, modified_observations=changed,
                            distribution=actual, expected=expect))
    dump(RUN / 'compiled_controls.json', results)
    print(f'{len(results)} native controls on saved compiled forms completed.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=('benchmark', 'rewrite', 'native', 'compiled'))
    stage = parser.parse_args().stage
    {'benchmark': evaluate_compilers, 'rewrite': evaluate_rewrites, 'native': native_checks, 'compiled': compiled_controls}[stage]()


if __name__ == '__main__':
    main()
