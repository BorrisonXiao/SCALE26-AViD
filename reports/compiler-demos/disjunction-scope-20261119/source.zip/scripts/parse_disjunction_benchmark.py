"""Prepare the frozen text benchmark for the existing CPU parsers."""
import hashlib
import json

from generate_disjunction_rewrites import RUN
from prepare_compiler_fallback import dump
from probabilistic_verification.parsing import DependencyParser


def main():
    folder = RUN / 'benchmark'
    reference = folder / 'references.json'
    examples = json.loads(reference.read_text())
    assert len(examples) == len({e['claim_id'] for e in examples}) == 12
    parser = DependencyParser()
    annotations = []
    for row in examples:
        cid, text = row['claim_id'], row['text']
        record = dict(claim_id=cid, text=text, tokens=parser.parse(text), srl=None)
        annotations.append(dict(claim_id=cid, clauses=[dict(id='c1', text=text, record=record)]))
    (folder / 'dependencies.jsonl').write_text(
        ''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in annotations))
    dump(folder / 'dependency_provenance.json',
         dict(parser.provenance, reference_sha256=hashlib.sha256(reference.read_bytes()).hexdigest()))
    (folder / 'amr_inputs.jsonl').write_text(''.join(
        json.dumps(dict(claim_id=r['claim_id'], text=r['text']), ensure_ascii=False) + '\n'
        for r in examples))


if __name__ == '__main__':
    main()
