"""Package the exact cached inputs and judgments used for the logical-form review."""
import hashlib
import json
import zipfile

from logical_form_review_report import URL, DOWNLOADS
from sample_logical_form_review import ROOT, RUN, COVERAGE, INPUTS, SCOPE, STRICT, rows

OUTPUTS = ('sample.json', 'summary.json', 'benchmark.json', 'warning_queue.json')
DOC = ROOT / 'docs/logical_form_review_20261118.md'


def as_lines(records):
    return ''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records).encode()


def main():
    code = [
        ROOT / 'scripts' / name for name in
        ('prepare_compiler_fallback.py', 'sample_logical_form_review.py', 'review_logical_forms.py')
    ]
    code.extend((ROOT / 'scripts/probabilistic_verification').glob('*.py'))
    paths = [*code, ROOT / 'tests/test_benchmark_warnings.py']
    paths.extend(COVERAGE / n for n in ('audit.json', 'checked_forms.json', 'corpus.jsonl'))
    paths.extend(SCOPE / n for n in ('fidelity.json', 'repairs.json'))
    paths.extend(RUN / n for n in DOWNLOADS)
    data = {str(p.relative_to(ROOT)): p.read_bytes() for p in paths}
    data[str(INPUTS.relative_to(ROOT))] = as_lines(
        {key: r[key] for key in ('claim_id', 'text', 'source_videos', 'tokens')} for r in rows(INPUTS)
    )
    strict_corpus = STRICT / 'corpus.jsonl'
    data[str(strict_corpus.relative_to(ROOT))] = as_lines(
        {key: r[key] for key in ('claim_id', 'parsing_status', 'output')}
        for r in rows(strict_corpus) if r['parsing_status'] == 'compiled'
    )
    additions = STRICT / 'reviewed_additions.json'
    prior_ids = [{'claim_id': r['claim_id']} for r in json.loads(additions.read_text())]
    data[str(additions.relative_to(ROOT))] = json.dumps(prior_ids).encode()
    data['REPLAY_SHA256.json'] = json.dumps(
        {name: hashlib.sha256((RUN / name).read_bytes()).hexdigest() for name in OUTPUTS},
        indent=2,
    ).encode()
    data['README.md'] = DOC.read_bytes()

    target = ROOT / 'site/reports' / URL / 'source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in sorted(data.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
    print(f'Bundled {len(data)} files in {target.stat().st_size / 2**20:.2f} MiB.')


if __name__ == '__main__':
    main()
