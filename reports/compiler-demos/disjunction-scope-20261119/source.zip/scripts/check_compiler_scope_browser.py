"""Check the scope and binding sections and their links to prior case views."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import threading

from playwright.sync_api import sync_playwright
from prepare_compiler_fallback import ROOT
from run_compiler_scope_repairs import RUN


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


def main():
    site = ROOT / 'site'
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=str(site)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = f'http://127.0.0.1:{server.server_port}/reports/'
    try:
        with sync_playwright() as driver:
            browser = driver.chromium.launch(args=['--no-sandbox'])
            page = browser.new_page(viewport={'width': 1400, 'height': 960})
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto(url + 'compiler-demos.html#remaining-failures', wait_until='networkidle')
            assert '2,358/2,375' in page.locator('#current-work').inner_text()
            assert page.get_by_role('tab').count() == 5
            page.goto(url + 'compiler-demos.html#scope-repair-examples', wait_until='networkidle')
            assert page.locator('#scope-repair-examples article').count() == 4
            assert page.locator('#scope-repair-examples tbody tr').count() == 17
            page.locator('#scope-repair-examples details summary').first.click()
            assert 'condition' in page.locator('#scope-repair-examples details pre').first.inner_text()
            page.goto(url + 'compiler-demos.html#scope-fidelity', wait_until='networkidle')
            assert page.locator('#scope-fidelity tbody').last.locator('tr').count() == 32
            page.goto(url + 'compiler-demos.html#binding-contrasts', wait_until='networkidle')
            assert page.locator('#binding-contrasts tbody tr').count() == 5
            assert 'sunrise' in page.locator('#binding-contrasts').inner_text()
            page.screenshot(path=str(RUN / 'binding-report.png'))
            page.goto(url + 'compiler-demos.html?coverage_claim=TFgw4IaR9R8s_1639#coverage-cases',
                      wait_until='networkidle')
            assert 'The ruling means' in page.locator('#coverage-text').inner_text()
            assert page.locator('#coverage-case option').count() == 198
            page.goto(url + 'compiler-demos.html#earlier-coverage', wait_until='networkidle')
            assert page.locator('#history').is_visible()
            assert '2,354/2,375' in page.locator('#history').inner_text()
            page.set_viewport_size({'width': 390, 'height': 844})
            page.emulate_media(color_scheme='dark')
            for fragment in ('remaining-failures', 'scope-repair-examples', 'scope-fidelity', 'binding-contrasts'):
                page.goto(url + 'compiler-demos.html#' + fragment, wait_until='networkidle')
                assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'), fragment
            page.goto(url + 'verification-pipeline.html#next-steps', wait_until='networkidle')
            assert '2,358/2,375' in page.locator('#next-steps').inner_text()
            page.goto(url, wait_until='networkidle')
            assert page.locator('.card-link').count() == 2
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()
    print('Four repairs, 17 residual cases, 32 reviews, five pairs, prior views and mobile navigation pass.')


if __name__ == '__main__':
    main()
