"""Package the cached OR comparison inputs for exact replay."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from disjunction_repairs_report import ROOT, RUN, STRICT, URL
from prepare_compiler_fallback import BASE, rows
from sample_logical_form_review import INPUTS

PIER = 'Txf2EdqOg1SQ_2166'


def lines(records):
    return ''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records).encode()


def baseline_signatures():
    for r in rows(STRICT / 'corpus.jsonl'):
        output = r['output']
        yield dict(claim_id=r['claim_id'], selected_stage=r['selected_stage'],
                   output={'program_sha256': output['program_sha256']} if output else None,
                   attempts=[{k: a[k] for k in ('stage', 'code', 'status') if k in a} for a in r['attempts']])


def main():
    paths = [INPUTS, RUN / 'control/parsed.jsonl', RUN / 'comparison.json',
             RUN.with_name('compiler_or_audit_20261119') / 'audit.json',
             ROOT / 'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl',
             STRICT / 'missing_rewrites/parsed.jsonl', STRICT / 'missing_rewrites/routing.json',
             ROOT / 'tests/test_amr_operators.py', ROOT / 'tests/test_rewrite_disjunction.py']
    for folder in ('scripts', 'scripts/probabilistic_verification', 'scripts/probabilistic_verification/resources'):
        paths.extend(p for p in (ROOT / folder).glob('*') if p.is_file() and p.suffix in {'.py', '.json'})
    bundle = {str(p.relative_to(ROOT)): p.read_bytes() for p in paths}
    bundle[str((BASE / 'corpus.jsonl').relative_to(ROOT))] = lines(
        dict(claim_id=r['claim_id'], raw=r['raw']) for r in rows(BASE / 'corpus.jsonl'))
    bundle[str((STRICT / 'corpus.jsonl').relative_to(ROOT))] = lines(baseline_signatures())
    bundle[str((STRICT / 'amr_attempts.jsonl').relative_to(ROOT))] = lines(
        dict(claim_id=PIER, raw=r['raw']) for r in rows(STRICT / 'amr_attempts.jsonl') if r['claim_id']==PIER)
    bundle['README.md'] = (ROOT / 'docs/disjunction_repairs_20261119.md').read_bytes()
    bundle['REPLAY_SHA256.json'] = json.dumps(
        {'comparison.json': sha256((RUN / 'comparison.json').read_bytes()).hexdigest()}, indent=2).encode()
    target = ROOT / 'site/reports' / URL / 'source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(target, 'w', compression=ZIP_DEFLATED) as archive:
        for name, data in sorted(bundle.items()):
            member = ZipInfo(name, date_time=(2026,11,19,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, data)
    print(f'Bundled {len(bundle)} files in {target.stat().st_size / 2**20:.2f} MiB.')


if __name__ == '__main__':
    main()
