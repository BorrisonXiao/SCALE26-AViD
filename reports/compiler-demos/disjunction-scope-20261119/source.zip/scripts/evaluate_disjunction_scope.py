"""Run the frozen OR cases and a source-aligned shared-relative-clause control."""
import argparse
from collections import Counter
import hashlib
import itertools
import json

from generate_disjunction_rewrites import PREVIOUS, RUN as EVALUATION
from prepare_compiler_fallback import ROOT, dump, rows
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.compiler_fallback import check_output, compile_claim, restore
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.fallback_amr import compile_fallback_amr, prepare_fallback
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.representation import STATES
from run_amr_types import inspect
from run_compiler_fallback import cached_rewrite
from sample_logical_form_review import INPUTS

RUN = PREVIOUS.with_name('disjunction_scope_20261119')


def load(path):
    return json.loads(path.read_text())


def by_id(records):
    return {row['claim_id']: row for row in records}


def run_amr(record, raw):
    return inspect(record, raw, compiler=compile_fallback_amr, prepare=prepare_fallback)


def benchmark():
    folder = EVALUATION / 'benchmark'
    references = load(folder / 'references.json')
    assert hashlib.sha256((folder / 'references.json').read_bytes()).hexdigest() == load(
        folder / 'dependency_provenance.json')['reference_sha256']
    parsed = by_id(rows(folder / 'parsed.jsonl'))
    graphs = {r['request']['task']['claim_id']: r['raw'] for r in rows(folder / 'amr.jsonl')}
    cases = []
    for reference in references:
        cid = reference['claim_id']
        record = dict(parsed[cid]['clauses'][0]['record'], claim_id=cid)
        srl = check_output(record, compile_one(record))
        amr = check_output(record, run_amr(record, graphs[cid]))
        fixed = compile_claim(record, srl=lambda _: srl, amr=lambda _: amr)
        cases.append(dict(reference, srl=srl, amr=amr, fixed=fixed))
    dump(RUN / 'benchmark.json', cases)

    shared = RUN / 'shared_control'
    original = rows(shared / 'original/parsed.jsonl')[0]
    record = dict(original['clauses'][0]['record'], claim_id=original['claim_id'])
    rewritten = rows(shared / 'rewrite/parsed.jsonl')[0]

    def simulated_refusal(_):
        return dict(status='unsupported', code='controlled_failure', reason='Exercise the rewrite path.')

    result = compile_claim(record, srl=simulated_refusal, amr=simulated_refusal,
                           rewrite=lambda r, _: cached_rewrite(r, rewritten))
    assert result['selected_stage'] == 'rewrite'
    bad = rows(shared / 'negative/parsed.jsonl')[0]
    refused = compile_claim(record, srl=simulated_refusal, amr=simulated_refusal,
                            rewrite=lambda r, _: cached_rewrite(r, bad))
    assert refused['attempts'][-1]['code'] == 'rewrite_shared_condition_scope'
    dump(RUN / 'shared_control.json', dict(result=result,
         rewritten=dict(sentences=[c['text'] for c in rewritten['clauses']], formula=rewritten['proposal']['formula']),
         comparison=refused['attempts'][-1]))


def native():
    cases = {row['claim_id']: row['fixed']['output'] for row in load(RUN / 'benchmark.json')}
    ctl = load(RUN / 'shared_control.json')
    cases['or_shared_relative'] = ctl['result']['output']
    results = []

    def run(cid, label, expected, policy, *, domains=None, observation_route=None):
        claim = restore(cases[cid]['compilation'])
        candidates = {v.name: ['candidate:' + v.name] for v in claim.variables}
        candidates.update(domains or {})
        evidence = Evidence('or-control', candidates, dict.fromkeys(candidates, True), {})
        var_names = set(candidates)
        for atom in claim.atoms:
            args = sorted(var_names & set(atom.arguments))
            for values in itertools.product(*(candidates[v] for v in args)):
                assignment = dict(zip(args, values))
                state = policy(atom, assignment)
                if state is None:
                    continue
                route = (observation_route or 'speech_assertion') if atom.predicate == 'reported_disjunction' else evidence.route
                key = canonical_key(evidence.media_id, atom, assignment, route)
                evidence.observations[key] = Observation(key, tuple(float(s == state) for s in STATES),
                                                         False, atom.text)
        program = ground(claim, evidence)
        actual = DirectVerifier([program], learned=False, program_builder=compact_prolog_program).predict()[0]['distribution']
        assert actual[expected] > 1-1e-10, (cid, label, expected, actual)
        results.append(dict(claim_id=cid, case=label, expected=expected, distribution=actual))

    for cid, test in (
        ('or_exclusion_1', lambda a: a.predicate == 'stand'),
        ('or_exclusion_2', lambda a: a.predicate == 'show'),
        ('or_exclusion_3', lambda a: a.predicate == 'state_at'),
    ):
        atoms = [a.id for a in restore(cases[cid]['compilation']).atoms if test(a)]
        assert len(atoms) == 2
        for pair, label, expected in (
            (('supported','refuted'), 'One alternative supported', 'supported'),
            (('refuted','supported'), 'The other alternative supported', 'supported'),
            (('supported','supported'), 'Both alternatives supported', 'refuted'),
            (('supported','unknown'), 'One supported, one unknown', 'unknown'),
            (('refuted','refuted'), 'Both alternatives refuted', 'refuted'),
        ):
            states = dict(zip(atoms, pair))
            run(cid, label, expected, lambda a,_: states.get(a.id, 'supported'))
    run('or_exclusion_3', 'One physical candidate reused for both doors', 'refuted',
        lambda a,_: ('refuted' if a.predicate=='state_at' and a.arguments[0]=='X2' else 'supported'),
        domains={'X1':['same door'], 'X2':['same door']})
    run('or_exclusion_4', 'Inclusive control with both doors open', 'supported', lambda a,_: 'supported')

    report = restore(cases['or_report_1']['compilation'])
    assert [a.predicate for a in report.atoms].count('reported_disjunction') == 1
    assert not any(a.predicate == 'concept' and a.arguments[1] in {'open-01','close-01'} for a in report.atoms)
    for label, observation, expected in (
        ('Complete utterance expresses OR', 'supported', 'supported'),
        ('Complete utterance only states one alternative', 'refuted', 'refuted'),
        ('Transcript is incomplete', None, 'unknown'),
    ):
        run('or_report_1', label, expected,
            lambda a,_: observation if a.predicate=='reported_disjunction' else 'supported')
    run('or_report_1', 'Visual evidence alone', 'unknown', lambda a,_: 'supported',
        observation_route='visual_depiction')
    run('or_modifier_3', 'Shared vehicle color refuted', 'refuted',
        lambda a,_: 'refuted' if a.predicate=='concept' and a.arguments[1]=='red-02' else 'supported')
    run('or_modifier_4', 'Shared time refuted', 'refuted',
        lambda a,_: 'refuted' if a.predicate=='concept' and a.arguments[1]=='noon' else 'supported')

    claim = restore(cases['or_shared_relative']['compilation'])
    near = next(a for a in claim.atoms if a.predicate == 'try')
    block = next(a for a in claim.atoms if a.predicate == 'block')
    truck = near.arguments[near.arguments.index('ARGM-LOC') + 1]
    assert block.arguments[block.arguments.index('ARG0') + 1] == truck
    run('or_shared_relative', 'One movement can establish the attempted alternative', 'supported',
        lambda a,_: 'refuted' if a.predicate=='stand' else 'supported')
    run('or_shared_relative', 'Relative clause evidence missing', 'unknown',
        lambda a,_: None if a.predicate=='block' else 'supported')
    run('or_shared_relative', 'Near one truck and the other truck blocks the path', 'refuted',
        lambda a,v: 'refuted' if ((a.predicate=='try' and v[truck]=='truck-b')
                                 or (a.predicate=='block' and v[truck]=='truck-a')) else 'supported',
        domains={truck:['truck-a','truck-b']})
    dump(RUN / 'native.json', results)
    print(f'{len(results)} native controls on generated forms passed.')


def compare():
    prior = by_id(rows(PREVIOUS / 'corpus.jsonl'))
    after = by_id(rows(RUN / 'corpus.jsonl'))
    assert len(prior) == 2375 and prior.keys() == after.keys()
    counts = Counter()
    changes = []
    for cid, row in after.items():
        before = prior[cid]
        old, new = (r['output'] for r in (before, row))
        counts['before'] += bool(old)
        counts['after'] += bool(new)
        if old and new and old['program_sha256'] == new['program_sha256']:
            counts['identical_programs'] += 1
            continue
        if not (old or new):
            continue
        kind = 'changed_programs' if old and new else 'added' if new else 'removed'
        counts[kind] += 1
        changes.append(dict(claim_id=cid, text=row['text'], kind=kind,
                            before=before['selected_stage'], after=row['selected_stage'],
                            old_output=old, new_output=new, diagnosis=row['attempts'][-1].get('reason')))
    rewrite_ids = {r['claim_id'] for r in load(EVALUATION / 'requests.json')}
    probes = []
    for cid in sorted(rewrite_ids):
        case = after[cid]
        probes.append(dict(claim_id=cid, text=case['text'], selected=case['selected_stage'],
                           last_status=case['attempts'][-1]['status'],
                           code=case['attempts'][-1].get('code'),
                           reason=case['attempts'][-1].get('reason')))
    dump(RUN / 'comparison.json', dict(counts=counts, total=2375, changes=changes, rewrite_cases=probes))
    print(dict(counts))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=('benchmark','native','compare'))
    {'benchmark': benchmark, 'native': native, 'compare': compare}[parser.parse_args().stage]()
