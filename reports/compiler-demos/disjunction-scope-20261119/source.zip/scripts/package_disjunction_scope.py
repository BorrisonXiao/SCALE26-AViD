"""Package the frozen inputs for replay of the OR scope repairs."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from disjunction_scope_report import URL
from evaluate_disjunction_scope import EVALUATION, INPUTS, PREVIOUS, ROOT, RUN
from prepare_compiler_fallback import BASE, RUN as STRICT, rows

REPLAY = ('benchmark.json', 'shared_control.json', 'native.json', 'comparison.json', 'evaluation.json')


def lines(records):
    return ''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records).encode()


def main():
    paths = [INPUTS, ROOT / 'tests/test_disjunction_scope.py',
             ROOT / 'docs/disjunction_scope_20261119.md',
             ROOT / 'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl',
             STRICT / 'missing_rewrites/parsed.jsonl', STRICT / 'missing_rewrites/routing.json']
    paths.extend(EVALUATION / n for n in (
        'benchmark/references.json', 'benchmark/dependency_provenance.json', 'benchmark/reviews.json',
        'benchmark/parsed.jsonl', 'benchmark/amr.jsonl', 'rewrite/parsed.jsonl', 'requests.json'))
    paths.extend(RUN / name for name in ('reviews.json', *REPLAY))
    for name in ('original','rewrite','negative'):
        paths.extend((RUN / 'shared_control' / name / filename) for filename in
                     ('raw.jsonl', 'parsed.jsonl', 'dependency_provenance.json','srl_provenance.json'))
    for folder in ('scripts', 'scripts/probabilistic_verification', 'scripts/probabilistic_verification/resources'):
        paths.extend(p for p in (ROOT / folder).glob('*')
                     if p.is_file() and p.suffix in {'.py', '.json'})
    data = {str(p.relative_to(ROOT)): p.read_bytes() for p in paths}
    data[str((BASE / 'corpus.jsonl').relative_to(ROOT))] = lines(
        dict(claim_id=r['claim_id'], raw=r['raw']) for r in rows(BASE / 'corpus.jsonl'))
    old = PREVIOUS / 'corpus.jsonl'
    data[str(old.relative_to(ROOT))] = lines(
        dict(claim_id=r['claim_id'], selected_stage=r['selected_stage'],
             output={'program_sha256': r['output']['program_sha256']} if r['output'] else None)
        for r in rows(old))
    data['README.md'] = (ROOT / 'docs/disjunction_scope_20261119.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps(
        {n: sha256((RUN / n).read_bytes()).hexdigest() for n in REPLAY}, indent=2).encode()
    target = ROOT / 'site/reports' / URL / 'source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(target, 'w', compression=ZIP_DEFLATED) as archive:
        for name, contents in sorted(data.items()):
            member = ZipInfo(name, date_time=(2026,11,19,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, contents)
    print(f'Bundled {len(data)} files for clean replay.')


if __name__ == '__main__':
    main()
