import torch

from cache_speech_option_alignment import WIDTH, option_input
from train_speech_option_alignment import OptionClassifier


def test_option_offsets_mark_distinct_occurrences_of_overlapping_phrases():
    options = ['using two sensors','using two sensors with a controller']
    text,bounds = option_input(options,'replacement','in the two-sensor trial')
    assert [text[a:b] for a,b in bounds] == options
    assert bounds[0][1] < bounds[1][0]
    assert 'in the two-sensor trial' in text


def test_attention_and_uniform_comparison_ignore_padded_tokens():
    torch.manual_seed(1)
    pooled = torch.randn(1,768)
    options = torch.randn(1,2,WIDTH)
    tokens = torch.randn(1,4,WIDTH)
    mask = torch.tensor([[True,True,False,False]])
    changed = tokens.clone()
    changed[:,2:] = torch.randn_like(changed[:,2:])*50.
    for mode in ('uniform','attention'):
        model = OptionClassifier(mode,768).eval()
        with torch.inference_mode():
            assert torch.allclose(model(pooled,options,tokens,mask),model(pooled,options,changed,mask))
