# Broader speech training and option alignment

## Data and controls

We extended the earlier 104 AMI training examples with 120 manually reviewed examples from 30 ICSI reports in 21 meetings. The added recordings cover two meeting groups, one on dialogue systems and one on speech robustness. All fitted heads use 94 calibration examples. These are the earlier 62 AMI examples and 32 new examples from three ICSI networking meetings. The new evaluation uses 60 queries from 15 reports across 10 ICSI meeting-recording and transcription meetings. The ICSI meeting-group prefixes are disjoint across the three sets. Individual speakers can recur across groups. The other evaluation is the previously published 86-query AMI benchmark, whose queries stay outside fitting and calibration. [ICSI corpus](https://groups.inf.ed.ac.uk/ami/icsi/) · [AMI preparation](https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#speech-training-examples)

Each ICSI report has a reference claim, a supported paraphrase, an edit that changes a detail, and an edit that changes the relation or reverses its direction. The excerpts come from manual timed transcripts. The implementing assistant wrote and reviewed the annotations before scoring. Comments about support concern the reported text. Follow-up review of 17 disagreements found two source groups that merit another look at scope. One utterance uses “I guess” when describing a combined adaptation. Another asks a question framed around a possible requirement to speak rather than gesture. Dropping the two groups in a secondary check gives 43/52 for frozen Qwen, 41/52 for the pooled head, 36/52 for uniform token averages, and 38/52 for attention (seed 17). The full 60 cases remain the main test. [Official ICSI transcript archive](https://groups.inf.ed.ac.uk/ami/ICSICorpusAnnotations/ICSI_original_transcripts.zip) · [Corpus license](https://groups.inf.ed.ac.uk/ami/icsi/license.shtml)

## Models

All learned heads start from the same frozen DeBERTa cross-encoder. Its input pairs a transcript excerpt with the relation, the two ordered option phrases, and any qualifier. We cache one 768-dimensional vector for the whole pair. We additionally cache transcript token vectors and the means of the token vectors for each option, projected to 128 values by a fixed random matrix with seed 1729. This projection reduces cache size. It uses no labels. The two token heads project the option and transcript vectors to 32 values and compare each option to a transcript representation. One uses the same uniform transcript mean for both options. The other learns a separate weighted average from the dot products with each option. Both add the resulting comparison to the pooled vector. Both use 75,969 trainable parameters. The pooled neural head uses 50,817 and logistic regression uses 769.

All neural heads use a 64-unit hidden layer, GELU, dropout 0.1, and 280 AdamW updates with batches of up to 24. The seeds are 17, 23, and 41, learning rate 0.002, and weight decay 0.02. All calibration uses the separate 94 examples. Each head has one temperature fitted to its logits. The main frozen baseline uses the Qwen relation score with a frozen DeBERTa full-claim score. We also apply the same temperature-fitting procedure to the frozen relation score. In the main comparison we multiply those probabilities within the same eligible speaker and time span and decide at 0.5. This models the two scores as independent observations. The fresh test gives one annotated candidate span per query. All 876 DeepProbLog support probabilities for the three main learned heads agree with the direct calculation. The baseline ran on one L40S for 122 seconds. Learning ran on CPU. All 717 tests pass.

## Results and cutoff check

| Method | Training | AMI correct | ICSI correct |
| --- | --- | ---: | ---: |
| Frozen whole claim | Frozen | 71/86 | 42/60 |
| Frozen Qwen with whole claim | Frozen | 80/86 | 50/60 |
| Frozen Qwen with temperature and whole claim | Frozen | 80/86 | 50/60 |
| Logistic | AMI | 76/86 | 45/60 |
| Pooled neural head | AMI | 76–78/86 | 46–48/60 |
| Option attention | AMI | 74–78/86 | 45–47/60 |
| Logistic | AMI and ICSI | 77/86 | 46/60 |
| Pooled neural head | AMI and ICSI | 73–76/86 | 45–47/60 |
| Uniform token averages | AMI and ICSI | 75–76/86 | 41–46/60 |
| Option attention | AMI and ICSI | 73–76/86 | 42–44/60 |

The training expansion shifts the balance between accepting valid reports and rejecting edits. On the ICSI test, the expanded attention heads give false support to six of the 30 negative queries per run and support 18–20 of 30 positives. The frozen scorer gives false support to seven negatives and supports 27 positives. The frozen combination ranks both supported versions above both edits for 13 of 15 reports, compared with 12 for the pooled head, 11 for uniform token averages, and 10 for attention at seed 17. One detail the learned heads catch is a substitution of English proficiency for the variety of English a person speaks. A failure is the valid contrast between a high beep and a low beep.

We then tested whether a cutoff on the product causes the misses. A two-parameter mapping calibrates the raw product per span, keeping the same speaker and time match. We fit the mapping only on the 94 calibration examples. For ICSI this moves attention at seed 17 from 42 to 46 correct. Valid support increases from 18 to 27, and false support increases from six to eleven. The pooled head reaches 48/60, and the recalibrated frozen score also reaches 48/60. The original frozen comparison gives 50/60. On AMI, the corresponding after-product scores are 72/86 for attention, 76/86 for the pooled head, 77/86 for logistic, and 78/86 for the frozen score, with the original frozen result at 80/86. The diagnostic uses the same primary seed 17. The test provides a reason to keep the original frozen speech scorer for the next evidence-selection experiment.

## Next steps

- Test the same claims with annotated and automatically selected evidence windows. The goal is to measure how often a missing or partial transcript span matters more than changing the relation classifier.
- Compare a short window of neighboring frames with one frame on the existing occlusion examples. The goal is to check whether an additional view supplies the missing evidence and supports the same object identity.

## Replay

The archive contains the checked excerpts, split files, frozen features, scorer outputs, learned weights, and inference programs. The source archive and model checkpoints are separate downloads. Offline replay uses the cached features and scores. Use Python 3.12, NumPy 2.2.6, SciPy 1.17.1, PyTorch 2.10.0 and the bundled requirements.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python scripts/prepare_icsi_option_examples.py build
python scripts/cache_speech_option_alignment.py prepare
python scripts/train_speech_option_alignment.py
python scripts/evaluate_speech_option_alignment.py
python scripts/calibrate_speech_combined_score.py evaluate
python scripts/speech_option_alignment_report.py
python -m pytest -q tests/test_speech_option_alignment.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/speech_option_alignment_20261127')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```
