"""Check whether calibrating the product recovers supported reports."""
from argparse import ArgumentParser
from collections import defaultdict
from math import prod

import numpy as np

from cache_speech_option_alignment import RUN, validated_inputs
from calibrate_ami_speech_scores import calibrated, fit, probabilities
from evaluate_ami_speech_scoring import MODELS
from evaluate_reported_or_transcripts import score_pairs
from evaluate_speech_option_alignment import key
from evaluate_speech_relation_classifier import metrics
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read

METHODS = ('frozen_qwen','expanded_logistic_0','expanded_pooled_17','expanded_uniform_17','expanded_attention_17')


def score():
    pairs = {(r['evidence']['text'],r['claim']) for r in validated_inputs() if r['split']=='calibration'}
    dump(RUN/'calibration_nli.json',score_pairs(pairs,MODELS['deberta']))


def evaluate():
    rows = validated_inputs()
    initial = read(RUN/'evaluation.json')
    cal = [r for r in rows if r['split']=='calibration']
    raw_qwen = {(s['evidence'],*s['options'],s['relation']):s['probabilities'][0] for s in read(RUN/'qwen.json')['records']}
    content = probabilities(RUN/'calibration_nli.json')
    with np.load(RUN/'scores.npz',allow_pickle=False) as array:
        learners = {m:array[m][:,0] for m in METHODS if m!='frozen_qwen'}
    calibration = {}
    for method in METHODS:
        values = []
        for r in cal:
            whole = content[r['evidence']['text'],r['claim']]['entailment']
            relation = raw_qwen[key(r)] if method=='frozen_qwen' else learners[method][r['feature_id']]
            values.append(dict(expected_support=r['supported'],scores=dict(entailment=whole*float(relation))))
        calibration[method] = fit(values)
    identifiers = defaultdict(list)
    for r in rows:
        if r['split']=='test':
            identifiers[r.get('case_id',r['id'])].append(r)
    output = {}
    instances = {}
    for corpus,cases in initial['rows'].items():
        scores = []
        for c in cases:
            loc = identifiers[c['id']]
            by_method = {}
            assert [r['evidence']['id'] for r in loc]==[w['id'] for w in c['windows']]
            for m in METHODS:
                product = []
                for w,r in zip(c['windows'],loc,strict=True):
                    if not all(w['checks'].values()):
                        continue
                    if m!='frozen_qwen':
                        relation = learners[m][r['feature_id']]
                    elif corpus=='AMI':
                        relation = w['scores']['option_relation']
                    else:
                        relation = raw_qwen[key(r)]
                    p = float(relation)*w['scores']['whole_claim']
                    product.append(calibrated(p,calibration[m]))
                by_method[m] = 1.-prod(1.-p for p in product)
            scores.append(dict(id=c['id'],support=c['expected_support'],scores=by_method))
        output[corpus] = {m:metrics([r['support'] for r in scores],[r['scores'][m] for r in scores]) for m in METHODS}
        instances[corpus] = scores
    dump(RUN/'combined_calibration.json',dict(calibration_size=len(cal),parameters=calibration,benchmark=output,cases=instances))
    print({k:{m:(v['correct'],v['true_support'],v['false_support']) for m,v in p.items()} for k,p in output.items()},flush=True)


if __name__=='__main__':
    p = ArgumentParser()
    p.add_argument('stage',choices=('score','evaluate'))
    {'score':score,'evaluate':evaluate}[p.parse_args().stage]()
