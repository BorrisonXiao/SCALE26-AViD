"""Archive the trained heads, frozen features and exact logic outputs."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from cache_speech_classifier_features import BENCHMARK_FILE
from speech_relation_classifier_report import DATA, ROOT, RUN, URL

OUTPUTS = ('logistic.npz','mlp.npz','logistic_training.json','mlp_training.json',
           'logistic_evaluation.json','logistic_evaluation.pl','evaluation.json','evaluation.pl','summary.json')


def main():
    paths = [ROOT/name for name in ('requirements-compilation.txt','requirements-verification.txt',
                                   'tests/test_speech_relation_classifier.py')]
    paths.extend(RUN/name for name in (*OUTPUTS,'benchmark_features.npy','benchmark_features_index.json',
                                      'claim_only_features.npy','claim_only_features_index.json','tests.xml'))
    paths.extend(DATA/name for name in ('train.jsonl','calibration.jsonl','features.npy','features_index.json'))
    paths.append(BENCHMARK_FILE)
    prior = ROOT/'site/reports/compiler-demos/speech-relation-training-20261127/source.zip'
    with ZipFile(prior) as archive:
        paths.extend(ROOT/name for name in archive.namelist() if name.startswith('scripts/'))
    paths.extend(ROOT/'scripts'/f'{name}.py' for name in ('cache_speech_classifier_features',
                 'train_speech_relation_classifier','evaluate_speech_relation_classifier',
                 'speech_relation_classifier_report','package_speech_relation_classifier'))
    data = {str(path.relative_to(ROOT)):path.read_bytes() for path in paths}
    data['README.md'] = (ROOT/'docs/speech_relation_classifier_20261127.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({name:sha256((RUN/name).read_bytes()).hexdigest()
                                            for name in OUTPUTS},indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(exist_ok=True,parents=True)
    with ZipFile(target,'w') as archive:
        for name,contents in sorted(data.items()):
            member = ZipInfo(name,date_time=(2026,11,27,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member,contents)
    print(f'Archived {len(data)} files for replay.')


if __name__ == '__main__':
    main()
