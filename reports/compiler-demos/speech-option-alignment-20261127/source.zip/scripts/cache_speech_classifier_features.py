"""Cache the evaluation inputs and the claim-only control for the speech pilot."""
import numpy as np

from cache_speech_relation_features import encode_pairs, read_pairs
from prepare_compiler_fallback import dump
from prepare_option_binding import CONTRAST, DENY, REPLACE, RUN as BENCHMARK
from prepare_or_source_evaluation import read
from prepare_speech_relation_training import RUN as DATA, ROOT, digest, render

RUN = DATA.with_name('speech_relation_classifier_20261127')
BENCHMARK_FILE = BENCHMARK/'speech_evaluation.json'


def relation_text(case):
    a,b = case['options']
    relation = case['relation']
    if relation == CONTRAST:
        return render((a,b),'alternatives','')
    if relation == REPLACE:
        return f'The speaker proposes or prefers {a} in place of {b}.'
    if relation == DENY:
        return f'The speaker denies that {a} should replace {b}.'
    raise ValueError(f'Unknown reference relation {relation!r}')


def benchmark_rows():
    return [(row['split'], row['meeting'], case) for row in read(BENCHMARK_FILE)['rows'] for case in row['cases']]


def save(name, keys, pairs, views, source):
    features, info = encode_pairs(pairs, views)
    target = RUN/f'{name}.npy'
    np.save(target,features,allow_pickle=False)
    dump(RUN/f'{name}_index.json', dict(rows=keys, **info, input_sha256=source, feature_sha256=digest(target)))
    print(f'{name}: {features.shape}, from {info["unique_inputs"]} unique input pairs.', flush=True)


def main():
    RUN.mkdir(parents=True,exist_ok=True)
    keys, pairs = read_pairs()
    save('claim_only_features', keys, [(('',relation[1]),) for _,relation in pairs], ('claim_only',),
         {split:digest(DATA/f'{split}.jsonl') for split in ('train','calibration')})
    keys, pairs = [], []
    for _,_,case in benchmark_rows():
        target = relation_text(case)
        for w in case['windows']:
            text = w['text']
            pairs.append(((text,case['content']),(text,target),('',target)))
            keys.append(dict(case=case['id'], span=w['id']))
    save('benchmark_features', keys, pairs, ('claim','relation','claim_only'), digest(BENCHMARK_FILE))


if __name__ == '__main__':
    main()
