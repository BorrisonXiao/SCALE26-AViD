"""Fit matched pooled, uniform, and option-attention speech classifiers."""
from argparse import ArgumentParser
from itertools import islice
from math import sqrt

import numpy as np
from scipy.special import expit
import torch
from torch import nn

from cache_speech_option_alignment import RUN, WIDTH, validated_inputs
from prepare_compiler_fallback import dump
from prepare_icsi_option_examples import digest
from prepare_or_source_evaluation import read
from train_speech_relation_classifier import fit_logistic, learn_standardizer, report_weights, temperature

HIDDEN = 64
MATCH_DIM = 32
UPDATES = 280
BATCH = 24
LR = 0.002
WEIGHT_DECAY = 0.02
SEEDS = (17,23,41)
CONFIGURATIONS = {
    'ami': ('logistic','pooled','attention'),
    'expanded': ('logistic','pooled','uniform','attention'),
}


class Features:
    def __init__(self):
        path = RUN/'features.npz'
        meta = read(RUN/'features.json')
        assert meta['feature_sha256']==digest(path)
        assert meta['input_sha256']==digest(RUN/'inputs.json')
        with np.load(path,allow_pickle=False) as data:
            self.pool,self.tokens,self.options,self.offsets,self.lookup=(data[k] for k in ('pooled','tokens','options','offsets','lookup'))

    def batch(self, indices, with_tokens):
        lookup = self.lookup[indices]
        pooled = torch.from_numpy(self.pool[lookup])
        if not with_tokens:
            return pooled,None,None,None
        starts,ends = self.offsets[lookup],self.offsets[lookup+1]
        lengths = ends-starts
        mask = np.arange(lengths.max())[None,:]<lengths[:,None]
        padded = np.zeros((*mask.shape,WIDTH),np.float32)
        for i,(start,end) in enumerate(zip(starts,ends,strict=True)):
            padded[i,:end-start] = self.tokens[start:end]
        return pooled,torch.from_numpy(self.options[lookup]),torch.from_numpy(padded),torch.from_numpy(mask)


class OptionClassifier(nn.Module):
    def __init__(self, mode, pooled_dim):
        super().__init__()
        self.mode = mode
        self.pooled_norm = nn.LayerNorm(pooled_dim)
        if mode!='pooled':
            self.option_norm = nn.LayerNorm(WIDTH)
            self.token_norm = nn.LayerNorm(WIDTH)
            self.option_map = nn.Linear(WIDTH,MATCH_DIM)
            self.token_map = nn.Linear(WIDTH,MATCH_DIM)
        width = pooled_dim if mode=='pooled' else pooled_dim+MATCH_DIM*8
        self.head = nn.Sequential(nn.Linear(width,HIDDEN),nn.GELU(),nn.Dropout(0.1),nn.Linear(HIDDEN,1))

    def compare(self, options, tokens, mask):
        q = self.option_map(self.option_norm(options))
        k = self.token_map(self.token_norm(tokens))
        if self.mode=='attention':
            scores = (q @ k.transpose(1,2))/sqrt(MATCH_DIM)
            w = torch.softmax(scores.masked_fill(~mask[:,None,:],-torch.inf),dim=-1)
            contexts = w @ k
        else:
            mean = (mask[:,:,None]*k).sum(1)/mask.sum(1,keepdim=True)
            contexts = mean[:,None,:].expand_as(q)
        return torch.cat((q,contexts,q*contexts,(q-contexts).abs()),dim=-1).flatten(1)

    def forward(self, pooled, options, tokens, mask):
        x = self.pooled_norm(pooled)
        if self.mode!='pooled':
            x = torch.cat((x,self.compare(options,tokens,mask)),dim=1)
        return self.head(x).squeeze(-1)


def train_neural(features, selected, y, weights, mode, seed):
    torch.manual_seed(seed)
    generator = torch.Generator().manual_seed(seed)
    model = OptionClassifier(mode,features.pool.shape[1]).train()
    loss = nn.BCEWithLogitsLoss(reduction='none')
    optimizer = torch.optim.AdamW(model.parameters(),lr=LR,weight_decay=WEIGHT_DECAY)
    def batches():
        while True:
            order = torch.randperm(len(selected),generator=generator).numpy()
            yield from np.array_split(order,(len(order)+BATCH-1)//BATCH)

    for part in islice(batches(),UPDATES):
        optimizer.zero_grad()
        z = model(*features.batch(selected[part],mode!='pooled'))
        (loss(z,y[part])*weights[part]).mean().backward()
        optimizer.step()
    model.eval()
    return model


def logits_from(model, features, total):
    with torch.inference_mode():
        values = [model(*features.batch(batch,model.mode!='pooled')).numpy()
                  for batch in np.array_split(np.arange(total),(total+BATCH-1)//BATCH)]
    return np.concatenate(values).astype(np.float64)


def fit():
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    records = validated_inputs()
    features = Features()
    assert len(features.lookup)==len(records)
    cal = np.array([i for i,r in enumerate(records) if r['split']=='calibration'])
    cal_rows = [records[i] for i in cal]
    cal_y = np.array([r['supported'] for r in cal_rows],np.float64)
    cal_w = report_weights(cal_rows)
    details = {}
    scores = {}
    checkpoint = {}
    for split,methods in CONFIGURATIONS.items():
        selected = np.array([i for i,r in enumerate(records) if r['split']=='train' and (split=='expanded' or r['corpus']=='AMI')])
        selected_rows = [records[i] for i in selected]
        weights = report_weights(selected_rows)
        y = np.array([r['supported'] for r in selected_rows],np.float64)
        assert set(selected).isdisjoint(cal)
        for mode in methods:
            for seed in ((0,) if mode=='logistic' else SEEDS):
                tag = f'{split}_{mode}_{seed}'
                if mode=='logistic':
                    matrix = features.pool[features.lookup].astype(np.float64)
                    mean,sd = learn_standardizer(matrix[selected],weights)
                    scaled = (matrix-mean)/sd
                    state,_ = fit_logistic(scaled[selected],y,weights)
                    values = scaled@state['linear_weight']+state['linear_bias'][0]
                    state.update(mean=mean,scale=sd)
                    size = matrix.shape[1]+1
                else:
                    model = train_neural(features,selected,torch.from_numpy(y).float(),
                                         torch.from_numpy(weights*len(y)).float(),mode,seed)
                    values = logits_from(model,features,len(records))
                    state = {k:v.numpy() for k,v in model.state_dict().items()}
                    size = sum(p.numel() for p in model.parameters())
                assert np.isfinite(values).all()
                t = temperature(values[cal],cal_y,cal_w)
                scores[tag] = np.column_stack((expit(values),expit(values/t)))
                details[tag] = dict(corpus=split,mode=mode,seed=seed,train=len(selected),temperature=t,
                                    size=size,train_correct=int(np.count_nonzero((values[selected]>=0)==y)),
                                    calibration_correct=int(np.count_nonzero((values[cal]>=0)==cal_y)))
                checkpoint.update({f'{tag}/{name}':a for name,a in state.items()})
                print(tag,details[tag],flush=True)
    np.savez_compressed(RUN/'scores.npz',**scores)
    np.savez_compressed(RUN/'models.npz',**checkpoint)
    dump(RUN/'training.json',dict(models=details,fit=dict(seeds=SEEDS,hidden=HIDDEN,match=MATCH_DIM,updates=UPDATES,
                                      batch=BATCH,lr=LR,weight_decay=WEIGHT_DECAY,calibration_rows=len(cal),
                                      configurations=CONFIGURATIONS),
                                  input_sha256=digest(RUN/'inputs.json'),features_sha256=digest(RUN/'features.npz'),
                                  scores_sha256=digest(RUN/'scores.npz'),models_sha256=digest(RUN/'models.npz')))


if __name__=='__main__':
    p=ArgumentParser()
    p.parse_args()
    fit()
