"""Compare learned and frozen scores on the fixed speech evaluation queries."""
from argparse import ArgumentParser
from collections import Counter, defaultdict
from math import isclose, prod

import numpy as np
from scipy.special import expit

from cache_speech_classifier_features import BENCHMARK_FILE, RUN, benchmark_rows
from evaluate_binding_followup import solve
from evaluate_option_binding import speech_program
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from prepare_speech_relation_training import digest
from train_speech_relation_classifier import MLP_SEEDS, load_models, load_rows, predict, training_features

PRIMARY = ('logistic_relation', f'mlp_{MLP_SEEDS[0]}')
MODES = ('relation','combined')
VARIANT_PAIRS = (('different_span','paraphrase'),('reversed_preference','reference'))


def metrics(labels, predictions):
    y = np.asarray(labels,dtype=bool)
    p = np.asarray(predictions,dtype=np.float64)
    assert y.size > 0 and y.shape == p.shape
    positive = p>=0.5
    conf = np.clip(p,1e-12,1.-1e-12)
    return dict(total=int(y.size), correct=int(np.count_nonzero(positive==y)), valid=int(y.sum()),
                true_support=int(np.count_nonzero(positive & y)), false_support=int(np.count_nonzero(positive & ~y)),
                brier=float(np.mean((p-y)**2)), log_loss=float(-np.mean(np.where(y,np.log(conf),np.log1p(-conf)))))


def pair_diagnostics(rows, probabilities, reference_variant, negative_variant):
    positives = {r['pair_id']:p for r,p in zip(rows,probabilities,strict=True) if r['variant']==reference_variant}
    counters = Counter(total=0, correct_order=0, ties=0, both_correct=0)
    for r,p in zip(rows,probabilities,strict=True):
        if r['variant']!=negative_variant:
            continue
        yes = positives[r['pair_id']]
        counters['total'] += 1
        counters['correct_order'] += int(yes>p+1e-12)
        counters['ties'] += int(abs(yes-p)<=1e-12)
        counters['both_correct'] += int(yes>=0.5 and p<0.5)
    return counters


def diagnostics(models):
    rows = load_rows()
    features = training_features(rows)
    output = {}
    all_rows = [r for dataset in rows.values() for r in dataset]
    for name,(spec,params) in models.items():
        logits = predict(params,features[spec['view']])
        raw, calibrated = expit(logits),expit(logits/spec['temperature'])
        diagnostic = {}
        for split, selected in rows.items():
            indices = np.array([r['split']==split for r in all_rows],dtype=bool)
            labels = [r['is_supported'] for r in selected]
            scores = calibrated[indices]
            cases = [dict(id=r['id'], variant=r['variant'], supported=r['is_supported'],
                          raw=float(a), calibrated=float(b))
                     for r,a,b in zip(selected,raw[indices],scores,strict=True)]
            diagnostic[split] = dict(raw=metrics(labels,raw[indices]), calibrated=metrics(labels,scores), cases=cases,
                                     pairs={neg:pair_diagnostics(selected,scores,pos,neg) for neg,pos in VARIANT_PAIRS})
        output[name] = diagnostic
    return output


def benchmark_matrix(cases):
    path = RUN/'benchmark_features.npy'
    index = read(RUN/'benchmark_features_index.json')
    keys = [dict(case=c['id'],span=w['id']) for _,_,c in cases for w in c['windows']]
    assert index['input_sha256']==digest(BENCHMARK_FILE)
    assert index['feature_sha256']==digest(path) and keys==index['rows']
    return {name:matrix for name,matrix in zip(index['views'],np.load(path,allow_pickle=False).transpose(1,0,2),strict=True)}


def support(windows, probabilities, combine):
    p = []
    for window,value in zip(windows,probabilities,strict=True):
        if window['checks']['speaker'] and window['checks']['time']:
            p.append(float(value)*(window['scores']['whole_claim'] if combine else 1.))
    return 1.-prod(1.-v for v in p)


def native(case, method, scores, combine):
    prepared = dict(case,id=case['id']+':'+method,windows=[
        dict(w,scores=dict(w['scores'],option_relation=float(p)))
        for w,p in zip(case['windows'],scores,strict=True)])
    return speech_program(prepared,'specific_and_content' if combine else 'specific_relation')


def run(families):
    models = load_models(families)
    cases = benchmark_rows()
    matrix = benchmark_matrix(cases)
    predicted = {}
    for name,(spec,params) in models.items():
        logits = predict(params,matrix[spec['view']])
        predicted[name] = (expit(logits),expit(logits/spec['temperature']))
    cursor = 0
    entries = []
    native_programs = []
    expected = {}
    for split,meeting,case in cases:
        windows = case['windows']
        end = cursor+len(windows)
        previous = case['results']
        predictions = {mode:dict(frozen_qwen=previous['specific_relation' if mode=='relation' else 'specific_and_content'],
                                 frozen_content=previous['content']) for mode in MODES}
        raw = {mode:{} for mode in MODES}
        local = {}
        for name,pair in predicted.items():
            a,b = (p[cursor:end] for p in pair)
            local[name] = b.tolist()
            for mode in ('relation',) if name=='logistic_claim_only' else MODES:
                combine = mode=='combined'
                raw[mode][name] = support(windows,a,combine)
                value = support(windows,b,combine)
                predictions[mode][name] = value
                if name in PRIMARY:
                    program = native(case,name,b,combine)
                    native_programs.append(program)
                    expected[program.claim_id] = value
        cursor = end
        record = dict(case, split=split, meeting=meeting, scores=predictions, uncalibrated=raw, window_scores=local)
        entries.append(record)
    assert cursor == len(next(iter(matrix.values())))
    distributions, code = solve(native_programs)
    for name,p in expected.items():
        assert isclose(p,distributions[name]['supported'],abs_tol=1e-10)
        assert abs(distributions[name]['refuted'])<=1e-10, name
    summary = {}
    by_variant = {}
    disagreements = {}
    for split in ('previous','fresh','all'):
        group = [r for r in entries if split in (r['split'],'all')]
        summary[split] = {mode:{m:metrics([r['expected_support'] for r in group],[r['scores'][mode][m] for r in group])
                                for m in group[0]['scores'][mode]} for mode in MODES}
        by_variant[split] = {}
        for mode in MODES:
            variants = defaultdict(list)
            for r in group:
                variants[r['variant']].append(r)
            by_variant[split][mode] = {v:{m:metrics([r['expected_support'] for r in rec],
                                                    [r['scores'][mode][m] for r in rec])
                                             for m in rec[0]['scores'][mode]} for v,rec in variants.items()}
        disagreements[split] = {mode:{m:Counter(((r['scores'][mode]['frozen_qwen']>=0.5)==r['expected_support'],
                                                  (r['scores'][mode][m]>=0.5)==r['expected_support'])
                                                 for r in group) for m in (*PRIMARY,'logistic_claim_only')
                                                  if m in group[0]['scores'][mode]} for mode in MODES}
    paired = {s:{mode:{m:{'both_correct':counts[True,True],'both_wrong':counts[False,False],
                          'only_learned_correct':counts[False,True],'only_frozen_correct':counts[True,False]}
                       for m,counts in result.items()} for mode,result in modes.items()} for s,modes in disagreements.items()}
    raw_summary = {mode:{m:metrics([r['expected_support'] for r in entries],
                                    [r['uncalibrated'][mode][m] for r in entries])
                         for m in entries[0]['uncalibrated'][mode]} for mode in MODES}
    name = 'logistic_evaluation' if set(families)=={'logistic'} else 'evaluation'
    dump(RUN/f'{name}.json',dict(summary=summary,by_variant=by_variant,paired=paired,uncalibrated=raw_summary,
         diagnostics=diagnostics(models),model={m:s for m,(s,_) in models.items()}, rows=entries,
         native=len(distributions), benchmark_sha256=digest(BENCHMARK_FILE)))
    (RUN/f'{name}.pl').write_text(code)
    for mode in MODES:
        print(mode,{m:(r['correct'],r['total'],r['true_support'],r['false_support'])
                    for m,r in summary['all'][mode].items()},flush=True)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('stage',choices=('logistic','all'))
    run(('logistic',) if parser.parse_args().stage=='logistic' else ('logistic','mlp'))
