"""Report the controlled logistic, MLP, and frozen speech comparisons."""
from html import escape
from shutil import copy2
from xml.etree import ElementTree as ET

from binding_followup_report import support_counts
from compiler_fallback_report import table
from evaluate_speech_relation_classifier import PRIMARY
from option_binding_report import VARIANTS
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from speech_relation_training_report import dataset_rows
from train_speech_relation_classifier import DATA, MLP_SEEDS, RUN
from prepare_speech_relation_training import ROOT

URL = 'compiler-demos/speech-relation-classifier-20261127/'
LOGISTIC, MLP = PRIMARY
LABELS = {'frozen_content':'Frozen whole claim', 'frozen_qwen':'Frozen Qwen relation',
          'logistic_relation':'Logistic on the stated relation', 'logistic_claim':'Logistic on the full claim',
          'logistic_claim_only':'Logistic without the transcript', MLP:'Neural classifier (64 hidden units)'}
SHOWN = ('frozen_content','frozen_qwen',LOGISTIC,MLP,'logistic_claim','logistic_claim_only')


def summarize():
    r = read(RUN/'evaluation.json')
    suite = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(k,0))==0 for k in ('failures','errors','skipped'))
    dump(RUN/'summary.json',dict(summary=r['summary'], model=r['model'], paired=r['paired'], native=r['native'],
                                 tests=int(suite.get('tests')), benchmark_sha256=r['benchmark_sha256']))


def status_html():
    s = read(RUN/'summary.json')['summary']['all']['combined']
    return (f'<b>The logistic classifier gets {s[LOGISTIC]["correct"]}/{s[LOGISTIC]["total"]} speech decisions '
            f'right and the neural classifier gets {s[MLP]["correct"]}/{s[MLP]["total"]} in its first run.</b> '
            f'The frozen comparison gets {s["frozen_qwen"]["correct"]}/{s["frozen_qwen"]["total"]}.')


def overview_html():
    r = read(RUN/'evaluation.json')
    tests = read(RUN/'summary.json')['tests']
    modes = r['summary']['all']
    pieces = [
        '<h2 id="remaining-failures">Learning a speech relation score</h2>'
        '<p>We fit logistic regression and a neural classifier with one hidden layer of 64 units. '
        'Both see a frozen 768-value representation of the transcript and the stated relation. '
        'Logistic regression combines these values with one set of weights. The neural classifier can learn '
        'interactions between them. The control removes the transcript from the same input format. An additional '
        'logistic model sees the transcript paired with the original full claim.</p>'
        '<p>We fit the heads on 104 examples from three related AMI recordings and calibrate with 62 examples '
        'from two other recordings. Calibration fits one number that softens or sharpens the model scores. '
        'The 86 benchmark queries were reserved from fitting and calibration. These are the same queries used '
        'in the earlier frozen comparison, with reviewed speaker and time spans and manually specified options.</p>'
        '<p>At inference, every score uses the same speaker and time checks. The combined method multiplies the '
        'relation score by the same frozen DeBERTa whole-claim score within one eligible span. The table reports '
        'correct decisions at 0.5. The neural result uses the first preset seed, with all five shown below.</p>'
        '<div class="binding-result-tables">'
    ]
    pieces.append(table('Correct decisions on the same 86 held-out queries.', ['Method','Direct score','With whole-claim check'],
                        [(LABELS[m], support_counts(modes['relation'][m])[0],
                          support_counts(modes['combined'][m])[0] if m in modes['combined'] else '—') for m in SHOWN]))
    pieces.append(table('What the methods accept when combined with the same whole-claim check.',
                        ['Relation score','Valid claims accepted','False support'],
                        [(LABELS[m],*support_counts(modes['combined'][m])[1:]) for m in ('frozen_qwen',LOGISTIC,MLP)]))
    pieces.append('</div><p>The frozen combination accepts 18/20 valid claims and makes four false positives. '
                  'The logistic combination accepts 17/20 and makes six false positives. The first neural run '
                  'accepts 16/20 and makes five false positives. The neural classifier rejects all the training '
                  'edits, while its five benchmark runs give 76–77/86. The gains and losses concern different '
                  'queries. Both learned heads reject a remark about a cat facing the other way, yet miss the '
                  'correct report about pressing volume-down twice. '
                  '<a href="#trained-speech-examples">Examples and errors by query type</a></p>'
                  '<h3>Did the model use the excerpt?</h3><p>Six calibration pairs keep the claim fixed and change the '
                  'excerpt from the same speaker. We count how often a model gives the supporting excerpt a '
                  'strictly higher score, and how often both pass and fail at 0.5 as expected. These diagnostics '
                  'use the recordings that supplied the calibration labels.</p><div class="binding-result-tables">')
    diagnostics = r['diagnostics']
    pieces.append(table('Results on the six identical-claim pairs in the calibration recordings.',
                        ['Method','Higher on supported excerpt','Both labels correct','Tied'],
                        [(LABELS[m], f'{p["correct_order"]}/{p["total"]}',f'{p["both_correct"]}/{p["total"]}',p['ties'])
                         for m in (LOGISTIC,MLP,'logistic_claim','logistic_claim_only')
                         for p in (diagnostics[m]['calibration']['pairs']['different_span'],)]))
    pieces.append('</div><p>The claim-only model ties on all six. The neural classifier ranks all six correctly '
                  'and gets both labels right in three. The full-claim logistic model also ranks all six correctly '
                  'and gets both labels right in four. A useful change in the score can still fall on one side of 0.5. '
                  '<a href="#identical-claim-speech-pair">See the same claim with both excerpts</a></p>'
                  f'<p>All {r["native"]} exact DeepProbLog support probabilities match a separate calculation. '
                  f'All {tests} project tests passed. '
                  f'<a href="{URL}source.zip">Models, inputs, and replay</a> · <a href="{URL}evaluation.json">All predictions</a> · '
                  f'<a href="{URL}tests.xml">Tests</a> · <a href="verification-pipeline.html#next-steps">Checklist</a> · '
                  '<a href="#earlier-speech-training-prep">Training data</a></p>')
    return ''.join(pieces)


def examples_html():
    r = read(RUN/'evaluation.json')
    compared = ('frozen_qwen',LOGISTIC,MLP)
    output = ['<section id="trained-speech-examples"><h2>Speech claims the models disagree on</h2>',
              '<div class="binding-result-tables">']
    variations = r['by_variant']['all']['combined']
    output.append(table('Errors by query type with the same whole-claim check.',
                        ['Query','Frozen','Logistic','Neural'],
                        [(VARIANTS[v],*(f'{c["total"]-c["correct"]}/{c["total"]}' for c in (scores[m] for m in compared)))
                         for v,scores in variations.items()]))
    seeds = [f'mlp_{seed}' for seed in MLP_SEEDS]
    output.append(table('All five neural classifier runs, using the same 86 evaluation queries.',
                        ['Seed','Correct','Valid accepted','False support','Temperature'],
                        [(r['model'][m]['seed'],*support_counts(r['summary']['all']['combined'][m]),
                          f'{r["model"][m]["temperature"]:.1f}') for m in seeds]))
    output.append('</div><p>A larger temperature pulls scores closer to 0.5. The neural classifier fits '
                  '104/104 training examples in every run. Four runs reach the upper temperature limit of 20 '
                  'on calibration. The frozen and learned results above use no benchmark labels for fitting.</p>')
    examples = (('ES2013a','addition_or_no_choice','Facing the other way'),
                ('TS3003d','faithful','The twice-pressed volume-down button'),
                ('TS3006c','changed_option','A different description of the remote'),
                ('ES2005b','changed_option','An ad slogan changed to a jingle'),
                ('IS1006b','addition_or_no_choice','A feature added to the recognizer'))
    for meeting,variant,title in examples:
        case, = (c for c in r['rows'] if c['meeting']==meeting and c['variant']==variant)
        output.append(f'<article id="learned-{meeting}-{variant}" class="box benchmark-case"><h3>{escape(title)}</h3>'
                      f'<p><strong>Claim</strong> {escape(case["content"])}</p>'
                      f'<p><strong>Expected</strong> {"Supported" if case["expected_support"] else "Unsupported"}</p>')
        output.extend(f'<blockquote>{escape(w["text"])}</blockquote>' for w in case['windows'] if all(w['checks'].values()))
        output.append('<div class="binding-result-tables">'+table('Support from the same eligible transcript span.',
                      ['Method','Score'],[(LABELS[m],f'{case["scores"]["combined"][m]:.3f}') for m in compared])+'</div></article>')
    pair_id = 'IN1005.sync.511'
    records = dataset_rows()
    wanted = ('paraphrase','different_span')
    relevant = [next(r for r in records if r['id']==f'{pair_id}:{v}') for v in wanted]
    output.append('<article id="identical-claim-speech-pair" class="box benchmark-case"><h3>Same claim, different excerpt</h3>'
                  f'<p>{escape(relevant[0]["claim"])}</p>')
    for title,row in zip(('Supporting excerpt','Other excerpt by the same speaker'),relevant,strict=True):
        output.append(f'<h4>{title}</h4><blockquote>{escape(row["evidence"]["text"])}</blockquote>')
    output.append('<div class="binding-result-tables">'+table('Calibrated support scores for the same claim.',
                  ['Method','Supporting excerpt','Other excerpt'],
                  [(LABELS[m],*(f'{next(c["calibrated"] for c in r["diagnostics"][m]["calibration"]["cases"] if c["id"]==row["id"]):.3f}'
                                for row in relevant)) for m in (LOGISTIC,MLP,'logistic_claim','logistic_claim_only')])
                  +'</div></article><p>AMI transcript excerpts © University of Edinburgh and partners under CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a>.</p></section>')
    return ''.join(output)


def write_downloads():
    dest = ROOT/'site/reports'/URL
    dest.mkdir(parents=True,exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,dest/name)


if __name__ == '__main__':
    summarize()
