"""Report the new training group, option alignment and independent recordings."""
from html import escape
from shutil import copy2
from xml.etree import ElementTree as ET

from compiler_fallback_report import table
from prepare_compiler_fallback import dump
from prepare_icsi_option_examples import ROOT, RUN
from prepare_or_source_evaluation import read
from train_speech_option_alignment import SEEDS

URL = 'compiler-demos/speech-option-alignment-20261127/'
BASES = {'frozen_content':'Frozen DeBERTa whole claim','frozen_qwen':'Frozen Qwen relation',
         'frozen_calibrated':'Frozen Qwen with calibration'}
MODES = {'logistic':'Logistic on pooled features','pooled':'Neural classifier on pooled features',
         'uniform':'Option and transcript token averages','attention':'Each option attends to transcript tokens'}
VARIANTS = {'reference':'Reference','paraphrase':'Paraphrase','option':'Changed option','description':'Changed description',
            'quantity':'Changed quantity','reversed_preference':'Reversed preference','reversed_replacement':'Reversed replacement',
            'addition_as_alternatives':'Combination described as alternatives',
            'alternatives_as_addition':'Alternatives described as a combination'}
A = 'expanded_attention_17'
U = 'expanded_uniform_17'
P = 'expanded_pooled_17'


def summarize():
    r = read(RUN/'evaluation.json')
    combined = read(RUN/'combined_calibration.json')['benchmark']
    suite = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(k,0))==0 for k in ('errors','failures','skipped'))
    compared = ('frozen_qwen',P,U,A)
    i = r['rows']['ICSI']
    def correct(row,method):
        return (row['results']['combined'][method]>=0.5)==row['expected_support']
    reviewed = sum(len({correct(c,m) for m in compared})>1 for c in i)
    filtered = [c for c in i if c['pair_id'] not in ('Bmr019:841','Btr001:2066')]
    review = dict(disagreements=reviewed, retained=len(filtered),
                  sensitivity={m:sum(correct(c,m) for c in filtered) for m in compared})
    dump(RUN/'summary.json',dict(scores={c:v['metrics'] for c,v in r['summary'].items()}, pairs=r['pairs'],
                                  data=read(RUN/'icsi_counts.json'),native=r['native'],tests=int(suite.get('tests')),
                                  frozen_temperature=r['frozen_temperature'],combined_calibration=combined,review=review))


def range_score(r, corpus, mode, group, head):
    registry = r['scores'][corpus][mode]
    tags = [f'{group}_{head}_{s}' for s in ((0,) if head=='logistic' else SEEDS)]
    vals = [registry[k]['correct'] for k in tags]
    lo,hi = min(vals),max(vals)
    return (str(lo) if lo==hi else f'{lo}–{hi}')+f'/{registry[tags[0]]["total"]}'


def status_html():
    s = read(RUN/'summary.json')
    ice = s['scores']['ICSI']['combined']
    observed = range_score(s,'ICSI','combined','expanded','attention')
    return (f'<b>On the {ice["frozen_qwen"]["total"]} new ICSI queries, option attention gives {observed} correct '
            f'over three runs.</b> The frozen combination gives {ice["frozen_qwen"]["correct"]}/{ice["frozen_qwen"]["total"]}.')


def overview_html():
    s = read(RUN/'summary.json')
    results = read(RUN/'evaluation.json')
    configs = results['training']['fit']['configurations']
    comparison_rows = [(BASES[m], 'Frozen', *(f'{s["scores"][c]["combined"][m]["correct"]}/{s["scores"][c]["combined"][m]["total"]}'
                                             for c in ('AMI','ICSI'))) for m in BASES]
    for corpus,modes in configs.items():
        for m in modes:
            comparison_rows.append((MODES[m], 'AMI' if corpus=='ami' else 'AMI + ICSI',
                                    *(range_score(s,c,'combined',corpus,m) for c in ('AMI','ICSI'))))
    return (
        '<h2 id="remaining-failures">Broader speech training and option alignment</h2>'
        '<p>We added 120 supervised examples from 21 ICSI recordings about dialogue systems and speech processing. '
        'We used 32 examples from a separate networking group for calibration and 60 new queries from 10 recordings '
        'about meeting recording and transcription for testing. Each report has two supported claims and two edits. '
        'I reviewed the excerpts and edits. The recording groups are separate and '
        'individual speakers may recur. <a href="https://groups.inf.ed.ac.uk/ami/icsi/">ICSI corpus</a></p>'
        '<p>For each transcript and claim we mark the tokens for the first and second options in the input to frozen '
        'DeBERTa. The pooled classifier uses one vector for the whole input. The other classifiers also see the option '
        'vectors and transcript tokens. One takes a uniform average over the transcript. The attention version learns '
        'a separate weighted average for each option. These two heads have the same number of trainable parameters.</p>'
        '<p>Each neural fit uses 280 updates from one of three fixed seeds. Every fitted model uses the same '
        '94 calibration examples. The frozen baseline uses Qwen for the specific relation, and we also test '
        'calibrating that score on the same 94 examples. The table shows correct decisions with the same frozen '
        'whole-claim score, speaker and time checks, and threshold of 0.5. ICSI gives one annotated excerpt per query.</p>'
        '<div class="binding-result-tables">'
        +table('Correct decisions with the whole-claim check. Ranges cover the three seeds.',
               ['Method','Training data','AMI','New ICSI'],comparison_rows)
        +'</div>'+ interpretation(s)
        +f'<p>All {s["native"]} exact DeepProbLog support computations for the three primary learned heads agree '
        f'with a separate calculation. All {s["tests"]} project tests passed. '
        '<a href="#aligned-speech-examples">Errors and examples</a> · <a href="#speech-alignment-seeds">Individual runs</a></p>'
        f'<p><a href="{URL}source.zip">Data, fitted models, and replay</a> · <a href="{URL}evaluation.json">All predictions</a> · '
        f'<a href="{URL}tests.xml">Tests</a> · <a href="verification-pipeline.html#next-steps">Checklist</a> · '
        '<a href="#earlier-learned-speech">Earlier classifier comparison</a></p>'
    )


def interpretation(summary):
    return (
        '<p>On ICSI, the frozen combination accepts 27/30 supported reports and seven unsupported claims. '
        'Option attention trained on both corpora accepts 18–20/30 supported reports and six unsupported claims '
        'in each run. The pooled classifier using the broader data gives 45–47/60. The AMI-only pooled classifier '
        'gives 46–48/60. The added data improves some direct scores, and the combined accuracy varies by model. '
        'Option attention trails the pooled classifier on ICSI and overlaps the token-average control across seeds.</p>'
        '<h3>Calibrating after the two scores are combined</h3>'
        '<p>We ran a second check to see whether the learned heads lost valid reports at the cutoff. '
        'A two-parameter calibration maps the product of the two scores to a support probability. '
        'The same 94 calibration examples set this map for each method. '
        'Every comparison keeps the same eligible transcript span.</p><div class="binding-result-tables">'
        +table('Correct decisions after calibrating the product. Neural heads use seed 17.',
               ['Method','AMI','New ICSI'],
               [(name,*(f'{summary["combined_calibration"][c][method]["correct"]}/{summary["combined_calibration"][c][method]["total"]}'
                         for c in ('AMI','ICSI'))) for method,name in (
                         ('frozen_qwen','Frozen Qwen relation'),('expanded_logistic_0','Logistic'),
                         (P,'Pooled'),(U,'Token averages'),(A,'Option attention'))])
        +'</div><p>On ICSI, this check raises option attention from 42 to 46 correct. Valid reports supported '
        'rise from 18 to 27, while false support rises from six to eleven. The frozen score at its original '
        'threshold remains ahead. Across all four claims per source, the frozen combination gives the '
        'correct ranking in 13 of 15 reports, compared with 12 for the pooled head and 10 for option attention. '
        'This comparison supports carrying the frozen relation score into the next evidence-selection test.</p>'
    )


def examples_html():
    r = read(RUN/'evaluation.json')
    shown = ('frozen_qwen',P,U,A)
    names = {**BASES,P:'Pooled',U:'Token averages',A:'Option attention'}
    result = r['summary']['ICSI']['by_variant']['combined']
    output = ['<section id="aligned-speech-examples"><h2>Option details in the new recordings</h2>',
              '<p>These comparisons use seed 17 and the same whole-claim score. Each row counts errors within a '
              'query type.</p><div class="binding-result-tables">']
    output.append(table('Errors by query type on the new ICSI test.', ['Query','Frozen','Pooled','Average','Attention'],
                        [(VARIANTS[k],*(f'{v["total"]-v["correct"]}/{v["total"]}' for v in (values[m] for m in shown)))
                         for k,values in result.items()]))
    output.append(table('Within each report, both supported claims must score above both edits.',
                        ['Method','Reports ranked correctly','All four labels correct'],
                        [(names[m],f'{v["ranked"]}/{v["groups"]}',f'{v["all_correct"]}/{v["groups"]}')
                         for m in shown for v in (r['pairs']['combined'][m],)]))
    output.append('</div>')
    for cid,title in (
        ('Bmr009:1713:description','English variety changed to proficiency'),
        ('Bmr022:256:reference','Choosing between high and low beeps'),
        ('Bmr030:230:paraphrase','Words versus whole utterances'),
        ('Bmr019:841:addition_as_alternatives','Adapting foreground and background speakers'),
        ('Btr002:2476:option','A breath, a laugh, or a cough'),
    ):
        row, = (c for c in r['rows']['ICSI'] if c['id']==cid)
        span, = row['windows']
        anchor = escape(cid.replace(':','-'))
        output.append(f'<article class="box benchmark-case" id="alignment-{anchor}"><h3>{escape(title)}</h3>'
                      f'<p>{escape(span["meeting"])} · {span["start"]:.1f}–{span["end"]:.1f} s</p>'
                      f'<blockquote>{escape(span["text"])}</blockquote>'
                      f'<p><strong>Claim</strong> {escape(row["content"])}</p>'
                      f'<p><strong>Expected</strong> {"Supported" if row["expected_support"] else "Unsupported"}</p>'
                      '<div class="binding-result-tables">'
                      +table('Support scores with the same whole-claim check.', ['Method','Score'],
                             [(names[m],f'{row["results"]["combined"][m]:.3f}') for m in shown])
                      +'</div></article>')
    output.append('<p>I reread the 17 queries where these methods disagree. Two source reports merit another '
                  'look at scope. One says “I guess” before describing a combined adaptation, and another asks '
                  'whether gestures are allowed. On the remaining 52 queries, the frozen combination gets 43, '
                  'the pooled head 41, the token averages 36, and option attention 38. '
                  'The full 60-query test remains the primary comparison.</p>'
                  '<p>ICSI transcript excerpts © International Computer Science Institute and corpus contributors. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/icsi/license.shtml">CC BY 4.0 license</a>.</p>'
                  '<h2 id="speech-alignment-seeds">Individual runs and direct scores</h2><div class="binding-result-tables">')
    for corpus in ('AMI','ICSI'):
        registry = r['summary'][corpus]['metrics']
        output.append(table(f'All fitted models on the {corpus} queries.', ['Training','Method','Seed','Direct','Combined'],
                            [('AMI' if p['corpus']=='ami' else 'AMI + ICSI',MODES[p['mode']],p['seed'],
                              *(f'{registry[mode][key]["correct"]}/{registry[mode][key]["total"]}' for mode in ('direct','combined')))
                             for key,p in r['training']['models'].items()]))
    output.append('</div></section>')
    return ''.join(output)


def write_downloads():
    target = ROOT/'site/reports'/URL
    target.mkdir(parents=True,exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,target/name)


if __name__=='__main__':
    summarize()
