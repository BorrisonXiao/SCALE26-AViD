"""Archive the source excerpts, fitted heads and reproducible comparison."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from cache_speech_classifier_features import BENCHMARK_FILE
from prepare_icsi_option_examples import TRAINING
from speech_option_alignment_report import ROOT, RUN, URL

OUTPUTS = ('icsi_train.jsonl','icsi_calibration.jsonl','icsi_test.jsonl','icsi_counts.json','inputs.json',
           'input_manifest.json','models.npz','scores.npz','training.json','evaluation.json','evaluation.pl',
           'combined_calibration.json','summary.json')


def main():
    paths = [ROOT/name for name in ('requirements-compilation.txt','requirements-verification.txt',
                                   'tests/test_speech_option_alignment.py')]
    paths.extend(RUN/name for name in (*OUTPUTS,'icsi_spans.json','icsi_annotations.tsv','icsi_source.json',
                                      'features.json','features.npz','qwen.json','nli.json','calibration_nli.json','tests.xml'))
    paths.extend(TRAINING/name for name in ('train.jsonl','calibration.jsonl'))
    paths.append(BENCHMARK_FILE)
    prior = ROOT/'site/reports/compiler-demos/speech-relation-classifier-20261127/source.zip'
    with ZipFile(prior) as archive:
        paths.extend(ROOT/name for name in archive.namelist() if name.startswith('scripts/'))
    paths.extend(ROOT/'scripts'/f'{name}.py' for name in ('prepare_icsi_option_examples','cache_speech_option_alignment',
                 'train_speech_option_alignment','evaluate_speech_option_alignment','calibrate_speech_combined_score',
                 'speech_option_alignment_report','package_speech_option_alignment'))
    data = {str(path.relative_to(ROOT)):path.read_bytes() for path in paths}
    data['README.md'] = (ROOT/'docs/speech_option_alignment_20261127.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({name:sha256((RUN/name).read_bytes()).hexdigest() for name in OUTPUTS},indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(exist_ok=True,parents=True)
    with ZipFile(target,'w') as archive:
        for name,contents in sorted(data.items()):
            member = ZipInfo(name,date_time=(2026,11,27,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member,contents)
    print(f'Archived {len(data)} files for replay.')


if __name__ == '__main__':
    main()
