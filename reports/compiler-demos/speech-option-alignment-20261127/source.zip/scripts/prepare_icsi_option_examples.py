"""Select and export reviewed choice and preference examples from ICSI recordings."""
from argparse import ArgumentParser
from collections import Counter
import csv
from hashlib import sha256
from pathlib import Path
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from prepare_speech_relation_training import ROOT, RUN as TRAINING, digest, jsonl, normalized, render

RUN = TRAINING.with_name('speech_option_alignment_20261127')
SOURCE = RUN/'source/ICSI_original_transcripts.zip'
SOURCE_URL = 'https://groups.inf.ed.ac.uk/ami/ICSICorpusAnnotations/ICSI_original_transcripts.zip'
SPLITS = {'Bed':'train','Bro':'train','Bns':'calibration','Bmr':'test','Btr':'test'}
PATTERNS = {
    'preference':re.compile(r'\b(?:instead of|rather than|prefer(?:red)?|as opposed to)\b',re.I),
    'alternatives':re.compile(r'\b(?:either|alternatively|choose|option|or)\b',re.I),
    'together':re.compile(r'\b(?:both|along with|together with|as well as|and also)\b',re.I),
    'quantity':re.compile(r'\b(?:two|three|four|five|six|ten|twenty|hundred|[0-9]+)\b',re.I),
}


def transcripts(archive):
    for name in sorted(archive.namelist()):
        meeting = Path(name).stem
        if not name.endswith('.mrt') or meeting[:3] not in SPLITS:
            continue
        tree = ET.fromstring(archive.read(name))
        rows = {}
        assert tree.get('Session') == meeting
        for index,s in enumerate(tree.findall('./Transcript/Segment'),1):
            speaker = s.get('Participant')
            if not speaker or not s.get('StartTime') or not s.get('EndTime'):
                continue
            start,end = float(s.get('StartTime')),float(s.get('EndTime'))
            text = re.sub(r'\s+',' ',''.join(s.itertext())).strip()
            if text and end>start:
                ident = f'{meeting}:{index}'
                rows[ident] = dict(id=ident, meeting=meeting, series=meeting[:3], speaker=speaker,
                                   start=start,end=end,text=text)
        yield meeting,rows


def mine():
    groups = {prefix:[] for prefix in SPLITS}
    with ZipFile(SOURCE) as archive:
        for meeting,rows in transcripts(archive):
            for row in rows.values():
                text = row['text']
                if not 13<=len(normalized(text).split())<=80:
                    continue
                marks = [key for key,p in PATTERNS.items() if p.search(text)]
                if not marks or marks==['quantity']:
                    continue
                groups[meeting[:3]].append(dict(row, markers=marks))
    for prefix,rows in groups.items():
        groups[prefix] = sorted(rows,key=lambda r:sha256(r['id'].encode()).hexdigest())
    dump(RUN/'candidates.json',groups)
    print({k:len(v) for k,v in groups.items()})


def annotations():
    with (RUN/'icsi_annotations.tsv').open(encoding='utf-8',newline='') as file:
        return list(csv.DictReader(file,delimiter='\t'))


def freeze():
    requested = {r['id'] for r in annotations()}
    with ZipFile(SOURCE) as archive:
        spans = {k:v for _,rows in transcripts(archive) for k,v in rows.items() if k in requested}
    assert requested == spans.keys()
    dump(RUN/'icsi_spans.json',spans)
    dump(RUN/'icsi_source.json',dict(source_url=SOURCE_URL,source_sha256=digest(SOURCE),
                                    split_by_meeting_group=SPLITS, groups=sorted(SPLITS)))


def expanded_rows():
    selected = annotations()
    spans = read(RUN/'icsi_spans.json')
    grouped = {split:[] for split in ('train','calibration','test')}
    assert len({r['id'] for r in selected}) == len(selected)
    for item in selected:
        span = spans[item['id']]
        relation,condition = item['relation'],item['qualifier']
        split = SPLITS[span['series']]
        options = [item['first'],item['second']]
        assert all(options) and len(set(map(normalized,options)))==2
        edited = options.copy()
        side = int(item['side'])-1
        assert side in (0,1) and item['replacement'] != edited[side]
        edited[side] = item['replacement']
        assert item['before'] and item['after'] and item['paraphrase'].count(item['before'])==1,item['id']
        change = item['paraphrase'].replace(item['before'],item['after'])
        if relation in ('preference','replacement'):
            crossed, new_relation, variant = options[::-1], relation, f'reversed_{relation}'
        elif relation=='together':
            crossed,new_relation,variant = options,'alternatives','addition_as_alternatives'
        else:
            crossed,new_relation,variant = options,'together','alternatives_as_addition'
        versions = [('reference',render_relation(options,relation,condition),options,relation,True),
                    ('paraphrase',item['paraphrase'],options,relation,True),
                    (item['edit'],change,edited,relation,False),
                    (variant,render_relation(crossed,new_relation,condition),crossed,new_relation,False)]
        for key,claim,args,kind,label in versions:
            grouped[split].append(dict(id=f'{span["id"]}:{key}',pair_id=span['id'],split=split,claim=claim,
                                      options=args,relation=kind,qualifier=condition,evidence=span,is_supported=label,
                                      variant=key, review_reason=item['rationale']))
    return grouped


def render_relation(options, relation, condition):
    if relation!='replacement':
        return render(options,relation,condition)
    first,second = options
    text = f'The speaker describes {first} in place of {second}.'
    return f'{condition}, {text[0].lower()}{text[1:]}' if condition else text


def build():
    groups = expanded_rows()
    counts = {}
    seen = set()
    for split,rows in groups.items():
        assert len({r['id'] for r in rows})==len(rows) and rows
        texts = {normalized(r['evidence']['text']) for r in rows}
        assert seen.isdisjoint(texts)
        seen.update(texts)
        jsonl(RUN/f'icsi_{split}.jsonl',rows)
        counts[split] = dict(examples=len(rows),reports=len({r['pair_id'] for r in rows}),
                             recordings=sorted({r['evidence']['meeting'] for r in rows}),
                             variants=dict(sorted(Counter(r['variant'] for r in rows).items())))
    dump(RUN/'icsi_counts.json',counts)
    print(counts,flush=True)


if __name__=='__main__':
    p=ArgumentParser()
    operations={'mine':mine,'freeze':freeze,'build':build}
    p.add_argument('stage',choices=operations)
    operations[p.parse_args().stage]()
