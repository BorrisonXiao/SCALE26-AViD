"""Compare data and token alignment on two fixed transcript benchmarks."""
from collections import defaultdict
from math import isclose, prod

import numpy as np
from scipy.special import expit, logit

from cache_speech_classifier_features import BENCHMARK_FILE, benchmark_rows
from cache_speech_option_alignment import RUN, relation_description, validated_inputs
from calibrate_ami_speech_scores import probabilities
from evaluate_binding_followup import solve
from evaluate_speech_relation_classifier import metrics, native
from prepare_compiler_fallback import dump
from prepare_icsi_option_examples import digest
from prepare_or_source_evaluation import read
from train_speech_relation_classifier import report_weights, temperature

MODES = ('direct','combined')
PRIMARY = ('expanded_pooled_17','expanded_uniform_17','expanded_attention_17')
BASELINES = ('frozen_content','frozen_qwen','frozen_calibrated')


def key(row):
    return (row['evidence']['text'],*row['options'],relation_description(row['relation'],row['qualifier']))


def load():
    model = read(RUN/'training.json')
    assert model['scores_sha256']==digest(RUN/'scores.npz')
    assert model['input_sha256']==digest(RUN/'inputs.json')
    with np.load(RUN/'scores.npz',allow_pickle=False) as z:
        return model,{k:z[k][:,1] for k in z.files}


def support(case, values, combined=False):
    factors = [float(p)*(window['scores']['whole_claim'] if combined else 1.)
               for p,window in zip(values,case['windows'],strict=True) if all(window['checks'][k] for k in ('speaker','time'))]
    return 1.-prod(1.-x for x in factors)


def aggregate(entries):
    metrics_by_mode, variants = {},{}
    for mode in MODES:
        metrics_by_mode[mode] = {m:metrics([r['expected_support'] for r in entries],[r['results'][mode][m] for r in entries])
                                  for m in entries[0]['results'][mode]}
        by_type = defaultdict(list)
        for record in entries:
            by_type[record['variant']].append(record)
        variants[mode] = {variant:{m:metrics([r['expected_support'] for r in group],[r['results'][mode][m] for r in group])
                         for m in metrics_by_mode[mode]} for variant,group in by_type.items()}
    return dict(metrics=metrics_by_mode,by_variant=variants)


def compare_pairs(entries):
    by_pair = defaultdict(list)
    for r in entries:
        by_pair[r['pair_id']].append(r)
    tested = {}
    for mode in MODES:
        tested[mode] = {}
        for method in entries[0]['results'][mode]:
            detail = [([r['results'][mode][method] for r in rows if r['expected_support']],
                       [r['results'][mode][method] for r in rows if not r['expected_support']])
                      for rows in by_pair.values()]
            tested[mode][method] = dict(groups=len(detail),
                ranked=sum(min(pos)>max(neg) for pos,neg in detail),
                all_correct=sum(min(pos)>=0.5 and max(neg)<0.5 for pos,neg in detail))
    return tested


def main():
    rows = validated_inputs()
    trained, predictions = load()
    baseline = {(q['evidence'],*q['options'],q['relation']):q['probabilities'][0]
                for q in read(RUN/'qwen.json')['records']}
    content = probabilities(RUN/'nli.json')
    cal_rows = [row for row in rows if row['split']=='calibration']
    q = np.array([baseline[key(r)] for r in cal_rows],np.float64)
    cal = temperature(logit(q.clip(1e-9,1.-1e-9)),np.asarray([r['supported'] for r in cal_rows],np.float64),
                      report_weights(cal_rows))
    entries = {'AMI':[],'ICSI':[]}
    checks = {}
    programs = []

    def compare(corpus, case, features, qwen):
        results = {mode:{} for mode in MODES}
        whole = [w['scores']['whole_claim'] for w in case['windows']]
        qcal = expit(logit(np.clip(qwen,1e-9,1.-1e-9))/cal)
        for mode in MODES:
            joint=mode=='combined'
            results[mode] = dict(frozen_content=support(case,whole), frozen_qwen=support(case,qwen,joint),
                                 frozen_calibrated=support(case,qcal,joint))
            for m,p in predictions.items():
                local = p[features]
                s=support(case,local,joint)
                results[mode][m] = s
                if m in PRIMARY:
                    program = native(case,m,local,joint)
                    programs.append(program)
                    checks[program.claim_id]=s
        entries[corpus].append(dict(case,results=results))

    index = defaultdict(list)
    for r in rows:
        if r['split']=='test' and r['corpus']=='AMI':
            index[r['case_id']].append(r)
    for split,meeting,c in benchmark_rows():
        keys = index[c['id']]
        assert [r['evidence']['id'] for r in keys]==[w['id'] for w in c['windows']]
        qwen = [w['scores']['option_relation'] for w in c['windows']]
        compare('AMI',dict(c,meeting=meeting,pair_id=c['id'],earlier_split=split),[r['feature_id'] for r in keys],qwen)
        output=entries['AMI'][-1]['results']
        assert isclose(output['direct']['frozen_qwen'],c['results']['specific_relation'],abs_tol=1e-10)
        assert isclose(output['combined']['frozen_qwen'],c['results']['specific_and_content'],abs_tol=1e-10)
    for r in rows:
        if r['split']!='test' or r['corpus']!='ICSI':
            continue
        span = r['evidence']
        whole=content[span['text'],r['claim']]['entailment']
        w=dict(span,checks=dict(speaker=True,time=True),scores=dict(whole_claim=whole))
        c=dict(id=r['id'],meeting=span['meeting'],pair_id=r['pair_id'],content=r['claim'],options=r['options'],
               relation=relation_description(r['relation'],r['qualifier']),variant=r['variant'],expected_support=r['supported'],
               query=dict(speaker=span['speaker'],start=span['start'],end=span['end']),windows=[w])
        compare('ICSI',c,[r['feature_id']],[baseline[key(r)]])
    observed,code = solve(programs)
    assert checks.keys()==observed.keys()
    for ident,answer in observed.items():
        assert isclose(checks[ident],answer['supported'],abs_tol=1e-10) and abs(answer['refuted'])<=1e-10
    summary = {corpus:aggregate(results) for corpus,results in entries.items()}
    dump(RUN/'evaluation.json',dict(summary=summary, rows=entries, training=trained,
                                    frozen_temperature=cal, native=len(observed), pairs=compare_pairs(entries['ICSI']),
                                    benchmark_sha256=digest(BENCHMARK_FILE)))
    (RUN/'evaluation.pl').write_text(code)
    for corpus,data in summary.items():
        for mode,m in data['metrics'].items():
            print(corpus,mode,{k:(v['correct'],v['true_support'],v['false_support']) for k,v in m.items()},flush=True)


if __name__=='__main__':
    main()
