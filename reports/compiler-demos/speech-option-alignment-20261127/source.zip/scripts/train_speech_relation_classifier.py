"""Fit fixed logistic and MLP heads using only the training and calibration recordings."""
from argparse import ArgumentParser
from collections import Counter
import json
from math import log

import numpy as np
from scipy.optimize import minimize, minimize_scalar
from scipy.special import expit
import torch
from torch import nn

from cache_speech_classifier_features import DATA, RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from prepare_speech_relation_training import SPLITS, digest

LOGISTIC_L2 = 0.02
MLP_SEEDS = (17, 23, 41, 53, 71)
MLP_HIDDEN = 64
MLP_STEPS = 80
MLP_LR = 0.003
MLP_WEIGHT_DECAY = 0.02
VIEWS = ('relation', 'claim', 'claim_only')


def load_rows():
    rows = {}
    for split in SPLITS:
        with (DATA/f'{split}.jsonl').open(encoding='utf-8') as file:
            subset = [json.loads(line) for line in file]
        assert all(row['split'] == split for row in subset)
        rows[split] = subset
    return rows


def report_weights(rows):
    count = Counter(r['pair_id'] for r in rows)
    weights = np.array([1/count[r['pair_id']] for r in rows], dtype=np.float64)
    return weights/weights.sum()


def training_features(rows):
    paths = (DATA/'features.npy',RUN/'claim_only_features.npy')
    matrix, control = (np.load(path, allow_pickle=False) for path in paths)
    index = read(DATA/'features_index.json')
    claim_only = read(RUN/'claim_only_features_index.json')
    indices = [dict(id=r['id'],split=split) for split,items in rows.items() for r in items]
    assert indices == index['rows'] == claim_only['rows']
    assert index['views']==['claim','relation'] and claim_only['views']==['claim_only']
    assert [digest(path) for path in paths] == [index['feature_sha256'],claim_only['feature_sha256']]
    assert all(digest(DATA/f'{split}.jsonl') == value for split,value in claim_only['input_sha256'].items())
    return {'claim':matrix[:,0,:], 'relation':matrix[:,1,:], 'claim_only':control[:,0,:]}


def learn_standardizer(x, weights):
    x = np.asarray(x,dtype=np.float64)
    mean = weights @ x
    sd = np.sqrt(weights @ ((x-mean)**2)).clip(min=1e-4)
    return mean, sd


def fit_logistic(x, y, sample_weights):
    def objective(params):
        vector, bias = params[:-1], params[-1]
        z = x @ vector+bias
        loss = sample_weights @ (np.logaddexp(0,z)-y*z) + LOGISTIC_L2/2*(vector @ vector)
        residual = sample_weights*(expit(z)-y)
        grad = np.append(x.T @ residual+LOGISTIC_L2*vector,residual.sum())
        return loss,grad
    result = minimize(objective,np.zeros(x.shape[1]+1),jac=True,method='L-BFGS-B',
                      options={'maxiter':1000,'ftol':1e-12,'gtol':1e-8})
    if not result.success:
        raise RuntimeError(result.message)
    return dict(linear_weight=result.x[:-1], linear_bias=result.x[-1:]), int(result.nit)


def fit_mlp(x, y, weights, seed):
    torch.manual_seed(seed)
    network = nn.Sequential(nn.Linear(x.shape[1],MLP_HIDDEN),nn.GELU(),nn.Linear(MLP_HIDDEN,1)).double()
    optimizer = torch.optim.AdamW(network.parameters(),lr=MLP_LR,weight_decay=MLP_WEIGHT_DECAY)
    inputs, target, weighting = (torch.from_numpy(a) for a in (x,y,weights))
    for _ in range(MLP_STEPS):
        optimizer.zero_grad()
        logits = network(inputs).squeeze(-1)
        losses = nn.functional.binary_cross_entropy_with_logits(logits,target,reduction='none')
        (losses @ weighting).backward()
        optimizer.step()
    state = network.state_dict()
    return dict(hidden_weight=state['0.weight'].numpy(), hidden_bias=state['0.bias'].numpy(),
                linear_weight=state['2.weight'].numpy()[0], linear_bias=state['2.bias'].numpy())


def predict(params, x):
    standardized = (x-params['mean'])/params['scale']
    if 'hidden_weight' in params:
        from scipy.special import ndtr
        h = standardized @ params['hidden_weight'].T+params['hidden_bias']
        standardized = h*ndtr(h)
    return standardized @ params['linear_weight']+params['linear_bias'][0]


def temperature(logits, y, weights):
    # One positive scalar adjusts confidence while preserving the sign of logits.
    def loss(log_t):
        z = logits/np.exp(log_t)
        return float(weights @ (np.logaddexp(0,z)-y*z))
    result = minimize_scalar(loss,bounds=(log(0.1),log(20.)),method='bounded',options={'xatol':1e-9})
    if not result.success:
        raise RuntimeError(result.message)
    return float(np.exp(result.x))


def fit(family):
    rows = load_rows()
    borrowed = {split:{r['evidence']['series'] for r in sample} for split,sample in rows.items()}
    assert borrowed['train'].isdisjoint(borrowed['calibration'])
    matrices = training_features(rows)
    labels = {s:np.array([r['is_supported'] for r in rows[s]],dtype=np.float64) for s in SPLITS}
    weights = {s:report_weights(rows[s]) for s in SPLITS}
    n = len(rows['train'])
    records = {}
    arrays = {}
    if family=='logistic':
        specs = [(f'logistic_{view}',view,None) for view in VIEWS]
    else:
        torch.set_num_threads(1)
        torch.use_deterministic_algorithms(True)
        specs = [(f'mlp_{seed}','relation',seed) for seed in MLP_SEEDS]
    for name,view,seed in specs:
        x = matrices[view]
        mean, scale = learn_standardizer(x[:n],weights['train'])
        train = (x[:n]-mean)/scale
        if seed is None:
            params,iterations = fit_logistic(train,labels['train'],weights['train'])
        else:
            params = fit_mlp(train,labels['train'],weights['train'],seed)
            iterations = MLP_STEPS
        params.update(mean=mean,scale=scale)
        calibration = predict(params,x[n:])
        t = temperature(calibration,labels['calibration'],weights['calibration'])
        records[name] = dict(view=view,seed=seed,temperature=t,iterations=iterations,
                             num_parameters=sum(v.size for k,v in params.items() if k not in ('mean','scale')))
        arrays.update({f'{name}/{key}':val for key,val in params.items()})
        print(f'{name}: {records[name]}',flush=True)
    path = RUN/f'{family}.npz'
    np.savez_compressed(path,**arrays)
    dump(RUN/f'{family}_training.json',dict(family=family, records=records,
         input_rows={k:len(v) for k,v in rows.items()}, source_series={k:sorted(v) for k,v in borrowed.items()},
         data_sha256={s:digest(DATA/f'{s}.jsonl') for s in SPLITS}, weight_sha256=digest(path),
         logistic_l2=LOGISTIC_L2, mlp_hidden=MLP_HIDDEN, mlp_steps=MLP_STEPS, mlp_lr=MLP_LR,
         mlp_weight_decay=MLP_WEIGHT_DECAY, torch_version=torch.__version__))


def load_models(families):
    models = {}
    for family in families:
        path = RUN/f'{family}.npz'
        metadata = read(RUN/f'{family}_training.json')
        assert metadata['weight_sha256']==digest(path)
        with np.load(path,allow_pickle=False) as weights:
            for name,rec in metadata['records'].items():
                prefix = name+'/'
                params = {k[len(prefix):]:weights[k] for k in weights.files if k.startswith(prefix)}
                models[name] = (rec,params)
    return models


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('family',choices=('logistic','mlp'))
    fit(parser.parse_args().family)
