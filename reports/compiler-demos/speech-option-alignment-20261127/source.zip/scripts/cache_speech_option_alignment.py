"""Prepare matched pooled and token features and score the fixed speech baseline."""
from argparse import ArgumentParser
import json

import numpy as np

from cache_speech_classifier_features import BENCHMARK_FILE, benchmark_rows
from evaluate_ami_speech_scoring import MODELS
from evaluate_reported_or_transcripts import load_nli_model, score_pairs
from prepare_compiler_fallback import dump
from prepare_icsi_option_examples import RUN, TRAINING, digest
from prepare_or_source_evaluation import read
from score_binding_followup import load_qwen_scorer
from score_option_binding import RELATION, RELATION_CHOICES

WIDTH = 128
PROJECTION_SEED = 1729
RELATION_PROMPTS = {
    'preference':'presents the first option as preferable to the second',
    'replacement':'describes using the first option in place of the second',
    'alternatives':'presents the two options as alternatives',
    'together':'presents the two options together as a combination',
}


def dataset(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]


def relation_description(relation, qualifier):
    words = RELATION_PROMPTS.get(relation,relation)
    return f'{words}, under the condition: {qualifier}' if qualifier else words


def option_input(options, relation, qualifier):
    description = relation_description(relation,qualifier)
    first,second = options
    intro = f'The speaker {description}. First option: '
    middle = '. Second option: '
    a,b = len(intro),len(intro)+len(first)+len(middle)
    return intro+first+middle+second+'.', ((a,a+len(first)),(b,b+len(second)))


def prepare():
    records = []
    for corpus,split,path in [*(('AMI',s,TRAINING/f'{s}.jsonl') for s in ('train','calibration')),
                              *(('ICSI',s,RUN/f'icsi_{s}.jsonl') for s in ('train','calibration','test'))]:
        for row in dataset(path):
            source = row['evidence']
            records.append(dict(id=row['id'], pair_id=row['pair_id'], feature_id=len(records),corpus=corpus, split=split,
                                claim=row['claim'], options=row['options'], relation=row['relation'], qualifier=row['qualifier'],
                                evidence=source, supported=row['is_supported'],variant=row['variant'],eligible=True))
    for _,meeting,c in benchmark_rows():
        for w in c['windows']:
            records.append(dict(id=f'{c["id"]}:{w["id"]}',case_id=c['id'],pair_id=c['id'],feature_id=len(records),corpus='AMI',split='test',
                                claim=c['content'],options=c['options'],relation=c['relation'],qualifier='',
                                evidence=dict(w,meeting=meeting),supported=c['expected_support'],variant=c['variant'],
                                eligible=all(w['checks'][k] for k in ('speaker','time'))))
    assert len({r['id'] for r in records})==len(records)
    dump(RUN/'inputs.json',records)
    sources = [TRAINING/'train.jsonl',TRAINING/'calibration.jsonl',BENCHMARK_FILE]
    sources.extend(RUN/f'icsi_{s}.jsonl' for s in ('train','calibration','test'))
    dump(RUN/'input_manifest.json',dict(sources={str(p.relative_to(RUN.parent)):digest(p) for p in sources},
                                       input_sha256=digest(RUN/'inputs.json')))


def validated_inputs():
    assert read(RUN/'input_manifest.json')['input_sha256']==digest(RUN/'inputs.json')
    return read(RUN/'inputs.json')


def features():
    import torch

    records = validated_inputs()
    pairs = [(r['evidence']['text'],*option_input(r['options'],r['relation'],r['qualifier'])) for r in records]
    unique = sorted(set(pairs))
    lookup = {p:i for i,p in enumerate(unique)}
    source_index = np.array([lookup[p] for p in pairs],np.int32)
    tokenizer, model, snapshot = load_nli_model(MODELS['deberta'])
    assert tokenizer.is_fast
    seed = np.random.default_rng(PROJECTION_SEED)
    weight = seed.normal(size=(model.config.hidden_size, WIDTH)).astype(np.float32) / np.float32(model.config.hidden_size**0.5)
    projection = torch.from_numpy(weight)
    tokens, option_vectors, pools = [], [], []
    offsets = [0]
    max_tokens = 0
    with torch.inference_mode():
        for start in range(0,len(unique),16):
            chunk = unique[start:start+16]
            premises, hypotheses, bounds = zip(*chunk)
            items = tokenizer(list(premises),list(hypotheses),padding=True,truncation=False,return_offsets_mapping=True,
                              return_tensors='pt')
            max_tokens = max(max_tokens,items['input_ids'].shape[1])
            assert max_tokens<=model.config.max_position_embeddings
            seq = [items.sequence_ids(i) for i in range(len(chunk))]
            chars = items.pop('offset_mapping').numpy()
            hidden = model.deberta(**items).last_hidden_state
            pooled = model.pooler(hidden).numpy()
            projected = (hidden @ projection).numpy()
            for i, spans in enumerate(bounds):
                valid = [k for k,v in enumerate(seq[i]) if v==0]
                option_rows = [[k for k,v in enumerate(seq[i]) if v==1 and chars[i,k,0]<right and chars[i,k,1]>left]
                               for left,right in spans]
                assert valid and all(option_rows) and set(option_rows[0]).isdisjoint(option_rows[1]), hypotheses[i]
                tokens.append(projected[i,valid].astype(np.float16))
                option_vectors.append([projected[i,idx].mean(0) for idx in option_rows])
                pools.append(pooled[i])
                offsets.append(offsets[-1]+len(valid))
    target = RUN/'features.npz'
    np.savez_compressed(target, tokens=np.concatenate(tokens), offsets=np.asarray(offsets,np.int32),
                        options=np.asarray(option_vectors,np.float32), pooled=np.asarray(pools,np.float32),lookup=source_index)
    dump(RUN/'features.json',dict(checkpoint=snapshot, torch_version=torch.__version__, rows=len(records), inputs=len(unique),
                                 transcript_tokens=offsets[-1],max_input_tokens=max_tokens, projection_width=WIDTH,
                                 projection_seed=PROJECTION_SEED,input_sha256=digest(RUN/'inputs.json'), feature_sha256=digest(target)))
    print('Feature cache:', len(records), 'rows,',len(unique),'unique encoder inputs,',offsets[-1],'transcript tokens',flush=True)


def baseline_qwen():
    records = [r for r in validated_inputs() if r['split']=='calibration' or (r['corpus']=='ICSI' and r['split']=='test')]
    inputs = sorted({(r['evidence']['text'],*r['options'],relation_description(r['relation'],r['qualifier'])) for r in records})
    score,provenance=load_qwen_scorer()
    rows=[]
    for evidence,a,b,relation in inputs:
        question=RELATION.format(first=a,second=b,relation=relation)
        rows.append(dict(evidence=evidence,options=[a,b],relation=relation,**score(question,RELATION_CHOICES,text=evidence)))
    dump(RUN/'qwen.json',dict(provenance,records=rows, prompt=RELATION,choices=RELATION_CHOICES))
    print('Frozen Qwen requests:',len(rows), 'pairs with both answer orders',flush=True)


def baseline_nli():
    pairs = {(r['evidence']['text'],r['claim']) for r in validated_inputs() if r['corpus']=='ICSI' and r['split']=='test'}
    dump(RUN/'nli.json',score_pairs(pairs,MODELS['deberta']))
    print('Frozen whole-claim requests:',len(pairs),flush=True)


if __name__=='__main__':
    p=ArgumentParser()
    stages={'prepare':prepare,'features':features,'qwen':baseline_qwen,'nli':baseline_nli}
    p.add_argument('stage',choices=stages)
    stages[p.parse_args().stage]()
