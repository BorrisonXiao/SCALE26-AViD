"""Source-context contrasts: a goal/definition/request is not its realization."""
import pytest
from probabilistic_verification.amr_contexts import compile_contextual
from test_amr_semantic_checks import record


def concept_scope(c, label):
    return [a.arguments[-3] for a in c.atoms if a.predicate == 'concept' and a.arguments[1] == label]


def test_definition_keeps_expulsion_inside_definition_context():
    r=record("'Term' refers to expulsion.",[("'Term'",'Term','PROPN',2,'nsubj',None),('refers','refer','VERB',0,'root',None),('to','to','ADP',4,'case',None),('expulsion','expulsion','NOUN',2,'obl',None)])
    c=compile_contextual(r,'(r / refer-01 :ARG1 (e / expel-01) :ARG2 (s / string-entity :value "Term"))')
    assert concept_scope(c,'expel-01')==['c1']
    assert c.metadata['scopes']['c1']['kind']=='definition'


def test_referring_a_person_is_not_a_definition():
    r=record('Doctor refers patient.',[('Doctor','doctor','NOUN',2,'nsubj',None),('refers','refer','VERB',0,'root',None),('patient','patient','NOUN',2,'obj',None)])
    c=compile_contextual(r,'(r / refer-01 :ARG0 (d / doctor) :ARG1 (p / patient))')
    assert not c.metadata['scopes']


def test_landing_mission_does_not_assert_landing():
    r=record('A landing mission.',[('A','a','DET',3,'det',None),('landing','landing','NOUN',3,'compound',None),('mission','mission','NOUN',0,'root',None)])
    c=compile_contextual(r,'(m / mission-01 :ARG1 (l / land-01))')
    assert concept_scope(c,'land-01')==['c1']
    assert c.metadata['scopes']['c1']['kind']=='purpose'


def test_actual_landing_is_not_put_under_mission_scope():
    r=record('The mission landed.',[('The','the','DET',2,'det',None),('mission','mission','NOUN',3,'nsubj',None),('landed','land','VERB',0,'root','Tense=Past|VerbForm=Fin')])
    c=compile_contextual(r,'(l / land-01 :ARG1 (m / mission-01))')
    assert concept_scope(c,'land-01')==['world']


@pytest.mark.parametrize('negative',[False,True])
def test_request_preserves_scope_and_negation(negative):
    r=record('People request departure.',[('People','person','NOUN',2,'nsubj',None),('request','request','VERB',0,'root',None),('departure','departure','NOUN',2,'obj',None)])
    c=compile_contextual(r,'(r / request-01 '+(':polarity - 'if negative else'')+':ARG0 (p / person) :ARG1 (d / depart-01))')
    assert concept_scope(c,'depart-01')==['c1']
    assert c.metadata['scopes']['c1']['kind']=='request'
    assert ('NOT'in c.to_dict()['logical_form'])==negative


def test_work_purpose_and_shared_actor():
    r=record('People work to build houses.',[('People','person','NOUN',2,'nsubj',None),('work','work','VERB',0,'root',None),('to','to','PART',4,'mark',None),('build','build','VERB',2,'advcl',None),('houses','house','NOUN',4,'obj','Number=Plur')])
    c=compile_contextual(r,'(w / work-01 :ARG0 (p / person) :ARG1 (b / build-01 :ARG0 p :ARG1 (h / house)))')
    assert concept_scope(c,'build-01')==['c1']
    assert c.metadata['scopes']['c1']['kind']=='purpose'
    person=c.metadata['node_variables']['p']
    assert sum(a.predicate=='role' and a.arguments[1]=='ARG0' and a.arguments[2]==person for a in c.atoms)==2


def test_only_to_result_is_not_assumed_purpose():
    r=record('People work only to fail.',[('People','person','NOUN',2,'nsubj',None),('work','work','VERB',0,'root',None),('only','only','ADV',5,'advmod',None),('to','to','PART',5,'mark',None),('fail','fail','VERB',2,'advcl',None)])
    with pytest.raises(Exception,match='No scope policy'):
        compile_contextual(r,'(w / work-01 :ARG0 (p / person) :ARG1 (f / fail-01))')


def test_pneumatic_drill_is_a_tool_without_an_actual_drilling_event():
    r=record('Pneumatic drill.',[('Pneumatic','pneumatic','ADJ',2,'amod',None),('drill','drill','NOUN',0,'root',None)])
    c=compile_contextual(r,'(d / drill-01 :mod (p / pneumatic))')
    assert not concept_scope(c,'drill-01') and concept_scope(c,'drill')==['world']
    assert next(v.kind for v in c.variables if v.description=='drill')=='entity'
    assert c.metadata['source_alignment']['normalisations'][0]['lookup']=='pneumatic_drill'


def test_verbal_drilling_stays_an_event():
    r=record('Workers drill holes.',[('Workers','worker','NOUN',2,'nsubj',None),('drill','drill','VERB',0,'root',None),('holes','hole','NOUN',2,'obj',None)])
    c=compile_contextual(r,'(d / drill-01 :ARG0 (w / worker) :ARG1 (h / hole))')
    assert concept_scope(c,'drill-01')==['world']


def test_copular_ruling_is_a_noun_and_this_is_not_its_actor():
    r=record('This is a ruling.',[('This','this','PRON',4,'nsubj',None),('is','be','AUX',4,'cop',None),('a','a','DET',4,'det',None),('ruling','ruling','NOUN',0,'root',None)])
    c=compile_contextual(r,'(r / rule-01 :ARG0 (t / this))')
    assert concept_scope(c,'ruling')==['world']
    assert any(a.predicate=='role' and a.arguments[1]=='domain' for a in c.atoms)
    assert not any(a.predicate=='role' and a.arguments[1]=='ARG0' for a in c.atoms)


def test_noun_of_relationship_does_not_become_an_event_participant():
    r=record('Group of people.',[('Group','group','NOUN',0,'root',None),('of','of','ADP',3,'case',None),('people','person','NOUN',1,'nmod','Number=Plur')])
    c=compile_contextual(r,'(g / group-01 :ARG1 (p / person))')
    assert concept_scope(c,'group')==['world']
    assert any(a.predicate=='role' and a.arguments[1]=='of' for a in c.atoms)


def test_unresolved_noun_roles_still_flag_the_candidate():
    r=record('Pneumatic drill.',[('Pneumatic','pneumatic','ADJ',2,'amod',None),('drill','drill','NOUN',0,'root',None)])
    with pytest.raises(Exception,match='noun'):
        compile_contextual(r,'(d / drill-01 :ARG1 (g / globe) :mod (p / pneumatic))')


def test_function_of_a_tool_is_not_an_actual_manufacturing_event():
    r=record('Manufacturing tools.',[('Manufacturing','manufacturing','NOUN',2,'compound',None),('tools','tool','NOUN',0,'root','Number=Plur')])
    c=compile_contextual(r,'(t / tool :instrument-of (m / manufacture-01))')
    assert concept_scope(c,'manufacture-01')==['c1']
    assert c.metadata['scopes']['c1']['kind']=='purpose'


@pytest.mark.parametrize('adjective,frame',[('reflective','reflect-01'),('surprising','surprise-01')])
def test_derived_adjective_stays_a_property(adjective,frame):
    r=record(adjective+' object.',[(adjective,adjective,'ADJ',2,'amod',None),('object','object','NOUN',0,'root',None)])
    c=compile_contextual(r,'(o / object :ARG0-of (p / '+frame+'))')
    assert c.metadata['predicate_types']['p']['kind']=='property'
    assert next(v.kind for v in c.variables if v.description==frame)=='property'


def test_communication_nouns_do_not_automatically_become_physical_objects():
    r=record('People violate vows.',[('People','person','NOUN',2,'nsubj',None),('violate','violate','VERB',0,'root',None),('vows','vow','NOUN',2,'obj',None)])
    c=compile_contextual(r,'(v / violate-01 :ARG0 (p / person) :ARG1 (w / vow-01 :ARG0 p))')
    assert concept_scope(c,'vow-01')==['world']


@pytest.mark.parametrize('word,verb',[('responder','respond-01'),('protester','protest-01'),('volunteer','volunteer-01')])
def test_agent_noun_describes_the_same_person(word,verb):
    r=record(word+'.',[(word,word,'NOUN',0,'root',None)])
    c=compile_contextual(r,'(p / person :ARG0-of (v / '+verb+'))')
    assert concept_scope(c,word)==['world']
    assert not concept_scope(c,verb)
    assert any(a.predicate=='role' and a.arguments[1]=='domain' and a.arguments[2]==c.metadata['node_variables']['p'] for a in c.atoms)


def test_prepositional_copula_is_not_noun_classification():
    r=record('It is in transit.',[('It','it','PRON',4,'nsubj',None),('is','be','AUX',4,'cop',None),('in','in','ADP',4,'case',None),('transit','transit','NOUN',0,'root',None)])
    c=compile_contextual(r,'(t / transit-01 :ARG1 (i / it))')
    assert concept_scope(c,'transit-01')==['world']


def test_copular_subject_uses_source_grammar_not_a_universal_arg_number():
    r=record('This is a ruling.',[('This','this','PRON',4,'nsubj',None),('is','be','AUX',4,'cop',None),('a','a','DET',4,'det',None),('ruling','ruling','NOUN',0,'root',None)])
    c=compile_contextual(r,'(r / rule-01 :ARG1 (t / this))')
    assert concept_scope(c,'ruling')==['world']
    assert any(a.predicate=='role'and a.arguments[1]=='domain' for a in c.atoms)


def test_named_copular_subject_and_explicit_noun_to_relationship():
    r=record('Jane Smith is advisor to Lee.',[('Jane','Jane','PROPN',2,'flat',None),('Smith','Smith','PROPN',4,'nsubj',None),('is','be','AUX',4,'cop',None),('advisor','advisor','NOUN',0,'root',None),('to','to','ADP',6,'case',None),('Lee','Lee','PROPN',4,'nmod',None)])
    c=compile_contextual(r,'(a / advise-01 :ARG0 (p / person :name (n / name :op1 "Jane" :op2 "Smith")) :ARG1 (l / person :name (n2 / name :op1 "Lee")))')
    assert concept_scope(c,'advisor')==['world']
    assert any(a.predicate=='role'and a.arguments[1]=='domain' for a in c.atoms)
    assert any(a.predicate=='role'and a.arguments[1]=='to' for a in c.atoms)


def test_adjective_related_to_a_noun_remains_a_modifier():
    r=record('These are economic policy.',[('These','this','PRON',4,'nsubj',None),('are','be','AUX',4,'cop',None),('economic','economic','ADJ',4,'amod',None),('policy','policy','NOUN',0,'root',None)])
    c=compile_contextual(r,'(p / policy-01 :domain (t / this) :ARG2 (e / economy))')
    assert concept_scope(c,'policy')==['world']
    assert any(a.predicate=='role'and a.arguments[1]=='mod' for a in c.atoms)


def test_relational_adjective_does_not_create_a_false_argument_alarm():
    r=record('Musical performance.',[('Musical','musical','ADJ',2,'amod',None),('performance','performance','NOUN',0,'root',None)])
    c=compile_contextual(r,'(p / perform-01 :ARG1 (m / music))')
    assert not c.metadata['semantic_checks']


def test_copular_event_noun_keeps_its_participants():
    r=record('Video is an interview between people.',[('Video','video','NOUN',4,'nsubj',None),('is','be','AUX',4,'cop',None),('an','a','DET',4,'det',None),('interview','interview','NOUN',0,'root',None),('between','between','ADP',6,'case',None),('people','person','NOUN',4,'nmod',None)])
    c=compile_contextual(r,'(i / interview-01 :ARG1 (p / person) :medium (v / video))')
    assert concept_scope(c,'interview-01')==['world']
    assert any(a.predicate=='role'and a.arguments[1]=='ARG1' for a in c.atoms)
