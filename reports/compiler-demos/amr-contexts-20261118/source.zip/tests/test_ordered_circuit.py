import pytest
from probabilistic_verification.representation import Expression as E
from probabilistic_verification.logic import Observation,GroundProgram,enumerate_probability
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.ordered_circuit import OrderedSolver

@pytest.mark.parametrize('op',['and','or','evidence'])
def test_grouped_categorical_variables_preserve_shared_worlds(op):
 a=Observation('a',(.3,.2,.5),False,'a');b=Observation('b',(.6,.1,.3),False,'b');x,y=E.atom(a.id),E.atom(b.id)
 p=GroundProgram('shared',E.combine('or',[E.combine('and',[E(op,(x,y)),x]),E.negate(y)]),{a.id:a,b.id:b},[],[])
 actual=DirectVerifier([p],learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver).predict()[0]['distribution']
 assert actual==pytest.approx(enumerate_probability(p),abs=1e-10)

@pytest.mark.parametrize('n',[19,32,64])
def test_grouped_long_conjunction_matches_analytic_probability(n):
 obs=[Observation('o'+str(i),(.9,.05,.05),False,'o')for i in range(n)]
 p=GroundProgram('long',E.combine('and',[E.atom(o.id)for o in obs]),{o.id:o for o in obs},[],[])
 actual=DirectVerifier([p],learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver).predict()[0]['distribution']
 assert actual==pytest.approx(dict(supported=.9**n,refuted=1-.95**n,unknown=.95**n-.9**n),abs=1e-10)

def test_reordering_keeps_neural_gradients_and_cached_re_evaluation():
 import torch
 obs=[Observation('a',(.4,.3,.3),True,'a'),Observation('b',(.5,.2,.3),True,'b')]
 p=GroundProgram('gradient',E.combine('or',[E.combine('and',[E.atom(o.id)for o in obs]),E.negate(E.atom('a'))]),{o.id:o for o in obs},[],[])
 outcomes=[]
 for solver in [None,OrderedSolver]:
  v=DirectVerifier([p],learned=True,program_builder=compact_prolog_program,solver_class=solver);q=v.query('gradient','unknown');r=v.model.solve([q])[0].result[q.query];(-r.log()).backward();grad=v.classifier.layers[-1].weight.grad.detach().clone();outcomes.append((float(r.detach()),grad))
  old=float(r.detach());v.optimizer.step();again=v.model.solve([q])[0].result[q.query];assert float(again.detach())!=pytest.approx(old,abs=1e-7)
 assert outcomes[0][0]==pytest.approx(outcomes[1][0],abs=1e-10)
 assert torch.allclose(outcomes[0][1],outcomes[1][1],atol=1e-10)and outcomes[1][1].norm()>0

@pytest.mark.parametrize('state',['supported','refuted','unknown'])
def test_constants_do_not_require_an_ad_constraint(state):
 p=GroundProgram('constant',E.negate(E.constant(state)),{},[],[])
 actual=DirectVerifier([p],learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver).predict()[0]['distribution']
 assert actual==pytest.approx(enumerate_probability(p),abs=1e-10)
