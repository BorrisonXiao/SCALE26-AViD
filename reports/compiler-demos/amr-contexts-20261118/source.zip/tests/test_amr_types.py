"""Meaning contrasts for source-based types, scopes, aliases and quantities."""
import pytest
from probabilistic_verification.amr_types import compile_typed, normalization_licenses, TypedAlignment
from probabilistic_verification.amr_checked import compile_checked
from test_amr_semantic_checks import record


def test_sound_keeps_content_under_audio_scope():
    r = record('Sound of fireworks exploding.', [
        ('Sound','sound','NOUN',0,'root',None), ('of','of','ADP',3,'case',None),
        ('fireworks','firework','NOUN',1,'nmod','Number=Plur'), ('exploding','explode','VERB',3,'acl',None)])
    g = '(s / sound-01 :ARG1 (e / explode-01 :ARG1 (f / firework)))'
    c = compile_typed(r, g)
    assert c.metadata['scopes']['c1']['kind'] == 'sound'
    assert c.metadata['scopes']['c1']['route'] == 'audio_event'
    explosion = next(a for a in c.atoms if a.predicate == 'concept' and a.arguments[1] == 'explode-01')
    assert explosion.arguments[-3:] == ('c1', 'route', 'audio_event')
    assert 'context_owner' in explosion.arguments
    with pytest.raises(Exception, match='No scope policy'):
        compile_checked(r, g)
    negative = compile_typed(r, g.replace('sound-01', 'sound-01 :polarity -'))
    assert negative.expression.display({a.id:a for a in negative.atoms}).count('NOT') == 1


def test_nonfactual_purpose_does_not_assert_achievement():
    r = record('The operation goal is to keep port open.', [
        ('The','the','DET',2,'det',None), ('operation','operation','NOUN',3,'compound',None),
        ('goal','goal','NOUN',0,'root',None), ('is','be','AUX',3,'cop',None), ('to','to','PART',6,'mark',None),
        ('keep','keep','VERB',3,'acl',None), ('port','port','NOUN',6,'obj',None), ('open','open','ADJ',6,'xcomp',None)])
    c = compile_typed(r, '(h / have-purpose-91 :ARG1 (o / operate-01) :ARG2 (k / keep-02 :ARG0 o :ARG1 (a / open-09 :ARG1 (p / port))))')
    scope = next(iter(c.metadata['scopes'].values()))
    assert scope['kind'] == 'purpose'
    kept = next(a for a in c.atoms if a.predicate == 'concept' and a.arguments[1] == 'keep-02')
    assert kept.arguments[-3] != 'world'
    assert any(a.predicate == 'reference' and a.arguments[-3] != 'world' for a in c.atoms)


def test_event_reference_does_not_escape_a_belief():
    r = record('Operation belief.', [('Operation','operation','NOUN',0,'root',None), ('belief','belief','NOUN',1,'nmod',None)])
    with pytest.raises(Exception, match='context'):
        compile_typed(r, '(a / and :op1 (b / believe-01 :ARG1 (o / operate-01)) :op2 (s / stop-01 :ARG0 o))')


def test_comparative_property_keeps_degree_and_subject_roles():
    r = record('Closer footage.', [('Closer','close','ADJ',2,'amod',None), ('footage','footage','NOUN',0,'root',None)])
    c = compile_typed(r, '(h / have-degree-91 :ARG1 (f / footage) :ARG2 (c / close-10 :ARG1 f) :ARG3 (m / more))')
    assert any(a.predicate == 'concept' and a.arguments[1] == 'close-10' for a in c.atoms)
    assert any(a.predicate == 'concept' and a.arguments[1] == 'more' for a in c.atoms)
    assert c.metadata['predicate_types']['c']['kind'] == 'property'
    assert next(v for v in c.variables if v.description == 'close-10').kind == 'property'
    assert not c.metadata['temporal']


def test_unknown_modal_adjective_still_requires_a_scope_policy():
    r = record('Leaving is unlikely.', [('Leaving','leave','VERB',3,'csubj',None), ('is','be','AUX',3,'cop',None), ('unlikely','unlikely','ADJ',0,'root',None)])
    with pytest.raises(Exception, match='No scope policy'):
        compile_typed(r, '(u / unlikely-01 :ARG1 (l / leave-01))')


def test_event_noun_alignment_excludes_instrument_nouns_and_repeated_anchors():
    r = record('Shaking flight charger.', [('Shaking','shaking','NOUN',2,'compound',None), ('flight','flight','NOUN',0,'root',None), ('charger','charger','NOUN',2,'compound',None)])
    a = TypedAlignment(r, {'s':'shake-01', 'f':'fly-01', 'c':'charge-03'})
    assert a.unique('s')['text'] == 'Shaking'
    assert a.unique('f')['text'] == 'flight'
    assert not a.matches('c')
    r = record('Shaking shaking.', [('Shaking','shaking','NOUN',0,'root',None), ('shaking','shaking','NOUN',1,'conj',None)])
    assert not TypedAlignment(r, {'s':'shake-01'}).matches('s')


def alias_record(text):
    return record(text, [(text.rstrip('.'),text.rstrip('.'),'PROPN',0,'root',None)])


@pytest.mark.parametrize('source,name,kind,accepted', [
    ('SCOTUS.', 'Supreme Court of the United States', 'government-organization', True),
    ('USA.', 'United States of America', 'country', True),
    ('US.', 'United States', 'person', False),
    ('us.', 'United States', 'country', False),
    ('SCOTUS.', 'Supreme Court of Canada', 'government-organization', False),
    ('Phillies.', 'Phillipines', 'team', False),
    ('Haboob.', 'Hambob', 'location', False),
])
def test_aliases_preserve_verified_identity(source, name, kind, accepted):
    import json
    g = '(x / '+kind+' :name (n / name :op1 '+json.dumps(name)+'))'
    if accepted:
        c = compile_typed(alias_record(source), g)
        assert c.metadata['normalization']['name_aliases']['n']['graph'] == name
    else:
        with pytest.raises(Exception, match='name|source'):
            compile_typed(alias_record(source), g)


def rate_record(text):
    return record(text, [('40','40','NUM',2,'nummod',None), ('meters','meter','NOUN',0,'root',None), ('second','second','ADJ',2,'nmod',None)])


@pytest.mark.parametrize('denominator,unit,accepted', [('1','second',True), ('2','second',False), ('1','hour',False)])
def test_rate_preserves_linked_numerator_and_denominator(denominator, unit, accepted):
    r = rate_record('40 meters/second.')
    g = '(r / rate-entity-91 :ARG1 (d / distance-quantity :quant 40 :unit (m / meter)) :ARG2 (t / temporal-quantity :quant '+denominator+' :unit (s / '+unit+')))'
    if accepted:
        c = compile_typed(r, g)
        assert c.metadata['normalization']['implicit_values'] == [('t', ':quant', '1')]
        # A unit denominator of 1.0 is the same value as 1.
        compile_typed(r, g.replace(':quant 1 ', ':quant 1.0 '))
    else:
        with pytest.raises(Exception):
            compile_typed(r, g)


def test_unspecified_seconds_are_not_one_second_or_a_guessed_count():
    r = record('Seconds after eruption.', [('Seconds','second','NOUN',3,'obl','Number=Plur'), ('after','after','ADP',3,'case',None), ('eruption','eruption','NOUN',0,'root',None)])
    g = '(a / after :op1 (e / erupt-01) :quant (m / multiple :op1 (t / temporal-quantity :quant 1 :unit (s / second))))'
    c = compile_typed(r, g)
    assert c.metadata['normalization']['implicit_values']
    with pytest.raises(Exception):
        compile_typed(r, '(t / temporal-quantity :quant 1 :unit (s / second))')
    with pytest.raises(Exception):
        compile_typed(r, g.replace(':quant 1', ':quant 6'))
