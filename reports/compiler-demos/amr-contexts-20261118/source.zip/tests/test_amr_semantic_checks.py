import pytest
from probabilistic_verification.amr_semantic_checks import semantic_checks
from probabilistic_verification.amr_source_alignment import prepare_source

def record(text,rows):
 tokens=[];offset=0
 for i,(word,lemma,pos,head,rel,feats)in enumerate(rows,1):
  start=text.index(word,offset);offset=start+len(word);tokens.append(dict(id=i,text=word,lemma=lemma,upos=pos,head=head,deprel=rel,feats=feats,start_char=start,end_char=offset))
 return dict(claim_id='x',text=text,tokens=tokens)
def codes(r,g):
 raw,info,a=prepare_source(r,g);return {x['code']for x in semantic_checks(r,raw,a)}

def test_noun_adjective_cannot_be_a_charge_participant():
 r=record('A portable charger.', [('A','a','DET',3,'det',None),('portable','portable','ADJ',3,'amod',None),('charger','charger','NOUN',0,'root',None)])
 assert'adjective_argument'in codes(r,'(t / thing :ARG0-of (c / charge-03 :ARG1 (p / portable)))')
 assert'adjective_argument'not in codes(r,'(c / charger :mod (p / portable))')

def test_degree_reification_and_predicative_color_values_are_allowed():
 r=record('Smaller boats.', [('Smaller','small','ADJ',2,'amod',None),('boats','boat','NOUN',0,'root',None)])
 assert'adjective_argument'not in codes(r,'(b / boat :ARG1-of (h / have-degree-91 :ARG2 (s / small) :ARG3 (m / more)))')
 r=record('Orange tint.', [('Orange','orange','ADJ',2,'amod',None),('tint','tint','NOUN',0,'root',None)])
 assert'adjective_argument'not in codes(r,'(t / tint-01 :ARG2 (o / orange))')

def test_metalinguistic_reference_to_an_adjective_is_not_a_noun_participant_error():
 r=record('Tall building.', [('Tall','tall','ADJ',2,'amod',None),('building','building','NOUN',0,'root',None)])
 assert'adjective_argument'not in codes(r,'(b / building :mod (t / tall :ARG1-of (m / mean-01 :ARG2 (s / story :quant 23))))')

def test_result_state_does_not_silently_license_an_agentive_action():
 r=record('Man has eyes closed.', [('Man','man','NOUN',2,'nsubj',None),('has','have','VERB',0,'root','VerbForm=Fin'),('eyes','eye','NOUN',2,'obj',None),('closed','close','VERB',2,'xcomp','VerbForm=Part|Tense=Past')])
 assert'result_state_agent'in codes(r,'(c / close-01 :ARG0 (m / man :part (e / eye)) :ARG1 e)')
 assert'result_state_agent'not in codes(r,'(e / eye :mod (c / closed) :part-of (m / man))')

def test_perfect_action_is_not_a_have_object_participle():
 r=record('Man has closed eyes.', [('Man','man','NOUN',3,'nsubj',None),('has','have','AUX',3,'aux',None),('closed','close','VERB',0,'root','VerbForm=Part|Tense=Past'),('eyes','eye','NOUN',3,'obj',None)])
 assert'result_state_agent'not in codes(r,'(c / close-01 :ARG0 (m / man) :ARG1 (e / eye))')

def test_media_location_requests_scope_but_video_recording_location_does_not():
 r=record('People in video.', [('People','person','NOUN',0,'root',None),('in','in','ADP',3,'case',None),('video','video','NOUN',1,'nmod',None)])
 assert'media_location'in codes(r,'(b / be-located-at-91 :ARG1 (p / person) :ARG2 (v / video))')
 assert'media_location'not in codes(r,'(v / video :topic (p / person))')
 assert'media_location'not in codes(r,'(t / take-01 :ARG1 (v / video) :location (c / city))')

def test_media_boundary_must_not_end_a_velocity():
 r=record('End of video velocity.', [('End','end','NOUN',0,'root',None),('of','of','ADP',3,'case',None),('video','video','NOUN',1,'nmod',None),('velocity','velocity','NOUN',1,'nmod',None)])
 assert'media_time_attachment'in codes(r,'(e / end-01 :ARG1 (v / velocity))')
 assert'media_time_attachment'not in codes(r,'(e / end-01 :ARG1 (v / video))')

def test_duplicate_time_values_require_a_single_value_or_explicit_interval():
 r=record('Video.', [('Video','video','NOUN',0,'root',None)])
 assert'time_cardinality'in codes(r,'(v / video :time (d / date-entity :time "T+" :time "57:24"))')
 assert'time_cardinality'not in codes(r,'(v / video :time (d / date-interval :op1 (a / date-entity :time "10:00") :op2 (b / date-entity :time "11:00")))')
