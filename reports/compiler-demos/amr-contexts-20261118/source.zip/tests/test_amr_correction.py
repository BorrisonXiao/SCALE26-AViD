import json
import pytest
from probabilistic_verification.amr_correction import apply_edits,graph_data,edit_source_checks,output_schema,request,evaluate

def test_indexed_edit_can_correct_a_name_without_replacing_the_claim():
 g=graph_data('(p / person :name (n / name :op1 "IPCC"))');i=g['triples'].index(['n',':op1','"IPCC"'])
 new=apply_edits(g,dict(top='p',edits=[dict(op='replace',index=i,triple=['n',':op1','"IPC"'])]))
 assert'"IPC"'in new and'IPCC'not in new and'person'in new

def test_two_edits_cannot_refer_to_the_same_original_index():
 g=graph_data('(p / person)')
 with pytest.raises(ValueError,match='twice'):apply_edits(g,dict(top='p',edits=[dict(op='remove',index=0),dict(op='replace',index=0,triple=['p',':instance','man'])]))

def test_dangling_node_and_unsupported_role_are_refused():
 g=graph_data('(p / person)')
 for triple in [['p',':ARG1','missing'],['p',':invented-role','"x"']]:
  with pytest.raises(ValueError):apply_edits(g,dict(top='p',edits=[dict(op='add',triple=triple)]))

def test_empty_edit_list_is_an_explicit_refusal():
 with pytest.raises(ValueError,match='model_refuse'):apply_edits(graph_data('(p / person)'),dict(top='p',edits=[]))

def test_failed_edits_retain_the_graph_without_recursive_runner_metadata():
 r=dict(claim_id='x',text='Person.',tokens=[]);current=dict(claim_id='x',text=r['text'],normalised_amr='(p / person)',output={'status':'unsupported'},response_raw='old response')
 out=evaluate(r,current,'{"top":"p","edits":[]}')
 assert out['code']=='model_refuse'and out['normalised_amr']=='(p / person)'
 assert'output'not in out and'response_raw'not in out

def test_scope_head_cannot_disappear_to_pass_a_compiler():
 r=dict(claim_id='x',text='A robot may fall.',tokens=[])
 issues=edit_source_checks(r,graph_data('(p / possible-01 :ARG1 (f / fall-01 :ARG1 (r / robot)))'),graph_data('(f / fall-01 :ARG1 (r / robot))'))
 assert any(x['code']=='dropped_scope_head'for x in issues)

def test_original_source_alignment_survives_across_retry_checks():
 r=dict(claim_id='x',text='Red car.',tokens=[dict(id=1,text='Red',lemma='red',upos='ADJ',head=2,deprel='amod'),dict(id=2,text='car',lemma='car',upos='NOUN',head=0,deprel='root')]);original=graph_data('(c / car :mod (r / red))');changed=graph_data('(c / car)')
 assert any(x['code']=='dropped_aligned_content'for x in edit_source_checks(r,original,changed))
 # Rechecking against the initial graph still catches the omission, even if
 # the current graph in a later round no longer contains its old node.
 current=dict(normalised_amr='(c / car)',errors=[])
 retry=json.dumps(dict(top='c',edits=[dict(op='add',triple=['x1',':instance','bright']),dict(op='add',triple=['c',':mod','x1'])]))
 result=evaluate(r,current,retry,original_graph=original)
 assert result['status']=='unsupported'and any(x['code']=='dropped_aligned_content'for x in result['errors'])

def test_feedback_and_generic_keep_original_errors_without_reference_labels():
 r=dict(text='A car.',tokens=[]);current=dict(normalised_amr='(c / car)',errors=[dict(code='new_error',reason='New compiler error')]);initial=dict(original_direct_error=dict(code='original_error',reason='Original failure'),output=dict(errors=[dict(code='first_amr_error',reason='Initial AMR failure')]))
 for guided in [True,False]:
  messages,schema=request(r,initial,current,previous='{}',feedback=guided);user=json.loads(messages[1]['content']);assert user['original_direct_error']['code']=='original_error'and user['initial_amr_errors'][0]['code']=='first_amr_error';assert('compiler_errors'in user)==guided;assert'Version'not in messages[1]['content']and'reference'not in user
