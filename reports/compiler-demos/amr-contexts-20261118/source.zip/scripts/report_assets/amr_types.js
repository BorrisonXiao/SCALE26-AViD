(() => {
  const el = id => document.getElementById(id);
  if (!el('typed-case')) return;
  const esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let rows = [];
  function show(save = false) {
    const row = rows.find(x => x.claim_id === el('typed-case').value);
    if (!row) return;
    const condition = el('typed-condition').value, out = row[condition], c = out.compilation;
    el('typed-text').textContent = row.text;
    el('typed-reference').textContent = row.reference.meaning;
    el('typed-verdict').textContent = 'After-change meaning review: ' + row.review.whole_reading.replaceAll('_', ' ') + '. Selected compilation: ' + (out.program ? 'program generated; ' + (out.errors.length ? 'checks flag it' : 'checks pass') : 'no program');
    el('typed-reason').textContent = row.review.reason;
    el('typed-provenance').textContent = row.review.provenance + '. Reviews concern text meaning, not media support.';
    el('typed-graph').innerHTML = row.svg;
    el('typed-checks').innerHTML = out.errors.length ? '<ul>' + out.errors.map(e => '<li><b>' + esc(e.code.replaceAll('_', ' ')) + ':</b> ' + esc(e.reason) + (e.value || e.text ? ' [' + esc(e.value || e.text) + ']' : '') + '</li>').join('') + '</ul>' : '<p>No automatic flag. This is not a certificate of correct meaning.</p>';
    if (c) {
      const m = c.metadata, types = m.predicate_types || {}, by = Object.fromEntries(c.atoms.map(a => [a.id, a]));
      const describe = v => { const variable = c.variables.find(x => x.name === v); return variable ? v + ' (' + variable.description + ')' : v; };
      const special = Object.entries(types).filter(([, t]) => ['property', 'nominal_event', 'structural_relation'].includes(t.kind));
      el('typed-types').innerHTML = special.length ? '<ul>' + special.map(([node, t]) => '<li>' + esc(node + ' / ' + t.concept + ': ' + t.kind.replaceAll('_', ' ')) + (t.derivational ? ' — aligned through an event-noun derivation' : '') + '</li>').join('') + '</ul>' : '<p>No source-based type changes in this selected compilation.</p>';
      const norm = m.normalization || {};
      const aliases = Object.values(norm.name_aliases || {}).map(x => '<li>Verified alias: ' + esc(x.source) + ' = ' + esc(x.graph) + '</li>');
      const units = (norm.trace || []).map(x => '<li>' + esc(x.kind.replaceAll('_', ' ')) + (x.source ? ': ' + esc(x.source) : '') + '</li>');
      if (aliases.length + units.length) el('typed-types').innerHTML += '<ul>' + aliases.concat(units).join('') + '</ul>';
      function atom(a) {
        const v = a.arguments; let text;
        if (a.predicate === 'concept') text = describe(v[0]) + ' must match ' + v[1];
        else if (a.predicate === 'role') text = describe(v[0]) + ' — ' + v[1] + ' → ' + describe(v[2]);
        else if (a.predicate === 'name') text = describe(v[0]) + ' must have name “' + v[1] + '”';
        else if (a.predicate === 'proposition') text = describe(v[0]) + ' has ' + v[1] + ' in ' + v[2] + ' context ' + v[3];
        else if (a.predicate === 'reference') text = 'Use the same ' + describe(v[0]) + ' in this context';
        else if (a.predicate === 'temporal') text = describe(v[0]) + ': ' + ({pres:'present',past:'past'}[v[1]] || v[1]) + ' tense; ' + v[2] + ' aspect';
        else if (a.predicate === 'written_text') text = describe(v[0]) + ' must contain written text “' + v[1] + '”';
        else text = describe(v[0]) + ': ' + v[1] + (v[2] ? ' = ' + describe(v[2]) : '');
        return '<p class="amr-condition">' + esc(text) + ' <small>[' + esc(v[v.length-3]) + '; ' + esc(v[v.length-1]) + ']</small></p>';
      }
      function formula(e) {
        if (e.op === 'atom') return atom(by[e.atom_id]);
        if (e.op === 'constant') return '<p>' + esc(e.state) + '</p>';
        if (e.op === 'exists') return formula(e.children[0]);
        if (e.op === 'not') return '<div class="box amr-negative"><b>NOT: no matching assignment satisfies these conditions</b>' + formula(e.children[0]) + '</div>';
        if (e.op === 'or') return '<div class="box"><b>OR: at least one branch holds</b>' + e.children.map((x, i) => '<div class="box"><b>Branch ' + (i+1) + '</b>' + formula(x) + '</div>').join('') + '</div>';
        return e.children.map(formula).join('');
      }
      const contexts = Object.entries(m.scopes).map(([id, s]) => '<li>' + esc(id + ': ' + s.kind + '; owner ' + s.owner + ' / ' + m.concepts[s.owner] + '; parent ' + s.parent + '; route ' + s.route) + '</li>');
      el('typed-conditions').innerHTML = '<p>Repeated IDs refer to the same candidate. Conditions are required together unless an OR/NOT box says otherwise. “world” names the outer claim; it does not certify world truth.</p>' + (contexts.length ? '<ul>' + contexts.join('') + '</ul>' : '<p>No embedded context.</p>') + formula(c.expression);
    } else {
      el('typed-types').textContent = 'No complete logical form was generated. Earlier source checks and the final conversion error are shown above.';
      el('typed-conditions').textContent = 'Compilation refused. No partial graph is presented as a complete claim.';
    }
    el('typed-exact').textContent = out.raw + '\n\n' + (c?.logical_form || 'No complete logical form') + '\n\n' + (out.program || 'No emitted program') + '\n\n' + JSON.stringify(c?.metadata || out.source_trace || {}, null, 2);
    const u = new URL(location); u.searchParams.set('typed_claim', row.claim_id); u.searchParams.set('typed_condition', condition); u.hash = 'amr-types-example';
    el('typed-share').href = u.pathname + u.search + u.hash;
    if (save) { history.replaceState(null, '', u); window.dispatchEvent(new Event('hashchange')); }
  }
  fetch('compiler-demos/amr-types-20261115/cases.json').then(r => { if (!r.ok) throw Error('Could not load examples'); return r.json(); }).then(data => {
    rows = data;
    for (const r of rows) { const o = document.createElement('option'); o.value = r.claim_id; o.textContent = r.review.whole_reading.replaceAll('_', ' ') + ' · ' + r.text; el('typed-case').append(o); }
    const query = new URLSearchParams(location.search), cid = query.get('typed_claim');
    el('typed-case').value = rows.some(r => r.claim_id === cid) ? cid : 'TQKCK6-tRaoE_662';
    if (['before','after'].includes(query.get('typed_condition'))) el('typed-condition').value = query.get('typed_condition');
    show(); window.dispatchEvent(new Event('hashchange'));
  }).catch(e => el('typed-verdict').textContent = e.message);
  el('typed-case').addEventListener('change', () => show(true));
  el('typed-condition').addEventListener('change', () => show(true));
})();
