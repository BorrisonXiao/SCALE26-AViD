(()=>{
 const el=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 if(!el('correction-case'))return;let rows=[];
 function conditions(c){
  const by=Object.fromEntries(c.atoms.map(a=>[a.id,a])),describe=v=>{const x=c.variables.find(x=>x.name===v);return v+(x?' ('+x.description+')':'');};
  function atom(a){const v=a.arguments;let s;
   if(a.predicate==='concept')s=describe(v[0])+' must match '+v[1];
   else if(a.predicate==='role')s=describe(v[0])+' — '+v[1]+' → '+describe(v[2]);
   else if(a.predicate==='name'||a.predicate==='written_text')s=describe(v[0])+' must '+(a.predicate==='name'?'have name':'contain written text')+' “'+v[1]+'”';
   else if(a.predicate==='proposition')s=describe(v[0])+' has '+v[1]+' in '+v[2]+' context '+v[3];
   else if(a.predicate==='reference')s='Use the same '+describe(v[0])+' in this context';
   else if(a.predicate==='member')s=describe(v[1])+' is a member of '+describe(v[0]);
   else if(a.predicate==='group')s=describe(v[0])+' is an AND group';
   else if(a.predicate==='grammatical_number')s=describe(v[0])+' has source grammatical number '+v[1];
   else if(a.predicate==='temporal')s=describe(v[0])+': '+v[1]+' tense; '+v[2]+' aspect';
   else s=describe(v[0])+': '+v[1]+' = '+v[2];
   return '<p class="amr-condition">'+esc(s)+' <small>['+esc(v[v.length-3])+'; '+esc(v[v.length-1])+']</small></p>';
  }
  function form(e){if(e.op==='atom')return atom(by[e.atom_id]);if(e.op==='constant')return '<p>'+esc(e.state)+'</p>';if(e.op==='exists')return form(e.children[0]);if(e.op==='not')return '<div class="box amr-negative"><b>NOT</b>'+form(e.children[0])+'</div>';if(e.op==='or')return '<div class="box"><b>OR: at least one branch</b>'+e.children.map((x,i)=>'<div class="box"><b>Branch '+(i+1)+'</b>'+form(x)+'</div>').join('')+'</div>';return e.children.map(form).join('');}
  const scopes=Object.entries(c.metadata.scopes).map(([id,s])=>'<li>'+esc(id+': '+s.kind+'; parent '+s.parent+'; owner '+s.owner+'; route '+s.route)+'</li>').join('');
  return '<p>All conditions are required unless an OR/NOT box says otherwise. Same ID means the same candidate. Variables are existentially quantified; exact placement is in the optional logical form. These are evidence requirements, not media predictions.</p>'+(scopes?'<ul>'+scopes+'</ul>':'<p>No embedded context.</p>')+form(c.expression);
 }
 const errors=r=>r.errors?.length?'<ul>'+r.errors.map(x=>'<li>'+esc(x.code.replaceAll('_',' '))+': '+esc(x.reason)+(x.source_words?' Source: '+esc(x.source_words):'')+'</li>').join('')+'</ul>':'<p>No automatic error. This does not establish correct meaning.</p>';
 function edit_text(a){try{const d=JSON.parse(a.response_raw),nodes=Object.fromEntries(a.previous_graph.triples.filter(t=>t[1]===':instance').map(t=>[t[0],t[2]]));for(const e of d.edits)if(e.triple?.[1]===':instance')nodes[e.triple[0]]=e.triple[2];const label=n=>nodes[n]?n+' ('+nodes[n]+')':n;const triple=t=>!t?'missing original triple':t[1]===':instance'?'declare '+t[0]+' as '+t[2]:label(t[0])+' — '+t[1].slice(1)+' → '+label(t[2]);return '<p>Root: '+esc(label(d.top))+'</p><ul>'+d.edits.map(e=>'<li>'+esc(e.op==='add'?'Add: '+triple(e.triple):e.op==='remove'?'Remove: '+triple(a.previous_graph.triples[e.index]):'Replace '+triple(a.previous_graph.triples[e.index])+' with '+triple(e.triple))+'</li>').join('')+'</ul>';}catch{return '<p>The response could not be decoded.</p>';}}
 function show(save=false){
  const r=rows.find(x=>x.claim_id===el('correction-case').value);if(!r)return;const name=el('correction-condition').value,o=r.outputs[name];
  el('correction-text').textContent=r.text;el('correction-reference').textContent=r.reference.meaning;
  el('correction-cohort').textContent=(r.cohort==='followup'?'Follow-up of 24 claims; original readings frozen before new outputs. Same previously processed videos.':'Known development case; earlier meaning judgments reused only for identical programs.')+' Reviewer: implementing assistant.';
  el('correction-verdict').textContent=(o.status==='compiled'?'Automatic checks pass':'Automatic checks refuse')+' · meaning review: '+(o.review?.whole_reading||'not established').replaceAll('_',' ');
  el('correction-reason').textContent=o.review?.reason||o.reason||'No complete program is accepted from this output.';
  el('correction-failure-analysis').innerHTML=r.failure_analysis?'<h3>Failure diagnosis</h3><p>'+esc(r.failure_analysis.analysis)+'</p>':' ';
  el('correction-before-graph').innerHTML=r.before_svg;el('correction-after-graph').innerHTML=o.graph_unchanged?'<p>The graph is unchanged. This condition made no accepted graph edit; proposed changes and errors are below.</p>':o.svg;
  el('correction-errors').innerHTML=errors(o);
  el('correction-conditions').innerHTML=o.compilation?conditions(o.compilation):'<p>No compiled candidate: '+esc(o.reason||'')+'</p>';
  const attempts=name==='before'?[]:r.attempts.filter(x=>x.condition==='first'||name!=='first'&&x.condition.startsWith(name+'_'));
  el('correction-attempts').innerHTML=attempts.length?attempts.map((a,i)=>'<article class="box"><h4>Attempt '+(i+1)+' · '+esc(a.condition.replaceAll('_',' '))+'</h4>'+edit_text(a)+errors(a.output)+'<details><summary>Exact prompt, response and compiler result</summary><pre>'+esc(JSON.stringify(a.messages,null,2)+'\n\nRESPONSE\n'+a.response_raw+'\n\nCHECKS\n'+JSON.stringify(a.output.errors,null,2))+'</pre></details></article>').join(''):'<p>No model request in this condition. Passing originals and passing checked AMRs bypass generation.</p>';
  el('correction-numbered').innerHTML=r.numbered_pilot?'<p>This additional pilot compares implicit array positions and explicit index labels on12 development cases. It is separate from the primary comparison above.</p>'+r.numbered_pilot.attempts.map(a=>'<article class="box"><h4>'+esc(a.condition.replaceAll('_',' '))+'</h4>'+edit_text(a)+errors(a.output)+'<details><summary>Exact pilot prompt and response</summary><pre>'+esc(JSON.stringify(a.messages,null,2)+'\n\n'+a.response_raw)+'</pre></details></article>').join(''):'<p>Not selected for the additional12-case development diagnostic. No extra model calls.</p>';
  el('correction-exact').textContent=o.compilation?o.compilation.logical_form+'\n\nPROBLOG (placeholder candidates, no media)\n'+o.program:o.reason||'';
  const u=new URL(location);u.searchParams.set('correction_claim',r.claim_id);u.searchParams.set('correction_condition',name);u.hash='amr-correction-example';el('correction-share').href=u.pathname+u.search+u.hash;if(save){history.replaceState(null,'',u);window.dispatchEvent(new Event('hashchange'));}
 }
 fetch('compiler-demos/amr-correction-20261114/cases.json').then(r=>{if(!r.ok)throw Error('Could not load correction cases');return r.json();}).then(data=>{rows=data;for(const r of rows){const o=document.createElement('option');o.value=r.claim_id;o.textContent=(r.cohort==='followup'?'Follow-up':'Development')+' · '+r.text;el('correction-case').append(o);}const q=new URLSearchParams(location.search),cid=q.get('correction_claim'),name=q.get('correction_condition');el('correction-case').value=rows.some(r=>r.claim_id===cid)?cid:'TQKCK6-tRaoE_662';if(['before','first','feedback','generic'].includes(name))el('correction-condition').value=name;show();window.dispatchEvent(new Event('hashchange'));}).catch(e=>el('correction-verdict').textContent=e.message);
 el('correction-case').addEventListener('change',()=>show(true));el('correction-condition').addEventListener('change',()=>show(true));
})();
