(()=>{
 const $=id=>document.getElementById(id),esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
 let cases=[];
 function output(row,n){
  // Rejected candidates are displayed as candidates, never relabeled accepted.
  return ClaimOutputView.render(row.form?{...row,status:'compiled'}:row,row.metadata||{},n);
 }
 function show(id){
  const r=cases.find(x=>x.id===id);if(!r)return;$('component-select').value=id;$('component-text').textContent=r.text;$('component-note').textContent=r.note;
  for(const [key,n]of[['before',201],['after',202]]){
   const row=r[key];$('component-'+key+'-status').textContent=row.status==='compiled'?'Passes compiler checks.':'Rejected: '+(row.reason||row.code)+(row.form?' The structure below is the rejected diagnostic candidate.':'');
   $('component-'+key).innerHTML=output(row,n);
  }
  $('component-alignments').innerHTML=r.alignments.length?r.alignments.map(a=>'<li>“'+esc(a.text)+'” → '+esc(a.target)+' · '+esc(a.kind)+': '+esc(typeof a.value==='string'?a.value:JSON.stringify(a.value))+'</li>').join(''):'<li>No normalized value/relation alignment was emitted for this case.</li>';
  $('component-checks').textContent=Object.keys(r.checks).length?'Targeted checks: '+Object.entries(r.checks).map(([k,v])=>k.replaceAll('_',' ')+': '+(v?'pass':'fail')).join('; ')+'. These checks are not a whole-claim accuracy label.':'';
  $('component-exact').textContent=JSON.stringify({previous:r.before,shared_components:r.after},null,2);
  const u=new URL(location.href);u.searchParams.set('component',id);u.hash='component-example';$('component-share').href=u.pathname+u.search+u.hash;
 }
 $('component-select').addEventListener('change',e=>{show(e.target.value);history.replaceState(null,'',new URL($('component-share').href));});
 fetch('compiler-demos/components-20261112/cases.json').then(r=>{if(!r.ok)throw Error('Could not load the experiment examples.');return r.json();}).then(data=>{cases=data;$('component-select').innerHTML=cases.map(r=>'<option value="'+esc(r.id)+'">'+esc(r.title+' · '+r.text.slice(0,90))+'</option>').join('');const id=new URLSearchParams(location.search).get('component');show(cases.some(r=>r.id===id)?id:'TjHepwuhkYFA_1016__c1');}).catch(e=>{$('component-note').textContent=e.message;});
})();
