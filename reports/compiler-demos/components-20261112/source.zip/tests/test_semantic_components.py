"""Semantic invariants for the shared values and phrase-relation experiment."""
import copy,itertools,json
from pathlib import Path
import pytest
from probabilistic_verification.semantic_values import normalized_literal,temporal_literal,DATE_TIME
from probabilistic_verification.semantic_components import compile_components,compile_one,valid_alignment
from probabilistic_verification.compilation_followup import walk_events
from probabilistic_verification.logical_form import LogicalFormError

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/semantic_components_20261112'
RECORDS={r['claim_id']:r for r in map(json.loads,(RUN/'probe_parsed.jsonl').read_text().splitlines())}

@pytest.mark.parametrize('text',['2025-08-19','2025/08/19','August 19, 2025','19 August 2025'])
def test_equivalent_calendar_forms_have_one_value(text):
    assert temporal_literal(text)==dict(kind='date',value='2025-08-19')

def test_calendar_and_clock_are_one_value_without_invented_timezone():
    assert temporal_literal('2025-03-28 12:46:35')==dict(kind='time',value='2025-03-28T12:46:35')
    assert temporal_literal('12:46:35')==dict(kind='time',value='12:46:35',attribute='unspecified_time_scale')

@pytest.mark.parametrize('text',['February 30, 2025','2025-13-01','25:01 PM','12:65'])
def test_invalid_times_are_refused(text):
    with pytest.raises(LogicalFormError):temporal_literal(text)

def test_date_and_duration_operators_remain_distinct():
    assert temporal_literal('before March 17, 2025')['operator']=='before'
    assert temporal_literal('after March 17, 2025')['operator']=='after'
    assert normalized_literal('for five minutes')['kind']=='duration'
    assert normalized_literal('five meters')['kind']=='measurement'
    assert normalized_literal('Flight 2025')is None
    assert temporal_literal('2025')is None

def test_values_do_not_depend_on_original_wording():
    a=normalized_literal('five meters');b=normalized_literal('5 meters')
    assert {k:v for k,v in a.items()if k!='text'}=={k:v for k,v in b.items()if k!='text'}
    assert not list(DATE_TIME.finditer('ratio100:30 labelX2025-03-28'))

def test_elapsed_time_is_not_silently_coerced_to_a_clock():
    assert temporal_literal('at T+ 57:24')==dict(kind='time',value='57:24',attribute='elapsed')
    value=temporal_literal('0:00');assert value['value']=='0:00'and value['attribute']=='unspecified_time_scale'

def test_explicit_zone_label_is_retained_without_guessing_an_offset():
    value=temporal_literal('July 19, 2025, 00:00 BJT')
    assert value==dict(kind='time',value='2025-07-19T00:00:00',timezone='BJT')
    assert temporal_literal('2025/07/18 12:30:00Z')['timezone']=='Z'

def test_repeated_time_arguments_keep_their_types_and_original_spans():
    source=ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl'
    record=next(r for r in map(json.loads,source.read_text().splitlines())if r['claim_id']=='T8u81WMIyj18_754')
    row=compile_one(record);assert row['status']=='compiled'
    event=next(walk_events(row['proposed_form']))
    assert event['arguments']['ARGM-TMP']['value']=='01:50:00'
    assert event['adjuncts'][0]['target']==dict(kind='date',value='2025-08-19')
    assert all(valid_alignment(row['proposed_form'],a)for a in row['compilation']['metadata']['source_alignments'])

def test_before_after_are_distinct_compiled_requirements():
    a,_=compile_components(RECORDS['before']);b,_=compile_components(RECORDS['after'])
    av=[x.arguments for x in a.atoms if x.predicate=='record'];bv=[x.arguments for x in b.atoms if x.predicate=='record']
    assert av!=bv and any('before'in v for args in av for v in args)and any('after'in v for args in bv for v in args)

def test_reference_role_keeps_both_participants_and_source_alignment():
    row=compile_one(RECORDS['motion_relative']);assert row['status']=='compiled'
    f=row['proposed_form'];event=next(walk_events(f));entities={e['id']:e for e in f['entities']}
    assert entities[event['arguments']['reference']]['text']=='buoy'
    assert [p['value']for p in event.get('properties',[])if p['role']=='preposition:reference']==['relative to']
    assert any(entities[v]['text']=='boat'for k,v in event['arguments'].items()if k!='reference')
    assert all(valid_alignment(f,a)for a in row['compilation']['metadata']['source_alignments'])
    assert 'reference'not in next(walk_events(compile_one(RECORDS['motion_towards'])['proposed_form']))['arguments']

def test_reference_is_not_assigned_to_adjective_or_topic():
    for cid in ['relative_adjective','topic_respect']:
        row=compile_one(RECORDS[cid]);assert not any('reference'in e.get('arguments',{})for e in walk_events(row.get('proposed_form',{})))

def test_date_conversion_does_not_change_cached_parse():
    record=copy.deepcopy(RECORDS['date_nominal']);before=copy.deepcopy(record)
    row=compile_one(record);assert row['status']=='compiled'and record==before
    assert row['compilation']['metadata']['source_alignments']

@pytest.mark.parametrize('cid',['depicted','negation','modal','while'])
def test_reference_survives_existing_scoped_operators(cid):
    row=compile_one(RECORDS[cid]);assert row['status']=='compiled'
    assert any('reference'in e.get('arguments',{})for e in walk_events(row['proposed_form']))

def test_quoted_events_are_not_required_as_independent_assertions():
    source=ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl'
    record=next(r for r in map(json.loads,source.read_text().splitlines())if r['claim_id']=='TFOEIehBwT8Q_505')
    row=compile_one(record)
    assert not any(a.get('code')=='missing_event'for a in row.get('structural_alerts',[]))

@pytest.mark.parametrize('cid,expected',[('motion_relative','supported'),('reference_swap','refuted')])
def test_native_inference_keeps_reference_and_moving_entity_in_the_same_event(cid,expected):
    from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground
    from probabilistic_verification.direct_backend import DirectVerifier
    claim,_=compile_components(RECORDS[cid]);meta=claim.metadata
    domains={v.name:[meta['entities'][v.name]['text'].lower()if v.name in meta['entities']else'move1']for v in claim.variables}
    evidence=Evidence('constructed-motion',domains,{v.name:True for v in claim.variables},{})
    for atom in claim.atoms:
        names=[v.name for v in claim.variables if v.name in atom.arguments]
        for values in itertools.product(*(domains[n]for n in names)):
            assignment=dict(zip(names,values));state='supported'
            if atom.predicate=='move':
                args=[assignment.get(x,x)for x in atom.arguments];roles=dict(zip(args[1::2],args[2::2]))
                moving=next((roles[k]for k in ['ARG0','ARG1','nsubj']if k in roles),None)
                state='supported'if moving=='boat'and roles.get('reference')=='buoy'else'refuted'
            key=canonical_key(evidence.media_id,atom,assignment,evidence.route)
            evidence.observations[key]=Observation(key,(1.,0.,0.)if state=='supported'else(0.,1.,0.),False,'Constructed observation; no media model')
    result=DirectVerifier([ground(claim,evidence)],learned=False).predict()[0]['distribution']
    assert result[expected]==pytest.approx(1.)
