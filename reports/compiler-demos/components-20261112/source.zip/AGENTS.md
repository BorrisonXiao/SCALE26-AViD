# AViD project guidance

## Latest shared-component experiment — 12 November 2026

User authorized a bounded test of general temporal/quantity normalization, phrase relations, source alignments and checks, then cached replay. Read docs/semantic_components_20261112.md and exp/probabilistic_verification/semantic_components_20261112/summary.json. No new model requests/media inference/empirical training. ADR-023 and direct-failure-only rewriting remain unchanged.

Completed:36 author-written construction probes (2motivating/34variants, not independent heldout) improve targeted checks10/36→34/36. Fixed1437cachedclauses1140→1147pass;87completeprograms on449(previous84). Nine changed/newprograms inspected;78exactprogram/form judgments reused. Thirtycohortoutputs approved(previous27),57notapproved. Three newdate/time recoveries are balanced by three newly reviewed legacy exclusions with opaque temporal/event content: TgR_u37mCoQ4_1831,_1908,_1924. Revised combined pool remains1953/2375=82.23%,422remaining. Do not claim1956 or that allprevious1926acceptedrows remain valid/unchanged.

Automatic DIRECT counts on2375originals also1953before/after, but membership/acceptance differs from reviewedcombinedpool;3newpasses/3newrefusals,123changedprograms. Neither is semanticaccuracy. Shared normalization is opt-in;385tests pass incl25new/2controllednativebindingchecks; default2375outputs exact. Three core files have compatible extensions, including phrase-marker deduplication. Baretimecodes retain unspecifiedscale; explicitT+ elapsed; timezone labels preserved without guessedoffsets. Repeatedtypedtimes keep their types. Bounded motion-reference/spatialphrase inventory, not generalprepositionunderstanding. Focalterrainclaim date/relative repairedlocally, wholeclaimstillfails Duringthis time/shift event reference. Nominalcollapse and ambiguous inrelationto remainprobelimitations.

Current report staysexistingOverview/Examples/fiveviews/twoReportscards. Old449model inspector/sourcebundles remain historical. Proposed next: event/interval coreference, bounded nominal-event analysis, then freeze components and evaluate newclaims before further expansion/training. Detailed provenance/development corrections in newRUN; do not rerun old packagers or overwrite historical proofs.


## Earlier full failure-cohort result — 12 November 2026

The user authorized the bounded role/identifier and measurement/absence repairs, plus rewrite+compilation on ALL449 previous rejects. This supersedes earlier restrictions against expanding the31-case experiment. Read docs/rewrite_all_20261112.md and exp/probabilistic_verification/rewrite_all_20261112/summary.json. ADR-023 and failure-only generation remain unchanged; no new empirical relation training or media inference is authorized by this compilation experiment.

Completed:30 direct automatic passes bypass the model;419 final frozen Qwen requests produce1,437 clauses.207 cases stop at component compilation,142 at alignment,14 at composition,2 at model refusal;54 composed programs plus30 direct programs receive hash-bound compiler-author meaning review.27 additions approved (14direct/13rewrite),57 not approved. Previous1,926 passes retained exactly:1,953/2,375=82.23%;422 remain. This is development compilation coverage with27 newly reviewed additions, NOT semantic accuracy; prior1,926 were not all re-reviewed. Automatic checks alone would retain2,010=84.63%, including unfaithful programs.

Current code adds opt-in repeated adjuncts, measurements/ranges/scalar magnitude, bounded NOT EXISTS absence, explicit participant IDs and source-use alignment. Five original core files have backward-compatible extensions; the historical default exactly reproduces all2,375 saved outputs. The old38-file snapshot is preserved in baseline_source; do not claim current files remain frozen.360 tests pass. Actual native absence checks use constructed inventories, not media. Final H100 job1226791 completed419 requests; initial1226788 completed418 and is entirely excluded. Resources released. One fixed final prompt; no per-claim attempt/prompt selection.

Keep current results and all449 examples in compiler-demos.html Overview/Examples (five views; two Reports cards). Earlier inspectors/URLs/25 archives/26 original viewer files remain. Proposed next: preserve OR/while/modality/source scope in composition; improve class-description/original-span/group reference resolution; replay cached419 responses and review any new programs before another model run or relation training. Keep completion next steps and goals explicit.


## Report organization and communication — confirmed12 November2026

Keep current compiler/rewrite work in the existing compiler-demos.html; do not create a new report page for every iteration. Reports/index.html has two main entries, with old reports under the compiler report History. Main report views: Overview, Examples, All claims, Daily log, History. Preserve old URLs, source bundles and case inspectors. The user also requested fewer interim progress updates: keep them brief and meaningful, and avoid repeating full experiment reports. Required tool/progress communication still applies.

Before the full-cohort experiment, the449 failures included29 tested unrecovered and420 never rewritten. Do not claim the rewrite failed on all19% or infer corpus recovery from the deliberately selected31-case pilot. First checks group227 parser/compiler predicate formation,173 omitted content,43 unsupported operators/types,6 explicit alignment/controller/media checks; these are not a full semantic taxonomy. No new model/compiler experiment in this consolidation. See docs/compiler_report_consolidation_20261112.md.


## Earlier alignment and full-corpus result —12 November2026

Read docs/split_alignment_20261112.md. The user authorized sentences-only generation plus separate original-mention alignment and a fixed evaluation/full-corpus rate. This completed experiment does not authorize unrestricted automatic fallback or new learning. One frozen Qwen prompt on the same31 direct failures returns only action/sentences; a separate module aligns unique original noun/event mentions and refuses ambiguous/unsupported cases. The38 direct-compiler files stay frozen.

Fresh2375 originals exactly reproduce1924 content-check passes (81.01%) and2103 candidates (88.55%). Two reviewed automatic outputs (Trump/image and police officers) in the fixed sentences-only condition yield1926/2375 passes (81.09%),2105 candidates (88.63%),449 failures. These are development compilation counts, not whole-corpus semantic accuracy. No manual clauses counted. The earlier1927 is a separate single-sentence diagnostic, not a cumulative production count.

Old sentences+new alignment recover2 (officers/robot); new sentences-only+alignment recover2 (Trump/officers), with different membership. Do not union best outputs across prompts. The new prompt still invents narration/construction and expands quotes; quantity/source/reference limitations remain. All62 comparisons are assistant reviewed, not independent gold.42 focused tests; source/browser/publication evidence logged separately. Next proposals: bounded participant-ID/source-frame handling, then typed measurement/absence contracts and another full census before expanded evaluation or DeepProbLog training.


## Sentence splitting fallback — user clarification12 November2026

The intended rewrite is split-and-rephrase: break a difficult claim into simpler subclaims while retaining meaning, shared entities/events and depiction/speech/OCR or other context links. The earlier one-sentence restriction was too narrow and is historical. Keep direct compilation first and never rewrite a passing original. No automatic scale-up is enabled.

Read docs/claim_split_20261112.md and the report Sentence splitting tab. One frozen Qwen prompt on31 previously inspected failures produces65/77 passing clauses and20 all-component passes, but0 approved complete automatic results. Seven selected assistant-written splits give18/18 component passes and4 faithful linked compositions; an eighth no-audio guard is refused. These are compiler-author diagnostics, not model gains, independent gold or corpus accuracy. Frozen38 direct-compiler files stay unchanged. New adapter preserves context and shared mentions; original corpus counts stay2103/1924. No new media/native inference/training. Proposed next: simplify generation/reference alignment, then repeat a fixed fidelity evaluation before scale-up.


## Current paper direction — accepted 2026-10-14

Follow ADR-023 in docs/project_notes/decisions.md: probabilistic parsing for multimodal claim verification. Compile claims into probabilistic logic, keep media models frozen, and learn small relation classifiers. Predefined and learned functions are interchangeable; inference considers alternative evidence assignments. An existing DeepProbLog-like backend is a valid implementation choice.

The user selected this as the paper direction, likely finalized. Earlier tree-CRF and temporal-only proposals are historical comparisons. Experimental results can refine the design; do not automatically reopen the paper direction from old notes.

Read site/proposals/probabilistic-verification.html or its generator scripts/build_probabilistic_verification_proposal.py for the current design. Logistic regression and a small MLP are the initial classifiers; frozen BERT-style features are optional. Decoder-only models remain frozen evidence/parsing modules or baselines.

## Terminology and memory

- Read docs/project_notes/terminology.md and CLAUDE.md before writing documentation or implementation.
- Use standard NLP terms and plain language. Define semantic roles, logical forms, neural predicates, and calibration when needed. Do not invent labels or acronyms for familiar components.
- Check decisions.md before architecture changes, key_facts.md before experiments, and bugs.md when diagnosing known failures. Log significant work in issues.md.
- Keep supported/refuted/insufficient evidence distinct, preserve evidence-route meaning, and distinguish source assertions from direct event evidence.
- Keep proposed methods and resource estimates separate from completed experiments. Never infer new accuracy results from this design page.
- Preserve existing evaluation annotations and artifacts. Use separate training/calibration data and split by source video.

## Rewrite fallback — confirmed12 November2026

Compile the original claim first. Only a strict unsupported result may trigger rewriting; this includes a diagnostic candidate rejected by content checks. A compiled original must be returned unchanged, without loading/querying the rewriter. A separate semantic concern is not a trigger when direct compilation passes. Historical passing-control/guard model probes are diagnostic records, not exceptions to this policy. Keep exact prompts, model settings, raw responses and failure reasons inspectable.
