#!/bin/bash
#SBATCH --job-name=avid-fallback-missing
#SBATCH --partition=gpu
#SBATCH --gres=gpu:h100:1
#SBATCH --exclude=rack3n06
#SBATCH --cpus-per-task=8
#SBATCH --mem=100G
#SBATCH --time=00:20:00
#SBATCH --output=/exp/cxiao/scale26/avid/exp/probabilistic_verification/compiler_fallback_20261118/missing_%j.out
#SBATCH --error=/exp/cxiao/scale26/avid/exp/probabilistic_verification/compiler_fallback_20261118/missing_%j.err
set -euo pipefail
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4 PYTHONDONTWRITEBYTECODE=1
cd /exp/cxiao/scale26/avid
envs/probabilistic-verification/bin/python -u scripts/generate_fallback_missing.py
