"""Routing, source semantics and distinct parse/evidence failures."""
import copy
import pytest
from probabilistic_verification.compiler_fallback import compile_claim,check_output,verify,restore,serialize
from probabilistic_verification.fallback_semantics import source_triggers,qualify_root_modal,written_quotes,shared_checks
from probabilistic_verification.fallback_amr import prepare_fallback,compile_fallback_amr
from probabilistic_verification.logical_form_v2 import ScopedClaim
from probabilistic_verification.representation import Atom,Expression as E,Variable

def simple(text='Alice runs.',tokens=(),cid='test'):
    a=Atom('a1','run',('E1','scope','world','route','unspecified'),'relation',(),'run',(),True)
    return ScopedClaim(cid,text,tuple(tokens),(Variable('E1','event','run',()),),(a,),E.exists(['E1'],E.atom('a1')),(),(),metadata={'scopes':{},'allowed_routes':{'a1':['unspecified']}})

def row(claim=None,status='compiled'):
    if status!='compiled':return dict(status=status,code='test_refusal',reason='No complete source meaning.')
    return dict(status='compiled',**serialize(claim or simple()))

def would_record(embedded=False):
    return dict(claim_id='conditional',text='The rate would be 20%.',tokens=[dict(id=1,text='would',lemma='would',upos='AUX',head=2,deprel='aux'),dict(id=2,text='rate',lemma='rate',upos='NOUN',head=3 if embedded else 0,deprel='ccomp'if embedded else'root')])

def test_success_skips_both_fallbacks():
    def forbidden(*args):raise AssertionError('Later stage must not run')
    r=compile_claim(dict(claim_id='test',text='Alice runs.',tokens=[]),srl=lambda _:row(),amr=forbidden,rewrite=forbidden)
    assert r['selected_stage']=='srl'and len(r['attempts'])==1

def test_amr_runs_only_after_srl_failure():
    calls=[]
    def amr(r):calls.append('amr');return row()
    r=compile_claim(dict(claim_id='test',text='Alice runs.',tokens=[]),srl=lambda _:row(status='unsupported'),amr=amr,rewrite=lambda *_:pytest.fail('rewrite ran'))
    assert calls==['amr']and r['selected_stage']=='amr'

def test_rewrite_receives_both_previous_errors():
    seen=[]
    def rewrite(r,attempts):seen.extend(a['stage']for a in attempts);return row()
    r=compile_claim(dict(claim_id='test',text='Alice runs.',tokens=[]),srl=lambda _:row(status='unsupported'),amr=lambda _:row(status='unsupported'),rewrite=rewrite)
    assert seen==['srl','amr']and r['selected_stage']=='rewrite'

def test_exceptions_do_not_drop_claims():
    def error(_):raise ValueError('Bad graph')
    r=compile_claim(dict(claim_id='test',text='Alice runs.',tokens=[]),srl=error,amr=error)
    assert r['parsing_status']=='abstained'and r['output']is None and len(r['attempts'])==3

def test_parse_failure_never_calls_evidence_verifier():
    r=verify(dict(claim_id='x',parsing_status='abstained'),lambda _:pytest.fail('Evidence called on no program'))
    assert r['verdict']=='abstain'and r['distribution']is None and r['reason']=='parsing_failure'

def test_compiled_unknown_is_not_parse_failure():
    r=verify(dict(claim_id='x',parsing_status='compiled',output=row()),lambda _:dict(supported=0.,refuted=0.,unknown=1.))
    assert r['verdict']=='insufficient_evidence'and r['distribution']['unknown']==1

@pytest.mark.parametrize('distribution',[dict(supported=float('nan'),refuted=0.,unknown=1.),dict(supported=.9,refuted=.9,unknown=.1),dict(supported=.5,refuted=.5)])
def test_invalid_probabilities_rejected(distribution):
    with pytest.raises(ValueError):verify(dict(claim_id='x',parsing_status='compiled',output=row()),lambda _:distribution)

def test_roundtrip_preserves_structure():
    c=simple();assert restore(c.to_dict()).to_dict()==c.to_dict()

def test_would_preserves_qualification_and_context():
    record=would_record();c=simple(record['text'],record['tokens'],cid=record['claim_id']);changed,errors=qualify_root_modal(c,record)
    assert not errors
    assert changed.atoms[0].arguments[2]=='modal_would::conditional'
    assert changed.atoms[-1].predicate=='qualification'and changed.atoms[-1].arguments[0]=='would'
    assert c.atoms[0].arguments[2]=='world'

def test_would_scope_names_do_not_share_between_claims():
    r=would_record();a,_=qualify_root_modal(simple(cid='first'),r);b,_=qualify_root_modal(simple(cid='second'),r)
    assert a.atoms[-1].arguments!=b.atoms[-1].arguments

def test_embedded_would_is_not_wrapped_over_the_outer_claim():
    c=simple();changed,errors=qualify_root_modal(c,would_record(embedded=True));assert changed==c and errors[0]['code']=='modal_scope'

def test_would_qualification_idempotent():
    r=would_record();c,_=qualify_root_modal(simple(),r);d,e=qualify_root_modal(c,r);assert c==d and not e

def test_writing_quote_not_actual_modal():
    r=dict(text='A sign says "It would rain".',tokens=[dict(id=1,text='would',head=2,start_char=16,deprel='aux')]);assert not source_triggers(r)['would']

def test_poster_near_named_day_is_not_automatically_written_text():
    assert not written_quotes(dict(text='The poster appeared on "Liberation Day".'))

def test_graffiti_strings_are_detected():
    r=dict(text='"First" and "Second" written in graffiti.');assert len(written_quotes(r))==2

def test_simple_written_quote_requires_literal_binding():
    r=dict(text='A sign says "Hello".',tokens=[]);assert shared_checks(r,simple())[0]['code']=='written_quote_scope'

def test_plain_sentence_quotes_are_not_a_written_artifact():
    assert not shared_checks(dict(text='"Alice runs."',tokens=[]),simple())

def test_universal_cannot_be_one_existential_witness():
    r=dict(text='Everyone cheers.',tokens=[dict(id=1,text='Everyone',lemma='everyone',head=2)]);assert shared_checks(r,simple())[0]['code']=='universal_scope'

def test_generic_correlative_is_detected():
    r=dict(text='The faster it moves, the louder it sounds.',tokens=[dict(id=1,text='The',head=2),dict(id=2,text='faster',head=6,deprel='advcl',feats='Degree=Cmp'),dict(id=5,text='the',head=6),dict(id=6,text='louder',head=0,feats='Degree=Cmp')]);assert source_triggers(r)['comparative_generic']

def test_one_comparison_is_not_generic_correlative():
    r=dict(text='The faster robot wins.',tokens=[dict(id=1,text='The',head=2),dict(id=2,text='faster',head=3,deprel='amod',feats='Degree=Cmp')]);assert not source_triggers(r)['comparative_generic']

def test_graph_saying_carrier_preserves_exact_quote():
    text='A sign says "Mexico bleeds".'
    tokens=[dict(id=1,text='sign',lemma='sign',upos='NOUN',start_char=2,end_char=6),dict(id=2,text='says',lemma='say',upos='VERB',start_char=7,end_char=11),dict(id=3,text='Mexico',lemma='Mexico',upos='PROPN',start_char=13,end_char=19),dict(id=4,text='bleeds',lemma='bleed',upos='VERB',start_char=20,end_char=26)]
    r=dict(claim_id='quote',text=text,tokens=tokens)
    raw='(s / sign :ARG0-of (v / say-01 :ARG1 (b / bleed-01 :ARG1 (c / country :name (n / name :op1 "Mexico")))))'
    prepared=prepare_fallback(r,raw);claim=compile_fallback_amr(r,raw,strict=False,prepared=prepared)
    assert any(a.predicate=='written_text'and a.arguments[1]=='Mexico bleeds'for a in claim.atoms)
    assert 'bleed-01'not in claim.metadata['concepts'].values()

def test_shared_quote_reference_is_refused():
    r=dict(claim_id='shared',text='Mexico holds a sign saying "Mexico bleeds".',tokens=[dict(id=1,text='Mexico',lemma='Mexico',upos='PROPN',start_char=0,end_char=6),dict(id=2,text='sign',lemma='sign',upos='NOUN',start_char=15,end_char=19),dict(id=3,text='saying',lemma='say',upos='VERB',start_char=20,end_char=26),dict(id=4,text='bleeds',lemma='bleed',upos='VERB',start_char=34,end_char=40)])
    raw='(h / hold-01 :ARG0 (c / country :name (n / name :op1 "Mexico")) :ARG1 (s / sign :ARG0-of (v / say-01 :ARG1 (b / bleed-01 :ARG1 c))))'
    prepared=prepare_fallback(r,raw);assert any(x['code']in{'quote_external_anchor','quote_shared_reference'}for x in prepared[1]['issues'])

def test_name_alignment_is_not_borrowed_from_unrelated_people():
    from probabilistic_verification.fallback_amr import FallbackAlignment
    r=dict(text='Alex sees people.',tokens=[dict(id=1,text='Alex',lemma='Alex',upos='PROPN',head=2,start_char=0,end_char=4),dict(id=2,text='sees',lemma='see',upos='VERB',head=0,start_char=5,end_char=9),dict(id=3,text='people',lemma='person',upos='NOUN',head=2,start_char=10,end_char=16)])
    a=FallbackAlignment(r,{'p':'person','n':'name','q':'person'},[('p',':name','n'),('n',':op1','"Alex"')])
    assert a.unique('p')['id']==1 and a.unique('q')['id']==3

def test_role_noun_alignment_is_not_borrowed_from_reported_people():
    from probabilistic_verification.fallback_amr import FallbackAlignment
    r=dict(text='The narrator sees people.',tokens=[dict(id=1,text='narrator',lemma='narrator',upos='NOUN',head=2,start_char=4,end_char=12),dict(id=2,text='people',lemma='person',upos='NOUN',head=0,start_char=18,end_char=24)])
    a=FallbackAlignment(r,{'p':'person','n':'narrator','q':'person'},[('n',':domain','p')])
    assert a.unique('p')['id']==1 and a.unique('q')['id']==2

def test_modal_feature_metadata_follows_emitted_scope():
    from dataclasses import replace
    c=simple();c=replace(c,metadata=dict(c.metadata,source_features=[dict(scope='world')],node_scopes={'x':'world'}));d,_=qualify_root_modal(c,would_record())
    scope=d.atoms[0].arguments[2];assert d.metadata['source_features'][0]['scope']==scope and d.metadata['node_scopes']['x']==scope

def test_exact_speech_literal_does_not_need_internal_modal_parse():
    from dataclasses import replace
    r=dict(claim_id='spoken',text='Alice said "Everyone would cheer".',tokens=[dict(id=1,text='Everyone',lemma='everyone',start_char=12),dict(id=2,text='would',lemma='would',head=3,start_char=21),dict(id=3,text='cheer',lemma='cheer',head=4)])
    c=simple();a=replace(c.atoms[0],arguments=('E1','{"kind":"verbatim_text","value":"Everyone would cheer"}','scope','world','route','speech_assertion'));c=replace(c,atoms=(a,))
    revised,errors=qualify_root_modal(c,r);assert revised==c and not errors and not shared_checks(r,c)

def test_literal_scope_word_is_not_confused_with_scope_field():
    from dataclasses import replace
    c=simple();a=replace(c.atoms[0],predicate='referent',arguments=('E1','scope','scope','world','route','unspecified'));c=replace(c,atoms=(a,))
    d,e=qualify_root_modal(c,would_record());assert not e and d.atoms[0].arguments[1]=='scope'and d.atoms[0].arguments[3].startswith('modal_would::')

def test_implication_cannot_be_replaced_by_conjunction():
    r=dict(text='No containers implies later filming.',tokens=[dict(id=1,text='implies',lemma='imply')]);assert shared_checks(r,simple())[0]['code']=='conditional_scope'

def test_condition_context_satisfies_necessary_scope_check():
    from dataclasses import replace
    c=simple();c=replace(c,metadata=dict(c.metadata,scopes={'c1':dict(kind='condition')}))
    r=dict(text='If it rains, it floods.',tokens=[dict(id=1,text='If',lemma='if',deprel='mark')]);assert not shared_checks(r,c)

def test_two_graffiti_quotes_keep_the_conjunction_without_asserting_contents():
    text='"First" and "Second" written in graffiti.'
    words=[('First',1,6,'ADJ'),('and',8,11,'CCONJ'),('Second',13,19,'ADJ'),('written',21,28,'VERB'),('graffiti',32,40,'NOUN')]
    tokens=[dict(id=i,text=w,lemma='write'if w=='written'else w.lower(),upos=pos,start_char=lo,end_char=hi)for i,(w,lo,hi,pos)in enumerate(words,1)]
    r=dict(claim_id='twoquotes',text=text,tokens=tokens)
    raw='(w / write-01 :ARG1 (a / and :op1 (f / first) :op2 (s / second)) :location (g / graffiti))'
    p=prepare_fallback(r,raw);c=compile_fallback_amr(r,raw,strict=False,prepared=p)
    assert not p[1]['issues']
    assert {a.arguments[1]for a in c.atoms if a.predicate=='written_text'}=={'First','Second'}
    assert 'first'not in c.metadata['concepts'].values()and'second'not in c.metadata['concepts'].values()

def test_quoted_inverse_role_modifier_stays_inside_literal_not_outer_world():
    text='A sign says "The faculty is back".'
    words=[('sign','sign','NOUN',2,6),('says','say','VERB',7,11),('faculty','faculty','NOUN',17,24)]
    tokens=[dict(id=i,text=w,lemma=l,upos=p,start_char=lo,end_char=hi)for i,(w,l,p,lo,hi)in enumerate(words,1)]
    r=dict(claim_id='inverse_quote',text=text,tokens=tokens)
    raw='(s / sign :ARG0-of (v / say-01 :ARG1 (f / faculty :ARG1-of (r / return-01))))'
    p=prepare_fallback(r,raw);c=compile_fallback_amr(r,raw,strict=False,prepared=p)
    assert 'return-01'not in c.metadata['concepts'].values()
    assert any(a.predicate=='written_text'and a.arguments[1]=='The faculty is back'for a in c.atoms)
