import re

from probabilistic_verification.benchmark_warnings import warnings
from probabilistic_verification.logical_form_v2 import ScopedClaim
from probabilistic_verification.representation import Atom, Expression


def check(text, predicates, *, scopes=None, alternatives=False, names=()):
    tokens = [
        dict(id=i, text=m[0], lemma=m[0].lower(), start_char=m.start(), end_char=m.end(),
             upos='PROPN' if m[0] in names else 'X', deprel='cc' if m[0] == 'or' else '')
        for i, m in enumerate(re.finditer(r"[\w]+", text), 1)
    ]
    atoms = tuple(Atom(str(i), predicate, tuple(args), 'test', (), '', (), False)
                  for i, (predicate, args) in enumerate(predicates))
    expression = Expression.combine('or' if alternatives else 'and',
                                    (Expression.atom(a.id) for a in atoms))
    claim = ScopedClaim('test', text, (), (), atoms, expression, (),
                        metadata={'scopes': scopes or {}})
    return [(a['code'], a['source']) for a in warnings(dict(text=text, tokens=tokens), claim.to_dict())]


def test_missing_unique_name_and_handle():
    text = 'Maria Santos uploaded it as maria_santos_18.'
    assert check(text, [('entity', ('Maria',))], names=('Maria', 'Santos')) == [
        ('proper_name_omission', 'Maria Santos'), ('identifier_omission', 'maria_santos_18')
    ]
    assert check(text, [('entity', ('Maria Santos', 'maria_santos_18'))],
                 names=('Maria', 'Santos')) == []


def test_count_and_wrong_unit_do_not_encode_speed():
    text = 'It reached 384 mph.'
    assert check(text, [('quantity', ('mph', 'count', '384')), ('value', ('384 km/h',))]) == [
        ('measurement_unbound', '384 mph')
    ]
    assert check(text, [('value', ('384 mph',))]) == []


def test_range_needs_linked_bounds_and_matching_units():
    text = 'It reached 100 to 135 km/h.'
    assert check(text, [('value', ('100 km/h',)), ('value', ('135 km/h',))]) == [
        ('measurement_range_unbound', '100 to 135 km/h')
    ]
    assert check(text, [('value', ('100 to 135 km/h',))]) == []


def test_future_does_not_satisfy_likelihood():
    text = 'It will likely collapse.'
    assert check(text, [('event', ('collapse', 'likely'))], scopes={'q1': {'kind': 'future'}}) == [
        ('qualification_scope_missing', 'likely')
    ]
    assert check(text, [('event', ('collapse',))], scopes={'q1': {'operator': 'likely'}}) == []


def test_alternative_in_source_needs_or():
    text = 'They heard a bang or a shot.'
    predicates = [('event', ('bang',)), ('event', ('shot',))]
    assert check(text, predicates) == [('alternative_missing', 'or')]
    assert check(text, predicates, alternatives=True) == []


def test_or_inside_preserved_literal_does_not_add_alternative():
    assert check('The sign reads "On or Off".', [('written_text', ('sign', 'On or Off'))]) == []
