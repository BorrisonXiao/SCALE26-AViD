# Comparing speech binding on the same candidate transcripts

## Design

We evaluate 96 queries from the 12 meeting series previously set aside for speech calibration evaluation. The 48 content queries use the audited original reports, paraphrases, changed alternatives, and changed surrounding context. For each meeting, we add four queries about a valid paraphrase and change its speaker, move its time window earlier, split the source words across two utterances by the same speaker, or assign the two utterances to different speakers. The split controls remove the spoken “or” and keep the words on either side. Support means that the named speaker presented the claimed alternatives together in an utterance in the requested time slot.

The evidence inventory contains the original annotated utterance or its two split variants and up to three neighboring, annotated utterances. We prefer distractors with an “or” where available, then by proximity. Candidate selection precedes model scoring. The main comparison supplies the true speaker and word times from the annotation. Exact calibration parameters come from the earlier, source-disjoint set of 12 other meetings. Reported-content and control labels are development judgments by the implementing assistant. [AMI corpus and manual annotations](https://groups.inf.ed.ac.uk/ami/download/)

The five methods each receive every candidate in the supplied inventory. All use the same frozen DeBERTa checkpoint and use the same threshold of 0.5 on their final support probability. The raw and calibrated runs apply the threshold separately. We retain unsupported probability as unknown when the available evidence fails to establish the report.

1. **Whole-claim DeBERTa.** Serialize each utterance in order with its speaker and whether it overlaps the query interval. Score the resulting transcript block against the whole claim in one call. The input includes the same information as the other systems, formatted in text.
2. **Separate DeepProbLog witnesses.** Find an utterance matching speaker and time and an utterance with an alternative cue and content support. The two can be different.
3. **Shared DeepProbLog witness without a cue.** Require the speaker, time, and content score to belong to one utterance.
4. **Shared DeepProbLog witness.** Require one utterance to match the speaker and time, express an alternative cue, and support the reported content. An explicit “or” or a recognized construction such as “another option” provides the cue. These checks never receive the case label.
5. **Filtered maximum.** Use the same four checks and scores as the shared program, then take the highest support score among eligible utterances. A missing eligible witness gives zero support.

The three logic runs use identical per-utterance model scores and fixed observations. The program checks whether one of the eligible utterances supports the claim. When more than one utterance qualifies, their model outputs are treated as independent, so support is one minus the product of their non-support probabilities. We check native inference against this direct calculation for every distribution. The filtered-maximum baseline exposes whether this extra probability combination changes decisions. Whole-claim calibration applies the existing score map to a different input format, with no fit to those serialized inputs. [DeBERTa model](https://huggingface.co/cross-encoder/nli-deberta-v3-small)

We use the same reviewed logical form template for every case so parser abstentions cannot determine the controlled comparison. We also rerun the current compiler on the 48 original and edited claims expressed as natural direct quotations. This separate census distinguishes literal quotation, the explicit reported-disjunction predicate, and abstention. It uses the existing dependency, SRL, and AMR models and the source checks, with no new rewrite calls.

The reference template uses `U` for a candidate transcript utterance. The speaker and time are fixed to the query. The content is the material attributed to the speaker, including the alternatives and any surrounding conditions.

```text
EXISTS U:
    speaker_matches(U, requested_speaker)
    AND within_time(U, requested_interval)
    AND has_alternative_cue(U)
    AND reported_disjunction(U, claimed_content)
```

AMI transcript excerpts are © University of Edinburgh and partners under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

## Results

With calibrated scores and identical per-utterance observations, linking the speaker, time, and content to the same utterance improves decisions from 72 to 89 of 96. The raw comparison moves from 67 to 84. All 24 valid original and paraphrased reports remain supported. The full program has zero false supports on 12 wrong-speaker queries and 24 split-utterance queries. It incorrectly supports one of the 12 wrong-time queries and six of the 24 content edits with calibrated scores.

The wrong-time error comes from IN1002. A real earlier utterance by the requested speaker says “It takes at least one or two weeks.” DeBERTa treats this as supporting “We can wait at least one week or two weeks for it.” The utterance meets the speaker, time, and alternative checks, so the inference propagates the model's content error. Other false supports change the number of remotes, reverse a preference, replace a device, or move the device below the TV. The experiment includes an eligible distractor in eight wrong-speaker queries and seven wrong-time queries.

Whole-claim DeBERTa gets 32 of 96 decisions right with raw scores and 40 with calibrated scores using the specified transcript format. It often treats content from several utterances as if it belonged to the same report. This is one way of presenting speaker and time metadata to a frozen NLI model. The same-observation ablation is the main comparison. The simple filter matches DeepProbLog on all 96 raw and 96 calibrated decisions. The support probabilities differ on four queries at each scale, with maximum calibrated difference 0.013. The measured decision gain comes from the binding constraints. A further experiment with uncertain or competing assignments can test when probabilistic inference changes decisions usefully.

The compiler produces 32 of 48 programs for direct-quotation claims, all with the speaker and the full verbatim report. These use a quotation literal, so none use the semantic `reported_disjunction` predicate from the controlled comparison. The other 16 abstain at sentence parsing because the quotation contains more than one sentence. Direct quotation and semantic support for an indirect report are distinct tasks. All 576 exact distributions match the independent calculation, and all 709 project tests pass.

## Next steps

- Evaluate on fresh reports with independently checked labels and alternatives expressed without explicit “or.” This tests whether the shared-utterance result survives changes in wording and evidence.
- Run the same comparison on visual or OCR claims with multiple relations and uncertain candidate assignments. This tests where the probabilistic program improves on applying the same constraints and taking the highest score.

## Replay

Use Python 3.12 and the bundled requirements, with NumPy 2.2.6 and SciPy 1.17.1. The archive contains frozen candidate windows, scored model pairs, compiler annotations, and the earlier calibration record. Model and audio files are unnecessary for this replay. The frozen case list gives exact AMI segment IDs and word IDs.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
run=exp/probabilistic_verification/ami_probabilistic_binding_20261126
python scripts/evaluate_or_followup_compilation.py "$run/compiler" "$run/compiler/amr.jsonl" "$run/compiled.json"
python scripts/evaluate_ami_probabilistic_binding.py compiler
python scripts/evaluate_ami_probabilistic_binding.py evaluate
python scripts/ami_probabilistic_binding_report.py
python -m pytest -q tests/test_ami_probabilistic_binding.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/ami_probabilistic_binding_20261126')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```
