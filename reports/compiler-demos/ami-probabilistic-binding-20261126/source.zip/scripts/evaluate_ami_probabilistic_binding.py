"""Compare speech binding under identical candidate transcript evidence."""
import argparse
from collections import Counter
import json
from math import isclose, prod

from calibrate_ami_speech_scores import calibrated, probabilities
from evaluate_ami_speech_scoring import MODELS, compilation
from evaluate_reported_or_transcripts import score_pairs
from prepare_ami_probabilistic_binding import PRIOR, RUN, cases, overlaps
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.compiler_fallback import restore
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.ordered_circuit import OrderedSolver
from probabilistic_verification.representation import Atom, CompiledClaim, Expression as E, Variable
from probabilistic_verification.transcript_or import implicit_splits, splits

SCALES = ('raw','calibrated')
LOGIC = ('separate_witnesses','shared_without_cue','shared_witness')
METHODS = ('whole_claim',*LOGIC,'filtered_max')
CONTENT = ('original','paraphrase','changed_option','changed_context')


def has_alternatives(text):
    return any(splits(text,'or')) or any(implicit_splits(text))


def whole_claim_pair(case):
    """Give the whole-claim scorer the same utterance and metadata information."""
    query = case['query']
    evidence = []
    for w in case['windows']:
        interval = 'during' if overlaps(w,query) else 'outside'
        evidence.append(f'Participant {w["speaker"]} said in one utterance {interval} the query interval: "{w["text"]}"')
    hypothesis = (f'Participant {query["speaker"]} presented the following alternatives in one utterance '
                  f'during the query interval: "{case["content"]}"')
    return '\n'.join(evidence),hypothesis


def score():
    pairs = set()
    for row in cases():
        for case in row['cases']:
            pairs.add(whole_claim_pair(case))
            pairs.update((w['text'],case['content']) for w in case['windows'])
    prior = read(PRIOR/'claim_scores.json')
    cached = [r for r in prior['scores'] if (r['premise'],r['hypothesis']) in pairs]
    pending = pairs-{(r['premise'],r['hypothesis']) for r in cached}
    result = score_pairs(pending,MODELS['deberta'])
    assert result['snapshot']==prior['snapshot'], 'Frozen scorer differs between experiments.'
    result['scores'] = sorted(result['scores']+cached,key=lambda r:(r['premise'],r['hypothesis']))
    result['reused'] = len(cached)
    dump(RUN/'nli_scores.json',result)
    print('Scored',len(pending),'new pairs and reused',len(cached),flush=True)


def predicates(case):
    q = case['query']
    interval = f'{q["start"]:g} to {q["end"]:g} seconds'
    records = (('speaker_matches',('U',q['speaker'])), ('within_time',('U',interval)),
               ('has_alternative_cue',('U',)), ('reported_disjunction',('U',case['content'])))
    return tuple(Atom(name,name,args,'relation',(),case['content'],(),False) for name,args in records)


def logical_form(case,method,scale):
    atoms = predicates(case)
    speaker, time, cue, words = (E.atom(a.id) for a in atoms)
    def exists(*items):
        return E.exists(('U',),E.combine('and',items))
    if method=='separate_witnesses':
        expression = E.combine('and',(exists(speaker,time),exists(cue,words)))
    elif method=='shared_without_cue':
        expression = exists(speaker,time,words)
    elif method=='shared_witness':
        expression = exists(speaker,time,cue,words)
    else:
        raise ValueError(method)
    return CompiledClaim(f'{case["id"]}:{scale}:{method}',case['content'],(),
                         (Variable('U','utterance','Candidate transcript utterance',()),),atoms,expression,())


def state(flag):
    return (1.,0.,0.) if flag else (0.,1.,0.)


def grounded_case(case,method,scale):
    form = logical_form(case,method,scale)
    media = f'{case["id"]}:{scale}'
    domain = [w['id'] for w in case['windows']]
    evidence = Evidence(media,{'U':domain},{'U':False},{},route='speech_assertion')
    for w in case['windows']:
        p = w['probability'][scale]
        distributions = (state(w['checks']['speaker']),state(w['checks']['time']),state(w['checks']['cue']),(p,0.,1-p))
        for atom, dist in zip(form.atoms,distributions):
            key = canonical_key(media,atom,{'U':w['id']},evidence.route)
            evidence.observations[key] = Observation(key,dist,False,atom.text,dict(utterance=w['id']))
    return ground(form,evidence)


def expected_support_probability(windows,method,scale):
    eligible = lambda w: w['checks']['speaker'] and w['checks']['time']
    if method=='separate_witnesses':
        if not any(eligible(w) for w in windows):
            return 0.
        selected = [w for w in windows if w['checks']['cue']]
    elif method=='shared_without_cue':
        selected = [w for w in windows if eligible(w)]
    else:
        selected = [w for w in windows if eligible(w) and w['checks']['cue']]
    if method=='filtered_max':
        return max((w['probability'][scale] for w in selected),default=0.)
    return 1-prod(1-w['probability'][scale] for w in selected)


def describe_compiler():
    outcomes = []
    for row in read(RUN/'compiled.json'):
        info = compilation(row,row['speaker'])
        if info['state']=='missing_report' and literal_quote_preserved(row):
            info['state'] = 'verbatim_quote'
        outcomes.append(dict(id=row['claim_id'],text=row['text'],compiled=bool(row['fixed']['output']),**info))
    result = dict(cases=outcomes,counts=Counter(r['state'] for r in outcomes))
    dump(RUN/'compiler_evaluation.json',result)
    print(result['counts'],flush=True)


def literal_quote_preserved(row):
    claim = restore(row['fixed']['output']['compilation'])
    speaker = f'Participant {row["speaker"]}'
    entities = {a.arguments[0] for a in claim.atoms if a.predicate=='referent' and a.arguments[1]==speaker}
    quoted = row['content'] if row['content'].endswith(('.', '?', '!')) else row['content']+'.'
    for a in claim.atoms:
        if a.predicate!='say' or not {'ARG0','ARG1'}<=set(a.arguments):
            continue
        actor = a.arguments[a.arguments.index('ARG0')+1]
        text = a.arguments[a.arguments.index('ARG1')+1]
        if actor in entities and text.startswith('{'):
            if json.loads(text)=={'kind':'verbatim_text','value':quoted}:
                return True
    return False


def evaluate():
    scores = probabilities(RUN/'nli_scores.json')
    model = read(PRIOR/'calibration_evaluation.json')['model']
    meetings = cases()
    entries = [c for r in meetings for c in r['cases']]
    for case in entries:
        query = case['query']
        baseline = scores[whole_claim_pair(case)]['entailment']
        case['whole_claim'] = {'raw':baseline,'calibrated':calibrated(baseline,model)}
        for w in case['windows']:
            raw = scores[w['text'],case['content']]['entailment']
            w['checks'] = dict(speaker=w['speaker']==query['speaker'],time=overlaps(w,query),cue=has_alternatives(w['text']))
            w['probability'] = {'raw':raw,'calibrated':calibrated(raw,model)}
    inferred = {}
    programs = []
    for row in meetings:
        batch = [grounded_case(case,method,scale) for case in row['cases'] for scale in SCALES for method in LOGIC]
        verifier = DirectVerifier(batch,learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver)
        inferred.update((r['claim_id'],r['distribution']) for r in verifier.predict())
        programs.extend(batch)
        print(row['meeting'],len(batch),'exact distributions',flush=True)
    program, _ = compact_prolog_program(programs,learned=False)
    (RUN/'program.pl').write_text(program)
    summary = {scale:{m:{'all':Counter(),'content':Counter(),
                         **{k:Counter() for k in ('wrong_speaker','wrong_time','split_utterances','split_speakers')}}
                      for m in METHODS} for scale in SCALES}
    same = Counter()
    for case in entries:
        expected = case['expected_support']
        case['results'] = {}
        group = 'content' if case['variant'] in CONTENT else case['variant']
        for scale in SCALES:
            whole = case['whole_claim'][scale]
            filtered = expected_support_probability(case['windows'],'filtered_max',scale)
            dist = {'whole_claim':dict(supported=whole,refuted=0.,unknown=1-whole),
                    'filtered_max':dict(supported=filtered,refuted=0.,unknown=1-filtered)}
            for method in LOGIC:
                p = inferred[f'{case["id"]}:{scale}:{method}']
                expected_p = expected_support_probability(case['windows'],method,scale)
                assert isclose(p['supported'],expected_p,abs_tol=1e-10) and abs(p['refuted'])<1e-10,(case['id'],p)
                dist[method] = p
            verdicts = {}
            for method in METHODS:
                p = dist[method]['supported']
                predicted = p>=0.5
                verdicts[method] = dict(distribution=dist[method],support=predicted)
                for key in ('all',group):
                    count = summary[scale][method][key]
                    count['total'] += 1
                    count['correct'] += predicted==expected
                    count['false_support'] += predicted and not expected
                    count['missed_support'] += expected and not predicted
            same[scale] += verdicts['shared_witness']['support']==verdicts['filtered_max']['support']
            case['results'][scale] = verdicts
    result = dict(total=len(entries), exact_comparisons=len(inferred), calibration=model,
                  equal_decisions_with_filtered_max=same,summary=summary,meetings=meetings)
    dump(RUN/'binding_evaluation.json',result)
    print({s:{m:dict(x['all']) for m,x in k.items()} for s,k in summary.items()},flush=True)
    print('Same decisions as the filtered maximum',same,flush=True)


if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage',choices=('score','evaluate','compiler'))
    {'score':score,'evaluate':evaluate,'compiler':describe_compiler}[parser.parse_args().stage]()
