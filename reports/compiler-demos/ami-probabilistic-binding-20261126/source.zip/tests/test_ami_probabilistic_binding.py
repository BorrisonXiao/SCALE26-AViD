"""Evidence from different utterances cannot satisfy a shared witness."""
import pytest

from evaluate_ami_probabilistic_binding import expected_support_probability, grounded_case
from probabilistic_verification.logic import enumerate_probability


def window(identifier, speaker, probability):
    return dict(id=identifier, checks=dict(speaker=speaker,time=True,cue=True),
                probability=dict(raw=probability))


def test_same_utterance_connects_the_report_to_the_requested_speaker():
    case = dict(id='claim',content='A report with two options',query=dict(speaker='A',start=0,end=10),
                windows=[window('u1',True,.1),window('u2',False,.9)])
    separate = enumerate_probability(grounded_case(case,'separate_witnesses','raw'))
    shared = enumerate_probability(grounded_case(case,'shared_witness','raw'))
    assert separate==pytest.approx(dict(supported=.91,refuted=0,unknown=.09))
    assert shared==pytest.approx(dict(supported=.1,refuted=0,unknown=.9))


def test_existential_probability_can_exceed_the_best_eligible_window():
    windows = [window('u1',True,.4),window('u2',True,.4)]
    assert expected_support_probability(windows,'shared_witness','raw')==pytest.approx(.64)
    assert expected_support_probability(windows,'filtered_max','raw')==.4
