# Reported OR in transcripts and new claims

## Transcript evidence

We selected eight readable, manually transcribed utterances with an explicit “or” from distinct meeting groups in the [AMI corpus](https://groups.inf.ed.ac.uk/ami/download/). We froze the expected outputs and paraphrases before model scoring. The test receives the hypothesized speaker and time window, plus a flag for whether the candidate text covers the full statement. The AMI annotation supplies speaker identity and word times. The pilot runs on transcripts.

The 58 comparisons per method include eight unedited full utterances, 16 genuine timestamped crops, eight altered speaker assignments, eight original utterances matched against paraphrased claims, 16 edits that change the meaning, and two edited paraphrases that preserve alternatives without the word “or.” Edited text reuses the original time interval as a control. The intended judgment is whether the selected utterance presents the alternatives attributed to the speaker.

- Whole-utterance natural language inference (NLI) matched 42 of 58 expected judgments. It returned unknown for all eight edited single assertions and supported for all eight edited AND statements. Both edits were labeled refuted by the reference.
- An exact-text comparison of both alternatives matched 48 of 58. It got the crops, wrong-speaker and meaning-changing edits right.
- Comparing alternative spans with frozen NLI matched 54 of 58. It recovered six of eight claim paraphrases. The two misses concern color or texture choices and raising or lowering volume. It also returned unknown for both instances of alternatives expressed without the word “or.”

The NLI model is [cross-encoder/nli-MiniLM2-L6-H768](https://huggingface.co/cross-encoder/nli-MiniLM2-L6-H768/tree/b95119ce93d3e065de6214e38cd4a97b0f2f2c6d). The whole-text baseline uses the highest-scoring NLI label. The alternative comparison first matches the speaker and time, then checks text equality or bidirectional entailment at a fixed 0.55 threshold for each aligned alternative. A known complete statement that matches just one alternative or joins both with AND yields refuted. Unknown is returned when the transcript lacks coverage or the wording cannot be matched. Scores are recorded for all 282 text pairs.

The compiler produced four programs for the eight claims with an added “The participant said that” attribution. Three contain the full reported OR. A fourth program passed without that predicate for a speaker choosing between broccoli and mango. The four remaining claims were refused for issues such as unresolved contractions, missing words or an unsupported embedded scope. Exact DeepProbLog inference matched all 18 expected judgments on the three programs with the full speech condition. The speaker candidate and all other observations were supplied. The two NLI paraphrase errors outside that inference run are included in the 58-case evaluation.

AMI transcript excerpts are from the AMI meeting corpus, © University of Edinburgh and partners, [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The original or edited status, speaker, and timing are recorded per item.

## New claim texts

The [AVeriTeC dataset](https://fever.ai/dataset/averitec.html) supplied 16 claims with standalone “or” outside quotes. The selected claim and fact-check pages are distinct and original pages are disjoint from the earlier 20-case audit. We excluded duplicate claim text from the earlier audit and the project corpus. Four texts came from the dataset's dev split and 12 from its train split. Both splits serve only as evaluation inputs here. Selection and reference readings were frozen before seeing model output. The implementing assistant reviewed all 16 outputs. The study does not use any AVeriTeC truth label or media evidence.

The fixed SRL-first, AMR-on-failure sequence compiled 10 inputs, eight through SRL and two through AMR. No rewrite provider ran. Two programs match the reference reading, four are partial, three are incorrect, and one needs context. Six claims produced no program. The two clearest incorrect passes distribute negation incorrectly across OR and join a completed flight with a scheduled flight using AND. Other limitations include shared modifiers, a shared noun head, alternative durations inside opaque text, and distinguishing a numeric restatement from an alternative. The eight-meeting transcript test and 16-source claim audit are small development evaluations.

The compiler itself did not change. The prior automatic corpus count stays at 2,179 of 2,375. The transcript method remains an experimental way to supply a speech condition. No training, audio transcription or media feature extraction ran. All 677 project tests pass.

## Replay

Use Python 3.12 with the project compilation requirements. From this archive's root, run the commands below. The bundle includes frozen parser artifacts and frozen model scores, so replay needs no checkpoint downloads.

```sh
export PYTHONPATH=scripts
python scripts/evaluate_or_source_compilation.py fresh
python scripts/evaluate_or_source_compilation.py transcripts
python scripts/evaluate_reported_or_transcripts.py evaluate
python scripts/evaluate_reported_or_transcripts.py inference
python scripts/or_source_evaluation_report.py
python -m pytest -q tests/test_transcript_or.py
```

Compare hashes against `REPLAY_SHA256.json` using the paths under `exp/probabilistic_verification/or_source_evaluation_20261119`. Source provenance is frozen alongside the inputs. To reproduce the CPU NLI scoring from the checkpoint, fetch the four files in the pinned snapshot into the run's `source/minilm-nli` directory and run the transcript script with `score`.

## Next steps

1. Correct negation over OR and preserve shared words in coordinated branches. Retest the observed false passes and use fresh inputs to check that the fixes preserve claim meaning.
2. Add naturally worded alternatives without “or” and vary the speaker and time windows. Measure how the speech condition behaves when wording and alignment are less controlled, before training any relation model.
