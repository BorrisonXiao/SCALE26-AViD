"""Create transcript pairs with the same speaker and original segment timestamps."""
from hashlib import file_digest, sha256
import re

from collect_ami_or_candidates import detokenize
from prepare_or_source_evaluation import RUN, read
from prepare_compiler_fallback import dump

# One judgment per meeting, chosen from readable corpus segments before scoring.
# Paraphrases are written as claims about the existing recordings.
READINGS = {
    'ES2010b.sync.266': (
        'We could make the logo yellow, or perhaps illuminate the keys in yellow.',
        'We could make the logo yellow. Another option is to illuminate the keys in yellow.',
    ),
    'TS3004c.sync.175': (
        'Normally you place the remote on the table or on the sofa.',
        None,
    ),
    'ES2011d.sync.644': (
        'You could choose broccoli, or you could choose a mango.',
        'Broccoli is one option. Mango is the other option.',
    ),
    'EN2004a.sync.763': (
        'I will work it out and post it on the wiki or send you an email.',
        None,
    ),
    'IN1009.sync.439': (
        'That may work for ten minutes, but then the person might move, or someone else might arrive.',
        None,
    ),
    'EN2003a.sync.460': (
        "I would schedule it for an entire morning or an entire afternoon.",
        None,
    ),
    'IS1000d.sync.372': (
        'You can choose different colors or different surface finishes.',
        None,
    ),
    'IS1009d.sync.325': (
        "We added two buttons to turn the volume up or turn it down.",
        None,
    ),
}


def main():
    folder = RUN / 'transcripts'
    candidates = {r['segment_id']: r for r in read(folder / 'candidates.json')}
    archive = RUN / 'source/ami_public_manual_1.6.2.zip'
    selected = []
    claims = []
    with archive.open('rb') as file:
        source_sha = file_digest(file, 'sha256').hexdigest()
    for index,(segment,(paraphrase, alternate)) in enumerate(READINGS.items(),1):
        raw = candidates[segment]
        words = raw['words']
        split = raw['idx']
        full = raw['text']
        left, right = detokenize(words[:split]).rstrip(' ,.'), detokenize(words[split+1:])
        start, end = words[0]['start'], words[-1]['end']
        speaker = raw['speaker']
        identifier = f'reported_or_{index:02d}'
        # Insert an attribution for the compilation check. Keep the speaker's
        # full content and ask the compiler to preserve its alternatives.
        content = re.sub(r'^(?:(?:yeah|so|but|and|well)[, ]+)+', '', full, flags=re.I)
        if not content.startswith(('I ', "I'", 'I’')):
            content = content[0].lower() + content[1:]
        claims.append(dict(claim_id=identifier, text='The participant said that '+content,
                           content=content, speaker=speaker, segment_id=segment))
        variants = [
            ('complete', full, full, speaker, start, end, True, 'supported', 'original transcript'),
            ('prefix', left, full, speaker, start, words[split-1]['end'], False, 'unknown', 'original prefix crop'),
            ('suffix', right, full, speaker, words[split+1]['start'], end, False, 'unknown', 'original suffix crop'),
            ('single_statement', left+'.', full, speaker, start, end, True, 'refuted', 'controlled edit'),
            ('conjunction', detokenize([*words[:split],dict(words[split],text='and'),*words[split+1:]]),
             full,speaker,start,end,True,'refuted','controlled edit'),
            ('paraphrased_claim', full, paraphrase, speaker,start,end,True,'supported','original transcript, paraphrased claim'),
            ('different_speaker', full, full, 'B' if speaker=='A' else 'A',start,end,True,'unknown',
             'original transcript, other speaker selected'),
        ]
        if alternate:
            variants.append(('implicit_alternatives',alternate,full,speaker,start,end,True,
                             'supported','controlled paraphrase without or'))
        cases = [dict(variant=n, text=text, target=target, speaker=person, start=a, end=b,
                      complete=complete, expected=state, provenance=provenance)
                 for n,text,target,person,a,b,complete,state,provenance in variants]
        selected.append(dict(claim_id=identifier,meeting=raw['meeting'],speaker=speaker,segment_id=segment,
                             text=full,start=start,end=end,words=words,cases=cases))
    assert len({re.sub(r'[a-z]$','',r['meeting']) for r in selected})==len(READINGS)
    assert all(r['end'] > r['start'] and r['words'][-1]['text']=='.' for r in selected)
    dump(folder / 'cases.json',dict(
        source='AMI manual annotations v1.6.2', archive_sha256=source_sha,
        license='CC BY 4.0', cases=selected,
        boundary='Original times for transcript rows and word-aligned crops. Edited text uses the original interval as a fixed control.',
        annotation='Complete means that the evaluated excerpt is supplied as the complete attributed statement.'))
    dump(folder / 'claims.json', claims)
    (folder / 'case_sha256.txt').write_text(sha256((folder / 'cases.json').read_bytes()).hexdigest()+'\n')
    print(f'{len(selected)} meetings, {sum(len(r["cases"]) for r in selected)} comparisons.')


if __name__ == '__main__':
    main()
