"""Freeze new text sources and prepare both OR evaluations for cached parsers."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

from prepare_compiler_fallback import ROOT, dump, rows
from probabilistic_verification.amr_source_alignment import quote_spans
from sample_logical_form_review import INPUTS

RUN = ROOT / 'exp/probabilistic_verification/or_source_evaluation_20261119'
REVISION = '7c62d1ec8df3fb560d6efe2b85fa191135636f81'
OR = re.compile(r'(?<![\w-])or(?![\w-])', re.I)


def read(path):
    return json.loads(path.read_text())


def source_key(url):
    parsed = urlsplit(url or '')
    path = parsed.path.rstrip('/')
    # Preserve identifiers on sites that encode claim identity in query strings.
    query = '&'.join(q for q in parsed.query.split('&') if q and not q.startswith('utm_'))
    return parsed.netloc.lower().removeprefix('www.'), path, query


def text_key(text):
    return ' '.join(re.findall(r'\w+', text.casefold()))


def write_rows(path, records):
    path.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records))


def select():
    folder = RUN / 'fresh'
    folder.mkdir(parents=True, exist_ok=True)
    earlier = ROOT / 'exp/probabilistic_verification/amr_contexts_20261118/external_claims.json'
    earlier_claims = read(earlier)
    urls = {source_key(r['source_url']) for r in earlier_claims}
    texts = {text_key(r['text']) for r in rows(INPUTS)} | {text_key(r['text']) for r in earlier_claims}
    split_stats = {}
    selected = []
    for split in ('dev','train'):
        path = RUN / 'source' / f'averitec-{split}.json'
        source_rows = read(path)
        candidates = []
        for index, row in enumerate(source_rows):
            text = row['claim']
            if not 6 <= len(text.split()) <= 45:
                continue
            quoted = quote_spans(text)
            if not any(not any(q['start'] <= m.start() < q['end'] for q in quoted)
                       for m in OR.finditer(text)):
                continue
            url = row.get('original_claim_url')
            article = row.get('fact_checking_article')
            if any(not isinstance(v,str) or not source_key(v)[0] for v in (url,article)):
                continue
            candidates.append(dict(claim_id=f'or_averitec_{split}_{index}', text=text,
                                   source_url=url, fact_checking_article=article,
                                   split=split, record_index=index))
        candidates.sort(key=lambda r: sha256(('or-source-20261119:' + r['claim_id']).encode()).hexdigest())
        start = len(selected)
        for row in candidates:
            if len(selected) == 16:
                break
            pages = {source_key(row[k]) for k in ('source_url','fact_checking_article')}
            key = text_key(row['text'])
            if key in texts or pages & urls:
                continue
            selected.append(row)
            texts.add(key)
            urls.update(pages)
        split_stats[split] = dict(total=len(source_rows), candidates=len(candidates),
                                 selected=len(selected)-start, sha256=sha256(path.read_bytes()).hexdigest())
    assert len(selected)==16, split_stats
    dump(folder / 'claims.json', selected)
    dump(folder / 'selection.json', dict(
        dataset='AVeriTeC', revision=REVISION, splits=split_stats,
        prior_source_pages=len(earlier_claims), n=len(selected),
        criteria='Standalone unquoted or, 6–45 words, nonempty original and fact-check page URLs, one per page and no earlier claim text. Prefer dev then fixed hash order in train.',
        use='Compiler evaluation development. Dataset labels and factual evidence are excluded.'))
    for row in selected:
        print(row['claim_id'],row['text'])


def prepare(group):
    from probabilistic_verification.parsing import DependencyParser
    folder = RUN / group
    claims_path = folder / 'claims.json'
    examples = read(claims_path)
    parser = DependencyParser()
    outputs = []
    for row in examples:
        cid, text = row['claim_id'], row['text']
        record = dict(claim_id=cid, text=text, tokens=parser.parse(text), srl=None)
        outputs.append(dict(claim_id=cid, clauses=[dict(id='c1', text=text, record=record)]))
    write_rows(folder / 'dependencies.jsonl', outputs)
    dump(folder / 'dependency_provenance.json',
         dict(parser.provenance, claims_sha256=sha256(claims_path.read_bytes()).hexdigest()))
    write_rows(folder / 'amr_inputs.jsonl',
               (dict(claim_id=r['claim_id'], text=r['text']) for r in examples))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=('select','fresh','transcripts'))
    stage = parser.parse_args().stage
    if stage == 'select':
        select()
    else:
        prepare(stage)
