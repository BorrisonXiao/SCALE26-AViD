"""Compare three transcript checks and connect their outputs to DeepProbLog."""
import argparse
from collections import Counter
from hashlib import file_digest, sha256
import itertools

from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import RUN, read
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.compiler_fallback import restore
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.representation import STATES
from probabilistic_verification.transcript_or import ENTAILMENT_THRESHOLD, judge, normalize, splits

FOLDER = RUN / 'transcripts'
METHODS = ('whole_nli', 'explicit_or', 'branch_nli')
NLI_STATE = {'entailment': 'supported', 'contradiction': 'refuted', 'neutral': 'unknown'}


def verified_cases():
    assert sha256((FOLDER / 'cases.json').read_bytes()).hexdigest() == (
        FOLDER / 'case_sha256.txt').read_text().strip()
    return read(FOLDER / 'cases.json')['cases']


def score():
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    torch.set_num_threads(4)
    folder = RUN / 'source/minilm-nli'
    snapshot = read(folder / 'snapshot.json')
    for name, digest in snapshot['sha256'].items():
        with (folder / name).open('rb') as file:
            assert file_digest(file, 'sha256').hexdigest() == digest
    tokenizer = AutoTokenizer.from_pretrained(folder, local_files_only=True, use_fast=True)
    model = AutoModelForSequenceClassification.from_pretrained(
        folder, local_files_only=True, use_safetensors=True).eval()
    labels = {i: label.casefold() for i, label in model.config.id2label.items()}
    assert set(labels.values()) == NLI_STATE.keys()
    pairs = set()
    for segment in verified_cases():
        for case in segment['cases']:
            if case['speaker'] != segment['speaker']:
                continue
            evidence, target = case['text'], case['target']
            pairs.add((evidence, target))
            targets = list(splits(target, 'or'))
            if len(targets) == 1:
                candidates = {evidence}
                for pair in itertools.chain(splits(evidence, 'or'), splits(evidence, 'and')):
                    candidates.update(pair)
                for a, b in itertools.product(candidates, targets[0]):
                    if normalize(a) != normalize(b):
                        pairs.update(((a, b), (b, a)))
    outputs = []
    pairs = sorted(pairs)
    with torch.inference_mode():
        for i in range(0, len(pairs), 16):
            batch = pairs[i:i+16]
            premises, hypotheses = zip(*batch)
            inputs = tokenizer(list(premises), list(hypotheses), padding=True,
                               truncation=True, return_tensors='pt')
            probabilities = model(**inputs).logits.softmax(dim=-1).tolist()
            outputs.extend(dict(premise=a, hypothesis=b, probabilities={labels[i]: p for i, p in enumerate(probs)})
                           for (a, b), probs in zip(batch, probabilities))
    dump(FOLDER / 'nli_scores.json', dict(snapshot=snapshot, device='cpu',
         torch_version=torch.__version__, scores=outputs))
    print(f'Scored {len(outputs)} premise and hypothesis pairs.')


def evaluate():
    scores = {(r['premise'], r['hypothesis']): r['probabilities']
              for r in read(FOLDER / 'nli_scores.json')['scores']}

    def entailment(a, b):
        return scores[a, b]['entailment']

    segments = verified_cases()
    totals, correct, confusion = Counter(), {m: Counter() for m in METHODS}, {m: Counter() for m in METHODS}
    for segment in segments:
        for case in segment['cases']:
            v, expected = case['variant'], case['expected']
            if (case['speaker'] == segment['speaker'] and case['start'] < segment['end']
                    and case['end'] > segment['start']):
                nli = scores[case['text'], case['target']]
                baseline = NLI_STATE[max(nli, key=nli.get)]
            else:
                baseline = 'unknown'
            case['predictions'] = dict(zip(METHODS, (
                baseline, judge(segment, case), judge(segment, case, entailment))))
            totals[v] += 1
            for method, outcome in case['predictions'].items():
                correct[method][v] += outcome == expected
                confusion[method][expected, outcome] += 1
    per_variant = {v: dict(total=n, correct={m: correct[m][v] for m in METHODS}) for v, n in totals.items()}
    result = dict(
        matches={m: sum(correct[m].values()) for m in METHODS}, comparisons=sum(totals.values()),
        entailment_threshold=ENTAILMENT_THRESHOLD, per_variant=per_variant, segments=segments,
        confusion={m: {e: {p: cells[e,p] for p in STATES} for e in STATES} for m, cells in confusion.items()})
    dump(FOLDER / 'evaluation.json', result)
    print(result['matches'], result['per_variant'])


def inference():
    results = read(FOLDER / 'evaluation.json')
    segments = {r['claim_id']: r for r in results['segments']}
    records = []
    for row in read(FOLDER / 'compiled.json'):
        segment = segments[row['claim_id']]
        output = row['fixed']['output']
        record = dict(claim_id=row['claim_id'], claim=row['text'], stage=row['fixed']['selected_stage'],
                      attempts=row['fixed']['attempts'], conditions=[], cases=[])
        records.append(record)
        if not output:
            continue
        claim = restore(output['compilation'])
        atoms = [a for a in claim.atoms if a.predicate == 'reported_disjunction']
        record['conditions'] = [a.arguments[2] for a in atoms]
        if len(atoms) != 1:
            continue
        # The compiler may retain the complementizer that introduces the reported clause.
        compiled_content = normalize(atoms[0].arguments[2])
        source_forms = {normalize(row['content']), normalize(segment['text'])}
        if not source_forms.intersection({compiled_content, compiled_content.removeprefix('that ')}):
            continue
        candidates = {v.name: [f'{segment["meeting"]}:{segment["speaker"]}' if v.name == atoms[0].arguments[0]
                               else 'control:'+v.name] for v in claim.variables}
        assignment = {v: ids[0] for v, ids in candidates.items()}
        for case in segment['cases']:
            if case['variant'] == 'paraphrased_claim':
                continue
            state = case['predictions']['branch_nli']
            observations = {}
            for atom in claim.atoms:
                speech = atom.predicate == 'reported_disjunction'
                route = 'speech_assertion' if speech else 'visual_depiction'
                key = canonical_key(segment['meeting'], atom, assignment, route)
                atom_state = state if speech else 'supported'
                provenance = dict(source=case['provenance'], speaker=case['speaker'],
                                  start=case['start'], end=case['end']) if speech else dict(source='fixed control')
                observations[key] = Observation(key, tuple(float(s == atom_state) for s in STATES),
                                                False, atom.text, provenance)
            evidence = Evidence(segment['meeting'], candidates, dict.fromkeys(candidates, True), observations)
            program = ground(claim, evidence)
            result = DirectVerifier([program], learned=False, program_builder=compact_prolog_program).predict()[0]
            distribution = result['distribution']
            record['cases'].append(dict(variant=case['variant'], expected=case['expected'], transcript_state=state,
                                        distribution=distribution, occurrences=program.occurrences,
                                        observations=[o.to_dict() for o in program.observations.values()]))
    dump(FOLDER / 'inference.json', records)
    print('Actual compiler conditions', sum(bool(r['conditions']) for r in records),
          'exact matches', sum(bool(r['cases']) for r in records),
          'inference comparisons', sum(len(r['cases']) for r in records))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage', choices=('score','evaluate','inference'))
    {'score': score, 'evaluate': evaluate, 'inference': inference}[p.parse_args().stage]()
