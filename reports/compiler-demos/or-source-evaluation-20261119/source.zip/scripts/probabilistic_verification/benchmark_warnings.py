"""Advisory checks for source names, measurements and clause scope."""
from decimal import Decimal, InvalidOperation
import json
import re

from .amr_source_alignment import quote_spans
from .compiler_fallback import restore
from .fallback_semantics import literal_values
from .typed_literals import PATTERN, measurement_literal


def words(text):
    return re.findall(r'[^\W_]+', str(text).casefold())


def arguments(atom):
    # Compiler atoms may carry scope, owner and route metadata after their
    # semantic arguments. Keep the literal text in a single source value.
    parts = atom.arguments
    i = max((i for i, x in enumerate(parts) if x == 'scope'), default=len(parts))
    content = parts[:i]
    return content[:content.index('context_owner')] if 'context_owner' in content else content


def values(claim):
    for atom in claim.atoms:
        yield atom.predicate
        for value in arguments(atom):
            try:
                parsed = json.loads(value)
            except (ValueError, TypeError):
                yield value
                continue
            if isinstance(parsed, dict):
                yield str(parsed.get('value', ''))
            else:
                yield value


def name_spans(tokens):
    sequence = []
    for token in tokens:
        if token['upos'] == 'PROPN':
            if sequence and token['id'] != sequence[-1]['id'] + 1:
                if len(sequence) >= 2:
                    yield sequence
                sequence = []
            sequence.append(token)
        else:
            if len(sequence) >= 2:
                yield sequence
            sequence = []
    if len(sequence) >= 2:
        yield sequence


def measurement_key(value):
    try:
        unit = value.get('unit', '').casefold()
        lower = Decimal(str(value.get('lower', value['value'])).replace(',', ''))
        upper = Decimal(str(value['upper']).replace(',', '')) if 'upper' in value else None
        return lower, upper, unit
    except (KeyError, TypeError, InvalidOperation):
        return None


def measurements(claim):
    for atom in claim.atoms:
        for value in arguments(atom):
            try:
                literal = json.loads(value)
            except (TypeError, ValueError):
                literal = measurement_literal(value)
            if (isinstance(literal, dict) and literal.get('kind') == 'measurement'
                    and measurement_key(literal)):
                yield measurement_key(literal)
    # Typed AMR represents an interval by a between node and two quantities.
    roles = {}
    concepts = {}
    quantities = {}
    for atom in claim.atoms:
        content = arguments(atom)
        if atom.predicate == 'concept' and len(content) == 2:
            concepts[content[0]] = content[1]
        elif atom.predicate == 'role' and len(content) == 3:
            roles.setdefault(content[0], {}).setdefault(content[1], []).append(content[2])
        elif atom.predicate in {'quantity', 'literal'} and len(content) == 3 and content[1] in {'quant', 'value'}:
            quantities.setdefault(content[0], []).append(content[2])

    def get_unit(name):
        if concepts.get(name) == 'percentage-entity':
            return '%'
        unit = roles.get(name, {}).get('unit', [])
        if len(unit) == 1:
            parsed = measurement_literal('1 ' + concepts.get(unit[0], ''))
            return parsed['unit'] if parsed else None
        return None

    for var, values in quantities.items():
        unit = get_unit(var)
        if len(values) == 1 and unit:
            key = measurement_key(dict(value=values[0], unit=unit))
            if key:
                yield key
    for var, concept in concepts.items():
        if concept != 'between':
            continue
        lo, hi = (roles.get(var, {}).get(op, []) for op in ('op1', 'op2'))
        if len(lo) != 1 or len(hi) != 1:
            continue
        first, second = (quantities.get(v, []) for v in (lo[0], hi[0]))
        unit = get_unit(lo[0])
        if len(first) == len(second) == 1 and unit and unit == get_unit(hi[0]):
            key = measurement_key(dict(value=first[0], lower=first[0], upper=second[0], unit=unit))
            if key:
                yield key


def warnings(record, compilation):
    claim = restore(compilation)
    text = record['text']
    literal_quotes = set(literal_values(claim))
    quoted = [q for q in quote_spans(text) if q['text'] in literal_quotes]

    def outside(start):
        return not any(q['start'] <= start < q['end'] for q in quoted)

    tokens = [t for t in record.get('tokens', []) if outside(t.get('start_char', -1))]
    emitted = [words(v) for v in values(claim)]
    words_used = {part for seq in emitted for part in seq}
    alerts = []
    for name in name_spans(tokens):
        source = text[name[0]['start_char']:name[-1]['end_char']]
        missing = set(words(source)) - words_used
        if missing:
            alerts.append(dict(code='proper_name_omission', source=source, missing=sorted(missing),
                               reason='Part of an explicit multiword name is absent from the emitted predicates.'))
    for match in re.finditer(r"(?<!\w)@?[A-Za-z][A-Za-z0-9]*(?:_[A-Za-z0-9]+)+(?!\w)", text):
        if outside(match.start()) and not set(words(match[0])).issubset(words_used):
            alerts.append(dict(code='identifier_omission', source=match[0],
                               reason='An explicit handle or identifier is absent from the emitted predicates.'))
    represented = set(measurements(claim))
    for match in PATTERN.finditer(text):
        if not outside(match.start()):
            continue
        if match.start() and (text[match.start() - 1].isalnum() or text[match.start() - 1] in '$€£'):
            continue
        if match.end() < len(text) and text[match.end()].isalnum():
            continue
        parsed = measurement_literal(match[0])
        if parsed and measurement_key(parsed) not in represented:
            code = 'measurement_range_unbound' if match['upper'] else 'measurement_unbound'
            alerts.append(dict(code=code, source=match[0],
                               reason='An explicit numeric value and its unit lack a typed measurement binding.'))
    scopes = claim.metadata.get('scopes', {})
    source_or = any(t['lemma'] == 'or' and t['deprel'] == 'cc' for t in tokens)
    def contains_or(node):
        return node.op == 'or' or any(contains_or(child) for child in node.children)

    has_or = contains_or(claim.expression)
    if source_or and not has_or:
        alerts.append(dict(code='alternative_missing', source='or',
                           reason='The source contains an explicit alternative and the formula contains no OR.'))
    # An explicitly inferred location or possibility must appear as a
    # qualification. Being present as a word or an unrelated event is weaker.
    source_forms = {t['text'].casefold() for t in tokens}
    observed_kinds = {scope.get('kind', '') for scope in scopes.values()}
    operators = {scope.get('operator', '') for scope in scopes.values()}
    operators.update(arguments(atom)[0] for atom in claim.atoms if atom.predicate == 'qualification')
    cue_classes = (
        ({'likely', 'probably', 'presumably'}, {'likely', 'likely identity', 'belief'}, 'likely'),
        ({'possibly'}, {'possible', 'possibility'}, 'possible'),
        ({'apparently', 'inferred'}, {'appearance', 'inference', 'uncertain'}, 'inferred'),
        ({'reportedly', 'allegedly'}, {'assertion', 'accusation', 'uncertain'}, 'reported'),
    )
    for cues, expected, name in cue_classes:
        present = sorted(cues & source_forms)
        generic_likelihood = name == 'likely' and any(
            atom.predicate == 'proposition' and 'likely identity' in arguments(atom) for atom in claim.atoms
        )
        if present and not ((observed_kinds | operators) & expected or generic_likelihood):
            alerts.append(dict(code='qualification_scope_missing', source=' '.join(present),
                               reason='An explicit qualifier has no matching qualification in the emitted program.'))
    return alerts
