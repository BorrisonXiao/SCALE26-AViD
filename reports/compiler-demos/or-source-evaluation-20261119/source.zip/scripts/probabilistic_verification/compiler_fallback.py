"""Fixed, failure-only SRL -> AMR -> bounded rewrite routing.

Review judgments, media evidence and claim-level labels never select a parser.
A parsing abstention is distinct from unknown evidence for a compiled claim.
"""
import copy,hashlib,json,math
from dataclasses import replace
from .representation import Atom,Expression,Variable
from .logical_form_v2 import ScopedClaim
from .fallback_semantics import apply_shared_semantics
from .logic import Evidence,ground
from .compact_backend import compact_prolog_program


def restore(data):
    def expr(d):return Expression(d['op'],tuple(expr(c)for c in d.get('children',[])),d.get('atom_id',''),tuple(d.get('variables',[])),d.get('state',''))
    def atom(d):return Atom(d['id'],d['predicate'],tuple(d['arguments']),d['kind'],tuple(d.get('roles',[])),d.get('text',''),tuple(d.get('token_ids',[])),d.get('trainable',False))
    return ScopedClaim(data['claim_id'],data['text'],tuple(data.get('tokens',[])),tuple(Variable(v['name'],v['kind'],v['description'],tuple(v.get('token_ids',[])))for v in data['variables']),tuple(atom(a)for a in data['atoms']),expr(data['expression']),tuple(data.get('coverage',[])),tuple(data.get('warnings',[])),data.get('version','logical-form-v2'),copy.deepcopy(data.get('metadata',{})))


def serialize(claim):
    evidence=Evidence('compilation_only',{v.name:['placeholder:'+v.name]for v in claim.variables},{v.name:True for v in claim.variables},{})
    p=compact_prolog_program([ground(claim,evidence,max_expansions=3000)],learned=False)[0]
    from problog.program import PrologString
    list(PrologString(p))
    return dict(compilation=claim.to_dict(),program=p,program_sha256=hashlib.sha256(p.encode()).hexdigest())


def check_output(record,output):
    result=copy.deepcopy(output)
    if 'compilation'not in result:return result
    claim=restore(result['compilation']);revised,errors=apply_shared_semantics(record,claim)
    result['shared_checks']=errors
    # Re-emit only after an actual change; keep exact old successful strings.
    if revised.to_dict()!=claim.to_dict():result.update(serialize(revised))
    if errors:
        result['status']='unsupported';result['code']=errors[0]['code'];result['reason']=errors[0]['reason']
    return result


def compile_claim(record,*,srl,amr,rewrite=None):
    attempts=[]
    for name,compiler in [('srl',srl),('amr',amr),('rewrite',rewrite)]:
        if compiler is None:
            attempts.append(dict(stage=name,status='unavailable',code='rewrite_unavailable',reason='No rewrite provider supplied.'));continue
        try:
            raw=compiler(record,attempts)if name=='rewrite'else compiler(record)
            output=check_output(record,raw)
        except Exception as error:
            output=dict(status='unsupported',code=getattr(error,'code',type(error).__name__),reason=str(error))
        attempts.append(dict(stage=name,**output))
        if output['status']=='compiled':
            return dict(claim_id=record['claim_id'],text=record['text'],parsing_status='compiled',selected_stage=name,output=output,attempts=attempts,verification_status='not_run')
    return dict(claim_id=record['claim_id'],text=record['text'],parsing_status='abstained',selected_stage=None,output=None,attempts=attempts,reason='No complete program passes the fixed compilation checks.',verification_status='parsing_abstention')


def verify(compilation,predict):
    """predict takes the selected program and returns evidence-state probabilities."""
    if compilation['parsing_status']!='compiled':
        return dict(claim_id=compilation['claim_id'],verdict='abstain',reason='parsing_failure',distribution=None)
    distribution=predict(compilation['output'])
    if set(distribution)!={'supported','refuted','unknown'}:raise ValueError('Expected supported/refuted/unknown evidence probabilities.')
    if any(not isinstance(v,(int,float))or not math.isfinite(v)or v<0 or v>1 for v in distribution.values())or abs(sum(distribution.values())-1)>1e-6:raise ValueError('Evidence probabilities must be finite and sum to one.')
    verdict=max(distribution,key=distribution.get)
    return dict(claim_id=compilation['claim_id'],verdict='insufficient_evidence'if verdict=='unknown'else verdict,reason='evidence_inference',distribution=distribution)
