"""Source-licensed repairs for embedded references and conditional alternatives."""
import re
from dataclasses import replace

import penman
from penman.models.amr import model

from .amr_types import compile_typed
from .compiler_coverage import (
    CoordinationScopePolicy,
    compile_reentrant_amr,
    normalize_annotated_coordination,
    normalize_sentence_mode,
)
from .fallback_amr import prepare_fallback


def source_scope_graph(record, raw):
    """Preserve source scope in three narrow, fully anchored graph constructions."""
    graph = penman.decode(raw, model=model)
    triples = list(graph.triples)
    concepts = {node: sense for node, _, sense in graph.instances()}
    text = record['text']
    tokens = record.get('tokens', [])
    edits = []

    def targets(node, role):
        return [value for source, edge, value in triples if (source, edge) == (node, role)]

    def one(node, role):
        values = targets(node, role)
        return values[0] if len(values) == 1 else None

    def change(remove, add, kind):
        for edge in remove:
            triples.remove(edge)
        triples.extend(add)
        edits.append(dict(kind=kind, removed=remove, added=add))

    # The source introduces a noun as the subject of "means that", then
    # refers to that same definite NP inside the "unless" clause.
    root = graph.top
    ruling = one(root, ':ARG1')
    result = one(root, ':ARG2')
    if (concepts[root] == 'mean-01' and concepts.get(ruling) == 'rule-01'
            and re.search(r'^The ruling means that .*\bunless the ruling\b', text, re.I)
            and not any(source == ruling and edge != ':instance' for source, edge, _ in triples)):
        change([(ruling, ':instance', 'rule-01'), (root, ':ARG2', result)],
               [(ruling, ':instance', 'ruling'), (root, ':implication', result)],
               'shared definite noun across unless')

    # Only move a condition when the source parser attaches its head to the
    # final member of an explicit OR. The cached AMR attaches it to possibility.
    marks = [t for t in tokens if t['lemma'] == 'if' and t['deprel'] == 'mark']
    token_map = {t['id']: t for t in tokens}
    if len(marks) == 1 and concepts[root] in {'note-01', 'say-01', 'report-01'}:
        condition_head = token_map.get(marks[0]['head'])
        last_member = token_map.get(condition_head['head']) if condition_head else None
        syntax_agrees = bool(last_member and last_member['deprel'] == 'conj'
                             and any(t['head'] == last_member['id'] and t['deprel'] == 'cc'
                                     and t['lemma'] == 'or' for t in tokens))
        if syntax_agrees and last_member['lemma'] == 'ballot':
            for possible, sense in concepts.items():
                if sense != 'possible-01':
                    continue
                vote = one(possible, ':ARG1')
                condition = one(possible, ':condition')
                if concepts.get(vote) != 'vote-01' or condition is None:
                    continue
                actor = one(vote, ':ARG0')
                alternatives = one(vote, ':time')
                if concepts.get(alternatives) != 'or' or actor is None:
                    continue
                options = sorted((edge, target) for source, edge, target in triples
                                 if source == alternatives and re.fullmatch(r':op[1-9]', edge))
                if (len(options) < 2 or concepts.get(options[-1][1]) != 'ballot'
                        or {edge for source, edge, _ in triples if source == vote}
                        != {':instance', ':ARG0', ':time'}
                        or any(target == vote and (source, edge) != (possible, ':ARG1')
                               for source, edge, target in triples)):
                    continue
                remove = [(possible, ':ARG1', vote), (possible, ':condition', condition),
                          (vote, ':time', alternatives), (vote, ':ARG0', actor),
                          (vote, ':instance', 'vote-01')]
                add = [(possible, ':ARG1', alternatives)]
                for index, (edge, option) in enumerate(options):
                    new_vote = vote if index == 0 else f'{vote}option{index}'
                    while new_vote in concepts and index > 0:
                        new_vote += 'x'
                    last = index == len(options) - 1
                    remove.append((alternatives, edge, option))
                    add.extend([(alternatives, edge, new_vote),
                                (new_vote, ':instance', 'vote-01'), (new_vote, ':ARG0', actor),
                                (new_vote, ':instrument' if last else ':time', option)])
                    if last:
                        add.append((new_vote, ':condition', condition))
                change(remove, add, 'condition on final alternative')

    # "Image of PERSON doing ..." supplies an explicit depiction relation.
    # A parenthetical likely NP classifies the same object under uncertainty.
    if concepts[root] in {'image', 'photo', 'photograph'} and re.match(
            r'^(?:An? )?(?:Image|Photo|Photograph) of\b', text, re.I,
    ):
        action = one(root, ':mod')
        actor = one(action, ':ARG0')
        obj = one(action, ':ARG1')
        identity = [source for source, role, target in triples
                    if (role, target) == (':ARG1', obj) and concepts.get(source) == 'mean-01']
        if actor and obj and len(identity) == 1:
            ident = identity[0]
            object_type = one(ident, ':ARG2')
            likelihood = [source for source, role, target in triples
                          if (role, target) == (':ARG1', object_type) and concepts.get(source) == 'likely-01']
            adjectives = [target for source, role, target in triples
                          if source == object_type and role == ':mod']
            anchors = [t for t in tokens if t.get('deprel') == 'acl'
                       and t['head'] == next((u['id'] for u in tokens if u['head'] == 0), -1)
                       and concepts.get(action, '').startswith(t['lemma'] + '-')]
            parenthetical = re.search(r'\(likely ([^()]+)\)\.?$', text, re.I)
            if (len(likelihood) == 1 and len(anchors) == 1 and parenthetical
                    and concepts.get(obj) == 'something' and object_type
                    and re.search(rf'\b{re.escape(concepts[object_type].split("-")[0])}s?\b',
                                  parenthetical[1], re.I)
                    and {edge for source, edge, _ in triples if source == ident}
                    == {':instance', ':ARG1', ':ARG2'}
                    and len(adjectives) <= 1):
                change([(root, ':mod', action), (ident, ':instance', 'mean-01'),
                        (ident, ':ARG1', obj), (ident, ':ARG2', object_type),
                        (likelihood[0], ':ARG1', object_type),
                        (object_type, ':instance', concepts[object_type])],
                       [(root, ':topic', action), (obj, ':qualification', likelihood[0]),
                        (likelihood[0], ':ARG1', object_type),
                        (object_type, ':instance', concepts[object_type].split('-')[0])],
                       'depiction and likely object type')

    if not edits:
        return raw, []
    return penman.encode(penman.Graph(triples, top=root), model=model), edits


class SourceScopeRepairPolicy(CoordinationScopePolicy):
    def kind(self, predicate, role, node, concepts, edges, matches):
        if role == 'implication':
            return 'implication'
        if role == 'qualification':
            return 'qualification'
        if predicate == 'likely-01' and role == 'ARG1':
            return 'likely identity'
        return super().kind(predicate, role, node, concepts, edges, matches)


def compile_scope_repair(record, raw, *, strict=False, prepared=None):
    """Compile repaired graphs with the original typing and scope defaults."""
    claim = compile_typed(record, raw, strict=strict, prepared=prepared,
                          scope_policy=SourceScopeRepairPolicy(record))
    return preserve_ancestor_bindings(claim)


def repair_program(record, raw, inspect):
    normalized, edits = source_scope_graph(record, raw)
    if not edits:
        return dict(status='unsupported', code='no_source_licensed_edit',
                    reason='The clause and graph do not match the supported repair conditions.')
    normalized, modes = normalize_sentence_mode(normalized)
    normalized, coordination = normalize_annotated_coordination(normalized)
    prepare = (prepare_condition if any(edit['kind'] == 'shared definite noun across unless'
                                       for edit in edits) else prepare_fallback)
    result = inspect(record, normalized, compiler=compile_scope_repair, prepare=prepare)
    if not result.get('program'):
        result = inspect(record, normalized, compiler=compile_reentrant_amr, prepare=prepare)

    return dict(result, source_repairs=edits, modes=modes, coordination_changes=coordination)


def place_condition_declaration(raw):
    """Declare a condition under its owning clause, leaving its referent shared."""
    from collections import Counter

    tree = penman.parse(raw)
    nodes = {}
    parents = {}

    def index(node, parent=None, role=None):
        name, edges = node
        nodes[name] = node
        parents[name] = (parent, role)
        for edge, value in edges:
            if isinstance(value, tuple):
                index(value, name, edge)

    index(tree.node)
    moves = {}
    for name, (_, edges) in nodes.items():
        for edge, value in edges:
            if edge != ':condition' or not isinstance(value, str) or value not in nodes:
                continue
            parent, inverse = parents[value]
            if not parent or not model.is_role_inverted(inverse):
                continue
            # The earlier declaration was incidental to an inverse role. Move
            # the definition to the condition and add the corresponding
            # forward argument back to the same named referent.
            _, forward, _ = model.invert((parent, inverse, value))
            moves[value] = (name, parent, inverse, forward)
    if not moves:
        return raw, []

    def encode_node(node):
        name, edges = node
        output = []
        for edge, value in edges:
            if isinstance(value, tuple) and value[0] in moves and moves[value[0]][1:3] == (name, edge):
                continue
            if edge == ':condition' and isinstance(value, str) and value in moves and moves[value][0] == name:
                _, parent, _, forward = moves[value]
                node_name, new_edges = encode_node(nodes[value])
                output.append((edge, (node_name, [*new_edges, (forward, parent)])))
            else:
                output.append((edge, encode_node(value) if isinstance(value, tuple) else value))
        return name, output

    candidate = penman.format(penman.Tree(encode_node(tree.node)))
    before = penman.decode(raw, model=model)
    after = penman.decode(candidate, model=model)
    if before.top != after.top or Counter(before.triples) != Counter(after.triples):
        raise ValueError('Changing the declaration position must preserve every semantic edge.')
    trace = [dict(condition=node, owner=owner, referent=parent, role=forward)
             for node, (owner, parent, _, forward) in moves.items()]
    return candidate, trace


def prepare_condition(record, raw):
    changed, info, alignment, licenses = prepare_fallback(record, raw)
    changed, trace = place_condition_declaration(changed)
    info['normalisations'] += [dict(kind='condition_declaration', **item) for item in trace]
    return changed, info, alignment, licenses


def preserve_ancestor_bindings(claim):
    """Keep an explicit reference bound to its ancestor even inside NOT."""
    from .representation import Expression

    references = {atom.id: atom.arguments[0] for atom in claim.atoms
                  if atom.predicate == 'reference'}
    changes = []

    def referenced(node):
        if node.op == 'atom':
            return {references[node.atom_id]} if node.atom_id in references else set()
        return set().union(*(referenced(child) for child in node.children))

    def visit(node, outer):
        shadowed = set(node.variables) & outer & referenced(node) if node.op == 'exists' else set()
        if shadowed:
            changes.extend(sorted(shadowed))
        remaining = tuple(v for v in node.variables if v not in shadowed)
        children = tuple(visit(child, outer | set(remaining)) for child in node.children)
        if node.op == 'exists':
            return Expression.exists(remaining, children[0])
        return replace(node, children=children)

    expression = visit(claim.expression, set())
    if not changes:
        return claim
    return replace(claim, expression=expression,
                   metadata=dict(claim.metadata, ancestor_bindings_preserved=changes))


def explicit_or_warning(record, compilation):
    """Find a source coordinator with no OR in the selected formula."""
    from .fallback_semantics import literal_values
    from .compiler_fallback import restore
    from .amr_source_alignment import quote_spans

    claim = restore(compilation)
    quotes = set(literal_values(claim))
    protected = [q for q in quote_spans(record['text']) if q['text'] in quotes]
    markers = [t for t in record['tokens'] if t['lemma'] == 'or' and t['deprel'] == 'cc'
               and not any(q['start'] <= t['start_char'] < q['end'] for q in protected)]
    if not markers:
        return False

    def has_or(node):
        return node.op == 'or' or any(has_or(child) for child in node.children)

    return not has_or(claim.expression)
