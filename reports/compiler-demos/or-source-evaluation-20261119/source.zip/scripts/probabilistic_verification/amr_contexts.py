"""Source-licensed noun readings and contexts; preserve every changed triple.

This is a bounded extension of one AMR compiler, not a second parser. Lexical
ambiguity without a usable source construction is retained or flagged.
"""
from functools import lru_cache
import itertools
import re

from .amr_composition import COMPLEMENTS, EVENT
from .amr_scope import CLASSES
from .amr_source_alignment import prepare_source, literal, normal
from .amr_types import (TypedAlignment, TypedScopePolicy, compile_typed,
                        normalization_licenses, EVENT_NOUN_CLASSES)

SCOPE_PREDICATES = set(COMPLEMENTS) | {p for ps in CLASSES.values() for p in ps} | {
    'sound-01', 'have-purpose-91', 'mission-01', 'request-01', 'refer-01', 'mean-01', 'define-01'}
OBJECT_CATEGORIES = {'noun.artifact','noun.object','noun.person','noun.animal','noun.plant',
                     'noun.food','noun.location','noun.body','noun.substance','noun.shape','noun.group','noun.Tops'}


@lru_cache(maxsize=4096)
def noun_senses(word):
    from nltk.corpus import wordnet
    return tuple(dict(name=s.name(), category=s.lexname(),
                      verbs=tuple(sorted({v.name().replace('_','-') for l in s.lemmas()
                                          for v in l.derivationally_related_forms()
                                          if v.synset().pos() == 'v'})))
                 for s in wordnet.synsets(word, pos=wordnet.NOUN))


@lru_cache(maxsize=2048)
def adjective_verbs(word):
    from nltk.corpus import wordnet
    verbs = {v.name() for s in wordnet.synsets(word, pos=wordnet.ADJ)
             for l in s.lemmas() if normal(l.name()) == word
             for v in l.derivationally_related_forms() if v.synset().pos() == 'v'}
    base = wordnet.morphy(word, wordnet.VERB)
    if base:
        verbs.add(base)
    return verbs


@lru_cache(maxsize=2048)
def adjective_nouns(word):
    from nltk.corpus import wordnet
    return {v.name().replace('_','-') for s in wordnet.synsets(word,pos=wordnet.ADJ)
            for l in s.lemmas() if normal(l.name())==word for v in l.pertainyms()
            if v.synset().pos()=='n'}


class ContextAlignment(TypedAlignment):
    def __init__(self, record, concepts, triples=(), *, relational_adjectives=False):
        super().__init__(record, concepts)
        self.property_alignments = {}
        for n, p in concepts.items():
            if self.matches(n):
                continue
            if not EVENT.search(p) and not relational_adjectives:
                continue
            stem = re.sub(r'-\d\d$', '', p)
            ts = [t for t in self.tokens if t.get('upos') == 'ADJ'
                  and stem in (adjective_verbs if EVENT.search(p) else adjective_nouns)(normal(t.get('lemma', t['text'])))]
            if len(ts) == 1:
                self.anchors[n] = ts
                self.property_alignments[n] = dict(token_id=ts[0]['id'], source=ts[0]['text'])
        # Align a named participant to the head of its exact source mention.
        # This is needed for "David Axelrod is an advisor"; no fuzzy names.
        for node, role, target in triples:
            if role != ':name' or self.matches(node):
                continue
            parts=sorted([(r,literal(v))for s,r,v in triples if s==target and re.fullmatch(r':op\d+',r)],key=lambda x:int(x[0][3:]))
            name=' '.join(v for _,v in parts)
            spans=list(re.finditer(r'(?<!\w)'+re.escape(name)+r'(?!\w)',record['text'],re.I)) if name else []
            if len(spans)!=1:
                continue
            span=spans[0];terms=[t for t in self.tokens if span.start()<=t.get('start_char',-1)<span.end()];ids={t['id']for t in terms}
            heads=[t for t in terms if t.get('head')not in ids]
            if len(heads)==1:self.anchors[node]=heads


def noun_anchors(record, concepts, triples):
    # Relational adjectives help map noun dependents (economic -> economy),
    # but must not be fed into a check that rejects adjective participants:
    # music is a legitimate theme of a musical performance.
    alignment = ContextAlignment(record, concepts, triples, relational_adjectives=True)
    for n, p in concepts.items():
        if alignment.matches(n) or not EVENT.search(p):
            continue
        stem = re.sub(r'-\d\d$', '', p)
        ts = [t for t in record.get('tokens', []) if t.get('upos') == 'NOUN'
              and any(stem in s['verbs'] for s in noun_senses(normal(t.get('lemma', t['text']))))]
        if len(ts) == 1:
            alignment.anchors[n] = ts
    return alignment


def nominal_lexicon(record, token):
    """Prefer an attested adjacent noun compound over the isolated head word."""
    modifiers = [t for t in record.get('tokens', []) if t.get('head') == token['id']
                 and t.get('deprel') in {'amod', 'compound'} and t['id'] < token['id']]
    for count in range(min(2, len(modifiers)), 0, -1):
        for selected in itertools.combinations(modifiers, count):
            terms = sorted([*selected, token], key=lambda t:t['id'])
            if terms[-1]['id']-terms[0]['id'] != len(terms)-1:
                continue
            word = '_'.join(normal(t.get('lemma', t['text'])) for t in terms)
            senses = noun_senses(word)
            if senses:
                return word, senses
    word = normal(token.get('lemma', token['text']))
    return word, noun_senses(word)


def normalize_nouns(record, raw):
    import penman
    from penman.models.amr import model
    graph = penman.decode(raw, model=model); triples = list(graph.triples)
    concepts = {s:t for s,r,t in triples if r == ':instance'}
    alignment = noun_anchors(record, concepts, triples)
    tokens = record.get('tokens', []); changes = []; issues = []; readings = {}
    for node, predicate in concepts.items():
        token = alignment.unique(node)
        if not EVENT.search(predicate) or predicate.endswith('-91') or predicate in SCOPE_PREDICATES or not token or token.get('upos') != 'NOUN':
            continue
        word, senses = nominal_lexicon(record, token)
        copula = (any(t.get('head') == token['id'] and t.get('deprel') == 'cop' and t.get('lemma') == 'be' for t in tokens)
                  and not any(t.get('head') == token['id'] and t.get('deprel') == 'case' for t in tokens))
        non_event = (bool(senses) and any(s['category'] in OBJECT_CATEGORIES for s in senses)
                     and all(s['category'] not in EVENT_NOUN_CLASSES for s in senses))
        readings[node] = dict(source=token['text'], token_id=token['id'], lookup=word,
                              senses=[s['name'] for s in senses], non_event=non_event, copular_noun=copula)
        if not (non_event or copula):
            continue
        core = [(s,r,t) for s,r,t in triples if s == node and re.fullmatch(r':ARG\d', r)]
        replacements = []
        for edge in core:
            subject = alignment.unique(edge[2])
            nominal_referent = (edge[1] == ':ARG0' and non_event
                                and concepts.get(edge[2]) in {'person','thing','man','woman','animal','organization','government-organization','company','political-party'}
                                and (graph.top == edge[2] or any(t == edge[2] and s != node and r != ':instance' for s,r,t in triples)))
            if nominal_referent:
                replacements.append((edge, (node, ':domain', edge[2])))
            elif copula and subject and subject.get('head') == token['id'] and subject.get('deprel','').startswith('nsubj'):
                replacements.append((edge, (node, ':domain', edge[2])))
            elif edge[1] == ':ARG0' and copula:
                if subject and subject.get('head') == token['id'] and subject.get('deprel','').startswith('nsubj'):
                    replacements.append((edge, (node, ':domain', edge[2])))
                else:
                    break
            elif subject and subject.get('head') == token['id'] and subject.get('deprel') in {'amod','compound'}:
                replacements.append((edge, (node, ':mod', edge[2])))
            elif subject and subject.get('head') == token['id'] and subject.get('deprel','').startswith('nmod'):
                cases = [t.get('lemma') for t in tokens if t.get('head') == subject['id'] and t.get('deprel') == 'case']
                if cases in [['of'],['to']]:
                    # A normalized source-preposition relation, not a PropBank
                    # participant or a suffix that PENMAN can invert.
                    replacements.append((edge, (node, ':'+cases[0], edge[2])))
                else:
                    break
            else:
                break
        if len(replacements) != len(core):
            message='A source noun reading has unresolved core-role mappings; coarse lexical categories alone do not establish an error.'
            readings[node]['unresolved_roles']=message
            # A copula alone does not distinguish an event noun from a result:
            # "the video is an interview" can keep the interview's participants.
            # Block only a lexicalized, unambiguous object reading.
            if non_event and word != normal(token.get('lemma',token['text'])):
                issues.append(dict(code='noun_argument_type', node=node, reason=message, source=token['text']))
            continue
        replacements.append(((node, ':instance', predicate), (node, ':instance', normal(token.get('lemma', token['text'])))))
        for before, after in replacements:
            triples[triples.index(before)] = after
        changes.append(dict(kind='source_noun_reading', node=node, source=token['text'], lookup=word,
                            replacements=[dict(before=a, after=b) for a,b in replacements]))
    # An event noun modifying an artifact through instrument denotes its function,
    # e.g. manufacturing tools. Do not claim that manufacturing is occurring.
    for old in list(triples):
        event, role, artifact = old
        if role != ':instrument' or event not in concepts or artifact not in concepts:
            continue
        event_token = alignment.unique(event); head = alignment.unique(artifact)
        if not event_token or not head or event_token.get('upos') != 'NOUN' or event_token.get('deprel') != 'compound' or event_token.get('head') != head['id']:
            continue
        _, senses = nominal_lexicon(record, head)
        if not any(s['category'] == 'noun.artifact' for s in senses):
            continue
        if any(t == event and r != ':instance' for s,r,t in triples):
            continue
        new = (artifact, ':purpose', event); triples[triples.index(old)] = new
        changes.append(dict(kind='artifact_function', source=event_token['text']+' '+head['text'], replacements=[dict(before=old, after=new)]))
    return penman.encode(penman.Graph(triples, top=graph.top), model=model), changes, issues, readings


class ContextScopePolicy(TypedScopePolicy):
    def kind(self, p, r, n, concepts, edges, matches):
        if p == 'request-01' and r == 'ARG1':
            return 'request'
        targets = [t for role,t in edges[n] if role == r and t in concepts]
        if p == 'mission-01' and r == 'ARG1' and any(t.get('upos') == 'NOUN' and t.get('lemma','').lower() == 'mission' for t in matches(n)):
            if targets and (EVENT.search(concepts[targets[0]]) or concepts[targets[0]] in {'and','or'}):
                return 'purpose'
        # A quoted/string term can introduce a definition. Ordinary referrals
        # of people and objects do not acquire definition scope.
        if p in {'refer-01','mean-01','define-01'} and r in {'ARG1','ARG2'} and targets:
            others = [t for role,t in edges[n] if role != r and concepts.get(t) == 'string-entity']
            if others and concepts.get(targets[0]) != 'string-entity':
                strings = [literal(v) for t in others for role,v in edges[t] if role == 'value']
                if any(value and value in self.record['text'] for value in strings):
                    return 'definition'
        # Infinitival purpose adjuncts of work/use, or explicit "in order to".
        for parent in matches(n):
            for target in targets:
                for child in matches(target):
                    if child.get('head') != parent['id'] or child.get('deprel') != 'advcl':
                        continue
                    markers = [t for t in self.record.get('tokens', []) if t.get('head') == child['id'] and t.get('deprel') == 'mark']
                    if not any(t.get('lemma') == 'to' for t in markers):
                        continue
                    clause = self.record['text'][parent.get('end_char',0):child.get('start_char',0)].lower()
                    if re.search(r'\bonly\s+to\b', clause):
                        continue
                    if parent.get('lemma') in {'work','use','employ'} or 'in order to' in clause:
                        return 'purpose'
        return super().kind(p, r, n, concepts, edges, matches)


def prepare_contextual(record, raw):
    changed, info, _ = prepare_source(record, raw)
    changed, changes, issues, readings = normalize_nouns(record, changed)
    info['normalisations'] += changes; info['issues'] += issues
    info['noun_readings'] = readings
    import penman
    normalized=penman.decode(changed)
    alignment = ContextAlignment(record, {s:t for s,r,t in normalized.instances()}, normalized.triples)
    info['property_alignments'] = alignment.property_alignments
    return changed, info, alignment, normalization_licenses(record, changed)


def compile_contextual(record, raw, *, strict=True, prepared=None):
    prepared = prepared or prepare_contextual(record, raw)
    return compile_typed(record, raw, strict=strict, prepared=prepared, scope_policy=ContextScopePolicy(record))
