"""Opt-in source/semantic checks around the fixed AMR compiler."""
from dataclasses import replace
from .amr_source_alignment import prepare_source
from .amr_refinement import compile_refined
from .amr_semantic_checks import semantic_checks
from .predicate_compilation import PredicateError

def compile_checked(record,raw,*,strict=True,prepared=None):
 prepared=prepared or prepare_source(record,raw)
 issues=semantic_checks(record,prepared[0],prepared[2])
 c=compile_refined(record,raw,strict=False,prepared=prepared)
 c=replace(c,metadata=dict(c.metadata,semantic_checks=issues,semantic_checks_pass=not issues))
 failures=c.metadata['source_checks']+issues
 if strict and failures:raise PredicateError(failures[0]['code'],failures[0]['reason'])
 return c
