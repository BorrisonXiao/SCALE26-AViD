"""One AMR converter with source-bound written strings and complement scope."""
import re
from .amr_contexts import prepare_contextual,ContextScopePolicy,ContextAlignment,noun_senses
from .amr_types import compile_typed
from .amr_source_alignment import quote_spans,normal,literal

ARTIFACTS={'sign','overlay','caption','graffiti','banner','poster','placard','inscription','text'}


class FallbackAlignment(ContextAlignment):
    """Names and explicit role nouns outrank unrelated common-noun matches."""
    def __init__(self,record,concepts,triples):
        super().__init__(record,concepts,triples)
        tokens=record.get('tokens',[])
        for node,role,target in triples:
            if role!=':name':continue
            parts=sorted([(r,literal(v))for s,r,v in triples if s==target and re.fullmatch(r':op\d+',r)],key=lambda x:int(x[0][3:]))
            name=' '.join(v for _,v in parts)
            spans=list(re.finditer(r'(?<!\w)'+re.escape(name)+r'(?!\w)',record['text'],re.I))if name else[]
            if len(spans)!=1:continue
            span=spans[0];terms=[t for t in tokens if span.start()<=t.get('start_char',-1)<span.end()];ids={t['id']for t in terms}
            heads=[t for t in terms if t.get('head')not in ids]
            if len(heads)==1:self.anchors[node]=heads
        for node,p in concepts.items():
            if p!='person'or any(s==node and r==':name'for s,r,t in triples):continue
            candidates=[]
            for source,role,target in triples:
                if target!=node or role not in{':domain',':ARG0'}:continue
                for head in self.matches(source):
                    if head.get('upos')=='NOUN'and any(x['category']=='noun.person'for x in noun_senses(normal(head.get('lemma',head['text'])))):candidates.append(head)
            if len({x['id']for x in candidates})==1:self.anchors[node]=[candidates[0]]


def normalize_quotes(record,raw):
    import penman
    from penman.models.amr import model
    graph=penman.decode(raw,model=model);triples=list(graph.triples);concepts={s:t for s,r,t in triples if r==':instance'}
    edges={n:[]for n in concepts}
    for s,r,t in triples:
        if r!=':instance':edges[s].append((r,t))
    quotes=quote_spans(record['text']);tokens=record.get('tokens',[]);alignment=ContextAlignment(record,concepts,triples)
    # Keep inverse-role modifiers declared inside the quoted PENMAN subtree.
    # Their normalized graph edge can point back toward its nominal head.
    declared_children={}
    def index(node):
        declared_children[node[0]]=[value[0]for role,value in node[1]if isinstance(value,tuple)]
        for role,value in node[1]:
            if isinstance(value,tuple):index(value)
    index(penman.parse(raw).node)
    inscriptions=[];changes=[];issues=[]
    for q in quotes:
        candidates=[]
        # Use the graph's explicit artifact-to-saying link when the dependency
        # parser attaches a long relative clause to an intervening noun.
        for n,p in concepts.items():
            if p not in ARTIFACTS:continue
            anchors=[t for t in tokens if normal(t.get('lemma',t['text']))==p]
            if len(anchors)!=1:continue
            for event,pred in concepts.items():
                if pred not in{'say-01','read-01','write-01'}:continue
                rel=edges[event]
                linked=(':ARG0',n)in rel or (pred=='write-01'and any(r in{':ARG2',':location',':medium'}and v==n for r,v in rel))
                if not linked:continue
                heads=alignment.matches(event)
                if not any(abs(t.get('start_char',-100)-q['start'])<200 for t in heads):continue
                body=[v for r,v in rel if r==':ARG1'and v in concepts and v!=n]
                if len(body)==1:candidates.append((n,event,body[0]))
        if len(set(candidates))!=1:continue
        carrier,event,body=candidates[0]
        if not any(t[0]==body for t in triples):continue
        deletion=set();todo=[body]
        while todo:
            n=todo.pop()
            if n==carrier or n in deletion:continue
            deletion.add(n);todo +=[v for _,v in edges.get(n,[])if v in concepts]+declared_children.get(n,[])
        # For several quotations joined by AND, prune only after every source
        # content anchor in that subtree belongs to one of those exact quotes.
        protected=[x for x in quotes if any(x['start']<=t.get('start_char',-1)<x['end']for n in deletion for t in alignment.matches(n))]
        if q not in protected:continue
        outside=[t for n in deletion if concepts.get(n)not in{'and','or'}for t in alignment.matches(n)if not any(x['start']<=t.get('start_char',-1)<x['end']for x in protected)]
        if outside:
            issues.append(dict(code='quote_external_anchor',reason='The quoted subtree also contains source content outside the bound quotations.'));continue
        shared=[(s,r,t)for s,r,t in triples if r!=':instance'and t in deletion and s not in deletion and s!=event]
        if shared:
            issues.append(dict(code='quote_shared_reference',reason='The quote shares an unresolved referent with content outside the quotation.'));continue
        gone=[t for t in triples if t[0]in deletion or(t[1]!=':instance'and t[2]in deletion)]
        triples=[t for t in triples if t not in gone]
        # Artifact-says/read is an inscription, not an additional speaking event.
        # A write event can still carry unquoted source participants/locations.
        if concepts[event]in{'say-01','read-01'} or (concepts[event]=='write-01' and not any(r==':ARG0'for r,_ in edges[event]) and not any(t.get('deprel')in{'aux','aux:pass'}and t.get('head')in{u['id']for u in alignment.matches(event)}for t in tokens)):
            other=[t for t in triples if t[0]==event and t[1]not in{':instance',':ARG0'} and not(t[1]in{':location',':medium',':ARG2'}and t[2]==carrier)]
            if other:
                issues.append(dict(code='quote_event_extras',reason='The inscription event has additional source conditions and is retained.'))
            else:
                gone +=[t for t in triples if t[0]==event or(t[1]!=':instance'and t[2]==event)]
                triples=[t for t in triples if t[0]!=event and not(t[1]!=':instance'and t[2]==event)]
                if graph.top==event:graph.top=carrier
        for quote in protected:
            if not any(x['carrier']==carrier and x['text']==quote['text']for x in inscriptions):inscriptions.append(dict(quote,carrier=carrier,carrier_token=next(t['id']for t in tokens if normal(t.get('lemma',t['text']))==concepts[carrier])))
        changes.append(dict(kind='written_quotation',carrier=carrier,source=protected,removed_triples=gone))
    return penman.encode(penman.Graph(triples,top=graph.top),model=model),inscriptions,changes,issues


def normalize_frames(record,raw):
    import penman
    from penman.models.amr import model
    g=penman.decode(raw,model=model);triples=list(g.triples);concepts={s:t for s,r,t in triples if r==':instance'}
    alignment=ContextAlignment(record,concepts,triples);changes=[]
    for i,(n,r,p)in enumerate(triples):
        if r!=':instance':continue
        heads=alignment.matches(n);new=None
        # Explicit lexical constructions, never global frame-number aliases.
        if p=='call-02'and re.search(r'\bcall(?:s|ed|ing)?\s+for\b',record['text'],re.I):new='call-03'
        if p=='tweet-01'and heads and (quote_spans(record['text'])or re.search(r'\b(?:Twitter|tweeted|retweet)\b',record['text'],re.I))and not re.search(r'\bbird\b',record['text'],re.I):new='tweet-02'
        if p=='sound-01'and any(t.get('upos')=='NOUN'for t in heads)and not any(s==n and k==':ARG2'for s,k,v in triples):new='sound-02'
        if new:
            triples[i]=(n,r,new);changes.append(dict(kind='frame_sense',node=n,before=p,after=new,basis='Explicit source construction and official PropBank role definitions.'))
    return penman.encode(penman.Graph(triples,top=g.top),model=model),changes


def normalize_shared_or(record, raw):
    """Preserve explicit shared time or purpose, and discard redundant 'either'."""
    if not re.search(r'/\s*or\b',raw):
        return raw, []
    import penman
    from penman.models.amr import model
    from .compiler_coverage import normalize_annotated_coordination

    graph = penman.decode(raw, model=model)
    triples = list(graph.triples)
    concepts = {n: p for n, _, p in graph.instances()}
    tokens = record['tokens']
    changes = []
    for node, predicate in concepts.items():
        if predicate != 'or':
            continue
        outgoing = [(s, r, t) for s, r, t in triples if s == node]
        members = [t for _, r, t in outgoing if re.fullmatch(r':op\d+', r)]
        annotations = [(s, r, t) for s, r, t in outgoing if r != ':instance' and not re.fullmatch(r':op\d+', r)]
        if len(members) != 2:
            continue
        if len(annotations) == 1 and annotations[0][1] == ':mod' and concepts.get(annotations[0][2]) == 'either':
            either = annotations[0][2]
            if (any(t.get('lemma') == 'either' and t.get('deprel') == 'cc:preconj' for t in tokens)
                    and {edge for edge in triples if either in (edge[0], edge[2])}
                    == {annotations[0], (either, ':instance', 'either')}):
                triples.remove(annotations[0])
                triples.remove((either, ':instance', 'either'))
                changes.append(dict(kind='explicit disjunction marker', node=node))
        if node != graph.top or len(annotations) != 1 or not all(re.search(r'-\d\d$', concepts.get(t, '')) for t in members):
            continue
        _, role, value = annotations[0]
        if role == ':time' and not any(s in members and r == ':time' for s, r, _ in triples):
            # Both event alternatives use the same time node.
            triples.remove(annotations[0])
            triples.extend((member, ':time', value) for member in members)
            changes.append(dict(kind='time shared by both event alternatives', node=node, target=value))
        elif role == ':purpose':
            # The goal scopes over the coordination. Retain a source boundary.
            rewritten, trace = normalize_annotated_coordination(raw)
            if len(trace) == 1 and trace[0]['node'] == node:
                return rewritten, [dict(kind='purpose shared by the alternatives', node=node, target=value)]
    if not changes:
        return raw, []
    return penman.encode(penman.Graph(triples, top=graph.top), model=model), changes


class FallbackScopePolicy(ContextScopePolicy):
    def kind(self,p,r,n,concepts,edges,matches):
        if (p,r)==('stop-01','ARG1'):
            heads={t['id'] for t in matches(n)}
            targets=[t for role,t in edges[n] if role==r]
            if len(targets)==1 and any(t.get('deprel')=='nsubj' and t.get('head') in heads
                                       for t in matches(targets[0])):
                # Intransitive stopping takes its participant as ARG1.
                return False
        if (p,r)==('coordination','content'):return 'coordinated content'
        if (p,r)==('look-02','ARG1'):return 'appearance'
        if (p,r)==('blame-01','ARG2'):return 'accusation'
        if (p,r)==('tweet-02','ARG1'):return 'assertion'
        if (p,r)==('call-03','ARG1'):return 'request'
        if (p,r)==('sound-02','ARG1'):return 'sound'
        return super().kind(p,r,n,concepts,edges,matches)
    def route(self,p,kind):
        if p=='tweet-02'and kind=='assertion':return 'ocr_assertion'
        return super().route(p,kind)


def prepare_fallback(record,raw):
    raw,coordination_changes=normalize_shared_or(record,raw)
    raw,frame_changes=normalize_frames(record,raw)
    changed,inscriptions,changes,issues=normalize_quotes(record,raw)
    changes=coordination_changes+frame_changes+changes
    changed,info,alignment,licenses=prepare_contextual(record,changed)
    info['normalisations']=changes+info['normalisations'];info['issues']+=issues
    for q in inscriptions:
        if not any(x['carrier']==q['carrier']and x['text']==q['text']for x in info['inscriptions']):info['inscriptions'].append(q)
    import penman
    graph=penman.decode(changed)
    alignment=FallbackAlignment(record,{s:t for s,r,t in graph.instances()},graph.triples)
    return changed,info,alignment,licenses


def compile_fallback_amr(record,raw,*,strict=True,prepared=None):
    return compile_typed(record,raw,strict=strict,prepared=prepared or prepare_fallback(record,raw),
                         scope_policy=FallbackScopePolicy(record),local_or_modifiers=True)
