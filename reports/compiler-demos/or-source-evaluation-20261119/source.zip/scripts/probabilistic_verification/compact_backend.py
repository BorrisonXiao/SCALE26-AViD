"""Exact three-state rules with unknown derived from disjoint support/refutation.

Every observation is categorical. At each expression exactly one of supported,
refuted and unknown holds, so unknown equals neither supported nor refuted.
This changes the Boolean encoding, not probabilities or observation sharing.
"""
import hashlib,itertools
from .representation import STATES
from .logic import combine_states

def compact_prolog_program(programs,*,learned=True):
 observations={}
 for p in programs:
  for oid,o in p.observations.items():
   if oid in observations and observations[oid]!=o:raise ValueError('Conflicting shared observations.')
   observations[oid]=o
 lines=['% Exact categorical evidence; internal unknown = neither supported nor refuted.']
 if learned and any(o.trainable and o.available for o in observations.values()):lines.append('nn(relation_net,[tensor(features(O))],Z,[supported,refuted,unknown]) :: learned_status(O,Z).')
 for oid,o in sorted(observations.items()):
  lines.append(f'status({oid},Z) :- learned_status({oid},Z).'if learned and o.trainable and o.available else'; '.join(f'{p:.17g}::status({oid},{s})'for p,s in zip(o.distribution,STATES))+'.')
 nodes={};names={}
 def rule(name,state,body):lines.append(f'node({name},{state}) :- '+', '.join(f'node({c},{s})'for c,s in body)+'.')
 def emit(e):
  if e in nodes:return nodes[e]
  n='n'+str(len(nodes));nodes[e]=n
  if e.op=='atom':
   for s in STATES:lines.append(f'node({n},{s}) :- status({e.atom_id},{s}).')
  elif e.op=='constant':lines.append(f'node({n},{e.state}).')
  else:
   cs=[emit(c)for c in e.children]
   if e.op=='not':
    rule(n,'supported',[(cs[0],'refuted')]);rule(n,'refuted',[(cs[0],'supported')])
   elif e.op in{'and','or'}:
    all_state='supported'if e.op=='and'else'refuted';any_state='refuted'if e.op=='and'else'supported'
    rule(n,all_state,[(c,all_state)for c in cs])
    for c in cs:rule(n,any_state,[(c,any_state)])
   elif e.op=='evidence':
    if len(cs)!=2:raise ValueError('Evidence composition requires two children.')
    for a,b in itertools.product(STATES,repeat=2):
     s=combine_states('evidence',[a,b])
     if s!='unknown':rule(n,s,[(cs[0],a),(cs[1],b)])
   else:raise ValueError('Expression must be grounded.')
   negation=r'\+'
   lines.append(f'node({n},unknown) :- {negation} node({n},supported), {negation} node({n},refuted).')
  return n
 for p in programs:
  if p.claim_id in names:raise ValueError('Repeated claim ID.')
  name='c_'+hashlib.sha256(p.claim_id.encode()).hexdigest()[:16];names[p.claim_id]=name;root=emit(p.expression)
  for s in STATES:lines +=[f'verdict({name},{s}) :- node({root},{s}).',f'query(verdict({name},{s})).']
 return '\n'.join(lines)+'\n',names
