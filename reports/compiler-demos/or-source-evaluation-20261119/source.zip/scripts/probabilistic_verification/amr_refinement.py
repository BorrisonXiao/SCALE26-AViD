"""One fixed AMR frontend with source preservation and shared operator rules."""
from dataclasses import replace
from .amr_composition import AMRCompiler
from .amr_scope import ScopePolicy
from .amr_source_alignment import prepare_source,add_source_conditions,source_checks
from .predicate_compilation import PredicateError

def compile_refined(record,raw,*,strict=True,prepared=None):
 changed,info,alignment=prepared or prepare_source(record,raw)
 claim=AMRCompiler(coordination=True,scope_policy=ScopePolicy(record),source_alignment=alignment).compile(record['claim_id'],record['text'],changed,record.get('tokens',[]))
 claim=add_source_conditions(claim,record,info,alignment)
 issues=source_checks(record,changed,info)
 metadata=dict(claim.metadata,source_checks=issues,source_checks_pass=not issues)
 claim=replace(claim,metadata=metadata)
 if strict and issues:raise PredicateError(issues[0]['code'],issues[0]['reason'])
 return claim
