"""Simple sentences plus an explicit AND/OR syntax tree; no generated predicates."""
import copy,json,re,jsonschema
from .claim_split import FORMULA
from .amr_source_alignment import quote_spans
from .split_composition import fail, nodes
SCHEMA=dict(type='object',properties=dict(action=dict(type='string',enum=['rewrite','keep','refuse']),sentences=dict(type='array',maxItems=8,items=dict(type='string')),formula=dict(anyOf=[{'$ref':'#/$defs/formula'},dict(type='null')])),required=['action','sentences','formula'],additionalProperties=False,**{'$defs':dict(formula=FORMULA)})
SYSTEM='''Simplify the claim without changing its meaning. Return the fewest complete sentences, preferably one. Keep the original names, modifiers, counts, tense, uncertainty, negation, quotations and source (depiction/speech/written text). Keep qualifications with everything they qualify. Do not turn goals or possibilities into events that happened. Do not invent entities or event descriptions just to split a sentence. Each sentence must be self-contained and grammatical. For parallel alternatives, repeat shared participants and context, keeping branch-specific modifiers in their own sentence.
Return JSON: action=rewrite, sentences, and formula. A formula leaf is a 1-based sentence number; internal nodes are {"op":"and" or "or","children":[...]}. Use every sentence once. For one sentence, formula=1. Do not add OR or copy a count to another alternative unless the original says so. If simplification is impossible, action=refuse, sentences=[], formula=null. The supplied parses may be wrong; the original claim controls the meaning.'''
REVISED_SYSTEM='''The original claim FAILED compilation. Rewrite its sentence structure to avoid the supplied error. Do not return the rejected wording unchanged. Usually use 2–4 short clauses, keeping names, modifiers, counts, tense, negation, uncertainty, exact quotations and source. Keep a qualification with the full statement it qualifies. Do not assert a goal, possibility or quoted claim as an actual event.
Return JSON: action=rewrite, sentences, formula. A formula leaf is a 1-based sentence number; internal nodes use op=and/or and children. Use every sentence exactly once. For parallel alternatives, repeat shared participants and context, keeping branch-specific modifiers and counts in their own sentence. For one genuinely simpler sentence, formula=1. Refuse rather than invent missing information.
Examples:
"Cars were parked in Boston on Monday." -> sentences=["Cars were parked.","The parking was in Boston.","The parking occurred on Monday."], formula={"op":"and","children":[1,2,3]}.
"Six knocks were heard or an alarm sounded." -> sentences=["Six knocks were heard.","An alarm sounded."], formula={"op":"or","children":[1,2]}.
"Flooding likely in the town." -> sentences=["Flooding is likely in the town."], formula=1.
The original controls the meaning; the supplied parses may be wrong. After feedback, change the rejected structure instead of repeating it.'''

def validate(data):
    jsonschema.validate(data,SCHEMA)
    if data['action']!='rewrite':
        if data['sentences']or data['formula']is not None:raise ValueError('Keep/refuse must not add sentences or formula.')
        return
    if not data['sentences']or data['formula']is None:raise ValueError('Rewrite needs sentences and a formula.')
    if len(set(data['sentences']))!=len(data['sentences']):raise ValueError('Duplicate sentences are not a simplification.')
    leaves=[]
    def visit(n):
        if isinstance(n,int):leaves.append(n)
        else:
            for c in n['children']:visit(c)
    visit(data['formula'])
    if sorted(leaves)!=list(range(1,len(data['sentences'])+1)):raise ValueError('Formula must use each sentence exactly once.')

def proposal(data):
    validate(data)
    return dict(action='split'if len(data['sentences'])>1 else'rewrite'if data['sentences']else data['action'],clauses=[dict(id='c'+str(i+1),text=t)for i,t in enumerate(data['sentences'])],formula=data['formula'])

def request(record,amr=None):
    return dict(claim=record['text'],syntax=[{k:t.get(k)for k in ['id','text','lemma','upos','head','deprel','feats']}for t in record['tokens']],srl=record.get('srl',{}).get('frames',[]),amr=amr)


_NOMINAL = {'NOUN', 'PROPN', 'PRON'}
_CONTENT = _NOMINAL | {'VERB', 'ADJ', 'ADV', 'NUM', 'SYM', 'AUX', 'ADP', 'SCONJ'}
_NUMERIC_BOUND = re.compile(r'\d[\d,.]*\s*(?:%\s*)?(?P<or>or)\s+(?:less|fewer|more)\b', re.I)
_SOURCE_VERBS = {'say', 'tell', 'report', 'claim', 'state', 'ask', 'read', 'show', 'depict', 'write',
                 'describe', 'note', 'mention', 'believe', 'suppose', 'hear', 'see'}


def _subtree(tokens, root, *, skip=None):
    found = {root}
    while True:
        extra = {t['id'] for t in tokens if t['head'] in found and t['id'] != skip} - found
        if not extra:
            return found
        found.update(extra)


def _content(tokens):
    return {t['lemma'].casefold() for t in tokens
            if t['upos'] in _CONTENT or (t['upos']=='DET' and t['lemma'].casefold() not in {'a','an','the'})}


def parallel_with_shared(formula):
    """Return two clause indices under OR and one shared conjunct."""
    if not isinstance(formula, dict) or formula.get('op') != 'and' or len(formula.get('children', [])) != 2:
        return None
    leaves = formula['children']
    joint = next((i for i in leaves if isinstance(i, int)), None)
    choice = next((i for i in leaves if isinstance(i, dict) and i.get('op') == 'or'), None)
    if joint is None or choice is None:
        return None
    branches = choice.get('children', [])
    if len(branches) != 2 or any(not isinstance(i, int) for i in branches) or set(branches) | {joint} != {1, 2, 3}:
        return None
    return branches, joint


def check_shared_relative(tokens, left, right, clauses, specification):
    """Validate two coordinated complements plus a relative clause of a shared argument."""
    by_id = {t['id']: t for t in tokens}
    governor = by_id.get(left.get('head'), {})
    if (left.get('deprel') != 'xcomp' or right.get('deprel') != 'conj'
            or left.get('upos') != 'VERB' or right.get('upos') != 'VERB'
            or governor.get('deprel') != 'root' or governor.get('upos') != 'VERB'
            or governor['lemma'].casefold() in _SOURCE_VERBS
            or any(t['lemma'].casefold() in {'not','never','may','might','could','would','whether','only'}
                   or t['deprel'] in {'ccomp','parataxis','advcl'} for t in tokens)):
        fail('rewrite_shared_condition_scope', 'The shared clause must have an explicit source attachment to a shared argument.')
    branches, shared = specification
    shared_tokens = clauses[shared-1]['record']['tokens']
    roots = [t for t in shared_tokens if t['deprel'] == 'root']
    if len(roots) != 1:
        fail('rewrite_shared_condition_scope', 'The shared clause needs one source-aligned predicate.')
    originals = [t for t in tokens if t['lemma'].casefold() == roots[0]['lemma'].casefold()
                 and t['deprel'] in {'acl','acl:relcl'}]
    if len(originals) != 1:
        fail('rewrite_shared_condition_scope', 'The shared predicate is not an explicit relative clause in the source.')
    relative = originals[0]
    owner = by_id[relative['head']]
    subject = [t for t in shared_tokens if t['head'] == roots[0]['id'] and t['deprel'] == 'nsubj']
    if (owner['upos'] not in _NOMINAL or owner['head'] != governor['id']
            or len(subject) != 1 or subject[0]['lemma'].casefold() != owner['lemma'].casefold()):
        fail('rewrite_shared_condition_scope', 'The relative clause must reuse the source argument of the governing event.')
    relative_ids = _subtree(tokens, relative['id'])
    relative_words = _content(t for t in tokens if t['id'] in relative_ids and t['lemma'] not in {'that','which','who'})
    if _content(shared_tokens) != relative_words | {owner['lemma'].casefold()}:
        fail('rewrite_shared_condition_alignment', 'The shared sentence changes the relative clause or its participant.')
    # Other content stays with the governing event and its two infinitives.
    common = _content(t for t in tokens if t['id'] not in relative_ids | {left['id'], right['id']})
    left_right = {left['lemma'].casefold(), right['lemma'].casefold()}
    found = set()
    for index in branches:
        part = clauses[index-1]['record']['tokens']
        heads = [t for t in part if t['deprel'] == 'root' and t['lemma'] == governor['lemma']]
        if len(heads) != 1:
            fail('rewrite_shared_condition_alignment', 'Both sentences must keep the governing predicate.')
        children = [t for t in part if t['head'] == heads[0]['id']]
        complements = {t['lemma'].casefold() for t in children if t['deprel'] == 'xcomp'}
        shared_owners = [t for t in children if t['deprel'] == owner['deprel'] and t['lemma'] == owner['lemma']]
        if (len(complements) != 1 or not complements <= left_right or len(shared_owners) != 1
                or _content(part) != common | complements):
            fail('rewrite_shared_condition_alignment', 'Each sentence must retain its alternative and the same shared argument.')
        found.update(complements)
    if found != left_right:
        fail('rewrite_shared_condition_alignment', 'The rewrite must keep both source alternatives.')


def checked_rewrite_formula(original, clauses, formula=None):
    """Verify source alignment for simple parallel rewrites using an explicit OR.

    More complex alternatives need a separate scope-preserving conversion. A
    token-span check cannot establish general paraphrase equivalence.
    """
    text = original['text']
    tokens = original['tokens']
    quoted = quote_spans(text)
    numeric_bounds = {m.start('or') for m in _NUMERIC_BOUND.finditer(text)}
    positions = {m.start() for m in re.finditer(r'(?<![\w-])or(?![\w-])', text, re.I)
                 if m.start() not in numeric_bounds
                 and not any(q['start'] <= m.start() < q['end'] for q in quoted)}
    markers = [t for t in tokens if t.get('start_char') in positions and t['lemma'].casefold() == 'or']
    has_or = any(n.get('op') == 'or' for n in nodes(formula))
    if not positions:
        if has_or:
            fail('rewrite_or_source', 'A rewrite OR requires a source alternative outside quoted text.')
        return formula
    if not has_or:
        fail('rewrite_or_required', 'Keep explicit source alternatives in an OR formula.')
    common = parallel_with_shared(formula)
    if common and len(clauses) == 3 and len(positions) == len(markers) == 1 and markers[0]['deprel'] == 'cc':
        by_id = {t['id']: t for t in tokens}
        right = by_id.get(markers[0]['head'], {})
        check_shared_relative(tokens, by_id.get(right.get('head'), {}), right, clauses, common)
        return formula
    if (len(positions) != 1 or len(markers) != 1 or markers[0]['deprel'] != 'cc'
            or len(clauses) != 2 or formula.get('op') != 'or'
            or formula.get('children') not in ([1, 2], [2, 1])):
        fail('rewrite_or_scope', 'This rewrite needs two parallel branches with one source coordinator.')
    by_id = {t['id']: t for t in tokens}
    right = by_id.get(markers[0]['head'], {})
    left = by_id.get(right.get('head'), {})
    governor = by_id.get(left.get('head'), {})
    nominal = (left.get('upos') in _NOMINAL and right.get('upos') in _NOMINAL
               and left.get('deprel') in {'obl', 'obj', 'iobj', 'nsubj'}
               and governor.get('deprel') == 'root' and governor.get('upos') == 'VERB')
    clausal = (left.get('deprel') == 'root' and left.get('upos') == right.get('upos') == 'VERB')
    if (right.get('deprel') != 'conj' or not (nominal or clausal)
            or any(t['lemma'].casefold() in _SOURCE_VERBS | {'not', 'never', 'whether', 'must', 'may',
                                                             'might', 'could', 'would', 'likely', 'only'}
                   or t['deprel'] in {'advcl', 'ccomp', 'xcomp', 'parataxis'}
                   for t in tokens)):
        fail('rewrite_or_scope', 'Keep embedded, qualified or otherwise ambiguous alternatives in their source scope.')

    right_ids = _subtree(tokens, right['id'])
    left_ids = _subtree(tokens, left['id'], skip=right['id'])
    shared_ids = set(by_id) - left_ids - right_ids
    if clausal:
        # The source subject and auxiliary of a coordinated predicate apply to
        # the second clause when it omits those arguments.
        right_roles = {t['deprel'].split(':')[0] for t in tokens if t['head'] == right['id']}
        for t in tokens:
            role = t['deprel'].split(':')[0]
            if t['head'] == left['id'] and role in {'nsubj', 'aux'} - right_roles:
                shared_ids.update(_subtree(tokens, t['id']))
    elif not any(t['head'] == right['id'] and t['deprel'] == 'case' for t in tokens):
        shared_ids.update(t['id'] for t in tokens if t['head'] == left['id'] and t['deprel'] == 'case')
    left_ids -= shared_ids
    left_words, right_words, shared_words = (_content(by_id[i] for i in ids)
                                             for ids in (left_ids, right_ids, shared_ids))

    source_root = governor if nominal else left
    shared_arguments = {(t['deprel'], t['lemma'].casefold()) for t in tokens
                        if t['id'] in shared_ids and t['head'] == source_root['id'] and t['upos'] in _NOMINAL}

    def matches(clause, head, expected, other):
        part = clause['record']['tokens']
        case_content = _content(part)
        if not ((expected | shared_words) <= case_content <= (left_words | right_words | shared_words)):
            return False
        if case_content & (other - expected - shared_words):
            return False
        roots = [t for t in part if t['deprel'] == 'root']
        if len(roots) != 1:
            return False
        root = roots[0]
        attached_roles = {(t['deprel'], t['lemma'].casefold()) for t in part if t['head'] == root['id']}
        if not shared_arguments <= attached_roles:
            return False
        if clausal:
            return root['lemma'].casefold() == head['lemma'].casefold()
        arguments = [t for t in part if t['head'] == root['id'] and t['deprel'] == left['deprel']
                     and t['lemma'].casefold() == head['lemma'].casefold()]
        if root['lemma'].casefold() != governor['lemma'].casefold() or len(arguments) != 1:
            return False
        attached = _subtree(part, arguments[0]['id'])
        return expected <= _content(t for t in part if t['id'] in attached)

    if not any(matches(a, left, left_words, right_words) and matches(b, right, right_words, left_words)
               for a, b in (clauses, list(reversed(clauses)))):
        fail('rewrite_or_alignment', 'Each alternative must retain its own source description and the shared claim.')
    return formula
