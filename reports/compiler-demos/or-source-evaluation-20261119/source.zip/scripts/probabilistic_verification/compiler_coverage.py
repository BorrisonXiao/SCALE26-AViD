"""Opt-in repairs for the coverage experiment on previously compiled inputs."""
from dataclasses import replace

from .amr_composition import ASSERTED, COMPLEMENTS, EVENT, MEDIA
from .compiler_fallback import restore
from .fallback_amr import FallbackScopePolicy
from .logical_form import LogicalFormError, bind_variables
from .logical_form_v2 import ScopedClaim
from .representation import Atom, Expression, Variable


class SourceScopePolicy(FallbackScopePolicy):
    """Keep source-licensed implications and media descriptions embedded."""

    def kind(self, predicate, role, node, concepts, edges, matches):
        known = super().kind(predicate, role, node, concepts, edges, matches)
        if known:
            return known
        targets = [target for edge, target in edges[node] if edge == role and target in concepts]
        if len(targets) != 1:
            return None
        heads = matches(node)
        target_heads = matches(targets[0])
        if role == 'ARG1' and predicate.startswith('imply-') and any(t['lemma'] == 'imply' for t in heads):
            # "It is implied that X" supplies content, but no antecedent for an IF rule.
            if any(t.get('deprel') in {'ccomp', 'csubj', 'csubj:pass', 'xcomp'} for t in target_heads):
                return 'implication'
        if role == 'ARG1' and predicate in {'show-01', 'depict-01', 'display-01'}:
            if any(t.get('lemma') in {'show', 'depict', 'display'} for t in heads):
                actor = next((target for edge, target in edges[node] if edge == 'ARG0'), None)
                if actor is None and any(t.get('head') == 0 for t in heads):
                    # The AViD claim convention allows a media description with omitted subject.
                    return 'depiction'
        return None


class UnresolvedComplementPolicy(SourceScopePolicy):
    """Preserve AMR complement edges without deciding their factuality."""

    def kind(self, predicate, role, node, concepts, edges, matches):
        known = super().kind(predicate, role, node, concepts, edges, matches)
        if known or role in COMPLEMENTS.get(predicate, {}) or predicate in ASSERTED:
            return known
        targets = [value for edge, value in edges[node] if edge == role and value in concepts]
        if not (len(targets) == 1 and len(role) == 4 and role.startswith('ARG') and role[-1].isdigit()):
            return None
        target = targets[0]
        if ('polarity', '-') in edges[target]:
            return 'unresolved negated argument'
        if not EVENT.search(concepts[target]):
            return None
        if self.predicate_value(predicate, role, target, concepts, edges, matches):
            return None
        anchors = matches(target)
        if anchors and all(t.get('upos') in {'NOUN', 'PROPN'} for t in anchors):
            return None
        if predicate in {'show-01', 'depict-01', 'display-01'} and role == 'ARG1':
            if any(edge == 'ARG0' and concepts.get(value) in MEDIA for edge, value in edges[node]):
                return None  # Preserve the converter's ordinary media route.
        return 'unresolved complement'


def dependency_conditions(record):
    """Compile source-located predicates and dependency relationships for review.

    The dependencies express syntax only. In particular, nsubj is not an agent
    label, and ccomp is not an independent assertion. Use a separate context
    for this diagnostic representation and keep it out of evidence verification.
    """
    text = record['text']
    tokens = record.get('tokens') or []
    by_id = {token['id']: token for token in tokens}
    children = {token_id: [] for token_id in by_id}
    for token in tokens:
        if token['head'] in children:
            children[token['head']].append(token)
    roots = [token for token in tokens if token['head'] == 0 and token['upos'] != 'PUNCT']
    if not roots:
        raise LogicalFormError('missing_dependency_root', 'No source dependency root is available.')

    scope = f"syntax::{record['claim_id']}"
    variables = {}
    atoms = []
    quoted = []
    from .amr_source_alignment import quote_spans
    for quote in quote_spans(text):
        first = quote['start']
        last = quote['end']
        members = [t for t in tokens if first <= t['start_char'] and t['end_char'] <= last]
        if members and len(members) < sum(t['upos'] != 'PUNCT' for t in tokens):
            quoted.append((quote, members))

    within_quote = {t['id'] for _, group in quoted for t in group}
    roots = [token for token in roots if token['id'] not in within_quote]
    relation_labels = {'nsubj', 'csubj', 'obj', 'iobj', 'obl', 'nmod', 'amod', 'compound', 'appos',
                       'acl', 'xcomp', 'ccomp', 'advcl', 'conj', 'parataxis', 'advmod', 'nummod',
                       'flat', 'aux', 'cop', 'cc', 'mark', 'case', 'neg', 'det', 'discourse'}
    ignored = {'PUNCT', 'SYM'}
    core_edges = {'nsubj', 'csubj', 'obj', 'iobj', 'obl', 'nmod', 'amod', 'compound', 'appos',
                  'acl', 'xcomp', 'ccomp', 'advcl', 'conj', 'parataxis', 'nummod', 'flat'}
    bindings = 0

    def term(token):
        token_id = token['id']
        if token_id not in variables:
            predicate = token['upos'] in {'VERB', 'AUX'} or any(
                child['deprel'] == 'cop' for child in children[token_id]
            )
            variables[token_id] = Variable(
                f'T{token_id}', 'event' if predicate else 'entity', token['text'], (token_id,)
            )
        return variables[token_id].name

    def add(predicate, arguments, token_ids):
        atoms.append(Atom(
            f'a{len(atoms) + 1}', predicate, (*arguments, 'scope', scope, 'route', 'unspecified'),
            'syntax', (), predicate, tuple(token_ids), False,
        ))

    for token in tokens:
        parent = by_id.get(token['head'])
        relation = token['deprel']
        family = relation.split(':', 1)[0]
        if (not parent or token['upos'] in ignored or parent['upos'] in ignored
                or token['id'] in within_quote or parent['id'] in within_quote
                or family not in relation_labels):
            continue
        # Keep grammatical function words as a value on their own head.
        if family in {'aux', 'cop', 'cc', 'mark', 'case', 'neg', 'det', 'discourse'}:
            add('source_modifier', (term(parent), relation, token['text']), (parent['id'], token['id']))
        else:
            add('dependency', (term(parent), relation, term(token)), (parent['id'], token['id']))
            bindings += family in core_edges
    for quote, members in quoted:
        ids = {t['id'] for t in members}
        carriers = {t['head'] for t in members if t['head'] not in ids and t['head'] in by_id}
        if len(carriers) == 1:
            host = by_id[carriers.pop()]
            add('source_quote', (term(host), quote['text']), (host['id'], *sorted(ids)))
            bindings += 1
    if not roots or not bindings or not variables:
        raise LogicalFormError('missing_dependency_binding', 'No source predicate or nominal root with a linked condition.')
    for root in roots:
        add('source_root', (term(root),), (root['id'],))
    for token_id, variable in variables.items():
        token = by_id[token_id]
        add('source_term', (variable.name, token['lemma'], token['upos']), (token_id,))
    variables = tuple(variables.values())
    expression = Expression.combine('and', [Expression.atom(atom.id) for atom in atoms])
    return ScopedClaim(
        record['claim_id'], text, tuple(tokens), variables, tuple(atoms),
        bind_variables(expression, atoms, variables), (),
        ('Grammatical dependencies still need semantic roles, scope and source interpretation.',),
        metadata={
            'kind': 'dependency_analysis',
            'scopes': {scope: dict(parent='world', kind='syntax', route='unspecified')},
            'allowed_routes': {atom.id: [] for atom in atoms},
            'linked_conditions': bindings,
        },
    )


def review_only(compilation, reason):
    """Mark provisional output and disable all routes in its logical form."""
    claim = restore(compilation)
    metadata = dict(claim.metadata, coverage_review_required=True, coverage_review_reason=reason,
                    allowed_routes={atom.id: [] for atom in claim.atoms})
    atoms = tuple(replace(atom, trainable=False) for atom in claim.atoms)
    return replace(claim, atoms=atoms, metadata=metadata)


def written_quote_conditions(record):
    """Recognize a single exact inscription with a source-local carrier."""
    import re

    from .amr_source_alignment import quote_spans

    text = record['text']
    quotes = quote_spans(text)
    if len(quotes) != 1:
        raise LogicalFormError('written_quote_scope', 'Expected one source-bound written quotation.')
    quote = quotes[0]
    # Use the text outside the quote. Dependency attachment can cross a quote
    # boundary when the embedded quote is long or spans several sentences.
    prefix = text[:quote['start']].rstrip(' "“\'')
    suffix = text[quote['end']:].strip(' "”\'.')
    match = re.fullmatch(
        r'(?:(?:a|the|some) )?(?P<carrier>(?:video |on[- ]screen )?'
        r'(?:overlay|caption|sign|text|banner|poster|placard))'
        r'(?P<cropped>, cut off,)?\s+(?:reads?|reading|says?|saying|shows?|showing)\s*:?\s*',
        prefix, re.IGNORECASE,
    )
    tweet = re.fullmatch(
        r'(?i:shows?) (?:an? |the )?image of (?:an? |the )?(?P<carrier>tweet) from '
        r"(?P<author>[A-Z][\w.'-]*(?: [A-Z][\w.'-]*)*)\s*:\s*", prefix,
    )
    match = match or tweet
    if not match or (suffix and suffix.casefold() != 'is visible'):
        raise LogicalFormError('written_quote_scope', 'Unresolved outer claim around the written quotation.')
    tokens = tuple(record.get('tokens', []))
    carrier_tokens = tuple(t['id'] for t in tokens
                           if match.start('carrier') <= t['start_char'] < match.end('carrier'))
    quote_tokens = tuple(t['id'] for t in tokens if quote['start'] <= t['start_char'] < quote['end'])
    carrier = Variable('X1', 'entity', match['carrier'], carrier_tokens)
    variables = [carrier]
    atoms = []
    routes = {}

    def add(predicate, args, route, kind, token_ids=()):
        identifier = f'a{len(atoms) + 1}'
        atoms.append(Atom(identifier, predicate, (*args, 'scope', 'world', 'route', route),
                          kind, (), predicate, token_ids, False))
        routes[identifier] = [route]

    add('referent', (carrier.name, carrier.description), 'visual_depiction', 'entity', carrier_tokens)
    if tweet:
        author = Variable('X2', 'entity', tweet['author'], tuple(
            t['id'] for t in tokens if tweet.start('author') <= t['start_char'] < tweet.end('author')
        ))
        variables.append(author)
        add('name', (author.name, author.description), 'ocr_assertion', 'property', author.token_ids)
        add('entity_relation', (carrier.name, 'author', author.name), 'ocr_assertion', 'relation')
        add('property', (carrier.name, 'depicted in an image', 'true'), 'visual_depiction', 'property')
    if match.groupdict().get('cropped'):
        add('property', (carrier.name, 'cut off', 'true'), 'visual_depiction', 'property')
    if suffix:
        add('property', (carrier.name, 'visible', 'true'), 'visual_depiction', 'property')
    add('written_text', (carrier.name, quote['text']), 'ocr_assertion', 'property', quote_tokens)
    expression = Expression.exists([v.name for v in variables], Expression.combine(
        'and', [Expression.atom(atom.id) for atom in atoms],
    ))
    return ScopedClaim(
        record['claim_id'], text, tokens, tuple(variables), tuple(atoms), expression, (),
        metadata={'kind': 'claim', 'scopes': {}, 'allowed_routes': routes,
                  'quotation': {'carrier_span': match.span('carrier'), 'content': quote}},
    )


def normalize_annotated_coordination(raw):
    """Keep conditions on an entire coordination outside its AND/OR children."""
    import re

    import penman
    from penman.models.amr import model

    graph = penman.decode(raw, model=model)
    concepts = {source: concept for source, _, concept in graph.instances()}
    triples = list(graph.triples)
    added = []
    changes = []
    index = 0
    for node, concept in concepts.items():
        if concept not in {'and', 'or', 'multi-sentence'}:
            continue
        member_pattern = r':snt\d+' if concept == 'multi-sentence' else r':op\d+'
        members = [(s, role, target) for s, role, target in triples
                   if s == node and re.fullmatch(member_pattern, role)]
        annotations = [(s, role, target) for s, role, target in triples
                       if s == node and role not in {':instance', ':wiki'}
                       and not re.fullmatch(member_pattern, role)]
        if len(members) < 2 or not annotations:
            continue
        # For a finite conjunction of named participants, "all" restricts the
        # explicit group, not an unbounded universe. Keep the modifier attached.
        all_only = (concept == 'and' and all(
            role == ':mod' and concepts.get(target) == 'all' for _, role, target in annotations
        ))
        incoming = [(s, role) for s, role, target in triples if target == node and role != ':instance']
        participant = any(role.startswith(':ARG') for _, role in incoming)
        nominal_group = concept == 'and' and all(
            target in concepts and not EVENT.search(concepts[target]) for _, _, target in members
        )
        if participant and not (all_only or nominal_group):
            clause_members = all(target in concepts and EVENT.search(concepts[target])
                                 for _, _, target in members)
            if not clause_members and not any(role == ':domain' for _, role, _ in annotations):
                continue
        if any(role in {':mode', ':quant'} or role == ':polarity' and value != '-'
               for _, role, value in annotations):
            continue
        if all_only or participant and nominal_group:
            # Expose the original member edges without rewriting an OR or
            # projecting a single member to the whole NP.
            moved = [*members, *annotations, (node, ':instance', concept)]
            replacements = [(node, ':instance', 'group')]
            replacements += [(node, ':member', target) for _, _, target in members]
            replacements += annotations
        else:
            index += 1
            choice = f'coord{index}'
            while choice in concepts:
                index += 1
                choice = f'coord{index}'
            moved = [*members, (node, ':instance', concept)]
            replacements = [(node, ':instance', 'coordination'), (node, ':content', choice),
                            (choice, ':instance', concept)]
            replacements += [(choice, role, target) for _, role, target in members]
        triples = [triple for triple in triples if triple not in moved]
        triples.extend(replacements)
        changes.append({'node': node, 'original_operator': concept,
                        'annotations': annotations, 'replacements': replacements})
    if not changes:
        return raw, []
    return penman.encode(penman.Graph(triples, top=graph.top), model=model), changes


class CoordinationScopePolicy(UnresolvedComplementPolicy):
    def kind(self, predicate, role, node, concepts, edges, matches):
        if role == 'content' and predicate in {'interrogative', 'imperative', 'truth-value'}:
            return 'directive' if predicate == 'imperative' else 'question'
        if (predicate, role) == ('coordination', 'content'):
            return 'coordinated content'
        return super().kind(predicate, role, node, concepts, edges, matches)


def inverse_edges(raw):
    """Identify AMR argument edges printed in inverse form in the source graph."""
    import penman
    from penman.models.amr import model

    inverse = set()

    def visit(term):
        node, branches = term
        for role, target in branches:
            if isinstance(target, tuple):
                visit(target)
                target = target[0]
            if role == '/' or not model.is_role_inverted(role):
                continue
            source, canonical_role, value = model.invert((node, role, target))
            inverse.add((source, canonical_role.lstrip(':'), value))

    visit(penman.parse(raw).node)
    return inverse


class ReentrantScopePolicy(CoordinationScopePolicy):
    def __init__(self, record, inverse):
        super().__init__(record)
        self.inverse = inverse

    def kind(self, predicate, role, node, concepts, edges, matches):
        targets = [target for edge, target in edges[node] if edge == role]
        if len(targets) == 1 and (node, role, targets[0]) in self.inverse:
            if ('polarity', '-') in edges[targets[0]]:
                return 'unresolved negated argument'
            # The earlier traversal will visit the inverse predicate as a
            # relative condition of the already introduced referent.
            return SourceScopePolicy.kind(self, predicate, role, node, concepts, edges, matches)
        return super().kind(predicate, role, node, concepts, edges, matches)


def compile_reentrant_amr(record, raw, *, strict=False, prepared=None):
    """Keep AMR identity across nested contexts for explicit graph references."""
    import penman

    from .amr_composition import AMRCompiler
    from .amr_semantic_checks import semantic_checks
    from .amr_source_alignment import add_source_conditions, source_checks
    from .amr_types import PredicateTypes
    from .fallback_amr import prepare_fallback
    from .predicate_compilation import PredicateError

    changed, info, alignment, licenses = prepared or prepare_fallback(record, raw)
    inverse = inverse_edges(changed)
    graph = penman.decode(changed)
    incoming = {}
    for source, role, target in graph.edges():
        incoming.setdefault(target, set()).add((source, role))
    reentrant = {target for target, edges in incoming.items() if len(edges) > 1}
    reentrant |= {target for _, _, target in inverse}

    class ReentrantPredicateTypes(PredicateTypes):
        def is_nominal(self, node):
            # The existing converter uses this method to decide whether a node
            # may reference an already-bound event in an ancestor context.
            return node in reentrant or super().is_nominal(node)

        def allows_argument(self, parent, role, target):
            return (parent, role, target) in inverse or super().allows_argument(parent, role, target)

    policy = ReentrantScopePolicy(record, inverse)
    claim = AMRCompiler(
        coordination=True, scope_policy=policy, source_alignment=alignment,
        predicate_types=ReentrantPredicateTypes(alignment.concepts, alignment),
    ).compile(record['claim_id'], record['text'], changed, record.get('tokens', []))
    claim = add_source_conditions(claim, record, info, alignment)
    source_alerts = source_checks(record, changed, info, normalization=licenses)
    semantic_alerts = semantic_checks(record, changed, alignment)
    if strict and (alerts := source_alerts + semantic_alerts):
        raise PredicateError(alerts[0]['code'], alerts[0]['reason'])
    return replace(claim, metadata=dict(
        claim.metadata, source_checks=source_alerts, source_checks_pass=not source_alerts,
        semantic_checks=semantic_alerts, semantic_checks_pass=not semantic_alerts,
        normalization=licenses, inverse_arguments=sorted(inverse),
        reentrant_nodes=sorted(reentrant),
    ))


def normalize_sentence_mode(raw):
    """Keep AMR mode and question variables in explicit nonassertive clauses."""
    import penman
    from penman.models.amr import model

    graph = penman.decode(raw, model=model)
    nodes = {source: concept for source, _, concept in graph.instances()}
    modes = [(s, target) for s, role, target in graph.triples
             if role == ':mode' and target in {'interrogative', 'imperative'}]
    unknowns = {n for n, p in nodes.items() if p == 'amr-unknown'}
    polar_questions = [(s, target) for s, role, target in graph.triples
                       if role == ':polarity' and nodes.get(target) in {'truth-value', 'amr-unknown'}]
    if not modes and not unknowns and not polar_questions:
        return raw, []
    mode_map = dict(modes)
    wrappers = dict(polar_questions)
    answer_nodes = set(wrappers.values())
    for i, node in enumerate(mode_map, 1):
        if node in wrappers:
            continue
        wrapper = f'mode{i}'
        while wrapper in nodes or wrapper in wrappers.values():
            wrapper += 'x'
        wrappers[node] = wrapper
    triples = []
    for s, role, target in graph.triples:
        if (role == ':mode' and (s, target) in modes
                or role == ':polarity' and (s, target) in polar_questions):
            continue
        if role == ':instance':
            concept = 'truth-value' if s in answer_nodes else 'unknown-answer' if s in unknowns else target
            triples.append((s, role, concept))
        else:
            # Attach the incoming proposition to the speech act and keep the
            # original clause and its internal roles underneath that act.
            triples.append((s, role, wrappers.get(target, target)))
    for node, wrapper in wrappers.items():
        if wrapper not in answer_nodes:
            triples.append((wrapper, ':instance', mode_map[node]))
        triples.append((wrapper, ':content', node))
    normalized = penman.encode(penman.Graph(triples, top=wrappers.get(graph.top, graph.top)), model=model)
    return normalized, [dict(modes=modes, answer_variables=sorted(unknowns), polar_questions=polar_questions)]


def request_scope_warning(record, compilation):
    """Audit explicit call-for requests that lack a request context."""
    import re

    # Keep this diagnostic limited to unambiguous request nouns.
    if not re.search(
        r'\bcall(?:s|ed|ing)?\s+for\s+(?:(?:a|an|the)\s+)?'
        r'(?:boycott|resignation|investigation|ban|ceasefire)\b', record['text'], re.I,
    ):
        return None
    scopes = compilation.get('metadata', {}).get('scopes', {})
    if any(scope['kind'] in {'request', 'directive'} for scope in scopes.values()):
        return None
    return {'code': 'request_scope', 'reason': 'A call for action lacks an explicit request context.'}


def verify_coverage(row, predict, *, baseline_output=None):
    """A provisional parse cannot enter the evidence verifier."""
    from .compiler_fallback import verify

    output = row.get('output')
    if row['category'] == 'strict_baseline':
        if not baseline_output or baseline_output.get('program_sha256') != row['program_sha256']:
            raise ValueError('The strict baseline output must match the saved program hash.')
        output = baseline_output
    if not output or output.get('status') == 'review_required':
        return dict(claim_id=row['claim_id'], verdict='abstain',
                    reason='parse_review_required' if output else 'parsing_failure', distribution=None)
    return verify(dict(claim_id=row['claim_id'], parsing_status='compiled', output=output), predict)


def repair_srl_implication(record, previous):
    """Label an existing, dependency-linked imply-that complement."""
    import re

    from .fallback_semantics import source_triggers

    if not previous.get('compilation') or previous.get('code') != 'conditional_scope':
        return None
    triggers = source_triggers(record)['conditional_tokens']
    if not triggers or any(t['lemma'] != 'imply' for t in triggers):
        return None
    if not re.search(r'\bimpli(?:es|ed)\s+that\b|\bimply\s+that\b', record['text'], re.I):
        return None
    if previous.get('coverage', {}).get('complete') is not True or previous.get('structural_alerts'):
        return None
    if {issue['code'] for issue in previous.get('shared_checks', [])} != {'conditional_scope'}:
        return None
    claim = restore(previous['compilation'])
    scopes = claim.metadata['scopes']
    events = claim.metadata['events']
    qualified = {
        scope for scope, data in scopes.items()
        if data.get('kind') == 'complement'
        and events.get(data.get('owner'), {}).get('predicate') == 'imply'
    }
    if len(qualified) != len(triggers):
        return None
    atoms = tuple(
        replace(atom, arguments=(*atom.arguments[:2], 'implication', *atom.arguments[3:]))
        if atom.predicate == 'proposition' and atom.arguments[3] in qualified else atom
        for atom in claim.atoms
    )
    scopes = {scope: dict(data, kind='implication') if scope in qualified else data
              for scope, data in scopes.items()}
    import copy

    metadata = copy.deepcopy(claim.metadata)
    metadata['scopes'] = scopes
    event_roles = {(events[scopes[scope]['owner']]['id'], scopes[scope]['role'])
                   for scope in qualified}

    def retag(node):
        for value in node.values():
            if isinstance(value, dict):
                retag(value)
            elif isinstance(value, list):
                for child in value:
                    if isinstance(child, dict):
                        retag(child)
        if node.get('op') == 'event':
            for proposition in node.get('propositions', []):
                if proposition['kind'] == 'complement' and (node.get('id'), proposition['role']) in event_roles:
                    proposition['kind'] = 'implication'

    retag(metadata['logical_form']['formula'])
    for event in metadata['events'].values():
        retag(event)
    return replace(claim, atoms=atoms, metadata=metadata)
