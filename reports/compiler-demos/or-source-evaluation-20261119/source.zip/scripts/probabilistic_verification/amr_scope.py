"""Shared, explicit complement classes; frame roles follow PropBank definitions.

Classes are not a learned factivity model. Unknown frames still refuse. These
rules keep content in a declared context rather than assert every inner event.
"""
CLASSES={
 'assertion':{'note-01':'ARG1','confirm-01':'ARG1','mention-01':'ARG1','announce-01':'ARG1'},
 'description':{'describe-01':'ARG1'},
 'prediction':{'predict-01':'ARG1','forecast-01':'ARG1'},
 'directive':{'urge-01':'ARG2'},
 'accusation':{'accuse-01':'ARG2'},
 'reason':{'arrest-01':'ARG2'},
 'requirement':{'need-01':'ARG1'},
 'cancellation':{'cancel-01':'ARG1'},
 'attempt':{'attempt-01':'ARG1'},
 'failure':{'fail-01':'ARG2'},
 'completion':{'finish-01':'ARG1'},
 'cessation':{'stop-01':'ARG1'},
 'prevention':{'stop-03':'ARG2'},
 'result':{'succeed-01':'ARG1'},
 'topic':{'talk-01':'ARG1','speak-01':'ARG1'},
}
# Frame-91 reification arguments can be predicate values, not clauses.
RELATIONS={'have-degree-91','have-quant-91','have-org-role-91','have-rel-role-91','have-mod-91'}

class ScopePolicy:
 def __init__(self,record):
  self.record=record;self.entries={(p,r):k for k,ps in CLASSES.items()for p,r in ps.items()}
 def kind(self,p,r,n,concepts,edges,matches):
  # A noun "report about rain" introduces a topic; it does not assert rain.
  if p=='report-01'and r=='ARG1':
   heads=matches(n)
   targets=[t for role,t in edges[n]if role==r];terms=[]
   for t in targets:
    terms+=([u for role,u in edges[t]if role.startswith('op')]if concepts.get(t)in{'and','or'}else[t])
   topic_ids={u['id']for t in terms if t in concepts for u in matches(t)}
   if len(heads)==1 and heads[0].get('upos')=='NOUN'and any(t.get('lemma','').lower()in{'about','on'}and t.get('head')in topic_ids for t in self.record.get('tokens',[])):return 'topic'
  return self.entries.get((p,r))
 def predicate_value(self,p,r,t,concepts,edges,matches):
  incoming=sum(v==t for rs in edges.values()for _,v in rs)
  return p in RELATIONS and not edges[t] and incoming==1 and any(u.get('upos')in{'ADJ','ADV'}for u in matches(t))
