"""Check the content of one speaker-aligned transcript segment."""
import re

from .amr_source_alignment import quote_spans

ENTAILMENT_THRESHOLD = 0.55


def normalize(text):
    return ' '.join(re.findall(r"\w+(?:['’]\w+)*", text.casefold()))


def splits(text, word):
    quoted = quote_spans(text)
    for match in re.finditer(rf'(?<![\w-]){word}(?![\w-])', text, re.I):
        if any(q['start'] <= match.start() < q['end'] for q in quoted):
            continue
        left, right = text[:match.start()].strip(' ,.;'), text[match.end():].strip(' ,.;')
        if left and right:
            yield left, right


def judge(segment, case, score=None):
    """Compare the two alternatives within one observed utterance.

    The segment supplies the hypothesized speaker and time window. Candidate
    completeness is supplied by the caller and only counts for a full window.
    """
    if (case['speaker'] != segment['speaker']
            or case['end'] <= segment['start'] or case['start'] >= segment['end']):
        return 'unknown'
    complete = (case['complete'] and case['start'] <= segment['start']
                and case['end'] >= segment['end'])
    alternatives = list(splits(case['target'], 'or'))
    if len(alternatives) != 1:
        return 'unknown'
    first, second = alternatives[0]

    def equivalent(a, b):
        if normalize(a) == normalize(b):
            return True
        return score is not None and min(score(a, b), score(b, a)) >= ENTAILMENT_THRESHOLD

    def matches(left, right):
        direct = (equivalent(left, first), equivalent(right, second))
        reverse = (equivalent(left, second), equivalent(right, first))
        return all(direct) or all(reverse)

    evidence = case['text']
    observed = list(splits(evidence, 'or'))
    if len(observed) == 1 and matches(*observed[0]):
        return 'supported'
    if not complete or observed:
        return 'unknown'
    conjunction = any([matches(a, b) for a, b in splits(evidence, 'and')])
    single = (equivalent(evidence, first), equivalent(evidence, second))
    return 'refuted' if conjunction or any(single) else 'unknown'
