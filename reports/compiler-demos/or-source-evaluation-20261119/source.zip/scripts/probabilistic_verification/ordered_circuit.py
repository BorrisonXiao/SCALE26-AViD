"""Group each categorical observation's Boolean variables before SDD compilation.

This changes variable order only: probabilities, annotated-disjunction groups,
shared facts, queries and evidence labels remain the same. The standard
DeepProbLog circuit evaluator and PyTorch semiring are reused unchanged.
"""
import time
from problog.formula import LogicDAG,LogicFormula
from problog.sdd_formula import SDD
from deepproblog.arithmetic_circuit import ArithmeticCircuit
from deepproblog.solver import Solver

def group_categorical_atoms(source):
 target=LogicDAG(auto_compact=False,keep_named=True);mapping={0:0,None:None}
 atoms=[(i,n)for i,n,t in source if t=='atom']
 # A group is a single grounded annotated disjunction. Keep all its outcomes
 # adjacent, including the extra outcome that represents unused mass.
 atoms.sort(key=lambda x:(repr(x[1].group)if x[1].group is not None else'ungrouped:'+str(x[0]),x[0]))
 for i,n in atoms:
  mapping[i]=target.add_atom(n.identifier,n.probability,group=n.group,name=n.name,source=n.source,cr_extra=False,is_extra=n.is_extra)
 def remap(i):return mapping[i]if i in mapping else -mapping[-i]
 for i,n,t in source:
  if t!='atom':mapping[i]=(target.add_and if t=='conj'else target.add_or)([remap(c)for c in n.children],name=n.name)
 for name,node,label in source.get_names_with_label():target.add_name(name,remap(node),label)
 # add_atom above recreates all AD constraints with their original group IDs.
 # Other constraint types are outside this adapter's declared fragment.
 assert all(type(c).__name__=='ConstraintAD'for c in source.constraints())
 assert len(list(source.constraints()))==len(list(target.constraints()))
 return target

class OrderedArithmeticCircuit(ArithmeticCircuit):
 def __init__(self,formula,semiring,ground_time=None,sdd_auto_gc=False):
  started=time.perf_counter();original=LogicDAG.create_from(formula,keep_named=True)
  self.proof=group_categorical_atoms(original);self.sdd=SDD.create_from(self.proof,sdd_auto_gc=sdd_auto_gc)
  self.compile_time=time.perf_counter()-started;self.re_evaluate=False;self.semiring=semiring;self.ground_time=ground_time;self.results={}

class OrderedSolver(Solver):
 def build_ac(self,q):
  started=time.perf_counter();formula=self.engine.ground(q,label=LogicFormula.LABEL_QUERY)
  return OrderedArithmeticCircuit(formula,self.semiring,time.perf_counter()-started,self.sdd_auto_gc)
