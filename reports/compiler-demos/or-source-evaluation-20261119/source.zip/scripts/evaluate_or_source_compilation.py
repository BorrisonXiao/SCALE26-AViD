"""Compile frozen new OR claims without changing the compiler or references."""
import argparse
from collections import Counter
from hashlib import sha256

from prepare_compiler_fallback import dump, rows
from prepare_or_source_evaluation import RUN, read
from probabilistic_verification.compiler_fallback import check_output, compile_claim
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.fallback_amr import compile_fallback_amr, prepare_fallback
from run_amr_types import inspect


def evaluate(folder):
    claims = read(folder / 'claims.json')
    assert sha256((folder / 'claims.json').read_bytes()).hexdigest() == read(
        folder / 'dependency_provenance.json')['claims_sha256']
    reference = folder / ('reference_sha256.txt' if folder.name == 'fresh' else 'case_sha256.txt')
    checks = folder / ('references.json' if folder.name == 'fresh' else 'cases.json')
    assert sha256(checks.read_bytes()).hexdigest() == reference.read_text().strip()
    parsed = {r['claim_id']: r['clauses'][0]['record'] for r in rows(folder / 'parsed.jsonl')}
    graphs = {r['request']['task']['claim_id']: r['raw'] for r in rows(folder / 'amr.jsonl')}
    assert parsed.keys() == graphs.keys() == {r['claim_id'] for r in claims}
    results = []
    for claim in claims:
        cid = claim['claim_id']
        record = parsed[cid]
        assert record['text'] == claim['text']
        srl = check_output(record, compile_one(record))
        amr = check_output(record, inspect(record, graphs[cid], compiler=compile_fallback_amr,
                                           prepare=prepare_fallback))
        fixed = compile_claim(record, srl=lambda _: srl, amr=lambda _: amr)
        results.append(dict(claim, srl=srl, amr=amr, fixed=fixed))
    dump(folder / 'compiled.json', results)
    print(folder.name, dict(Counter(r['fixed']['selected_stage'] for r in results)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('group', choices=('fresh', 'transcripts'))
    evaluate(RUN / parser.parse_args().group)
