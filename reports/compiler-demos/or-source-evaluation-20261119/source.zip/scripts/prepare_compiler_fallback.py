"""Freeze the original paired audit before changing routing or semantics."""
from pathlib import Path
from collections import Counter
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compiler_fallback_20261118'
BASE=ROOT/'exp/probabilistic_verification/amr_contexts_20261118'
def rows(p):return [json.loads(s)for s in p.read_text().splitlines()if s.strip()]
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def verify_freeze():
 for name,digest in json.loads((RUN/'compiler_freeze.json').read_text()).items():
  assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name

def main():
 RUN.mkdir(exist_ok=True)
 sr=ROOT/'exp/probabilistic_verification/compiler_structural_20261113/direct_all.jsonl';ar=BASE/'corpus.jsonl'
 s={r['claim_id']:r for r in rows(sr)};a={r['claim_id']:r for r in rows(ar)}
 candidates=[dict(claim_id=cid,text=s[cid]['text'],srl=s[cid],amr=a[cid])for cid in s if s[cid]['status']!='compiled'and a[cid]['status']=='compiled']
 assert len(candidates)==183
 dump(RUN/'baseline_candidates.json',candidates)
 prior={r['claim_id']:r for r in json.loads((BASE/'reviewed_cases.json').read_text())}
 for r in candidates:
  r['prior_review']=prior.get(r['claim_id'],{}).get('review')
  r['reference']=prior.get(r['claim_id'],{}).get('reference')
 dump(RUN/'audit_inputs.json',candidates)
 dump(RUN/'baseline_inventory.json',dict(total=2375,srl_pass=1983,amr_pass=1578,fallback_candidates=183,automatic_either_pass=2166,neither_pass=209,prior_reviews=sum(bool(r['prior_review'])for r in candidates),policy='Fixed SRL check failure triggers AMR. No semantic review judgment or media/claim label controls routing. All totals count claims once.'))
 hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [sr,ar,BASE/'reviewed_cases.json',ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl']}
 dump(RUN/'input_manifest.json',hashes)
 old=json.loads((BASE/'preserved_files.json').read_text())
 for p in [ROOT/'site/reports/compiler-demos/amr-contexts-20261118/source.zip',ROOT/'site/reports/compiler-demos/amr-contexts-20261118/cases.json',ROOT/'site/reports/compiler-demos/amr-types-20261115/cases.json']:
  old[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
 dump(RUN/'preserved_files.json',old)
 print('Frozen183 candidates,38 prior reviews and baseline2,166 automatic passes.')
if __name__=='__main__':main()
