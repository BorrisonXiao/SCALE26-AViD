"""Archive the small evaluation and the source needed to replay it."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from or_source_evaluation_report import URL
from prepare_or_source_evaluation import ROOT, RUN

REPLAY = ('fresh/compiled.json', 'transcripts/compiled.json', 'transcripts/evaluation.json',
          'transcripts/inference.json', 'evaluation.json')


def main():
    inputs = RUN / 'source/minilm-nli/snapshot.json'
    paths = [inputs, ROOT / 'requirements-compilation.txt', ROOT / 'requirements-verification.txt',
             ROOT / 'tests/test_transcript_or.py', RUN / 'tests.xml']
    for folder in ('fresh', 'transcripts'):
        paths.extend(p for p in (RUN / folder).iterdir() if p.is_file() and p.name != 'candidates.json')
    paths.extend(RUN / name for name in REPLAY)
    scripts = (
        'collect_ami_or_candidates', 'freeze_reported_or_cases', 'prepare_or_source_evaluation',
        'evaluate_or_source_compilation', 'evaluate_reported_or_transcripts', 'or_source_evaluation_report',
        'package_or_source_evaluation', 'run_amr_types', 'prepare_compiler_fallback', 'sample_logical_form_review',
        'compiler_fallback_report', 'compiler_structural_report', 'full_rewrite_report',
        'prepare_structural_compiler', 'prepare_compiler_feedback', 'build_reviewed_compilation_report',
        'compiler_feedback_report', 'prompts_phase2', 'run_scope_coverage_census',
    )
    paths.extend(ROOT / 'scripts' / (name + '.py') for name in scripts)
    for dirname in ('probabilistic_verification', 'probabilistic_verification/resources'):
        paths.extend(p for p in (ROOT / 'scripts' / dirname).glob('*')
                     if p.is_file() and p.suffix in {'.py', '.json'})
    data = {str(p.relative_to(ROOT)): p.read_bytes() for p in paths}
    data['README.md'] = (ROOT / 'docs/or_source_evaluation_20261119.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps(
        {n: sha256((RUN / n).read_bytes()).hexdigest() for n in REPLAY}, indent=2).encode()
    target = ROOT / 'site/reports' / URL / 'source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(target, 'w', compression=ZIP_DEFLATED) as archive:
        for name, contents in sorted(data.items()):
            member = ZipInfo(name, date_time=(2026,11,19,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, contents)
    print(f'Bundled {len(data)} files for replay.')


if __name__ == '__main__':
    main()
