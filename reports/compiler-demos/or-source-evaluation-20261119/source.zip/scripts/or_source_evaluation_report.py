"""Render the transcript and fresh-source OR audit in the compiler report."""
from collections import Counter
from html import escape
from shutil import copy2
import xml.etree.ElementTree as ET

from compiler_fallback_report import table
from prepare_compiler_fallback import ROOT, dump
from prepare_or_source_evaluation import RUN, read

URL = 'compiler-demos/or-source-evaluation-20261119/'
AMI = 'https://groups.inf.ed.ac.uk/ami/download/'
AVERITEC = 'https://fever.ai/dataset/averitec.html'
METHODS = {
    'whole_nli': 'Whole-utterance NLI',
    'explicit_or': 'Exact alternatives',
    'branch_nli': 'NLI on alternatives',
}
VARIANTS = {
    'complete': 'Complete real utterance',
    'prefix': 'Real crop before OR',
    'suffix': 'Real crop after OR',
    'single_statement': 'Edited single assertion',
    'conjunction': 'Edited AND',
    'paraphrased_claim': 'Real utterance, paraphrased claim',
    'different_speaker': 'Real words assigned to a different speaker',
    'implicit_alternatives': 'Edited alternatives without “or”',
}
LABELS = {'matches_reference': 'Full match', 'partial': 'Partial', 'incorrect': 'Incorrect',
          'context_needed': 'Context needed', 'no_program': 'No program'}


def summarize():
    compiled = read(RUN / 'fresh/compiled.json')
    references = read(RUN / 'fresh/references.json')
    reviews = read(RUN / 'fresh/reviews.json')
    assert references.keys() == reviews.keys() == {r['claim_id'] for r in compiled}
    examples = []
    for row in compiled:
        cid = row['claim_id']
        judgment, finding = reviews[cid]
        assert judgment in LABELS
        if judgment != 'context_needed':
            assert (judgment != 'no_program') == bool(row['fixed']['output'])
        examples.append(dict(row, reference=references[cid], judgment=judgment, finding=finding))
    transcript = read(RUN / 'transcripts/evaluation.json')
    inference = read(RUN / 'transcripts/inference.json')
    all_controls = [c for r in inference for c in r['cases']]
    test_suite = ET.parse(RUN / 'tests.xml').find('testsuite')
    tests_passing = int(test_suite.get('tests')) - sum(int(test_suite.get(key, 0))
                     for key in ('failures', 'errors', 'skipped'))
    summary = dict(
        claims=len(compiled), passes=sum(bool(r['fixed']['output']) for r in compiled),
        stages=dict(Counter(r['fixed']['selected_stage'] or 'abstained' for r in compiled)),
        judgments=dict(Counter(r['judgment'] for r in examples)),
        transcript_programs=sum(r['stage'] is not None for r in inference),
        transcript_conditions=sum(bool(r['cases']) for r in inference),
        native_cases=len(all_controls),
        native_matches=sum(c['distribution'][c['expected']] >= 1-1e-10 for c in all_controls),
        tests_passing=tests_passing)
    dump(RUN / 'evaluation.json', dict(summary=summary, transcripts=transcript,
                                      inference=inference, fresh=examples))


def status_html():
    result = read(RUN / 'evaluation.json')
    s, t = result['summary'], result['transcripts']
    return (f'<b>Comparing alternatives matches {t["matches"]["branch_nli"]} of '
            f'{t["comparisons"]} transcript judgments.</b> '
            f'On {s["claims"]} fresh OR claims, {s["passes"]} compile and '
            f'{s["judgments"].get("matches_reference", 0)} match the reference reading.')


def overview_html():
    result = read(RUN / 'evaluation.json')
    s, t = result['summary'], result['transcripts']
    return (
        '<h2 id="remaining-failures">Reported OR in transcripts and new claims</h2>'
        '<p>A report such as “The participant said that you can put the remote on the table or on the couch” '
        'requires evidence that the speaker presented both locations as alternatives. One location alone can '
        'support a claim about where the remote goes while giving insufficient evidence of what was said.</p>'
        '<h3>What the speaker said</h3>'
        '<p>Eight meetings provide manually transcribed speech, speaker IDs, and word times. We used the whole utterance '
        'and two real crops, then added controlled text edits and paraphrases. The test receives the intended speaker, '
        f'time window, and whether that window is complete. <a href="{AMI}">AMI manual transcripts</a>.</p>'
        + table('Number of expected judgments matched across the same 58 comparisons.',
                ['Transcript check', 'Matches', 'Comparisons'],
                [(label, t['matches'][key], t['comparisons']) for key, label in METHODS.items()])
        + '<p>Whole-utterance natural language inference (NLI) tests whether one text entails another. '
        'It gives unknown for the eight edited single assertions and support for the eight edited AND statements. '
        'Comparing the two alternative spans with NLI recovers six of eight claim paraphrases. Both edited '
        'utterances that express alternatives without using “or” stay unknown.</p>'
        f'<p>{s["transcript_conditions"]} of eight transcript-derived claims compile to the full speech condition. '
        f'DeepProbLog returns the expected answer for all {s["native_matches"]} selected comparisons on those programs '
        'with the speaker candidate and other conditions supplied.</p>'
        '<h3>What new claim texts expose</h3>'
        '<p>The 16 AVeriTeC claims come from distinct source pages outside the earlier audit. We froze a reference '
        'reading for each before seeing the parses. We scored the fixed SRL and AMR sequence on meaning after '
        f'the automatic checks. This run ends after AMR if both direct paths fail. <a href="{AVERITEC}">AVeriTeC dataset</a>.</p>'
        + table('Each new claim contributes one result. The reference readings are development judgments.',
                ['Automatic passes', *LABELS.values()],
                [(s['passes'], *(s['judgments'].get(key, 0) for key in LABELS))])
        + '<p>One program negates each branch and joins them with OR, which weakens a denial of both actions. '
        'Another demands both a completed flight and a scheduled flight. The source offers those as alternatives.</p>'
        + f'<p>The earlier corpus count remains 2,179 of 2,375. {s["tests_passing"]} project tests pass. '
        'Both pilots used frozen models on CPU.</p>'
        '<p><a href="#reported-or-transcripts">Transcript examples and inference</a> · '
        '<a href="#fresh-or-cases">All 16 new claims and programs</a> · '
        '<a href="#earlier-or-scope">Earlier OR repairs</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}evaluation.json">Exact outputs and evidence</a> · '
        f'<a href="{URL}source.zip">Source and replay</a> · <a href="{URL}tests.xml">Tests</a></p>')


def attempt_details(attempts):
    rows = [(a['stage'].upper() if a['stage'] != 'rewrite' else 'Rewrite',
             a['status'], escape(a.get('reason') or 'Passed the automatic checks')) for a in attempts]
    return table('Compilation attempts in order.', ['Stage', 'Outcome', 'Detail'], rows)


def transcript_html(result):
    t, inference = result['transcripts'], {r['claim_id']: r for r in result['inference']}
    blocks = [
        '<section id="reported-or-transcripts"><h2>Eight speaker-aligned transcript examples</h2>'
        '<p>The exact check compares the two spans on either side of “or.” The NLI check also accepts paraphrases '
        'when each span entails the other in both directions with a probability of at least 0.55. '
        'The speaker and window must match. A complete utterance with only one alternative or with AND refutes '
        'the claim about what was said. A crop with only one alternative stays unknown.</p>'
        + table('Matches under each test condition.',
                ['Input', 'Comparisons', *METHODS.values()],
                [(VARIANTS[v], scores['total'], *(scores['correct'][m] for m in METHODS))
                 for v, scores in t['per_variant'].items()])]
    for segment in t['segments']:
        cid = segment['claim_id']
        trace = inference[cid]
        proof = {x['variant']: max(x['distribution'], key=x['distribution'].get) for x in trace['cases']}
        rows = [(VARIANTS[c['variant']], escape(c['text']), escape(c['target']) if c['target'] != segment['text'] else 'Original wording',
                 f'{c["speaker"]}, {c["start"]:.2f}–{c["end"]:.2f} s',
                 c['expected'], *(c['predictions'][m] for m in METHODS),
                 proof.get(c['variant'], '—')) for c in segment['cases']]
        caption = (f'AMI meeting {segment["meeting"]}, speaker {segment["speaker"]}, '
                   f'{segment["start"]:.2f}–{segment["end"]:.2f} seconds. DeepProbLog uses the branch judgments and fixed other observations.')
        conditions = ('<p><code>reported_disjunction</code> ' + escape(trace['conditions'][0]) + '</p>'
                      if trace['conditions'] else '<p>This input has no compiled condition for the full reported OR.</p>')
        blocks.append(f'<article class="box benchmark-case" id="transcript-{cid}">'
                      f'<h3>{escape(segment["segment_id"])}</h3><blockquote>{escape(segment["text"])}</blockquote>'
                      f'{conditions}<details><summary>Compare evidence, labels, and inference</summary>'
                      + table(caption, ['Input', 'Evidence', 'Claim wording', 'Speaker and time', 'Expected', *METHODS.values(),
                                        'DeepProbLog'], rows)
                      + f'<p><b>Input to compiler.</b> {escape(trace["claim"])}</p>'
                      + attempt_details(trace['attempts']) + '</details></article>')
    blocks.append(f'<p>Excerpted from the AMI corpus, © University of Edinburgh and partners, CC BY 4.0. '
                  f'Edited text and crops are labeled in each example. <a href="{AMI}">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a>.</p></section>')
    return ''.join(blocks)


def examples_html():
    result = read(RUN / 'evaluation.json')
    cards = [transcript_html(result), '<section id="fresh-or-cases"><h2>Sixteen new OR claims</h2>'
             '<p>Each entry shows the dataset claim as written, the frozen reading, and the gap in the selected program. '
             'The reference describes the claim’s meaning. The factual claims are quoted for language analysis.</p>']
    for case in result['fresh']:
        fixed = case['fixed']
        reference = case['reference']
        output = fixed['output']
        cid = case['claim_id']
        details = attempt_details(fixed['attempts'])
        if output:
            details += (f'<h4>Logical form</h4><pre>{escape(output["compilation"]["logical_form"])}</pre>'
                        f'<h4>DeepProbLog program</h4><pre>{escape(output["program"])}</pre>')
        cards.append(f'<article class="box benchmark-case" id="fresh-{escape(cid)}">'
                     f'<h3>{escape(reference["phenomenon"])} · {LABELS[case["judgment"]]}</h3>'
                     f'<blockquote>{escape(case["text"])}</blockquote>'
                     f'<p><b>Reference reading.</b> {escape(reference["reading"])}</p>'
                     f'<p><b>Finding.</b> {escape(case["finding"])}</p>'
                     f'<details><summary>Compilation attempts and exact output</summary>{details}</details>'
                     f'<p><a href="{escape(case["fact_checking_article"], quote=True)}">AVeriTeC source article</a></p></article>')
    return ''.join(cards) + '</section>'


def write_downloads():
    target = ROOT / 'site/reports' / URL
    target.mkdir(parents=True, exist_ok=True)
    for name in ('evaluation.json', 'tests.xml'):
        copy2(RUN / name, target / name)


if __name__ == '__main__':
    summarize()
