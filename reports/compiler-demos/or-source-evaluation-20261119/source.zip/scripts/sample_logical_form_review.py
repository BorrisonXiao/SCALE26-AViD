"""Freeze a diverse benchmark audit of cached logical forms."""
import hashlib
import json
import re
from collections import Counter

from prepare_compiler_fallback import ROOT, RUN as STRICT, rows, dump
from probabilistic_verification.amr_source_alignment import quote_spans

COVERAGE = STRICT.with_name('compiler_coverage_20261118')
SCOPE = STRICT.with_name('compiler_scope_20261118')
INPUTS = ROOT / 'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl'
RUN = STRICT.with_name('logical_form_review_20261118')
SEED = 'logical-form-benchmark-audit-v1'
STRICT_QUOTAS = dict(names=6, quantities=6, qualification=6, source_scope=6, coordination=6, general=6)
PROVISIONAL_QUOTAS = dict(advisory_checks=14, amr_unresolved_complement=5, amr_reentrancy=4,
                          amr_annotated_coordination=1)


def constructions(record):
    text = record['text']
    quotes = quote_spans(text)
    tokens = [t for t in record['tokens']
              if not any(q['start'] <= t['start_char'] < q['end'] for q in quotes)]
    return {
        'names': sum(t['upos'] == 'PROPN' for t in tokens) >= 2,
        'quantities': any(t['upos'] == 'NUM' for t in tokens),
        'qualification': any(t['lemma'] in {'would', 'if', 'may', 'might', 'unless', 'likely', 'possible',
                                             'reportedly', 'allegedly', 'infer'} for t in tokens),
        'source_scope': bool(quotes or any(t['lemma'] in {'say', 'tell', 'claim', 'note', 'report', 'show',
                                                        'depict', 'read', 'write', 'describe'}
                                           and t['upos'] in {'VERB', 'NOUN'} for t in tokens)),
        'coordination': any(t['lemma'] in {'and', 'or', 'but'} and t['deprel'] == 'cc' for t in tokens),
        'general': True,
    }


def key_hash(claim_id):
    return hashlib.sha256(f'{SEED}:{claim_id}'.encode()).hexdigest()


def content_key(text):
    return re.sub(r'\W+', ' ', text.casefold()).strip()


def select():
    records = {r['claim_id']: r for r in rows(INPUTS)}
    earlier = json.loads((COVERAGE / 'audit.json').read_text())
    earlier_reviews = json.loads((SCOPE / 'fidelity.json').read_text())['reviews']
    legacy = json.loads((STRICT / 'reviewed_additions.json').read_text())
    checked = json.loads((COVERAGE / 'checked_forms.json').read_text())
    exclude = {r['claim_id'] for r in [*earlier['examples'], *earlier_reviews, *legacy, *checked]}
    seen_text = {content_key(records[cid]['text']) for cid in exclude}
    strict_outputs = {r['claim_id']: r for r in rows(STRICT / 'corpus.jsonl') if r['parsing_status'] == 'compiled'}
    coverage = rows(COVERAGE / 'corpus.jsonl')
    untouched = [r for r in coverage if r['claim_id'] not in exclude and content_key(r['text']) not in seen_text]
    selected = []
    group_counts = Counter()
    topic_counts = Counter()
    selected_ids = set()
    strata = {cid: constructions(r) for cid, r in records.items()}

    def take(label, quota, candidates, strict):
        for _ in range(quota):
            def rank(row):
                cid = row['claim_id']
                return (sum(group_counts[k] for k in records[cid]['source_videos']),
                        topic_counts[cid.rsplit('_', 1)[0]], key_hash(cid))
            row = min((r for r in candidates if r['claim_id'] not in selected_ids
                       and content_key(r['text']) not in seen_text), key=rank)
            cid = row['claim_id']
            source = records[cid]
            output = strict_outputs[cid]['output'] if strict else row['output']
            assert output['program_sha256'] == row['program_sha256'], cid
            selected.append(dict(claim_id=cid, text=row['text'], source_videos=source['source_videos'],
                                 stratum=label, bucket='strict_srl' if strict else 'provisional',
                                 stage=row['chosen_stage'], output=output))
            group_counts.update(source['source_videos'])
            topic_counts[cid.rsplit('_', 1)[0]] += 1
            selected_ids.add(cid)
            seen_text.add(content_key(row['text']))

    for stage, quota in reversed(PROVISIONAL_QUOTAS.items()):
        take(stage, quota, [r for r in untouched if r['category'] == stage], False)
    strict_candidates = [r for r in untouched if r['category'] == 'strict_baseline'
                         and r['chosen_stage'] == 'srl']
    for construction, quota in STRICT_QUOTAS.items():
        take(construction, quota, [r for r in strict_candidates if strata[r['claim_id']][construction]], True)
    assert len(selected) == 60
    return dict(seed=SEED, strict_quotas=STRICT_QUOTAS, provisional_quotas=PROVISIONAL_QUOTAS,
                source_groups=len(group_counts), topics=len(topic_counts), excluded_prior_review_ids=len(exclude),
                sample=selected)


def main():
    RUN.mkdir(exist_ok=True)
    manifest = select()
    dump(RUN / 'sample.json', manifest)
    for i, row in enumerate(manifest['sample'], 1):
        output = row['output']
        form = output['compilation']
        print(f'{i:02d} {row["claim_id"]} [{row["stratum"]}] {row["text"]}')
        print('     Logical form:', form['logical_form'])
        print('     Prior warnings:', output.get('code'),
              [a['code'] for a in output.get('errors', []) + output.get('shared_checks', [])])
    print('Source groups', manifest['source_groups'], 'topics', manifest['topics'])


if __name__ == '__main__':
    main()
