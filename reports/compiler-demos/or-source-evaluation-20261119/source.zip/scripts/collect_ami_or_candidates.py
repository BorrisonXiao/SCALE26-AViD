"""Find readable two-alternative examples in the AMI manual annotations."""
from hashlib import sha256
from pathlib import Path
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import RUN

NITE_ID = '{http://nite.sourceforge.net/}id'


def detokenize(words):
    text = ' '.join(word['text'] for word in words)
    text = re.sub(r'\s+([,.!?:;])', r'\1', text)
    return re.sub(r"\s+((?:'|’)\w+|n['’]t)\b", r'\1', text)


def aligned_words(segment, tokens, positions):
    words = []
    for child in segment:
        bounds = re.findall(r'id\(([^)]+)\)', child.get('href', ''))
        if not bounds or any(b not in positions for b in bounds):
            continue
        for token in tokens[positions[bounds[0]]:positions[bounds[-1]]+1]:
            if token.tag != 'w' or not token.text:
                continue
            start, end = token.get('starttime'), token.get('endtime')
            if start is None or end is None:
                if token.get('punc') != 'true' or not words:
                    return []
                start = end = words[-1]['end']
            words.append(dict(text=token.text, start=float(start), end=float(end),
                              trunc=token.get('trunc') == 'true', word_id=token.get(NITE_ID)))
    return words


def candidate(meeting, speaker, segment, words):
    positions = [i for i, w in enumerate(words) if w['text'].casefold() == 'or']
    if not 10 <= len(words) <= 27 or len(positions) != 1 or any(w['trunc'] for w in words):
        return None
    split = positions[0]
    if split < 4 or len(words) - split < 4:
        return None
    text = detokenize(words)
    if not text.endswith('.') or text.count('.') != 1 or '?' in text:
        return None
    if re.search(r'\bor\s+(something|whatever|so|what|just|otherwise|anything)\b', text, re.I):
        return None
    if re.search(r'^or\b|\b(uh|um|you know|I mean)\b', text, re.I):
        return None
    return dict(meeting=meeting, speaker=speaker, segment_id=segment.get(NITE_ID),
                text=text, idx=split, words=words)


def main():
    candidates = []
    with ZipFile(RUN / 'source/ami_public_manual_1.6.2.zip') as archive:
        names = set(archive.namelist())
        for path in sorted(p for p in names if p.startswith('segments/') and p.endswith('.segments.xml')):
            meeting, speaker, *_ = Path(path).name.split('.')
            word_path = f'words/{meeting}.{speaker}.words.xml'
            if word_path not in names:
                continue
            tokens = list(ET.fromstring(archive.read(word_path)))
            positions = {token.get(NITE_ID): i for i, token in enumerate(tokens)}
            for segment in ET.fromstring(archive.read(path)):
                row = candidate(meeting, speaker, segment, aligned_words(segment, tokens, positions))
                if row is not None:
                    candidates.append(row)
    candidates.sort(key=lambda r: sha256(('or-transcript-19:' + r['segment_id']).encode()).hexdigest())
    dump(RUN / 'transcripts/candidates.json', candidates)
    print(f'{len(candidates)} candidate segments.')


if __name__ == '__main__':
    main()
