"""Render the fixed-input compilation comparison; no inference while rendering."""
from __future__ import annotations
from html import escape as esc
import json
from pathlib import Path
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compilation_methods_20261028'
PREFIX='verification-pipeline/compilation-methods/'


def load(name):return json.loads((RUN/name).read_text())
def rows():return [json.loads(s) for s in (RUN/'results.jsonl').read_text().splitlines()]
def pre(x):return '<pre>'+esc(x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,indent=2))+'</pre>'


def build_methods(table,figure,svg_dot,q):
    summary=load('summary.json');results=rows();reviews=load('quality_review.json')
    by_id={(r['method'],r['claim_id']):r for r in results}
    body='<section class="panel" role="tabpanel" id="compilation-methods" aria-labelledby="tab-methods" hidden><h2>Getting claim compilation working</h2>'
    body+='<p><strong>Current priority:</strong> choose a reliable route from a claim to a logical form and then DeepProbLog. This comparison uses 79 previously reviewed development claims and 21 constructed controls. It performs no new media verification or relation-classifier training.</p>'
    body+='<p><strong>Recommendation:</strong> keep trained semantic role labeling (SRL) as the inexpensive span/role baseline and pretrained Abstract Meaning Representation (AMR) as the main structured alternative. Fix their shared deterministic translation first. The next neural experiment should build a small logical form clause by clause, with deterministic serialization. The prompted 8B graphs below are not reliable enough to adopt.</p>'
    body+='<p>Syntax still helps with alignment, verb forms and diagnostics. It need not be the structure used by probabilistic inference. A shared argument in the logical form matters more than whether it came from a dependency tree or a semantic parser. This implements the existing paper direction; it does not change the paper to a parser-training project.</p>'
    body+='<div class="download-row">'+''.join('<a href="'+PREFIX+n+'">'+label+'</a>' for n,label in [
        ('source.zip','Source and CPU replay'),('summary.json','Measured counts'),('results.jsonl','All 400 compilation outcomes'),
        ('quality_review.json','Focused quality review'),('LITERATURE.md','Literature and recommendations'),
        ('direct_combined_raw.json','Direct model requests/responses'),('guided_combined_raw.json','Assisted model requests/responses'),
        ('tests.xml','Regression checks')])+'</div>'
    body+='<h3>1. Compare front ends through the same compiler</h3>'
    body+=figure(svg_dot([
        'a [label="Original claim"];',
        'b [label="Dependency analysis + trained SRL\n→ rule transformation"];',
        'c [label="Pretrained AMR parser"];',
        'd [label="Frozen text model\nwith or without syntax/SRL assistance"];',
        'e [label="Predicate–argument graph\nroles, shared referents, operators",fillcolor="#dcece4"];',
        'f [label="Deterministic logical-form compiler\nexplicit scope and variable binding",fillcolor="#dcece4"];',
        'g [label="Generated DeepProbLog program\nsyntax checked for every compiled input"];',
        'h [label="Selected backend execution checks\nartificial unknown observations only"];',
        'a -> b; a -> c; a -> d; b -> e; c -> e; d -> e; e -> f; f -> g; g -> h;'
    ],'Compilation approaches feeding a common logical-form compiler'),
        'The four new routes share one compiler. PENMAN is the graph notation; SRL-derived graphs are not full AMRs. No media scores or factual labels enter this comparison.')
    body+=table(['Approach','Implemented input / model','What it contributes','Main limitation'],[
        ['Dependency rules (historical)','Frozen v1 compiler','A reference for the earlier supported fragment','Narrow rules and lexical/POS dependence. Unchanged.'],
        ['Trained SRL → rules','Cached AllenNLP BERT-SRL on real claims; the same trained model run on controls','Predicate spans, frame-specific roles and complete argument phrases','Source scope needs translation; phrases can hide the bindings we want to learn.'],
        ['Pretrained AMR → post-processing','amrlib parse_xfm BART-large checkpoint, beam size 4','Concepts, semantic roles, modifiers and shared nodes','AMR is not executable logic; scope, time and missing details need handling.'],
        ['Text → neural graph','Frozen Qwen3-VL-8B-Instruct, text only, greedy decoding','Direct semantic graph proposal','Repeated graph variables, incorrect roles and invented polarity.'],
        ['Syntax/SRL → neural graph','Same 8B model, supplied cached dependencies and trained-SRL frames','Tests whether existing analyses help transformation','More context did not reliably preserve the supplied roles.'],
        ['PredPatt diagnostic','Existing installed PredPatt with UD 2.0 input','An additional predicate/argument extraction baseline','99/100 extraction outputs; not connected to a complete scope-aware compiler.']
    ],'Compared routes and their actual scope. ARG0/ARG1 are PropBank frame-specific labels, not universal agent/patient definitions.')
    body+='<h3>2. Execution counts, separate from meaning</h3><p><strong>These are coverage measurements, not accuracy scores.</strong> A valid graph has parseable syntax and one concept per variable. A compiled program passed the restricted logical translation. Every compiled program below also parses as ProbLog. The routes use different levels of detail, so their coverage counts do not establish which one preserves meaning best.</p>'
    counts=[]
    for key,m in summary['methods'].items():
        r=m['real'];c=m['controls']
        counts.append([esc(m['name']),f"{r['graph_valid']}/79",f"{r['compiled']}/79",f"{c['graph_valid']}/21",f"{c['compiled']}/21",f"{r['program_syntax_valid']+c['program_syntax_valid']}/{r['compiled']+c['compiled']}"])
    body+=table(['New route','Valid graph: real','Compiled: real','Valid graph: controls','Compiled: controls','Generated Prolog parses'],counts,
                'Fixed development inputs. Historical v1 compiled 20/79 and the earlier schema-heavy 8B condition compiled 11/79 under different supported fragments.')
    backend=[]
    for key,m in summary['methods'].items():
        attempted=sum(m[c]['backend_attempted'] for c in ['real','controls']);accepted=sum(m[c]['backend_accepted'] for c in ['real','controls'])
        backend.append([esc(m['name']),str(accepted)+'/'+str(attempted)])
    body+=table(['Route','Selected DeepProbLog checks accepted'],backend,
                'Five case IDs were selected per route; only compiled cases were submitted. Each check uses one placeholder per variable and unknown observations. These are execution checks, not media verdicts or a throughput benchmark.')
    body+='<p>The initial unrestricted backend sweep was stopped after a slow case. The saved comparison uses bounded subprocesses instead. Backend execution is sampled; Prolog syntax is checked for all compiled outputs. The 77 regression tests include the original 64 checks plus 13 new graph/compiler checks. Passing them does not certify generated-parser accuracy.</p>'
    body+='<h3>3. Inspect the meaning, not just the count</h3><p>Ten selected cases have assistant qualitative reviews across all four routes. These are examples, not an independent human gold set or a parser-accuracy estimate. The planned full reference review covers 25 real diagnostic claims and all 21 controls.</p>'
    body+=table(['Observed problem','Concrete evidence','What follows'],[
        ['Incorrect accepted roles','For IM-1 landed on the moon, both neural conditions use ARG0=IM-1 and ARG1=moon; the trained AMR has ARG1=IM-1 and location=moon.','Predicate signatures need checking. Valid syntax is insufficient.'],
        ['Invented negation','The direct graph negates was landing. The assisted graph negates has been arrested and buildings have collapsed.','Add polarity/scope checks against the sentence and reference controls.'],
        ['Lost names or qualifiers','AMR changes Phillies to Phillips and types Haboob as a city; an Alaskan-coast relation remains untranslated.','Inspect accepted outputs; preserve and validate lexical content.'],
        ['Coarse decomposition','SRL retains Alaskan coast or collapsed buildings as a phrase. Source contents remain opaque propositions in the new compiler.','Do not count preserved wording as completed internal binding analysis.'],
        ['Successful structural controls','Pretrained AMR preserves active/passive hug roles and a shared Alice across hugs and waves. Source-aligned tense distinguishes landing forms.','Retain these controls as regression tests while extending the compiler.']
    ],'Examples found by inspecting actual generated graphs and logical forms. All failed outputs remain available.')
    body+='<label for="methods-case">Choose an inspected claim </label><select id="methods-case" data-methods-select>'
    for case in reviews['cases']:body+='<option value="'+esc(case['claim_id'])+'">'+esc(case['title'])+'</option>'
    body+='</select><div id="methods-examples">'
    for i,case in enumerate(reviews['cases']):
        cid=case['claim_id'];text=by_id[('amr',cid)]['text']
        body+='<article data-methods-case="'+esc(cid)+'"'+(' hidden' if i else '')+'><h4>'+esc(case['title'])+'</h4><blockquote>'+esc(text)+'</blockquote><p><strong>Meaning to preserve:</strong> '+esc(case['requirement'])+'</p>'
        for method,m in summary['methods'].items():
            r=by_id[(method,cid)]
            body+='<details><summary>'+esc(m['name'])+' — '+esc(r['status'])+'</summary><p>'+esc(case['assessments'][method])+'</p><h5>Generated graph</h5>'+pre(r.get('graph',r.get('message','No graph')))
            if r['status']=='compiled':
                c=r['compilation'];body+='<h5>Compiled logical form</h5>'+pre(c['logical_form'])
                body+='<p><code>E1</code> denotes an event variable, <code>X1</code> an entity variable, and <code>T0</code> the discourse reference context. EXISTS introduces a candidate; AND requires all conditions; NOT has the displayed scope. These are variables and operators, not probabilities.</p>'
                if c.get('warnings'):body+='<p><strong>Warnings:</strong></p>'+pre(c['warnings'])
                if c['metadata']['source_contents']:body+='<h5>Preserved source content</h5>'+pre(c['metadata']['source_contents'])
                if c['metadata']['untranslated_edges']:body+='<h5>Graph edges without an executable translation</h5>'+pre(c['metadata']['untranslated_edges'])
                body+='<details><summary>Generated Prolog and execution diagnostic</summary>'+pre(r['program'])+pre(r.get('backend',{'note':'Not in the selected backend sample; Prolog syntax was checked.'}))+'</details>'
            else:body+='<h5>Compiler refusal</h5>'+pre(r.get('code','')+': '+r.get('message',''))
            body+='</details>'
        body+='</article>'
    body+='</div><h3>4. What the literature changes in the plan</h3>'
    lit=json.loads((ROOT/'research/2026-10-28-compilation/literature.json').read_text())
    selected=['Boxer','ccg2lambda','AMR-FOL','AMR-time','Constrained-LM','PICARD','CLOVER','Code4Logic','NL2LOGIC']
    body+=table(['Primary source','Relevant lesson'],[[
        '<a href="'+esc(p['source'])+'">'+esc(p['title'])+'</a> ('+str(p['year'])+')',esc(p['relevance'])] for p in lit['papers'] if p['id'] in selected],
        'Verified primary literature. These are design lessons; we have not implemented the cited systems in this comparison.')
    body+='<p><strong>Interpretation:</strong> building a logical form and compiling it deterministically is established practice. The future paper needs its contribution in multimodal evidence assignments and binding learning. We should use established parsing techniques as infrastructure and avoid turning this into a new general-purpose semantic-parser project.</p>'
    body+='<h3>5. Updated compilation-first plan</h3>'
    checklist=json.loads((ROOT/'exp/probabilistic_verification/av_features_20261022/checklist.json').read_text())
    step=next(s for s in checklist['steps'] if s['id']==7)
    body+='<ul class="checklist">'+''.join('<li><span aria-label="'+('done' if x['done'] else 'pending')+'">'+('☑' if x['done'] else '☐')+'</span>'+esc(x['text'])+'</li>' for x in step['items'])+'</ul>'
    body+='<p><strong>Proposed planning limit:</strong> one or two focused working days on the remaining compilation choices, then choose the simplest adequate route and document its supported fragment. This is a planning proposal, not a promised completion time. Keep media verification and new relation training deferred.</p>'
    body+='<p>The next neural condition should generate a small <strong>logical abstract syntax tree</strong>: a structured representation of predicates and operators, built clause by clause. Deterministic code can assign graph identifiers and emit Prolog, reducing formatting burden. Compare it with both trained SRL and pretrained AMR using the same meaning requirements. Grammar constraints improve format validity; they do not prove the translation correct.</p>'
    body+='<p>Before selecting a front end, resolve source-content recursion, noun-phrase relationships, predicate senses and signatures, and one temporal interface. The four-argument temporal atoms in this pilot are compilation outputs; they are not connected to the earlier five-argument interval checker. Keep refusals explicit for unsupported meanings. Then freeze the parser and evaluate compilation on unseen sources, reporting faithful accepted outputs separately from wrong accepted outputs and refusals.</p>'
    body+='<p>Measured GPU allocation: five completed one-V100 jobs, at most four concurrently, totaling 0.3336 GPU hours including loading. The real-claim SRL cache was reused; only the 21 controls required new trained-SRL CPU inference. No model was fine-tuned. Exact jobs/configuration and source references are in the downloadable artifacts.</p></section>'
    from build_logical_form_update import build_update
    outer='<section class="panel" role="tabpanel" id="compilation-methods" aria-labelledby="tab-methods" hidden>'
    historical=body.split('<h2>',1)[1].rsplit('</section>',1)[0]
    historical='<h2>'+historical
    census=ROOT/'exp/probabilistic_verification/full_compilation_20261029/results.summary.json'
    latest=''
    if census.exists():
        summary=json.loads(census.read_text())
        if summary['attempted']==2375:
            latest='<div class="callout" id="full-compilation-update"><h3>29 October: full 2,375-claim compilation run</h3><p>The revised original-text semantic parser and scoped compiler produce '+str(summary['counts']['compiled'])+' executable outputs, compared with 1,544 under the previous SRL/AMR selection policy. Compilation acceptance is not semantic accuracy. <a href="claim-compilation.html">Open the complete census, meaning review, failure analysis and searchable per-claim structures</a>.</p></div>'
    semantic_revision=ROOT/'exp/probabilistic_verification/srl_semantics_20261029/analysis.json'
    revision=ROOT/'exp/probabilistic_verification/srl_revision_20261029/analysis.json'
    if revision.exists():
        latest='<div class="callout" id="srl-compilation-update"><h3>29 October follow-up: one SRL compilation path</h3><p>The new experiment removes per-claim parser selection and compares a deterministic SRL/dependency compiler with separate LLM edit conditions. Coverage and meaning preservation are reported separately. <a href="srl-compilation.html">Open the SRL-only census, concise prompt and paired reviews</a>.</p></div>'+latest
    if semantic_revision.exists():
        latest='<div class="callout" id="semantic-compilation-update"><h3>29 October: meaning preservation in compilation</h3><p>The bounded SRL revision compiles 2,042/2,375 inputs. Fresh 20-case review: 8 faithful, 5 partial, 2 incorrect and 5 refused. Inspect the 24 reference readings, corrected bindings and remaining errors. <a href="semantic-compilation.html">Open the semantic compiler revision and next steps</a>.</p></div>'+latest
    followup=ROOT/'exp/probabilistic_verification/compiler_followup_20261030/analysis.json'
    if followup.exists():
        latest='<div class="callout" id="compiler-followup-update"><h3>30 October: compiler revision and evaluation</h3><p>The revision compiles 2,108/2,375 inputs. New-source assistant review: 12 faithful, 4 partial, 2 incorrect, 2 refused. Only 2 of 10 newly accepted outputs are fully faithful. Native inference completes the earlier nested-case timeout. <a href="compiler-followup.html">Open the full results, separate model review and next steps</a>.</p></div>'+latest
    scope_run=ROOT/'exp/probabilistic_verification/scope_compilation_20261101/analysis.json'
    if scope_run.exists():
        latest='<div class="callout" id="scope-compilation-update"><h3>1 November: source scope and claim conditions</h3><p>The frozen revision compiles 2,095/2,375 inputs, versus 2,108 previously. New refusals are not automatically correctness improvements. All 187 tests pass; actual human judgments remain pending. <a href="scope-compilation.html">Open the full census and source/condition examples</a> · <a href="claim-review.html">Open the empty 20-claim human review packet</a>.</p></div>'+latest
    if (ROOT/'exp/probabilistic_verification/compiler_revision_20261105/census_analysis.json').exists():
        latest='<div class="callout" id="reviewed-compilation-update"><h3>5 November: returned human review and compiler revision</h3><p>All 20 reviews are imported. Targeted fixes compile 2,099/2,375 claims, with four additions and no earlier accepts lost. The fresh sample is unchanged:13 faithful,4 partial,3 incorrect assistant judgments. Scope and missing-content errors remain. <a href="reviewed-compilation.html">Inspect the results, readable before/after structures and limits</a>.</p></div>'+latest
    if (ROOT/'exp/probabilistic_verification/scope_coverage_20261105/analysis.json').exists():
        latest='<div class="callout" id="scope-coverage-update"><h3>5 November follow-up: claim scope and missing content</h3><p>Eleven programs change. All 2,099 executable candidates remain; 1,839 pass the new coverage check and 260 require review. The 276 earlier refusals remain. All 228 checks pass; the fresh review shows no semantic gain. <a href="scope-coverage.html">See how the two fixes work, all outcomes and remaining errors</a>.</p></div>'+latest
    if (ROOT/'exp/probabilistic_verification/content_recovery_20261105/analysis.json').exists():
        latest='<div class="callout" id="compiler-demo-update"><h3>5 November: content recovery and plain-language demos</h3><p>1,866 original claims pass the current checks, versus 1,839 before; executable candidates rise to 2,103. All 259 tests pass. <a href="compiler-demos.html">See 28 before/after walkthroughs, including earlier difficult cases, plus all 2,375 outputs</a>. Checks and semantic correctness remain separate; reference resolution and rewriting are deferred.</p></div>'+latest
    earlier=build_update(table,figure,svg_dot,q).replace('Current implementation: logical forms and compiler interfaces','28 October implementation: logical forms and compiler interfaces')
    return outer+'<h2>Claim compilation: logical forms and interfaces</h2>'+latest+'<details id="earlier-compilation-comparison"><summary>Earlier comparison: PENMAN graphs and the first shared compiler</summary>'+historical+'</details>'+earlier+'</section>'


METHODS_SCRIPT="""
document.querySelector('[data-methods-select]').addEventListener('change',event=>{
 document.querySelectorAll('[data-methods-case]').forEach(el=>el.hidden=el.dataset.methodsCase!==event.target.value);
});
"""


def write_downloads(output):
    folder=output.parent/'verification-pipeline/compilation-methods';folder.mkdir(exist_ok=True,parents=True)
    data=['inputs.jsonl','amr_raw.jsonl','predpatt_raw.jsonl','summary.json','results.jsonl','quality_review.json','tests.xml','resource_usage.json','control_srl_provenance.json']
    data += [f'{m}_{i}_raw.jsonl' for m in ['direct','guided'] for i in [0,1]]
    for name in data+['direct_combined_raw.json','guided_combined_raw.json']:
        shutil.copyfile(RUN/name,folder/name)
    research=ROOT/'research/2026-10-28-compilation'
    for name in ['LITERATURE.md','literature.json']:shutil.copyfile(research/name,folder/name)
    files=list((ROOT/'scripts/probabilistic_verification').glob('*.py'))
    files += [ROOT/'scripts'/name for name in ['analyze_compilation_methods.py','check_compilation_backend.py','replay_compilation_methods.py',
               'run_compilation_models.py','run_compilation_models.slurm','run_compilation_srl.py','run_compilation_predpatt.py',
               'prompts_phase2.py','compile_verification_claim.py','run_verification_pipeline.py']]
    files += [ROOT/'tests'/name for name in ['test_probabilistic_verification.py','test_multimodal_verification.py','test_semantic_compiler.py','test_predicate_compilation.py']]
    files += list((ROOT/'tests/fixtures').glob('*.json'))
    files += [ROOT/'requirements-verification.txt',ROOT/'requirements-compilation.txt',ROOT/'docs/compilation_methods.md']
    files += [ROOT/'scripts/build_compilation_methods_report.py',research/'LITERATURE.md',research/'literature.json']
    files += [RUN/name for name in data]+[RUN/'models/download.json']
    contents={str(p.relative_to(ROOT)):p.read_bytes() for p in files}
    contents['README.md']=b'Compilation-only replay: install requirements-compilation.txt in an isolated environment, then run PYTHONPATH=scripts python scripts/replay_compilation_methods.py. All 400 saved compilation outcomes are checked without model loading, media, or training. See docs/compilation_methods.md for tests and bounded backend checks. Model weights are not included.\n'
    with zipfile.ZipFile(folder/'source.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,content in sorted(contents.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,content)
