# Specific speech options and naturally difficult visual evidence

## Speech

The comparison uses 48 previous queries and 38 queries from 12 additional recordings. Before scoring, the implementing assistant checked the original utterance, the claimed option phrases, the relation, and the edit. The new recordings were checked against five earlier AMI evaluation inventories and the previous 48 queries. The cases share the same annotated speaker, time, and candidate report spans across methods. They use manually specified options and relation types. The cases include actual reports, substitutions, queried wrong speakers, and controls for additions. Five of the new reports also have a reversed preference and a denial of the original replacement. The new prompts were fixed before scoring. [AMI corpus](https://groups.inf.ed.ac.uk/ami/download/)

DeBERTa gives a whole-claim entailment score. Qwen3-VL-8B scores text only. We compare an unconditioned check for whether alternatives are discussed, two separate option-presence scores, and a single score for the specific ordered options and their relationship. The scorer normalizes over three answer letters, then averages over two orders of the first two alternatives. All methods use 0.5 as the decision threshold. If a method uses multiple scores, the program treats the observations as independent and multiplies them in the same candidate span. All 430 native support distributions match the direct support calculation. The earlier baseline also reproduces every earlier decision on the 48 previous queries. Models and threshold are fixed. [DeBERTa checkpoint](https://huggingface.co/cross-encoder/nli-deberta-v3-small) · [Qwen checkpoint](https://huggingface.co/Qwen/Qwen3-VL-8B-Instruct)

On the previous queries, the whole claim plus any-alternatives score gives 44/48. Whole claim plus the specific relation gives 45/48. The power-button substitution drops from 0.961 to 0.005. A substituted tap still gets 0.99. The new queries improve from 32/38 to 35/38 with the same replacement. The earlier method supports 5/8 valid queries and gives false support to 3/8 substitutions. The new combination supports 7/8 valid queries and gives false support to 2/8 substitutions. It accepts two remotes in place of five and confuses functional with minimalist. It recovers the direct keypad choice and the solar energy and hand dynamo choice. All compared methods reject the five reversed preferences and five inserted negations in this set, so those controls show no incremental gain.

The specific relation alone supports all 20 valid queries and accepts 10/20 substitutions across both sets. Adding the two separate option checks rejects all 20 substitutions and supports just 4/20 valid claims. Applying 0.5 to each score separately also supports just 4/20. For example, the model detects volume-down twice but gives near zero to the separate mute button as an option, despite recognizing their relationship. This diagnostic suggests checking whether a direct option score distinguishes good paraphrases from substitutions before requiring it in a program. [CC BY 4.0 for transcript excerpts](https://creativecommons.org/licenses/by/4.0/)

## Visual evidence

Eight fresh frame sources were chosen for natural blur, obstruction, or small regions. We manually selected three or four distinct candidate crops per frame and fixed the two claims before scoring. Each frame has one supported claim and a controlled negative that asks for two objects in a category marked once. The queries refer only to the marked regions of the original images. There was no deliberate image degradation. Region and pair scores come from the same frozen Qwen inputs in every condition. Exact inference and the earlier best-pair and independent-pair calculations use the same categorical score for each region. The exact program assumes distinct crop observations are independent and reuses a region’s observation across any proofs that use it. Enumeration matches all 16 native distributions.

All three methods give 15/16 decisions at 0.25 and 0.5, and 14/16 at 0.75. At 0.5 they support 7/8 valid claims and reject all eight controls. The smoke-covered shield claim gets 0.0021 from the best pair and 0.0036 with exact inference. Only one shield region scores above 0.004. Four of 16 queries have a second pair scoring at least 0.1. The greatest support increase is 0.0185 for the white vans, where the best pair already scores 0.979. Support mean squared error is 0.0680 for the best pair and 0.0678 for the two aggregations, to four decimal places. These eight selected frames cannot establish a general accuracy or calibration advantage. Figure crops and model weights are available separately. The two Slurm jobs ran in sequence on one L40S at a time, for 199 and 25 seconds. All 713 project tests passed.

## Next steps

- Prepare source-disjoint examples for a small speech relation scorer, with substitutions of numbers, adjectives, and argument roles, and separate examples for calibration. The goal is to learn which changes break support without fitting on the benchmark cases.
- Compare each frame with a short neighboring-frame window on the same visual queries. The goal is to measure how often a second view supplies evidence for the same object when the first view is obscured. Keep the best pair as the baseline in both conditions.

## Replay

Use Python 3.12 with the bundled requirements, NumPy 2.2.6, and SciPy 1.17.1. The archive includes the inputs, raw predictions, frozen prompts, logic programs, and the prior results needed for the baseline check. The replay needs no GPU or model downloads. The test report contains the full project test result.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
sha256sum -c exp/probabilistic_verification/option_binding_20261127/input_sha256.txt
python scripts/evaluate_option_binding.py speech
python scripts/evaluate_option_binding.py visual
python scripts/option_binding_report.py
python -m pytest -q tests/test_option_binding.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/option_binding_20261127')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```
