% Exact categorical evidence; internal unknown = neither supported nor refuted.
0.99999672839110687::status(o_03a4f41b2ef72965e1ee,supported); 6.8907277187088689e-07::status(o_03a4f41b2ef72965e1ee,refuted); 2.5825361212444672e-06::status(o_03a4f41b2ef72965e1ee,unknown).
0.0030641257988218611::status(o_099bf39e37c15caaa876,supported); 0.00045773833686497912::status(o_099bf39e37c15caaa876,refuted); 0.99647813586431333::status(o_099bf39e37c15caaa876,unknown).
0.00015126360204912616::status(o_15342abf0ac6ce576da0,supported); 0.00067177790167186643::status(o_15342abf0ac6ce576da0,refuted); 0.99917695849627908::status(o_15342abf0ac6ce576da0,unknown).
0.86999035199371444::status(o_23bb53697b83a3f7c90b,supported); 0.0010556393817732349::status(o_23bb53697b83a3f7c90b,refuted); 0.12895400862451228::status(o_23bb53697b83a3f7c90b,unknown).
0.99999678606816544::status(o_29f042768c6fec809a99,supported); 1.2838112919065826e-06::status(o_29f042768c6fec809a99,refuted); 1.9301205427395543e-06::status(o_29f042768c6fec809a99,unknown).
0.9999973280865867::status(o_3c8be15d62657d195314,supported); 7.0374374763622552e-07::status(o_3c8be15d62657d195314,refuted); 1.9681696656431377e-06::status(o_3c8be15d62657d195314,unknown).
0.99999822036673092::status(o_4770c9c66e6ba36ee99a,supported); 8.8376730496136608e-07::status(o_4770c9c66e6ba36ee99a,refuted); 8.9586596409473318e-07::status(o_4770c9c66e6ba36ee99a,unknown).
2.7175559872138484e-06::status(o_515c91ccab8a2d193304,supported); 0.99970278696179049::status(o_515c91ccab8a2d193304,refuted); 0.00029449548222246555::status(o_515c91ccab8a2d193304,unknown).
0.98524057440712043::status(o_548d5aa6d62ebf26cb1c,supported); 6.7876293092214099e-05::status(o_548d5aa6d62ebf26cb1c,refuted); 0.014691549299787394::status(o_548d5aa6d62ebf26cb1c,unknown).
6.6083035276998767e-06::status(o_5beda4a0a5c3cd9547d2,supported); 0.99994864549030349::status(o_5beda4a0a5c3cd9547d2,refuted); 4.4746206168765391e-05::status(o_5beda4a0a5c3cd9547d2,unknown).
2.7385307039413592e-06::status(o_5df7fced193fa4722f3f,supported); 0.99871290537348534::status(o_5df7fced193fa4722f3f,refuted); 0.0012843560958108306::status(o_5df7fced193fa4722f3f,unknown).
0.0026429969159723942::status(o_629e758896a7ed7fb7b5,supported); 2.0657730964523812e-05::status(o_629e758896a7ed7fb7b5,refuted); 0.99733634535306304::status(o_629e758896a7ed7fb7b5,unknown).
0.98123011024925977::status(o_6356ab0a91d4612174d5,supported); 4.9146010576566414e-06::status(o_6356ab0a91d4612174d5,refuted); 0.018764975149682679::status(o_6356ab0a91d4612174d5,unknown).
0.024733827954867317::status(o_67f2bcb7da272bac1de7,supported); 0.31580827921852989::status(o_67f2bcb7da272bac1de7,refuted); 0.65945789282660283::status(o_67f2bcb7da272bac1de7,unknown).
0.014536130428962984::status(o_76991fa5dd14d94b29cd,supported); 0.49516893591683031::status(o_76991fa5dd14d94b29cd,refuted); 0.49029493365420668::status(o_76991fa5dd14d94b29cd,unknown).
5.4633950241361201e-07::status(o_7e8512c0575bce22d8c3,supported); 8.1960123587964296e-07::status(o_7e8512c0575bce22d8c3,refuted); 0.9999986340592617::status(o_7e8512c0575bce22d8c3,unknown).
0.99996681408624122::status(o_814c23295b17ea283e9e,supported); 3.3577527695711081e-06::status(o_814c23295b17ea283e9e,refuted); 2.9828160989165669e-05::status(o_814c23295b17ea283e9e,unknown).
0.99996979526977436::status(o_8718bbaf726f4b57acdb,supported); 6.9744985363340567e-06::status(o_8718bbaf726f4b57acdb,refuted); 2.3230231689214993e-05::status(o_8718bbaf726f4b57acdb,unknown).
0.99994589034868486::status(o_894454eb9ee947d0f984,supported); 2.1140151870417085e-06::status(o_894454eb9ee947d0f984,refuted); 5.1995636128011824e-05::status(o_894454eb9ee947d0f984,unknown).
1.8719338336741049e-06::status(o_968cbcbfe446bb0037a0,supported); 0.99999290280849007::status(o_968cbcbfe446bb0037a0,refuted); 5.2252576762988611e-06::status(o_968cbcbfe446bb0037a0,unknown).
0.99995107750197731::status(o_b5b59cf6f362e5f1f862,supported); 3.5247893382378775e-06::status(o_b5b59cf6f362e5f1f862,refuted); 4.5397708684510821e-05::status(o_b5b59cf6f362e5f1f862,unknown).
0.99996695699724603::status(o_b92c83b88d034537f86a,supported); 1.0895409873261196e-05::status(o_b92c83b88d034537f86a,refuted); 2.2147592880807152e-05::status(o_b92c83b88d034537f86a,unknown).
0.0016759758572304985::status(o_c2b66092e224ec056b3b,supported); 0.00046550287250007297::status(o_c2b66092e224ec056b3b,refuted); 0.99785852127026931::status(o_c2b66092e224ec056b3b,unknown).
0.7099108872917107::status(o_cd6fb2934759b42a5ffe,supported); 1.6979460463061213e-05::status(o_cd6fb2934759b42a5ffe,refuted); 0.29007213324782616::status(o_cd6fb2934759b42a5ffe,unknown).
0.00041289431108849141::status(o_d5cb68cb989d25802138,supported); 0.016230945401086085::status(o_d5cb68cb989d25802138,refuted); 0.98335616028782535::status(o_d5cb68cb989d25802138,unknown).
0.90245968895728024::status(o_d88b755649c7a6db34de,supported); 1.0593261219545221e-05::status(o_d88b755649c7a6db34de,refuted); 0.097529717781500352::status(o_d88b755649c7a6db34de,unknown).
0.97950576308347281::status(o_dae17789765c55acd6e8,supported); 1.2735289872338148e-05::status(o_dae17789765c55acd6e8,refuted); 0.020481501626654873::status(o_dae17789765c55acd6e8,unknown).
0.99985297200382228::status(o_e40da41138019d771c92,supported); 6.1134106074153932e-06::status(o_e40da41138019d771c92,refuted); 0.00014091458557021288::status(o_e40da41138019d771c92,unknown).
0.69959869231869787::status(o_f4c0675de2f4db7ccd49,supported); 0.00043392339591235738::status(o_f4c0675de2f4db7ccd49,refuted); 0.29996738428538972::status(o_f4c0675de2f4db7ccd49,unknown).
0.99999766063913031::status(o_fa9a67f4bad9cca1d447,supported); 8.8540331465474787e-07::status(o_fa9a67f4bad9cca1d447,refuted); 1.4539575551961634e-06::status(o_fa9a67f4bad9cca1d447,unknown).
0.99827045427729555::status(o_fad30c96eadbbcfc1616,supported); 3.780128048710888e-05::status(o_fad30c96eadbbcfc1616,refuted); 0.001691744442217345::status(o_fad30c96eadbbcfc1616,unknown).
node(n2,supported) :- status(o_3c8be15d62657d195314,supported).
node(n2,refuted) :- status(o_3c8be15d62657d195314,refuted).
node(n2,unknown) :- status(o_3c8be15d62657d195314,unknown).
node(n3,supported) :- status(o_23bb53697b83a3f7c90b,supported).
node(n3,refuted) :- status(o_23bb53697b83a3f7c90b,refuted).
node(n3,unknown) :- status(o_23bb53697b83a3f7c90b,unknown).
node(n1,supported) :- node(n2,supported), node(n3,supported).
node(n1,refuted) :- node(n2,refuted).
node(n1,refuted) :- node(n3,refuted).
node(n1,unknown) :- \+ node(n1,supported), \+ node(n1,refuted).
node(n5,supported) :- status(o_b92c83b88d034537f86a,supported).
node(n5,refuted) :- status(o_b92c83b88d034537f86a,refuted).
node(n5,unknown) :- status(o_b92c83b88d034537f86a,unknown).
node(n4,supported) :- node(n2,supported), node(n5,supported).
node(n4,refuted) :- node(n2,refuted).
node(n4,refuted) :- node(n5,refuted).
node(n4,unknown) :- \+ node(n4,supported), \+ node(n4,refuted).
node(n7,supported) :- status(o_5df7fced193fa4722f3f,supported).
node(n7,refuted) :- status(o_5df7fced193fa4722f3f,refuted).
node(n7,unknown) :- status(o_5df7fced193fa4722f3f,unknown).
node(n6,supported) :- node(n2,supported), node(n7,supported).
node(n6,refuted) :- node(n2,refuted).
node(n6,refuted) :- node(n7,refuted).
node(n6,unknown) :- \+ node(n6,supported), \+ node(n6,refuted).
node(n8,supported) :- node(n3,supported), node(n5,supported).
node(n8,refuted) :- node(n3,refuted).
node(n8,refuted) :- node(n5,refuted).
node(n8,unknown) :- \+ node(n8,supported), \+ node(n8,refuted).
node(n9,supported) :- node(n3,supported), node(n7,supported).
node(n9,refuted) :- node(n3,refuted).
node(n9,refuted) :- node(n7,refuted).
node(n9,unknown) :- \+ node(n9,supported), \+ node(n9,refuted).
node(n10,supported) :- node(n5,supported), node(n7,supported).
node(n10,refuted) :- node(n5,refuted).
node(n10,refuted) :- node(n7,refuted).
node(n10,unknown) :- \+ node(n10,supported), \+ node(n10,refuted).
node(n0,refuted) :- node(n1,refuted), node(n4,refuted), node(n6,refuted), node(n8,refuted), node(n9,refuted), node(n10,refuted).
node(n0,supported) :- node(n1,supported).
node(n0,supported) :- node(n4,supported).
node(n0,supported) :- node(n6,supported).
node(n0,supported) :- node(n8,supported).
node(n0,supported) :- node(n9,supported).
node(n0,supported) :- node(n10,supported).
node(n0,unknown) :- \+ node(n0,supported), \+ node(n0,refuted).
verdict(c_3c8be15d62657d19,supported) :- node(n0,supported).
query(verdict(c_3c8be15d62657d19,supported)).
verdict(c_3c8be15d62657d19,refuted) :- node(n0,refuted).
query(verdict(c_3c8be15d62657d19,refuted)).
verdict(c_3c8be15d62657d19,unknown) :- node(n0,unknown).
query(verdict(c_3c8be15d62657d19,unknown)).
node(n13,supported) :- node(n2,refuted).
node(n13,refuted) :- node(n2,supported).
node(n13,unknown) :- \+ node(n13,supported), \+ node(n13,refuted).
node(n14,supported) :- node(n3,refuted).
node(n14,refuted) :- node(n3,supported).
node(n14,unknown) :- \+ node(n14,supported), \+ node(n14,refuted).
node(n12,supported) :- node(n13,supported), node(n14,supported).
node(n12,refuted) :- node(n13,refuted).
node(n12,refuted) :- node(n14,refuted).
node(n12,unknown) :- \+ node(n12,supported), \+ node(n12,refuted).
node(n16,supported) :- node(n5,refuted).
node(n16,refuted) :- node(n5,supported).
node(n16,unknown) :- \+ node(n16,supported), \+ node(n16,refuted).
node(n15,supported) :- node(n13,supported), node(n16,supported).
node(n15,refuted) :- node(n13,refuted).
node(n15,refuted) :- node(n16,refuted).
node(n15,unknown) :- \+ node(n15,supported), \+ node(n15,refuted).
node(n18,supported) :- node(n7,refuted).
node(n18,refuted) :- node(n7,supported).
node(n18,unknown) :- \+ node(n18,supported), \+ node(n18,refuted).
node(n17,supported) :- node(n13,supported), node(n18,supported).
node(n17,refuted) :- node(n13,refuted).
node(n17,refuted) :- node(n18,refuted).
node(n17,unknown) :- \+ node(n17,supported), \+ node(n17,refuted).
node(n19,supported) :- node(n14,supported), node(n16,supported).
node(n19,refuted) :- node(n14,refuted).
node(n19,refuted) :- node(n16,refuted).
node(n19,unknown) :- \+ node(n19,supported), \+ node(n19,refuted).
node(n20,supported) :- node(n14,supported), node(n18,supported).
node(n20,refuted) :- node(n14,refuted).
node(n20,refuted) :- node(n18,refuted).
node(n20,unknown) :- \+ node(n20,supported), \+ node(n20,refuted).
node(n21,supported) :- node(n16,supported), node(n18,supported).
node(n21,refuted) :- node(n16,refuted).
node(n21,refuted) :- node(n18,refuted).
node(n21,unknown) :- \+ node(n21,supported), \+ node(n21,refuted).
node(n11,refuted) :- node(n12,refuted), node(n15,refuted), node(n17,refuted), node(n19,refuted), node(n20,refuted), node(n21,refuted).
node(n11,supported) :- node(n12,supported).
node(n11,supported) :- node(n15,supported).
node(n11,supported) :- node(n17,supported).
node(n11,supported) :- node(n19,supported).
node(n11,supported) :- node(n20,supported).
node(n11,supported) :- node(n21,supported).
node(n11,unknown) :- \+ node(n11,supported), \+ node(n11,refuted).
verdict(c_23bb53697b83a3f7,supported) :- node(n11,supported).
query(verdict(c_23bb53697b83a3f7,supported)).
verdict(c_23bb53697b83a3f7,refuted) :- node(n11,refuted).
query(verdict(c_23bb53697b83a3f7,refuted)).
verdict(c_23bb53697b83a3f7,unknown) :- node(n11,unknown).
query(verdict(c_23bb53697b83a3f7,unknown)).
node(n24,supported) :- status(o_814c23295b17ea283e9e,supported).
node(n24,refuted) :- status(o_814c23295b17ea283e9e,refuted).
node(n24,unknown) :- status(o_814c23295b17ea283e9e,unknown).
node(n25,supported) :- status(o_e40da41138019d771c92,supported).
node(n25,refuted) :- status(o_e40da41138019d771c92,refuted).
node(n25,unknown) :- status(o_e40da41138019d771c92,unknown).
node(n23,supported) :- node(n24,supported), node(n25,supported).
node(n23,refuted) :- node(n24,refuted).
node(n23,refuted) :- node(n25,refuted).
node(n23,unknown) :- \+ node(n23,supported), \+ node(n23,refuted).
node(n27,supported) :- status(o_7e8512c0575bce22d8c3,supported).
node(n27,refuted) :- status(o_7e8512c0575bce22d8c3,refuted).
node(n27,unknown) :- status(o_7e8512c0575bce22d8c3,unknown).
node(n26,supported) :- node(n24,supported), node(n27,supported).
node(n26,refuted) :- node(n24,refuted).
node(n26,refuted) :- node(n27,refuted).
node(n26,unknown) :- \+ node(n26,supported), \+ node(n26,refuted).
node(n29,supported) :- status(o_67f2bcb7da272bac1de7,supported).
node(n29,refuted) :- status(o_67f2bcb7da272bac1de7,refuted).
node(n29,unknown) :- status(o_67f2bcb7da272bac1de7,unknown).
node(n28,supported) :- node(n24,supported), node(n29,supported).
node(n28,refuted) :- node(n24,refuted).
node(n28,refuted) :- node(n29,refuted).
node(n28,unknown) :- \+ node(n28,supported), \+ node(n28,refuted).
node(n30,supported) :- node(n25,supported), node(n27,supported).
node(n30,refuted) :- node(n25,refuted).
node(n30,refuted) :- node(n27,refuted).
node(n30,unknown) :- \+ node(n30,supported), \+ node(n30,refuted).
node(n31,supported) :- node(n25,supported), node(n29,supported).
node(n31,refuted) :- node(n25,refuted).
node(n31,refuted) :- node(n29,refuted).
node(n31,unknown) :- \+ node(n31,supported), \+ node(n31,refuted).
node(n32,supported) :- node(n27,supported), node(n29,supported).
node(n32,refuted) :- node(n27,refuted).
node(n32,refuted) :- node(n29,refuted).
node(n32,unknown) :- \+ node(n32,supported), \+ node(n32,refuted).
node(n22,refuted) :- node(n23,refuted), node(n26,refuted), node(n28,refuted), node(n30,refuted), node(n31,refuted), node(n32,refuted).
node(n22,supported) :- node(n23,supported).
node(n22,supported) :- node(n26,supported).
node(n22,supported) :- node(n28,supported).
node(n22,supported) :- node(n30,supported).
node(n22,supported) :- node(n31,supported).
node(n22,supported) :- node(n32,supported).
node(n22,unknown) :- \+ node(n22,supported), \+ node(n22,refuted).
verdict(c_814c23295b17ea28,supported) :- node(n22,supported).
query(verdict(c_814c23295b17ea28,supported)).
verdict(c_814c23295b17ea28,refuted) :- node(n22,refuted).
query(verdict(c_814c23295b17ea28,refuted)).
verdict(c_814c23295b17ea28,unknown) :- node(n22,unknown).
query(verdict(c_814c23295b17ea28,unknown)).
node(n35,supported) :- node(n24,refuted).
node(n35,refuted) :- node(n24,supported).
node(n35,unknown) :- \+ node(n35,supported), \+ node(n35,refuted).
node(n36,supported) :- node(n25,refuted).
node(n36,refuted) :- node(n25,supported).
node(n36,unknown) :- \+ node(n36,supported), \+ node(n36,refuted).
node(n34,supported) :- node(n35,supported), node(n36,supported).
node(n34,refuted) :- node(n35,refuted).
node(n34,refuted) :- node(n36,refuted).
node(n34,unknown) :- \+ node(n34,supported), \+ node(n34,refuted).
node(n38,supported) :- node(n27,refuted).
node(n38,refuted) :- node(n27,supported).
node(n38,unknown) :- \+ node(n38,supported), \+ node(n38,refuted).
node(n37,supported) :- node(n35,supported), node(n38,supported).
node(n37,refuted) :- node(n35,refuted).
node(n37,refuted) :- node(n38,refuted).
node(n37,unknown) :- \+ node(n37,supported), \+ node(n37,refuted).
node(n40,supported) :- node(n29,refuted).
node(n40,refuted) :- node(n29,supported).
node(n40,unknown) :- \+ node(n40,supported), \+ node(n40,refuted).
node(n39,supported) :- node(n35,supported), node(n40,supported).
node(n39,refuted) :- node(n35,refuted).
node(n39,refuted) :- node(n40,refuted).
node(n39,unknown) :- \+ node(n39,supported), \+ node(n39,refuted).
node(n41,supported) :- node(n36,supported), node(n38,supported).
node(n41,refuted) :- node(n36,refuted).
node(n41,refuted) :- node(n38,refuted).
node(n41,unknown) :- \+ node(n41,supported), \+ node(n41,refuted).
node(n42,supported) :- node(n36,supported), node(n40,supported).
node(n42,refuted) :- node(n36,refuted).
node(n42,refuted) :- node(n40,refuted).
node(n42,unknown) :- \+ node(n42,supported), \+ node(n42,refuted).
node(n43,supported) :- node(n38,supported), node(n40,supported).
node(n43,refuted) :- node(n38,refuted).
node(n43,refuted) :- node(n40,refuted).
node(n43,unknown) :- \+ node(n43,supported), \+ node(n43,refuted).
node(n33,refuted) :- node(n34,refuted), node(n37,refuted), node(n39,refuted), node(n41,refuted), node(n42,refuted), node(n43,refuted).
node(n33,supported) :- node(n34,supported).
node(n33,supported) :- node(n37,supported).
node(n33,supported) :- node(n39,supported).
node(n33,supported) :- node(n41,supported).
node(n33,supported) :- node(n42,supported).
node(n33,supported) :- node(n43,supported).
node(n33,unknown) :- \+ node(n33,supported), \+ node(n33,refuted).
verdict(c_e40da41138019d77,supported) :- node(n33,supported).
query(verdict(c_e40da41138019d77,supported)).
verdict(c_e40da41138019d77,refuted) :- node(n33,refuted).
query(verdict(c_e40da41138019d77,refuted)).
verdict(c_e40da41138019d77,unknown) :- node(n33,unknown).
query(verdict(c_e40da41138019d77,unknown)).
node(n46,supported) :- status(o_894454eb9ee947d0f984,supported).
node(n46,refuted) :- status(o_894454eb9ee947d0f984,refuted).
node(n46,unknown) :- status(o_894454eb9ee947d0f984,unknown).
node(n47,supported) :- status(o_548d5aa6d62ebf26cb1c,supported).
node(n47,refuted) :- status(o_548d5aa6d62ebf26cb1c,refuted).
node(n47,unknown) :- status(o_548d5aa6d62ebf26cb1c,unknown).
node(n45,supported) :- node(n46,supported), node(n47,supported).
node(n45,refuted) :- node(n46,refuted).
node(n45,refuted) :- node(n47,refuted).
node(n45,unknown) :- \+ node(n45,supported), \+ node(n45,refuted).
node(n49,supported) :- status(o_29f042768c6fec809a99,supported).
node(n49,refuted) :- status(o_29f042768c6fec809a99,refuted).
node(n49,unknown) :- status(o_29f042768c6fec809a99,unknown).
node(n48,supported) :- node(n46,supported), node(n49,supported).
node(n48,refuted) :- node(n46,refuted).
node(n48,refuted) :- node(n49,refuted).
node(n48,unknown) :- \+ node(n48,supported), \+ node(n48,refuted).
node(n51,supported) :- status(o_515c91ccab8a2d193304,supported).
node(n51,refuted) :- status(o_515c91ccab8a2d193304,refuted).
node(n51,unknown) :- status(o_515c91ccab8a2d193304,unknown).
node(n50,supported) :- node(n46,supported), node(n51,supported).
node(n50,refuted) :- node(n46,refuted).
node(n50,refuted) :- node(n51,refuted).
node(n50,unknown) :- \+ node(n50,supported), \+ node(n50,refuted).
node(n52,supported) :- node(n47,supported), node(n49,supported).
node(n52,refuted) :- node(n47,refuted).
node(n52,refuted) :- node(n49,refuted).
node(n52,unknown) :- \+ node(n52,supported), \+ node(n52,refuted).
node(n53,supported) :- node(n47,supported), node(n51,supported).
node(n53,refuted) :- node(n47,refuted).
node(n53,refuted) :- node(n51,refuted).
node(n53,unknown) :- \+ node(n53,supported), \+ node(n53,refuted).
node(n54,supported) :- node(n49,supported), node(n51,supported).
node(n54,refuted) :- node(n49,refuted).
node(n54,refuted) :- node(n51,refuted).
node(n54,unknown) :- \+ node(n54,supported), \+ node(n54,refuted).
node(n44,refuted) :- node(n45,refuted), node(n48,refuted), node(n50,refuted), node(n52,refuted), node(n53,refuted), node(n54,refuted).
node(n44,supported) :- node(n45,supported).
node(n44,supported) :- node(n48,supported).
node(n44,supported) :- node(n50,supported).
node(n44,supported) :- node(n52,supported).
node(n44,supported) :- node(n53,supported).
node(n44,supported) :- node(n54,supported).
node(n44,unknown) :- \+ node(n44,supported), \+ node(n44,refuted).
verdict(c_894454eb9ee947d0,supported) :- node(n44,supported).
query(verdict(c_894454eb9ee947d0,supported)).
verdict(c_894454eb9ee947d0,refuted) :- node(n44,refuted).
query(verdict(c_894454eb9ee947d0,refuted)).
verdict(c_894454eb9ee947d0,unknown) :- node(n44,unknown).
query(verdict(c_894454eb9ee947d0,unknown)).
node(n57,supported) :- node(n46,refuted).
node(n57,refuted) :- node(n46,supported).
node(n57,unknown) :- \+ node(n57,supported), \+ node(n57,refuted).
node(n58,supported) :- node(n47,refuted).
node(n58,refuted) :- node(n47,supported).
node(n58,unknown) :- \+ node(n58,supported), \+ node(n58,refuted).
node(n56,supported) :- node(n57,supported), node(n58,supported).
node(n56,refuted) :- node(n57,refuted).
node(n56,refuted) :- node(n58,refuted).
node(n56,unknown) :- \+ node(n56,supported), \+ node(n56,refuted).
node(n60,supported) :- node(n49,refuted).
node(n60,refuted) :- node(n49,supported).
node(n60,unknown) :- \+ node(n60,supported), \+ node(n60,refuted).
node(n59,supported) :- node(n57,supported), node(n60,supported).
node(n59,refuted) :- node(n57,refuted).
node(n59,refuted) :- node(n60,refuted).
node(n59,unknown) :- \+ node(n59,supported), \+ node(n59,refuted).
node(n62,supported) :- node(n51,refuted).
node(n62,refuted) :- node(n51,supported).
node(n62,unknown) :- \+ node(n62,supported), \+ node(n62,refuted).
node(n61,supported) :- node(n57,supported), node(n62,supported).
node(n61,refuted) :- node(n57,refuted).
node(n61,refuted) :- node(n62,refuted).
node(n61,unknown) :- \+ node(n61,supported), \+ node(n61,refuted).
node(n63,supported) :- node(n58,supported), node(n60,supported).
node(n63,refuted) :- node(n58,refuted).
node(n63,refuted) :- node(n60,refuted).
node(n63,unknown) :- \+ node(n63,supported), \+ node(n63,refuted).
node(n64,supported) :- node(n58,supported), node(n62,supported).
node(n64,refuted) :- node(n58,refuted).
node(n64,refuted) :- node(n62,refuted).
node(n64,unknown) :- \+ node(n64,supported), \+ node(n64,refuted).
node(n65,supported) :- node(n60,supported), node(n62,supported).
node(n65,refuted) :- node(n60,refuted).
node(n65,refuted) :- node(n62,refuted).
node(n65,unknown) :- \+ node(n65,supported), \+ node(n65,refuted).
node(n55,refuted) :- node(n56,refuted), node(n59,refuted), node(n61,refuted), node(n63,refuted), node(n64,refuted), node(n65,refuted).
node(n55,supported) :- node(n56,supported).
node(n55,supported) :- node(n59,supported).
node(n55,supported) :- node(n61,supported).
node(n55,supported) :- node(n63,supported).
node(n55,supported) :- node(n64,supported).
node(n55,supported) :- node(n65,supported).
node(n55,unknown) :- \+ node(n55,supported), \+ node(n55,refuted).
verdict(c_548d5aa6d62ebf26,supported) :- node(n55,supported).
query(verdict(c_548d5aa6d62ebf26,supported)).
verdict(c_548d5aa6d62ebf26,refuted) :- node(n55,refuted).
query(verdict(c_548d5aa6d62ebf26,refuted)).
verdict(c_548d5aa6d62ebf26,unknown) :- node(n55,unknown).
query(verdict(c_548d5aa6d62ebf26,unknown)).
node(n68,supported) :- status(o_b5b59cf6f362e5f1f862,supported).
node(n68,refuted) :- status(o_b5b59cf6f362e5f1f862,refuted).
node(n68,unknown) :- status(o_b5b59cf6f362e5f1f862,unknown).
node(n69,supported) :- status(o_fad30c96eadbbcfc1616,supported).
node(n69,refuted) :- status(o_fad30c96eadbbcfc1616,refuted).
node(n69,unknown) :- status(o_fad30c96eadbbcfc1616,unknown).
node(n67,supported) :- node(n68,supported), node(n69,supported).
node(n67,refuted) :- node(n68,refuted).
node(n67,refuted) :- node(n69,refuted).
node(n67,unknown) :- \+ node(n67,supported), \+ node(n67,refuted).
node(n71,supported) :- status(o_76991fa5dd14d94b29cd,supported).
node(n71,refuted) :- status(o_76991fa5dd14d94b29cd,refuted).
node(n71,unknown) :- status(o_76991fa5dd14d94b29cd,unknown).
node(n70,supported) :- node(n68,supported), node(n71,supported).
node(n70,refuted) :- node(n68,refuted).
node(n70,refuted) :- node(n71,refuted).
node(n70,unknown) :- \+ node(n70,supported), \+ node(n70,refuted).
node(n72,supported) :- node(n69,supported), node(n71,supported).
node(n72,refuted) :- node(n69,refuted).
node(n72,refuted) :- node(n71,refuted).
node(n72,unknown) :- \+ node(n72,supported), \+ node(n72,refuted).
node(n66,refuted) :- node(n67,refuted), node(n70,refuted), node(n72,refuted).
node(n66,supported) :- node(n67,supported).
node(n66,supported) :- node(n70,supported).
node(n66,supported) :- node(n72,supported).
node(n66,unknown) :- \+ node(n66,supported), \+ node(n66,refuted).
verdict(c_b5b59cf6f362e5f1,supported) :- node(n66,supported).
query(verdict(c_b5b59cf6f362e5f1,supported)).
verdict(c_b5b59cf6f362e5f1,refuted) :- node(n66,refuted).
query(verdict(c_b5b59cf6f362e5f1,refuted)).
verdict(c_b5b59cf6f362e5f1,unknown) :- node(n66,unknown).
query(verdict(c_b5b59cf6f362e5f1,unknown)).
node(n75,supported) :- node(n68,refuted).
node(n75,refuted) :- node(n68,supported).
node(n75,unknown) :- \+ node(n75,supported), \+ node(n75,refuted).
node(n76,supported) :- node(n69,refuted).
node(n76,refuted) :- node(n69,supported).
node(n76,unknown) :- \+ node(n76,supported), \+ node(n76,refuted).
node(n74,supported) :- node(n75,supported), node(n76,supported).
node(n74,refuted) :- node(n75,refuted).
node(n74,refuted) :- node(n76,refuted).
node(n74,unknown) :- \+ node(n74,supported), \+ node(n74,refuted).
node(n78,supported) :- node(n71,refuted).
node(n78,refuted) :- node(n71,supported).
node(n78,unknown) :- \+ node(n78,supported), \+ node(n78,refuted).
node(n77,supported) :- node(n75,supported), node(n78,supported).
node(n77,refuted) :- node(n75,refuted).
node(n77,refuted) :- node(n78,refuted).
node(n77,unknown) :- \+ node(n77,supported), \+ node(n77,refuted).
node(n79,supported) :- node(n76,supported), node(n78,supported).
node(n79,refuted) :- node(n76,refuted).
node(n79,refuted) :- node(n78,refuted).
node(n79,unknown) :- \+ node(n79,supported), \+ node(n79,refuted).
node(n73,refuted) :- node(n74,refuted), node(n77,refuted), node(n79,refuted).
node(n73,supported) :- node(n74,supported).
node(n73,supported) :- node(n77,supported).
node(n73,supported) :- node(n79,supported).
node(n73,unknown) :- \+ node(n73,supported), \+ node(n73,refuted).
verdict(c_fad30c96eadbbcfc,supported) :- node(n73,supported).
query(verdict(c_fad30c96eadbbcfc,supported)).
verdict(c_fad30c96eadbbcfc,refuted) :- node(n73,refuted).
query(verdict(c_fad30c96eadbbcfc,refuted)).
verdict(c_fad30c96eadbbcfc,unknown) :- node(n73,unknown).
query(verdict(c_fad30c96eadbbcfc,unknown)).
node(n82,supported) :- status(o_c2b66092e224ec056b3b,supported).
node(n82,refuted) :- status(o_c2b66092e224ec056b3b,refuted).
node(n82,unknown) :- status(o_c2b66092e224ec056b3b,unknown).
node(n83,supported) :- status(o_f4c0675de2f4db7ccd49,supported).
node(n83,refuted) :- status(o_f4c0675de2f4db7ccd49,refuted).
node(n83,unknown) :- status(o_f4c0675de2f4db7ccd49,unknown).
node(n81,supported) :- node(n82,supported), node(n83,supported).
node(n81,refuted) :- node(n82,refuted).
node(n81,refuted) :- node(n83,refuted).
node(n81,unknown) :- \+ node(n81,supported), \+ node(n81,refuted).
node(n85,supported) :- status(o_099bf39e37c15caaa876,supported).
node(n85,refuted) :- status(o_099bf39e37c15caaa876,refuted).
node(n85,unknown) :- status(o_099bf39e37c15caaa876,unknown).
node(n84,supported) :- node(n82,supported), node(n85,supported).
node(n84,refuted) :- node(n82,refuted).
node(n84,refuted) :- node(n85,refuted).
node(n84,unknown) :- \+ node(n84,supported), \+ node(n84,refuted).
node(n87,supported) :- status(o_d5cb68cb989d25802138,supported).
node(n87,refuted) :- status(o_d5cb68cb989d25802138,refuted).
node(n87,unknown) :- status(o_d5cb68cb989d25802138,unknown).
node(n86,supported) :- node(n82,supported), node(n87,supported).
node(n86,refuted) :- node(n82,refuted).
node(n86,refuted) :- node(n87,refuted).
node(n86,unknown) :- \+ node(n86,supported), \+ node(n86,refuted).
node(n88,supported) :- node(n83,supported), node(n85,supported).
node(n88,refuted) :- node(n83,refuted).
node(n88,refuted) :- node(n85,refuted).
node(n88,unknown) :- \+ node(n88,supported), \+ node(n88,refuted).
node(n89,supported) :- node(n83,supported), node(n87,supported).
node(n89,refuted) :- node(n83,refuted).
node(n89,refuted) :- node(n87,refuted).
node(n89,unknown) :- \+ node(n89,supported), \+ node(n89,refuted).
node(n90,supported) :- node(n85,supported), node(n87,supported).
node(n90,refuted) :- node(n85,refuted).
node(n90,refuted) :- node(n87,refuted).
node(n90,unknown) :- \+ node(n90,supported), \+ node(n90,refuted).
node(n80,refuted) :- node(n81,refuted), node(n84,refuted), node(n86,refuted), node(n88,refuted), node(n89,refuted), node(n90,refuted).
node(n80,supported) :- node(n81,supported).
node(n80,supported) :- node(n84,supported).
node(n80,supported) :- node(n86,supported).
node(n80,supported) :- node(n88,supported).
node(n80,supported) :- node(n89,supported).
node(n80,supported) :- node(n90,supported).
node(n80,unknown) :- \+ node(n80,supported), \+ node(n80,refuted).
verdict(c_c2b66092e224ec05,supported) :- node(n80,supported).
query(verdict(c_c2b66092e224ec05,supported)).
verdict(c_c2b66092e224ec05,refuted) :- node(n80,refuted).
query(verdict(c_c2b66092e224ec05,refuted)).
verdict(c_c2b66092e224ec05,unknown) :- node(n80,unknown).
query(verdict(c_c2b66092e224ec05,unknown)).
node(n93,supported) :- node(n82,refuted).
node(n93,refuted) :- node(n82,supported).
node(n93,unknown) :- \+ node(n93,supported), \+ node(n93,refuted).
node(n94,supported) :- node(n83,refuted).
node(n94,refuted) :- node(n83,supported).
node(n94,unknown) :- \+ node(n94,supported), \+ node(n94,refuted).
node(n92,supported) :- node(n93,supported), node(n94,supported).
node(n92,refuted) :- node(n93,refuted).
node(n92,refuted) :- node(n94,refuted).
node(n92,unknown) :- \+ node(n92,supported), \+ node(n92,refuted).
node(n96,supported) :- node(n85,refuted).
node(n96,refuted) :- node(n85,supported).
node(n96,unknown) :- \+ node(n96,supported), \+ node(n96,refuted).
node(n95,supported) :- node(n93,supported), node(n96,supported).
node(n95,refuted) :- node(n93,refuted).
node(n95,refuted) :- node(n96,refuted).
node(n95,unknown) :- \+ node(n95,supported), \+ node(n95,refuted).
node(n98,supported) :- node(n87,refuted).
node(n98,refuted) :- node(n87,supported).
node(n98,unknown) :- \+ node(n98,supported), \+ node(n98,refuted).
node(n97,supported) :- node(n93,supported), node(n98,supported).
node(n97,refuted) :- node(n93,refuted).
node(n97,refuted) :- node(n98,refuted).
node(n97,unknown) :- \+ node(n97,supported), \+ node(n97,refuted).
node(n99,supported) :- node(n94,supported), node(n96,supported).
node(n99,refuted) :- node(n94,refuted).
node(n99,refuted) :- node(n96,refuted).
node(n99,unknown) :- \+ node(n99,supported), \+ node(n99,refuted).
node(n100,supported) :- node(n94,supported), node(n98,supported).
node(n100,refuted) :- node(n94,refuted).
node(n100,refuted) :- node(n98,refuted).
node(n100,unknown) :- \+ node(n100,supported), \+ node(n100,refuted).
node(n101,supported) :- node(n96,supported), node(n98,supported).
node(n101,refuted) :- node(n96,refuted).
node(n101,refuted) :- node(n98,refuted).
node(n101,unknown) :- \+ node(n101,supported), \+ node(n101,refuted).
node(n91,refuted) :- node(n92,refuted), node(n95,refuted), node(n97,refuted), node(n99,refuted), node(n100,refuted), node(n101,refuted).
node(n91,supported) :- node(n92,supported).
node(n91,supported) :- node(n95,supported).
node(n91,supported) :- node(n97,supported).
node(n91,supported) :- node(n99,supported).
node(n91,supported) :- node(n100,supported).
node(n91,supported) :- node(n101,supported).
node(n91,unknown) :- \+ node(n91,supported), \+ node(n91,refuted).
verdict(c_f4c0675de2f4db7c,supported) :- node(n91,supported).
query(verdict(c_f4c0675de2f4db7c,supported)).
verdict(c_f4c0675de2f4db7c,refuted) :- node(n91,refuted).
query(verdict(c_f4c0675de2f4db7c,refuted)).
verdict(c_f4c0675de2f4db7c,unknown) :- node(n91,unknown).
query(verdict(c_f4c0675de2f4db7c,unknown)).
node(n104,supported) :- status(o_6356ab0a91d4612174d5,supported).
node(n104,refuted) :- status(o_6356ab0a91d4612174d5,refuted).
node(n104,unknown) :- status(o_6356ab0a91d4612174d5,unknown).
node(n105,supported) :- status(o_cd6fb2934759b42a5ffe,supported).
node(n105,refuted) :- status(o_cd6fb2934759b42a5ffe,refuted).
node(n105,unknown) :- status(o_cd6fb2934759b42a5ffe,unknown).
node(n103,supported) :- node(n104,supported), node(n105,supported).
node(n103,refuted) :- node(n104,refuted).
node(n103,refuted) :- node(n105,refuted).
node(n103,unknown) :- \+ node(n103,supported), \+ node(n103,refuted).
node(n107,supported) :- status(o_629e758896a7ed7fb7b5,supported).
node(n107,refuted) :- status(o_629e758896a7ed7fb7b5,refuted).
node(n107,unknown) :- status(o_629e758896a7ed7fb7b5,unknown).
node(n106,supported) :- node(n104,supported), node(n107,supported).
node(n106,refuted) :- node(n104,refuted).
node(n106,refuted) :- node(n107,refuted).
node(n106,unknown) :- \+ node(n106,supported), \+ node(n106,refuted).
node(n109,supported) :- status(o_15342abf0ac6ce576da0,supported).
node(n109,refuted) :- status(o_15342abf0ac6ce576da0,refuted).
node(n109,unknown) :- status(o_15342abf0ac6ce576da0,unknown).
node(n108,supported) :- node(n104,supported), node(n109,supported).
node(n108,refuted) :- node(n104,refuted).
node(n108,refuted) :- node(n109,refuted).
node(n108,unknown) :- \+ node(n108,supported), \+ node(n108,refuted).
node(n110,supported) :- node(n105,supported), node(n107,supported).
node(n110,refuted) :- node(n105,refuted).
node(n110,refuted) :- node(n107,refuted).
node(n110,unknown) :- \+ node(n110,supported), \+ node(n110,refuted).
node(n111,supported) :- node(n105,supported), node(n109,supported).
node(n111,refuted) :- node(n105,refuted).
node(n111,refuted) :- node(n109,refuted).
node(n111,unknown) :- \+ node(n111,supported), \+ node(n111,refuted).
node(n112,supported) :- node(n107,supported), node(n109,supported).
node(n112,refuted) :- node(n107,refuted).
node(n112,refuted) :- node(n109,refuted).
node(n112,unknown) :- \+ node(n112,supported), \+ node(n112,refuted).
node(n102,refuted) :- node(n103,refuted), node(n106,refuted), node(n108,refuted), node(n110,refuted), node(n111,refuted), node(n112,refuted).
node(n102,supported) :- node(n103,supported).
node(n102,supported) :- node(n106,supported).
node(n102,supported) :- node(n108,supported).
node(n102,supported) :- node(n110,supported).
node(n102,supported) :- node(n111,supported).
node(n102,supported) :- node(n112,supported).
node(n102,unknown) :- \+ node(n102,supported), \+ node(n102,refuted).
verdict(c_6356ab0a91d46121,supported) :- node(n102,supported).
query(verdict(c_6356ab0a91d46121,supported)).
verdict(c_6356ab0a91d46121,refuted) :- node(n102,refuted).
query(verdict(c_6356ab0a91d46121,refuted)).
verdict(c_6356ab0a91d46121,unknown) :- node(n102,unknown).
query(verdict(c_6356ab0a91d46121,unknown)).
node(n115,supported) :- node(n104,refuted).
node(n115,refuted) :- node(n104,supported).
node(n115,unknown) :- \+ node(n115,supported), \+ node(n115,refuted).
node(n116,supported) :- node(n105,refuted).
node(n116,refuted) :- node(n105,supported).
node(n116,unknown) :- \+ node(n116,supported), \+ node(n116,refuted).
node(n114,supported) :- node(n115,supported), node(n116,supported).
node(n114,refuted) :- node(n115,refuted).
node(n114,refuted) :- node(n116,refuted).
node(n114,unknown) :- \+ node(n114,supported), \+ node(n114,refuted).
node(n118,supported) :- node(n107,refuted).
node(n118,refuted) :- node(n107,supported).
node(n118,unknown) :- \+ node(n118,supported), \+ node(n118,refuted).
node(n117,supported) :- node(n115,supported), node(n118,supported).
node(n117,refuted) :- node(n115,refuted).
node(n117,refuted) :- node(n118,refuted).
node(n117,unknown) :- \+ node(n117,supported), \+ node(n117,refuted).
node(n120,supported) :- node(n109,refuted).
node(n120,refuted) :- node(n109,supported).
node(n120,unknown) :- \+ node(n120,supported), \+ node(n120,refuted).
node(n119,supported) :- node(n115,supported), node(n120,supported).
node(n119,refuted) :- node(n115,refuted).
node(n119,refuted) :- node(n120,refuted).
node(n119,unknown) :- \+ node(n119,supported), \+ node(n119,refuted).
node(n121,supported) :- node(n116,supported), node(n118,supported).
node(n121,refuted) :- node(n116,refuted).
node(n121,refuted) :- node(n118,refuted).
node(n121,unknown) :- \+ node(n121,supported), \+ node(n121,refuted).
node(n122,supported) :- node(n116,supported), node(n120,supported).
node(n122,refuted) :- node(n116,refuted).
node(n122,refuted) :- node(n120,refuted).
node(n122,unknown) :- \+ node(n122,supported), \+ node(n122,refuted).
node(n123,supported) :- node(n118,supported), node(n120,supported).
node(n123,refuted) :- node(n118,refuted).
node(n123,refuted) :- node(n120,refuted).
node(n123,unknown) :- \+ node(n123,supported), \+ node(n123,refuted).
node(n113,refuted) :- node(n114,refuted), node(n117,refuted), node(n119,refuted), node(n121,refuted), node(n122,refuted), node(n123,refuted).
node(n113,supported) :- node(n114,supported).
node(n113,supported) :- node(n117,supported).
node(n113,supported) :- node(n119,supported).
node(n113,supported) :- node(n121,supported).
node(n113,supported) :- node(n122,supported).
node(n113,supported) :- node(n123,supported).
node(n113,unknown) :- \+ node(n113,supported), \+ node(n113,refuted).
verdict(c_cd6fb2934759b42a,supported) :- node(n113,supported).
query(verdict(c_cd6fb2934759b42a,supported)).
verdict(c_cd6fb2934759b42a,refuted) :- node(n113,refuted).
query(verdict(c_cd6fb2934759b42a,refuted)).
verdict(c_cd6fb2934759b42a,unknown) :- node(n113,unknown).
query(verdict(c_cd6fb2934759b42a,unknown)).
node(n126,supported) :- status(o_8718bbaf726f4b57acdb,supported).
node(n126,refuted) :- status(o_8718bbaf726f4b57acdb,refuted).
node(n126,unknown) :- status(o_8718bbaf726f4b57acdb,unknown).
node(n127,supported) :- status(o_dae17789765c55acd6e8,supported).
node(n127,refuted) :- status(o_dae17789765c55acd6e8,refuted).
node(n127,unknown) :- status(o_dae17789765c55acd6e8,unknown).
node(n125,supported) :- node(n126,supported), node(n127,supported).
node(n125,refuted) :- node(n126,refuted).
node(n125,refuted) :- node(n127,refuted).
node(n125,unknown) :- \+ node(n125,supported), \+ node(n125,refuted).
node(n129,supported) :- status(o_d88b755649c7a6db34de,supported).
node(n129,refuted) :- status(o_d88b755649c7a6db34de,refuted).
node(n129,unknown) :- status(o_d88b755649c7a6db34de,unknown).
node(n128,supported) :- node(n126,supported), node(n129,supported).
node(n128,refuted) :- node(n126,refuted).
node(n128,refuted) :- node(n129,refuted).
node(n128,unknown) :- \+ node(n128,supported), \+ node(n128,refuted).
node(n131,supported) :- status(o_5beda4a0a5c3cd9547d2,supported).
node(n131,refuted) :- status(o_5beda4a0a5c3cd9547d2,refuted).
node(n131,unknown) :- status(o_5beda4a0a5c3cd9547d2,unknown).
node(n130,supported) :- node(n126,supported), node(n131,supported).
node(n130,refuted) :- node(n126,refuted).
node(n130,refuted) :- node(n131,refuted).
node(n130,unknown) :- \+ node(n130,supported), \+ node(n130,refuted).
node(n132,supported) :- node(n127,supported), node(n129,supported).
node(n132,refuted) :- node(n127,refuted).
node(n132,refuted) :- node(n129,refuted).
node(n132,unknown) :- \+ node(n132,supported), \+ node(n132,refuted).
node(n133,supported) :- node(n127,supported), node(n131,supported).
node(n133,refuted) :- node(n127,refuted).
node(n133,refuted) :- node(n131,refuted).
node(n133,unknown) :- \+ node(n133,supported), \+ node(n133,refuted).
node(n134,supported) :- node(n129,supported), node(n131,supported).
node(n134,refuted) :- node(n129,refuted).
node(n134,refuted) :- node(n131,refuted).
node(n134,unknown) :- \+ node(n134,supported), \+ node(n134,refuted).
node(n124,refuted) :- node(n125,refuted), node(n128,refuted), node(n130,refuted), node(n132,refuted), node(n133,refuted), node(n134,refuted).
node(n124,supported) :- node(n125,supported).
node(n124,supported) :- node(n128,supported).
node(n124,supported) :- node(n130,supported).
node(n124,supported) :- node(n132,supported).
node(n124,supported) :- node(n133,supported).
node(n124,supported) :- node(n134,supported).
node(n124,unknown) :- \+ node(n124,supported), \+ node(n124,refuted).
verdict(c_8718bbaf726f4b57,supported) :- node(n124,supported).
query(verdict(c_8718bbaf726f4b57,supported)).
verdict(c_8718bbaf726f4b57,refuted) :- node(n124,refuted).
query(verdict(c_8718bbaf726f4b57,refuted)).
verdict(c_8718bbaf726f4b57,unknown) :- node(n124,unknown).
query(verdict(c_8718bbaf726f4b57,unknown)).
node(n137,supported) :- node(n126,refuted).
node(n137,refuted) :- node(n126,supported).
node(n137,unknown) :- \+ node(n137,supported), \+ node(n137,refuted).
node(n138,supported) :- node(n127,refuted).
node(n138,refuted) :- node(n127,supported).
node(n138,unknown) :- \+ node(n138,supported), \+ node(n138,refuted).
node(n136,supported) :- node(n137,supported), node(n138,supported).
node(n136,refuted) :- node(n137,refuted).
node(n136,refuted) :- node(n138,refuted).
node(n136,unknown) :- \+ node(n136,supported), \+ node(n136,refuted).
node(n140,supported) :- node(n129,refuted).
node(n140,refuted) :- node(n129,supported).
node(n140,unknown) :- \+ node(n140,supported), \+ node(n140,refuted).
node(n139,supported) :- node(n137,supported), node(n140,supported).
node(n139,refuted) :- node(n137,refuted).
node(n139,refuted) :- node(n140,refuted).
node(n139,unknown) :- \+ node(n139,supported), \+ node(n139,refuted).
node(n142,supported) :- node(n131,refuted).
node(n142,refuted) :- node(n131,supported).
node(n142,unknown) :- \+ node(n142,supported), \+ node(n142,refuted).
node(n141,supported) :- node(n137,supported), node(n142,supported).
node(n141,refuted) :- node(n137,refuted).
node(n141,refuted) :- node(n142,refuted).
node(n141,unknown) :- \+ node(n141,supported), \+ node(n141,refuted).
node(n143,supported) :- node(n138,supported), node(n140,supported).
node(n143,refuted) :- node(n138,refuted).
node(n143,refuted) :- node(n140,refuted).
node(n143,unknown) :- \+ node(n143,supported), \+ node(n143,refuted).
node(n144,supported) :- node(n138,supported), node(n142,supported).
node(n144,refuted) :- node(n138,refuted).
node(n144,refuted) :- node(n142,refuted).
node(n144,unknown) :- \+ node(n144,supported), \+ node(n144,refuted).
node(n145,supported) :- node(n140,supported), node(n142,supported).
node(n145,refuted) :- node(n140,refuted).
node(n145,refuted) :- node(n142,refuted).
node(n145,unknown) :- \+ node(n145,supported), \+ node(n145,refuted).
node(n135,refuted) :- node(n136,refuted), node(n139,refuted), node(n141,refuted), node(n143,refuted), node(n144,refuted), node(n145,refuted).
node(n135,supported) :- node(n136,supported).
node(n135,supported) :- node(n139,supported).
node(n135,supported) :- node(n141,supported).
node(n135,supported) :- node(n143,supported).
node(n135,supported) :- node(n144,supported).
node(n135,supported) :- node(n145,supported).
node(n135,unknown) :- \+ node(n135,supported), \+ node(n135,refuted).
verdict(c_dae17789765c55ac,supported) :- node(n135,supported).
query(verdict(c_dae17789765c55ac,supported)).
verdict(c_dae17789765c55ac,refuted) :- node(n135,refuted).
query(verdict(c_dae17789765c55ac,refuted)).
verdict(c_dae17789765c55ac,unknown) :- node(n135,unknown).
query(verdict(c_dae17789765c55ac,unknown)).
node(n148,supported) :- status(o_4770c9c66e6ba36ee99a,supported).
node(n148,refuted) :- status(o_4770c9c66e6ba36ee99a,refuted).
node(n148,unknown) :- status(o_4770c9c66e6ba36ee99a,unknown).
node(n149,supported) :- status(o_fa9a67f4bad9cca1d447,supported).
node(n149,refuted) :- status(o_fa9a67f4bad9cca1d447,refuted).
node(n149,unknown) :- status(o_fa9a67f4bad9cca1d447,unknown).
node(n147,supported) :- node(n148,supported), node(n149,supported).
node(n147,refuted) :- node(n148,refuted).
node(n147,refuted) :- node(n149,refuted).
node(n147,unknown) :- \+ node(n147,supported), \+ node(n147,refuted).
node(n151,supported) :- status(o_03a4f41b2ef72965e1ee,supported).
node(n151,refuted) :- status(o_03a4f41b2ef72965e1ee,refuted).
node(n151,unknown) :- status(o_03a4f41b2ef72965e1ee,unknown).
node(n150,supported) :- node(n148,supported), node(n151,supported).
node(n150,refuted) :- node(n148,refuted).
node(n150,refuted) :- node(n151,refuted).
node(n150,unknown) :- \+ node(n150,supported), \+ node(n150,refuted).
node(n153,supported) :- status(o_968cbcbfe446bb0037a0,supported).
node(n153,refuted) :- status(o_968cbcbfe446bb0037a0,refuted).
node(n153,unknown) :- status(o_968cbcbfe446bb0037a0,unknown).
node(n152,supported) :- node(n148,supported), node(n153,supported).
node(n152,refuted) :- node(n148,refuted).
node(n152,refuted) :- node(n153,refuted).
node(n152,unknown) :- \+ node(n152,supported), \+ node(n152,refuted).
node(n154,supported) :- node(n149,supported), node(n151,supported).
node(n154,refuted) :- node(n149,refuted).
node(n154,refuted) :- node(n151,refuted).
node(n154,unknown) :- \+ node(n154,supported), \+ node(n154,refuted).
node(n155,supported) :- node(n149,supported), node(n153,supported).
node(n155,refuted) :- node(n149,refuted).
node(n155,refuted) :- node(n153,refuted).
node(n155,unknown) :- \+ node(n155,supported), \+ node(n155,refuted).
node(n156,supported) :- node(n151,supported), node(n153,supported).
node(n156,refuted) :- node(n151,refuted).
node(n156,refuted) :- node(n153,refuted).
node(n156,unknown) :- \+ node(n156,supported), \+ node(n156,refuted).
node(n146,refuted) :- node(n147,refuted), node(n150,refuted), node(n152,refuted), node(n154,refuted), node(n155,refuted), node(n156,refuted).
node(n146,supported) :- node(n147,supported).
node(n146,supported) :- node(n150,supported).
node(n146,supported) :- node(n152,supported).
node(n146,supported) :- node(n154,supported).
node(n146,supported) :- node(n155,supported).
node(n146,supported) :- node(n156,supported).
node(n146,unknown) :- \+ node(n146,supported), \+ node(n146,refuted).
verdict(c_4770c9c66e6ba36e,supported) :- node(n146,supported).
query(verdict(c_4770c9c66e6ba36e,supported)).
verdict(c_4770c9c66e6ba36e,refuted) :- node(n146,refuted).
query(verdict(c_4770c9c66e6ba36e,refuted)).
verdict(c_4770c9c66e6ba36e,unknown) :- node(n146,unknown).
query(verdict(c_4770c9c66e6ba36e,unknown)).
node(n159,supported) :- node(n148,refuted).
node(n159,refuted) :- node(n148,supported).
node(n159,unknown) :- \+ node(n159,supported), \+ node(n159,refuted).
node(n160,supported) :- node(n149,refuted).
node(n160,refuted) :- node(n149,supported).
node(n160,unknown) :- \+ node(n160,supported), \+ node(n160,refuted).
node(n158,supported) :- node(n159,supported), node(n160,supported).
node(n158,refuted) :- node(n159,refuted).
node(n158,refuted) :- node(n160,refuted).
node(n158,unknown) :- \+ node(n158,supported), \+ node(n158,refuted).
node(n162,supported) :- node(n151,refuted).
node(n162,refuted) :- node(n151,supported).
node(n162,unknown) :- \+ node(n162,supported), \+ node(n162,refuted).
node(n161,supported) :- node(n159,supported), node(n162,supported).
node(n161,refuted) :- node(n159,refuted).
node(n161,refuted) :- node(n162,refuted).
node(n161,unknown) :- \+ node(n161,supported), \+ node(n161,refuted).
node(n164,supported) :- node(n153,refuted).
node(n164,refuted) :- node(n153,supported).
node(n164,unknown) :- \+ node(n164,supported), \+ node(n164,refuted).
node(n163,supported) :- node(n159,supported), node(n164,supported).
node(n163,refuted) :- node(n159,refuted).
node(n163,refuted) :- node(n164,refuted).
node(n163,unknown) :- \+ node(n163,supported), \+ node(n163,refuted).
node(n165,supported) :- node(n160,supported), node(n162,supported).
node(n165,refuted) :- node(n160,refuted).
node(n165,refuted) :- node(n162,refuted).
node(n165,unknown) :- \+ node(n165,supported), \+ node(n165,refuted).
node(n166,supported) :- node(n160,supported), node(n164,supported).
node(n166,refuted) :- node(n160,refuted).
node(n166,refuted) :- node(n164,refuted).
node(n166,unknown) :- \+ node(n166,supported), \+ node(n166,refuted).
node(n167,supported) :- node(n162,supported), node(n164,supported).
node(n167,refuted) :- node(n162,refuted).
node(n167,refuted) :- node(n164,refuted).
node(n167,unknown) :- \+ node(n167,supported), \+ node(n167,refuted).
node(n157,refuted) :- node(n158,refuted), node(n161,refuted), node(n163,refuted), node(n165,refuted), node(n166,refuted), node(n167,refuted).
node(n157,supported) :- node(n158,supported).
node(n157,supported) :- node(n161,supported).
node(n157,supported) :- node(n163,supported).
node(n157,supported) :- node(n165,supported).
node(n157,supported) :- node(n166,supported).
node(n157,supported) :- node(n167,supported).
node(n157,unknown) :- \+ node(n157,supported), \+ node(n157,refuted).
verdict(c_fa9a67f4bad9cca1,supported) :- node(n157,supported).
query(verdict(c_fa9a67f4bad9cca1,supported)).
verdict(c_fa9a67f4bad9cca1,refuted) :- node(n157,refuted).
query(verdict(c_fa9a67f4bad9cca1,refuted)).
verdict(c_fa9a67f4bad9cca1,unknown) :- node(n157,unknown).
query(verdict(c_fa9a67f4bad9cca1,unknown)).
