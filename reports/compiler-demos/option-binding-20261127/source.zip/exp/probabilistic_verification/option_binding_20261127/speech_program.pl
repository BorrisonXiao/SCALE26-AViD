% Exact categorical evidence; internal unknown = neither supported nor refuted.
0::status(o_001df7a39756b9be90e7,supported); 1::status(o_001df7a39756b9be90e7,refuted); 0::status(o_001df7a39756b9be90e7,unknown).
0.02884664386510849::status(o_00cceca778286f138990,supported); 0::status(o_00cceca778286f138990,refuted); 0.97115335613489151::status(o_00cceca778286f138990,unknown).
0.00035502800062487452::status(o_00d349367fa992fed1a0,supported); 0::status(o_00d349367fa992fed1a0,refuted); 0.99964497199937508::status(o_00d349367fa992fed1a0,unknown).
9.0030916908290237e-05::status(o_00ee12c5168b51bcfb9c,supported); 0::status(o_00ee12c5168b51bcfb9c,refuted); 0.99990996908309171::status(o_00ee12c5168b51bcfb9c,unknown).
1::status(o_00f2c5af9702eaaa9ac8,supported); 0::status(o_00f2c5af9702eaaa9ac8,refuted); 0::status(o_00f2c5af9702eaaa9ac8,unknown).
1::status(o_00feea56a3fb78186054,supported); 0::status(o_00feea56a3fb78186054,refuted); 0::status(o_00feea56a3fb78186054,unknown).
1::status(o_0115940621757dbaf9a0,supported); 0::status(o_0115940621757dbaf9a0,refuted); 0::status(o_0115940621757dbaf9a0,unknown).
1::status(o_011ef167b0355c41f24c,supported); 0::status(o_011ef167b0355c41f24c,refuted); 0::status(o_011ef167b0355c41f24c,unknown).
5.3418588668473969e-07::status(o_0154d63a61a596ad498b,supported); 0::status(o_0154d63a61a596ad498b,refuted); 0.99999946581411336::status(o_0154d63a61a596ad498b,unknown).
1::status(o_01afeed185f79f387e2b,supported); 0::status(o_01afeed185f79f387e2b,refuted); 0::status(o_01afeed185f79f387e2b,unknown).
0::status(o_01fd2e559a2136193291,supported); 1::status(o_01fd2e559a2136193291,refuted); 0::status(o_01fd2e559a2136193291,unknown).
0.22309549152851105::status(o_023e48e2bb067f1e4c40,supported); 0::status(o_023e48e2bb067f1e4c40,refuted); 0.77690450847148895::status(o_023e48e2bb067f1e4c40,unknown).
0::status(o_02646096a93a00fa1955,supported); 1::status(o_02646096a93a00fa1955,refuted); 0::status(o_02646096a93a00fa1955,unknown).
0.99999883815351143::status(o_02e81a30da73bdc0e9aa,supported); 0::status(o_02e81a30da73bdc0e9aa,refuted); 1.1618464885732038e-06::status(o_02e81a30da73bdc0e9aa,unknown).
1::status(o_030ba71f0a2f9fd42706,supported); 0::status(o_030ba71f0a2f9fd42706,refuted); 0::status(o_030ba71f0a2f9fd42706,unknown).
0.99999987123526379::status(o_0384398be9d70d1f3447,supported); 0::status(o_0384398be9d70d1f3447,refuted); 1.2876473620693218e-07::status(o_0384398be9d70d1f3447,unknown).
0.99999969610069539::status(o_03fbbce7bb70c41449aa,supported); 0::status(o_03fbbce7bb70c41449aa,refuted); 3.0389930461005576e-07::status(o_03fbbce7bb70c41449aa,unknown).
0.00011422050738474354::status(o_0462471f25df45fc1ba2,supported); 0::status(o_0462471f25df45fc1ba2,refuted); 0.99988577949261526::status(o_0462471f25df45fc1ba2,unknown).
0.99887460470199585::status(o_048fbd17b230ce792022,supported); 0::status(o_048fbd17b230ce792022,refuted); 0.0011253952980041504::status(o_048fbd17b230ce792022,unknown).
0.99999996709064987::status(o_04be5d700f90dc3916ab,supported); 0::status(o_04be5d700f90dc3916ab,refuted); 3.2909350133891735e-08::status(o_04be5d700f90dc3916ab,unknown).
3.9486884255223481e-06::status(o_04c519b5959366f2bae8,supported); 0::status(o_04c519b5959366f2bae8,refuted); 0.99999605131157443::status(o_04c519b5959366f2bae8,unknown).
0.88197631740513005::status(o_04e4f823e5e8ff9b2cb6,supported); 0::status(o_04e4f823e5e8ff9b2cb6,refuted); 0.11802368259486995::status(o_04e4f823e5e8ff9b2cb6,unknown).
0.070867766607818697::status(o_053689d2e5637db3dc9e,supported); 0::status(o_053689d2e5637db3dc9e,refuted); 0.92913223339218132::status(o_053689d2e5637db3dc9e,unknown).
0.39008886799262038::status(o_055f314ba3372308c037,supported); 0::status(o_055f314ba3372308c037,refuted); 0.60991113200737956::status(o_055f314ba3372308c037,unknown).
6.146516897648907e-06::status(o_0581ee98b416b2447ed9,supported); 0::status(o_0581ee98b416b2447ed9,refuted); 0.99999385348310232::status(o_0581ee98b416b2447ed9,unknown).
1::status(o_05c3e47978287286111a,supported); 0::status(o_05c3e47978287286111a,refuted); 0::status(o_05c3e47978287286111a,unknown).
2.8278058427373192e-08::status(o_05d987d65f59de8f73ec,supported); 0::status(o_05d987d65f59de8f73ec,refuted); 0.99999997172194155::status(o_05d987d65f59de8f73ec,unknown).
0.001097465050406754::status(o_0602c266670279ab9c34,supported); 0::status(o_0602c266670279ab9c34,refuted); 0.99890253494959325::status(o_0602c266670279ab9c34,unknown).
0.00018795524410060175::status(o_0605cf80d5cb8c0eb0d9,supported); 0::status(o_0605cf80d5cb8c0eb0d9,refuted); 0.99981204475589935::status(o_0605cf80d5cb8c0eb0d9,unknown).
0.0015275897180665864::status(o_062c3d23073c9e68d5ef,supported); 0::status(o_062c3d23073c9e68d5ef,refuted); 0.99847241028193345::status(o_062c3d23073c9e68d5ef,unknown).
0.003883931552991271::status(o_067d48913581ce03d73f,supported); 0::status(o_067d48913581ce03d73f,refuted); 0.99611606844700873::status(o_067d48913581ce03d73f,unknown).
1::status(o_06bee04783cee3b11415,supported); 0::status(o_06bee04783cee3b11415,refuted); 0::status(o_06bee04783cee3b11415,unknown).
0.99997198757213868::status(o_0721eb85bc4f09e2d07c,supported); 0::status(o_0721eb85bc4f09e2d07c,refuted); 2.801242786132363e-05::status(o_0721eb85bc4f09e2d07c,unknown).
7.2735645583604145e-08::status(o_073af1e867f3112966e0,supported); 0::status(o_073af1e867f3112966e0,refuted); 0.99999992726435438::status(o_073af1e867f3112966e0,unknown).
1.7690656117834124e-05::status(o_075e9b3f267a8e6fa34b,supported); 0::status(o_075e9b3f267a8e6fa34b,refuted); 0.99998230934388221::status(o_075e9b3f267a8e6fa34b,unknown).
1.3772274031924337e-05::status(o_07644fea3fb5b095cb08,supported); 0::status(o_07644fea3fb5b095cb08,refuted); 0.99998622772596812::status(o_07644fea3fb5b095cb08,unknown).
0.99996105067167163::status(o_07a5dffc9dc8e0712231,supported); 0::status(o_07a5dffc9dc8e0712231,refuted); 3.8949328328374833e-05::status(o_07a5dffc9dc8e0712231,unknown).
1.3695292072794446e-06::status(o_083f65da051fe17281d9,supported); 0::status(o_083f65da051fe17281d9,refuted); 0.99999863047079274::status(o_083f65da051fe17281d9,unknown).
1::status(o_086165ba462a9247b42b,supported); 0::status(o_086165ba462a9247b42b,refuted); 0::status(o_086165ba462a9247b42b,unknown).
0.99999964331402236::status(o_08dd0cecb2759d3291c7,supported); 0::status(o_08dd0cecb2759d3291c7,refuted); 3.5668597764271226e-07::status(o_08dd0cecb2759d3291c7,unknown).
1::status(o_0913078a3624de41980e,supported); 0::status(o_0913078a3624de41980e,refuted); 0::status(o_0913078a3624de41980e,unknown).
0::status(o_091f8113da440896d756,supported); 1::status(o_091f8113da440896d756,refuted); 0::status(o_091f8113da440896d756,unknown).
1::status(o_093e826d8b75d5a0fccf,supported); 0::status(o_093e826d8b75d5a0fccf,refuted); 0::status(o_093e826d8b75d5a0fccf,unknown).
4.1746313953515482e-07::status(o_096100267337c3a5271f,supported); 0::status(o_096100267337c3a5271f,refuted); 0.9999995825368605::status(o_096100267337c3a5271f,unknown).
0.99999902675069929::status(o_09c999552d49ecddc015,supported); 0::status(o_09c999552d49ecddc015,refuted); 9.7324930070641358e-07::status(o_09c999552d49ecddc015,unknown).
0.9999971777349157::status(o_09d5c61a5a58987b24dd,supported); 0::status(o_09d5c61a5a58987b24dd,refuted); 2.8222650843012786e-06::status(o_09d5c61a5a58987b24dd,unknown).
0.99999902675069929::status(o_0a7e6689c49192573f2f,supported); 0::status(o_0a7e6689c49192573f2f,refuted); 9.7324930070641358e-07::status(o_0a7e6689c49192573f2f,unknown).
0::status(o_0abef6bf37bbd92bbfb0,supported); 1::status(o_0abef6bf37bbd92bbfb0,refuted); 0::status(o_0abef6bf37bbd92bbfb0,unknown).
0.99999108955419413::status(o_0afb4fc16cec45d2dd4d,supported); 0::status(o_0afb4fc16cec45d2dd4d,refuted); 8.910445805865308e-06::status(o_0afb4fc16cec45d2dd4d,unknown).
7.240704569089391e-08::status(o_0b34b68faf2c8286ed4f,supported); 0::status(o_0b34b68faf2c8286ed4f,refuted); 0.99999992759295431::status(o_0b34b68faf2c8286ed4f,unknown).
1.1341866148431104e-06::status(o_0c1f31a22a22830c6a39,supported); 0::status(o_0c1f31a22a22830c6a39,refuted); 0.99999886581338515::status(o_0c1f31a22a22830c6a39,unknown).
1::status(o_0c36cfcbdcf0eec862e0,supported); 0::status(o_0c36cfcbdcf0eec862e0,refuted); 0::status(o_0c36cfcbdcf0eec862e0,unknown).
1::status(o_0c661e10e0f22728b44c,supported); 0::status(o_0c661e10e0f22728b44c,refuted); 0::status(o_0c661e10e0f22728b44c,unknown).
0.99999804612923038::status(o_0ca91855a63af1aaa5a7,supported); 0::status(o_0ca91855a63af1aaa5a7,refuted); 1.953870769622057e-06::status(o_0ca91855a63af1aaa5a7,unknown).
0.0014219179392286787::status(o_0d49d9f3565072318d06,supported); 0::status(o_0d49d9f3565072318d06,refuted); 0.99857808206077137::status(o_0d49d9f3565072318d06,unknown).
0.0018518617143854499::status(o_0dcb1f5cf72fea5b0aac,supported); 0::status(o_0dcb1f5cf72fea5b0aac,refuted); 0.99814813828561455::status(o_0dcb1f5cf72fea5b0aac,unknown).
0.0029208550695329905::status(o_0de694408a7f537751d5,supported); 0::status(o_0de694408a7f537751d5,refuted); 0.99707914493046701::status(o_0de694408a7f537751d5,unknown).
0.00013074099404702724::status(o_0e3183f37adc7dd88ac9,supported); 0::status(o_0e3183f37adc7dd88ac9,refuted); 0.99986925900595303::status(o_0e3183f37adc7dd88ac9,unknown).
0.93599168147::status(o_0e5d30e195dbed5df4aa,supported); 0::status(o_0e5d30e195dbed5df4aa,refuted); 0.064008318529999997::status(o_0e5d30e195dbed5df4aa,unknown).
1::status(o_0e9f9944ff68cfb3608c,supported); 0::status(o_0e9f9944ff68cfb3608c,refuted); 0::status(o_0e9f9944ff68cfb3608c,unknown).
2.9215075622410366e-05::status(o_0eb6cb694a5b8e7351ca,supported); 0::status(o_0eb6cb694a5b8e7351ca,refuted); 0.99997078492437763::status(o_0eb6cb694a5b8e7351ca,unknown).
0.99999999633715397::status(o_0f2752609df209e9ed98,supported); 0::status(o_0f2752609df209e9ed98,refuted); 3.6628460264864771e-09::status(o_0f2752609df209e9ed98,unknown).
0.99810886383056641::status(o_0f5f2749dc93af654e51,supported); 0::status(o_0f5f2749dc93af654e51,refuted); 0.0018911361694335938::status(o_0f5f2749dc93af654e51,unknown).
1::status(o_0ff2500d0981a46c8165,supported); 0::status(o_0ff2500d0981a46c8165,refuted); 0::status(o_0ff2500d0981a46c8165,unknown).
0.99999983246230739::status(o_0ffb0b77b3530e919aad,supported); 0::status(o_0ffb0b77b3530e919aad,refuted); 1.6753769260802187e-07::status(o_0ffb0b77b3530e919aad,unknown).
0.99999108955419413::status(o_10009f723b8c8c96e726,supported); 0::status(o_10009f723b8c8c96e726,refuted); 8.910445805865308e-06::status(o_10009f723b8c8c96e726,unknown).
0.99993287134783926::status(o_1005b28cd469a9b590b4,supported); 0::status(o_1005b28cd469a9b590b4,refuted); 6.7128652160741709e-05::status(o_1005b28cd469a9b590b4,unknown).
1::status(o_1024e28b63adb107bf5c,supported); 0::status(o_1024e28b63adb107bf5c,refuted); 0::status(o_1024e28b63adb107bf5c,unknown).
0::status(o_10d9f513ed1fa08b6300,supported); 1::status(o_10d9f513ed1fa08b6300,refuted); 0::status(o_10d9f513ed1fa08b6300,unknown).
1::status(o_117467c80adc274805b3,supported); 0::status(o_117467c80adc274805b3,refuted); 0::status(o_117467c80adc274805b3,unknown).
0.99995082857550566::status(o_118120580b7b6efe5d5b,supported); 0::status(o_118120580b7b6efe5d5b,refuted); 4.9171424494343086e-05::status(o_118120580b7b6efe5d5b,unknown).
2.1822341355879039e-09::status(o_11827030d9e3b2d7abd0,supported); 0::status(o_11827030d9e3b2d7abd0,refuted); 0.99999999781776583::status(o_11827030d9e3b2d7abd0,unknown).
0.0013008691603317857::status(o_11c681a32d34bb0b962b,supported); 0::status(o_11c681a32d34bb0b962b,refuted); 0.99869913083966821::status(o_11c681a32d34bb0b962b,unknown).
1::status(o_124d157201f26d0b1890,supported); 0::status(o_124d157201f26d0b1890,refuted); 0::status(o_124d157201f26d0b1890,unknown).
0.00021537096107015222::status(o_1267b4ff73f065d941ea,supported); 0::status(o_1267b4ff73f065d941ea,refuted); 0.99978462903892984::status(o_1267b4ff73f065d941ea,unknown).
0.002940004225820303::status(o_12bde1e3c18aacbbcf49,supported); 0::status(o_12bde1e3c18aacbbcf49,refuted); 0.9970599957741797::status(o_12bde1e3c18aacbbcf49,unknown).
7.618703582816562e-09::status(o_13035df4d5772ec35ea2,supported); 0::status(o_13035df4d5772ec35ea2,refuted); 0.99999999238129644::status(o_13035df4d5772ec35ea2,unknown).
0.99964481635247604::status(o_13a56e61fda7cb3cd81d,supported); 0::status(o_13a56e61fda7cb3cd81d,refuted); 0.00035518364752396003::status(o_13a56e61fda7cb3cd81d,unknown).
9.7990869313366259e-09::status(o_13ab81dc81a5bfe5bccf,supported); 0::status(o_13ab81dc81a5bfe5bccf,refuted); 0.99999999020091301::status(o_13ab81dc81a5bfe5bccf,unknown).
4.3944322083903182e-08::status(o_13ab9be9c0f2432e29f6,supported); 0::status(o_13ab9be9c0f2432e29f6,refuted); 0.99999995605567793::status(o_13ab9be9c0f2432e29f6,unknown).
0.99999691607382513::status(o_13e5e0d7e6441ffe385a,supported); 0::status(o_13e5e0d7e6441ffe385a,refuted); 3.0839261748738522e-06::status(o_13e5e0d7e6441ffe385a,unknown).
0.15821032226085663::status(o_13ff7d2497bad4b5c23c,supported); 0::status(o_13ff7d2497bad4b5c23c,refuted); 0.84178967773914337::status(o_13ff7d2497bad4b5c23c,unknown).
7.2544266787091473e-08::status(o_14176ca6ec1ae96d9228,supported); 0::status(o_14176ca6ec1ae96d9228,refuted); 0.99999992745573318::status(o_14176ca6ec1ae96d9228,unknown).
0.096061237156391144::status(o_144e6585ef2e3dd08b4b,supported); 0::status(o_144e6585ef2e3dd08b4b,refuted); 0.90393876284360886::status(o_144e6585ef2e3dd08b4b,unknown).
0.99978179605165418::status(o_145a39118572dee0fafd,supported); 0::status(o_145a39118572dee0fafd,refuted); 0.00021820394834581869::status(o_145a39118572dee0fafd,unknown).
4.6348650727496434e-05::status(o_1463d1e3cfbc58e7352b,supported); 0::status(o_1463d1e3cfbc58e7352b,refuted); 0.9999536513492725::status(o_1463d1e3cfbc58e7352b,unknown).
0.99999844166479634::status(o_146755d1daa78560a9a0,supported); 0::status(o_146755d1daa78560a9a0,refuted); 1.5583352036552256e-06::status(o_146755d1daa78560a9a0,unknown).
0.99999995459456814::status(o_146dea726bd2becb028a,supported); 0::status(o_146dea726bd2becb028a,refuted); 4.5405431858824841e-08::status(o_146dea726bd2becb028a,unknown).
4.1273197200221173e-09::status(o_146f2f1c521700595a7e,supported); 0::status(o_146f2f1c521700595a7e,refuted); 0.99999999587268029::status(o_146f2f1c521700595a7e,unknown).
1.1937902328639256e-07::status(o_149a4294d83ef0ec3e32,supported); 0::status(o_149a4294d83ef0ec3e32,refuted); 0.99999988062097667::status(o_149a4294d83ef0ec3e32,unknown).
1::status(o_14b8f503dbeff36cd587,supported); 0::status(o_14b8f503dbeff36cd587,refuted); 0::status(o_14b8f503dbeff36cd587,unknown).
1.2276381312403828e-05::status(o_14f36cd494a1a905dd7b,supported); 0::status(o_14f36cd494a1a905dd7b,refuted); 0.9999877236186876::status(o_14f36cd494a1a905dd7b,unknown).
0.059627130257008998::status(o_150a3d72452880dbf010,supported); 0::status(o_150a3d72452880dbf010,refuted); 0.94037286974299095::status(o_150a3d72452880dbf010,unknown).
2.659361886107589e-08::status(o_1579904599b3c3065804,supported); 0::status(o_1579904599b3c3065804,refuted); 0.99999997340638114::status(o_1579904599b3c3065804,unknown).
0::status(o_16236e605f1143c61462,supported); 1::status(o_16236e605f1143c61462,refuted); 0::status(o_16236e605f1143c61462,unknown).
1::status(o_1714ed829ffddd54e18e,supported); 0::status(o_1714ed829ffddd54e18e,refuted); 0::status(o_1714ed829ffddd54e18e,unknown).
2.2732953732053438e-05::status(o_1729d7b5b3d2d7c00f80,supported); 0::status(o_1729d7b5b3d2d7c00f80,refuted); 0.99997726704626799::status(o_1729d7b5b3d2d7c00f80,unknown).
0.99865079059131978::status(o_17783a1e4c08b2bb7b76,supported); 0::status(o_17783a1e4c08b2bb7b76,refuted); 0.0013492094086802187::status(o_17783a1e4c08b2bb7b76,unknown).
0.42756217829016024::status(o_17b94f30857ce14b67b1,supported); 0::status(o_17b94f30857ce14b67b1,refuted); 0.57243782170983981::status(o_17b94f30857ce14b67b1,unknown).
5.3744847294178184e-07::status(o_185dd364f006ede046c1,supported); 0::status(o_185dd364f006ede046c1,refuted); 0.99999946255152705::status(o_185dd364f006ede046c1,unknown).
8.3507141241693934e-06::status(o_194e0cfef17333878f05,supported); 0::status(o_194e0cfef17333878f05,refuted); 0.99999164928587581::status(o_194e0cfef17333878f05,unknown).
1::status(o_19a67469bd154fc77bbb,supported); 0::status(o_19a67469bd154fc77bbb,refuted); 0::status(o_19a67469bd154fc77bbb,unknown).
4.822686275353781e-05::status(o_19d69bb5d0cb7877d779,supported); 0::status(o_19d69bb5d0cb7877d779,refuted); 0.99995177313724648::status(o_19d69bb5d0cb7877d779,unknown).
0.99007987976074219::status(o_1a2363a115389a615c3c,supported); 0::status(o_1a2363a115389a615c3c,refuted); 0.0099201202392578125::status(o_1a2363a115389a615c3c,unknown).
0.999999966881435::status(o_1a28d002e22762578962,supported); 0::status(o_1a28d002e22762578962,refuted); 3.3118565001544198e-08::status(o_1a28d002e22762578962,unknown).
3.9486884255223481e-06::status(o_1abfe7cbc8254a1feba9,supported); 0::status(o_1abfe7cbc8254a1feba9,refuted); 0.99999605131157443::status(o_1abfe7cbc8254a1feba9,unknown).
0.99385096469335199::status(o_1afe71cdd473e131925a,supported); 0::status(o_1afe71cdd473e131925a,refuted); 0.0061490353066480097::status(o_1afe71cdd473e131925a,unknown).
0::status(o_1b7726a15b54c14e5adc,supported); 1::status(o_1b7726a15b54c14e5adc,refuted); 0::status(o_1b7726a15b54c14e5adc,unknown).
0.88519181387132784::status(o_1b7a3a94d38cdb516d90,supported); 0::status(o_1b7a3a94d38cdb516d90,refuted); 0.11480818612867216::status(o_1b7a3a94d38cdb516d90,unknown).
3.2482797206823362e-07::status(o_1bb76ab420cf43c6332f,supported); 0::status(o_1bb76ab420cf43c6332f,refuted); 0.99999967517202792::status(o_1bb76ab420cf43c6332f,unknown).
7.240704569089391e-08::status(o_1be6ccecfc7137411886,supported); 0::status(o_1be6ccecfc7137411886,refuted); 0.99999992759295431::status(o_1be6ccecfc7137411886,unknown).
7.618703582816562e-09::status(o_1c7db52c5791880bbcde,supported); 0::status(o_1c7db52c5791880bbcde,refuted); 0.99999999238129644::status(o_1c7db52c5791880bbcde,unknown).
0.99964323617997897::status(o_1d3f91ba878f9049ba81,supported); 0::status(o_1d3f91ba878f9049ba81,refuted); 0.00035676382002103324::status(o_1d3f91ba878f9049ba81,unknown).
6.5270009395127061e-06::status(o_1d5101a6e078601e6386,supported); 0::status(o_1d5101a6e078601e6386,refuted); 0.9999934729990605::status(o_1d5101a6e078601e6386,unknown).
0.00058511312818154693::status(o_1d55d0ba054bca6d48d9,supported); 0::status(o_1d55d0ba054bca6d48d9,refuted); 0.99941488687181845::status(o_1d55d0ba054bca6d48d9,unknown).
3.7454981436164323e-05::status(o_1d632313ab0d407dd8be,supported); 0::status(o_1d632313ab0d407dd8be,refuted); 0.99996254501856385::status(o_1d632313ab0d407dd8be,unknown).
1::status(o_1d661a7f383bf2103395,supported); 0::status(o_1d661a7f383bf2103395,refuted); 0::status(o_1d661a7f383bf2103395,unknown).
1::status(o_1d87fe60ecdadcf61d93,supported); 0::status(o_1d87fe60ecdadcf61d93,refuted); 0::status(o_1d87fe60ecdadcf61d93,unknown).
0::status(o_1e7b30b94b6863f2e644,supported); 1::status(o_1e7b30b94b6863f2e644,refuted); 0::status(o_1e7b30b94b6863f2e644,unknown).
1.4587193293713937e-06::status(o_1e9fa898d903b4822da8,supported); 0::status(o_1e9fa898d903b4822da8,refuted); 0.99999854128067067::status(o_1e9fa898d903b4822da8,unknown).
0.039551112800836563::status(o_1eb3ad58ddb7568b584e,supported); 0::status(o_1eb3ad58ddb7568b584e,refuted); 0.96044888719916344::status(o_1eb3ad58ddb7568b584e,unknown).
0.9999858004591502::status(o_2014ebbfcf940ec893a8,supported); 0::status(o_2014ebbfcf940ec893a8,refuted); 1.4199540849801906e-05::status(o_2014ebbfcf940ec893a8,unknown).
0::status(o_2034544f9423b13ee10c,supported); 1::status(o_2034544f9423b13ee10c,refuted); 0::status(o_2034544f9423b13ee10c,unknown).
0.00038813083665445447::status(o_208962c0e68aea132d33,supported); 0::status(o_208962c0e68aea132d33,refuted); 0.99961186916334555::status(o_208962c0e68aea132d33,unknown).
0.9814574122428894::status(o_20a5b56cbd65de533338,supported); 0::status(o_20a5b56cbd65de533338,refuted); 0.018542587757110596::status(o_20a5b56cbd65de533338,unknown).
0.99999237368905358::status(o_20b77f84d904aa78e934,supported); 0::status(o_20b77f84d904aa78e934,refuted); 7.6263109464180801e-06::status(o_20b77f84d904aa78e934,unknown).
1::status(o_20c14f40b044c7153778,supported); 0::status(o_20c14f40b044c7153778,refuted); 0::status(o_20c14f40b044c7153778,unknown).
0.00021535077497592163::status(o_214f92c75ed48b6786f2,supported); 0::status(o_214f92c75ed48b6786f2,refuted); 0.99978464922502408::status(o_214f92c75ed48b6786f2,unknown).
1::status(o_216b31c1d6bd89280676,supported); 0::status(o_216b31c1d6bd89280676,refuted); 0::status(o_216b31c1d6bd89280676,unknown).
1::status(o_216de3531cd0852ced93,supported); 0::status(o_216de3531cd0852ced93,refuted); 0::status(o_216de3531cd0852ced93,unknown).
0.99908996705486874::status(o_22061740add817095de1,supported); 0::status(o_22061740add817095de1,refuted); 0.0009100329451312561::status(o_22061740add817095de1,unknown).
2.2732953732053438e-05::status(o_2208b731f143e3799ba4,supported); 0::status(o_2208b731f143e3799ba4,refuted); 0.99997726704626799::status(o_2208b731f143e3799ba4,unknown).
0.99999597388339545::status(o_222784d95691759723dc,supported); 0::status(o_222784d95691759723dc,refuted); 4.0261166045496566e-06::status(o_222784d95691759723dc,unknown).
1::status(o_2236d0e401eb969bae19,supported); 0::status(o_2236d0e401eb969bae19,refuted); 0::status(o_2236d0e401eb969bae19,unknown).
4.394259667606093e-05::status(o_229b42c6aa4e1e630c37,supported); 0::status(o_229b42c6aa4e1e630c37,refuted); 0.99995605740332394::status(o_229b42c6aa4e1e630c37,unknown).
0.00012726461784352694::status(o_22a816de4bcca588aebf,supported); 0::status(o_22a816de4bcca588aebf,refuted); 0.99987273538215649::status(o_22a816de4bcca588aebf,unknown).
1::status(o_22b1f2e7bcaabd8f0f5d,supported); 0::status(o_22b1f2e7bcaabd8f0f5d,refuted); 0::status(o_22b1f2e7bcaabd8f0f5d,unknown).
0::status(o_22effeae2f1aeb5a4309,supported); 1::status(o_22effeae2f1aeb5a4309,refuted); 0::status(o_22effeae2f1aeb5a4309,unknown).
1::status(o_232585831e4ef20e3cb3,supported); 0::status(o_232585831e4ef20e3cb3,refuted); 0::status(o_232585831e4ef20e3cb3,unknown).
1::status(o_23898dddbf45158ec6c2,supported); 0::status(o_23898dddbf45158ec6c2,refuted); 0::status(o_23898dddbf45158ec6c2,unknown).
0.99977468029036498::status(o_23a48761d1816fadfcbb,supported); 0::status(o_23a48761d1816fadfcbb,refuted); 0.00022531970963501902::status(o_23a48761d1816fadfcbb,unknown).
0.36756375367835886::status(o_23b2d03d8fefee4eb775,supported); 0::status(o_23b2d03d8fefee4eb775,refuted); 0.63243624632164108::status(o_23b2d03d8fefee4eb775,unknown).
1::status(o_23cb7c2855eb34b2f2e4,supported); 0::status(o_23cb7c2855eb34b2f2e4,refuted); 0::status(o_23cb7c2855eb34b2f2e4,unknown).
1.1368821425472355e-06::status(o_24262540d5953308caf3,supported); 0::status(o_24262540d5953308caf3,refuted); 0.99999886311785746::status(o_24262540d5953308caf3,unknown).
0.99978179605165418::status(o_244e877aab9680c8dac1,supported); 0::status(o_244e877aab9680c8dac1,refuted); 0.00021820394834581869::status(o_244e877aab9680c8dac1,unknown).
0.014709697338768809::status(o_24557400479bfc39193e,supported); 0::status(o_24557400479bfc39193e,refuted); 0.98529030266123119::status(o_24557400479bfc39193e,unknown).
0.988739013671875::status(o_2456133848944474da7b,supported); 0::status(o_2456133848944474da7b,refuted); 0.011260986328125::status(o_2456133848944474da7b,unknown).
0.00062835169956088066::status(o_2458bd728c6f3dbfe2e4,supported); 0::status(o_2458bd728c6f3dbfe2e4,refuted); 0.99937164830043912::status(o_2458bd728c6f3dbfe2e4,unknown).
1.3842511524140808e-05::status(o_245a59cbec95f041a8fb,supported); 0::status(o_245a59cbec95f041a8fb,refuted); 0.99998615748847586::status(o_245a59cbec95f041a8fb,unknown).
0.039551112800836563::status(o_2484d806017feff4162b,supported); 0::status(o_2484d806017feff4162b,refuted); 0.96044888719916344::status(o_2484d806017feff4162b,unknown).
0.99999811605901279::status(o_252abecde0701ebf95ef,supported); 0::status(o_252abecde0701ebf95ef,refuted); 1.8839409872128954e-06::status(o_252abecde0701ebf95ef,unknown).
0.99876517950783739::status(o_25540f753245f4ab1ef6,supported); 0::status(o_25540f753245f4ab1ef6,refuted); 0.0012348204921626138::status(o_25540f753245f4ab1ef6,unknown).
1::status(o_2630f44fe0e5b747c24b,supported); 0::status(o_2630f44fe0e5b747c24b,refuted); 0::status(o_2630f44fe0e5b747c24b,unknown).
0::status(o_2637fe5c35e3f75cdb50,supported); 1::status(o_2637fe5c35e3f75cdb50,refuted); 0::status(o_2637fe5c35e3f75cdb50,unknown).
1::status(o_264b090fd927b1839032,supported); 0::status(o_264b090fd927b1839032,refuted); 0::status(o_264b090fd927b1839032,unknown).
0.0033596660356459839::status(o_2660a0f3072cc3cbb448,supported); 0::status(o_2660a0f3072cc3cbb448,refuted); 0.99664033396435403::status(o_2660a0f3072cc3cbb448,unknown).
0.99999927408378753::status(o_26aa38a902d5110ade35,supported); 0::status(o_26aa38a902d5110ade35,refuted); 7.2591621247397597e-07::status(o_26aa38a902d5110ade35,unknown).
0.00013119971225404874::status(o_27067b9952b6212d7904,supported); 0::status(o_27067b9952b6212d7904,refuted); 0.99986880028774594::status(o_27067b9952b6212d7904,unknown).
0.99998812204089271::status(o_272248f7750133d23ce8,supported); 0::status(o_272248f7750133d23ce8,refuted); 1.1877959107287062e-05::status(o_272248f7750133d23ce8,unknown).
0.00010130231256763193::status(o_2740050efa21cd8e3ad2,supported); 0::status(o_2740050efa21cd8e3ad2,refuted); 0.99989869768743234::status(o_2740050efa21cd8e3ad2,unknown).
0.018944852536761814::status(o_274a0082d9863aaa056e,supported); 0::status(o_274a0082d9863aaa056e,refuted); 0.98105514746323819::status(o_274a0082d9863aaa056e,unknown).
1::status(o_282b0eeede0e2ae213dc,supported); 0::status(o_282b0eeede0e2ae213dc,refuted); 0::status(o_282b0eeede0e2ae213dc,unknown).
0.96967961634467392::status(o_282dbf326fc43e737c39,supported); 0::status(o_282dbf326fc43e737c39,refuted); 0.030320383655326077::status(o_282dbf326fc43e737c39,unknown).
0.99999992580897223::status(o_283c893c4045ed4f9918,supported); 0::status(o_283c893c4045ed4f9918,refuted); 7.4191027765735384e-08::status(o_283c893c4045ed4f9918,unknown).
0.00074594078844149683::status(o_296c9c4edd26bae1a7f0,supported); 0::status(o_296c9c4edd26bae1a7f0,refuted); 0.99925405921155852::status(o_296c9c4edd26bae1a7f0,unknown).
6.5963271696655905e-06::status(o_296d9c71e10224e5b0f4,supported); 0::status(o_296d9c71e10224e5b0f4,refuted); 0.99999340367283029::status(o_296d9c71e10224e5b0f4,unknown).
1::status(o_29bd8a4271e36d52eb72,supported); 0::status(o_29bd8a4271e36d52eb72,refuted); 0::status(o_29bd8a4271e36d52eb72,unknown).
0.96754372119903564::status(o_29fdb58d4dfee7e97189,supported); 0::status(o_29fdb58d4dfee7e97189,refuted); 0.032456278800964355::status(o_29fdb58d4dfee7e97189,unknown).
0.00026037926617243477::status(o_2a3fe068f3e204ca5991,supported); 0::status(o_2a3fe068f3e204ca5991,refuted); 0.99973962073382761::status(o_2a3fe068f3e204ca5991,unknown).
1.1945303317492204e-07::status(o_2ac8eea810660c0b3b32,supported); 0::status(o_2ac8eea810660c0b3b32,refuted); 0.99999988054696687::status(o_2ac8eea810660c0b3b32,unknown).
0.99876297288292504::status(o_2acadda5d9f63382bd08,supported); 0::status(o_2acadda5d9f63382bd08,refuted); 0.0012370271170749625::status(o_2acadda5d9f63382bd08,unknown).
0.65991017137378538::status(o_2adfb24f0a65efca5cd6,supported); 0::status(o_2adfb24f0a65efca5cd6,refuted); 0.34008982862621462::status(o_2adfb24f0a65efca5cd6,unknown).
0.0048420415206189274::status(o_2b0d4fddbf0ec894eae7,supported); 0::status(o_2b0d4fddbf0ec894eae7,refuted); 0.99515795847938104::status(o_2b0d4fddbf0ec894eae7,unknown).
1.1341866148431104e-06::status(o_2b2116d29fb3b1d86af2,supported); 0::status(o_2b2116d29fb3b1d86af2,refuted); 0.99999886581338515::status(o_2b2116d29fb3b1d86af2,unknown).
1::status(o_2b21617586bcbfdbab61,supported); 0::status(o_2b21617586bcbfdbab61,refuted); 0::status(o_2b21617586bcbfdbab61,unknown).
0.61071423813271009::status(o_2b2aaff05c389ae3b6e5,supported); 0::status(o_2b2aaff05c389ae3b6e5,refuted); 0.38928576186728991::status(o_2b2aaff05c389ae3b6e5,unknown).
0.42642668777506293::status(o_2b6cf098123b11dca966,supported); 0::status(o_2b6cf098123b11dca966,refuted); 0.57357331222493713::status(o_2b6cf098123b11dca966,unknown).
1::status(o_2b742144c90c2edf86af,supported); 0::status(o_2b742144c90c2edf86af,refuted); 0::status(o_2b742144c90c2edf86af,unknown).
1.7531706077486635e-05::status(o_2be3909b8275e551a030,supported); 0::status(o_2be3909b8275e551a030,refuted); 0.99998246829392257::status(o_2be3909b8275e551a030,unknown).
1::status(o_2c0c82c2ab7a93b68682,supported); 0::status(o_2c0c82c2ab7a93b68682,refuted); 0::status(o_2c0c82c2ab7a93b68682,unknown).
0.99989653443063942::status(o_2c1838410301abfacbe3,supported); 0::status(o_2c1838410301abfacbe3,refuted); 0.00010346556936058349::status(o_2c1838410301abfacbe3,unknown).
1.7692152154538707e-05::status(o_2cb73e287f98e50f148d,supported); 0::status(o_2cb73e287f98e50f148d,refuted); 0.99998230784784548::status(o_2cb73e287f98e50f148d,unknown).
1::status(o_2d399fcd8fa0152f0695,supported); 0::status(o_2d399fcd8fa0152f0695,refuted); 0::status(o_2d399fcd8fa0152f0695,unknown).
0.00026651250664144754::status(o_2d6e1ac9ff6bbdb38d2b,supported); 0::status(o_2d6e1ac9ff6bbdb38d2b,refuted); 0.99973348749335855::status(o_2d6e1ac9ff6bbdb38d2b,unknown).
0.99999983246230739::status(o_2da9dad26d0d185ff038,supported); 0::status(o_2da9dad26d0d185ff038,refuted); 1.6753769260802187e-07::status(o_2da9dad26d0d185ff038,unknown).
1::status(o_2db7d1b502b9c07adf60,supported); 0::status(o_2db7d1b502b9c07adf60,refuted); 0::status(o_2db7d1b502b9c07adf60,unknown).
1.1399314962425972e-06::status(o_2de567a8891ebacadb02,supported); 0::status(o_2de567a8891ebacadb02,refuted); 0.9999988600685038::status(o_2de567a8891ebacadb02,unknown).
0.10388609021902084::status(o_2df00fd361a432eb191f,supported); 0::status(o_2df00fd361a432eb191f,refuted); 0.89611390978097916::status(o_2df00fd361a432eb191f,unknown).
0.00050635967636480927::status(o_2e51ed694e2c552883b3,supported); 0::status(o_2e51ed694e2c552883b3,refuted); 0.99949364032363519::status(o_2e51ed694e2c552883b3,unknown).
1::status(o_2e6a6d2fe5da3f78515b,supported); 0::status(o_2e6a6d2fe5da3f78515b,refuted); 0::status(o_2e6a6d2fe5da3f78515b,unknown).
0.003354658596551997::status(o_2ea9f04f17caf58744f9,supported); 0::status(o_2ea9f04f17caf58744f9,refuted); 0.99664534140344796::status(o_2ea9f04f17caf58744f9,unknown).
0.99999851230450709::status(o_2f13f140666921abe284,supported); 0::status(o_2f13f140666921abe284,refuted); 1.4876954929077257e-06::status(o_2f13f140666921abe284,unknown).
0.99999996500192156::status(o_2fb7ab23989ea0ad8036,supported); 0::status(o_2fb7ab23989ea0ad8036,refuted); 3.49980784353221e-08::status(o_2fb7ab23989ea0ad8036,unknown).
1::status(o_2fc41054333cfcecb34a,supported); 0::status(o_2fc41054333cfcecb34a,refuted); 0::status(o_2fc41054333cfcecb34a,unknown).
0.00035502800062487452::status(o_2fe345f0929505a8b534,supported); 0::status(o_2fe345f0929505a8b534,refuted); 0.99964497199937508::status(o_2fe345f0929505a8b534,unknown).
1::status(o_2ff2e6bf13961fba2c64,supported); 0::status(o_2ff2e6bf13961fba2c64,refuted); 0::status(o_2ff2e6bf13961fba2c64,unknown).
1::status(o_30130703a48919500408,supported); 0::status(o_30130703a48919500408,refuted); 0::status(o_30130703a48919500408,unknown).
1.3034778761802781e-06::status(o_30a204659967732bdbf8,supported); 0::status(o_30a204659967732bdbf8,refuted); 0.99999869652212381::status(o_30a204659967732bdbf8,unknown).
5.95479684862836e-09::status(o_30aba41fcae31f3066a3,supported); 0::status(o_30aba41fcae31f3066a3,refuted); 0.99999999404520312::status(o_30aba41fcae31f3066a3,unknown).
0.26025130424020321::status(o_30df118d33e1851c9db8,supported); 0::status(o_30df118d33e1851c9db8,refuted); 0.73974869575979674::status(o_30df118d33e1851c9db8,unknown).
1::status(o_30ef72946975fd41249f,supported); 0::status(o_30ef72946975fd41249f,refuted); 0::status(o_30ef72946975fd41249f,unknown).
0::status(o_30f0596f3e8b3bef1789,supported); 1::status(o_30f0596f3e8b3bef1789,refuted); 0::status(o_30f0596f3e8b3bef1789,unknown).
5.9323157161615858e-09::status(o_30f3367f6f30cf4082df,supported); 0::status(o_30f3367f6f30cf4082df,refuted); 0.99999999406768425::status(o_30f3367f6f30cf4082df,unknown).
1::status(o_314d238ce7873f35a435,supported); 0::status(o_314d238ce7873f35a435,refuted); 0::status(o_314d238ce7873f35a435,unknown).
0.00019939233607146889::status(o_318793ebc83a0cec6566,supported); 0::status(o_318793ebc83a0cec6566,refuted); 0.99980060766392853::status(o_318793ebc83a0cec6566,unknown).
0.99999998873827356::status(o_31b7f88749056815651e,supported); 0::status(o_31b7f88749056815651e,refuted); 1.126172644028145e-08::status(o_31b7f88749056815651e,unknown).
0.00086517402650655359::status(o_31b92fcc81d2fd7a9544,supported); 0::status(o_31b92fcc81d2fd7a9544,refuted); 0.99913482597349346::status(o_31b92fcc81d2fd7a9544,unknown).
0.15455253835212221::status(o_321c02242be4a6778f5f,supported); 0::status(o_321c02242be4a6778f5f,refuted); 0.84544746164787776::status(o_321c02242be4a6778f5f,unknown).
0.99999844166479634::status(o_326dd4f570d38427114f,supported); 0::status(o_326dd4f570d38427114f,refuted); 1.5583352036552256e-06::status(o_326dd4f570d38427114f,unknown).
0::status(o_3278e76aa9601a814674,supported); 1::status(o_3278e76aa9601a814674,refuted); 0::status(o_3278e76aa9601a814674,unknown).
0.00027939380379393697::status(o_32896d1f7c85554fa055,supported); 0::status(o_32896d1f7c85554fa055,refuted); 0.99972060619620606::status(o_32896d1f7c85554fa055,unknown).
0.96967961634467392::status(o_3294134d8b4a702b7b5a,supported); 0::status(o_3294134d8b4a702b7b5a,refuted); 0.030320383655326077::status(o_3294134d8b4a702b7b5a,unknown).
0.99385096469335199::status(o_32a0d32a2aacd26e41ee,supported); 0::status(o_32a0d32a2aacd26e41ee,refuted); 0.0061490353066480097::status(o_32a0d32a2aacd26e41ee,unknown).
8.3507141241693934e-06::status(o_33874f958a8f1176dbfb,supported); 0::status(o_33874f958a8f1176dbfb,refuted); 0.99999164928587581::status(o_33874f958a8f1176dbfb,unknown).
7.9832112533040345e-05::status(o_3396687cda575dc277f5,supported); 0::status(o_3396687cda575dc277f5,refuted); 0.99992016788746696::status(o_3396687cda575dc277f5,unknown).
0.99999979749184909::status(o_33ba4315c21af1a92d64,supported); 0::status(o_33ba4315c21af1a92d64,refuted); 2.0250815091493735e-07::status(o_33ba4315c21af1a92d64,unknown).
0.99896850369236945::status(o_344f646fd75ef8a83548,supported); 0::status(o_344f646fd75ef8a83548,refuted); 0.0010314963076305528::status(o_344f646fd75ef8a83548,unknown).
0.00010203728353087578::status(o_3484bc933ea05303150c,supported); 0::status(o_3484bc933ea05303150c,refuted); 0.99989796271646914::status(o_3484bc933ea05303150c,unknown).
7.618703582816562e-09::status(o_34850de3a5531348864d,supported); 0::status(o_34850de3a5531348864d,refuted); 0.99999999238129644::status(o_34850de3a5531348864d,unknown).
8.2629048319032865e-06::status(o_34bc8813119604fd76c4,supported); 0::status(o_34bc8813119604fd76c4,refuted); 0.99999173709516809::status(o_34bc8813119604fd76c4,unknown).
0.0043052313349343447::status(o_34d68d86ef3511666221,supported); 0::status(o_34d68d86ef3511666221,refuted); 0.99569476866506568::status(o_34d68d86ef3511666221,unknown).
0.36756375367835886::status(o_34ff47e94f640bd7afd1,supported); 0::status(o_34ff47e94f640bd7afd1,refuted); 0.63243624632164108::status(o_34ff47e94f640bd7afd1,unknown).
0.99999987123526379::status(o_3508e4edb9b5d6b43b21,supported); 0::status(o_3508e4edb9b5d6b43b21,refuted); 1.2876473620693218e-07::status(o_3508e4edb9b5d6b43b21,unknown).
1::status(o_3586b0880e9c45194d1e,supported); 0::status(o_3586b0880e9c45194d1e,refuted); 0::status(o_3586b0880e9c45194d1e,unknown).
1::status(o_35b1d6162f2df5cc7432,supported); 0::status(o_35b1d6162f2df5cc7432,refuted); 0::status(o_35b1d6162f2df5cc7432,unknown).
0.0018071738304570317::status(o_35b52544c4bf9af370f1,supported); 0::status(o_35b52544c4bf9af370f1,refuted); 0.99819282616954297::status(o_35b52544c4bf9af370f1,unknown).
1::status(o_35fb0c4f19ff888aa014,supported); 0::status(o_35fb0c4f19ff888aa014,refuted); 0::status(o_35fb0c4f19ff888aa014,unknown).
0.99999999827831965::status(o_36ccb9b936c01024b2fe,supported); 0::status(o_36ccb9b936c01024b2fe,refuted); 1.7216803538389058e-09::status(o_36ccb9b936c01024b2fe,unknown).
0::status(o_381640a894caa1ee3ebf,supported); 1::status(o_381640a894caa1ee3ebf,refuted); 0::status(o_381640a894caa1ee3ebf,unknown).
2.9835346984907715e-06::status(o_3816a9ef8f5d9c8e70c5,supported); 0::status(o_3816a9ef8f5d9c8e70c5,refuted); 0.99999701646530148::status(o_3816a9ef8f5d9c8e70c5,unknown).
0.65991017137378538::status(o_382f6ff7294f8b5ac697,supported); 0::status(o_382f6ff7294f8b5ac697,refuted); 0.34008982862621462::status(o_382f6ff7294f8b5ac697,unknown).
0.0037578577175736427::status(o_384a7d5237a5ebc767c1,supported); 0::status(o_384a7d5237a5ebc767c1,refuted); 0.99624214228242636::status(o_384a7d5237a5ebc767c1,unknown).
0.56514988456671289::status(o_38515954ea72f56b822b,supported); 0::status(o_38515954ea72f56b822b,refuted); 0.43485011543328711::status(o_38515954ea72f56b822b,unknown).
0.99506819248199463::status(o_3865ba0a763bf419dcfd,supported); 0::status(o_3865ba0a763bf419dcfd,refuted); 0.0049318075180053711::status(o_3865ba0a763bf419dcfd,unknown).
4.1598854149835274e-07::status(o_38dfd6e95d981f9e3808,supported); 0::status(o_38dfd6e95d981f9e3808,refuted); 0.9999995840114585::status(o_38dfd6e95d981f9e3808,unknown).
1::status(o_390f38eba41b0d7a0394,supported); 0::status(o_390f38eba41b0d7a0394,refuted); 0::status(o_390f38eba41b0d7a0394,unknown).
1::status(o_396aca41adbc1fecbc40,supported); 0::status(o_396aca41adbc1fecbc40,refuted); 0::status(o_396aca41adbc1fecbc40,unknown).
0::status(o_3983783991258ab58391,supported); 1::status(o_3983783991258ab58391,refuted); 0::status(o_3983783991258ab58391,unknown).
0.9999996697685809::status(o_39c32c530e2e6fe49876,supported); 0::status(o_39c32c530e2e6fe49876,refuted); 3.3023141909893639e-07::status(o_39c32c530e2e6fe49876,unknown).
0.00012811402848456055::status(o_39d4ad977e6f3ce625bd,supported); 0::status(o_39d4ad977e6f3ce625bd,refuted); 0.99987188597151544::status(o_39d4ad977e6f3ce625bd,unknown).
0::status(o_39e0bff00f1d8c29ba36,supported); 1::status(o_39e0bff00f1d8c29ba36,refuted); 0::status(o_39e0bff00f1d8c29ba36,unknown).
0.99999692912085059::status(o_3a42a93554340f05abf1,supported); 0::status(o_3a42a93554340f05abf1,refuted); 3.070879149413841e-06::status(o_3a42a93554340f05abf1,unknown).
1::status(o_3a57806343106f021d86,supported); 0::status(o_3a57806343106f021d86,refuted); 0::status(o_3a57806343106f021d86,unknown).
0.99999999306661269::status(o_3a6a0c07300ab56a96d9,supported); 0::status(o_3a6a0c07300ab56a96d9,refuted); 6.9333873087273901e-09::status(o_3a6a0c07300ab56a96d9,unknown).
0.002602787222713232::status(o_3a783aa140d9a331e149,supported); 0::status(o_3a783aa140d9a331e149,refuted); 0.99739721277728677::status(o_3a783aa140d9a331e149,unknown).
1::status(o_3a9ccd4264b4c28b9828,supported); 0::status(o_3a9ccd4264b4c28b9828,refuted); 0::status(o_3a9ccd4264b4c28b9828,unknown).
0.9999997374770605::status(o_3ab2d5644fce35f21d63,supported); 0::status(o_3ab2d5644fce35f21d63,refuted); 2.6252293949813321e-07::status(o_3ab2d5644fce35f21d63,unknown).
0.2129049152135849::status(o_3ae6fded58dbf316a781,supported); 0::status(o_3ae6fded58dbf316a781,refuted); 0.7870950847864151::status(o_3ae6fded58dbf316a781,unknown).
1::status(o_3c80799815bd65d38e24,supported); 0::status(o_3c80799815bd65d38e24,refuted); 0::status(o_3c80799815bd65d38e24,unknown).
0.0010746419297370359::status(o_3c94decaae2a28b334fd,supported); 0::status(o_3c94decaae2a28b334fd,refuted); 0.99892535807026295::status(o_3c94decaae2a28b334fd,unknown).
2.2700603234613133e-05::status(o_3d4ff69b6aa37cceb461,supported); 0::status(o_3d4ff69b6aa37cceb461,refuted); 0.99997729939676538::status(o_3d4ff69b6aa37cceb461,unknown).
7.618703582816562e-09::status(o_3d5a8913b1d0b7f98e9f,supported); 0::status(o_3d5a8913b1d0b7f98e9f,refuted); 0.99999999238129644::status(o_3d5a8913b1d0b7f98e9f,unknown).
0.00093610340901188077::status(o_3dae32fe8363083ec938,supported); 0::status(o_3dae32fe8363083ec938,refuted); 0.99906389659098815::status(o_3dae32fe8363083ec938,unknown).
2.8278058427373192e-08::status(o_3db065b60ed8c77853f6,supported); 0::status(o_3db065b60ed8c77853f6,refuted); 0.99999997172194155::status(o_3db065b60ed8c77853f6,unknown).
1.5218837849288215e-05::status(o_3db708494f75baca5c3b,supported); 0::status(o_3db708494f75baca5c3b,refuted); 0.99998478116215073::status(o_3db708494f75baca5c3b,unknown).
1.9659593271839971e-07::status(o_3df249eed57e0f5b175a,supported); 0::status(o_3df249eed57e0f5b175a,refuted); 0.99999980340406724::status(o_3df249eed57e0f5b175a,unknown).
0.0092268962651216643::status(o_3e7654f5eff05ce9a048,supported); 0::status(o_3e7654f5eff05ce9a048,refuted); 0.99077310373487837::status(o_3e7654f5eff05ce9a048,unknown).
1::status(o_3eb98e1a537974471e6e,supported); 0::status(o_3eb98e1a537974471e6e,refuted); 0::status(o_3eb98e1a537974471e6e,unknown).
0.93599168147::status(o_3ec308e56f1ec36fbd08,supported); 0::status(o_3ec308e56f1ec36fbd08,refuted); 0.064008318529999997::status(o_3ec308e56f1ec36fbd08,unknown).
0.0044489046558737755::status(o_3efa494945075eb5cc33,supported); 0::status(o_3efa494945075eb5cc33,refuted); 0.99555109534412622::status(o_3efa494945075eb5cc33,unknown).
0.99999811428839869::status(o_3f685faf47a733f1ec45,supported); 0::status(o_3f685faf47a733f1ec45,refuted); 1.8857116013126785e-06::status(o_3f685faf47a733f1ec45,unknown).
1::status(o_3f7c8f381b2138305165,supported); 0::status(o_3f7c8f381b2138305165,refuted); 0::status(o_3f7c8f381b2138305165,unknown).
1::status(o_3f7f52bce0c1f3f89081,supported); 0::status(o_3f7f52bce0c1f3f89081,refuted); 0::status(o_3f7f52bce0c1f3f89081,unknown).
0::status(o_3fd0b3a7fba382f3da26,supported); 1::status(o_3fd0b3a7fba382f3da26,refuted); 0::status(o_3fd0b3a7fba382f3da26,unknown).
0::status(o_402b2f1d4ab0ce6df786,supported); 1::status(o_402b2f1d4ab0ce6df786,refuted); 0::status(o_402b2f1d4ab0ce6df786,unknown).
0.98928332328796387::status(o_4057f2a0b396a206be2d,supported); 0::status(o_4057f2a0b396a206be2d,refuted); 0.010716676712036133::status(o_4057f2a0b396a206be2d,unknown).
0.99999882968458842::status(o_4113fad32ff4a272b1f2,supported); 0::status(o_4113fad32ff4a272b1f2,refuted); 1.1703154115805248e-06::status(o_4113fad32ff4a272b1f2,unknown).
1::status(o_4139c0be4d60ab6af521,supported); 0::status(o_4139c0be4d60ab6af521,refuted); 0::status(o_4139c0be4d60ab6af521,unknown).
0.9999483373762641::status(o_416e5e94197e85645ab7,supported); 0::status(o_416e5e94197e85645ab7,refuted); 5.1662623735904134e-05::status(o_416e5e94197e85645ab7,unknown).
0.9998293912531433::status(o_4171044df128b0a97450,supported); 0::status(o_4171044df128b0a97450,refuted); 0.00017060874685670413::status(o_4171044df128b0a97450,unknown).
0.00044824578799307346::status(o_418c81c5d740dcfd54e2,supported); 0::status(o_418c81c5d740dcfd54e2,refuted); 0.99955175421200693::status(o_418c81c5d740dcfd54e2,unknown).
0.00086517402650655359::status(o_41a9251a68555c8893e4,supported); 0::status(o_41a9251a68555c8893e4,refuted); 0.99913482597349346::status(o_41a9251a68555c8893e4,unknown).
8.8334579666288478e-07::status(o_41dc8c7343eab021b49c,supported); 0::status(o_41dc8c7343eab021b49c,refuted); 0.99999911665420338::status(o_41dc8c7343eab021b49c,unknown).
0.97427183389663696::status(o_41eccfe5d76a353aca66,supported); 0::status(o_41eccfe5d76a353aca66,refuted); 0.025728166103363037::status(o_41eccfe5d76a353aca66,unknown).
1::status(o_41f64795b55d5ec5c7f4,supported); 0::status(o_41f64795b55d5ec5c7f4,refuted); 0::status(o_41f64795b55d5ec5c7f4,unknown).
0.00036025015354824991::status(o_421567c8da13534f2a16,supported); 0::status(o_421567c8da13534f2a16,refuted); 0.99963974984645176::status(o_421567c8da13534f2a16,unknown).
0.00035502800062487452::status(o_428b655d6a5d5b500205,supported); 0::status(o_428b655d6a5d5b500205,refuted); 0.99964497199937508::status(o_428b655d6a5d5b500205,unknown).
0.99999945813975577::status(o_42a022bc0e832aa24be9,supported); 0::status(o_42a022bc0e832aa24be9,refuted); 5.4186024422975265e-07::status(o_42a022bc0e832aa24be9,unknown).
0.0013122661039233208::status(o_42c3db54e399f7219f4d,supported); 0::status(o_42c3db54e399f7219f4d,refuted); 0.99868773389607668::status(o_42c3db54e399f7219f4d,unknown).
8.4610291128067943e-06::status(o_42fdcfd91b3bb54f75ec,supported); 0::status(o_42fdcfd91b3bb54f75ec,refuted); 0.99999153897088722::status(o_42fdcfd91b3bb54f75ec,unknown).
0.00048787630967903365::status(o_436b2fb505dcd7e18488,supported); 0::status(o_436b2fb505dcd7e18488,refuted); 0.99951212369032094::status(o_436b2fb505dcd7e18488,unknown).
0.99738341569900513::status(o_4375e605e7ec70625eb4,supported); 0::status(o_4375e605e7ec70625eb4,refuted); 0.002616584300994873::status(o_4375e605e7ec70625eb4,unknown).
0.0005490043549798429::status(o_43e88a49e533a5c3591b,supported); 0::status(o_43e88a49e533a5c3591b,refuted); 0.99945099564502016::status(o_43e88a49e533a5c3591b,unknown).
0.00019939233607146889::status(o_43ef585e02abace9d3ba,supported); 0::status(o_43ef585e02abace9d3ba,refuted); 0.99980060766392853::status(o_43ef585e02abace9d3ba,unknown).
0.99977468029036498::status(o_441e919acce0edfe56ab,supported); 0::status(o_441e919acce0edfe56ab,refuted); 0.00022531970963501902::status(o_441e919acce0edfe56ab,unknown).
7.6279627133513372e-09::status(o_4487134dde9b7abefcae,supported); 0::status(o_4487134dde9b7abefcae,refuted); 0.99999999237203729::status(o_4487134dde9b7abefcae,unknown).
1::status(o_44eb32fe2101f3c40478,supported); 0::status(o_44eb32fe2101f3c40478,refuted); 0::status(o_44eb32fe2101f3c40478,unknown).
1.3842511524140808e-05::status(o_44fcb59128352ed85c2a,supported); 0::status(o_44fcb59128352ed85c2a,refuted); 0.99998615748847586::status(o_44fcb59128352ed85c2a,unknown).
0.998406055936786::status(o_450a028c5fa80cc11da4,supported); 0::status(o_450a028c5fa80cc11da4,refuted); 0.0015939440632140034::status(o_450a028c5fa80cc11da4,unknown).
0.99726450443267822::status(o_4512c0e13994a0d98fd1,supported); 0::status(o_4512c0e13994a0d98fd1,refuted); 0.0027354955673217773::status(o_4512c0e13994a0d98fd1,unknown).
9.8864622903377894e-09::status(o_451c7e569e3d3e169268,supported); 0::status(o_451c7e569e3d3e169268,refuted); 0.99999999011353768::status(o_451c7e569e3d3e169268,unknown).
7.9219131214654283e-05::status(o_4527326328e39f266016,supported); 0::status(o_4527326328e39f266016,refuted); 0.99992078086878533::status(o_4527326328e39f266016,unknown).
0.99999597388339545::status(o_45803550c0c23f5ca629,supported); 0::status(o_45803550c0c23f5ca629,refuted); 4.0261166045496566e-06::status(o_45803550c0c23f5ca629,unknown).
1::status(o_458b18f8f3b02d7e4147,supported); 0::status(o_458b18f8f3b02d7e4147,refuted); 0::status(o_458b18f8f3b02d7e4147,unknown).
1::status(o_45fb76a0eee3994f484f,supported); 0::status(o_45fb76a0eee3994f484f,refuted); 0::status(o_45fb76a0eee3994f484f,unknown).
0.4066462516784668::status(o_461a53eab86e82340b41,supported); 0::status(o_461a53eab86e82340b41,refuted); 0.5933537483215332::status(o_461a53eab86e82340b41,unknown).
0.98993896128776182::status(o_4652dffdd9046fb67582,supported); 0::status(o_4652dffdd9046fb67582,refuted); 0.010061038712238179::status(o_4652dffdd9046fb67582,unknown).
0.99964323617997897::status(o_468147b8b61a40ed50e6,supported); 0::status(o_468147b8b61a40ed50e6,refuted); 0.00035676382002103324::status(o_468147b8b61a40ed50e6,unknown).
1.3842511524140808e-05::status(o_46880351d762613f194c,supported); 0::status(o_46880351d762613f194c,refuted); 0.99998615748847586::status(o_46880351d762613f194c,unknown).
0.40537978642262851::status(o_468ed5709f6b9cef5906,supported); 0::status(o_468ed5709f6b9cef5906,refuted); 0.59462021357737149::status(o_468ed5709f6b9cef5906,unknown).
0.018792862408150444::status(o_46a9f62215ff0d8265be,supported); 0::status(o_46a9f62215ff0d8265be,refuted); 0.98120713759184952::status(o_46a9f62215ff0d8265be,unknown).
0.9999995818080889::status(o_46aa2f76a579837492d4,supported); 0::status(o_46aa2f76a579837492d4,refuted); 4.1819191110015197e-07::status(o_46aa2f76a579837492d4,unknown).
0.00035556388320401311::status(o_46f81eb23b33e03bc5af,supported); 0::status(o_46f81eb23b33e03bc5af,refuted); 0.99964443611679599::status(o_46f81eb23b33e03bc5af,unknown).
0.99977876665451038::status(o_483133157e868f685560,supported); 0::status(o_483133157e868f685560,refuted); 0.00022123334548962426::status(o_483133157e868f685560,unknown).
0.02884664386510849::status(o_48d07ce9509d549dc25d,supported); 0::status(o_48d07ce9509d549dc25d,refuted); 0.97115335613489151::status(o_48d07ce9509d549dc25d,unknown).
0.00035134500389086433::status(o_495977da048a9673bb6a,supported); 0::status(o_495977da048a9673bb6a,refuted); 0.99964865499610911::status(o_495977da048a9673bb6a,unknown).
1::status(o_49b54e5364d8c3f7c68c,supported); 0::status(o_49b54e5364d8c3f7c68c,refuted); 0::status(o_49b54e5364d8c3f7c68c,unknown).
0.9999947693734208::status(o_49cb2fb72a56a876de5b,supported); 0::status(o_49cb2fb72a56a876de5b,refuted); 5.2306265792001483e-06::status(o_49cb2fb72a56a876de5b,unknown).
1::status(o_49e77356060fc4068c06,supported); 0::status(o_49e77356060fc4068c06,refuted); 0::status(o_49e77356060fc4068c06,unknown).
3.5982731700619071e-09::status(o_4a4bf1d0fdd1fced519e,supported); 0::status(o_4a4bf1d0fdd1fced519e,refuted); 0.99999999640172688::status(o_4a4bf1d0fdd1fced519e,unknown).
0::status(o_4a64b449a54269fec3a4,supported); 1::status(o_4a64b449a54269fec3a4,refuted); 0::status(o_4a64b449a54269fec3a4,unknown).
0.99999992580897223::status(o_4a9f99d0282d3c9de002,supported); 0::status(o_4a9f99d0282d3c9de002,refuted); 7.4191027765735384e-08::status(o_4a9f99d0282d3c9de002,unknown).
1.1945303317492204e-07::status(o_4aa9ec4ec4cf47f8b4da,supported); 0::status(o_4aa9ec4ec4cf47f8b4da,refuted); 0.99999988054696687::status(o_4aa9ec4ec4cf47f8b4da,unknown).
0.97427183389663696::status(o_4abdc732aa9fde88ff8d,supported); 0::status(o_4abdc732aa9fde88ff8d,refuted); 0.025728166103363037::status(o_4abdc732aa9fde88ff8d,unknown).
0::status(o_4b458ad808b682de0273,supported); 1::status(o_4b458ad808b682de0273,refuted); 0::status(o_4b458ad808b682de0273,unknown).
0.70547658205032349::status(o_4b69ce6f08ef602eb19e,supported); 0::status(o_4b69ce6f08ef602eb19e,refuted); 0.29452341794967651::status(o_4b69ce6f08ef602eb19e,unknown).
0.976348876953125::status(o_4b8ecb25124d4c821496,supported); 0::status(o_4b8ecb25124d4c821496,refuted); 0.023651123046875::status(o_4b8ecb25124d4c821496,unknown).
0.99999811567972463::status(o_4b9a9da51e26ac206ccc,supported); 0::status(o_4b9a9da51e26ac206ccc,refuted); 1.8843202753693333e-06::status(o_4b9a9da51e26ac206ccc,unknown).
1::status(o_4c8442e408e665cc6396,supported); 0::status(o_4c8442e408e665cc6396,refuted); 0::status(o_4c8442e408e665cc6396,unknown).
2.9215075622410366e-05::status(o_4cd71c0b183188133301,supported); 0::status(o_4cd71c0b183188133301,refuted); 0.99997078492437763::status(o_4cd71c0b183188133301,unknown).
1.9659593271839971e-07::status(o_4d3fb9f97ac8088eec0c,supported); 0::status(o_4d3fb9f97ac8088eec0c,refuted); 0.99999980340406724::status(o_4d3fb9f97ac8088eec0c,unknown).
0.99977876665451038::status(o_4d70ba639582eee3465a,supported); 0::status(o_4d70ba639582eee3465a,refuted); 0.00022123334548962426::status(o_4d70ba639582eee3465a,unknown).
1::status(o_4d97b5f3cae689758f0b,supported); 0::status(o_4d97b5f3cae689758f0b,refuted); 0::status(o_4d97b5f3cae689758f0b,unknown).
0.99998772104878231::status(o_4dce5c29c2f6ac42cb1c,supported); 0::status(o_4dce5c29c2f6ac42cb1c,refuted); 1.2278951217692402e-05::status(o_4dce5c29c2f6ac42cb1c,unknown).
0.015547662042081356::status(o_4dff44d0f78f37e81bb1,supported); 0::status(o_4dff44d0f78f37e81bb1,refuted); 0.98445233795791864::status(o_4dff44d0f78f37e81bb1,unknown).
2.9022342199702556e-05::status(o_4e59651f9d07fdd29fc1,supported); 0::status(o_4e59651f9d07fdd29fc1,refuted); 0.9999709776578003::status(o_4e59651f9d07fdd29fc1,unknown).
0.00030407517731461102::status(o_4e6ce6b894bc99a91cfa,supported); 0::status(o_4e6ce6b894bc99a91cfa,refuted); 0.99969592482268543::status(o_4e6ce6b894bc99a91cfa,unknown).
1.5297249606975189e-07::status(o_4e8bde75705a59e53deb,supported); 0::status(o_4e8bde75705a59e53deb,refuted); 0.99999984702750389::status(o_4e8bde75705a59e53deb,unknown).
0.00021535077497592163::status(o_4eedf291829845e0033a,supported); 0::status(o_4eedf291829845e0033a,refuted); 0.99978464922502408::status(o_4eedf291829845e0033a,unknown).
0::status(o_4ef8985688890ab10c08,supported); 1::status(o_4ef8985688890ab10c08,refuted); 0::status(o_4ef8985688890ab10c08,unknown).
0.9999815690971734::status(o_4eff13f464b8361fe6a7,supported); 0::status(o_4eff13f464b8361fe6a7,refuted); 1.8430902826604978e-05::status(o_4eff13f464b8361fe6a7,unknown).
0.016417878034424356::status(o_4f3b6b2724edb6a69972,supported); 0::status(o_4f3b6b2724edb6a69972,refuted); 0.9835821219655756::status(o_4f3b6b2724edb6a69972,unknown).
0.99810886383056641::status(o_4fd3ccf9c7eb5d3e082d,supported); 0::status(o_4fd3ccf9c7eb5d3e082d,refuted); 0.0018911361694335938::status(o_4fd3ccf9c7eb5d3e082d,unknown).
5.6871512399229536e-07::status(o_50144a626201feee3c3f,supported); 0::status(o_50144a626201feee3c3f,refuted); 0.99999943128487601::status(o_50144a626201feee3c3f,unknown).
0.003689546836540103::status(o_5019c49e1e444762f405,supported); 0::status(o_5019c49e1e444762f405,refuted); 0.9963104531634599::status(o_5019c49e1e444762f405,unknown).
1.0724153266763563e-05::status(o_50d118dc80796a4f69b2,supported); 0::status(o_50d118dc80796a4f69b2,refuted); 0.99998927584673325::status(o_50d118dc80796a4f69b2,unknown).
0.31135774259586463::status(o_50d48a5f37d08a31f7e4,supported); 0::status(o_50d48a5f37d08a31f7e4,refuted); 0.68864225740413532::status(o_50d48a5f37d08a31f7e4,unknown).
0.99999804612923038::status(o_511980cebe672ee2eb96,supported); 0::status(o_511980cebe672ee2eb96,refuted); 1.953870769622057e-06::status(o_511980cebe672ee2eb96,unknown).
1::status(o_5139bfd40782e56ade39,supported); 0::status(o_5139bfd40782e56ade39,refuted); 0::status(o_5139bfd40782e56ade39,unknown).
0.99999096451664449::status(o_5152b8420dc74ba7527a,supported); 0::status(o_5152b8420dc74ba7527a,refuted); 9.0354833555128522e-06::status(o_5152b8420dc74ba7527a,unknown).
1::status(o_521e3a96e4acde4bdb2c,supported); 0::status(o_521e3a96e4acde4bdb2c,refuted); 0::status(o_521e3a96e4acde4bdb2c,unknown).
0.99660646915435791::status(o_523cf2e77a806947b8e8,supported); 0::status(o_523cf2e77a806947b8e8,refuted); 0.0033935308456420898::status(o_523cf2e77a806947b8e8,unknown).
8.3541615338853956e-06::status(o_5246e0da2191f9a4234c,supported); 0::status(o_5246e0da2191f9a4234c,refuted); 0.99999164583846611::status(o_5246e0da2191f9a4234c,unknown).
1.1945303317492204e-07::status(o_52d84e0df87b2cc31da2,supported); 0::status(o_52d84e0df87b2cc31da2,refuted); 0.99999988054696687::status(o_52d84e0df87b2cc31da2,unknown).
0.00038613700400698018::status(o_531a905a46459b40bc28,supported); 0::status(o_531a905a46459b40bc28,refuted); 0.99961386299599297::status(o_531a905a46459b40bc28,unknown).
0.00096378276237123986::status(o_537b1c90a503ff637d23,supported); 0::status(o_537b1c90a503ff637d23,refuted); 0.99903621723762881::status(o_537b1c90a503ff637d23,unknown).
0.00021535077497592163::status(o_54425c78960fea0fad18,supported); 0::status(o_54425c78960fea0fad18,refuted); 0.99978464922502408::status(o_54425c78960fea0fad18,unknown).
0.96967961634467392::status(o_544c70d32c85792699e0,supported); 0::status(o_544c70d32c85792699e0,refuted); 0.030320383655326077::status(o_544c70d32c85792699e0,unknown).
0.0007167395087890327::status(o_5452606a46537080ee77,supported); 0::status(o_5452606a46537080ee77,refuted); 0.99928326049121097::status(o_5452606a46537080ee77,unknown).
1::status(o_545903d715611c3bd136,supported); 0::status(o_545903d715611c3bd136,refuted); 0::status(o_545903d715611c3bd136,unknown).
7.9219131214654283e-05::status(o_5461327bf70d86853aa1,supported); 0::status(o_5461327bf70d86853aa1,refuted); 0.99992078086878533::status(o_5461327bf70d86853aa1,unknown).
0.99978179605165418::status(o_54750fcc5f0455b0c255,supported); 0::status(o_54750fcc5f0455b0c255,refuted); 0.00021820394834581869::status(o_54750fcc5f0455b0c255,unknown).
2.546949727292555e-07::status(o_54eb6b83cb6a4af86885,supported); 0::status(o_54eb6b83cb6a4af86885,refuted); 0.99999974530502722::status(o_54eb6b83cb6a4af86885,unknown).
0.98721271753311157::status(o_550af0d5d23f526f0080,supported); 0::status(o_550af0d5d23f526f0080,refuted); 0.012787282466888428::status(o_550af0d5d23f526f0080,unknown).
0.99999945813975577::status(o_55411322c155f2a8f5ab,supported); 0::status(o_55411322c155f2a8f5ab,refuted); 5.4186024422975265e-07::status(o_55411322c155f2a8f5ab,unknown).
1.1982675125189598e-07::status(o_555fa9e704c26288dbf5,supported); 0::status(o_555fa9e704c26288dbf5,refuted); 0.9999998801732487::status(o_555fa9e704c26288dbf5,unknown).
0.99999343413011421::status(o_559b4e01fff5fc1ae848,supported); 0::status(o_559b4e01fff5fc1ae848,refuted); 6.5658698857884445e-06::status(o_559b4e01fff5fc1ae848,unknown).
1.1982675125189598e-07::status(o_559d7d8d7712f2a958e8,supported); 0::status(o_559d7d8d7712f2a958e8,refuted); 0.9999998801732487::status(o_559d7d8d7712f2a958e8,unknown).
0.99535101332905751::status(o_55d322ff631c2f704b48,supported); 0::status(o_55d322ff631c2f704b48,refuted); 0.0046489866709424899::status(o_55d322ff631c2f704b48,unknown).
5.7750552951804822e-05::status(o_55da9749d00d2197a82f,supported); 0::status(o_55da9749d00d2197a82f,refuted); 0.99994224944704824::status(o_55da9749d00d2197a82f,unknown).
0::status(o_56182db54b551cf25838,supported); 1::status(o_56182db54b551cf25838,refuted); 0::status(o_56182db54b551cf25838,unknown).
1::status(o_5640a6b89b41f2e05596,supported); 0::status(o_5640a6b89b41f2e05596,refuted); 0::status(o_5640a6b89b41f2e05596,unknown).
0.015679161995649338::status(o_56a0272adfb08d9e9a92,supported); 0::status(o_56a0272adfb08d9e9a92,refuted); 0.98432083800435066::status(o_56a0272adfb08d9e9a92,unknown).
2.3938698023086402e-06::status(o_574a9f7f5028cc8c211c,supported); 0::status(o_574a9f7f5028cc8c211c,refuted); 0.99999760613019772::status(o_574a9f7f5028cc8c211c,unknown).
0.99999939047324271::status(o_57bc81ed67176903fbac,supported); 0::status(o_57bc81ed67176903fbac,refuted); 6.0952675728920269e-07::status(o_57bc81ed67176903fbac,unknown).
0.99981849066906681::status(o_57fc30281e3e092e5bff,supported); 0::status(o_57fc30281e3e092e5bff,refuted); 0.00018150933093319388::status(o_57fc30281e3e092e5bff,unknown).
0.59074564597745061::status(o_58a94025d672a25ca24e,supported); 0::status(o_58a94025d672a25ca24e,refuted); 0.40925435402254939::status(o_58a94025d672a25ca24e,unknown).
0.0070033296942710876::status(o_59adf45df3da0f7ba27d,supported); 0::status(o_59adf45df3da0f7ba27d,refuted); 0.99299667030572891::status(o_59adf45df3da0f7ba27d,unknown).
0.0041071532961066259::status(o_59fb0062c74428db12c2,supported); 0::status(o_59fb0062c74428db12c2,refuted); 0.99589284670389333::status(o_59fb0062c74428db12c2,unknown).
8.8376535664596482e-07::status(o_5a5deb07daea404e63b2,supported); 0::status(o_5a5deb07daea404e63b2,refuted); 0.99999911623464333::status(o_5a5deb07daea404e63b2,unknown).
0.0020350743089324287::status(o_5aa5fb76befc670efa9e,supported); 0::status(o_5aa5fb76befc670efa9e,refuted); 0.99796492569106754::status(o_5aa5fb76befc670efa9e,unknown).
7.240704569089391e-08::status(o_5afd556c9ddb228cddd4,supported); 0::status(o_5afd556c9ddb228cddd4,refuted); 0.99999992759295431::status(o_5afd556c9ddb228cddd4,unknown).
1::status(o_5b71811a31d99aec3541,supported); 0::status(o_5b71811a31d99aec3541,refuted); 0::status(o_5b71811a31d99aec3541,unknown).
0::status(o_5b7486c18996a7c3676a,supported); 1::status(o_5b7486c18996a7c3676a,refuted); 0::status(o_5b7486c18996a7c3676a,unknown).
0.99999964331402236::status(o_5bb8a43209e817939c43,supported); 0::status(o_5bb8a43209e817939c43,refuted); 3.5668597764271226e-07::status(o_5bb8a43209e817939c43,unknown).
0.99999984565285616::status(o_5bf9e0ba8da3ba2ef7e3,supported); 0::status(o_5bf9e0ba8da3ba2ef7e3,refuted); 1.5434714384365833e-07::status(o_5bf9e0ba8da3ba2ef7e3,unknown).
1::status(o_5c05a0bfd1ac8160c1a2,supported); 0::status(o_5c05a0bfd1ac8160c1a2,refuted); 0::status(o_5c05a0bfd1ac8160c1a2,unknown).
0.00096308212960138917::status(o_5c13853e25dc6be86f22,supported); 0::status(o_5c13853e25dc6be86f22,refuted); 0.99903691787039861::status(o_5c13853e25dc6be86f22,unknown).
0.99999084716085185::status(o_5c24b86eb8ef8e422775,supported); 0::status(o_5c24b86eb8ef8e422775,refuted); 9.1528391481521254e-06::status(o_5c24b86eb8ef8e422775,unknown).
1::status(o_5c39c2cfccd72236bb5d,supported); 0::status(o_5c39c2cfccd72236bb5d,refuted); 0::status(o_5c39c2cfccd72236bb5d,unknown).
0.00048713211435824633::status(o_5c55932562f0fec968e0,supported); 0::status(o_5c55932562f0fec968e0,refuted); 0.99951286788564175::status(o_5c55932562f0fec968e0,unknown).
5.6363439411678987e-08::status(o_5cfd309933f1985a62e9,supported); 0::status(o_5cfd309933f1985a62e9,refuted); 0.99999994363656064::status(o_5cfd309933f1985a62e9,unknown).
1::status(o_5d06823432dee63d68d3,supported); 0::status(o_5d06823432dee63d68d3,refuted); 0::status(o_5d06823432dee63d68d3,unknown).
1::status(o_5d4ae964beb7889a3585,supported); 0::status(o_5d4ae964beb7889a3585,refuted); 0::status(o_5d4ae964beb7889a3585,unknown).
0.59074564597745061::status(o_5d6fa1cf932456eac52e,supported); 0::status(o_5d6fa1cf932456eac52e,refuted); 0.40925435402254939::status(o_5d6fa1cf932456eac52e,unknown).
1::status(o_5d9490126fa26d341478,supported); 0::status(o_5d9490126fa26d341478,refuted); 0::status(o_5d9490126fa26d341478,unknown).
0.61694091558456421::status(o_5dee46ce37bc7ae08640,supported); 0::status(o_5dee46ce37bc7ae08640,refuted); 0.38305908441543579::status(o_5dee46ce37bc7ae08640,unknown).
1::status(o_5e6eecbefd831250cd15,supported); 0::status(o_5e6eecbefd831250cd15,refuted); 0::status(o_5e6eecbefd831250cd15,unknown).
0.00013269758210973168::status(o_5eb6d9f8c62b4d939ce6,supported); 0::status(o_5eb6d9f8c62b4d939ce6,refuted); 0.99986730241789024::status(o_5eb6d9f8c62b4d939ce6,unknown).
0.99876297288292504::status(o_5f20e589a8df76aa1918,supported); 0::status(o_5f20e589a8df76aa1918,refuted); 0.0012370271170749625::status(o_5f20e589a8df76aa1918,unknown).
9.7789052431741335e-09::status(o_5f22e18873b8cdf697c3,supported); 0::status(o_5f22e18873b8cdf697c3,refuted); 0.99999999022109476::status(o_5f22e18873b8cdf697c3,unknown).
0.0016452829586341977::status(o_5f95e0e8218de5370eb2,supported); 0::status(o_5f95e0e8218de5370eb2,refuted); 0.9983547170413658::status(o_5f95e0e8218de5370eb2,unknown).
0.99999987409595859::status(o_5fa818e4929428c820d3,supported); 0::status(o_5fa818e4929428c820d3,refuted); 1.2590404141477052e-07::status(o_5fa818e4929428c820d3,unknown).
0.42756217829016024::status(o_5fc90dd0d393e614db3f,supported); 0::status(o_5fc90dd0d393e614db3f,refuted); 0.57243782170983981::status(o_5fc90dd0d393e614db3f,unknown).
0::status(o_6006db5469a8bb36335a,supported); 1::status(o_6006db5469a8bb36335a,refuted); 0::status(o_6006db5469a8bb36335a,unknown).
0.00018795524410060175::status(o_60bb291ee458e021327d,supported); 0::status(o_60bb291ee458e021327d,refuted); 0.99981204475589935::status(o_60bb291ee458e021327d,unknown).
0.0023976406082510948::status(o_60f8829b21da00e7e53e,supported); 0::status(o_60f8829b21da00e7e53e,refuted); 0.99760235939174891::status(o_60f8829b21da00e7e53e,unknown).
0.00033183039771404955::status(o_6130905d7012fc081304,supported); 0::status(o_6130905d7012fc081304,refuted); 0.99966816960228599::status(o_6130905d7012fc081304,unknown).
0.99999999306661269::status(o_61b97c38f0fb04ac7cc9,supported); 0::status(o_61b97c38f0fb04ac7cc9,refuted); 6.9333873087273901e-09::status(o_61b97c38f0fb04ac7cc9,unknown).
0.00020004313584599665::status(o_61d21aa9646fe198fd08,supported); 0::status(o_61d21aa9646fe198fd08,refuted); 0.99979995686415402::status(o_61d21aa9646fe198fd08,unknown).
0.00035480998360670177::status(o_6293767f4b44d9a27b86,supported); 0::status(o_6293767f4b44d9a27b86,refuted); 0.99964519001639329::status(o_6293767f4b44d9a27b86,unknown).
0::status(o_62959a560bf083808c40,supported); 1::status(o_62959a560bf083808c40,refuted); 0::status(o_62959a560bf083808c40,unknown).
0.99938875530479332::status(o_629da59e1ad937cf39b0,supported); 0::status(o_629da59e1ad937cf39b0,refuted); 0.00061124469520668079::status(o_629da59e1ad937cf39b0,unknown).
3.0788986898399006e-06::status(o_62a5a22f2c2dc1d86a08,supported); 0::status(o_62a5a22f2c2dc1d86a08,refuted); 0.99999692110131011::status(o_62a5a22f2c2dc1d86a08,unknown).
0::status(o_62f3c09755664935c836,supported); 1::status(o_62f3c09755664935c836,refuted); 0::status(o_62f3c09755664935c836,unknown).
1.1982675125189598e-07::status(o_62f6bb66337a91ee3b18,supported); 0::status(o_62f6bb66337a91ee3b18,refuted); 0.9999998801732487::status(o_62f6bb66337a91ee3b18,unknown).
1::status(o_6332ef2756469f508f8a,supported); 0::status(o_6332ef2756469f508f8a,refuted); 0::status(o_6332ef2756469f508f8a,unknown).
0.99999108955419413::status(o_63bbfe9f39f4da8af342,supported); 0::status(o_63bbfe9f39f4da8af342,refuted); 8.910445805865308e-06::status(o_63bbfe9f39f4da8af342,unknown).
0.9999997374770605::status(o_64bd6401b634c9b5abaf,supported); 0::status(o_64bd6401b634c9b5abaf,refuted); 2.6252293949813321e-07::status(o_64bd6401b634c9b5abaf,unknown).
0.998406055936786::status(o_64e2557e58334b56b7f0,supported); 0::status(o_64e2557e58334b56b7f0,refuted); 0.0015939440632140034::status(o_64e2557e58334b56b7f0,unknown).
1::status(o_6536aaa1c481d11d62d3,supported); 0::status(o_6536aaa1c481d11d62d3,refuted); 0::status(o_6536aaa1c481d11d62d3,unknown).
1::status(o_653a984030b14ee8d6d8,supported); 0::status(o_653a984030b14ee8d6d8,refuted); 0::status(o_653a984030b14ee8d6d8,unknown).
0.99470680952072144::status(o_65881da29db045b0ac40,supported); 0::status(o_65881da29db045b0ac40,refuted); 0.0052931904792785645::status(o_65881da29db045b0ac40,unknown).
0.99993287134783926::status(o_658b0f2172a11e1a45f4,supported); 0::status(o_658b0f2172a11e1a45f4,refuted); 6.7128652160741709e-05::status(o_658b0f2172a11e1a45f4,unknown).
1::status(o_65efce06180744851949,supported); 0::status(o_65efce06180744851949,refuted); 0::status(o_65efce06180744851949,unknown).
0.59074564597745061::status(o_65fb9f175c4bc5a6bb48,supported); 0::status(o_65fb9f175c4bc5a6bb48,refuted); 0.40925435402254939::status(o_65fb9f175c4bc5a6bb48,unknown).
1::status(o_661f4d5129c617b73504,supported); 0::status(o_661f4d5129c617b73504,refuted); 0::status(o_661f4d5129c617b73504,unknown).
0.98102275343556544::status(o_666ee0929e55230cbc24,supported); 0::status(o_666ee0929e55230cbc24,refuted); 0.018977246564434558::status(o_666ee0929e55230cbc24,unknown).
8.8232187260972506e-07::status(o_67f3f4d1827fe1c69ebe,supported); 0::status(o_67f3f4d1827fe1c69ebe,refuted); 0.99999911767812744::status(o_67f3f4d1827fe1c69ebe,unknown).
0.00016834795824150473::status(o_680f559024f01b1588cb,supported); 0::status(o_680f559024f01b1588cb,refuted); 0.9998316520417585::status(o_680f559024f01b1588cb,unknown).
0::status(o_692839554c5ff643c4a5,supported); 1::status(o_692839554c5ff643c4a5,refuted); 0::status(o_692839554c5ff643c4a5,unknown).
0.99978371589185011::status(o_6979a5238ef812a40a6e,supported); 0::status(o_6979a5238ef812a40a6e,refuted); 0.00021628410814988897::status(o_6979a5238ef812a40a6e,unknown).
1::status(o_69baeed33b58dda70f4a,supported); 0::status(o_69baeed33b58dda70f4a,refuted); 0::status(o_69baeed33b58dda70f4a,unknown).
8.8232187260972506e-07::status(o_6a1d25e7ab9e503b074e,supported); 0::status(o_6a1d25e7ab9e503b074e,refuted); 0.99999911767812744::status(o_6a1d25e7ab9e503b074e,unknown).
1.9687974051039514e-07::status(o_6a279ddf2c02f9321c76,supported); 0::status(o_6a279ddf2c02f9321c76,refuted); 0.99999980312025949::status(o_6a279ddf2c02f9321c76,unknown).
0.003883931552991271::status(o_6a57fc79bac900faaff5,supported); 0::status(o_6a57fc79bac900faaff5,refuted); 0.99611606844700873::status(o_6a57fc79bac900faaff5,unknown).
2.2732953732053438e-05::status(o_6a764828540de177cc2f,supported); 0::status(o_6a764828540de177cc2f,refuted); 0.99997726704626799::status(o_6a764828540de177cc2f,unknown).
1::status(o_6a8ca0739d62f7098a04,supported); 0::status(o_6a8ca0739d62f7098a04,refuted); 0::status(o_6a8ca0739d62f7098a04,unknown).
0.99999811605901279::status(o_6b95737c99cd93cc052a,supported); 0::status(o_6b95737c99cd93cc052a,refuted); 1.8839409872128954e-06::status(o_6b95737c99cd93cc052a,unknown).
3.6053385413765965e-08::status(o_6c1e8ab686b31f187df2,supported); 0::status(o_6c1e8ab686b31f187df2,refuted); 0.99999996394661461::status(o_6c1e8ab686b31f187df2,unknown).
1.1398072013235465e-06::status(o_6c3e121720c0f995051c,supported); 0::status(o_6c3e121720c0f995051c,refuted); 0.99999886019279871::status(o_6c3e121720c0f995051c,unknown).
1::status(o_6c7eecf8093795ba1d8d,supported); 0::status(o_6c7eecf8093795ba1d8d,refuted); 0::status(o_6c7eecf8093795ba1d8d,unknown).
1::status(o_6caf67aca4f84947a589,supported); 0::status(o_6caf67aca4f84947a589,refuted); 0::status(o_6caf67aca4f84947a589,unknown).
1::status(o_6d14ff10a5de5d3e988f,supported); 0::status(o_6d14ff10a5de5d3e988f,refuted); 0::status(o_6d14ff10a5de5d3e988f,unknown).
8.3507141241693934e-06::status(o_6d563875386c9825546f,supported); 0::status(o_6d563875386c9825546f,refuted); 0.99999164928587581::status(o_6d563875386c9825546f,unknown).
0::status(o_6d5b604603c6b90e0b2c,supported); 1::status(o_6d5b604603c6b90e0b2c,refuted); 0::status(o_6d5b604603c6b90e0b2c,unknown).
1::status(o_6d7c81f5e17ed442ba93,supported); 0::status(o_6d7c81f5e17ed442ba93,refuted); 0::status(o_6d7c81f5e17ed442ba93,unknown).
0.014693513442172146::status(o_6d9cb4f93b84116861e0,supported); 0::status(o_6d9cb4f93b84116861e0,refuted); 0.98530648655782782::status(o_6d9cb4f93b84116861e0,unknown).
1::status(o_6e1268fc8948a84cf498,supported); 0::status(o_6e1268fc8948a84cf498,refuted); 0::status(o_6e1268fc8948a84cf498,unknown).
0.99999902675069929::status(o_6e4759a836899fad6672,supported); 0::status(o_6e4759a836899fad6672,refuted); 9.7324930070641358e-07::status(o_6e4759a836899fad6672,unknown).
1::status(o_6e7107127db37ed22106,supported); 0::status(o_6e7107127db37ed22106,refuted); 0::status(o_6e7107127db37ed22106,unknown).
0::status(o_6e7532ab2825c9b1800f,supported); 1::status(o_6e7532ab2825c9b1800f,refuted); 0::status(o_6e7532ab2825c9b1800f,unknown).
1::status(o_6e8e27c18c8e5528d30d,supported); 0::status(o_6e8e27c18c8e5528d30d,refuted); 0::status(o_6e8e27c18c8e5528d30d,unknown).
0.00036025015354824991::status(o_6f0656f897bf5527d539,supported); 0::status(o_6f0656f897bf5527d539,refuted); 0.99963974984645176::status(o_6f0656f897bf5527d539,unknown).
0::status(o_6f0b78e3f3c7386eddfe,supported); 1::status(o_6f0b78e3f3c7386eddfe,refuted); 0::status(o_6f0b78e3f3c7386eddfe,unknown).
1.0310798287111386e-09::status(o_6f7152e20d37baf6efe5,supported); 0::status(o_6f7152e20d37baf6efe5,refuted); 0.99999999896892022::status(o_6f7152e20d37baf6efe5,unknown).
1.1939807101529052e-07::status(o_6f87adf239c4b919c9bb,supported); 0::status(o_6f87adf239c4b919c9bb,refuted); 0.99999988060192901::status(o_6f87adf239c4b919c9bb,unknown).
0.99996105067167163::status(o_6f87d6f81567fe8bd21c,supported); 0::status(o_6f87d6f81567fe8bd21c,refuted); 3.8949328328374833e-05::status(o_6f87d6f81567fe8bd21c,unknown).
0.17303879251806237::status(o_6fb68d5004e215a02ddf,supported); 0::status(o_6fb68d5004e215a02ddf,refuted); 0.82696120748193769::status(o_6fb68d5004e215a02ddf,unknown).
0.99986850708269226::status(o_6fcbb4c83dc4b4103b50,supported); 0::status(o_6fcbb4c83dc4b4103b50,refuted); 0.0001314929173077406::status(o_6fcbb4c83dc4b4103b50,unknown).
0.9999985242868028::status(o_70438dfbe15b479379a4,supported); 0::status(o_70438dfbe15b479379a4,refuted); 1.4757131971965265e-06::status(o_70438dfbe15b479379a4,unknown).
0.31135774259586463::status(o_7094f8389d7e8e02f99e,supported); 0::status(o_7094f8389d7e8e02f99e,refuted); 0.68864225740413532::status(o_7094f8389d7e8e02f99e,unknown).
0.091254428029060364::status(o_7098b9c5cf36ef2599dc,supported); 0::status(o_7098b9c5cf36ef2599dc,refuted); 0.90874557197093964::status(o_7098b9c5cf36ef2599dc,unknown).
0.99999730550533539::status(o_70ed7fe4a44b8c614d21,supported); 0::status(o_70ed7fe4a44b8c614d21,refuted); 2.6944946646123569e-06::status(o_70ed7fe4a44b8c614d21,unknown).
2.9145862656160176e-05::status(o_71031c289901e9a1e964,supported); 0::status(o_71031c289901e9a1e964,refuted); 0.99997085413734388::status(o_71031c289901e9a1e964,unknown).
0::status(o_712c10287a0a91b15238,supported); 1::status(o_712c10287a0a91b15238,refuted); 0::status(o_712c10287a0a91b15238,unknown).
0::status(o_715e01b223eff8ad564f,supported); 1::status(o_715e01b223eff8ad564f,refuted); 0::status(o_715e01b223eff8ad564f,unknown).
1::status(o_71608d3b97b0cac582ca,supported); 0::status(o_71608d3b97b0cac582ca,refuted); 0::status(o_71608d3b97b0cac582ca,unknown).
0.99998772104878231::status(o_717c6c9ac3391e449ef3,supported); 0::status(o_717c6c9ac3391e449ef3,refuted); 1.2278951217692402e-05::status(o_717c6c9ac3391e449ef3,unknown).
0.99734755297201794::status(o_7183e4fe32fdaf1863b1,supported); 0::status(o_7183e4fe32fdaf1863b1,refuted); 0.0026524470279820633::status(o_7183e4fe32fdaf1863b1,unknown).
1::status(o_71d8d78292bc7921cf92,supported); 0::status(o_71d8d78292bc7921cf92,refuted); 0::status(o_71d8d78292bc7921cf92,unknown).
1.3034778761802781e-06::status(o_71dd89155c928c5a4cdc,supported); 0::status(o_71dd89155c928c5a4cdc,refuted); 0.99999869652212381::status(o_71dd89155c928c5a4cdc,unknown).
1::status(o_7234cc02dcbd8f5aa9cd,supported); 0::status(o_7234cc02dcbd8f5aa9cd,refuted); 0::status(o_7234cc02dcbd8f5aa9cd,unknown).
0.59034655452329843::status(o_725009d3dcd926dee28f,supported); 0::status(o_725009d3dcd926dee28f,refuted); 0.40965344547670157::status(o_725009d3dcd926dee28f,unknown).
0.00035502800062487452::status(o_72b6e08810511e3ae16a,supported); 0::status(o_72b6e08810511e3ae16a,refuted); 0.99964497199937508::status(o_72b6e08810511e3ae16a,unknown).
0.99991882974182511::status(o_72ebf141f0c78640731d,supported); 0::status(o_72ebf141f0c78640731d,refuted); 8.1170258174889653e-05::status(o_72ebf141f0c78640731d,unknown).
1::status(o_73f208e5952551e50207,supported); 0::status(o_73f208e5952551e50207,refuted); 0::status(o_73f208e5952551e50207,unknown).
1::status(o_7439e372b4d6e1edbca1,supported); 0::status(o_7439e372b4d6e1edbca1,refuted); 0::status(o_7439e372b4d6e1edbca1,unknown).
0.00085279322229325771::status(o_744f27687f26e7fd822b,supported); 0::status(o_744f27687f26e7fd822b,refuted); 0.99914720677770674::status(o_744f27687f26e7fd822b,unknown).
1::status(o_74cb5f7fc428f04be3dd,supported); 0::status(o_74cb5f7fc428f04be3dd,refuted); 0::status(o_74cb5f7fc428f04be3dd,unknown).
2.964500090961157e-05::status(o_758497fab81797cb1871,supported); 0::status(o_758497fab81797cb1871,refuted); 0.99997035499909037::status(o_758497fab81797cb1871,unknown).
0.11399187182013393::status(o_75a2551f2b1a8daf5b9a,supported); 0::status(o_75a2551f2b1a8daf5b9a,refuted); 0.88600812817986607::status(o_75a2551f2b1a8daf5b9a,unknown).
0.99738341569900513::status(o_75ebe6269a3b80b49288,supported); 0::status(o_75ebe6269a3b80b49288,refuted); 0.002616584300994873::status(o_75ebe6269a3b80b49288,unknown).
2.9942671007835537e-05::status(o_760c8d45c8337dd0bd8a,supported); 0::status(o_760c8d45c8337dd0bd8a,refuted); 0.99997005732899213::status(o_760c8d45c8337dd0bd8a,unknown).
0.9999858004591502::status(o_7668e5aa8be34e2a4cdb,supported); 0::status(o_7668e5aa8be34e2a4cdb,refuted); 1.4199540849801906e-05::status(o_7668e5aa8be34e2a4cdb,unknown).
0.99998772104878231::status(o_76a68c80b2eec0603456,supported); 0::status(o_76a68c80b2eec0603456,refuted); 1.2278951217692402e-05::status(o_76a68c80b2eec0603456,unknown).
1::status(o_76c2f83b76219d4dfb59,supported); 0::status(o_76c2f83b76219d4dfb59,refuted); 0::status(o_76c2f83b76219d4dfb59,unknown).
0.99547606706619263::status(o_76c908ad4c958b25f67e,supported); 0::status(o_76c908ad4c958b25f67e,refuted); 0.004523932933807373::status(o_76c908ad4c958b25f67e,unknown).
0::status(o_76f77003a5227f200728,supported); 1::status(o_76f77003a5227f200728,refuted); 0::status(o_76f77003a5227f200728,unknown).
8.8232187260972506e-07::status(o_77d06d21c341e1be2a4c,supported); 0::status(o_77d06d21c341e1be2a4c,refuted); 0.99999911767812744::status(o_77d06d21c341e1be2a4c,unknown).
0.31135774259586463::status(o_7809da65a16c2bbeedef,supported); 0::status(o_7809da65a16c2bbeedef,refuted); 0.68864225740413532::status(o_7809da65a16c2bbeedef,unknown).
0.99506819248199463::status(o_784cd4955759eb97970e,supported); 0::status(o_784cd4955759eb97970e,refuted); 0.0049318075180053711::status(o_784cd4955759eb97970e,unknown).
3.2482797206823362e-07::status(o_78cc8ef7aed6965d0cfb,supported); 0::status(o_78cc8ef7aed6965d0cfb,refuted); 0.99999967517202792::status(o_78cc8ef7aed6965d0cfb,unknown).
4.1746313953515482e-07::status(o_792d819302f06839cc2a,supported); 0::status(o_792d819302f06839cc2a,refuted); 0.9999995825368605::status(o_792d819302f06839cc2a,unknown).
0.26344888300134306::status(o_79ab174a376372e7b44b,supported); 0::status(o_79ab174a376372e7b44b,refuted); 0.73655111699865694::status(o_79ab174a376372e7b44b,unknown).
0::status(o_79eda2530f51ba8eb99b,supported); 1::status(o_79eda2530f51ba8eb99b,refuted); 0::status(o_79eda2530f51ba8eb99b,unknown).
0.0090255900882156188::status(o_7afa2df8d5dc0a6a4954,supported); 0::status(o_7afa2df8d5dc0a6a4954,refuted); 0.99097440991178443::status(o_7afa2df8d5dc0a6a4954,unknown).
0::status(o_7b21776c0546f550dffa,supported); 1::status(o_7b21776c0546f550dffa,refuted); 0::status(o_7b21776c0546f550dffa,unknown).
7.9219131214654283e-05::status(o_7c0e5bcf811896c933e0,supported); 0::status(o_7c0e5bcf811896c933e0,refuted); 0.99992078086878533::status(o_7c0e5bcf811896c933e0,unknown).
1::status(o_7c4098b26a0475fb1319,supported); 0::status(o_7c4098b26a0475fb1319,refuted); 0::status(o_7c4098b26a0475fb1319,unknown).
0.00033183039771404955::status(o_7cf375cf219d4af3cc8f,supported); 0::status(o_7cf375cf219d4af3cc8f,refuted); 0.99966816960228599::status(o_7cf375cf219d4af3cc8f,unknown).
0.00035480998360670177::status(o_7d886354deee17531da1,supported); 0::status(o_7d886354deee17531da1,refuted); 0.99964519001639329::status(o_7d886354deee17531da1,unknown).
0::status(o_7de7aa94cd2f2bd7ca97,supported); 1::status(o_7de7aa94cd2f2bd7ca97,refuted); 0::status(o_7de7aa94cd2f2bd7ca97,unknown).
1::status(o_7dfbcc296ae8b3540226,supported); 0::status(o_7dfbcc296ae8b3540226,refuted); 0::status(o_7dfbcc296ae8b3540226,unknown).
5.7750552951804822e-05::status(o_7e82e6337a4db47ebfa1,supported); 0::status(o_7e82e6337a4db47ebfa1,refuted); 0.99994224944704824::status(o_7e82e6337a4db47ebfa1,unknown).
0.00063080125255510211::status(o_7ecc285ca92e3a070846,supported); 0::status(o_7ecc285ca92e3a070846,refuted); 0.9993691987474449::status(o_7ecc285ca92e3a070846,unknown).
0.96227091550827026::status(o_7ecfe705aca39aef2c2a,supported); 0::status(o_7ecfe705aca39aef2c2a,refuted); 0.037729084491729736::status(o_7ecfe705aca39aef2c2a,unknown).
0.40537978642262851::status(o_7f302fff9d200b911cee,supported); 0::status(o_7f302fff9d200b911cee,refuted); 0.59462021357737149::status(o_7f302fff9d200b911cee,unknown).
0.998406055936786::status(o_7f3593dcfb218c27696d,supported); 0::status(o_7f3593dcfb218c27696d,refuted); 0.0015939440632140034::status(o_7f3593dcfb218c27696d,unknown).
1::status(o_7f3b8b2a2d6a5a06bd50,supported); 0::status(o_7f3b8b2a2d6a5a06bd50,refuted); 0::status(o_7f3b8b2a2d6a5a06bd50,unknown).
0.99999902675069929::status(o_7f92e25c4cefd850d924,supported); 0::status(o_7f92e25c4cefd850d924,refuted); 9.7324930070641358e-07::status(o_7f92e25c4cefd850d924,unknown).
0.999999966881435::status(o_7fcc9eebcaed6057b543,supported); 0::status(o_7fcc9eebcaed6057b543,refuted); 3.3118565001544198e-08::status(o_7fcc9eebcaed6057b543,unknown).
1::status(o_8002b1224a08ded93d2f,supported); 0::status(o_8002b1224a08ded93d2f,refuted); 0::status(o_8002b1224a08ded93d2f,unknown).
5.5235427339093855e-05::status(o_801c31918729886ff1e4,supported); 0::status(o_801c31918729886ff1e4,refuted); 0.9999447645726609::status(o_801c31918729886ff1e4,unknown).
0.36756375367835886::status(o_807f9757ca3f396f5466,supported); 0::status(o_807f9757ca3f396f5466,refuted); 0.63243624632164108::status(o_807f9757ca3f396f5466,unknown).
0::status(o_808a01bcdf57704d23db,supported); 1::status(o_808a01bcdf57704d23db,refuted); 0::status(o_808a01bcdf57704d23db,unknown).
0::status(o_809a3244c4665450a38f,supported); 1::status(o_809a3244c4665450a38f,refuted); 0::status(o_809a3244c4665450a38f,unknown).
0.99794512987136841::status(o_809b6b04bc4e9773c86b,supported); 0::status(o_809b6b04bc4e9773c86b,refuted); 0.0020548701286315918::status(o_809b6b04bc4e9773c86b,unknown).
0.99999811605901279::status(o_80c53c3190b388d09275,supported); 0::status(o_80c53c3190b388d09275,refuted); 1.8839409872128954e-06::status(o_80c53c3190b388d09275,unknown).
1::status(o_811c448afd79a4e5ea46,supported); 0::status(o_811c448afd79a4e5ea46,refuted); 0::status(o_811c448afd79a4e5ea46,unknown).
0.99999939047324271::status(o_815d674823e0b6721491,supported); 0::status(o_815d674823e0b6721491,refuted); 6.0952675728920269e-07::status(o_815d674823e0b6721491,unknown).
0.99999944684311093::status(o_81f242b2e6a2ebcae6f1,supported); 0::status(o_81f242b2e6a2ebcae6f1,refuted); 5.5315688907153771e-07::status(o_81f242b2e6a2ebcae6f1,unknown).
5.7750552951804822e-05::status(o_822738dfc56925f41c59,supported); 0::status(o_822738dfc56925f41c59,refuted); 0.99994224944704824::status(o_822738dfc56925f41c59,unknown).
0::status(o_82ad221b33ab2c15f58c,supported); 1::status(o_82ad221b33ab2c15f58c,refuted); 0::status(o_82ad221b33ab2c15f58c,unknown).
0.021092737093567848::status(o_82bf01f9874cfcfea4af,supported); 0::status(o_82bf01f9874cfcfea4af,refuted); 0.97890726290643215::status(o_82bf01f9874cfcfea4af,unknown).
0.40906063893112277::status(o_82d59e3ad716635875f9,supported); 0::status(o_82d59e3ad716635875f9,refuted); 0.59093936106887723::status(o_82d59e3ad716635875f9,unknown).
0.59405595423652324::status(o_83309c1c94c2e088e02d,supported); 0::status(o_83309c1c94c2e088e02d,refuted); 0.40594404576347676::status(o_83309c1c94c2e088e02d,unknown).
0.99999998873827356::status(o_8333724971b1c67b144a,supported); 0::status(o_8333724971b1c67b144a,refuted); 1.126172644028145e-08::status(o_8333724971b1c67b144a,unknown).
0.36756375367835886::status(o_833f304508883542f299,supported); 0::status(o_833f304508883542f299,refuted); 0.63243624632164108::status(o_833f304508883542f299,unknown).
0.99547606706619263::status(o_8360765729abee05682b,supported); 0::status(o_8360765729abee05682b,refuted); 0.004523932933807373::status(o_8360765729abee05682b,unknown).
0.00035486903271498394::status(o_8363ba639599b8ee4ac7,supported); 0::status(o_8363ba639599b8ee4ac7,refuted); 0.99964513096728502::status(o_8363ba639599b8ee4ac7,unknown).
0.99999811605901279::status(o_83669c1ccc8c09e383d0,supported); 0::status(o_83669c1ccc8c09e383d0,refuted); 1.8839409872128954e-06::status(o_83669c1ccc8c09e383d0,unknown).
1.8664938787461042e-06::status(o_8388fae312e5e6d4595f,supported); 0::status(o_8388fae312e5e6d4595f,refuted); 0.99999813350612121::status(o_8388fae312e5e6d4595f,unknown).
0.40537978642262851::status(o_83a7eb1b81e7be443af2,supported); 0::status(o_83a7eb1b81e7be443af2,refuted); 0.59462021357737149::status(o_83a7eb1b81e7be443af2,unknown).
0.96011406183242798::status(o_83e0e7e4f9595bd57fd0,supported); 0::status(o_83e0e7e4f9595bd57fd0,refuted); 0.039885938167572021::status(o_83e0e7e4f9595bd57fd0,unknown).
1::status(o_83e1cd59886a1ae471bd,supported); 0::status(o_83e1cd59886a1ae471bd,refuted); 0::status(o_83e1cd59886a1ae471bd,unknown).
0.0031784586608409882::status(o_8484e9496ee04402cc6f,supported); 0::status(o_8484e9496ee04402cc6f,refuted); 0.99682154133915901::status(o_8484e9496ee04402cc6f,unknown).
1::status(o_84a6bb3aa500bf97227d,supported); 0::status(o_84a6bb3aa500bf97227d,refuted); 0::status(o_84a6bb3aa500bf97227d,unknown).
0.26344888300134306::status(o_85979373934f63781532,supported); 0::status(o_85979373934f63781532,refuted); 0.73655111699865694::status(o_85979373934f63781532,unknown).
0.99999939047324271::status(o_85add405662655c6ddfe,supported); 0::status(o_85add405662655c6ddfe,refuted); 6.0952675728920269e-07::status(o_85add405662655c6ddfe,unknown).
1::status(o_85dcec15211ddf1abfdf,supported); 0::status(o_85dcec15211ddf1abfdf,refuted); 0::status(o_85dcec15211ddf1abfdf,unknown).
1::status(o_86363b95e6a5b82e00dc,supported); 0::status(o_86363b95e6a5b82e00dc,refuted); 0::status(o_86363b95e6a5b82e00dc,unknown).
0.0016038946647859631::status(o_867f5de1c76fa2df063a,supported); 0::status(o_867f5de1c76fa2df063a,refuted); 0.99839610533521406::status(o_867f5de1c76fa2df063a,unknown).
2.0894597638485889e-07::status(o_86839479ce6c1c05b265,supported); 0::status(o_86839479ce6c1c05b265,refuted); 0.99999979105402359::status(o_86839479ce6c1c05b265,unknown).
0.99999811567972463::status(o_869d18c885d1045c40d4,supported); 0::status(o_869d18c885d1045c40d4,refuted); 1.8843202753693333e-06::status(o_869d18c885d1045c40d4,unknown).
1::status(o_869fa890e9e739907fc3,supported); 0::status(o_869fa890e9e739907fc3,refuted); 0::status(o_869fa890e9e739907fc3,unknown).
2.0750996724554319e-08::status(o_87958d68f26d8919a131,supported); 0::status(o_87958d68f26d8919a131,refuted); 0.9999999792490033::status(o_87958d68f26d8919a131,unknown).
0.0024758365470916033::status(o_87da43ce47e698e3eacf,supported); 0::status(o_87da43ce47e698e3eacf,refuted); 0.9975241634529084::status(o_87da43ce47e698e3eacf,unknown).
4.822686275353781e-05::status(o_88249683aa3878e436ba,supported); 0::status(o_88249683aa3878e436ba,refuted); 0.99995177313724648::status(o_88249683aa3878e436ba,unknown).
0.99964481635247604::status(o_88845199cc014e0062dc,supported); 0::status(o_88845199cc014e0062dc,refuted); 0.00035518364752396003::status(o_88845199cc014e0062dc,unknown).
0.99999998873827356::status(o_888aec2150580b3b3b2c,supported); 0::status(o_888aec2150580b3b3b2c,refuted); 1.126172644028145e-08::status(o_888aec2150580b3b3b2c,unknown).
8.837632431410118e-07::status(o_88a276fc3155159736af,supported); 0::status(o_88a276fc3155159736af,refuted); 0.99999911623675686::status(o_88a276fc3155159736af,unknown).
1::status(o_8920fcd17281bd29fbdd,supported); 0::status(o_8920fcd17281bd29fbdd,refuted); 0::status(o_8920fcd17281bd29fbdd,unknown).
0.0018071738304570317::status(o_89c5541aaba880657923,supported); 0::status(o_89c5541aaba880657923,refuted); 0.99819282616954297::status(o_89c5541aaba880657923,unknown).
1::status(o_89cecf9732127e905f38,supported); 0::status(o_89cecf9732127e905f38,refuted); 0::status(o_89cecf9732127e905f38,unknown).
2.7902980907204649e-05::status(o_8a198ead5a0d5c3d74a5,supported); 0::status(o_8a198ead5a0d5c3d74a5,refuted); 0.99997209701909284::status(o_8a198ead5a0d5c3d74a5,unknown).
0.00096378276237123986::status(o_8a6a09f96c2b358aa588,supported); 0::status(o_8a6a09f96c2b358aa588,refuted); 0.99903621723762881::status(o_8a6a09f96c2b358aa588,unknown).
0.96967961634467392::status(o_8ab49489c3f340927c7b,supported); 0::status(o_8ab49489c3f340927c7b,refuted); 0.030320383655326077::status(o_8ab49489c3f340927c7b,unknown).
5.5235427339093855e-05::status(o_8ab6773296e4ff1ee812,supported); 0::status(o_8ab6773296e4ff1ee812,refuted); 0.9999447645726609::status(o_8ab6773296e4ff1ee812,unknown).
1.3772274031924337e-05::status(o_8ae71956eed3a6cccf21,supported); 0::status(o_8ae71956eed3a6cccf21,refuted); 0.99998622772596812::status(o_8ae71956eed3a6cccf21,unknown).
0.999999966881435::status(o_8b223a9a9aadc04ac805,supported); 0::status(o_8b223a9a9aadc04ac805,refuted); 3.3118565001544198e-08::status(o_8b223a9a9aadc04ac805,unknown).
0.070867766607818697::status(o_8b65271d2845166eacc8,supported); 0::status(o_8b65271d2845166eacc8,refuted); 0.92913223339218132::status(o_8b65271d2845166eacc8,unknown).
1::status(o_8b855fef8bdcedff7307,supported); 0::status(o_8b855fef8bdcedff7307,refuted); 0::status(o_8b855fef8bdcedff7307,unknown).
0::status(o_8baed694a0944fb7fb8d,supported); 1::status(o_8baed694a0944fb7fb8d,refuted); 0::status(o_8baed694a0944fb7fb8d,unknown).
9.2399274103717775e-07::status(o_8bb75eed9e3568e62796,supported); 0::status(o_8bb75eed9e3568e62796,refuted); 0.99999907600725901::status(o_8bb75eed9e3568e62796,unknown).
0.99977468029036498::status(o_8c14b3e6420c3ad49ff9,supported); 0::status(o_8c14b3e6420c3ad49ff9,refuted); 0.00022531970963501902::status(o_8c14b3e6420c3ad49ff9,unknown).
0.018944852536761814::status(o_8c18cdf30846a9cbb8c8,supported); 0::status(o_8c18cdf30846a9cbb8c8,refuted); 0.98105514746323819::status(o_8c18cdf30846a9cbb8c8,unknown).
0.99999882968458842::status(o_8c1bbcbb845ca5a5fbf9,supported); 0::status(o_8c1bbcbb845ca5a5fbf9,refuted); 1.1703154115805248e-06::status(o_8c1bbcbb845ca5a5fbf9,unknown).
0::status(o_8c527c6063c7779d2cc2,supported); 1::status(o_8c527c6063c7779d2cc2,refuted); 0::status(o_8c527c6063c7779d2cc2,unknown).
0::status(o_8cdfaa3d67d8f824e0b7,supported); 1::status(o_8cdfaa3d67d8f824e0b7,refuted); 0::status(o_8cdfaa3d67d8f824e0b7,unknown).
0.99999987123526379::status(o_8ce3e0a182571e665c76,supported); 0::status(o_8ce3e0a182571e665c76,refuted); 1.2876473620693218e-07::status(o_8ce3e0a182571e665c76,unknown).
1.3790825998871118e-05::status(o_8cfd4b2852843bded632,supported); 0::status(o_8cfd4b2852843bded632,refuted); 0.99998620917400116::status(o_8cfd4b2852843bded632,unknown).
0.94859583948832515::status(o_8d949ffb95a211bc43dd,supported); 0::status(o_8d949ffb95a211bc43dd,refuted); 0.051404160511674846::status(o_8d949ffb95a211bc43dd,unknown).
1::status(o_8d97031b12b50ebc9bf5,supported); 0::status(o_8d97031b12b50ebc9bf5,refuted); 0::status(o_8d97031b12b50ebc9bf5,unknown).
0.9999997374770605::status(o_8e8fde7fc82198d1e375,supported); 0::status(o_8e8fde7fc82198d1e375,refuted); 2.6252293949813321e-07::status(o_8e8fde7fc82198d1e375,unknown).
1::status(o_8f596277e9b09a6ce7fb,supported); 0::status(o_8f596277e9b09a6ce7fb,refuted); 0::status(o_8f596277e9b09a6ce7fb,unknown).
0.99999983608087528::status(o_8f688dc283616ac8fade,supported); 0::status(o_8f688dc283616ac8fade,refuted); 1.639191247182481e-07::status(o_8f688dc283616ac8fade,unknown).
0.048343271204560223::status(o_8f6d1028a2e9793bd0aa,supported); 0::status(o_8f6d1028a2e9793bd0aa,refuted); 0.95165672879543983::status(o_8f6d1028a2e9793bd0aa,unknown).
2.8278058427373192e-08::status(o_8f8b4710a2762a772eee,supported); 0::status(o_8f8b4710a2762a772eee,refuted); 0.99999997172194155::status(o_8f8b4710a2762a772eee,unknown).
0.0018518617143854499::status(o_8f9876917b4446a5c43d,supported); 0::status(o_8f9876917b4446a5c43d,refuted); 0.99814813828561455::status(o_8f9876917b4446a5c43d,unknown).
0.00022408674703910947::status(o_8fc8b1fb5f088e985d0d,supported); 0::status(o_8fc8b1fb5f088e985d0d,refuted); 0.99977591325296089::status(o_8fc8b1fb5f088e985d0d,unknown).
0.99535101332905751::status(o_8fdc18904d435f513d28,supported); 0::status(o_8fdc18904d435f513d28,refuted); 0.0046489866709424899::status(o_8fdc18904d435f513d28,unknown).
0.15455253835212221::status(o_90122905fce44dfdee7b,supported); 0::status(o_90122905fce44dfdee7b,refuted); 0.84544746164787776::status(o_90122905fce44dfdee7b,unknown).
0.99999996500192156::status(o_908daf10e6423c5f2068,supported); 0::status(o_908daf10e6423c5f2068,refuted); 3.49980784353221e-08::status(o_908daf10e6423c5f2068,unknown).
0.56174170970916748::status(o_9128613b8b75f4088975,supported); 0::status(o_9128613b8b75f4088975,refuted); 0.43825829029083252::status(o_9128613b8b75f4088975,unknown).
1::status(o_9178702dd21232ad6781,supported); 0::status(o_9178702dd21232ad6781,refuted); 0::status(o_9178702dd21232ad6781,unknown).
1::status(o_919833f76cbd98fd14d0,supported); 0::status(o_919833f76cbd98fd14d0,refuted); 0::status(o_919833f76cbd98fd14d0,unknown).
2.4339600097483744e-06::status(o_91bbd368cb4f93c26294,supported); 0::status(o_91bbd368cb4f93c26294,refuted); 0.99999756603999024::status(o_91bbd368cb4f93c26294,unknown).
0.003354658596551997::status(o_91df501355fb7dac64de,supported); 0::status(o_91df501355fb7dac64de,refuted); 0.99664534140344796::status(o_91df501355fb7dac64de,unknown).
1::status(o_91ec70e05f090cc2f898,supported); 0::status(o_91ec70e05f090cc2f898,refuted); 0::status(o_91ec70e05f090cc2f898,unknown).
1::status(o_91eef027d6d7d155292b,supported); 0::status(o_91eef027d6d7d155292b,refuted); 0::status(o_91eef027d6d7d155292b,unknown).
0.99660646915435791::status(o_9363f58ae7671ce5bd15,supported); 0::status(o_9363f58ae7671ce5bd15,refuted); 0.0033935308456420898::status(o_9363f58ae7671ce5bd15,unknown).
2.1078815721349881e-08::status(o_9390576d90574c5d0762,supported); 0::status(o_9390576d90574c5d0762,refuted); 0.99999997892118431::status(o_9390576d90574c5d0762,unknown).
0.99492681207231914::status(o_939d05a58786e22c90f7,supported); 0::status(o_939d05a58786e22c90f7,refuted); 0.0050731879276808556::status(o_939d05a58786e22c90f7,unknown).
0.00035502800062487452::status(o_93d037006e19c94d46b5,supported); 0::status(o_93d037006e19c94d46b5,refuted); 0.99964497199937508::status(o_93d037006e19c94d46b5,unknown).
1.4547524827703678e-06::status(o_93d24fe7fa96e6534682,supported); 0::status(o_93d24fe7fa96e6534682,refuted); 0.99999854524751719::status(o_93d24fe7fa96e6534682,unknown).
1::status(o_93fd8457a3f57b0aa60b,supported); 0::status(o_93fd8457a3f57b0aa60b,refuted); 0::status(o_93fd8457a3f57b0aa60b,unknown).
1::status(o_941670903a9ed187ced1,supported); 0::status(o_941670903a9ed187ced1,refuted); 0::status(o_941670903a9ed187ced1,unknown).
8.9271348052939361e-07::status(o_942e669a2e4c0ac6da2f,supported); 0::status(o_942e669a2e4c0ac6da2f,refuted); 0.99999910728651942::status(o_942e669a2e4c0ac6da2f,unknown).
8.3507141241693934e-06::status(o_949af639dbb0745441b6,supported); 0::status(o_949af639dbb0745441b6,refuted); 0.99999164928587581::status(o_949af639dbb0745441b6,unknown).
0::status(o_950402d57bd57182cc46,supported); 1::status(o_950402d57bd57182cc46,refuted); 0::status(o_950402d57bd57182cc46,unknown).
0.41033004360134684::status(o_9510d568d6cec6af769b,supported); 0::status(o_9510d568d6cec6af769b,refuted); 0.58966995639865316::status(o_9510d568d6cec6af769b,unknown).
1::status(o_95187676549c4c9c3ee5,supported); 0::status(o_95187676549c4c9c3ee5,refuted); 0::status(o_95187676549c4c9c3ee5,unknown).
0.0027664784469140684::status(o_95d2a34b38545682987f,supported); 0::status(o_95d2a34b38545682987f,refuted); 0.99723352155308598::status(o_95d2a34b38545682987f,unknown).
1::status(o_95db15e16a5cc43e5642,supported); 0::status(o_95db15e16a5cc43e5642,refuted); 0::status(o_95db15e16a5cc43e5642,unknown).
1::status(o_9611065846119469d907,supported); 0::status(o_9611065846119469d907,refuted); 0::status(o_9611065846119469d907,unknown).
0.00035480998360670177::status(o_9658dae5abced03b0e3f,supported); 0::status(o_9658dae5abced03b0e3f,refuted); 0.99964519001639329::status(o_9658dae5abced03b0e3f,unknown).
1::status(o_96c3418f7ad073390db4,supported); 0::status(o_96c3418f7ad073390db4,refuted); 0::status(o_96c3418f7ad073390db4,unknown).
1::status(o_970f7dffc1b0811da674,supported); 0::status(o_970f7dffc1b0811da674,refuted); 0::status(o_970f7dffc1b0811da674,unknown).
0.99977468029036498::status(o_974538fec76e42d94146,supported); 0::status(o_974538fec76e42d94146,refuted); 0.00022531970963501902::status(o_974538fec76e42d94146,unknown).
0.00096419803208583539::status(o_9797de34e3ada7a0b237,supported); 0::status(o_9797de34e3ada7a0b237,refuted); 0.99903580196791419::status(o_9797de34e3ada7a0b237,unknown).
1::status(o_97feb2a1dd70f8cac96f,supported); 0::status(o_97feb2a1dd70f8cac96f,refuted); 0::status(o_97feb2a1dd70f8cac96f,unknown).
1::status(o_98aa5efa2a7111a8692d,supported); 0::status(o_98aa5efa2a7111a8692d,refuted); 0::status(o_98aa5efa2a7111a8692d,unknown).
0.0071083765268546645::status(o_98ac4e8ce3149bea26cc,supported); 0::status(o_98ac4e8ce3149bea26cc,refuted); 0.9928916234731453::status(o_98ac4e8ce3149bea26cc,unknown).
0.96754372119903564::status(o_98ec298b70503d0d2552,supported); 0::status(o_98ec298b70503d0d2552,refuted); 0.032456278800964355::status(o_98ec298b70503d0d2552,unknown).
0::status(o_996253e346367dcb7b19,supported); 1::status(o_996253e346367dcb7b19,refuted); 0::status(o_996253e346367dcb7b19,unknown).
0.68876990696500395::status(o_998d029375c86e619456,supported); 0::status(o_998d029375c86e619456,refuted); 0.31123009303499605::status(o_998d029375c86e619456,unknown).
1::status(o_99b118d8e2dad88ecf9e,supported); 0::status(o_99b118d8e2dad88ecf9e,refuted); 0::status(o_99b118d8e2dad88ecf9e,unknown).
0.00027316782507114112::status(o_9a0f7f9d66980bd1d0d7,supported); 0::status(o_9a0f7f9d66980bd1d0d7,refuted); 0.99972683217492886::status(o_9a0f7f9d66980bd1d0d7,unknown).
4.822686275353781e-05::status(o_9a6e0e407434517a572e,supported); 0::status(o_9a6e0e407434517a572e,refuted); 0.99995177313724648::status(o_9a6e0e407434517a572e,unknown).
0.00027939380379393697::status(o_9ad67c6c86a3fef10281,supported); 0::status(o_9ad67c6c86a3fef10281,refuted); 0.99972060619620606::status(o_9ad67c6c86a3fef10281,unknown).
0.060433860787262768::status(o_9b7201b4fc8be9a32b76,supported); 0::status(o_9b7201b4fc8be9a32b76,refuted); 0.93956613921273724::status(o_9b7201b4fc8be9a32b76,unknown).
0.99999812854020698::status(o_9be74a47dbfb888e54c9,supported); 0::status(o_9be74a47dbfb888e54c9,refuted); 1.871459793023611e-06::status(o_9be74a47dbfb888e54c9,unknown).
0.99999996709064987::status(o_9c3011b5e8e40ce34901,supported); 0::status(o_9c3011b5e8e40ce34901,refuted); 3.2909350133891735e-08::status(o_9c3011b5e8e40ce34901,unknown).
0.00011525061563588679::status(o_9c3e5cb7d20961112020,supported); 0::status(o_9c3e5cb7d20961112020,refuted); 0.99988474938436411::status(o_9c3e5cb7d20961112020,unknown).
0.025744652299528711::status(o_9cc9b78ebb59262bb7f7,supported); 0::status(o_9cc9b78ebb59262bb7f7,refuted); 0.97425534770047129::status(o_9cc9b78ebb59262bb7f7,unknown).
1.1399314962425972e-06::status(o_9db47beaf086b2133d4e,supported); 0::status(o_9db47beaf086b2133d4e,refuted); 0.9999988600685038::status(o_9db47beaf086b2133d4e,unknown).
1::status(o_9df46a7278c03fc421c0,supported); 0::status(o_9df46a7278c03fc421c0,refuted); 0::status(o_9df46a7278c03fc421c0,unknown).
1::status(o_9e468dae4c85caf4db6f,supported); 0::status(o_9e468dae4c85caf4db6f,refuted); 0::status(o_9e468dae4c85caf4db6f,unknown).
2.2375324988388456e-05::status(o_9f18e4d49c59938e1220,supported); 0::status(o_9f18e4d49c59938e1220,refuted); 0.99997762467501161::status(o_9f18e4d49c59938e1220,unknown).
0.73811351400821135::status(o_9f5926b404d083ce0741,supported); 0::status(o_9f5926b404d083ce0741,refuted); 0.26188648599178865::status(o_9f5926b404d083ce0741,unknown).
1::status(o_9f85c3d357e2edf5fbc3,supported); 0::status(o_9f85c3d357e2edf5fbc3,refuted); 0::status(o_9f85c3d357e2edf5fbc3,unknown).
1::status(o_9fa3d7d2b461709897ef,supported); 0::status(o_9fa3d7d2b461709897ef,refuted); 0::status(o_9fa3d7d2b461709897ef,unknown).
6.5270009395127061e-06::status(o_9ffa9a58f0a878071f39,supported); 0::status(o_9ffa9a58f0a878071f39,refuted); 0.9999934729990605::status(o_9ffa9a58f0a878071f39,unknown).
1::status(o_a025c34aebabb11ec4df,supported); 0::status(o_a025c34aebabb11ec4df,refuted); 0::status(o_a025c34aebabb11ec4df,unknown).
0.00012856320746051369::status(o_a07e57a096373f07e17a,supported); 0::status(o_a07e57a096373f07e17a,refuted); 0.99987143679253954::status(o_a07e57a096373f07e17a,unknown).
0.99999987123526379::status(o_a0f35ea0a888755382ed,supported); 0::status(o_a0f35ea0a888755382ed,refuted); 1.2876473620693218e-07::status(o_a0f35ea0a888755382ed,unknown).
0.98997622728347778::status(o_a14400b9666d4a5a34d8,supported); 0::status(o_a14400b9666d4a5a34d8,refuted); 0.010023772716522217::status(o_a14400b9666d4a5a34d8,unknown).
0.0050932755693793297::status(o_a1482db353d2f3756a89,supported); 0::status(o_a1482db353d2f3756a89,refuted); 0.99490672443062067::status(o_a1482db353d2f3756a89,unknown).
0.99999983608087528::status(o_a16f342b3a8eff6df36a,supported); 0::status(o_a16f342b3a8eff6df36a,refuted); 1.639191247182481e-07::status(o_a16f342b3a8eff6df36a,unknown).
0::status(o_a24e2d8acc2b09ec3074,supported); 1::status(o_a24e2d8acc2b09ec3074,refuted); 0::status(o_a24e2d8acc2b09ec3074,unknown).
1::status(o_a2b80fa9d773535f8831,supported); 0::status(o_a2b80fa9d773535f8831,refuted); 0::status(o_a2b80fa9d773535f8831,unknown).
1::status(o_a2cafaf57d29df52be1d,supported); 0::status(o_a2cafaf57d29df52be1d,refuted); 0::status(o_a2cafaf57d29df52be1d,unknown).
2.8278058427373192e-08::status(o_a2ce3aae1b5ab8f80ad1,supported); 0::status(o_a2ce3aae1b5ab8f80ad1,refuted); 0.99999997172194155::status(o_a2ce3aae1b5ab8f80ad1,unknown).
1::status(o_a31788f8c927a387dcc0,supported); 0::status(o_a31788f8c927a387dcc0,refuted); 0::status(o_a31788f8c927a387dcc0,unknown).
1::status(o_a3a77687b0c023d8effa,supported); 0::status(o_a3a77687b0c023d8effa,refuted); 0::status(o_a3a77687b0c023d8effa,unknown).
0.00050072265336658891::status(o_a3cd9489986c31ed1ac2,supported); 0::status(o_a3cd9489986c31ed1ac2,refuted); 0.99949927734663346::status(o_a3cd9489986c31ed1ac2,unknown).
0::status(o_a3d49b82fc7264a6ebad,supported); 1::status(o_a3d49b82fc7264a6ebad,refuted); 0::status(o_a3d49b82fc7264a6ebad,unknown).
0.0033512931012975233::status(o_a3d78d0fc95a8628d225,supported); 0::status(o_a3d78d0fc95a8628d225,refuted); 0.99664870689870244::status(o_a3d78d0fc95a8628d225,unknown).
0.99506652355194092::status(o_a4ded78248734d41626d,supported); 0::status(o_a4ded78248734d41626d,refuted); 0.004933476448059082::status(o_a4ded78248734d41626d,unknown).
0.9999997374770605::status(o_a5072ac02de3affc9e60,supported); 0::status(o_a5072ac02de3affc9e60,refuted); 2.6252293949813321e-07::status(o_a5072ac02de3affc9e60,unknown).
0.99969756536284771::status(o_a596942e0cdb492f752a,supported); 0::status(o_a596942e0cdb492f752a,refuted); 0.00030243463715229346::status(o_a596942e0cdb492f752a,unknown).
0.002602787222713232::status(o_a5a73310a7ecafdef3e6,supported); 0::status(o_a5a73310a7ecafdef3e6,refuted); 0.99739721277728677::status(o_a5a73310a7ecafdef3e6,unknown).
0::status(o_a5b8218bfb8e5b4aa030,supported); 1::status(o_a5b8218bfb8e5b4aa030,refuted); 0::status(o_a5b8218bfb8e5b4aa030,unknown).
0.0020350743089324287::status(o_a5bef5aa5fcfe4e31298,supported); 0::status(o_a5bef5aa5fcfe4e31298,refuted); 0.99796492569106754::status(o_a5bef5aa5fcfe4e31298,unknown).
0::status(o_a5dc23ae225d02442c48,supported); 1::status(o_a5dc23ae225d02442c48,refuted); 0::status(o_a5dc23ae225d02442c48,unknown).
0.99999811605901279::status(o_a5e8ca439ddb711acb6f,supported); 0::status(o_a5e8ca439ddb711acb6f,refuted); 1.8839409872128954e-06::status(o_a5e8ca439ddb711acb6f,unknown).
0.99999987409595859::status(o_a62d6af01204425ab611,supported); 0::status(o_a62d6af01204425ab611,refuted); 1.2590404141477052e-07::status(o_a62d6af01204425ab611,unknown).
1::status(o_a68587f531b8bc09f6d6,supported); 0::status(o_a68587f531b8bc09f6d6,refuted); 0::status(o_a68587f531b8bc09f6d6,unknown).
0.99964481635247604::status(o_a69f88c6f9b7a59d2f3b,supported); 0::status(o_a69f88c6f9b7a59d2f3b,refuted); 0.00035518364752396003::status(o_a69f88c6f9b7a59d2f3b,unknown).
1.4511560439441892e-06::status(o_a6ac81f582d19d203086,supported); 0::status(o_a6ac81f582d19d203086,refuted); 0.999998548843956::status(o_a6ac81f582d19d203086,unknown).
0.99981395376311699::status(o_a6d92bca5a7680c71b58,supported); 0::status(o_a6d92bca5a7680c71b58,refuted); 0.00018604623688300848::status(o_a6d92bca5a7680c71b58,unknown).
1::status(o_a6edad1c2656c19e55e5,supported); 0::status(o_a6edad1c2656c19e55e5,refuted); 0::status(o_a6edad1c2656c19e55e5,unknown).
2.5679240045586824e-07::status(o_a6f90de34dff56a7cf0e,supported); 0::status(o_a6f90de34dff56a7cf0e,refuted); 0.99999974320759955::status(o_a6f90de34dff56a7cf0e,unknown).
0.066804807499719648::status(o_a78bf4cc3ba494b53928,supported); 0::status(o_a78bf4cc3ba494b53928,refuted); 0.93319519250028038::status(o_a78bf4cc3ba494b53928,unknown).
0.99981849066906681::status(o_a7f87e2723618759a4ae,supported); 0::status(o_a7f87e2723618759a4ae,refuted); 0.00018150933093319388::status(o_a7f87e2723618759a4ae,unknown).
0.99999964331402236::status(o_a85c60c303535c9e37cb,supported); 0::status(o_a85c60c303535c9e37cb,refuted); 3.5668597764271226e-07::status(o_a85c60c303535c9e37cb,unknown).
4.2038271418984164e-07::status(o_a86a524061215ba5095a,supported); 0::status(o_a86a524061215ba5095a,refuted); 0.99999957961728581::status(o_a86a524061215ba5095a,unknown).
0.98928332328796387::status(o_a8f64c38b70984d54fe6,supported); 0::status(o_a8f64c38b70984d54fe6,refuted); 0.010716676712036133::status(o_a8f64c38b70984d54fe6,unknown).
0.99986850708269226::status(o_a9413655a7829e10b034,supported); 0::status(o_a9413655a7829e10b034,refuted); 0.0001314929173077406::status(o_a9413655a7829e10b034,unknown).
6.146516897648907e-06::status(o_a9899d0435a6f5cc21a5,supported); 0::status(o_a9899d0435a6f5cc21a5,refuted); 0.99999385348310232::status(o_a9899d0435a6f5cc21a5,unknown).
0.99999730550533539::status(o_a9a71c550435a9b5f458,supported); 0::status(o_a9a71c550435a9b5f458,refuted); 2.6944946646123569e-06::status(o_a9a71c550435a9b5f458,unknown).
2.4976663312887304e-06::status(o_aa280bf8ca92eb393367,supported); 0::status(o_aa280bf8ca92eb393367,refuted); 0.99999750233366869::status(o_aa280bf8ca92eb393367,unknown).
0.0070060962520664743::status(o_aa47169f475643434256,supported); 0::status(o_aa47169f475643434256,refuted); 0.9929939037479335::status(o_aa47169f475643434256,unknown).
1.134237811956457e-06::status(o_aa69a86b7fc2e0e9e895,supported); 0::status(o_aa69a86b7fc2e0e9e895,refuted); 0.99999886576218799::status(o_aa69a86b7fc2e0e9e895,unknown).
0.99999691607382513::status(o_aa815e279f14b096ff07,supported); 0::status(o_aa815e279f14b096ff07,refuted); 3.0839261748738522e-06::status(o_aa815e279f14b096ff07,unknown).
0.99999998244632882::status(o_aad9276d5b0fbab5593f,supported); 0::status(o_aad9276d5b0fbab5593f,refuted); 1.7553671183279107e-08::status(o_aad9276d5b0fbab5593f,unknown).
2.659361886107589e-08::status(o_aafb03b5ef24fcb52612,supported); 0::status(o_aafb03b5ef24fcb52612,refuted); 0.99999997340638114::status(o_aafb03b5ef24fcb52612,unknown).
0.00044824578799307346::status(o_ab081b90bc561808b3ea,supported); 0::status(o_ab081b90bc561808b3ea,refuted); 0.99955175421200693::status(o_ab081b90bc561808b3ea,unknown).
0.0020350743089324287::status(o_ab08fdf6a824c703e196,supported); 0::status(o_ab08fdf6a824c703e196,refuted); 0.99796492569106754::status(o_ab08fdf6a824c703e196,unknown).
5.5101139844798569e-05::status(o_ab2add253af7154bfdc5,supported); 0::status(o_ab2add253af7154bfdc5,refuted); 0.99994489886015525::status(o_ab2add253af7154bfdc5,unknown).
1::status(o_ab35433ed82c6a74bf24,supported); 0::status(o_ab35433ed82c6a74bf24,refuted); 0::status(o_ab35433ed82c6a74bf24,unknown).
1::status(o_ab3a6fda92bd5e97f565,supported); 0::status(o_ab3a6fda92bd5e97f565,refuted); 0::status(o_ab3a6fda92bd5e97f565,unknown).
0.99999999827831965::status(o_ab4928d5d94b427096b0,supported); 0::status(o_ab4928d5d94b427096b0,refuted); 1.7216803538389058e-09::status(o_ab4928d5d94b427096b0,unknown).
0.00045137316919863224::status(o_abb36428887f039587c9,supported); 0::status(o_abb36428887f039587c9,refuted); 0.99954862683080137::status(o_abb36428887f039587c9,unknown).
0.99999998716797778::status(o_abb899e60839e5a158ae,supported); 0::status(o_abb899e60839e5a158ae,refuted); 1.283202222257529e-08::status(o_abb899e60839e5a158ae,unknown).
0.99492681207231914::status(o_abdb1258e0f2118dd6d1,supported); 0::status(o_abdb1258e0f2118dd6d1,refuted); 0.0050731879276808556::status(o_abdb1258e0f2118dd6d1,unknown).
1::status(o_abff36a2d0e9ebbcb35a,supported); 0::status(o_abff36a2d0e9ebbcb35a,refuted); 0::status(o_abff36a2d0e9ebbcb35a,unknown).
1::status(o_ac1bcb2fb29a858d4d2e,supported); 0::status(o_ac1bcb2fb29a858d4d2e,refuted); 0::status(o_ac1bcb2fb29a858d4d2e,unknown).
2.964500090961157e-05::status(o_ac6490f7cfdb497e9a9e,supported); 0::status(o_ac6490f7cfdb497e9a9e,refuted); 0.99997035499909037::status(o_ac6490f7cfdb497e9a9e,unknown).
1.709237322971677e-09::status(o_ace4cad0c568390e7df3,supported); 0::status(o_ace4cad0c568390e7df3,refuted); 0.99999999829076269::status(o_ace4cad0c568390e7df3,unknown).
0.99999992580897223::status(o_acf8d83f7f894f98b977,supported); 0::status(o_acf8d83f7f894f98b977,refuted); 7.4191027765735384e-08::status(o_acf8d83f7f894f98b977,unknown).
0::status(o_ad1ede6da12b16e19f8f,supported); 1::status(o_ad1ede6da12b16e19f8f,refuted); 0::status(o_ad1ede6da12b16e19f8f,unknown).
1::status(o_ad487b050f2c1c0c9f13,supported); 0::status(o_ad487b050f2c1c0c9f13,refuted); 0::status(o_ad487b050f2c1c0c9f13,unknown).
0::status(o_ad8632f4fd2a33f45a3e,supported); 1::status(o_ad8632f4fd2a33f45a3e,refuted); 0::status(o_ad8632f4fd2a33f45a3e,unknown).
3.2482797206823362e-07::status(o_ad961dcc306cafbb16e9,supported); 0::status(o_ad961dcc306cafbb16e9,refuted); 0.99999967517202792::status(o_ad961dcc306cafbb16e9,unknown).
0::status(o_ada382440bc5c753506a,supported); 1::status(o_ada382440bc5c753506a,refuted); 0::status(o_ada382440bc5c753506a,unknown).
0.69931845840447693::status(o_ada7ab6a3223ca399cf7,supported); 0::status(o_ada7ab6a3223ca399cf7,refuted); 0.30068154159552307::status(o_ada7ab6a3223ca399cf7,unknown).
0::status(o_ae0363c9e2e526a4ddf2,supported); 1::status(o_ae0363c9e2e526a4ddf2,refuted); 0::status(o_ae0363c9e2e526a4ddf2,unknown).
0.0001668355253059417::status(o_ae07b2d9c4914c6c0cb8,supported); 0::status(o_ae07b2d9c4914c6c0cb8,refuted); 0.99983316447469406::status(o_ae07b2d9c4914c6c0cb8,unknown).
1::status(o_ae7650a90aa23c291995,supported); 0::status(o_ae7650a90aa23c291995,refuted); 0::status(o_ae7650a90aa23c291995,unknown).
0.69931845840447693::status(o_aed4955ac51c7f0c97d6,supported); 0::status(o_aed4955ac51c7f0c97d6,refuted); 0.30068154159552307::status(o_aed4955ac51c7f0c97d6,unknown).
1::status(o_aed4ab3133197d75432b,supported); 0::status(o_aed4ab3133197d75432b,refuted); 0::status(o_aed4ab3133197d75432b,unknown).
0.99986850708269226::status(o_af1d606e17ce67c123e7,supported); 0::status(o_af1d606e17ce67c123e7,refuted); 0.0001314929173077406::status(o_af1d606e17ce67c123e7,unknown).
2.9835346984907715e-06::status(o_af46469a7bb664fae51f,supported); 0::status(o_af46469a7bb664fae51f,refuted); 0.99999701646530148::status(o_af46469a7bb664fae51f,unknown).
0.011508996621853498::status(o_af8c70fcd4d37a470ec0,supported); 0::status(o_af8c70fcd4d37a470ec0,refuted); 0.98849100337814655::status(o_af8c70fcd4d37a470ec0,unknown).
0.99999987912775168::status(o_b08059c328fac992f433,supported); 0::status(o_b08059c328fac992f433,refuted); 1.2087224832146859e-07::status(o_b08059c328fac992f433,unknown).
0.99991537478661774::status(o_b0b85fd1712f1a733c85,supported); 0::status(o_b0b85fd1712f1a733c85,refuted); 8.4625213382261144e-05::status(o_b0b85fd1712f1a733c85,unknown).
1::status(o_b10ea0a60a6e283cbdf2,supported); 0::status(o_b10ea0a60a6e283cbdf2,refuted); 0::status(o_b10ea0a60a6e283cbdf2,unknown).
1.3871065855594944e-05::status(o_b12095df7fe05fd6066c,supported); 0::status(o_b12095df7fe05fd6066c,refuted); 0.9999861289341444::status(o_b12095df7fe05fd6066c,unknown).
0.99007987976074219::status(o_b1e7458bd3ce2cbe8fd1,supported); 0::status(o_b1e7458bd3ce2cbe8fd1,refuted); 0.0099201202392578125::status(o_b1e7458bd3ce2cbe8fd1,unknown).
1.1326341640430422e-06::status(o_b23f08e6804f3ef76fc9,supported); 0::status(o_b23f08e6804f3ef76fc9,refuted); 0.99999886736583599::status(o_b23f08e6804f3ef76fc9,unknown).
0.99999992072483646::status(o_b29e59686e05cf7bdeb2,supported); 0::status(o_b29e59686e05cf7bdeb2,refuted); 7.9275163544778593e-08::status(o_b29e59686e05cf7bdeb2,unknown).
0.00027707242373065007::status(o_b2da8d2847914fa66c47,supported); 0::status(o_b2da8d2847914fa66c47,refuted); 0.99972292757626935::status(o_b2da8d2847914fa66c47,unknown).
0.40906063893112277::status(o_b2e0e2dd2c2b99b4d2f8,supported); 0::status(o_b2e0e2dd2c2b99b4d2f8,refuted); 0.59093936106887723::status(o_b2e0e2dd2c2b99b4d2f8,unknown).
1::status(o_b2e8ecc179ef5ee152f6,supported); 0::status(o_b2e8ecc179ef5ee152f6,refuted); 0::status(o_b2e8ecc179ef5ee152f6,unknown).
1::status(o_b38149e79a9ea4fadfbf,supported); 0::status(o_b38149e79a9ea4fadfbf,refuted); 0::status(o_b38149e79a9ea4fadfbf,unknown).
0.00024648782915689162::status(o_b38e98b359e24159ffe7,supported); 0::status(o_b38e98b359e24159ffe7,refuted); 0.99975351217084307::status(o_b38e98b359e24159ffe7,unknown).
1.1341866148431104e-06::status(o_b3add89a1e3dd582be95,supported); 0::status(o_b3add89a1e3dd582be95,refuted); 0.99999886581338515::status(o_b3add89a1e3dd582be95,unknown).
0::status(o_b3d2c1398eb36c39e4db,supported); 1::status(o_b3d2c1398eb36c39e4db,refuted); 0::status(o_b3d2c1398eb36c39e4db,unknown).
0.99999957329941025::status(o_b3de788de87fd49a8b5b,supported); 0::status(o_b3de788de87fd49a8b5b,refuted); 4.267005897506948e-07::status(o_b3de788de87fd49a8b5b,unknown).
0.99999730550533539::status(o_b3e04498fa63fb08a414,supported); 0::status(o_b3e04498fa63fb08a414,refuted); 2.6944946646123569e-06::status(o_b3e04498fa63fb08a414,unknown).
0.0071083765268546645::status(o_b4585eb123471c6fd0bc,supported); 0::status(o_b4585eb123471c6fd0bc,refuted); 0.9928916234731453::status(o_b4585eb123471c6fd0bc,unknown).
1::status(o_b542e65140eed93920f5,supported); 0::status(o_b542e65140eed93920f5,refuted); 0::status(o_b542e65140eed93920f5,unknown).
0.99999999827831965::status(o_b56868647643f8ca6914,supported); 0::status(o_b56868647643f8ca6914,refuted); 1.7216803538389058e-09::status(o_b56868647643f8ca6914,unknown).
0.070867766607818697::status(o_b582f00dbc271d39f4a1,supported); 0::status(o_b582f00dbc271d39f4a1,refuted); 0.92913223339218132::status(o_b582f00dbc271d39f4a1,unknown).
0.0050932755693793297::status(o_b6198dcb4c517634438d,supported); 0::status(o_b6198dcb4c517634438d,refuted); 0.99490672443062067::status(o_b6198dcb4c517634438d,unknown).
0.99999910404853032::status(o_b6592c0778d5ae83fbb6,supported); 0::status(o_b6592c0778d5ae83fbb6,refuted); 8.9595146968157735e-07::status(o_b6592c0778d5ae83fbb6,unknown).
0.99991537478661774::status(o_b6c2cbe60171a499ef21,supported); 0::status(o_b6c2cbe60171a499ef21,refuted); 8.4625213382261144e-05::status(o_b6c2cbe60171a499ef21,unknown).
0.0060011227615177631::status(o_b6da7082fcfffa942afc,supported); 0::status(o_b6da7082fcfffa942afc,refuted); 0.99399887723848224::status(o_b6da7082fcfffa942afc,unknown).
1::status(o_b7592dc456a5bedaf940,supported); 0::status(o_b7592dc456a5bedaf940,refuted); 0::status(o_b7592dc456a5bedaf940,unknown).
0.99954386777280857::status(o_b78e9789bd074dd0e7b0,supported); 0::status(o_b78e9789bd074dd0e7b0,refuted); 0.00045613222719143032::status(o_b78e9789bd074dd0e7b0,unknown).
0.73811351400821135::status(o_b79af642d2eb4e465c09,supported); 0::status(o_b79af642d2eb4e465c09,refuted); 0.26188648599178865::status(o_b79af642d2eb4e465c09,unknown).
1::status(o_b84ca2f7dd808b71f241,supported); 0::status(o_b84ca2f7dd808b71f241,refuted); 0::status(o_b84ca2f7dd808b71f241,unknown).
3.9539527097963542e-06::status(o_b879e4b1386f5c36efe6,supported); 0::status(o_b879e4b1386f5c36efe6,refuted); 0.9999960460472902::status(o_b879e4b1386f5c36efe6,unknown).
1::status(o_b88a0db577e10602a8e6,supported); 0::status(o_b88a0db577e10602a8e6,refuted); 0::status(o_b88a0db577e10602a8e6,unknown).
0.50441722518680632::status(o_b8ba8dc852844048c4a7,supported); 0::status(o_b8ba8dc852844048c4a7,refuted); 0.49558277481319368::status(o_b8ba8dc852844048c4a7,unknown).
1::status(o_b90275f9aae920038ffa,supported); 0::status(o_b90275f9aae920038ffa,refuted); 0::status(o_b90275f9aae920038ffa,unknown).
4.1145860368124536e-05::status(o_b907b6b19cdaaaea849c,supported); 0::status(o_b907b6b19cdaaaea849c,refuted); 0.99995885413963193::status(o_b907b6b19cdaaaea849c,unknown).
0.99999983246230739::status(o_b9381e767327151e2f41,supported); 0::status(o_b9381e767327151e2f41,refuted); 1.6753769260802187e-07::status(o_b9381e767327151e2f41,unknown).
1::status(o_b948db4b7c6fa9b55a94,supported); 0::status(o_b948db4b7c6fa9b55a94,refuted); 0::status(o_b948db4b7c6fa9b55a94,unknown).
0.004732172042544433::status(o_b98839ae7e8bd865fa50,supported); 0::status(o_b98839ae7e8bd865fa50,refuted); 0.99526782795745561::status(o_b98839ae7e8bd865fa50,unknown).
1::status(o_b9c0b64a722bc7a7aa97,supported); 0::status(o_b9c0b64a722bc7a7aa97,refuted); 0::status(o_b9c0b64a722bc7a7aa97,unknown).
1::status(o_ba4d4e5aaa4c7d3a761b,supported); 0::status(o_ba4d4e5aaa4c7d3a761b,refuted); 0::status(o_ba4d4e5aaa4c7d3a761b,unknown).
0.99999998716797778::status(o_ba7dee39b29f8d1d9bea,supported); 0::status(o_ba7dee39b29f8d1d9bea,refuted); 1.283202222257529e-08::status(o_ba7dee39b29f8d1d9bea,unknown).
0.99999992072483646::status(o_bad1802578d39e3aad5f,supported); 0::status(o_bad1802578d39e3aad5f,refuted); 7.9275163544778593e-08::status(o_bad1802578d39e3aad5f,unknown).
0.0033596660356459839::status(o_baf788ab55cf8cdc5ae2,supported); 0::status(o_baf788ab55cf8cdc5ae2,refuted); 0.99664033396435403::status(o_baf788ab55cf8cdc5ae2,unknown).
0.89999573912569597::status(o_bb0f462adc4218b7c1b0,supported); 0::status(o_bb0f462adc4218b7c1b0,refuted); 0.10000426087430403::status(o_bb0f462adc4218b7c1b0,unknown).
3.0788986898399006e-06::status(o_bb880cbcf680890dc13f,supported); 0::status(o_bb880cbcf680890dc13f,refuted); 0.99999692110131011::status(o_bb880cbcf680890dc13f,unknown).
0.98071907652205503::status(o_bbc86d529139754841f3,supported); 0::status(o_bbc86d529139754841f3,refuted); 0.019280923477944967::status(o_bbc86d529139754841f3,unknown).
6.4896452275927255e-08::status(o_bbd643ab513131d0dc7a,supported); 0::status(o_bbd643ab513131d0dc7a,refuted); 0.99999993510354768::status(o_bbd643ab513131d0dc7a,unknown).
4.2283380025764927e-05::status(o_bc90005c66df9816d858,supported); 0::status(o_bc90005c66df9816d858,refuted); 0.99995771661997424::status(o_bc90005c66df9816d858,unknown).
3.1648520225863829e-06::status(o_bd110358e590f87cabed,supported); 0::status(o_bd110358e590f87cabed,refuted); 0.99999683514797744::status(o_bd110358e590f87cabed,unknown).
1::status(o_bd12b7177218af934894,supported); 0::status(o_bd12b7177218af934894,refuted); 0::status(o_bd12b7177218af934894,unknown).
0.99876297288292504::status(o_bd209f534526335fa87c,supported); 0::status(o_bd209f534526335fa87c,refuted); 0.0012370271170749625::status(o_bd209f534526335fa87c,unknown).
0.96967961634467392::status(o_bd35ae02a2a74912f63e,supported); 0::status(o_bd35ae02a2a74912f63e,refuted); 0.030320383655326077::status(o_bd35ae02a2a74912f63e,unknown).
0.014693513442172146::status(o_bd382028ee5f1bc36359,supported); 0::status(o_bd382028ee5f1bc36359,refuted); 0.98530648655782782::status(o_bd382028ee5f1bc36359,unknown).
0.99978371589185011::status(o_bd44423cc9dde20859d4,supported); 0::status(o_bd44423cc9dde20859d4,refuted); 0.00021628410814988897::status(o_bd44423cc9dde20859d4,unknown).
1::status(o_bd762be8d8fe921a17c3,supported); 0::status(o_bd762be8d8fe921a17c3,refuted); 0::status(o_bd762be8d8fe921a17c3,unknown).
0.070867766607818697::status(o_bdba07b9fc902d24db96,supported); 0::status(o_bdba07b9fc902d24db96,refuted); 0.92913223339218132::status(o_bdba07b9fc902d24db96,unknown).
1.256644413556593e-08::status(o_be4e8fb5f97cc67e4ee9,supported); 0::status(o_be4e8fb5f97cc67e4ee9,refuted); 0.99999998743355589::status(o_be4e8fb5f97cc67e4ee9,unknown).
0.99999998873827356::status(o_beb8ca0934ea0da80a69,supported); 0::status(o_beb8ca0934ea0da80a69,refuted); 1.126172644028145e-08::status(o_beb8ca0934ea0da80a69,unknown).
2.9835346984907715e-06::status(o_beca17c645ddd54bf4e6,supported); 0::status(o_beca17c645ddd54bf4e6,refuted); 0.99999701646530148::status(o_beca17c645ddd54bf4e6,unknown).
1::status(o_bf0eeadaa213a18ef935,supported); 0::status(o_bf0eeadaa213a18ef935,refuted); 0::status(o_bf0eeadaa213a18ef935,unknown).
0.99999084716085185::status(o_bf91dc8699285fa2353e,supported); 0::status(o_bf91dc8699285fa2353e,refuted); 9.1528391481521254e-06::status(o_bf91dc8699285fa2353e,unknown).
1::status(o_bfa0db2cc3ce43f56517,supported); 0::status(o_bfa0db2cc3ce43f56517,refuted); 0::status(o_bfa0db2cc3ce43f56517,unknown).
1::status(o_c06fd871273a6216d27f,supported); 0::status(o_c06fd871273a6216d27f,refuted); 0::status(o_c06fd871273a6216d27f,unknown).
0.0093391509712997672::status(o_c09170d8e4c2bf8aaa2d,supported); 0::status(o_c09170d8e4c2bf8aaa2d,refuted); 0.99066084902870022::status(o_c09170d8e4c2bf8aaa2d,unknown).
0.99964481635247604::status(o_c0e1c40bbf9e428cd889,supported); 0::status(o_c0e1c40bbf9e428cd889,refuted); 0.00035518364752396003::status(o_c0e1c40bbf9e428cd889,unknown).
2.2699736233417991e-05::status(o_c149cf3e3cfd2bbef6a8,supported); 0::status(o_c149cf3e3cfd2bbef6a8,refuted); 0.99997730026376663::status(o_c149cf3e3cfd2bbef6a8,unknown).
8.8334579666288478e-07::status(o_c15e928222dd2529baea,supported); 0::status(o_c15e928222dd2529baea,refuted); 0.99999911665420338::status(o_c15e928222dd2529baea,unknown).
1::status(o_c1b00583d45b7b41b0b3,supported); 0::status(o_c1b00583d45b7b41b0b3,refuted); 0::status(o_c1b00583d45b7b41b0b3,unknown).
0.74738532304763794::status(o_c1d0a468d80cd1578af4,supported); 0::status(o_c1d0a468d80cd1578af4,refuted); 0.25261467695236206::status(o_c1d0a468d80cd1578af4,unknown).
0.00013554155002503743::status(o_c1e4db37d9d1455a3b2d,supported); 0::status(o_c1e4db37d9d1455a3b2d,refuted); 0.99986445844997496::status(o_c1e4db37d9d1455a3b2d,unknown).
0.68876990696500395::status(o_c207e6316e1d5058ae54,supported); 0::status(o_c207e6316e1d5058ae54,refuted); 0.31123009303499605::status(o_c207e6316e1d5058ae54,unknown).
0.00030407517731461102::status(o_c220f40c2193041a22df,supported); 0::status(o_c220f40c2193041a22df,refuted); 0.99969592482268543::status(o_c220f40c2193041a22df,unknown).
0.9999971777349157::status(o_c288045ad94b023aebe7,supported); 0::status(o_c288045ad94b023aebe7,refuted); 2.8222650843012786e-06::status(o_c288045ad94b023aebe7,unknown).
0.99999851230450709::status(o_c35b9bc02daec097b521,supported); 0::status(o_c35b9bc02daec097b521,refuted); 1.4876954929077257e-06::status(o_c35b9bc02daec097b521,unknown).
0.00013119971225404874::status(o_c372185a0374844fd3b1,supported); 0::status(o_c372185a0374844fd3b1,refuted); 0.99986880028774594::status(o_c372185a0374844fd3b1,unknown).
0.99978179605165418::status(o_c3c19b1dab83f7f749c9,supported); 0::status(o_c3c19b1dab83f7f749c9,refuted); 0.00021820394834581869::status(o_c3c19b1dab83f7f749c9,unknown).
1::status(o_c3f26b04d3451f147006,supported); 0::status(o_c3f26b04d3451f147006,refuted); 0::status(o_c3f26b04d3451f147006,unknown).
0.99995082857550566::status(o_c3ffa9fdb24aab9422aa,supported); 0::status(o_c3ffa9fdb24aab9422aa,refuted); 4.9171424494343086e-05::status(o_c3ffa9fdb24aab9422aa,unknown).
0.61694091558456421::status(o_c4010f88dd20d5a326cf,supported); 0::status(o_c4010f88dd20d5a326cf,refuted); 0.38305908441543579::status(o_c4010f88dd20d5a326cf,unknown).
6.5270009395127061e-06::status(o_c4351ef2e7079be8eeda,supported); 0::status(o_c4351ef2e7079be8eeda,refuted); 0.9999934729990605::status(o_c4351ef2e7079be8eeda,unknown).
0.0070033296942710876::status(o_c43ffa98ff0dfb965a94,supported); 0::status(o_c43ffa98ff0dfb965a94,refuted); 0.99299667030572891::status(o_c43ffa98ff0dfb965a94,unknown).
0.99999811567972463::status(o_c4429c64ed4f656452ef,supported); 0::status(o_c4429c64ed4f656452ef,refuted); 1.8843202753693333e-06::status(o_c4429c64ed4f656452ef,unknown).
1::status(o_c495b76d91324bb051a1,supported); 0::status(o_c495b76d91324bb051a1,refuted); 0::status(o_c495b76d91324bb051a1,unknown).
1::status(o_c50390ebea355f7aaa35,supported); 0::status(o_c50390ebea355f7aaa35,refuted); 0::status(o_c50390ebea355f7aaa35,unknown).
1::status(o_c53804bffb8ed0e4a968,supported); 0::status(o_c53804bffb8ed0e4a968,refuted); 0::status(o_c53804bffb8ed0e4a968,unknown).
0.378240684148061::status(o_c53aa6bf8add47ef84d6,supported); 0::status(o_c53aa6bf8add47ef84d6,refuted); 0.621759315851939::status(o_c53aa6bf8add47ef84d6,unknown).
4.1746293694636073e-07::status(o_c55f57db57d801608117,supported); 0::status(o_c55f57db57d801608117,refuted); 0.999999582537063::status(o_c55f57db57d801608117,unknown).
0.0004814279091078788::status(o_c572a95b4a7bce2f2fb1,supported); 0::status(o_c572a95b4a7bce2f2fb1,refuted); 0.99951857209089212::status(o_c572a95b4a7bce2f2fb1,unknown).
0::status(o_c5ea265751666dec42f7,supported); 1::status(o_c5ea265751666dec42f7,refuted); 0::status(o_c5ea265751666dec42f7,unknown).
1::status(o_c5fa2eaf7c2981fdff97,supported); 0::status(o_c5fa2eaf7c2981fdff97,refuted); 0::status(o_c5fa2eaf7c2981fdff97,unknown).
0.00035486903271498394::status(o_c5fbba8fb0af2c7cf6f4,supported); 0::status(o_c5fbba8fb0af2c7cf6f4,refuted); 0.99964513096728502::status(o_c5fbba8fb0af2c7cf6f4,unknown).
5.0747717808921999e-06::status(o_c6b99994f382ea080a7d,supported); 0::status(o_c6b99994f382ea080a7d,refuted); 0.99999492522821909::status(o_c6b99994f382ea080a7d,unknown).
0.003354658596551997::status(o_c6cd8b6852631d140c52,supported); 0::status(o_c6cd8b6852631d140c52,refuted); 0.99664534140344796::status(o_c6cd8b6852631d140c52,unknown).
1::status(o_c7342ff157047269e43a,supported); 0::status(o_c7342ff157047269e43a,refuted); 0::status(o_c7342ff157047269e43a,unknown).
0.68876990696500395::status(o_c7bfe99f77a2cba070e2,supported); 0::status(o_c7bfe99f77a2cba070e2,refuted); 0.31123009303499605::status(o_c7bfe99f77a2cba070e2,unknown).
1::status(o_c7d2be08cada49b19671,supported); 0::status(o_c7d2be08cada49b19671,refuted); 0::status(o_c7d2be08cada49b19671,unknown).
0.00016834795824150473::status(o_c7e853d7eebb8ea9135a,supported); 0::status(o_c7e853d7eebb8ea9135a,refuted); 0.9998316520417585::status(o_c7e853d7eebb8ea9135a,unknown).
1::status(o_c8a71231ece89c54cf5b,supported); 0::status(o_c8a71231ece89c54cf5b,refuted); 0::status(o_c8a71231ece89c54cf5b,unknown).
0.99985496538327623::status(o_c8c83c24746f4bff99c6,supported); 0::status(o_c8c83c24746f4bff99c6,refuted); 0.00014503461672377149::status(o_c8c83c24746f4bff99c6,unknown).
0.0015857911002918681::status(o_c8d1035e474234fb70cf,supported); 0::status(o_c8d1035e474234fb70cf,refuted); 0.99841420889970811::status(o_c8d1035e474234fb70cf,unknown).
1::status(o_c962032ef8e0fc3e442c,supported); 0::status(o_c962032ef8e0fc3e442c,refuted); 0::status(o_c962032ef8e0fc3e442c,unknown).
0.99999944684311093::status(o_c969bcebaaebc76769bd,supported); 0::status(o_c969bcebaaebc76769bd,refuted); 5.5315688907153771e-07::status(o_c969bcebaaebc76769bd,unknown).
0.988739013671875::status(o_c996c2d2227b47950eb5,supported); 0::status(o_c996c2d2227b47950eb5,refuted); 0.011260986328125::status(o_c996c2d2227b47950eb5,unknown).
0.00096378276237123986::status(o_c99b0a1ffb85579ca7cf,supported); 0::status(o_c99b0a1ffb85579ca7cf,refuted); 0.99903621723762881::status(o_c99b0a1ffb85579ca7cf,unknown).
0.014693513442172146::status(o_c99dab4bce1e6a5fe904,supported); 0::status(o_c99dab4bce1e6a5fe904,refuted); 0.98530648655782782::status(o_c99dab4bce1e6a5fe904,unknown).
0.61071423813271009::status(o_c9a776ae447f44e9c017,supported); 0::status(o_c9a776ae447f44e9c017,refuted); 0.38928576186728991::status(o_c9a776ae447f44e9c017,unknown).
0.99999841824856839::status(o_ca4926d30f536418ea4f,supported); 0::status(o_ca4926d30f536418ea4f,refuted); 1.5817514316118775e-06::status(o_ca4926d30f536418ea4f,unknown).
1.3523938199314318e-07::status(o_ca6414747a2e3f760287,supported); 0::status(o_ca6414747a2e3f760287,refuted); 0.99999986476061797::status(o_ca6414747a2e3f760287,unknown).
1::status(o_cad5724412c44adabf7d,supported); 0::status(o_cad5724412c44adabf7d,refuted); 0::status(o_cad5724412c44adabf7d,unknown).
4.9145063431047793e-05::status(o_cb089fcbbe9767b7327a,supported); 0::status(o_cb089fcbbe9767b7327a,refuted); 0.99995085493656899::status(o_cb089fcbbe9767b7327a,unknown).
4.8156220751304061e-05::status(o_cb23442a430b57b88624,supported); 0::status(o_cb23442a430b57b88624,refuted); 0.99995184377924873::status(o_cb23442a430b57b88624,unknown).
0.99414408406556098::status(o_cb3cb7887c70bc274e1a,supported); 0::status(o_cb3cb7887c70bc274e1a,refuted); 0.0058559159344390155::status(o_cb3cb7887c70bc274e1a,unknown).
3.2482797206823362e-07::status(o_cbb4b9575ece5dc92dc1,supported); 0::status(o_cbb4b9575ece5dc92dc1,refuted); 0.99999967517202792::status(o_cbb4b9575ece5dc92dc1,unknown).
1::status(o_cbf23ee1358e61bea908,supported); 0::status(o_cbf23ee1358e61bea908,refuted); 0::status(o_cbf23ee1358e61bea908,unknown).
0.0010018589673563838::status(o_cc630dc0fe728cbd1825,supported); 0::status(o_cc630dc0fe728cbd1825,refuted); 0.99899814103264362::status(o_cc630dc0fe728cbd1825,unknown).
0.00073105525015214367::status(o_cc7292526013fa2a1a4c,supported); 0::status(o_cc7292526013fa2a1a4c,refuted); 0.99926894474984784::status(o_cc7292526013fa2a1a4c,unknown).
0.99964323617997897::status(o_cc7b6e17b8da4f7d1b7b,supported); 0::status(o_cc7b6e17b8da4f7d1b7b,refuted); 0.00035676382002103324::status(o_cc7b6e17b8da4f7d1b7b,unknown).
1.709237322971677e-09::status(o_cc7c28954943edd5fc1f,supported); 0::status(o_cc7c28954943edd5fc1f,refuted); 0.99999999829076269::status(o_cc7c28954943edd5fc1f,unknown).
2.2732953732053438e-05::status(o_cd1b608b189c789b9629,supported); 0::status(o_cd1b608b189c789b9629,refuted); 0.99997726704626799::status(o_cd1b608b189c789b9629,unknown).
0.0033596660356459839::status(o_cd3137c453912cda677b,supported); 0::status(o_cd3137c453912cda677b,refuted); 0.99664033396435403::status(o_cd3137c453912cda677b,unknown).
1::status(o_cd54a64bf3f9af7dd4ca,supported); 0::status(o_cd54a64bf3f9af7dd4ca,refuted); 0::status(o_cd54a64bf3f9af7dd4ca,unknown).
0.99999996539626701::status(o_cd56cdf8f4aef4759513,supported); 0::status(o_cd56cdf8f4aef4759513,refuted); 3.4603732990134972e-08::status(o_cd56cdf8f4aef4759513,unknown).
0::status(o_cd613265cd1c24a0126f,supported); 1::status(o_cd613265cd1c24a0126f,refuted); 0::status(o_cd613265cd1c24a0126f,unknown).
0.0043052313349343447::status(o_cdeca8eeb3fbda1aa24b,supported); 0::status(o_cdeca8eeb3fbda1aa24b,refuted); 0.99569476866506568::status(o_cdeca8eeb3fbda1aa24b,unknown).
0.65991017137378538::status(o_ce3e0b1d14622325cba4,supported); 0::status(o_ce3e0b1d14622325cba4,refuted); 0.34008982862621462::status(o_ce3e0b1d14622325cba4,unknown).
1::status(o_ce6f0fe5ffbf952258f9,supported); 0::status(o_ce6f0fe5ffbf952258f9,refuted); 0::status(o_ce6f0fe5ffbf952258f9,unknown).
0.0013882720377296209::status(o_ceffc576b1df0a12075c,supported); 0::status(o_ceffc576b1df0a12075c,refuted); 0.99861172796227038::status(o_ceffc576b1df0a12075c,unknown).
0.067158885300159454::status(o_cf2fae3140c98371428e,supported); 0::status(o_cf2fae3140c98371428e,refuted); 0.93284111469984055::status(o_cf2fae3140c98371428e,unknown).
0.0041071532961066259::status(o_cf592a381edc0896fee2,supported); 0::status(o_cf592a381edc0896fee2,refuted); 0.99589284670389333::status(o_cf592a381edc0896fee2,unknown).
1.9543818213611758e-05::status(o_cf5b840eeaf8532c4cf7,supported); 0::status(o_cf5b840eeaf8532c4cf7,refuted); 0.99998045618178644::status(o_cf5b840eeaf8532c4cf7,unknown).
0.99185353517532349::status(o_cf686954e3e926a159c1,supported); 0::status(o_cf686954e3e926a159c1,refuted); 0.0081464648246765137::status(o_cf686954e3e926a159c1,unknown).
0.99414408406556098::status(o_cff608308240351f5b86,supported); 0::status(o_cff608308240351f5b86,refuted); 0.0058559159344390155::status(o_cff608308240351f5b86,unknown).
0.00039488702896051109::status(o_d0441a8ef1717855f6d3,supported); 0::status(o_d0441a8ef1717855f6d3,refuted); 0.99960511297103949::status(o_d0441a8ef1717855f6d3,unknown).
1::status(o_d07331ef307f5570fa81,supported); 0::status(o_d07331ef307f5570fa81,refuted); 0::status(o_d07331ef307f5570fa81,unknown).
0.99887460470199585::status(o_d0962efd3b3365eea7f8,supported); 0::status(o_d0962efd3b3365eea7f8,refuted); 0.0011253952980041504::status(o_d0962efd3b3365eea7f8,unknown).
1::status(o_d0bcaf3ca68997dc6a69,supported); 0::status(o_d0bcaf3ca68997dc6a69,refuted); 0::status(o_d0bcaf3ca68997dc6a69,unknown).
0.98598873615264893::status(o_d0cbc0de5af2d9c48df8,supported); 0::status(o_d0cbc0de5af2d9c48df8,refuted); 0.014011263847351074::status(o_d0cbc0de5af2d9c48df8,unknown).
0.0093486057594418526::status(o_d130d797f4a5a0238738,supported); 0::status(o_d130d797f4a5a0238738,refuted); 0.99065139424055815::status(o_d130d797f4a5a0238738,unknown).
1::status(o_d1bf99e344a2702fcee1,supported); 0::status(o_d1bf99e344a2702fcee1,refuted); 0::status(o_d1bf99e344a2702fcee1,unknown).
1.5427439770380169e-07::status(o_d1eecfd8faf69578c636,supported); 0::status(o_d1eecfd8faf69578c636,refuted); 0.9999998457256023::status(o_d1eecfd8faf69578c636,unknown).
0.99213320016860962::status(o_d2627137402160e4f678,supported); 0::status(o_d2627137402160e4f678,refuted); 0.0078667998313903809::status(o_d2627137402160e4f678,unknown).
0.99524873495101929::status(o_d28003caa0a2297d4738,supported); 0::status(o_d28003caa0a2297d4738,refuted); 0.0047512650489807129::status(o_d28003caa0a2297d4738,unknown).
0.99999096451664449::status(o_d2cf8b56a70e97807382,supported); 0::status(o_d2cf8b56a70e97807382,refuted); 9.0354833555128522e-06::status(o_d2cf8b56a70e97807382,unknown).
1.7690656117834124e-05::status(o_d31ade2afb018c75fe61,supported); 0::status(o_d31ade2afb018c75fe61,refuted); 0.99998230934388221::status(o_d31ade2afb018c75fe61,unknown).
0.018944852536761814::status(o_d336ac63513450cce26c,supported); 0::status(o_d336ac63513450cce26c,refuted); 0.98105514746323819::status(o_d336ac63513450cce26c,unknown).
1::status(o_d3490d8637e891875156,supported); 0::status(o_d3490d8637e891875156,refuted); 0::status(o_d3490d8637e891875156,unknown).
0.018551224042092456::status(o_d381bbd170f5f33bc04e,supported); 0::status(o_d381bbd170f5f33bc04e,refuted); 0.98144877595790758::status(o_d381bbd170f5f33bc04e,unknown).
0.99999998873827356::status(o_d3b78e17cea7d0247cab,supported); 0::status(o_d3b78e17cea7d0247cab,refuted); 1.126172644028145e-08::status(o_d3b78e17cea7d0247cab,unknown).
0.98706090450286865::status(o_d42deff94728076a9823,supported); 0::status(o_d42deff94728076a9823,refuted); 0.012939095497131348::status(o_d42deff94728076a9823,unknown).
0.99950693702381521::status(o_d45a8408c07e3f494380,supported); 0::status(o_d45a8408c07e3f494380,refuted); 0.00049306297618478823::status(o_d45a8408c07e3f494380,unknown).
0.0016958331689238548::status(o_d493d0a37cac3e84312b,supported); 0::status(o_d493d0a37cac3e84312b,refuted); 0.99830416683107615::status(o_d493d0a37cac3e84312b,unknown).
6.8628094811873742e-07::status(o_d4f607678494c3b1187c,supported); 0::status(o_d4f607678494c3b1187c,refuted); 0.99999931371905193::status(o_d4f607678494c3b1187c,unknown).
0.99981849066906681::status(o_d517d2c477e42643fd1d,supported); 0::status(o_d517d2c477e42643fd1d,refuted); 0.00018150933093319388::status(o_d517d2c477e42643fd1d,unknown).
1::status(o_d560820296afe1f40af4,supported); 0::status(o_d560820296afe1f40af4,refuted); 0::status(o_d560820296afe1f40af4,unknown).
0.070867766607818697::status(o_d5705b273125818b726a,supported); 0::status(o_d5705b273125818b726a,refuted); 0.92913223339218132::status(o_d5705b273125818b726a,unknown).
1.7692152154538707e-05::status(o_d5d704d59660457007ec,supported); 0::status(o_d5d704d59660457007ec,refuted); 0.99998230784784548::status(o_d5d704d59660457007ec,unknown).
0.0067142620652578602::status(o_d5ed9e5b3ffd9412ef53,supported); 0::status(o_d5ed9e5b3ffd9412ef53,refuted); 0.99328573793474217::status(o_d5ed9e5b3ffd9412ef53,unknown).
1::status(o_d694712a3037b095ce1a,supported); 0::status(o_d694712a3037b095ce1a,refuted); 0::status(o_d694712a3037b095ce1a,unknown).
0.99999991052597204::status(o_d69722e0f08f607956ac,supported); 0::status(o_d69722e0f08f607956ac,refuted); 8.9474027964442371e-08::status(o_d69722e0f08f607956ac,unknown).
0.017168149352073669::status(o_d71534db61997165694f,supported); 0::status(o_d71534db61997165694f,refuted); 0.98283185064792633::status(o_d71534db61997165694f,unknown).
0.00096456717105419213::status(o_d76ea98883c307a83355,supported); 0::status(o_d76ea98883c307a83355,refuted); 0.9990354328289458::status(o_d76ea98883c307a83355,unknown).
0::status(o_d7988eb331fd3b44c5ff,supported); 1::status(o_d7988eb331fd3b44c5ff,refuted); 0::status(o_d7988eb331fd3b44c5ff,unknown).
1::status(o_d82bd5dab3c9278cc648,supported); 0::status(o_d82bd5dab3c9278cc648,refuted); 0::status(o_d82bd5dab3c9278cc648,unknown).
1::status(o_d8db77b3e349c0a4722d,supported); 0::status(o_d8db77b3e349c0a4722d,refuted); 0::status(o_d8db77b3e349c0a4722d,unknown).
0::status(o_d97e883d577304530102,supported); 1::status(o_d97e883d577304530102,refuted); 0::status(o_d97e883d577304530102,unknown).
0.037853103131055832::status(o_da965b02af937e2e7e7c,supported); 0::status(o_da965b02af937e2e7e7c,refuted); 0.96214689686894417::status(o_da965b02af937e2e7e7c,unknown).
0.99098694570899437::status(o_da9bfd1a9ce0d58182cc,supported); 0::status(o_da9bfd1a9ce0d58182cc,refuted); 0.0090130542910056288::status(o_da9bfd1a9ce0d58182cc,unknown).
0.99999969610069539::status(o_dae7c4a5d3bf432080a8,supported); 0::status(o_dae7c4a5d3bf432080a8,refuted); 3.0389930461005576e-07::status(o_dae7c4a5d3bf432080a8,unknown).
1::status(o_db40faa3025449a16bcb,supported); 0::status(o_db40faa3025449a16bcb,refuted); 0::status(o_db40faa3025449a16bcb,unknown).
0.99794512987136841::status(o_db481b9f3c92f3c0d928,supported); 0::status(o_db481b9f3c92f3c0d928,refuted); 0.0020548701286315918::status(o_db481b9f3c92f3c0d928,unknown).
1::status(o_db5c098b729c56b25252,supported); 0::status(o_db5c098b729c56b25252,refuted); 0::status(o_db5c098b729c56b25252,unknown).
0.00010203728353087578::status(o_db8926506bfba2edfb38,supported); 0::status(o_db8926506bfba2edfb38,refuted); 0.99989796271646914::status(o_db8926506bfba2edfb38,unknown).
0.99999343413011421::status(o_dc0d0bc1b798d1d39a03,supported); 0::status(o_dc0d0bc1b798d1d39a03,refuted); 6.5658698857884445e-06::status(o_dc0d0bc1b798d1d39a03,unknown).
1.3019815249289163e-07::status(o_dc206f3dd6ac20b636ec,supported); 0::status(o_dc206f3dd6ac20b636ec,refuted); 0.99999986980184752::status(o_dc206f3dd6ac20b636ec,unknown).
1::status(o_dc5de3b50cc503b0b7c4,supported); 0::status(o_dc5de3b50cc503b0b7c4,refuted); 0::status(o_dc5de3b50cc503b0b7c4,unknown).
0.096061237156391144::status(o_dc613e2e64d0208da85f,supported); 0::status(o_dc613e2e64d0208da85f,refuted); 0.90393876284360886::status(o_dc613e2e64d0208da85f,unknown).
1.9662205308173876e-07::status(o_dcb328c8d7ba0fef5af8,supported); 0::status(o_dcb328c8d7ba0fef5af8,refuted); 0.99999980337794692::status(o_dcb328c8d7ba0fef5af8,unknown).
0.99999472206484685::status(o_dcb3fe05b05612ad55ec,supported); 0::status(o_dcb3fe05b05612ad55ec,refuted); 5.2779351531473395e-06::status(o_dcb3fe05b05612ad55ec,unknown).
1::status(o_dd74d631ac51b9a9dcd7,supported); 0::status(o_dd74d631ac51b9a9dcd7,refuted); 0::status(o_dd74d631ac51b9a9dcd7,unknown).
0.99999987123526379::status(o_de273979067664e0ca57,supported); 0::status(o_de273979067664e0ca57,refuted); 1.2876473620693218e-07::status(o_de273979067664e0ca57,unknown).
1::status(o_de3a643b8180fc7f0118,supported); 0::status(o_de3a643b8180fc7f0118,refuted); 0::status(o_de3a643b8180fc7f0118,unknown).
3.4223872807549547e-08::status(o_deb82273b78aa3a928db,supported); 0::status(o_deb82273b78aa3a928db,refuted); 0.99999996577612715::status(o_deb82273b78aa3a928db,unknown).
0.0027664784469140684::status(o_df02bb542c259975a561,supported); 0::status(o_df02bb542c259975a561,refuted); 0.99723352155308598::status(o_df02bb542c259975a561,unknown).
0.0003760041520746113::status(o_df0ea2915fd49492e497,supported); 0::status(o_df0ea2915fd49492e497,refuted); 0.99962399584792538::status(o_df0ea2915fd49492e497,unknown).
0.008551986236149025::status(o_dfe59f6ddd86e6df6e50,supported); 0::status(o_dfe59f6ddd86e6df6e50,refuted); 0.99144801376385094::status(o_dfe59f6ddd86e6df6e50,unknown).
1::status(o_e01faaa10ef7d63d35db,supported); 0::status(o_e01faaa10ef7d63d35db,refuted); 0::status(o_e01faaa10ef7d63d35db,unknown).
1::status(o_e034b05a102bb71443eb,supported); 0::status(o_e034b05a102bb71443eb,refuted); 0::status(o_e034b05a102bb71443eb,unknown).
1::status(o_e0474a61cfe85562a998,supported); 0::status(o_e0474a61cfe85562a998,refuted); 0::status(o_e0474a61cfe85562a998,unknown).
0.00063768832478672266::status(o_e09d9af4afb9fe42db84,supported); 0::status(o_e09d9af4afb9fe42db84,refuted); 0.99936231167521328::status(o_e09d9af4afb9fe42db84,unknown).
0.00066984596196562052::status(o_e0c6336bd180723c5a39,supported); 0::status(o_e0c6336bd180723c5a39,refuted); 0.99933015403803438::status(o_e0c6336bd180723c5a39,unknown).
0.00013119971225404874::status(o_e1012bd785724620575a,supported); 0::status(o_e1012bd785724620575a,refuted); 0.99986880028774594::status(o_e1012bd785724620575a,unknown).
0.99997198757213868::status(o_e104d9720e2c174cf9e7,supported); 0::status(o_e104d9720e2c174cf9e7,refuted); 2.801242786132363e-05::status(o_e104d9720e2c174cf9e7,unknown).
0.99999964564751598::status(o_e13d7089ad343a93054f,supported); 0::status(o_e13d7089ad343a93054f,refuted); 3.5435248402215791e-07::status(o_e13d7089ad343a93054f,unknown).
0.0047103664837777615::status(o_e1fe6768ac2fbc02beea,supported); 0::status(o_e1fe6768ac2fbc02beea,refuted); 0.99528963351622224::status(o_e1fe6768ac2fbc02beea,unknown).
1::status(o_e235eec835637a147400,supported); 0::status(o_e235eec835637a147400,refuted); 0::status(o_e235eec835637a147400,unknown).
0.36756375367835886::status(o_e27ecf9569131766aceb,supported); 0::status(o_e27ecf9569131766aceb,refuted); 0.63243624632164108::status(o_e27ecf9569131766aceb,unknown).
0.34373353337659723::status(o_e2a3493f0e611443c4a1,supported); 0::status(o_e2a3493f0e611443c4a1,refuted); 0.65626646662340282::status(o_e2a3493f0e611443c4a1,unknown).
0.99999957329941025::status(o_e30c7d8ed67e577c28bb,supported); 0::status(o_e30c7d8ed67e577c28bb,refuted); 4.267005897506948e-07::status(o_e30c7d8ed67e577c28bb,unknown).
1::status(o_e32d957b339b057b63a6,supported); 0::status(o_e32d957b339b057b63a6,refuted); 0::status(o_e32d957b339b057b63a6,unknown).
0.00028077524621039629::status(o_e35232dd1f3018bc1bdd,supported); 0::status(o_e35232dd1f3018bc1bdd,refuted); 0.9997192247537896::status(o_e35232dd1f3018bc1bdd,unknown).
1::status(o_e3797fc0fb014060bd6d,supported); 0::status(o_e3797fc0fb014060bd6d,refuted); 0::status(o_e3797fc0fb014060bd6d,unknown).
0.99385096469335199::status(o_e3f206f47c32ad8739a7,supported); 0::status(o_e3f206f47c32ad8739a7,refuted); 0.0061490353066480097::status(o_e3f206f47c32ad8739a7,unknown).
0.99999730550533539::status(o_e3f2cde0c6419fe4632c,supported); 0::status(o_e3f2cde0c6419fe4632c,refuted); 2.6944946646123569e-06::status(o_e3f2cde0c6419fe4632c,unknown).
0.99997198757213868::status(o_e42bc9625d21172c97c6,supported); 0::status(o_e42bc9625d21172c97c6,refuted); 2.801242786132363e-05::status(o_e42bc9625d21172c97c6,unknown).
0.00035486903271498394::status(o_e4d7d0adc010caa1aa21,supported); 0::status(o_e4d7d0adc010caa1aa21,refuted); 0.99964513096728502::status(o_e4d7d0adc010caa1aa21,unknown).
0::status(o_e4df053c7e99474f2c94,supported); 1::status(o_e4df053c7e99474f2c94,refuted); 0::status(o_e4df053c7e99474f2c94,unknown).
0.9993758139079767::status(o_e52c04cadc01e5365146,supported); 0::status(o_e52c04cadc01e5365146,refuted); 0.00062418609202330444::status(o_e52c04cadc01e5365146,unknown).
1::status(o_e535860b8222682781a5,supported); 0::status(o_e535860b8222682781a5,refuted); 0::status(o_e535860b8222682781a5,unknown).
2.0750996724554319e-08::status(o_e57e9030325120071eb3,supported); 0::status(o_e57e9030325120071eb3,refuted); 0.9999999792490033::status(o_e57e9030325120071eb3,unknown).
1::status(o_e586c7c125e503a83f45,supported); 0::status(o_e586c7c125e503a83f45,refuted); 0::status(o_e586c7c125e503a83f45,unknown).
0.00076209998223930597::status(o_e645b3c63ae35ebbaa07,supported); 0::status(o_e645b3c63ae35ebbaa07,refuted); 0.99923790001776069::status(o_e645b3c63ae35ebbaa07,unknown).
0.99999597388339545::status(o_e65ae4b3d1a72ffa6187,supported); 0::status(o_e65ae4b3d1a72ffa6187,refuted); 4.0261166045496566e-06::status(o_e65ae4b3d1a72ffa6187,unknown).
0.99999996709064987::status(o_e6915b4896efc809687a,supported); 0::status(o_e6915b4896efc809687a,refuted); 3.2909350133891735e-08::status(o_e6915b4896efc809687a,unknown).
0.9814574122428894::status(o_e710780d1d6a09559a12,supported); 0::status(o_e710780d1d6a09559a12,refuted); 0.018542587757110596::status(o_e710780d1d6a09559a12,unknown).
0.9999997374770605::status(o_e712b1b8f770b3328877,supported); 0::status(o_e712b1b8f770b3328877,refuted); 2.6252293949813321e-07::status(o_e712b1b8f770b3328877,unknown).
1::status(o_e7144f5eebc7a4dbaee9,supported); 0::status(o_e7144f5eebc7a4dbaee9,refuted); 0::status(o_e7144f5eebc7a4dbaee9,unknown).
0.976348876953125::status(o_e7cb16d0723df82281e5,supported); 0::status(o_e7cb16d0723df82281e5,refuted); 0.023651123046875::status(o_e7cb16d0723df82281e5,unknown).
0.28751092054261485::status(o_e7d8e0bd800e0ac51eab,supported); 0::status(o_e7d8e0bd800e0ac51eab,refuted); 0.71248907945738515::status(o_e7d8e0bd800e0ac51eab,unknown).
3.9168113824947599e-06::status(o_e879a67926bad10beba9,supported); 0::status(o_e879a67926bad10beba9,refuted); 0.99999608318861755::status(o_e879a67926bad10beba9,unknown).
1::status(o_e89ee2add9affede6550,supported); 0::status(o_e89ee2add9affede6550,refuted); 0::status(o_e89ee2add9affede6550,unknown).
1.8655004332620904e-06::status(o_e8da5d5e874317e6b5b5,supported); 0::status(o_e8da5d5e874317e6b5b5,refuted); 0.99999813449956676::status(o_e8da5d5e874317e6b5b5,unknown).
0.00030347461329718059::status(o_e8f1b11fbb8e0d2d7e7e,supported); 0::status(o_e8f1b11fbb8e0d2d7e7e,refuted); 0.99969652538670284::status(o_e8f1b11fbb8e0d2d7e7e,unknown).
1::status(o_e94c430ac2f93b24acf3,supported); 0::status(o_e94c430ac2f93b24acf3,refuted); 0::status(o_e94c430ac2f93b24acf3,unknown).
0.0041071532961066259::status(o_e9cf1fefc4ed6c16069b,supported); 0::status(o_e9cf1fefc4ed6c16069b,refuted); 0.99589284670389333::status(o_e9cf1fefc4ed6c16069b,unknown).
1::status(o_e9d6117e867175d3e03c,supported); 0::status(o_e9d6117e867175d3e03c,refuted); 0::status(o_e9d6117e867175d3e03c,unknown).
0.029979904578408205::status(o_e9f308e1977da8cf9dca,supported); 0::status(o_e9f308e1977da8cf9dca,refuted); 0.97002009542159184::status(o_e9f308e1977da8cf9dca,unknown).
0.99999980136698285::status(o_ea3b2b940713174a0692,supported); 0::status(o_ea3b2b940713174a0692,refuted); 1.9863301714551085e-07::status(o_ea3b2b940713174a0692,unknown).
5.6390664903726097e-08::status(o_ea620b80cd62b0f24a66,supported); 0::status(o_ea620b80cd62b0f24a66,refuted); 0.99999994360933508::status(o_ea620b80cd62b0f24a66,unknown).
0.9999483373762641::status(o_ea8eda7f01f8b33472e3,supported); 0::status(o_ea8eda7f01f8b33472e3,refuted); 5.1662623735904134e-05::status(o_ea8eda7f01f8b33472e3,unknown).
0.28751092054261485::status(o_eaad72544fa1a65573dd,supported); 0::status(o_eaad72544fa1a65573dd,refuted); 0.71248907945738515::status(o_eaad72544fa1a65573dd,unknown).
0.99999945813975577::status(o_ead5d99fd06dba9ffd82,supported); 0::status(o_ead5d99fd06dba9ffd82,refuted); 5.4186024422975265e-07::status(o_ead5d99fd06dba9ffd82,unknown).
1::status(o_eb11b9557d9095a4ed41,supported); 0::status(o_eb11b9557d9095a4ed41,refuted); 0::status(o_eb11b9557d9095a4ed41,unknown).
1::status(o_eb4ce3732a7138390c3d,supported); 0::status(o_eb4ce3732a7138390c3d,refuted); 0::status(o_eb4ce3732a7138390c3d,unknown).
0.0001937485837026921::status(o_eb582db99c112d906a35,supported); 0::status(o_eb582db99c112d906a35,refuted); 0.99980625141629731::status(o_eb582db99c112d906a35,unknown).
0.002940004225820303::status(o_ebf8ec75796688146699,supported); 0::status(o_ebf8ec75796688146699,refuted); 0.9970599957741797::status(o_ebf8ec75796688146699,unknown).
0::status(o_ec0af894b25e2a747005,supported); 1::status(o_ec0af894b25e2a747005,refuted); 0::status(o_ec0af894b25e2a747005,unknown).
1::status(o_ec0dbd26d248721ccf94,supported); 0::status(o_ec0dbd26d248721ccf94,refuted); 0::status(o_ec0dbd26d248721ccf94,unknown).
0.99999882968458842::status(o_ec7b76e158a4503c6f6f,supported); 0::status(o_ec7b76e158a4503c6f6f,refuted); 1.1703154115805248e-06::status(o_ec7b76e158a4503c6f6f,unknown).
0.99999999306661269::status(o_ec83ad486bb9f3c429b4,supported); 0::status(o_ec83ad486bb9f3c429b4,refuted); 6.9333873087273901e-09::status(o_ec83ad486bb9f3c429b4,unknown).
1::status(o_ec8f8d96179e97438b06,supported); 0::status(o_ec8f8d96179e97438b06,refuted); 0::status(o_ec8f8d96179e97438b06,unknown).
0.28751092054261485::status(o_eccdeba6a8e49d5fcb73,supported); 0::status(o_eccdeba6a8e49d5fcb73,refuted); 0.71248907945738515::status(o_eccdeba6a8e49d5fcb73,unknown).
0.045692827552556992::status(o_edc9471cb348ce6e8226,supported); 0::status(o_edc9471cb348ce6e8226,refuted); 0.95430717244744301::status(o_edc9471cb348ce6e8226,unknown).
0.99999536788406029::status(o_edf8cc726335643f3d44,supported); 0::status(o_edf8cc726335643f3d44,refuted); 4.6321159397066936e-06::status(o_edf8cc726335643f3d44,unknown).
1::status(o_ee37a283c2604a0f7780,supported); 0::status(o_ee37a283c2604a0f7780,refuted); 0::status(o_ee37a283c2604a0f7780,unknown).
1.3034778761802781e-06::status(o_ee6764a7a15e0aac64af,supported); 0::status(o_ee6764a7a15e0aac64af,refuted); 0.99999869652212381::status(o_ee6764a7a15e0aac64af,unknown).
1::status(o_ee68725bfe35b557701a,supported); 0::status(o_ee68725bfe35b557701a,refuted); 0::status(o_ee68725bfe35b557701a,unknown).
0.00012811402848456055::status(o_eef4dbd2539c1906ed1b,supported); 0::status(o_eef4dbd2539c1906ed1b,refuted); 0.99987188597151544::status(o_eef4dbd2539c1906ed1b,unknown).
0.083609746696326107::status(o_ef0ab1f5dddf0f0055fb,supported); 0::status(o_ef0ab1f5dddf0f0055fb,refuted); 0.91639025330367385::status(o_ef0ab1f5dddf0f0055fb,unknown).
0.99999996500192156::status(o_efa4b0938cb926411442,supported); 0::status(o_efa4b0938cb926411442,refuted); 3.49980784353221e-08::status(o_efa4b0938cb926411442,unknown).
5.6373784900642931e-05::status(o_efad762f582c0feddb14,supported); 0::status(o_efad762f582c0feddb14,refuted); 0.99994362621509936::status(o_efad762f582c0feddb14,unknown).
0.99999995459456814::status(o_f0633230dc1ec584666b,supported); 0::status(o_f0633230dc1ec584666b,refuted); 4.5405431858824841e-08::status(o_f0633230dc1ec584666b,unknown).
1::status(o_f118935329aff130bfd0,supported); 0::status(o_f118935329aff130bfd0,refuted); 0::status(o_f118935329aff130bfd0,unknown).
0.13451996445655823::status(o_f11da506dd5b5b7d6bdd,supported); 0::status(o_f11da506dd5b5b7d6bdd,refuted); 0.86548003554344177::status(o_f11da506dd5b5b7d6bdd,unknown).
0::status(o_f154e2d5659aa89931ed,supported); 1::status(o_f154e2d5659aa89931ed,refuted); 0::status(o_f154e2d5659aa89931ed,unknown).
2.9215075622410366e-05::status(o_f20c8f8735fc1ecd44ed,supported); 0::status(o_f20c8f8735fc1ecd44ed,refuted); 0.99997078492437763::status(o_f20c8f8735fc1ecd44ed,unknown).
0.99999999633715397::status(o_f2386cddef60e4a38030,supported); 0::status(o_f2386cddef60e4a38030,refuted); 3.6628460264864771e-09::status(o_f2386cddef60e4a38030,unknown).
4.6334251766444354e-09::status(o_f269562cca344b7eb949,supported); 0::status(o_f269562cca344b7eb949,refuted); 0.9999999953665748::status(o_f269562cca344b7eb949,unknown).
0.99999851928475114::status(o_f2bb39ef37bdfe4b9163,supported); 0::status(o_f2bb39ef37bdfe4b9163,refuted); 1.4807152488582886e-06::status(o_f2bb39ef37bdfe4b9163,unknown).
0.99185353517532349::status(o_f31f34bccaee7a7fb4fe,supported); 0::status(o_f31f34bccaee7a7fb4fe,refuted); 0.0081464648246765137::status(o_f31f34bccaee7a7fb4fe,unknown).
0.021092737093567848::status(o_f3510cdad365aaf78e3b,supported); 0::status(o_f3510cdad365aaf78e3b,refuted); 0.97890726290643215::status(o_f3510cdad365aaf78e3b,unknown).
0.003354658596551997::status(o_f35babcf0f55f5596300,supported); 0::status(o_f35babcf0f55f5596300,refuted); 0.99664534140344796::status(o_f35babcf0f55f5596300,unknown).
1::status(o_f379d85f0b7e899d148d,supported); 0::status(o_f379d85f0b7e899d148d,refuted); 0::status(o_f379d85f0b7e899d148d,unknown).
2.0795546286345143e-08::status(o_f3c7e8b383ece912bd6b,supported); 0::status(o_f3c7e8b383ece912bd6b,refuted); 0.99999997920445372::status(o_f3c7e8b383ece912bd6b,unknown).
0.00010203728353087578::status(o_f3de2d9ac363914a6789,supported); 0::status(o_f3de2d9ac363914a6789,refuted); 0.99989796271646914::status(o_f3de2d9ac363914a6789,unknown).
1::status(o_f3ed1091696a55805aca,supported); 0::status(o_f3ed1091696a55805aca,refuted); 0::status(o_f3ed1091696a55805aca,unknown).
2.0750996724554319e-08::status(o_f3f74453809bddea0e41,supported); 0::status(o_f3f74453809bddea0e41,refuted); 0.9999999792490033::status(o_f3f74453809bddea0e41,unknown).
1::status(o_f416673ee51932105ce7,supported); 0::status(o_f416673ee51932105ce7,refuted); 0::status(o_f416673ee51932105ce7,unknown).
0.0042693153955042362::status(o_f42265825af9d88511dd,supported); 0::status(o_f42265825af9d88511dd,refuted); 0.99573068460449576::status(o_f42265825af9d88511dd,unknown).
0.42756217829016024::status(o_f42bd4828c2d0a999d7b,supported); 0::status(o_f42bd4828c2d0a999d7b,refuted); 0.57243782170983981::status(o_f42bd4828c2d0a999d7b,unknown).
0.17084306019186274::status(o_f4bf08bec5beb31c2282,supported); 0::status(o_f4bf08bec5beb31c2282,refuted); 0.82915693980813732::status(o_f4bf08bec5beb31c2282,unknown).
2.6584332787354958e-08::status(o_f5363864bf87b5e9ef38,supported); 0::status(o_f5363864bf87b5e9ef38,refuted); 0.99999997341566726::status(o_f5363864bf87b5e9ef38,unknown).
1::status(o_f53a9600c4d6a337bc5b,supported); 0::status(o_f53a9600c4d6a337bc5b,refuted); 0::status(o_f53a9600c4d6a337bc5b,unknown).
1::status(o_f5b72e68a2dfede9d956,supported); 0::status(o_f5b72e68a2dfede9d956,refuted); 0::status(o_f5b72e68a2dfede9d956,unknown).
0.99155628681182861::status(o_f5db951324718ddea538,supported); 0::status(o_f5db951324718ddea538,refuted); 0.0084437131881713867::status(o_f5db951324718ddea538,unknown).
0.99535101332905751::status(o_f5e9506c4eaee6a812d2,supported); 0::status(o_f5e9506c4eaee6a812d2,refuted); 0.0046489866709424899::status(o_f5e9506c4eaee6a812d2,unknown).
0::status(o_f5ee22f6a9ec87c80c31,supported); 1::status(o_f5ee22f6a9ec87c80c31,refuted); 0::status(o_f5ee22f6a9ec87c80c31,unknown).
2.8278058427373192e-08::status(o_f67beb85e1f14f3b27e1,supported); 0::status(o_f67beb85e1f14f3b27e1,refuted); 0.99999997172194155::status(o_f67beb85e1f14f3b27e1,unknown).
1::status(o_f6a79ff0dfdc9f0c500d,supported); 0::status(o_f6a79ff0dfdc9f0c500d,refuted); 0::status(o_f6a79ff0dfdc9f0c500d,unknown).
1.1311926485658931e-06::status(o_f7000bb76f220a9b2b12,supported); 0::status(o_f7000bb76f220a9b2b12,refuted); 0.99999886880735145::status(o_f7000bb76f220a9b2b12,unknown).
0.68876990696500395::status(o_f75f4e08473910d490e3,supported); 0::status(o_f75f4e08473910d490e3,refuted); 0.31123009303499605::status(o_f75f4e08473910d490e3,unknown).
5.6352172912447028e-08::status(o_f76aa5db32f83a40f739,supported); 0::status(o_f76aa5db32f83a40f739,refuted); 0.99999994364782707::status(o_f76aa5db32f83a40f739,unknown).
0.99726450443267822::status(o_f77bf96b27918572d5e2,supported); 0::status(o_f77bf96b27918572d5e2,refuted); 0.0027354955673217773::status(o_f77bf96b27918572d5e2,unknown).
0.00043609272688627243::status(o_f7c7a14c20b40180ffef,supported); 0::status(o_f7c7a14c20b40180ffef,refuted); 0.99956390727311373::status(o_f7c7a14c20b40180ffef,unknown).
1::status(o_f81075f6b51ab1ffb493,supported); 0::status(o_f81075f6b51ab1ffb493,refuted); 0::status(o_f81075f6b51ab1ffb493,unknown).
0.99989653443063942::status(o_f835fe79960121d8a5f5,supported); 0::status(o_f835fe79960121d8a5f5,refuted); 0.00010346556936058349::status(o_f835fe79960121d8a5f5,unknown).
1::status(o_f88ac82d1fefa5bc376a,supported); 0::status(o_f88ac82d1fefa5bc376a,refuted); 0::status(o_f88ac82d1fefa5bc376a,unknown).
1::status(o_f8f00c68ec78f1f20fd4,supported); 0::status(o_f8f00c68ec78f1f20fd4,refuted); 0::status(o_f8f00c68ec78f1f20fd4,unknown).
0::status(o_f90ffc761fcc55a6452d,supported); 1::status(o_f90ffc761fcc55a6452d,refuted); 0::status(o_f90ffc761fcc55a6452d,unknown).
0.99876517950783739::status(o_f94b64a13313a3c9ba93,supported); 0::status(o_f94b64a13313a3c9ba93,refuted); 0.0012348204921626138::status(o_f94b64a13313a3c9ba93,unknown).
0.9996891099334213::status(o_f973d63a2b66fc985a75,supported); 0::status(o_f973d63a2b66fc985a75,refuted); 0.00031089006657869511::status(o_f973d63a2b66fc985a75,unknown).
1::status(o_fa8acaa14760def5f7d8,supported); 0::status(o_fa8acaa14760def5f7d8,refuted); 0::status(o_fa8acaa14760def5f7d8,unknown).
1::status(o_faaa4f84b2ff8a28c02c,supported); 0::status(o_faaa4f84b2ff8a28c02c,refuted); 0::status(o_faaa4f84b2ff8a28c02c,unknown).
0.99998812204089271::status(o_fb13a646425ba88d2480,supported); 0::status(o_fb13a646425ba88d2480,refuted); 1.1877959107287062e-05::status(o_fb13a646425ba88d2480,unknown).
0.99506652355194092::status(o_fb25b49a1d41dd64804a,supported); 0::status(o_fb25b49a1d41dd64804a,refuted); 0.004933476448059082::status(o_fb25b49a1d41dd64804a,unknown).
0.99986850708269226::status(o_fb2b3491eebbcaba91aa,supported); 0::status(o_fb2b3491eebbcaba91aa,refuted); 0.0001314929173077406::status(o_fb2b3491eebbcaba91aa,unknown).
0.99999730550533539::status(o_fb5d81928e8abb798b86,supported); 0::status(o_fb5d81928e8abb798b86,refuted); 2.6944946646123569e-06::status(o_fb5d81928e8abb798b86,unknown).
1::status(o_fbd6b8bb57bf07ff9482,supported); 0::status(o_fbd6b8bb57bf07ff9482,refuted); 0::status(o_fbd6b8bb57bf07ff9482,unknown).
1::status(o_fbf4355644bed3bb34fe,supported); 0::status(o_fbf4355644bed3bb34fe,refuted); 0::status(o_fbf4355644bed3bb34fe,unknown).
1::status(o_fbfc8d9bc235d81c7b46,supported); 0::status(o_fbfc8d9bc235d81c7b46,refuted); 0::status(o_fbfc8d9bc235d81c7b46,unknown).
0.99999692912085059::status(o_fc03b07d2418f15a6690,supported); 0::status(o_fc03b07d2418f15a6690,refuted); 3.070879149413841e-06::status(o_fc03b07d2418f15a6690,unknown).
0.99999902675069929::status(o_fc4017cbc354175c35f3,supported); 0::status(o_fc4017cbc354175c35f3,refuted); 9.7324930070641358e-07::status(o_fc4017cbc354175c35f3,unknown).
0.99213320016860962::status(o_fc6d6c2b6d1a32a90854,supported); 0::status(o_fc6d6c2b6d1a32a90854,refuted); 0.0078667998313903809::status(o_fc6d6c2b6d1a32a90854,unknown).
3.2482797206823362e-07::status(o_fc9408c7df03f42d6c4d,supported); 0::status(o_fc9408c7df03f42d6c4d,refuted); 0.99999967517202792::status(o_fc9408c7df03f42d6c4d,unknown).
0.0060226605273783207::status(o_fd35a71424497f5dde03,supported); 0::status(o_fd35a71424497f5dde03,refuted); 0.99397733947262168::status(o_fd35a71424497f5dde03,unknown).
8.4538020221954996e-06::status(o_fdc563b7ff056f0fe69a,supported); 0::status(o_fdc563b7ff056f0fe69a,refuted); 0.99999154619797781::status(o_fdc563b7ff056f0fe69a,unknown).
1::status(o_fe14b7290fb5c040e291,supported); 0::status(o_fe14b7290fb5c040e291,refuted); 0::status(o_fe14b7290fb5c040e291,unknown).
5.0035413667122327e-06::status(o_feb65674051c34c9f834,supported); 0::status(o_feb65674051c34c9f834,refuted); 0.99999499645863332::status(o_feb65674051c34c9f834,unknown).
1::status(o_fee85bb93d4e6473adc9,supported); 0::status(o_fee85bb93d4e6473adc9,refuted); 0::status(o_fee85bb93d4e6473adc9,unknown).
8.3507141241693934e-06::status(o_ff158b861a69c54e2a3a,supported); 0::status(o_ff158b861a69c54e2a3a,refuted); 0.99999164928587581::status(o_ff158b861a69c54e2a3a,unknown).
0::status(o_ff56425e2313cb2834b6,supported); 1::status(o_ff56425e2313cb2834b6,refuted); 0::status(o_ff56425e2313cb2834b6,unknown).
0.99999237368905358::status(o_ff671b0846bc5ab76f41,supported); 0::status(o_ff671b0846bc5ab76f41,refuted); 7.6263109464180801e-06::status(o_ff671b0846bc5ab76f41,unknown).
1::status(o_ffe189c0930848dba1dd,supported); 0::status(o_ffe189c0930848dba1dd,refuted); 0::status(o_ffe189c0930848dba1dd,unknown).
8.8334579666288478e-07::status(o_fff29ee9c4059d76426f,supported); 0::status(o_fff29ee9c4059d76426f,refuted); 0.99999911665420338::status(o_fff29ee9c4059d76426f,unknown).
0.99978179605165418::status(o_fffb2df3111000840e16,supported); 0::status(o_fffb2df3111000840e16,refuted); 0.00021820394834581869::status(o_fffb2df3111000840e16,unknown).
node(n2,supported) :- status(o_35fb0c4f19ff888aa014,supported).
node(n2,refuted) :- status(o_35fb0c4f19ff888aa014,refuted).
node(n2,unknown) :- status(o_35fb0c4f19ff888aa014,unknown).
node(n3,supported) :- status(o_de3a643b8180fc7f0118,supported).
node(n3,refuted) :- status(o_de3a643b8180fc7f0118,refuted).
node(n3,unknown) :- status(o_de3a643b8180fc7f0118,unknown).
node(n4,supported) :- status(o_9363f58ae7671ce5bd15,supported).
node(n4,refuted) :- status(o_9363f58ae7671ce5bd15,refuted).
node(n4,unknown) :- status(o_9363f58ae7671ce5bd15,unknown).
node(n1,supported) :- node(n2,supported), node(n3,supported), node(n4,supported).
node(n1,refuted) :- node(n2,refuted).
node(n1,refuted) :- node(n3,refuted).
node(n1,refuted) :- node(n4,refuted).
node(n1,unknown) :- \+ node(n1,supported), \+ node(n1,refuted).
node(n6,supported) :- status(o_62f3c09755664935c836,supported).
node(n6,refuted) :- status(o_62f3c09755664935c836,refuted).
node(n6,unknown) :- status(o_62f3c09755664935c836,unknown).
node(n7,supported) :- status(o_93fd8457a3f57b0aa60b,supported).
node(n7,refuted) :- status(o_93fd8457a3f57b0aa60b,refuted).
node(n7,unknown) :- status(o_93fd8457a3f57b0aa60b,unknown).
node(n8,supported) :- status(o_59adf45df3da0f7ba27d,supported).
node(n8,refuted) :- status(o_59adf45df3da0f7ba27d,refuted).
node(n8,unknown) :- status(o_59adf45df3da0f7ba27d,unknown).
node(n5,supported) :- node(n6,supported), node(n7,supported), node(n8,supported).
node(n5,refuted) :- node(n6,refuted).
node(n5,refuted) :- node(n7,refuted).
node(n5,refuted) :- node(n8,refuted).
node(n5,unknown) :- \+ node(n5,supported), \+ node(n5,refuted).
node(n9,unknown).
node(n0,refuted) :- node(n1,refuted), node(n5,refuted), node(n9,refuted).
node(n0,supported) :- node(n1,supported).
node(n0,supported) :- node(n5,supported).
node(n0,supported) :- node(n9,supported).
node(n0,unknown) :- \+ node(n0,supported), \+ node(n0,refuted).
verdict(c_96fc881770ebaaa1,supported) :- node(n0,supported).
query(verdict(c_96fc881770ebaaa1,supported)).
verdict(c_96fc881770ebaaa1,refuted) :- node(n0,refuted).
query(verdict(c_96fc881770ebaaa1,refuted)).
verdict(c_96fc881770ebaaa1,unknown) :- node(n0,unknown).
query(verdict(c_96fc881770ebaaa1,unknown)).
node(n12,supported) :- status(o_57bc81ed67176903fbac,supported).
node(n12,refuted) :- status(o_57bc81ed67176903fbac,refuted).
node(n12,unknown) :- status(o_57bc81ed67176903fbac,unknown).
node(n11,supported) :- node(n2,supported), node(n3,supported), node(n4,supported), node(n12,supported).
node(n11,refuted) :- node(n2,refuted).
node(n11,refuted) :- node(n3,refuted).
node(n11,refuted) :- node(n4,refuted).
node(n11,refuted) :- node(n12,refuted).
node(n11,unknown) :- \+ node(n11,supported), \+ node(n11,refuted).
node(n14,supported) :- status(o_50d48a5f37d08a31f7e4,supported).
node(n14,refuted) :- status(o_50d48a5f37d08a31f7e4,refuted).
node(n14,unknown) :- status(o_50d48a5f37d08a31f7e4,unknown).
node(n13,supported) :- node(n6,supported), node(n7,supported), node(n8,supported), node(n14,supported).
node(n13,refuted) :- node(n6,refuted).
node(n13,refuted) :- node(n7,refuted).
node(n13,refuted) :- node(n8,refuted).
node(n13,refuted) :- node(n14,refuted).
node(n13,unknown) :- \+ node(n13,supported), \+ node(n13,refuted).
node(n10,refuted) :- node(n11,refuted), node(n13,refuted), node(n9,refuted).
node(n10,supported) :- node(n11,supported).
node(n10,supported) :- node(n13,supported).
node(n10,supported) :- node(n9,supported).
node(n10,unknown) :- \+ node(n10,supported), \+ node(n10,refuted).
verdict(c_c10ffe7eca11f807,supported) :- node(n10,supported).
query(verdict(c_c10ffe7eca11f807,supported)).
verdict(c_c10ffe7eca11f807,refuted) :- node(n10,refuted).
query(verdict(c_c10ffe7eca11f807,refuted)).
verdict(c_c10ffe7eca11f807,unknown) :- node(n10,unknown).
query(verdict(c_c10ffe7eca11f807,unknown)).
node(n17,supported) :- status(o_c9a776ae447f44e9c017,supported).
node(n17,refuted) :- status(o_c9a776ae447f44e9c017,refuted).
node(n17,unknown) :- status(o_c9a776ae447f44e9c017,unknown).
node(n18,supported) :- status(o_3484bc933ea05303150c,supported).
node(n18,refuted) :- status(o_3484bc933ea05303150c,refuted).
node(n18,unknown) :- status(o_3484bc933ea05303150c,unknown).
node(n16,supported) :- node(n2,supported), node(n3,supported), node(n4,supported), node(n12,supported), node(n17,supported), node(n18,supported).
node(n16,refuted) :- node(n2,refuted).
node(n16,refuted) :- node(n3,refuted).
node(n16,refuted) :- node(n4,refuted).
node(n16,refuted) :- node(n12,refuted).
node(n16,refuted) :- node(n17,refuted).
node(n16,refuted) :- node(n18,refuted).
node(n16,unknown) :- \+ node(n16,supported), \+ node(n16,refuted).
node(n20,supported) :- status(o_04c519b5959366f2bae8,supported).
node(n20,refuted) :- status(o_04c519b5959366f2bae8,refuted).
node(n20,unknown) :- status(o_04c519b5959366f2bae8,unknown).
node(n21,supported) :- status(o_41dc8c7343eab021b49c,supported).
node(n21,refuted) :- status(o_41dc8c7343eab021b49c,refuted).
node(n21,unknown) :- status(o_41dc8c7343eab021b49c,unknown).
node(n19,supported) :- node(n6,supported), node(n7,supported), node(n8,supported), node(n14,supported), node(n20,supported), node(n21,supported).
node(n19,refuted) :- node(n6,refuted).
node(n19,refuted) :- node(n7,refuted).
node(n19,refuted) :- node(n8,refuted).
node(n19,refuted) :- node(n14,refuted).
node(n19,refuted) :- node(n20,refuted).
node(n19,refuted) :- node(n21,refuted).
node(n19,unknown) :- \+ node(n19,supported), \+ node(n19,refuted).
node(n15,refuted) :- node(n16,refuted), node(n19,refuted), node(n9,refuted).
node(n15,supported) :- node(n16,supported).
node(n15,supported) :- node(n19,supported).
node(n15,supported) :- node(n9,supported).
node(n15,unknown) :- \+ node(n15,supported), \+ node(n15,refuted).
verdict(c_78826fd118bcc0e4,supported) :- node(n15,supported).
query(verdict(c_78826fd118bcc0e4,supported)).
verdict(c_78826fd118bcc0e4,refuted) :- node(n15,refuted).
query(verdict(c_78826fd118bcc0e4,refuted)).
verdict(c_78826fd118bcc0e4,unknown) :- node(n15,unknown).
query(verdict(c_78826fd118bcc0e4,unknown)).
node(n24,supported) :- status(o_7668e5aa8be34e2a4cdb,supported).
node(n24,refuted) :- status(o_7668e5aa8be34e2a4cdb,refuted).
node(n24,unknown) :- status(o_7668e5aa8be34e2a4cdb,unknown).
node(n23,supported) :- node(n2,supported), node(n3,supported), node(n24,supported).
node(n23,refuted) :- node(n2,refuted).
node(n23,refuted) :- node(n3,refuted).
node(n23,refuted) :- node(n24,refuted).
node(n23,unknown) :- \+ node(n23,supported), \+ node(n23,refuted).
node(n26,supported) :- status(o_758497fab81797cb1871,supported).
node(n26,refuted) :- status(o_758497fab81797cb1871,refuted).
node(n26,unknown) :- status(o_758497fab81797cb1871,unknown).
node(n25,supported) :- node(n6,supported), node(n7,supported), node(n26,supported).
node(n25,refuted) :- node(n6,refuted).
node(n25,refuted) :- node(n7,refuted).
node(n25,refuted) :- node(n26,refuted).
node(n25,unknown) :- \+ node(n25,supported), \+ node(n25,refuted).
node(n22,refuted) :- node(n23,refuted), node(n25,refuted), node(n9,refuted).
node(n22,supported) :- node(n23,supported).
node(n22,supported) :- node(n25,supported).
node(n22,supported) :- node(n9,supported).
node(n22,unknown) :- \+ node(n22,supported), \+ node(n22,refuted).
verdict(c_c7047419fd65cdfb,supported) :- node(n22,supported).
query(verdict(c_c7047419fd65cdfb,supported)).
verdict(c_c7047419fd65cdfb,refuted) :- node(n22,refuted).
query(verdict(c_c7047419fd65cdfb,refuted)).
verdict(c_c7047419fd65cdfb,unknown) :- node(n22,unknown).
query(verdict(c_c7047419fd65cdfb,unknown)).
node(n28,supported) :- node(n2,supported), node(n3,supported), node(n4,supported), node(n24,supported).
node(n28,refuted) :- node(n2,refuted).
node(n28,refuted) :- node(n3,refuted).
node(n28,refuted) :- node(n4,refuted).
node(n28,refuted) :- node(n24,refuted).
node(n28,unknown) :- \+ node(n28,supported), \+ node(n28,refuted).
node(n29,supported) :- node(n6,supported), node(n7,supported), node(n8,supported), node(n26,supported).
node(n29,refuted) :- node(n6,refuted).
node(n29,refuted) :- node(n7,refuted).
node(n29,refuted) :- node(n8,refuted).
node(n29,refuted) :- node(n26,refuted).
node(n29,unknown) :- \+ node(n29,supported), \+ node(n29,refuted).
node(n27,refuted) :- node(n28,refuted), node(n29,refuted), node(n9,refuted).
node(n27,supported) :- node(n28,supported).
node(n27,supported) :- node(n29,supported).
node(n27,supported) :- node(n9,supported).
node(n27,unknown) :- \+ node(n27,supported), \+ node(n27,refuted).
verdict(c_c290080d433006ae,supported) :- node(n27,supported).
query(verdict(c_c290080d433006ae,supported)).
verdict(c_c290080d433006ae,refuted) :- node(n27,refuted).
query(verdict(c_c290080d433006ae,refuted)).
verdict(c_c290080d433006ae,unknown) :- node(n27,unknown).
query(verdict(c_c290080d433006ae,unknown)).
node(n32,supported) :- status(o_fa8acaa14760def5f7d8,supported).
node(n32,refuted) :- status(o_fa8acaa14760def5f7d8,refuted).
node(n32,unknown) :- status(o_fa8acaa14760def5f7d8,unknown).
node(n33,supported) :- status(o_5c05a0bfd1ac8160c1a2,supported).
node(n33,refuted) :- status(o_5c05a0bfd1ac8160c1a2,refuted).
node(n33,unknown) :- status(o_5c05a0bfd1ac8160c1a2,unknown).
node(n34,supported) :- status(o_87da43ce47e698e3eacf,supported).
node(n34,refuted) :- status(o_87da43ce47e698e3eacf,refuted).
node(n34,unknown) :- status(o_87da43ce47e698e3eacf,unknown).
node(n31,supported) :- node(n32,supported), node(n33,supported), node(n34,supported).
node(n31,refuted) :- node(n32,refuted).
node(n31,refuted) :- node(n33,refuted).
node(n31,refuted) :- node(n34,refuted).
node(n31,unknown) :- \+ node(n31,supported), \+ node(n31,refuted).
node(n36,supported) :- status(o_2637fe5c35e3f75cdb50,supported).
node(n36,refuted) :- status(o_2637fe5c35e3f75cdb50,refuted).
node(n36,unknown) :- status(o_2637fe5c35e3f75cdb50,unknown).
node(n37,supported) :- status(o_35b1d6162f2df5cc7432,supported).
node(n37,refuted) :- status(o_35b1d6162f2df5cc7432,refuted).
node(n37,unknown) :- status(o_35b1d6162f2df5cc7432,unknown).
node(n38,supported) :- status(o_2458bd728c6f3dbfe2e4,supported).
node(n38,refuted) :- status(o_2458bd728c6f3dbfe2e4,refuted).
node(n38,unknown) :- status(o_2458bd728c6f3dbfe2e4,unknown).
node(n35,supported) :- node(n36,supported), node(n37,supported), node(n38,supported).
node(n35,refuted) :- node(n36,refuted).
node(n35,refuted) :- node(n37,refuted).
node(n35,refuted) :- node(n38,refuted).
node(n35,unknown) :- \+ node(n35,supported), \+ node(n35,refuted).
node(n30,refuted) :- node(n31,refuted), node(n35,refuted), node(n9,refuted).
node(n30,supported) :- node(n31,supported).
node(n30,supported) :- node(n35,supported).
node(n30,supported) :- node(n9,supported).
node(n30,unknown) :- \+ node(n30,supported), \+ node(n30,refuted).
verdict(c_a3ef2128ebdc3b4c,supported) :- node(n30,supported).
query(verdict(c_a3ef2128ebdc3b4c,supported)).
verdict(c_a3ef2128ebdc3b4c,refuted) :- node(n30,refuted).
query(verdict(c_a3ef2128ebdc3b4c,refuted)).
verdict(c_a3ef2128ebdc3b4c,unknown) :- node(n30,unknown).
query(verdict(c_a3ef2128ebdc3b4c,unknown)).
node(n41,supported) :- status(o_815d674823e0b6721491,supported).
node(n41,refuted) :- status(o_815d674823e0b6721491,refuted).
node(n41,unknown) :- status(o_815d674823e0b6721491,unknown).
node(n40,supported) :- node(n32,supported), node(n33,supported), node(n34,supported), node(n41,supported).
node(n40,refuted) :- node(n32,refuted).
node(n40,refuted) :- node(n33,refuted).
node(n40,refuted) :- node(n34,refuted).
node(n40,refuted) :- node(n41,refuted).
node(n40,unknown) :- \+ node(n40,supported), \+ node(n40,refuted).
node(n43,supported) :- status(o_7809da65a16c2bbeedef,supported).
node(n43,refuted) :- status(o_7809da65a16c2bbeedef,refuted).
node(n43,unknown) :- status(o_7809da65a16c2bbeedef,unknown).
node(n42,supported) :- node(n36,supported), node(n37,supported), node(n38,supported), node(n43,supported).
node(n42,refuted) :- node(n36,refuted).
node(n42,refuted) :- node(n37,refuted).
node(n42,refuted) :- node(n38,refuted).
node(n42,refuted) :- node(n43,refuted).
node(n42,unknown) :- \+ node(n42,supported), \+ node(n42,refuted).
node(n39,refuted) :- node(n40,refuted), node(n42,refuted), node(n9,refuted).
node(n39,supported) :- node(n40,supported).
node(n39,supported) :- node(n42,supported).
node(n39,supported) :- node(n9,supported).
node(n39,unknown) :- \+ node(n39,supported), \+ node(n39,refuted).
verdict(c_a62246824f047755,supported) :- node(n39,supported).
query(verdict(c_a62246824f047755,supported)).
verdict(c_a62246824f047755,refuted) :- node(n39,refuted).
query(verdict(c_a62246824f047755,refuted)).
verdict(c_a62246824f047755,unknown) :- node(n39,unknown).
query(verdict(c_a62246824f047755,unknown)).
node(n46,supported) :- status(o_30f3367f6f30cf4082df,supported).
node(n46,refuted) :- status(o_30f3367f6f30cf4082df,refuted).
node(n46,unknown) :- status(o_30f3367f6f30cf4082df,unknown).
node(n47,supported) :- status(o_f3de2d9ac363914a6789,supported).
node(n47,refuted) :- status(o_f3de2d9ac363914a6789,refuted).
node(n47,unknown) :- status(o_f3de2d9ac363914a6789,unknown).
node(n45,supported) :- node(n32,supported), node(n33,supported), node(n34,supported), node(n41,supported), node(n46,supported), node(n47,supported).
node(n45,refuted) :- node(n32,refuted).
node(n45,refuted) :- node(n33,refuted).
node(n45,refuted) :- node(n34,refuted).
node(n45,refuted) :- node(n41,refuted).
node(n45,refuted) :- node(n46,refuted).
node(n45,refuted) :- node(n47,refuted).
node(n45,unknown) :- \+ node(n45,supported), \+ node(n45,refuted).
node(n49,supported) :- status(o_149a4294d83ef0ec3e32,supported).
node(n49,refuted) :- status(o_149a4294d83ef0ec3e32,refuted).
node(n49,unknown) :- status(o_149a4294d83ef0ec3e32,unknown).
node(n50,supported) :- status(o_fff29ee9c4059d76426f,supported).
node(n50,refuted) :- status(o_fff29ee9c4059d76426f,refuted).
node(n50,unknown) :- status(o_fff29ee9c4059d76426f,unknown).
node(n48,supported) :- node(n36,supported), node(n37,supported), node(n38,supported), node(n43,supported), node(n49,supported), node(n50,supported).
node(n48,refuted) :- node(n36,refuted).
node(n48,refuted) :- node(n37,refuted).
node(n48,refuted) :- node(n38,refuted).
node(n48,refuted) :- node(n43,refuted).
node(n48,refuted) :- node(n49,refuted).
node(n48,refuted) :- node(n50,refuted).
node(n48,unknown) :- \+ node(n48,supported), \+ node(n48,refuted).
node(n44,refuted) :- node(n45,refuted), node(n48,refuted), node(n9,refuted).
node(n44,supported) :- node(n45,supported).
node(n44,supported) :- node(n48,supported).
node(n44,supported) :- node(n9,supported).
node(n44,unknown) :- \+ node(n44,supported), \+ node(n44,refuted).
verdict(c_668df6d8281bf828,supported) :- node(n44,supported).
query(verdict(c_668df6d8281bf828,supported)).
verdict(c_668df6d8281bf828,refuted) :- node(n44,refuted).
query(verdict(c_668df6d8281bf828,refuted)).
verdict(c_668df6d8281bf828,unknown) :- node(n44,unknown).
query(verdict(c_668df6d8281bf828,unknown)).
node(n53,supported) :- status(o_75a2551f2b1a8daf5b9a,supported).
node(n53,refuted) :- status(o_75a2551f2b1a8daf5b9a,refuted).
node(n53,unknown) :- status(o_75a2551f2b1a8daf5b9a,unknown).
node(n52,supported) :- node(n32,supported), node(n33,supported), node(n53,supported).
node(n52,refuted) :- node(n32,refuted).
node(n52,refuted) :- node(n33,refuted).
node(n52,refuted) :- node(n53,refuted).
node(n52,unknown) :- \+ node(n52,supported), \+ node(n52,refuted).
node(n55,supported) :- status(o_34bc8813119604fd76c4,supported).
node(n55,refuted) :- status(o_34bc8813119604fd76c4,refuted).
node(n55,unknown) :- status(o_34bc8813119604fd76c4,unknown).
node(n54,supported) :- node(n36,supported), node(n37,supported), node(n55,supported).
node(n54,refuted) :- node(n36,refuted).
node(n54,refuted) :- node(n37,refuted).
node(n54,refuted) :- node(n55,refuted).
node(n54,unknown) :- \+ node(n54,supported), \+ node(n54,refuted).
node(n51,refuted) :- node(n52,refuted), node(n54,refuted), node(n9,refuted).
node(n51,supported) :- node(n52,supported).
node(n51,supported) :- node(n54,supported).
node(n51,supported) :- node(n9,supported).
node(n51,unknown) :- \+ node(n51,supported), \+ node(n51,refuted).
verdict(c_5cbd1ce665272690,supported) :- node(n51,supported).
query(verdict(c_5cbd1ce665272690,supported)).
verdict(c_5cbd1ce665272690,refuted) :- node(n51,refuted).
query(verdict(c_5cbd1ce665272690,refuted)).
verdict(c_5cbd1ce665272690,unknown) :- node(n51,unknown).
query(verdict(c_5cbd1ce665272690,unknown)).
node(n57,supported) :- node(n32,supported), node(n33,supported), node(n34,supported), node(n53,supported).
node(n57,refuted) :- node(n32,refuted).
node(n57,refuted) :- node(n33,refuted).
node(n57,refuted) :- node(n34,refuted).
node(n57,refuted) :- node(n53,refuted).
node(n57,unknown) :- \+ node(n57,supported), \+ node(n57,refuted).
node(n58,supported) :- node(n36,supported), node(n37,supported), node(n38,supported), node(n55,supported).
node(n58,refuted) :- node(n36,refuted).
node(n58,refuted) :- node(n37,refuted).
node(n58,refuted) :- node(n38,refuted).
node(n58,refuted) :- node(n55,refuted).
node(n58,unknown) :- \+ node(n58,supported), \+ node(n58,refuted).
node(n56,refuted) :- node(n57,refuted), node(n58,refuted), node(n9,refuted).
node(n56,supported) :- node(n57,supported).
node(n56,supported) :- node(n58,supported).
node(n56,supported) :- node(n9,supported).
node(n56,unknown) :- \+ node(n56,supported), \+ node(n56,refuted).
verdict(c_21719a10ad7b2891,supported) :- node(n56,supported).
query(verdict(c_21719a10ad7b2891,supported)).
verdict(c_21719a10ad7b2891,refuted) :- node(n56,refuted).
query(verdict(c_21719a10ad7b2891,refuted)).
verdict(c_21719a10ad7b2891,unknown) :- node(n56,unknown).
query(verdict(c_21719a10ad7b2891,unknown)).
node(n61,supported) :- status(o_4b458ad808b682de0273,supported).
node(n61,refuted) :- status(o_4b458ad808b682de0273,refuted).
node(n61,unknown) :- status(o_4b458ad808b682de0273,unknown).
node(n62,supported) :- status(o_e3797fc0fb014060bd6d,supported).
node(n62,refuted) :- status(o_e3797fc0fb014060bd6d,refuted).
node(n62,unknown) :- status(o_e3797fc0fb014060bd6d,unknown).
node(n63,supported) :- status(o_523cf2e77a806947b8e8,supported).
node(n63,refuted) :- status(o_523cf2e77a806947b8e8,refuted).
node(n63,unknown) :- status(o_523cf2e77a806947b8e8,unknown).
node(n60,supported) :- node(n61,supported), node(n62,supported), node(n63,supported).
node(n60,refuted) :- node(n61,refuted).
node(n60,refuted) :- node(n62,refuted).
node(n60,refuted) :- node(n63,refuted).
node(n60,unknown) :- \+ node(n60,supported), \+ node(n60,refuted).
node(n65,supported) :- status(o_d82bd5dab3c9278cc648,supported).
node(n65,refuted) :- status(o_d82bd5dab3c9278cc648,refuted).
node(n65,unknown) :- status(o_d82bd5dab3c9278cc648,unknown).
node(n66,supported) :- status(o_869fa890e9e739907fc3,supported).
node(n66,refuted) :- status(o_869fa890e9e739907fc3,refuted).
node(n66,unknown) :- status(o_869fa890e9e739907fc3,unknown).
node(n67,supported) :- status(o_c43ffa98ff0dfb965a94,supported).
node(n67,refuted) :- status(o_c43ffa98ff0dfb965a94,refuted).
node(n67,unknown) :- status(o_c43ffa98ff0dfb965a94,unknown).
node(n64,supported) :- node(n65,supported), node(n66,supported), node(n67,supported).
node(n64,refuted) :- node(n65,refuted).
node(n64,refuted) :- node(n66,refuted).
node(n64,refuted) :- node(n67,refuted).
node(n64,unknown) :- \+ node(n64,supported), \+ node(n64,refuted).
node(n59,refuted) :- node(n60,refuted), node(n64,refuted), node(n9,refuted).
node(n59,supported) :- node(n60,supported).
node(n59,supported) :- node(n64,supported).
node(n59,supported) :- node(n9,supported).
node(n59,unknown) :- \+ node(n59,supported), \+ node(n59,refuted).
verdict(c_bf0fb57fa0d2290b,supported) :- node(n59,supported).
query(verdict(c_bf0fb57fa0d2290b,supported)).
verdict(c_bf0fb57fa0d2290b,refuted) :- node(n59,refuted).
query(verdict(c_bf0fb57fa0d2290b,refuted)).
verdict(c_bf0fb57fa0d2290b,unknown) :- node(n59,unknown).
query(verdict(c_bf0fb57fa0d2290b,unknown)).
node(n70,supported) :- status(o_85add405662655c6ddfe,supported).
node(n70,refuted) :- status(o_85add405662655c6ddfe,refuted).
node(n70,unknown) :- status(o_85add405662655c6ddfe,unknown).
node(n69,supported) :- node(n61,supported), node(n62,supported), node(n63,supported), node(n70,supported).
node(n69,refuted) :- node(n61,refuted).
node(n69,refuted) :- node(n62,refuted).
node(n69,refuted) :- node(n63,refuted).
node(n69,refuted) :- node(n70,refuted).
node(n69,unknown) :- \+ node(n69,supported), \+ node(n69,refuted).
node(n72,supported) :- status(o_7094f8389d7e8e02f99e,supported).
node(n72,refuted) :- status(o_7094f8389d7e8e02f99e,refuted).
node(n72,unknown) :- status(o_7094f8389d7e8e02f99e,unknown).
node(n71,supported) :- node(n65,supported), node(n66,supported), node(n67,supported), node(n72,supported).
node(n71,refuted) :- node(n65,refuted).
node(n71,refuted) :- node(n66,refuted).
node(n71,refuted) :- node(n67,refuted).
node(n71,refuted) :- node(n72,refuted).
node(n71,unknown) :- \+ node(n71,supported), \+ node(n71,refuted).
node(n68,refuted) :- node(n69,refuted), node(n71,refuted), node(n9,refuted).
node(n68,supported) :- node(n69,supported).
node(n68,supported) :- node(n71,supported).
node(n68,supported) :- node(n9,supported).
node(n68,unknown) :- \+ node(n68,supported), \+ node(n68,refuted).
verdict(c_8743e1f2f6044bb0,supported) :- node(n68,supported).
query(verdict(c_8743e1f2f6044bb0,supported)).
verdict(c_8743e1f2f6044bb0,refuted) :- node(n68,refuted).
query(verdict(c_8743e1f2f6044bb0,refuted)).
verdict(c_8743e1f2f6044bb0,unknown) :- node(n68,unknown).
query(verdict(c_8743e1f2f6044bb0,unknown)).
node(n75,supported) :- status(o_2b2aaff05c389ae3b6e5,supported).
node(n75,refuted) :- status(o_2b2aaff05c389ae3b6e5,refuted).
node(n75,unknown) :- status(o_2b2aaff05c389ae3b6e5,unknown).
node(n76,supported) :- status(o_db8926506bfba2edfb38,supported).
node(n76,refuted) :- status(o_db8926506bfba2edfb38,refuted).
node(n76,unknown) :- status(o_db8926506bfba2edfb38,unknown).
node(n74,supported) :- node(n61,supported), node(n62,supported), node(n63,supported), node(n70,supported), node(n75,supported), node(n76,supported).
node(n74,refuted) :- node(n61,refuted).
node(n74,refuted) :- node(n62,refuted).
node(n74,refuted) :- node(n63,refuted).
node(n74,refuted) :- node(n70,refuted).
node(n74,refuted) :- node(n75,refuted).
node(n74,refuted) :- node(n76,refuted).
node(n74,unknown) :- \+ node(n74,supported), \+ node(n74,refuted).
node(n78,supported) :- status(o_1abfe7cbc8254a1feba9,supported).
node(n78,refuted) :- status(o_1abfe7cbc8254a1feba9,refuted).
node(n78,unknown) :- status(o_1abfe7cbc8254a1feba9,unknown).
node(n79,supported) :- status(o_c15e928222dd2529baea,supported).
node(n79,refuted) :- status(o_c15e928222dd2529baea,refuted).
node(n79,unknown) :- status(o_c15e928222dd2529baea,unknown).
node(n77,supported) :- node(n65,supported), node(n66,supported), node(n67,supported), node(n72,supported), node(n78,supported), node(n79,supported).
node(n77,refuted) :- node(n65,refuted).
node(n77,refuted) :- node(n66,refuted).
node(n77,refuted) :- node(n67,refuted).
node(n77,refuted) :- node(n72,refuted).
node(n77,refuted) :- node(n78,refuted).
node(n77,refuted) :- node(n79,refuted).
node(n77,unknown) :- \+ node(n77,supported), \+ node(n77,refuted).
node(n73,refuted) :- node(n74,refuted), node(n77,refuted), node(n9,refuted).
node(n73,supported) :- node(n74,supported).
node(n73,supported) :- node(n77,supported).
node(n73,supported) :- node(n9,supported).
node(n73,unknown) :- \+ node(n73,supported), \+ node(n73,refuted).
verdict(c_d6fb2370fdef742b,supported) :- node(n73,supported).
query(verdict(c_d6fb2370fdef742b,supported)).
verdict(c_d6fb2370fdef742b,refuted) :- node(n73,refuted).
query(verdict(c_d6fb2370fdef742b,refuted)).
verdict(c_d6fb2370fdef742b,unknown) :- node(n73,unknown).
query(verdict(c_d6fb2370fdef742b,unknown)).
node(n82,supported) :- status(o_2014ebbfcf940ec893a8,supported).
node(n82,refuted) :- status(o_2014ebbfcf940ec893a8,refuted).
node(n82,unknown) :- status(o_2014ebbfcf940ec893a8,unknown).
node(n81,supported) :- node(n61,supported), node(n62,supported), node(n82,supported).
node(n81,refuted) :- node(n61,refuted).
node(n81,refuted) :- node(n62,refuted).
node(n81,refuted) :- node(n82,refuted).
node(n81,unknown) :- \+ node(n81,supported), \+ node(n81,refuted).
node(n84,supported) :- status(o_ac6490f7cfdb497e9a9e,supported).
node(n84,refuted) :- status(o_ac6490f7cfdb497e9a9e,refuted).
node(n84,unknown) :- status(o_ac6490f7cfdb497e9a9e,unknown).
node(n83,supported) :- node(n65,supported), node(n66,supported), node(n84,supported).
node(n83,refuted) :- node(n65,refuted).
node(n83,refuted) :- node(n66,refuted).
node(n83,refuted) :- node(n84,refuted).
node(n83,unknown) :- \+ node(n83,supported), \+ node(n83,refuted).
node(n80,refuted) :- node(n81,refuted), node(n83,refuted), node(n9,refuted).
node(n80,supported) :- node(n81,supported).
node(n80,supported) :- node(n83,supported).
node(n80,supported) :- node(n9,supported).
node(n80,unknown) :- \+ node(n80,supported), \+ node(n80,refuted).
verdict(c_e406c0f7f087565b,supported) :- node(n80,supported).
query(verdict(c_e406c0f7f087565b,supported)).
verdict(c_e406c0f7f087565b,refuted) :- node(n80,refuted).
query(verdict(c_e406c0f7f087565b,refuted)).
verdict(c_e406c0f7f087565b,unknown) :- node(n80,unknown).
query(verdict(c_e406c0f7f087565b,unknown)).
node(n86,supported) :- node(n61,supported), node(n62,supported), node(n63,supported), node(n82,supported).
node(n86,refuted) :- node(n61,refuted).
node(n86,refuted) :- node(n62,refuted).
node(n86,refuted) :- node(n63,refuted).
node(n86,refuted) :- node(n82,refuted).
node(n86,unknown) :- \+ node(n86,supported), \+ node(n86,refuted).
node(n87,supported) :- node(n65,supported), node(n66,supported), node(n67,supported), node(n84,supported).
node(n87,refuted) :- node(n65,refuted).
node(n87,refuted) :- node(n66,refuted).
node(n87,refuted) :- node(n67,refuted).
node(n87,refuted) :- node(n84,refuted).
node(n87,unknown) :- \+ node(n87,supported), \+ node(n87,refuted).
node(n85,refuted) :- node(n86,refuted), node(n87,refuted), node(n9,refuted).
node(n85,supported) :- node(n86,supported).
node(n85,supported) :- node(n87,supported).
node(n85,supported) :- node(n9,supported).
node(n85,unknown) :- \+ node(n85,supported), \+ node(n85,refuted).
verdict(c_0f3576e0dfa880e4,supported) :- node(n85,supported).
query(verdict(c_0f3576e0dfa880e4,supported)).
verdict(c_0f3576e0dfa880e4,refuted) :- node(n85,refuted).
query(verdict(c_0f3576e0dfa880e4,refuted)).
verdict(c_0f3576e0dfa880e4,unknown) :- node(n85,unknown).
query(verdict(c_0f3576e0dfa880e4,unknown)).
node(n90,supported) :- status(o_82ad221b33ab2c15f58c,supported).
node(n90,refuted) :- status(o_82ad221b33ab2c15f58c,refuted).
node(n90,unknown) :- status(o_82ad221b33ab2c15f58c,unknown).
node(n91,supported) :- status(o_1d87fe60ecdadcf61d93,supported).
node(n91,refuted) :- status(o_1d87fe60ecdadcf61d93,refuted).
node(n91,unknown) :- status(o_1d87fe60ecdadcf61d93,unknown).
node(n92,supported) :- status(o_ebf8ec75796688146699,supported).
node(n92,refuted) :- status(o_ebf8ec75796688146699,refuted).
node(n92,unknown) :- status(o_ebf8ec75796688146699,unknown).
node(n89,supported) :- node(n90,supported), node(n91,supported), node(n92,supported).
node(n89,refuted) :- node(n90,refuted).
node(n89,refuted) :- node(n91,refuted).
node(n89,refuted) :- node(n92,refuted).
node(n89,unknown) :- \+ node(n89,supported), \+ node(n89,refuted).
node(n94,supported) :- status(o_85dcec15211ddf1abfdf,supported).
node(n94,refuted) :- status(o_85dcec15211ddf1abfdf,refuted).
node(n94,unknown) :- status(o_85dcec15211ddf1abfdf,unknown).
node(n95,supported) :- status(o_9f85c3d357e2edf5fbc3,supported).
node(n95,refuted) :- status(o_9f85c3d357e2edf5fbc3,refuted).
node(n95,unknown) :- status(o_9f85c3d357e2edf5fbc3,unknown).
node(n96,supported) :- status(o_4b8ecb25124d4c821496,supported).
node(n96,refuted) :- status(o_4b8ecb25124d4c821496,refuted).
node(n96,unknown) :- status(o_4b8ecb25124d4c821496,unknown).
node(n93,supported) :- node(n94,supported), node(n95,supported), node(n96,supported).
node(n93,refuted) :- node(n94,refuted).
node(n93,refuted) :- node(n95,refuted).
node(n93,refuted) :- node(n96,refuted).
node(n93,unknown) :- \+ node(n93,supported), \+ node(n93,refuted).
node(n88,refuted) :- node(n89,refuted), node(n93,refuted), node(n9,refuted).
node(n88,supported) :- node(n89,supported).
node(n88,supported) :- node(n93,supported).
node(n88,supported) :- node(n9,supported).
node(n88,unknown) :- \+ node(n88,supported), \+ node(n88,refuted).
verdict(c_0b795e98fd3a99fe,supported) :- node(n88,supported).
query(verdict(c_0b795e98fd3a99fe,supported)).
verdict(c_0b795e98fd3a99fe,refuted) :- node(n88,refuted).
query(verdict(c_0b795e98fd3a99fe,refuted)).
verdict(c_0b795e98fd3a99fe,unknown) :- node(n88,unknown).
query(verdict(c_0b795e98fd3a99fe,unknown)).
node(n99,supported) :- status(o_0afb4fc16cec45d2dd4d,supported).
node(n99,refuted) :- status(o_0afb4fc16cec45d2dd4d,refuted).
node(n99,unknown) :- status(o_0afb4fc16cec45d2dd4d,unknown).
node(n98,supported) :- node(n90,supported), node(n91,supported), node(n92,supported), node(n99,supported).
node(n98,refuted) :- node(n90,refuted).
node(n98,refuted) :- node(n91,refuted).
node(n98,refuted) :- node(n92,refuted).
node(n98,refuted) :- node(n99,refuted).
node(n98,unknown) :- \+ node(n98,supported), \+ node(n98,refuted).
node(n101,supported) :- status(o_9c3011b5e8e40ce34901,supported).
node(n101,refuted) :- status(o_9c3011b5e8e40ce34901,refuted).
node(n101,unknown) :- status(o_9c3011b5e8e40ce34901,unknown).
node(n100,supported) :- node(n94,supported), node(n95,supported), node(n96,supported), node(n101,supported).
node(n100,refuted) :- node(n94,refuted).
node(n100,refuted) :- node(n95,refuted).
node(n100,refuted) :- node(n96,refuted).
node(n100,refuted) :- node(n101,refuted).
node(n100,unknown) :- \+ node(n100,supported), \+ node(n100,refuted).
node(n97,refuted) :- node(n98,refuted), node(n100,refuted), node(n9,refuted).
node(n97,supported) :- node(n98,supported).
node(n97,supported) :- node(n100,supported).
node(n97,supported) :- node(n9,supported).
node(n97,unknown) :- \+ node(n97,supported), \+ node(n97,refuted).
verdict(c_45d29e74176efafc,supported) :- node(n97,supported).
query(verdict(c_45d29e74176efafc,supported)).
verdict(c_45d29e74176efafc,refuted) :- node(n97,refuted).
query(verdict(c_45d29e74176efafc,refuted)).
verdict(c_45d29e74176efafc,unknown) :- node(n97,unknown).
query(verdict(c_45d29e74176efafc,unknown)).
node(n104,supported) :- status(o_bb880cbcf680890dc13f,supported).
node(n104,refuted) :- status(o_bb880cbcf680890dc13f,refuted).
node(n104,unknown) :- status(o_bb880cbcf680890dc13f,unknown).
node(n105,supported) :- status(o_2b2116d29fb3b1d86af2,supported).
node(n105,refuted) :- status(o_2b2116d29fb3b1d86af2,refuted).
node(n105,unknown) :- status(o_2b2116d29fb3b1d86af2,unknown).
node(n103,supported) :- node(n90,supported), node(n91,supported), node(n92,supported), node(n99,supported), node(n104,supported), node(n105,supported).
node(n103,refuted) :- node(n90,refuted).
node(n103,refuted) :- node(n91,refuted).
node(n103,refuted) :- node(n92,refuted).
node(n103,refuted) :- node(n99,refuted).
node(n103,refuted) :- node(n104,refuted).
node(n103,refuted) :- node(n105,refuted).
node(n103,unknown) :- \+ node(n103,supported), \+ node(n103,refuted).
node(n107,supported) :- status(o_b6c2cbe60171a499ef21,supported).
node(n107,refuted) :- status(o_b6c2cbe60171a499ef21,refuted).
node(n107,unknown) :- status(o_b6c2cbe60171a499ef21,unknown).
node(n108,supported) :- status(o_a5bef5aa5fcfe4e31298,supported).
node(n108,refuted) :- status(o_a5bef5aa5fcfe4e31298,refuted).
node(n108,unknown) :- status(o_a5bef5aa5fcfe4e31298,unknown).
node(n106,supported) :- node(n94,supported), node(n95,supported), node(n96,supported), node(n101,supported), node(n107,supported), node(n108,supported).
node(n106,refuted) :- node(n94,refuted).
node(n106,refuted) :- node(n95,refuted).
node(n106,refuted) :- node(n96,refuted).
node(n106,refuted) :- node(n101,refuted).
node(n106,refuted) :- node(n107,refuted).
node(n106,refuted) :- node(n108,refuted).
node(n106,unknown) :- \+ node(n106,supported), \+ node(n106,refuted).
node(n102,refuted) :- node(n103,refuted), node(n106,refuted), node(n9,refuted).
node(n102,supported) :- node(n103,supported).
node(n102,supported) :- node(n106,supported).
node(n102,supported) :- node(n9,supported).
node(n102,unknown) :- \+ node(n102,supported), \+ node(n102,refuted).
verdict(c_a1dff32f8f8f2944,supported) :- node(n102,supported).
query(verdict(c_a1dff32f8f8f2944,supported)).
verdict(c_a1dff32f8f8f2944,refuted) :- node(n102,refuted).
query(verdict(c_a1dff32f8f8f2944,refuted)).
verdict(c_a1dff32f8f8f2944,unknown) :- node(n102,unknown).
query(verdict(c_a1dff32f8f8f2944,unknown)).
node(n111,supported) :- status(o_41a9251a68555c8893e4,supported).
node(n111,refuted) :- status(o_41a9251a68555c8893e4,refuted).
node(n111,unknown) :- status(o_41a9251a68555c8893e4,unknown).
node(n110,supported) :- node(n90,supported), node(n91,supported), node(n111,supported).
node(n110,refuted) :- node(n90,refuted).
node(n110,refuted) :- node(n91,refuted).
node(n110,refuted) :- node(n111,refuted).
node(n110,unknown) :- \+ node(n110,supported), \+ node(n110,refuted).
node(n113,supported) :- status(o_6f87d6f81567fe8bd21c,supported).
node(n113,refuted) :- status(o_6f87d6f81567fe8bd21c,refuted).
node(n113,unknown) :- status(o_6f87d6f81567fe8bd21c,unknown).
node(n112,supported) :- node(n94,supported), node(n95,supported), node(n113,supported).
node(n112,refuted) :- node(n94,refuted).
node(n112,refuted) :- node(n95,refuted).
node(n112,refuted) :- node(n113,refuted).
node(n112,unknown) :- \+ node(n112,supported), \+ node(n112,refuted).
node(n109,refuted) :- node(n110,refuted), node(n112,refuted), node(n9,refuted).
node(n109,supported) :- node(n110,supported).
node(n109,supported) :- node(n112,supported).
node(n109,supported) :- node(n9,supported).
node(n109,unknown) :- \+ node(n109,supported), \+ node(n109,refuted).
verdict(c_7b55fa8b2c5f7eba,supported) :- node(n109,supported).
query(verdict(c_7b55fa8b2c5f7eba,supported)).
verdict(c_7b55fa8b2c5f7eba,refuted) :- node(n109,refuted).
query(verdict(c_7b55fa8b2c5f7eba,refuted)).
verdict(c_7b55fa8b2c5f7eba,unknown) :- node(n109,unknown).
query(verdict(c_7b55fa8b2c5f7eba,unknown)).
node(n115,supported) :- node(n90,supported), node(n91,supported), node(n92,supported), node(n111,supported).
node(n115,refuted) :- node(n90,refuted).
node(n115,refuted) :- node(n91,refuted).
node(n115,refuted) :- node(n92,refuted).
node(n115,refuted) :- node(n111,refuted).
node(n115,unknown) :- \+ node(n115,supported), \+ node(n115,refuted).
node(n116,supported) :- node(n94,supported), node(n95,supported), node(n96,supported), node(n113,supported).
node(n116,refuted) :- node(n94,refuted).
node(n116,refuted) :- node(n95,refuted).
node(n116,refuted) :- node(n96,refuted).
node(n116,refuted) :- node(n113,refuted).
node(n116,unknown) :- \+ node(n116,supported), \+ node(n116,refuted).
node(n114,refuted) :- node(n115,refuted), node(n116,refuted), node(n9,refuted).
node(n114,supported) :- node(n115,supported).
node(n114,supported) :- node(n116,supported).
node(n114,supported) :- node(n9,supported).
node(n114,unknown) :- \+ node(n114,supported), \+ node(n114,refuted).
verdict(c_4a3ce2248ec981e7,supported) :- node(n114,supported).
query(verdict(c_4a3ce2248ec981e7,supported)).
verdict(c_4a3ce2248ec981e7,refuted) :- node(n114,refuted).
query(verdict(c_4a3ce2248ec981e7,refuted)).
verdict(c_4a3ce2248ec981e7,unknown) :- node(n114,unknown).
query(verdict(c_4a3ce2248ec981e7,unknown)).
node(n119,supported) :- status(o_d7988eb331fd3b44c5ff,supported).
node(n119,refuted) :- status(o_d7988eb331fd3b44c5ff,refuted).
node(n119,unknown) :- status(o_d7988eb331fd3b44c5ff,unknown).
node(n120,supported) :- status(o_f3ed1091696a55805aca,supported).
node(n120,refuted) :- status(o_f3ed1091696a55805aca,refuted).
node(n120,unknown) :- status(o_f3ed1091696a55805aca,unknown).
node(n121,supported) :- status(o_744f27687f26e7fd822b,supported).
node(n121,refuted) :- status(o_744f27687f26e7fd822b,refuted).
node(n121,unknown) :- status(o_744f27687f26e7fd822b,unknown).
node(n118,supported) :- node(n119,supported), node(n120,supported), node(n121,supported).
node(n118,refuted) :- node(n119,refuted).
node(n118,refuted) :- node(n120,refuted).
node(n118,refuted) :- node(n121,refuted).
node(n118,unknown) :- \+ node(n118,supported), \+ node(n118,refuted).
node(n123,supported) :- status(o_0115940621757dbaf9a0,supported).
node(n123,refuted) :- status(o_0115940621757dbaf9a0,refuted).
node(n123,unknown) :- status(o_0115940621757dbaf9a0,unknown).
node(n124,supported) :- status(o_030ba71f0a2f9fd42706,supported).
node(n124,refuted) :- status(o_030ba71f0a2f9fd42706,refuted).
node(n124,unknown) :- status(o_030ba71f0a2f9fd42706,unknown).
node(n125,supported) :- status(o_5c55932562f0fec968e0,supported).
node(n125,refuted) :- status(o_5c55932562f0fec968e0,refuted).
node(n125,unknown) :- status(o_5c55932562f0fec968e0,unknown).
node(n122,supported) :- node(n123,supported), node(n124,supported), node(n125,supported).
node(n122,refuted) :- node(n123,refuted).
node(n122,refuted) :- node(n124,refuted).
node(n122,refuted) :- node(n125,refuted).
node(n122,unknown) :- \+ node(n122,supported), \+ node(n122,refuted).
node(n117,refuted) :- node(n118,refuted), node(n122,refuted), node(n9,refuted).
node(n117,supported) :- node(n118,supported).
node(n117,supported) :- node(n122,supported).
node(n117,supported) :- node(n9,supported).
node(n117,unknown) :- \+ node(n117,supported), \+ node(n117,refuted).
verdict(c_c91e4ef90208fe99,supported) :- node(n117,supported).
query(verdict(c_c91e4ef90208fe99,supported)).
verdict(c_c91e4ef90208fe99,refuted) :- node(n117,refuted).
query(verdict(c_c91e4ef90208fe99,refuted)).
verdict(c_c91e4ef90208fe99,unknown) :- node(n117,unknown).
query(verdict(c_c91e4ef90208fe99,unknown)).
node(n128,supported) :- status(o_10009f723b8c8c96e726,supported).
node(n128,refuted) :- status(o_10009f723b8c8c96e726,refuted).
node(n128,unknown) :- status(o_10009f723b8c8c96e726,unknown).
node(n127,supported) :- node(n119,supported), node(n120,supported), node(n121,supported), node(n128,supported).
node(n127,refuted) :- node(n119,refuted).
node(n127,refuted) :- node(n120,refuted).
node(n127,refuted) :- node(n121,refuted).
node(n127,refuted) :- node(n128,refuted).
node(n127,unknown) :- \+ node(n127,supported), \+ node(n127,refuted).
node(n130,supported) :- status(o_e6915b4896efc809687a,supported).
node(n130,refuted) :- status(o_e6915b4896efc809687a,refuted).
node(n130,unknown) :- status(o_e6915b4896efc809687a,unknown).
node(n129,supported) :- node(n123,supported), node(n124,supported), node(n125,supported), node(n130,supported).
node(n129,refuted) :- node(n123,refuted).
node(n129,refuted) :- node(n124,refuted).
node(n129,refuted) :- node(n125,refuted).
node(n129,refuted) :- node(n130,refuted).
node(n129,unknown) :- \+ node(n129,supported), \+ node(n129,refuted).
node(n126,refuted) :- node(n127,refuted), node(n129,refuted), node(n9,refuted).
node(n126,supported) :- node(n127,supported).
node(n126,supported) :- node(n129,supported).
node(n126,supported) :- node(n9,supported).
node(n126,unknown) :- \+ node(n126,supported), \+ node(n126,refuted).
verdict(c_c31d5a963ec43fab,supported) :- node(n126,supported).
query(verdict(c_c31d5a963ec43fab,supported)).
verdict(c_c31d5a963ec43fab,refuted) :- node(n126,refuted).
query(verdict(c_c31d5a963ec43fab,refuted)).
verdict(c_c31d5a963ec43fab,unknown) :- node(n126,unknown).
query(verdict(c_c31d5a963ec43fab,unknown)).
node(n133,supported) :- status(o_1e9fa898d903b4822da8,supported).
node(n133,refuted) :- status(o_1e9fa898d903b4822da8,refuted).
node(n133,unknown) :- status(o_1e9fa898d903b4822da8,unknown).
node(n134,supported) :- status(o_0c1f31a22a22830c6a39,supported).
node(n134,refuted) :- status(o_0c1f31a22a22830c6a39,refuted).
node(n134,unknown) :- status(o_0c1f31a22a22830c6a39,unknown).
node(n132,supported) :- node(n119,supported), node(n120,supported), node(n121,supported), node(n128,supported), node(n133,supported), node(n134,supported).
node(n132,refuted) :- node(n119,refuted).
node(n132,refuted) :- node(n120,refuted).
node(n132,refuted) :- node(n121,refuted).
node(n132,refuted) :- node(n128,refuted).
node(n132,refuted) :- node(n133,refuted).
node(n132,refuted) :- node(n134,refuted).
node(n132,unknown) :- \+ node(n132,supported), \+ node(n132,refuted).
node(n136,supported) :- status(o_5f22e18873b8cdf697c3,supported).
node(n136,refuted) :- status(o_5f22e18873b8cdf697c3,refuted).
node(n136,unknown) :- status(o_5f22e18873b8cdf697c3,unknown).
node(n137,supported) :- status(o_ab08fdf6a824c703e196,supported).
node(n137,refuted) :- status(o_ab08fdf6a824c703e196,refuted).
node(n137,unknown) :- status(o_ab08fdf6a824c703e196,unknown).
node(n135,supported) :- node(n123,supported), node(n124,supported), node(n125,supported), node(n130,supported), node(n136,supported), node(n137,supported).
node(n135,refuted) :- node(n123,refuted).
node(n135,refuted) :- node(n124,refuted).
node(n135,refuted) :- node(n125,refuted).
node(n135,refuted) :- node(n130,refuted).
node(n135,refuted) :- node(n136,refuted).
node(n135,refuted) :- node(n137,refuted).
node(n135,unknown) :- \+ node(n135,supported), \+ node(n135,refuted).
node(n131,refuted) :- node(n132,refuted), node(n135,refuted), node(n9,refuted).
node(n131,supported) :- node(n132,supported).
node(n131,supported) :- node(n135,supported).
node(n131,supported) :- node(n9,supported).
node(n131,unknown) :- \+ node(n131,supported), \+ node(n131,refuted).
verdict(c_68d12a17dd4cac89,supported) :- node(n131,supported).
query(verdict(c_68d12a17dd4cac89,supported)).
verdict(c_68d12a17dd4cac89,refuted) :- node(n131,refuted).
query(verdict(c_68d12a17dd4cac89,refuted)).
verdict(c_68d12a17dd4cac89,unknown) :- node(n131,unknown).
query(verdict(c_68d12a17dd4cac89,unknown)).
node(n140,supported) :- status(o_eb582db99c112d906a35,supported).
node(n140,refuted) :- status(o_eb582db99c112d906a35,refuted).
node(n140,unknown) :- status(o_eb582db99c112d906a35,unknown).
node(n139,supported) :- node(n119,supported), node(n120,supported), node(n140,supported).
node(n139,refuted) :- node(n119,refuted).
node(n139,refuted) :- node(n120,refuted).
node(n139,refuted) :- node(n140,refuted).
node(n139,unknown) :- \+ node(n139,supported), \+ node(n139,refuted).
node(n142,supported) :- status(o_b12095df7fe05fd6066c,supported).
node(n142,refuted) :- status(o_b12095df7fe05fd6066c,refuted).
node(n142,unknown) :- status(o_b12095df7fe05fd6066c,unknown).
node(n141,supported) :- node(n123,supported), node(n124,supported), node(n142,supported).
node(n141,refuted) :- node(n123,refuted).
node(n141,refuted) :- node(n124,refuted).
node(n141,refuted) :- node(n142,refuted).
node(n141,unknown) :- \+ node(n141,supported), \+ node(n141,refuted).
node(n138,refuted) :- node(n139,refuted), node(n141,refuted), node(n9,refuted).
node(n138,supported) :- node(n139,supported).
node(n138,supported) :- node(n141,supported).
node(n138,supported) :- node(n9,supported).
node(n138,unknown) :- \+ node(n138,supported), \+ node(n138,refuted).
verdict(c_2a77feb3d59a26fd,supported) :- node(n138,supported).
query(verdict(c_2a77feb3d59a26fd,supported)).
verdict(c_2a77feb3d59a26fd,refuted) :- node(n138,refuted).
query(verdict(c_2a77feb3d59a26fd,refuted)).
verdict(c_2a77feb3d59a26fd,unknown) :- node(n138,unknown).
query(verdict(c_2a77feb3d59a26fd,unknown)).
node(n144,supported) :- node(n119,supported), node(n120,supported), node(n121,supported), node(n140,supported).
node(n144,refuted) :- node(n119,refuted).
node(n144,refuted) :- node(n120,refuted).
node(n144,refuted) :- node(n121,refuted).
node(n144,refuted) :- node(n140,refuted).
node(n144,unknown) :- \+ node(n144,supported), \+ node(n144,refuted).
node(n145,supported) :- node(n123,supported), node(n124,supported), node(n125,supported), node(n142,supported).
node(n145,refuted) :- node(n123,refuted).
node(n145,refuted) :- node(n124,refuted).
node(n145,refuted) :- node(n125,refuted).
node(n145,refuted) :- node(n142,refuted).
node(n145,unknown) :- \+ node(n145,supported), \+ node(n145,refuted).
node(n143,refuted) :- node(n144,refuted), node(n145,refuted), node(n9,refuted).
node(n143,supported) :- node(n144,supported).
node(n143,supported) :- node(n145,supported).
node(n143,supported) :- node(n9,supported).
node(n143,unknown) :- \+ node(n143,supported), \+ node(n143,refuted).
verdict(c_a3bb25874764bab0,supported) :- node(n143,supported).
query(verdict(c_a3bb25874764bab0,supported)).
verdict(c_a3bb25874764bab0,refuted) :- node(n143,refuted).
query(verdict(c_a3bb25874764bab0,refuted)).
verdict(c_a3bb25874764bab0,unknown) :- node(n143,unknown).
query(verdict(c_a3bb25874764bab0,unknown)).
node(n148,supported) :- status(o_e034b05a102bb71443eb,supported).
node(n148,refuted) :- status(o_e034b05a102bb71443eb,refuted).
node(n148,unknown) :- status(o_e034b05a102bb71443eb,unknown).
node(n149,supported) :- status(o_3a9ccd4264b4c28b9828,supported).
node(n149,refuted) :- status(o_3a9ccd4264b4c28b9828,refuted).
node(n149,unknown) :- status(o_3a9ccd4264b4c28b9828,unknown).
node(n150,supported) :- status(o_12bde1e3c18aacbbcf49,supported).
node(n150,refuted) :- status(o_12bde1e3c18aacbbcf49,refuted).
node(n150,unknown) :- status(o_12bde1e3c18aacbbcf49,unknown).
node(n147,supported) :- node(n148,supported), node(n149,supported), node(n150,supported).
node(n147,refuted) :- node(n148,refuted).
node(n147,refuted) :- node(n149,refuted).
node(n147,refuted) :- node(n150,refuted).
node(n147,unknown) :- \+ node(n147,supported), \+ node(n147,refuted).
node(n152,supported) :- status(o_2034544f9423b13ee10c,supported).
node(n152,refuted) :- status(o_2034544f9423b13ee10c,refuted).
node(n152,unknown) :- status(o_2034544f9423b13ee10c,unknown).
node(n153,supported) :- status(o_c1b00583d45b7b41b0b3,supported).
node(n153,refuted) :- status(o_c1b00583d45b7b41b0b3,refuted).
node(n153,unknown) :- status(o_c1b00583d45b7b41b0b3,unknown).
node(n154,supported) :- status(o_e7cb16d0723df82281e5,supported).
node(n154,refuted) :- status(o_e7cb16d0723df82281e5,refuted).
node(n154,unknown) :- status(o_e7cb16d0723df82281e5,unknown).
node(n151,supported) :- node(n152,supported), node(n153,supported), node(n154,supported).
node(n151,refuted) :- node(n152,refuted).
node(n151,refuted) :- node(n153,refuted).
node(n151,refuted) :- node(n154,refuted).
node(n151,unknown) :- \+ node(n151,supported), \+ node(n151,refuted).
node(n146,refuted) :- node(n147,refuted), node(n151,refuted), node(n9,refuted).
node(n146,supported) :- node(n147,supported).
node(n146,supported) :- node(n151,supported).
node(n146,supported) :- node(n9,supported).
node(n146,unknown) :- \+ node(n146,supported), \+ node(n146,refuted).
verdict(c_4547d55d14a887e8,supported) :- node(n146,supported).
query(verdict(c_4547d55d14a887e8,supported)).
verdict(c_4547d55d14a887e8,refuted) :- node(n146,refuted).
query(verdict(c_4547d55d14a887e8,refuted)).
verdict(c_4547d55d14a887e8,unknown) :- node(n146,unknown).
query(verdict(c_4547d55d14a887e8,unknown)).
node(n157,supported) :- status(o_63bbfe9f39f4da8af342,supported).
node(n157,refuted) :- status(o_63bbfe9f39f4da8af342,refuted).
node(n157,unknown) :- status(o_63bbfe9f39f4da8af342,unknown).
node(n156,supported) :- node(n148,supported), node(n149,supported), node(n150,supported), node(n157,supported).
node(n156,refuted) :- node(n148,refuted).
node(n156,refuted) :- node(n149,refuted).
node(n156,refuted) :- node(n150,refuted).
node(n156,refuted) :- node(n157,refuted).
node(n156,unknown) :- \+ node(n156,supported), \+ node(n156,refuted).
node(n159,supported) :- status(o_04be5d700f90dc3916ab,supported).
node(n159,refuted) :- status(o_04be5d700f90dc3916ab,refuted).
node(n159,unknown) :- status(o_04be5d700f90dc3916ab,unknown).
node(n158,supported) :- node(n152,supported), node(n153,supported), node(n154,supported), node(n159,supported).
node(n158,refuted) :- node(n152,refuted).
node(n158,refuted) :- node(n153,refuted).
node(n158,refuted) :- node(n154,refuted).
node(n158,refuted) :- node(n159,refuted).
node(n158,unknown) :- \+ node(n158,supported), \+ node(n158,refuted).
node(n155,refuted) :- node(n156,refuted), node(n158,refuted), node(n9,refuted).
node(n155,supported) :- node(n156,supported).
node(n155,supported) :- node(n158,supported).
node(n155,supported) :- node(n9,supported).
node(n155,unknown) :- \+ node(n155,supported), \+ node(n155,refuted).
verdict(c_a1292c115258a20c,supported) :- node(n155,supported).
query(verdict(c_a1292c115258a20c,supported)).
verdict(c_a1292c115258a20c,refuted) :- node(n155,refuted).
query(verdict(c_a1292c115258a20c,refuted)).
verdict(c_a1292c115258a20c,unknown) :- node(n155,unknown).
query(verdict(c_a1292c115258a20c,unknown)).
node(n162,supported) :- status(o_62a5a22f2c2dc1d86a08,supported).
node(n162,refuted) :- status(o_62a5a22f2c2dc1d86a08,refuted).
node(n162,unknown) :- status(o_62a5a22f2c2dc1d86a08,unknown).
node(n163,supported) :- status(o_b3add89a1e3dd582be95,supported).
node(n163,refuted) :- status(o_b3add89a1e3dd582be95,refuted).
node(n163,unknown) :- status(o_b3add89a1e3dd582be95,unknown).
node(n161,supported) :- node(n148,supported), node(n149,supported), node(n150,supported), node(n157,supported), node(n162,supported), node(n163,supported).
node(n161,refuted) :- node(n148,refuted).
node(n161,refuted) :- node(n149,refuted).
node(n161,refuted) :- node(n150,refuted).
node(n161,refuted) :- node(n157,refuted).
node(n161,refuted) :- node(n162,refuted).
node(n161,refuted) :- node(n163,refuted).
node(n161,unknown) :- \+ node(n161,supported), \+ node(n161,refuted).
node(n165,supported) :- status(o_b0b85fd1712f1a733c85,supported).
node(n165,refuted) :- status(o_b0b85fd1712f1a733c85,refuted).
node(n165,unknown) :- status(o_b0b85fd1712f1a733c85,unknown).
node(n166,supported) :- status(o_5aa5fb76befc670efa9e,supported).
node(n166,refuted) :- status(o_5aa5fb76befc670efa9e,refuted).
node(n166,unknown) :- status(o_5aa5fb76befc670efa9e,unknown).
node(n164,supported) :- node(n152,supported), node(n153,supported), node(n154,supported), node(n159,supported), node(n165,supported), node(n166,supported).
node(n164,refuted) :- node(n152,refuted).
node(n164,refuted) :- node(n153,refuted).
node(n164,refuted) :- node(n154,refuted).
node(n164,refuted) :- node(n159,refuted).
node(n164,refuted) :- node(n165,refuted).
node(n164,refuted) :- node(n166,refuted).
node(n164,unknown) :- \+ node(n164,supported), \+ node(n164,refuted).
node(n160,refuted) :- node(n161,refuted), node(n164,refuted), node(n9,refuted).
node(n160,supported) :- node(n161,supported).
node(n160,supported) :- node(n164,supported).
node(n160,supported) :- node(n9,supported).
node(n160,unknown) :- \+ node(n160,supported), \+ node(n160,refuted).
verdict(c_fcd094d9884f8580,supported) :- node(n160,supported).
query(verdict(c_fcd094d9884f8580,supported)).
verdict(c_fcd094d9884f8580,refuted) :- node(n160,refuted).
query(verdict(c_fcd094d9884f8580,refuted)).
verdict(c_fcd094d9884f8580,unknown) :- node(n160,unknown).
query(verdict(c_fcd094d9884f8580,unknown)).
node(n169,supported) :- status(o_31b92fcc81d2fd7a9544,supported).
node(n169,refuted) :- status(o_31b92fcc81d2fd7a9544,refuted).
node(n169,unknown) :- status(o_31b92fcc81d2fd7a9544,unknown).
node(n168,supported) :- node(n148,supported), node(n149,supported), node(n169,supported).
node(n168,refuted) :- node(n148,refuted).
node(n168,refuted) :- node(n149,refuted).
node(n168,refuted) :- node(n169,refuted).
node(n168,unknown) :- \+ node(n168,supported), \+ node(n168,refuted).
node(n171,supported) :- status(o_07a5dffc9dc8e0712231,supported).
node(n171,refuted) :- status(o_07a5dffc9dc8e0712231,refuted).
node(n171,unknown) :- status(o_07a5dffc9dc8e0712231,unknown).
node(n170,supported) :- node(n152,supported), node(n153,supported), node(n171,supported).
node(n170,refuted) :- node(n152,refuted).
node(n170,refuted) :- node(n153,refuted).
node(n170,refuted) :- node(n171,refuted).
node(n170,unknown) :- \+ node(n170,supported), \+ node(n170,refuted).
node(n167,refuted) :- node(n168,refuted), node(n170,refuted), node(n9,refuted).
node(n167,supported) :- node(n168,supported).
node(n167,supported) :- node(n170,supported).
node(n167,supported) :- node(n9,supported).
node(n167,unknown) :- \+ node(n167,supported), \+ node(n167,refuted).
verdict(c_0e9e48507535271d,supported) :- node(n167,supported).
query(verdict(c_0e9e48507535271d,supported)).
verdict(c_0e9e48507535271d,refuted) :- node(n167,refuted).
query(verdict(c_0e9e48507535271d,refuted)).
verdict(c_0e9e48507535271d,unknown) :- node(n167,unknown).
query(verdict(c_0e9e48507535271d,unknown)).
node(n173,supported) :- node(n148,supported), node(n149,supported), node(n150,supported), node(n169,supported).
node(n173,refuted) :- node(n148,refuted).
node(n173,refuted) :- node(n149,refuted).
node(n173,refuted) :- node(n150,refuted).
node(n173,refuted) :- node(n169,refuted).
node(n173,unknown) :- \+ node(n173,supported), \+ node(n173,refuted).
node(n174,supported) :- node(n152,supported), node(n153,supported), node(n154,supported), node(n171,supported).
node(n174,refuted) :- node(n152,refuted).
node(n174,refuted) :- node(n153,refuted).
node(n174,refuted) :- node(n154,refuted).
node(n174,refuted) :- node(n171,refuted).
node(n174,unknown) :- \+ node(n174,supported), \+ node(n174,refuted).
node(n172,refuted) :- node(n173,refuted), node(n174,refuted), node(n9,refuted).
node(n172,supported) :- node(n173,supported).
node(n172,supported) :- node(n174,supported).
node(n172,supported) :- node(n9,supported).
node(n172,unknown) :- \+ node(n172,supported), \+ node(n172,refuted).
verdict(c_37ff73d73fac29cb,supported) :- node(n172,supported).
query(verdict(c_37ff73d73fac29cb,supported)).
verdict(c_37ff73d73fac29cb,refuted) :- node(n172,refuted).
query(verdict(c_37ff73d73fac29cb,refuted)).
verdict(c_37ff73d73fac29cb,unknown) :- node(n172,unknown).
query(verdict(c_37ff73d73fac29cb,unknown)).
node(n177,supported) :- status(o_20c14f40b044c7153778,supported).
node(n177,refuted) :- status(o_20c14f40b044c7153778,refuted).
node(n177,unknown) :- status(o_20c14f40b044c7153778,unknown).
node(n178,supported) :- status(o_e01faaa10ef7d63d35db,supported).
node(n178,refuted) :- status(o_e01faaa10ef7d63d35db,refuted).
node(n178,unknown) :- status(o_e01faaa10ef7d63d35db,unknown).
node(n179,supported) :- status(o_4375e605e7ec70625eb4,supported).
node(n179,refuted) :- status(o_4375e605e7ec70625eb4,refuted).
node(n179,unknown) :- status(o_4375e605e7ec70625eb4,unknown).
node(n176,supported) :- node(n177,supported), node(n178,supported), node(n179,supported).
node(n176,refuted) :- node(n177,refuted).
node(n176,refuted) :- node(n178,refuted).
node(n176,refuted) :- node(n179,refuted).
node(n176,unknown) :- \+ node(n176,supported), \+ node(n176,refuted).
node(n181,supported) :- status(o_30f0596f3e8b3bef1789,supported).
node(n181,refuted) :- status(o_30f0596f3e8b3bef1789,refuted).
node(n181,unknown) :- status(o_30f0596f3e8b3bef1789,unknown).
node(n182,supported) :- status(o_6e1268fc8948a84cf498,supported).
node(n182,refuted) :- status(o_6e1268fc8948a84cf498,refuted).
node(n182,unknown) :- status(o_6e1268fc8948a84cf498,unknown).
node(n183,supported) :- status(o_89c5541aaba880657923,supported).
node(n183,refuted) :- status(o_89c5541aaba880657923,refuted).
node(n183,unknown) :- status(o_89c5541aaba880657923,unknown).
node(n180,supported) :- node(n181,supported), node(n182,supported), node(n183,supported).
node(n180,refuted) :- node(n181,refuted).
node(n180,refuted) :- node(n182,refuted).
node(n180,refuted) :- node(n183,refuted).
node(n180,unknown) :- \+ node(n180,supported), \+ node(n180,refuted).
node(n175,refuted) :- node(n176,refuted), node(n180,refuted), node(n9,refuted).
node(n175,supported) :- node(n176,supported).
node(n175,supported) :- node(n180,supported).
node(n175,supported) :- node(n9,supported).
node(n175,unknown) :- \+ node(n175,supported), \+ node(n175,refuted).
verdict(c_32860bcebbb29477,supported) :- node(n175,supported).
query(verdict(c_32860bcebbb29477,supported)).
verdict(c_32860bcebbb29477,refuted) :- node(n175,refuted).
query(verdict(c_32860bcebbb29477,refuted)).
verdict(c_32860bcebbb29477,unknown) :- node(n175,unknown).
query(verdict(c_32860bcebbb29477,unknown)).
node(n186,supported) :- status(o_4a9f99d0282d3c9de002,supported).
node(n186,refuted) :- status(o_4a9f99d0282d3c9de002,refuted).
node(n186,unknown) :- status(o_4a9f99d0282d3c9de002,unknown).
node(n185,supported) :- node(n177,supported), node(n178,supported), node(n179,supported), node(n186,supported).
node(n185,refuted) :- node(n177,refuted).
node(n185,refuted) :- node(n178,refuted).
node(n185,refuted) :- node(n179,refuted).
node(n185,refuted) :- node(n186,refuted).
node(n185,unknown) :- \+ node(n185,supported), \+ node(n185,refuted).
node(n188,supported) :- status(o_32a0d32a2aacd26e41ee,supported).
node(n188,refuted) :- status(o_32a0d32a2aacd26e41ee,refuted).
node(n188,unknown) :- status(o_32a0d32a2aacd26e41ee,unknown).
node(n187,supported) :- node(n181,supported), node(n182,supported), node(n183,supported), node(n188,supported).
node(n187,refuted) :- node(n181,refuted).
node(n187,refuted) :- node(n182,refuted).
node(n187,refuted) :- node(n183,refuted).
node(n187,refuted) :- node(n188,refuted).
node(n187,unknown) :- \+ node(n187,supported), \+ node(n187,refuted).
node(n184,refuted) :- node(n185,refuted), node(n187,refuted), node(n9,refuted).
node(n184,supported) :- node(n185,supported).
node(n184,supported) :- node(n187,supported).
node(n184,supported) :- node(n9,supported).
node(n184,unknown) :- \+ node(n184,supported), \+ node(n184,refuted).
verdict(c_48b1db31c5c8766b,supported) :- node(n184,supported).
query(verdict(c_48b1db31c5c8766b,supported)).
verdict(c_48b1db31c5c8766b,refuted) :- node(n184,refuted).
query(verdict(c_48b1db31c5c8766b,refuted)).
verdict(c_48b1db31c5c8766b,unknown) :- node(n184,unknown).
query(verdict(c_48b1db31c5c8766b,unknown)).
node(n191,supported) :- status(o_dc0d0bc1b798d1d39a03,supported).
node(n191,refuted) :- status(o_dc0d0bc1b798d1d39a03,refuted).
node(n191,unknown) :- status(o_dc0d0bc1b798d1d39a03,unknown).
node(n192,supported) :- status(o_5fc90dd0d393e614db3f,supported).
node(n192,refuted) :- status(o_5fc90dd0d393e614db3f,refuted).
node(n192,unknown) :- status(o_5fc90dd0d393e614db3f,unknown).
node(n190,supported) :- node(n177,supported), node(n178,supported), node(n179,supported), node(n186,supported), node(n191,supported), node(n192,supported).
node(n190,refuted) :- node(n177,refuted).
node(n190,refuted) :- node(n178,refuted).
node(n190,refuted) :- node(n179,refuted).
node(n190,refuted) :- node(n186,refuted).
node(n190,refuted) :- node(n191,refuted).
node(n190,refuted) :- node(n192,refuted).
node(n190,unknown) :- \+ node(n190,supported), \+ node(n190,refuted).
node(n194,supported) :- status(o_4d3fb9f97ac8088eec0c,supported).
node(n194,refuted) :- status(o_4d3fb9f97ac8088eec0c,refuted).
node(n194,unknown) :- status(o_4d3fb9f97ac8088eec0c,unknown).
node(n195,supported) :- status(o_87958d68f26d8919a131,supported).
node(n195,refuted) :- status(o_87958d68f26d8919a131,refuted).
node(n195,unknown) :- status(o_87958d68f26d8919a131,unknown).
node(n193,supported) :- node(n181,supported), node(n182,supported), node(n183,supported), node(n188,supported), node(n194,supported), node(n195,supported).
node(n193,refuted) :- node(n181,refuted).
node(n193,refuted) :- node(n182,refuted).
node(n193,refuted) :- node(n183,refuted).
node(n193,refuted) :- node(n188,refuted).
node(n193,refuted) :- node(n194,refuted).
node(n193,refuted) :- node(n195,refuted).
node(n193,unknown) :- \+ node(n193,supported), \+ node(n193,refuted).
node(n189,refuted) :- node(n190,refuted), node(n193,refuted), node(n9,refuted).
node(n189,supported) :- node(n190,supported).
node(n189,supported) :- node(n193,supported).
node(n189,supported) :- node(n9,supported).
node(n189,unknown) :- \+ node(n189,supported), \+ node(n189,refuted).
verdict(c_5618973d51676781,supported) :- node(n189,supported).
query(verdict(c_5618973d51676781,supported)).
verdict(c_5618973d51676781,refuted) :- node(n189,refuted).
query(verdict(c_5618973d51676781,refuted)).
verdict(c_5618973d51676781,unknown) :- node(n189,unknown).
query(verdict(c_5618973d51676781,unknown)).
node(n198,supported) :- status(o_146dea726bd2becb028a,supported).
node(n198,refuted) :- status(o_146dea726bd2becb028a,refuted).
node(n198,unknown) :- status(o_146dea726bd2becb028a,unknown).
node(n197,supported) :- node(n177,supported), node(n178,supported), node(n198,supported).
node(n197,refuted) :- node(n177,refuted).
node(n197,refuted) :- node(n178,refuted).
node(n197,refuted) :- node(n198,refuted).
node(n197,unknown) :- \+ node(n197,supported), \+ node(n197,refuted).
node(n200,supported) :- status(o_cdeca8eeb3fbda1aa24b,supported).
node(n200,refuted) :- status(o_cdeca8eeb3fbda1aa24b,refuted).
node(n200,unknown) :- status(o_cdeca8eeb3fbda1aa24b,unknown).
node(n199,supported) :- node(n181,supported), node(n182,supported), node(n200,supported).
node(n199,refuted) :- node(n181,refuted).
node(n199,refuted) :- node(n182,refuted).
node(n199,refuted) :- node(n200,refuted).
node(n199,unknown) :- \+ node(n199,supported), \+ node(n199,refuted).
node(n196,refuted) :- node(n197,refuted), node(n199,refuted), node(n9,refuted).
node(n196,supported) :- node(n197,supported).
node(n196,supported) :- node(n199,supported).
node(n196,supported) :- node(n9,supported).
node(n196,unknown) :- \+ node(n196,supported), \+ node(n196,refuted).
verdict(c_4218ee16f5d158a8,supported) :- node(n196,supported).
query(verdict(c_4218ee16f5d158a8,supported)).
verdict(c_4218ee16f5d158a8,refuted) :- node(n196,refuted).
query(verdict(c_4218ee16f5d158a8,refuted)).
verdict(c_4218ee16f5d158a8,unknown) :- node(n196,unknown).
query(verdict(c_4218ee16f5d158a8,unknown)).
node(n202,supported) :- node(n177,supported), node(n178,supported), node(n179,supported), node(n198,supported).
node(n202,refuted) :- node(n177,refuted).
node(n202,refuted) :- node(n178,refuted).
node(n202,refuted) :- node(n179,refuted).
node(n202,refuted) :- node(n198,refuted).
node(n202,unknown) :- \+ node(n202,supported), \+ node(n202,refuted).
node(n203,supported) :- node(n181,supported), node(n182,supported), node(n183,supported), node(n200,supported).
node(n203,refuted) :- node(n181,refuted).
node(n203,refuted) :- node(n182,refuted).
node(n203,refuted) :- node(n183,refuted).
node(n203,refuted) :- node(n200,refuted).
node(n203,unknown) :- \+ node(n203,supported), \+ node(n203,refuted).
node(n201,refuted) :- node(n202,refuted), node(n203,refuted), node(n9,refuted).
node(n201,supported) :- node(n202,supported).
node(n201,supported) :- node(n203,supported).
node(n201,supported) :- node(n9,supported).
node(n201,unknown) :- \+ node(n201,supported), \+ node(n201,refuted).
verdict(c_944dd8cd923eb1b6,supported) :- node(n201,supported).
query(verdict(c_944dd8cd923eb1b6,supported)).
verdict(c_944dd8cd923eb1b6,refuted) :- node(n201,refuted).
query(verdict(c_944dd8cd923eb1b6,refuted)).
verdict(c_944dd8cd923eb1b6,unknown) :- node(n201,unknown).
query(verdict(c_944dd8cd923eb1b6,unknown)).
node(n206,supported) :- status(o_95db15e16a5cc43e5642,supported).
node(n206,refuted) :- status(o_95db15e16a5cc43e5642,refuted).
node(n206,unknown) :- status(o_95db15e16a5cc43e5642,unknown).
node(n207,supported) :- status(o_2fc41054333cfcecb34a,supported).
node(n207,refuted) :- status(o_2fc41054333cfcecb34a,refuted).
node(n207,unknown) :- status(o_2fc41054333cfcecb34a,unknown).
node(n208,supported) :- status(o_208962c0e68aea132d33,supported).
node(n208,refuted) :- status(o_208962c0e68aea132d33,refuted).
node(n208,unknown) :- status(o_208962c0e68aea132d33,unknown).
node(n205,supported) :- node(n206,supported), node(n207,supported), node(n208,supported).
node(n205,refuted) :- node(n206,refuted).
node(n205,refuted) :- node(n207,refuted).
node(n205,refuted) :- node(n208,refuted).
node(n205,unknown) :- \+ node(n205,supported), \+ node(n205,refuted).
node(n210,supported) :- status(o_b3d2c1398eb36c39e4db,supported).
node(n210,refuted) :- status(o_b3d2c1398eb36c39e4db,refuted).
node(n210,unknown) :- status(o_b3d2c1398eb36c39e4db,unknown).
node(n211,supported) :- status(o_ce6f0fe5ffbf952258f9,supported).
node(n211,refuted) :- status(o_ce6f0fe5ffbf952258f9,refuted).
node(n211,unknown) :- status(o_ce6f0fe5ffbf952258f9,unknown).
node(n212,supported) :- status(o_ceffc576b1df0a12075c,supported).
node(n212,refuted) :- status(o_ceffc576b1df0a12075c,refuted).
node(n212,unknown) :- status(o_ceffc576b1df0a12075c,unknown).
node(n209,supported) :- node(n210,supported), node(n211,supported), node(n212,supported).
node(n209,refuted) :- node(n210,refuted).
node(n209,refuted) :- node(n211,refuted).
node(n209,refuted) :- node(n212,refuted).
node(n209,unknown) :- \+ node(n209,supported), \+ node(n209,refuted).
node(n204,refuted) :- node(n205,refuted), node(n209,refuted), node(n9,refuted).
node(n204,supported) :- node(n205,supported).
node(n204,supported) :- node(n209,supported).
node(n204,supported) :- node(n9,supported).
node(n204,unknown) :- \+ node(n204,supported), \+ node(n204,refuted).
verdict(c_c4e91aa4c24e3bb9,supported) :- node(n204,supported).
query(verdict(c_c4e91aa4c24e3bb9,supported)).
verdict(c_c4e91aa4c24e3bb9,refuted) :- node(n204,refuted).
query(verdict(c_c4e91aa4c24e3bb9,refuted)).
verdict(c_c4e91aa4c24e3bb9,unknown) :- node(n204,unknown).
query(verdict(c_c4e91aa4c24e3bb9,unknown)).
node(n215,supported) :- status(o_283c893c4045ed4f9918,supported).
node(n215,refuted) :- status(o_283c893c4045ed4f9918,refuted).
node(n215,unknown) :- status(o_283c893c4045ed4f9918,unknown).
node(n214,supported) :- node(n206,supported), node(n207,supported), node(n208,supported), node(n215,supported).
node(n214,refuted) :- node(n206,refuted).
node(n214,refuted) :- node(n207,refuted).
node(n214,refuted) :- node(n208,refuted).
node(n214,refuted) :- node(n215,refuted).
node(n214,unknown) :- \+ node(n214,supported), \+ node(n214,refuted).
node(n217,supported) :- status(o_e3f206f47c32ad8739a7,supported).
node(n217,refuted) :- status(o_e3f206f47c32ad8739a7,refuted).
node(n217,unknown) :- status(o_e3f206f47c32ad8739a7,unknown).
node(n216,supported) :- node(n210,supported), node(n211,supported), node(n212,supported), node(n217,supported).
node(n216,refuted) :- node(n210,refuted).
node(n216,refuted) :- node(n211,refuted).
node(n216,refuted) :- node(n212,refuted).
node(n216,refuted) :- node(n217,refuted).
node(n216,unknown) :- \+ node(n216,supported), \+ node(n216,refuted).
node(n213,refuted) :- node(n214,refuted), node(n216,refuted), node(n9,refuted).
node(n213,supported) :- node(n214,supported).
node(n213,supported) :- node(n216,supported).
node(n213,supported) :- node(n9,supported).
node(n213,unknown) :- \+ node(n213,supported), \+ node(n213,refuted).
verdict(c_9b3ca243208d0b4e,supported) :- node(n213,supported).
query(verdict(c_9b3ca243208d0b4e,supported)).
verdict(c_9b3ca243208d0b4e,refuted) :- node(n213,refuted).
query(verdict(c_9b3ca243208d0b4e,refuted)).
verdict(c_9b3ca243208d0b4e,unknown) :- node(n213,unknown).
query(verdict(c_9b3ca243208d0b4e,unknown)).
node(n220,supported) :- status(o_13ab9be9c0f2432e29f6,supported).
node(n220,refuted) :- status(o_13ab9be9c0f2432e29f6,refuted).
node(n220,unknown) :- status(o_13ab9be9c0f2432e29f6,unknown).
node(n221,supported) :- status(o_f42bd4828c2d0a999d7b,supported).
node(n221,refuted) :- status(o_f42bd4828c2d0a999d7b,refuted).
node(n221,unknown) :- status(o_f42bd4828c2d0a999d7b,unknown).
node(n219,supported) :- node(n206,supported), node(n207,supported), node(n208,supported), node(n215,supported), node(n220,supported), node(n221,supported).
node(n219,refuted) :- node(n206,refuted).
node(n219,refuted) :- node(n207,refuted).
node(n219,refuted) :- node(n208,refuted).
node(n219,refuted) :- node(n215,refuted).
node(n219,refuted) :- node(n220,refuted).
node(n219,refuted) :- node(n221,refuted).
node(n219,unknown) :- \+ node(n219,supported), \+ node(n219,refuted).
node(n223,supported) :- status(o_0154d63a61a596ad498b,supported).
node(n223,refuted) :- status(o_0154d63a61a596ad498b,refuted).
node(n223,unknown) :- status(o_0154d63a61a596ad498b,unknown).
node(n224,supported) :- status(o_e57e9030325120071eb3,supported).
node(n224,refuted) :- status(o_e57e9030325120071eb3,refuted).
node(n224,unknown) :- status(o_e57e9030325120071eb3,unknown).
node(n222,supported) :- node(n210,supported), node(n211,supported), node(n212,supported), node(n217,supported), node(n223,supported), node(n224,supported).
node(n222,refuted) :- node(n210,refuted).
node(n222,refuted) :- node(n211,refuted).
node(n222,refuted) :- node(n212,refuted).
node(n222,refuted) :- node(n217,refuted).
node(n222,refuted) :- node(n223,refuted).
node(n222,refuted) :- node(n224,refuted).
node(n222,unknown) :- \+ node(n222,supported), \+ node(n222,refuted).
node(n218,refuted) :- node(n219,refuted), node(n222,refuted), node(n9,refuted).
node(n218,supported) :- node(n219,supported).
node(n218,supported) :- node(n222,supported).
node(n218,supported) :- node(n9,supported).
node(n218,unknown) :- \+ node(n218,supported), \+ node(n218,refuted).
verdict(c_db4deda445df675b,supported) :- node(n218,supported).
query(verdict(c_db4deda445df675b,supported)).
verdict(c_db4deda445df675b,refuted) :- node(n218,refuted).
query(verdict(c_db4deda445df675b,refuted)).
verdict(c_db4deda445df675b,unknown) :- node(n218,unknown).
query(verdict(c_db4deda445df675b,unknown)).
node(n227,supported) :- status(o_a3d78d0fc95a8628d225,supported).
node(n227,refuted) :- status(o_a3d78d0fc95a8628d225,refuted).
node(n227,unknown) :- status(o_a3d78d0fc95a8628d225,unknown).
node(n226,supported) :- node(n206,supported), node(n207,supported), node(n227,supported).
node(n226,refuted) :- node(n206,refuted).
node(n226,refuted) :- node(n207,refuted).
node(n226,refuted) :- node(n227,refuted).
node(n226,unknown) :- \+ node(n226,supported), \+ node(n226,refuted).
node(n229,supported) :- status(o_531a905a46459b40bc28,supported).
node(n229,refuted) :- status(o_531a905a46459b40bc28,refuted).
node(n229,unknown) :- status(o_531a905a46459b40bc28,unknown).
node(n228,supported) :- node(n210,supported), node(n211,supported), node(n229,supported).
node(n228,refuted) :- node(n210,refuted).
node(n228,refuted) :- node(n211,refuted).
node(n228,refuted) :- node(n229,refuted).
node(n228,unknown) :- \+ node(n228,supported), \+ node(n228,refuted).
node(n225,refuted) :- node(n226,refuted), node(n228,refuted), node(n9,refuted).
node(n225,supported) :- node(n226,supported).
node(n225,supported) :- node(n228,supported).
node(n225,supported) :- node(n9,supported).
node(n225,unknown) :- \+ node(n225,supported), \+ node(n225,refuted).
verdict(c_78bf9f4bf7f87978,supported) :- node(n225,supported).
query(verdict(c_78bf9f4bf7f87978,supported)).
verdict(c_78bf9f4bf7f87978,refuted) :- node(n225,refuted).
query(verdict(c_78bf9f4bf7f87978,refuted)).
verdict(c_78bf9f4bf7f87978,unknown) :- node(n225,unknown).
query(verdict(c_78bf9f4bf7f87978,unknown)).
node(n231,supported) :- node(n206,supported), node(n207,supported), node(n208,supported), node(n227,supported).
node(n231,refuted) :- node(n206,refuted).
node(n231,refuted) :- node(n207,refuted).
node(n231,refuted) :- node(n208,refuted).
node(n231,refuted) :- node(n227,refuted).
node(n231,unknown) :- \+ node(n231,supported), \+ node(n231,refuted).
node(n232,supported) :- node(n210,supported), node(n211,supported), node(n212,supported), node(n229,supported).
node(n232,refuted) :- node(n210,refuted).
node(n232,refuted) :- node(n211,refuted).
node(n232,refuted) :- node(n212,refuted).
node(n232,refuted) :- node(n229,refuted).
node(n232,unknown) :- \+ node(n232,supported), \+ node(n232,refuted).
node(n230,refuted) :- node(n231,refuted), node(n232,refuted), node(n9,refuted).
node(n230,supported) :- node(n231,supported).
node(n230,supported) :- node(n232,supported).
node(n230,supported) :- node(n9,supported).
node(n230,unknown) :- \+ node(n230,supported), \+ node(n230,refuted).
verdict(c_5ea62d58a62690fe,supported) :- node(n230,supported).
query(verdict(c_5ea62d58a62690fe,supported)).
verdict(c_5ea62d58a62690fe,refuted) :- node(n230,refuted).
query(verdict(c_5ea62d58a62690fe,refuted)).
verdict(c_5ea62d58a62690fe,unknown) :- node(n230,unknown).
query(verdict(c_5ea62d58a62690fe,unknown)).
node(n235,supported) :- status(o_3983783991258ab58391,supported).
node(n235,refuted) :- status(o_3983783991258ab58391,refuted).
node(n235,unknown) :- status(o_3983783991258ab58391,unknown).
node(n236,supported) :- status(o_811c448afd79a4e5ea46,supported).
node(n236,refuted) :- status(o_811c448afd79a4e5ea46,refuted).
node(n236,unknown) :- status(o_811c448afd79a4e5ea46,unknown).
node(n237,supported) :- status(o_75ebe6269a3b80b49288,supported).
node(n237,refuted) :- status(o_75ebe6269a3b80b49288,refuted).
node(n237,unknown) :- status(o_75ebe6269a3b80b49288,unknown).
node(n234,supported) :- node(n235,supported), node(n236,supported), node(n237,supported).
node(n234,refuted) :- node(n235,refuted).
node(n234,refuted) :- node(n236,refuted).
node(n234,refuted) :- node(n237,refuted).
node(n234,unknown) :- \+ node(n234,supported), \+ node(n234,refuted).
node(n239,supported) :- status(o_264b090fd927b1839032,supported).
node(n239,refuted) :- status(o_264b090fd927b1839032,refuted).
node(n239,unknown) :- status(o_264b090fd927b1839032,unknown).
node(n240,supported) :- status(o_1024e28b63adb107bf5c,supported).
node(n240,refuted) :- status(o_1024e28b63adb107bf5c,refuted).
node(n240,unknown) :- status(o_1024e28b63adb107bf5c,unknown).
node(n241,supported) :- status(o_35b52544c4bf9af370f1,supported).
node(n241,refuted) :- status(o_35b52544c4bf9af370f1,refuted).
node(n241,unknown) :- status(o_35b52544c4bf9af370f1,unknown).
node(n238,supported) :- node(n239,supported), node(n240,supported), node(n241,supported).
node(n238,refuted) :- node(n239,refuted).
node(n238,refuted) :- node(n240,refuted).
node(n238,refuted) :- node(n241,refuted).
node(n238,unknown) :- \+ node(n238,supported), \+ node(n238,refuted).
node(n233,refuted) :- node(n234,refuted), node(n238,refuted), node(n9,refuted).
node(n233,supported) :- node(n234,supported).
node(n233,supported) :- node(n238,supported).
node(n233,supported) :- node(n9,supported).
node(n233,unknown) :- \+ node(n233,supported), \+ node(n233,refuted).
verdict(c_25dca40d25db718d,supported) :- node(n233,supported).
query(verdict(c_25dca40d25db718d,supported)).
verdict(c_25dca40d25db718d,refuted) :- node(n233,refuted).
query(verdict(c_25dca40d25db718d,refuted)).
verdict(c_25dca40d25db718d,unknown) :- node(n233,unknown).
query(verdict(c_25dca40d25db718d,unknown)).
node(n244,supported) :- status(o_acf8d83f7f894f98b977,supported).
node(n244,refuted) :- status(o_acf8d83f7f894f98b977,refuted).
node(n244,unknown) :- status(o_acf8d83f7f894f98b977,unknown).
node(n243,supported) :- node(n235,supported), node(n236,supported), node(n237,supported), node(n244,supported).
node(n243,refuted) :- node(n235,refuted).
node(n243,refuted) :- node(n236,refuted).
node(n243,refuted) :- node(n237,refuted).
node(n243,refuted) :- node(n244,refuted).
node(n243,unknown) :- \+ node(n243,supported), \+ node(n243,refuted).
node(n246,supported) :- status(o_1afe71cdd473e131925a,supported).
node(n246,refuted) :- status(o_1afe71cdd473e131925a,refuted).
node(n246,unknown) :- status(o_1afe71cdd473e131925a,unknown).
node(n245,supported) :- node(n239,supported), node(n240,supported), node(n241,supported), node(n246,supported).
node(n245,refuted) :- node(n239,refuted).
node(n245,refuted) :- node(n240,refuted).
node(n245,refuted) :- node(n241,refuted).
node(n245,refuted) :- node(n246,refuted).
node(n245,unknown) :- \+ node(n245,supported), \+ node(n245,refuted).
node(n242,refuted) :- node(n243,refuted), node(n245,refuted), node(n9,refuted).
node(n242,supported) :- node(n243,supported).
node(n242,supported) :- node(n245,supported).
node(n242,supported) :- node(n9,supported).
node(n242,unknown) :- \+ node(n242,supported), \+ node(n242,refuted).
verdict(c_8835375b700b56c5,supported) :- node(n242,supported).
query(verdict(c_8835375b700b56c5,supported)).
verdict(c_8835375b700b56c5,refuted) :- node(n242,refuted).
query(verdict(c_8835375b700b56c5,refuted)).
verdict(c_8835375b700b56c5,unknown) :- node(n242,unknown).
query(verdict(c_8835375b700b56c5,unknown)).
node(n249,supported) :- status(o_559b4e01fff5fc1ae848,supported).
node(n249,refuted) :- status(o_559b4e01fff5fc1ae848,refuted).
node(n249,unknown) :- status(o_559b4e01fff5fc1ae848,unknown).
node(n250,supported) :- status(o_17b94f30857ce14b67b1,supported).
node(n250,refuted) :- status(o_17b94f30857ce14b67b1,refuted).
node(n250,unknown) :- status(o_17b94f30857ce14b67b1,unknown).
node(n248,supported) :- node(n235,supported), node(n236,supported), node(n237,supported), node(n244,supported), node(n249,supported), node(n250,supported).
node(n248,refuted) :- node(n235,refuted).
node(n248,refuted) :- node(n236,refuted).
node(n248,refuted) :- node(n237,refuted).
node(n248,refuted) :- node(n244,refuted).
node(n248,refuted) :- node(n249,refuted).
node(n248,refuted) :- node(n250,refuted).
node(n248,unknown) :- \+ node(n248,supported), \+ node(n248,refuted).
node(n252,supported) :- status(o_3df249eed57e0f5b175a,supported).
node(n252,refuted) :- status(o_3df249eed57e0f5b175a,refuted).
node(n252,unknown) :- status(o_3df249eed57e0f5b175a,unknown).
node(n253,supported) :- status(o_f3f74453809bddea0e41,supported).
node(n253,refuted) :- status(o_f3f74453809bddea0e41,refuted).
node(n253,unknown) :- status(o_f3f74453809bddea0e41,unknown).
node(n251,supported) :- node(n239,supported), node(n240,supported), node(n241,supported), node(n246,supported), node(n252,supported), node(n253,supported).
node(n251,refuted) :- node(n239,refuted).
node(n251,refuted) :- node(n240,refuted).
node(n251,refuted) :- node(n241,refuted).
node(n251,refuted) :- node(n246,refuted).
node(n251,refuted) :- node(n252,refuted).
node(n251,refuted) :- node(n253,refuted).
node(n251,unknown) :- \+ node(n251,supported), \+ node(n251,refuted).
node(n247,refuted) :- node(n248,refuted), node(n251,refuted), node(n9,refuted).
node(n247,supported) :- node(n248,supported).
node(n247,supported) :- node(n251,supported).
node(n247,supported) :- node(n9,supported).
node(n247,unknown) :- \+ node(n247,supported), \+ node(n247,refuted).
verdict(c_7f73fc9613cd9fbe,supported) :- node(n247,supported).
query(verdict(c_7f73fc9613cd9fbe,supported)).
verdict(c_7f73fc9613cd9fbe,refuted) :- node(n247,refuted).
query(verdict(c_7f73fc9613cd9fbe,refuted)).
verdict(c_7f73fc9613cd9fbe,unknown) :- node(n247,unknown).
query(verdict(c_7f73fc9613cd9fbe,unknown)).
node(n256,supported) :- status(o_f0633230dc1ec584666b,supported).
node(n256,refuted) :- status(o_f0633230dc1ec584666b,refuted).
node(n256,unknown) :- status(o_f0633230dc1ec584666b,unknown).
node(n255,supported) :- node(n235,supported), node(n236,supported), node(n256,supported).
node(n255,refuted) :- node(n235,refuted).
node(n255,refuted) :- node(n236,refuted).
node(n255,refuted) :- node(n256,refuted).
node(n255,unknown) :- \+ node(n255,supported), \+ node(n255,refuted).
node(n258,supported) :- status(o_34d68d86ef3511666221,supported).
node(n258,refuted) :- status(o_34d68d86ef3511666221,refuted).
node(n258,unknown) :- status(o_34d68d86ef3511666221,unknown).
node(n257,supported) :- node(n239,supported), node(n240,supported), node(n258,supported).
node(n257,refuted) :- node(n239,refuted).
node(n257,refuted) :- node(n240,refuted).
node(n257,refuted) :- node(n258,refuted).
node(n257,unknown) :- \+ node(n257,supported), \+ node(n257,refuted).
node(n254,refuted) :- node(n255,refuted), node(n257,refuted), node(n9,refuted).
node(n254,supported) :- node(n255,supported).
node(n254,supported) :- node(n257,supported).
node(n254,supported) :- node(n9,supported).
node(n254,unknown) :- \+ node(n254,supported), \+ node(n254,refuted).
verdict(c_dcf7e77dfe59e1f2,supported) :- node(n254,supported).
query(verdict(c_dcf7e77dfe59e1f2,supported)).
verdict(c_dcf7e77dfe59e1f2,refuted) :- node(n254,refuted).
query(verdict(c_dcf7e77dfe59e1f2,refuted)).
verdict(c_dcf7e77dfe59e1f2,unknown) :- node(n254,unknown).
query(verdict(c_dcf7e77dfe59e1f2,unknown)).
node(n260,supported) :- node(n235,supported), node(n236,supported), node(n237,supported), node(n256,supported).
node(n260,refuted) :- node(n235,refuted).
node(n260,refuted) :- node(n236,refuted).
node(n260,refuted) :- node(n237,refuted).
node(n260,refuted) :- node(n256,refuted).
node(n260,unknown) :- \+ node(n260,supported), \+ node(n260,refuted).
node(n261,supported) :- node(n239,supported), node(n240,supported), node(n241,supported), node(n258,supported).
node(n261,refuted) :- node(n239,refuted).
node(n261,refuted) :- node(n240,refuted).
node(n261,refuted) :- node(n241,refuted).
node(n261,refuted) :- node(n258,refuted).
node(n261,unknown) :- \+ node(n261,supported), \+ node(n261,refuted).
node(n259,refuted) :- node(n260,refuted), node(n261,refuted), node(n9,refuted).
node(n259,supported) :- node(n260,supported).
node(n259,supported) :- node(n261,supported).
node(n259,supported) :- node(n9,supported).
node(n259,unknown) :- \+ node(n259,supported), \+ node(n259,refuted).
verdict(c_b9e0b0241a84166a,supported) :- node(n259,supported).
query(verdict(c_b9e0b0241a84166a,supported)).
verdict(c_b9e0b0241a84166a,refuted) :- node(n259,refuted).
query(verdict(c_b9e0b0241a84166a,refuted)).
verdict(c_b9e0b0241a84166a,unknown) :- node(n259,unknown).
query(verdict(c_b9e0b0241a84166a,unknown)).
node(n264,supported) :- status(o_d97e883d577304530102,supported).
node(n264,refuted) :- status(o_d97e883d577304530102,refuted).
node(n264,unknown) :- status(o_d97e883d577304530102,unknown).
node(n265,supported) :- status(o_8f596277e9b09a6ce7fb,supported).
node(n265,refuted) :- status(o_8f596277e9b09a6ce7fb,refuted).
node(n265,unknown) :- status(o_8f596277e9b09a6ce7fb,unknown).
node(n266,supported) :- status(o_8f9876917b4446a5c43d,supported).
node(n266,refuted) :- status(o_8f9876917b4446a5c43d,refuted).
node(n266,unknown) :- status(o_8f9876917b4446a5c43d,unknown).
node(n263,supported) :- node(n264,supported), node(n265,supported), node(n266,supported).
node(n263,refuted) :- node(n264,refuted).
node(n263,refuted) :- node(n265,refuted).
node(n263,refuted) :- node(n266,refuted).
node(n263,unknown) :- \+ node(n263,supported), \+ node(n263,refuted).
node(n268,supported) :- status(o_8b855fef8bdcedff7307,supported).
node(n268,refuted) :- status(o_8b855fef8bdcedff7307,refuted).
node(n268,unknown) :- status(o_8b855fef8bdcedff7307,unknown).
node(n269,supported) :- status(o_2ff2e6bf13961fba2c64,supported).
node(n269,refuted) :- status(o_2ff2e6bf13961fba2c64,refuted).
node(n269,unknown) :- status(o_2ff2e6bf13961fba2c64,unknown).
node(n270,supported) :- status(o_b1e7458bd3ce2cbe8fd1,supported).
node(n270,refuted) :- status(o_b1e7458bd3ce2cbe8fd1,refuted).
node(n270,unknown) :- status(o_b1e7458bd3ce2cbe8fd1,unknown).
node(n267,supported) :- node(n268,supported), node(n269,supported), node(n270,supported).
node(n267,refuted) :- node(n268,refuted).
node(n267,refuted) :- node(n269,refuted).
node(n267,refuted) :- node(n270,refuted).
node(n267,unknown) :- \+ node(n267,supported), \+ node(n267,refuted).
node(n262,refuted) :- node(n263,refuted), node(n267,refuted), node(n9,refuted).
node(n262,supported) :- node(n263,supported).
node(n262,supported) :- node(n267,supported).
node(n262,supported) :- node(n9,supported).
node(n262,unknown) :- \+ node(n262,supported), \+ node(n262,refuted).
verdict(c_0e2cdff6c06c1183,supported) :- node(n262,supported).
query(verdict(c_0e2cdff6c06c1183,supported)).
verdict(c_0e2cdff6c06c1183,refuted) :- node(n262,refuted).
query(verdict(c_0e2cdff6c06c1183,refuted)).
verdict(c_0e2cdff6c06c1183,unknown) :- node(n262,unknown).
query(verdict(c_0e2cdff6c06c1183,unknown)).
node(n273,supported) :- status(o_450a028c5fa80cc11da4,supported).
node(n273,refuted) :- status(o_450a028c5fa80cc11da4,refuted).
node(n273,unknown) :- status(o_450a028c5fa80cc11da4,unknown).
node(n272,supported) :- node(n264,supported), node(n265,supported), node(n266,supported), node(n273,supported).
node(n272,refuted) :- node(n264,refuted).
node(n272,refuted) :- node(n265,refuted).
node(n272,refuted) :- node(n266,refuted).
node(n272,refuted) :- node(n273,refuted).
node(n272,unknown) :- \+ node(n272,supported), \+ node(n272,refuted).
node(n275,supported) :- status(o_1d3f91ba878f9049ba81,supported).
node(n275,refuted) :- status(o_1d3f91ba878f9049ba81,refuted).
node(n275,unknown) :- status(o_1d3f91ba878f9049ba81,unknown).
node(n274,supported) :- node(n268,supported), node(n269,supported), node(n270,supported), node(n275,supported).
node(n274,refuted) :- node(n268,refuted).
node(n274,refuted) :- node(n269,refuted).
node(n274,refuted) :- node(n270,refuted).
node(n274,refuted) :- node(n275,refuted).
node(n274,unknown) :- \+ node(n274,supported), \+ node(n274,refuted).
node(n271,refuted) :- node(n272,refuted), node(n274,refuted), node(n9,refuted).
node(n271,supported) :- node(n272,supported).
node(n271,supported) :- node(n274,supported).
node(n271,supported) :- node(n9,supported).
node(n271,unknown) :- \+ node(n271,supported), \+ node(n271,refuted).
verdict(c_383342c8d9f9222f,supported) :- node(n271,supported).
query(verdict(c_383342c8d9f9222f,supported)).
verdict(c_383342c8d9f9222f,refuted) :- node(n271,refuted).
query(verdict(c_383342c8d9f9222f,refuted)).
verdict(c_383342c8d9f9222f,unknown) :- node(n271,unknown).
query(verdict(c_383342c8d9f9222f,unknown)).
node(n278,supported) :- status(o_d31ade2afb018c75fe61,supported).
node(n278,refuted) :- status(o_d31ade2afb018c75fe61,refuted).
node(n278,unknown) :- status(o_d31ade2afb018c75fe61,unknown).
node(n279,supported) :- status(o_4cd71c0b183188133301,supported).
node(n279,refuted) :- status(o_4cd71c0b183188133301,refuted).
node(n279,unknown) :- status(o_4cd71c0b183188133301,unknown).
node(n277,supported) :- node(n264,supported), node(n265,supported), node(n266,supported), node(n273,supported), node(n278,supported), node(n279,supported).
node(n277,refuted) :- node(n264,refuted).
node(n277,refuted) :- node(n265,refuted).
node(n277,refuted) :- node(n266,refuted).
node(n277,refuted) :- node(n273,refuted).
node(n277,refuted) :- node(n278,refuted).
node(n277,refuted) :- node(n279,refuted).
node(n277,unknown) :- \+ node(n277,supported), \+ node(n277,refuted).
node(n281,supported) :- status(o_146755d1daa78560a9a0,supported).
node(n281,refuted) :- status(o_146755d1daa78560a9a0,refuted).
node(n281,unknown) :- status(o_146755d1daa78560a9a0,unknown).
node(n282,supported) :- status(o_5461327bf70d86853aa1,supported).
node(n282,refuted) :- status(o_5461327bf70d86853aa1,refuted).
node(n282,unknown) :- status(o_5461327bf70d86853aa1,unknown).
node(n280,supported) :- node(n268,supported), node(n269,supported), node(n270,supported), node(n275,supported), node(n281,supported), node(n282,supported).
node(n280,refuted) :- node(n268,refuted).
node(n280,refuted) :- node(n269,refuted).
node(n280,refuted) :- node(n270,refuted).
node(n280,refuted) :- node(n275,refuted).
node(n280,refuted) :- node(n281,refuted).
node(n280,refuted) :- node(n282,refuted).
node(n280,unknown) :- \+ node(n280,supported), \+ node(n280,refuted).
node(n276,refuted) :- node(n277,refuted), node(n280,refuted), node(n9,refuted).
node(n276,supported) :- node(n277,supported).
node(n276,supported) :- node(n280,supported).
node(n276,supported) :- node(n9,supported).
node(n276,unknown) :- \+ node(n276,supported), \+ node(n276,refuted).
verdict(c_ef4817e472f62cb7,supported) :- node(n276,supported).
query(verdict(c_ef4817e472f62cb7,supported)).
verdict(c_ef4817e472f62cb7,refuted) :- node(n276,refuted).
query(verdict(c_ef4817e472f62cb7,refuted)).
verdict(c_ef4817e472f62cb7,unknown) :- node(n276,unknown).
query(verdict(c_ef4817e472f62cb7,unknown)).
node(n285,supported) :- status(o_0e5d30e195dbed5df4aa,supported).
node(n285,refuted) :- status(o_0e5d30e195dbed5df4aa,refuted).
node(n285,unknown) :- status(o_0e5d30e195dbed5df4aa,unknown).
node(n284,supported) :- node(n264,supported), node(n265,supported), node(n285,supported).
node(n284,refuted) :- node(n264,refuted).
node(n284,refuted) :- node(n265,refuted).
node(n284,refuted) :- node(n285,refuted).
node(n284,unknown) :- \+ node(n284,supported), \+ node(n284,refuted).
node(n287,supported) :- status(o_8f688dc283616ac8fade,supported).
node(n287,refuted) :- status(o_8f688dc283616ac8fade,refuted).
node(n287,unknown) :- status(o_8f688dc283616ac8fade,unknown).
node(n286,supported) :- node(n268,supported), node(n269,supported), node(n287,supported).
node(n286,refuted) :- node(n268,refuted).
node(n286,refuted) :- node(n269,refuted).
node(n286,refuted) :- node(n287,refuted).
node(n286,unknown) :- \+ node(n286,supported), \+ node(n286,refuted).
node(n283,refuted) :- node(n284,refuted), node(n286,refuted), node(n9,refuted).
node(n283,supported) :- node(n284,supported).
node(n283,supported) :- node(n286,supported).
node(n283,supported) :- node(n9,supported).
node(n283,unknown) :- \+ node(n283,supported), \+ node(n283,refuted).
verdict(c_4f8b58ec58a0ba3d,supported) :- node(n283,supported).
query(verdict(c_4f8b58ec58a0ba3d,supported)).
verdict(c_4f8b58ec58a0ba3d,refuted) :- node(n283,refuted).
query(verdict(c_4f8b58ec58a0ba3d,refuted)).
verdict(c_4f8b58ec58a0ba3d,unknown) :- node(n283,unknown).
query(verdict(c_4f8b58ec58a0ba3d,unknown)).
node(n289,supported) :- node(n264,supported), node(n265,supported), node(n266,supported), node(n285,supported).
node(n289,refuted) :- node(n264,refuted).
node(n289,refuted) :- node(n265,refuted).
node(n289,refuted) :- node(n266,refuted).
node(n289,refuted) :- node(n285,refuted).
node(n289,unknown) :- \+ node(n289,supported), \+ node(n289,refuted).
node(n290,supported) :- node(n268,supported), node(n269,supported), node(n270,supported), node(n287,supported).
node(n290,refuted) :- node(n268,refuted).
node(n290,refuted) :- node(n269,refuted).
node(n290,refuted) :- node(n270,refuted).
node(n290,refuted) :- node(n287,refuted).
node(n290,unknown) :- \+ node(n290,supported), \+ node(n290,refuted).
node(n288,refuted) :- node(n289,refuted), node(n290,refuted), node(n9,refuted).
node(n288,supported) :- node(n289,supported).
node(n288,supported) :- node(n290,supported).
node(n288,supported) :- node(n9,supported).
node(n288,unknown) :- \+ node(n288,supported), \+ node(n288,refuted).
verdict(c_8779c86f808aeb84,supported) :- node(n288,supported).
query(verdict(c_8779c86f808aeb84,supported)).
verdict(c_8779c86f808aeb84,refuted) :- node(n288,refuted).
query(verdict(c_8779c86f808aeb84,refuted)).
verdict(c_8779c86f808aeb84,unknown) :- node(n288,unknown).
query(verdict(c_8779c86f808aeb84,unknown)).
node(n293,supported) :- status(o_ada382440bc5c753506a,supported).
node(n293,refuted) :- status(o_ada382440bc5c753506a,refuted).
node(n293,unknown) :- status(o_ada382440bc5c753506a,unknown).
node(n294,supported) :- status(o_ac1bcb2fb29a858d4d2e,supported).
node(n294,refuted) :- status(o_ac1bcb2fb29a858d4d2e,refuted).
node(n294,unknown) :- status(o_ac1bcb2fb29a858d4d2e,unknown).
node(n295,supported) :- status(o_e645b3c63ae35ebbaa07,supported).
node(n295,refuted) :- status(o_e645b3c63ae35ebbaa07,refuted).
node(n295,unknown) :- status(o_e645b3c63ae35ebbaa07,unknown).
node(n292,supported) :- node(n293,supported), node(n294,supported), node(n295,supported).
node(n292,refuted) :- node(n293,refuted).
node(n292,refuted) :- node(n294,refuted).
node(n292,refuted) :- node(n295,refuted).
node(n292,unknown) :- \+ node(n292,supported), \+ node(n292,refuted).
node(n297,supported) :- status(o_e535860b8222682781a5,supported).
node(n297,refuted) :- status(o_e535860b8222682781a5,refuted).
node(n297,unknown) :- status(o_e535860b8222682781a5,unknown).
node(n298,supported) :- status(o_6e8e27c18c8e5528d30d,supported).
node(n298,refuted) :- status(o_6e8e27c18c8e5528d30d,refuted).
node(n298,unknown) :- status(o_6e8e27c18c8e5528d30d,unknown).
node(n299,supported) :- status(o_fd35a71424497f5dde03,supported).
node(n299,refuted) :- status(o_fd35a71424497f5dde03,refuted).
node(n299,unknown) :- status(o_fd35a71424497f5dde03,unknown).
node(n296,supported) :- node(n297,supported), node(n298,supported), node(n299,supported).
node(n296,refuted) :- node(n297,refuted).
node(n296,refuted) :- node(n298,refuted).
node(n296,refuted) :- node(n299,refuted).
node(n296,unknown) :- \+ node(n296,supported), \+ node(n296,refuted).
node(n291,refuted) :- node(n292,refuted), node(n296,refuted), node(n9,refuted).
node(n291,supported) :- node(n292,supported).
node(n291,supported) :- node(n296,supported).
node(n291,supported) :- node(n9,supported).
node(n291,unknown) :- \+ node(n291,supported), \+ node(n291,refuted).
verdict(c_8bfe6bd59e198678,supported) :- node(n291,supported).
query(verdict(c_8bfe6bd59e198678,supported)).
verdict(c_8bfe6bd59e198678,refuted) :- node(n291,refuted).
query(verdict(c_8bfe6bd59e198678,refuted)).
verdict(c_8bfe6bd59e198678,unknown) :- node(n291,unknown).
query(verdict(c_8bfe6bd59e198678,unknown)).
node(n302,supported) :- status(o_64e2557e58334b56b7f0,supported).
node(n302,refuted) :- status(o_64e2557e58334b56b7f0,refuted).
node(n302,unknown) :- status(o_64e2557e58334b56b7f0,unknown).
node(n301,supported) :- node(n293,supported), node(n294,supported), node(n295,supported), node(n302,supported).
node(n301,refuted) :- node(n293,refuted).
node(n301,refuted) :- node(n294,refuted).
node(n301,refuted) :- node(n295,refuted).
node(n301,refuted) :- node(n302,refuted).
node(n301,unknown) :- \+ node(n301,supported), \+ node(n301,refuted).
node(n304,supported) :- status(o_468147b8b61a40ed50e6,supported).
node(n304,refuted) :- status(o_468147b8b61a40ed50e6,refuted).
node(n304,unknown) :- status(o_468147b8b61a40ed50e6,unknown).
node(n303,supported) :- node(n297,supported), node(n298,supported), node(n299,supported), node(n304,supported).
node(n303,refuted) :- node(n297,refuted).
node(n303,refuted) :- node(n298,refuted).
node(n303,refuted) :- node(n299,refuted).
node(n303,refuted) :- node(n304,refuted).
node(n303,unknown) :- \+ node(n303,supported), \+ node(n303,refuted).
node(n300,refuted) :- node(n301,refuted), node(n303,refuted), node(n9,refuted).
node(n300,supported) :- node(n301,supported).
node(n300,supported) :- node(n303,supported).
node(n300,supported) :- node(n9,supported).
node(n300,unknown) :- \+ node(n300,supported), \+ node(n300,refuted).
verdict(c_6af38cb542fa9ba8,supported) :- node(n300,supported).
query(verdict(c_6af38cb542fa9ba8,supported)).
verdict(c_6af38cb542fa9ba8,refuted) :- node(n300,refuted).
query(verdict(c_6af38cb542fa9ba8,refuted)).
verdict(c_6af38cb542fa9ba8,unknown) :- node(n300,unknown).
query(verdict(c_6af38cb542fa9ba8,unknown)).
node(n307,supported) :- status(o_185dd364f006ede046c1,supported).
node(n307,refuted) :- status(o_185dd364f006ede046c1,refuted).
node(n307,unknown) :- status(o_185dd364f006ede046c1,unknown).
node(n308,supported) :- status(o_0eb6cb694a5b8e7351ca,supported).
node(n308,refuted) :- status(o_0eb6cb694a5b8e7351ca,refuted).
node(n308,unknown) :- status(o_0eb6cb694a5b8e7351ca,unknown).
node(n306,supported) :- node(n293,supported), node(n294,supported), node(n295,supported), node(n302,supported), node(n307,supported), node(n308,supported).
node(n306,refuted) :- node(n293,refuted).
node(n306,refuted) :- node(n294,refuted).
node(n306,refuted) :- node(n295,refuted).
node(n306,refuted) :- node(n302,refuted).
node(n306,refuted) :- node(n307,refuted).
node(n306,refuted) :- node(n308,refuted).
node(n306,unknown) :- \+ node(n306,supported), \+ node(n306,refuted).
node(n310,supported) :- status(o_574a9f7f5028cc8c211c,supported).
node(n310,refuted) :- status(o_574a9f7f5028cc8c211c,refuted).
node(n310,unknown) :- status(o_574a9f7f5028cc8c211c,unknown).
node(n311,supported) :- status(o_7c0e5bcf811896c933e0,supported).
node(n311,refuted) :- status(o_7c0e5bcf811896c933e0,refuted).
node(n311,unknown) :- status(o_7c0e5bcf811896c933e0,unknown).
node(n309,supported) :- node(n297,supported), node(n298,supported), node(n299,supported), node(n304,supported), node(n310,supported), node(n311,supported).
node(n309,refuted) :- node(n297,refuted).
node(n309,refuted) :- node(n298,refuted).
node(n309,refuted) :- node(n299,refuted).
node(n309,refuted) :- node(n304,refuted).
node(n309,refuted) :- node(n310,refuted).
node(n309,refuted) :- node(n311,refuted).
node(n309,unknown) :- \+ node(n309,supported), \+ node(n309,refuted).
node(n305,refuted) :- node(n306,refuted), node(n309,refuted), node(n9,refuted).
node(n305,supported) :- node(n306,supported).
node(n305,supported) :- node(n309,supported).
node(n305,supported) :- node(n9,supported).
node(n305,unknown) :- \+ node(n305,supported), \+ node(n305,refuted).
verdict(c_2945b878263ba2c8,supported) :- node(n305,supported).
query(verdict(c_2945b878263ba2c8,supported)).
verdict(c_2945b878263ba2c8,refuted) :- node(n305,refuted).
query(verdict(c_2945b878263ba2c8,refuted)).
verdict(c_2945b878263ba2c8,unknown) :- node(n305,unknown).
query(verdict(c_2945b878263ba2c8,unknown)).
node(n314,supported) :- status(o_725009d3dcd926dee28f,supported).
node(n314,refuted) :- status(o_725009d3dcd926dee28f,refuted).
node(n314,unknown) :- status(o_725009d3dcd926dee28f,unknown).
node(n313,supported) :- node(n293,supported), node(n294,supported), node(n314,supported).
node(n313,refuted) :- node(n293,refuted).
node(n313,refuted) :- node(n294,refuted).
node(n313,refuted) :- node(n314,refuted).
node(n313,unknown) :- \+ node(n313,supported), \+ node(n313,refuted).
node(n316,supported) :- status(o_1b7a3a94d38cdb516d90,supported).
node(n316,refuted) :- status(o_1b7a3a94d38cdb516d90,refuted).
node(n316,unknown) :- status(o_1b7a3a94d38cdb516d90,unknown).
node(n315,supported) :- node(n297,supported), node(n298,supported), node(n316,supported).
node(n315,refuted) :- node(n297,refuted).
node(n315,refuted) :- node(n298,refuted).
node(n315,refuted) :- node(n316,refuted).
node(n315,unknown) :- \+ node(n315,supported), \+ node(n315,refuted).
node(n312,refuted) :- node(n313,refuted), node(n315,refuted), node(n9,refuted).
node(n312,supported) :- node(n313,supported).
node(n312,supported) :- node(n315,supported).
node(n312,supported) :- node(n9,supported).
node(n312,unknown) :- \+ node(n312,supported), \+ node(n312,refuted).
verdict(c_a94f7b70a4da6bf4,supported) :- node(n312,supported).
query(verdict(c_a94f7b70a4da6bf4,supported)).
verdict(c_a94f7b70a4da6bf4,refuted) :- node(n312,refuted).
query(verdict(c_a94f7b70a4da6bf4,refuted)).
verdict(c_a94f7b70a4da6bf4,unknown) :- node(n312,unknown).
query(verdict(c_a94f7b70a4da6bf4,unknown)).
node(n318,supported) :- node(n293,supported), node(n294,supported), node(n295,supported), node(n314,supported).
node(n318,refuted) :- node(n293,refuted).
node(n318,refuted) :- node(n294,refuted).
node(n318,refuted) :- node(n295,refuted).
node(n318,refuted) :- node(n314,refuted).
node(n318,unknown) :- \+ node(n318,supported), \+ node(n318,refuted).
node(n319,supported) :- node(n297,supported), node(n298,supported), node(n299,supported), node(n316,supported).
node(n319,refuted) :- node(n297,refuted).
node(n319,refuted) :- node(n298,refuted).
node(n319,refuted) :- node(n299,refuted).
node(n319,refuted) :- node(n316,refuted).
node(n319,unknown) :- \+ node(n319,supported), \+ node(n319,refuted).
node(n317,refuted) :- node(n318,refuted), node(n319,refuted), node(n9,refuted).
node(n317,supported) :- node(n318,supported).
node(n317,supported) :- node(n319,supported).
node(n317,supported) :- node(n9,supported).
node(n317,unknown) :- \+ node(n317,supported), \+ node(n317,refuted).
verdict(c_544d7ec8acbc76e8,supported) :- node(n317,supported).
query(verdict(c_544d7ec8acbc76e8,supported)).
verdict(c_544d7ec8acbc76e8,refuted) :- node(n317,refuted).
query(verdict(c_544d7ec8acbc76e8,refuted)).
verdict(c_544d7ec8acbc76e8,unknown) :- node(n317,unknown).
query(verdict(c_544d7ec8acbc76e8,unknown)).
node(n322,supported) :- status(o_c3f26b04d3451f147006,supported).
node(n322,refuted) :- status(o_c3f26b04d3451f147006,refuted).
node(n322,unknown) :- status(o_c3f26b04d3451f147006,unknown).
node(n323,supported) :- status(o_c8a71231ece89c54cf5b,supported).
node(n323,refuted) :- status(o_c8a71231ece89c54cf5b,refuted).
node(n323,unknown) :- status(o_c8a71231ece89c54cf5b,unknown).
node(n324,supported) :- status(o_0dcb1f5cf72fea5b0aac,supported).
node(n324,refuted) :- status(o_0dcb1f5cf72fea5b0aac,refuted).
node(n324,unknown) :- status(o_0dcb1f5cf72fea5b0aac,unknown).
node(n321,supported) :- node(n322,supported), node(n323,supported), node(n324,supported).
node(n321,refuted) :- node(n322,refuted).
node(n321,refuted) :- node(n323,refuted).
node(n321,refuted) :- node(n324,refuted).
node(n321,unknown) :- \+ node(n321,supported), \+ node(n321,refuted).
node(n326,supported) :- status(o_56182db54b551cf25838,supported).
node(n326,refuted) :- status(o_56182db54b551cf25838,refuted).
node(n326,unknown) :- status(o_56182db54b551cf25838,unknown).
node(n327,supported) :- status(o_919833f76cbd98fd14d0,supported).
node(n327,refuted) :- status(o_919833f76cbd98fd14d0,refuted).
node(n327,unknown) :- status(o_919833f76cbd98fd14d0,unknown).
node(n328,supported) :- status(o_1a2363a115389a615c3c,supported).
node(n328,refuted) :- status(o_1a2363a115389a615c3c,refuted).
node(n328,unknown) :- status(o_1a2363a115389a615c3c,unknown).
node(n325,supported) :- node(n326,supported), node(n327,supported), node(n328,supported).
node(n325,refuted) :- node(n326,refuted).
node(n325,refuted) :- node(n327,refuted).
node(n325,refuted) :- node(n328,refuted).
node(n325,unknown) :- \+ node(n325,supported), \+ node(n325,refuted).
node(n320,refuted) :- node(n321,refuted), node(n325,refuted), node(n9,refuted).
node(n320,supported) :- node(n321,supported).
node(n320,supported) :- node(n325,supported).
node(n320,supported) :- node(n9,supported).
node(n320,unknown) :- \+ node(n320,supported), \+ node(n320,refuted).
verdict(c_672d3e3f6ec168af,supported) :- node(n320,supported).
query(verdict(c_672d3e3f6ec168af,supported)).
verdict(c_672d3e3f6ec168af,refuted) :- node(n320,refuted).
query(verdict(c_672d3e3f6ec168af,refuted)).
verdict(c_672d3e3f6ec168af,unknown) :- node(n320,unknown).
query(verdict(c_672d3e3f6ec168af,unknown)).
node(n331,supported) :- status(o_7f3593dcfb218c27696d,supported).
node(n331,refuted) :- status(o_7f3593dcfb218c27696d,refuted).
node(n331,unknown) :- status(o_7f3593dcfb218c27696d,unknown).
node(n330,supported) :- node(n322,supported), node(n323,supported), node(n324,supported), node(n331,supported).
node(n330,refuted) :- node(n322,refuted).
node(n330,refuted) :- node(n323,refuted).
node(n330,refuted) :- node(n324,refuted).
node(n330,refuted) :- node(n331,refuted).
node(n330,unknown) :- \+ node(n330,supported), \+ node(n330,refuted).
node(n333,supported) :- status(o_cc7b6e17b8da4f7d1b7b,supported).
node(n333,refuted) :- status(o_cc7b6e17b8da4f7d1b7b,refuted).
node(n333,unknown) :- status(o_cc7b6e17b8da4f7d1b7b,unknown).
node(n332,supported) :- node(n326,supported), node(n327,supported), node(n328,supported), node(n333,supported).
node(n332,refuted) :- node(n326,refuted).
node(n332,refuted) :- node(n327,refuted).
node(n332,refuted) :- node(n328,refuted).
node(n332,refuted) :- node(n333,refuted).
node(n332,unknown) :- \+ node(n332,supported), \+ node(n332,refuted).
node(n329,refuted) :- node(n330,refuted), node(n332,refuted), node(n9,refuted).
node(n329,supported) :- node(n330,supported).
node(n329,supported) :- node(n332,supported).
node(n329,supported) :- node(n9,supported).
node(n329,unknown) :- \+ node(n329,supported), \+ node(n329,refuted).
verdict(c_2dc3e7991c4da792,supported) :- node(n329,supported).
query(verdict(c_2dc3e7991c4da792,supported)).
verdict(c_2dc3e7991c4da792,refuted) :- node(n329,refuted).
query(verdict(c_2dc3e7991c4da792,refuted)).
verdict(c_2dc3e7991c4da792,unknown) :- node(n329,unknown).
query(verdict(c_2dc3e7991c4da792,unknown)).
node(n336,supported) :- status(o_075e9b3f267a8e6fa34b,supported).
node(n336,refuted) :- status(o_075e9b3f267a8e6fa34b,refuted).
node(n336,unknown) :- status(o_075e9b3f267a8e6fa34b,unknown).
node(n337,supported) :- status(o_f20c8f8735fc1ecd44ed,supported).
node(n337,refuted) :- status(o_f20c8f8735fc1ecd44ed,refuted).
node(n337,unknown) :- status(o_f20c8f8735fc1ecd44ed,unknown).
node(n335,supported) :- node(n322,supported), node(n323,supported), node(n324,supported), node(n331,supported), node(n336,supported), node(n337,supported).
node(n335,refuted) :- node(n322,refuted).
node(n335,refuted) :- node(n323,refuted).
node(n335,refuted) :- node(n324,refuted).
node(n335,refuted) :- node(n331,refuted).
node(n335,refuted) :- node(n336,refuted).
node(n335,refuted) :- node(n337,refuted).
node(n335,unknown) :- \+ node(n335,supported), \+ node(n335,refuted).
node(n339,supported) :- status(o_326dd4f570d38427114f,supported).
node(n339,refuted) :- status(o_326dd4f570d38427114f,refuted).
node(n339,unknown) :- status(o_326dd4f570d38427114f,unknown).
node(n340,supported) :- status(o_4527326328e39f266016,supported).
node(n340,refuted) :- status(o_4527326328e39f266016,refuted).
node(n340,unknown) :- status(o_4527326328e39f266016,unknown).
node(n338,supported) :- node(n326,supported), node(n327,supported), node(n328,supported), node(n333,supported), node(n339,supported), node(n340,supported).
node(n338,refuted) :- node(n326,refuted).
node(n338,refuted) :- node(n327,refuted).
node(n338,refuted) :- node(n328,refuted).
node(n338,refuted) :- node(n333,refuted).
node(n338,refuted) :- node(n339,refuted).
node(n338,refuted) :- node(n340,refuted).
node(n338,unknown) :- \+ node(n338,supported), \+ node(n338,refuted).
node(n334,refuted) :- node(n335,refuted), node(n338,refuted), node(n9,refuted).
node(n334,supported) :- node(n335,supported).
node(n334,supported) :- node(n338,supported).
node(n334,supported) :- node(n9,supported).
node(n334,unknown) :- \+ node(n334,supported), \+ node(n334,refuted).
verdict(c_e4d3a90f8d0011da,supported) :- node(n334,supported).
query(verdict(c_e4d3a90f8d0011da,supported)).
verdict(c_e4d3a90f8d0011da,refuted) :- node(n334,refuted).
query(verdict(c_e4d3a90f8d0011da,refuted)).
verdict(c_e4d3a90f8d0011da,unknown) :- node(n334,unknown).
query(verdict(c_e4d3a90f8d0011da,unknown)).
node(n343,supported) :- status(o_3ec308e56f1ec36fbd08,supported).
node(n343,refuted) :- status(o_3ec308e56f1ec36fbd08,refuted).
node(n343,unknown) :- status(o_3ec308e56f1ec36fbd08,unknown).
node(n342,supported) :- node(n322,supported), node(n323,supported), node(n343,supported).
node(n342,refuted) :- node(n322,refuted).
node(n342,refuted) :- node(n323,refuted).
node(n342,refuted) :- node(n343,refuted).
node(n342,unknown) :- \+ node(n342,supported), \+ node(n342,refuted).
node(n345,supported) :- status(o_a16f342b3a8eff6df36a,supported).
node(n345,refuted) :- status(o_a16f342b3a8eff6df36a,refuted).
node(n345,unknown) :- status(o_a16f342b3a8eff6df36a,unknown).
node(n344,supported) :- node(n326,supported), node(n327,supported), node(n345,supported).
node(n344,refuted) :- node(n326,refuted).
node(n344,refuted) :- node(n327,refuted).
node(n344,refuted) :- node(n345,refuted).
node(n344,unknown) :- \+ node(n344,supported), \+ node(n344,refuted).
node(n341,refuted) :- node(n342,refuted), node(n344,refuted), node(n9,refuted).
node(n341,supported) :- node(n342,supported).
node(n341,supported) :- node(n344,supported).
node(n341,supported) :- node(n9,supported).
node(n341,unknown) :- \+ node(n341,supported), \+ node(n341,refuted).
verdict(c_6186d2b0e2feb0fe,supported) :- node(n341,supported).
query(verdict(c_6186d2b0e2feb0fe,supported)).
verdict(c_6186d2b0e2feb0fe,refuted) :- node(n341,refuted).
query(verdict(c_6186d2b0e2feb0fe,refuted)).
verdict(c_6186d2b0e2feb0fe,unknown) :- node(n341,unknown).
query(verdict(c_6186d2b0e2feb0fe,unknown)).
node(n347,supported) :- node(n322,supported), node(n323,supported), node(n324,supported), node(n343,supported).
node(n347,refuted) :- node(n322,refuted).
node(n347,refuted) :- node(n323,refuted).
node(n347,refuted) :- node(n324,refuted).
node(n347,refuted) :- node(n343,refuted).
node(n347,unknown) :- \+ node(n347,supported), \+ node(n347,refuted).
node(n348,supported) :- node(n326,supported), node(n327,supported), node(n328,supported), node(n345,supported).
node(n348,refuted) :- node(n326,refuted).
node(n348,refuted) :- node(n327,refuted).
node(n348,refuted) :- node(n328,refuted).
node(n348,refuted) :- node(n345,refuted).
node(n348,unknown) :- \+ node(n348,supported), \+ node(n348,refuted).
node(n346,refuted) :- node(n347,refuted), node(n348,refuted), node(n9,refuted).
node(n346,supported) :- node(n347,supported).
node(n346,supported) :- node(n348,supported).
node(n346,supported) :- node(n9,supported).
node(n346,unknown) :- \+ node(n346,supported), \+ node(n346,refuted).
verdict(c_66f8459b3d608d84,supported) :- node(n346,supported).
query(verdict(c_66f8459b3d608d84,supported)).
verdict(c_66f8459b3d608d84,refuted) :- node(n346,refuted).
query(verdict(c_66f8459b3d608d84,refuted)).
verdict(c_66f8459b3d608d84,unknown) :- node(n346,unknown).
query(verdict(c_66f8459b3d608d84,unknown)).
node(n351,supported) :- status(o_ad8632f4fd2a33f45a3e,supported).
node(n351,refuted) :- status(o_ad8632f4fd2a33f45a3e,refuted).
node(n351,unknown) :- status(o_ad8632f4fd2a33f45a3e,unknown).
node(n352,supported) :- status(o_6d14ff10a5de5d3e988f,supported).
node(n352,refuted) :- status(o_6d14ff10a5de5d3e988f,refuted).
node(n352,unknown) :- status(o_6d14ff10a5de5d3e988f,unknown).
node(n353,supported) :- status(o_9ad67c6c86a3fef10281,supported).
node(n353,refuted) :- status(o_9ad67c6c86a3fef10281,refuted).
node(n353,unknown) :- status(o_9ad67c6c86a3fef10281,unknown).
node(n350,supported) :- node(n351,supported), node(n352,supported), node(n353,supported).
node(n350,refuted) :- node(n351,refuted).
node(n350,refuted) :- node(n352,refuted).
node(n350,refuted) :- node(n353,refuted).
node(n350,unknown) :- \+ node(n350,supported), \+ node(n350,refuted).
node(n355,supported) :- status(o_bd12b7177218af934894,supported).
node(n355,refuted) :- status(o_bd12b7177218af934894,refuted).
node(n355,unknown) :- status(o_bd12b7177218af934894,unknown).
node(n356,supported) :- status(o_6e7107127db37ed22106,supported).
node(n356,refuted) :- status(o_6e7107127db37ed22106,refuted).
node(n356,unknown) :- status(o_6e7107127db37ed22106,unknown).
node(n357,supported) :- status(o_98ec298b70503d0d2552,supported).
node(n357,refuted) :- status(o_98ec298b70503d0d2552,refuted).
node(n357,unknown) :- status(o_98ec298b70503d0d2552,unknown).
node(n354,supported) :- node(n355,supported), node(n356,supported), node(n357,supported).
node(n354,refuted) :- node(n355,refuted).
node(n354,refuted) :- node(n356,refuted).
node(n354,refuted) :- node(n357,refuted).
node(n354,unknown) :- \+ node(n354,supported), \+ node(n354,refuted).
node(n349,refuted) :- node(n350,refuted), node(n354,refuted), node(n9,refuted).
node(n349,supported) :- node(n350,supported).
node(n349,supported) :- node(n354,supported).
node(n349,supported) :- node(n9,supported).
node(n349,unknown) :- \+ node(n349,supported), \+ node(n349,refuted).
verdict(c_dabb087d8e36e0ed,supported) :- node(n349,supported).
query(verdict(c_dabb087d8e36e0ed,supported)).
verdict(c_dabb087d8e36e0ed,refuted) :- node(n349,refuted).
query(verdict(c_dabb087d8e36e0ed,refuted)).
verdict(c_dabb087d8e36e0ed,unknown) :- node(n349,unknown).
query(verdict(c_dabb087d8e36e0ed,unknown)).
node(n360,supported) :- status(o_57fc30281e3e092e5bff,supported).
node(n360,refuted) :- status(o_57fc30281e3e092e5bff,refuted).
node(n360,unknown) :- status(o_57fc30281e3e092e5bff,unknown).
node(n359,supported) :- node(n351,supported), node(n352,supported), node(n353,supported), node(n360,supported).
node(n359,refuted) :- node(n351,refuted).
node(n359,refuted) :- node(n352,refuted).
node(n359,refuted) :- node(n353,refuted).
node(n359,refuted) :- node(n360,refuted).
node(n359,unknown) :- \+ node(n359,supported), \+ node(n359,refuted).
node(n362,supported) :- status(o_ec83ad486bb9f3c429b4,supported).
node(n362,refuted) :- status(o_ec83ad486bb9f3c429b4,refuted).
node(n362,unknown) :- status(o_ec83ad486bb9f3c429b4,unknown).
node(n361,supported) :- node(n355,supported), node(n356,supported), node(n357,supported), node(n362,supported).
node(n361,refuted) :- node(n355,refuted).
node(n361,refuted) :- node(n356,refuted).
node(n361,refuted) :- node(n357,refuted).
node(n361,refuted) :- node(n362,refuted).
node(n361,unknown) :- \+ node(n361,supported), \+ node(n361,refuted).
node(n358,refuted) :- node(n359,refuted), node(n361,refuted), node(n9,refuted).
node(n358,supported) :- node(n359,supported).
node(n358,supported) :- node(n361,supported).
node(n358,supported) :- node(n9,supported).
node(n358,unknown) :- \+ node(n358,supported), \+ node(n358,refuted).
verdict(c_a362a3e609858985,supported) :- node(n358,supported).
query(verdict(c_a362a3e609858985,supported)).
verdict(c_a362a3e609858985,refuted) :- node(n358,refuted).
query(verdict(c_a362a3e609858985,refuted)).
verdict(c_a362a3e609858985,unknown) :- node(n358,unknown).
query(verdict(c_a362a3e609858985,unknown)).
node(n365,supported) :- status(o_2cb73e287f98e50f148d,supported).
node(n365,refuted) :- status(o_2cb73e287f98e50f148d,refuted).
node(n365,unknown) :- status(o_2cb73e287f98e50f148d,unknown).
node(n366,supported) :- status(o_9a6e0e407434517a572e,supported).
node(n366,refuted) :- status(o_9a6e0e407434517a572e,refuted).
node(n366,unknown) :- status(o_9a6e0e407434517a572e,unknown).
node(n364,supported) :- node(n351,supported), node(n352,supported), node(n353,supported), node(n360,supported), node(n365,supported), node(n366,supported).
node(n364,refuted) :- node(n351,refuted).
node(n364,refuted) :- node(n352,refuted).
node(n364,refuted) :- node(n353,refuted).
node(n364,refuted) :- node(n360,refuted).
node(n364,refuted) :- node(n365,refuted).
node(n364,refuted) :- node(n366,refuted).
node(n364,unknown) :- \+ node(n364,supported), \+ node(n364,refuted).
node(n368,supported) :- status(o_118120580b7b6efe5d5b,supported).
node(n368,refuted) :- status(o_118120580b7b6efe5d5b,refuted).
node(n368,unknown) :- status(o_118120580b7b6efe5d5b,unknown).
node(n369,supported) :- status(o_bd382028ee5f1bc36359,supported).
node(n369,refuted) :- status(o_bd382028ee5f1bc36359,refuted).
node(n369,unknown) :- status(o_bd382028ee5f1bc36359,unknown).
node(n367,supported) :- node(n355,supported), node(n356,supported), node(n357,supported), node(n362,supported), node(n368,supported), node(n369,supported).
node(n367,refuted) :- node(n355,refuted).
node(n367,refuted) :- node(n356,refuted).
node(n367,refuted) :- node(n357,refuted).
node(n367,refuted) :- node(n362,refuted).
node(n367,refuted) :- node(n368,refuted).
node(n367,refuted) :- node(n369,refuted).
node(n367,unknown) :- \+ node(n367,supported), \+ node(n367,refuted).
node(n363,refuted) :- node(n364,refuted), node(n367,refuted), node(n9,refuted).
node(n363,supported) :- node(n364,supported).
node(n363,supported) :- node(n367,supported).
node(n363,supported) :- node(n9,supported).
node(n363,unknown) :- \+ node(n363,supported), \+ node(n363,refuted).
verdict(c_f798636fdaa27b3c,supported) :- node(n363,supported).
query(verdict(c_f798636fdaa27b3c,supported)).
verdict(c_f798636fdaa27b3c,refuted) :- node(n363,refuted).
query(verdict(c_f798636fdaa27b3c,refuted)).
verdict(c_f798636fdaa27b3c,unknown) :- node(n363,unknown).
query(verdict(c_f798636fdaa27b3c,unknown)).
node(n372,supported) :- status(o_90122905fce44dfdee7b,supported).
node(n372,refuted) :- status(o_90122905fce44dfdee7b,refuted).
node(n372,unknown) :- status(o_90122905fce44dfdee7b,unknown).
node(n371,supported) :- node(n351,supported), node(n352,supported), node(n372,supported).
node(n371,refuted) :- node(n351,refuted).
node(n371,refuted) :- node(n352,refuted).
node(n371,refuted) :- node(n372,refuted).
node(n371,unknown) :- \+ node(n371,supported), \+ node(n371,refuted).
node(n374,supported) :- status(o_b29e59686e05cf7bdeb2,supported).
node(n374,refuted) :- status(o_b29e59686e05cf7bdeb2,refuted).
node(n374,unknown) :- status(o_b29e59686e05cf7bdeb2,unknown).
node(n373,supported) :- node(n355,supported), node(n356,supported), node(n374,supported).
node(n373,refuted) :- node(n355,refuted).
node(n373,refuted) :- node(n356,refuted).
node(n373,refuted) :- node(n374,refuted).
node(n373,unknown) :- \+ node(n373,supported), \+ node(n373,refuted).
node(n370,refuted) :- node(n371,refuted), node(n373,refuted), node(n9,refuted).
node(n370,supported) :- node(n371,supported).
node(n370,supported) :- node(n373,supported).
node(n370,supported) :- node(n9,supported).
node(n370,unknown) :- \+ node(n370,supported), \+ node(n370,refuted).
verdict(c_6f850c76f969d91e,supported) :- node(n370,supported).
query(verdict(c_6f850c76f969d91e,supported)).
verdict(c_6f850c76f969d91e,refuted) :- node(n370,refuted).
query(verdict(c_6f850c76f969d91e,refuted)).
verdict(c_6f850c76f969d91e,unknown) :- node(n370,unknown).
query(verdict(c_6f850c76f969d91e,unknown)).
node(n376,supported) :- node(n351,supported), node(n352,supported), node(n353,supported), node(n372,supported).
node(n376,refuted) :- node(n351,refuted).
node(n376,refuted) :- node(n352,refuted).
node(n376,refuted) :- node(n353,refuted).
node(n376,refuted) :- node(n372,refuted).
node(n376,unknown) :- \+ node(n376,supported), \+ node(n376,refuted).
node(n377,supported) :- node(n355,supported), node(n356,supported), node(n357,supported), node(n374,supported).
node(n377,refuted) :- node(n355,refuted).
node(n377,refuted) :- node(n356,refuted).
node(n377,refuted) :- node(n357,refuted).
node(n377,refuted) :- node(n374,refuted).
node(n377,unknown) :- \+ node(n377,supported), \+ node(n377,refuted).
node(n375,refuted) :- node(n376,refuted), node(n377,refuted), node(n9,refuted).
node(n375,supported) :- node(n376,supported).
node(n375,supported) :- node(n377,supported).
node(n375,supported) :- node(n9,supported).
node(n375,unknown) :- \+ node(n375,supported), \+ node(n375,refuted).
verdict(c_13e83c7833d389d1,supported) :- node(n375,supported).
query(verdict(c_13e83c7833d389d1,supported)).
verdict(c_13e83c7833d389d1,refuted) :- node(n375,refuted).
query(verdict(c_13e83c7833d389d1,refuted)).
verdict(c_13e83c7833d389d1,unknown) :- node(n375,unknown).
query(verdict(c_13e83c7833d389d1,unknown)).
node(n380,supported) :- status(o_381640a894caa1ee3ebf,supported).
node(n380,refuted) :- status(o_381640a894caa1ee3ebf,refuted).
node(n380,unknown) :- status(o_381640a894caa1ee3ebf,unknown).
node(n381,supported) :- status(o_cd54a64bf3f9af7dd4ca,supported).
node(n381,refuted) :- status(o_cd54a64bf3f9af7dd4ca,refuted).
node(n381,unknown) :- status(o_cd54a64bf3f9af7dd4ca,unknown).
node(n382,supported) :- status(o_9c3e5cb7d20961112020,supported).
node(n382,refuted) :- status(o_9c3e5cb7d20961112020,refuted).
node(n382,unknown) :- status(o_9c3e5cb7d20961112020,unknown).
node(n379,supported) :- node(n380,supported), node(n381,supported), node(n382,supported).
node(n379,refuted) :- node(n380,refuted).
node(n379,refuted) :- node(n381,refuted).
node(n379,refuted) :- node(n382,refuted).
node(n379,unknown) :- \+ node(n379,supported), \+ node(n379,refuted).
node(n384,supported) :- status(o_3f7c8f381b2138305165,supported).
node(n384,refuted) :- status(o_3f7c8f381b2138305165,refuted).
node(n384,unknown) :- status(o_3f7c8f381b2138305165,unknown).
node(n385,supported) :- status(o_5c39c2cfccd72236bb5d,supported).
node(n385,refuted) :- status(o_5c39c2cfccd72236bb5d,refuted).
node(n385,unknown) :- status(o_5c39c2cfccd72236bb5d,unknown).
node(n386,supported) :- status(o_3396687cda575dc277f5,supported).
node(n386,refuted) :- status(o_3396687cda575dc277f5,refuted).
node(n386,unknown) :- status(o_3396687cda575dc277f5,unknown).
node(n383,supported) :- node(n384,supported), node(n385,supported), node(n386,supported).
node(n383,refuted) :- node(n384,refuted).
node(n383,refuted) :- node(n385,refuted).
node(n383,refuted) :- node(n386,refuted).
node(n383,unknown) :- \+ node(n383,supported), \+ node(n383,refuted).
node(n378,refuted) :- node(n379,refuted), node(n383,refuted), node(n9,refuted).
node(n378,supported) :- node(n379,supported).
node(n378,supported) :- node(n383,supported).
node(n378,supported) :- node(n9,supported).
node(n378,unknown) :- \+ node(n378,supported), \+ node(n378,refuted).
verdict(c_bba1976f3e51910e,supported) :- node(n378,supported).
query(verdict(c_bba1976f3e51910e,supported)).
verdict(c_bba1976f3e51910e,refuted) :- node(n378,refuted).
query(verdict(c_bba1976f3e51910e,refuted)).
verdict(c_bba1976f3e51910e,unknown) :- node(n378,unknown).
query(verdict(c_bba1976f3e51910e,unknown)).
node(n389,supported) :- status(o_d517d2c477e42643fd1d,supported).
node(n389,refuted) :- status(o_d517d2c477e42643fd1d,refuted).
node(n389,unknown) :- status(o_d517d2c477e42643fd1d,unknown).
node(n388,supported) :- node(n380,supported), node(n381,supported), node(n382,supported), node(n389,supported).
node(n388,refuted) :- node(n380,refuted).
node(n388,refuted) :- node(n381,refuted).
node(n388,refuted) :- node(n382,refuted).
node(n388,refuted) :- node(n389,refuted).
node(n388,unknown) :- \+ node(n388,supported), \+ node(n388,refuted).
node(n391,supported) :- status(o_3a6a0c07300ab56a96d9,supported).
node(n391,refuted) :- status(o_3a6a0c07300ab56a96d9,refuted).
node(n391,unknown) :- status(o_3a6a0c07300ab56a96d9,unknown).
node(n390,supported) :- node(n384,supported), node(n385,supported), node(n386,supported), node(n391,supported).
node(n390,refuted) :- node(n384,refuted).
node(n390,refuted) :- node(n385,refuted).
node(n390,refuted) :- node(n386,refuted).
node(n390,refuted) :- node(n391,refuted).
node(n390,unknown) :- \+ node(n390,supported), \+ node(n390,refuted).
node(n387,refuted) :- node(n388,refuted), node(n390,refuted), node(n9,refuted).
node(n387,supported) :- node(n388,supported).
node(n387,supported) :- node(n390,supported).
node(n387,supported) :- node(n9,supported).
node(n387,unknown) :- \+ node(n387,supported), \+ node(n387,refuted).
verdict(c_c4977129c10776f1,supported) :- node(n387,supported).
query(verdict(c_c4977129c10776f1,supported)).
verdict(c_c4977129c10776f1,refuted) :- node(n387,refuted).
query(verdict(c_c4977129c10776f1,refuted)).
verdict(c_c4977129c10776f1,unknown) :- node(n387,unknown).
query(verdict(c_c4977129c10776f1,unknown)).
node(n394,supported) :- status(o_c6b99994f382ea080a7d,supported).
node(n394,refuted) :- status(o_c6b99994f382ea080a7d,refuted).
node(n394,unknown) :- status(o_c6b99994f382ea080a7d,unknown).
node(n395,supported) :- status(o_88249683aa3878e436ba,supported).
node(n395,refuted) :- status(o_88249683aa3878e436ba,refuted).
node(n395,unknown) :- status(o_88249683aa3878e436ba,unknown).
node(n393,supported) :- node(n380,supported), node(n381,supported), node(n382,supported), node(n389,supported), node(n394,supported), node(n395,supported).
node(n393,refuted) :- node(n380,refuted).
node(n393,refuted) :- node(n381,refuted).
node(n393,refuted) :- node(n382,refuted).
node(n393,refuted) :- node(n389,refuted).
node(n393,refuted) :- node(n394,refuted).
node(n393,refuted) :- node(n395,refuted).
node(n393,unknown) :- \+ node(n393,supported), \+ node(n393,refuted).
node(n397,supported) :- status(o_be4e8fb5f97cc67e4ee9,supported).
node(n397,refuted) :- status(o_be4e8fb5f97cc67e4ee9,refuted).
node(n397,unknown) :- status(o_be4e8fb5f97cc67e4ee9,unknown).
node(n398,supported) :- status(o_6d9cb4f93b84116861e0,supported).
node(n398,refuted) :- status(o_6d9cb4f93b84116861e0,refuted).
node(n398,unknown) :- status(o_6d9cb4f93b84116861e0,unknown).
node(n396,supported) :- node(n384,supported), node(n385,supported), node(n386,supported), node(n391,supported), node(n397,supported), node(n398,supported).
node(n396,refuted) :- node(n384,refuted).
node(n396,refuted) :- node(n385,refuted).
node(n396,refuted) :- node(n386,refuted).
node(n396,refuted) :- node(n391,refuted).
node(n396,refuted) :- node(n397,refuted).
node(n396,refuted) :- node(n398,refuted).
node(n396,unknown) :- \+ node(n396,supported), \+ node(n396,refuted).
node(n392,refuted) :- node(n393,refuted), node(n396,refuted), node(n9,refuted).
node(n392,supported) :- node(n393,supported).
node(n392,supported) :- node(n396,supported).
node(n392,supported) :- node(n9,supported).
node(n392,unknown) :- \+ node(n392,supported), \+ node(n392,refuted).
verdict(c_c8ab27842f69f92c,supported) :- node(n392,supported).
query(verdict(c_c8ab27842f69f92c,supported)).
verdict(c_c8ab27842f69f92c,refuted) :- node(n392,refuted).
query(verdict(c_c8ab27842f69f92c,refuted)).
verdict(c_c8ab27842f69f92c,unknown) :- node(n392,unknown).
query(verdict(c_c8ab27842f69f92c,unknown)).
node(n401,supported) :- status(o_0d49d9f3565072318d06,supported).
node(n401,refuted) :- status(o_0d49d9f3565072318d06,refuted).
node(n401,unknown) :- status(o_0d49d9f3565072318d06,unknown).
node(n400,supported) :- node(n380,supported), node(n381,supported), node(n401,supported).
node(n400,refuted) :- node(n380,refuted).
node(n400,refuted) :- node(n381,refuted).
node(n400,refuted) :- node(n401,refuted).
node(n400,unknown) :- \+ node(n400,supported), \+ node(n400,refuted).
node(n403,supported) :- status(o_062c3d23073c9e68d5ef,supported).
node(n403,refuted) :- status(o_062c3d23073c9e68d5ef,refuted).
node(n403,unknown) :- status(o_062c3d23073c9e68d5ef,unknown).
node(n402,supported) :- node(n384,supported), node(n385,supported), node(n403,supported).
node(n402,refuted) :- node(n384,refuted).
node(n402,refuted) :- node(n385,refuted).
node(n402,refuted) :- node(n403,refuted).
node(n402,unknown) :- \+ node(n402,supported), \+ node(n402,refuted).
node(n399,refuted) :- node(n400,refuted), node(n402,refuted), node(n9,refuted).
node(n399,supported) :- node(n400,supported).
node(n399,supported) :- node(n402,supported).
node(n399,supported) :- node(n9,supported).
node(n399,unknown) :- \+ node(n399,supported), \+ node(n399,refuted).
verdict(c_da3bc28103ea317a,supported) :- node(n399,supported).
query(verdict(c_da3bc28103ea317a,supported)).
verdict(c_da3bc28103ea317a,refuted) :- node(n399,refuted).
query(verdict(c_da3bc28103ea317a,refuted)).
verdict(c_da3bc28103ea317a,unknown) :- node(n399,unknown).
query(verdict(c_da3bc28103ea317a,unknown)).
node(n405,supported) :- node(n380,supported), node(n381,supported), node(n382,supported), node(n401,supported).
node(n405,refuted) :- node(n380,refuted).
node(n405,refuted) :- node(n381,refuted).
node(n405,refuted) :- node(n382,refuted).
node(n405,refuted) :- node(n401,refuted).
node(n405,unknown) :- \+ node(n405,supported), \+ node(n405,refuted).
node(n406,supported) :- node(n384,supported), node(n385,supported), node(n386,supported), node(n403,supported).
node(n406,refuted) :- node(n384,refuted).
node(n406,refuted) :- node(n385,refuted).
node(n406,refuted) :- node(n386,refuted).
node(n406,refuted) :- node(n403,refuted).
node(n406,unknown) :- \+ node(n406,supported), \+ node(n406,refuted).
node(n404,refuted) :- node(n405,refuted), node(n406,refuted), node(n9,refuted).
node(n404,supported) :- node(n405,supported).
node(n404,supported) :- node(n406,supported).
node(n404,supported) :- node(n9,supported).
node(n404,unknown) :- \+ node(n404,supported), \+ node(n404,refuted).
verdict(c_fa6dff1ee1b8a6f9,supported) :- node(n404,supported).
query(verdict(c_fa6dff1ee1b8a6f9,supported)).
verdict(c_fa6dff1ee1b8a6f9,refuted) :- node(n404,refuted).
query(verdict(c_fa6dff1ee1b8a6f9,refuted)).
verdict(c_fa6dff1ee1b8a6f9,unknown) :- node(n404,unknown).
query(verdict(c_fa6dff1ee1b8a6f9,unknown)).
node(n409,supported) :- status(o_2236d0e401eb969bae19,supported).
node(n409,refuted) :- status(o_2236d0e401eb969bae19,refuted).
node(n409,unknown) :- status(o_2236d0e401eb969bae19,unknown).
node(n410,supported) :- status(o_b542e65140eed93920f5,supported).
node(n410,refuted) :- status(o_b542e65140eed93920f5,refuted).
node(n410,unknown) :- status(o_b542e65140eed93920f5,unknown).
node(n411,supported) :- status(o_32896d1f7c85554fa055,supported).
node(n411,refuted) :- status(o_32896d1f7c85554fa055,refuted).
node(n411,unknown) :- status(o_32896d1f7c85554fa055,unknown).
node(n408,supported) :- node(n409,supported), node(n410,supported), node(n411,supported).
node(n408,refuted) :- node(n409,refuted).
node(n408,refuted) :- node(n410,refuted).
node(n408,refuted) :- node(n411,refuted).
node(n408,unknown) :- \+ node(n408,supported), \+ node(n408,refuted).
node(n413,supported) :- status(o_4a64b449a54269fec3a4,supported).
node(n413,refuted) :- status(o_4a64b449a54269fec3a4,refuted).
node(n413,unknown) :- status(o_4a64b449a54269fec3a4,unknown).
node(n414,supported) :- status(o_2b742144c90c2edf86af,supported).
node(n414,refuted) :- status(o_2b742144c90c2edf86af,refuted).
node(n414,unknown) :- status(o_2b742144c90c2edf86af,unknown).
node(n415,supported) :- status(o_29fdb58d4dfee7e97189,supported).
node(n415,refuted) :- status(o_29fdb58d4dfee7e97189,refuted).
node(n415,unknown) :- status(o_29fdb58d4dfee7e97189,unknown).
node(n412,supported) :- node(n413,supported), node(n414,supported), node(n415,supported).
node(n412,refuted) :- node(n413,refuted).
node(n412,refuted) :- node(n414,refuted).
node(n412,refuted) :- node(n415,refuted).
node(n412,unknown) :- \+ node(n412,supported), \+ node(n412,refuted).
node(n407,refuted) :- node(n408,refuted), node(n412,refuted), node(n9,refuted).
node(n407,supported) :- node(n408,supported).
node(n407,supported) :- node(n412,supported).
node(n407,supported) :- node(n9,supported).
node(n407,unknown) :- \+ node(n407,supported), \+ node(n407,refuted).
verdict(c_6f0d52946c925f17,supported) :- node(n407,supported).
query(verdict(c_6f0d52946c925f17,supported)).
verdict(c_6f0d52946c925f17,refuted) :- node(n407,refuted).
query(verdict(c_6f0d52946c925f17,refuted)).
verdict(c_6f0d52946c925f17,unknown) :- node(n407,unknown).
query(verdict(c_6f0d52946c925f17,unknown)).
node(n418,supported) :- status(o_a7f87e2723618759a4ae,supported).
node(n418,refuted) :- status(o_a7f87e2723618759a4ae,refuted).
node(n418,unknown) :- status(o_a7f87e2723618759a4ae,unknown).
node(n417,supported) :- node(n409,supported), node(n410,supported), node(n411,supported), node(n418,supported).
node(n417,refuted) :- node(n409,refuted).
node(n417,refuted) :- node(n410,refuted).
node(n417,refuted) :- node(n411,refuted).
node(n417,refuted) :- node(n418,refuted).
node(n417,unknown) :- \+ node(n417,supported), \+ node(n417,refuted).
node(n420,supported) :- status(o_61b97c38f0fb04ac7cc9,supported).
node(n420,refuted) :- status(o_61b97c38f0fb04ac7cc9,refuted).
node(n420,unknown) :- status(o_61b97c38f0fb04ac7cc9,unknown).
node(n419,supported) :- node(n413,supported), node(n414,supported), node(n415,supported), node(n420,supported).
node(n419,refuted) :- node(n413,refuted).
node(n419,refuted) :- node(n414,refuted).
node(n419,refuted) :- node(n415,refuted).
node(n419,refuted) :- node(n420,refuted).
node(n419,unknown) :- \+ node(n419,supported), \+ node(n419,refuted).
node(n416,refuted) :- node(n417,refuted), node(n419,refuted), node(n9,refuted).
node(n416,supported) :- node(n417,supported).
node(n416,supported) :- node(n419,supported).
node(n416,supported) :- node(n9,supported).
node(n416,unknown) :- \+ node(n416,supported), \+ node(n416,refuted).
verdict(c_31182cd284e6d80c,supported) :- node(n416,supported).
query(verdict(c_31182cd284e6d80c,supported)).
verdict(c_31182cd284e6d80c,refuted) :- node(n416,refuted).
query(verdict(c_31182cd284e6d80c,refuted)).
verdict(c_31182cd284e6d80c,unknown) :- node(n416,unknown).
query(verdict(c_31182cd284e6d80c,unknown)).
node(n423,supported) :- status(o_d5d704d59660457007ec,supported).
node(n423,refuted) :- status(o_d5d704d59660457007ec,refuted).
node(n423,unknown) :- status(o_d5d704d59660457007ec,unknown).
node(n424,supported) :- status(o_19d69bb5d0cb7877d779,supported).
node(n424,refuted) :- status(o_19d69bb5d0cb7877d779,refuted).
node(n424,unknown) :- status(o_19d69bb5d0cb7877d779,unknown).
node(n422,supported) :- node(n409,supported), node(n410,supported), node(n411,supported), node(n418,supported), node(n423,supported), node(n424,supported).
node(n422,refuted) :- node(n409,refuted).
node(n422,refuted) :- node(n410,refuted).
node(n422,refuted) :- node(n411,refuted).
node(n422,refuted) :- node(n418,refuted).
node(n422,refuted) :- node(n423,refuted).
node(n422,refuted) :- node(n424,refuted).
node(n422,unknown) :- \+ node(n422,supported), \+ node(n422,refuted).
node(n426,supported) :- status(o_c3ffa9fdb24aab9422aa,supported).
node(n426,refuted) :- status(o_c3ffa9fdb24aab9422aa,refuted).
node(n426,unknown) :- status(o_c3ffa9fdb24aab9422aa,unknown).
node(n427,supported) :- status(o_c99dab4bce1e6a5fe904,supported).
node(n427,refuted) :- status(o_c99dab4bce1e6a5fe904,refuted).
node(n427,unknown) :- status(o_c99dab4bce1e6a5fe904,unknown).
node(n425,supported) :- node(n413,supported), node(n414,supported), node(n415,supported), node(n420,supported), node(n426,supported), node(n427,supported).
node(n425,refuted) :- node(n413,refuted).
node(n425,refuted) :- node(n414,refuted).
node(n425,refuted) :- node(n415,refuted).
node(n425,refuted) :- node(n420,refuted).
node(n425,refuted) :- node(n426,refuted).
node(n425,refuted) :- node(n427,refuted).
node(n425,unknown) :- \+ node(n425,supported), \+ node(n425,refuted).
node(n421,refuted) :- node(n422,refuted), node(n425,refuted), node(n9,refuted).
node(n421,supported) :- node(n422,supported).
node(n421,supported) :- node(n425,supported).
node(n421,supported) :- node(n9,supported).
node(n421,unknown) :- \+ node(n421,supported), \+ node(n421,refuted).
verdict(c_4871a5b2a5f98a95,supported) :- node(n421,supported).
query(verdict(c_4871a5b2a5f98a95,supported)).
verdict(c_4871a5b2a5f98a95,refuted) :- node(n421,refuted).
query(verdict(c_4871a5b2a5f98a95,refuted)).
verdict(c_4871a5b2a5f98a95,unknown) :- node(n421,unknown).
query(verdict(c_4871a5b2a5f98a95,unknown)).
node(n430,supported) :- status(o_321c02242be4a6778f5f,supported).
node(n430,refuted) :- status(o_321c02242be4a6778f5f,refuted).
node(n430,unknown) :- status(o_321c02242be4a6778f5f,unknown).
node(n429,supported) :- node(n409,supported), node(n410,supported), node(n430,supported).
node(n429,refuted) :- node(n409,refuted).
node(n429,refuted) :- node(n410,refuted).
node(n429,refuted) :- node(n430,refuted).
node(n429,unknown) :- \+ node(n429,supported), \+ node(n429,refuted).
node(n432,supported) :- status(o_bad1802578d39e3aad5f,supported).
node(n432,refuted) :- status(o_bad1802578d39e3aad5f,refuted).
node(n432,unknown) :- status(o_bad1802578d39e3aad5f,unknown).
node(n431,supported) :- node(n413,supported), node(n414,supported), node(n432,supported).
node(n431,refuted) :- node(n413,refuted).
node(n431,refuted) :- node(n414,refuted).
node(n431,refuted) :- node(n432,refuted).
node(n431,unknown) :- \+ node(n431,supported), \+ node(n431,refuted).
node(n428,refuted) :- node(n429,refuted), node(n431,refuted), node(n9,refuted).
node(n428,supported) :- node(n429,supported).
node(n428,supported) :- node(n431,supported).
node(n428,supported) :- node(n9,supported).
node(n428,unknown) :- \+ node(n428,supported), \+ node(n428,refuted).
verdict(c_f2c35fba67b6f467,supported) :- node(n428,supported).
query(verdict(c_f2c35fba67b6f467,supported)).
verdict(c_f2c35fba67b6f467,refuted) :- node(n428,refuted).
query(verdict(c_f2c35fba67b6f467,refuted)).
verdict(c_f2c35fba67b6f467,unknown) :- node(n428,unknown).
query(verdict(c_f2c35fba67b6f467,unknown)).
node(n434,supported) :- node(n409,supported), node(n410,supported), node(n411,supported), node(n430,supported).
node(n434,refuted) :- node(n409,refuted).
node(n434,refuted) :- node(n410,refuted).
node(n434,refuted) :- node(n411,refuted).
node(n434,refuted) :- node(n430,refuted).
node(n434,unknown) :- \+ node(n434,supported), \+ node(n434,refuted).
node(n435,supported) :- node(n413,supported), node(n414,supported), node(n415,supported), node(n432,supported).
node(n435,refuted) :- node(n413,refuted).
node(n435,refuted) :- node(n414,refuted).
node(n435,refuted) :- node(n415,refuted).
node(n435,refuted) :- node(n432,refuted).
node(n435,unknown) :- \+ node(n435,supported), \+ node(n435,refuted).
node(n433,refuted) :- node(n434,refuted), node(n435,refuted), node(n9,refuted).
node(n433,supported) :- node(n434,supported).
node(n433,supported) :- node(n435,supported).
node(n433,supported) :- node(n9,supported).
node(n433,unknown) :- \+ node(n433,supported), \+ node(n433,refuted).
verdict(c_453358fe90479f30,supported) :- node(n433,supported).
query(verdict(c_453358fe90479f30,supported)).
verdict(c_453358fe90479f30,refuted) :- node(n433,refuted).
query(verdict(c_453358fe90479f30,refuted)).
verdict(c_453358fe90479f30,unknown) :- node(n433,unknown).
query(verdict(c_453358fe90479f30,unknown)).
node(n438,supported) :- status(o_23898dddbf45158ec6c2,supported).
node(n438,refuted) :- status(o_23898dddbf45158ec6c2,refuted).
node(n438,unknown) :- status(o_23898dddbf45158ec6c2,unknown).
node(n439,supported) :- status(o_390f38eba41b0d7a0394,supported).
node(n439,refuted) :- status(o_390f38eba41b0d7a0394,refuted).
node(n439,unknown) :- status(o_390f38eba41b0d7a0394,unknown).
node(n440,supported) :- status(o_cf686954e3e926a159c1,supported).
node(n440,refuted) :- status(o_cf686954e3e926a159c1,refuted).
node(n440,unknown) :- status(o_cf686954e3e926a159c1,unknown).
node(n437,supported) :- node(n438,supported), node(n439,supported), node(n440,supported).
node(n437,refuted) :- node(n438,refuted).
node(n437,refuted) :- node(n439,refuted).
node(n437,refuted) :- node(n440,refuted).
node(n437,unknown) :- \+ node(n437,supported), \+ node(n437,refuted).
node(n442,supported) :- status(o_62959a560bf083808c40,supported).
node(n442,refuted) :- status(o_62959a560bf083808c40,refuted).
node(n442,unknown) :- status(o_62959a560bf083808c40,unknown).
node(n443,supported) :- status(o_c495b76d91324bb051a1,supported).
node(n443,refuted) :- status(o_c495b76d91324bb051a1,refuted).
node(n443,unknown) :- status(o_c495b76d91324bb051a1,unknown).
node(n444,supported) :- status(o_ab081b90bc561808b3ea,supported).
node(n444,refuted) :- status(o_ab081b90bc561808b3ea,refuted).
node(n444,unknown) :- status(o_ab081b90bc561808b3ea,unknown).
node(n441,supported) :- node(n442,supported), node(n443,supported), node(n444,supported).
node(n441,refuted) :- node(n442,refuted).
node(n441,refuted) :- node(n443,refuted).
node(n441,refuted) :- node(n444,refuted).
node(n441,unknown) :- \+ node(n441,supported), \+ node(n441,refuted).
node(n436,refuted) :- node(n437,refuted), node(n441,refuted), node(n9,refuted).
node(n436,supported) :- node(n437,supported).
node(n436,supported) :- node(n441,supported).
node(n436,supported) :- node(n9,supported).
node(n436,unknown) :- \+ node(n436,supported), \+ node(n436,refuted).
verdict(c_8a8356b4e86af456,supported) :- node(n436,supported).
query(verdict(c_8a8356b4e86af456,supported)).
verdict(c_8a8356b4e86af456,refuted) :- node(n436,refuted).
query(verdict(c_8a8356b4e86af456,refuted)).
verdict(c_8a8356b4e86af456,unknown) :- node(n436,unknown).
query(verdict(c_8a8356b4e86af456,unknown)).
node(n447,supported) :- status(o_ec7b76e158a4503c6f6f,supported).
node(n447,refuted) :- status(o_ec7b76e158a4503c6f6f,refuted).
node(n447,unknown) :- status(o_ec7b76e158a4503c6f6f,unknown).
node(n446,supported) :- node(n438,supported), node(n439,supported), node(n440,supported), node(n447,supported).
node(n446,refuted) :- node(n438,refuted).
node(n446,refuted) :- node(n439,refuted).
node(n446,refuted) :- node(n440,refuted).
node(n446,refuted) :- node(n447,refuted).
node(n446,unknown) :- \+ node(n446,supported), \+ node(n446,refuted).
node(n449,supported) :- status(o_eccdeba6a8e49d5fcb73,supported).
node(n449,refuted) :- status(o_eccdeba6a8e49d5fcb73,refuted).
node(n449,unknown) :- status(o_eccdeba6a8e49d5fcb73,unknown).
node(n448,supported) :- node(n442,supported), node(n443,supported), node(n444,supported), node(n449,supported).
node(n448,refuted) :- node(n442,refuted).
node(n448,refuted) :- node(n443,refuted).
node(n448,refuted) :- node(n444,refuted).
node(n448,refuted) :- node(n449,refuted).
node(n448,unknown) :- \+ node(n448,supported), \+ node(n448,refuted).
node(n445,refuted) :- node(n446,refuted), node(n448,refuted), node(n9,refuted).
node(n445,supported) :- node(n446,supported).
node(n445,supported) :- node(n448,supported).
node(n445,supported) :- node(n9,supported).
node(n445,unknown) :- \+ node(n445,supported), \+ node(n445,refuted).
verdict(c_7256791363bbd531,supported) :- node(n445,supported).
query(verdict(c_7256791363bbd531,supported)).
verdict(c_7256791363bbd531,refuted) :- node(n445,refuted).
query(verdict(c_7256791363bbd531,refuted)).
verdict(c_7256791363bbd531,unknown) :- node(n445,unknown).
query(verdict(c_7256791363bbd531,unknown)).
node(n452,supported) :- status(o_f835fe79960121d8a5f5,supported).
node(n452,refuted) :- status(o_f835fe79960121d8a5f5,refuted).
node(n452,unknown) :- status(o_f835fe79960121d8a5f5,unknown).
node(n453,supported) :- status(o_c5fbba8fb0af2c7cf6f4,supported).
node(n453,refuted) :- status(o_c5fbba8fb0af2c7cf6f4,refuted).
node(n453,unknown) :- status(o_c5fbba8fb0af2c7cf6f4,unknown).
node(n451,supported) :- node(n438,supported), node(n439,supported), node(n440,supported), node(n447,supported), node(n452,supported), node(n453,supported).
node(n451,refuted) :- node(n438,refuted).
node(n451,refuted) :- node(n439,refuted).
node(n451,refuted) :- node(n440,refuted).
node(n451,refuted) :- node(n447,refuted).
node(n451,refuted) :- node(n452,refuted).
node(n451,refuted) :- node(n453,refuted).
node(n451,unknown) :- \+ node(n451,supported), \+ node(n451,refuted).
node(n455,supported) :- status(o_8ae71956eed3a6cccf21,supported).
node(n455,refuted) :- status(o_8ae71956eed3a6cccf21,refuted).
node(n455,unknown) :- status(o_8ae71956eed3a6cccf21,unknown).
node(n456,supported) :- status(o_67f3f4d1827fe1c69ebe,supported).
node(n456,refuted) :- status(o_67f3f4d1827fe1c69ebe,refuted).
node(n456,unknown) :- status(o_67f3f4d1827fe1c69ebe,unknown).
node(n454,supported) :- node(n442,supported), node(n443,supported), node(n444,supported), node(n449,supported), node(n455,supported), node(n456,supported).
node(n454,refuted) :- node(n442,refuted).
node(n454,refuted) :- node(n443,refuted).
node(n454,refuted) :- node(n444,refuted).
node(n454,refuted) :- node(n449,refuted).
node(n454,refuted) :- node(n455,refuted).
node(n454,refuted) :- node(n456,refuted).
node(n454,unknown) :- \+ node(n454,supported), \+ node(n454,refuted).
node(n450,refuted) :- node(n451,refuted), node(n454,refuted), node(n9,refuted).
node(n450,supported) :- node(n451,supported).
node(n450,supported) :- node(n454,supported).
node(n450,supported) :- node(n9,supported).
node(n450,unknown) :- \+ node(n450,supported), \+ node(n450,refuted).
verdict(c_8428760b6e38c132,supported) :- node(n450,supported).
query(verdict(c_8428760b6e38c132,supported)).
verdict(c_8428760b6e38c132,refuted) :- node(n450,refuted).
query(verdict(c_8428760b6e38c132,refuted)).
verdict(c_8428760b6e38c132,unknown) :- node(n450,unknown).
query(verdict(c_8428760b6e38c132,unknown)).
node(n459,supported) :- status(o_03fbbce7bb70c41449aa,supported).
node(n459,refuted) :- status(o_03fbbce7bb70c41449aa,refuted).
node(n459,unknown) :- status(o_03fbbce7bb70c41449aa,unknown).
node(n458,supported) :- node(n438,supported), node(n439,supported), node(n459,supported).
node(n458,refuted) :- node(n438,refuted).
node(n458,refuted) :- node(n439,refuted).
node(n458,refuted) :- node(n459,refuted).
node(n458,unknown) :- \+ node(n458,supported), \+ node(n458,refuted).
node(n461,supported) :- status(o_6130905d7012fc081304,supported).
node(n461,refuted) :- status(o_6130905d7012fc081304,refuted).
node(n461,unknown) :- status(o_6130905d7012fc081304,unknown).
node(n460,supported) :- node(n442,supported), node(n443,supported), node(n461,supported).
node(n460,refuted) :- node(n442,refuted).
node(n460,refuted) :- node(n443,refuted).
node(n460,refuted) :- node(n461,refuted).
node(n460,unknown) :- \+ node(n460,supported), \+ node(n460,refuted).
node(n457,refuted) :- node(n458,refuted), node(n460,refuted), node(n9,refuted).
node(n457,supported) :- node(n458,supported).
node(n457,supported) :- node(n460,supported).
node(n457,supported) :- node(n9,supported).
node(n457,unknown) :- \+ node(n457,supported), \+ node(n457,refuted).
verdict(c_ba8a4db2e9d48500,supported) :- node(n457,supported).
query(verdict(c_ba8a4db2e9d48500,supported)).
verdict(c_ba8a4db2e9d48500,refuted) :- node(n457,refuted).
query(verdict(c_ba8a4db2e9d48500,refuted)).
verdict(c_ba8a4db2e9d48500,unknown) :- node(n457,unknown).
query(verdict(c_ba8a4db2e9d48500,unknown)).
node(n463,supported) :- node(n438,supported), node(n439,supported), node(n440,supported), node(n459,supported).
node(n463,refuted) :- node(n438,refuted).
node(n463,refuted) :- node(n439,refuted).
node(n463,refuted) :- node(n440,refuted).
node(n463,refuted) :- node(n459,refuted).
node(n463,unknown) :- \+ node(n463,supported), \+ node(n463,refuted).
node(n464,supported) :- node(n442,supported), node(n443,supported), node(n444,supported), node(n461,supported).
node(n464,refuted) :- node(n442,refuted).
node(n464,refuted) :- node(n443,refuted).
node(n464,refuted) :- node(n444,refuted).
node(n464,refuted) :- node(n461,refuted).
node(n464,unknown) :- \+ node(n464,supported), \+ node(n464,refuted).
node(n462,refuted) :- node(n463,refuted), node(n464,refuted), node(n9,refuted).
node(n462,supported) :- node(n463,supported).
node(n462,supported) :- node(n464,supported).
node(n462,supported) :- node(n9,supported).
node(n462,unknown) :- \+ node(n462,supported), \+ node(n462,refuted).
verdict(c_1082e7edfae0e715,supported) :- node(n462,supported).
query(verdict(c_1082e7edfae0e715,supported)).
verdict(c_1082e7edfae0e715,refuted) :- node(n462,refuted).
query(verdict(c_1082e7edfae0e715,refuted)).
verdict(c_1082e7edfae0e715,unknown) :- node(n462,unknown).
query(verdict(c_1082e7edfae0e715,unknown)).
node(n467,supported) :- status(o_bd762be8d8fe921a17c3,supported).
node(n467,refuted) :- status(o_bd762be8d8fe921a17c3,refuted).
node(n467,unknown) :- status(o_bd762be8d8fe921a17c3,unknown).
node(n468,supported) :- status(o_970f7dffc1b0811da674,supported).
node(n468,refuted) :- status(o_970f7dffc1b0811da674,refuted).
node(n468,unknown) :- status(o_970f7dffc1b0811da674,unknown).
node(n469,supported) :- status(o_5019c49e1e444762f405,supported).
node(n469,refuted) :- status(o_5019c49e1e444762f405,refuted).
node(n469,unknown) :- status(o_5019c49e1e444762f405,unknown).
node(n466,supported) :- node(n467,supported), node(n468,supported), node(n469,supported).
node(n466,refuted) :- node(n467,refuted).
node(n466,refuted) :- node(n468,refuted).
node(n466,refuted) :- node(n469,refuted).
node(n466,unknown) :- \+ node(n466,supported), \+ node(n466,refuted).
node(n471,supported) :- status(o_a3d49b82fc7264a6ebad,supported).
node(n471,refuted) :- status(o_a3d49b82fc7264a6ebad,refuted).
node(n471,unknown) :- status(o_a3d49b82fc7264a6ebad,unknown).
node(n472,supported) :- status(o_ec0dbd26d248721ccf94,supported).
node(n472,refuted) :- status(o_ec0dbd26d248721ccf94,refuted).
node(n472,unknown) :- status(o_ec0dbd26d248721ccf94,unknown).
node(n473,supported) :- status(o_42c3db54e399f7219f4d,supported).
node(n473,refuted) :- status(o_42c3db54e399f7219f4d,refuted).
node(n473,unknown) :- status(o_42c3db54e399f7219f4d,unknown).
node(n470,supported) :- node(n471,supported), node(n472,supported), node(n473,supported).
node(n470,refuted) :- node(n471,refuted).
node(n470,refuted) :- node(n472,refuted).
node(n470,refuted) :- node(n473,refuted).
node(n470,unknown) :- \+ node(n470,supported), \+ node(n470,refuted).
node(n465,refuted) :- node(n466,refuted), node(n470,refuted), node(n9,refuted).
node(n465,supported) :- node(n466,supported).
node(n465,supported) :- node(n470,supported).
node(n465,supported) :- node(n9,supported).
node(n465,unknown) :- \+ node(n465,supported), \+ node(n465,refuted).
verdict(c_dd57368a4059b0fc,supported) :- node(n465,supported).
query(verdict(c_dd57368a4059b0fc,supported)).
verdict(c_dd57368a4059b0fc,refuted) :- node(n465,refuted).
query(verdict(c_dd57368a4059b0fc,refuted)).
verdict(c_dd57368a4059b0fc,unknown) :- node(n465,unknown).
query(verdict(c_dd57368a4059b0fc,unknown)).
node(n476,supported) :- status(o_4113fad32ff4a272b1f2,supported).
node(n476,refuted) :- status(o_4113fad32ff4a272b1f2,refuted).
node(n476,unknown) :- status(o_4113fad32ff4a272b1f2,unknown).
node(n475,supported) :- node(n467,supported), node(n468,supported), node(n469,supported), node(n476,supported).
node(n475,refuted) :- node(n467,refuted).
node(n475,refuted) :- node(n468,refuted).
node(n475,refuted) :- node(n469,refuted).
node(n475,refuted) :- node(n476,refuted).
node(n475,unknown) :- \+ node(n475,supported), \+ node(n475,refuted).
node(n478,supported) :- status(o_e7d8e0bd800e0ac51eab,supported).
node(n478,refuted) :- status(o_e7d8e0bd800e0ac51eab,refuted).
node(n478,unknown) :- status(o_e7d8e0bd800e0ac51eab,unknown).
node(n477,supported) :- node(n471,supported), node(n472,supported), node(n473,supported), node(n478,supported).
node(n477,refuted) :- node(n471,refuted).
node(n477,refuted) :- node(n472,refuted).
node(n477,refuted) :- node(n473,refuted).
node(n477,refuted) :- node(n478,refuted).
node(n477,unknown) :- \+ node(n477,supported), \+ node(n477,refuted).
node(n474,refuted) :- node(n475,refuted), node(n477,refuted), node(n9,refuted).
node(n474,supported) :- node(n475,supported).
node(n474,supported) :- node(n477,supported).
node(n474,supported) :- node(n9,supported).
node(n474,unknown) :- \+ node(n474,supported), \+ node(n474,refuted).
verdict(c_6748fa0b0e096a95,supported) :- node(n474,supported).
query(verdict(c_6748fa0b0e096a95,supported)).
verdict(c_6748fa0b0e096a95,refuted) :- node(n474,refuted).
query(verdict(c_6748fa0b0e096a95,refuted)).
verdict(c_6748fa0b0e096a95,unknown) :- node(n474,unknown).
query(verdict(c_6748fa0b0e096a95,unknown)).
node(n481,supported) :- status(o_d4f607678494c3b1187c,supported).
node(n481,refuted) :- status(o_d4f607678494c3b1187c,refuted).
node(n481,unknown) :- status(o_d4f607678494c3b1187c,unknown).
node(n482,supported) :- status(o_8363ba639599b8ee4ac7,supported).
node(n482,refuted) :- status(o_8363ba639599b8ee4ac7,refuted).
node(n482,unknown) :- status(o_8363ba639599b8ee4ac7,unknown).
node(n480,supported) :- node(n467,supported), node(n468,supported), node(n469,supported), node(n476,supported), node(n481,supported), node(n482,supported).
node(n480,refuted) :- node(n467,refuted).
node(n480,refuted) :- node(n468,refuted).
node(n480,refuted) :- node(n469,refuted).
node(n480,refuted) :- node(n476,refuted).
node(n480,refuted) :- node(n481,refuted).
node(n480,refuted) :- node(n482,refuted).
node(n480,unknown) :- \+ node(n480,supported), \+ node(n480,refuted).
node(n484,supported) :- status(o_073af1e867f3112966e0,supported).
node(n484,refuted) :- status(o_073af1e867f3112966e0,refuted).
node(n484,unknown) :- status(o_073af1e867f3112966e0,unknown).
node(n485,supported) :- status(o_6a1d25e7ab9e503b074e,supported).
node(n485,refuted) :- status(o_6a1d25e7ab9e503b074e,refuted).
node(n485,unknown) :- status(o_6a1d25e7ab9e503b074e,unknown).
node(n483,supported) :- node(n471,supported), node(n472,supported), node(n473,supported), node(n478,supported), node(n484,supported), node(n485,supported).
node(n483,refuted) :- node(n471,refuted).
node(n483,refuted) :- node(n472,refuted).
node(n483,refuted) :- node(n473,refuted).
node(n483,refuted) :- node(n478,refuted).
node(n483,refuted) :- node(n484,refuted).
node(n483,refuted) :- node(n485,refuted).
node(n483,unknown) :- \+ node(n483,supported), \+ node(n483,refuted).
node(n479,refuted) :- node(n480,refuted), node(n483,refuted), node(n9,refuted).
node(n479,supported) :- node(n480,supported).
node(n479,supported) :- node(n483,supported).
node(n479,supported) :- node(n9,supported).
node(n479,unknown) :- \+ node(n479,supported), \+ node(n479,refuted).
verdict(c_f30d1e0f7743e500,supported) :- node(n479,supported).
query(verdict(c_f30d1e0f7743e500,supported)).
verdict(c_f30d1e0f7743e500,refuted) :- node(n479,refuted).
query(verdict(c_f30d1e0f7743e500,refuted)).
verdict(c_f30d1e0f7743e500,unknown) :- node(n479,unknown).
query(verdict(c_f30d1e0f7743e500,unknown)).
node(n488,supported) :- status(o_edf8cc726335643f3d44,supported).
node(n488,refuted) :- status(o_edf8cc726335643f3d44,refuted).
node(n488,unknown) :- status(o_edf8cc726335643f3d44,unknown).
node(n487,supported) :- node(n467,supported), node(n468,supported), node(n488,supported).
node(n487,refuted) :- node(n467,refuted).
node(n487,refuted) :- node(n468,refuted).
node(n487,refuted) :- node(n488,refuted).
node(n487,unknown) :- \+ node(n487,supported), \+ node(n487,refuted).
node(n490,supported) :- status(o_b907b6b19cdaaaea849c,supported).
node(n490,refuted) :- status(o_b907b6b19cdaaaea849c,refuted).
node(n490,unknown) :- status(o_b907b6b19cdaaaea849c,unknown).
node(n489,supported) :- node(n471,supported), node(n472,supported), node(n490,supported).
node(n489,refuted) :- node(n471,refuted).
node(n489,refuted) :- node(n472,refuted).
node(n489,refuted) :- node(n490,refuted).
node(n489,unknown) :- \+ node(n489,supported), \+ node(n489,refuted).
node(n486,refuted) :- node(n487,refuted), node(n489,refuted), node(n9,refuted).
node(n486,supported) :- node(n487,supported).
node(n486,supported) :- node(n489,supported).
node(n486,supported) :- node(n9,supported).
node(n486,unknown) :- \+ node(n486,supported), \+ node(n486,refuted).
verdict(c_d88ca34c5bf5dc61,supported) :- node(n486,supported).
query(verdict(c_d88ca34c5bf5dc61,supported)).
verdict(c_d88ca34c5bf5dc61,refuted) :- node(n486,refuted).
query(verdict(c_d88ca34c5bf5dc61,refuted)).
verdict(c_d88ca34c5bf5dc61,unknown) :- node(n486,unknown).
query(verdict(c_d88ca34c5bf5dc61,unknown)).
node(n492,supported) :- node(n467,supported), node(n468,supported), node(n469,supported), node(n488,supported).
node(n492,refuted) :- node(n467,refuted).
node(n492,refuted) :- node(n468,refuted).
node(n492,refuted) :- node(n469,refuted).
node(n492,refuted) :- node(n488,refuted).
node(n492,unknown) :- \+ node(n492,supported), \+ node(n492,refuted).
node(n493,supported) :- node(n471,supported), node(n472,supported), node(n473,supported), node(n490,supported).
node(n493,refuted) :- node(n471,refuted).
node(n493,refuted) :- node(n472,refuted).
node(n493,refuted) :- node(n473,refuted).
node(n493,refuted) :- node(n490,refuted).
node(n493,unknown) :- \+ node(n493,supported), \+ node(n493,refuted).
node(n491,refuted) :- node(n492,refuted), node(n493,refuted), node(n9,refuted).
node(n491,supported) :- node(n492,supported).
node(n491,supported) :- node(n493,supported).
node(n491,supported) :- node(n9,supported).
node(n491,unknown) :- \+ node(n491,supported), \+ node(n491,refuted).
verdict(c_cd353c5e99c0d457,supported) :- node(n491,supported).
query(verdict(c_cd353c5e99c0d457,supported)).
verdict(c_cd353c5e99c0d457,refuted) :- node(n491,refuted).
query(verdict(c_cd353c5e99c0d457,refuted)).
verdict(c_cd353c5e99c0d457,unknown) :- node(n491,unknown).
query(verdict(c_cd353c5e99c0d457,unknown)).
node(n496,supported) :- status(o_3278e76aa9601a814674,supported).
node(n496,refuted) :- status(o_3278e76aa9601a814674,refuted).
node(n496,unknown) :- status(o_3278e76aa9601a814674,unknown).
node(n497,supported) :- status(o_7f3b8b2a2d6a5a06bd50,supported).
node(n497,refuted) :- status(o_7f3b8b2a2d6a5a06bd50,refuted).
node(n497,unknown) :- status(o_7f3b8b2a2d6a5a06bd50,unknown).
node(n498,supported) :- status(o_f31f34bccaee7a7fb4fe,supported).
node(n498,refuted) :- status(o_f31f34bccaee7a7fb4fe,refuted).
node(n498,unknown) :- status(o_f31f34bccaee7a7fb4fe,unknown).
node(n495,supported) :- node(n496,supported), node(n497,supported), node(n498,supported).
node(n495,refuted) :- node(n496,refuted).
node(n495,refuted) :- node(n497,refuted).
node(n495,refuted) :- node(n498,refuted).
node(n495,unknown) :- \+ node(n495,supported), \+ node(n495,refuted).
node(n500,supported) :- status(o_2b21617586bcbfdbab61,supported).
node(n500,refuted) :- status(o_2b21617586bcbfdbab61,refuted).
node(n500,unknown) :- status(o_2b21617586bcbfdbab61,unknown).
node(n501,supported) :- status(o_30ef72946975fd41249f,supported).
node(n501,refuted) :- status(o_30ef72946975fd41249f,refuted).
node(n501,unknown) :- status(o_30ef72946975fd41249f,unknown).
node(n502,supported) :- status(o_418c81c5d740dcfd54e2,supported).
node(n502,refuted) :- status(o_418c81c5d740dcfd54e2,refuted).
node(n502,unknown) :- status(o_418c81c5d740dcfd54e2,unknown).
node(n499,supported) :- node(n500,supported), node(n501,supported), node(n502,supported).
node(n499,refuted) :- node(n500,refuted).
node(n499,refuted) :- node(n501,refuted).
node(n499,refuted) :- node(n502,refuted).
node(n499,unknown) :- \+ node(n499,supported), \+ node(n499,refuted).
node(n494,refuted) :- node(n495,refuted), node(n499,refuted), node(n9,refuted).
node(n494,supported) :- node(n495,supported).
node(n494,supported) :- node(n499,supported).
node(n494,supported) :- node(n9,supported).
node(n494,unknown) :- \+ node(n494,supported), \+ node(n494,refuted).
verdict(c_2533c6161f53b1c4,supported) :- node(n494,supported).
query(verdict(c_2533c6161f53b1c4,supported)).
verdict(c_2533c6161f53b1c4,refuted) :- node(n494,refuted).
query(verdict(c_2533c6161f53b1c4,refuted)).
verdict(c_2533c6161f53b1c4,unknown) :- node(n494,unknown).
query(verdict(c_2533c6161f53b1c4,unknown)).
node(n505,supported) :- status(o_8c1bbcbb845ca5a5fbf9,supported).
node(n505,refuted) :- status(o_8c1bbcbb845ca5a5fbf9,refuted).
node(n505,unknown) :- status(o_8c1bbcbb845ca5a5fbf9,unknown).
node(n504,supported) :- node(n496,supported), node(n497,supported), node(n498,supported), node(n505,supported).
node(n504,refuted) :- node(n496,refuted).
node(n504,refuted) :- node(n497,refuted).
node(n504,refuted) :- node(n498,refuted).
node(n504,refuted) :- node(n505,refuted).
node(n504,unknown) :- \+ node(n504,supported), \+ node(n504,refuted).
node(n507,supported) :- status(o_eaad72544fa1a65573dd,supported).
node(n507,refuted) :- status(o_eaad72544fa1a65573dd,refuted).
node(n507,unknown) :- status(o_eaad72544fa1a65573dd,unknown).
node(n506,supported) :- node(n500,supported), node(n501,supported), node(n502,supported), node(n507,supported).
node(n506,refuted) :- node(n500,refuted).
node(n506,refuted) :- node(n501,refuted).
node(n506,refuted) :- node(n502,refuted).
node(n506,refuted) :- node(n507,refuted).
node(n506,unknown) :- \+ node(n506,supported), \+ node(n506,refuted).
node(n503,refuted) :- node(n504,refuted), node(n506,refuted), node(n9,refuted).
node(n503,supported) :- node(n504,supported).
node(n503,supported) :- node(n506,supported).
node(n503,supported) :- node(n9,supported).
node(n503,unknown) :- \+ node(n503,supported), \+ node(n503,refuted).
verdict(c_065862e10a10b438,supported) :- node(n503,supported).
query(verdict(c_065862e10a10b438,supported)).
verdict(c_065862e10a10b438,refuted) :- node(n503,refuted).
query(verdict(c_065862e10a10b438,refuted)).
verdict(c_065862e10a10b438,unknown) :- node(n503,unknown).
query(verdict(c_065862e10a10b438,unknown)).
node(n510,supported) :- status(o_2c1838410301abfacbe3,supported).
node(n510,refuted) :- status(o_2c1838410301abfacbe3,refuted).
node(n510,unknown) :- status(o_2c1838410301abfacbe3,unknown).
node(n511,supported) :- status(o_e4d7d0adc010caa1aa21,supported).
node(n511,refuted) :- status(o_e4d7d0adc010caa1aa21,refuted).
node(n511,unknown) :- status(o_e4d7d0adc010caa1aa21,unknown).
node(n509,supported) :- node(n496,supported), node(n497,supported), node(n498,supported), node(n505,supported), node(n510,supported), node(n511,supported).
node(n509,refuted) :- node(n496,refuted).
node(n509,refuted) :- node(n497,refuted).
node(n509,refuted) :- node(n498,refuted).
node(n509,refuted) :- node(n505,refuted).
node(n509,refuted) :- node(n510,refuted).
node(n509,refuted) :- node(n511,refuted).
node(n509,unknown) :- \+ node(n509,supported), \+ node(n509,refuted).
node(n513,supported) :- status(o_07644fea3fb5b095cb08,supported).
node(n513,refuted) :- status(o_07644fea3fb5b095cb08,refuted).
node(n513,unknown) :- status(o_07644fea3fb5b095cb08,unknown).
node(n514,supported) :- status(o_77d06d21c341e1be2a4c,supported).
node(n514,refuted) :- status(o_77d06d21c341e1be2a4c,refuted).
node(n514,unknown) :- status(o_77d06d21c341e1be2a4c,unknown).
node(n512,supported) :- node(n500,supported), node(n501,supported), node(n502,supported), node(n507,supported), node(n513,supported), node(n514,supported).
node(n512,refuted) :- node(n500,refuted).
node(n512,refuted) :- node(n501,refuted).
node(n512,refuted) :- node(n502,refuted).
node(n512,refuted) :- node(n507,refuted).
node(n512,refuted) :- node(n513,refuted).
node(n512,refuted) :- node(n514,refuted).
node(n512,unknown) :- \+ node(n512,supported), \+ node(n512,refuted).
node(n508,refuted) :- node(n509,refuted), node(n512,refuted), node(n9,refuted).
node(n508,supported) :- node(n509,supported).
node(n508,supported) :- node(n512,supported).
node(n508,supported) :- node(n9,supported).
node(n508,unknown) :- \+ node(n508,supported), \+ node(n508,refuted).
verdict(c_80dfb15b4fd28f82,supported) :- node(n508,supported).
query(verdict(c_80dfb15b4fd28f82,supported)).
verdict(c_80dfb15b4fd28f82,refuted) :- node(n508,refuted).
query(verdict(c_80dfb15b4fd28f82,refuted)).
verdict(c_80dfb15b4fd28f82,unknown) :- node(n508,unknown).
query(verdict(c_80dfb15b4fd28f82,unknown)).
node(n517,supported) :- status(o_dae7c4a5d3bf432080a8,supported).
node(n517,refuted) :- status(o_dae7c4a5d3bf432080a8,refuted).
node(n517,unknown) :- status(o_dae7c4a5d3bf432080a8,unknown).
node(n516,supported) :- node(n496,supported), node(n497,supported), node(n517,supported).
node(n516,refuted) :- node(n496,refuted).
node(n516,refuted) :- node(n497,refuted).
node(n516,refuted) :- node(n517,refuted).
node(n516,unknown) :- \+ node(n516,supported), \+ node(n516,refuted).
node(n519,supported) :- status(o_7cf375cf219d4af3cc8f,supported).
node(n519,refuted) :- status(o_7cf375cf219d4af3cc8f,refuted).
node(n519,unknown) :- status(o_7cf375cf219d4af3cc8f,unknown).
node(n518,supported) :- node(n500,supported), node(n501,supported), node(n519,supported).
node(n518,refuted) :- node(n500,refuted).
node(n518,refuted) :- node(n501,refuted).
node(n518,refuted) :- node(n519,refuted).
node(n518,unknown) :- \+ node(n518,supported), \+ node(n518,refuted).
node(n515,refuted) :- node(n516,refuted), node(n518,refuted), node(n9,refuted).
node(n515,supported) :- node(n516,supported).
node(n515,supported) :- node(n518,supported).
node(n515,supported) :- node(n9,supported).
node(n515,unknown) :- \+ node(n515,supported), \+ node(n515,refuted).
verdict(c_e5f7200214716f94,supported) :- node(n515,supported).
query(verdict(c_e5f7200214716f94,supported)).
verdict(c_e5f7200214716f94,refuted) :- node(n515,refuted).
query(verdict(c_e5f7200214716f94,refuted)).
verdict(c_e5f7200214716f94,unknown) :- node(n515,unknown).
query(verdict(c_e5f7200214716f94,unknown)).
node(n521,supported) :- node(n496,supported), node(n497,supported), node(n498,supported), node(n517,supported).
node(n521,refuted) :- node(n496,refuted).
node(n521,refuted) :- node(n497,refuted).
node(n521,refuted) :- node(n498,refuted).
node(n521,refuted) :- node(n517,refuted).
node(n521,unknown) :- \+ node(n521,supported), \+ node(n521,refuted).
node(n522,supported) :- node(n500,supported), node(n501,supported), node(n502,supported), node(n519,supported).
node(n522,refuted) :- node(n500,refuted).
node(n522,refuted) :- node(n501,refuted).
node(n522,refuted) :- node(n502,refuted).
node(n522,refuted) :- node(n519,refuted).
node(n522,unknown) :- \+ node(n522,supported), \+ node(n522,refuted).
node(n520,refuted) :- node(n521,refuted), node(n522,refuted), node(n9,refuted).
node(n520,supported) :- node(n521,supported).
node(n520,supported) :- node(n522,supported).
node(n520,supported) :- node(n9,supported).
node(n520,unknown) :- \+ node(n520,supported), \+ node(n520,refuted).
verdict(c_a516278444363fa2,supported) :- node(n520,supported).
query(verdict(c_a516278444363fa2,supported)).
verdict(c_a516278444363fa2,refuted) :- node(n520,refuted).
query(verdict(c_a516278444363fa2,refuted)).
verdict(c_a516278444363fa2,unknown) :- node(n520,unknown).
query(verdict(c_a516278444363fa2,unknown)).
node(n525,supported) :- status(o_5640a6b89b41f2e05596,supported).
node(n525,refuted) :- status(o_5640a6b89b41f2e05596,refuted).
node(n525,unknown) :- status(o_5640a6b89b41f2e05596,unknown).
node(n526,supported) :- status(o_c7d2be08cada49b19671,supported).
node(n526,refuted) :- status(o_c7d2be08cada49b19671,refuted).
node(n526,unknown) :- status(o_c7d2be08cada49b19671,unknown).
node(n527,supported) :- status(o_4abdc732aa9fde88ff8d,supported).
node(n527,refuted) :- status(o_4abdc732aa9fde88ff8d,refuted).
node(n527,unknown) :- status(o_4abdc732aa9fde88ff8d,unknown).
node(n524,supported) :- node(n525,supported), node(n526,supported), node(n527,supported).
node(n524,refuted) :- node(n525,refuted).
node(n524,refuted) :- node(n526,refuted).
node(n524,refuted) :- node(n527,refuted).
node(n524,unknown) :- \+ node(n524,supported), \+ node(n524,refuted).
node(n523,refuted) :- node(n524,refuted), node(n9,refuted).
node(n523,supported) :- node(n524,supported).
node(n523,supported) :- node(n9,supported).
node(n523,unknown) :- \+ node(n523,supported), \+ node(n523,refuted).
verdict(c_fb1fa3e2494fe8d4,supported) :- node(n523,supported).
query(verdict(c_fb1fa3e2494fe8d4,supported)).
verdict(c_fb1fa3e2494fe8d4,refuted) :- node(n523,refuted).
query(verdict(c_fb1fa3e2494fe8d4,refuted)).
verdict(c_fb1fa3e2494fe8d4,unknown) :- node(n523,unknown).
query(verdict(c_fb1fa3e2494fe8d4,unknown)).
node(n530,supported) :- status(o_bd209f534526335fa87c,supported).
node(n530,refuted) :- status(o_bd209f534526335fa87c,refuted).
node(n530,unknown) :- status(o_bd209f534526335fa87c,unknown).
node(n529,supported) :- node(n525,supported), node(n526,supported), node(n527,supported), node(n530,supported).
node(n529,refuted) :- node(n525,refuted).
node(n529,refuted) :- node(n526,refuted).
node(n529,refuted) :- node(n527,refuted).
node(n529,refuted) :- node(n530,refuted).
node(n529,unknown) :- \+ node(n529,supported), \+ node(n529,refuted).
node(n528,refuted) :- node(n529,refuted), node(n9,refuted).
node(n528,supported) :- node(n529,supported).
node(n528,supported) :- node(n9,supported).
node(n528,unknown) :- \+ node(n528,supported), \+ node(n528,refuted).
verdict(c_af31d18044f3de95,supported) :- node(n528,supported).
query(verdict(c_af31d18044f3de95,supported)).
verdict(c_af31d18044f3de95,refuted) :- node(n528,refuted).
query(verdict(c_af31d18044f3de95,refuted)).
verdict(c_af31d18044f3de95,unknown) :- node(n528,unknown).
query(verdict(c_af31d18044f3de95,unknown)).
node(n533,supported) :- status(o_6979a5238ef812a40a6e,supported).
node(n533,refuted) :- status(o_6979a5238ef812a40a6e,refuted).
node(n533,unknown) :- status(o_6979a5238ef812a40a6e,unknown).
node(n534,supported) :- status(o_4eedf291829845e0033a,supported).
node(n534,refuted) :- status(o_4eedf291829845e0033a,refuted).
node(n534,unknown) :- status(o_4eedf291829845e0033a,unknown).
node(n532,supported) :- node(n525,supported), node(n526,supported), node(n527,supported), node(n530,supported), node(n533,supported), node(n534,supported).
node(n532,refuted) :- node(n525,refuted).
node(n532,refuted) :- node(n526,refuted).
node(n532,refuted) :- node(n527,refuted).
node(n532,refuted) :- node(n530,refuted).
node(n532,refuted) :- node(n533,refuted).
node(n532,refuted) :- node(n534,refuted).
node(n532,unknown) :- \+ node(n532,supported), \+ node(n532,refuted).
node(n531,refuted) :- node(n532,refuted), node(n9,refuted).
node(n531,supported) :- node(n532,supported).
node(n531,supported) :- node(n9,supported).
node(n531,unknown) :- \+ node(n531,supported), \+ node(n531,refuted).
verdict(c_b09d0ba8ee36ff5b,supported) :- node(n531,supported).
query(verdict(c_b09d0ba8ee36ff5b,supported)).
verdict(c_b09d0ba8ee36ff5b,refuted) :- node(n531,refuted).
query(verdict(c_b09d0ba8ee36ff5b,refuted)).
verdict(c_b09d0ba8ee36ff5b,unknown) :- node(n531,unknown).
query(verdict(c_b09d0ba8ee36ff5b,unknown)).
node(n537,supported) :- status(o_b3de788de87fd49a8b5b,supported).
node(n537,refuted) :- status(o_b3de788de87fd49a8b5b,refuted).
node(n537,unknown) :- status(o_b3de788de87fd49a8b5b,unknown).
node(n536,supported) :- node(n525,supported), node(n526,supported), node(n537,supported).
node(n536,refuted) :- node(n525,refuted).
node(n536,refuted) :- node(n526,refuted).
node(n536,refuted) :- node(n537,refuted).
node(n536,unknown) :- \+ node(n536,supported), \+ node(n536,refuted).
node(n535,refuted) :- node(n536,refuted), node(n9,refuted).
node(n535,supported) :- node(n536,supported).
node(n535,supported) :- node(n9,supported).
node(n535,unknown) :- \+ node(n535,supported), \+ node(n535,refuted).
verdict(c_06ccfbd577c6ddf3,supported) :- node(n535,supported).
query(verdict(c_06ccfbd577c6ddf3,supported)).
verdict(c_06ccfbd577c6ddf3,refuted) :- node(n535,refuted).
query(verdict(c_06ccfbd577c6ddf3,refuted)).
verdict(c_06ccfbd577c6ddf3,unknown) :- node(n535,unknown).
query(verdict(c_06ccfbd577c6ddf3,unknown)).
node(n539,supported) :- node(n525,supported), node(n526,supported), node(n527,supported), node(n537,supported).
node(n539,refuted) :- node(n525,refuted).
node(n539,refuted) :- node(n526,refuted).
node(n539,refuted) :- node(n527,refuted).
node(n539,refuted) :- node(n537,refuted).
node(n539,unknown) :- \+ node(n539,supported), \+ node(n539,refuted).
node(n538,refuted) :- node(n539,refuted), node(n9,refuted).
node(n538,supported) :- node(n539,supported).
node(n538,supported) :- node(n9,supported).
node(n538,unknown) :- \+ node(n538,supported), \+ node(n538,refuted).
verdict(c_804d94d36563de19,supported) :- node(n538,supported).
query(verdict(c_804d94d36563de19,supported)).
verdict(c_804d94d36563de19,refuted) :- node(n538,refuted).
query(verdict(c_804d94d36563de19,refuted)).
verdict(c_804d94d36563de19,unknown) :- node(n538,unknown).
query(verdict(c_804d94d36563de19,unknown)).
node(n542,supported) :- status(o_eb4ce3732a7138390c3d,supported).
node(n542,refuted) :- status(o_eb4ce3732a7138390c3d,refuted).
node(n542,unknown) :- status(o_eb4ce3732a7138390c3d,unknown).
node(n543,supported) :- status(o_74cb5f7fc428f04be3dd,supported).
node(n543,refuted) :- status(o_74cb5f7fc428f04be3dd,refuted).
node(n543,unknown) :- status(o_74cb5f7fc428f04be3dd,unknown).
node(n544,supported) :- status(o_7ecfe705aca39aef2c2a,supported).
node(n544,refuted) :- status(o_7ecfe705aca39aef2c2a,refuted).
node(n544,unknown) :- status(o_7ecfe705aca39aef2c2a,unknown).
node(n541,supported) :- node(n542,supported), node(n543,supported), node(n544,supported).
node(n541,refuted) :- node(n542,refuted).
node(n541,refuted) :- node(n543,refuted).
node(n541,refuted) :- node(n544,refuted).
node(n541,unknown) :- \+ node(n541,supported), \+ node(n541,refuted).
node(n540,refuted) :- node(n541,refuted), node(n9,refuted).
node(n540,supported) :- node(n541,supported).
node(n540,supported) :- node(n9,supported).
node(n540,unknown) :- \+ node(n540,supported), \+ node(n540,refuted).
verdict(c_a141e1e99051b02e,supported) :- node(n540,supported).
query(verdict(c_a141e1e99051b02e,supported)).
verdict(c_a141e1e99051b02e,refuted) :- node(n540,refuted).
query(verdict(c_a141e1e99051b02e,refuted)).
verdict(c_a141e1e99051b02e,unknown) :- node(n540,unknown).
query(verdict(c_a141e1e99051b02e,unknown)).
node(n547,supported) :- status(o_5f20e589a8df76aa1918,supported).
node(n547,refuted) :- status(o_5f20e589a8df76aa1918,refuted).
node(n547,unknown) :- status(o_5f20e589a8df76aa1918,unknown).
node(n546,supported) :- node(n542,supported), node(n543,supported), node(n544,supported), node(n547,supported).
node(n546,refuted) :- node(n542,refuted).
node(n546,refuted) :- node(n543,refuted).
node(n546,refuted) :- node(n544,refuted).
node(n546,refuted) :- node(n547,refuted).
node(n546,unknown) :- \+ node(n546,supported), \+ node(n546,refuted).
node(n545,refuted) :- node(n546,refuted), node(n9,refuted).
node(n545,supported) :- node(n546,supported).
node(n545,supported) :- node(n9,supported).
node(n545,unknown) :- \+ node(n545,supported), \+ node(n545,refuted).
verdict(c_dd85477bfc93db6d,supported) :- node(n545,supported).
query(verdict(c_dd85477bfc93db6d,supported)).
verdict(c_dd85477bfc93db6d,refuted) :- node(n545,refuted).
query(verdict(c_dd85477bfc93db6d,refuted)).
verdict(c_dd85477bfc93db6d,unknown) :- node(n545,unknown).
query(verdict(c_dd85477bfc93db6d,unknown)).
node(n550,supported) :- status(o_30aba41fcae31f3066a3,supported).
node(n550,refuted) :- status(o_30aba41fcae31f3066a3,refuted).
node(n550,unknown) :- status(o_30aba41fcae31f3066a3,unknown).
node(n551,supported) :- status(o_214f92c75ed48b6786f2,supported).
node(n551,refuted) :- status(o_214f92c75ed48b6786f2,refuted).
node(n551,unknown) :- status(o_214f92c75ed48b6786f2,unknown).
node(n549,supported) :- node(n542,supported), node(n543,supported), node(n544,supported), node(n547,supported), node(n550,supported), node(n551,supported).
node(n549,refuted) :- node(n542,refuted).
node(n549,refuted) :- node(n543,refuted).
node(n549,refuted) :- node(n544,refuted).
node(n549,refuted) :- node(n547,refuted).
node(n549,refuted) :- node(n550,refuted).
node(n549,refuted) :- node(n551,refuted).
node(n549,unknown) :- \+ node(n549,supported), \+ node(n549,refuted).
node(n548,refuted) :- node(n549,refuted), node(n9,refuted).
node(n548,supported) :- node(n549,supported).
node(n548,supported) :- node(n9,supported).
node(n548,unknown) :- \+ node(n548,supported), \+ node(n548,refuted).
verdict(c_9d84265723cbf9d1,supported) :- node(n548,supported).
query(verdict(c_9d84265723cbf9d1,supported)).
verdict(c_9d84265723cbf9d1,refuted) :- node(n548,refuted).
query(verdict(c_9d84265723cbf9d1,refuted)).
verdict(c_9d84265723cbf9d1,unknown) :- node(n548,unknown).
query(verdict(c_9d84265723cbf9d1,unknown)).
node(n554,supported) :- status(o_b98839ae7e8bd865fa50,supported).
node(n554,refuted) :- status(o_b98839ae7e8bd865fa50,refuted).
node(n554,unknown) :- status(o_b98839ae7e8bd865fa50,unknown).
node(n553,supported) :- node(n542,supported), node(n543,supported), node(n554,supported).
node(n553,refuted) :- node(n542,refuted).
node(n553,refuted) :- node(n543,refuted).
node(n553,refuted) :- node(n554,refuted).
node(n553,unknown) :- \+ node(n553,supported), \+ node(n553,refuted).
node(n552,refuted) :- node(n553,refuted), node(n9,refuted).
node(n552,supported) :- node(n553,supported).
node(n552,supported) :- node(n9,supported).
node(n552,unknown) :- \+ node(n552,supported), \+ node(n552,refuted).
verdict(c_1a49921c73c13bdb,supported) :- node(n552,supported).
query(verdict(c_1a49921c73c13bdb,supported)).
verdict(c_1a49921c73c13bdb,refuted) :- node(n552,refuted).
query(verdict(c_1a49921c73c13bdb,refuted)).
verdict(c_1a49921c73c13bdb,unknown) :- node(n552,unknown).
query(verdict(c_1a49921c73c13bdb,unknown)).
node(n556,supported) :- node(n542,supported), node(n543,supported), node(n544,supported), node(n554,supported).
node(n556,refuted) :- node(n542,refuted).
node(n556,refuted) :- node(n543,refuted).
node(n556,refuted) :- node(n544,refuted).
node(n556,refuted) :- node(n554,refuted).
node(n556,unknown) :- \+ node(n556,supported), \+ node(n556,refuted).
node(n555,refuted) :- node(n556,refuted), node(n9,refuted).
node(n555,supported) :- node(n556,supported).
node(n555,supported) :- node(n9,supported).
node(n555,unknown) :- \+ node(n555,supported), \+ node(n555,refuted).
verdict(c_ffde6d951063c9a8,supported) :- node(n555,supported).
query(verdict(c_ffde6d951063c9a8,supported)).
verdict(c_ffde6d951063c9a8,refuted) :- node(n555,refuted).
query(verdict(c_ffde6d951063c9a8,refuted)).
verdict(c_ffde6d951063c9a8,unknown) :- node(n555,unknown).
query(verdict(c_ffde6d951063c9a8,unknown)).
node(n559,supported) :- status(o_f90ffc761fcc55a6452d,supported).
node(n559,refuted) :- status(o_f90ffc761fcc55a6452d,refuted).
node(n559,unknown) :- status(o_f90ffc761fcc55a6452d,unknown).
node(n560,supported) :- status(o_2db7d1b502b9c07adf60,supported).
node(n560,refuted) :- status(o_2db7d1b502b9c07adf60,refuted).
node(n560,unknown) :- status(o_2db7d1b502b9c07adf60,unknown).
node(n561,supported) :- status(o_41eccfe5d76a353aca66,supported).
node(n561,refuted) :- status(o_41eccfe5d76a353aca66,refuted).
node(n561,unknown) :- status(o_41eccfe5d76a353aca66,unknown).
node(n558,supported) :- node(n559,supported), node(n560,supported), node(n561,supported).
node(n558,refuted) :- node(n559,refuted).
node(n558,refuted) :- node(n560,refuted).
node(n558,refuted) :- node(n561,refuted).
node(n558,unknown) :- \+ node(n558,supported), \+ node(n558,refuted).
node(n557,refuted) :- node(n558,refuted), node(n9,refuted).
node(n557,supported) :- node(n558,supported).
node(n557,supported) :- node(n9,supported).
node(n557,unknown) :- \+ node(n557,supported), \+ node(n557,refuted).
verdict(c_169efa6d414249ee,supported) :- node(n557,supported).
query(verdict(c_169efa6d414249ee,supported)).
verdict(c_169efa6d414249ee,refuted) :- node(n557,refuted).
query(verdict(c_169efa6d414249ee,refuted)).
verdict(c_169efa6d414249ee,unknown) :- node(n557,unknown).
query(verdict(c_169efa6d414249ee,unknown)).
node(n564,supported) :- status(o_2acadda5d9f63382bd08,supported).
node(n564,refuted) :- status(o_2acadda5d9f63382bd08,refuted).
node(n564,unknown) :- status(o_2acadda5d9f63382bd08,unknown).
node(n563,supported) :- node(n559,supported), node(n560,supported), node(n561,supported), node(n564,supported).
node(n563,refuted) :- node(n559,refuted).
node(n563,refuted) :- node(n560,refuted).
node(n563,refuted) :- node(n561,refuted).
node(n563,refuted) :- node(n564,refuted).
node(n563,unknown) :- \+ node(n563,supported), \+ node(n563,refuted).
node(n562,refuted) :- node(n563,refuted), node(n9,refuted).
node(n562,supported) :- node(n563,supported).
node(n562,supported) :- node(n9,supported).
node(n562,unknown) :- \+ node(n562,supported), \+ node(n562,refuted).
verdict(c_44b9ba2ba8fd4222,supported) :- node(n562,supported).
query(verdict(c_44b9ba2ba8fd4222,supported)).
verdict(c_44b9ba2ba8fd4222,refuted) :- node(n562,refuted).
query(verdict(c_44b9ba2ba8fd4222,refuted)).
verdict(c_44b9ba2ba8fd4222,unknown) :- node(n562,unknown).
query(verdict(c_44b9ba2ba8fd4222,unknown)).
node(n567,supported) :- status(o_bd44423cc9dde20859d4,supported).
node(n567,refuted) :- status(o_bd44423cc9dde20859d4,refuted).
node(n567,unknown) :- status(o_bd44423cc9dde20859d4,unknown).
node(n568,supported) :- status(o_54425c78960fea0fad18,supported).
node(n568,refuted) :- status(o_54425c78960fea0fad18,refuted).
node(n568,unknown) :- status(o_54425c78960fea0fad18,unknown).
node(n566,supported) :- node(n559,supported), node(n560,supported), node(n561,supported), node(n564,supported), node(n567,supported), node(n568,supported).
node(n566,refuted) :- node(n559,refuted).
node(n566,refuted) :- node(n560,refuted).
node(n566,refuted) :- node(n561,refuted).
node(n566,refuted) :- node(n564,refuted).
node(n566,refuted) :- node(n567,refuted).
node(n566,refuted) :- node(n568,refuted).
node(n566,unknown) :- \+ node(n566,supported), \+ node(n566,refuted).
node(n565,refuted) :- node(n566,refuted), node(n9,refuted).
node(n565,supported) :- node(n566,supported).
node(n565,supported) :- node(n9,supported).
node(n565,unknown) :- \+ node(n565,supported), \+ node(n565,refuted).
verdict(c_05bc45256f32c0ab,supported) :- node(n565,supported).
query(verdict(c_05bc45256f32c0ab,supported)).
verdict(c_05bc45256f32c0ab,refuted) :- node(n565,refuted).
query(verdict(c_05bc45256f32c0ab,refuted)).
verdict(c_05bc45256f32c0ab,unknown) :- node(n565,unknown).
query(verdict(c_05bc45256f32c0ab,unknown)).
node(n571,supported) :- status(o_e30c7d8ed67e577c28bb,supported).
node(n571,refuted) :- status(o_e30c7d8ed67e577c28bb,refuted).
node(n571,unknown) :- status(o_e30c7d8ed67e577c28bb,unknown).
node(n570,supported) :- node(n559,supported), node(n560,supported), node(n571,supported).
node(n570,refuted) :- node(n559,refuted).
node(n570,refuted) :- node(n560,refuted).
node(n570,refuted) :- node(n571,refuted).
node(n570,unknown) :- \+ node(n570,supported), \+ node(n570,refuted).
node(n569,refuted) :- node(n570,refuted), node(n9,refuted).
node(n569,supported) :- node(n570,supported).
node(n569,supported) :- node(n9,supported).
node(n569,unknown) :- \+ node(n569,supported), \+ node(n569,refuted).
verdict(c_aa70023cf6bc4868,supported) :- node(n569,supported).
query(verdict(c_aa70023cf6bc4868,supported)).
verdict(c_aa70023cf6bc4868,refuted) :- node(n569,refuted).
query(verdict(c_aa70023cf6bc4868,refuted)).
verdict(c_aa70023cf6bc4868,unknown) :- node(n569,unknown).
query(verdict(c_aa70023cf6bc4868,unknown)).
node(n573,supported) :- node(n559,supported), node(n560,supported), node(n561,supported), node(n571,supported).
node(n573,refuted) :- node(n559,refuted).
node(n573,refuted) :- node(n560,refuted).
node(n573,refuted) :- node(n561,refuted).
node(n573,refuted) :- node(n571,refuted).
node(n573,unknown) :- \+ node(n573,supported), \+ node(n573,refuted).
node(n572,refuted) :- node(n573,refuted), node(n9,refuted).
node(n572,supported) :- node(n573,supported).
node(n572,supported) :- node(n9,supported).
node(n572,unknown) :- \+ node(n572,supported), \+ node(n572,refuted).
verdict(c_87d12c35833266d2,supported) :- node(n572,supported).
query(verdict(c_87d12c35833266d2,supported)).
verdict(c_87d12c35833266d2,refuted) :- node(n572,refuted).
query(verdict(c_87d12c35833266d2,refuted)).
verdict(c_87d12c35833266d2,unknown) :- node(n572,unknown).
query(verdict(c_87d12c35833266d2,unknown)).
node(n576,supported) :- status(o_2e6a6d2fe5da3f78515b,supported).
node(n576,refuted) :- status(o_2e6a6d2fe5da3f78515b,refuted).
node(n576,unknown) :- status(o_2e6a6d2fe5da3f78515b,unknown).
node(n577,supported) :- status(o_e235eec835637a147400,supported).
node(n577,refuted) :- status(o_e235eec835637a147400,refuted).
node(n577,unknown) :- status(o_e235eec835637a147400,unknown).
node(n578,supported) :- status(o_0f5f2749dc93af654e51,supported).
node(n578,refuted) :- status(o_0f5f2749dc93af654e51,refuted).
node(n578,unknown) :- status(o_0f5f2749dc93af654e51,unknown).
node(n575,supported) :- node(n576,supported), node(n577,supported), node(n578,supported).
node(n575,refuted) :- node(n576,refuted).
node(n575,refuted) :- node(n577,refuted).
node(n575,refuted) :- node(n578,refuted).
node(n575,unknown) :- \+ node(n575,supported), \+ node(n575,refuted).
node(n574,refuted) :- node(n575,refuted), node(n9,refuted).
node(n574,supported) :- node(n575,supported).
node(n574,supported) :- node(n9,supported).
node(n574,unknown) :- \+ node(n574,supported), \+ node(n574,refuted).
verdict(c_255592629091a269,supported) :- node(n574,supported).
query(verdict(c_255592629091a269,supported)).
verdict(c_255592629091a269,refuted) :- node(n574,refuted).
query(verdict(c_255592629091a269,refuted)).
verdict(c_255592629091a269,unknown) :- node(n574,unknown).
query(verdict(c_255592629091a269,unknown)).
node(n581,supported) :- status(o_717c6c9ac3391e449ef3,supported).
node(n581,refuted) :- status(o_717c6c9ac3391e449ef3,refuted).
node(n581,unknown) :- status(o_717c6c9ac3391e449ef3,unknown).
node(n580,supported) :- node(n576,supported), node(n577,supported), node(n578,supported), node(n581,supported).
node(n580,refuted) :- node(n576,refuted).
node(n580,refuted) :- node(n577,refuted).
node(n580,refuted) :- node(n578,refuted).
node(n580,refuted) :- node(n581,refuted).
node(n580,unknown) :- \+ node(n580,supported), \+ node(n580,refuted).
node(n579,refuted) :- node(n580,refuted), node(n9,refuted).
node(n579,supported) :- node(n580,supported).
node(n579,supported) :- node(n9,supported).
node(n579,unknown) :- \+ node(n579,supported), \+ node(n579,refuted).
verdict(c_d974220eea0f2007,supported) :- node(n579,supported).
query(verdict(c_d974220eea0f2007,supported)).
verdict(c_d974220eea0f2007,refuted) :- node(n579,refuted).
query(verdict(c_d974220eea0f2007,refuted)).
verdict(c_d974220eea0f2007,unknown) :- node(n579,unknown).
query(verdict(c_d974220eea0f2007,unknown)).
node(n584,supported) :- status(o_2f13f140666921abe284,supported).
node(n584,refuted) :- status(o_2f13f140666921abe284,refuted).
node(n584,unknown) :- status(o_2f13f140666921abe284,unknown).
node(n585,supported) :- status(o_c99b0a1ffb85579ca7cf,supported).
node(n585,refuted) :- status(o_c99b0a1ffb85579ca7cf,refuted).
node(n585,unknown) :- status(o_c99b0a1ffb85579ca7cf,unknown).
node(n583,supported) :- node(n576,supported), node(n577,supported), node(n578,supported), node(n581,supported), node(n584,supported), node(n585,supported).
node(n583,refuted) :- node(n576,refuted).
node(n583,refuted) :- node(n577,refuted).
node(n583,refuted) :- node(n578,refuted).
node(n583,refuted) :- node(n581,refuted).
node(n583,refuted) :- node(n584,refuted).
node(n583,refuted) :- node(n585,refuted).
node(n583,unknown) :- \+ node(n583,supported), \+ node(n583,refuted).
node(n582,refuted) :- node(n583,refuted), node(n9,refuted).
node(n582,supported) :- node(n583,supported).
node(n582,supported) :- node(n9,supported).
node(n582,unknown) :- \+ node(n582,supported), \+ node(n582,refuted).
verdict(c_5cfafd013c599973,supported) :- node(n582,supported).
query(verdict(c_5cfafd013c599973,supported)).
verdict(c_5cfafd013c599973,refuted) :- node(n582,refuted).
query(verdict(c_5cfafd013c599973,refuted)).
verdict(c_5cfafd013c599973,unknown) :- node(n582,unknown).
query(verdict(c_5cfafd013c599973,unknown)).
node(n588,supported) :- status(o_09d5c61a5a58987b24dd,supported).
node(n588,refuted) :- status(o_09d5c61a5a58987b24dd,refuted).
node(n588,unknown) :- status(o_09d5c61a5a58987b24dd,unknown).
node(n587,supported) :- node(n576,supported), node(n577,supported), node(n588,supported).
node(n587,refuted) :- node(n576,refuted).
node(n587,refuted) :- node(n577,refuted).
node(n587,refuted) :- node(n588,refuted).
node(n587,unknown) :- \+ node(n587,supported), \+ node(n587,refuted).
node(n586,refuted) :- node(n587,refuted), node(n9,refuted).
node(n586,supported) :- node(n587,supported).
node(n586,supported) :- node(n9,supported).
node(n586,unknown) :- \+ node(n586,supported), \+ node(n586,refuted).
verdict(c_8aae57e77276c3a5,supported) :- node(n586,supported).
query(verdict(c_8aae57e77276c3a5,supported)).
verdict(c_8aae57e77276c3a5,refuted) :- node(n586,refuted).
query(verdict(c_8aae57e77276c3a5,refuted)).
verdict(c_8aae57e77276c3a5,unknown) :- node(n586,unknown).
query(verdict(c_8aae57e77276c3a5,unknown)).
node(n590,supported) :- node(n576,supported), node(n577,supported), node(n578,supported), node(n588,supported).
node(n590,refuted) :- node(n576,refuted).
node(n590,refuted) :- node(n577,refuted).
node(n590,refuted) :- node(n578,refuted).
node(n590,refuted) :- node(n588,refuted).
node(n590,unknown) :- \+ node(n590,supported), \+ node(n590,refuted).
node(n589,refuted) :- node(n590,refuted), node(n9,refuted).
node(n589,supported) :- node(n590,supported).
node(n589,supported) :- node(n9,supported).
node(n589,unknown) :- \+ node(n589,supported), \+ node(n589,refuted).
verdict(c_fe5acdb2805484a4,supported) :- node(n589,supported).
query(verdict(c_fe5acdb2805484a4,supported)).
verdict(c_fe5acdb2805484a4,refuted) :- node(n589,refuted).
query(verdict(c_fe5acdb2805484a4,refuted)).
verdict(c_fe5acdb2805484a4,unknown) :- node(n589,unknown).
query(verdict(c_fe5acdb2805484a4,unknown)).
node(n593,supported) :- status(o_093e826d8b75d5a0fccf,supported).
node(n593,refuted) :- status(o_093e826d8b75d5a0fccf,refuted).
node(n593,unknown) :- status(o_093e826d8b75d5a0fccf,unknown).
node(n594,supported) :- status(o_91ec70e05f090cc2f898,supported).
node(n594,refuted) :- status(o_91ec70e05f090cc2f898,refuted).
node(n594,unknown) :- status(o_91ec70e05f090cc2f898,unknown).
node(n595,supported) :- status(o_ae07b2d9c4914c6c0cb8,supported).
node(n595,refuted) :- status(o_ae07b2d9c4914c6c0cb8,refuted).
node(n595,unknown) :- status(o_ae07b2d9c4914c6c0cb8,unknown).
node(n592,supported) :- node(n593,supported), node(n594,supported), node(n595,supported).
node(n592,refuted) :- node(n593,refuted).
node(n592,refuted) :- node(n594,refuted).
node(n592,refuted) :- node(n595,refuted).
node(n592,unknown) :- \+ node(n592,supported), \+ node(n592,refuted).
node(n591,refuted) :- node(n592,refuted), node(n9,refuted).
node(n591,supported) :- node(n592,supported).
node(n591,supported) :- node(n9,supported).
node(n591,unknown) :- \+ node(n591,supported), \+ node(n591,refuted).
verdict(c_c08d0576405e6909,supported) :- node(n591,supported).
query(verdict(c_c08d0576405e6909,supported)).
verdict(c_c08d0576405e6909,refuted) :- node(n591,refuted).
query(verdict(c_c08d0576405e6909,refuted)).
verdict(c_c08d0576405e6909,unknown) :- node(n591,unknown).
query(verdict(c_c08d0576405e6909,unknown)).
node(n598,supported) :- status(o_76a68c80b2eec0603456,supported).
node(n598,refuted) :- status(o_76a68c80b2eec0603456,refuted).
node(n598,unknown) :- status(o_76a68c80b2eec0603456,unknown).
node(n597,supported) :- node(n593,supported), node(n594,supported), node(n595,supported), node(n598,supported).
node(n597,refuted) :- node(n593,refuted).
node(n597,refuted) :- node(n594,refuted).
node(n597,refuted) :- node(n595,refuted).
node(n597,refuted) :- node(n598,refuted).
node(n597,unknown) :- \+ node(n597,supported), \+ node(n597,refuted).
node(n596,refuted) :- node(n597,refuted), node(n9,refuted).
node(n596,supported) :- node(n597,supported).
node(n596,supported) :- node(n9,supported).
node(n596,unknown) :- \+ node(n596,supported), \+ node(n596,refuted).
verdict(c_e48c27fd47dc40c4,supported) :- node(n596,supported).
query(verdict(c_e48c27fd47dc40c4,supported)).
verdict(c_e48c27fd47dc40c4,refuted) :- node(n596,refuted).
query(verdict(c_e48c27fd47dc40c4,refuted)).
verdict(c_e48c27fd47dc40c4,unknown) :- node(n596,unknown).
query(verdict(c_e48c27fd47dc40c4,unknown)).
node(n601,supported) :- status(o_9797de34e3ada7a0b237,supported).
node(n601,refuted) :- status(o_9797de34e3ada7a0b237,refuted).
node(n601,unknown) :- status(o_9797de34e3ada7a0b237,unknown).
node(n602,supported) :- status(o_537b1c90a503ff637d23,supported).
node(n602,refuted) :- status(o_537b1c90a503ff637d23,refuted).
node(n602,unknown) :- status(o_537b1c90a503ff637d23,unknown).
node(n600,supported) :- node(n593,supported), node(n594,supported), node(n595,supported), node(n598,supported), node(n601,supported), node(n602,supported).
node(n600,refuted) :- node(n593,refuted).
node(n600,refuted) :- node(n594,refuted).
node(n600,refuted) :- node(n595,refuted).
node(n600,refuted) :- node(n598,refuted).
node(n600,refuted) :- node(n601,refuted).
node(n600,refuted) :- node(n602,refuted).
node(n600,unknown) :- \+ node(n600,supported), \+ node(n600,refuted).
node(n599,refuted) :- node(n600,refuted), node(n9,refuted).
node(n599,supported) :- node(n600,supported).
node(n599,supported) :- node(n9,supported).
node(n599,unknown) :- \+ node(n599,supported), \+ node(n599,refuted).
verdict(c_a88c8b6c7f23a145,supported) :- node(n599,supported).
query(verdict(c_a88c8b6c7f23a145,supported)).
verdict(c_a88c8b6c7f23a145,refuted) :- node(n599,refuted).
query(verdict(c_a88c8b6c7f23a145,refuted)).
verdict(c_a88c8b6c7f23a145,unknown) :- node(n599,unknown).
query(verdict(c_a88c8b6c7f23a145,unknown)).
node(n605,supported) :- status(o_bbc86d529139754841f3,supported).
node(n605,refuted) :- status(o_bbc86d529139754841f3,refuted).
node(n605,unknown) :- status(o_bbc86d529139754841f3,unknown).
node(n604,supported) :- node(n593,supported), node(n594,supported), node(n605,supported).
node(n604,refuted) :- node(n593,refuted).
node(n604,refuted) :- node(n594,refuted).
node(n604,refuted) :- node(n605,refuted).
node(n604,unknown) :- \+ node(n604,supported), \+ node(n604,refuted).
node(n603,refuted) :- node(n604,refuted), node(n9,refuted).
node(n603,supported) :- node(n604,supported).
node(n603,supported) :- node(n9,supported).
node(n603,unknown) :- \+ node(n603,supported), \+ node(n603,refuted).
verdict(c_0f3c7ce8bf7b9e2c,supported) :- node(n603,supported).
query(verdict(c_0f3c7ce8bf7b9e2c,supported)).
verdict(c_0f3c7ce8bf7b9e2c,refuted) :- node(n603,refuted).
query(verdict(c_0f3c7ce8bf7b9e2c,refuted)).
verdict(c_0f3c7ce8bf7b9e2c,unknown) :- node(n603,unknown).
query(verdict(c_0f3c7ce8bf7b9e2c,unknown)).
node(n607,supported) :- node(n593,supported), node(n594,supported), node(n595,supported), node(n605,supported).
node(n607,refuted) :- node(n593,refuted).
node(n607,refuted) :- node(n594,refuted).
node(n607,refuted) :- node(n595,refuted).
node(n607,refuted) :- node(n605,refuted).
node(n607,unknown) :- \+ node(n607,supported), \+ node(n607,refuted).
node(n606,refuted) :- node(n607,refuted), node(n9,refuted).
node(n606,supported) :- node(n607,supported).
node(n606,supported) :- node(n9,supported).
node(n606,unknown) :- \+ node(n606,supported), \+ node(n606,refuted).
verdict(c_bcc37fa872606c9f,supported) :- node(n606,supported).
query(verdict(c_bcc37fa872606c9f,supported)).
verdict(c_bcc37fa872606c9f,refuted) :- node(n606,refuted).
query(verdict(c_bcc37fa872606c9f,refuted)).
verdict(c_bcc37fa872606c9f,unknown) :- node(n606,unknown).
query(verdict(c_bcc37fa872606c9f,unknown)).
node(n610,supported) :- status(o_ff56425e2313cb2834b6,supported).
node(n610,refuted) :- status(o_ff56425e2313cb2834b6,refuted).
node(n610,unknown) :- status(o_ff56425e2313cb2834b6,unknown).
node(n611,supported) :- status(o_a68587f531b8bc09f6d6,supported).
node(n611,refuted) :- status(o_a68587f531b8bc09f6d6,refuted).
node(n611,unknown) :- status(o_a68587f531b8bc09f6d6,unknown).
node(n612,supported) :- status(o_4fd3ccf9c7eb5d3e082d,supported).
node(n612,refuted) :- status(o_4fd3ccf9c7eb5d3e082d,refuted).
node(n612,unknown) :- status(o_4fd3ccf9c7eb5d3e082d,unknown).
node(n609,supported) :- node(n610,supported), node(n611,supported), node(n612,supported).
node(n609,refuted) :- node(n610,refuted).
node(n609,refuted) :- node(n611,refuted).
node(n609,refuted) :- node(n612,refuted).
node(n609,unknown) :- \+ node(n609,supported), \+ node(n609,refuted).
node(n608,refuted) :- node(n609,refuted), node(n9,refuted).
node(n608,supported) :- node(n609,supported).
node(n608,supported) :- node(n9,supported).
node(n608,unknown) :- \+ node(n608,supported), \+ node(n608,refuted).
verdict(c_55d675353516b19a,supported) :- node(n608,supported).
query(verdict(c_55d675353516b19a,supported)).
verdict(c_55d675353516b19a,refuted) :- node(n608,refuted).
query(verdict(c_55d675353516b19a,refuted)).
verdict(c_55d675353516b19a,unknown) :- node(n608,unknown).
query(verdict(c_55d675353516b19a,unknown)).
node(n615,supported) :- status(o_4dce5c29c2f6ac42cb1c,supported).
node(n615,refuted) :- status(o_4dce5c29c2f6ac42cb1c,refuted).
node(n615,unknown) :- status(o_4dce5c29c2f6ac42cb1c,unknown).
node(n614,supported) :- node(n610,supported), node(n611,supported), node(n612,supported), node(n615,supported).
node(n614,refuted) :- node(n610,refuted).
node(n614,refuted) :- node(n611,refuted).
node(n614,refuted) :- node(n612,refuted).
node(n614,refuted) :- node(n615,refuted).
node(n614,unknown) :- \+ node(n614,supported), \+ node(n614,refuted).
node(n613,refuted) :- node(n614,refuted), node(n9,refuted).
node(n613,supported) :- node(n614,supported).
node(n613,supported) :- node(n9,supported).
node(n613,unknown) :- \+ node(n613,supported), \+ node(n613,refuted).
verdict(c_24f21e8a2673050d,supported) :- node(n613,supported).
query(verdict(c_24f21e8a2673050d,supported)).
verdict(c_24f21e8a2673050d,refuted) :- node(n613,refuted).
query(verdict(c_24f21e8a2673050d,refuted)).
verdict(c_24f21e8a2673050d,unknown) :- node(n613,unknown).
query(verdict(c_24f21e8a2673050d,unknown)).
node(n618,supported) :- status(o_c35b9bc02daec097b521,supported).
node(n618,refuted) :- status(o_c35b9bc02daec097b521,refuted).
node(n618,unknown) :- status(o_c35b9bc02daec097b521,unknown).
node(n619,supported) :- status(o_8a6a09f96c2b358aa588,supported).
node(n619,refuted) :- status(o_8a6a09f96c2b358aa588,refuted).
node(n619,unknown) :- status(o_8a6a09f96c2b358aa588,unknown).
node(n617,supported) :- node(n610,supported), node(n611,supported), node(n612,supported), node(n615,supported), node(n618,supported), node(n619,supported).
node(n617,refuted) :- node(n610,refuted).
node(n617,refuted) :- node(n611,refuted).
node(n617,refuted) :- node(n612,refuted).
node(n617,refuted) :- node(n615,refuted).
node(n617,refuted) :- node(n618,refuted).
node(n617,refuted) :- node(n619,refuted).
node(n617,unknown) :- \+ node(n617,supported), \+ node(n617,refuted).
node(n616,refuted) :- node(n617,refuted), node(n9,refuted).
node(n616,supported) :- node(n617,supported).
node(n616,supported) :- node(n9,supported).
node(n616,unknown) :- \+ node(n616,supported), \+ node(n616,refuted).
verdict(c_e82fca7db074c4fc,supported) :- node(n616,supported).
query(verdict(c_e82fca7db074c4fc,supported)).
verdict(c_e82fca7db074c4fc,refuted) :- node(n616,refuted).
query(verdict(c_e82fca7db074c4fc,refuted)).
verdict(c_e82fca7db074c4fc,unknown) :- node(n616,unknown).
query(verdict(c_e82fca7db074c4fc,unknown)).
node(n622,supported) :- status(o_c288045ad94b023aebe7,supported).
node(n622,refuted) :- status(o_c288045ad94b023aebe7,refuted).
node(n622,unknown) :- status(o_c288045ad94b023aebe7,unknown).
node(n621,supported) :- node(n610,supported), node(n611,supported), node(n622,supported).
node(n621,refuted) :- node(n610,refuted).
node(n621,refuted) :- node(n611,refuted).
node(n621,refuted) :- node(n622,refuted).
node(n621,unknown) :- \+ node(n621,supported), \+ node(n621,refuted).
node(n620,refuted) :- node(n621,refuted), node(n9,refuted).
node(n620,supported) :- node(n621,supported).
node(n620,supported) :- node(n9,supported).
node(n620,unknown) :- \+ node(n620,supported), \+ node(n620,refuted).
verdict(c_83338cda82fe91c9,supported) :- node(n620,supported).
query(verdict(c_83338cda82fe91c9,supported)).
verdict(c_83338cda82fe91c9,refuted) :- node(n620,refuted).
query(verdict(c_83338cda82fe91c9,refuted)).
verdict(c_83338cda82fe91c9,unknown) :- node(n620,unknown).
query(verdict(c_83338cda82fe91c9,unknown)).
node(n624,supported) :- node(n610,supported), node(n611,supported), node(n612,supported), node(n622,supported).
node(n624,refuted) :- node(n610,refuted).
node(n624,refuted) :- node(n611,refuted).
node(n624,refuted) :- node(n612,refuted).
node(n624,refuted) :- node(n622,refuted).
node(n624,unknown) :- \+ node(n624,supported), \+ node(n624,refuted).
node(n623,refuted) :- node(n624,refuted), node(n9,refuted).
node(n623,supported) :- node(n624,supported).
node(n623,supported) :- node(n9,supported).
node(n623,unknown) :- \+ node(n623,supported), \+ node(n623,refuted).
verdict(c_532fabb499408390,supported) :- node(n623,supported).
query(verdict(c_532fabb499408390,supported)).
verdict(c_532fabb499408390,refuted) :- node(n623,refuted).
query(verdict(c_532fabb499408390,refuted)).
verdict(c_532fabb499408390,unknown) :- node(n623,unknown).
query(verdict(c_532fabb499408390,unknown)).
node(n627,supported) :- status(o_950402d57bd57182cc46,supported).
node(n627,refuted) :- status(o_950402d57bd57182cc46,refuted).
node(n627,unknown) :- status(o_950402d57bd57182cc46,unknown).
node(n628,supported) :- status(o_b2e8ecc179ef5ee152f6,supported).
node(n628,refuted) :- status(o_b2e8ecc179ef5ee152f6,refuted).
node(n628,unknown) :- status(o_b2e8ecc179ef5ee152f6,unknown).
node(n629,supported) :- status(o_a5a73310a7ecafdef3e6,supported).
node(n629,refuted) :- status(o_a5a73310a7ecafdef3e6,refuted).
node(n629,unknown) :- status(o_a5a73310a7ecafdef3e6,unknown).
node(n626,supported) :- node(n627,supported), node(n628,supported), node(n629,supported).
node(n626,refuted) :- node(n627,refuted).
node(n626,refuted) :- node(n628,refuted).
node(n626,refuted) :- node(n629,refuted).
node(n626,unknown) :- \+ node(n626,supported), \+ node(n626,refuted).
node(n631,supported) :- status(o_71608d3b97b0cac582ca,supported).
node(n631,refuted) :- status(o_71608d3b97b0cac582ca,refuted).
node(n631,unknown) :- status(o_71608d3b97b0cac582ca,unknown).
node(n632,supported) :- status(o_b88a0db577e10602a8e6,supported).
node(n632,refuted) :- status(o_b88a0db577e10602a8e6,refuted).
node(n632,unknown) :- status(o_b88a0db577e10602a8e6,unknown).
node(n633,supported) :- status(o_e710780d1d6a09559a12,supported).
node(n633,refuted) :- status(o_e710780d1d6a09559a12,refuted).
node(n633,unknown) :- status(o_e710780d1d6a09559a12,unknown).
node(n630,supported) :- node(n631,supported), node(n632,supported), node(n633,supported).
node(n630,refuted) :- node(n631,refuted).
node(n630,refuted) :- node(n632,refuted).
node(n630,refuted) :- node(n633,refuted).
node(n630,unknown) :- \+ node(n630,supported), \+ node(n630,refuted).
node(n625,refuted) :- node(n626,refuted), node(n630,refuted), node(n9,refuted).
node(n625,supported) :- node(n626,supported).
node(n625,supported) :- node(n630,supported).
node(n625,supported) :- node(n9,supported).
node(n625,unknown) :- \+ node(n625,supported), \+ node(n625,refuted).
verdict(c_0662b7b8cfbb3643,supported) :- node(n625,supported).
query(verdict(c_0662b7b8cfbb3643,supported)).
verdict(c_0662b7b8cfbb3643,refuted) :- node(n625,refuted).
query(verdict(c_0662b7b8cfbb3643,refuted)).
verdict(c_0662b7b8cfbb3643,unknown) :- node(n625,unknown).
query(verdict(c_0662b7b8cfbb3643,unknown)).
node(n636,supported) :- status(o_822738dfc56925f41c59,supported).
node(n636,refuted) :- status(o_822738dfc56925f41c59,refuted).
node(n636,unknown) :- status(o_822738dfc56925f41c59,unknown).
node(n635,supported) :- node(n627,supported), node(n628,supported), node(n629,supported), node(n636,supported).
node(n635,refuted) :- node(n627,refuted).
node(n635,refuted) :- node(n628,refuted).
node(n635,refuted) :- node(n629,refuted).
node(n635,refuted) :- node(n636,refuted).
node(n635,unknown) :- \+ node(n635,supported), \+ node(n635,refuted).
node(n638,supported) :- status(o_908daf10e6423c5f2068,supported).
node(n638,refuted) :- status(o_908daf10e6423c5f2068,refuted).
node(n638,unknown) :- status(o_908daf10e6423c5f2068,unknown).
node(n637,supported) :- node(n631,supported), node(n632,supported), node(n633,supported), node(n638,supported).
node(n637,refuted) :- node(n631,refuted).
node(n637,refuted) :- node(n632,refuted).
node(n637,refuted) :- node(n633,refuted).
node(n637,refuted) :- node(n638,refuted).
node(n637,unknown) :- \+ node(n637,supported), \+ node(n637,refuted).
node(n634,refuted) :- node(n635,refuted), node(n637,refuted), node(n9,refuted).
node(n634,supported) :- node(n635,supported).
node(n634,supported) :- node(n637,supported).
node(n634,supported) :- node(n9,supported).
node(n634,unknown) :- \+ node(n634,supported), \+ node(n634,refuted).
verdict(c_36457b6617aa5520,supported) :- node(n634,supported).
query(verdict(c_36457b6617aa5520,supported)).
verdict(c_36457b6617aa5520,refuted) :- node(n634,refuted).
query(verdict(c_36457b6617aa5520,refuted)).
verdict(c_36457b6617aa5520,unknown) :- node(n634,unknown).
query(verdict(c_36457b6617aa5520,unknown)).
node(n641,supported) :- status(o_cc7c28954943edd5fc1f,supported).
node(n641,refuted) :- status(o_cc7c28954943edd5fc1f,refuted).
node(n641,unknown) :- status(o_cc7c28954943edd5fc1f,unknown).
node(n642,supported) :- status(o_4aa9ec4ec4cf47f8b4da,supported).
node(n642,refuted) :- status(o_4aa9ec4ec4cf47f8b4da,refuted).
node(n642,unknown) :- status(o_4aa9ec4ec4cf47f8b4da,unknown).
node(n640,supported) :- node(n627,supported), node(n628,supported), node(n629,supported), node(n636,supported), node(n641,supported), node(n642,supported).
node(n640,refuted) :- node(n627,refuted).
node(n640,refuted) :- node(n628,refuted).
node(n640,refuted) :- node(n629,refuted).
node(n640,refuted) :- node(n636,refuted).
node(n640,refuted) :- node(n641,refuted).
node(n640,refuted) :- node(n642,refuted).
node(n640,unknown) :- \+ node(n640,supported), \+ node(n640,refuted).
node(n644,supported) :- status(o_1005b28cd469a9b590b4,supported).
node(n644,refuted) :- status(o_1005b28cd469a9b590b4,refuted).
node(n644,unknown) :- status(o_1005b28cd469a9b590b4,unknown).
node(n645,supported) :- status(o_a85c60c303535c9e37cb,supported).
node(n645,refuted) :- status(o_a85c60c303535c9e37cb,refuted).
node(n645,unknown) :- status(o_a85c60c303535c9e37cb,unknown).
node(n643,supported) :- node(n631,supported), node(n632,supported), node(n633,supported), node(n638,supported), node(n644,supported), node(n645,supported).
node(n643,refuted) :- node(n631,refuted).
node(n643,refuted) :- node(n632,refuted).
node(n643,refuted) :- node(n633,refuted).
node(n643,refuted) :- node(n638,refuted).
node(n643,refuted) :- node(n644,refuted).
node(n643,refuted) :- node(n645,refuted).
node(n643,unknown) :- \+ node(n643,supported), \+ node(n643,refuted).
node(n639,refuted) :- node(n640,refuted), node(n643,refuted), node(n9,refuted).
node(n639,supported) :- node(n640,supported).
node(n639,supported) :- node(n643,supported).
node(n639,supported) :- node(n9,supported).
node(n639,unknown) :- \+ node(n639,supported), \+ node(n639,refuted).
verdict(c_fff6ff62c906223a,supported) :- node(n639,supported).
query(verdict(c_fff6ff62c906223a,supported)).
verdict(c_fff6ff62c906223a,refuted) :- node(n639,refuted).
query(verdict(c_fff6ff62c906223a,refuted)).
verdict(c_fff6ff62c906223a,unknown) :- node(n639,unknown).
query(verdict(c_fff6ff62c906223a,unknown)).
node(n648,supported) :- status(o_0581ee98b416b2447ed9,supported).
node(n648,refuted) :- status(o_0581ee98b416b2447ed9,refuted).
node(n648,unknown) :- status(o_0581ee98b416b2447ed9,unknown).
node(n647,supported) :- node(n627,supported), node(n628,supported), node(n648,supported).
node(n647,refuted) :- node(n627,refuted).
node(n647,refuted) :- node(n628,refuted).
node(n647,refuted) :- node(n648,refuted).
node(n647,unknown) :- \+ node(n647,supported), \+ node(n647,refuted).
node(n650,supported) :- status(o_3a42a93554340f05abf1,supported).
node(n650,refuted) :- status(o_3a42a93554340f05abf1,refuted).
node(n650,unknown) :- status(o_3a42a93554340f05abf1,unknown).
node(n649,supported) :- node(n631,supported), node(n632,supported), node(n650,supported).
node(n649,refuted) :- node(n631,refuted).
node(n649,refuted) :- node(n632,refuted).
node(n649,refuted) :- node(n650,refuted).
node(n649,unknown) :- \+ node(n649,supported), \+ node(n649,refuted).
node(n646,refuted) :- node(n647,refuted), node(n649,refuted), node(n9,refuted).
node(n646,supported) :- node(n647,supported).
node(n646,supported) :- node(n649,supported).
node(n646,supported) :- node(n9,supported).
node(n646,unknown) :- \+ node(n646,supported), \+ node(n646,refuted).
verdict(c_7fc6c5c06d4e3555,supported) :- node(n646,supported).
query(verdict(c_7fc6c5c06d4e3555,supported)).
verdict(c_7fc6c5c06d4e3555,refuted) :- node(n646,refuted).
query(verdict(c_7fc6c5c06d4e3555,refuted)).
verdict(c_7fc6c5c06d4e3555,unknown) :- node(n646,unknown).
query(verdict(c_7fc6c5c06d4e3555,unknown)).
node(n652,supported) :- node(n627,supported), node(n628,supported), node(n629,supported), node(n648,supported).
node(n652,refuted) :- node(n627,refuted).
node(n652,refuted) :- node(n628,refuted).
node(n652,refuted) :- node(n629,refuted).
node(n652,refuted) :- node(n648,refuted).
node(n652,unknown) :- \+ node(n652,supported), \+ node(n652,refuted).
node(n653,supported) :- node(n631,supported), node(n632,supported), node(n633,supported), node(n650,supported).
node(n653,refuted) :- node(n631,refuted).
node(n653,refuted) :- node(n632,refuted).
node(n653,refuted) :- node(n633,refuted).
node(n653,refuted) :- node(n650,refuted).
node(n653,unknown) :- \+ node(n653,supported), \+ node(n653,refuted).
node(n651,refuted) :- node(n652,refuted), node(n653,refuted), node(n9,refuted).
node(n651,supported) :- node(n652,supported).
node(n651,supported) :- node(n653,supported).
node(n651,supported) :- node(n9,supported).
node(n651,unknown) :- \+ node(n651,supported), \+ node(n651,refuted).
verdict(c_372633bd0265b473,supported) :- node(n651,supported).
query(verdict(c_372633bd0265b473,supported)).
verdict(c_372633bd0265b473,refuted) :- node(n651,refuted).
query(verdict(c_372633bd0265b473,refuted)).
verdict(c_372633bd0265b473,unknown) :- node(n651,unknown).
query(verdict(c_372633bd0265b473,unknown)).
node(n656,supported) :- status(o_808a01bcdf57704d23db,supported).
node(n656,refuted) :- status(o_808a01bcdf57704d23db,refuted).
node(n656,unknown) :- status(o_808a01bcdf57704d23db,unknown).
node(n657,supported) :- status(o_1d661a7f383bf2103395,supported).
node(n657,refuted) :- status(o_1d661a7f383bf2103395,refuted).
node(n657,unknown) :- status(o_1d661a7f383bf2103395,unknown).
node(n658,supported) :- status(o_60f8829b21da00e7e53e,supported).
node(n658,refuted) :- status(o_60f8829b21da00e7e53e,refuted).
node(n658,unknown) :- status(o_60f8829b21da00e7e53e,unknown).
node(n655,supported) :- node(n656,supported), node(n657,supported), node(n658,supported).
node(n655,refuted) :- node(n656,refuted).
node(n655,refuted) :- node(n657,refuted).
node(n655,refuted) :- node(n658,refuted).
node(n655,unknown) :- \+ node(n655,supported), \+ node(n655,refuted).
node(n660,supported) :- status(o_e94c430ac2f93b24acf3,supported).
node(n660,refuted) :- status(o_e94c430ac2f93b24acf3,refuted).
node(n660,unknown) :- status(o_e94c430ac2f93b24acf3,unknown).
node(n661,supported) :- status(o_a025c34aebabb11ec4df,supported).
node(n661,refuted) :- status(o_a025c34aebabb11ec4df,refuted).
node(n661,unknown) :- status(o_a025c34aebabb11ec4df,unknown).
node(n662,supported) :- status(o_0602c266670279ab9c34,supported).
node(n662,refuted) :- status(o_0602c266670279ab9c34,refuted).
node(n662,unknown) :- status(o_0602c266670279ab9c34,unknown).
node(n659,supported) :- node(n660,supported), node(n661,supported), node(n662,supported).
node(n659,refuted) :- node(n660,refuted).
node(n659,refuted) :- node(n661,refuted).
node(n659,refuted) :- node(n662,refuted).
node(n659,unknown) :- \+ node(n659,supported), \+ node(n659,refuted).
node(n654,refuted) :- node(n655,refuted), node(n659,refuted), node(n9,refuted).
node(n654,supported) :- node(n655,supported).
node(n654,supported) :- node(n659,supported).
node(n654,supported) :- node(n9,supported).
node(n654,unknown) :- \+ node(n654,supported), \+ node(n654,refuted).
verdict(c_6c19ac5420df521c,supported) :- node(n654,supported).
query(verdict(c_6c19ac5420df521c,supported)).
verdict(c_6c19ac5420df521c,refuted) :- node(n654,refuted).
query(verdict(c_6c19ac5420df521c,refuted)).
verdict(c_6c19ac5420df521c,unknown) :- node(n654,unknown).
query(verdict(c_6c19ac5420df521c,unknown)).
node(n665,supported) :- status(o_7e82e6337a4db47ebfa1,supported).
node(n665,refuted) :- status(o_7e82e6337a4db47ebfa1,refuted).
node(n665,unknown) :- status(o_7e82e6337a4db47ebfa1,unknown).
node(n664,supported) :- node(n656,supported), node(n657,supported), node(n658,supported), node(n665,supported).
node(n664,refuted) :- node(n656,refuted).
node(n664,refuted) :- node(n657,refuted).
node(n664,refuted) :- node(n658,refuted).
node(n664,refuted) :- node(n665,refuted).
node(n664,unknown) :- \+ node(n664,supported), \+ node(n664,refuted).
node(n667,supported) :- status(o_2fb7ab23989ea0ad8036,supported).
node(n667,refuted) :- status(o_2fb7ab23989ea0ad8036,refuted).
node(n667,unknown) :- status(o_2fb7ab23989ea0ad8036,unknown).
node(n666,supported) :- node(n660,supported), node(n661,supported), node(n662,supported), node(n667,supported).
node(n666,refuted) :- node(n660,refuted).
node(n666,refuted) :- node(n661,refuted).
node(n666,refuted) :- node(n662,refuted).
node(n666,refuted) :- node(n667,refuted).
node(n666,unknown) :- \+ node(n666,supported), \+ node(n666,refuted).
node(n663,refuted) :- node(n664,refuted), node(n666,refuted), node(n9,refuted).
node(n663,supported) :- node(n664,supported).
node(n663,supported) :- node(n666,supported).
node(n663,supported) :- node(n9,supported).
node(n663,unknown) :- \+ node(n663,supported), \+ node(n663,refuted).
verdict(c_1cac1dd0de350fec,supported) :- node(n663,supported).
query(verdict(c_1cac1dd0de350fec,supported)).
verdict(c_1cac1dd0de350fec,refuted) :- node(n663,refuted).
query(verdict(c_1cac1dd0de350fec,refuted)).
verdict(c_1cac1dd0de350fec,unknown) :- node(n663,unknown).
query(verdict(c_1cac1dd0de350fec,unknown)).
node(n670,supported) :- status(o_451c7e569e3d3e169268,supported).
node(n670,refuted) :- status(o_451c7e569e3d3e169268,refuted).
node(n670,unknown) :- status(o_451c7e569e3d3e169268,unknown).
node(n671,supported) :- status(o_2ac8eea810660c0b3b32,supported).
node(n671,refuted) :- status(o_2ac8eea810660c0b3b32,refuted).
node(n671,unknown) :- status(o_2ac8eea810660c0b3b32,unknown).
node(n669,supported) :- node(n656,supported), node(n657,supported), node(n658,supported), node(n665,supported), node(n670,supported), node(n671,supported).
node(n669,refuted) :- node(n656,refuted).
node(n669,refuted) :- node(n657,refuted).
node(n669,refuted) :- node(n658,refuted).
node(n669,refuted) :- node(n665,refuted).
node(n669,refuted) :- node(n670,refuted).
node(n669,refuted) :- node(n671,refuted).
node(n669,unknown) :- \+ node(n669,supported), \+ node(n669,refuted).
node(n673,supported) :- status(o_11827030d9e3b2d7abd0,supported).
node(n673,refuted) :- status(o_11827030d9e3b2d7abd0,refuted).
node(n673,unknown) :- status(o_11827030d9e3b2d7abd0,unknown).
node(n674,supported) :- status(o_08dd0cecb2759d3291c7,supported).
node(n674,refuted) :- status(o_08dd0cecb2759d3291c7,refuted).
node(n674,unknown) :- status(o_08dd0cecb2759d3291c7,unknown).
node(n672,supported) :- node(n660,supported), node(n661,supported), node(n662,supported), node(n667,supported), node(n673,supported), node(n674,supported).
node(n672,refuted) :- node(n660,refuted).
node(n672,refuted) :- node(n661,refuted).
node(n672,refuted) :- node(n662,refuted).
node(n672,refuted) :- node(n667,refuted).
node(n672,refuted) :- node(n673,refuted).
node(n672,refuted) :- node(n674,refuted).
node(n672,unknown) :- \+ node(n672,supported), \+ node(n672,refuted).
node(n668,refuted) :- node(n669,refuted), node(n672,refuted), node(n9,refuted).
node(n668,supported) :- node(n669,supported).
node(n668,supported) :- node(n672,supported).
node(n668,supported) :- node(n9,supported).
node(n668,unknown) :- \+ node(n668,supported), \+ node(n668,refuted).
verdict(c_a1df4e18a67ea1be,supported) :- node(n668,supported).
query(verdict(c_a1df4e18a67ea1be,supported)).
verdict(c_a1df4e18a67ea1be,refuted) :- node(n668,refuted).
query(verdict(c_a1df4e18a67ea1be,refuted)).
verdict(c_a1df4e18a67ea1be,unknown) :- node(n668,unknown).
query(verdict(c_a1df4e18a67ea1be,unknown)).
node(n677,supported) :- status(o_b879e4b1386f5c36efe6,supported).
node(n677,refuted) :- status(o_b879e4b1386f5c36efe6,refuted).
node(n677,unknown) :- status(o_b879e4b1386f5c36efe6,unknown).
node(n676,supported) :- node(n656,supported), node(n657,supported), node(n677,supported).
node(n676,refuted) :- node(n656,refuted).
node(n676,refuted) :- node(n657,refuted).
node(n676,refuted) :- node(n677,refuted).
node(n676,unknown) :- \+ node(n676,supported), \+ node(n676,refuted).
node(n679,supported) :- status(o_3dae32fe8363083ec938,supported).
node(n679,refuted) :- status(o_3dae32fe8363083ec938,refuted).
node(n679,unknown) :- status(o_3dae32fe8363083ec938,unknown).
node(n678,supported) :- node(n660,supported), node(n661,supported), node(n679,supported).
node(n678,refuted) :- node(n660,refuted).
node(n678,refuted) :- node(n661,refuted).
node(n678,refuted) :- node(n679,refuted).
node(n678,unknown) :- \+ node(n678,supported), \+ node(n678,refuted).
node(n675,refuted) :- node(n676,refuted), node(n678,refuted), node(n9,refuted).
node(n675,supported) :- node(n676,supported).
node(n675,supported) :- node(n678,supported).
node(n675,supported) :- node(n9,supported).
node(n675,unknown) :- \+ node(n675,supported), \+ node(n675,refuted).
verdict(c_4234d21191c00d40,supported) :- node(n675,supported).
query(verdict(c_4234d21191c00d40,supported)).
verdict(c_4234d21191c00d40,refuted) :- node(n675,refuted).
query(verdict(c_4234d21191c00d40,refuted)).
verdict(c_4234d21191c00d40,unknown) :- node(n675,unknown).
query(verdict(c_4234d21191c00d40,unknown)).
node(n681,supported) :- node(n656,supported), node(n657,supported), node(n658,supported), node(n677,supported).
node(n681,refuted) :- node(n656,refuted).
node(n681,refuted) :- node(n657,refuted).
node(n681,refuted) :- node(n658,refuted).
node(n681,refuted) :- node(n677,refuted).
node(n681,unknown) :- \+ node(n681,supported), \+ node(n681,refuted).
node(n682,supported) :- node(n660,supported), node(n661,supported), node(n662,supported), node(n679,supported).
node(n682,refuted) :- node(n660,refuted).
node(n682,refuted) :- node(n661,refuted).
node(n682,refuted) :- node(n662,refuted).
node(n682,refuted) :- node(n679,refuted).
node(n682,unknown) :- \+ node(n682,supported), \+ node(n682,refuted).
node(n680,refuted) :- node(n681,refuted), node(n682,refuted), node(n9,refuted).
node(n680,supported) :- node(n681,supported).
node(n680,supported) :- node(n682,supported).
node(n680,supported) :- node(n9,supported).
node(n680,unknown) :- \+ node(n680,supported), \+ node(n680,refuted).
verdict(c_2df2cbb57ffd7ad9,supported) :- node(n680,supported).
query(verdict(c_2df2cbb57ffd7ad9,supported)).
verdict(c_2df2cbb57ffd7ad9,refuted) :- node(n680,refuted).
query(verdict(c_2df2cbb57ffd7ad9,refuted)).
verdict(c_2df2cbb57ffd7ad9,unknown) :- node(n680,unknown).
query(verdict(c_2df2cbb57ffd7ad9,unknown)).
node(n685,supported) :- status(o_458b18f8f3b02d7e4147,supported).
node(n685,refuted) :- status(o_458b18f8f3b02d7e4147,refuted).
node(n685,unknown) :- status(o_458b18f8f3b02d7e4147,unknown).
node(n686,supported) :- status(o_8002b1224a08ded93d2f,supported).
node(n686,refuted) :- status(o_8002b1224a08ded93d2f,refuted).
node(n686,unknown) :- status(o_8002b1224a08ded93d2f,unknown).
node(n687,supported) :- status(o_3a783aa140d9a331e149,supported).
node(n687,refuted) :- status(o_3a783aa140d9a331e149,refuted).
node(n687,unknown) :- status(o_3a783aa140d9a331e149,unknown).
node(n684,supported) :- node(n685,supported), node(n686,supported), node(n687,supported).
node(n684,refuted) :- node(n685,refuted).
node(n684,refuted) :- node(n686,refuted).
node(n684,refuted) :- node(n687,refuted).
node(n684,unknown) :- \+ node(n684,supported), \+ node(n684,refuted).
node(n689,supported) :- status(o_7b21776c0546f550dffa,supported).
node(n689,refuted) :- status(o_7b21776c0546f550dffa,refuted).
node(n689,unknown) :- status(o_7b21776c0546f550dffa,unknown).
node(n690,supported) :- status(o_44eb32fe2101f3c40478,supported).
node(n690,refuted) :- status(o_44eb32fe2101f3c40478,refuted).
node(n690,unknown) :- status(o_44eb32fe2101f3c40478,unknown).
node(n691,supported) :- status(o_20a5b56cbd65de533338,supported).
node(n691,refuted) :- status(o_20a5b56cbd65de533338,refuted).
node(n691,unknown) :- status(o_20a5b56cbd65de533338,unknown).
node(n688,supported) :- node(n689,supported), node(n690,supported), node(n691,supported).
node(n688,refuted) :- node(n689,refuted).
node(n688,refuted) :- node(n690,refuted).
node(n688,refuted) :- node(n691,refuted).
node(n688,unknown) :- \+ node(n688,supported), \+ node(n688,refuted).
node(n683,refuted) :- node(n684,refuted), node(n688,refuted), node(n9,refuted).
node(n683,supported) :- node(n684,supported).
node(n683,supported) :- node(n688,supported).
node(n683,supported) :- node(n9,supported).
node(n683,unknown) :- \+ node(n683,supported), \+ node(n683,refuted).
verdict(c_60c114e579c1492f,supported) :- node(n683,supported).
query(verdict(c_60c114e579c1492f,supported)).
verdict(c_60c114e579c1492f,refuted) :- node(n683,refuted).
query(verdict(c_60c114e579c1492f,refuted)).
verdict(c_60c114e579c1492f,unknown) :- node(n683,unknown).
query(verdict(c_60c114e579c1492f,unknown)).
node(n694,supported) :- status(o_55da9749d00d2197a82f,supported).
node(n694,refuted) :- status(o_55da9749d00d2197a82f,refuted).
node(n694,unknown) :- status(o_55da9749d00d2197a82f,unknown).
node(n693,supported) :- node(n685,supported), node(n686,supported), node(n687,supported), node(n694,supported).
node(n693,refuted) :- node(n685,refuted).
node(n693,refuted) :- node(n686,refuted).
node(n693,refuted) :- node(n687,refuted).
node(n693,refuted) :- node(n694,refuted).
node(n693,unknown) :- \+ node(n693,supported), \+ node(n693,refuted).
node(n696,supported) :- status(o_efa4b0938cb926411442,supported).
node(n696,refuted) :- status(o_efa4b0938cb926411442,refuted).
node(n696,unknown) :- status(o_efa4b0938cb926411442,unknown).
node(n695,supported) :- node(n689,supported), node(n690,supported), node(n691,supported), node(n696,supported).
node(n695,refuted) :- node(n689,refuted).
node(n695,refuted) :- node(n690,refuted).
node(n695,refuted) :- node(n691,refuted).
node(n695,refuted) :- node(n696,refuted).
node(n695,unknown) :- \+ node(n695,supported), \+ node(n695,refuted).
node(n692,refuted) :- node(n693,refuted), node(n695,refuted), node(n9,refuted).
node(n692,supported) :- node(n693,supported).
node(n692,supported) :- node(n695,supported).
node(n692,supported) :- node(n9,supported).
node(n692,unknown) :- \+ node(n692,supported), \+ node(n692,refuted).
verdict(c_56054d6af605256b,supported) :- node(n692,supported).
query(verdict(c_56054d6af605256b,supported)).
verdict(c_56054d6af605256b,refuted) :- node(n692,refuted).
query(verdict(c_56054d6af605256b,refuted)).
verdict(c_56054d6af605256b,unknown) :- node(n692,unknown).
query(verdict(c_56054d6af605256b,unknown)).
node(n699,supported) :- status(o_ace4cad0c568390e7df3,supported).
node(n699,refuted) :- status(o_ace4cad0c568390e7df3,refuted).
node(n699,unknown) :- status(o_ace4cad0c568390e7df3,unknown).
node(n700,supported) :- status(o_52d84e0df87b2cc31da2,supported).
node(n700,refuted) :- status(o_52d84e0df87b2cc31da2,refuted).
node(n700,unknown) :- status(o_52d84e0df87b2cc31da2,unknown).
node(n698,supported) :- node(n685,supported), node(n686,supported), node(n687,supported), node(n694,supported), node(n699,supported), node(n700,supported).
node(n698,refuted) :- node(n685,refuted).
node(n698,refuted) :- node(n686,refuted).
node(n698,refuted) :- node(n687,refuted).
node(n698,refuted) :- node(n694,refuted).
node(n698,refuted) :- node(n699,refuted).
node(n698,refuted) :- node(n700,refuted).
node(n698,unknown) :- \+ node(n698,supported), \+ node(n698,refuted).
node(n702,supported) :- status(o_658b0f2172a11e1a45f4,supported).
node(n702,refuted) :- status(o_658b0f2172a11e1a45f4,refuted).
node(n702,unknown) :- status(o_658b0f2172a11e1a45f4,unknown).
node(n703,supported) :- status(o_5bb8a43209e817939c43,supported).
node(n703,refuted) :- status(o_5bb8a43209e817939c43,refuted).
node(n703,unknown) :- status(o_5bb8a43209e817939c43,unknown).
node(n701,supported) :- node(n689,supported), node(n690,supported), node(n691,supported), node(n696,supported), node(n702,supported), node(n703,supported).
node(n701,refuted) :- node(n689,refuted).
node(n701,refuted) :- node(n690,refuted).
node(n701,refuted) :- node(n691,refuted).
node(n701,refuted) :- node(n696,refuted).
node(n701,refuted) :- node(n702,refuted).
node(n701,refuted) :- node(n703,refuted).
node(n701,unknown) :- \+ node(n701,supported), \+ node(n701,refuted).
node(n697,refuted) :- node(n698,refuted), node(n701,refuted), node(n9,refuted).
node(n697,supported) :- node(n698,supported).
node(n697,supported) :- node(n701,supported).
node(n697,supported) :- node(n9,supported).
node(n697,unknown) :- \+ node(n697,supported), \+ node(n697,refuted).
verdict(c_b03b2b892d4e7701,supported) :- node(n697,supported).
query(verdict(c_b03b2b892d4e7701,supported)).
verdict(c_b03b2b892d4e7701,refuted) :- node(n697,refuted).
query(verdict(c_b03b2b892d4e7701,refuted)).
verdict(c_b03b2b892d4e7701,unknown) :- node(n697,unknown).
query(verdict(c_b03b2b892d4e7701,unknown)).
node(n706,supported) :- status(o_a9899d0435a6f5cc21a5,supported).
node(n706,refuted) :- status(o_a9899d0435a6f5cc21a5,refuted).
node(n706,unknown) :- status(o_a9899d0435a6f5cc21a5,unknown).
node(n705,supported) :- node(n685,supported), node(n686,supported), node(n706,supported).
node(n705,refuted) :- node(n685,refuted).
node(n705,refuted) :- node(n686,refuted).
node(n705,refuted) :- node(n706,refuted).
node(n705,unknown) :- \+ node(n705,supported), \+ node(n705,refuted).
node(n708,supported) :- status(o_fc03b07d2418f15a6690,supported).
node(n708,refuted) :- status(o_fc03b07d2418f15a6690,refuted).
node(n708,unknown) :- status(o_fc03b07d2418f15a6690,unknown).
node(n707,supported) :- node(n689,supported), node(n690,supported), node(n708,supported).
node(n707,refuted) :- node(n689,refuted).
node(n707,refuted) :- node(n690,refuted).
node(n707,refuted) :- node(n708,refuted).
node(n707,unknown) :- \+ node(n707,supported), \+ node(n707,refuted).
node(n704,refuted) :- node(n705,refuted), node(n707,refuted), node(n9,refuted).
node(n704,supported) :- node(n705,supported).
node(n704,supported) :- node(n707,supported).
node(n704,supported) :- node(n9,supported).
node(n704,unknown) :- \+ node(n704,supported), \+ node(n704,refuted).
verdict(c_8731b4dc498c1bd8,supported) :- node(n704,supported).
query(verdict(c_8731b4dc498c1bd8,supported)).
verdict(c_8731b4dc498c1bd8,refuted) :- node(n704,refuted).
query(verdict(c_8731b4dc498c1bd8,refuted)).
verdict(c_8731b4dc498c1bd8,unknown) :- node(n704,unknown).
query(verdict(c_8731b4dc498c1bd8,unknown)).
node(n710,supported) :- node(n685,supported), node(n686,supported), node(n687,supported), node(n706,supported).
node(n710,refuted) :- node(n685,refuted).
node(n710,refuted) :- node(n686,refuted).
node(n710,refuted) :- node(n687,refuted).
node(n710,refuted) :- node(n706,refuted).
node(n710,unknown) :- \+ node(n710,supported), \+ node(n710,refuted).
node(n711,supported) :- node(n689,supported), node(n690,supported), node(n691,supported), node(n708,supported).
node(n711,refuted) :- node(n689,refuted).
node(n711,refuted) :- node(n690,refuted).
node(n711,refuted) :- node(n691,refuted).
node(n711,refuted) :- node(n708,refuted).
node(n711,unknown) :- \+ node(n711,supported), \+ node(n711,refuted).
node(n709,refuted) :- node(n710,refuted), node(n711,refuted), node(n9,refuted).
node(n709,supported) :- node(n710,supported).
node(n709,supported) :- node(n711,supported).
node(n709,supported) :- node(n9,supported).
node(n709,unknown) :- \+ node(n709,supported), \+ node(n709,refuted).
verdict(c_2d23f67702299358,supported) :- node(n709,supported).
query(verdict(c_2d23f67702299358,supported)).
verdict(c_2d23f67702299358,refuted) :- node(n709,refuted).
query(verdict(c_2d23f67702299358,refuted)).
verdict(c_2d23f67702299358,unknown) :- node(n709,unknown).
query(verdict(c_2d23f67702299358,unknown)).
node(n714,supported) :- status(o_79eda2530f51ba8eb99b,supported).
node(n714,refuted) :- status(o_79eda2530f51ba8eb99b,refuted).
node(n714,unknown) :- status(o_79eda2530f51ba8eb99b,unknown).
node(n715,supported) :- status(o_91eef027d6d7d155292b,supported).
node(n715,refuted) :- status(o_91eef027d6d7d155292b,refuted).
node(n715,unknown) :- status(o_91eef027d6d7d155292b,unknown).
node(n716,supported) :- status(o_5dee46ce37bc7ae08640,supported).
node(n716,refuted) :- status(o_5dee46ce37bc7ae08640,refuted).
node(n716,unknown) :- status(o_5dee46ce37bc7ae08640,unknown).
node(n713,supported) :- node(n714,supported), node(n715,supported), node(n716,supported).
node(n713,refuted) :- node(n714,refuted).
node(n713,refuted) :- node(n715,refuted).
node(n713,refuted) :- node(n716,refuted).
node(n713,unknown) :- \+ node(n713,supported), \+ node(n713,refuted).
node(n718,supported) :- status(o_9178702dd21232ad6781,supported).
node(n718,refuted) :- status(o_9178702dd21232ad6781,refuted).
node(n718,unknown) :- status(o_9178702dd21232ad6781,unknown).
node(n719,supported) :- status(o_f118935329aff130bfd0,supported).
node(n719,refuted) :- status(o_f118935329aff130bfd0,refuted).
node(n719,unknown) :- status(o_f118935329aff130bfd0,unknown).
node(n720,supported) :- status(o_d2627137402160e4f678,supported).
node(n720,refuted) :- status(o_d2627137402160e4f678,refuted).
node(n720,unknown) :- status(o_d2627137402160e4f678,unknown).
node(n717,supported) :- node(n718,supported), node(n719,supported), node(n720,supported).
node(n717,refuted) :- node(n718,refuted).
node(n717,refuted) :- node(n719,refuted).
node(n717,refuted) :- node(n720,refuted).
node(n717,unknown) :- \+ node(n717,supported), \+ node(n717,refuted).
node(n712,refuted) :- node(n713,refuted), node(n717,refuted), node(n9,refuted).
node(n712,supported) :- node(n713,supported).
node(n712,supported) :- node(n717,supported).
node(n712,supported) :- node(n9,supported).
node(n712,unknown) :- \+ node(n712,supported), \+ node(n712,refuted).
verdict(c_6df61328e72c02a5,supported) :- node(n712,supported).
query(verdict(c_6df61328e72c02a5,supported)).
verdict(c_6df61328e72c02a5,refuted) :- node(n712,refuted).
query(verdict(c_6df61328e72c02a5,refuted)).
verdict(c_6df61328e72c02a5,unknown) :- node(n712,unknown).
query(verdict(c_6df61328e72c02a5,unknown)).
node(n723,supported) :- status(o_5d6fa1cf932456eac52e,supported).
node(n723,refuted) :- status(o_5d6fa1cf932456eac52e,refuted).
node(n723,unknown) :- status(o_5d6fa1cf932456eac52e,unknown).
node(n722,supported) :- node(n714,supported), node(n715,supported), node(n716,supported), node(n723,supported).
node(n722,refuted) :- node(n714,refuted).
node(n722,refuted) :- node(n715,refuted).
node(n722,refuted) :- node(n716,refuted).
node(n722,refuted) :- node(n723,refuted).
node(n722,unknown) :- \+ node(n722,supported), \+ node(n722,refuted).
node(n725,supported) :- status(o_b56868647643f8ca6914,supported).
node(n725,refuted) :- status(o_b56868647643f8ca6914,refuted).
node(n725,unknown) :- status(o_b56868647643f8ca6914,unknown).
node(n724,supported) :- node(n718,supported), node(n719,supported), node(n720,supported), node(n725,supported).
node(n724,refuted) :- node(n718,refuted).
node(n724,refuted) :- node(n719,refuted).
node(n724,refuted) :- node(n720,refuted).
node(n724,refuted) :- node(n725,refuted).
node(n724,unknown) :- \+ node(n724,supported), \+ node(n724,refuted).
node(n721,refuted) :- node(n722,refuted), node(n724,refuted), node(n9,refuted).
node(n721,supported) :- node(n722,supported).
node(n721,supported) :- node(n724,supported).
node(n721,supported) :- node(n9,supported).
node(n721,unknown) :- \+ node(n721,supported), \+ node(n721,refuted).
verdict(c_c12568f90ac0c008,supported) :- node(n721,supported).
query(verdict(c_c12568f90ac0c008,supported)).
verdict(c_c12568f90ac0c008,refuted) :- node(n721,refuted).
query(verdict(c_c12568f90ac0c008,refuted)).
verdict(c_c12568f90ac0c008,unknown) :- node(n721,unknown).
query(verdict(c_c12568f90ac0c008,unknown)).
node(n728,supported) :- status(o_c7e853d7eebb8ea9135a,supported).
node(n728,refuted) :- status(o_c7e853d7eebb8ea9135a,refuted).
node(n728,unknown) :- status(o_c7e853d7eebb8ea9135a,unknown).
node(n729,supported) :- status(o_8fdc18904d435f513d28,supported).
node(n729,refuted) :- status(o_8fdc18904d435f513d28,refuted).
node(n729,unknown) :- status(o_8fdc18904d435f513d28,unknown).
node(n727,supported) :- node(n714,supported), node(n715,supported), node(n716,supported), node(n723,supported), node(n728,supported), node(n729,supported).
node(n727,refuted) :- node(n714,refuted).
node(n727,refuted) :- node(n715,refuted).
node(n727,refuted) :- node(n716,refuted).
node(n727,refuted) :- node(n723,refuted).
node(n727,refuted) :- node(n728,refuted).
node(n727,refuted) :- node(n729,refuted).
node(n727,unknown) :- \+ node(n727,supported), \+ node(n727,refuted).
node(n731,supported) :- status(o_5c24b86eb8ef8e422775,supported).
node(n731,refuted) :- status(o_5c24b86eb8ef8e422775,refuted).
node(n731,unknown) :- status(o_5c24b86eb8ef8e422775,unknown).
node(n732,supported) :- status(o_ce3e0b1d14622325cba4,supported).
node(n732,refuted) :- status(o_ce3e0b1d14622325cba4,refuted).
node(n732,unknown) :- status(o_ce3e0b1d14622325cba4,unknown).
node(n730,supported) :- node(n718,supported), node(n719,supported), node(n720,supported), node(n725,supported), node(n731,supported), node(n732,supported).
node(n730,refuted) :- node(n718,refuted).
node(n730,refuted) :- node(n719,refuted).
node(n730,refuted) :- node(n720,refuted).
node(n730,refuted) :- node(n725,refuted).
node(n730,refuted) :- node(n731,refuted).
node(n730,refuted) :- node(n732,refuted).
node(n730,unknown) :- \+ node(n730,supported), \+ node(n730,refuted).
node(n726,refuted) :- node(n727,refuted), node(n730,refuted), node(n9,refuted).
node(n726,supported) :- node(n727,supported).
node(n726,supported) :- node(n730,supported).
node(n726,supported) :- node(n9,supported).
node(n726,unknown) :- \+ node(n726,supported), \+ node(n726,refuted).
verdict(c_80dc5838bdcbfe0d,supported) :- node(n726,supported).
query(verdict(c_80dc5838bdcbfe0d,supported)).
verdict(c_80dc5838bdcbfe0d,refuted) :- node(n726,refuted).
query(verdict(c_80dc5838bdcbfe0d,refuted)).
verdict(c_80dc5838bdcbfe0d,unknown) :- node(n726,unknown).
query(verdict(c_80dc5838bdcbfe0d,unknown)).
node(n735,supported) :- status(o_ada7ab6a3223ca399cf7,supported).
node(n735,refuted) :- status(o_ada7ab6a3223ca399cf7,refuted).
node(n735,unknown) :- status(o_ada7ab6a3223ca399cf7,unknown).
node(n734,supported) :- node(n714,supported), node(n715,supported), node(n735,supported).
node(n734,refuted) :- node(n714,refuted).
node(n734,refuted) :- node(n715,refuted).
node(n734,refuted) :- node(n735,refuted).
node(n734,unknown) :- \+ node(n734,supported), \+ node(n734,refuted).
node(n737,supported) :- status(o_483133157e868f685560,supported).
node(n737,refuted) :- status(o_483133157e868f685560,refuted).
node(n737,unknown) :- status(o_483133157e868f685560,unknown).
node(n736,supported) :- node(n718,supported), node(n719,supported), node(n737,supported).
node(n736,refuted) :- node(n718,refuted).
node(n736,refuted) :- node(n719,refuted).
node(n736,refuted) :- node(n737,refuted).
node(n736,unknown) :- \+ node(n736,supported), \+ node(n736,refuted).
node(n733,refuted) :- node(n734,refuted), node(n736,refuted), node(n9,refuted).
node(n733,supported) :- node(n734,supported).
node(n733,supported) :- node(n736,supported).
node(n733,supported) :- node(n9,supported).
node(n733,unknown) :- \+ node(n733,supported), \+ node(n733,refuted).
verdict(c_ddbe501c1ad899ff,supported) :- node(n733,supported).
query(verdict(c_ddbe501c1ad899ff,supported)).
verdict(c_ddbe501c1ad899ff,refuted) :- node(n733,refuted).
query(verdict(c_ddbe501c1ad899ff,refuted)).
verdict(c_ddbe501c1ad899ff,unknown) :- node(n733,unknown).
query(verdict(c_ddbe501c1ad899ff,unknown)).
node(n739,supported) :- node(n714,supported), node(n715,supported), node(n716,supported), node(n735,supported).
node(n739,refuted) :- node(n714,refuted).
node(n739,refuted) :- node(n715,refuted).
node(n739,refuted) :- node(n716,refuted).
node(n739,refuted) :- node(n735,refuted).
node(n739,unknown) :- \+ node(n739,supported), \+ node(n739,refuted).
node(n740,supported) :- node(n718,supported), node(n719,supported), node(n720,supported), node(n737,supported).
node(n740,refuted) :- node(n718,refuted).
node(n740,refuted) :- node(n719,refuted).
node(n740,refuted) :- node(n720,refuted).
node(n740,refuted) :- node(n737,refuted).
node(n740,unknown) :- \+ node(n740,supported), \+ node(n740,refuted).
node(n738,refuted) :- node(n739,refuted), node(n740,refuted), node(n9,refuted).
node(n738,supported) :- node(n739,supported).
node(n738,supported) :- node(n740,supported).
node(n738,supported) :- node(n9,supported).
node(n738,unknown) :- \+ node(n738,supported), \+ node(n738,refuted).
verdict(c_e7e2301d4fa65544,supported) :- node(n738,supported).
query(verdict(c_e7e2301d4fa65544,supported)).
verdict(c_e7e2301d4fa65544,refuted) :- node(n738,refuted).
query(verdict(c_e7e2301d4fa65544,refuted)).
verdict(c_e7e2301d4fa65544,unknown) :- node(n738,unknown).
query(verdict(c_e7e2301d4fa65544,unknown)).
node(n743,supported) :- status(o_996253e346367dcb7b19,supported).
node(n743,refuted) :- status(o_996253e346367dcb7b19,refuted).
node(n743,unknown) :- status(o_996253e346367dcb7b19,unknown).
node(n744,supported) :- status(o_b7592dc456a5bedaf940,supported).
node(n744,refuted) :- status(o_b7592dc456a5bedaf940,refuted).
node(n744,unknown) :- status(o_b7592dc456a5bedaf940,unknown).
node(n745,supported) :- status(o_f42265825af9d88511dd,supported).
node(n745,refuted) :- status(o_f42265825af9d88511dd,refuted).
node(n745,unknown) :- status(o_f42265825af9d88511dd,unknown).
node(n742,supported) :- node(n743,supported), node(n744,supported), node(n745,supported).
node(n742,refuted) :- node(n743,refuted).
node(n742,refuted) :- node(n744,refuted).
node(n742,refuted) :- node(n745,refuted).
node(n742,unknown) :- \+ node(n742,supported), \+ node(n742,refuted).
node(n747,supported) :- status(o_5b71811a31d99aec3541,supported).
node(n747,refuted) :- status(o_5b71811a31d99aec3541,refuted).
node(n747,unknown) :- status(o_5b71811a31d99aec3541,unknown).
node(n748,supported) :- status(o_ae7650a90aa23c291995,supported).
node(n748,refuted) :- status(o_ae7650a90aa23c291995,refuted).
node(n748,unknown) :- status(o_ae7650a90aa23c291995,unknown).
node(n749,supported) :- status(o_a14400b9666d4a5a34d8,supported).
node(n749,refuted) :- status(o_a14400b9666d4a5a34d8,refuted).
node(n749,unknown) :- status(o_a14400b9666d4a5a34d8,unknown).
node(n746,supported) :- node(n747,supported), node(n748,supported), node(n749,supported).
node(n746,refuted) :- node(n747,refuted).
node(n746,refuted) :- node(n748,refuted).
node(n746,refuted) :- node(n749,refuted).
node(n746,unknown) :- \+ node(n746,supported), \+ node(n746,refuted).
node(n741,refuted) :- node(n742,refuted), node(n746,refuted), node(n9,refuted).
node(n741,supported) :- node(n742,supported).
node(n741,supported) :- node(n746,supported).
node(n741,supported) :- node(n9,supported).
node(n741,unknown) :- \+ node(n741,supported), \+ node(n741,refuted).
verdict(c_ed0726517deaea66,supported) :- node(n741,supported).
query(verdict(c_ed0726517deaea66,supported)).
verdict(c_ed0726517deaea66,refuted) :- node(n741,refuted).
query(verdict(c_ed0726517deaea66,refuted)).
verdict(c_ed0726517deaea66,unknown) :- node(n741,unknown).
query(verdict(c_ed0726517deaea66,unknown)).
node(n752,supported) :- status(o_58a94025d672a25ca24e,supported).
node(n752,refuted) :- status(o_58a94025d672a25ca24e,refuted).
node(n752,unknown) :- status(o_58a94025d672a25ca24e,unknown).
node(n751,supported) :- node(n743,supported), node(n744,supported), node(n745,supported), node(n752,supported).
node(n751,refuted) :- node(n743,refuted).
node(n751,refuted) :- node(n744,refuted).
node(n751,refuted) :- node(n745,refuted).
node(n751,refuted) :- node(n752,refuted).
node(n751,unknown) :- \+ node(n751,supported), \+ node(n751,refuted).
node(n754,supported) :- status(o_36ccb9b936c01024b2fe,supported).
node(n754,refuted) :- status(o_36ccb9b936c01024b2fe,refuted).
node(n754,unknown) :- status(o_36ccb9b936c01024b2fe,unknown).
node(n753,supported) :- node(n747,supported), node(n748,supported), node(n749,supported), node(n754,supported).
node(n753,refuted) :- node(n747,refuted).
node(n753,refuted) :- node(n748,refuted).
node(n753,refuted) :- node(n749,refuted).
node(n753,refuted) :- node(n754,refuted).
node(n753,unknown) :- \+ node(n753,supported), \+ node(n753,refuted).
node(n750,refuted) :- node(n751,refuted), node(n753,refuted), node(n9,refuted).
node(n750,supported) :- node(n751,supported).
node(n750,supported) :- node(n753,supported).
node(n750,supported) :- node(n9,supported).
node(n750,unknown) :- \+ node(n750,supported), \+ node(n750,refuted).
verdict(c_a8527ed44a949388,supported) :- node(n750,supported).
query(verdict(c_a8527ed44a949388,supported)).
verdict(c_a8527ed44a949388,refuted) :- node(n750,refuted).
query(verdict(c_a8527ed44a949388,refuted)).
verdict(c_a8527ed44a949388,unknown) :- node(n750,unknown).
query(verdict(c_a8527ed44a949388,unknown)).
node(n757,supported) :- status(o_c55f57db57d801608117,supported).
node(n757,refuted) :- status(o_c55f57db57d801608117,refuted).
node(n757,unknown) :- status(o_c55f57db57d801608117,unknown).
node(n758,supported) :- status(o_55d322ff631c2f704b48,supported).
node(n758,refuted) :- status(o_55d322ff631c2f704b48,refuted).
node(n758,unknown) :- status(o_55d322ff631c2f704b48,unknown).
node(n756,supported) :- node(n743,supported), node(n744,supported), node(n745,supported), node(n752,supported), node(n757,supported), node(n758,supported).
node(n756,refuted) :- node(n743,refuted).
node(n756,refuted) :- node(n744,refuted).
node(n756,refuted) :- node(n745,refuted).
node(n756,refuted) :- node(n752,refuted).
node(n756,refuted) :- node(n757,refuted).
node(n756,refuted) :- node(n758,refuted).
node(n756,unknown) :- \+ node(n756,supported), \+ node(n756,refuted).
node(n760,supported) :- status(o_aa69a86b7fc2e0e9e895,supported).
node(n760,refuted) :- status(o_aa69a86b7fc2e0e9e895,refuted).
node(n760,unknown) :- status(o_aa69a86b7fc2e0e9e895,unknown).
node(n761,supported) :- status(o_382f6ff7294f8b5ac697,supported).
node(n761,refuted) :- status(o_382f6ff7294f8b5ac697,refuted).
node(n761,unknown) :- status(o_382f6ff7294f8b5ac697,unknown).
node(n759,supported) :- node(n747,supported), node(n748,supported), node(n749,supported), node(n754,supported), node(n760,supported), node(n761,supported).
node(n759,refuted) :- node(n747,refuted).
node(n759,refuted) :- node(n748,refuted).
node(n759,refuted) :- node(n749,refuted).
node(n759,refuted) :- node(n754,refuted).
node(n759,refuted) :- node(n760,refuted).
node(n759,refuted) :- node(n761,refuted).
node(n759,unknown) :- \+ node(n759,supported), \+ node(n759,refuted).
node(n755,refuted) :- node(n756,refuted), node(n759,refuted), node(n9,refuted).
node(n755,supported) :- node(n756,supported).
node(n755,supported) :- node(n759,supported).
node(n755,supported) :- node(n9,supported).
node(n755,unknown) :- \+ node(n755,supported), \+ node(n755,refuted).
verdict(c_5bfeae935d086ff8,supported) :- node(n755,supported).
query(verdict(c_5bfeae935d086ff8,supported)).
verdict(c_5bfeae935d086ff8,refuted) :- node(n755,refuted).
query(verdict(c_5bfeae935d086ff8,refuted)).
verdict(c_5bfeae935d086ff8,unknown) :- node(n755,unknown).
query(verdict(c_5bfeae935d086ff8,unknown)).
node(n764,supported) :- status(o_f4bf08bec5beb31c2282,supported).
node(n764,refuted) :- status(o_f4bf08bec5beb31c2282,refuted).
node(n764,unknown) :- status(o_f4bf08bec5beb31c2282,unknown).
node(n763,supported) :- node(n743,supported), node(n744,supported), node(n764,supported).
node(n763,refuted) :- node(n743,refuted).
node(n763,refuted) :- node(n744,refuted).
node(n763,refuted) :- node(n764,refuted).
node(n763,unknown) :- \+ node(n763,supported), \+ node(n763,refuted).
node(n766,supported) :- status(o_f973d63a2b66fc985a75,supported).
node(n766,refuted) :- status(o_f973d63a2b66fc985a75,refuted).
node(n766,unknown) :- status(o_f973d63a2b66fc985a75,unknown).
node(n765,supported) :- node(n747,supported), node(n748,supported), node(n766,supported).
node(n765,refuted) :- node(n747,refuted).
node(n765,refuted) :- node(n748,refuted).
node(n765,refuted) :- node(n766,refuted).
node(n765,unknown) :- \+ node(n765,supported), \+ node(n765,refuted).
node(n762,refuted) :- node(n763,refuted), node(n765,refuted), node(n9,refuted).
node(n762,supported) :- node(n763,supported).
node(n762,supported) :- node(n765,supported).
node(n762,supported) :- node(n9,supported).
node(n762,unknown) :- \+ node(n762,supported), \+ node(n762,refuted).
verdict(c_f0f6c2c461f1ead0,supported) :- node(n762,supported).
query(verdict(c_f0f6c2c461f1ead0,supported)).
verdict(c_f0f6c2c461f1ead0,refuted) :- node(n762,refuted).
query(verdict(c_f0f6c2c461f1ead0,refuted)).
verdict(c_f0f6c2c461f1ead0,unknown) :- node(n762,unknown).
query(verdict(c_f0f6c2c461f1ead0,unknown)).
node(n768,supported) :- node(n743,supported), node(n744,supported), node(n745,supported), node(n764,supported).
node(n768,refuted) :- node(n743,refuted).
node(n768,refuted) :- node(n744,refuted).
node(n768,refuted) :- node(n745,refuted).
node(n768,refuted) :- node(n764,refuted).
node(n768,unknown) :- \+ node(n768,supported), \+ node(n768,refuted).
node(n769,supported) :- node(n747,supported), node(n748,supported), node(n749,supported), node(n766,supported).
node(n769,refuted) :- node(n747,refuted).
node(n769,refuted) :- node(n748,refuted).
node(n769,refuted) :- node(n749,refuted).
node(n769,refuted) :- node(n766,refuted).
node(n769,unknown) :- \+ node(n769,supported), \+ node(n769,refuted).
node(n767,refuted) :- node(n768,refuted), node(n769,refuted), node(n9,refuted).
node(n767,supported) :- node(n768,supported).
node(n767,supported) :- node(n769,supported).
node(n767,supported) :- node(n9,supported).
node(n767,unknown) :- \+ node(n767,supported), \+ node(n767,refuted).
verdict(c_84e9dd1a060ef33a,supported) :- node(n767,supported).
query(verdict(c_84e9dd1a060ef33a,supported)).
verdict(c_84e9dd1a060ef33a,refuted) :- node(n767,refuted).
query(verdict(c_84e9dd1a060ef33a,refuted)).
verdict(c_84e9dd1a060ef33a,unknown) :- node(n767,unknown).
query(verdict(c_84e9dd1a060ef33a,unknown)).
node(n772,supported) :- status(o_00feea56a3fb78186054,supported).
node(n772,refuted) :- status(o_00feea56a3fb78186054,refuted).
node(n772,unknown) :- status(o_00feea56a3fb78186054,unknown).
node(n773,supported) :- status(o_65efce06180744851949,supported).
node(n773,refuted) :- status(o_65efce06180744851949,refuted).
node(n773,unknown) :- status(o_65efce06180744851949,unknown).
node(n774,supported) :- status(o_c4010f88dd20d5a326cf,supported).
node(n774,refuted) :- status(o_c4010f88dd20d5a326cf,refuted).
node(n774,unknown) :- status(o_c4010f88dd20d5a326cf,unknown).
node(n771,supported) :- node(n772,supported), node(n773,supported), node(n774,supported).
node(n771,refuted) :- node(n772,refuted).
node(n771,refuted) :- node(n773,refuted).
node(n771,refuted) :- node(n774,refuted).
node(n771,unknown) :- \+ node(n771,supported), \+ node(n771,refuted).
node(n776,supported) :- status(o_22effeae2f1aeb5a4309,supported).
node(n776,refuted) :- status(o_22effeae2f1aeb5a4309,refuted).
node(n776,unknown) :- status(o_22effeae2f1aeb5a4309,unknown).
node(n777,supported) :- status(o_4d97b5f3cae689758f0b,supported).
node(n777,refuted) :- status(o_4d97b5f3cae689758f0b,refuted).
node(n777,unknown) :- status(o_4d97b5f3cae689758f0b,unknown).
node(n778,supported) :- status(o_fc6d6c2b6d1a32a90854,supported).
node(n778,refuted) :- status(o_fc6d6c2b6d1a32a90854,refuted).
node(n778,unknown) :- status(o_fc6d6c2b6d1a32a90854,unknown).
node(n775,supported) :- node(n776,supported), node(n777,supported), node(n778,supported).
node(n775,refuted) :- node(n776,refuted).
node(n775,refuted) :- node(n777,refuted).
node(n775,refuted) :- node(n778,refuted).
node(n775,unknown) :- \+ node(n775,supported), \+ node(n775,refuted).
node(n770,refuted) :- node(n771,refuted), node(n775,refuted), node(n9,refuted).
node(n770,supported) :- node(n771,supported).
node(n770,supported) :- node(n775,supported).
node(n770,supported) :- node(n9,supported).
node(n770,unknown) :- \+ node(n770,supported), \+ node(n770,refuted).
verdict(c_c6c2368117c41d21,supported) :- node(n770,supported).
query(verdict(c_c6c2368117c41d21,supported)).
verdict(c_c6c2368117c41d21,refuted) :- node(n770,refuted).
query(verdict(c_c6c2368117c41d21,refuted)).
verdict(c_c6c2368117c41d21,unknown) :- node(n770,unknown).
query(verdict(c_c6c2368117c41d21,unknown)).
node(n781,supported) :- status(o_65fb9f175c4bc5a6bb48,supported).
node(n781,refuted) :- status(o_65fb9f175c4bc5a6bb48,refuted).
node(n781,unknown) :- status(o_65fb9f175c4bc5a6bb48,unknown).
node(n780,supported) :- node(n772,supported), node(n773,supported), node(n774,supported), node(n781,supported).
node(n780,refuted) :- node(n772,refuted).
node(n780,refuted) :- node(n773,refuted).
node(n780,refuted) :- node(n774,refuted).
node(n780,refuted) :- node(n781,refuted).
node(n780,unknown) :- \+ node(n780,supported), \+ node(n780,refuted).
node(n783,supported) :- status(o_ab4928d5d94b427096b0,supported).
node(n783,refuted) :- status(o_ab4928d5d94b427096b0,refuted).
node(n783,unknown) :- status(o_ab4928d5d94b427096b0,unknown).
node(n782,supported) :- node(n776,supported), node(n777,supported), node(n778,supported), node(n783,supported).
node(n782,refuted) :- node(n776,refuted).
node(n782,refuted) :- node(n777,refuted).
node(n782,refuted) :- node(n778,refuted).
node(n782,refuted) :- node(n783,refuted).
node(n782,unknown) :- \+ node(n782,supported), \+ node(n782,refuted).
node(n779,refuted) :- node(n780,refuted), node(n782,refuted), node(n9,refuted).
node(n779,supported) :- node(n780,supported).
node(n779,supported) :- node(n782,supported).
node(n779,supported) :- node(n9,supported).
node(n779,unknown) :- \+ node(n779,supported), \+ node(n779,refuted).
verdict(c_bf85b6bc216b0257,supported) :- node(n779,supported).
query(verdict(c_bf85b6bc216b0257,supported)).
verdict(c_bf85b6bc216b0257,refuted) :- node(n779,refuted).
query(verdict(c_bf85b6bc216b0257,refuted)).
verdict(c_bf85b6bc216b0257,unknown) :- node(n779,unknown).
query(verdict(c_bf85b6bc216b0257,unknown)).
node(n786,supported) :- status(o_680f559024f01b1588cb,supported).
node(n786,refuted) :- status(o_680f559024f01b1588cb,refuted).
node(n786,unknown) :- status(o_680f559024f01b1588cb,unknown).
node(n787,supported) :- status(o_f5e9506c4eaee6a812d2,supported).
node(n787,refuted) :- status(o_f5e9506c4eaee6a812d2,refuted).
node(n787,unknown) :- status(o_f5e9506c4eaee6a812d2,unknown).
node(n785,supported) :- node(n772,supported), node(n773,supported), node(n774,supported), node(n781,supported), node(n786,supported), node(n787,supported).
node(n785,refuted) :- node(n772,refuted).
node(n785,refuted) :- node(n773,refuted).
node(n785,refuted) :- node(n774,refuted).
node(n785,refuted) :- node(n781,refuted).
node(n785,refuted) :- node(n786,refuted).
node(n785,refuted) :- node(n787,refuted).
node(n785,unknown) :- \+ node(n785,supported), \+ node(n785,refuted).
node(n789,supported) :- status(o_bf91dc8699285fa2353e,supported).
node(n789,refuted) :- status(o_bf91dc8699285fa2353e,refuted).
node(n789,unknown) :- status(o_bf91dc8699285fa2353e,unknown).
node(n790,supported) :- status(o_2adfb24f0a65efca5cd6,supported).
node(n790,refuted) :- status(o_2adfb24f0a65efca5cd6,refuted).
node(n790,unknown) :- status(o_2adfb24f0a65efca5cd6,unknown).
node(n788,supported) :- node(n776,supported), node(n777,supported), node(n778,supported), node(n783,supported), node(n789,supported), node(n790,supported).
node(n788,refuted) :- node(n776,refuted).
node(n788,refuted) :- node(n777,refuted).
node(n788,refuted) :- node(n778,refuted).
node(n788,refuted) :- node(n783,refuted).
node(n788,refuted) :- node(n789,refuted).
node(n788,refuted) :- node(n790,refuted).
node(n788,unknown) :- \+ node(n788,supported), \+ node(n788,refuted).
node(n784,refuted) :- node(n785,refuted), node(n788,refuted), node(n9,refuted).
node(n784,supported) :- node(n785,supported).
node(n784,supported) :- node(n788,supported).
node(n784,supported) :- node(n9,supported).
node(n784,unknown) :- \+ node(n784,supported), \+ node(n784,refuted).
verdict(c_9d50d565e7c8164e,supported) :- node(n784,supported).
query(verdict(c_9d50d565e7c8164e,supported)).
verdict(c_9d50d565e7c8164e,refuted) :- node(n784,refuted).
query(verdict(c_9d50d565e7c8164e,refuted)).
verdict(c_9d50d565e7c8164e,unknown) :- node(n784,unknown).
query(verdict(c_9d50d565e7c8164e,unknown)).
node(n793,supported) :- status(o_aed4955ac51c7f0c97d6,supported).
node(n793,refuted) :- status(o_aed4955ac51c7f0c97d6,refuted).
node(n793,unknown) :- status(o_aed4955ac51c7f0c97d6,unknown).
node(n792,supported) :- node(n772,supported), node(n773,supported), node(n793,supported).
node(n792,refuted) :- node(n772,refuted).
node(n792,refuted) :- node(n773,refuted).
node(n792,refuted) :- node(n793,refuted).
node(n792,unknown) :- \+ node(n792,supported), \+ node(n792,refuted).
node(n795,supported) :- status(o_4d70ba639582eee3465a,supported).
node(n795,refuted) :- status(o_4d70ba639582eee3465a,refuted).
node(n795,unknown) :- status(o_4d70ba639582eee3465a,unknown).
node(n794,supported) :- node(n776,supported), node(n777,supported), node(n795,supported).
node(n794,refuted) :- node(n776,refuted).
node(n794,refuted) :- node(n777,refuted).
node(n794,refuted) :- node(n795,refuted).
node(n794,unknown) :- \+ node(n794,supported), \+ node(n794,refuted).
node(n791,refuted) :- node(n792,refuted), node(n794,refuted), node(n9,refuted).
node(n791,supported) :- node(n792,supported).
node(n791,supported) :- node(n794,supported).
node(n791,supported) :- node(n9,supported).
node(n791,unknown) :- \+ node(n791,supported), \+ node(n791,refuted).
verdict(c_2c40a724ebc13bcb,supported) :- node(n791,supported).
query(verdict(c_2c40a724ebc13bcb,supported)).
verdict(c_2c40a724ebc13bcb,refuted) :- node(n791,refuted).
query(verdict(c_2c40a724ebc13bcb,refuted)).
verdict(c_2c40a724ebc13bcb,unknown) :- node(n791,unknown).
query(verdict(c_2c40a724ebc13bcb,unknown)).
node(n797,supported) :- node(n772,supported), node(n773,supported), node(n774,supported), node(n793,supported).
node(n797,refuted) :- node(n772,refuted).
node(n797,refuted) :- node(n773,refuted).
node(n797,refuted) :- node(n774,refuted).
node(n797,refuted) :- node(n793,refuted).
node(n797,unknown) :- \+ node(n797,supported), \+ node(n797,refuted).
node(n798,supported) :- node(n776,supported), node(n777,supported), node(n778,supported), node(n795,supported).
node(n798,refuted) :- node(n776,refuted).
node(n798,refuted) :- node(n777,refuted).
node(n798,refuted) :- node(n778,refuted).
node(n798,refuted) :- node(n795,refuted).
node(n798,unknown) :- \+ node(n798,supported), \+ node(n798,refuted).
node(n796,refuted) :- node(n797,refuted), node(n798,refuted), node(n9,refuted).
node(n796,supported) :- node(n797,supported).
node(n796,supported) :- node(n798,supported).
node(n796,supported) :- node(n9,supported).
node(n796,unknown) :- \+ node(n796,supported), \+ node(n796,refuted).
verdict(c_500bb59adbd5a12d,supported) :- node(n796,supported).
query(verdict(c_500bb59adbd5a12d,supported)).
verdict(c_500bb59adbd5a12d,refuted) :- node(n796,refuted).
query(verdict(c_500bb59adbd5a12d,refuted)).
verdict(c_500bb59adbd5a12d,unknown) :- node(n796,unknown).
query(verdict(c_500bb59adbd5a12d,unknown)).
node(n801,supported) :- status(o_ad1ede6da12b16e19f8f,supported).
node(n801,refuted) :- status(o_ad1ede6da12b16e19f8f,refuted).
node(n801,unknown) :- status(o_ad1ede6da12b16e19f8f,unknown).
node(n802,supported) :- status(o_b84ca2f7dd808b71f241,supported).
node(n802,refuted) :- status(o_b84ca2f7dd808b71f241,refuted).
node(n802,unknown) :- status(o_b84ca2f7dd808b71f241,unknown).
node(n803,supported) :- status(o_eef4dbd2539c1906ed1b,supported).
node(n803,refuted) :- status(o_eef4dbd2539c1906ed1b,refuted).
node(n803,unknown) :- status(o_eef4dbd2539c1906ed1b,unknown).
node(n800,supported) :- node(n801,supported), node(n802,supported), node(n803,supported).
node(n800,refuted) :- node(n801,refuted).
node(n800,refuted) :- node(n802,refuted).
node(n800,refuted) :- node(n803,refuted).
node(n800,unknown) :- \+ node(n800,supported), \+ node(n800,refuted).
node(n805,supported) :- status(o_0913078a3624de41980e,supported).
node(n805,refuted) :- status(o_0913078a3624de41980e,refuted).
node(n805,unknown) :- status(o_0913078a3624de41980e,unknown).
node(n806,supported) :- status(o_314d238ce7873f35a435,supported).
node(n806,refuted) :- status(o_314d238ce7873f35a435,refuted).
node(n806,unknown) :- status(o_314d238ce7873f35a435,unknown).
node(n807,supported) :- status(o_4057f2a0b396a206be2d,supported).
node(n807,refuted) :- status(o_4057f2a0b396a206be2d,refuted).
node(n807,unknown) :- status(o_4057f2a0b396a206be2d,unknown).
node(n804,supported) :- node(n805,supported), node(n806,supported), node(n807,supported).
node(n804,refuted) :- node(n805,refuted).
node(n804,refuted) :- node(n806,refuted).
node(n804,refuted) :- node(n807,refuted).
node(n804,unknown) :- \+ node(n804,supported), \+ node(n804,refuted).
node(n799,refuted) :- node(n800,refuted), node(n804,refuted), node(n9,refuted).
node(n799,supported) :- node(n800,supported).
node(n799,supported) :- node(n804,supported).
node(n799,supported) :- node(n9,supported).
node(n799,unknown) :- \+ node(n799,supported), \+ node(n799,refuted).
verdict(c_3fb3bb74c9a037e3,supported) :- node(n799,supported).
query(verdict(c_3fb3bb74c9a037e3,supported)).
verdict(c_3fb3bb74c9a037e3,refuted) :- node(n799,refuted).
query(verdict(c_3fb3bb74c9a037e3,refuted)).
verdict(c_3fb3bb74c9a037e3,unknown) :- node(n799,unknown).
query(verdict(c_3fb3bb74c9a037e3,unknown)).
node(n810,supported) :- status(o_30a204659967732bdbf8,supported).
node(n810,refuted) :- status(o_30a204659967732bdbf8,refuted).
node(n810,unknown) :- status(o_30a204659967732bdbf8,unknown).
node(n809,supported) :- node(n801,supported), node(n802,supported), node(n803,supported), node(n810,supported).
node(n809,refuted) :- node(n801,refuted).
node(n809,refuted) :- node(n802,refuted).
node(n809,refuted) :- node(n803,refuted).
node(n809,refuted) :- node(n810,refuted).
node(n809,unknown) :- \+ node(n809,supported), \+ node(n809,refuted).
node(n812,supported) :- status(o_2da9dad26d0d185ff038,supported).
node(n812,refuted) :- status(o_2da9dad26d0d185ff038,refuted).
node(n812,unknown) :- status(o_2da9dad26d0d185ff038,unknown).
node(n811,supported) :- node(n805,supported), node(n806,supported), node(n807,supported), node(n812,supported).
node(n811,refuted) :- node(n805,refuted).
node(n811,refuted) :- node(n806,refuted).
node(n811,refuted) :- node(n807,refuted).
node(n811,refuted) :- node(n812,refuted).
node(n811,unknown) :- \+ node(n811,supported), \+ node(n811,refuted).
node(n808,refuted) :- node(n809,refuted), node(n811,refuted), node(n9,refuted).
node(n808,supported) :- node(n809,supported).
node(n808,supported) :- node(n811,supported).
node(n808,supported) :- node(n9,supported).
node(n808,unknown) :- \+ node(n808,supported), \+ node(n808,refuted).
verdict(c_63feb6faee99976c,supported) :- node(n808,supported).
query(verdict(c_63feb6faee99976c,supported)).
verdict(c_63feb6faee99976c,refuted) :- node(n808,refuted).
query(verdict(c_63feb6faee99976c,refuted)).
verdict(c_63feb6faee99976c,unknown) :- node(n808,unknown).
query(verdict(c_63feb6faee99976c,unknown)).
node(n815,supported) :- status(o_c4351ef2e7079be8eeda,supported).
node(n815,refuted) :- status(o_c4351ef2e7079be8eeda,refuted).
node(n815,unknown) :- status(o_c4351ef2e7079be8eeda,unknown).
node(n816,supported) :- status(o_2de567a8891ebacadb02,supported).
node(n816,refuted) :- status(o_2de567a8891ebacadb02,refuted).
node(n816,unknown) :- status(o_2de567a8891ebacadb02,unknown).
node(n814,supported) :- node(n801,supported), node(n802,supported), node(n803,supported), node(n810,supported), node(n815,supported), node(n816,supported).
node(n814,refuted) :- node(n801,refuted).
node(n814,refuted) :- node(n802,refuted).
node(n814,refuted) :- node(n803,refuted).
node(n814,refuted) :- node(n810,refuted).
node(n814,refuted) :- node(n815,refuted).
node(n814,refuted) :- node(n816,refuted).
node(n814,unknown) :- \+ node(n814,supported), \+ node(n814,refuted).
node(n818,supported) :- status(o_42a022bc0e832aa24be9,supported).
node(n818,refuted) :- status(o_42a022bc0e832aa24be9,refuted).
node(n818,unknown) :- status(o_42a022bc0e832aa24be9,unknown).
node(n819,supported) :- status(o_82d59e3ad716635875f9,supported).
node(n819,refuted) :- status(o_82d59e3ad716635875f9,refuted).
node(n819,unknown) :- status(o_82d59e3ad716635875f9,unknown).
node(n817,supported) :- node(n805,supported), node(n806,supported), node(n807,supported), node(n812,supported), node(n818,supported), node(n819,supported).
node(n817,refuted) :- node(n805,refuted).
node(n817,refuted) :- node(n806,refuted).
node(n817,refuted) :- node(n807,refuted).
node(n817,refuted) :- node(n812,refuted).
node(n817,refuted) :- node(n818,refuted).
node(n817,refuted) :- node(n819,refuted).
node(n817,unknown) :- \+ node(n817,supported), \+ node(n817,refuted).
node(n813,refuted) :- node(n814,refuted), node(n817,refuted), node(n9,refuted).
node(n813,supported) :- node(n814,supported).
node(n813,supported) :- node(n817,supported).
node(n813,supported) :- node(n9,supported).
node(n813,unknown) :- \+ node(n813,supported), \+ node(n813,refuted).
verdict(c_0424aee834134335,supported) :- node(n813,supported).
query(verdict(c_0424aee834134335,supported)).
verdict(c_0424aee834134335,refuted) :- node(n813,refuted).
query(verdict(c_0424aee834134335,refuted)).
verdict(c_0424aee834134335,unknown) :- node(n813,unknown).
query(verdict(c_0424aee834134335,unknown)).
node(n822,supported) :- status(o_421567c8da13534f2a16,supported).
node(n822,refuted) :- status(o_421567c8da13534f2a16,refuted).
node(n822,unknown) :- status(o_421567c8da13534f2a16,unknown).
node(n821,supported) :- node(n801,supported), node(n802,supported), node(n822,supported).
node(n821,refuted) :- node(n801,refuted).
node(n821,refuted) :- node(n802,refuted).
node(n821,refuted) :- node(n822,refuted).
node(n821,unknown) :- \+ node(n821,supported), \+ node(n821,refuted).
node(n824,supported) :- status(o_a62d6af01204425ab611,supported).
node(n824,refuted) :- status(o_a62d6af01204425ab611,refuted).
node(n824,unknown) :- status(o_a62d6af01204425ab611,unknown).
node(n823,supported) :- node(n805,supported), node(n806,supported), node(n824,supported).
node(n823,refuted) :- node(n805,refuted).
node(n823,refuted) :- node(n806,refuted).
node(n823,refuted) :- node(n824,refuted).
node(n823,unknown) :- \+ node(n823,supported), \+ node(n823,refuted).
node(n820,refuted) :- node(n821,refuted), node(n823,refuted), node(n9,refuted).
node(n820,supported) :- node(n821,supported).
node(n820,supported) :- node(n823,supported).
node(n820,supported) :- node(n9,supported).
node(n820,unknown) :- \+ node(n820,supported), \+ node(n820,refuted).
verdict(c_f5c213cc5f7a4717,supported) :- node(n820,supported).
query(verdict(c_f5c213cc5f7a4717,supported)).
verdict(c_f5c213cc5f7a4717,refuted) :- node(n820,refuted).
query(verdict(c_f5c213cc5f7a4717,refuted)).
verdict(c_f5c213cc5f7a4717,unknown) :- node(n820,unknown).
query(verdict(c_f5c213cc5f7a4717,unknown)).
node(n826,supported) :- node(n801,supported), node(n802,supported), node(n803,supported), node(n822,supported).
node(n826,refuted) :- node(n801,refuted).
node(n826,refuted) :- node(n802,refuted).
node(n826,refuted) :- node(n803,refuted).
node(n826,refuted) :- node(n822,refuted).
node(n826,unknown) :- \+ node(n826,supported), \+ node(n826,refuted).
node(n827,supported) :- node(n805,supported), node(n806,supported), node(n807,supported), node(n824,supported).
node(n827,refuted) :- node(n805,refuted).
node(n827,refuted) :- node(n806,refuted).
node(n827,refuted) :- node(n807,refuted).
node(n827,refuted) :- node(n824,refuted).
node(n827,unknown) :- \+ node(n827,supported), \+ node(n827,refuted).
node(n825,refuted) :- node(n826,refuted), node(n827,refuted), node(n9,refuted).
node(n825,supported) :- node(n826,supported).
node(n825,supported) :- node(n827,supported).
node(n825,supported) :- node(n9,supported).
node(n825,unknown) :- \+ node(n825,supported), \+ node(n825,refuted).
verdict(c_f638a96f0e539774,supported) :- node(n825,supported).
query(verdict(c_f638a96f0e539774,supported)).
verdict(c_f638a96f0e539774,refuted) :- node(n825,refuted).
query(verdict(c_f638a96f0e539774,refuted)).
verdict(c_f638a96f0e539774,unknown) :- node(n825,unknown).
query(verdict(c_f638a96f0e539774,unknown)).
node(n830,supported) :- status(o_16236e605f1143c61462,supported).
node(n830,refuted) :- status(o_16236e605f1143c61462,refuted).
node(n830,unknown) :- status(o_16236e605f1143c61462,unknown).
node(n831,supported) :- status(o_fee85bb93d4e6473adc9,supported).
node(n831,refuted) :- status(o_fee85bb93d4e6473adc9,refuted).
node(n831,unknown) :- status(o_fee85bb93d4e6473adc9,unknown).
node(n832,supported) :- status(o_0462471f25df45fc1ba2,supported).
node(n832,refuted) :- status(o_0462471f25df45fc1ba2,refuted).
node(n832,unknown) :- status(o_0462471f25df45fc1ba2,unknown).
node(n829,supported) :- node(n830,supported), node(n831,supported), node(n832,supported).
node(n829,refuted) :- node(n830,refuted).
node(n829,refuted) :- node(n831,refuted).
node(n829,refuted) :- node(n832,refuted).
node(n829,unknown) :- \+ node(n829,supported), \+ node(n829,refuted).
node(n834,supported) :- status(o_117467c80adc274805b3,supported).
node(n834,refuted) :- status(o_117467c80adc274805b3,refuted).
node(n834,unknown) :- status(o_117467c80adc274805b3,unknown).
node(n835,supported) :- status(o_d3490d8637e891875156,supported).
node(n835,refuted) :- status(o_d3490d8637e891875156,refuted).
node(n835,unknown) :- status(o_d3490d8637e891875156,unknown).
node(n836,supported) :- status(o_cf2fae3140c98371428e,supported).
node(n836,refuted) :- status(o_cf2fae3140c98371428e,refuted).
node(n836,unknown) :- status(o_cf2fae3140c98371428e,unknown).
node(n833,supported) :- node(n834,supported), node(n835,supported), node(n836,supported).
node(n833,refuted) :- node(n834,refuted).
node(n833,refuted) :- node(n835,refuted).
node(n833,refuted) :- node(n836,refuted).
node(n833,unknown) :- \+ node(n833,supported), \+ node(n833,refuted).
node(n828,refuted) :- node(n829,refuted), node(n833,refuted), node(n9,refuted).
node(n828,supported) :- node(n829,supported).
node(n828,supported) :- node(n833,supported).
node(n828,supported) :- node(n9,supported).
node(n828,unknown) :- \+ node(n828,supported), \+ node(n828,refuted).
verdict(c_c6ad1a0d0a4d7c62,supported) :- node(n828,supported).
query(verdict(c_c6ad1a0d0a4d7c62,supported)).
verdict(c_c6ad1a0d0a4d7c62,refuted) :- node(n828,refuted).
query(verdict(c_c6ad1a0d0a4d7c62,refuted)).
verdict(c_c6ad1a0d0a4d7c62,unknown) :- node(n828,unknown).
query(verdict(c_c6ad1a0d0a4d7c62,unknown)).
node(n839,supported) :- status(o_71dd89155c928c5a4cdc,supported).
node(n839,refuted) :- status(o_71dd89155c928c5a4cdc,refuted).
node(n839,unknown) :- status(o_71dd89155c928c5a4cdc,unknown).
node(n838,supported) :- node(n830,supported), node(n831,supported), node(n832,supported), node(n839,supported).
node(n838,refuted) :- node(n830,refuted).
node(n838,refuted) :- node(n831,refuted).
node(n838,refuted) :- node(n832,refuted).
node(n838,refuted) :- node(n839,refuted).
node(n838,unknown) :- \+ node(n838,supported), \+ node(n838,refuted).
node(n841,supported) :- status(o_0ffb0b77b3530e919aad,supported).
node(n841,refuted) :- status(o_0ffb0b77b3530e919aad,refuted).
node(n841,unknown) :- status(o_0ffb0b77b3530e919aad,unknown).
node(n840,supported) :- node(n834,supported), node(n835,supported), node(n836,supported), node(n841,supported).
node(n840,refuted) :- node(n834,refuted).
node(n840,refuted) :- node(n835,refuted).
node(n840,refuted) :- node(n836,refuted).
node(n840,refuted) :- node(n841,refuted).
node(n840,unknown) :- \+ node(n840,supported), \+ node(n840,refuted).
node(n837,refuted) :- node(n838,refuted), node(n840,refuted), node(n9,refuted).
node(n837,supported) :- node(n838,supported).
node(n837,supported) :- node(n840,supported).
node(n837,supported) :- node(n9,supported).
node(n837,unknown) :- \+ node(n837,supported), \+ node(n837,refuted).
verdict(c_64d87e5719e5da97,supported) :- node(n837,supported).
query(verdict(c_64d87e5719e5da97,supported)).
verdict(c_64d87e5719e5da97,refuted) :- node(n837,refuted).
query(verdict(c_64d87e5719e5da97,refuted)).
verdict(c_64d87e5719e5da97,unknown) :- node(n837,unknown).
query(verdict(c_64d87e5719e5da97,unknown)).
node(n844,supported) :- status(o_1d5101a6e078601e6386,supported).
node(n844,refuted) :- status(o_1d5101a6e078601e6386,refuted).
node(n844,unknown) :- status(o_1d5101a6e078601e6386,unknown).
node(n845,supported) :- status(o_5a5deb07daea404e63b2,supported).
node(n845,refuted) :- status(o_5a5deb07daea404e63b2,refuted).
node(n845,unknown) :- status(o_5a5deb07daea404e63b2,unknown).
node(n843,supported) :- node(n830,supported), node(n831,supported), node(n832,supported), node(n839,supported), node(n844,supported), node(n845,supported).
node(n843,refuted) :- node(n830,refuted).
node(n843,refuted) :- node(n831,refuted).
node(n843,refuted) :- node(n832,refuted).
node(n843,refuted) :- node(n839,refuted).
node(n843,refuted) :- node(n844,refuted).
node(n843,refuted) :- node(n845,refuted).
node(n843,unknown) :- \+ node(n843,supported), \+ node(n843,refuted).
node(n847,supported) :- status(o_ead5d99fd06dba9ffd82,supported).
node(n847,refuted) :- status(o_ead5d99fd06dba9ffd82,refuted).
node(n847,unknown) :- status(o_ead5d99fd06dba9ffd82,unknown).
node(n848,supported) :- status(o_f269562cca344b7eb949,supported).
node(n848,refuted) :- status(o_f269562cca344b7eb949,refuted).
node(n848,unknown) :- status(o_f269562cca344b7eb949,unknown).
node(n846,supported) :- node(n834,supported), node(n835,supported), node(n836,supported), node(n841,supported), node(n847,supported), node(n848,supported).
node(n846,refuted) :- node(n834,refuted).
node(n846,refuted) :- node(n835,refuted).
node(n846,refuted) :- node(n836,refuted).
node(n846,refuted) :- node(n841,refuted).
node(n846,refuted) :- node(n847,refuted).
node(n846,refuted) :- node(n848,refuted).
node(n846,unknown) :- \+ node(n846,supported), \+ node(n846,refuted).
node(n842,refuted) :- node(n843,refuted), node(n846,refuted), node(n9,refuted).
node(n842,supported) :- node(n843,supported).
node(n842,supported) :- node(n846,supported).
node(n842,supported) :- node(n9,supported).
node(n842,unknown) :- \+ node(n842,supported), \+ node(n842,refuted).
verdict(c_1af9d5b863c8cc34,supported) :- node(n842,supported).
query(verdict(c_1af9d5b863c8cc34,supported)).
verdict(c_1af9d5b863c8cc34,refuted) :- node(n842,refuted).
query(verdict(c_1af9d5b863c8cc34,refuted)).
verdict(c_1af9d5b863c8cc34,unknown) :- node(n842,unknown).
query(verdict(c_1af9d5b863c8cc34,unknown)).
node(n851,supported) :- status(o_2740050efa21cd8e3ad2,supported).
node(n851,refuted) :- status(o_2740050efa21cd8e3ad2,refuted).
node(n851,unknown) :- status(o_2740050efa21cd8e3ad2,unknown).
node(n850,supported) :- node(n830,supported), node(n831,supported), node(n851,supported).
node(n850,refuted) :- node(n830,refuted).
node(n850,refuted) :- node(n831,refuted).
node(n850,refuted) :- node(n851,refuted).
node(n850,unknown) :- \+ node(n850,supported), \+ node(n850,refuted).
node(n853,supported) :- status(o_296d9c71e10224e5b0f4,supported).
node(n853,refuted) :- status(o_296d9c71e10224e5b0f4,refuted).
node(n853,unknown) :- status(o_296d9c71e10224e5b0f4,unknown).
node(n852,supported) :- node(n834,supported), node(n835,supported), node(n853,supported).
node(n852,refuted) :- node(n834,refuted).
node(n852,refuted) :- node(n835,refuted).
node(n852,refuted) :- node(n853,refuted).
node(n852,unknown) :- \+ node(n852,supported), \+ node(n852,refuted).
node(n849,refuted) :- node(n850,refuted), node(n852,refuted), node(n9,refuted).
node(n849,supported) :- node(n850,supported).
node(n849,supported) :- node(n852,supported).
node(n849,supported) :- node(n9,supported).
node(n849,unknown) :- \+ node(n849,supported), \+ node(n849,refuted).
verdict(c_ac734172e132ed77,supported) :- node(n849,supported).
query(verdict(c_ac734172e132ed77,supported)).
verdict(c_ac734172e132ed77,refuted) :- node(n849,refuted).
query(verdict(c_ac734172e132ed77,refuted)).
verdict(c_ac734172e132ed77,unknown) :- node(n849,unknown).
query(verdict(c_ac734172e132ed77,unknown)).
node(n855,supported) :- node(n830,supported), node(n831,supported), node(n832,supported), node(n851,supported).
node(n855,refuted) :- node(n830,refuted).
node(n855,refuted) :- node(n831,refuted).
node(n855,refuted) :- node(n832,refuted).
node(n855,refuted) :- node(n851,refuted).
node(n855,unknown) :- \+ node(n855,supported), \+ node(n855,refuted).
node(n856,supported) :- node(n834,supported), node(n835,supported), node(n836,supported), node(n853,supported).
node(n856,refuted) :- node(n834,refuted).
node(n856,refuted) :- node(n835,refuted).
node(n856,refuted) :- node(n836,refuted).
node(n856,refuted) :- node(n853,refuted).
node(n856,unknown) :- \+ node(n856,supported), \+ node(n856,refuted).
node(n854,refuted) :- node(n855,refuted), node(n856,refuted), node(n9,refuted).
node(n854,supported) :- node(n855,supported).
node(n854,supported) :- node(n856,supported).
node(n854,supported) :- node(n9,supported).
node(n854,unknown) :- \+ node(n854,supported), \+ node(n854,refuted).
verdict(c_cba9267d2e4548b2,supported) :- node(n854,supported).
query(verdict(c_cba9267d2e4548b2,supported)).
verdict(c_cba9267d2e4548b2,refuted) :- node(n854,refuted).
query(verdict(c_cba9267d2e4548b2,refuted)).
verdict(c_cba9267d2e4548b2,unknown) :- node(n854,unknown).
query(verdict(c_cba9267d2e4548b2,unknown)).
node(n859,supported) :- status(o_6a8ca0739d62f7098a04,supported).
node(n859,refuted) :- status(o_6a8ca0739d62f7098a04,refuted).
node(n859,unknown) :- status(o_6a8ca0739d62f7098a04,unknown).
node(n860,supported) :- status(o_49b54e5364d8c3f7c68c,supported).
node(n860,refuted) :- status(o_49b54e5364d8c3f7c68c,refuted).
node(n860,unknown) :- status(o_49b54e5364d8c3f7c68c,unknown).
node(n861,supported) :- status(o_39d4ad977e6f3ce625bd,supported).
node(n861,refuted) :- status(o_39d4ad977e6f3ce625bd,refuted).
node(n861,unknown) :- status(o_39d4ad977e6f3ce625bd,unknown).
node(n858,supported) :- node(n859,supported), node(n860,supported), node(n861,supported).
node(n858,refuted) :- node(n859,refuted).
node(n858,refuted) :- node(n860,refuted).
node(n858,refuted) :- node(n861,refuted).
node(n858,unknown) :- \+ node(n858,supported), \+ node(n858,refuted).
node(n863,supported) :- status(o_8c527c6063c7779d2cc2,supported).
node(n863,refuted) :- status(o_8c527c6063c7779d2cc2,refuted).
node(n863,unknown) :- status(o_8c527c6063c7779d2cc2,unknown).
node(n864,supported) :- status(o_bfa0db2cc3ce43f56517,supported).
node(n864,refuted) :- status(o_bfa0db2cc3ce43f56517,refuted).
node(n864,unknown) :- status(o_bfa0db2cc3ce43f56517,unknown).
node(n865,supported) :- status(o_a8f64c38b70984d54fe6,supported).
node(n865,refuted) :- status(o_a8f64c38b70984d54fe6,refuted).
node(n865,unknown) :- status(o_a8f64c38b70984d54fe6,unknown).
node(n862,supported) :- node(n863,supported), node(n864,supported), node(n865,supported).
node(n862,refuted) :- node(n863,refuted).
node(n862,refuted) :- node(n864,refuted).
node(n862,refuted) :- node(n865,refuted).
node(n862,unknown) :- \+ node(n862,supported), \+ node(n862,refuted).
node(n857,refuted) :- node(n858,refuted), node(n862,refuted), node(n9,refuted).
node(n857,supported) :- node(n858,supported).
node(n857,supported) :- node(n862,supported).
node(n857,supported) :- node(n9,supported).
node(n857,unknown) :- \+ node(n857,supported), \+ node(n857,refuted).
verdict(c_cb9d443aff59cfd8,supported) :- node(n857,supported).
query(verdict(c_cb9d443aff59cfd8,supported)).
verdict(c_cb9d443aff59cfd8,refuted) :- node(n857,refuted).
query(verdict(c_cb9d443aff59cfd8,refuted)).
verdict(c_cb9d443aff59cfd8,unknown) :- node(n857,unknown).
query(verdict(c_cb9d443aff59cfd8,unknown)).
node(n868,supported) :- status(o_ee6764a7a15e0aac64af,supported).
node(n868,refuted) :- status(o_ee6764a7a15e0aac64af,refuted).
node(n868,unknown) :- status(o_ee6764a7a15e0aac64af,unknown).
node(n867,supported) :- node(n859,supported), node(n860,supported), node(n861,supported), node(n868,supported).
node(n867,refuted) :- node(n859,refuted).
node(n867,refuted) :- node(n860,refuted).
node(n867,refuted) :- node(n861,refuted).
node(n867,refuted) :- node(n868,refuted).
node(n867,unknown) :- \+ node(n867,supported), \+ node(n867,refuted).
node(n870,supported) :- status(o_b9381e767327151e2f41,supported).
node(n870,refuted) :- status(o_b9381e767327151e2f41,refuted).
node(n870,unknown) :- status(o_b9381e767327151e2f41,unknown).
node(n869,supported) :- node(n863,supported), node(n864,supported), node(n865,supported), node(n870,supported).
node(n869,refuted) :- node(n863,refuted).
node(n869,refuted) :- node(n864,refuted).
node(n869,refuted) :- node(n865,refuted).
node(n869,refuted) :- node(n870,refuted).
node(n869,unknown) :- \+ node(n869,supported), \+ node(n869,refuted).
node(n866,refuted) :- node(n867,refuted), node(n869,refuted), node(n9,refuted).
node(n866,supported) :- node(n867,supported).
node(n866,supported) :- node(n869,supported).
node(n866,supported) :- node(n9,supported).
node(n866,unknown) :- \+ node(n866,supported), \+ node(n866,refuted).
verdict(c_7f0641e50acc38f4,supported) :- node(n866,supported).
query(verdict(c_7f0641e50acc38f4,supported)).
verdict(c_7f0641e50acc38f4,refuted) :- node(n866,refuted).
query(verdict(c_7f0641e50acc38f4,refuted)).
verdict(c_7f0641e50acc38f4,unknown) :- node(n866,unknown).
query(verdict(c_7f0641e50acc38f4,unknown)).
node(n873,supported) :- status(o_9ffa9a58f0a878071f39,supported).
node(n873,refuted) :- status(o_9ffa9a58f0a878071f39,refuted).
node(n873,unknown) :- status(o_9ffa9a58f0a878071f39,unknown).
node(n874,supported) :- status(o_9db47beaf086b2133d4e,supported).
node(n874,refuted) :- status(o_9db47beaf086b2133d4e,refuted).
node(n874,unknown) :- status(o_9db47beaf086b2133d4e,unknown).
node(n872,supported) :- node(n859,supported), node(n860,supported), node(n861,supported), node(n868,supported), node(n873,supported), node(n874,supported).
node(n872,refuted) :- node(n859,refuted).
node(n872,refuted) :- node(n860,refuted).
node(n872,refuted) :- node(n861,refuted).
node(n872,refuted) :- node(n868,refuted).
node(n872,refuted) :- node(n873,refuted).
node(n872,refuted) :- node(n874,refuted).
node(n872,unknown) :- \+ node(n872,supported), \+ node(n872,refuted).
node(n876,supported) :- status(o_55411322c155f2a8f5ab,supported).
node(n876,refuted) :- status(o_55411322c155f2a8f5ab,refuted).
node(n876,unknown) :- status(o_55411322c155f2a8f5ab,unknown).
node(n877,supported) :- status(o_b2e0e2dd2c2b99b4d2f8,supported).
node(n877,refuted) :- status(o_b2e0e2dd2c2b99b4d2f8,refuted).
node(n877,unknown) :- status(o_b2e0e2dd2c2b99b4d2f8,unknown).
node(n875,supported) :- node(n863,supported), node(n864,supported), node(n865,supported), node(n870,supported), node(n876,supported), node(n877,supported).
node(n875,refuted) :- node(n863,refuted).
node(n875,refuted) :- node(n864,refuted).
node(n875,refuted) :- node(n865,refuted).
node(n875,refuted) :- node(n870,refuted).
node(n875,refuted) :- node(n876,refuted).
node(n875,refuted) :- node(n877,refuted).
node(n875,unknown) :- \+ node(n875,supported), \+ node(n875,refuted).
node(n871,refuted) :- node(n872,refuted), node(n875,refuted), node(n9,refuted).
node(n871,supported) :- node(n872,supported).
node(n871,supported) :- node(n875,supported).
node(n871,supported) :- node(n9,supported).
node(n871,unknown) :- \+ node(n871,supported), \+ node(n871,refuted).
verdict(c_1c0dd417add322d6,supported) :- node(n871,supported).
query(verdict(c_1c0dd417add322d6,supported)).
verdict(c_1c0dd417add322d6,refuted) :- node(n871,refuted).
query(verdict(c_1c0dd417add322d6,refuted)).
verdict(c_1c0dd417add322d6,unknown) :- node(n871,unknown).
query(verdict(c_1c0dd417add322d6,unknown)).
node(n880,supported) :- status(o_6f0656f897bf5527d539,supported).
node(n880,refuted) :- status(o_6f0656f897bf5527d539,refuted).
node(n880,unknown) :- status(o_6f0656f897bf5527d539,unknown).
node(n879,supported) :- node(n859,supported), node(n860,supported), node(n880,supported).
node(n879,refuted) :- node(n859,refuted).
node(n879,refuted) :- node(n860,refuted).
node(n879,refuted) :- node(n880,refuted).
node(n879,unknown) :- \+ node(n879,supported), \+ node(n879,refuted).
node(n882,supported) :- status(o_5fa818e4929428c820d3,supported).
node(n882,refuted) :- status(o_5fa818e4929428c820d3,refuted).
node(n882,unknown) :- status(o_5fa818e4929428c820d3,unknown).
node(n881,supported) :- node(n863,supported), node(n864,supported), node(n882,supported).
node(n881,refuted) :- node(n863,refuted).
node(n881,refuted) :- node(n864,refuted).
node(n881,refuted) :- node(n882,refuted).
node(n881,unknown) :- \+ node(n881,supported), \+ node(n881,refuted).
node(n878,refuted) :- node(n879,refuted), node(n881,refuted), node(n9,refuted).
node(n878,supported) :- node(n879,supported).
node(n878,supported) :- node(n881,supported).
node(n878,supported) :- node(n9,supported).
node(n878,unknown) :- \+ node(n878,supported), \+ node(n878,refuted).
verdict(c_28dfed86b988628a,supported) :- node(n878,supported).
query(verdict(c_28dfed86b988628a,supported)).
verdict(c_28dfed86b988628a,refuted) :- node(n878,refuted).
query(verdict(c_28dfed86b988628a,refuted)).
verdict(c_28dfed86b988628a,unknown) :- node(n878,unknown).
query(verdict(c_28dfed86b988628a,unknown)).
node(n884,supported) :- node(n859,supported), node(n860,supported), node(n861,supported), node(n880,supported).
node(n884,refuted) :- node(n859,refuted).
node(n884,refuted) :- node(n860,refuted).
node(n884,refuted) :- node(n861,refuted).
node(n884,refuted) :- node(n880,refuted).
node(n884,unknown) :- \+ node(n884,supported), \+ node(n884,refuted).
node(n885,supported) :- node(n863,supported), node(n864,supported), node(n865,supported), node(n882,supported).
node(n885,refuted) :- node(n863,refuted).
node(n885,refuted) :- node(n864,refuted).
node(n885,refuted) :- node(n865,refuted).
node(n885,refuted) :- node(n882,refuted).
node(n885,unknown) :- \+ node(n885,supported), \+ node(n885,refuted).
node(n883,refuted) :- node(n884,refuted), node(n885,refuted), node(n9,refuted).
node(n883,supported) :- node(n884,supported).
node(n883,supported) :- node(n885,supported).
node(n883,supported) :- node(n9,supported).
node(n883,unknown) :- \+ node(n883,supported), \+ node(n883,refuted).
verdict(c_a36928ab6f36af50,supported) :- node(n883,supported).
query(verdict(c_a36928ab6f36af50,supported)).
verdict(c_a36928ab6f36af50,refuted) :- node(n883,refuted).
query(verdict(c_a36928ab6f36af50,refuted)).
verdict(c_a36928ab6f36af50,unknown) :- node(n883,unknown).
query(verdict(c_a36928ab6f36af50,unknown)).
node(n888,supported) :- status(o_282b0eeede0e2ae213dc,supported).
node(n888,refuted) :- status(o_282b0eeede0e2ae213dc,refuted).
node(n888,unknown) :- status(o_282b0eeede0e2ae213dc,unknown).
node(n889,supported) :- status(o_c962032ef8e0fc3e442c,supported).
node(n889,refuted) :- status(o_c962032ef8e0fc3e442c,refuted).
node(n889,unknown) :- status(o_c962032ef8e0fc3e442c,unknown).
node(n890,supported) :- status(o_2484d806017feff4162b,supported).
node(n890,refuted) :- status(o_2484d806017feff4162b,refuted).
node(n890,unknown) :- status(o_2484d806017feff4162b,unknown).
node(n887,supported) :- node(n888,supported), node(n889,supported), node(n890,supported).
node(n887,refuted) :- node(n888,refuted).
node(n887,refuted) :- node(n889,refuted).
node(n887,refuted) :- node(n890,refuted).
node(n887,unknown) :- \+ node(n887,supported), \+ node(n887,refuted).
node(n892,supported) :- status(o_a24e2d8acc2b09ec3074,supported).
node(n892,refuted) :- status(o_a24e2d8acc2b09ec3074,refuted).
node(n892,unknown) :- status(o_a24e2d8acc2b09ec3074,unknown).
node(n893,supported) :- status(o_fe14b7290fb5c040e291,supported).
node(n893,refuted) :- status(o_fe14b7290fb5c040e291,refuted).
node(n893,unknown) :- status(o_fe14b7290fb5c040e291,unknown).
node(n894,supported) :- status(o_067d48913581ce03d73f,supported).
node(n894,refuted) :- status(o_067d48913581ce03d73f,refuted).
node(n894,unknown) :- status(o_067d48913581ce03d73f,unknown).
node(n891,supported) :- node(n892,supported), node(n893,supported), node(n894,supported).
node(n891,refuted) :- node(n892,refuted).
node(n891,refuted) :- node(n893,refuted).
node(n891,refuted) :- node(n894,refuted).
node(n891,unknown) :- \+ node(n891,supported), \+ node(n891,refuted).
node(n886,refuted) :- node(n887,refuted), node(n891,refuted), node(n9,refuted).
node(n886,supported) :- node(n887,supported).
node(n886,supported) :- node(n891,supported).
node(n886,supported) :- node(n9,supported).
node(n886,unknown) :- \+ node(n886,supported), \+ node(n886,refuted).
verdict(c_be0dde85fa0d34a5,supported) :- node(n886,supported).
query(verdict(c_be0dde85fa0d34a5,supported)).
verdict(c_be0dde85fa0d34a5,refuted) :- node(n886,refuted).
query(verdict(c_be0dde85fa0d34a5,refuted)).
verdict(c_be0dde85fa0d34a5,unknown) :- node(n886,unknown).
query(verdict(c_be0dde85fa0d34a5,unknown)).
node(n897,supported) :- status(o_1a28d002e22762578962,supported).
node(n897,refuted) :- status(o_1a28d002e22762578962,refuted).
node(n897,unknown) :- status(o_1a28d002e22762578962,unknown).
node(n896,supported) :- node(n888,supported), node(n889,supported), node(n890,supported), node(n897,supported).
node(n896,refuted) :- node(n888,refuted).
node(n896,refuted) :- node(n889,refuted).
node(n896,refuted) :- node(n890,refuted).
node(n896,refuted) :- node(n897,refuted).
node(n896,unknown) :- \+ node(n896,supported), \+ node(n896,refuted).
node(n899,supported) :- status(o_e9cf1fefc4ed6c16069b,supported).
node(n899,refuted) :- status(o_e9cf1fefc4ed6c16069b,refuted).
node(n899,unknown) :- status(o_e9cf1fefc4ed6c16069b,unknown).
node(n898,supported) :- node(n892,supported), node(n893,supported), node(n894,supported), node(n899,supported).
node(n898,refuted) :- node(n892,refuted).
node(n898,refuted) :- node(n893,refuted).
node(n898,refuted) :- node(n894,refuted).
node(n898,refuted) :- node(n899,refuted).
node(n898,unknown) :- \+ node(n898,supported), \+ node(n898,refuted).
node(n895,refuted) :- node(n896,refuted), node(n898,refuted), node(n9,refuted).
node(n895,supported) :- node(n896,supported).
node(n895,supported) :- node(n898,supported).
node(n895,supported) :- node(n9,supported).
node(n895,unknown) :- \+ node(n895,supported), \+ node(n895,refuted).
verdict(c_54b5253ced75ab99,supported) :- node(n895,supported).
query(verdict(c_54b5253ced75ab99,supported)).
verdict(c_54b5253ced75ab99,refuted) :- node(n895,refuted).
query(verdict(c_54b5253ced75ab99,refuted)).
verdict(c_54b5253ced75ab99,unknown) :- node(n895,unknown).
query(verdict(c_54b5253ced75ab99,unknown)).
node(n902,supported) :- status(o_9f5926b404d083ce0741,supported).
node(n902,refuted) :- status(o_9f5926b404d083ce0741,refuted).
node(n902,unknown) :- status(o_9f5926b404d083ce0741,unknown).
node(n903,supported) :- status(o_2660a0f3072cc3cbb448,supported).
node(n903,refuted) :- status(o_2660a0f3072cc3cbb448,refuted).
node(n903,unknown) :- status(o_2660a0f3072cc3cbb448,unknown).
node(n901,supported) :- node(n888,supported), node(n889,supported), node(n890,supported), node(n897,supported), node(n902,supported), node(n903,supported).
node(n901,refuted) :- node(n888,refuted).
node(n901,refuted) :- node(n889,refuted).
node(n901,refuted) :- node(n890,refuted).
node(n901,refuted) :- node(n897,refuted).
node(n901,refuted) :- node(n902,refuted).
node(n901,refuted) :- node(n903,refuted).
node(n901,unknown) :- \+ node(n901,supported), \+ node(n901,refuted).
node(n905,supported) :- status(o_b4585eb123471c6fd0bc,supported).
node(n905,refuted) :- status(o_b4585eb123471c6fd0bc,refuted).
node(n905,unknown) :- status(o_b4585eb123471c6fd0bc,unknown).
node(n906,supported) :- status(o_e1012bd785724620575a,supported).
node(n906,refuted) :- status(o_e1012bd785724620575a,refuted).
node(n906,unknown) :- status(o_e1012bd785724620575a,unknown).
node(n904,supported) :- node(n892,supported), node(n893,supported), node(n894,supported), node(n899,supported), node(n905,supported), node(n906,supported).
node(n904,refuted) :- node(n892,refuted).
node(n904,refuted) :- node(n893,refuted).
node(n904,refuted) :- node(n894,refuted).
node(n904,refuted) :- node(n899,refuted).
node(n904,refuted) :- node(n905,refuted).
node(n904,refuted) :- node(n906,refuted).
node(n904,unknown) :- \+ node(n904,supported), \+ node(n904,refuted).
node(n900,refuted) :- node(n901,refuted), node(n904,refuted), node(n9,refuted).
node(n900,supported) :- node(n901,supported).
node(n900,supported) :- node(n904,supported).
node(n900,supported) :- node(n9,supported).
node(n900,unknown) :- \+ node(n900,supported), \+ node(n900,refuted).
verdict(c_c18a604e1ee6e4ed,supported) :- node(n900,supported).
query(verdict(c_c18a604e1ee6e4ed,supported)).
verdict(c_c18a604e1ee6e4ed,refuted) :- node(n900,refuted).
query(verdict(c_c18a604e1ee6e4ed,refuted)).
verdict(c_c18a604e1ee6e4ed,unknown) :- node(n900,unknown).
query(verdict(c_c18a604e1ee6e4ed,unknown)).
node(n909,supported) :- status(o_f94b64a13313a3c9ba93,supported).
node(n909,refuted) :- status(o_f94b64a13313a3c9ba93,refuted).
node(n909,unknown) :- status(o_f94b64a13313a3c9ba93,unknown).
node(n908,supported) :- node(n888,supported), node(n889,supported), node(n909,supported).
node(n908,refuted) :- node(n888,refuted).
node(n908,refuted) :- node(n889,refuted).
node(n908,refuted) :- node(n909,refuted).
node(n908,unknown) :- \+ node(n908,supported), \+ node(n908,refuted).
node(n911,supported) :- status(o_79ab174a376372e7b44b,supported).
node(n911,refuted) :- status(o_79ab174a376372e7b44b,refuted).
node(n911,unknown) :- status(o_79ab174a376372e7b44b,unknown).
node(n910,supported) :- node(n892,supported), node(n893,supported), node(n911,supported).
node(n910,refuted) :- node(n892,refuted).
node(n910,refuted) :- node(n893,refuted).
node(n910,refuted) :- node(n911,refuted).
node(n910,unknown) :- \+ node(n910,supported), \+ node(n910,refuted).
node(n907,refuted) :- node(n908,refuted), node(n910,refuted), node(n9,refuted).
node(n907,supported) :- node(n908,supported).
node(n907,supported) :- node(n910,supported).
node(n907,supported) :- node(n9,supported).
node(n907,unknown) :- \+ node(n907,supported), \+ node(n907,refuted).
verdict(c_c869b6ab5ea66477,supported) :- node(n907,supported).
query(verdict(c_c869b6ab5ea66477,supported)).
verdict(c_c869b6ab5ea66477,refuted) :- node(n907,refuted).
query(verdict(c_c869b6ab5ea66477,refuted)).
verdict(c_c869b6ab5ea66477,unknown) :- node(n907,unknown).
query(verdict(c_c869b6ab5ea66477,unknown)).
node(n913,supported) :- node(n888,supported), node(n889,supported), node(n890,supported), node(n909,supported).
node(n913,refuted) :- node(n888,refuted).
node(n913,refuted) :- node(n889,refuted).
node(n913,refuted) :- node(n890,refuted).
node(n913,refuted) :- node(n909,refuted).
node(n913,unknown) :- \+ node(n913,supported), \+ node(n913,refuted).
node(n914,supported) :- node(n892,supported), node(n893,supported), node(n894,supported), node(n911,supported).
node(n914,refuted) :- node(n892,refuted).
node(n914,refuted) :- node(n893,refuted).
node(n914,refuted) :- node(n894,refuted).
node(n914,refuted) :- node(n911,refuted).
node(n914,unknown) :- \+ node(n914,supported), \+ node(n914,refuted).
node(n912,refuted) :- node(n913,refuted), node(n914,refuted), node(n9,refuted).
node(n912,supported) :- node(n913,supported).
node(n912,supported) :- node(n914,supported).
node(n912,supported) :- node(n9,supported).
node(n912,unknown) :- \+ node(n912,supported), \+ node(n912,refuted).
verdict(c_0a92c4b02f8faa4c,supported) :- node(n912,supported).
query(verdict(c_0a92c4b02f8faa4c,supported)).
verdict(c_0a92c4b02f8faa4c,refuted) :- node(n912,refuted).
query(verdict(c_0a92c4b02f8faa4c,refuted)).
verdict(c_0a92c4b02f8faa4c,unknown) :- node(n912,unknown).
query(verdict(c_0a92c4b02f8faa4c,unknown)).
node(n917,supported) :- status(o_5139bfd40782e56ade39,supported).
node(n917,refuted) :- status(o_5139bfd40782e56ade39,refuted).
node(n917,unknown) :- status(o_5139bfd40782e56ade39,unknown).
node(n918,supported) :- status(o_c06fd871273a6216d27f,supported).
node(n918,refuted) :- status(o_c06fd871273a6216d27f,refuted).
node(n918,unknown) :- status(o_c06fd871273a6216d27f,unknown).
node(n919,supported) :- status(o_7098b9c5cf36ef2599dc,supported).
node(n919,refuted) :- status(o_7098b9c5cf36ef2599dc,refuted).
node(n919,unknown) :- status(o_7098b9c5cf36ef2599dc,unknown).
node(n916,supported) :- node(n917,supported), node(n918,supported), node(n919,supported).
node(n916,refuted) :- node(n917,refuted).
node(n916,refuted) :- node(n918,refuted).
node(n916,refuted) :- node(n919,refuted).
node(n916,unknown) :- \+ node(n916,supported), \+ node(n916,refuted).
node(n921,supported) :- status(o_8cdfaa3d67d8f824e0b7,supported).
node(n921,refuted) :- status(o_8cdfaa3d67d8f824e0b7,refuted).
node(n921,unknown) :- status(o_8cdfaa3d67d8f824e0b7,unknown).
node(n922,supported) :- status(o_5e6eecbefd831250cd15,supported).
node(n922,refuted) :- status(o_5e6eecbefd831250cd15,refuted).
node(n922,unknown) :- status(o_5e6eecbefd831250cd15,unknown).
node(n923,supported) :- status(o_5f95e0e8218de5370eb2,supported).
node(n923,refuted) :- status(o_5f95e0e8218de5370eb2,refuted).
node(n923,unknown) :- status(o_5f95e0e8218de5370eb2,unknown).
node(n920,supported) :- node(n921,supported), node(n922,supported), node(n923,supported).
node(n920,refuted) :- node(n921,refuted).
node(n920,refuted) :- node(n922,refuted).
node(n920,refuted) :- node(n923,refuted).
node(n920,unknown) :- \+ node(n920,supported), \+ node(n920,refuted).
node(n915,refuted) :- node(n916,refuted), node(n920,refuted), node(n9,refuted).
node(n915,supported) :- node(n916,supported).
node(n915,supported) :- node(n920,supported).
node(n915,supported) :- node(n9,supported).
node(n915,unknown) :- \+ node(n915,supported), \+ node(n915,refuted).
verdict(c_7ea4b2df9d7ec955,supported) :- node(n915,supported).
query(verdict(c_7ea4b2df9d7ec955,supported)).
verdict(c_7ea4b2df9d7ec955,refuted) :- node(n915,refuted).
query(verdict(c_7ea4b2df9d7ec955,refuted)).
verdict(c_7ea4b2df9d7ec955,unknown) :- node(n915,unknown).
query(verdict(c_7ea4b2df9d7ec955,unknown)).
node(n926,supported) :- status(o_7fcc9eebcaed6057b543,supported).
node(n926,refuted) :- status(o_7fcc9eebcaed6057b543,refuted).
node(n926,unknown) :- status(o_7fcc9eebcaed6057b543,unknown).
node(n925,supported) :- node(n917,supported), node(n918,supported), node(n919,supported), node(n926,supported).
node(n925,refuted) :- node(n917,refuted).
node(n925,refuted) :- node(n918,refuted).
node(n925,refuted) :- node(n919,refuted).
node(n925,refuted) :- node(n926,refuted).
node(n925,unknown) :- \+ node(n925,supported), \+ node(n925,refuted).
node(n928,supported) :- status(o_59fb0062c74428db12c2,supported).
node(n928,refuted) :- status(o_59fb0062c74428db12c2,refuted).
node(n928,unknown) :- status(o_59fb0062c74428db12c2,unknown).
node(n927,supported) :- node(n921,supported), node(n922,supported), node(n923,supported), node(n928,supported).
node(n927,refuted) :- node(n921,refuted).
node(n927,refuted) :- node(n922,refuted).
node(n927,refuted) :- node(n923,refuted).
node(n927,refuted) :- node(n928,refuted).
node(n927,unknown) :- \+ node(n927,supported), \+ node(n927,refuted).
node(n924,refuted) :- node(n925,refuted), node(n927,refuted), node(n9,refuted).
node(n924,supported) :- node(n925,supported).
node(n924,supported) :- node(n927,supported).
node(n924,supported) :- node(n9,supported).
node(n924,unknown) :- \+ node(n924,supported), \+ node(n924,refuted).
verdict(c_a22b048542a8a68c,supported) :- node(n924,supported).
query(verdict(c_a22b048542a8a68c,supported)).
verdict(c_a22b048542a8a68c,refuted) :- node(n924,refuted).
query(verdict(c_a22b048542a8a68c,refuted)).
verdict(c_a22b048542a8a68c,unknown) :- node(n924,unknown).
query(verdict(c_a22b048542a8a68c,unknown)).
node(n931,supported) :- status(o_24262540d5953308caf3,supported).
node(n931,refuted) :- status(o_24262540d5953308caf3,refuted).
node(n931,unknown) :- status(o_24262540d5953308caf3,unknown).
node(n932,supported) :- status(o_baf788ab55cf8cdc5ae2,supported).
node(n932,refuted) :- status(o_baf788ab55cf8cdc5ae2,refuted).
node(n932,unknown) :- status(o_baf788ab55cf8cdc5ae2,unknown).
node(n930,supported) :- node(n917,supported), node(n918,supported), node(n919,supported), node(n926,supported), node(n931,supported), node(n932,supported).
node(n930,refuted) :- node(n917,refuted).
node(n930,refuted) :- node(n918,refuted).
node(n930,refuted) :- node(n919,refuted).
node(n930,refuted) :- node(n926,refuted).
node(n930,refuted) :- node(n931,refuted).
node(n930,refuted) :- node(n932,refuted).
node(n930,unknown) :- \+ node(n930,supported), \+ node(n930,refuted).
node(n934,supported) :- status(o_f3c7e8b383ece912bd6b,supported).
node(n934,refuted) :- status(o_f3c7e8b383ece912bd6b,refuted).
node(n934,unknown) :- status(o_f3c7e8b383ece912bd6b,unknown).
node(n935,supported) :- status(o_c372185a0374844fd3b1,supported).
node(n935,refuted) :- status(o_c372185a0374844fd3b1,refuted).
node(n935,unknown) :- status(o_c372185a0374844fd3b1,unknown).
node(n933,supported) :- node(n921,supported), node(n922,supported), node(n923,supported), node(n928,supported), node(n934,supported), node(n935,supported).
node(n933,refuted) :- node(n921,refuted).
node(n933,refuted) :- node(n922,refuted).
node(n933,refuted) :- node(n923,refuted).
node(n933,refuted) :- node(n928,refuted).
node(n933,refuted) :- node(n934,refuted).
node(n933,refuted) :- node(n935,refuted).
node(n933,unknown) :- \+ node(n933,supported), \+ node(n933,refuted).
node(n929,refuted) :- node(n930,refuted), node(n933,refuted), node(n9,refuted).
node(n929,supported) :- node(n930,supported).
node(n929,supported) :- node(n933,supported).
node(n929,supported) :- node(n9,supported).
node(n929,unknown) :- \+ node(n929,supported), \+ node(n929,refuted).
verdict(c_73098175526858d2,supported) :- node(n929,supported).
query(verdict(c_73098175526858d2,supported)).
verdict(c_73098175526858d2,refuted) :- node(n929,refuted).
query(verdict(c_73098175526858d2,refuted)).
verdict(c_73098175526858d2,unknown) :- node(n929,unknown).
query(verdict(c_73098175526858d2,unknown)).
node(n938,supported) :- status(o_8d949ffb95a211bc43dd,supported).
node(n938,refuted) :- status(o_8d949ffb95a211bc43dd,refuted).
node(n938,unknown) :- status(o_8d949ffb95a211bc43dd,unknown).
node(n937,supported) :- node(n917,supported), node(n918,supported), node(n938,supported).
node(n937,refuted) :- node(n917,refuted).
node(n937,refuted) :- node(n918,refuted).
node(n937,refuted) :- node(n938,refuted).
node(n937,unknown) :- \+ node(n937,supported), \+ node(n937,refuted).
node(n940,supported) :- status(o_ef0ab1f5dddf0f0055fb,supported).
node(n940,refuted) :- status(o_ef0ab1f5dddf0f0055fb,refuted).
node(n940,unknown) :- status(o_ef0ab1f5dddf0f0055fb,unknown).
node(n939,supported) :- node(n921,supported), node(n922,supported), node(n940,supported).
node(n939,refuted) :- node(n921,refuted).
node(n939,refuted) :- node(n922,refuted).
node(n939,refuted) :- node(n940,refuted).
node(n939,unknown) :- \+ node(n939,supported), \+ node(n939,refuted).
node(n936,refuted) :- node(n937,refuted), node(n939,refuted), node(n9,refuted).
node(n936,supported) :- node(n937,supported).
node(n936,supported) :- node(n939,supported).
node(n936,supported) :- node(n9,supported).
node(n936,unknown) :- \+ node(n936,supported), \+ node(n936,refuted).
verdict(c_57c13adbdfbd06fe,supported) :- node(n936,supported).
query(verdict(c_57c13adbdfbd06fe,supported)).
verdict(c_57c13adbdfbd06fe,refuted) :- node(n936,refuted).
query(verdict(c_57c13adbdfbd06fe,refuted)).
verdict(c_57c13adbdfbd06fe,unknown) :- node(n936,unknown).
query(verdict(c_57c13adbdfbd06fe,unknown)).
node(n942,supported) :- node(n917,supported), node(n918,supported), node(n919,supported), node(n938,supported).
node(n942,refuted) :- node(n917,refuted).
node(n942,refuted) :- node(n918,refuted).
node(n942,refuted) :- node(n919,refuted).
node(n942,refuted) :- node(n938,refuted).
node(n942,unknown) :- \+ node(n942,supported), \+ node(n942,refuted).
node(n943,supported) :- node(n921,supported), node(n922,supported), node(n923,supported), node(n940,supported).
node(n943,refuted) :- node(n921,refuted).
node(n943,refuted) :- node(n922,refuted).
node(n943,refuted) :- node(n923,refuted).
node(n943,refuted) :- node(n940,refuted).
node(n943,unknown) :- \+ node(n943,supported), \+ node(n943,refuted).
node(n941,refuted) :- node(n942,refuted), node(n943,refuted), node(n9,refuted).
node(n941,supported) :- node(n942,supported).
node(n941,supported) :- node(n943,supported).
node(n941,supported) :- node(n9,supported).
node(n941,unknown) :- \+ node(n941,supported), \+ node(n941,refuted).
verdict(c_bc1188fe02c2e652,supported) :- node(n941,supported).
query(verdict(c_bc1188fe02c2e652,supported)).
verdict(c_bc1188fe02c2e652,refuted) :- node(n941,refuted).
query(verdict(c_bc1188fe02c2e652,refuted)).
verdict(c_bc1188fe02c2e652,unknown) :- node(n941,unknown).
query(verdict(c_bc1188fe02c2e652,unknown)).
node(n946,supported) :- status(o_6006db5469a8bb36335a,supported).
node(n946,refuted) :- status(o_6006db5469a8bb36335a,refuted).
node(n946,unknown) :- status(o_6006db5469a8bb36335a,unknown).
node(n947,supported) :- status(o_ffe189c0930848dba1dd,supported).
node(n947,refuted) :- status(o_ffe189c0930848dba1dd,refuted).
node(n947,unknown) :- status(o_ffe189c0930848dba1dd,unknown).
node(n948,supported) :- status(o_1eb3ad58ddb7568b584e,supported).
node(n948,refuted) :- status(o_1eb3ad58ddb7568b584e,refuted).
node(n948,unknown) :- status(o_1eb3ad58ddb7568b584e,unknown).
node(n945,supported) :- node(n946,supported), node(n947,supported), node(n948,supported).
node(n945,refuted) :- node(n946,refuted).
node(n945,refuted) :- node(n947,refuted).
node(n945,refuted) :- node(n948,refuted).
node(n945,unknown) :- \+ node(n945,supported), \+ node(n945,refuted).
node(n950,supported) :- status(o_a2cafaf57d29df52be1d,supported).
node(n950,refuted) :- status(o_a2cafaf57d29df52be1d,refuted).
node(n950,unknown) :- status(o_a2cafaf57d29df52be1d,unknown).
node(n951,supported) :- status(o_a3a77687b0c023d8effa,supported).
node(n951,refuted) :- status(o_a3a77687b0c023d8effa,refuted).
node(n951,unknown) :- status(o_a3a77687b0c023d8effa,unknown).
node(n952,supported) :- status(o_6a57fc79bac900faaff5,supported).
node(n952,refuted) :- status(o_6a57fc79bac900faaff5,refuted).
node(n952,unknown) :- status(o_6a57fc79bac900faaff5,unknown).
node(n949,supported) :- node(n950,supported), node(n951,supported), node(n952,supported).
node(n949,refuted) :- node(n950,refuted).
node(n949,refuted) :- node(n951,refuted).
node(n949,refuted) :- node(n952,refuted).
node(n949,unknown) :- \+ node(n949,supported), \+ node(n949,refuted).
node(n944,refuted) :- node(n945,refuted), node(n949,refuted), node(n9,refuted).
node(n944,supported) :- node(n945,supported).
node(n944,supported) :- node(n949,supported).
node(n944,supported) :- node(n9,supported).
node(n944,unknown) :- \+ node(n944,supported), \+ node(n944,refuted).
verdict(c_f568375e3623dae0,supported) :- node(n944,supported).
query(verdict(c_f568375e3623dae0,supported)).
verdict(c_f568375e3623dae0,refuted) :- node(n944,refuted).
query(verdict(c_f568375e3623dae0,refuted)).
verdict(c_f568375e3623dae0,unknown) :- node(n944,unknown).
query(verdict(c_f568375e3623dae0,unknown)).
node(n955,supported) :- status(o_8b223a9a9aadc04ac805,supported).
node(n955,refuted) :- status(o_8b223a9a9aadc04ac805,refuted).
node(n955,unknown) :- status(o_8b223a9a9aadc04ac805,unknown).
node(n954,supported) :- node(n946,supported), node(n947,supported), node(n948,supported), node(n955,supported).
node(n954,refuted) :- node(n946,refuted).
node(n954,refuted) :- node(n947,refuted).
node(n954,refuted) :- node(n948,refuted).
node(n954,refuted) :- node(n955,refuted).
node(n954,unknown) :- \+ node(n954,supported), \+ node(n954,refuted).
node(n957,supported) :- status(o_cf592a381edc0896fee2,supported).
node(n957,refuted) :- status(o_cf592a381edc0896fee2,refuted).
node(n957,unknown) :- status(o_cf592a381edc0896fee2,unknown).
node(n956,supported) :- node(n950,supported), node(n951,supported), node(n952,supported), node(n957,supported).
node(n956,refuted) :- node(n950,refuted).
node(n956,refuted) :- node(n951,refuted).
node(n956,refuted) :- node(n952,refuted).
node(n956,refuted) :- node(n957,refuted).
node(n956,unknown) :- \+ node(n956,supported), \+ node(n956,refuted).
node(n953,refuted) :- node(n954,refuted), node(n956,refuted), node(n9,refuted).
node(n953,supported) :- node(n954,supported).
node(n953,supported) :- node(n956,supported).
node(n953,supported) :- node(n9,supported).
node(n953,unknown) :- \+ node(n953,supported), \+ node(n953,refuted).
verdict(c_a1e3a5dc60e9c9a6,supported) :- node(n953,supported).
query(verdict(c_a1e3a5dc60e9c9a6,supported)).
verdict(c_a1e3a5dc60e9c9a6,refuted) :- node(n953,refuted).
query(verdict(c_a1e3a5dc60e9c9a6,refuted)).
verdict(c_a1e3a5dc60e9c9a6,unknown) :- node(n953,unknown).
query(verdict(c_a1e3a5dc60e9c9a6,unknown)).
node(n960,supported) :- status(o_b79af642d2eb4e465c09,supported).
node(n960,refuted) :- status(o_b79af642d2eb4e465c09,refuted).
node(n960,unknown) :- status(o_b79af642d2eb4e465c09,unknown).
node(n961,supported) :- status(o_cd3137c453912cda677b,supported).
node(n961,refuted) :- status(o_cd3137c453912cda677b,refuted).
node(n961,unknown) :- status(o_cd3137c453912cda677b,unknown).
node(n959,supported) :- node(n946,supported), node(n947,supported), node(n948,supported), node(n955,supported), node(n960,supported), node(n961,supported).
node(n959,refuted) :- node(n946,refuted).
node(n959,refuted) :- node(n947,refuted).
node(n959,refuted) :- node(n948,refuted).
node(n959,refuted) :- node(n955,refuted).
node(n959,refuted) :- node(n960,refuted).
node(n959,refuted) :- node(n961,refuted).
node(n959,unknown) :- \+ node(n959,supported), \+ node(n959,refuted).
node(n963,supported) :- status(o_98ac4e8ce3149bea26cc,supported).
node(n963,refuted) :- status(o_98ac4e8ce3149bea26cc,refuted).
node(n963,unknown) :- status(o_98ac4e8ce3149bea26cc,unknown).
node(n964,supported) :- status(o_27067b9952b6212d7904,supported).
node(n964,refuted) :- status(o_27067b9952b6212d7904,refuted).
node(n964,unknown) :- status(o_27067b9952b6212d7904,unknown).
node(n962,supported) :- node(n950,supported), node(n951,supported), node(n952,supported), node(n957,supported), node(n963,supported), node(n964,supported).
node(n962,refuted) :- node(n950,refuted).
node(n962,refuted) :- node(n951,refuted).
node(n962,refuted) :- node(n952,refuted).
node(n962,refuted) :- node(n957,refuted).
node(n962,refuted) :- node(n963,refuted).
node(n962,refuted) :- node(n964,refuted).
node(n962,unknown) :- \+ node(n962,supported), \+ node(n962,refuted).
node(n958,refuted) :- node(n959,refuted), node(n962,refuted), node(n9,refuted).
node(n958,supported) :- node(n959,supported).
node(n958,supported) :- node(n962,supported).
node(n958,supported) :- node(n9,supported).
node(n958,unknown) :- \+ node(n958,supported), \+ node(n958,refuted).
verdict(c_11d82cd2bdf7146e,supported) :- node(n958,supported).
query(verdict(c_11d82cd2bdf7146e,supported)).
verdict(c_11d82cd2bdf7146e,refuted) :- node(n958,refuted).
query(verdict(c_11d82cd2bdf7146e,refuted)).
verdict(c_11d82cd2bdf7146e,unknown) :- node(n958,unknown).
query(verdict(c_11d82cd2bdf7146e,unknown)).
node(n967,supported) :- status(o_25540f753245f4ab1ef6,supported).
node(n967,refuted) :- status(o_25540f753245f4ab1ef6,refuted).
node(n967,unknown) :- status(o_25540f753245f4ab1ef6,unknown).
node(n966,supported) :- node(n946,supported), node(n947,supported), node(n967,supported).
node(n966,refuted) :- node(n946,refuted).
node(n966,refuted) :- node(n947,refuted).
node(n966,refuted) :- node(n967,refuted).
node(n966,unknown) :- \+ node(n966,supported), \+ node(n966,refuted).
node(n969,supported) :- status(o_85979373934f63781532,supported).
node(n969,refuted) :- status(o_85979373934f63781532,refuted).
node(n969,unknown) :- status(o_85979373934f63781532,unknown).
node(n968,supported) :- node(n950,supported), node(n951,supported), node(n969,supported).
node(n968,refuted) :- node(n950,refuted).
node(n968,refuted) :- node(n951,refuted).
node(n968,refuted) :- node(n969,refuted).
node(n968,unknown) :- \+ node(n968,supported), \+ node(n968,refuted).
node(n965,refuted) :- node(n966,refuted), node(n968,refuted), node(n9,refuted).
node(n965,supported) :- node(n966,supported).
node(n965,supported) :- node(n968,supported).
node(n965,supported) :- node(n9,supported).
node(n965,unknown) :- \+ node(n965,supported), \+ node(n965,refuted).
verdict(c_4aca4c5932104bf0,supported) :- node(n965,supported).
query(verdict(c_4aca4c5932104bf0,supported)).
verdict(c_4aca4c5932104bf0,refuted) :- node(n965,refuted).
query(verdict(c_4aca4c5932104bf0,refuted)).
verdict(c_4aca4c5932104bf0,unknown) :- node(n965,unknown).
query(verdict(c_4aca4c5932104bf0,unknown)).
node(n971,supported) :- node(n946,supported), node(n947,supported), node(n948,supported), node(n967,supported).
node(n971,refuted) :- node(n946,refuted).
node(n971,refuted) :- node(n947,refuted).
node(n971,refuted) :- node(n948,refuted).
node(n971,refuted) :- node(n967,refuted).
node(n971,unknown) :- \+ node(n971,supported), \+ node(n971,refuted).
node(n972,supported) :- node(n950,supported), node(n951,supported), node(n952,supported), node(n969,supported).
node(n972,refuted) :- node(n950,refuted).
node(n972,refuted) :- node(n951,refuted).
node(n972,refuted) :- node(n952,refuted).
node(n972,refuted) :- node(n969,refuted).
node(n972,unknown) :- \+ node(n972,supported), \+ node(n972,refuted).
node(n970,refuted) :- node(n971,refuted), node(n972,refuted), node(n9,refuted).
node(n970,supported) :- node(n971,supported).
node(n970,supported) :- node(n972,supported).
node(n970,supported) :- node(n9,supported).
node(n970,unknown) :- \+ node(n970,supported), \+ node(n970,refuted).
verdict(c_122282acd0d3eda5,supported) :- node(n970,supported).
query(verdict(c_122282acd0d3eda5,supported)).
verdict(c_122282acd0d3eda5,refuted) :- node(n970,refuted).
query(verdict(c_122282acd0d3eda5,refuted)).
verdict(c_122282acd0d3eda5,unknown) :- node(n970,unknown).
query(verdict(c_122282acd0d3eda5,unknown)).
node(n975,supported) :- status(o_f379d85f0b7e899d148d,supported).
node(n975,refuted) :- status(o_f379d85f0b7e899d148d,refuted).
node(n975,unknown) :- status(o_f379d85f0b7e899d148d,unknown).
node(n976,supported) :- status(o_23cb7c2855eb34b2f2e4,supported).
node(n976,refuted) :- status(o_23cb7c2855eb34b2f2e4,refuted).
node(n976,unknown) :- status(o_23cb7c2855eb34b2f2e4,unknown).
node(n977,supported) :- status(o_3efa494945075eb5cc33,supported).
node(n977,refuted) :- status(o_3efa494945075eb5cc33,refuted).
node(n977,unknown) :- status(o_3efa494945075eb5cc33,unknown).
node(n974,supported) :- node(n975,supported), node(n976,supported), node(n977,supported).
node(n974,refuted) :- node(n975,refuted).
node(n974,refuted) :- node(n976,refuted).
node(n974,refuted) :- node(n977,refuted).
node(n974,unknown) :- \+ node(n974,supported), \+ node(n974,refuted).
node(n979,supported) :- status(o_ec0af894b25e2a747005,supported).
node(n979,refuted) :- status(o_ec0af894b25e2a747005,refuted).
node(n979,unknown) :- status(o_ec0af894b25e2a747005,unknown).
node(n980,supported) :- status(o_95187676549c4c9c3ee5,supported).
node(n980,refuted) :- status(o_95187676549c4c9c3ee5,refuted).
node(n980,unknown) :- status(o_95187676549c4c9c3ee5,unknown).
node(n981,supported) :- status(o_43e88a49e533a5c3591b,supported).
node(n981,refuted) :- status(o_43e88a49e533a5c3591b,refuted).
node(n981,unknown) :- status(o_43e88a49e533a5c3591b,unknown).
node(n978,supported) :- node(n979,supported), node(n980,supported), node(n981,supported).
node(n978,refuted) :- node(n979,refuted).
node(n978,refuted) :- node(n980,refuted).
node(n978,refuted) :- node(n981,refuted).
node(n978,unknown) :- \+ node(n978,supported), \+ node(n978,refuted).
node(n973,refuted) :- node(n974,refuted), node(n978,refuted), node(n9,refuted).
node(n973,supported) :- node(n974,supported).
node(n973,supported) :- node(n978,supported).
node(n973,supported) :- node(n9,supported).
node(n973,unknown) :- \+ node(n973,supported), \+ node(n973,refuted).
verdict(c_c34ac85acbbf2d44,supported) :- node(n973,supported).
query(verdict(c_c34ac85acbbf2d44,supported)).
verdict(c_c34ac85acbbf2d44,refuted) :- node(n973,refuted).
query(verdict(c_c34ac85acbbf2d44,refuted)).
verdict(c_c34ac85acbbf2d44,unknown) :- node(n973,unknown).
query(verdict(c_c34ac85acbbf2d44,unknown)).
node(n984,supported) :- status(o_c8c83c24746f4bff99c6,supported).
node(n984,refuted) :- status(o_c8c83c24746f4bff99c6,refuted).
node(n984,unknown) :- status(o_c8c83c24746f4bff99c6,unknown).
node(n983,supported) :- node(n975,supported), node(n976,supported), node(n977,supported), node(n984,supported).
node(n983,refuted) :- node(n975,refuted).
node(n983,refuted) :- node(n976,refuted).
node(n983,refuted) :- node(n977,refuted).
node(n983,refuted) :- node(n984,refuted).
node(n983,unknown) :- \+ node(n983,supported), \+ node(n983,refuted).
node(n986,supported) :- status(o_24557400479bfc39193e,supported).
node(n986,refuted) :- status(o_24557400479bfc39193e,refuted).
node(n986,unknown) :- status(o_24557400479bfc39193e,unknown).
node(n985,supported) :- node(n979,supported), node(n980,supported), node(n981,supported), node(n986,supported).
node(n985,refuted) :- node(n979,refuted).
node(n985,refuted) :- node(n980,refuted).
node(n985,refuted) :- node(n981,refuted).
node(n985,refuted) :- node(n986,refuted).
node(n985,unknown) :- \+ node(n985,supported), \+ node(n985,refuted).
node(n982,refuted) :- node(n983,refuted), node(n985,refuted), node(n9,refuted).
node(n982,supported) :- node(n983,supported).
node(n982,supported) :- node(n985,supported).
node(n982,supported) :- node(n9,supported).
node(n982,unknown) :- \+ node(n982,supported), \+ node(n982,refuted).
verdict(c_e25f5e0832878911,supported) :- node(n982,supported).
query(verdict(c_e25f5e0832878911,supported)).
verdict(c_e25f5e0832878911,refuted) :- node(n982,refuted).
query(verdict(c_e25f5e0832878911,refuted)).
verdict(c_e25f5e0832878911,unknown) :- node(n982,unknown).
query(verdict(c_e25f5e0832878911,unknown)).
node(n989,supported) :- status(o_d5ed9e5b3ffd9412ef53,supported).
node(n989,refuted) :- status(o_d5ed9e5b3ffd9412ef53,refuted).
node(n989,unknown) :- status(o_d5ed9e5b3ffd9412ef53,unknown).
node(n990,supported) :- status(o_38515954ea72f56b822b,supported).
node(n990,refuted) :- status(o_38515954ea72f56b822b,refuted).
node(n990,unknown) :- status(o_38515954ea72f56b822b,unknown).
node(n988,supported) :- node(n975,supported), node(n976,supported), node(n977,supported), node(n984,supported), node(n989,supported), node(n990,supported).
node(n988,refuted) :- node(n975,refuted).
node(n988,refuted) :- node(n976,refuted).
node(n988,refuted) :- node(n977,refuted).
node(n988,refuted) :- node(n984,refuted).
node(n988,refuted) :- node(n989,refuted).
node(n988,refuted) :- node(n990,refuted).
node(n988,unknown) :- \+ node(n988,supported), \+ node(n988,refuted).
node(n992,supported) :- status(o_6c3e121720c0f995051c,supported).
node(n992,refuted) :- status(o_6c3e121720c0f995051c,refuted).
node(n992,unknown) :- status(o_6c3e121720c0f995051c,unknown).
node(n993,supported) :- status(o_4e59651f9d07fdd29fc1,supported).
node(n993,refuted) :- status(o_4e59651f9d07fdd29fc1,refuted).
node(n993,unknown) :- status(o_4e59651f9d07fdd29fc1,unknown).
node(n991,supported) :- node(n979,supported), node(n980,supported), node(n981,supported), node(n986,supported), node(n992,supported), node(n993,supported).
node(n991,refuted) :- node(n979,refuted).
node(n991,refuted) :- node(n980,refuted).
node(n991,refuted) :- node(n981,refuted).
node(n991,refuted) :- node(n986,refuted).
node(n991,refuted) :- node(n992,refuted).
node(n991,refuted) :- node(n993,refuted).
node(n991,unknown) :- \+ node(n991,supported), \+ node(n991,refuted).
node(n987,refuted) :- node(n988,refuted), node(n991,refuted), node(n9,refuted).
node(n987,supported) :- node(n988,supported).
node(n987,supported) :- node(n991,supported).
node(n987,supported) :- node(n9,supported).
node(n987,unknown) :- \+ node(n987,supported), \+ node(n987,refuted).
verdict(c_d7ead5306f512a20,supported) :- node(n987,supported).
query(verdict(c_d7ead5306f512a20,supported)).
verdict(c_d7ead5306f512a20,refuted) :- node(n987,refuted).
query(verdict(c_d7ead5306f512a20,refuted)).
verdict(c_d7ead5306f512a20,unknown) :- node(n987,unknown).
query(verdict(c_d7ead5306f512a20,unknown)).
node(n996,supported) :- status(o_436b2fb505dcd7e18488,supported).
node(n996,refuted) :- status(o_436b2fb505dcd7e18488,refuted).
node(n996,unknown) :- status(o_436b2fb505dcd7e18488,unknown).
node(n995,supported) :- node(n975,supported), node(n976,supported), node(n996,supported).
node(n995,refuted) :- node(n975,refuted).
node(n995,refuted) :- node(n976,refuted).
node(n995,refuted) :- node(n996,refuted).
node(n995,unknown) :- \+ node(n995,supported), \+ node(n995,refuted).
node(n998,supported) :- status(o_cf5b840eeaf8532c4cf7,supported).
node(n998,refuted) :- status(o_cf5b840eeaf8532c4cf7,refuted).
node(n998,unknown) :- status(o_cf5b840eeaf8532c4cf7,unknown).
node(n997,supported) :- node(n979,supported), node(n980,supported), node(n998,supported).
node(n997,refuted) :- node(n979,refuted).
node(n997,refuted) :- node(n980,refuted).
node(n997,refuted) :- node(n998,refuted).
node(n997,unknown) :- \+ node(n997,supported), \+ node(n997,refuted).
node(n994,refuted) :- node(n995,refuted), node(n997,refuted), node(n9,refuted).
node(n994,supported) :- node(n995,supported).
node(n994,supported) :- node(n997,supported).
node(n994,supported) :- node(n9,supported).
node(n994,unknown) :- \+ node(n994,supported), \+ node(n994,refuted).
verdict(c_dca8c8c623a77746,supported) :- node(n994,supported).
query(verdict(c_dca8c8c623a77746,supported)).
verdict(c_dca8c8c623a77746,refuted) :- node(n994,refuted).
query(verdict(c_dca8c8c623a77746,refuted)).
verdict(c_dca8c8c623a77746,unknown) :- node(n994,unknown).
query(verdict(c_dca8c8c623a77746,unknown)).
node(n1000,supported) :- node(n975,supported), node(n976,supported), node(n977,supported), node(n996,supported).
node(n1000,refuted) :- node(n975,refuted).
node(n1000,refuted) :- node(n976,refuted).
node(n1000,refuted) :- node(n977,refuted).
node(n1000,refuted) :- node(n996,refuted).
node(n1000,unknown) :- \+ node(n1000,supported), \+ node(n1000,refuted).
node(n1001,supported) :- node(n979,supported), node(n980,supported), node(n981,supported), node(n998,supported).
node(n1001,refuted) :- node(n979,refuted).
node(n1001,refuted) :- node(n980,refuted).
node(n1001,refuted) :- node(n981,refuted).
node(n1001,refuted) :- node(n998,refuted).
node(n1001,unknown) :- \+ node(n1001,supported), \+ node(n1001,refuted).
node(n999,refuted) :- node(n1000,refuted), node(n1001,refuted), node(n9,refuted).
node(n999,supported) :- node(n1000,supported).
node(n999,supported) :- node(n1001,supported).
node(n999,supported) :- node(n9,supported).
node(n999,unknown) :- \+ node(n999,supported), \+ node(n999,refuted).
verdict(c_50a142b0bfbcb4fa,supported) :- node(n999,supported).
query(verdict(c_50a142b0bfbcb4fa,supported)).
verdict(c_50a142b0bfbcb4fa,refuted) :- node(n999,refuted).
query(verdict(c_50a142b0bfbcb4fa,refuted)).
verdict(c_50a142b0bfbcb4fa,unknown) :- node(n999,unknown).
query(verdict(c_50a142b0bfbcb4fa,unknown)).
node(n1004,supported) :- status(o_4ef8985688890ab10c08,supported).
node(n1004,refuted) :- status(o_4ef8985688890ab10c08,refuted).
node(n1004,unknown) :- status(o_4ef8985688890ab10c08,unknown).
node(n1005,supported) :- status(o_2c0c82c2ab7a93b68682,supported).
node(n1005,refuted) :- status(o_2c0c82c2ab7a93b68682,refuted).
node(n1005,unknown) :- status(o_2c0c82c2ab7a93b68682,unknown).
node(n1006,supported) :- status(o_00ee12c5168b51bcfb9c,supported).
node(n1006,refuted) :- status(o_00ee12c5168b51bcfb9c,refuted).
node(n1006,unknown) :- status(o_00ee12c5168b51bcfb9c,unknown).
node(n1003,supported) :- node(n1004,supported), node(n1005,supported), node(n1006,supported).
node(n1003,refuted) :- node(n1004,refuted).
node(n1003,refuted) :- node(n1005,refuted).
node(n1003,refuted) :- node(n1006,refuted).
node(n1003,unknown) :- \+ node(n1003,supported), \+ node(n1003,refuted).
node(n1008,supported) :- status(o_9e468dae4c85caf4db6f,supported).
node(n1008,refuted) :- status(o_9e468dae4c85caf4db6f,refuted).
node(n1008,unknown) :- status(o_9e468dae4c85caf4db6f,unknown).
node(n1009,supported) :- status(o_4139c0be4d60ab6af521,supported).
node(n1009,refuted) :- status(o_4139c0be4d60ab6af521,refuted).
node(n1009,unknown) :- status(o_4139c0be4d60ab6af521,unknown).
node(n1010,supported) :- status(o_9128613b8b75f4088975,supported).
node(n1010,refuted) :- status(o_9128613b8b75f4088975,refuted).
node(n1010,unknown) :- status(o_9128613b8b75f4088975,unknown).
node(n1007,supported) :- node(n1008,supported), node(n1009,supported), node(n1010,supported).
node(n1007,refuted) :- node(n1008,refuted).
node(n1007,refuted) :- node(n1009,refuted).
node(n1007,refuted) :- node(n1010,refuted).
node(n1007,unknown) :- \+ node(n1007,supported), \+ node(n1007,refuted).
node(n1002,refuted) :- node(n1003,refuted), node(n1007,refuted), node(n9,refuted).
node(n1002,supported) :- node(n1003,supported).
node(n1002,supported) :- node(n1007,supported).
node(n1002,supported) :- node(n9,supported).
node(n1002,unknown) :- \+ node(n1002,supported), \+ node(n1002,refuted).
verdict(c_e43517890ef28179,supported) :- node(n1002,supported).
query(verdict(c_e43517890ef28179,supported)).
verdict(c_e43517890ef28179,refuted) :- node(n1002,refuted).
query(verdict(c_e43517890ef28179,refuted)).
verdict(c_e43517890ef28179,unknown) :- node(n1002,unknown).
query(verdict(c_e43517890ef28179,unknown)).
node(n1013,supported) :- status(o_666ee0929e55230cbc24,supported).
node(n1013,refuted) :- status(o_666ee0929e55230cbc24,refuted).
node(n1013,unknown) :- status(o_666ee0929e55230cbc24,unknown).
node(n1012,supported) :- node(n1004,supported), node(n1005,supported), node(n1006,supported), node(n1013,supported).
node(n1012,refuted) :- node(n1004,refuted).
node(n1012,refuted) :- node(n1005,refuted).
node(n1012,refuted) :- node(n1006,refuted).
node(n1012,refuted) :- node(n1013,refuted).
node(n1012,unknown) :- \+ node(n1012,supported), \+ node(n1012,refuted).
node(n1015,supported) :- status(o_1463d1e3cfbc58e7352b,supported).
node(n1015,refuted) :- status(o_1463d1e3cfbc58e7352b,refuted).
node(n1015,unknown) :- status(o_1463d1e3cfbc58e7352b,unknown).
node(n1014,supported) :- node(n1008,supported), node(n1009,supported), node(n1010,supported), node(n1015,supported).
node(n1014,refuted) :- node(n1008,refuted).
node(n1014,refuted) :- node(n1009,refuted).
node(n1014,refuted) :- node(n1010,refuted).
node(n1014,refuted) :- node(n1015,refuted).
node(n1014,unknown) :- \+ node(n1014,supported), \+ node(n1014,refuted).
node(n1011,refuted) :- node(n1012,refuted), node(n1014,refuted), node(n9,refuted).
node(n1011,supported) :- node(n1012,supported).
node(n1011,supported) :- node(n1014,supported).
node(n1011,supported) :- node(n9,supported).
node(n1011,unknown) :- \+ node(n1011,supported), \+ node(n1011,refuted).
verdict(c_dc0cd2daa46e5cf5,supported) :- node(n1011,supported).
query(verdict(c_dc0cd2daa46e5cf5,supported)).
verdict(c_dc0cd2daa46e5cf5,refuted) :- node(n1011,refuted).
query(verdict(c_dc0cd2daa46e5cf5,refuted)).
verdict(c_dc0cd2daa46e5cf5,unknown) :- node(n1011,unknown).
query(verdict(c_dc0cd2daa46e5cf5,unknown)).
node(n1018,supported) :- status(o_cb23442a430b57b88624,supported).
node(n1018,refuted) :- status(o_cb23442a430b57b88624,refuted).
node(n1018,unknown) :- status(o_cb23442a430b57b88624,unknown).
node(n1019,supported) :- status(o_4171044df128b0a97450,supported).
node(n1019,refuted) :- status(o_4171044df128b0a97450,refuted).
node(n1019,unknown) :- status(o_4171044df128b0a97450,unknown).
node(n1017,supported) :- node(n1004,supported), node(n1005,supported), node(n1006,supported), node(n1013,supported), node(n1018,supported), node(n1019,supported).
node(n1017,refuted) :- node(n1004,refuted).
node(n1017,refuted) :- node(n1005,refuted).
node(n1017,refuted) :- node(n1006,refuted).
node(n1017,refuted) :- node(n1013,refuted).
node(n1017,refuted) :- node(n1018,refuted).
node(n1017,refuted) :- node(n1019,refuted).
node(n1017,unknown) :- \+ node(n1017,supported), \+ node(n1017,refuted).
node(n1021,supported) :- status(o_26aa38a902d5110ade35,supported).
node(n1021,refuted) :- status(o_26aa38a902d5110ade35,refuted).
node(n1021,unknown) :- status(o_26aa38a902d5110ade35,unknown).
node(n1022,supported) :- status(o_d45a8408c07e3f494380,supported).
node(n1022,refuted) :- status(o_d45a8408c07e3f494380,refuted).
node(n1022,unknown) :- status(o_d45a8408c07e3f494380,unknown).
node(n1020,supported) :- node(n1008,supported), node(n1009,supported), node(n1010,supported), node(n1015,supported), node(n1021,supported), node(n1022,supported).
node(n1020,refuted) :- node(n1008,refuted).
node(n1020,refuted) :- node(n1009,refuted).
node(n1020,refuted) :- node(n1010,refuted).
node(n1020,refuted) :- node(n1015,refuted).
node(n1020,refuted) :- node(n1021,refuted).
node(n1020,refuted) :- node(n1022,refuted).
node(n1020,unknown) :- \+ node(n1020,supported), \+ node(n1020,refuted).
node(n1016,refuted) :- node(n1017,refuted), node(n1020,refuted), node(n9,refuted).
node(n1016,supported) :- node(n1017,supported).
node(n1016,supported) :- node(n1020,supported).
node(n1016,supported) :- node(n9,supported).
node(n1016,unknown) :- \+ node(n1016,supported), \+ node(n1016,refuted).
verdict(c_9d0b401d9579da9c,supported) :- node(n1016,supported).
query(verdict(c_9d0b401d9579da9c,supported)).
verdict(c_9d0b401d9579da9c,refuted) :- node(n1016,refuted).
query(verdict(c_9d0b401d9579da9c,refuted)).
verdict(c_9d0b401d9579da9c,unknown) :- node(n1016,unknown).
query(verdict(c_9d0b401d9579da9c,unknown)).
node(n1025,supported) :- status(o_50d118dc80796a4f69b2,supported).
node(n1025,refuted) :- status(o_50d118dc80796a4f69b2,refuted).
node(n1025,unknown) :- status(o_50d118dc80796a4f69b2,unknown).
node(n1024,supported) :- node(n1004,supported), node(n1005,supported), node(n1025,supported).
node(n1024,refuted) :- node(n1004,refuted).
node(n1024,refuted) :- node(n1005,refuted).
node(n1024,refuted) :- node(n1025,refuted).
node(n1024,unknown) :- \+ node(n1024,supported), \+ node(n1024,refuted).
node(n1027,supported) :- status(o_2b0d4fddbf0ec894eae7,supported).
node(n1027,refuted) :- status(o_2b0d4fddbf0ec894eae7,refuted).
node(n1027,unknown) :- status(o_2b0d4fddbf0ec894eae7,unknown).
node(n1026,supported) :- node(n1008,supported), node(n1009,supported), node(n1027,supported).
node(n1026,refuted) :- node(n1008,refuted).
node(n1026,refuted) :- node(n1009,refuted).
node(n1026,refuted) :- node(n1027,refuted).
node(n1026,unknown) :- \+ node(n1026,supported), \+ node(n1026,refuted).
node(n1023,refuted) :- node(n1024,refuted), node(n1026,refuted), node(n9,refuted).
node(n1023,supported) :- node(n1024,supported).
node(n1023,supported) :- node(n1026,supported).
node(n1023,supported) :- node(n9,supported).
node(n1023,unknown) :- \+ node(n1023,supported), \+ node(n1023,refuted).
verdict(c_7ce2e15c04fe6725,supported) :- node(n1023,supported).
query(verdict(c_7ce2e15c04fe6725,supported)).
verdict(c_7ce2e15c04fe6725,refuted) :- node(n1023,refuted).
query(verdict(c_7ce2e15c04fe6725,refuted)).
verdict(c_7ce2e15c04fe6725,unknown) :- node(n1023,unknown).
query(verdict(c_7ce2e15c04fe6725,unknown)).
node(n1029,supported) :- node(n1004,supported), node(n1005,supported), node(n1006,supported), node(n1025,supported).
node(n1029,refuted) :- node(n1004,refuted).
node(n1029,refuted) :- node(n1005,refuted).
node(n1029,refuted) :- node(n1006,refuted).
node(n1029,refuted) :- node(n1025,refuted).
node(n1029,unknown) :- \+ node(n1029,supported), \+ node(n1029,refuted).
node(n1030,supported) :- node(n1008,supported), node(n1009,supported), node(n1010,supported), node(n1027,supported).
node(n1030,refuted) :- node(n1008,refuted).
node(n1030,refuted) :- node(n1009,refuted).
node(n1030,refuted) :- node(n1010,refuted).
node(n1030,refuted) :- node(n1027,refuted).
node(n1030,unknown) :- \+ node(n1030,supported), \+ node(n1030,refuted).
node(n1028,refuted) :- node(n1029,refuted), node(n1030,refuted), node(n9,refuted).
node(n1028,supported) :- node(n1029,supported).
node(n1028,supported) :- node(n1030,supported).
node(n1028,supported) :- node(n9,supported).
node(n1028,unknown) :- \+ node(n1028,supported), \+ node(n1028,refuted).
verdict(c_03dd5a2d503e1445,supported) :- node(n1028,supported).
query(verdict(c_03dd5a2d503e1445,supported)).
verdict(c_03dd5a2d503e1445,refuted) :- node(n1028,refuted).
query(verdict(c_03dd5a2d503e1445,refuted)).
verdict(c_03dd5a2d503e1445,unknown) :- node(n1028,unknown).
query(verdict(c_03dd5a2d503e1445,unknown)).
node(n1033,supported) :- status(o_e586c7c125e503a83f45,supported).
node(n1033,refuted) :- status(o_e586c7c125e503a83f45,refuted).
node(n1033,unknown) :- status(o_e586c7c125e503a83f45,unknown).
node(n1034,supported) :- status(o_f416673ee51932105ce7,supported).
node(n1034,refuted) :- status(o_f416673ee51932105ce7,refuted).
node(n1034,unknown) :- status(o_f416673ee51932105ce7,unknown).
node(n1035,supported) :- status(o_3ae6fded58dbf316a781,supported).
node(n1035,refuted) :- status(o_3ae6fded58dbf316a781,refuted).
node(n1035,unknown) :- status(o_3ae6fded58dbf316a781,unknown).
node(n1032,supported) :- node(n1033,supported), node(n1034,supported), node(n1035,supported).
node(n1032,refuted) :- node(n1033,refuted).
node(n1032,refuted) :- node(n1034,refuted).
node(n1032,refuted) :- node(n1035,refuted).
node(n1032,unknown) :- \+ node(n1032,supported), \+ node(n1032,refuted).
node(n1031,refuted) :- node(n1032,refuted), node(n9,refuted).
node(n1031,supported) :- node(n1032,supported).
node(n1031,supported) :- node(n9,supported).
node(n1031,unknown) :- \+ node(n1031,supported), \+ node(n1031,refuted).
verdict(c_6b1bab9fee1b1af7,supported) :- node(n1031,supported).
query(verdict(c_6b1bab9fee1b1af7,supported)).
verdict(c_6b1bab9fee1b1af7,refuted) :- node(n1031,refuted).
query(verdict(c_6b1bab9fee1b1af7,refuted)).
verdict(c_6b1bab9fee1b1af7,unknown) :- node(n1031,unknown).
query(verdict(c_6b1bab9fee1b1af7,unknown)).
node(n1038,supported) :- status(o_50144a626201feee3c3f,supported).
node(n1038,refuted) :- status(o_50144a626201feee3c3f,refuted).
node(n1038,unknown) :- status(o_50144a626201feee3c3f,unknown).
node(n1037,supported) :- node(n1033,supported), node(n1034,supported), node(n1035,supported), node(n1038,supported).
node(n1037,refuted) :- node(n1033,refuted).
node(n1037,refuted) :- node(n1034,refuted).
node(n1037,refuted) :- node(n1035,refuted).
node(n1037,refuted) :- node(n1038,refuted).
node(n1037,unknown) :- \+ node(n1037,supported), \+ node(n1037,refuted).
node(n1036,refuted) :- node(n1037,refuted), node(n9,refuted).
node(n1036,supported) :- node(n1037,supported).
node(n1036,supported) :- node(n9,supported).
node(n1036,unknown) :- \+ node(n1036,supported), \+ node(n1036,refuted).
verdict(c_5485d9e22a529c89,supported) :- node(n1036,supported).
query(verdict(c_5485d9e22a529c89,supported)).
verdict(c_5485d9e22a529c89,refuted) :- node(n1036,refuted).
query(verdict(c_5485d9e22a529c89,refuted)).
verdict(c_5485d9e22a529c89,unknown) :- node(n1036,unknown).
query(verdict(c_5485d9e22a529c89,unknown)).
node(n1041,supported) :- status(o_b08059c328fac992f433,supported).
node(n1041,refuted) :- status(o_b08059c328fac992f433,refuted).
node(n1041,unknown) :- status(o_b08059c328fac992f433,unknown).
node(n1042,supported) :- status(o_33ba4315c21af1a92d64,supported).
node(n1042,refuted) :- status(o_33ba4315c21af1a92d64,refuted).
node(n1042,unknown) :- status(o_33ba4315c21af1a92d64,unknown).
node(n1040,supported) :- node(n1033,supported), node(n1034,supported), node(n1035,supported), node(n1038,supported), node(n1041,supported), node(n1042,supported).
node(n1040,refuted) :- node(n1033,refuted).
node(n1040,refuted) :- node(n1034,refuted).
node(n1040,refuted) :- node(n1035,refuted).
node(n1040,refuted) :- node(n1038,refuted).
node(n1040,refuted) :- node(n1041,refuted).
node(n1040,refuted) :- node(n1042,refuted).
node(n1040,unknown) :- \+ node(n1040,supported), \+ node(n1040,refuted).
node(n1039,refuted) :- node(n1040,refuted), node(n9,refuted).
node(n1039,supported) :- node(n1040,supported).
node(n1039,supported) :- node(n9,supported).
node(n1039,unknown) :- \+ node(n1039,supported), \+ node(n1039,refuted).
verdict(c_e1addada8df6bd5a,supported) :- node(n1039,supported).
query(verdict(c_e1addada8df6bd5a,supported)).
verdict(c_e1addada8df6bd5a,refuted) :- node(n1039,refuted).
query(verdict(c_e1addada8df6bd5a,refuted)).
verdict(c_e1addada8df6bd5a,unknown) :- node(n1039,unknown).
query(verdict(c_e1addada8df6bd5a,unknown)).
node(n1045,supported) :- status(o_3e7654f5eff05ce9a048,supported).
node(n1045,refuted) :- status(o_3e7654f5eff05ce9a048,refuted).
node(n1045,unknown) :- status(o_3e7654f5eff05ce9a048,unknown).
node(n1044,supported) :- node(n1033,supported), node(n1034,supported), node(n1045,supported).
node(n1044,refuted) :- node(n1033,refuted).
node(n1044,refuted) :- node(n1034,refuted).
node(n1044,refuted) :- node(n1045,refuted).
node(n1044,unknown) :- \+ node(n1044,supported), \+ node(n1044,refuted).
node(n1043,refuted) :- node(n1044,refuted), node(n9,refuted).
node(n1043,supported) :- node(n1044,supported).
node(n1043,supported) :- node(n9,supported).
node(n1043,unknown) :- \+ node(n1043,supported), \+ node(n1043,refuted).
verdict(c_1a123d25e87ffa04,supported) :- node(n1043,supported).
query(verdict(c_1a123d25e87ffa04,supported)).
verdict(c_1a123d25e87ffa04,refuted) :- node(n1043,refuted).
query(verdict(c_1a123d25e87ffa04,refuted)).
verdict(c_1a123d25e87ffa04,unknown) :- node(n1043,unknown).
query(verdict(c_1a123d25e87ffa04,unknown)).
node(n1047,supported) :- node(n1033,supported), node(n1034,supported), node(n1035,supported), node(n1045,supported).
node(n1047,refuted) :- node(n1033,refuted).
node(n1047,refuted) :- node(n1034,refuted).
node(n1047,refuted) :- node(n1035,refuted).
node(n1047,refuted) :- node(n1045,refuted).
node(n1047,unknown) :- \+ node(n1047,supported), \+ node(n1047,refuted).
node(n1046,refuted) :- node(n1047,refuted), node(n9,refuted).
node(n1046,supported) :- node(n1047,supported).
node(n1046,supported) :- node(n9,supported).
node(n1046,unknown) :- \+ node(n1046,supported), \+ node(n1046,refuted).
verdict(c_28b43f35f0bbc038,supported) :- node(n1046,supported).
query(verdict(c_28b43f35f0bbc038,supported)).
verdict(c_28b43f35f0bbc038,refuted) :- node(n1046,refuted).
query(verdict(c_28b43f35f0bbc038,refuted)).
verdict(c_28b43f35f0bbc038,unknown) :- node(n1046,unknown).
query(verdict(c_28b43f35f0bbc038,unknown)).
node(n1050,supported) :- status(o_6d5b604603c6b90e0b2c,supported).
node(n1050,refuted) :- status(o_6d5b604603c6b90e0b2c,refuted).
node(n1050,unknown) :- status(o_6d5b604603c6b90e0b2c,unknown).
node(n1051,supported) :- status(o_bf0eeadaa213a18ef935,supported).
node(n1051,refuted) :- status(o_bf0eeadaa213a18ef935,refuted).
node(n1051,unknown) :- status(o_bf0eeadaa213a18ef935,unknown).
node(n1052,supported) :- status(o_11c681a32d34bb0b962b,supported).
node(n1052,refuted) :- status(o_11c681a32d34bb0b962b,refuted).
node(n1052,unknown) :- status(o_11c681a32d34bb0b962b,unknown).
node(n1049,supported) :- node(n1050,supported), node(n1051,supported), node(n1052,supported).
node(n1049,refuted) :- node(n1050,refuted).
node(n1049,refuted) :- node(n1051,refuted).
node(n1049,refuted) :- node(n1052,refuted).
node(n1049,unknown) :- \+ node(n1049,supported), \+ node(n1049,refuted).
node(n1054,supported) :- status(o_9611065846119469d907,supported).
node(n1054,refuted) :- status(o_9611065846119469d907,refuted).
node(n1054,unknown) :- status(o_9611065846119469d907,unknown).
node(n1055,supported) :- status(o_ba4d4e5aaa4c7d3a761b,supported).
node(n1055,refuted) :- status(o_ba4d4e5aaa4c7d3a761b,refuted).
node(n1055,unknown) :- status(o_ba4d4e5aaa4c7d3a761b,unknown).
node(n1056,supported) :- status(o_2df00fd361a432eb191f,supported).
node(n1056,refuted) :- status(o_2df00fd361a432eb191f,refuted).
node(n1056,unknown) :- status(o_2df00fd361a432eb191f,unknown).
node(n1053,supported) :- node(n1054,supported), node(n1055,supported), node(n1056,supported).
node(n1053,refuted) :- node(n1054,refuted).
node(n1053,refuted) :- node(n1055,refuted).
node(n1053,refuted) :- node(n1056,refuted).
node(n1053,unknown) :- \+ node(n1053,supported), \+ node(n1053,refuted).
node(n1048,refuted) :- node(n1049,refuted), node(n1053,refuted), node(n9,refuted).
node(n1048,supported) :- node(n1049,supported).
node(n1048,supported) :- node(n1053,supported).
node(n1048,supported) :- node(n9,supported).
node(n1048,unknown) :- \+ node(n1048,supported), \+ node(n1048,refuted).
verdict(c_68f61c701b633728,supported) :- node(n1048,supported).
query(verdict(c_68f61c701b633728,supported)).
verdict(c_68f61c701b633728,refuted) :- node(n1048,refuted).
query(verdict(c_68f61c701b633728,refuted)).
verdict(c_68f61c701b633728,unknown) :- node(n1048,unknown).
query(verdict(c_68f61c701b633728,unknown)).
node(n1059,supported) :- status(o_8a198ead5a0d5c3d74a5,supported).
node(n1059,refuted) :- status(o_8a198ead5a0d5c3d74a5,refuted).
node(n1059,unknown) :- status(o_8a198ead5a0d5c3d74a5,unknown).
node(n1058,supported) :- node(n1050,supported), node(n1051,supported), node(n1052,supported), node(n1059,supported).
node(n1058,refuted) :- node(n1050,refuted).
node(n1058,refuted) :- node(n1051,refuted).
node(n1058,refuted) :- node(n1052,refuted).
node(n1058,refuted) :- node(n1059,refuted).
node(n1058,unknown) :- \+ node(n1058,supported), \+ node(n1058,refuted).
node(n1061,supported) :- status(o_8bb75eed9e3568e62796,supported).
node(n1061,refuted) :- status(o_8bb75eed9e3568e62796,refuted).
node(n1061,unknown) :- status(o_8bb75eed9e3568e62796,unknown).
node(n1060,supported) :- node(n1054,supported), node(n1055,supported), node(n1056,supported), node(n1061,supported).
node(n1060,refuted) :- node(n1054,refuted).
node(n1060,refuted) :- node(n1055,refuted).
node(n1060,refuted) :- node(n1056,refuted).
node(n1060,refuted) :- node(n1061,refuted).
node(n1060,unknown) :- \+ node(n1060,supported), \+ node(n1060,refuted).
node(n1057,refuted) :- node(n1058,refuted), node(n1060,refuted), node(n9,refuted).
node(n1057,supported) :- node(n1058,supported).
node(n1057,supported) :- node(n1060,supported).
node(n1057,supported) :- node(n9,supported).
node(n1057,unknown) :- \+ node(n1057,supported), \+ node(n1057,refuted).
verdict(c_31e8c1da695f28e9,supported) :- node(n1057,supported).
query(verdict(c_31e8c1da695f28e9,supported)).
verdict(c_31e8c1da695f28e9,refuted) :- node(n1057,refuted).
query(verdict(c_31e8c1da695f28e9,refuted)).
verdict(c_31e8c1da695f28e9,unknown) :- node(n1057,unknown).
query(verdict(c_31e8c1da695f28e9,unknown)).
node(n1064,supported) :- status(o_942e669a2e4c0ac6da2f,supported).
node(n1064,refuted) :- status(o_942e669a2e4c0ac6da2f,refuted).
node(n1064,unknown) :- status(o_942e669a2e4c0ac6da2f,unknown).
node(n1065,supported) :- status(o_86839479ce6c1c05b265,supported).
node(n1065,refuted) :- status(o_86839479ce6c1c05b265,refuted).
node(n1065,unknown) :- status(o_86839479ce6c1c05b265,unknown).
node(n1063,supported) :- node(n1050,supported), node(n1051,supported), node(n1052,supported), node(n1059,supported), node(n1064,supported), node(n1065,supported).
node(n1063,refuted) :- node(n1050,refuted).
node(n1063,refuted) :- node(n1051,refuted).
node(n1063,refuted) :- node(n1052,refuted).
node(n1063,refuted) :- node(n1059,refuted).
node(n1063,refuted) :- node(n1064,refuted).
node(n1063,refuted) :- node(n1065,refuted).
node(n1063,unknown) :- \+ node(n1063,supported), \+ node(n1063,refuted).
node(n1067,supported) :- status(o_70438dfbe15b479379a4,supported).
node(n1067,refuted) :- status(o_70438dfbe15b479379a4,refuted).
node(n1067,unknown) :- status(o_70438dfbe15b479379a4,unknown).
node(n1068,supported) :- status(o_ea3b2b940713174a0692,supported).
node(n1068,refuted) :- status(o_ea3b2b940713174a0692,refuted).
node(n1068,unknown) :- status(o_ea3b2b940713174a0692,unknown).
node(n1066,supported) :- node(n1054,supported), node(n1055,supported), node(n1056,supported), node(n1061,supported), node(n1067,supported), node(n1068,supported).
node(n1066,refuted) :- node(n1054,refuted).
node(n1066,refuted) :- node(n1055,refuted).
node(n1066,refuted) :- node(n1056,refuted).
node(n1066,refuted) :- node(n1061,refuted).
node(n1066,refuted) :- node(n1067,refuted).
node(n1066,refuted) :- node(n1068,refuted).
node(n1066,unknown) :- \+ node(n1066,supported), \+ node(n1066,refuted).
node(n1062,refuted) :- node(n1063,refuted), node(n1066,refuted), node(n9,refuted).
node(n1062,supported) :- node(n1063,supported).
node(n1062,supported) :- node(n1066,supported).
node(n1062,supported) :- node(n9,supported).
node(n1062,unknown) :- \+ node(n1062,supported), \+ node(n1062,refuted).
verdict(c_6122ad1a655380b0,supported) :- node(n1062,supported).
query(verdict(c_6122ad1a655380b0,supported)).
verdict(c_6122ad1a655380b0,refuted) :- node(n1062,refuted).
query(verdict(c_6122ad1a655380b0,refuted)).
verdict(c_6122ad1a655380b0,unknown) :- node(n1062,unknown).
query(verdict(c_6122ad1a655380b0,unknown)).
node(n1071,supported) :- status(o_083f65da051fe17281d9,supported).
node(n1071,refuted) :- status(o_083f65da051fe17281d9,refuted).
node(n1071,unknown) :- status(o_083f65da051fe17281d9,unknown).
node(n1070,supported) :- node(n1050,supported), node(n1051,supported), node(n1071,supported).
node(n1070,refuted) :- node(n1050,refuted).
node(n1070,refuted) :- node(n1051,refuted).
node(n1070,refuted) :- node(n1071,refuted).
node(n1070,unknown) :- \+ node(n1070,supported), \+ node(n1070,refuted).
node(n1073,supported) :- status(o_3c94decaae2a28b334fd,supported).
node(n1073,refuted) :- status(o_3c94decaae2a28b334fd,refuted).
node(n1073,unknown) :- status(o_3c94decaae2a28b334fd,unknown).
node(n1072,supported) :- node(n1054,supported), node(n1055,supported), node(n1073,supported).
node(n1072,refuted) :- node(n1054,refuted).
node(n1072,refuted) :- node(n1055,refuted).
node(n1072,refuted) :- node(n1073,refuted).
node(n1072,unknown) :- \+ node(n1072,supported), \+ node(n1072,refuted).
node(n1069,refuted) :- node(n1070,refuted), node(n1072,refuted), node(n9,refuted).
node(n1069,supported) :- node(n1070,supported).
node(n1069,supported) :- node(n1072,supported).
node(n1069,supported) :- node(n9,supported).
node(n1069,unknown) :- \+ node(n1069,supported), \+ node(n1069,refuted).
verdict(c_d596b1964c5498e6,supported) :- node(n1069,supported).
query(verdict(c_d596b1964c5498e6,supported)).
verdict(c_d596b1964c5498e6,refuted) :- node(n1069,refuted).
query(verdict(c_d596b1964c5498e6,refuted)).
verdict(c_d596b1964c5498e6,unknown) :- node(n1069,unknown).
query(verdict(c_d596b1964c5498e6,unknown)).
node(n1075,supported) :- node(n1050,supported), node(n1051,supported), node(n1052,supported), node(n1071,supported).
node(n1075,refuted) :- node(n1050,refuted).
node(n1075,refuted) :- node(n1051,refuted).
node(n1075,refuted) :- node(n1052,refuted).
node(n1075,refuted) :- node(n1071,refuted).
node(n1075,unknown) :- \+ node(n1075,supported), \+ node(n1075,refuted).
node(n1076,supported) :- node(n1054,supported), node(n1055,supported), node(n1056,supported), node(n1073,supported).
node(n1076,refuted) :- node(n1054,refuted).
node(n1076,refuted) :- node(n1055,refuted).
node(n1076,refuted) :- node(n1056,refuted).
node(n1076,refuted) :- node(n1073,refuted).
node(n1076,unknown) :- \+ node(n1076,supported), \+ node(n1076,refuted).
node(n1074,refuted) :- node(n1075,refuted), node(n1076,refuted), node(n9,refuted).
node(n1074,supported) :- node(n1075,supported).
node(n1074,supported) :- node(n1076,supported).
node(n1074,supported) :- node(n9,supported).
node(n1074,unknown) :- \+ node(n1074,supported), \+ node(n1074,refuted).
verdict(c_9f140754d570f9ad,supported) :- node(n1074,supported).
query(verdict(c_9f140754d570f9ad,supported)).
verdict(c_9f140754d570f9ad,refuted) :- node(n1074,refuted).
query(verdict(c_9f140754d570f9ad,refuted)).
verdict(c_9f140754d570f9ad,unknown) :- node(n1074,unknown).
query(verdict(c_9f140754d570f9ad,unknown)).
node(n1079,supported) :- status(o_216de3531cd0852ced93,supported).
node(n1079,refuted) :- status(o_216de3531cd0852ced93,refuted).
node(n1079,unknown) :- status(o_216de3531cd0852ced93,unknown).
node(n1080,supported) :- status(o_db40faa3025449a16bcb,supported).
node(n1080,refuted) :- status(o_db40faa3025449a16bcb,refuted).
node(n1080,unknown) :- status(o_db40faa3025449a16bcb,unknown).
node(n1081,supported) :- status(o_5452606a46537080ee77,supported).
node(n1081,refuted) :- status(o_5452606a46537080ee77,refuted).
node(n1081,unknown) :- status(o_5452606a46537080ee77,unknown).
node(n1078,supported) :- node(n1079,supported), node(n1080,supported), node(n1081,supported).
node(n1078,refuted) :- node(n1079,refuted).
node(n1078,refuted) :- node(n1080,refuted).
node(n1078,refuted) :- node(n1081,refuted).
node(n1078,unknown) :- \+ node(n1078,supported), \+ node(n1078,refuted).
node(n1077,refuted) :- node(n1078,refuted), node(n9,refuted).
node(n1077,supported) :- node(n1078,supported).
node(n1077,supported) :- node(n9,supported).
node(n1077,unknown) :- \+ node(n1077,supported), \+ node(n1077,refuted).
verdict(c_6e588cfe13b878e5,supported) :- node(n1077,supported).
query(verdict(c_6e588cfe13b878e5,supported)).
verdict(c_6e588cfe13b878e5,refuted) :- node(n1077,refuted).
query(verdict(c_6e588cfe13b878e5,refuted)).
verdict(c_6e588cfe13b878e5,unknown) :- node(n1077,unknown).
query(verdict(c_6e588cfe13b878e5,unknown)).
node(n1084,supported) :- status(o_146f2f1c521700595a7e,supported).
node(n1084,refuted) :- status(o_146f2f1c521700595a7e,refuted).
node(n1084,unknown) :- status(o_146f2f1c521700595a7e,unknown).
node(n1083,supported) :- node(n1079,supported), node(n1080,supported), node(n1081,supported), node(n1084,supported).
node(n1083,refuted) :- node(n1079,refuted).
node(n1083,refuted) :- node(n1080,refuted).
node(n1083,refuted) :- node(n1081,refuted).
node(n1083,refuted) :- node(n1084,refuted).
node(n1083,unknown) :- \+ node(n1083,supported), \+ node(n1083,refuted).
node(n1082,refuted) :- node(n1083,refuted), node(n9,refuted).
node(n1082,supported) :- node(n1083,supported).
node(n1082,supported) :- node(n9,supported).
node(n1082,unknown) :- \+ node(n1082,supported), \+ node(n1082,refuted).
verdict(c_a095e2487bfa638d,supported) :- node(n1082,supported).
query(verdict(c_a095e2487bfa638d,supported)).
verdict(c_a095e2487bfa638d,refuted) :- node(n1082,refuted).
query(verdict(c_a095e2487bfa638d,refuted)).
verdict(c_a095e2487bfa638d,unknown) :- node(n1082,unknown).
query(verdict(c_a095e2487bfa638d,unknown)).
node(n1087,supported) :- status(o_9be74a47dbfb888e54c9,supported).
node(n1087,refuted) :- status(o_9be74a47dbfb888e54c9,refuted).
node(n1087,unknown) :- status(o_9be74a47dbfb888e54c9,unknown).
node(n1088,supported) :- status(o_b78e9789bd074dd0e7b0,supported).
node(n1088,refuted) :- status(o_b78e9789bd074dd0e7b0,refuted).
node(n1088,unknown) :- status(o_b78e9789bd074dd0e7b0,unknown).
node(n1086,supported) :- node(n1079,supported), node(n1080,supported), node(n1081,supported), node(n1084,supported), node(n1087,supported), node(n1088,supported).
node(n1086,refuted) :- node(n1079,refuted).
node(n1086,refuted) :- node(n1080,refuted).
node(n1086,refuted) :- node(n1081,refuted).
node(n1086,refuted) :- node(n1084,refuted).
node(n1086,refuted) :- node(n1087,refuted).
node(n1086,refuted) :- node(n1088,refuted).
node(n1086,unknown) :- \+ node(n1086,supported), \+ node(n1086,refuted).
node(n1085,refuted) :- node(n1086,refuted), node(n9,refuted).
node(n1085,supported) :- node(n1086,supported).
node(n1085,supported) :- node(n9,supported).
node(n1085,unknown) :- \+ node(n1085,supported), \+ node(n1085,refuted).
verdict(c_23e812028dfb7ec2,supported) :- node(n1085,supported).
query(verdict(c_23e812028dfb7ec2,supported)).
verdict(c_23e812028dfb7ec2,refuted) :- node(n1085,refuted).
query(verdict(c_23e812028dfb7ec2,refuted)).
verdict(c_23e812028dfb7ec2,unknown) :- node(n1085,unknown).
query(verdict(c_23e812028dfb7ec2,unknown)).
node(n1091,supported) :- status(o_495977da048a9673bb6a,supported).
node(n1091,refuted) :- status(o_495977da048a9673bb6a,refuted).
node(n1091,unknown) :- status(o_495977da048a9673bb6a,unknown).
node(n1090,supported) :- node(n1079,supported), node(n1080,supported), node(n1091,supported).
node(n1090,refuted) :- node(n1079,refuted).
node(n1090,refuted) :- node(n1080,refuted).
node(n1090,refuted) :- node(n1091,refuted).
node(n1090,unknown) :- \+ node(n1090,supported), \+ node(n1090,refuted).
node(n1089,refuted) :- node(n1090,refuted), node(n9,refuted).
node(n1089,supported) :- node(n1090,supported).
node(n1089,supported) :- node(n9,supported).
node(n1089,unknown) :- \+ node(n1089,supported), \+ node(n1089,refuted).
verdict(c_33bc36e60c4b96c0,supported) :- node(n1089,supported).
query(verdict(c_33bc36e60c4b96c0,supported)).
verdict(c_33bc36e60c4b96c0,refuted) :- node(n1089,refuted).
query(verdict(c_33bc36e60c4b96c0,refuted)).
verdict(c_33bc36e60c4b96c0,unknown) :- node(n1089,unknown).
query(verdict(c_33bc36e60c4b96c0,unknown)).
node(n1093,supported) :- node(n1079,supported), node(n1080,supported), node(n1081,supported), node(n1091,supported).
node(n1093,refuted) :- node(n1079,refuted).
node(n1093,refuted) :- node(n1080,refuted).
node(n1093,refuted) :- node(n1081,refuted).
node(n1093,refuted) :- node(n1091,refuted).
node(n1093,unknown) :- \+ node(n1093,supported), \+ node(n1093,refuted).
node(n1092,refuted) :- node(n1093,refuted), node(n9,refuted).
node(n1092,supported) :- node(n1093,supported).
node(n1092,supported) :- node(n9,supported).
node(n1092,unknown) :- \+ node(n1092,supported), \+ node(n1092,refuted).
verdict(c_616a39ec9cb38646,supported) :- node(n1092,supported).
query(verdict(c_616a39ec9cb38646,supported)).
verdict(c_616a39ec9cb38646,refuted) :- node(n1092,refuted).
query(verdict(c_616a39ec9cb38646,refuted)).
verdict(c_616a39ec9cb38646,unknown) :- node(n1092,unknown).
query(verdict(c_616a39ec9cb38646,unknown)).
node(n1096,supported) :- status(o_7de7aa94cd2f2bd7ca97,supported).
node(n1096,refuted) :- status(o_7de7aa94cd2f2bd7ca97,refuted).
node(n1096,unknown) :- status(o_7de7aa94cd2f2bd7ca97,unknown).
node(n1097,supported) :- status(o_5d06823432dee63d68d3,supported).
node(n1097,refuted) :- status(o_5d06823432dee63d68d3,refuted).
node(n1097,unknown) :- status(o_5d06823432dee63d68d3,unknown).
node(n1098,supported) :- status(o_e0c6336bd180723c5a39,supported).
node(n1098,refuted) :- status(o_e0c6336bd180723c5a39,refuted).
node(n1098,unknown) :- status(o_e0c6336bd180723c5a39,unknown).
node(n1095,supported) :- node(n1096,supported), node(n1097,supported), node(n1098,supported).
node(n1095,refuted) :- node(n1096,refuted).
node(n1095,refuted) :- node(n1097,refuted).
node(n1095,refuted) :- node(n1098,refuted).
node(n1095,unknown) :- \+ node(n1095,supported), \+ node(n1095,refuted).
node(n1100,supported) :- status(o_99b118d8e2dad88ecf9e,supported).
node(n1100,refuted) :- status(o_99b118d8e2dad88ecf9e,refuted).
node(n1100,unknown) :- status(o_99b118d8e2dad88ecf9e,unknown).
node(n1101,supported) :- status(o_3c80799815bd65d38e24,supported).
node(n1101,refuted) :- status(o_3c80799815bd65d38e24,refuted).
node(n1101,unknown) :- status(o_3c80799815bd65d38e24,unknown).
node(n1102,supported) :- status(o_e09d9af4afb9fe42db84,supported).
node(n1102,refuted) :- status(o_e09d9af4afb9fe42db84,refuted).
node(n1102,unknown) :- status(o_e09d9af4afb9fe42db84,unknown).
node(n1099,supported) :- node(n1100,supported), node(n1101,supported), node(n1102,supported).
node(n1099,refuted) :- node(n1100,refuted).
node(n1099,refuted) :- node(n1101,refuted).
node(n1099,refuted) :- node(n1102,refuted).
node(n1099,unknown) :- \+ node(n1099,supported), \+ node(n1099,refuted).
node(n1094,refuted) :- node(n1095,refuted), node(n1099,refuted), node(n9,refuted).
node(n1094,supported) :- node(n1095,supported).
node(n1094,supported) :- node(n1099,supported).
node(n1094,supported) :- node(n9,supported).
node(n1094,unknown) :- \+ node(n1094,supported), \+ node(n1094,refuted).
verdict(c_5ca911bebdca3723,supported) :- node(n1094,supported).
query(verdict(c_5ca911bebdca3723,supported)).
verdict(c_5ca911bebdca3723,refuted) :- node(n1094,refuted).
query(verdict(c_5ca911bebdca3723,refuted)).
verdict(c_5ca911bebdca3723,unknown) :- node(n1094,unknown).
query(verdict(c_5ca911bebdca3723,unknown)).
node(n1105,supported) :- status(o_296c9c4edd26bae1a7f0,supported).
node(n1105,refuted) :- status(o_296c9c4edd26bae1a7f0,refuted).
node(n1105,unknown) :- status(o_296c9c4edd26bae1a7f0,unknown).
node(n1104,supported) :- node(n1096,supported), node(n1097,supported), node(n1098,supported), node(n1105,supported).
node(n1104,refuted) :- node(n1096,refuted).
node(n1104,refuted) :- node(n1097,refuted).
node(n1104,refuted) :- node(n1098,refuted).
node(n1104,refuted) :- node(n1105,refuted).
node(n1104,unknown) :- \+ node(n1104,supported), \+ node(n1104,refuted).
node(n1107,supported) :- status(o_14176ca6ec1ae96d9228,supported).
node(n1107,refuted) :- status(o_14176ca6ec1ae96d9228,refuted).
node(n1107,unknown) :- status(o_14176ca6ec1ae96d9228,unknown).
node(n1106,supported) :- node(n1100,supported), node(n1101,supported), node(n1102,supported), node(n1107,supported).
node(n1106,refuted) :- node(n1100,refuted).
node(n1106,refuted) :- node(n1101,refuted).
node(n1106,refuted) :- node(n1102,refuted).
node(n1106,refuted) :- node(n1107,refuted).
node(n1106,unknown) :- \+ node(n1106,supported), \+ node(n1106,refuted).
node(n1103,refuted) :- node(n1104,refuted), node(n1106,refuted), node(n9,refuted).
node(n1103,supported) :- node(n1104,supported).
node(n1103,supported) :- node(n1106,supported).
node(n1103,supported) :- node(n9,supported).
node(n1103,unknown) :- \+ node(n1103,supported), \+ node(n1103,refuted).
verdict(c_2bc3d32bdab08261,supported) :- node(n1103,supported).
query(verdict(c_2bc3d32bdab08261,supported)).
verdict(c_2bc3d32bdab08261,refuted) :- node(n1103,refuted).
query(verdict(c_2bc3d32bdab08261,refuted)).
verdict(c_2bc3d32bdab08261,unknown) :- node(n1103,unknown).
query(verdict(c_2bc3d32bdab08261,unknown)).
node(n1110,supported) :- status(o_6a279ddf2c02f9321c76,supported).
node(n1110,refuted) :- status(o_6a279ddf2c02f9321c76,refuted).
node(n1110,unknown) :- status(o_6a279ddf2c02f9321c76,unknown).
node(n1111,supported) :- status(o_38dfd6e95d981f9e3808,supported).
node(n1111,refuted) :- status(o_38dfd6e95d981f9e3808,refuted).
node(n1111,unknown) :- status(o_38dfd6e95d981f9e3808,unknown).
node(n1109,supported) :- node(n1096,supported), node(n1097,supported), node(n1098,supported), node(n1105,supported), node(n1110,supported), node(n1111,supported).
node(n1109,refuted) :- node(n1096,refuted).
node(n1109,refuted) :- node(n1097,refuted).
node(n1109,refuted) :- node(n1098,refuted).
node(n1109,refuted) :- node(n1105,refuted).
node(n1109,refuted) :- node(n1110,refuted).
node(n1109,refuted) :- node(n1111,refuted).
node(n1109,unknown) :- \+ node(n1109,supported), \+ node(n1109,refuted).
node(n1113,supported) :- status(o_dcb3fe05b05612ad55ec,supported).
node(n1113,refuted) :- status(o_dcb3fe05b05612ad55ec,refuted).
node(n1113,unknown) :- status(o_dcb3fe05b05612ad55ec,unknown).
node(n1114,supported) :- status(o_39c32c530e2e6fe49876,supported).
node(n1114,refuted) :- status(o_39c32c530e2e6fe49876,refuted).
node(n1114,unknown) :- status(o_39c32c530e2e6fe49876,unknown).
node(n1112,supported) :- node(n1100,supported), node(n1101,supported), node(n1102,supported), node(n1107,supported), node(n1113,supported), node(n1114,supported).
node(n1112,refuted) :- node(n1100,refuted).
node(n1112,refuted) :- node(n1101,refuted).
node(n1112,refuted) :- node(n1102,refuted).
node(n1112,refuted) :- node(n1107,refuted).
node(n1112,refuted) :- node(n1113,refuted).
node(n1112,refuted) :- node(n1114,refuted).
node(n1112,unknown) :- \+ node(n1112,supported), \+ node(n1112,refuted).
node(n1108,refuted) :- node(n1109,refuted), node(n1112,refuted), node(n9,refuted).
node(n1108,supported) :- node(n1109,supported).
node(n1108,supported) :- node(n1112,supported).
node(n1108,supported) :- node(n9,supported).
node(n1108,unknown) :- \+ node(n1108,supported), \+ node(n1108,refuted).
verdict(c_b906b462807515c3,supported) :- node(n1108,supported).
query(verdict(c_b906b462807515c3,supported)).
verdict(c_b906b462807515c3,refuted) :- node(n1108,refuted).
query(verdict(c_b906b462807515c3,refuted)).
verdict(c_b906b462807515c3,unknown) :- node(n1108,unknown).
query(verdict(c_b906b462807515c3,unknown)).
node(n1117,supported) :- status(o_e879a67926bad10beba9,supported).
node(n1117,refuted) :- status(o_e879a67926bad10beba9,refuted).
node(n1117,unknown) :- status(o_e879a67926bad10beba9,unknown).
node(n1116,supported) :- node(n1096,supported), node(n1097,supported), node(n1117,supported).
node(n1116,refuted) :- node(n1096,refuted).
node(n1116,refuted) :- node(n1097,refuted).
node(n1116,refuted) :- node(n1117,refuted).
node(n1116,unknown) :- \+ node(n1116,supported), \+ node(n1116,refuted).
node(n1119,supported) :- status(o_a6ac81f582d19d203086,supported).
node(n1119,refuted) :- status(o_a6ac81f582d19d203086,refuted).
node(n1119,unknown) :- status(o_a6ac81f582d19d203086,unknown).
node(n1118,supported) :- node(n1100,supported), node(n1101,supported), node(n1119,supported).
node(n1118,refuted) :- node(n1100,refuted).
node(n1118,refuted) :- node(n1101,refuted).
node(n1118,refuted) :- node(n1119,refuted).
node(n1118,unknown) :- \+ node(n1118,supported), \+ node(n1118,refuted).
node(n1115,refuted) :- node(n1116,refuted), node(n1118,refuted), node(n9,refuted).
node(n1115,supported) :- node(n1116,supported).
node(n1115,supported) :- node(n1118,supported).
node(n1115,supported) :- node(n9,supported).
node(n1115,unknown) :- \+ node(n1115,supported), \+ node(n1115,refuted).
verdict(c_b4db5bcf9de205ec,supported) :- node(n1115,supported).
query(verdict(c_b4db5bcf9de205ec,supported)).
verdict(c_b4db5bcf9de205ec,refuted) :- node(n1115,refuted).
query(verdict(c_b4db5bcf9de205ec,refuted)).
verdict(c_b4db5bcf9de205ec,unknown) :- node(n1115,unknown).
query(verdict(c_b4db5bcf9de205ec,unknown)).
node(n1121,supported) :- node(n1096,supported), node(n1097,supported), node(n1098,supported), node(n1117,supported).
node(n1121,refuted) :- node(n1096,refuted).
node(n1121,refuted) :- node(n1097,refuted).
node(n1121,refuted) :- node(n1098,refuted).
node(n1121,refuted) :- node(n1117,refuted).
node(n1121,unknown) :- \+ node(n1121,supported), \+ node(n1121,refuted).
node(n1122,supported) :- node(n1100,supported), node(n1101,supported), node(n1102,supported), node(n1119,supported).
node(n1122,refuted) :- node(n1100,refuted).
node(n1122,refuted) :- node(n1101,refuted).
node(n1122,refuted) :- node(n1102,refuted).
node(n1122,refuted) :- node(n1119,refuted).
node(n1122,unknown) :- \+ node(n1122,supported), \+ node(n1122,refuted).
node(n1120,refuted) :- node(n1121,refuted), node(n1122,refuted), node(n9,refuted).
node(n1120,supported) :- node(n1121,supported).
node(n1120,supported) :- node(n1122,supported).
node(n1120,supported) :- node(n9,supported).
node(n1120,unknown) :- \+ node(n1120,supported), \+ node(n1120,refuted).
verdict(c_074e38a8dbe9d021,supported) :- node(n1120,supported).
query(verdict(c_074e38a8dbe9d021,supported)).
verdict(c_074e38a8dbe9d021,refuted) :- node(n1120,refuted).
query(verdict(c_074e38a8dbe9d021,refuted)).
verdict(c_074e38a8dbe9d021,unknown) :- node(n1120,unknown).
query(verdict(c_074e38a8dbe9d021,unknown)).
node(n1125,supported) :- status(o_ae0363c9e2e526a4ddf2,supported).
node(n1125,refuted) :- status(o_ae0363c9e2e526a4ddf2,refuted).
node(n1125,unknown) :- status(o_ae0363c9e2e526a4ddf2,unknown).
node(n1126,supported) :- status(o_aed4ab3133197d75432b,supported).
node(n1126,refuted) :- status(o_aed4ab3133197d75432b,refuted).
node(n1126,unknown) :- status(o_aed4ab3133197d75432b,unknown).
node(n1127,supported) :- status(o_abb36428887f039587c9,supported).
node(n1127,refuted) :- status(o_abb36428887f039587c9,refuted).
node(n1127,unknown) :- status(o_abb36428887f039587c9,unknown).
node(n1124,supported) :- node(n1125,supported), node(n1126,supported), node(n1127,supported).
node(n1124,refuted) :- node(n1125,refuted).
node(n1124,refuted) :- node(n1126,refuted).
node(n1124,refuted) :- node(n1127,refuted).
node(n1124,unknown) :- \+ node(n1124,supported), \+ node(n1124,refuted).
node(n1129,supported) :- status(o_abff36a2d0e9ebbcb35a,supported).
node(n1129,refuted) :- status(o_abff36a2d0e9ebbcb35a,refuted).
node(n1129,unknown) :- status(o_abff36a2d0e9ebbcb35a,unknown).
node(n1130,supported) :- status(o_fbfc8d9bc235d81c7b46,supported).
node(n1130,refuted) :- status(o_fbfc8d9bc235d81c7b46,refuted).
node(n1130,unknown) :- status(o_fbfc8d9bc235d81c7b46,unknown).
node(n1131,supported) :- status(o_65881da29db045b0ac40,supported).
node(n1131,refuted) :- status(o_65881da29db045b0ac40,refuted).
node(n1131,unknown) :- status(o_65881da29db045b0ac40,unknown).
node(n1128,supported) :- node(n1129,supported), node(n1130,supported), node(n1131,supported).
node(n1128,refuted) :- node(n1129,refuted).
node(n1128,refuted) :- node(n1130,refuted).
node(n1128,refuted) :- node(n1131,refuted).
node(n1128,unknown) :- \+ node(n1128,supported), \+ node(n1128,refuted).
node(n1123,refuted) :- node(n1124,refuted), node(n1128,refuted), node(n9,refuted).
node(n1123,supported) :- node(n1124,supported).
node(n1123,supported) :- node(n1128,supported).
node(n1123,supported) :- node(n9,supported).
node(n1123,unknown) :- \+ node(n1123,supported), \+ node(n1123,refuted).
verdict(c_cdb5484cb0d9c68e,supported) :- node(n1123,supported).
query(verdict(c_cdb5484cb0d9c68e,supported)).
verdict(c_cdb5484cb0d9c68e,refuted) :- node(n1123,refuted).
query(verdict(c_cdb5484cb0d9c68e,refuted)).
verdict(c_cdb5484cb0d9c68e,unknown) :- node(n1123,unknown).
query(verdict(c_cdb5484cb0d9c68e,unknown)).
node(n1134,supported) :- status(o_feb65674051c34c9f834,supported).
node(n1134,refuted) :- status(o_feb65674051c34c9f834,refuted).
node(n1134,unknown) :- status(o_feb65674051c34c9f834,unknown).
node(n1133,supported) :- node(n1125,supported), node(n1126,supported), node(n1127,supported), node(n1134,supported).
node(n1133,refuted) :- node(n1125,refuted).
node(n1133,refuted) :- node(n1126,refuted).
node(n1133,refuted) :- node(n1127,refuted).
node(n1133,refuted) :- node(n1134,refuted).
node(n1133,unknown) :- \+ node(n1133,supported), \+ node(n1133,refuted).
node(n1136,supported) :- status(o_ab2add253af7154bfdc5,supported).
node(n1136,refuted) :- status(o_ab2add253af7154bfdc5,refuted).
node(n1136,unknown) :- status(o_ab2add253af7154bfdc5,unknown).
node(n1135,supported) :- node(n1129,supported), node(n1130,supported), node(n1131,supported), node(n1136,supported).
node(n1135,refuted) :- node(n1129,refuted).
node(n1135,refuted) :- node(n1130,refuted).
node(n1135,refuted) :- node(n1131,refuted).
node(n1135,refuted) :- node(n1136,refuted).
node(n1135,unknown) :- \+ node(n1135,supported), \+ node(n1135,refuted).
node(n1132,refuted) :- node(n1133,refuted), node(n1135,refuted), node(n9,refuted).
node(n1132,supported) :- node(n1133,supported).
node(n1132,supported) :- node(n1135,supported).
node(n1132,supported) :- node(n9,supported).
node(n1132,unknown) :- \+ node(n1132,supported), \+ node(n1132,refuted).
verdict(c_8a3cf1436af669b2,supported) :- node(n1132,supported).
query(verdict(c_8a3cf1436af669b2,supported)).
verdict(c_8a3cf1436af669b2,refuted) :- node(n1132,refuted).
query(verdict(c_8a3cf1436af669b2,refuted)).
verdict(c_8a3cf1436af669b2,unknown) :- node(n1132,unknown).
query(verdict(c_8a3cf1436af669b2,unknown)).
node(n1139,supported) :- status(o_dcb328c8d7ba0fef5af8,supported).
node(n1139,refuted) :- status(o_dcb328c8d7ba0fef5af8,refuted).
node(n1139,unknown) :- status(o_dcb328c8d7ba0fef5af8,unknown).
node(n1140,supported) :- status(o_54eb6b83cb6a4af86885,supported).
node(n1140,refuted) :- status(o_54eb6b83cb6a4af86885,refuted).
node(n1140,unknown) :- status(o_54eb6b83cb6a4af86885,unknown).
node(n1138,supported) :- node(n1125,supported), node(n1126,supported), node(n1127,supported), node(n1134,supported), node(n1139,supported), node(n1140,supported).
node(n1138,refuted) :- node(n1125,refuted).
node(n1138,refuted) :- node(n1126,refuted).
node(n1138,refuted) :- node(n1127,refuted).
node(n1138,refuted) :- node(n1134,refuted).
node(n1138,refuted) :- node(n1139,refuted).
node(n1138,refuted) :- node(n1140,refuted).
node(n1138,unknown) :- \+ node(n1138,supported), \+ node(n1138,refuted).
node(n1142,supported) :- status(o_f2bb39ef37bdfe4b9163,supported).
node(n1142,refuted) :- status(o_f2bb39ef37bdfe4b9163,refuted).
node(n1142,unknown) :- status(o_f2bb39ef37bdfe4b9163,unknown).
node(n1143,supported) :- status(o_02e81a30da73bdc0e9aa,supported).
node(n1143,refuted) :- status(o_02e81a30da73bdc0e9aa,refuted).
node(n1143,unknown) :- status(o_02e81a30da73bdc0e9aa,unknown).
node(n1141,supported) :- node(n1129,supported), node(n1130,supported), node(n1131,supported), node(n1136,supported), node(n1142,supported), node(n1143,supported).
node(n1141,refuted) :- node(n1129,refuted).
node(n1141,refuted) :- node(n1130,refuted).
node(n1141,refuted) :- node(n1131,refuted).
node(n1141,refuted) :- node(n1136,refuted).
node(n1141,refuted) :- node(n1142,refuted).
node(n1141,refuted) :- node(n1143,refuted).
node(n1141,unknown) :- \+ node(n1141,supported), \+ node(n1141,refuted).
node(n1137,refuted) :- node(n1138,refuted), node(n1141,refuted), node(n9,refuted).
node(n1137,supported) :- node(n1138,supported).
node(n1137,supported) :- node(n1141,supported).
node(n1137,supported) :- node(n9,supported).
node(n1137,unknown) :- \+ node(n1137,supported), \+ node(n1137,refuted).
verdict(c_538d396859058d76,supported) :- node(n1137,supported).
query(verdict(c_538d396859058d76,supported)).
verdict(c_538d396859058d76,refuted) :- node(n1137,refuted).
query(verdict(c_538d396859058d76,refuted)).
verdict(c_538d396859058d76,unknown) :- node(n1137,unknown).
query(verdict(c_538d396859058d76,unknown)).
node(n1146,supported) :- status(o_a3cd9489986c31ed1ac2,supported).
node(n1146,refuted) :- status(o_a3cd9489986c31ed1ac2,refuted).
node(n1146,unknown) :- status(o_a3cd9489986c31ed1ac2,unknown).
node(n1145,supported) :- node(n1125,supported), node(n1126,supported), node(n1146,supported).
node(n1145,refuted) :- node(n1125,refuted).
node(n1145,refuted) :- node(n1126,refuted).
node(n1145,refuted) :- node(n1146,refuted).
node(n1145,unknown) :- \+ node(n1145,supported), \+ node(n1145,refuted).
node(n1148,supported) :- status(o_2b6cf098123b11dca966,supported).
node(n1148,refuted) :- status(o_2b6cf098123b11dca966,refuted).
node(n1148,unknown) :- status(o_2b6cf098123b11dca966,unknown).
node(n1147,supported) :- node(n1129,supported), node(n1130,supported), node(n1148,supported).
node(n1147,refuted) :- node(n1129,refuted).
node(n1147,refuted) :- node(n1130,refuted).
node(n1147,refuted) :- node(n1148,refuted).
node(n1147,unknown) :- \+ node(n1147,supported), \+ node(n1147,refuted).
node(n1144,refuted) :- node(n1145,refuted), node(n1147,refuted), node(n9,refuted).
node(n1144,supported) :- node(n1145,supported).
node(n1144,supported) :- node(n1147,supported).
node(n1144,supported) :- node(n9,supported).
node(n1144,unknown) :- \+ node(n1144,supported), \+ node(n1144,refuted).
verdict(c_3a6c2715dfed7f10,supported) :- node(n1144,supported).
query(verdict(c_3a6c2715dfed7f10,supported)).
verdict(c_3a6c2715dfed7f10,refuted) :- node(n1144,refuted).
query(verdict(c_3a6c2715dfed7f10,refuted)).
verdict(c_3a6c2715dfed7f10,unknown) :- node(n1144,unknown).
query(verdict(c_3a6c2715dfed7f10,unknown)).
node(n1150,supported) :- node(n1125,supported), node(n1126,supported), node(n1127,supported), node(n1146,supported).
node(n1150,refuted) :- node(n1125,refuted).
node(n1150,refuted) :- node(n1126,refuted).
node(n1150,refuted) :- node(n1127,refuted).
node(n1150,refuted) :- node(n1146,refuted).
node(n1150,unknown) :- \+ node(n1150,supported), \+ node(n1150,refuted).
node(n1151,supported) :- node(n1129,supported), node(n1130,supported), node(n1131,supported), node(n1148,supported).
node(n1151,refuted) :- node(n1129,refuted).
node(n1151,refuted) :- node(n1130,refuted).
node(n1151,refuted) :- node(n1131,refuted).
node(n1151,refuted) :- node(n1148,refuted).
node(n1151,unknown) :- \+ node(n1151,supported), \+ node(n1151,refuted).
node(n1149,refuted) :- node(n1150,refuted), node(n1151,refuted), node(n9,refuted).
node(n1149,supported) :- node(n1150,supported).
node(n1149,supported) :- node(n1151,supported).
node(n1149,supported) :- node(n9,supported).
node(n1149,unknown) :- \+ node(n1149,supported), \+ node(n1149,refuted).
verdict(c_b15128c9746e9356,supported) :- node(n1149,supported).
query(verdict(c_b15128c9746e9356,supported)).
verdict(c_b15128c9746e9356,refuted) :- node(n1149,refuted).
query(verdict(c_b15128c9746e9356,refuted)).
verdict(c_b15128c9746e9356,unknown) :- node(n1149,unknown).
query(verdict(c_b15128c9746e9356,unknown)).
node(n1154,supported) :- status(o_3fd0b3a7fba382f3da26,supported).
node(n1154,refuted) :- status(o_3fd0b3a7fba382f3da26,refuted).
node(n1154,unknown) :- status(o_3fd0b3a7fba382f3da26,unknown).
node(n1155,supported) :- status(o_6332ef2756469f508f8a,supported).
node(n1155,refuted) :- status(o_6332ef2756469f508f8a,refuted).
node(n1155,unknown) :- status(o_6332ef2756469f508f8a,unknown).
node(n1156,supported) :- status(o_d130d797f4a5a0238738,supported).
node(n1156,refuted) :- status(o_d130d797f4a5a0238738,refuted).
node(n1156,unknown) :- status(o_d130d797f4a5a0238738,unknown).
node(n1153,supported) :- node(n1154,supported), node(n1155,supported), node(n1156,supported).
node(n1153,refuted) :- node(n1154,refuted).
node(n1153,refuted) :- node(n1155,refuted).
node(n1153,refuted) :- node(n1156,refuted).
node(n1153,unknown) :- \+ node(n1153,supported), \+ node(n1153,refuted).
node(n1158,supported) :- status(o_7c4098b26a0475fb1319,supported).
node(n1158,refuted) :- status(o_7c4098b26a0475fb1319,refuted).
node(n1158,unknown) :- status(o_7c4098b26a0475fb1319,unknown).
node(n1159,supported) :- status(o_00f2c5af9702eaaa9ac8,supported).
node(n1159,refuted) :- status(o_00f2c5af9702eaaa9ac8,refuted).
node(n1159,unknown) :- status(o_00f2c5af9702eaaa9ac8,unknown).
node(n1160,supported) :- status(o_cc630dc0fe728cbd1825,supported).
node(n1160,refuted) :- status(o_cc630dc0fe728cbd1825,refuted).
node(n1160,unknown) :- status(o_cc630dc0fe728cbd1825,unknown).
node(n1157,supported) :- node(n1158,supported), node(n1159,supported), node(n1160,supported).
node(n1157,refuted) :- node(n1158,refuted).
node(n1157,refuted) :- node(n1159,refuted).
node(n1157,refuted) :- node(n1160,refuted).
node(n1157,unknown) :- \+ node(n1157,supported), \+ node(n1157,refuted).
node(n1152,refuted) :- node(n1153,refuted), node(n1157,refuted), node(n9,refuted).
node(n1152,supported) :- node(n1153,supported).
node(n1152,supported) :- node(n1157,supported).
node(n1152,supported) :- node(n9,supported).
node(n1152,unknown) :- \+ node(n1152,supported), \+ node(n1152,refuted).
verdict(c_6f12d310aadccdae,supported) :- node(n1152,supported).
query(verdict(c_6f12d310aadccdae,supported)).
verdict(c_6f12d310aadccdae,refuted) :- node(n1152,refuted).
query(verdict(c_6f12d310aadccdae,refuted)).
verdict(c_6f12d310aadccdae,unknown) :- node(n1152,unknown).
query(verdict(c_6f12d310aadccdae,unknown)).
node(n1163,supported) :- status(o_e8f1b11fbb8e0d2d7e7e,supported).
node(n1163,refuted) :- status(o_e8f1b11fbb8e0d2d7e7e,refuted).
node(n1163,unknown) :- status(o_e8f1b11fbb8e0d2d7e7e,unknown).
node(n1162,supported) :- node(n1154,supported), node(n1155,supported), node(n1156,supported), node(n1163,supported).
node(n1162,refuted) :- node(n1154,refuted).
node(n1162,refuted) :- node(n1155,refuted).
node(n1162,refuted) :- node(n1156,refuted).
node(n1162,refuted) :- node(n1163,refuted).
node(n1162,unknown) :- \+ node(n1162,supported), \+ node(n1162,refuted).
node(n1165,supported) :- status(o_a6f90de34dff56a7cf0e,supported).
node(n1165,refuted) :- status(o_a6f90de34dff56a7cf0e,refuted).
node(n1165,unknown) :- status(o_a6f90de34dff56a7cf0e,unknown).
node(n1164,supported) :- node(n1158,supported), node(n1159,supported), node(n1160,supported), node(n1165,supported).
node(n1164,refuted) :- node(n1158,refuted).
node(n1164,refuted) :- node(n1159,refuted).
node(n1164,refuted) :- node(n1160,refuted).
node(n1164,refuted) :- node(n1165,refuted).
node(n1164,unknown) :- \+ node(n1164,supported), \+ node(n1164,refuted).
node(n1161,refuted) :- node(n1162,refuted), node(n1164,refuted), node(n9,refuted).
node(n1161,supported) :- node(n1162,supported).
node(n1161,supported) :- node(n1164,supported).
node(n1161,supported) :- node(n9,supported).
node(n1161,unknown) :- \+ node(n1161,supported), \+ node(n1161,refuted).
verdict(c_63688f8013d2f0b6,supported) :- node(n1161,supported).
query(verdict(c_63688f8013d2f0b6,supported)).
verdict(c_63688f8013d2f0b6,refuted) :- node(n1161,refuted).
query(verdict(c_63688f8013d2f0b6,refuted)).
verdict(c_63688f8013d2f0b6,unknown) :- node(n1161,unknown).
query(verdict(c_63688f8013d2f0b6,unknown)).
node(n1168,supported) :- status(o_9390576d90574c5d0762,supported).
node(n1168,refuted) :- status(o_9390576d90574c5d0762,refuted).
node(n1168,unknown) :- status(o_9390576d90574c5d0762,unknown).
node(n1169,supported) :- status(o_6c1e8ab686b31f187df2,supported).
node(n1169,refuted) :- status(o_6c1e8ab686b31f187df2,refuted).
node(n1169,unknown) :- status(o_6c1e8ab686b31f187df2,unknown).
node(n1167,supported) :- node(n1154,supported), node(n1155,supported), node(n1156,supported), node(n1163,supported), node(n1168,supported), node(n1169,supported).
node(n1167,refuted) :- node(n1154,refuted).
node(n1167,refuted) :- node(n1155,refuted).
node(n1167,refuted) :- node(n1156,refuted).
node(n1167,refuted) :- node(n1163,refuted).
node(n1167,refuted) :- node(n1168,refuted).
node(n1167,refuted) :- node(n1169,refuted).
node(n1167,unknown) :- \+ node(n1167,supported), \+ node(n1167,refuted).
node(n1171,supported) :- status(o_46aa2f76a579837492d4,supported).
node(n1171,refuted) :- status(o_46aa2f76a579837492d4,refuted).
node(n1171,unknown) :- status(o_46aa2f76a579837492d4,unknown).
node(n1172,supported) :- status(o_5bf9e0ba8da3ba2ef7e3,supported).
node(n1172,refuted) :- status(o_5bf9e0ba8da3ba2ef7e3,refuted).
node(n1172,unknown) :- status(o_5bf9e0ba8da3ba2ef7e3,unknown).
node(n1170,supported) :- node(n1158,supported), node(n1159,supported), node(n1160,supported), node(n1165,supported), node(n1171,supported), node(n1172,supported).
node(n1170,refuted) :- node(n1158,refuted).
node(n1170,refuted) :- node(n1159,refuted).
node(n1170,refuted) :- node(n1160,refuted).
node(n1170,refuted) :- node(n1165,refuted).
node(n1170,refuted) :- node(n1171,refuted).
node(n1170,refuted) :- node(n1172,refuted).
node(n1170,unknown) :- \+ node(n1170,supported), \+ node(n1170,refuted).
node(n1166,refuted) :- node(n1167,refuted), node(n1170,refuted), node(n9,refuted).
node(n1166,supported) :- node(n1167,supported).
node(n1166,supported) :- node(n1170,supported).
node(n1166,supported) :- node(n9,supported).
node(n1166,unknown) :- \+ node(n1166,supported), \+ node(n1166,refuted).
verdict(c_c8508fbefb46d136,supported) :- node(n1166,supported).
query(verdict(c_c8508fbefb46d136,supported)).
verdict(c_c8508fbefb46d136,refuted) :- node(n1166,refuted).
query(verdict(c_c8508fbefb46d136,refuted)).
verdict(c_c8508fbefb46d136,unknown) :- node(n1166,unknown).
query(verdict(c_c8508fbefb46d136,unknown)).
node(n1175,supported) :- status(o_91bbd368cb4f93c26294,supported).
node(n1175,refuted) :- status(o_91bbd368cb4f93c26294,refuted).
node(n1175,unknown) :- status(o_91bbd368cb4f93c26294,unknown).
node(n1174,supported) :- node(n1154,supported), node(n1155,supported), node(n1175,supported).
node(n1174,refuted) :- node(n1154,refuted).
node(n1174,refuted) :- node(n1155,refuted).
node(n1174,refuted) :- node(n1175,refuted).
node(n1174,unknown) :- \+ node(n1174,supported), \+ node(n1174,refuted).
node(n1177,supported) :- status(o_e9f308e1977da8cf9dca,supported).
node(n1177,refuted) :- status(o_e9f308e1977da8cf9dca,refuted).
node(n1177,unknown) :- status(o_e9f308e1977da8cf9dca,unknown).
node(n1176,supported) :- node(n1158,supported), node(n1159,supported), node(n1177,supported).
node(n1176,refuted) :- node(n1158,refuted).
node(n1176,refuted) :- node(n1159,refuted).
node(n1176,refuted) :- node(n1177,refuted).
node(n1176,unknown) :- \+ node(n1176,supported), \+ node(n1176,refuted).
node(n1173,refuted) :- node(n1174,refuted), node(n1176,refuted), node(n9,refuted).
node(n1173,supported) :- node(n1174,supported).
node(n1173,supported) :- node(n1176,supported).
node(n1173,supported) :- node(n9,supported).
node(n1173,unknown) :- \+ node(n1173,supported), \+ node(n1173,refuted).
verdict(c_36e8cfd532c5a3ab,supported) :- node(n1173,supported).
query(verdict(c_36e8cfd532c5a3ab,supported)).
verdict(c_36e8cfd532c5a3ab,refuted) :- node(n1173,refuted).
query(verdict(c_36e8cfd532c5a3ab,refuted)).
verdict(c_36e8cfd532c5a3ab,unknown) :- node(n1173,unknown).
query(verdict(c_36e8cfd532c5a3ab,unknown)).
node(n1179,supported) :- node(n1154,supported), node(n1155,supported), node(n1156,supported), node(n1175,supported).
node(n1179,refuted) :- node(n1154,refuted).
node(n1179,refuted) :- node(n1155,refuted).
node(n1179,refuted) :- node(n1156,refuted).
node(n1179,refuted) :- node(n1175,refuted).
node(n1179,unknown) :- \+ node(n1179,supported), \+ node(n1179,refuted).
node(n1180,supported) :- node(n1158,supported), node(n1159,supported), node(n1160,supported), node(n1177,supported).
node(n1180,refuted) :- node(n1158,refuted).
node(n1180,refuted) :- node(n1159,refuted).
node(n1180,refuted) :- node(n1160,refuted).
node(n1180,refuted) :- node(n1177,refuted).
node(n1180,unknown) :- \+ node(n1180,supported), \+ node(n1180,refuted).
node(n1178,refuted) :- node(n1179,refuted), node(n1180,refuted), node(n9,refuted).
node(n1178,supported) :- node(n1179,supported).
node(n1178,supported) :- node(n1180,supported).
node(n1178,supported) :- node(n9,supported).
node(n1178,unknown) :- \+ node(n1178,supported), \+ node(n1178,refuted).
verdict(c_185f654306ccccef,supported) :- node(n1178,supported).
query(verdict(c_185f654306ccccef,supported)).
verdict(c_185f654306ccccef,refuted) :- node(n1178,refuted).
query(verdict(c_185f654306ccccef,refuted)).
verdict(c_185f654306ccccef,unknown) :- node(n1178,unknown).
query(verdict(c_185f654306ccccef,unknown)).
node(n1183,supported) :- status(o_45fb76a0eee3994f484f,supported).
node(n1183,refuted) :- status(o_45fb76a0eee3994f484f,refuted).
node(n1183,unknown) :- status(o_45fb76a0eee3994f484f,unknown).
node(n1184,supported) :- status(o_1714ed829ffddd54e18e,supported).
node(n1184,refuted) :- status(o_1714ed829ffddd54e18e,refuted).
node(n1184,unknown) :- status(o_1714ed829ffddd54e18e,unknown).
node(n1185,supported) :- status(o_da965b02af937e2e7e7c,supported).
node(n1185,refuted) :- status(o_da965b02af937e2e7e7c,refuted).
node(n1185,unknown) :- status(o_da965b02af937e2e7e7c,unknown).
node(n1182,supported) :- node(n1183,supported), node(n1184,supported), node(n1185,supported).
node(n1182,refuted) :- node(n1183,refuted).
node(n1182,refuted) :- node(n1184,refuted).
node(n1182,refuted) :- node(n1185,refuted).
node(n1182,unknown) :- \+ node(n1182,supported), \+ node(n1182,refuted).
node(n1187,supported) :- status(o_712c10287a0a91b15238,supported).
node(n1187,refuted) :- status(o_712c10287a0a91b15238,refuted).
node(n1187,unknown) :- status(o_712c10287a0a91b15238,unknown).
node(n1188,supported) :- status(o_0e9f9944ff68cfb3608c,supported).
node(n1188,refuted) :- status(o_0e9f9944ff68cfb3608c,refuted).
node(n1188,unknown) :- status(o_0e9f9944ff68cfb3608c,unknown).
node(n1189,supported) :- status(o_9a0f7f9d66980bd1d0d7,supported).
node(n1189,refuted) :- status(o_9a0f7f9d66980bd1d0d7,refuted).
node(n1189,unknown) :- status(o_9a0f7f9d66980bd1d0d7,unknown).
node(n1186,supported) :- node(n1187,supported), node(n1188,supported), node(n1189,supported).
node(n1186,refuted) :- node(n1187,refuted).
node(n1186,refuted) :- node(n1188,refuted).
node(n1186,refuted) :- node(n1189,refuted).
node(n1186,unknown) :- \+ node(n1186,supported), \+ node(n1186,refuted).
node(n1181,refuted) :- node(n1182,refuted), node(n1186,refuted), node(n9,refuted).
node(n1181,supported) :- node(n1182,supported).
node(n1181,supported) :- node(n1186,supported).
node(n1181,supported) :- node(n9,supported).
node(n1181,unknown) :- \+ node(n1181,supported), \+ node(n1181,refuted).
verdict(c_a613eb9d664d1428,supported) :- node(n1181,supported).
query(verdict(c_a613eb9d664d1428,supported)).
verdict(c_a613eb9d664d1428,refuted) :- node(n1181,refuted).
query(verdict(c_a613eb9d664d1428,refuted)).
verdict(c_a613eb9d664d1428,unknown) :- node(n1181,unknown).
query(verdict(c_a613eb9d664d1428,unknown)).
node(n1192,supported) :- status(o_ca6414747a2e3f760287,supported).
node(n1192,refuted) :- status(o_ca6414747a2e3f760287,refuted).
node(n1192,unknown) :- status(o_ca6414747a2e3f760287,unknown).
node(n1191,supported) :- node(n1183,supported), node(n1184,supported), node(n1185,supported), node(n1192,supported).
node(n1191,refuted) :- node(n1183,refuted).
node(n1191,refuted) :- node(n1184,refuted).
node(n1191,refuted) :- node(n1185,refuted).
node(n1191,refuted) :- node(n1192,refuted).
node(n1191,unknown) :- \+ node(n1191,supported), \+ node(n1191,refuted).
node(n1194,supported) :- status(o_a596942e0cdb492f752a,supported).
node(n1194,refuted) :- status(o_a596942e0cdb492f752a,refuted).
node(n1194,unknown) :- status(o_a596942e0cdb492f752a,unknown).
node(n1193,supported) :- node(n1187,supported), node(n1188,supported), node(n1189,supported), node(n1194,supported).
node(n1193,refuted) :- node(n1187,refuted).
node(n1193,refuted) :- node(n1188,refuted).
node(n1193,refuted) :- node(n1189,refuted).
node(n1193,refuted) :- node(n1194,refuted).
node(n1193,unknown) :- \+ node(n1193,supported), \+ node(n1193,refuted).
node(n1190,refuted) :- node(n1191,refuted), node(n1193,refuted), node(n9,refuted).
node(n1190,supported) :- node(n1191,supported).
node(n1190,supported) :- node(n1193,supported).
node(n1190,supported) :- node(n9,supported).
node(n1190,unknown) :- \+ node(n1190,supported), \+ node(n1190,refuted).
verdict(c_f560c62d922b7848,supported) :- node(n1190,supported).
query(verdict(c_f560c62d922b7848,supported)).
verdict(c_f560c62d922b7848,refuted) :- node(n1190,refuted).
query(verdict(c_f560c62d922b7848,refuted)).
verdict(c_f560c62d922b7848,unknown) :- node(n1190,unknown).
query(verdict(c_f560c62d922b7848,unknown)).
node(n1197,supported) :- status(o_344f646fd75ef8a83548,supported).
node(n1197,refuted) :- status(o_344f646fd75ef8a83548,refuted).
node(n1197,unknown) :- status(o_344f646fd75ef8a83548,unknown).
node(n1198,supported) :- status(o_c53aa6bf8add47ef84d6,supported).
node(n1198,refuted) :- status(o_c53aa6bf8add47ef84d6,refuted).
node(n1198,unknown) :- status(o_c53aa6bf8add47ef84d6,unknown).
node(n1196,supported) :- node(n1183,supported), node(n1184,supported), node(n1185,supported), node(n1192,supported), node(n1197,supported), node(n1198,supported).
node(n1196,refuted) :- node(n1183,refuted).
node(n1196,refuted) :- node(n1184,refuted).
node(n1196,refuted) :- node(n1185,refuted).
node(n1196,refuted) :- node(n1192,refuted).
node(n1196,refuted) :- node(n1197,refuted).
node(n1196,refuted) :- node(n1198,refuted).
node(n1196,unknown) :- \+ node(n1196,supported), \+ node(n1196,refuted).
node(n1200,supported) :- status(o_88a276fc3155159736af,supported).
node(n1200,refuted) :- status(o_88a276fc3155159736af,refuted).
node(n1200,unknown) :- status(o_88a276fc3155159736af,unknown).
node(n1201,supported) :- status(o_8cfd4b2852843bded632,supported).
node(n1201,refuted) :- status(o_8cfd4b2852843bded632,refuted).
node(n1201,unknown) :- status(o_8cfd4b2852843bded632,unknown).
node(n1199,supported) :- node(n1187,supported), node(n1188,supported), node(n1189,supported), node(n1194,supported), node(n1200,supported), node(n1201,supported).
node(n1199,refuted) :- node(n1187,refuted).
node(n1199,refuted) :- node(n1188,refuted).
node(n1199,refuted) :- node(n1189,refuted).
node(n1199,refuted) :- node(n1194,refuted).
node(n1199,refuted) :- node(n1200,refuted).
node(n1199,refuted) :- node(n1201,refuted).
node(n1199,unknown) :- \+ node(n1199,supported), \+ node(n1199,refuted).
node(n1195,refuted) :- node(n1196,refuted), node(n1199,refuted), node(n9,refuted).
node(n1195,supported) :- node(n1196,supported).
node(n1195,supported) :- node(n1199,supported).
node(n1195,supported) :- node(n9,supported).
node(n1195,unknown) :- \+ node(n1195,supported), \+ node(n1195,refuted).
verdict(c_b050c07c45143041,supported) :- node(n1195,supported).
query(verdict(c_b050c07c45143041,supported)).
verdict(c_b050c07c45143041,refuted) :- node(n1195,refuted).
query(verdict(c_b050c07c45143041,refuted)).
verdict(c_b050c07c45143041,unknown) :- node(n1195,unknown).
query(verdict(c_b050c07c45143041,unknown)).
node(n1204,supported) :- status(o_61d21aa9646fe198fd08,supported).
node(n1204,refuted) :- status(o_61d21aa9646fe198fd08,refuted).
node(n1204,unknown) :- status(o_61d21aa9646fe198fd08,unknown).
node(n1203,supported) :- node(n1183,supported), node(n1184,supported), node(n1204,supported).
node(n1203,refuted) :- node(n1183,refuted).
node(n1203,refuted) :- node(n1184,refuted).
node(n1203,refuted) :- node(n1204,refuted).
node(n1203,unknown) :- \+ node(n1203,supported), \+ node(n1203,refuted).
node(n1206,supported) :- status(o_22061740add817095de1,supported).
node(n1206,refuted) :- status(o_22061740add817095de1,refuted).
node(n1206,unknown) :- status(o_22061740add817095de1,unknown).
node(n1205,supported) :- node(n1187,supported), node(n1188,supported), node(n1206,supported).
node(n1205,refuted) :- node(n1187,refuted).
node(n1205,refuted) :- node(n1188,refuted).
node(n1205,refuted) :- node(n1206,refuted).
node(n1205,unknown) :- \+ node(n1205,supported), \+ node(n1205,refuted).
node(n1202,refuted) :- node(n1203,refuted), node(n1205,refuted), node(n9,refuted).
node(n1202,supported) :- node(n1203,supported).
node(n1202,supported) :- node(n1205,supported).
node(n1202,supported) :- node(n9,supported).
node(n1202,unknown) :- \+ node(n1202,supported), \+ node(n1202,refuted).
verdict(c_f70ecd8646217dc4,supported) :- node(n1202,supported).
query(verdict(c_f70ecd8646217dc4,supported)).
verdict(c_f70ecd8646217dc4,refuted) :- node(n1202,refuted).
query(verdict(c_f70ecd8646217dc4,refuted)).
verdict(c_f70ecd8646217dc4,unknown) :- node(n1202,unknown).
query(verdict(c_f70ecd8646217dc4,unknown)).
node(n1208,supported) :- node(n1183,supported), node(n1184,supported), node(n1185,supported), node(n1204,supported).
node(n1208,refuted) :- node(n1183,refuted).
node(n1208,refuted) :- node(n1184,refuted).
node(n1208,refuted) :- node(n1185,refuted).
node(n1208,refuted) :- node(n1204,refuted).
node(n1208,unknown) :- \+ node(n1208,supported), \+ node(n1208,refuted).
node(n1209,supported) :- node(n1187,supported), node(n1188,supported), node(n1189,supported), node(n1206,supported).
node(n1209,refuted) :- node(n1187,refuted).
node(n1209,refuted) :- node(n1188,refuted).
node(n1209,refuted) :- node(n1189,refuted).
node(n1209,refuted) :- node(n1206,refuted).
node(n1209,unknown) :- \+ node(n1209,supported), \+ node(n1209,refuted).
node(n1207,refuted) :- node(n1208,refuted), node(n1209,refuted), node(n9,refuted).
node(n1207,supported) :- node(n1208,supported).
node(n1207,supported) :- node(n1209,supported).
node(n1207,supported) :- node(n9,supported).
node(n1207,unknown) :- \+ node(n1207,supported), \+ node(n1207,refuted).
verdict(c_2b945cc04efa344c,supported) :- node(n1207,supported).
query(verdict(c_2b945cc04efa344c,supported)).
verdict(c_2b945cc04efa344c,refuted) :- node(n1207,refuted).
query(verdict(c_2b945cc04efa344c,refuted)).
verdict(c_2b945cc04efa344c,unknown) :- node(n1207,unknown).
query(verdict(c_2b945cc04efa344c,unknown)).
node(n1212,supported) :- status(o_d560820296afe1f40af4,supported).
node(n1212,refuted) :- status(o_d560820296afe1f40af4,refuted).
node(n1212,unknown) :- status(o_d560820296afe1f40af4,unknown).
node(n1213,supported) :- status(o_f53a9600c4d6a337bc5b,supported).
node(n1213,refuted) :- status(o_f53a9600c4d6a337bc5b,refuted).
node(n1213,unknown) :- status(o_f53a9600c4d6a337bc5b,unknown).
node(n1214,supported) :- status(o_d28003caa0a2297d4738,supported).
node(n1214,refuted) :- status(o_d28003caa0a2297d4738,refuted).
node(n1214,unknown) :- status(o_d28003caa0a2297d4738,unknown).
node(n1211,supported) :- node(n1212,supported), node(n1213,supported), node(n1214,supported).
node(n1211,refuted) :- node(n1212,refuted).
node(n1211,refuted) :- node(n1213,refuted).
node(n1211,refuted) :- node(n1214,refuted).
node(n1211,unknown) :- \+ node(n1211,supported), \+ node(n1211,refuted).
node(n1216,supported) :- status(o_809a3244c4665450a38f,supported).
node(n1216,refuted) :- status(o_809a3244c4665450a38f,refuted).
node(n1216,unknown) :- status(o_809a3244c4665450a38f,unknown).
node(n1217,supported) :- status(o_d8db77b3e349c0a4722d,supported).
node(n1217,refuted) :- status(o_d8db77b3e349c0a4722d,refuted).
node(n1217,unknown) :- status(o_d8db77b3e349c0a4722d,unknown).
node(n1218,supported) :- status(o_c572a95b4a7bce2f2fb1,supported).
node(n1218,refuted) :- status(o_c572a95b4a7bce2f2fb1,refuted).
node(n1218,unknown) :- status(o_c572a95b4a7bce2f2fb1,unknown).
node(n1215,supported) :- node(n1216,supported), node(n1217,supported), node(n1218,supported).
node(n1215,refuted) :- node(n1216,refuted).
node(n1215,refuted) :- node(n1217,refuted).
node(n1215,refuted) :- node(n1218,refuted).
node(n1215,unknown) :- \+ node(n1215,supported), \+ node(n1215,refuted).
node(n1210,refuted) :- node(n1211,refuted), node(n1215,refuted), node(n9,refuted).
node(n1210,supported) :- node(n1211,supported).
node(n1210,supported) :- node(n1215,supported).
node(n1210,supported) :- node(n9,supported).
node(n1210,unknown) :- \+ node(n1210,supported), \+ node(n1210,refuted).
verdict(c_464de3bb0e3952e7,supported) :- node(n1210,supported).
query(verdict(c_464de3bb0e3952e7,supported)).
verdict(c_464de3bb0e3952e7,refuted) :- node(n1210,refuted).
query(verdict(c_464de3bb0e3952e7,refuted)).
verdict(c_464de3bb0e3952e7,unknown) :- node(n1210,unknown).
query(verdict(c_464de3bb0e3952e7,unknown)).
node(n1221,supported) :- status(o_dc206f3dd6ac20b636ec,supported).
node(n1221,refuted) :- status(o_dc206f3dd6ac20b636ec,refuted).
node(n1221,unknown) :- status(o_dc206f3dd6ac20b636ec,unknown).
node(n1220,supported) :- node(n1212,supported), node(n1213,supported), node(n1214,supported), node(n1221,supported).
node(n1220,refuted) :- node(n1212,refuted).
node(n1220,refuted) :- node(n1213,refuted).
node(n1220,refuted) :- node(n1214,refuted).
node(n1220,refuted) :- node(n1221,refuted).
node(n1220,unknown) :- \+ node(n1220,supported), \+ node(n1220,refuted).
node(n1223,supported) :- status(o_46a9f62215ff0d8265be,supported).
node(n1223,refuted) :- status(o_46a9f62215ff0d8265be,refuted).
node(n1223,unknown) :- status(o_46a9f62215ff0d8265be,unknown).
node(n1222,supported) :- node(n1216,supported), node(n1217,supported), node(n1218,supported), node(n1223,supported).
node(n1222,refuted) :- node(n1216,refuted).
node(n1222,refuted) :- node(n1217,refuted).
node(n1222,refuted) :- node(n1218,refuted).
node(n1222,refuted) :- node(n1223,refuted).
node(n1222,unknown) :- \+ node(n1222,supported), \+ node(n1222,refuted).
node(n1219,refuted) :- node(n1220,refuted), node(n1222,refuted), node(n9,refuted).
node(n1219,supported) :- node(n1220,supported).
node(n1219,supported) :- node(n1222,supported).
node(n1219,supported) :- node(n9,supported).
node(n1219,unknown) :- \+ node(n1219,supported), \+ node(n1219,refuted).
verdict(c_744c5dd34806c6bb,supported) :- node(n1219,supported).
query(verdict(c_744c5dd34806c6bb,supported)).
verdict(c_744c5dd34806c6bb,refuted) :- node(n1219,refuted).
query(verdict(c_744c5dd34806c6bb,refuted)).
verdict(c_744c5dd34806c6bb,unknown) :- node(n1219,unknown).
query(verdict(c_744c5dd34806c6bb,unknown)).
node(n1226,supported) :- status(o_aad9276d5b0fbab5593f,supported).
node(n1226,refuted) :- status(o_aad9276d5b0fbab5593f,refuted).
node(n1226,unknown) :- status(o_aad9276d5b0fbab5593f,unknown).
node(n1227,supported) :- status(o_d69722e0f08f607956ac,supported).
node(n1227,refuted) :- status(o_d69722e0f08f607956ac,refuted).
node(n1227,unknown) :- status(o_d69722e0f08f607956ac,unknown).
node(n1225,supported) :- node(n1212,supported), node(n1213,supported), node(n1214,supported), node(n1221,supported), node(n1226,supported), node(n1227,supported).
node(n1225,refuted) :- node(n1212,refuted).
node(n1225,refuted) :- node(n1213,refuted).
node(n1225,refuted) :- node(n1214,refuted).
node(n1225,refuted) :- node(n1221,refuted).
node(n1225,refuted) :- node(n1226,refuted).
node(n1225,refuted) :- node(n1227,refuted).
node(n1225,unknown) :- \+ node(n1225,supported), \+ node(n1225,refuted).
node(n1229,supported) :- status(o_9cc9b78ebb59262bb7f7,supported).
node(n1229,refuted) :- status(o_9cc9b78ebb59262bb7f7,refuted).
node(n1229,unknown) :- status(o_9cc9b78ebb59262bb7f7,unknown).
node(n1230,supported) :- status(o_93d24fe7fa96e6534682,supported).
node(n1230,refuted) :- status(o_93d24fe7fa96e6534682,refuted).
node(n1230,unknown) :- status(o_93d24fe7fa96e6534682,unknown).
node(n1228,supported) :- node(n1216,supported), node(n1217,supported), node(n1218,supported), node(n1223,supported), node(n1229,supported), node(n1230,supported).
node(n1228,refuted) :- node(n1216,refuted).
node(n1228,refuted) :- node(n1217,refuted).
node(n1228,refuted) :- node(n1218,refuted).
node(n1228,refuted) :- node(n1223,refuted).
node(n1228,refuted) :- node(n1229,refuted).
node(n1228,refuted) :- node(n1230,refuted).
node(n1228,unknown) :- \+ node(n1228,supported), \+ node(n1228,refuted).
node(n1224,refuted) :- node(n1225,refuted), node(n1228,refuted), node(n9,refuted).
node(n1224,supported) :- node(n1225,supported).
node(n1224,supported) :- node(n1228,supported).
node(n1224,supported) :- node(n9,supported).
node(n1224,unknown) :- \+ node(n1224,supported), \+ node(n1224,refuted).
verdict(c_652042ab10bbb53a,supported) :- node(n1224,supported).
query(verdict(c_652042ab10bbb53a,supported)).
verdict(c_652042ab10bbb53a,refuted) :- node(n1224,refuted).
query(verdict(c_652042ab10bbb53a,refuted)).
verdict(c_652042ab10bbb53a,unknown) :- node(n1224,unknown).
query(verdict(c_652042ab10bbb53a,unknown)).
node(n1233,supported) :- status(o_2be3909b8275e551a030,supported).
node(n1233,refuted) :- status(o_2be3909b8275e551a030,refuted).
node(n1233,unknown) :- status(o_2be3909b8275e551a030,unknown).
node(n1232,supported) :- node(n1212,supported), node(n1213,supported), node(n1233,supported).
node(n1232,refuted) :- node(n1212,refuted).
node(n1232,refuted) :- node(n1213,refuted).
node(n1232,refuted) :- node(n1233,refuted).
node(n1232,unknown) :- \+ node(n1232,supported), \+ node(n1232,refuted).
node(n1235,supported) :- status(o_c1e4db37d9d1455a3b2d,supported).
node(n1235,refuted) :- status(o_c1e4db37d9d1455a3b2d,refuted).
node(n1235,unknown) :- status(o_c1e4db37d9d1455a3b2d,unknown).
node(n1234,supported) :- node(n1216,supported), node(n1217,supported), node(n1235,supported).
node(n1234,refuted) :- node(n1216,refuted).
node(n1234,refuted) :- node(n1217,refuted).
node(n1234,refuted) :- node(n1235,refuted).
node(n1234,unknown) :- \+ node(n1234,supported), \+ node(n1234,refuted).
node(n1231,refuted) :- node(n1232,refuted), node(n1234,refuted), node(n9,refuted).
node(n1231,supported) :- node(n1232,supported).
node(n1231,supported) :- node(n1234,supported).
node(n1231,supported) :- node(n9,supported).
node(n1231,unknown) :- \+ node(n1231,supported), \+ node(n1231,refuted).
verdict(c_410e43df5ed287d5,supported) :- node(n1231,supported).
query(verdict(c_410e43df5ed287d5,supported)).
verdict(c_410e43df5ed287d5,refuted) :- node(n1231,refuted).
query(verdict(c_410e43df5ed287d5,refuted)).
verdict(c_410e43df5ed287d5,unknown) :- node(n1231,unknown).
query(verdict(c_410e43df5ed287d5,unknown)).
node(n1237,supported) :- node(n1212,supported), node(n1213,supported), node(n1214,supported), node(n1233,supported).
node(n1237,refuted) :- node(n1212,refuted).
node(n1237,refuted) :- node(n1213,refuted).
node(n1237,refuted) :- node(n1214,refuted).
node(n1237,refuted) :- node(n1233,refuted).
node(n1237,unknown) :- \+ node(n1237,supported), \+ node(n1237,refuted).
node(n1238,supported) :- node(n1216,supported), node(n1217,supported), node(n1218,supported), node(n1235,supported).
node(n1238,refuted) :- node(n1216,refuted).
node(n1238,refuted) :- node(n1217,refuted).
node(n1238,refuted) :- node(n1218,refuted).
node(n1238,refuted) :- node(n1235,refuted).
node(n1238,unknown) :- \+ node(n1238,supported), \+ node(n1238,refuted).
node(n1236,refuted) :- node(n1237,refuted), node(n1238,refuted), node(n9,refuted).
node(n1236,supported) :- node(n1237,supported).
node(n1236,supported) :- node(n1238,supported).
node(n1236,supported) :- node(n9,supported).
node(n1236,unknown) :- \+ node(n1236,supported), \+ node(n1236,refuted).
verdict(c_8658708b8f73af67,supported) :- node(n1236,supported).
query(verdict(c_8658708b8f73af67,supported)).
verdict(c_8658708b8f73af67,refuted) :- node(n1236,refuted).
query(verdict(c_8658708b8f73af67,refuted)).
verdict(c_8658708b8f73af67,unknown) :- node(n1236,unknown).
query(verdict(c_8658708b8f73af67,unknown)).
node(n1241,supported) :- status(o_6d7c81f5e17ed442ba93,supported).
node(n1241,refuted) :- status(o_6d7c81f5e17ed442ba93,refuted).
node(n1241,unknown) :- status(o_6d7c81f5e17ed442ba93,unknown).
node(n1242,supported) :- status(o_ec8f8d96179e97438b06,supported).
node(n1242,refuted) :- status(o_ec8f8d96179e97438b06,refuted).
node(n1242,unknown) :- status(o_ec8f8d96179e97438b06,unknown).
node(n1243,supported) :- status(o_d0cbc0de5af2d9c48df8,supported).
node(n1243,refuted) :- status(o_d0cbc0de5af2d9c48df8,refuted).
node(n1243,unknown) :- status(o_d0cbc0de5af2d9c48df8,unknown).
node(n1240,supported) :- node(n1241,supported), node(n1242,supported), node(n1243,supported).
node(n1240,refuted) :- node(n1241,refuted).
node(n1240,refuted) :- node(n1242,refuted).
node(n1240,refuted) :- node(n1243,refuted).
node(n1240,unknown) :- \+ node(n1240,supported), \+ node(n1240,refuted).
node(n1239,refuted) :- node(n1240,refuted), node(n9,refuted).
node(n1239,supported) :- node(n1240,supported).
node(n1239,supported) :- node(n9,supported).
node(n1239,unknown) :- \+ node(n1239,supported), \+ node(n1239,refuted).
verdict(c_78386aa1f315dd5c,supported) :- node(n1239,supported).
query(verdict(c_78386aa1f315dd5c,supported)).
verdict(c_78386aa1f315dd5c,refuted) :- node(n1239,refuted).
query(verdict(c_78386aa1f315dd5c,refuted)).
verdict(c_78386aa1f315dd5c,unknown) :- node(n1239,unknown).
query(verdict(c_78386aa1f315dd5c,unknown)).
node(n1246,supported) :- status(o_ea620b80cd62b0f24a66,supported).
node(n1246,refuted) :- status(o_ea620b80cd62b0f24a66,refuted).
node(n1246,unknown) :- status(o_ea620b80cd62b0f24a66,unknown).
node(n1245,supported) :- node(n1241,supported), node(n1242,supported), node(n1243,supported), node(n1246,supported).
node(n1245,refuted) :- node(n1241,refuted).
node(n1245,refuted) :- node(n1242,refuted).
node(n1245,refuted) :- node(n1243,refuted).
node(n1245,refuted) :- node(n1246,refuted).
node(n1245,unknown) :- \+ node(n1245,supported), \+ node(n1245,refuted).
node(n1244,refuted) :- node(n1245,refuted), node(n9,refuted).
node(n1244,supported) :- node(n1245,supported).
node(n1244,supported) :- node(n9,supported).
node(n1244,unknown) :- \+ node(n1244,supported), \+ node(n1244,refuted).
verdict(c_507b9bd2a267b6a4,supported) :- node(n1244,supported).
query(verdict(c_507b9bd2a267b6a4,supported)).
verdict(c_507b9bd2a267b6a4,refuted) :- node(n1244,refuted).
query(verdict(c_507b9bd2a267b6a4,refuted)).
verdict(c_507b9bd2a267b6a4,unknown) :- node(n1244,unknown).
query(verdict(c_507b9bd2a267b6a4,unknown)).
node(n1249,supported) :- status(o_72ebf141f0c78640731d,supported).
node(n1249,refuted) :- status(o_72ebf141f0c78640731d,refuted).
node(n1249,unknown) :- status(o_72ebf141f0c78640731d,unknown).
node(n1250,supported) :- status(o_49cb2fb72a56a876de5b,supported).
node(n1250,refuted) :- status(o_49cb2fb72a56a876de5b,refuted).
node(n1250,unknown) :- status(o_49cb2fb72a56a876de5b,unknown).
node(n1248,supported) :- node(n1241,supported), node(n1242,supported), node(n1243,supported), node(n1246,supported), node(n1249,supported), node(n1250,supported).
node(n1248,refuted) :- node(n1241,refuted).
node(n1248,refuted) :- node(n1242,refuted).
node(n1248,refuted) :- node(n1243,refuted).
node(n1248,refuted) :- node(n1246,refuted).
node(n1248,refuted) :- node(n1249,refuted).
node(n1248,refuted) :- node(n1250,refuted).
node(n1248,unknown) :- \+ node(n1248,supported), \+ node(n1248,refuted).
node(n1247,refuted) :- node(n1248,refuted), node(n9,refuted).
node(n1247,supported) :- node(n1248,supported).
node(n1247,supported) :- node(n9,supported).
node(n1247,unknown) :- \+ node(n1247,supported), \+ node(n1247,refuted).
verdict(c_d25dceb8e8d906f1,supported) :- node(n1247,supported).
query(verdict(c_d25dceb8e8d906f1,supported)).
verdict(c_d25dceb8e8d906f1,refuted) :- node(n1247,refuted).
query(verdict(c_d25dceb8e8d906f1,refuted)).
verdict(c_d25dceb8e8d906f1,unknown) :- node(n1247,unknown).
query(verdict(c_d25dceb8e8d906f1,unknown)).
node(n1253,supported) :- status(o_6f87adf239c4b919c9bb,supported).
node(n1253,refuted) :- status(o_6f87adf239c4b919c9bb,refuted).
node(n1253,unknown) :- status(o_6f87adf239c4b919c9bb,unknown).
node(n1252,supported) :- node(n1241,supported), node(n1242,supported), node(n1253,supported).
node(n1252,refuted) :- node(n1241,refuted).
node(n1252,refuted) :- node(n1242,refuted).
node(n1252,refuted) :- node(n1253,refuted).
node(n1252,unknown) :- \+ node(n1252,supported), \+ node(n1252,refuted).
node(n1251,refuted) :- node(n1252,refuted), node(n9,refuted).
node(n1251,supported) :- node(n1252,supported).
node(n1251,supported) :- node(n9,supported).
node(n1251,unknown) :- \+ node(n1251,supported), \+ node(n1251,refuted).
verdict(c_73cf4b3868d06677,supported) :- node(n1251,supported).
query(verdict(c_73cf4b3868d06677,supported)).
verdict(c_73cf4b3868d06677,refuted) :- node(n1251,refuted).
query(verdict(c_73cf4b3868d06677,refuted)).
verdict(c_73cf4b3868d06677,unknown) :- node(n1251,unknown).
query(verdict(c_73cf4b3868d06677,unknown)).
node(n1255,supported) :- node(n1241,supported), node(n1242,supported), node(n1243,supported), node(n1253,supported).
node(n1255,refuted) :- node(n1241,refuted).
node(n1255,refuted) :- node(n1242,refuted).
node(n1255,refuted) :- node(n1243,refuted).
node(n1255,refuted) :- node(n1253,refuted).
node(n1255,unknown) :- \+ node(n1255,supported), \+ node(n1255,refuted).
node(n1254,refuted) :- node(n1255,refuted), node(n9,refuted).
node(n1254,supported) :- node(n1255,supported).
node(n1254,supported) :- node(n9,supported).
node(n1254,unknown) :- \+ node(n1254,supported), \+ node(n1254,refuted).
verdict(c_0e27c72d359ec726,supported) :- node(n1254,supported).
query(verdict(c_0e27c72d359ec726,supported)).
verdict(c_0e27c72d359ec726,refuted) :- node(n1254,refuted).
query(verdict(c_0e27c72d359ec726,refuted)).
verdict(c_0e27c72d359ec726,unknown) :- node(n1254,unknown).
query(verdict(c_0e27c72d359ec726,unknown)).
node(n1258,supported) :- status(o_011ef167b0355c41f24c,supported).
node(n1258,refuted) :- status(o_011ef167b0355c41f24c,refuted).
node(n1258,unknown) :- status(o_011ef167b0355c41f24c,unknown).
node(n1259,supported) :- status(o_84a6bb3aa500bf97227d,supported).
node(n1259,refuted) :- status(o_84a6bb3aa500bf97227d,refuted).
node(n1259,unknown) :- status(o_84a6bb3aa500bf97227d,unknown).
node(n1260,supported) :- status(o_c1d0a468d80cd1578af4,supported).
node(n1260,refuted) :- status(o_c1d0a468d80cd1578af4,refuted).
node(n1260,unknown) :- status(o_c1d0a468d80cd1578af4,unknown).
node(n1257,supported) :- node(n1258,supported), node(n1259,supported), node(n1260,supported).
node(n1257,refuted) :- node(n1258,refuted).
node(n1257,refuted) :- node(n1259,refuted).
node(n1257,refuted) :- node(n1260,refuted).
node(n1257,unknown) :- \+ node(n1257,supported), \+ node(n1257,refuted).
node(n1256,refuted) :- node(n1257,refuted), node(n9,refuted).
node(n1256,supported) :- node(n1257,supported).
node(n1256,supported) :- node(n9,supported).
node(n1256,unknown) :- \+ node(n1256,supported), \+ node(n1256,refuted).
verdict(c_ac7b4f512909fb49,supported) :- node(n1256,supported).
query(verdict(c_ac7b4f512909fb49,supported)).
verdict(c_ac7b4f512909fb49,refuted) :- node(n1256,refuted).
query(verdict(c_ac7b4f512909fb49,refuted)).
verdict(c_ac7b4f512909fb49,unknown) :- node(n1256,unknown).
query(verdict(c_ac7b4f512909fb49,unknown)).
node(n1263,supported) :- status(o_7183e4fe32fdaf1863b1,supported).
node(n1263,refuted) :- status(o_7183e4fe32fdaf1863b1,refuted).
node(n1263,unknown) :- status(o_7183e4fe32fdaf1863b1,unknown).
node(n1262,supported) :- node(n1258,supported), node(n1259,supported), node(n1260,supported), node(n1263,supported).
node(n1262,refuted) :- node(n1258,refuted).
node(n1262,refuted) :- node(n1259,refuted).
node(n1262,refuted) :- node(n1260,refuted).
node(n1262,refuted) :- node(n1263,refuted).
node(n1262,unknown) :- \+ node(n1262,supported), \+ node(n1262,refuted).
node(n1261,refuted) :- node(n1262,refuted), node(n9,refuted).
node(n1261,supported) :- node(n1262,supported).
node(n1261,supported) :- node(n9,supported).
node(n1261,unknown) :- \+ node(n1261,supported), \+ node(n1261,refuted).
verdict(c_541d385da25751e1,supported) :- node(n1261,supported).
query(verdict(c_541d385da25751e1,supported)).
verdict(c_541d385da25751e1,refuted) :- node(n1261,refuted).
query(verdict(c_541d385da25751e1,refuted)).
verdict(c_541d385da25751e1,unknown) :- node(n1261,unknown).
query(verdict(c_541d385da25751e1,unknown)).
node(n1266,supported) :- status(o_055f314ba3372308c037,supported).
node(n1266,refuted) :- status(o_055f314ba3372308c037,refuted).
node(n1266,unknown) :- status(o_055f314ba3372308c037,unknown).
node(n1267,supported) :- status(o_da9bfd1a9ce0d58182cc,supported).
node(n1267,refuted) :- status(o_da9bfd1a9ce0d58182cc,refuted).
node(n1267,unknown) :- status(o_da9bfd1a9ce0d58182cc,unknown).
node(n1265,supported) :- node(n1258,supported), node(n1259,supported), node(n1260,supported), node(n1263,supported), node(n1266,supported), node(n1267,supported).
node(n1265,refuted) :- node(n1258,refuted).
node(n1265,refuted) :- node(n1259,refuted).
node(n1265,refuted) :- node(n1260,refuted).
node(n1265,refuted) :- node(n1263,refuted).
node(n1265,refuted) :- node(n1266,refuted).
node(n1265,refuted) :- node(n1267,refuted).
node(n1265,unknown) :- \+ node(n1265,supported), \+ node(n1265,refuted).
node(n1264,refuted) :- node(n1265,refuted), node(n9,refuted).
node(n1264,supported) :- node(n1265,supported).
node(n1264,supported) :- node(n9,supported).
node(n1264,unknown) :- \+ node(n1264,supported), \+ node(n1264,refuted).
verdict(c_cf96e9b06becf116,supported) :- node(n1264,supported).
query(verdict(c_cf96e9b06becf116,supported)).
verdict(c_cf96e9b06becf116,refuted) :- node(n1264,refuted).
query(verdict(c_cf96e9b06becf116,refuted)).
verdict(c_cf96e9b06becf116,unknown) :- node(n1264,unknown).
query(verdict(c_cf96e9b06becf116,unknown)).
node(n1270,supported) :- status(o_17783a1e4c08b2bb7b76,supported).
node(n1270,refuted) :- status(o_17783a1e4c08b2bb7b76,refuted).
node(n1270,unknown) :- status(o_17783a1e4c08b2bb7b76,unknown).
node(n1269,supported) :- node(n1258,supported), node(n1259,supported), node(n1270,supported).
node(n1269,refuted) :- node(n1258,refuted).
node(n1269,refuted) :- node(n1259,refuted).
node(n1269,refuted) :- node(n1270,refuted).
node(n1269,unknown) :- \+ node(n1269,supported), \+ node(n1269,refuted).
node(n1268,refuted) :- node(n1269,refuted), node(n9,refuted).
node(n1268,supported) :- node(n1269,supported).
node(n1268,supported) :- node(n9,supported).
node(n1268,unknown) :- \+ node(n1268,supported), \+ node(n1268,refuted).
verdict(c_e4ae68faac13e652,supported) :- node(n1268,supported).
query(verdict(c_e4ae68faac13e652,supported)).
verdict(c_e4ae68faac13e652,refuted) :- node(n1268,refuted).
query(verdict(c_e4ae68faac13e652,refuted)).
verdict(c_e4ae68faac13e652,unknown) :- node(n1268,unknown).
query(verdict(c_e4ae68faac13e652,unknown)).
node(n1272,supported) :- node(n1258,supported), node(n1259,supported), node(n1260,supported), node(n1270,supported).
node(n1272,refuted) :- node(n1258,refuted).
node(n1272,refuted) :- node(n1259,refuted).
node(n1272,refuted) :- node(n1260,refuted).
node(n1272,refuted) :- node(n1270,refuted).
node(n1272,unknown) :- \+ node(n1272,supported), \+ node(n1272,refuted).
node(n1271,refuted) :- node(n1272,refuted), node(n9,refuted).
node(n1271,supported) :- node(n1272,supported).
node(n1271,supported) :- node(n9,supported).
node(n1271,unknown) :- \+ node(n1271,supported), \+ node(n1271,refuted).
verdict(c_6cb58f10cbb346ef,supported) :- node(n1271,supported).
query(verdict(c_6cb58f10cbb346ef,supported)).
verdict(c_6cb58f10cbb346ef,refuted) :- node(n1271,refuted).
query(verdict(c_6cb58f10cbb346ef,refuted)).
verdict(c_6cb58f10cbb346ef,unknown) :- node(n1271,unknown).
query(verdict(c_6cb58f10cbb346ef,unknown)).
node(n1275,supported) :- status(o_216b31c1d6bd89280676,supported).
node(n1275,refuted) :- status(o_216b31c1d6bd89280676,refuted).
node(n1275,unknown) :- status(o_216b31c1d6bd89280676,unknown).
node(n1276,supported) :- status(o_49e77356060fc4068c06,supported).
node(n1276,refuted) :- status(o_49e77356060fc4068c06,refuted).
node(n1276,unknown) :- status(o_49e77356060fc4068c06,unknown).
node(n1277,supported) :- status(o_4512c0e13994a0d98fd1,supported).
node(n1277,refuted) :- status(o_4512c0e13994a0d98fd1,refuted).
node(n1277,unknown) :- status(o_4512c0e13994a0d98fd1,unknown).
node(n1274,supported) :- node(n1275,supported), node(n1276,supported), node(n1277,supported).
node(n1274,refuted) :- node(n1275,refuted).
node(n1274,refuted) :- node(n1276,refuted).
node(n1274,refuted) :- node(n1277,refuted).
node(n1274,unknown) :- \+ node(n1274,supported), \+ node(n1274,refuted).
node(n1273,refuted) :- node(n1274,refuted), node(n9,refuted).
node(n1273,supported) :- node(n1274,supported).
node(n1273,supported) :- node(n9,supported).
node(n1273,unknown) :- \+ node(n1273,supported), \+ node(n1273,refuted).
verdict(c_6ae0921b91343980,supported) :- node(n1273,supported).
query(verdict(c_6ae0921b91343980,supported)).
verdict(c_6ae0921b91343980,refuted) :- node(n1273,refuted).
query(verdict(c_6ae0921b91343980,refuted)).
verdict(c_6ae0921b91343980,unknown) :- node(n1273,unknown).
query(verdict(c_6ae0921b91343980,unknown)).
node(n1280,supported) :- status(o_8ab49489c3f340927c7b,supported).
node(n1280,refuted) :- status(o_8ab49489c3f340927c7b,refuted).
node(n1280,unknown) :- status(o_8ab49489c3f340927c7b,unknown).
node(n1279,supported) :- node(n1275,supported), node(n1276,supported), node(n1277,supported), node(n1280,supported).
node(n1279,refuted) :- node(n1275,refuted).
node(n1279,refuted) :- node(n1276,refuted).
node(n1279,refuted) :- node(n1277,refuted).
node(n1279,refuted) :- node(n1280,refuted).
node(n1279,unknown) :- \+ node(n1279,supported), \+ node(n1279,refuted).
node(n1278,refuted) :- node(n1279,refuted), node(n9,refuted).
node(n1278,supported) :- node(n1279,supported).
node(n1278,supported) :- node(n9,supported).
node(n1278,unknown) :- \+ node(n1278,supported), \+ node(n1278,refuted).
verdict(c_1da7bcbb6ca47933,supported) :- node(n1278,supported).
query(verdict(c_1da7bcbb6ca47933,supported)).
verdict(c_1da7bcbb6ca47933,refuted) :- node(n1278,refuted).
query(verdict(c_1da7bcbb6ca47933,refuted)).
verdict(c_1da7bcbb6ca47933,unknown) :- node(n1278,unknown).
query(verdict(c_1da7bcbb6ca47933,unknown)).
node(n1283,supported) :- status(o_a5e8ca439ddb711acb6f,supported).
node(n1283,refuted) :- status(o_a5e8ca439ddb711acb6f,refuted).
node(n1283,unknown) :- status(o_a5e8ca439ddb711acb6f,unknown).
node(n1284,supported) :- status(o_c7bfe99f77a2cba070e2,supported).
node(n1284,refuted) :- status(o_c7bfe99f77a2cba070e2,refuted).
node(n1284,unknown) :- status(o_c7bfe99f77a2cba070e2,unknown).
node(n1282,supported) :- node(n1275,supported), node(n1276,supported), node(n1277,supported), node(n1280,supported), node(n1283,supported), node(n1284,supported).
node(n1282,refuted) :- node(n1275,refuted).
node(n1282,refuted) :- node(n1276,refuted).
node(n1282,refuted) :- node(n1277,refuted).
node(n1282,refuted) :- node(n1280,refuted).
node(n1282,refuted) :- node(n1283,refuted).
node(n1282,refuted) :- node(n1284,refuted).
node(n1282,unknown) :- \+ node(n1282,supported), \+ node(n1282,refuted).
node(n1281,refuted) :- node(n1282,refuted), node(n9,refuted).
node(n1281,supported) :- node(n1282,supported).
node(n1281,supported) :- node(n9,supported).
node(n1281,unknown) :- \+ node(n1281,supported), \+ node(n1281,refuted).
verdict(c_8c0fc526db843427,supported) :- node(n1281,supported).
query(verdict(c_8c0fc526db843427,supported)).
verdict(c_8c0fc526db843427,refuted) :- node(n1281,refuted).
query(verdict(c_8c0fc526db843427,refuted)).
verdict(c_8c0fc526db843427,unknown) :- node(n1281,unknown).
query(verdict(c_8c0fc526db843427,unknown)).
node(n1287,supported) :- status(o_f2386cddef60e4a38030,supported).
node(n1287,refuted) :- status(o_f2386cddef60e4a38030,refuted).
node(n1287,unknown) :- status(o_f2386cddef60e4a38030,unknown).
node(n1286,supported) :- node(n1275,supported), node(n1276,supported), node(n1287,supported).
node(n1286,refuted) :- node(n1275,refuted).
node(n1286,refuted) :- node(n1276,refuted).
node(n1286,refuted) :- node(n1287,refuted).
node(n1286,unknown) :- \+ node(n1286,supported), \+ node(n1286,refuted).
node(n1285,refuted) :- node(n1286,refuted), node(n9,refuted).
node(n1285,supported) :- node(n1286,supported).
node(n1285,supported) :- node(n9,supported).
node(n1285,unknown) :- \+ node(n1285,supported), \+ node(n1285,refuted).
verdict(c_5a9ed88999378e85,supported) :- node(n1285,supported).
query(verdict(c_5a9ed88999378e85,supported)).
verdict(c_5a9ed88999378e85,refuted) :- node(n1285,refuted).
query(verdict(c_5a9ed88999378e85,refuted)).
verdict(c_5a9ed88999378e85,unknown) :- node(n1285,unknown).
query(verdict(c_5a9ed88999378e85,unknown)).
node(n1289,supported) :- node(n1275,supported), node(n1276,supported), node(n1277,supported), node(n1287,supported).
node(n1289,refuted) :- node(n1275,refuted).
node(n1289,refuted) :- node(n1276,refuted).
node(n1289,refuted) :- node(n1277,refuted).
node(n1289,refuted) :- node(n1287,refuted).
node(n1289,unknown) :- \+ node(n1289,supported), \+ node(n1289,refuted).
node(n1288,refuted) :- node(n1289,refuted), node(n9,refuted).
node(n1288,supported) :- node(n1289,supported).
node(n1288,supported) :- node(n9,supported).
node(n1288,unknown) :- \+ node(n1288,supported), \+ node(n1288,refuted).
verdict(c_fa9d7f2f4efc07aa,supported) :- node(n1288,supported).
query(verdict(c_fa9d7f2f4efc07aa,supported)).
verdict(c_fa9d7f2f4efc07aa,refuted) :- node(n1288,refuted).
query(verdict(c_fa9d7f2f4efc07aa,refuted)).
verdict(c_fa9d7f2f4efc07aa,unknown) :- node(n1288,unknown).
query(verdict(c_fa9d7f2f4efc07aa,unknown)).
node(n1292,supported) :- status(o_fbf4355644bed3bb34fe,supported).
node(n1292,refuted) :- status(o_fbf4355644bed3bb34fe,refuted).
node(n1292,unknown) :- status(o_fbf4355644bed3bb34fe,unknown).
node(n1293,supported) :- status(o_8920fcd17281bd29fbdd,supported).
node(n1293,refuted) :- status(o_8920fcd17281bd29fbdd,refuted).
node(n1293,unknown) :- status(o_8920fcd17281bd29fbdd,unknown).
node(n1294,supported) :- status(o_83e0e7e4f9595bd57fd0,supported).
node(n1294,refuted) :- status(o_83e0e7e4f9595bd57fd0,refuted).
node(n1294,unknown) :- status(o_83e0e7e4f9595bd57fd0,unknown).
node(n1291,supported) :- node(n1292,supported), node(n1293,supported), node(n1294,supported).
node(n1291,refuted) :- node(n1292,refuted).
node(n1291,refuted) :- node(n1293,refuted).
node(n1291,refuted) :- node(n1294,refuted).
node(n1291,unknown) :- \+ node(n1291,supported), \+ node(n1291,refuted).
node(n1290,refuted) :- node(n1291,refuted), node(n9,refuted).
node(n1290,supported) :- node(n1291,supported).
node(n1290,supported) :- node(n9,supported).
node(n1290,unknown) :- \+ node(n1290,supported), \+ node(n1290,refuted).
verdict(c_ed1276f65b017375,supported) :- node(n1290,supported).
query(verdict(c_ed1276f65b017375,supported)).
verdict(c_ed1276f65b017375,refuted) :- node(n1290,refuted).
query(verdict(c_ed1276f65b017375,refuted)).
verdict(c_ed1276f65b017375,unknown) :- node(n1290,unknown).
query(verdict(c_ed1276f65b017375,unknown)).
node(n1297,supported) :- status(o_282dbf326fc43e737c39,supported).
node(n1297,refuted) :- status(o_282dbf326fc43e737c39,refuted).
node(n1297,unknown) :- status(o_282dbf326fc43e737c39,unknown).
node(n1296,supported) :- node(n1292,supported), node(n1293,supported), node(n1294,supported), node(n1297,supported).
node(n1296,refuted) :- node(n1292,refuted).
node(n1296,refuted) :- node(n1293,refuted).
node(n1296,refuted) :- node(n1294,refuted).
node(n1296,refuted) :- node(n1297,refuted).
node(n1296,unknown) :- \+ node(n1296,supported), \+ node(n1296,refuted).
node(n1295,refuted) :- node(n1296,refuted), node(n9,refuted).
node(n1295,supported) :- node(n1296,supported).
node(n1295,supported) :- node(n9,supported).
node(n1295,unknown) :- \+ node(n1295,supported), \+ node(n1295,refuted).
verdict(c_26ee8d196791da28,supported) :- node(n1295,supported).
query(verdict(c_26ee8d196791da28,supported)).
verdict(c_26ee8d196791da28,refuted) :- node(n1295,refuted).
query(verdict(c_26ee8d196791da28,refuted)).
verdict(c_26ee8d196791da28,unknown) :- node(n1295,unknown).
query(verdict(c_26ee8d196791da28,unknown)).
node(n1300,supported) :- status(o_80c53c3190b388d09275,supported).
node(n1300,refuted) :- status(o_80c53c3190b388d09275,refuted).
node(n1300,unknown) :- status(o_80c53c3190b388d09275,unknown).
node(n1301,supported) :- status(o_c149cf3e3cfd2bbef6a8,supported).
node(n1301,refuted) :- status(o_c149cf3e3cfd2bbef6a8,refuted).
node(n1301,unknown) :- status(o_c149cf3e3cfd2bbef6a8,unknown).
node(n1299,supported) :- node(n1292,supported), node(n1293,supported), node(n1294,supported), node(n1297,supported), node(n1300,supported), node(n1301,supported).
node(n1299,refuted) :- node(n1292,refuted).
node(n1299,refuted) :- node(n1293,refuted).
node(n1299,refuted) :- node(n1294,refuted).
node(n1299,refuted) :- node(n1297,refuted).
node(n1299,refuted) :- node(n1300,refuted).
node(n1299,refuted) :- node(n1301,refuted).
node(n1299,unknown) :- \+ node(n1299,supported), \+ node(n1299,refuted).
node(n1298,refuted) :- node(n1299,refuted), node(n9,refuted).
node(n1298,supported) :- node(n1299,supported).
node(n1298,supported) :- node(n9,supported).
node(n1298,unknown) :- \+ node(n1298,supported), \+ node(n1298,refuted).
verdict(c_46a5cbb07611a388,supported) :- node(n1298,supported).
query(verdict(c_46a5cbb07611a388,supported)).
verdict(c_46a5cbb07611a388,refuted) :- node(n1298,refuted).
query(verdict(c_46a5cbb07611a388,refuted)).
verdict(c_46a5cbb07611a388,unknown) :- node(n1298,unknown).
query(verdict(c_46a5cbb07611a388,unknown)).
node(n1304,supported) :- status(o_cd56cdf8f4aef4759513,supported).
node(n1304,refuted) :- status(o_cd56cdf8f4aef4759513,refuted).
node(n1304,unknown) :- status(o_cd56cdf8f4aef4759513,unknown).
node(n1303,supported) :- node(n1292,supported), node(n1293,supported), node(n1304,supported).
node(n1303,refuted) :- node(n1292,refuted).
node(n1303,refuted) :- node(n1293,refuted).
node(n1303,refuted) :- node(n1304,refuted).
node(n1303,unknown) :- \+ node(n1303,supported), \+ node(n1303,refuted).
node(n1302,refuted) :- node(n1303,refuted), node(n9,refuted).
node(n1302,supported) :- node(n1303,supported).
node(n1302,supported) :- node(n9,supported).
node(n1302,unknown) :- \+ node(n1302,supported), \+ node(n1302,refuted).
verdict(c_8e3f0bf5f402e343,supported) :- node(n1302,supported).
query(verdict(c_8e3f0bf5f402e343,supported)).
verdict(c_8e3f0bf5f402e343,refuted) :- node(n1302,refuted).
query(verdict(c_8e3f0bf5f402e343,refuted)).
verdict(c_8e3f0bf5f402e343,unknown) :- node(n1302,unknown).
query(verdict(c_8e3f0bf5f402e343,unknown)).
node(n1306,supported) :- node(n1292,supported), node(n1293,supported), node(n1294,supported), node(n1304,supported).
node(n1306,refuted) :- node(n1292,refuted).
node(n1306,refuted) :- node(n1293,refuted).
node(n1306,refuted) :- node(n1294,refuted).
node(n1306,refuted) :- node(n1304,refuted).
node(n1306,unknown) :- \+ node(n1306,supported), \+ node(n1306,refuted).
node(n1305,refuted) :- node(n1306,refuted), node(n9,refuted).
node(n1305,supported) :- node(n1306,supported).
node(n1305,supported) :- node(n9,supported).
node(n1305,unknown) :- \+ node(n1305,supported), \+ node(n1305,refuted).
verdict(c_d6e55387ce3a17bb,supported) :- node(n1305,supported).
query(verdict(c_d6e55387ce3a17bb,supported)).
verdict(c_d6e55387ce3a17bb,refuted) :- node(n1305,refuted).
query(verdict(c_d6e55387ce3a17bb,refuted)).
verdict(c_d6e55387ce3a17bb,unknown) :- node(n1305,unknown).
query(verdict(c_d6e55387ce3a17bb,unknown)).
node(n1309,supported) :- status(o_692839554c5ff643c4a5,supported).
node(n1309,refuted) :- status(o_692839554c5ff643c4a5,refuted).
node(n1309,unknown) :- status(o_692839554c5ff643c4a5,unknown).
node(n1310,supported) :- status(o_eb11b9557d9095a4ed41,supported).
node(n1310,refuted) :- status(o_eb11b9557d9095a4ed41,refuted).
node(n1310,unknown) :- status(o_eb11b9557d9095a4ed41,unknown).
node(n1311,supported) :- status(o_f77bf96b27918572d5e2,supported).
node(n1311,refuted) :- status(o_f77bf96b27918572d5e2,refuted).
node(n1311,unknown) :- status(o_f77bf96b27918572d5e2,unknown).
node(n1308,supported) :- node(n1309,supported), node(n1310,supported), node(n1311,supported).
node(n1308,refuted) :- node(n1309,refuted).
node(n1308,refuted) :- node(n1310,refuted).
node(n1308,refuted) :- node(n1311,refuted).
node(n1308,unknown) :- \+ node(n1308,supported), \+ node(n1308,refuted).
node(n1307,refuted) :- node(n1308,refuted), node(n9,refuted).
node(n1307,supported) :- node(n1308,supported).
node(n1307,supported) :- node(n9,supported).
node(n1307,unknown) :- \+ node(n1307,supported), \+ node(n1307,refuted).
verdict(c_14926925413b39a6,supported) :- node(n1307,supported).
query(verdict(c_14926925413b39a6,supported)).
verdict(c_14926925413b39a6,refuted) :- node(n1307,refuted).
query(verdict(c_14926925413b39a6,refuted)).
verdict(c_14926925413b39a6,unknown) :- node(n1307,unknown).
query(verdict(c_14926925413b39a6,unknown)).
node(n1314,supported) :- status(o_3294134d8b4a702b7b5a,supported).
node(n1314,refuted) :- status(o_3294134d8b4a702b7b5a,refuted).
node(n1314,unknown) :- status(o_3294134d8b4a702b7b5a,unknown).
node(n1313,supported) :- node(n1309,supported), node(n1310,supported), node(n1311,supported), node(n1314,supported).
node(n1313,refuted) :- node(n1309,refuted).
node(n1313,refuted) :- node(n1310,refuted).
node(n1313,refuted) :- node(n1311,refuted).
node(n1313,refuted) :- node(n1314,refuted).
node(n1313,unknown) :- \+ node(n1313,supported), \+ node(n1313,refuted).
node(n1312,refuted) :- node(n1313,refuted), node(n9,refuted).
node(n1312,supported) :- node(n1313,supported).
node(n1312,supported) :- node(n9,supported).
node(n1312,unknown) :- \+ node(n1312,supported), \+ node(n1312,refuted).
verdict(c_e7e8b4253f661f37,supported) :- node(n1312,supported).
query(verdict(c_e7e8b4253f661f37,supported)).
verdict(c_e7e8b4253f661f37,refuted) :- node(n1312,refuted).
query(verdict(c_e7e8b4253f661f37,refuted)).
verdict(c_e7e8b4253f661f37,unknown) :- node(n1312,unknown).
query(verdict(c_e7e8b4253f661f37,unknown)).
node(n1317,supported) :- status(o_6b95737c99cd93cc052a,supported).
node(n1317,refuted) :- status(o_6b95737c99cd93cc052a,refuted).
node(n1317,unknown) :- status(o_6b95737c99cd93cc052a,unknown).
node(n1318,supported) :- status(o_f75f4e08473910d490e3,supported).
node(n1318,refuted) :- status(o_f75f4e08473910d490e3,refuted).
node(n1318,unknown) :- status(o_f75f4e08473910d490e3,unknown).
node(n1316,supported) :- node(n1309,supported), node(n1310,supported), node(n1311,supported), node(n1314,supported), node(n1317,supported), node(n1318,supported).
node(n1316,refuted) :- node(n1309,refuted).
node(n1316,refuted) :- node(n1310,refuted).
node(n1316,refuted) :- node(n1311,refuted).
node(n1316,refuted) :- node(n1314,refuted).
node(n1316,refuted) :- node(n1317,refuted).
node(n1316,refuted) :- node(n1318,refuted).
node(n1316,unknown) :- \+ node(n1316,supported), \+ node(n1316,refuted).
node(n1315,refuted) :- node(n1316,refuted), node(n9,refuted).
node(n1315,supported) :- node(n1316,supported).
node(n1315,supported) :- node(n9,supported).
node(n1315,unknown) :- \+ node(n1315,supported), \+ node(n1315,refuted).
verdict(c_33f96540056fdb60,supported) :- node(n1315,supported).
query(verdict(c_33f96540056fdb60,supported)).
verdict(c_33f96540056fdb60,refuted) :- node(n1315,refuted).
query(verdict(c_33f96540056fdb60,refuted)).
verdict(c_33f96540056fdb60,unknown) :- node(n1315,unknown).
query(verdict(c_33f96540056fdb60,unknown)).
node(n1321,supported) :- status(o_0f2752609df209e9ed98,supported).
node(n1321,refuted) :- status(o_0f2752609df209e9ed98,refuted).
node(n1321,unknown) :- status(o_0f2752609df209e9ed98,unknown).
node(n1320,supported) :- node(n1309,supported), node(n1310,supported), node(n1321,supported).
node(n1320,refuted) :- node(n1309,refuted).
node(n1320,refuted) :- node(n1310,refuted).
node(n1320,refuted) :- node(n1321,refuted).
node(n1320,unknown) :- \+ node(n1320,supported), \+ node(n1320,refuted).
node(n1319,refuted) :- node(n1320,refuted), node(n9,refuted).
node(n1319,supported) :- node(n1320,supported).
node(n1319,supported) :- node(n9,supported).
node(n1319,unknown) :- \+ node(n1319,supported), \+ node(n1319,refuted).
verdict(c_14f9ad04254db425,supported) :- node(n1319,supported).
query(verdict(c_14f9ad04254db425,supported)).
verdict(c_14f9ad04254db425,refuted) :- node(n1319,refuted).
query(verdict(c_14f9ad04254db425,refuted)).
verdict(c_14f9ad04254db425,unknown) :- node(n1319,unknown).
query(verdict(c_14f9ad04254db425,unknown)).
node(n1323,supported) :- node(n1309,supported), node(n1310,supported), node(n1311,supported), node(n1321,supported).
node(n1323,refuted) :- node(n1309,refuted).
node(n1323,refuted) :- node(n1310,refuted).
node(n1323,refuted) :- node(n1311,refuted).
node(n1323,refuted) :- node(n1321,refuted).
node(n1323,unknown) :- \+ node(n1323,supported), \+ node(n1323,refuted).
node(n1322,refuted) :- node(n1323,refuted), node(n9,refuted).
node(n1322,supported) :- node(n1323,supported).
node(n1322,supported) :- node(n9,supported).
node(n1322,unknown) :- \+ node(n1322,supported), \+ node(n1322,refuted).
verdict(c_88456b404d5805ef,supported) :- node(n1322,supported).
query(verdict(c_88456b404d5805ef,supported)).
verdict(c_88456b404d5805ef,refuted) :- node(n1322,refuted).
query(verdict(c_88456b404d5805ef,refuted)).
verdict(c_88456b404d5805ef,unknown) :- node(n1322,unknown).
query(verdict(c_88456b404d5805ef,unknown)).
node(n1326,supported) :- status(o_653a984030b14ee8d6d8,supported).
node(n1326,refuted) :- status(o_653a984030b14ee8d6d8,refuted).
node(n1326,unknown) :- status(o_653a984030b14ee8d6d8,unknown).
node(n1327,supported) :- status(o_d0bcaf3ca68997dc6a69,supported).
node(n1327,refuted) :- status(o_d0bcaf3ca68997dc6a69,refuted).
node(n1327,unknown) :- status(o_d0bcaf3ca68997dc6a69,unknown).
node(n1328,supported) :- status(o_e35232dd1f3018bc1bdd,supported).
node(n1328,refuted) :- status(o_e35232dd1f3018bc1bdd,refuted).
node(n1328,unknown) :- status(o_e35232dd1f3018bc1bdd,unknown).
node(n1325,supported) :- node(n1326,supported), node(n1327,supported), node(n1328,supported).
node(n1325,refuted) :- node(n1326,refuted).
node(n1325,refuted) :- node(n1327,refuted).
node(n1325,refuted) :- node(n1328,refuted).
node(n1325,unknown) :- \+ node(n1325,supported), \+ node(n1325,refuted).
node(n1324,refuted) :- node(n1325,refuted), node(n9,refuted).
node(n1324,supported) :- node(n1325,supported).
node(n1324,supported) :- node(n9,supported).
node(n1324,unknown) :- \+ node(n1324,supported), \+ node(n1324,refuted).
verdict(c_82a349a56b02f20c,supported) :- node(n1324,supported).
query(verdict(c_82a349a56b02f20c,supported)).
verdict(c_82a349a56b02f20c,refuted) :- node(n1324,refuted).
query(verdict(c_82a349a56b02f20c,refuted)).
verdict(c_82a349a56b02f20c,unknown) :- node(n1324,unknown).
query(verdict(c_82a349a56b02f20c,unknown)).
node(n1331,supported) :- status(o_bd35ae02a2a74912f63e,supported).
node(n1331,refuted) :- status(o_bd35ae02a2a74912f63e,refuted).
node(n1331,unknown) :- status(o_bd35ae02a2a74912f63e,unknown).
node(n1330,supported) :- node(n1326,supported), node(n1327,supported), node(n1328,supported), node(n1331,supported).
node(n1330,refuted) :- node(n1326,refuted).
node(n1330,refuted) :- node(n1327,refuted).
node(n1330,refuted) :- node(n1328,refuted).
node(n1330,refuted) :- node(n1331,refuted).
node(n1330,unknown) :- \+ node(n1330,supported), \+ node(n1330,refuted).
node(n1329,refuted) :- node(n1330,refuted), node(n9,refuted).
node(n1329,supported) :- node(n1330,supported).
node(n1329,supported) :- node(n9,supported).
node(n1329,unknown) :- \+ node(n1329,supported), \+ node(n1329,refuted).
verdict(c_4bd716f63dc1a75a,supported) :- node(n1329,supported).
query(verdict(c_4bd716f63dc1a75a,supported)).
verdict(c_4bd716f63dc1a75a,refuted) :- node(n1329,refuted).
query(verdict(c_4bd716f63dc1a75a,refuted)).
verdict(c_4bd716f63dc1a75a,unknown) :- node(n1329,unknown).
query(verdict(c_4bd716f63dc1a75a,unknown)).
node(n1334,supported) :- status(o_998d029375c86e619456,supported).
node(n1334,refuted) :- status(o_998d029375c86e619456,refuted).
node(n1334,unknown) :- status(o_998d029375c86e619456,unknown).
node(n1335,supported) :- status(o_83669c1ccc8c09e383d0,supported).
node(n1335,refuted) :- status(o_83669c1ccc8c09e383d0,refuted).
node(n1335,unknown) :- status(o_83669c1ccc8c09e383d0,unknown).
node(n1333,supported) :- node(n1326,supported), node(n1327,supported), node(n1328,supported), node(n1331,supported), node(n1334,supported), node(n1335,supported).
node(n1333,refuted) :- node(n1326,refuted).
node(n1333,refuted) :- node(n1327,refuted).
node(n1333,refuted) :- node(n1328,refuted).
node(n1333,refuted) :- node(n1331,refuted).
node(n1333,refuted) :- node(n1334,refuted).
node(n1333,refuted) :- node(n1335,refuted).
node(n1333,unknown) :- \+ node(n1333,supported), \+ node(n1333,refuted).
node(n1332,refuted) :- node(n1333,refuted), node(n9,refuted).
node(n1332,supported) :- node(n1333,supported).
node(n1332,supported) :- node(n9,supported).
node(n1332,unknown) :- \+ node(n1332,supported), \+ node(n1332,refuted).
verdict(c_e57ecf628674b232,supported) :- node(n1332,supported).
query(verdict(c_e57ecf628674b232,supported)).
verdict(c_e57ecf628674b232,refuted) :- node(n1332,refuted).
query(verdict(c_e57ecf628674b232,refuted)).
verdict(c_e57ecf628674b232,unknown) :- node(n1332,unknown).
query(verdict(c_e57ecf628674b232,unknown)).
node(n1338,supported) :- status(o_4a4bf1d0fdd1fced519e,supported).
node(n1338,refuted) :- status(o_4a4bf1d0fdd1fced519e,refuted).
node(n1338,unknown) :- status(o_4a4bf1d0fdd1fced519e,unknown).
node(n1337,supported) :- node(n1326,supported), node(n1327,supported), node(n1338,supported).
node(n1337,refuted) :- node(n1326,refuted).
node(n1337,refuted) :- node(n1327,refuted).
node(n1337,refuted) :- node(n1338,refuted).
node(n1337,unknown) :- \+ node(n1337,supported), \+ node(n1337,refuted).
node(n1336,refuted) :- node(n1337,refuted), node(n9,refuted).
node(n1336,supported) :- node(n1337,supported).
node(n1336,supported) :- node(n9,supported).
node(n1336,unknown) :- \+ node(n1336,supported), \+ node(n1336,refuted).
verdict(c_8b8bc615f08721a2,supported) :- node(n1336,supported).
query(verdict(c_8b8bc615f08721a2,supported)).
verdict(c_8b8bc615f08721a2,refuted) :- node(n1336,refuted).
query(verdict(c_8b8bc615f08721a2,refuted)).
verdict(c_8b8bc615f08721a2,unknown) :- node(n1336,unknown).
query(verdict(c_8b8bc615f08721a2,unknown)).
node(n1340,supported) :- node(n1326,supported), node(n1327,supported), node(n1328,supported), node(n1338,supported).
node(n1340,refuted) :- node(n1326,refuted).
node(n1340,refuted) :- node(n1327,refuted).
node(n1340,refuted) :- node(n1328,refuted).
node(n1340,refuted) :- node(n1338,refuted).
node(n1340,unknown) :- \+ node(n1340,supported), \+ node(n1340,refuted).
node(n1339,refuted) :- node(n1340,refuted), node(n9,refuted).
node(n1339,supported) :- node(n1340,supported).
node(n1339,supported) :- node(n9,supported).
node(n1339,unknown) :- \+ node(n1339,supported), \+ node(n1339,refuted).
verdict(c_47820716f69171a1,supported) :- node(n1339,supported).
query(verdict(c_47820716f69171a1,supported)).
verdict(c_47820716f69171a1,refuted) :- node(n1339,refuted).
query(verdict(c_47820716f69171a1,refuted)).
verdict(c_47820716f69171a1,unknown) :- node(n1339,unknown).
query(verdict(c_47820716f69171a1,unknown)).
node(n1343,supported) :- status(o_b10ea0a60a6e283cbdf2,supported).
node(n1343,refuted) :- status(o_b10ea0a60a6e283cbdf2,refuted).
node(n1343,unknown) :- status(o_b10ea0a60a6e283cbdf2,unknown).
node(n1344,supported) :- status(o_0ff2500d0981a46c8165,supported).
node(n1344,refuted) :- status(o_0ff2500d0981a46c8165,refuted).
node(n1344,unknown) :- status(o_0ff2500d0981a46c8165,unknown).
node(n1345,supported) :- status(o_229b42c6aa4e1e630c37,supported).
node(n1345,refuted) :- status(o_229b42c6aa4e1e630c37,refuted).
node(n1345,unknown) :- status(o_229b42c6aa4e1e630c37,unknown).
node(n1342,supported) :- node(n1343,supported), node(n1344,supported), node(n1345,supported).
node(n1342,refuted) :- node(n1343,refuted).
node(n1342,refuted) :- node(n1344,refuted).
node(n1342,refuted) :- node(n1345,refuted).
node(n1342,unknown) :- \+ node(n1342,supported), \+ node(n1342,refuted).
node(n1341,refuted) :- node(n1342,refuted), node(n9,refuted).
node(n1341,supported) :- node(n1342,supported).
node(n1341,supported) :- node(n9,supported).
node(n1341,unknown) :- \+ node(n1341,supported), \+ node(n1341,refuted).
verdict(c_0e8c5601c3a26c5d,supported) :- node(n1341,supported).
query(verdict(c_0e8c5601c3a26c5d,supported)).
verdict(c_0e8c5601c3a26c5d,refuted) :- node(n1341,refuted).
query(verdict(c_0e8c5601c3a26c5d,refuted)).
verdict(c_0e8c5601c3a26c5d,unknown) :- node(n1341,unknown).
query(verdict(c_0e8c5601c3a26c5d,unknown)).
node(n1348,supported) :- status(o_544c70d32c85792699e0,supported).
node(n1348,refuted) :- status(o_544c70d32c85792699e0,refuted).
node(n1348,unknown) :- status(o_544c70d32c85792699e0,unknown).
node(n1347,supported) :- node(n1343,supported), node(n1344,supported), node(n1345,supported), node(n1348,supported).
node(n1347,refuted) :- node(n1343,refuted).
node(n1347,refuted) :- node(n1344,refuted).
node(n1347,refuted) :- node(n1345,refuted).
node(n1347,refuted) :- node(n1348,refuted).
node(n1347,unknown) :- \+ node(n1347,supported), \+ node(n1347,refuted).
node(n1346,refuted) :- node(n1347,refuted), node(n9,refuted).
node(n1346,supported) :- node(n1347,supported).
node(n1346,supported) :- node(n9,supported).
node(n1346,unknown) :- \+ node(n1346,supported), \+ node(n1346,refuted).
verdict(c_47cc2eff8ea4fcf0,supported) :- node(n1346,supported).
query(verdict(c_47cc2eff8ea4fcf0,supported)).
verdict(c_47cc2eff8ea4fcf0,refuted) :- node(n1346,refuted).
query(verdict(c_47cc2eff8ea4fcf0,refuted)).
verdict(c_47cc2eff8ea4fcf0,unknown) :- node(n1346,unknown).
query(verdict(c_47cc2eff8ea4fcf0,unknown)).
node(n1351,supported) :- status(o_252abecde0701ebf95ef,supported).
node(n1351,refuted) :- status(o_252abecde0701ebf95ef,refuted).
node(n1351,unknown) :- status(o_252abecde0701ebf95ef,unknown).
node(n1352,supported) :- status(o_c207e6316e1d5058ae54,supported).
node(n1352,refuted) :- status(o_c207e6316e1d5058ae54,refuted).
node(n1352,unknown) :- status(o_c207e6316e1d5058ae54,unknown).
node(n1350,supported) :- node(n1343,supported), node(n1344,supported), node(n1345,supported), node(n1348,supported), node(n1351,supported), node(n1352,supported).
node(n1350,refuted) :- node(n1343,refuted).
node(n1350,refuted) :- node(n1344,refuted).
node(n1350,refuted) :- node(n1345,refuted).
node(n1350,refuted) :- node(n1348,refuted).
node(n1350,refuted) :- node(n1351,refuted).
node(n1350,refuted) :- node(n1352,refuted).
node(n1350,unknown) :- \+ node(n1350,supported), \+ node(n1350,refuted).
node(n1349,refuted) :- node(n1350,refuted), node(n9,refuted).
node(n1349,supported) :- node(n1350,supported).
node(n1349,supported) :- node(n9,supported).
node(n1349,unknown) :- \+ node(n1349,supported), \+ node(n1349,refuted).
verdict(c_f8aab6ea4e346bb0,supported) :- node(n1349,supported).
query(verdict(c_f8aab6ea4e346bb0,supported)).
verdict(c_f8aab6ea4e346bb0,refuted) :- node(n1349,refuted).
query(verdict(c_f8aab6ea4e346bb0,refuted)).
verdict(c_f8aab6ea4e346bb0,unknown) :- node(n1349,unknown).
query(verdict(c_f8aab6ea4e346bb0,unknown)).
node(n1355,supported) :- status(o_71031c289901e9a1e964,supported).
node(n1355,refuted) :- status(o_71031c289901e9a1e964,refuted).
node(n1355,unknown) :- status(o_71031c289901e9a1e964,unknown).
node(n1354,supported) :- node(n1343,supported), node(n1344,supported), node(n1355,supported).
node(n1354,refuted) :- node(n1343,refuted).
node(n1354,refuted) :- node(n1344,refuted).
node(n1354,refuted) :- node(n1355,refuted).
node(n1354,unknown) :- \+ node(n1354,supported), \+ node(n1354,refuted).
node(n1353,refuted) :- node(n1354,refuted), node(n9,refuted).
node(n1353,supported) :- node(n1354,supported).
node(n1353,supported) :- node(n9,supported).
node(n1353,unknown) :- \+ node(n1353,supported), \+ node(n1353,refuted).
verdict(c_52ac60e4a4c143e7,supported) :- node(n1353,supported).
query(verdict(c_52ac60e4a4c143e7,supported)).
verdict(c_52ac60e4a4c143e7,refuted) :- node(n1353,refuted).
query(verdict(c_52ac60e4a4c143e7,refuted)).
verdict(c_52ac60e4a4c143e7,unknown) :- node(n1353,unknown).
query(verdict(c_52ac60e4a4c143e7,unknown)).
node(n1357,supported) :- node(n1343,supported), node(n1344,supported), node(n1345,supported), node(n1355,supported).
node(n1357,refuted) :- node(n1343,refuted).
node(n1357,refuted) :- node(n1344,refuted).
node(n1357,refuted) :- node(n1345,refuted).
node(n1357,refuted) :- node(n1355,refuted).
node(n1357,unknown) :- \+ node(n1357,supported), \+ node(n1357,refuted).
node(n1356,refuted) :- node(n1357,refuted), node(n9,refuted).
node(n1356,supported) :- node(n1357,supported).
node(n1356,supported) :- node(n9,supported).
node(n1356,unknown) :- \+ node(n1356,supported), \+ node(n1356,refuted).
verdict(c_e35de3bd54190050,supported) :- node(n1356,supported).
query(verdict(c_e35de3bd54190050,supported)).
verdict(c_e35de3bd54190050,refuted) :- node(n1356,refuted).
query(verdict(c_e35de3bd54190050,refuted)).
verdict(c_e35de3bd54190050,unknown) :- node(n1356,unknown).
query(verdict(c_e35de3bd54190050,unknown)).
node(n1360,supported) :- status(o_232585831e4ef20e3cb3,supported).
node(n1360,refuted) :- status(o_232585831e4ef20e3cb3,refuted).
node(n1360,unknown) :- status(o_232585831e4ef20e3cb3,unknown).
node(n1361,supported) :- status(o_ad487b050f2c1c0c9f13,supported).
node(n1361,refuted) :- status(o_ad487b050f2c1c0c9f13,refuted).
node(n1361,unknown) :- status(o_ad487b050f2c1c0c9f13,unknown).
node(n1362,supported) :- status(o_dc613e2e64d0208da85f,supported).
node(n1362,refuted) :- status(o_dc613e2e64d0208da85f,refuted).
node(n1362,unknown) :- status(o_dc613e2e64d0208da85f,unknown).
node(n1359,supported) :- node(n1360,supported), node(n1361,supported), node(n1362,supported).
node(n1359,refuted) :- node(n1360,refuted).
node(n1359,refuted) :- node(n1361,refuted).
node(n1359,refuted) :- node(n1362,refuted).
node(n1359,unknown) :- \+ node(n1359,supported), \+ node(n1359,refuted).
node(n1364,supported) :- status(o_715e01b223eff8ad564f,supported).
node(n1364,refuted) :- status(o_715e01b223eff8ad564f,refuted).
node(n1364,unknown) :- status(o_715e01b223eff8ad564f,unknown).
node(n1365,supported) :- status(o_521e3a96e4acde4bdb2c,supported).
node(n1365,refuted) :- status(o_521e3a96e4acde4bdb2c,refuted).
node(n1365,unknown) :- status(o_521e3a96e4acde4bdb2c,unknown).
node(n1366,supported) :- status(o_f3510cdad365aaf78e3b,supported).
node(n1366,refuted) :- status(o_f3510cdad365aaf78e3b,refuted).
node(n1366,unknown) :- status(o_f3510cdad365aaf78e3b,unknown).
node(n1363,supported) :- node(n1364,supported), node(n1365,supported), node(n1366,supported).
node(n1363,refuted) :- node(n1364,refuted).
node(n1363,refuted) :- node(n1365,refuted).
node(n1363,refuted) :- node(n1366,refuted).
node(n1363,unknown) :- \+ node(n1363,supported), \+ node(n1363,refuted).
node(n1358,refuted) :- node(n1359,refuted), node(n1363,refuted), node(n9,refuted).
node(n1358,supported) :- node(n1359,supported).
node(n1358,supported) :- node(n1363,supported).
node(n1358,supported) :- node(n9,supported).
node(n1358,unknown) :- \+ node(n1358,supported), \+ node(n1358,refuted).
verdict(c_2bdd551f188fdda7,supported) :- node(n1358,supported).
query(verdict(c_2bdd551f188fdda7,supported)).
verdict(c_2bdd551f188fdda7,refuted) :- node(n1358,refuted).
query(verdict(c_2bdd551f188fdda7,refuted)).
verdict(c_2bdd551f188fdda7,unknown) :- node(n1358,unknown).
query(verdict(c_2bdd551f188fdda7,unknown)).
node(n1369,supported) :- status(o_c3c19b1dab83f7f749c9,supported).
node(n1369,refuted) :- status(o_c3c19b1dab83f7f749c9,refuted).
node(n1369,unknown) :- status(o_c3c19b1dab83f7f749c9,unknown).
node(n1368,supported) :- node(n1360,supported), node(n1361,supported), node(n1362,supported), node(n1369,supported).
node(n1368,refuted) :- node(n1360,refuted).
node(n1368,refuted) :- node(n1361,refuted).
node(n1368,refuted) :- node(n1362,refuted).
node(n1368,refuted) :- node(n1369,refuted).
node(n1368,unknown) :- \+ node(n1368,supported), \+ node(n1368,refuted).
node(n1371,supported) :- status(o_09c999552d49ecddc015,supported).
node(n1371,refuted) :- status(o_09c999552d49ecddc015,refuted).
node(n1371,unknown) :- status(o_09c999552d49ecddc015,unknown).
node(n1370,supported) :- node(n1364,supported), node(n1365,supported), node(n1366,supported), node(n1371,supported).
node(n1370,refuted) :- node(n1364,refuted).
node(n1370,refuted) :- node(n1365,refuted).
node(n1370,refuted) :- node(n1366,refuted).
node(n1370,refuted) :- node(n1371,refuted).
node(n1370,unknown) :- \+ node(n1370,supported), \+ node(n1370,refuted).
node(n1367,refuted) :- node(n1368,refuted), node(n1370,refuted), node(n9,refuted).
node(n1367,supported) :- node(n1368,supported).
node(n1367,supported) :- node(n1370,supported).
node(n1367,supported) :- node(n9,supported).
node(n1367,unknown) :- \+ node(n1367,supported), \+ node(n1367,refuted).
verdict(c_939a405dd08a0a3c,supported) :- node(n1367,supported).
query(verdict(c_939a405dd08a0a3c,supported)).
verdict(c_939a405dd08a0a3c,refuted) :- node(n1367,refuted).
query(verdict(c_939a405dd08a0a3c,refuted)).
verdict(c_939a405dd08a0a3c,unknown) :- node(n1367,unknown).
query(verdict(c_939a405dd08a0a3c,unknown)).
node(n1374,supported) :- status(o_c6cd8b6852631d140c52,supported).
node(n1374,refuted) :- status(o_c6cd8b6852631d140c52,refuted).
node(n1374,unknown) :- status(o_c6cd8b6852631d140c52,unknown).
node(n1375,supported) :- status(o_1bb76ab420cf43c6332f,supported).
node(n1375,refuted) :- status(o_1bb76ab420cf43c6332f,refuted).
node(n1375,unknown) :- status(o_1bb76ab420cf43c6332f,unknown).
node(n1373,supported) :- node(n1360,supported), node(n1361,supported), node(n1362,supported), node(n1369,supported), node(n1374,supported), node(n1375,supported).
node(n1373,refuted) :- node(n1360,refuted).
node(n1373,refuted) :- node(n1361,refuted).
node(n1373,refuted) :- node(n1362,refuted).
node(n1373,refuted) :- node(n1369,refuted).
node(n1373,refuted) :- node(n1374,refuted).
node(n1373,refuted) :- node(n1375,refuted).
node(n1373,unknown) :- \+ node(n1373,supported), \+ node(n1373,refuted).
node(n1377,supported) :- status(o_6a764828540de177cc2f,supported).
node(n1377,refuted) :- status(o_6a764828540de177cc2f,refuted).
node(n1377,unknown) :- status(o_6a764828540de177cc2f,unknown).
node(n1378,supported) :- status(o_05d987d65f59de8f73ec,supported).
node(n1378,refuted) :- status(o_05d987d65f59de8f73ec,refuted).
node(n1378,unknown) :- status(o_05d987d65f59de8f73ec,unknown).
node(n1376,supported) :- node(n1364,supported), node(n1365,supported), node(n1366,supported), node(n1371,supported), node(n1377,supported), node(n1378,supported).
node(n1376,refuted) :- node(n1364,refuted).
node(n1376,refuted) :- node(n1365,refuted).
node(n1376,refuted) :- node(n1366,refuted).
node(n1376,refuted) :- node(n1371,refuted).
node(n1376,refuted) :- node(n1377,refuted).
node(n1376,refuted) :- node(n1378,refuted).
node(n1376,unknown) :- \+ node(n1376,supported), \+ node(n1376,refuted).
node(n1372,refuted) :- node(n1373,refuted), node(n1376,refuted), node(n9,refuted).
node(n1372,supported) :- node(n1373,supported).
node(n1372,supported) :- node(n1376,supported).
node(n1372,supported) :- node(n9,supported).
node(n1372,unknown) :- \+ node(n1372,supported), \+ node(n1372,refuted).
verdict(c_c92b83c6678f2074,supported) :- node(n1372,supported).
query(verdict(c_c92b83c6678f2074,supported)).
verdict(c_c92b83c6678f2074,refuted) :- node(n1372,refuted).
query(verdict(c_c92b83c6678f2074,refuted)).
verdict(c_c92b83c6678f2074,unknown) :- node(n1372,unknown).
query(verdict(c_c92b83c6678f2074,unknown)).
node(n1381,supported) :- status(o_cb3cb7887c70bc274e1a,supported).
node(n1381,refuted) :- status(o_cb3cb7887c70bc274e1a,refuted).
node(n1381,unknown) :- status(o_cb3cb7887c70bc274e1a,unknown).
node(n1380,supported) :- node(n1360,supported), node(n1361,supported), node(n1381,supported).
node(n1380,refuted) :- node(n1360,refuted).
node(n1380,refuted) :- node(n1361,refuted).
node(n1380,refuted) :- node(n1381,refuted).
node(n1380,unknown) :- \+ node(n1380,supported), \+ node(n1380,refuted).
node(n1383,supported) :- status(o_60bb291ee458e021327d,supported).
node(n1383,refuted) :- status(o_60bb291ee458e021327d,refuted).
node(n1383,unknown) :- status(o_60bb291ee458e021327d,unknown).
node(n1382,supported) :- node(n1364,supported), node(n1365,supported), node(n1383,supported).
node(n1382,refuted) :- node(n1364,refuted).
node(n1382,refuted) :- node(n1365,refuted).
node(n1382,refuted) :- node(n1383,refuted).
node(n1382,unknown) :- \+ node(n1382,supported), \+ node(n1382,refuted).
node(n1379,refuted) :- node(n1380,refuted), node(n1382,refuted), node(n9,refuted).
node(n1379,supported) :- node(n1380,supported).
node(n1379,supported) :- node(n1382,supported).
node(n1379,supported) :- node(n9,supported).
node(n1379,unknown) :- \+ node(n1379,supported), \+ node(n1379,refuted).
verdict(c_a10e7e20354addc5,supported) :- node(n1379,supported).
query(verdict(c_a10e7e20354addc5,supported)).
verdict(c_a10e7e20354addc5,refuted) :- node(n1379,refuted).
query(verdict(c_a10e7e20354addc5,refuted)).
verdict(c_a10e7e20354addc5,unknown) :- node(n1379,unknown).
query(verdict(c_a10e7e20354addc5,unknown)).
node(n1385,supported) :- node(n1360,supported), node(n1361,supported), node(n1362,supported), node(n1381,supported).
node(n1385,refuted) :- node(n1360,refuted).
node(n1385,refuted) :- node(n1361,refuted).
node(n1385,refuted) :- node(n1362,refuted).
node(n1385,refuted) :- node(n1381,refuted).
node(n1385,unknown) :- \+ node(n1385,supported), \+ node(n1385,refuted).
node(n1386,supported) :- node(n1364,supported), node(n1365,supported), node(n1366,supported), node(n1383,supported).
node(n1386,refuted) :- node(n1364,refuted).
node(n1386,refuted) :- node(n1365,refuted).
node(n1386,refuted) :- node(n1366,refuted).
node(n1386,refuted) :- node(n1383,refuted).
node(n1386,unknown) :- \+ node(n1386,supported), \+ node(n1386,refuted).
node(n1384,refuted) :- node(n1385,refuted), node(n1386,refuted), node(n9,refuted).
node(n1384,supported) :- node(n1385,supported).
node(n1384,supported) :- node(n1386,supported).
node(n1384,supported) :- node(n9,supported).
node(n1384,unknown) :- \+ node(n1384,supported), \+ node(n1384,refuted).
verdict(c_d09da64df6ec1fa3,supported) :- node(n1384,supported).
query(verdict(c_d09da64df6ec1fa3,supported)).
verdict(c_d09da64df6ec1fa3,refuted) :- node(n1384,refuted).
query(verdict(c_d09da64df6ec1fa3,refuted)).
verdict(c_d09da64df6ec1fa3,unknown) :- node(n1384,unknown).
query(verdict(c_d09da64df6ec1fa3,unknown)).
node(n1389,supported) :- status(o_faaa4f84b2ff8a28c02c,supported).
node(n1389,refuted) :- status(o_faaa4f84b2ff8a28c02c,refuted).
node(n1389,unknown) :- status(o_faaa4f84b2ff8a28c02c,unknown).
node(n1390,supported) :- status(o_7439e372b4d6e1edbca1,supported).
node(n1390,refuted) :- status(o_7439e372b4d6e1edbca1,refuted).
node(n1390,unknown) :- status(o_7439e372b4d6e1edbca1,unknown).
node(n1391,supported) :- status(o_7ecc285ca92e3a070846,supported).
node(n1391,refuted) :- status(o_7ecc285ca92e3a070846,refuted).
node(n1391,unknown) :- status(o_7ecc285ca92e3a070846,unknown).
node(n1388,supported) :- node(n1389,supported), node(n1390,supported), node(n1391,supported).
node(n1388,refuted) :- node(n1389,refuted).
node(n1388,refuted) :- node(n1390,refuted).
node(n1388,refuted) :- node(n1391,refuted).
node(n1388,unknown) :- \+ node(n1388,supported), \+ node(n1388,refuted).
node(n1393,supported) :- status(o_402b2f1d4ab0ce6df786,supported).
node(n1393,refuted) :- status(o_402b2f1d4ab0ce6df786,refuted).
node(n1393,unknown) :- status(o_402b2f1d4ab0ce6df786,unknown).
node(n1394,supported) :- status(o_69baeed33b58dda70f4a,supported).
node(n1394,refuted) :- status(o_69baeed33b58dda70f4a,refuted).
node(n1394,unknown) :- status(o_69baeed33b58dda70f4a,unknown).
node(n1395,supported) :- status(o_edc9471cb348ce6e8226,supported).
node(n1395,refuted) :- status(o_edc9471cb348ce6e8226,refuted).
node(n1395,unknown) :- status(o_edc9471cb348ce6e8226,unknown).
node(n1392,supported) :- node(n1393,supported), node(n1394,supported), node(n1395,supported).
node(n1392,refuted) :- node(n1393,refuted).
node(n1392,refuted) :- node(n1394,refuted).
node(n1392,refuted) :- node(n1395,refuted).
node(n1392,unknown) :- \+ node(n1392,supported), \+ node(n1392,refuted).
node(n1387,refuted) :- node(n1388,refuted), node(n1392,refuted), node(n9,refuted).
node(n1387,supported) :- node(n1388,supported).
node(n1387,supported) :- node(n1392,supported).
node(n1387,supported) :- node(n9,supported).
node(n1387,unknown) :- \+ node(n1387,supported), \+ node(n1387,refuted).
verdict(c_95b3f3a591cd8991,supported) :- node(n1387,supported).
query(verdict(c_95b3f3a591cd8991,supported)).
verdict(c_95b3f3a591cd8991,refuted) :- node(n1387,refuted).
query(verdict(c_95b3f3a591cd8991,refuted)).
verdict(c_95b3f3a591cd8991,unknown) :- node(n1387,unknown).
query(verdict(c_95b3f3a591cd8991,unknown)).
node(n1398,supported) :- status(o_145a39118572dee0fafd,supported).
node(n1398,refuted) :- status(o_145a39118572dee0fafd,refuted).
node(n1398,unknown) :- status(o_145a39118572dee0fafd,unknown).
node(n1397,supported) :- node(n1389,supported), node(n1390,supported), node(n1391,supported), node(n1398,supported).
node(n1397,refuted) :- node(n1389,refuted).
node(n1397,refuted) :- node(n1390,refuted).
node(n1397,refuted) :- node(n1391,refuted).
node(n1397,refuted) :- node(n1398,refuted).
node(n1397,unknown) :- \+ node(n1397,supported), \+ node(n1397,refuted).
node(n1400,supported) :- status(o_0a7e6689c49192573f2f,supported).
node(n1400,refuted) :- status(o_0a7e6689c49192573f2f,refuted).
node(n1400,unknown) :- status(o_0a7e6689c49192573f2f,unknown).
node(n1399,supported) :- node(n1393,supported), node(n1394,supported), node(n1395,supported), node(n1400,supported).
node(n1399,refuted) :- node(n1393,refuted).
node(n1399,refuted) :- node(n1394,refuted).
node(n1399,refuted) :- node(n1395,refuted).
node(n1399,refuted) :- node(n1400,refuted).
node(n1399,unknown) :- \+ node(n1399,supported), \+ node(n1399,refuted).
node(n1396,refuted) :- node(n1397,refuted), node(n1399,refuted), node(n9,refuted).
node(n1396,supported) :- node(n1397,supported).
node(n1396,supported) :- node(n1399,supported).
node(n1396,supported) :- node(n9,supported).
node(n1396,unknown) :- \+ node(n1396,supported), \+ node(n1396,refuted).
verdict(c_04ee0ab82a8e0b25,supported) :- node(n1396,supported).
query(verdict(c_04ee0ab82a8e0b25,supported)).
verdict(c_04ee0ab82a8e0b25,refuted) :- node(n1396,refuted).
query(verdict(c_04ee0ab82a8e0b25,refuted)).
verdict(c_04ee0ab82a8e0b25,unknown) :- node(n1396,unknown).
query(verdict(c_04ee0ab82a8e0b25,unknown)).
node(n1403,supported) :- status(o_8388fae312e5e6d4595f,supported).
node(n1403,refuted) :- status(o_8388fae312e5e6d4595f,refuted).
node(n1403,unknown) :- status(o_8388fae312e5e6d4595f,unknown).
node(n1404,supported) :- status(o_fc9408c7df03f42d6c4d,supported).
node(n1404,refuted) :- status(o_fc9408c7df03f42d6c4d,refuted).
node(n1404,unknown) :- status(o_fc9408c7df03f42d6c4d,unknown).
node(n1402,supported) :- node(n1389,supported), node(n1390,supported), node(n1391,supported), node(n1398,supported), node(n1403,supported), node(n1404,supported).
node(n1402,refuted) :- node(n1389,refuted).
node(n1402,refuted) :- node(n1390,refuted).
node(n1402,refuted) :- node(n1391,refuted).
node(n1402,refuted) :- node(n1398,refuted).
node(n1402,refuted) :- node(n1403,refuted).
node(n1402,refuted) :- node(n1404,refuted).
node(n1402,unknown) :- \+ node(n1402,supported), \+ node(n1402,refuted).
node(n1406,supported) :- status(o_e8da5d5e874317e6b5b5,supported).
node(n1406,refuted) :- status(o_e8da5d5e874317e6b5b5,refuted).
node(n1406,unknown) :- status(o_e8da5d5e874317e6b5b5,unknown).
node(n1407,supported) :- status(o_f67beb85e1f14f3b27e1,supported).
node(n1407,refuted) :- status(o_f67beb85e1f14f3b27e1,refuted).
node(n1407,unknown) :- status(o_f67beb85e1f14f3b27e1,unknown).
node(n1405,supported) :- node(n1393,supported), node(n1394,supported), node(n1395,supported), node(n1400,supported), node(n1406,supported), node(n1407,supported).
node(n1405,refuted) :- node(n1393,refuted).
node(n1405,refuted) :- node(n1394,refuted).
node(n1405,refuted) :- node(n1395,refuted).
node(n1405,refuted) :- node(n1400,refuted).
node(n1405,refuted) :- node(n1406,refuted).
node(n1405,refuted) :- node(n1407,refuted).
node(n1405,unknown) :- \+ node(n1405,supported), \+ node(n1405,refuted).
node(n1401,refuted) :- node(n1402,refuted), node(n1405,refuted), node(n9,refuted).
node(n1401,supported) :- node(n1402,supported).
node(n1401,supported) :- node(n1405,supported).
node(n1401,supported) :- node(n9,supported).
node(n1401,unknown) :- \+ node(n1401,supported), \+ node(n1401,refuted).
verdict(c_8d6dd8fd0b836f0b,supported) :- node(n1401,supported).
query(verdict(c_8d6dd8fd0b836f0b,supported)).
verdict(c_8d6dd8fd0b836f0b,refuted) :- node(n1401,refuted).
query(verdict(c_8d6dd8fd0b836f0b,refuted)).
verdict(c_8d6dd8fd0b836f0b,unknown) :- node(n1401,unknown).
query(verdict(c_8d6dd8fd0b836f0b,unknown)).
node(n1410,supported) :- status(o_8f6d1028a2e9793bd0aa,supported).
node(n1410,refuted) :- status(o_8f6d1028a2e9793bd0aa,refuted).
node(n1410,unknown) :- status(o_8f6d1028a2e9793bd0aa,unknown).
node(n1409,supported) :- node(n1389,supported), node(n1390,supported), node(n1410,supported).
node(n1409,refuted) :- node(n1389,refuted).
node(n1409,refuted) :- node(n1390,refuted).
node(n1409,refuted) :- node(n1410,refuted).
node(n1409,unknown) :- \+ node(n1409,supported), \+ node(n1409,refuted).
node(n1412,supported) :- status(o_760c8d45c8337dd0bd8a,supported).
node(n1412,refuted) :- status(o_760c8d45c8337dd0bd8a,refuted).
node(n1412,unknown) :- status(o_760c8d45c8337dd0bd8a,unknown).
node(n1411,supported) :- node(n1393,supported), node(n1394,supported), node(n1412,supported).
node(n1411,refuted) :- node(n1393,refuted).
node(n1411,refuted) :- node(n1394,refuted).
node(n1411,refuted) :- node(n1412,refuted).
node(n1411,unknown) :- \+ node(n1411,supported), \+ node(n1411,refuted).
node(n1408,refuted) :- node(n1409,refuted), node(n1411,refuted), node(n9,refuted).
node(n1408,supported) :- node(n1409,supported).
node(n1408,supported) :- node(n1411,supported).
node(n1408,supported) :- node(n9,supported).
node(n1408,unknown) :- \+ node(n1408,supported), \+ node(n1408,refuted).
verdict(c_2611265bd20a48c4,supported) :- node(n1408,supported).
query(verdict(c_2611265bd20a48c4,supported)).
verdict(c_2611265bd20a48c4,refuted) :- node(n1408,refuted).
query(verdict(c_2611265bd20a48c4,refuted)).
verdict(c_2611265bd20a48c4,unknown) :- node(n1408,unknown).
query(verdict(c_2611265bd20a48c4,unknown)).
node(n1414,supported) :- node(n1389,supported), node(n1390,supported), node(n1391,supported), node(n1410,supported).
node(n1414,refuted) :- node(n1389,refuted).
node(n1414,refuted) :- node(n1390,refuted).
node(n1414,refuted) :- node(n1391,refuted).
node(n1414,refuted) :- node(n1410,refuted).
node(n1414,unknown) :- \+ node(n1414,supported), \+ node(n1414,refuted).
node(n1415,supported) :- node(n1393,supported), node(n1394,supported), node(n1395,supported), node(n1412,supported).
node(n1415,refuted) :- node(n1393,refuted).
node(n1415,refuted) :- node(n1394,refuted).
node(n1415,refuted) :- node(n1395,refuted).
node(n1415,refuted) :- node(n1412,refuted).
node(n1415,unknown) :- \+ node(n1415,supported), \+ node(n1415,refuted).
node(n1413,refuted) :- node(n1414,refuted), node(n1415,refuted), node(n9,refuted).
node(n1413,supported) :- node(n1414,supported).
node(n1413,supported) :- node(n1415,supported).
node(n1413,supported) :- node(n9,supported).
node(n1413,unknown) :- \+ node(n1413,supported), \+ node(n1413,refuted).
verdict(c_01431d228bdbae40,supported) :- node(n1413,supported).
query(verdict(c_01431d228bdbae40,supported)).
verdict(c_01431d228bdbae40,refuted) :- node(n1413,refuted).
query(verdict(c_01431d228bdbae40,refuted)).
verdict(c_01431d228bdbae40,unknown) :- node(n1413,unknown).
query(verdict(c_01431d228bdbae40,unknown)).
node(n1418,supported) :- status(o_c5ea265751666dec42f7,supported).
node(n1418,refuted) :- status(o_c5ea265751666dec42f7,refuted).
node(n1418,unknown) :- status(o_c5ea265751666dec42f7,unknown).
node(n1419,supported) :- status(o_c50390ebea355f7aaa35,supported).
node(n1419,refuted) :- status(o_c50390ebea355f7aaa35,refuted).
node(n1419,unknown) :- status(o_c50390ebea355f7aaa35,unknown).
node(n1420,supported) :- status(o_144e6585ef2e3dd08b4b,supported).
node(n1420,refuted) :- status(o_144e6585ef2e3dd08b4b,refuted).
node(n1420,unknown) :- status(o_144e6585ef2e3dd08b4b,unknown).
node(n1417,supported) :- node(n1418,supported), node(n1419,supported), node(n1420,supported).
node(n1417,refuted) :- node(n1418,refuted).
node(n1417,refuted) :- node(n1419,refuted).
node(n1417,refuted) :- node(n1420,refuted).
node(n1417,unknown) :- \+ node(n1417,supported), \+ node(n1417,refuted).
node(n1422,supported) :- status(o_73f208e5952551e50207,supported).
node(n1422,refuted) :- status(o_73f208e5952551e50207,refuted).
node(n1422,unknown) :- status(o_73f208e5952551e50207,unknown).
node(n1423,supported) :- status(o_86363b95e6a5b82e00dc,supported).
node(n1423,refuted) :- status(o_86363b95e6a5b82e00dc,refuted).
node(n1423,unknown) :- status(o_86363b95e6a5b82e00dc,unknown).
node(n1424,supported) :- status(o_82bf01f9874cfcfea4af,supported).
node(n1424,refuted) :- status(o_82bf01f9874cfcfea4af,refuted).
node(n1424,unknown) :- status(o_82bf01f9874cfcfea4af,unknown).
node(n1421,supported) :- node(n1422,supported), node(n1423,supported), node(n1424,supported).
node(n1421,refuted) :- node(n1422,refuted).
node(n1421,refuted) :- node(n1423,refuted).
node(n1421,refuted) :- node(n1424,refuted).
node(n1421,unknown) :- \+ node(n1421,supported), \+ node(n1421,refuted).
node(n1416,refuted) :- node(n1417,refuted), node(n1421,refuted), node(n9,refuted).
node(n1416,supported) :- node(n1417,supported).
node(n1416,supported) :- node(n1421,supported).
node(n1416,supported) :- node(n9,supported).
node(n1416,unknown) :- \+ node(n1416,supported), \+ node(n1416,refuted).
verdict(c_f5ec774f28e29de0,supported) :- node(n1416,supported).
query(verdict(c_f5ec774f28e29de0,supported)).
verdict(c_f5ec774f28e29de0,refuted) :- node(n1416,refuted).
query(verdict(c_f5ec774f28e29de0,refuted)).
verdict(c_f5ec774f28e29de0,unknown) :- node(n1416,unknown).
query(verdict(c_f5ec774f28e29de0,unknown)).
node(n1427,supported) :- status(o_fffb2df3111000840e16,supported).
node(n1427,refuted) :- status(o_fffb2df3111000840e16,refuted).
node(n1427,unknown) :- status(o_fffb2df3111000840e16,unknown).
node(n1426,supported) :- node(n1418,supported), node(n1419,supported), node(n1420,supported), node(n1427,supported).
node(n1426,refuted) :- node(n1418,refuted).
node(n1426,refuted) :- node(n1419,refuted).
node(n1426,refuted) :- node(n1420,refuted).
node(n1426,refuted) :- node(n1427,refuted).
node(n1426,unknown) :- \+ node(n1426,supported), \+ node(n1426,refuted).
node(n1429,supported) :- status(o_7f92e25c4cefd850d924,supported).
node(n1429,refuted) :- status(o_7f92e25c4cefd850d924,refuted).
node(n1429,unknown) :- status(o_7f92e25c4cefd850d924,unknown).
node(n1428,supported) :- node(n1422,supported), node(n1423,supported), node(n1424,supported), node(n1429,supported).
node(n1428,refuted) :- node(n1422,refuted).
node(n1428,refuted) :- node(n1423,refuted).
node(n1428,refuted) :- node(n1424,refuted).
node(n1428,refuted) :- node(n1429,refuted).
node(n1428,unknown) :- \+ node(n1428,supported), \+ node(n1428,refuted).
node(n1425,refuted) :- node(n1426,refuted), node(n1428,refuted), node(n9,refuted).
node(n1425,supported) :- node(n1426,supported).
node(n1425,supported) :- node(n1428,supported).
node(n1425,supported) :- node(n9,supported).
node(n1425,unknown) :- \+ node(n1425,supported), \+ node(n1425,refuted).
verdict(c_6bf955676dce7198,supported) :- node(n1425,supported).
query(verdict(c_6bf955676dce7198,supported)).
verdict(c_6bf955676dce7198,refuted) :- node(n1425,refuted).
query(verdict(c_6bf955676dce7198,refuted)).
verdict(c_6bf955676dce7198,unknown) :- node(n1425,unknown).
query(verdict(c_6bf955676dce7198,unknown)).
node(n1432,supported) :- status(o_91df501355fb7dac64de,supported).
node(n1432,refuted) :- status(o_91df501355fb7dac64de,refuted).
node(n1432,unknown) :- status(o_91df501355fb7dac64de,unknown).
node(n1433,supported) :- status(o_cbb4b9575ece5dc92dc1,supported).
node(n1433,refuted) :- status(o_cbb4b9575ece5dc92dc1,refuted).
node(n1433,unknown) :- status(o_cbb4b9575ece5dc92dc1,unknown).
node(n1431,supported) :- node(n1418,supported), node(n1419,supported), node(n1420,supported), node(n1427,supported), node(n1432,supported), node(n1433,supported).
node(n1431,refuted) :- node(n1418,refuted).
node(n1431,refuted) :- node(n1419,refuted).
node(n1431,refuted) :- node(n1420,refuted).
node(n1431,refuted) :- node(n1427,refuted).
node(n1431,refuted) :- node(n1432,refuted).
node(n1431,refuted) :- node(n1433,refuted).
node(n1431,unknown) :- \+ node(n1431,supported), \+ node(n1431,refuted).
node(n1435,supported) :- status(o_2208b731f143e3799ba4,supported).
node(n1435,refuted) :- status(o_2208b731f143e3799ba4,refuted).
node(n1435,unknown) :- status(o_2208b731f143e3799ba4,unknown).
node(n1436,supported) :- status(o_a2ce3aae1b5ab8f80ad1,supported).
node(n1436,refuted) :- status(o_a2ce3aae1b5ab8f80ad1,refuted).
node(n1436,unknown) :- status(o_a2ce3aae1b5ab8f80ad1,unknown).
node(n1434,supported) :- node(n1422,supported), node(n1423,supported), node(n1424,supported), node(n1429,supported), node(n1435,supported), node(n1436,supported).
node(n1434,refuted) :- node(n1422,refuted).
node(n1434,refuted) :- node(n1423,refuted).
node(n1434,refuted) :- node(n1424,refuted).
node(n1434,refuted) :- node(n1429,refuted).
node(n1434,refuted) :- node(n1435,refuted).
node(n1434,refuted) :- node(n1436,refuted).
node(n1434,unknown) :- \+ node(n1434,supported), \+ node(n1434,refuted).
node(n1430,refuted) :- node(n1431,refuted), node(n1434,refuted), node(n9,refuted).
node(n1430,supported) :- node(n1431,supported).
node(n1430,supported) :- node(n1434,supported).
node(n1430,supported) :- node(n9,supported).
node(n1430,unknown) :- \+ node(n1430,supported), \+ node(n1430,refuted).
verdict(c_671247b1a4b7f758,supported) :- node(n1430,supported).
query(verdict(c_671247b1a4b7f758,supported)).
verdict(c_671247b1a4b7f758,refuted) :- node(n1430,refuted).
query(verdict(c_671247b1a4b7f758,refuted)).
verdict(c_671247b1a4b7f758,unknown) :- node(n1430,unknown).
query(verdict(c_671247b1a4b7f758,unknown)).
node(n1439,supported) :- status(o_cff608308240351f5b86,supported).
node(n1439,refuted) :- status(o_cff608308240351f5b86,refuted).
node(n1439,unknown) :- status(o_cff608308240351f5b86,unknown).
node(n1438,supported) :- node(n1418,supported), node(n1419,supported), node(n1439,supported).
node(n1438,refuted) :- node(n1418,refuted).
node(n1438,refuted) :- node(n1419,refuted).
node(n1438,refuted) :- node(n1439,refuted).
node(n1438,unknown) :- \+ node(n1438,supported), \+ node(n1438,refuted).
node(n1441,supported) :- status(o_0605cf80d5cb8c0eb0d9,supported).
node(n1441,refuted) :- status(o_0605cf80d5cb8c0eb0d9,refuted).
node(n1441,unknown) :- status(o_0605cf80d5cb8c0eb0d9,unknown).
node(n1440,supported) :- node(n1422,supported), node(n1423,supported), node(n1441,supported).
node(n1440,refuted) :- node(n1422,refuted).
node(n1440,refuted) :- node(n1423,refuted).
node(n1440,refuted) :- node(n1441,refuted).
node(n1440,unknown) :- \+ node(n1440,supported), \+ node(n1440,refuted).
node(n1437,refuted) :- node(n1438,refuted), node(n1440,refuted), node(n9,refuted).
node(n1437,supported) :- node(n1438,supported).
node(n1437,supported) :- node(n1440,supported).
node(n1437,supported) :- node(n9,supported).
node(n1437,unknown) :- \+ node(n1437,supported), \+ node(n1437,refuted).
verdict(c_015f1e769eef87c2,supported) :- node(n1437,supported).
query(verdict(c_015f1e769eef87c2,supported)).
verdict(c_015f1e769eef87c2,refuted) :- node(n1437,refuted).
query(verdict(c_015f1e769eef87c2,refuted)).
verdict(c_015f1e769eef87c2,unknown) :- node(n1437,unknown).
query(verdict(c_015f1e769eef87c2,unknown)).
node(n1443,supported) :- node(n1418,supported), node(n1419,supported), node(n1420,supported), node(n1439,supported).
node(n1443,refuted) :- node(n1418,refuted).
node(n1443,refuted) :- node(n1419,refuted).
node(n1443,refuted) :- node(n1420,refuted).
node(n1443,refuted) :- node(n1439,refuted).
node(n1443,unknown) :- \+ node(n1443,supported), \+ node(n1443,refuted).
node(n1444,supported) :- node(n1422,supported), node(n1423,supported), node(n1424,supported), node(n1441,supported).
node(n1444,refuted) :- node(n1422,refuted).
node(n1444,refuted) :- node(n1423,refuted).
node(n1444,refuted) :- node(n1424,refuted).
node(n1444,refuted) :- node(n1441,refuted).
node(n1444,unknown) :- \+ node(n1444,supported), \+ node(n1444,refuted).
node(n1442,refuted) :- node(n1443,refuted), node(n1444,refuted), node(n9,refuted).
node(n1442,supported) :- node(n1443,supported).
node(n1442,supported) :- node(n1444,supported).
node(n1442,supported) :- node(n9,supported).
node(n1442,unknown) :- \+ node(n1442,supported), \+ node(n1442,refuted).
verdict(c_11733444a5d3e096,supported) :- node(n1442,supported).
query(verdict(c_11733444a5d3e096,supported)).
verdict(c_11733444a5d3e096,refuted) :- node(n1442,refuted).
query(verdict(c_11733444a5d3e096,refuted)).
verdict(c_11733444a5d3e096,unknown) :- node(n1442,unknown).
query(verdict(c_11733444a5d3e096,unknown)).
node(n1447,supported) :- status(o_ab35433ed82c6a74bf24,supported).
node(n1447,refuted) :- status(o_ab35433ed82c6a74bf24,refuted).
node(n1447,unknown) :- status(o_ab35433ed82c6a74bf24,unknown).
node(n1448,supported) :- status(o_ee37a283c2604a0f7780,supported).
node(n1448,refuted) :- status(o_ee37a283c2604a0f7780,refuted).
node(n1448,unknown) :- status(o_ee37a283c2604a0f7780,unknown).
node(n1449,supported) :- status(o_5c13853e25dc6be86f22,supported).
node(n1449,refuted) :- status(o_5c13853e25dc6be86f22,refuted).
node(n1449,unknown) :- status(o_5c13853e25dc6be86f22,unknown).
node(n1446,supported) :- node(n1447,supported), node(n1448,supported), node(n1449,supported).
node(n1446,refuted) :- node(n1447,refuted).
node(n1446,refuted) :- node(n1448,refuted).
node(n1446,refuted) :- node(n1449,refuted).
node(n1446,unknown) :- \+ node(n1446,supported), \+ node(n1446,refuted).
node(n1451,supported) :- status(o_e4df053c7e99474f2c94,supported).
node(n1451,refuted) :- status(o_e4df053c7e99474f2c94,refuted).
node(n1451,unknown) :- status(o_e4df053c7e99474f2c94,unknown).
node(n1452,supported) :- status(o_4c8442e408e665cc6396,supported).
node(n1452,refuted) :- status(o_4c8442e408e665cc6396,refuted).
node(n1452,unknown) :- status(o_4c8442e408e665cc6396,unknown).
node(n1453,supported) :- status(o_b6da7082fcfffa942afc,supported).
node(n1453,refuted) :- status(o_b6da7082fcfffa942afc,refuted).
node(n1453,unknown) :- status(o_b6da7082fcfffa942afc,unknown).
node(n1450,supported) :- node(n1451,supported), node(n1452,supported), node(n1453,supported).
node(n1450,refuted) :- node(n1451,refuted).
node(n1450,refuted) :- node(n1452,refuted).
node(n1450,refuted) :- node(n1453,refuted).
node(n1450,unknown) :- \+ node(n1450,supported), \+ node(n1450,refuted).
node(n1445,refuted) :- node(n1446,refuted), node(n1450,refuted), node(n9,refuted).
node(n1445,supported) :- node(n1446,supported).
node(n1445,supported) :- node(n1450,supported).
node(n1445,supported) :- node(n9,supported).
node(n1445,unknown) :- \+ node(n1445,supported), \+ node(n1445,refuted).
verdict(c_65df3e999ea833ea,supported) :- node(n1445,supported).
query(verdict(c_65df3e999ea833ea,supported)).
verdict(c_65df3e999ea833ea,refuted) :- node(n1445,refuted).
query(verdict(c_65df3e999ea833ea,refuted)).
verdict(c_65df3e999ea833ea,unknown) :- node(n1445,unknown).
query(verdict(c_65df3e999ea833ea,unknown)).
node(n1456,supported) :- status(o_244e877aab9680c8dac1,supported).
node(n1456,refuted) :- status(o_244e877aab9680c8dac1,refuted).
node(n1456,unknown) :- status(o_244e877aab9680c8dac1,unknown).
node(n1455,supported) :- node(n1447,supported), node(n1448,supported), node(n1449,supported), node(n1456,supported).
node(n1455,refuted) :- node(n1447,refuted).
node(n1455,refuted) :- node(n1448,refuted).
node(n1455,refuted) :- node(n1449,refuted).
node(n1455,refuted) :- node(n1456,refuted).
node(n1455,unknown) :- \+ node(n1455,supported), \+ node(n1455,refuted).
node(n1458,supported) :- status(o_6e4759a836899fad6672,supported).
node(n1458,refuted) :- status(o_6e4759a836899fad6672,refuted).
node(n1458,unknown) :- status(o_6e4759a836899fad6672,unknown).
node(n1457,supported) :- node(n1451,supported), node(n1452,supported), node(n1453,supported), node(n1458,supported).
node(n1457,refuted) :- node(n1451,refuted).
node(n1457,refuted) :- node(n1452,refuted).
node(n1457,refuted) :- node(n1453,refuted).
node(n1457,refuted) :- node(n1458,refuted).
node(n1457,unknown) :- \+ node(n1457,supported), \+ node(n1457,refuted).
node(n1454,refuted) :- node(n1455,refuted), node(n1457,refuted), node(n9,refuted).
node(n1454,supported) :- node(n1455,supported).
node(n1454,supported) :- node(n1457,supported).
node(n1454,supported) :- node(n9,supported).
node(n1454,unknown) :- \+ node(n1454,supported), \+ node(n1454,refuted).
verdict(c_3e433e899255ed45,supported) :- node(n1454,supported).
query(verdict(c_3e433e899255ed45,supported)).
verdict(c_3e433e899255ed45,refuted) :- node(n1454,refuted).
query(verdict(c_3e433e899255ed45,refuted)).
verdict(c_3e433e899255ed45,unknown) :- node(n1454,unknown).
query(verdict(c_3e433e899255ed45,unknown)).
node(n1461,supported) :- status(o_78cc8ef7aed6965d0cfb,supported).
node(n1461,refuted) :- status(o_78cc8ef7aed6965d0cfb,refuted).
node(n1461,unknown) :- status(o_78cc8ef7aed6965d0cfb,unknown).
node(n1462,supported) :- status(o_2ea9f04f17caf58744f9,supported).
node(n1462,refuted) :- status(o_2ea9f04f17caf58744f9,refuted).
node(n1462,unknown) :- status(o_2ea9f04f17caf58744f9,unknown).
node(n1460,supported) :- node(n1447,supported), node(n1448,supported), node(n1449,supported), node(n1456,supported), node(n1461,supported), node(n1462,supported).
node(n1460,refuted) :- node(n1447,refuted).
node(n1460,refuted) :- node(n1448,refuted).
node(n1460,refuted) :- node(n1449,refuted).
node(n1460,refuted) :- node(n1456,refuted).
node(n1460,refuted) :- node(n1461,refuted).
node(n1460,refuted) :- node(n1462,refuted).
node(n1460,unknown) :- \+ node(n1460,supported), \+ node(n1460,refuted).
node(n1464,supported) :- status(o_8f8b4710a2762a772eee,supported).
node(n1464,refuted) :- status(o_8f8b4710a2762a772eee,refuted).
node(n1464,unknown) :- status(o_8f8b4710a2762a772eee,unknown).
node(n1465,supported) :- status(o_1729d7b5b3d2d7c00f80,supported).
node(n1465,refuted) :- status(o_1729d7b5b3d2d7c00f80,refuted).
node(n1465,unknown) :- status(o_1729d7b5b3d2d7c00f80,unknown).
node(n1463,supported) :- node(n1451,supported), node(n1452,supported), node(n1453,supported), node(n1458,supported), node(n1464,supported), node(n1465,supported).
node(n1463,refuted) :- node(n1451,refuted).
node(n1463,refuted) :- node(n1452,refuted).
node(n1463,refuted) :- node(n1453,refuted).
node(n1463,refuted) :- node(n1458,refuted).
node(n1463,refuted) :- node(n1464,refuted).
node(n1463,refuted) :- node(n1465,refuted).
node(n1463,unknown) :- \+ node(n1463,supported), \+ node(n1463,refuted).
node(n1459,refuted) :- node(n1460,refuted), node(n1463,refuted), node(n9,refuted).
node(n1459,supported) :- node(n1460,supported).
node(n1459,supported) :- node(n1463,supported).
node(n1459,supported) :- node(n9,supported).
node(n1459,unknown) :- \+ node(n1459,supported), \+ node(n1459,refuted).
verdict(c_c2b94cbacea8dd41,supported) :- node(n1459,supported).
query(verdict(c_c2b94cbacea8dd41,supported)).
verdict(c_c2b94cbacea8dd41,refuted) :- node(n1459,refuted).
query(verdict(c_c2b94cbacea8dd41,refuted)).
verdict(c_c2b94cbacea8dd41,unknown) :- node(n1459,unknown).
query(verdict(c_c2b94cbacea8dd41,unknown)).
node(n1468,supported) :- status(o_af8c70fcd4d37a470ec0,supported).
node(n1468,refuted) :- status(o_af8c70fcd4d37a470ec0,refuted).
node(n1468,unknown) :- status(o_af8c70fcd4d37a470ec0,unknown).
node(n1467,supported) :- node(n1447,supported), node(n1448,supported), node(n1468,supported).
node(n1467,refuted) :- node(n1447,refuted).
node(n1467,refuted) :- node(n1448,refuted).
node(n1467,refuted) :- node(n1468,refuted).
node(n1467,unknown) :- \+ node(n1467,supported), \+ node(n1467,refuted).
node(n1470,supported) :- status(o_fdc563b7ff056f0fe69a,supported).
node(n1470,refuted) :- status(o_fdc563b7ff056f0fe69a,refuted).
node(n1470,unknown) :- status(o_fdc563b7ff056f0fe69a,unknown).
node(n1469,supported) :- node(n1451,supported), node(n1452,supported), node(n1470,supported).
node(n1469,refuted) :- node(n1451,refuted).
node(n1469,refuted) :- node(n1452,refuted).
node(n1469,refuted) :- node(n1470,refuted).
node(n1469,unknown) :- \+ node(n1469,supported), \+ node(n1469,refuted).
node(n1466,refuted) :- node(n1467,refuted), node(n1469,refuted), node(n9,refuted).
node(n1466,supported) :- node(n1467,supported).
node(n1466,supported) :- node(n1469,supported).
node(n1466,supported) :- node(n9,supported).
node(n1466,unknown) :- \+ node(n1466,supported), \+ node(n1466,refuted).
verdict(c_ac7b656f3a2acc59,supported) :- node(n1466,supported).
query(verdict(c_ac7b656f3a2acc59,supported)).
verdict(c_ac7b656f3a2acc59,refuted) :- node(n1466,refuted).
query(verdict(c_ac7b656f3a2acc59,refuted)).
verdict(c_ac7b656f3a2acc59,unknown) :- node(n1466,unknown).
query(verdict(c_ac7b656f3a2acc59,unknown)).
node(n1472,supported) :- node(n1447,supported), node(n1448,supported), node(n1449,supported), node(n1468,supported).
node(n1472,refuted) :- node(n1447,refuted).
node(n1472,refuted) :- node(n1448,refuted).
node(n1472,refuted) :- node(n1449,refuted).
node(n1472,refuted) :- node(n1468,refuted).
node(n1472,unknown) :- \+ node(n1472,supported), \+ node(n1472,refuted).
node(n1473,supported) :- node(n1451,supported), node(n1452,supported), node(n1453,supported), node(n1470,supported).
node(n1473,refuted) :- node(n1451,refuted).
node(n1473,refuted) :- node(n1452,refuted).
node(n1473,refuted) :- node(n1453,refuted).
node(n1473,refuted) :- node(n1470,refuted).
node(n1473,unknown) :- \+ node(n1473,supported), \+ node(n1473,refuted).
node(n1471,refuted) :- node(n1472,refuted), node(n1473,refuted), node(n9,refuted).
node(n1471,supported) :- node(n1472,supported).
node(n1471,supported) :- node(n1473,supported).
node(n1471,supported) :- node(n9,supported).
node(n1471,unknown) :- \+ node(n1471,supported), \+ node(n1471,refuted).
verdict(c_30b40641a4ea3b50,supported) :- node(n1471,supported).
query(verdict(c_30b40641a4ea3b50,supported)).
verdict(c_30b40641a4ea3b50,refuted) :- node(n1471,refuted).
query(verdict(c_30b40641a4ea3b50,refuted)).
verdict(c_30b40641a4ea3b50,unknown) :- node(n1471,unknown).
query(verdict(c_30b40641a4ea3b50,unknown)).
node(n1476,supported) :- status(o_b38149e79a9ea4fadfbf,supported).
node(n1476,refuted) :- status(o_b38149e79a9ea4fadfbf,refuted).
node(n1476,unknown) :- status(o_b38149e79a9ea4fadfbf,unknown).
node(n1477,supported) :- status(o_76c2f83b76219d4dfb59,supported).
node(n1477,refuted) :- status(o_76c2f83b76219d4dfb59,refuted).
node(n1477,unknown) :- status(o_76c2f83b76219d4dfb59,unknown).
node(n1478,supported) :- status(o_14f36cd494a1a905dd7b,supported).
node(n1478,refuted) :- status(o_14f36cd494a1a905dd7b,refuted).
node(n1478,unknown) :- status(o_14f36cd494a1a905dd7b,unknown).
node(n1475,supported) :- node(n1476,supported), node(n1477,supported), node(n1478,supported).
node(n1475,refuted) :- node(n1476,refuted).
node(n1475,refuted) :- node(n1477,refuted).
node(n1475,refuted) :- node(n1478,refuted).
node(n1475,unknown) :- \+ node(n1475,supported), \+ node(n1475,refuted).
node(n1480,supported) :- status(o_f5ee22f6a9ec87c80c31,supported).
node(n1480,refuted) :- status(o_f5ee22f6a9ec87c80c31,refuted).
node(n1480,unknown) :- status(o_f5ee22f6a9ec87c80c31,unknown).
node(n1481,supported) :- status(o_124d157201f26d0b1890,supported).
node(n1481,refuted) :- status(o_124d157201f26d0b1890,refuted).
node(n1481,unknown) :- status(o_124d157201f26d0b1890,unknown).
node(n1482,supported) :- status(o_bc90005c66df9816d858,supported).
node(n1482,refuted) :- status(o_bc90005c66df9816d858,refuted).
node(n1482,unknown) :- status(o_bc90005c66df9816d858,unknown).
node(n1479,supported) :- node(n1480,supported), node(n1481,supported), node(n1482,supported).
node(n1479,refuted) :- node(n1480,refuted).
node(n1479,refuted) :- node(n1481,refuted).
node(n1479,refuted) :- node(n1482,refuted).
node(n1479,unknown) :- \+ node(n1479,supported), \+ node(n1479,refuted).
node(n1474,refuted) :- node(n1475,refuted), node(n1479,refuted), node(n9,refuted).
node(n1474,supported) :- node(n1475,supported).
node(n1474,supported) :- node(n1479,supported).
node(n1474,supported) :- node(n9,supported).
node(n1474,unknown) :- \+ node(n1474,supported), \+ node(n1474,refuted).
verdict(c_7b1313b51b4735b9,supported) :- node(n1474,supported).
query(verdict(c_7b1313b51b4735b9,supported)).
verdict(c_7b1313b51b4735b9,refuted) :- node(n1474,refuted).
query(verdict(c_7b1313b51b4735b9,refuted)).
verdict(c_7b1313b51b4735b9,unknown) :- node(n1474,unknown).
query(verdict(c_7b1313b51b4735b9,unknown)).
node(n1485,supported) :- status(o_54750fcc5f0455b0c255,supported).
node(n1485,refuted) :- status(o_54750fcc5f0455b0c255,refuted).
node(n1485,unknown) :- status(o_54750fcc5f0455b0c255,unknown).
node(n1484,supported) :- node(n1476,supported), node(n1477,supported), node(n1478,supported), node(n1485,supported).
node(n1484,refuted) :- node(n1476,refuted).
node(n1484,refuted) :- node(n1477,refuted).
node(n1484,refuted) :- node(n1478,refuted).
node(n1484,refuted) :- node(n1485,refuted).
node(n1484,unknown) :- \+ node(n1484,supported), \+ node(n1484,refuted).
node(n1487,supported) :- status(o_fc4017cbc354175c35f3,supported).
node(n1487,refuted) :- status(o_fc4017cbc354175c35f3,refuted).
node(n1487,unknown) :- status(o_fc4017cbc354175c35f3,unknown).
node(n1486,supported) :- node(n1480,supported), node(n1481,supported), node(n1482,supported), node(n1487,supported).
node(n1486,refuted) :- node(n1480,refuted).
node(n1486,refuted) :- node(n1481,refuted).
node(n1486,refuted) :- node(n1482,refuted).
node(n1486,refuted) :- node(n1487,refuted).
node(n1486,unknown) :- \+ node(n1486,supported), \+ node(n1486,refuted).
node(n1483,refuted) :- node(n1484,refuted), node(n1486,refuted), node(n9,refuted).
node(n1483,supported) :- node(n1484,supported).
node(n1483,supported) :- node(n1486,supported).
node(n1483,supported) :- node(n9,supported).
node(n1483,unknown) :- \+ node(n1483,supported), \+ node(n1483,refuted).
verdict(c_010cc3e0900f7a82,supported) :- node(n1483,supported).
query(verdict(c_010cc3e0900f7a82,supported)).
verdict(c_010cc3e0900f7a82,refuted) :- node(n1483,refuted).
query(verdict(c_010cc3e0900f7a82,refuted)).
verdict(c_010cc3e0900f7a82,unknown) :- node(n1483,unknown).
query(verdict(c_010cc3e0900f7a82,unknown)).
node(n1490,supported) :- status(o_f35babcf0f55f5596300,supported).
node(n1490,refuted) :- status(o_f35babcf0f55f5596300,refuted).
node(n1490,unknown) :- status(o_f35babcf0f55f5596300,unknown).
node(n1491,supported) :- status(o_ad961dcc306cafbb16e9,supported).
node(n1491,refuted) :- status(o_ad961dcc306cafbb16e9,refuted).
node(n1491,unknown) :- status(o_ad961dcc306cafbb16e9,unknown).
node(n1489,supported) :- node(n1476,supported), node(n1477,supported), node(n1478,supported), node(n1485,supported), node(n1490,supported), node(n1491,supported).
node(n1489,refuted) :- node(n1476,refuted).
node(n1489,refuted) :- node(n1477,refuted).
node(n1489,refuted) :- node(n1478,refuted).
node(n1489,refuted) :- node(n1485,refuted).
node(n1489,refuted) :- node(n1490,refuted).
node(n1489,refuted) :- node(n1491,refuted).
node(n1489,unknown) :- \+ node(n1489,supported), \+ node(n1489,refuted).
node(n1493,supported) :- status(o_cd1b608b189c789b9629,supported).
node(n1493,refuted) :- status(o_cd1b608b189c789b9629,refuted).
node(n1493,unknown) :- status(o_cd1b608b189c789b9629,unknown).
node(n1494,supported) :- status(o_3db065b60ed8c77853f6,supported).
node(n1494,refuted) :- status(o_3db065b60ed8c77853f6,refuted).
node(n1494,unknown) :- status(o_3db065b60ed8c77853f6,unknown).
node(n1492,supported) :- node(n1480,supported), node(n1481,supported), node(n1482,supported), node(n1487,supported), node(n1493,supported), node(n1494,supported).
node(n1492,refuted) :- node(n1480,refuted).
node(n1492,refuted) :- node(n1481,refuted).
node(n1492,refuted) :- node(n1482,refuted).
node(n1492,refuted) :- node(n1487,refuted).
node(n1492,refuted) :- node(n1493,refuted).
node(n1492,refuted) :- node(n1494,refuted).
node(n1492,unknown) :- \+ node(n1492,supported), \+ node(n1492,refuted).
node(n1488,refuted) :- node(n1489,refuted), node(n1492,refuted), node(n9,refuted).
node(n1488,supported) :- node(n1489,supported).
node(n1488,supported) :- node(n1492,supported).
node(n1488,supported) :- node(n9,supported).
node(n1488,unknown) :- \+ node(n1488,supported), \+ node(n1488,refuted).
verdict(c_fc353564d1d0de95,supported) :- node(n1488,supported).
query(verdict(c_fc353564d1d0de95,supported)).
verdict(c_fc353564d1d0de95,refuted) :- node(n1488,refuted).
query(verdict(c_fc353564d1d0de95,refuted)).
verdict(c_fc353564d1d0de95,unknown) :- node(n1488,unknown).
query(verdict(c_fc353564d1d0de95,unknown)).
node(n1497,supported) :- status(o_867f5de1c76fa2df063a,supported).
node(n1497,refuted) :- status(o_867f5de1c76fa2df063a,refuted).
node(n1497,unknown) :- status(o_867f5de1c76fa2df063a,unknown).
node(n1496,supported) :- node(n1476,supported), node(n1477,supported), node(n1497,supported).
node(n1496,refuted) :- node(n1476,refuted).
node(n1496,refuted) :- node(n1477,refuted).
node(n1496,refuted) :- node(n1497,refuted).
node(n1496,unknown) :- \+ node(n1496,supported), \+ node(n1496,refuted).
node(n1499,supported) :- status(o_cb089fcbbe9767b7327a,supported).
node(n1499,refuted) :- status(o_cb089fcbbe9767b7327a,refuted).
node(n1499,unknown) :- status(o_cb089fcbbe9767b7327a,unknown).
node(n1498,supported) :- node(n1480,supported), node(n1481,supported), node(n1499,supported).
node(n1498,refuted) :- node(n1480,refuted).
node(n1498,refuted) :- node(n1481,refuted).
node(n1498,refuted) :- node(n1499,refuted).
node(n1498,unknown) :- \+ node(n1498,supported), \+ node(n1498,refuted).
node(n1495,refuted) :- node(n1496,refuted), node(n1498,refuted), node(n9,refuted).
node(n1495,supported) :- node(n1496,supported).
node(n1495,supported) :- node(n1498,supported).
node(n1495,supported) :- node(n9,supported).
node(n1495,unknown) :- \+ node(n1495,supported), \+ node(n1495,refuted).
verdict(c_1ec06eab83704f4f,supported) :- node(n1495,supported).
query(verdict(c_1ec06eab83704f4f,supported)).
verdict(c_1ec06eab83704f4f,refuted) :- node(n1495,refuted).
query(verdict(c_1ec06eab83704f4f,refuted)).
verdict(c_1ec06eab83704f4f,unknown) :- node(n1495,unknown).
query(verdict(c_1ec06eab83704f4f,unknown)).
node(n1501,supported) :- node(n1476,supported), node(n1477,supported), node(n1478,supported), node(n1497,supported).
node(n1501,refuted) :- node(n1476,refuted).
node(n1501,refuted) :- node(n1477,refuted).
node(n1501,refuted) :- node(n1478,refuted).
node(n1501,refuted) :- node(n1497,refuted).
node(n1501,unknown) :- \+ node(n1501,supported), \+ node(n1501,refuted).
node(n1502,supported) :- node(n1480,supported), node(n1481,supported), node(n1482,supported), node(n1499,supported).
node(n1502,refuted) :- node(n1480,refuted).
node(n1502,refuted) :- node(n1481,refuted).
node(n1502,refuted) :- node(n1482,refuted).
node(n1502,refuted) :- node(n1499,refuted).
node(n1502,unknown) :- \+ node(n1502,supported), \+ node(n1502,refuted).
node(n1500,refuted) :- node(n1501,refuted), node(n1502,refuted), node(n9,refuted).
node(n1500,supported) :- node(n1501,supported).
node(n1500,supported) :- node(n1502,supported).
node(n1500,supported) :- node(n9,supported).
node(n1500,unknown) :- \+ node(n1500,supported), \+ node(n1500,refuted).
verdict(c_378594c8197d34d6,supported) :- node(n1500,supported).
query(verdict(c_378594c8197d34d6,supported)).
verdict(c_378594c8197d34d6,refuted) :- node(n1500,refuted).
query(verdict(c_378594c8197d34d6,refuted)).
verdict(c_378594c8197d34d6,unknown) :- node(n1500,unknown).
query(verdict(c_378594c8197d34d6,unknown)).
node(n1505,supported) :- status(o_f81075f6b51ab1ffb493,supported).
node(n1505,refuted) :- status(o_f81075f6b51ab1ffb493,refuted).
node(n1505,unknown) :- status(o_f81075f6b51ab1ffb493,unknown).
node(n1506,supported) :- status(o_0c661e10e0f22728b44c,supported).
node(n1506,refuted) :- status(o_0c661e10e0f22728b44c,refuted).
node(n1506,unknown) :- status(o_0c661e10e0f22728b44c,unknown).
node(n1507,supported) :- status(o_fb25b49a1d41dd64804a,supported).
node(n1507,refuted) :- status(o_fb25b49a1d41dd64804a,refuted).
node(n1507,unknown) :- status(o_fb25b49a1d41dd64804a,unknown).
node(n1504,supported) :- node(n1505,supported), node(n1506,supported), node(n1507,supported).
node(n1504,refuted) :- node(n1505,refuted).
node(n1504,refuted) :- node(n1506,refuted).
node(n1504,refuted) :- node(n1507,refuted).
node(n1504,unknown) :- \+ node(n1504,supported), \+ node(n1504,refuted).
node(n1503,refuted) :- node(n1504,refuted), node(n9,refuted).
node(n1503,supported) :- node(n1504,supported).
node(n1503,supported) :- node(n9,supported).
node(n1503,unknown) :- \+ node(n1503,supported), \+ node(n1503,refuted).
verdict(c_ce00576965ff036b,supported) :- node(n1503,supported).
query(verdict(c_ce00576965ff036b,supported)).
verdict(c_ce00576965ff036b,refuted) :- node(n1503,refuted).
query(verdict(c_ce00576965ff036b,refuted)).
verdict(c_ce00576965ff036b,unknown) :- node(n1503,unknown).
query(verdict(c_ce00576965ff036b,unknown)).
node(n1510,supported) :- status(o_e3f2cde0c6419fe4632c,supported).
node(n1510,refuted) :- status(o_e3f2cde0c6419fe4632c,refuted).
node(n1510,unknown) :- status(o_e3f2cde0c6419fe4632c,unknown).
node(n1509,supported) :- node(n1505,supported), node(n1506,supported), node(n1507,supported), node(n1510,supported).
node(n1509,refuted) :- node(n1505,refuted).
node(n1509,refuted) :- node(n1506,refuted).
node(n1509,refuted) :- node(n1507,refuted).
node(n1509,refuted) :- node(n1510,refuted).
node(n1509,unknown) :- \+ node(n1509,supported), \+ node(n1509,refuted).
node(n1508,refuted) :- node(n1509,refuted), node(n9,refuted).
node(n1508,supported) :- node(n1509,supported).
node(n1508,supported) :- node(n9,supported).
node(n1508,unknown) :- \+ node(n1508,supported), \+ node(n1508,refuted).
verdict(c_a089b5408592f9ac,supported) :- node(n1508,supported).
query(verdict(c_a089b5408592f9ac,supported)).
verdict(c_a089b5408592f9ac,refuted) :- node(n1508,refuted).
query(verdict(c_a089b5408592f9ac,refuted)).
verdict(c_a089b5408592f9ac,unknown) :- node(n1508,unknown).
query(verdict(c_a089b5408592f9ac,unknown)).
node(n1513,supported) :- status(o_3ab2d5644fce35f21d63,supported).
node(n1513,refuted) :- status(o_3ab2d5644fce35f21d63,refuted).
node(n1513,unknown) :- status(o_3ab2d5644fce35f21d63,unknown).
node(n1514,supported) :- status(o_c0e1c40bbf9e428cd889,supported).
node(n1514,refuted) :- status(o_c0e1c40bbf9e428cd889,refuted).
node(n1514,unknown) :- status(o_c0e1c40bbf9e428cd889,unknown).
node(n1512,supported) :- node(n1505,supported), node(n1506,supported), node(n1507,supported), node(n1510,supported), node(n1513,supported), node(n1514,supported).
node(n1512,refuted) :- node(n1505,refuted).
node(n1512,refuted) :- node(n1506,refuted).
node(n1512,refuted) :- node(n1507,refuted).
node(n1512,refuted) :- node(n1510,refuted).
node(n1512,refuted) :- node(n1513,refuted).
node(n1512,refuted) :- node(n1514,refuted).
node(n1512,unknown) :- \+ node(n1512,supported), \+ node(n1512,refuted).
node(n1511,refuted) :- node(n1512,refuted), node(n9,refuted).
node(n1511,supported) :- node(n1512,supported).
node(n1511,supported) :- node(n9,supported).
node(n1511,unknown) :- \+ node(n1511,supported), \+ node(n1511,refuted).
verdict(c_15ddab7b67858591,supported) :- node(n1511,supported).
query(verdict(c_15ddab7b67858591,supported)).
verdict(c_15ddab7b67858591,refuted) :- node(n1511,refuted).
query(verdict(c_15ddab7b67858591,refuted)).
verdict(c_15ddab7b67858591,unknown) :- node(n1511,unknown).
query(verdict(c_15ddab7b67858591,unknown)).
node(n1517,supported) :- status(o_511980cebe672ee2eb96,supported).
node(n1517,refuted) :- status(o_511980cebe672ee2eb96,refuted).
node(n1517,unknown) :- status(o_511980cebe672ee2eb96,unknown).
node(n1516,supported) :- node(n1505,supported), node(n1506,supported), node(n1517,supported).
node(n1516,refuted) :- node(n1505,refuted).
node(n1516,refuted) :- node(n1506,refuted).
node(n1516,refuted) :- node(n1517,refuted).
node(n1516,unknown) :- \+ node(n1516,supported), \+ node(n1516,refuted).
node(n1515,refuted) :- node(n1516,refuted), node(n9,refuted).
node(n1515,supported) :- node(n1516,supported).
node(n1515,supported) :- node(n9,supported).
node(n1515,unknown) :- \+ node(n1515,supported), \+ node(n1515,refuted).
verdict(c_285b3f65a00a4fe5,supported) :- node(n1515,supported).
query(verdict(c_285b3f65a00a4fe5,supported)).
verdict(c_285b3f65a00a4fe5,refuted) :- node(n1515,refuted).
query(verdict(c_285b3f65a00a4fe5,refuted)).
verdict(c_285b3f65a00a4fe5,unknown) :- node(n1515,unknown).
query(verdict(c_285b3f65a00a4fe5,unknown)).
node(n1519,supported) :- node(n1505,supported), node(n1506,supported), node(n1507,supported), node(n1517,supported).
node(n1519,refuted) :- node(n1505,refuted).
node(n1519,refuted) :- node(n1506,refuted).
node(n1519,refuted) :- node(n1507,refuted).
node(n1519,refuted) :- node(n1517,refuted).
node(n1519,unknown) :- \+ node(n1519,supported), \+ node(n1519,refuted).
node(n1518,refuted) :- node(n1519,refuted), node(n9,refuted).
node(n1518,supported) :- node(n1519,supported).
node(n1518,supported) :- node(n9,supported).
node(n1518,unknown) :- \+ node(n1518,supported), \+ node(n1518,refuted).
verdict(c_e85e707d13e8ec8c,supported) :- node(n1518,supported).
query(verdict(c_e85e707d13e8ec8c,supported)).
verdict(c_e85e707d13e8ec8c,refuted) :- node(n1518,refuted).
query(verdict(c_e85e707d13e8ec8c,refuted)).
verdict(c_e85e707d13e8ec8c,unknown) :- node(n1518,unknown).
query(verdict(c_e85e707d13e8ec8c,unknown)).
node(n1522,supported) :- status(o_f6a79ff0dfdc9f0c500d,supported).
node(n1522,refuted) :- status(o_f6a79ff0dfdc9f0c500d,refuted).
node(n1522,unknown) :- status(o_f6a79ff0dfdc9f0c500d,unknown).
node(n1523,supported) :- status(o_e9d6117e867175d3e03c,supported).
node(n1523,refuted) :- status(o_e9d6117e867175d3e03c,refuted).
node(n1523,unknown) :- status(o_e9d6117e867175d3e03c,unknown).
node(n1524,supported) :- status(o_4b69ce6f08ef602eb19e,supported).
node(n1524,refuted) :- status(o_4b69ce6f08ef602eb19e,refuted).
node(n1524,unknown) :- status(o_4b69ce6f08ef602eb19e,unknown).
node(n1521,supported) :- node(n1522,supported), node(n1523,supported), node(n1524,supported).
node(n1521,refuted) :- node(n1522,refuted).
node(n1521,refuted) :- node(n1523,refuted).
node(n1521,refuted) :- node(n1524,refuted).
node(n1521,unknown) :- \+ node(n1521,supported), \+ node(n1521,refuted).
node(n1520,refuted) :- node(n1521,refuted), node(n9,refuted).
node(n1520,supported) :- node(n1521,supported).
node(n1520,supported) :- node(n9,supported).
node(n1520,unknown) :- \+ node(n1520,supported), \+ node(n1520,refuted).
verdict(c_9b213dea55868cfd,supported) :- node(n1520,supported).
query(verdict(c_9b213dea55868cfd,supported)).
verdict(c_9b213dea55868cfd,refuted) :- node(n1520,refuted).
query(verdict(c_9b213dea55868cfd,refuted)).
verdict(c_9b213dea55868cfd,unknown) :- node(n1520,unknown).
query(verdict(c_9b213dea55868cfd,unknown)).
node(n1527,supported) :- status(o_fb5d81928e8abb798b86,supported).
node(n1527,refuted) :- status(o_fb5d81928e8abb798b86,refuted).
node(n1527,unknown) :- status(o_fb5d81928e8abb798b86,unknown).
node(n1526,supported) :- node(n1522,supported), node(n1523,supported), node(n1524,supported), node(n1527,supported).
node(n1526,refuted) :- node(n1522,refuted).
node(n1526,refuted) :- node(n1523,refuted).
node(n1526,refuted) :- node(n1524,refuted).
node(n1526,refuted) :- node(n1527,refuted).
node(n1526,unknown) :- \+ node(n1526,supported), \+ node(n1526,refuted).
node(n1525,refuted) :- node(n1526,refuted), node(n9,refuted).
node(n1525,supported) :- node(n1526,supported).
node(n1525,supported) :- node(n9,supported).
node(n1525,unknown) :- \+ node(n1525,supported), \+ node(n1525,refuted).
verdict(c_a4fa6dd2360447c0,supported) :- node(n1525,supported).
query(verdict(c_a4fa6dd2360447c0,supported)).
verdict(c_a4fa6dd2360447c0,refuted) :- node(n1525,refuted).
query(verdict(c_a4fa6dd2360447c0,refuted)).
verdict(c_a4fa6dd2360447c0,unknown) :- node(n1525,unknown).
query(verdict(c_a4fa6dd2360447c0,unknown)).
node(n1530,supported) :- status(o_e712b1b8f770b3328877,supported).
node(n1530,refuted) :- status(o_e712b1b8f770b3328877,refuted).
node(n1530,unknown) :- status(o_e712b1b8f770b3328877,unknown).
node(n1531,supported) :- status(o_b8ba8dc852844048c4a7,supported).
node(n1531,refuted) :- status(o_b8ba8dc852844048c4a7,refuted).
node(n1531,unknown) :- status(o_b8ba8dc852844048c4a7,unknown).
node(n1529,supported) :- node(n1522,supported), node(n1523,supported), node(n1524,supported), node(n1527,supported), node(n1530,supported), node(n1531,supported).
node(n1529,refuted) :- node(n1522,refuted).
node(n1529,refuted) :- node(n1523,refuted).
node(n1529,refuted) :- node(n1524,refuted).
node(n1529,refuted) :- node(n1527,refuted).
node(n1529,refuted) :- node(n1530,refuted).
node(n1529,refuted) :- node(n1531,refuted).
node(n1529,unknown) :- \+ node(n1529,supported), \+ node(n1529,refuted).
node(n1528,refuted) :- node(n1529,refuted), node(n9,refuted).
node(n1528,supported) :- node(n1529,supported).
node(n1528,supported) :- node(n9,supported).
node(n1528,unknown) :- \+ node(n1528,supported), \+ node(n1528,refuted).
verdict(c_871528231d436cf3,supported) :- node(n1528,supported).
query(verdict(c_871528231d436cf3,supported)).
verdict(c_871528231d436cf3,refuted) :- node(n1528,refuted).
query(verdict(c_871528231d436cf3,refuted)).
verdict(c_871528231d436cf3,unknown) :- node(n1528,unknown).
query(verdict(c_871528231d436cf3,unknown)).
node(n1534,supported) :- status(o_629da59e1ad937cf39b0,supported).
node(n1534,refuted) :- status(o_629da59e1ad937cf39b0,refuted).
node(n1534,unknown) :- status(o_629da59e1ad937cf39b0,unknown).
node(n1533,supported) :- node(n1522,supported), node(n1523,supported), node(n1534,supported).
node(n1533,refuted) :- node(n1522,refuted).
node(n1533,refuted) :- node(n1523,refuted).
node(n1533,refuted) :- node(n1534,refuted).
node(n1533,unknown) :- \+ node(n1533,supported), \+ node(n1533,refuted).
node(n1532,refuted) :- node(n1533,refuted), node(n9,refuted).
node(n1532,supported) :- node(n1533,supported).
node(n1532,supported) :- node(n9,supported).
node(n1532,unknown) :- \+ node(n1532,supported), \+ node(n1532,refuted).
verdict(c_5c5e049306c9fa7a,supported) :- node(n1532,supported).
query(verdict(c_5c5e049306c9fa7a,supported)).
verdict(c_5c5e049306c9fa7a,refuted) :- node(n1532,refuted).
query(verdict(c_5c5e049306c9fa7a,refuted)).
verdict(c_5c5e049306c9fa7a,unknown) :- node(n1532,unknown).
query(verdict(c_5c5e049306c9fa7a,unknown)).
node(n1536,supported) :- node(n1522,supported), node(n1523,supported), node(n1524,supported), node(n1534,supported).
node(n1536,refuted) :- node(n1522,refuted).
node(n1536,refuted) :- node(n1523,refuted).
node(n1536,refuted) :- node(n1524,refuted).
node(n1536,refuted) :- node(n1534,refuted).
node(n1536,unknown) :- \+ node(n1536,supported), \+ node(n1536,refuted).
node(n1535,refuted) :- node(n1536,refuted), node(n9,refuted).
node(n1535,supported) :- node(n1536,supported).
node(n1535,supported) :- node(n9,supported).
node(n1535,unknown) :- \+ node(n1535,supported), \+ node(n1535,refuted).
verdict(c_8f43e40640aca050,supported) :- node(n1535,supported).
query(verdict(c_8f43e40640aca050,supported)).
verdict(c_8f43e40640aca050,refuted) :- node(n1535,refuted).
query(verdict(c_8f43e40640aca050,refuted)).
verdict(c_8f43e40640aca050,unknown) :- node(n1535,unknown).
query(verdict(c_8f43e40640aca050,unknown)).
node(n1539,supported) :- status(o_39e0bff00f1d8c29ba36,supported).
node(n1539,refuted) :- status(o_39e0bff00f1d8c29ba36,refuted).
node(n1539,unknown) :- status(o_39e0bff00f1d8c29ba36,unknown).
node(n1540,supported) :- status(o_e89ee2add9affede6550,supported).
node(n1540,refuted) :- status(o_e89ee2add9affede6550,refuted).
node(n1540,unknown) :- status(o_e89ee2add9affede6550,unknown).
node(n1541,supported) :- status(o_a4ded78248734d41626d,supported).
node(n1541,refuted) :- status(o_a4ded78248734d41626d,refuted).
node(n1541,unknown) :- status(o_a4ded78248734d41626d,unknown).
node(n1538,supported) :- node(n1539,supported), node(n1540,supported), node(n1541,supported).
node(n1538,refuted) :- node(n1539,refuted).
node(n1538,refuted) :- node(n1540,refuted).
node(n1538,refuted) :- node(n1541,refuted).
node(n1538,unknown) :- \+ node(n1538,supported), \+ node(n1538,refuted).
node(n1537,refuted) :- node(n1538,refuted), node(n9,refuted).
node(n1537,supported) :- node(n1538,supported).
node(n1537,supported) :- node(n9,supported).
node(n1537,unknown) :- \+ node(n1537,supported), \+ node(n1537,refuted).
verdict(c_afa84e65de1e0b02,supported) :- node(n1537,supported).
query(verdict(c_afa84e65de1e0b02,supported)).
verdict(c_afa84e65de1e0b02,refuted) :- node(n1537,refuted).
query(verdict(c_afa84e65de1e0b02,refuted)).
verdict(c_afa84e65de1e0b02,unknown) :- node(n1537,unknown).
query(verdict(c_afa84e65de1e0b02,unknown)).
node(n1544,supported) :- status(o_b3e04498fa63fb08a414,supported).
node(n1544,refuted) :- status(o_b3e04498fa63fb08a414,refuted).
node(n1544,unknown) :- status(o_b3e04498fa63fb08a414,unknown).
node(n1543,supported) :- node(n1539,supported), node(n1540,supported), node(n1541,supported), node(n1544,supported).
node(n1543,refuted) :- node(n1539,refuted).
node(n1543,refuted) :- node(n1540,refuted).
node(n1543,refuted) :- node(n1541,refuted).
node(n1543,refuted) :- node(n1544,refuted).
node(n1543,unknown) :- \+ node(n1543,supported), \+ node(n1543,refuted).
node(n1542,refuted) :- node(n1543,refuted), node(n9,refuted).
node(n1542,supported) :- node(n1543,supported).
node(n1542,supported) :- node(n9,supported).
node(n1542,unknown) :- \+ node(n1542,supported), \+ node(n1542,refuted).
verdict(c_fc9d85bffefc6d72,supported) :- node(n1542,supported).
query(verdict(c_fc9d85bffefc6d72,supported)).
verdict(c_fc9d85bffefc6d72,refuted) :- node(n1542,refuted).
query(verdict(c_fc9d85bffefc6d72,refuted)).
verdict(c_fc9d85bffefc6d72,unknown) :- node(n1542,unknown).
query(verdict(c_fc9d85bffefc6d72,unknown)).
node(n1547,supported) :- status(o_64bd6401b634c9b5abaf,supported).
node(n1547,refuted) :- status(o_64bd6401b634c9b5abaf,refuted).
node(n1547,unknown) :- status(o_64bd6401b634c9b5abaf,unknown).
node(n1548,supported) :- status(o_a69f88c6f9b7a59d2f3b,supported).
node(n1548,refuted) :- status(o_a69f88c6f9b7a59d2f3b,refuted).
node(n1548,unknown) :- status(o_a69f88c6f9b7a59d2f3b,unknown).
node(n1546,supported) :- node(n1539,supported), node(n1540,supported), node(n1541,supported), node(n1544,supported), node(n1547,supported), node(n1548,supported).
node(n1546,refuted) :- node(n1539,refuted).
node(n1546,refuted) :- node(n1540,refuted).
node(n1546,refuted) :- node(n1541,refuted).
node(n1546,refuted) :- node(n1544,refuted).
node(n1546,refuted) :- node(n1547,refuted).
node(n1546,refuted) :- node(n1548,refuted).
node(n1546,unknown) :- \+ node(n1546,supported), \+ node(n1546,refuted).
node(n1545,refuted) :- node(n1546,refuted), node(n9,refuted).
node(n1545,supported) :- node(n1546,supported).
node(n1545,supported) :- node(n9,supported).
node(n1545,unknown) :- \+ node(n1545,supported), \+ node(n1545,refuted).
verdict(c_2a9c839212deac45,supported) :- node(n1545,supported).
query(verdict(c_2a9c839212deac45,supported)).
verdict(c_2a9c839212deac45,refuted) :- node(n1545,refuted).
query(verdict(c_2a9c839212deac45,refuted)).
verdict(c_2a9c839212deac45,unknown) :- node(n1545,unknown).
query(verdict(c_2a9c839212deac45,unknown)).
node(n1551,supported) :- status(o_0ca91855a63af1aaa5a7,supported).
node(n1551,refuted) :- status(o_0ca91855a63af1aaa5a7,refuted).
node(n1551,unknown) :- status(o_0ca91855a63af1aaa5a7,unknown).
node(n1550,supported) :- node(n1539,supported), node(n1540,supported), node(n1551,supported).
node(n1550,refuted) :- node(n1539,refuted).
node(n1550,refuted) :- node(n1540,refuted).
node(n1550,refuted) :- node(n1551,refuted).
node(n1550,unknown) :- \+ node(n1550,supported), \+ node(n1550,refuted).
node(n1549,refuted) :- node(n1550,refuted), node(n9,refuted).
node(n1549,supported) :- node(n1550,supported).
node(n1549,supported) :- node(n9,supported).
node(n1549,unknown) :- \+ node(n1549,supported), \+ node(n1549,refuted).
verdict(c_6280e0145317085a,supported) :- node(n1549,supported).
query(verdict(c_6280e0145317085a,supported)).
verdict(c_6280e0145317085a,refuted) :- node(n1549,refuted).
query(verdict(c_6280e0145317085a,refuted)).
verdict(c_6280e0145317085a,unknown) :- node(n1549,unknown).
query(verdict(c_6280e0145317085a,unknown)).
node(n1553,supported) :- node(n1539,supported), node(n1540,supported), node(n1541,supported), node(n1551,supported).
node(n1553,refuted) :- node(n1539,refuted).
node(n1553,refuted) :- node(n1540,refuted).
node(n1553,refuted) :- node(n1541,refuted).
node(n1553,refuted) :- node(n1551,refuted).
node(n1553,unknown) :- \+ node(n1553,supported), \+ node(n1553,refuted).
node(n1552,refuted) :- node(n1553,refuted), node(n9,refuted).
node(n1552,supported) :- node(n1553,supported).
node(n1552,supported) :- node(n9,supported).
node(n1552,unknown) :- \+ node(n1552,supported), \+ node(n1552,refuted).
verdict(c_999d1f70621b608f,supported) :- node(n1552,supported).
query(verdict(c_999d1f70621b608f,supported)).
verdict(c_999d1f70621b608f,refuted) :- node(n1552,refuted).
query(verdict(c_999d1f70621b608f,refuted)).
verdict(c_999d1f70621b608f,unknown) :- node(n1552,unknown).
query(verdict(c_999d1f70621b608f,unknown)).
node(n1556,supported) :- status(o_6c7eecf8093795ba1d8d,supported).
node(n1556,refuted) :- status(o_6c7eecf8093795ba1d8d,refuted).
node(n1556,unknown) :- status(o_6c7eecf8093795ba1d8d,unknown).
node(n1557,supported) :- status(o_b948db4b7c6fa9b55a94,supported).
node(n1557,refuted) :- status(o_b948db4b7c6fa9b55a94,refuted).
node(n1557,unknown) :- status(o_b948db4b7c6fa9b55a94,unknown).
node(n1558,supported) :- status(o_d0441a8ef1717855f6d3,supported).
node(n1558,refuted) :- status(o_d0441a8ef1717855f6d3,refuted).
node(n1558,unknown) :- status(o_d0441a8ef1717855f6d3,unknown).
node(n1555,supported) :- node(n1556,supported), node(n1557,supported), node(n1558,supported).
node(n1555,refuted) :- node(n1556,refuted).
node(n1555,refuted) :- node(n1557,refuted).
node(n1555,refuted) :- node(n1558,refuted).
node(n1555,unknown) :- \+ node(n1555,supported), \+ node(n1555,refuted).
node(n1554,refuted) :- node(n1555,refuted), node(n9,refuted).
node(n1554,supported) :- node(n1555,supported).
node(n1554,supported) :- node(n9,supported).
node(n1554,unknown) :- \+ node(n1554,supported), \+ node(n1554,refuted).
verdict(c_833777b5e2b4bd4f,supported) :- node(n1554,supported).
query(verdict(c_833777b5e2b4bd4f,supported)).
verdict(c_833777b5e2b4bd4f,refuted) :- node(n1554,refuted).
query(verdict(c_833777b5e2b4bd4f,refuted)).
verdict(c_833777b5e2b4bd4f,unknown) :- node(n1554,unknown).
query(verdict(c_833777b5e2b4bd4f,unknown)).
node(n1561,supported) :- status(o_a9a71c550435a9b5f458,supported).
node(n1561,refuted) :- status(o_a9a71c550435a9b5f458,refuted).
node(n1561,unknown) :- status(o_a9a71c550435a9b5f458,unknown).
node(n1560,supported) :- node(n1556,supported), node(n1557,supported), node(n1558,supported), node(n1561,supported).
node(n1560,refuted) :- node(n1556,refuted).
node(n1560,refuted) :- node(n1557,refuted).
node(n1560,refuted) :- node(n1558,refuted).
node(n1560,refuted) :- node(n1561,refuted).
node(n1560,unknown) :- \+ node(n1560,supported), \+ node(n1560,refuted).
node(n1559,refuted) :- node(n1560,refuted), node(n9,refuted).
node(n1559,supported) :- node(n1560,supported).
node(n1559,supported) :- node(n9,supported).
node(n1559,unknown) :- \+ node(n1559,supported), \+ node(n1559,refuted).
verdict(c_20a3a77c7b58efc9,supported) :- node(n1559,supported).
query(verdict(c_20a3a77c7b58efc9,supported)).
verdict(c_20a3a77c7b58efc9,refuted) :- node(n1559,refuted).
query(verdict(c_20a3a77c7b58efc9,refuted)).
verdict(c_20a3a77c7b58efc9,unknown) :- node(n1559,unknown).
query(verdict(c_20a3a77c7b58efc9,unknown)).
node(n1564,supported) :- status(o_13a56e61fda7cb3cd81d,supported).
node(n1564,refuted) :- status(o_13a56e61fda7cb3cd81d,refuted).
node(n1564,unknown) :- status(o_13a56e61fda7cb3cd81d,unknown).
node(n1565,supported) :- status(o_8e8fde7fc82198d1e375,supported).
node(n1565,refuted) :- status(o_8e8fde7fc82198d1e375,refuted).
node(n1565,unknown) :- status(o_8e8fde7fc82198d1e375,unknown).
node(n1563,supported) :- node(n1556,supported), node(n1557,supported), node(n1558,supported), node(n1561,supported), node(n1564,supported), node(n1565,supported).
node(n1563,refuted) :- node(n1556,refuted).
node(n1563,refuted) :- node(n1557,refuted).
node(n1563,refuted) :- node(n1558,refuted).
node(n1563,refuted) :- node(n1561,refuted).
node(n1563,refuted) :- node(n1564,refuted).
node(n1563,refuted) :- node(n1565,refuted).
node(n1563,unknown) :- \+ node(n1563,supported), \+ node(n1563,refuted).
node(n1562,refuted) :- node(n1563,refuted), node(n9,refuted).
node(n1562,supported) :- node(n1563,supported).
node(n1562,supported) :- node(n9,supported).
node(n1562,unknown) :- \+ node(n1562,supported), \+ node(n1562,refuted).
verdict(c_591831ed65c37403,supported) :- node(n1562,supported).
query(verdict(c_591831ed65c37403,supported)).
verdict(c_591831ed65c37403,refuted) :- node(n1562,refuted).
query(verdict(c_591831ed65c37403,refuted)).
verdict(c_591831ed65c37403,unknown) :- node(n1562,unknown).
query(verdict(c_591831ed65c37403,unknown)).
node(n1568,supported) :- status(o_4487134dde9b7abefcae,supported).
node(n1568,refuted) :- status(o_4487134dde9b7abefcae,refuted).
node(n1568,unknown) :- status(o_4487134dde9b7abefcae,unknown).
node(n1567,supported) :- node(n1556,supported), node(n1557,supported), node(n1568,supported).
node(n1567,refuted) :- node(n1556,refuted).
node(n1567,refuted) :- node(n1557,refuted).
node(n1567,refuted) :- node(n1568,refuted).
node(n1567,unknown) :- \+ node(n1567,supported), \+ node(n1567,refuted).
node(n1566,refuted) :- node(n1567,refuted), node(n9,refuted).
node(n1566,supported) :- node(n1567,supported).
node(n1566,supported) :- node(n9,supported).
node(n1566,unknown) :- \+ node(n1566,supported), \+ node(n1566,refuted).
verdict(c_e9695e6255bbea8f,supported) :- node(n1566,supported).
query(verdict(c_e9695e6255bbea8f,supported)).
verdict(c_e9695e6255bbea8f,refuted) :- node(n1566,refuted).
query(verdict(c_e9695e6255bbea8f,refuted)).
verdict(c_e9695e6255bbea8f,unknown) :- node(n1566,unknown).
query(verdict(c_e9695e6255bbea8f,unknown)).
node(n1570,supported) :- node(n1556,supported), node(n1557,supported), node(n1558,supported), node(n1568,supported).
node(n1570,refuted) :- node(n1556,refuted).
node(n1570,refuted) :- node(n1557,refuted).
node(n1570,refuted) :- node(n1558,refuted).
node(n1570,refuted) :- node(n1568,refuted).
node(n1570,unknown) :- \+ node(n1570,supported), \+ node(n1570,refuted).
node(n1569,refuted) :- node(n1570,refuted), node(n9,refuted).
node(n1569,supported) :- node(n1570,supported).
node(n1569,supported) :- node(n9,supported).
node(n1569,unknown) :- \+ node(n1569,supported), \+ node(n1569,refuted).
verdict(c_56889af99e46e684,supported) :- node(n1569,supported).
query(verdict(c_56889af99e46e684,supported)).
verdict(c_56889af99e46e684,refuted) :- node(n1569,refuted).
query(verdict(c_56889af99e46e684,refuted)).
verdict(c_56889af99e46e684,unknown) :- node(n1569,unknown).
query(verdict(c_56889af99e46e684,unknown)).
node(n1573,supported) :- status(o_5d4ae964beb7889a3585,supported).
node(n1573,refuted) :- status(o_5d4ae964beb7889a3585,refuted).
node(n1573,unknown) :- status(o_5d4ae964beb7889a3585,unknown).
node(n1574,supported) :- status(o_661f4d5129c617b73504,supported).
node(n1574,refuted) :- status(o_661f4d5129c617b73504,refuted).
node(n1574,unknown) :- status(o_661f4d5129c617b73504,unknown).
node(n1575,supported) :- status(o_2d6e1ac9ff6bbdb38d2b,supported).
node(n1575,refuted) :- status(o_2d6e1ac9ff6bbdb38d2b,refuted).
node(n1575,unknown) :- status(o_2d6e1ac9ff6bbdb38d2b,unknown).
node(n1572,supported) :- node(n1573,supported), node(n1574,supported), node(n1575,supported).
node(n1572,refuted) :- node(n1573,refuted).
node(n1572,refuted) :- node(n1574,refuted).
node(n1572,refuted) :- node(n1575,refuted).
node(n1572,unknown) :- \+ node(n1572,supported), \+ node(n1572,refuted).
node(n1571,refuted) :- node(n1572,refuted), node(n9,refuted).
node(n1571,supported) :- node(n1572,supported).
node(n1571,supported) :- node(n9,supported).
node(n1571,unknown) :- \+ node(n1571,supported), \+ node(n1571,refuted).
verdict(c_6b7da0bc7346994f,supported) :- node(n1571,supported).
query(verdict(c_6b7da0bc7346994f,supported)).
verdict(c_6b7da0bc7346994f,refuted) :- node(n1571,refuted).
query(verdict(c_6b7da0bc7346994f,refuted)).
verdict(c_6b7da0bc7346994f,unknown) :- node(n1571,unknown).
query(verdict(c_6b7da0bc7346994f,unknown)).
node(n1578,supported) :- status(o_70ed7fe4a44b8c614d21,supported).
node(n1578,refuted) :- status(o_70ed7fe4a44b8c614d21,refuted).
node(n1578,unknown) :- status(o_70ed7fe4a44b8c614d21,unknown).
node(n1577,supported) :- node(n1573,supported), node(n1574,supported), node(n1575,supported), node(n1578,supported).
node(n1577,refuted) :- node(n1573,refuted).
node(n1577,refuted) :- node(n1574,refuted).
node(n1577,refuted) :- node(n1575,refuted).
node(n1577,refuted) :- node(n1578,refuted).
node(n1577,unknown) :- \+ node(n1577,supported), \+ node(n1577,refuted).
node(n1576,refuted) :- node(n1577,refuted), node(n9,refuted).
node(n1576,supported) :- node(n1577,supported).
node(n1576,supported) :- node(n9,supported).
node(n1576,unknown) :- \+ node(n1576,supported), \+ node(n1576,refuted).
verdict(c_6f6224f547d6630d,supported) :- node(n1576,supported).
query(verdict(c_6f6224f547d6630d,supported)).
verdict(c_6f6224f547d6630d,refuted) :- node(n1576,refuted).
query(verdict(c_6f6224f547d6630d,refuted)).
verdict(c_6f6224f547d6630d,unknown) :- node(n1576,unknown).
query(verdict(c_6f6224f547d6630d,unknown)).
node(n1581,supported) :- status(o_a5072ac02de3affc9e60,supported).
node(n1581,refuted) :- status(o_a5072ac02de3affc9e60,refuted).
node(n1581,unknown) :- status(o_a5072ac02de3affc9e60,unknown).
node(n1582,supported) :- status(o_88845199cc014e0062dc,supported).
node(n1582,refuted) :- status(o_88845199cc014e0062dc,refuted).
node(n1582,unknown) :- status(o_88845199cc014e0062dc,unknown).
node(n1580,supported) :- node(n1573,supported), node(n1574,supported), node(n1575,supported), node(n1578,supported), node(n1581,supported), node(n1582,supported).
node(n1580,refuted) :- node(n1573,refuted).
node(n1580,refuted) :- node(n1574,refuted).
node(n1580,refuted) :- node(n1575,refuted).
node(n1580,refuted) :- node(n1578,refuted).
node(n1580,refuted) :- node(n1581,refuted).
node(n1580,refuted) :- node(n1582,refuted).
node(n1580,unknown) :- \+ node(n1580,supported), \+ node(n1580,refuted).
node(n1579,refuted) :- node(n1580,refuted), node(n9,refuted).
node(n1579,supported) :- node(n1580,supported).
node(n1579,supported) :- node(n9,supported).
node(n1579,unknown) :- \+ node(n1579,supported), \+ node(n1579,refuted).
verdict(c_c6090faebd3ca996,supported) :- node(n1579,supported).
query(verdict(c_c6090faebd3ca996,supported)).
verdict(c_c6090faebd3ca996,refuted) :- node(n1579,refuted).
query(verdict(c_c6090faebd3ca996,refuted)).
verdict(c_c6090faebd3ca996,unknown) :- node(n1579,unknown).
query(verdict(c_c6090faebd3ca996,unknown)).
node(n1585,supported) :- status(o_1267b4ff73f065d941ea,supported).
node(n1585,refuted) :- status(o_1267b4ff73f065d941ea,refuted).
node(n1585,unknown) :- status(o_1267b4ff73f065d941ea,unknown).
node(n1584,supported) :- node(n1573,supported), node(n1574,supported), node(n1585,supported).
node(n1584,refuted) :- node(n1573,refuted).
node(n1584,refuted) :- node(n1574,refuted).
node(n1584,refuted) :- node(n1585,refuted).
node(n1584,unknown) :- \+ node(n1584,supported), \+ node(n1584,refuted).
node(n1583,refuted) :- node(n1584,refuted), node(n9,refuted).
node(n1583,supported) :- node(n1584,supported).
node(n1583,supported) :- node(n9,supported).
node(n1583,unknown) :- \+ node(n1583,supported), \+ node(n1583,refuted).
verdict(c_333f784a7f0ab99d,supported) :- node(n1583,supported).
query(verdict(c_333f784a7f0ab99d,supported)).
verdict(c_333f784a7f0ab99d,refuted) :- node(n1583,refuted).
query(verdict(c_333f784a7f0ab99d,refuted)).
verdict(c_333f784a7f0ab99d,unknown) :- node(n1583,unknown).
query(verdict(c_333f784a7f0ab99d,unknown)).
node(n1587,supported) :- node(n1573,supported), node(n1574,supported), node(n1575,supported), node(n1585,supported).
node(n1587,refuted) :- node(n1573,refuted).
node(n1587,refuted) :- node(n1574,refuted).
node(n1587,refuted) :- node(n1575,refuted).
node(n1587,refuted) :- node(n1585,refuted).
node(n1587,unknown) :- \+ node(n1587,supported), \+ node(n1587,refuted).
node(n1586,refuted) :- node(n1587,refuted), node(n9,refuted).
node(n1586,supported) :- node(n1587,supported).
node(n1586,supported) :- node(n9,supported).
node(n1586,unknown) :- \+ node(n1586,supported), \+ node(n1586,refuted).
verdict(c_24d74f365480cf6f,supported) :- node(n1586,supported).
query(verdict(c_24d74f365480cf6f,supported)).
verdict(c_24d74f365480cf6f,refuted) :- node(n1586,refuted).
query(verdict(c_24d74f365480cf6f,refuted)).
verdict(c_24d74f365480cf6f,unknown) :- node(n1586,unknown).
query(verdict(c_24d74f365480cf6f,unknown)).
node(n1590,supported) :- status(o_3a57806343106f021d86,supported).
node(n1590,refuted) :- status(o_3a57806343106f021d86,refuted).
node(n1590,unknown) :- status(o_3a57806343106f021d86,unknown).
node(n1591,supported) :- status(o_9fa3d7d2b461709897ef,supported).
node(n1591,refuted) :- status(o_9fa3d7d2b461709897ef,refuted).
node(n1591,unknown) :- status(o_9fa3d7d2b461709897ef,unknown).
node(n1592,supported) :- status(o_784cd4955759eb97970e,supported).
node(n1592,refuted) :- status(o_784cd4955759eb97970e,refuted).
node(n1592,unknown) :- status(o_784cd4955759eb97970e,unknown).
node(n1589,supported) :- node(n1590,supported), node(n1591,supported), node(n1592,supported).
node(n1589,refuted) :- node(n1590,refuted).
node(n1589,refuted) :- node(n1591,refuted).
node(n1589,refuted) :- node(n1592,refuted).
node(n1589,unknown) :- \+ node(n1589,supported), \+ node(n1589,refuted).
node(n1588,refuted) :- node(n1589,refuted), node(n9,refuted).
node(n1588,supported) :- node(n1589,supported).
node(n1588,supported) :- node(n9,supported).
node(n1588,unknown) :- \+ node(n1588,supported), \+ node(n1588,refuted).
verdict(c_0529b2da57dbdbb5,supported) :- node(n1588,supported).
query(verdict(c_0529b2da57dbdbb5,supported)).
verdict(c_0529b2da57dbdbb5,refuted) :- node(n1588,refuted).
query(verdict(c_0529b2da57dbdbb5,refuted)).
verdict(c_0529b2da57dbdbb5,unknown) :- node(n1588,unknown).
query(verdict(c_0529b2da57dbdbb5,unknown)).
node(n1595,supported) :- status(o_559d7d8d7712f2a958e8,supported).
node(n1595,refuted) :- status(o_559d7d8d7712f2a958e8,refuted).
node(n1595,unknown) :- status(o_559d7d8d7712f2a958e8,unknown).
node(n1594,supported) :- node(n1590,supported), node(n1591,supported), node(n1592,supported), node(n1595,supported).
node(n1594,refuted) :- node(n1590,refuted).
node(n1594,refuted) :- node(n1591,refuted).
node(n1594,refuted) :- node(n1592,refuted).
node(n1594,refuted) :- node(n1595,refuted).
node(n1594,unknown) :- \+ node(n1594,supported), \+ node(n1594,refuted).
node(n1593,refuted) :- node(n1594,refuted), node(n9,refuted).
node(n1593,supported) :- node(n1594,supported).
node(n1593,supported) :- node(n9,supported).
node(n1593,unknown) :- \+ node(n1593,supported), \+ node(n1593,refuted).
verdict(c_c4dc094e59ed44b0,supported) :- node(n1593,supported).
query(verdict(c_c4dc094e59ed44b0,supported)).
verdict(c_c4dc094e59ed44b0,refuted) :- node(n1593,refuted).
query(verdict(c_c4dc094e59ed44b0,refuted)).
verdict(c_c4dc094e59ed44b0,unknown) :- node(n1593,unknown).
query(verdict(c_c4dc094e59ed44b0,unknown)).
node(n1598,supported) :- status(o_abb899e60839e5a158ae,supported).
node(n1598,refuted) :- status(o_abb899e60839e5a158ae,refuted).
node(n1598,unknown) :- status(o_abb899e60839e5a158ae,unknown).
node(n1599,supported) :- status(o_4b9a9da51e26ac206ccc,supported).
node(n1599,refuted) :- status(o_4b9a9da51e26ac206ccc,refuted).
node(n1599,unknown) :- status(o_4b9a9da51e26ac206ccc,unknown).
node(n1597,supported) :- node(n1590,supported), node(n1591,supported), node(n1592,supported), node(n1595,supported), node(n1598,supported), node(n1599,supported).
node(n1597,refuted) :- node(n1590,refuted).
node(n1597,refuted) :- node(n1591,refuted).
node(n1597,refuted) :- node(n1592,refuted).
node(n1597,refuted) :- node(n1595,refuted).
node(n1597,refuted) :- node(n1598,refuted).
node(n1597,refuted) :- node(n1599,refuted).
node(n1597,unknown) :- \+ node(n1597,supported), \+ node(n1597,refuted).
node(n1596,refuted) :- node(n1597,refuted), node(n9,refuted).
node(n1596,supported) :- node(n1597,supported).
node(n1596,supported) :- node(n9,supported).
node(n1596,unknown) :- \+ node(n1596,supported), \+ node(n1596,refuted).
verdict(c_7c40e238d3d51179,supported) :- node(n1596,supported).
query(verdict(c_7c40e238d3d51179,supported)).
verdict(c_7c40e238d3d51179,refuted) :- node(n1596,refuted).
query(verdict(c_7c40e238d3d51179,refuted)).
verdict(c_7c40e238d3d51179,unknown) :- node(n1596,unknown).
query(verdict(c_7c40e238d3d51179,unknown)).
node(n1602,supported) :- status(o_939d05a58786e22c90f7,supported).
node(n1602,refuted) :- status(o_939d05a58786e22c90f7,refuted).
node(n1602,unknown) :- status(o_939d05a58786e22c90f7,unknown).
node(n1601,supported) :- node(n1590,supported), node(n1591,supported), node(n1602,supported).
node(n1601,refuted) :- node(n1590,refuted).
node(n1601,refuted) :- node(n1591,refuted).
node(n1601,refuted) :- node(n1602,refuted).
node(n1601,unknown) :- \+ node(n1601,supported), \+ node(n1601,refuted).
node(n1600,refuted) :- node(n1601,refuted), node(n9,refuted).
node(n1600,supported) :- node(n1601,supported).
node(n1600,supported) :- node(n9,supported).
node(n1600,unknown) :- \+ node(n1600,supported), \+ node(n1600,refuted).
verdict(c_3657e97ae91aec44,supported) :- node(n1600,supported).
query(verdict(c_3657e97ae91aec44,supported)).
verdict(c_3657e97ae91aec44,refuted) :- node(n1600,refuted).
query(verdict(c_3657e97ae91aec44,refuted)).
verdict(c_3657e97ae91aec44,unknown) :- node(n1600,unknown).
query(verdict(c_3657e97ae91aec44,unknown)).
node(n1604,supported) :- node(n1590,supported), node(n1591,supported), node(n1592,supported), node(n1602,supported).
node(n1604,refuted) :- node(n1590,refuted).
node(n1604,refuted) :- node(n1591,refuted).
node(n1604,refuted) :- node(n1592,refuted).
node(n1604,refuted) :- node(n1602,refuted).
node(n1604,unknown) :- \+ node(n1604,supported), \+ node(n1604,refuted).
node(n1603,refuted) :- node(n1604,refuted), node(n9,refuted).
node(n1603,supported) :- node(n1604,supported).
node(n1603,supported) :- node(n9,supported).
node(n1603,unknown) :- \+ node(n1603,supported), \+ node(n1603,refuted).
verdict(c_7b04813e28f6feac,supported) :- node(n1603,supported).
query(verdict(c_7b04813e28f6feac,supported)).
verdict(c_7b04813e28f6feac,refuted) :- node(n1603,refuted).
query(verdict(c_7b04813e28f6feac,refuted)).
verdict(c_7b04813e28f6feac,unknown) :- node(n1603,unknown).
query(verdict(c_7b04813e28f6feac,unknown)).
node(n1607,supported) :- status(o_22b1f2e7bcaabd8f0f5d,supported).
node(n1607,refuted) :- status(o_22b1f2e7bcaabd8f0f5d,refuted).
node(n1607,unknown) :- status(o_22b1f2e7bcaabd8f0f5d,unknown).
node(n1608,supported) :- status(o_f8f00c68ec78f1f20fd4,supported).
node(n1608,refuted) :- status(o_f8f00c68ec78f1f20fd4,refuted).
node(n1608,unknown) :- status(o_f8f00c68ec78f1f20fd4,unknown).
node(n1609,supported) :- status(o_461a53eab86e82340b41,supported).
node(n1609,refuted) :- status(o_461a53eab86e82340b41,refuted).
node(n1609,unknown) :- status(o_461a53eab86e82340b41,unknown).
node(n1606,supported) :- node(n1607,supported), node(n1608,supported), node(n1609,supported).
node(n1606,refuted) :- node(n1607,refuted).
node(n1606,refuted) :- node(n1608,refuted).
node(n1606,refuted) :- node(n1609,refuted).
node(n1606,unknown) :- \+ node(n1606,supported), \+ node(n1606,refuted).
node(n1605,refuted) :- node(n1606,refuted), node(n9,refuted).
node(n1605,supported) :- node(n1606,supported).
node(n1605,supported) :- node(n9,supported).
node(n1605,unknown) :- \+ node(n1605,supported), \+ node(n1605,refuted).
verdict(c_9650c5f77e64e35c,supported) :- node(n1605,supported).
query(verdict(c_9650c5f77e64e35c,supported)).
verdict(c_9650c5f77e64e35c,refuted) :- node(n1605,refuted).
query(verdict(c_9650c5f77e64e35c,refuted)).
verdict(c_9650c5f77e64e35c,unknown) :- node(n1605,unknown).
query(verdict(c_9650c5f77e64e35c,unknown)).
node(n1612,supported) :- status(o_555fa9e704c26288dbf5,supported).
node(n1612,refuted) :- status(o_555fa9e704c26288dbf5,refuted).
node(n1612,unknown) :- status(o_555fa9e704c26288dbf5,unknown).
node(n1611,supported) :- node(n1607,supported), node(n1608,supported), node(n1609,supported), node(n1612,supported).
node(n1611,refuted) :- node(n1607,refuted).
node(n1611,refuted) :- node(n1608,refuted).
node(n1611,refuted) :- node(n1609,refuted).
node(n1611,refuted) :- node(n1612,refuted).
node(n1611,unknown) :- \+ node(n1611,supported), \+ node(n1611,refuted).
node(n1610,refuted) :- node(n1611,refuted), node(n9,refuted).
node(n1610,supported) :- node(n1611,supported).
node(n1610,supported) :- node(n9,supported).
node(n1610,unknown) :- \+ node(n1610,supported), \+ node(n1610,refuted).
verdict(c_a1c6aa9cbd190419,supported) :- node(n1610,supported).
query(verdict(c_a1c6aa9cbd190419,supported)).
verdict(c_a1c6aa9cbd190419,refuted) :- node(n1610,refuted).
query(verdict(c_a1c6aa9cbd190419,refuted)).
verdict(c_a1c6aa9cbd190419,unknown) :- node(n1610,unknown).
query(verdict(c_a1c6aa9cbd190419,unknown)).
node(n1615,supported) :- status(o_f5363864bf87b5e9ef38,supported).
node(n1615,refuted) :- status(o_f5363864bf87b5e9ef38,refuted).
node(n1615,unknown) :- status(o_f5363864bf87b5e9ef38,unknown).
node(n1616,supported) :- status(o_c4429c64ed4f656452ef,supported).
node(n1616,refuted) :- status(o_c4429c64ed4f656452ef,refuted).
node(n1616,unknown) :- status(o_c4429c64ed4f656452ef,unknown).
node(n1614,supported) :- node(n1607,supported), node(n1608,supported), node(n1609,supported), node(n1612,supported), node(n1615,supported), node(n1616,supported).
node(n1614,refuted) :- node(n1607,refuted).
node(n1614,refuted) :- node(n1608,refuted).
node(n1614,refuted) :- node(n1609,refuted).
node(n1614,refuted) :- node(n1612,refuted).
node(n1614,refuted) :- node(n1615,refuted).
node(n1614,refuted) :- node(n1616,refuted).
node(n1614,unknown) :- \+ node(n1614,supported), \+ node(n1614,refuted).
node(n1613,refuted) :- node(n1614,refuted), node(n9,refuted).
node(n1613,supported) :- node(n1614,supported).
node(n1613,supported) :- node(n9,supported).
node(n1613,unknown) :- \+ node(n1613,supported), \+ node(n1613,refuted).
verdict(c_84adfc0c7d9a2a21,supported) :- node(n1613,supported).
query(verdict(c_84adfc0c7d9a2a21,supported)).
verdict(c_84adfc0c7d9a2a21,refuted) :- node(n1613,refuted).
query(verdict(c_84adfc0c7d9a2a21,refuted)).
verdict(c_84adfc0c7d9a2a21,unknown) :- node(n1613,unknown).
query(verdict(c_84adfc0c7d9a2a21,unknown)).
node(n1619,supported) :- status(o_83309c1c94c2e088e02d,supported).
node(n1619,refuted) :- status(o_83309c1c94c2e088e02d,refuted).
node(n1619,unknown) :- status(o_83309c1c94c2e088e02d,unknown).
node(n1618,supported) :- node(n1607,supported), node(n1608,supported), node(n1619,supported).
node(n1618,refuted) :- node(n1607,refuted).
node(n1618,refuted) :- node(n1608,refuted).
node(n1618,refuted) :- node(n1619,refuted).
node(n1618,unknown) :- \+ node(n1618,supported), \+ node(n1618,refuted).
node(n1617,refuted) :- node(n1618,refuted), node(n9,refuted).
node(n1617,supported) :- node(n1618,supported).
node(n1617,supported) :- node(n9,supported).
node(n1617,unknown) :- \+ node(n1617,supported), \+ node(n1617,refuted).
verdict(c_3bd6b978f8adfca9,supported) :- node(n1617,supported).
query(verdict(c_3bd6b978f8adfca9,supported)).
verdict(c_3bd6b978f8adfca9,refuted) :- node(n1617,refuted).
query(verdict(c_3bd6b978f8adfca9,refuted)).
verdict(c_3bd6b978f8adfca9,unknown) :- node(n1617,unknown).
query(verdict(c_3bd6b978f8adfca9,unknown)).
node(n1621,supported) :- node(n1607,supported), node(n1608,supported), node(n1609,supported), node(n1619,supported).
node(n1621,refuted) :- node(n1607,refuted).
node(n1621,refuted) :- node(n1608,refuted).
node(n1621,refuted) :- node(n1609,refuted).
node(n1621,refuted) :- node(n1619,refuted).
node(n1621,unknown) :- \+ node(n1621,supported), \+ node(n1621,refuted).
node(n1620,refuted) :- node(n1621,refuted), node(n9,refuted).
node(n1620,supported) :- node(n1621,supported).
node(n1620,supported) :- node(n9,supported).
node(n1620,unknown) :- \+ node(n1620,supported), \+ node(n1620,refuted).
verdict(c_bb492307c75a817c,supported) :- node(n1620,supported).
query(verdict(c_bb492307c75a817c,supported)).
verdict(c_bb492307c75a817c,refuted) :- node(n1620,refuted).
query(verdict(c_bb492307c75a817c,refuted)).
verdict(c_bb492307c75a817c,unknown) :- node(n1620,unknown).
query(verdict(c_bb492307c75a817c,unknown)).
node(n1624,supported) :- status(o_1b7726a15b54c14e5adc,supported).
node(n1624,refuted) :- status(o_1b7726a15b54c14e5adc,refuted).
node(n1624,unknown) :- status(o_1b7726a15b54c14e5adc,unknown).
node(n1625,supported) :- status(o_dd74d631ac51b9a9dcd7,supported).
node(n1625,refuted) :- status(o_dd74d631ac51b9a9dcd7,refuted).
node(n1625,unknown) :- status(o_dd74d631ac51b9a9dcd7,unknown).
node(n1626,supported) :- status(o_3865ba0a763bf419dcfd,supported).
node(n1626,refuted) :- status(o_3865ba0a763bf419dcfd,refuted).
node(n1626,unknown) :- status(o_3865ba0a763bf419dcfd,unknown).
node(n1623,supported) :- node(n1624,supported), node(n1625,supported), node(n1626,supported).
node(n1623,refuted) :- node(n1624,refuted).
node(n1623,refuted) :- node(n1625,refuted).
node(n1623,refuted) :- node(n1626,refuted).
node(n1623,unknown) :- \+ node(n1623,supported), \+ node(n1623,refuted).
node(n1622,refuted) :- node(n1623,refuted), node(n9,refuted).
node(n1622,supported) :- node(n1623,supported).
node(n1622,supported) :- node(n9,supported).
node(n1622,unknown) :- \+ node(n1622,supported), \+ node(n1622,refuted).
verdict(c_fcac416b60dbb804,supported) :- node(n1622,supported).
query(verdict(c_fcac416b60dbb804,supported)).
verdict(c_fcac416b60dbb804,refuted) :- node(n1622,refuted).
query(verdict(c_fcac416b60dbb804,refuted)).
verdict(c_fcac416b60dbb804,unknown) :- node(n1622,unknown).
query(verdict(c_fcac416b60dbb804,unknown)).
node(n1629,supported) :- status(o_62f6bb66337a91ee3b18,supported).
node(n1629,refuted) :- status(o_62f6bb66337a91ee3b18,refuted).
node(n1629,unknown) :- status(o_62f6bb66337a91ee3b18,unknown).
node(n1628,supported) :- node(n1624,supported), node(n1625,supported), node(n1626,supported), node(n1629,supported).
node(n1628,refuted) :- node(n1624,refuted).
node(n1628,refuted) :- node(n1625,refuted).
node(n1628,refuted) :- node(n1626,refuted).
node(n1628,refuted) :- node(n1629,refuted).
node(n1628,unknown) :- \+ node(n1628,supported), \+ node(n1628,refuted).
node(n1627,refuted) :- node(n1628,refuted), node(n9,refuted).
node(n1627,supported) :- node(n1628,supported).
node(n1627,supported) :- node(n9,supported).
node(n1627,unknown) :- \+ node(n1627,supported), \+ node(n1627,refuted).
verdict(c_ea8e3cd30818a954,supported) :- node(n1627,supported).
query(verdict(c_ea8e3cd30818a954,supported)).
verdict(c_ea8e3cd30818a954,refuted) :- node(n1627,refuted).
query(verdict(c_ea8e3cd30818a954,refuted)).
verdict(c_ea8e3cd30818a954,unknown) :- node(n1627,unknown).
query(verdict(c_ea8e3cd30818a954,unknown)).
node(n1632,supported) :- status(o_ba7dee39b29f8d1d9bea,supported).
node(n1632,refuted) :- status(o_ba7dee39b29f8d1d9bea,refuted).
node(n1632,unknown) :- status(o_ba7dee39b29f8d1d9bea,unknown).
node(n1633,supported) :- status(o_869d18c885d1045c40d4,supported).
node(n1633,refuted) :- status(o_869d18c885d1045c40d4,refuted).
node(n1633,unknown) :- status(o_869d18c885d1045c40d4,unknown).
node(n1631,supported) :- node(n1624,supported), node(n1625,supported), node(n1626,supported), node(n1629,supported), node(n1632,supported), node(n1633,supported).
node(n1631,refuted) :- node(n1624,refuted).
node(n1631,refuted) :- node(n1625,refuted).
node(n1631,refuted) :- node(n1626,refuted).
node(n1631,refuted) :- node(n1629,refuted).
node(n1631,refuted) :- node(n1632,refuted).
node(n1631,refuted) :- node(n1633,refuted).
node(n1631,unknown) :- \+ node(n1631,supported), \+ node(n1631,refuted).
node(n1630,refuted) :- node(n1631,refuted), node(n9,refuted).
node(n1630,supported) :- node(n1631,supported).
node(n1630,supported) :- node(n9,supported).
node(n1630,unknown) :- \+ node(n1630,supported), \+ node(n1630,refuted).
verdict(c_f4beb3adf203d89f,supported) :- node(n1630,supported).
query(verdict(c_f4beb3adf203d89f,supported)).
verdict(c_f4beb3adf203d89f,refuted) :- node(n1630,refuted).
query(verdict(c_f4beb3adf203d89f,refuted)).
verdict(c_f4beb3adf203d89f,unknown) :- node(n1630,unknown).
query(verdict(c_f4beb3adf203d89f,unknown)).
node(n1636,supported) :- status(o_abdb1258e0f2118dd6d1,supported).
node(n1636,refuted) :- status(o_abdb1258e0f2118dd6d1,refuted).
node(n1636,unknown) :- status(o_abdb1258e0f2118dd6d1,unknown).
node(n1635,supported) :- node(n1624,supported), node(n1625,supported), node(n1636,supported).
node(n1635,refuted) :- node(n1624,refuted).
node(n1635,refuted) :- node(n1625,refuted).
node(n1635,refuted) :- node(n1636,refuted).
node(n1635,unknown) :- \+ node(n1635,supported), \+ node(n1635,refuted).
node(n1634,refuted) :- node(n1635,refuted), node(n9,refuted).
node(n1634,supported) :- node(n1635,supported).
node(n1634,supported) :- node(n9,supported).
node(n1634,unknown) :- \+ node(n1634,supported), \+ node(n1634,refuted).
verdict(c_6d18549b9aa4c84e,supported) :- node(n1634,supported).
query(verdict(c_6d18549b9aa4c84e,supported)).
verdict(c_6d18549b9aa4c84e,refuted) :- node(n1634,refuted).
query(verdict(c_6d18549b9aa4c84e,refuted)).
verdict(c_6d18549b9aa4c84e,unknown) :- node(n1634,unknown).
query(verdict(c_6d18549b9aa4c84e,unknown)).
node(n1638,supported) :- node(n1624,supported), node(n1625,supported), node(n1626,supported), node(n1636,supported).
node(n1638,refuted) :- node(n1624,refuted).
node(n1638,refuted) :- node(n1625,refuted).
node(n1638,refuted) :- node(n1626,refuted).
node(n1638,refuted) :- node(n1636,refuted).
node(n1638,unknown) :- \+ node(n1638,supported), \+ node(n1638,refuted).
node(n1637,refuted) :- node(n1638,refuted), node(n9,refuted).
node(n1637,supported) :- node(n1638,supported).
node(n1637,supported) :- node(n9,supported).
node(n1637,unknown) :- \+ node(n1637,supported), \+ node(n1637,refuted).
verdict(c_73b8af78ffef6959,supported) :- node(n1637,supported).
query(verdict(c_73b8af78ffef6959,supported)).
verdict(c_73b8af78ffef6959,refuted) :- node(n1637,refuted).
query(verdict(c_73b8af78ffef6959,refuted)).
verdict(c_73b8af78ffef6959,unknown) :- node(n1637,unknown).
query(verdict(c_73b8af78ffef6959,unknown)).
node(n1641,supported) :- status(o_a6edad1c2656c19e55e5,supported).
node(n1641,refuted) :- status(o_a6edad1c2656c19e55e5,refuted).
node(n1641,unknown) :- status(o_a6edad1c2656c19e55e5,unknown).
node(n1642,supported) :- status(o_98aa5efa2a7111a8692d,supported).
node(n1642,refuted) :- status(o_98aa5efa2a7111a8692d,refuted).
node(n1642,unknown) :- status(o_98aa5efa2a7111a8692d,unknown).
node(n1643,supported) :- status(o_2456133848944474da7b,supported).
node(n1643,refuted) :- status(o_2456133848944474da7b,refuted).
node(n1643,unknown) :- status(o_2456133848944474da7b,unknown).
node(n1640,supported) :- node(n1641,supported), node(n1642,supported), node(n1643,supported).
node(n1640,refuted) :- node(n1641,refuted).
node(n1640,refuted) :- node(n1642,refuted).
node(n1640,refuted) :- node(n1643,refuted).
node(n1640,unknown) :- \+ node(n1640,supported), \+ node(n1640,refuted).
node(n1645,supported) :- status(o_1e7b30b94b6863f2e644,supported).
node(n1645,refuted) :- status(o_1e7b30b94b6863f2e644,refuted).
node(n1645,unknown) :- status(o_1e7b30b94b6863f2e644,unknown).
node(n1646,supported) :- status(o_ee68725bfe35b557701a,supported).
node(n1646,refuted) :- status(o_ee68725bfe35b557701a,refuted).
node(n1646,unknown) :- status(o_ee68725bfe35b557701a,unknown).
node(n1647,supported) :- status(o_b6198dcb4c517634438d,supported).
node(n1647,refuted) :- status(o_b6198dcb4c517634438d,refuted).
node(n1647,unknown) :- status(o_b6198dcb4c517634438d,unknown).
node(n1644,supported) :- node(n1645,supported), node(n1646,supported), node(n1647,supported).
node(n1644,refuted) :- node(n1645,refuted).
node(n1644,refuted) :- node(n1646,refuted).
node(n1644,refuted) :- node(n1647,refuted).
node(n1644,unknown) :- \+ node(n1644,supported), \+ node(n1644,refuted).
node(n1639,refuted) :- node(n1640,refuted), node(n1644,refuted), node(n9,refuted).
node(n1639,supported) :- node(n1640,supported).
node(n1639,supported) :- node(n1644,supported).
node(n1639,supported) :- node(n9,supported).
node(n1639,unknown) :- \+ node(n1639,supported), \+ node(n1639,refuted).
verdict(c_3d94c32bd4d90f46,supported) :- node(n1639,supported).
query(verdict(c_3d94c32bd4d90f46,supported)).
verdict(c_3d94c32bd4d90f46,refuted) :- node(n1639,refuted).
query(verdict(c_3d94c32bd4d90f46,refuted)).
verdict(c_3d94c32bd4d90f46,unknown) :- node(n1639,unknown).
query(verdict(c_3d94c32bd4d90f46,unknown)).
node(n1650,supported) :- status(o_beb8ca0934ea0da80a69,supported).
node(n1650,refuted) :- status(o_beb8ca0934ea0da80a69,refuted).
node(n1650,unknown) :- status(o_beb8ca0934ea0da80a69,unknown).
node(n1649,supported) :- node(n1641,supported), node(n1642,supported), node(n1643,supported), node(n1650,supported).
node(n1649,refuted) :- node(n1641,refuted).
node(n1649,refuted) :- node(n1642,refuted).
node(n1649,refuted) :- node(n1643,refuted).
node(n1649,refuted) :- node(n1650,refuted).
node(n1649,unknown) :- \+ node(n1649,supported), \+ node(n1649,refuted).
node(n1652,supported) :- status(o_b582f00dbc271d39f4a1,supported).
node(n1652,refuted) :- status(o_b582f00dbc271d39f4a1,refuted).
node(n1652,unknown) :- status(o_b582f00dbc271d39f4a1,unknown).
node(n1651,supported) :- node(n1645,supported), node(n1646,supported), node(n1647,supported), node(n1652,supported).
node(n1651,refuted) :- node(n1645,refuted).
node(n1651,refuted) :- node(n1646,refuted).
node(n1651,refuted) :- node(n1647,refuted).
node(n1651,refuted) :- node(n1652,refuted).
node(n1651,unknown) :- \+ node(n1651,supported), \+ node(n1651,refuted).
node(n1648,refuted) :- node(n1649,refuted), node(n1651,refuted), node(n9,refuted).
node(n1648,supported) :- node(n1649,supported).
node(n1648,supported) :- node(n1651,supported).
node(n1648,supported) :- node(n9,supported).
node(n1648,unknown) :- \+ node(n1648,supported), \+ node(n1648,refuted).
verdict(c_dd7ff876e40efdfa,supported) :- node(n1648,supported).
query(verdict(c_dd7ff876e40efdfa,supported)).
verdict(c_dd7ff876e40efdfa,refuted) :- node(n1648,refuted).
query(verdict(c_dd7ff876e40efdfa,refuted)).
verdict(c_dd7ff876e40efdfa,unknown) :- node(n1648,unknown).
query(verdict(c_dd7ff876e40efdfa,unknown)).
node(n1655,supported) :- status(o_af1d606e17ce67c123e7,supported).
node(n1655,refuted) :- status(o_af1d606e17ce67c123e7,refuted).
node(n1655,unknown) :- status(o_af1d606e17ce67c123e7,unknown).
node(n1656,supported) :- status(o_34ff47e94f640bd7afd1,supported).
node(n1656,refuted) :- status(o_34ff47e94f640bd7afd1,refuted).
node(n1656,unknown) :- status(o_34ff47e94f640bd7afd1,unknown).
node(n1654,supported) :- node(n1641,supported), node(n1642,supported), node(n1643,supported), node(n1650,supported), node(n1655,supported), node(n1656,supported).
node(n1654,refuted) :- node(n1641,refuted).
node(n1654,refuted) :- node(n1642,refuted).
node(n1654,refuted) :- node(n1643,refuted).
node(n1654,refuted) :- node(n1650,refuted).
node(n1654,refuted) :- node(n1655,refuted).
node(n1654,refuted) :- node(n1656,refuted).
node(n1654,unknown) :- \+ node(n1654,supported), \+ node(n1654,refuted).
node(n1658,supported) :- status(o_34850de3a5531348864d,supported).
node(n1658,refuted) :- status(o_34850de3a5531348864d,refuted).
node(n1658,unknown) :- status(o_34850de3a5531348864d,unknown).
node(n1659,supported) :- status(o_194e0cfef17333878f05,supported).
node(n1659,refuted) :- status(o_194e0cfef17333878f05,refuted).
node(n1659,unknown) :- status(o_194e0cfef17333878f05,unknown).
node(n1657,supported) :- node(n1645,supported), node(n1646,supported), node(n1647,supported), node(n1652,supported), node(n1658,supported), node(n1659,supported).
node(n1657,refuted) :- node(n1645,refuted).
node(n1657,refuted) :- node(n1646,refuted).
node(n1657,refuted) :- node(n1647,refuted).
node(n1657,refuted) :- node(n1652,refuted).
node(n1657,refuted) :- node(n1658,refuted).
node(n1657,refuted) :- node(n1659,refuted).
node(n1657,unknown) :- \+ node(n1657,supported), \+ node(n1657,refuted).
node(n1653,refuted) :- node(n1654,refuted), node(n1657,refuted), node(n9,refuted).
node(n1653,supported) :- node(n1654,supported).
node(n1653,supported) :- node(n1657,supported).
node(n1653,supported) :- node(n9,supported).
node(n1653,unknown) :- \+ node(n1653,supported), \+ node(n1653,refuted).
verdict(c_affc104fa424294f,supported) :- node(n1653,supported).
query(verdict(c_affc104fa424294f,supported)).
verdict(c_affc104fa424294f,refuted) :- node(n1653,refuted).
query(verdict(c_affc104fa424294f,refuted)).
verdict(c_affc104fa424294f,unknown) :- node(n1653,unknown).
query(verdict(c_affc104fa424294f,unknown)).
node(n1662,supported) :- status(o_81f242b2e6a2ebcae6f1,supported).
node(n1662,refuted) :- status(o_81f242b2e6a2ebcae6f1,refuted).
node(n1662,unknown) :- status(o_81f242b2e6a2ebcae6f1,unknown).
node(n1661,supported) :- node(n1641,supported), node(n1642,supported), node(n1662,supported).
node(n1661,refuted) :- node(n1641,refuted).
node(n1661,refuted) :- node(n1642,refuted).
node(n1661,refuted) :- node(n1662,refuted).
node(n1661,unknown) :- \+ node(n1661,supported), \+ node(n1661,refuted).
node(n1664,supported) :- status(o_df02bb542c259975a561,supported).
node(n1664,refuted) :- status(o_df02bb542c259975a561,refuted).
node(n1664,unknown) :- status(o_df02bb542c259975a561,unknown).
node(n1663,supported) :- node(n1645,supported), node(n1646,supported), node(n1664,supported).
node(n1663,refuted) :- node(n1645,refuted).
node(n1663,refuted) :- node(n1646,refuted).
node(n1663,refuted) :- node(n1664,refuted).
node(n1663,unknown) :- \+ node(n1663,supported), \+ node(n1663,refuted).
node(n1660,refuted) :- node(n1661,refuted), node(n1663,refuted), node(n9,refuted).
node(n1660,supported) :- node(n1661,supported).
node(n1660,supported) :- node(n1663,supported).
node(n1660,supported) :- node(n9,supported).
node(n1660,unknown) :- \+ node(n1660,supported), \+ node(n1660,refuted).
verdict(c_fa189835b42529e1,supported) :- node(n1660,supported).
query(verdict(c_fa189835b42529e1,supported)).
verdict(c_fa189835b42529e1,refuted) :- node(n1660,refuted).
query(verdict(c_fa189835b42529e1,refuted)).
verdict(c_fa189835b42529e1,unknown) :- node(n1660,unknown).
query(verdict(c_fa189835b42529e1,unknown)).
node(n1666,supported) :- node(n1641,supported), node(n1642,supported), node(n1643,supported), node(n1662,supported).
node(n1666,refuted) :- node(n1641,refuted).
node(n1666,refuted) :- node(n1642,refuted).
node(n1666,refuted) :- node(n1643,refuted).
node(n1666,refuted) :- node(n1662,refuted).
node(n1666,unknown) :- \+ node(n1666,supported), \+ node(n1666,refuted).
node(n1667,supported) :- node(n1645,supported), node(n1646,supported), node(n1647,supported), node(n1664,supported).
node(n1667,refuted) :- node(n1645,refuted).
node(n1667,refuted) :- node(n1646,refuted).
node(n1667,refuted) :- node(n1647,refuted).
node(n1667,refuted) :- node(n1664,refuted).
node(n1667,unknown) :- \+ node(n1667,supported), \+ node(n1667,refuted).
node(n1665,refuted) :- node(n1666,refuted), node(n1667,refuted), node(n9,refuted).
node(n1665,supported) :- node(n1666,supported).
node(n1665,supported) :- node(n1667,supported).
node(n1665,supported) :- node(n9,supported).
node(n1665,unknown) :- \+ node(n1665,supported), \+ node(n1665,refuted).
verdict(c_8bfb4af1f189bc44,supported) :- node(n1665,supported).
query(verdict(c_8bfb4af1f189bc44,supported)).
verdict(c_8bfb4af1f189bc44,refuted) :- node(n1665,refuted).
query(verdict(c_8bfb4af1f189bc44,refuted)).
verdict(c_8bfb4af1f189bc44,unknown) :- node(n1665,unknown).
query(verdict(c_8bfb4af1f189bc44,unknown)).
node(n1670,supported) :- status(o_7234cc02dcbd8f5aa9cd,supported).
node(n1670,refuted) :- status(o_7234cc02dcbd8f5aa9cd,refuted).
node(n1670,unknown) :- status(o_7234cc02dcbd8f5aa9cd,unknown).
node(n1671,supported) :- status(o_ab3a6fda92bd5e97f565,supported).
node(n1671,refuted) :- status(o_ab3a6fda92bd5e97f565,refuted).
node(n1671,unknown) :- status(o_ab3a6fda92bd5e97f565,unknown).
node(n1672,supported) :- status(o_13ff7d2497bad4b5c23c,supported).
node(n1672,refuted) :- status(o_13ff7d2497bad4b5c23c,refuted).
node(n1672,unknown) :- status(o_13ff7d2497bad4b5c23c,unknown).
node(n1669,supported) :- node(n1670,supported), node(n1671,supported), node(n1672,supported).
node(n1669,refuted) :- node(n1670,refuted).
node(n1669,refuted) :- node(n1671,refuted).
node(n1669,refuted) :- node(n1672,refuted).
node(n1669,unknown) :- \+ node(n1669,supported), \+ node(n1669,refuted).
node(n1674,supported) :- status(o_001df7a39756b9be90e7,supported).
node(n1674,refuted) :- status(o_001df7a39756b9be90e7,refuted).
node(n1674,unknown) :- status(o_001df7a39756b9be90e7,unknown).
node(n1675,supported) :- status(o_41f64795b55d5ec5c7f4,supported).
node(n1675,refuted) :- status(o_41f64795b55d5ec5c7f4,refuted).
node(n1675,unknown) :- status(o_41f64795b55d5ec5c7f4,unknown).
node(n1676,supported) :- status(o_8484e9496ee04402cc6f,supported).
node(n1676,refuted) :- status(o_8484e9496ee04402cc6f,refuted).
node(n1676,unknown) :- status(o_8484e9496ee04402cc6f,unknown).
node(n1673,supported) :- node(n1674,supported), node(n1675,supported), node(n1676,supported).
node(n1673,refuted) :- node(n1674,refuted).
node(n1673,refuted) :- node(n1675,refuted).
node(n1673,refuted) :- node(n1676,refuted).
node(n1673,unknown) :- \+ node(n1673,supported), \+ node(n1673,refuted).
node(n1668,refuted) :- node(n1669,refuted), node(n1673,refuted), node(n9,refuted).
node(n1668,supported) :- node(n1669,supported).
node(n1668,supported) :- node(n1673,supported).
node(n1668,supported) :- node(n9,supported).
node(n1668,unknown) :- \+ node(n1668,supported), \+ node(n1668,refuted).
verdict(c_b16e2e8e2e7c3c17,supported) :- node(n1668,supported).
query(verdict(c_b16e2e8e2e7c3c17,supported)).
verdict(c_b16e2e8e2e7c3c17,refuted) :- node(n1668,refuted).
query(verdict(c_b16e2e8e2e7c3c17,refuted)).
verdict(c_b16e2e8e2e7c3c17,unknown) :- node(n1668,unknown).
query(verdict(c_b16e2e8e2e7c3c17,unknown)).
node(n1679,supported) :- status(o_8333724971b1c67b144a,supported).
node(n1679,refuted) :- status(o_8333724971b1c67b144a,refuted).
node(n1679,unknown) :- status(o_8333724971b1c67b144a,unknown).
node(n1678,supported) :- node(n1670,supported), node(n1671,supported), node(n1672,supported), node(n1679,supported).
node(n1678,refuted) :- node(n1670,refuted).
node(n1678,refuted) :- node(n1671,refuted).
node(n1678,refuted) :- node(n1672,refuted).
node(n1678,refuted) :- node(n1679,refuted).
node(n1678,unknown) :- \+ node(n1678,supported), \+ node(n1678,refuted).
node(n1681,supported) :- status(o_8b65271d2845166eacc8,supported).
node(n1681,refuted) :- status(o_8b65271d2845166eacc8,refuted).
node(n1681,unknown) :- status(o_8b65271d2845166eacc8,unknown).
node(n1680,supported) :- node(n1674,supported), node(n1675,supported), node(n1676,supported), node(n1681,supported).
node(n1680,refuted) :- node(n1674,refuted).
node(n1680,refuted) :- node(n1675,refuted).
node(n1680,refuted) :- node(n1676,refuted).
node(n1680,refuted) :- node(n1681,refuted).
node(n1680,unknown) :- \+ node(n1680,supported), \+ node(n1680,refuted).
node(n1677,refuted) :- node(n1678,refuted), node(n1680,refuted), node(n9,refuted).
node(n1677,supported) :- node(n1678,supported).
node(n1677,supported) :- node(n1680,supported).
node(n1677,supported) :- node(n9,supported).
node(n1677,unknown) :- \+ node(n1677,supported), \+ node(n1677,refuted).
verdict(c_b4c89c4b44b981bb,supported) :- node(n1677,supported).
query(verdict(c_b4c89c4b44b981bb,supported)).
verdict(c_b4c89c4b44b981bb,refuted) :- node(n1677,refuted).
query(verdict(c_b4c89c4b44b981bb,refuted)).
verdict(c_b4c89c4b44b981bb,unknown) :- node(n1677,unknown).
query(verdict(c_b4c89c4b44b981bb,unknown)).
node(n1684,supported) :- status(o_c8d1035e474234fb70cf,supported).
node(n1684,refuted) :- status(o_c8d1035e474234fb70cf,refuted).
node(n1684,unknown) :- status(o_c8d1035e474234fb70cf,unknown).
node(n1685,supported) :- status(o_e27ecf9569131766aceb,supported).
node(n1685,refuted) :- status(o_e27ecf9569131766aceb,refuted).
node(n1685,unknown) :- status(o_e27ecf9569131766aceb,unknown).
node(n1683,supported) :- node(n1670,supported), node(n1671,supported), node(n1672,supported), node(n1679,supported), node(n1684,supported), node(n1685,supported).
node(n1683,refuted) :- node(n1670,refuted).
node(n1683,refuted) :- node(n1671,refuted).
node(n1683,refuted) :- node(n1672,refuted).
node(n1683,refuted) :- node(n1679,refuted).
node(n1683,refuted) :- node(n1684,refuted).
node(n1683,refuted) :- node(n1685,refuted).
node(n1683,unknown) :- \+ node(n1683,supported), \+ node(n1683,refuted).
node(n1687,supported) :- status(o_13ab81dc81a5bfe5bccf,supported).
node(n1687,refuted) :- status(o_13ab81dc81a5bfe5bccf,refuted).
node(n1687,unknown) :- status(o_13ab81dc81a5bfe5bccf,unknown).
node(n1688,supported) :- status(o_6d563875386c9825546f,supported).
node(n1688,refuted) :- status(o_6d563875386c9825546f,refuted).
node(n1688,unknown) :- status(o_6d563875386c9825546f,unknown).
node(n1686,supported) :- node(n1674,supported), node(n1675,supported), node(n1676,supported), node(n1681,supported), node(n1687,supported), node(n1688,supported).
node(n1686,refuted) :- node(n1674,refuted).
node(n1686,refuted) :- node(n1675,refuted).
node(n1686,refuted) :- node(n1676,refuted).
node(n1686,refuted) :- node(n1681,refuted).
node(n1686,refuted) :- node(n1687,refuted).
node(n1686,refuted) :- node(n1688,refuted).
node(n1686,unknown) :- \+ node(n1686,supported), \+ node(n1686,refuted).
node(n1682,refuted) :- node(n1683,refuted), node(n1686,refuted), node(n9,refuted).
node(n1682,supported) :- node(n1683,supported).
node(n1682,supported) :- node(n1686,supported).
node(n1682,supported) :- node(n9,supported).
node(n1682,unknown) :- \+ node(n1682,supported), \+ node(n1682,refuted).
verdict(c_811f658e299ff694,supported) :- node(n1682,supported).
query(verdict(c_811f658e299ff694,supported)).
verdict(c_811f658e299ff694,refuted) :- node(n1682,refuted).
query(verdict(c_811f658e299ff694,refuted)).
verdict(c_811f658e299ff694,unknown) :- node(n1682,unknown).
query(verdict(c_811f658e299ff694,unknown)).
node(n1691,supported) :- status(o_4652dffdd9046fb67582,supported).
node(n1691,refuted) :- status(o_4652dffdd9046fb67582,refuted).
node(n1691,unknown) :- status(o_4652dffdd9046fb67582,unknown).
node(n1690,supported) :- node(n1670,supported), node(n1671,supported), node(n1691,supported).
node(n1690,refuted) :- node(n1670,refuted).
node(n1690,refuted) :- node(n1671,refuted).
node(n1690,refuted) :- node(n1691,refuted).
node(n1690,unknown) :- \+ node(n1690,supported), \+ node(n1690,refuted).
node(n1693,supported) :- status(o_04e4f823e5e8ff9b2cb6,supported).
node(n1693,refuted) :- status(o_04e4f823e5e8ff9b2cb6,refuted).
node(n1693,unknown) :- status(o_04e4f823e5e8ff9b2cb6,unknown).
node(n1692,supported) :- node(n1674,supported), node(n1675,supported), node(n1693,supported).
node(n1692,refuted) :- node(n1674,refuted).
node(n1692,refuted) :- node(n1675,refuted).
node(n1692,refuted) :- node(n1693,refuted).
node(n1692,unknown) :- \+ node(n1692,supported), \+ node(n1692,refuted).
node(n1689,refuted) :- node(n1690,refuted), node(n1692,refuted), node(n9,refuted).
node(n1689,supported) :- node(n1690,supported).
node(n1689,supported) :- node(n1692,supported).
node(n1689,supported) :- node(n9,supported).
node(n1689,unknown) :- \+ node(n1689,supported), \+ node(n1689,refuted).
verdict(c_29fd8c00ebcb59d6,supported) :- node(n1689,supported).
query(verdict(c_29fd8c00ebcb59d6,supported)).
verdict(c_29fd8c00ebcb59d6,refuted) :- node(n1689,refuted).
query(verdict(c_29fd8c00ebcb59d6,refuted)).
verdict(c_29fd8c00ebcb59d6,unknown) :- node(n1689,unknown).
query(verdict(c_29fd8c00ebcb59d6,unknown)).
node(n1695,supported) :- node(n1670,supported), node(n1671,supported), node(n1672,supported), node(n1691,supported).
node(n1695,refuted) :- node(n1670,refuted).
node(n1695,refuted) :- node(n1671,refuted).
node(n1695,refuted) :- node(n1672,refuted).
node(n1695,refuted) :- node(n1691,refuted).
node(n1695,unknown) :- \+ node(n1695,supported), \+ node(n1695,refuted).
node(n1696,supported) :- node(n1674,supported), node(n1675,supported), node(n1676,supported), node(n1693,supported).
node(n1696,refuted) :- node(n1674,refuted).
node(n1696,refuted) :- node(n1675,refuted).
node(n1696,refuted) :- node(n1676,refuted).
node(n1696,refuted) :- node(n1693,refuted).
node(n1696,unknown) :- \+ node(n1696,supported), \+ node(n1696,refuted).
node(n1694,refuted) :- node(n1695,refuted), node(n1696,refuted), node(n9,refuted).
node(n1694,supported) :- node(n1695,supported).
node(n1694,supported) :- node(n1696,supported).
node(n1694,supported) :- node(n9,supported).
node(n1694,unknown) :- \+ node(n1694,supported), \+ node(n1694,refuted).
verdict(c_18e95ad3ed2858bd,supported) :- node(n1694,supported).
query(verdict(c_18e95ad3ed2858bd,supported)).
verdict(c_18e95ad3ed2858bd,refuted) :- node(n1694,refuted).
query(verdict(c_18e95ad3ed2858bd,refuted)).
verdict(c_18e95ad3ed2858bd,unknown) :- node(n1694,unknown).
query(verdict(c_18e95ad3ed2858bd,unknown)).
node(n1699,supported) :- status(o_02646096a93a00fa1955,supported).
node(n1699,refuted) :- status(o_02646096a93a00fa1955,refuted).
node(n1699,unknown) :- status(o_02646096a93a00fa1955,unknown).
node(n1700,supported) :- status(o_3f7f52bce0c1f3f89081,supported).
node(n1700,refuted) :- status(o_3f7f52bce0c1f3f89081,refuted).
node(n1700,unknown) :- status(o_3f7f52bce0c1f3f89081,unknown).
node(n1701,supported) :- status(o_c996c2d2227b47950eb5,supported).
node(n1701,refuted) :- status(o_c996c2d2227b47950eb5,refuted).
node(n1701,unknown) :- status(o_c996c2d2227b47950eb5,unknown).
node(n1698,supported) :- node(n1699,supported), node(n1700,supported), node(n1701,supported).
node(n1698,refuted) :- node(n1699,refuted).
node(n1698,refuted) :- node(n1700,refuted).
node(n1698,refuted) :- node(n1701,refuted).
node(n1698,unknown) :- \+ node(n1698,supported), \+ node(n1698,refuted).
node(n1703,supported) :- status(o_396aca41adbc1fecbc40,supported).
node(n1703,refuted) :- status(o_396aca41adbc1fecbc40,refuted).
node(n1703,unknown) :- status(o_396aca41adbc1fecbc40,unknown).
node(n1704,supported) :- status(o_c5fa2eaf7c2981fdff97,supported).
node(n1704,refuted) :- status(o_c5fa2eaf7c2981fdff97,refuted).
node(n1704,unknown) :- status(o_c5fa2eaf7c2981fdff97,unknown).
node(n1705,supported) :- status(o_a1482db353d2f3756a89,supported).
node(n1705,refuted) :- status(o_a1482db353d2f3756a89,refuted).
node(n1705,unknown) :- status(o_a1482db353d2f3756a89,unknown).
node(n1702,supported) :- node(n1703,supported), node(n1704,supported), node(n1705,supported).
node(n1702,refuted) :- node(n1703,refuted).
node(n1702,refuted) :- node(n1704,refuted).
node(n1702,refuted) :- node(n1705,refuted).
node(n1702,unknown) :- \+ node(n1702,supported), \+ node(n1702,refuted).
node(n1697,refuted) :- node(n1698,refuted), node(n1702,refuted), node(n9,refuted).
node(n1697,supported) :- node(n1698,supported).
node(n1697,supported) :- node(n1702,supported).
node(n1697,supported) :- node(n9,supported).
node(n1697,unknown) :- \+ node(n1697,supported), \+ node(n1697,refuted).
verdict(c_f2ae0cec555524bd,supported) :- node(n1697,supported).
query(verdict(c_f2ae0cec555524bd,supported)).
verdict(c_f2ae0cec555524bd,refuted) :- node(n1697,refuted).
query(verdict(c_f2ae0cec555524bd,refuted)).
verdict(c_f2ae0cec555524bd,unknown) :- node(n1697,unknown).
query(verdict(c_f2ae0cec555524bd,unknown)).
node(n1708,supported) :- status(o_31b7f88749056815651e,supported).
node(n1708,refuted) :- status(o_31b7f88749056815651e,refuted).
node(n1708,unknown) :- status(o_31b7f88749056815651e,unknown).
node(n1707,supported) :- node(n1699,supported), node(n1700,supported), node(n1701,supported), node(n1708,supported).
node(n1707,refuted) :- node(n1699,refuted).
node(n1707,refuted) :- node(n1700,refuted).
node(n1707,refuted) :- node(n1701,refuted).
node(n1707,refuted) :- node(n1708,refuted).
node(n1707,unknown) :- \+ node(n1707,supported), \+ node(n1707,refuted).
node(n1710,supported) :- status(o_d5705b273125818b726a,supported).
node(n1710,refuted) :- status(o_d5705b273125818b726a,refuted).
node(n1710,unknown) :- status(o_d5705b273125818b726a,unknown).
node(n1709,supported) :- node(n1703,supported), node(n1704,supported), node(n1705,supported), node(n1710,supported).
node(n1709,refuted) :- node(n1703,refuted).
node(n1709,refuted) :- node(n1704,refuted).
node(n1709,refuted) :- node(n1705,refuted).
node(n1709,refuted) :- node(n1710,refuted).
node(n1709,unknown) :- \+ node(n1709,supported), \+ node(n1709,refuted).
node(n1706,refuted) :- node(n1707,refuted), node(n1709,refuted), node(n9,refuted).
node(n1706,supported) :- node(n1707,supported).
node(n1706,supported) :- node(n1709,supported).
node(n1706,supported) :- node(n9,supported).
node(n1706,unknown) :- \+ node(n1706,supported), \+ node(n1706,refuted).
verdict(c_314100b2e5649d80,supported) :- node(n1706,supported).
query(verdict(c_314100b2e5649d80,supported)).
verdict(c_314100b2e5649d80,refuted) :- node(n1706,refuted).
query(verdict(c_314100b2e5649d80,refuted)).
verdict(c_314100b2e5649d80,unknown) :- node(n1706,unknown).
query(verdict(c_314100b2e5649d80,unknown)).
node(n1713,supported) :- status(o_6fcbb4c83dc4b4103b50,supported).
node(n1713,refuted) :- status(o_6fcbb4c83dc4b4103b50,refuted).
node(n1713,unknown) :- status(o_6fcbb4c83dc4b4103b50,unknown).
node(n1714,supported) :- status(o_23b2d03d8fefee4eb775,supported).
node(n1714,refuted) :- status(o_23b2d03d8fefee4eb775,refuted).
node(n1714,unknown) :- status(o_23b2d03d8fefee4eb775,unknown).
node(n1712,supported) :- node(n1699,supported), node(n1700,supported), node(n1701,supported), node(n1708,supported), node(n1713,supported), node(n1714,supported).
node(n1712,refuted) :- node(n1699,refuted).
node(n1712,refuted) :- node(n1700,refuted).
node(n1712,refuted) :- node(n1701,refuted).
node(n1712,refuted) :- node(n1708,refuted).
node(n1712,refuted) :- node(n1713,refuted).
node(n1712,refuted) :- node(n1714,refuted).
node(n1712,unknown) :- \+ node(n1712,supported), \+ node(n1712,refuted).
node(n1716,supported) :- status(o_3d5a8913b1d0b7f98e9f,supported).
node(n1716,refuted) :- status(o_3d5a8913b1d0b7f98e9f,refuted).
node(n1716,unknown) :- status(o_3d5a8913b1d0b7f98e9f,unknown).
node(n1717,supported) :- status(o_33874f958a8f1176dbfb,supported).
node(n1717,refuted) :- status(o_33874f958a8f1176dbfb,refuted).
node(n1717,unknown) :- status(o_33874f958a8f1176dbfb,unknown).
node(n1715,supported) :- node(n1703,supported), node(n1704,supported), node(n1705,supported), node(n1710,supported), node(n1716,supported), node(n1717,supported).
node(n1715,refuted) :- node(n1703,refuted).
node(n1715,refuted) :- node(n1704,refuted).
node(n1715,refuted) :- node(n1705,refuted).
node(n1715,refuted) :- node(n1710,refuted).
node(n1715,refuted) :- node(n1716,refuted).
node(n1715,refuted) :- node(n1717,refuted).
node(n1715,unknown) :- \+ node(n1715,supported), \+ node(n1715,refuted).
node(n1711,refuted) :- node(n1712,refuted), node(n1715,refuted), node(n9,refuted).
node(n1711,supported) :- node(n1712,supported).
node(n1711,supported) :- node(n1715,supported).
node(n1711,supported) :- node(n9,supported).
node(n1711,unknown) :- \+ node(n1711,supported), \+ node(n1711,refuted).
verdict(c_27c372b11e3a24aa,supported) :- node(n1711,supported).
query(verdict(c_27c372b11e3a24aa,supported)).
verdict(c_27c372b11e3a24aa,refuted) :- node(n1711,refuted).
query(verdict(c_27c372b11e3a24aa,refuted)).
verdict(c_27c372b11e3a24aa,unknown) :- node(n1711,unknown).
query(verdict(c_27c372b11e3a24aa,unknown)).
node(n1720,supported) :- status(o_c969bcebaaebc76769bd,supported).
node(n1720,refuted) :- status(o_c969bcebaaebc76769bd,refuted).
node(n1720,unknown) :- status(o_c969bcebaaebc76769bd,unknown).
node(n1719,supported) :- node(n1699,supported), node(n1700,supported), node(n1720,supported).
node(n1719,refuted) :- node(n1699,refuted).
node(n1719,refuted) :- node(n1700,refuted).
node(n1719,refuted) :- node(n1720,refuted).
node(n1719,unknown) :- \+ node(n1719,supported), \+ node(n1719,refuted).
node(n1722,supported) :- status(o_95d2a34b38545682987f,supported).
node(n1722,refuted) :- status(o_95d2a34b38545682987f,refuted).
node(n1722,unknown) :- status(o_95d2a34b38545682987f,unknown).
node(n1721,supported) :- node(n1703,supported), node(n1704,supported), node(n1722,supported).
node(n1721,refuted) :- node(n1703,refuted).
node(n1721,refuted) :- node(n1704,refuted).
node(n1721,refuted) :- node(n1722,refuted).
node(n1721,unknown) :- \+ node(n1721,supported), \+ node(n1721,refuted).
node(n1718,refuted) :- node(n1719,refuted), node(n1721,refuted), node(n9,refuted).
node(n1718,supported) :- node(n1719,supported).
node(n1718,supported) :- node(n1721,supported).
node(n1718,supported) :- node(n9,supported).
node(n1718,unknown) :- \+ node(n1718,supported), \+ node(n1718,refuted).
verdict(c_15986a2a9159e7d9,supported) :- node(n1718,supported).
query(verdict(c_15986a2a9159e7d9,supported)).
verdict(c_15986a2a9159e7d9,refuted) :- node(n1718,refuted).
query(verdict(c_15986a2a9159e7d9,refuted)).
verdict(c_15986a2a9159e7d9,unknown) :- node(n1718,unknown).
query(verdict(c_15986a2a9159e7d9,unknown)).
node(n1724,supported) :- node(n1699,supported), node(n1700,supported), node(n1701,supported), node(n1720,supported).
node(n1724,refuted) :- node(n1699,refuted).
node(n1724,refuted) :- node(n1700,refuted).
node(n1724,refuted) :- node(n1701,refuted).
node(n1724,refuted) :- node(n1720,refuted).
node(n1724,unknown) :- \+ node(n1724,supported), \+ node(n1724,refuted).
node(n1725,supported) :- node(n1703,supported), node(n1704,supported), node(n1705,supported), node(n1722,supported).
node(n1725,refuted) :- node(n1703,refuted).
node(n1725,refuted) :- node(n1704,refuted).
node(n1725,refuted) :- node(n1705,refuted).
node(n1725,refuted) :- node(n1722,refuted).
node(n1725,unknown) :- \+ node(n1725,supported), \+ node(n1725,refuted).
node(n1723,refuted) :- node(n1724,refuted), node(n1725,refuted), node(n9,refuted).
node(n1723,supported) :- node(n1724,supported).
node(n1723,supported) :- node(n1725,supported).
node(n1723,supported) :- node(n9,supported).
node(n1723,unknown) :- \+ node(n1723,supported), \+ node(n1723,refuted).
verdict(c_c22dcb622a920d56,supported) :- node(n1723,supported).
query(verdict(c_c22dcb622a920d56,supported)).
verdict(c_c22dcb622a920d56,refuted) :- node(n1723,refuted).
query(verdict(c_c22dcb622a920d56,refuted)).
verdict(c_c22dcb622a920d56,unknown) :- node(n1723,unknown).
query(verdict(c_c22dcb622a920d56,unknown)).
node(n1728,supported) :- status(o_e7144f5eebc7a4dbaee9,supported).
node(n1728,refuted) :- status(o_e7144f5eebc7a4dbaee9,refuted).
node(n1728,unknown) :- status(o_e7144f5eebc7a4dbaee9,unknown).
node(n1729,supported) :- status(o_f5b72e68a2dfede9d956,supported).
node(n1729,refuted) :- status(o_f5b72e68a2dfede9d956,refuted).
node(n1729,unknown) :- status(o_f5b72e68a2dfede9d956,unknown).
node(n1730,supported) :- status(o_f7c7a14c20b40180ffef,supported).
node(n1730,refuted) :- status(o_f7c7a14c20b40180ffef,refuted).
node(n1730,unknown) :- status(o_f7c7a14c20b40180ffef,unknown).
node(n1727,supported) :- node(n1728,supported), node(n1729,supported), node(n1730,supported).
node(n1727,refuted) :- node(n1728,refuted).
node(n1727,refuted) :- node(n1729,refuted).
node(n1727,refuted) :- node(n1730,refuted).
node(n1727,unknown) :- \+ node(n1727,supported), \+ node(n1727,refuted).
node(n1732,supported) :- status(o_091f8113da440896d756,supported).
node(n1732,refuted) :- status(o_091f8113da440896d756,refuted).
node(n1732,unknown) :- status(o_091f8113da440896d756,unknown).
node(n1733,supported) :- status(o_0c36cfcbdcf0eec862e0,supported).
node(n1733,refuted) :- status(o_0c36cfcbdcf0eec862e0,refuted).
node(n1733,unknown) :- status(o_0c36cfcbdcf0eec862e0,unknown).
node(n1734,supported) :- status(o_384a7d5237a5ebc767c1,supported).
node(n1734,refuted) :- status(o_384a7d5237a5ebc767c1,refuted).
node(n1734,unknown) :- status(o_384a7d5237a5ebc767c1,unknown).
node(n1731,supported) :- node(n1732,supported), node(n1733,supported), node(n1734,supported).
node(n1731,refuted) :- node(n1732,refuted).
node(n1731,refuted) :- node(n1733,refuted).
node(n1731,refuted) :- node(n1734,refuted).
node(n1731,unknown) :- \+ node(n1731,supported), \+ node(n1731,refuted).
node(n1726,refuted) :- node(n1727,refuted), node(n1731,refuted), node(n9,refuted).
node(n1726,supported) :- node(n1727,supported).
node(n1726,supported) :- node(n1731,supported).
node(n1726,supported) :- node(n9,supported).
node(n1726,unknown) :- \+ node(n1726,supported), \+ node(n1726,refuted).
verdict(c_0b26eea103420b2a,supported) :- node(n1726,supported).
query(verdict(c_0b26eea103420b2a,supported)).
verdict(c_0b26eea103420b2a,refuted) :- node(n1726,refuted).
query(verdict(c_0b26eea103420b2a,refuted)).
verdict(c_0b26eea103420b2a,unknown) :- node(n1726,unknown).
query(verdict(c_0b26eea103420b2a,unknown)).
node(n1737,supported) :- status(o_d3b78e17cea7d0247cab,supported).
node(n1737,refuted) :- status(o_d3b78e17cea7d0247cab,refuted).
node(n1737,unknown) :- status(o_d3b78e17cea7d0247cab,unknown).
node(n1736,supported) :- node(n1728,supported), node(n1729,supported), node(n1730,supported), node(n1737,supported).
node(n1736,refuted) :- node(n1728,refuted).
node(n1736,refuted) :- node(n1729,refuted).
node(n1736,refuted) :- node(n1730,refuted).
node(n1736,refuted) :- node(n1737,refuted).
node(n1736,unknown) :- \+ node(n1736,supported), \+ node(n1736,refuted).
node(n1739,supported) :- status(o_bdba07b9fc902d24db96,supported).
node(n1739,refuted) :- status(o_bdba07b9fc902d24db96,refuted).
node(n1739,unknown) :- status(o_bdba07b9fc902d24db96,unknown).
node(n1738,supported) :- node(n1732,supported), node(n1733,supported), node(n1734,supported), node(n1739,supported).
node(n1738,refuted) :- node(n1732,refuted).
node(n1738,refuted) :- node(n1733,refuted).
node(n1738,refuted) :- node(n1734,refuted).
node(n1738,refuted) :- node(n1739,refuted).
node(n1738,unknown) :- \+ node(n1738,supported), \+ node(n1738,refuted).
node(n1735,refuted) :- node(n1736,refuted), node(n1738,refuted), node(n9,refuted).
node(n1735,supported) :- node(n1736,supported).
node(n1735,supported) :- node(n1738,supported).
node(n1735,supported) :- node(n9,supported).
node(n1735,unknown) :- \+ node(n1735,supported), \+ node(n1735,refuted).
verdict(c_50df7fa62214e9a4,supported) :- node(n1735,supported).
query(verdict(c_50df7fa62214e9a4,supported)).
verdict(c_50df7fa62214e9a4,refuted) :- node(n1735,refuted).
query(verdict(c_50df7fa62214e9a4,refuted)).
verdict(c_50df7fa62214e9a4,unknown) :- node(n1735,unknown).
query(verdict(c_50df7fa62214e9a4,unknown)).
node(n1742,supported) :- status(o_833f304508883542f299,supported).
node(n1742,refuted) :- status(o_833f304508883542f299,refuted).
node(n1742,unknown) :- status(o_833f304508883542f299,unknown).
node(n1743,supported) :- status(o_fb2b3491eebbcaba91aa,supported).
node(n1743,refuted) :- status(o_fb2b3491eebbcaba91aa,refuted).
node(n1743,unknown) :- status(o_fb2b3491eebbcaba91aa,unknown).
node(n1741,supported) :- node(n1728,supported), node(n1729,supported), node(n1730,supported), node(n1737,supported), node(n1742,supported), node(n1743,supported).
node(n1741,refuted) :- node(n1728,refuted).
node(n1741,refuted) :- node(n1729,refuted).
node(n1741,refuted) :- node(n1730,refuted).
node(n1741,refuted) :- node(n1737,refuted).
node(n1741,refuted) :- node(n1742,refuted).
node(n1741,refuted) :- node(n1743,refuted).
node(n1741,unknown) :- \+ node(n1741,supported), \+ node(n1741,refuted).
node(n1745,supported) :- status(o_ff158b861a69c54e2a3a,supported).
node(n1745,refuted) :- status(o_ff158b861a69c54e2a3a,refuted).
node(n1745,unknown) :- status(o_ff158b861a69c54e2a3a,unknown).
node(n1746,supported) :- status(o_1c7db52c5791880bbcde,supported).
node(n1746,refuted) :- status(o_1c7db52c5791880bbcde,refuted).
node(n1746,unknown) :- status(o_1c7db52c5791880bbcde,unknown).
node(n1744,supported) :- node(n1732,supported), node(n1733,supported), node(n1734,supported), node(n1739,supported), node(n1745,supported), node(n1746,supported).
node(n1744,refuted) :- node(n1732,refuted).
node(n1744,refuted) :- node(n1733,refuted).
node(n1744,refuted) :- node(n1734,refuted).
node(n1744,refuted) :- node(n1739,refuted).
node(n1744,refuted) :- node(n1745,refuted).
node(n1744,refuted) :- node(n1746,refuted).
node(n1744,unknown) :- \+ node(n1744,supported), \+ node(n1744,refuted).
node(n1740,refuted) :- node(n1741,refuted), node(n1744,refuted), node(n9,refuted).
node(n1740,supported) :- node(n1741,supported).
node(n1740,supported) :- node(n1744,supported).
node(n1740,supported) :- node(n9,supported).
node(n1740,unknown) :- \+ node(n1740,supported), \+ node(n1740,refuted).
verdict(c_5cf28aa0a3340af9,supported) :- node(n1740,supported).
query(verdict(c_5cf28aa0a3340af9,supported)).
verdict(c_5cf28aa0a3340af9,refuted) :- node(n1740,refuted).
query(verdict(c_5cf28aa0a3340af9,refuted)).
verdict(c_5cf28aa0a3340af9,unknown) :- node(n1740,unknown).
query(verdict(c_5cf28aa0a3340af9,unknown)).
node(n1749,supported) :- status(o_f7000bb76f220a9b2b12,supported).
node(n1749,refuted) :- status(o_f7000bb76f220a9b2b12,refuted).
node(n1749,unknown) :- status(o_f7000bb76f220a9b2b12,unknown).
node(n1748,supported) :- node(n1728,supported), node(n1729,supported), node(n1749,supported).
node(n1748,refuted) :- node(n1728,refuted).
node(n1748,refuted) :- node(n1729,refuted).
node(n1748,refuted) :- node(n1749,refuted).
node(n1748,unknown) :- \+ node(n1748,supported), \+ node(n1748,refuted).
node(n1751,supported) :- status(o_4f3b6b2724edb6a69972,supported).
node(n1751,refuted) :- status(o_4f3b6b2724edb6a69972,refuted).
node(n1751,unknown) :- status(o_4f3b6b2724edb6a69972,unknown).
node(n1750,supported) :- node(n1732,supported), node(n1733,supported), node(n1751,supported).
node(n1750,refuted) :- node(n1732,refuted).
node(n1750,refuted) :- node(n1733,refuted).
node(n1750,refuted) :- node(n1751,refuted).
node(n1750,unknown) :- \+ node(n1750,supported), \+ node(n1750,refuted).
node(n1747,refuted) :- node(n1748,refuted), node(n1750,refuted), node(n9,refuted).
node(n1747,supported) :- node(n1748,supported).
node(n1747,supported) :- node(n1750,supported).
node(n1747,supported) :- node(n9,supported).
node(n1747,unknown) :- \+ node(n1747,supported), \+ node(n1747,refuted).
verdict(c_038f66df92bb9a07,supported) :- node(n1747,supported).
query(verdict(c_038f66df92bb9a07,supported)).
verdict(c_038f66df92bb9a07,refuted) :- node(n1747,refuted).
query(verdict(c_038f66df92bb9a07,refuted)).
verdict(c_038f66df92bb9a07,unknown) :- node(n1747,unknown).
query(verdict(c_038f66df92bb9a07,unknown)).
node(n1753,supported) :- node(n1728,supported), node(n1729,supported), node(n1730,supported), node(n1749,supported).
node(n1753,refuted) :- node(n1728,refuted).
node(n1753,refuted) :- node(n1729,refuted).
node(n1753,refuted) :- node(n1730,refuted).
node(n1753,refuted) :- node(n1749,refuted).
node(n1753,unknown) :- \+ node(n1753,supported), \+ node(n1753,refuted).
node(n1754,supported) :- node(n1732,supported), node(n1733,supported), node(n1734,supported), node(n1751,supported).
node(n1754,refuted) :- node(n1732,refuted).
node(n1754,refuted) :- node(n1733,refuted).
node(n1754,refuted) :- node(n1734,refuted).
node(n1754,refuted) :- node(n1751,refuted).
node(n1754,unknown) :- \+ node(n1754,supported), \+ node(n1754,refuted).
node(n1752,refuted) :- node(n1753,refuted), node(n1754,refuted), node(n9,refuted).
node(n1752,supported) :- node(n1753,supported).
node(n1752,supported) :- node(n1754,supported).
node(n1752,supported) :- node(n9,supported).
node(n1752,unknown) :- \+ node(n1752,supported), \+ node(n1752,refuted).
verdict(c_a7fac70e7ce20554,supported) :- node(n1752,supported).
query(verdict(c_a7fac70e7ce20554,supported)).
verdict(c_a7fac70e7ce20554,refuted) :- node(n1752,refuted).
query(verdict(c_a7fac70e7ce20554,refuted)).
verdict(c_a7fac70e7ce20554,unknown) :- node(n1752,unknown).
query(verdict(c_a7fac70e7ce20554,unknown)).
node(n1757,supported) :- status(o_b9c0b64a722bc7a7aa97,supported).
node(n1757,refuted) :- status(o_b9c0b64a722bc7a7aa97,refuted).
node(n1757,unknown) :- status(o_b9c0b64a722bc7a7aa97,unknown).
node(n1758,supported) :- status(o_f88ac82d1fefa5bc376a,supported).
node(n1758,refuted) :- status(o_f88ac82d1fefa5bc376a,refuted).
node(n1758,unknown) :- status(o_f88ac82d1fefa5bc376a,unknown).
node(n1759,supported) :- status(o_9f18e4d49c59938e1220,supported).
node(n1759,refuted) :- status(o_9f18e4d49c59938e1220,refuted).
node(n1759,unknown) :- status(o_9f18e4d49c59938e1220,unknown).
node(n1756,supported) :- node(n1757,supported), node(n1758,supported), node(n1759,supported).
node(n1756,refuted) :- node(n1757,refuted).
node(n1756,refuted) :- node(n1758,refuted).
node(n1756,refuted) :- node(n1759,refuted).
node(n1756,unknown) :- \+ node(n1756,supported), \+ node(n1756,refuted).
node(n1761,supported) :- status(o_5b7486c18996a7c3676a,supported).
node(n1761,refuted) :- status(o_5b7486c18996a7c3676a,refuted).
node(n1761,unknown) :- status(o_5b7486c18996a7c3676a,unknown).
node(n1762,supported) :- status(o_05c3e47978287286111a,supported).
node(n1762,refuted) :- status(o_05c3e47978287286111a,refuted).
node(n1762,unknown) :- status(o_05c3e47978287286111a,unknown).
node(n1763,supported) :- status(o_1d55d0ba054bca6d48d9,supported).
node(n1763,refuted) :- status(o_1d55d0ba054bca6d48d9,refuted).
node(n1763,unknown) :- status(o_1d55d0ba054bca6d48d9,unknown).
node(n1760,supported) :- node(n1761,supported), node(n1762,supported), node(n1763,supported).
node(n1760,refuted) :- node(n1761,refuted).
node(n1760,refuted) :- node(n1762,refuted).
node(n1760,refuted) :- node(n1763,refuted).
node(n1760,unknown) :- \+ node(n1760,supported), \+ node(n1760,refuted).
node(n1755,refuted) :- node(n1756,refuted), node(n1760,refuted), node(n9,refuted).
node(n1755,supported) :- node(n1756,supported).
node(n1755,supported) :- node(n1760,supported).
node(n1755,supported) :- node(n9,supported).
node(n1755,unknown) :- \+ node(n1755,supported), \+ node(n1755,refuted).
verdict(c_8cd50f91e7df5c65,supported) :- node(n1755,supported).
query(verdict(c_8cd50f91e7df5c65,supported)).
verdict(c_8cd50f91e7df5c65,refuted) :- node(n1755,refuted).
query(verdict(c_8cd50f91e7df5c65,refuted)).
verdict(c_8cd50f91e7df5c65,unknown) :- node(n1755,unknown).
query(verdict(c_8cd50f91e7df5c65,unknown)).
node(n1766,supported) :- status(o_888aec2150580b3b3b2c,supported).
node(n1766,refuted) :- status(o_888aec2150580b3b3b2c,refuted).
node(n1766,unknown) :- status(o_888aec2150580b3b3b2c,unknown).
node(n1765,supported) :- node(n1757,supported), node(n1758,supported), node(n1759,supported), node(n1766,supported).
node(n1765,refuted) :- node(n1757,refuted).
node(n1765,refuted) :- node(n1758,refuted).
node(n1765,refuted) :- node(n1759,refuted).
node(n1765,refuted) :- node(n1766,refuted).
node(n1765,unknown) :- \+ node(n1765,supported), \+ node(n1765,refuted).
node(n1768,supported) :- status(o_053689d2e5637db3dc9e,supported).
node(n1768,refuted) :- status(o_053689d2e5637db3dc9e,refuted).
node(n1768,unknown) :- status(o_053689d2e5637db3dc9e,unknown).
node(n1767,supported) :- node(n1761,supported), node(n1762,supported), node(n1763,supported), node(n1768,supported).
node(n1767,refuted) :- node(n1761,refuted).
node(n1767,refuted) :- node(n1762,refuted).
node(n1767,refuted) :- node(n1763,refuted).
node(n1767,refuted) :- node(n1768,refuted).
node(n1767,unknown) :- \+ node(n1767,supported), \+ node(n1767,refuted).
node(n1764,refuted) :- node(n1765,refuted), node(n1767,refuted), node(n9,refuted).
node(n1764,supported) :- node(n1765,supported).
node(n1764,supported) :- node(n1767,supported).
node(n1764,supported) :- node(n9,supported).
node(n1764,unknown) :- \+ node(n1764,supported), \+ node(n1764,refuted).
verdict(c_8d3f251959dbdcd5,supported) :- node(n1764,supported).
query(verdict(c_8d3f251959dbdcd5,supported)).
verdict(c_8d3f251959dbdcd5,refuted) :- node(n1764,refuted).
query(verdict(c_8d3f251959dbdcd5,refuted)).
verdict(c_8d3f251959dbdcd5,unknown) :- node(n1764,unknown).
query(verdict(c_8d3f251959dbdcd5,unknown)).
node(n1771,supported) :- status(o_a9413655a7829e10b034,supported).
node(n1771,refuted) :- status(o_a9413655a7829e10b034,refuted).
node(n1771,unknown) :- status(o_a9413655a7829e10b034,unknown).
node(n1772,supported) :- status(o_807f9757ca3f396f5466,supported).
node(n1772,refuted) :- status(o_807f9757ca3f396f5466,refuted).
node(n1772,unknown) :- status(o_807f9757ca3f396f5466,unknown).
node(n1770,supported) :- node(n1757,supported), node(n1758,supported), node(n1759,supported), node(n1766,supported), node(n1771,supported), node(n1772,supported).
node(n1770,refuted) :- node(n1757,refuted).
node(n1770,refuted) :- node(n1758,refuted).
node(n1770,refuted) :- node(n1759,refuted).
node(n1770,refuted) :- node(n1766,refuted).
node(n1770,refuted) :- node(n1771,refuted).
node(n1770,refuted) :- node(n1772,refuted).
node(n1770,unknown) :- \+ node(n1770,supported), \+ node(n1770,refuted).
node(n1774,supported) :- status(o_13035df4d5772ec35ea2,supported).
node(n1774,refuted) :- status(o_13035df4d5772ec35ea2,refuted).
node(n1774,unknown) :- status(o_13035df4d5772ec35ea2,unknown).
node(n1775,supported) :- status(o_949af639dbb0745441b6,supported).
node(n1775,refuted) :- status(o_949af639dbb0745441b6,refuted).
node(n1775,unknown) :- status(o_949af639dbb0745441b6,unknown).
node(n1773,supported) :- node(n1761,supported), node(n1762,supported), node(n1763,supported), node(n1768,supported), node(n1774,supported), node(n1775,supported).
node(n1773,refuted) :- node(n1761,refuted).
node(n1773,refuted) :- node(n1762,refuted).
node(n1773,refuted) :- node(n1763,refuted).
node(n1773,refuted) :- node(n1768,refuted).
node(n1773,refuted) :- node(n1774,refuted).
node(n1773,refuted) :- node(n1775,refuted).
node(n1773,unknown) :- \+ node(n1773,supported), \+ node(n1773,refuted).
node(n1769,refuted) :- node(n1770,refuted), node(n1773,refuted), node(n9,refuted).
node(n1769,supported) :- node(n1770,supported).
node(n1769,supported) :- node(n1773,supported).
node(n1769,supported) :- node(n9,supported).
node(n1769,unknown) :- \+ node(n1769,supported), \+ node(n1769,refuted).
verdict(c_05ea3eb63ce53e0d,supported) :- node(n1769,supported).
query(verdict(c_05ea3eb63ce53e0d,supported)).
verdict(c_05ea3eb63ce53e0d,refuted) :- node(n1769,refuted).
query(verdict(c_05ea3eb63ce53e0d,refuted)).
verdict(c_05ea3eb63ce53e0d,unknown) :- node(n1769,unknown).
query(verdict(c_05ea3eb63ce53e0d,unknown)).
node(n1778,supported) :- status(o_c09170d8e4c2bf8aaa2d,supported).
node(n1778,refuted) :- status(o_c09170d8e4c2bf8aaa2d,refuted).
node(n1778,unknown) :- status(o_c09170d8e4c2bf8aaa2d,unknown).
node(n1777,supported) :- node(n1757,supported), node(n1758,supported), node(n1778,supported).
node(n1777,refuted) :- node(n1757,refuted).
node(n1777,refuted) :- node(n1758,refuted).
node(n1777,refuted) :- node(n1778,refuted).
node(n1777,unknown) :- \+ node(n1777,supported), \+ node(n1777,refuted).
node(n1780,supported) :- status(o_9510d568d6cec6af769b,supported).
node(n1780,refuted) :- status(o_9510d568d6cec6af769b,refuted).
node(n1780,unknown) :- status(o_9510d568d6cec6af769b,unknown).
node(n1779,supported) :- node(n1761,supported), node(n1762,supported), node(n1780,supported).
node(n1779,refuted) :- node(n1761,refuted).
node(n1779,refuted) :- node(n1762,refuted).
node(n1779,refuted) :- node(n1780,refuted).
node(n1779,unknown) :- \+ node(n1779,supported), \+ node(n1779,refuted).
node(n1776,refuted) :- node(n1777,refuted), node(n1779,refuted), node(n9,refuted).
node(n1776,supported) :- node(n1777,supported).
node(n1776,supported) :- node(n1779,supported).
node(n1776,supported) :- node(n9,supported).
node(n1776,unknown) :- \+ node(n1776,supported), \+ node(n1776,refuted).
verdict(c_cf01ae69fd05394f,supported) :- node(n1776,supported).
query(verdict(c_cf01ae69fd05394f,supported)).
verdict(c_cf01ae69fd05394f,refuted) :- node(n1776,refuted).
query(verdict(c_cf01ae69fd05394f,refuted)).
verdict(c_cf01ae69fd05394f,unknown) :- node(n1776,unknown).
query(verdict(c_cf01ae69fd05394f,unknown)).
node(n1782,supported) :- node(n1757,supported), node(n1758,supported), node(n1759,supported), node(n1778,supported).
node(n1782,refuted) :- node(n1757,refuted).
node(n1782,refuted) :- node(n1758,refuted).
node(n1782,refuted) :- node(n1759,refuted).
node(n1782,refuted) :- node(n1778,refuted).
node(n1782,unknown) :- \+ node(n1782,supported), \+ node(n1782,refuted).
node(n1783,supported) :- node(n1761,supported), node(n1762,supported), node(n1763,supported), node(n1780,supported).
node(n1783,refuted) :- node(n1761,refuted).
node(n1783,refuted) :- node(n1762,refuted).
node(n1783,refuted) :- node(n1763,refuted).
node(n1783,refuted) :- node(n1780,refuted).
node(n1783,unknown) :- \+ node(n1783,supported), \+ node(n1783,refuted).
node(n1781,refuted) :- node(n1782,refuted), node(n1783,refuted), node(n9,refuted).
node(n1781,supported) :- node(n1782,supported).
node(n1781,supported) :- node(n1783,supported).
node(n1781,supported) :- node(n9,supported).
node(n1781,unknown) :- \+ node(n1781,supported), \+ node(n1781,refuted).
verdict(c_a313fe0ad3d95324,supported) :- node(n1781,supported).
query(verdict(c_a313fe0ad3d95324,supported)).
verdict(c_a313fe0ad3d95324,refuted) :- node(n1781,refuted).
query(verdict(c_a313fe0ad3d95324,refuted)).
verdict(c_a313fe0ad3d95324,unknown) :- node(n1781,unknown).
query(verdict(c_a313fe0ad3d95324,unknown)).
node(n1786,supported) :- status(o_e32d957b339b057b63a6,supported).
node(n1786,refuted) :- status(o_e32d957b339b057b63a6,refuted).
node(n1786,unknown) :- status(o_e32d957b339b057b63a6,unknown).
node(n1787,supported) :- status(o_06bee04783cee3b11415,supported).
node(n1787,refuted) :- status(o_06bee04783cee3b11415,refuted).
node(n1787,unknown) :- status(o_06bee04783cee3b11415,unknown).
node(n1788,supported) :- status(o_76c908ad4c958b25f67e,supported).
node(n1788,refuted) :- status(o_76c908ad4c958b25f67e,refuted).
node(n1788,unknown) :- status(o_76c908ad4c958b25f67e,unknown).
node(n1785,supported) :- node(n1786,supported), node(n1787,supported), node(n1788,supported).
node(n1785,refuted) :- node(n1786,refuted).
node(n1785,refuted) :- node(n1787,refuted).
node(n1785,refuted) :- node(n1788,refuted).
node(n1785,unknown) :- \+ node(n1785,supported), \+ node(n1785,refuted).
node(n1790,supported) :- status(o_cd613265cd1c24a0126f,supported).
node(n1790,refuted) :- status(o_cd613265cd1c24a0126f,refuted).
node(n1790,unknown) :- status(o_cd613265cd1c24a0126f,unknown).
node(n1791,supported) :- status(o_a31788f8c927a387dcc0,supported).
node(n1791,refuted) :- status(o_a31788f8c927a387dcc0,refuted).
node(n1791,unknown) :- status(o_a31788f8c927a387dcc0,unknown).
node(n1792,supported) :- status(o_43ef585e02abace9d3ba,supported).
node(n1792,refuted) :- status(o_43ef585e02abace9d3ba,refuted).
node(n1792,unknown) :- status(o_43ef585e02abace9d3ba,unknown).
node(n1789,supported) :- node(n1790,supported), node(n1791,supported), node(n1792,supported).
node(n1789,refuted) :- node(n1790,refuted).
node(n1789,refuted) :- node(n1791,refuted).
node(n1789,refuted) :- node(n1792,refuted).
node(n1789,unknown) :- \+ node(n1789,supported), \+ node(n1789,refuted).
node(n1784,refuted) :- node(n1785,refuted), node(n1789,refuted), node(n9,refuted).
node(n1784,supported) :- node(n1785,supported).
node(n1784,supported) :- node(n1789,supported).
node(n1784,supported) :- node(n9,supported).
node(n1784,unknown) :- \+ node(n1784,supported), \+ node(n1784,refuted).
verdict(c_9509af721f600a13,supported) :- node(n1784,supported).
query(verdict(c_9509af721f600a13,supported)).
verdict(c_9509af721f600a13,refuted) :- node(n1784,refuted).
query(verdict(c_9509af721f600a13,refuted)).
verdict(c_9509af721f600a13,unknown) :- node(n1784,unknown).
query(verdict(c_9509af721f600a13,unknown)).
node(n1795,supported) :- status(o_274a0082d9863aaa056e,supported).
node(n1795,refuted) :- status(o_274a0082d9863aaa056e,refuted).
node(n1795,unknown) :- status(o_274a0082d9863aaa056e,unknown).
node(n1794,supported) :- node(n1786,supported), node(n1787,supported), node(n1788,supported), node(n1795,supported).
node(n1794,refuted) :- node(n1786,refuted).
node(n1794,refuted) :- node(n1787,refuted).
node(n1794,refuted) :- node(n1788,refuted).
node(n1794,refuted) :- node(n1795,refuted).
node(n1794,unknown) :- \+ node(n1794,supported), \+ node(n1794,refuted).
node(n1797,supported) :- status(o_83a7eb1b81e7be443af2,supported).
node(n1797,refuted) :- status(o_83a7eb1b81e7be443af2,refuted).
node(n1797,unknown) :- status(o_83a7eb1b81e7be443af2,unknown).
node(n1796,supported) :- node(n1790,supported), node(n1791,supported), node(n1792,supported), node(n1797,supported).
node(n1796,refuted) :- node(n1790,refuted).
node(n1796,refuted) :- node(n1791,refuted).
node(n1796,refuted) :- node(n1792,refuted).
node(n1796,refuted) :- node(n1797,refuted).
node(n1796,unknown) :- \+ node(n1796,supported), \+ node(n1796,refuted).
node(n1793,refuted) :- node(n1794,refuted), node(n1796,refuted), node(n9,refuted).
node(n1793,supported) :- node(n1794,supported).
node(n1793,supported) :- node(n1796,supported).
node(n1793,supported) :- node(n9,supported).
node(n1793,unknown) :- \+ node(n1793,supported), \+ node(n1793,refuted).
verdict(c_f125c29a92cb60fb,supported) :- node(n1793,supported).
query(verdict(c_f125c29a92cb60fb,supported)).
verdict(c_f125c29a92cb60fb,refuted) :- node(n1793,refuted).
query(verdict(c_f125c29a92cb60fb,refuted)).
verdict(c_f125c29a92cb60fb,unknown) :- node(n1793,unknown).
query(verdict(c_f125c29a92cb60fb,unknown)).
node(n1800,supported) :- status(o_e65ae4b3d1a72ffa6187,supported).
node(n1800,refuted) :- status(o_e65ae4b3d1a72ffa6187,refuted).
node(n1800,unknown) :- status(o_e65ae4b3d1a72ffa6187,unknown).
node(n1801,supported) :- status(o_aa815e279f14b096ff07,supported).
node(n1801,refuted) :- status(o_aa815e279f14b096ff07,refuted).
node(n1801,unknown) :- status(o_aa815e279f14b096ff07,unknown).
node(n1799,supported) :- node(n1786,supported), node(n1787,supported), node(n1788,supported), node(n1795,supported), node(n1800,supported), node(n1801,supported).
node(n1799,refuted) :- node(n1786,refuted).
node(n1799,refuted) :- node(n1787,refuted).
node(n1799,refuted) :- node(n1788,refuted).
node(n1799,refuted) :- node(n1795,refuted).
node(n1799,refuted) :- node(n1800,refuted).
node(n1799,refuted) :- node(n1801,refuted).
node(n1799,unknown) :- \+ node(n1799,supported), \+ node(n1799,refuted).
node(n1803,supported) :- status(o_1be6ccecfc7137411886,supported).
node(n1803,refuted) :- status(o_1be6ccecfc7137411886,refuted).
node(n1803,unknown) :- status(o_1be6ccecfc7137411886,unknown).
node(n1804,supported) :- status(o_792d819302f06839cc2a,supported).
node(n1804,refuted) :- status(o_792d819302f06839cc2a,refuted).
node(n1804,unknown) :- status(o_792d819302f06839cc2a,unknown).
node(n1802,supported) :- node(n1790,supported), node(n1791,supported), node(n1792,supported), node(n1797,supported), node(n1803,supported), node(n1804,supported).
node(n1802,refuted) :- node(n1790,refuted).
node(n1802,refuted) :- node(n1791,refuted).
node(n1802,refuted) :- node(n1792,refuted).
node(n1802,refuted) :- node(n1797,refuted).
node(n1802,refuted) :- node(n1803,refuted).
node(n1802,refuted) :- node(n1804,refuted).
node(n1802,unknown) :- \+ node(n1802,supported), \+ node(n1802,refuted).
node(n1798,refuted) :- node(n1799,refuted), node(n1802,refuted), node(n9,refuted).
node(n1798,supported) :- node(n1799,supported).
node(n1798,supported) :- node(n1802,supported).
node(n1798,supported) :- node(n9,supported).
node(n1798,unknown) :- \+ node(n1798,supported), \+ node(n1798,refuted).
verdict(c_03a39f847b469546,supported) :- node(n1798,supported).
query(verdict(c_03a39f847b469546,supported)).
verdict(c_03a39f847b469546,refuted) :- node(n1798,refuted).
query(verdict(c_03a39f847b469546,refuted)).
verdict(c_03a39f847b469546,unknown) :- node(n1798,unknown).
query(verdict(c_03a39f847b469546,unknown)).
node(n1807,supported) :- status(o_d2cf8b56a70e97807382,supported).
node(n1807,refuted) :- status(o_d2cf8b56a70e97807382,refuted).
node(n1807,unknown) :- status(o_d2cf8b56a70e97807382,unknown).
node(n1806,supported) :- node(n1786,supported), node(n1787,supported), node(n1807,supported).
node(n1806,refuted) :- node(n1786,refuted).
node(n1806,refuted) :- node(n1787,refuted).
node(n1806,refuted) :- node(n1807,refuted).
node(n1806,unknown) :- \+ node(n1806,supported), \+ node(n1806,refuted).
node(n1809,supported) :- status(o_4e6ce6b894bc99a91cfa,supported).
node(n1809,refuted) :- status(o_4e6ce6b894bc99a91cfa,refuted).
node(n1809,unknown) :- status(o_4e6ce6b894bc99a91cfa,unknown).
node(n1808,supported) :- node(n1790,supported), node(n1791,supported), node(n1809,supported).
node(n1808,refuted) :- node(n1790,refuted).
node(n1808,refuted) :- node(n1791,refuted).
node(n1808,refuted) :- node(n1809,refuted).
node(n1808,unknown) :- \+ node(n1808,supported), \+ node(n1808,refuted).
node(n1805,refuted) :- node(n1806,refuted), node(n1808,refuted), node(n9,refuted).
node(n1805,supported) :- node(n1806,supported).
node(n1805,supported) :- node(n1808,supported).
node(n1805,supported) :- node(n9,supported).
node(n1805,unknown) :- \+ node(n1805,supported), \+ node(n1805,refuted).
verdict(c_04209c667313a437,supported) :- node(n1805,supported).
query(verdict(c_04209c667313a437,supported)).
verdict(c_04209c667313a437,refuted) :- node(n1805,refuted).
query(verdict(c_04209c667313a437,refuted)).
verdict(c_04209c667313a437,unknown) :- node(n1805,unknown).
query(verdict(c_04209c667313a437,unknown)).
node(n1811,supported) :- node(n1786,supported), node(n1787,supported), node(n1788,supported), node(n1807,supported).
node(n1811,refuted) :- node(n1786,refuted).
node(n1811,refuted) :- node(n1787,refuted).
node(n1811,refuted) :- node(n1788,refuted).
node(n1811,refuted) :- node(n1807,refuted).
node(n1811,unknown) :- \+ node(n1811,supported), \+ node(n1811,refuted).
node(n1812,supported) :- node(n1790,supported), node(n1791,supported), node(n1792,supported), node(n1809,supported).
node(n1812,refuted) :- node(n1790,refuted).
node(n1812,refuted) :- node(n1791,refuted).
node(n1812,refuted) :- node(n1792,refuted).
node(n1812,refuted) :- node(n1809,refuted).
node(n1812,unknown) :- \+ node(n1812,supported), \+ node(n1812,refuted).
node(n1810,refuted) :- node(n1811,refuted), node(n1812,refuted), node(n9,refuted).
node(n1810,supported) :- node(n1811,supported).
node(n1810,supported) :- node(n1812,supported).
node(n1810,supported) :- node(n9,supported).
node(n1810,unknown) :- \+ node(n1810,supported), \+ node(n1810,refuted).
verdict(c_1fa15f9a3e2cde94,supported) :- node(n1810,supported).
query(verdict(c_1fa15f9a3e2cde94,supported)).
verdict(c_1fa15f9a3e2cde94,refuted) :- node(n1810,refuted).
query(verdict(c_1fa15f9a3e2cde94,refuted)).
verdict(c_1fa15f9a3e2cde94,unknown) :- node(n1810,unknown).
query(verdict(c_1fa15f9a3e2cde94,unknown)).
node(n1815,supported) :- status(o_545903d715611c3bd136,supported).
node(n1815,refuted) :- status(o_545903d715611c3bd136,refuted).
node(n1815,unknown) :- status(o_545903d715611c3bd136,unknown).
node(n1816,supported) :- status(o_97feb2a1dd70f8cac96f,supported).
node(n1816,refuted) :- status(o_97feb2a1dd70f8cac96f,refuted).
node(n1816,unknown) :- status(o_97feb2a1dd70f8cac96f,unknown).
node(n1817,supported) :- status(o_550af0d5d23f526f0080,supported).
node(n1817,refuted) :- status(o_550af0d5d23f526f0080,refuted).
node(n1817,unknown) :- status(o_550af0d5d23f526f0080,unknown).
node(n1814,supported) :- node(n1815,supported), node(n1816,supported), node(n1817,supported).
node(n1814,refuted) :- node(n1815,refuted).
node(n1814,refuted) :- node(n1816,refuted).
node(n1814,refuted) :- node(n1817,refuted).
node(n1814,unknown) :- \+ node(n1814,supported), \+ node(n1814,refuted).
node(n1819,supported) :- status(o_6e7532ab2825c9b1800f,supported).
node(n1819,refuted) :- status(o_6e7532ab2825c9b1800f,refuted).
node(n1819,unknown) :- status(o_6e7532ab2825c9b1800f,unknown).
node(n1820,supported) :- status(o_30130703a48919500408,supported).
node(n1820,refuted) :- status(o_30130703a48919500408,refuted).
node(n1820,unknown) :- status(o_30130703a48919500408,unknown).
node(n1821,supported) :- status(o_46f81eb23b33e03bc5af,supported).
node(n1821,refuted) :- status(o_46f81eb23b33e03bc5af,refuted).
node(n1821,unknown) :- status(o_46f81eb23b33e03bc5af,unknown).
node(n1818,supported) :- node(n1819,supported), node(n1820,supported), node(n1821,supported).
node(n1818,refuted) :- node(n1819,refuted).
node(n1818,refuted) :- node(n1820,refuted).
node(n1818,refuted) :- node(n1821,refuted).
node(n1818,unknown) :- \+ node(n1818,supported), \+ node(n1818,refuted).
node(n1813,refuted) :- node(n1814,refuted), node(n1818,refuted), node(n9,refuted).
node(n1813,supported) :- node(n1814,supported).
node(n1813,supported) :- node(n1818,supported).
node(n1813,supported) :- node(n9,supported).
node(n1813,unknown) :- \+ node(n1813,supported), \+ node(n1813,refuted).
verdict(c_3ad419080e80462d,supported) :- node(n1813,supported).
query(verdict(c_3ad419080e80462d,supported)).
verdict(c_3ad419080e80462d,refuted) :- node(n1813,refuted).
query(verdict(c_3ad419080e80462d,refuted)).
verdict(c_3ad419080e80462d,unknown) :- node(n1813,unknown).
query(verdict(c_3ad419080e80462d,unknown)).
node(n1824,supported) :- status(o_8c18cdf30846a9cbb8c8,supported).
node(n1824,refuted) :- status(o_8c18cdf30846a9cbb8c8,refuted).
node(n1824,unknown) :- status(o_8c18cdf30846a9cbb8c8,unknown).
node(n1823,supported) :- node(n1815,supported), node(n1816,supported), node(n1817,supported), node(n1824,supported).
node(n1823,refuted) :- node(n1815,refuted).
node(n1823,refuted) :- node(n1816,refuted).
node(n1823,refuted) :- node(n1817,refuted).
node(n1823,refuted) :- node(n1824,refuted).
node(n1823,unknown) :- \+ node(n1823,supported), \+ node(n1823,refuted).
node(n1826,supported) :- status(o_7f302fff9d200b911cee,supported).
node(n1826,refuted) :- status(o_7f302fff9d200b911cee,refuted).
node(n1826,unknown) :- status(o_7f302fff9d200b911cee,unknown).
node(n1825,supported) :- node(n1819,supported), node(n1820,supported), node(n1821,supported), node(n1826,supported).
node(n1825,refuted) :- node(n1819,refuted).
node(n1825,refuted) :- node(n1820,refuted).
node(n1825,refuted) :- node(n1821,refuted).
node(n1825,refuted) :- node(n1826,refuted).
node(n1825,unknown) :- \+ node(n1825,supported), \+ node(n1825,refuted).
node(n1822,refuted) :- node(n1823,refuted), node(n1825,refuted), node(n9,refuted).
node(n1822,supported) :- node(n1823,supported).
node(n1822,supported) :- node(n1825,supported).
node(n1822,supported) :- node(n9,supported).
node(n1822,unknown) :- \+ node(n1822,supported), \+ node(n1822,refuted).
verdict(c_710c5f50186869f5,supported) :- node(n1822,supported).
query(verdict(c_710c5f50186869f5,supported)).
verdict(c_710c5f50186869f5,refuted) :- node(n1822,refuted).
query(verdict(c_710c5f50186869f5,refuted)).
verdict(c_710c5f50186869f5,unknown) :- node(n1822,unknown).
query(verdict(c_710c5f50186869f5,unknown)).
node(n1829,supported) :- status(o_45803550c0c23f5ca629,supported).
node(n1829,refuted) :- status(o_45803550c0c23f5ca629,refuted).
node(n1829,unknown) :- status(o_45803550c0c23f5ca629,unknown).
node(n1830,supported) :- status(o_6f7152e20d37baf6efe5,supported).
node(n1830,refuted) :- status(o_6f7152e20d37baf6efe5,refuted).
node(n1830,unknown) :- status(o_6f7152e20d37baf6efe5,unknown).
node(n1828,supported) :- node(n1815,supported), node(n1816,supported), node(n1817,supported), node(n1824,supported), node(n1829,supported), node(n1830,supported).
node(n1828,refuted) :- node(n1815,refuted).
node(n1828,refuted) :- node(n1816,refuted).
node(n1828,refuted) :- node(n1817,refuted).
node(n1828,refuted) :- node(n1824,refuted).
node(n1828,refuted) :- node(n1829,refuted).
node(n1828,refuted) :- node(n1830,refuted).
node(n1828,unknown) :- \+ node(n1828,supported), \+ node(n1828,refuted).
node(n1832,supported) :- status(o_0b34b68faf2c8286ed4f,supported).
node(n1832,refuted) :- status(o_0b34b68faf2c8286ed4f,refuted).
node(n1832,unknown) :- status(o_0b34b68faf2c8286ed4f,unknown).
node(n1833,supported) :- status(o_5cfd309933f1985a62e9,supported).
node(n1833,refuted) :- status(o_5cfd309933f1985a62e9,refuted).
node(n1833,unknown) :- status(o_5cfd309933f1985a62e9,unknown).
node(n1831,supported) :- node(n1819,supported), node(n1820,supported), node(n1821,supported), node(n1826,supported), node(n1832,supported), node(n1833,supported).
node(n1831,refuted) :- node(n1819,refuted).
node(n1831,refuted) :- node(n1820,refuted).
node(n1831,refuted) :- node(n1821,refuted).
node(n1831,refuted) :- node(n1826,refuted).
node(n1831,refuted) :- node(n1832,refuted).
node(n1831,refuted) :- node(n1833,refuted).
node(n1831,unknown) :- \+ node(n1831,supported), \+ node(n1831,refuted).
node(n1827,refuted) :- node(n1828,refuted), node(n1831,refuted), node(n9,refuted).
node(n1827,supported) :- node(n1828,supported).
node(n1827,supported) :- node(n1831,supported).
node(n1827,supported) :- node(n9,supported).
node(n1827,unknown) :- \+ node(n1827,supported), \+ node(n1827,refuted).
verdict(c_0a7aba2f02a3fca1,supported) :- node(n1827,supported).
query(verdict(c_0a7aba2f02a3fca1,supported)).
verdict(c_0a7aba2f02a3fca1,refuted) :- node(n1827,refuted).
query(verdict(c_0a7aba2f02a3fca1,refuted)).
verdict(c_0a7aba2f02a3fca1,unknown) :- node(n1827,unknown).
query(verdict(c_0a7aba2f02a3fca1,unknown)).
node(n1836,supported) :- status(o_b2da8d2847914fa66c47,supported).
node(n1836,refuted) :- status(o_b2da8d2847914fa66c47,refuted).
node(n1836,unknown) :- status(o_b2da8d2847914fa66c47,unknown).
node(n1835,supported) :- node(n1815,supported), node(n1816,supported), node(n1836,supported).
node(n1835,refuted) :- node(n1815,refuted).
node(n1835,refuted) :- node(n1816,refuted).
node(n1835,refuted) :- node(n1836,refuted).
node(n1835,unknown) :- \+ node(n1835,supported), \+ node(n1835,refuted).
node(n1838,supported) :- status(o_2a3fe068f3e204ca5991,supported).
node(n1838,refuted) :- status(o_2a3fe068f3e204ca5991,refuted).
node(n1838,unknown) :- status(o_2a3fe068f3e204ca5991,unknown).
node(n1837,supported) :- node(n1819,supported), node(n1820,supported), node(n1838,supported).
node(n1837,refuted) :- node(n1819,refuted).
node(n1837,refuted) :- node(n1820,refuted).
node(n1837,refuted) :- node(n1838,refuted).
node(n1837,unknown) :- \+ node(n1837,supported), \+ node(n1837,refuted).
node(n1834,refuted) :- node(n1835,refuted), node(n1837,refuted), node(n9,refuted).
node(n1834,supported) :- node(n1835,supported).
node(n1834,supported) :- node(n1837,supported).
node(n1834,supported) :- node(n9,supported).
node(n1834,unknown) :- \+ node(n1834,supported), \+ node(n1834,refuted).
verdict(c_329257667b81ac2e,supported) :- node(n1834,supported).
query(verdict(c_329257667b81ac2e,supported)).
verdict(c_329257667b81ac2e,refuted) :- node(n1834,refuted).
query(verdict(c_329257667b81ac2e,refuted)).
verdict(c_329257667b81ac2e,unknown) :- node(n1834,unknown).
query(verdict(c_329257667b81ac2e,unknown)).
node(n1840,supported) :- node(n1815,supported), node(n1816,supported), node(n1817,supported), node(n1836,supported).
node(n1840,refuted) :- node(n1815,refuted).
node(n1840,refuted) :- node(n1816,refuted).
node(n1840,refuted) :- node(n1817,refuted).
node(n1840,refuted) :- node(n1836,refuted).
node(n1840,unknown) :- \+ node(n1840,supported), \+ node(n1840,refuted).
node(n1841,supported) :- node(n1819,supported), node(n1820,supported), node(n1821,supported), node(n1838,supported).
node(n1841,refuted) :- node(n1819,refuted).
node(n1841,refuted) :- node(n1820,refuted).
node(n1841,refuted) :- node(n1821,refuted).
node(n1841,refuted) :- node(n1838,refuted).
node(n1841,unknown) :- \+ node(n1841,supported), \+ node(n1841,refuted).
node(n1839,refuted) :- node(n1840,refuted), node(n1841,refuted), node(n9,refuted).
node(n1839,supported) :- node(n1840,supported).
node(n1839,supported) :- node(n1841,supported).
node(n1839,supported) :- node(n9,supported).
node(n1839,unknown) :- \+ node(n1839,supported), \+ node(n1839,refuted).
verdict(c_dd4a02345eaaf5b9,supported) :- node(n1839,supported).
query(verdict(c_dd4a02345eaaf5b9,supported)).
verdict(c_dd4a02345eaaf5b9,refuted) :- node(n1839,refuted).
query(verdict(c_dd4a02345eaaf5b9,refuted)).
verdict(c_dd4a02345eaaf5b9,unknown) :- node(n1839,unknown).
query(verdict(c_dd4a02345eaaf5b9,unknown)).
node(n1844,supported) :- status(o_f154e2d5659aa89931ed,supported).
node(n1844,refuted) :- status(o_f154e2d5659aa89931ed,refuted).
node(n1844,unknown) :- status(o_f154e2d5659aa89931ed,unknown).
node(n1845,supported) :- status(o_7dfbcc296ae8b3540226,supported).
node(n1845,refuted) :- status(o_7dfbcc296ae8b3540226,refuted).
node(n1845,unknown) :- status(o_7dfbcc296ae8b3540226,unknown).
node(n1846,supported) :- status(o_8360765729abee05682b,supported).
node(n1846,refuted) :- status(o_8360765729abee05682b,refuted).
node(n1846,unknown) :- status(o_8360765729abee05682b,unknown).
node(n1843,supported) :- node(n1844,supported), node(n1845,supported), node(n1846,supported).
node(n1843,refuted) :- node(n1844,refuted).
node(n1843,refuted) :- node(n1845,refuted).
node(n1843,refuted) :- node(n1846,refuted).
node(n1843,unknown) :- \+ node(n1843,supported), \+ node(n1843,refuted).
node(n1848,supported) :- status(o_6536aaa1c481d11d62d3,supported).
node(n1848,refuted) :- status(o_6536aaa1c481d11d62d3,refuted).
node(n1848,unknown) :- status(o_6536aaa1c481d11d62d3,unknown).
node(n1849,supported) :- status(o_db5c098b729c56b25252,supported).
node(n1849,refuted) :- status(o_db5c098b729c56b25252,refuted).
node(n1849,unknown) :- status(o_db5c098b729c56b25252,unknown).
node(n1850,supported) :- status(o_318793ebc83a0cec6566,supported).
node(n1850,refuted) :- status(o_318793ebc83a0cec6566,refuted).
node(n1850,unknown) :- status(o_318793ebc83a0cec6566,unknown).
node(n1847,supported) :- node(n1848,supported), node(n1849,supported), node(n1850,supported).
node(n1847,refuted) :- node(n1848,refuted).
node(n1847,refuted) :- node(n1849,refuted).
node(n1847,refuted) :- node(n1850,refuted).
node(n1847,unknown) :- \+ node(n1847,supported), \+ node(n1847,refuted).
node(n1842,refuted) :- node(n1843,refuted), node(n1847,refuted), node(n9,refuted).
node(n1842,supported) :- node(n1843,supported).
node(n1842,supported) :- node(n1847,supported).
node(n1842,supported) :- node(n9,supported).
node(n1842,unknown) :- \+ node(n1842,supported), \+ node(n1842,refuted).
verdict(c_831452643cd0f121,supported) :- node(n1842,supported).
query(verdict(c_831452643cd0f121,supported)).
verdict(c_831452643cd0f121,refuted) :- node(n1842,refuted).
query(verdict(c_831452643cd0f121,refuted)).
verdict(c_831452643cd0f121,unknown) :- node(n1842,unknown).
query(verdict(c_831452643cd0f121,unknown)).
node(n1853,supported) :- status(o_d336ac63513450cce26c,supported).
node(n1853,refuted) :- status(o_d336ac63513450cce26c,refuted).
node(n1853,unknown) :- status(o_d336ac63513450cce26c,unknown).
node(n1852,supported) :- node(n1844,supported), node(n1845,supported), node(n1846,supported), node(n1853,supported).
node(n1852,refuted) :- node(n1844,refuted).
node(n1852,refuted) :- node(n1845,refuted).
node(n1852,refuted) :- node(n1846,refuted).
node(n1852,refuted) :- node(n1853,refuted).
node(n1852,unknown) :- \+ node(n1852,supported), \+ node(n1852,refuted).
node(n1855,supported) :- status(o_468ed5709f6b9cef5906,supported).
node(n1855,refuted) :- status(o_468ed5709f6b9cef5906,refuted).
node(n1855,unknown) :- status(o_468ed5709f6b9cef5906,unknown).
node(n1854,supported) :- node(n1848,supported), node(n1849,supported), node(n1850,supported), node(n1855,supported).
node(n1854,refuted) :- node(n1848,refuted).
node(n1854,refuted) :- node(n1849,refuted).
node(n1854,refuted) :- node(n1850,refuted).
node(n1854,refuted) :- node(n1855,refuted).
node(n1854,unknown) :- \+ node(n1854,supported), \+ node(n1854,refuted).
node(n1851,refuted) :- node(n1852,refuted), node(n1854,refuted), node(n9,refuted).
node(n1851,supported) :- node(n1852,supported).
node(n1851,supported) :- node(n1854,supported).
node(n1851,supported) :- node(n9,supported).
node(n1851,unknown) :- \+ node(n1851,supported), \+ node(n1851,refuted).
verdict(c_d076803d9cb3e292,supported) :- node(n1851,supported).
query(verdict(c_d076803d9cb3e292,supported)).
verdict(c_d076803d9cb3e292,refuted) :- node(n1851,refuted).
query(verdict(c_d076803d9cb3e292,refuted)).
verdict(c_d076803d9cb3e292,unknown) :- node(n1851,unknown).
query(verdict(c_d076803d9cb3e292,unknown)).
node(n1858,supported) :- status(o_222784d95691759723dc,supported).
node(n1858,refuted) :- status(o_222784d95691759723dc,refuted).
node(n1858,unknown) :- status(o_222784d95691759723dc,unknown).
node(n1859,supported) :- status(o_13e5e0d7e6441ffe385a,supported).
node(n1859,refuted) :- status(o_13e5e0d7e6441ffe385a,refuted).
node(n1859,unknown) :- status(o_13e5e0d7e6441ffe385a,unknown).
node(n1857,supported) :- node(n1844,supported), node(n1845,supported), node(n1846,supported), node(n1853,supported), node(n1858,supported), node(n1859,supported).
node(n1857,refuted) :- node(n1844,refuted).
node(n1857,refuted) :- node(n1845,refuted).
node(n1857,refuted) :- node(n1846,refuted).
node(n1857,refuted) :- node(n1853,refuted).
node(n1857,refuted) :- node(n1858,refuted).
node(n1857,refuted) :- node(n1859,refuted).
node(n1857,unknown) :- \+ node(n1857,supported), \+ node(n1857,refuted).
node(n1861,supported) :- status(o_5afd556c9ddb228cddd4,supported).
node(n1861,refuted) :- status(o_5afd556c9ddb228cddd4,refuted).
node(n1861,unknown) :- status(o_5afd556c9ddb228cddd4,unknown).
node(n1862,supported) :- status(o_096100267337c3a5271f,supported).
node(n1862,refuted) :- status(o_096100267337c3a5271f,refuted).
node(n1862,unknown) :- status(o_096100267337c3a5271f,unknown).
node(n1860,supported) :- node(n1848,supported), node(n1849,supported), node(n1850,supported), node(n1855,supported), node(n1861,supported), node(n1862,supported).
node(n1860,refuted) :- node(n1848,refuted).
node(n1860,refuted) :- node(n1849,refuted).
node(n1860,refuted) :- node(n1850,refuted).
node(n1860,refuted) :- node(n1855,refuted).
node(n1860,refuted) :- node(n1861,refuted).
node(n1860,refuted) :- node(n1862,refuted).
node(n1860,unknown) :- \+ node(n1860,supported), \+ node(n1860,refuted).
node(n1856,refuted) :- node(n1857,refuted), node(n1860,refuted), node(n9,refuted).
node(n1856,supported) :- node(n1857,supported).
node(n1856,supported) :- node(n1860,supported).
node(n1856,supported) :- node(n9,supported).
node(n1856,unknown) :- \+ node(n1856,supported), \+ node(n1856,refuted).
verdict(c_13d9d18b0b06e12f,supported) :- node(n1856,supported).
query(verdict(c_13d9d18b0b06e12f,supported)).
verdict(c_13d9d18b0b06e12f,refuted) :- node(n1856,refuted).
query(verdict(c_13d9d18b0b06e12f,refuted)).
verdict(c_13d9d18b0b06e12f,unknown) :- node(n1856,unknown).
query(verdict(c_13d9d18b0b06e12f,unknown)).
node(n1865,supported) :- status(o_5152b8420dc74ba7527a,supported).
node(n1865,refuted) :- status(o_5152b8420dc74ba7527a,refuted).
node(n1865,unknown) :- status(o_5152b8420dc74ba7527a,unknown).
node(n1864,supported) :- node(n1844,supported), node(n1845,supported), node(n1865,supported).
node(n1864,refuted) :- node(n1844,refuted).
node(n1864,refuted) :- node(n1845,refuted).
node(n1864,refuted) :- node(n1865,refuted).
node(n1864,unknown) :- \+ node(n1864,supported), \+ node(n1864,refuted).
node(n1867,supported) :- status(o_c220f40c2193041a22df,supported).
node(n1867,refuted) :- status(o_c220f40c2193041a22df,refuted).
node(n1867,unknown) :- status(o_c220f40c2193041a22df,unknown).
node(n1866,supported) :- node(n1848,supported), node(n1849,supported), node(n1867,supported).
node(n1866,refuted) :- node(n1848,refuted).
node(n1866,refuted) :- node(n1849,refuted).
node(n1866,refuted) :- node(n1867,refuted).
node(n1866,unknown) :- \+ node(n1866,supported), \+ node(n1866,refuted).
node(n1863,refuted) :- node(n1864,refuted), node(n1866,refuted), node(n9,refuted).
node(n1863,supported) :- node(n1864,supported).
node(n1863,supported) :- node(n1866,supported).
node(n1863,supported) :- node(n9,supported).
node(n1863,unknown) :- \+ node(n1863,supported), \+ node(n1863,refuted).
verdict(c_f85e09e3cab971eb,supported) :- node(n1863,supported).
query(verdict(c_f85e09e3cab971eb,supported)).
verdict(c_f85e09e3cab971eb,refuted) :- node(n1863,refuted).
query(verdict(c_f85e09e3cab971eb,refuted)).
verdict(c_f85e09e3cab971eb,unknown) :- node(n1863,unknown).
query(verdict(c_f85e09e3cab971eb,unknown)).
node(n1869,supported) :- node(n1844,supported), node(n1845,supported), node(n1846,supported), node(n1865,supported).
node(n1869,refuted) :- node(n1844,refuted).
node(n1869,refuted) :- node(n1845,refuted).
node(n1869,refuted) :- node(n1846,refuted).
node(n1869,refuted) :- node(n1865,refuted).
node(n1869,unknown) :- \+ node(n1869,supported), \+ node(n1869,refuted).
node(n1870,supported) :- node(n1848,supported), node(n1849,supported), node(n1850,supported), node(n1867,supported).
node(n1870,refuted) :- node(n1848,refuted).
node(n1870,refuted) :- node(n1849,refuted).
node(n1870,refuted) :- node(n1850,refuted).
node(n1870,refuted) :- node(n1867,refuted).
node(n1870,unknown) :- \+ node(n1870,supported), \+ node(n1870,refuted).
node(n1868,refuted) :- node(n1869,refuted), node(n1870,refuted), node(n9,refuted).
node(n1868,supported) :- node(n1869,supported).
node(n1868,supported) :- node(n1870,supported).
node(n1868,supported) :- node(n9,supported).
node(n1868,unknown) :- \+ node(n1868,supported), \+ node(n1868,refuted).
verdict(c_b03f4d94dff543d6,supported) :- node(n1868,supported).
query(verdict(c_b03f4d94dff543d6,supported)).
verdict(c_b03f4d94dff543d6,refuted) :- node(n1868,refuted).
query(verdict(c_b03f4d94dff543d6,refuted)).
verdict(c_b03f4d94dff543d6,unknown) :- node(n1868,unknown).
query(verdict(c_b03f4d94dff543d6,unknown)).
node(n1873,supported) :- status(o_89cecf9732127e905f38,supported).
node(n1873,refuted) :- status(o_89cecf9732127e905f38,refuted).
node(n1873,unknown) :- status(o_89cecf9732127e905f38,unknown).
node(n1874,supported) :- status(o_5d9490126fa26d341478,supported).
node(n1874,refuted) :- status(o_5d9490126fa26d341478,refuted).
node(n1874,unknown) :- status(o_5d9490126fa26d341478,unknown).
node(n1875,supported) :- status(o_d0962efd3b3365eea7f8,supported).
node(n1875,refuted) :- status(o_d0962efd3b3365eea7f8,refuted).
node(n1875,unknown) :- status(o_d0962efd3b3365eea7f8,unknown).
node(n1872,supported) :- node(n1873,supported), node(n1874,supported), node(n1875,supported).
node(n1872,refuted) :- node(n1873,refuted).
node(n1872,refuted) :- node(n1874,refuted).
node(n1872,refuted) :- node(n1875,refuted).
node(n1872,unknown) :- \+ node(n1872,supported), \+ node(n1872,refuted).
node(n1871,refuted) :- node(n1872,refuted), node(n9,refuted).
node(n1871,supported) :- node(n1872,supported).
node(n1871,supported) :- node(n9,supported).
node(n1871,unknown) :- \+ node(n1871,supported), \+ node(n1871,refuted).
verdict(c_58bc35de2f94369d,supported) :- node(n1871,supported).
query(verdict(c_58bc35de2f94369d,supported)).
verdict(c_58bc35de2f94369d,refuted) :- node(n1871,refuted).
query(verdict(c_58bc35de2f94369d,refuted)).
verdict(c_58bc35de2f94369d,unknown) :- node(n1871,unknown).
query(verdict(c_58bc35de2f94369d,unknown)).
node(n1878,supported) :- status(o_a0f35ea0a888755382ed,supported).
node(n1878,refuted) :- status(o_a0f35ea0a888755382ed,refuted).
node(n1878,unknown) :- status(o_a0f35ea0a888755382ed,unknown).
node(n1877,supported) :- node(n1873,supported), node(n1874,supported), node(n1875,supported), node(n1878,supported).
node(n1877,refuted) :- node(n1873,refuted).
node(n1877,refuted) :- node(n1874,refuted).
node(n1877,refuted) :- node(n1875,refuted).
node(n1877,refuted) :- node(n1878,refuted).
node(n1877,unknown) :- \+ node(n1877,supported), \+ node(n1877,refuted).
node(n1876,refuted) :- node(n1877,refuted), node(n9,refuted).
node(n1876,supported) :- node(n1877,supported).
node(n1876,supported) :- node(n9,supported).
node(n1876,unknown) :- \+ node(n1876,supported), \+ node(n1876,refuted).
verdict(c_6897eba3e2e1c5e6,supported) :- node(n1876,supported).
query(verdict(c_6897eba3e2e1c5e6,supported)).
verdict(c_6897eba3e2e1c5e6,refuted) :- node(n1876,refuted).
query(verdict(c_6897eba3e2e1c5e6,refuted)).
verdict(c_6897eba3e2e1c5e6,unknown) :- node(n1876,unknown).
query(verdict(c_6897eba3e2e1c5e6,unknown)).
node(n1881,supported) :- status(o_441e919acce0edfe56ab,supported).
node(n1881,refuted) :- status(o_441e919acce0edfe56ab,refuted).
node(n1881,unknown) :- status(o_441e919acce0edfe56ab,unknown).
node(n1882,supported) :- status(o_72b6e08810511e3ae16a,supported).
node(n1882,refuted) :- status(o_72b6e08810511e3ae16a,refuted).
node(n1882,unknown) :- status(o_72b6e08810511e3ae16a,unknown).
node(n1880,supported) :- node(n1873,supported), node(n1874,supported), node(n1875,supported), node(n1878,supported), node(n1881,supported), node(n1882,supported).
node(n1880,refuted) :- node(n1873,refuted).
node(n1880,refuted) :- node(n1874,refuted).
node(n1880,refuted) :- node(n1875,refuted).
node(n1880,refuted) :- node(n1878,refuted).
node(n1880,refuted) :- node(n1881,refuted).
node(n1880,refuted) :- node(n1882,refuted).
node(n1880,unknown) :- \+ node(n1880,supported), \+ node(n1880,refuted).
node(n1879,refuted) :- node(n1880,refuted), node(n9,refuted).
node(n1879,supported) :- node(n1880,supported).
node(n1879,supported) :- node(n9,supported).
node(n1879,unknown) :- \+ node(n1879,supported), \+ node(n1879,refuted).
verdict(c_b9c4c44c67ac12da,supported) :- node(n1879,supported).
query(verdict(c_b9c4c44c67ac12da,supported)).
verdict(c_b9c4c44c67ac12da,refuted) :- node(n1879,refuted).
query(verdict(c_b9c4c44c67ac12da,refuted)).
verdict(c_b9c4c44c67ac12da,unknown) :- node(n1879,unknown).
query(verdict(c_b9c4c44c67ac12da,unknown)).
node(n1885,supported) :- status(o_416e5e94197e85645ab7,supported).
node(n1885,refuted) :- status(o_416e5e94197e85645ab7,refuted).
node(n1885,unknown) :- status(o_416e5e94197e85645ab7,unknown).
node(n1884,supported) :- node(n1873,supported), node(n1874,supported), node(n1885,supported).
node(n1884,refuted) :- node(n1873,refuted).
node(n1884,refuted) :- node(n1874,refuted).
node(n1884,refuted) :- node(n1885,refuted).
node(n1884,unknown) :- \+ node(n1884,supported), \+ node(n1884,refuted).
node(n1883,refuted) :- node(n1884,refuted), node(n9,refuted).
node(n1883,supported) :- node(n1884,supported).
node(n1883,supported) :- node(n9,supported).
node(n1883,unknown) :- \+ node(n1883,supported), \+ node(n1883,refuted).
verdict(c_49bc39a2dace8e58,supported) :- node(n1883,supported).
query(verdict(c_49bc39a2dace8e58,supported)).
verdict(c_49bc39a2dace8e58,refuted) :- node(n1883,refuted).
query(verdict(c_49bc39a2dace8e58,refuted)).
verdict(c_49bc39a2dace8e58,unknown) :- node(n1883,unknown).
query(verdict(c_49bc39a2dace8e58,unknown)).
node(n1887,supported) :- node(n1873,supported), node(n1874,supported), node(n1875,supported), node(n1885,supported).
node(n1887,refuted) :- node(n1873,refuted).
node(n1887,refuted) :- node(n1874,refuted).
node(n1887,refuted) :- node(n1875,refuted).
node(n1887,refuted) :- node(n1885,refuted).
node(n1887,unknown) :- \+ node(n1887,supported), \+ node(n1887,refuted).
node(n1886,refuted) :- node(n1887,refuted), node(n9,refuted).
node(n1886,supported) :- node(n1887,supported).
node(n1886,supported) :- node(n9,supported).
node(n1886,unknown) :- \+ node(n1886,supported), \+ node(n1886,refuted).
verdict(c_4a06685a8967959c,supported) :- node(n1886,supported).
query(verdict(c_4a06685a8967959c,supported)).
verdict(c_4a06685a8967959c,refuted) :- node(n1886,refuted).
query(verdict(c_4a06685a8967959c,refuted)).
verdict(c_4a06685a8967959c,unknown) :- node(n1886,unknown).
query(verdict(c_4a06685a8967959c,unknown)).
node(n1890,supported) :- status(o_19a67469bd154fc77bbb,supported).
node(n1890,refuted) :- status(o_19a67469bd154fc77bbb,refuted).
node(n1890,unknown) :- status(o_19a67469bd154fc77bbb,unknown).
node(n1891,supported) :- status(o_fbd6b8bb57bf07ff9482,supported).
node(n1891,refuted) :- status(o_fbd6b8bb57bf07ff9482,refuted).
node(n1891,unknown) :- status(o_fbd6b8bb57bf07ff9482,unknown).
node(n1892,supported) :- status(o_f5db951324718ddea538,supported).
node(n1892,refuted) :- status(o_f5db951324718ddea538,refuted).
node(n1892,unknown) :- status(o_f5db951324718ddea538,unknown).
node(n1889,supported) :- node(n1890,supported), node(n1891,supported), node(n1892,supported).
node(n1889,refuted) :- node(n1890,refuted).
node(n1889,refuted) :- node(n1891,refuted).
node(n1889,refuted) :- node(n1892,refuted).
node(n1889,unknown) :- \+ node(n1889,supported), \+ node(n1889,refuted).
node(n1888,refuted) :- node(n1889,refuted), node(n9,refuted).
node(n1888,supported) :- node(n1889,supported).
node(n1888,supported) :- node(n9,supported).
node(n1888,unknown) :- \+ node(n1888,supported), \+ node(n1888,refuted).
verdict(c_e17b410ad44efd2e,supported) :- node(n1888,supported).
query(verdict(c_e17b410ad44efd2e,supported)).
verdict(c_e17b410ad44efd2e,refuted) :- node(n1888,refuted).
query(verdict(c_e17b410ad44efd2e,refuted)).
verdict(c_e17b410ad44efd2e,unknown) :- node(n1888,unknown).
query(verdict(c_e17b410ad44efd2e,unknown)).
node(n1895,supported) :- status(o_de273979067664e0ca57,supported).
node(n1895,refuted) :- status(o_de273979067664e0ca57,refuted).
node(n1895,unknown) :- status(o_de273979067664e0ca57,unknown).
node(n1894,supported) :- node(n1890,supported), node(n1891,supported), node(n1892,supported), node(n1895,supported).
node(n1894,refuted) :- node(n1890,refuted).
node(n1894,refuted) :- node(n1891,refuted).
node(n1894,refuted) :- node(n1892,refuted).
node(n1894,refuted) :- node(n1895,refuted).
node(n1894,unknown) :- \+ node(n1894,supported), \+ node(n1894,refuted).
node(n1893,refuted) :- node(n1894,refuted), node(n9,refuted).
node(n1893,supported) :- node(n1894,supported).
node(n1893,supported) :- node(n9,supported).
node(n1893,unknown) :- \+ node(n1893,supported), \+ node(n1893,refuted).
verdict(c_cee26de21c452652,supported) :- node(n1893,supported).
query(verdict(c_cee26de21c452652,supported)).
verdict(c_cee26de21c452652,refuted) :- node(n1893,refuted).
query(verdict(c_cee26de21c452652,refuted)).
verdict(c_cee26de21c452652,unknown) :- node(n1893,unknown).
query(verdict(c_cee26de21c452652,unknown)).
node(n1898,supported) :- status(o_b23f08e6804f3ef76fc9,supported).
node(n1898,refuted) :- status(o_b23f08e6804f3ef76fc9,refuted).
node(n1898,unknown) :- status(o_b23f08e6804f3ef76fc9,unknown).
node(n1899,supported) :- status(o_93d037006e19c94d46b5,supported).
node(n1899,refuted) :- status(o_93d037006e19c94d46b5,refuted).
node(n1899,unknown) :- status(o_93d037006e19c94d46b5,unknown).
node(n1897,supported) :- node(n1890,supported), node(n1891,supported), node(n1892,supported), node(n1895,supported), node(n1898,supported), node(n1899,supported).
node(n1897,refuted) :- node(n1890,refuted).
node(n1897,refuted) :- node(n1891,refuted).
node(n1897,refuted) :- node(n1892,refuted).
node(n1897,refuted) :- node(n1895,refuted).
node(n1897,refuted) :- node(n1898,refuted).
node(n1897,refuted) :- node(n1899,refuted).
node(n1897,unknown) :- \+ node(n1897,supported), \+ node(n1897,refuted).
node(n1896,refuted) :- node(n1897,refuted), node(n9,refuted).
node(n1896,supported) :- node(n1897,supported).
node(n1896,supported) :- node(n9,supported).
node(n1896,unknown) :- \+ node(n1896,supported), \+ node(n1896,refuted).
verdict(c_647f06eb16a39bdf,supported) :- node(n1896,supported).
query(verdict(c_647f06eb16a39bdf,supported)).
verdict(c_647f06eb16a39bdf,refuted) :- node(n1896,refuted).
query(verdict(c_647f06eb16a39bdf,refuted)).
verdict(c_647f06eb16a39bdf,unknown) :- node(n1896,unknown).
query(verdict(c_647f06eb16a39bdf,unknown)).
node(n1902,supported) :- status(o_aa47169f475643434256,supported).
node(n1902,refuted) :- status(o_aa47169f475643434256,refuted).
node(n1902,unknown) :- status(o_aa47169f475643434256,unknown).
node(n1901,supported) :- node(n1890,supported), node(n1891,supported), node(n1902,supported).
node(n1901,refuted) :- node(n1890,refuted).
node(n1901,refuted) :- node(n1891,refuted).
node(n1901,refuted) :- node(n1902,refuted).
node(n1901,unknown) :- \+ node(n1901,supported), \+ node(n1901,refuted).
node(n1900,refuted) :- node(n1901,refuted), node(n9,refuted).
node(n1900,supported) :- node(n1901,supported).
node(n1900,supported) :- node(n9,supported).
node(n1900,unknown) :- \+ node(n1900,supported), \+ node(n1900,refuted).
verdict(c_5d80241ee6098ed3,supported) :- node(n1900,supported).
query(verdict(c_5d80241ee6098ed3,supported)).
verdict(c_5d80241ee6098ed3,refuted) :- node(n1900,refuted).
query(verdict(c_5d80241ee6098ed3,refuted)).
verdict(c_5d80241ee6098ed3,unknown) :- node(n1900,unknown).
query(verdict(c_5d80241ee6098ed3,unknown)).
node(n1904,supported) :- node(n1890,supported), node(n1891,supported), node(n1892,supported), node(n1902,supported).
node(n1904,refuted) :- node(n1890,refuted).
node(n1904,refuted) :- node(n1891,refuted).
node(n1904,refuted) :- node(n1892,refuted).
node(n1904,refuted) :- node(n1902,refuted).
node(n1904,unknown) :- \+ node(n1904,supported), \+ node(n1904,refuted).
node(n1903,refuted) :- node(n1904,refuted), node(n9,refuted).
node(n1903,supported) :- node(n1904,supported).
node(n1903,supported) :- node(n9,supported).
node(n1903,unknown) :- \+ node(n1903,supported), \+ node(n1903,refuted).
verdict(c_0ee50cd505f85308,supported) :- node(n1903,supported).
query(verdict(c_0ee50cd505f85308,supported)).
verdict(c_0ee50cd505f85308,refuted) :- node(n1903,refuted).
query(verdict(c_0ee50cd505f85308,refuted)).
verdict(c_0ee50cd505f85308,unknown) :- node(n1903,unknown).
query(verdict(c_0ee50cd505f85308,unknown)).
node(n1907,supported) :- status(o_0abef6bf37bbd92bbfb0,supported).
node(n1907,refuted) :- status(o_0abef6bf37bbd92bbfb0,refuted).
node(n1907,unknown) :- status(o_0abef6bf37bbd92bbfb0,unknown).
node(n1908,supported) :- status(o_941670903a9ed187ced1,supported).
node(n1908,refuted) :- status(o_941670903a9ed187ced1,refuted).
node(n1908,unknown) :- status(o_941670903a9ed187ced1,unknown).
node(n1909,supported) :- status(o_048fbd17b230ce792022,supported).
node(n1909,refuted) :- status(o_048fbd17b230ce792022,refuted).
node(n1909,unknown) :- status(o_048fbd17b230ce792022,unknown).
node(n1906,supported) :- node(n1907,supported), node(n1908,supported), node(n1909,supported).
node(n1906,refuted) :- node(n1907,refuted).
node(n1906,refuted) :- node(n1908,refuted).
node(n1906,refuted) :- node(n1909,refuted).
node(n1906,unknown) :- \+ node(n1906,supported), \+ node(n1906,refuted).
node(n1905,refuted) :- node(n1906,refuted), node(n9,refuted).
node(n1905,supported) :- node(n1906,supported).
node(n1905,supported) :- node(n9,supported).
node(n1905,unknown) :- \+ node(n1905,supported), \+ node(n1905,refuted).
verdict(c_2d78ec5318b34447,supported) :- node(n1905,supported).
query(verdict(c_2d78ec5318b34447,supported)).
verdict(c_2d78ec5318b34447,refuted) :- node(n1905,refuted).
query(verdict(c_2d78ec5318b34447,refuted)).
verdict(c_2d78ec5318b34447,unknown) :- node(n1905,unknown).
query(verdict(c_2d78ec5318b34447,unknown)).
node(n1912,supported) :- status(o_3508e4edb9b5d6b43b21,supported).
node(n1912,refuted) :- status(o_3508e4edb9b5d6b43b21,refuted).
node(n1912,unknown) :- status(o_3508e4edb9b5d6b43b21,unknown).
node(n1911,supported) :- node(n1907,supported), node(n1908,supported), node(n1909,supported), node(n1912,supported).
node(n1911,refuted) :- node(n1907,refuted).
node(n1911,refuted) :- node(n1908,refuted).
node(n1911,refuted) :- node(n1909,refuted).
node(n1911,refuted) :- node(n1912,refuted).
node(n1911,unknown) :- \+ node(n1911,supported), \+ node(n1911,refuted).
node(n1910,refuted) :- node(n1911,refuted), node(n9,refuted).
node(n1910,supported) :- node(n1911,supported).
node(n1910,supported) :- node(n9,supported).
node(n1910,unknown) :- \+ node(n1910,supported), \+ node(n1910,refuted).
verdict(c_75ef6a0d3662f5eb,supported) :- node(n1910,supported).
query(verdict(c_75ef6a0d3662f5eb,supported)).
verdict(c_75ef6a0d3662f5eb,refuted) :- node(n1910,refuted).
query(verdict(c_75ef6a0d3662f5eb,refuted)).
verdict(c_75ef6a0d3662f5eb,unknown) :- node(n1910,unknown).
query(verdict(c_75ef6a0d3662f5eb,unknown)).
node(n1915,supported) :- status(o_23a48761d1816fadfcbb,supported).
node(n1915,refuted) :- status(o_23a48761d1816fadfcbb,refuted).
node(n1915,unknown) :- status(o_23a48761d1816fadfcbb,unknown).
node(n1916,supported) :- status(o_2fe345f0929505a8b534,supported).
node(n1916,refuted) :- status(o_2fe345f0929505a8b534,refuted).
node(n1916,unknown) :- status(o_2fe345f0929505a8b534,unknown).
node(n1914,supported) :- node(n1907,supported), node(n1908,supported), node(n1909,supported), node(n1912,supported), node(n1915,supported), node(n1916,supported).
node(n1914,refuted) :- node(n1907,refuted).
node(n1914,refuted) :- node(n1908,refuted).
node(n1914,refuted) :- node(n1909,refuted).
node(n1914,refuted) :- node(n1912,refuted).
node(n1914,refuted) :- node(n1915,refuted).
node(n1914,refuted) :- node(n1916,refuted).
node(n1914,unknown) :- \+ node(n1914,supported), \+ node(n1914,refuted).
node(n1913,refuted) :- node(n1914,refuted), node(n9,refuted).
node(n1913,supported) :- node(n1914,supported).
node(n1913,supported) :- node(n9,supported).
node(n1913,unknown) :- \+ node(n1913,supported), \+ node(n1913,refuted).
verdict(c_38e92c138c9a61ec,supported) :- node(n1913,supported).
query(verdict(c_38e92c138c9a61ec,supported)).
verdict(c_38e92c138c9a61ec,refuted) :- node(n1913,refuted).
query(verdict(c_38e92c138c9a61ec,refuted)).
verdict(c_38e92c138c9a61ec,unknown) :- node(n1913,unknown).
query(verdict(c_38e92c138c9a61ec,unknown)).
node(n1919,supported) :- status(o_ea8eda7f01f8b33472e3,supported).
node(n1919,refuted) :- status(o_ea8eda7f01f8b33472e3,refuted).
node(n1919,unknown) :- status(o_ea8eda7f01f8b33472e3,unknown).
node(n1918,supported) :- node(n1907,supported), node(n1908,supported), node(n1919,supported).
node(n1918,refuted) :- node(n1907,refuted).
node(n1918,refuted) :- node(n1908,refuted).
node(n1918,refuted) :- node(n1919,refuted).
node(n1918,unknown) :- \+ node(n1918,supported), \+ node(n1918,refuted).
node(n1917,refuted) :- node(n1918,refuted), node(n9,refuted).
node(n1917,supported) :- node(n1918,supported).
node(n1917,supported) :- node(n9,supported).
node(n1917,unknown) :- \+ node(n1917,supported), \+ node(n1917,refuted).
verdict(c_1b6d5e1705543182,supported) :- node(n1917,supported).
query(verdict(c_1b6d5e1705543182,supported)).
verdict(c_1b6d5e1705543182,refuted) :- node(n1917,refuted).
query(verdict(c_1b6d5e1705543182,refuted)).
verdict(c_1b6d5e1705543182,unknown) :- node(n1917,unknown).
query(verdict(c_1b6d5e1705543182,unknown)).
node(n1921,supported) :- node(n1907,supported), node(n1908,supported), node(n1909,supported), node(n1919,supported).
node(n1921,refuted) :- node(n1907,refuted).
node(n1921,refuted) :- node(n1908,refuted).
node(n1921,refuted) :- node(n1909,refuted).
node(n1921,refuted) :- node(n1919,refuted).
node(n1921,unknown) :- \+ node(n1921,supported), \+ node(n1921,refuted).
node(n1920,refuted) :- node(n1921,refuted), node(n9,refuted).
node(n1920,supported) :- node(n1921,supported).
node(n1920,supported) :- node(n9,supported).
node(n1920,unknown) :- \+ node(n1920,supported), \+ node(n1920,refuted).
verdict(c_b958560bf0499ea1,supported) :- node(n1920,supported).
query(verdict(c_b958560bf0499ea1,supported)).
verdict(c_b958560bf0499ea1,refuted) :- node(n1920,refuted).
query(verdict(c_b958560bf0499ea1,refuted)).
verdict(c_b958560bf0499ea1,unknown) :- node(n1920,unknown).
query(verdict(c_b958560bf0499ea1,unknown)).
node(n1924,supported) :- status(o_2d399fcd8fa0152f0695,supported).
node(n1924,refuted) :- status(o_2d399fcd8fa0152f0695,refuted).
node(n1924,unknown) :- status(o_2d399fcd8fa0152f0695,unknown).
node(n1925,supported) :- status(o_cad5724412c44adabf7d,supported).
node(n1925,refuted) :- status(o_cad5724412c44adabf7d,refuted).
node(n1925,unknown) :- status(o_cad5724412c44adabf7d,unknown).
node(n1926,supported) :- status(o_0de694408a7f537751d5,supported).
node(n1926,refuted) :- status(o_0de694408a7f537751d5,refuted).
node(n1926,unknown) :- status(o_0de694408a7f537751d5,unknown).
node(n1923,supported) :- node(n1924,supported), node(n1925,supported), node(n1926,supported).
node(n1923,refuted) :- node(n1924,refuted).
node(n1923,refuted) :- node(n1925,refuted).
node(n1923,refuted) :- node(n1926,refuted).
node(n1923,unknown) :- \+ node(n1923,supported), \+ node(n1923,refuted).
node(n1922,refuted) :- node(n1923,refuted), node(n9,refuted).
node(n1922,supported) :- node(n1923,supported).
node(n1922,supported) :- node(n9,supported).
node(n1922,unknown) :- \+ node(n1922,supported), \+ node(n1922,refuted).
verdict(c_d9693ae5ccf3ef0e,supported) :- node(n1922,supported).
query(verdict(c_d9693ae5ccf3ef0e,supported)).
verdict(c_d9693ae5ccf3ef0e,refuted) :- node(n1922,refuted).
query(verdict(c_d9693ae5ccf3ef0e,refuted)).
verdict(c_d9693ae5ccf3ef0e,unknown) :- node(n1922,unknown).
query(verdict(c_d9693ae5ccf3ef0e,unknown)).
node(n1929,supported) :- status(o_8ce3e0a182571e665c76,supported).
node(n1929,refuted) :- status(o_8ce3e0a182571e665c76,refuted).
node(n1929,unknown) :- status(o_8ce3e0a182571e665c76,unknown).
node(n1928,supported) :- node(n1924,supported), node(n1925,supported), node(n1926,supported), node(n1929,supported).
node(n1928,refuted) :- node(n1924,refuted).
node(n1928,refuted) :- node(n1925,refuted).
node(n1928,refuted) :- node(n1926,refuted).
node(n1928,refuted) :- node(n1929,refuted).
node(n1928,unknown) :- \+ node(n1928,supported), \+ node(n1928,refuted).
node(n1927,refuted) :- node(n1928,refuted), node(n9,refuted).
node(n1927,supported) :- node(n1928,supported).
node(n1927,supported) :- node(n9,supported).
node(n1927,unknown) :- \+ node(n1927,supported), \+ node(n1927,refuted).
verdict(c_1f61f809c5f933db,supported) :- node(n1927,supported).
query(verdict(c_1f61f809c5f933db,supported)).
verdict(c_1f61f809c5f933db,refuted) :- node(n1927,refuted).
query(verdict(c_1f61f809c5f933db,refuted)).
verdict(c_1f61f809c5f933db,unknown) :- node(n1927,unknown).
query(verdict(c_1f61f809c5f933db,unknown)).
node(n1932,supported) :- status(o_00d349367fa992fed1a0,supported).
node(n1932,refuted) :- status(o_00d349367fa992fed1a0,refuted).
node(n1932,unknown) :- status(o_00d349367fa992fed1a0,unknown).
node(n1933,supported) :- status(o_8c14b3e6420c3ad49ff9,supported).
node(n1933,refuted) :- status(o_8c14b3e6420c3ad49ff9,refuted).
node(n1933,unknown) :- status(o_8c14b3e6420c3ad49ff9,unknown).
node(n1931,supported) :- node(n1924,supported), node(n1925,supported), node(n1926,supported), node(n1929,supported), node(n1932,supported), node(n1933,supported).
node(n1931,refuted) :- node(n1924,refuted).
node(n1931,refuted) :- node(n1925,refuted).
node(n1931,refuted) :- node(n1926,refuted).
node(n1931,refuted) :- node(n1929,refuted).
node(n1931,refuted) :- node(n1932,refuted).
node(n1931,refuted) :- node(n1933,refuted).
node(n1931,unknown) :- \+ node(n1931,supported), \+ node(n1931,refuted).
node(n1930,refuted) :- node(n1931,refuted), node(n9,refuted).
node(n1930,supported) :- node(n1931,supported).
node(n1930,supported) :- node(n9,supported).
node(n1930,unknown) :- \+ node(n1930,supported), \+ node(n1930,refuted).
verdict(c_a5d6f5215af64965,supported) :- node(n1930,supported).
query(verdict(c_a5d6f5215af64965,supported)).
verdict(c_a5d6f5215af64965,refuted) :- node(n1930,refuted).
query(verdict(c_a5d6f5215af64965,refuted)).
verdict(c_a5d6f5215af64965,unknown) :- node(n1930,unknown).
query(verdict(c_a5d6f5215af64965,unknown)).
node(n1936,supported) :- status(o_5246e0da2191f9a4234c,supported).
node(n1936,refuted) :- status(o_5246e0da2191f9a4234c,refuted).
node(n1936,unknown) :- status(o_5246e0da2191f9a4234c,unknown).
node(n1935,supported) :- node(n1924,supported), node(n1925,supported), node(n1936,supported).
node(n1935,refuted) :- node(n1924,refuted).
node(n1935,refuted) :- node(n1925,refuted).
node(n1935,refuted) :- node(n1936,refuted).
node(n1935,unknown) :- \+ node(n1935,supported), \+ node(n1935,refuted).
node(n1934,refuted) :- node(n1935,refuted), node(n9,refuted).
node(n1934,supported) :- node(n1935,supported).
node(n1934,supported) :- node(n9,supported).
node(n1934,unknown) :- \+ node(n1934,supported), \+ node(n1934,refuted).
verdict(c_80e31fcd3227a953,supported) :- node(n1934,supported).
query(verdict(c_80e31fcd3227a953,supported)).
verdict(c_80e31fcd3227a953,refuted) :- node(n1934,refuted).
query(verdict(c_80e31fcd3227a953,refuted)).
verdict(c_80e31fcd3227a953,unknown) :- node(n1934,unknown).
query(verdict(c_80e31fcd3227a953,unknown)).
node(n1938,supported) :- node(n1924,supported), node(n1925,supported), node(n1926,supported), node(n1936,supported).
node(n1938,refuted) :- node(n1924,refuted).
node(n1938,refuted) :- node(n1925,refuted).
node(n1938,refuted) :- node(n1926,refuted).
node(n1938,refuted) :- node(n1936,refuted).
node(n1938,unknown) :- \+ node(n1938,supported), \+ node(n1938,refuted).
node(n1937,refuted) :- node(n1938,refuted), node(n9,refuted).
node(n1937,supported) :- node(n1938,supported).
node(n1937,supported) :- node(n9,supported).
node(n1937,unknown) :- \+ node(n1937,supported), \+ node(n1937,refuted).
verdict(c_25278f6a3fc14664,supported) :- node(n1937,supported).
query(verdict(c_25278f6a3fc14664,supported)).
verdict(c_25278f6a3fc14664,refuted) :- node(n1937,refuted).
query(verdict(c_25278f6a3fc14664,refuted)).
verdict(c_25278f6a3fc14664,unknown) :- node(n1937,unknown).
query(verdict(c_25278f6a3fc14664,unknown)).
node(n1941,supported) :- status(o_e0474a61cfe85562a998,supported).
node(n1941,refuted) :- status(o_e0474a61cfe85562a998,refuted).
node(n1941,unknown) :- status(o_e0474a61cfe85562a998,unknown).
node(n1942,supported) :- status(o_2630f44fe0e5b747c24b,supported).
node(n1942,refuted) :- status(o_2630f44fe0e5b747c24b,refuted).
node(n1942,unknown) :- status(o_2630f44fe0e5b747c24b,unknown).
node(n1943,supported) :- status(o_2e51ed694e2c552883b3,supported).
node(n1943,refuted) :- status(o_2e51ed694e2c552883b3,refuted).
node(n1943,unknown) :- status(o_2e51ed694e2c552883b3,unknown).
node(n1940,supported) :- node(n1941,supported), node(n1942,supported), node(n1943,supported).
node(n1940,refuted) :- node(n1941,refuted).
node(n1940,refuted) :- node(n1942,refuted).
node(n1940,refuted) :- node(n1943,refuted).
node(n1940,unknown) :- \+ node(n1940,supported), \+ node(n1940,refuted).
node(n1939,refuted) :- node(n1940,refuted), node(n9,refuted).
node(n1939,supported) :- node(n1940,supported).
node(n1939,supported) :- node(n9,supported).
node(n1939,unknown) :- \+ node(n1939,supported), \+ node(n1939,refuted).
verdict(c_fe5b56d0c9dd8b96,supported) :- node(n1939,supported).
query(verdict(c_fe5b56d0c9dd8b96,supported)).
verdict(c_fe5b56d0c9dd8b96,refuted) :- node(n1939,refuted).
query(verdict(c_fe5b56d0c9dd8b96,refuted)).
verdict(c_fe5b56d0c9dd8b96,unknown) :- node(n1939,unknown).
query(verdict(c_fe5b56d0c9dd8b96,unknown)).
node(n1946,supported) :- status(o_0384398be9d70d1f3447,supported).
node(n1946,refuted) :- status(o_0384398be9d70d1f3447,refuted).
node(n1946,unknown) :- status(o_0384398be9d70d1f3447,unknown).
node(n1945,supported) :- node(n1941,supported), node(n1942,supported), node(n1943,supported), node(n1946,supported).
node(n1945,refuted) :- node(n1941,refuted).
node(n1945,refuted) :- node(n1942,refuted).
node(n1945,refuted) :- node(n1943,refuted).
node(n1945,refuted) :- node(n1946,refuted).
node(n1945,unknown) :- \+ node(n1945,supported), \+ node(n1945,refuted).
node(n1944,refuted) :- node(n1945,refuted), node(n9,refuted).
node(n1944,supported) :- node(n1945,supported).
node(n1944,supported) :- node(n9,supported).
node(n1944,unknown) :- \+ node(n1944,supported), \+ node(n1944,refuted).
verdict(c_d1afa4a3aee3121e,supported) :- node(n1944,supported).
query(verdict(c_d1afa4a3aee3121e,supported)).
verdict(c_d1afa4a3aee3121e,refuted) :- node(n1944,refuted).
query(verdict(c_d1afa4a3aee3121e,refuted)).
verdict(c_d1afa4a3aee3121e,unknown) :- node(n1944,unknown).
query(verdict(c_d1afa4a3aee3121e,unknown)).
node(n1949,supported) :- status(o_974538fec76e42d94146,supported).
node(n1949,refuted) :- status(o_974538fec76e42d94146,refuted).
node(n1949,unknown) :- status(o_974538fec76e42d94146,unknown).
node(n1950,supported) :- status(o_428b655d6a5d5b500205,supported).
node(n1950,refuted) :- status(o_428b655d6a5d5b500205,refuted).
node(n1950,unknown) :- status(o_428b655d6a5d5b500205,unknown).
node(n1948,supported) :- node(n1941,supported), node(n1942,supported), node(n1943,supported), node(n1946,supported), node(n1949,supported), node(n1950,supported).
node(n1948,refuted) :- node(n1941,refuted).
node(n1948,refuted) :- node(n1942,refuted).
node(n1948,refuted) :- node(n1943,refuted).
node(n1948,refuted) :- node(n1946,refuted).
node(n1948,refuted) :- node(n1949,refuted).
node(n1948,refuted) :- node(n1950,refuted).
node(n1948,unknown) :- \+ node(n1948,supported), \+ node(n1948,refuted).
node(n1947,refuted) :- node(n1948,refuted), node(n9,refuted).
node(n1947,supported) :- node(n1948,supported).
node(n1947,supported) :- node(n9,supported).
node(n1947,unknown) :- \+ node(n1947,supported), \+ node(n1947,refuted).
verdict(c_125f86c534dff535,supported) :- node(n1947,supported).
query(verdict(c_125f86c534dff535,supported)).
verdict(c_125f86c534dff535,refuted) :- node(n1947,refuted).
query(verdict(c_125f86c534dff535,refuted)).
verdict(c_125f86c534dff535,unknown) :- node(n1947,unknown).
query(verdict(c_125f86c534dff535,unknown)).
node(n1953,supported) :- status(o_a78bf4cc3ba494b53928,supported).
node(n1953,refuted) :- status(o_a78bf4cc3ba494b53928,refuted).
node(n1953,unknown) :- status(o_a78bf4cc3ba494b53928,unknown).
node(n1952,supported) :- node(n1941,supported), node(n1942,supported), node(n1953,supported).
node(n1952,refuted) :- node(n1941,refuted).
node(n1952,refuted) :- node(n1942,refuted).
node(n1952,refuted) :- node(n1953,refuted).
node(n1952,unknown) :- \+ node(n1952,supported), \+ node(n1952,refuted).
node(n1951,refuted) :- node(n1952,refuted), node(n9,refuted).
node(n1951,supported) :- node(n1952,supported).
node(n1951,supported) :- node(n9,supported).
node(n1951,unknown) :- \+ node(n1951,supported), \+ node(n1951,refuted).
verdict(c_3398e67af981d523,supported) :- node(n1951,supported).
query(verdict(c_3398e67af981d523,supported)).
verdict(c_3398e67af981d523,refuted) :- node(n1951,refuted).
query(verdict(c_3398e67af981d523,refuted)).
verdict(c_3398e67af981d523,unknown) :- node(n1951,unknown).
query(verdict(c_3398e67af981d523,unknown)).
node(n1955,supported) :- node(n1941,supported), node(n1942,supported), node(n1943,supported), node(n1953,supported).
node(n1955,refuted) :- node(n1941,refuted).
node(n1955,refuted) :- node(n1942,refuted).
node(n1955,refuted) :- node(n1943,refuted).
node(n1955,refuted) :- node(n1953,refuted).
node(n1955,unknown) :- \+ node(n1955,supported), \+ node(n1955,refuted).
node(n1954,refuted) :- node(n1955,refuted), node(n9,refuted).
node(n1954,supported) :- node(n1955,supported).
node(n1954,supported) :- node(n9,supported).
node(n1954,unknown) :- \+ node(n1954,supported), \+ node(n1954,refuted).
verdict(c_c12284823a3b909e,supported) :- node(n1954,supported).
query(verdict(c_c12284823a3b909e,supported)).
verdict(c_c12284823a3b909e,refuted) :- node(n1954,refuted).
query(verdict(c_c12284823a3b909e,refuted)).
verdict(c_c12284823a3b909e,unknown) :- node(n1954,unknown).
query(verdict(c_c12284823a3b909e,unknown)).
node(n1958,supported) :- status(o_01afeed185f79f387e2b,supported).
node(n1958,refuted) :- status(o_01afeed185f79f387e2b,refuted).
node(n1958,unknown) :- status(o_01afeed185f79f387e2b,unknown).
node(n1959,supported) :- status(o_a2b80fa9d773535f8831,supported).
node(n1959,refuted) :- status(o_a2b80fa9d773535f8831,refuted).
node(n1959,unknown) :- status(o_a2b80fa9d773535f8831,unknown).
node(n1960,supported) :- status(o_809b6b04bc4e9773c86b,supported).
node(n1960,refuted) :- status(o_809b6b04bc4e9773c86b,refuted).
node(n1960,unknown) :- status(o_809b6b04bc4e9773c86b,unknown).
node(n1957,supported) :- node(n1958,supported), node(n1959,supported), node(n1960,supported).
node(n1957,refuted) :- node(n1958,refuted).
node(n1957,refuted) :- node(n1959,refuted).
node(n1957,refuted) :- node(n1960,refuted).
node(n1957,unknown) :- \+ node(n1957,supported), \+ node(n1957,refuted).
node(n1962,supported) :- status(o_a5dc23ae225d02442c48,supported).
node(n1962,refuted) :- status(o_a5dc23ae225d02442c48,refuted).
node(n1962,unknown) :- status(o_a5dc23ae225d02442c48,unknown).
node(n1963,supported) :- status(o_b90275f9aae920038ffa,supported).
node(n1963,refuted) :- status(o_b90275f9aae920038ffa,refuted).
node(n1963,unknown) :- status(o_b90275f9aae920038ffa,unknown).
node(n1964,supported) :- status(o_00cceca778286f138990,supported).
node(n1964,refuted) :- status(o_00cceca778286f138990,refuted).
node(n1964,unknown) :- status(o_00cceca778286f138990,unknown).
node(n1961,supported) :- node(n1962,supported), node(n1963,supported), node(n1964,supported).
node(n1961,refuted) :- node(n1962,refuted).
node(n1961,refuted) :- node(n1963,refuted).
node(n1961,refuted) :- node(n1964,refuted).
node(n1961,unknown) :- \+ node(n1961,supported), \+ node(n1961,refuted).
node(n1956,refuted) :- node(n1957,refuted), node(n1961,refuted), node(n9,refuted).
node(n1956,supported) :- node(n1957,supported).
node(n1956,supported) :- node(n1961,supported).
node(n1956,supported) :- node(n9,supported).
node(n1956,unknown) :- \+ node(n1956,supported), \+ node(n1956,refuted).
verdict(c_7b2b9a0284444b0a,supported) :- node(n1956,supported).
query(verdict(c_7b2b9a0284444b0a,supported)).
verdict(c_7b2b9a0284444b0a,refuted) :- node(n1956,refuted).
query(verdict(c_7b2b9a0284444b0a,refuted)).
verdict(c_7b2b9a0284444b0a,unknown) :- node(n1956,unknown).
query(verdict(c_7b2b9a0284444b0a,unknown)).
node(n1967,supported) :- status(o_0721eb85bc4f09e2d07c,supported).
node(n1967,refuted) :- status(o_0721eb85bc4f09e2d07c,refuted).
node(n1967,unknown) :- status(o_0721eb85bc4f09e2d07c,unknown).
node(n1966,supported) :- node(n1958,supported), node(n1959,supported), node(n1960,supported), node(n1967,supported).
node(n1966,refuted) :- node(n1958,refuted).
node(n1966,refuted) :- node(n1959,refuted).
node(n1966,refuted) :- node(n1960,refuted).
node(n1966,refuted) :- node(n1967,refuted).
node(n1966,unknown) :- \+ node(n1966,supported), \+ node(n1966,refuted).
node(n1969,supported) :- status(o_245a59cbec95f041a8fb,supported).
node(n1969,refuted) :- status(o_245a59cbec95f041a8fb,refuted).
node(n1969,unknown) :- status(o_245a59cbec95f041a8fb,unknown).
node(n1968,supported) :- node(n1962,supported), node(n1963,supported), node(n1964,supported), node(n1969,supported).
node(n1968,refuted) :- node(n1962,refuted).
node(n1968,refuted) :- node(n1963,refuted).
node(n1968,refuted) :- node(n1964,refuted).
node(n1968,refuted) :- node(n1969,refuted).
node(n1968,unknown) :- \+ node(n1968,supported), \+ node(n1968,refuted).
node(n1965,refuted) :- node(n1966,refuted), node(n1968,refuted), node(n9,refuted).
node(n1965,supported) :- node(n1966,supported).
node(n1965,supported) :- node(n1968,supported).
node(n1965,supported) :- node(n9,supported).
node(n1965,unknown) :- \+ node(n1965,supported), \+ node(n1965,refuted).
verdict(c_9941657da078b1f5,supported) :- node(n1965,supported).
query(verdict(c_9941657da078b1f5,supported)).
verdict(c_9941657da078b1f5,refuted) :- node(n1965,refuted).
query(verdict(c_9941657da078b1f5,refuted)).
verdict(c_9941657da078b1f5,unknown) :- node(n1965,unknown).
query(verdict(c_9941657da078b1f5,unknown)).
node(n1972,supported) :- status(o_fb13a646425ba88d2480,supported).
node(n1972,refuted) :- status(o_fb13a646425ba88d2480,refuted).
node(n1972,unknown) :- status(o_fb13a646425ba88d2480,unknown).
node(n1973,supported) :- status(o_6293767f4b44d9a27b86,supported).
node(n1973,refuted) :- status(o_6293767f4b44d9a27b86,refuted).
node(n1973,unknown) :- status(o_6293767f4b44d9a27b86,unknown).
node(n1971,supported) :- node(n1958,supported), node(n1959,supported), node(n1960,supported), node(n1967,supported), node(n1972,supported), node(n1973,supported).
node(n1971,refuted) :- node(n1958,refuted).
node(n1971,refuted) :- node(n1959,refuted).
node(n1971,refuted) :- node(n1960,refuted).
node(n1971,refuted) :- node(n1967,refuted).
node(n1971,refuted) :- node(n1972,refuted).
node(n1971,refuted) :- node(n1973,refuted).
node(n1971,unknown) :- \+ node(n1971,supported), \+ node(n1971,refuted).
node(n1975,supported) :- status(o_aafb03b5ef24fcb52612,supported).
node(n1975,refuted) :- status(o_aafb03b5ef24fcb52612,refuted).
node(n1975,unknown) :- status(o_aafb03b5ef24fcb52612,unknown).
node(n1976,supported) :- status(o_af46469a7bb664fae51f,supported).
node(n1976,refuted) :- status(o_af46469a7bb664fae51f,refuted).
node(n1976,unknown) :- status(o_af46469a7bb664fae51f,unknown).
node(n1974,supported) :- node(n1962,supported), node(n1963,supported), node(n1964,supported), node(n1969,supported), node(n1975,supported), node(n1976,supported).
node(n1974,refuted) :- node(n1962,refuted).
node(n1974,refuted) :- node(n1963,refuted).
node(n1974,refuted) :- node(n1964,refuted).
node(n1974,refuted) :- node(n1969,refuted).
node(n1974,refuted) :- node(n1975,refuted).
node(n1974,refuted) :- node(n1976,refuted).
node(n1974,unknown) :- \+ node(n1974,supported), \+ node(n1974,refuted).
node(n1970,refuted) :- node(n1971,refuted), node(n1974,refuted), node(n9,refuted).
node(n1970,supported) :- node(n1971,supported).
node(n1970,supported) :- node(n1974,supported).
node(n1970,supported) :- node(n9,supported).
node(n1970,unknown) :- \+ node(n1970,supported), \+ node(n1970,refuted).
verdict(c_67316bb9d382d58f,supported) :- node(n1970,supported).
query(verdict(c_67316bb9d382d58f,supported)).
verdict(c_67316bb9d382d58f,refuted) :- node(n1970,refuted).
query(verdict(c_67316bb9d382d58f,refuted)).
verdict(c_67316bb9d382d58f,unknown) :- node(n1970,unknown).
query(verdict(c_67316bb9d382d58f,unknown)).
node(n1979,supported) :- status(o_20b77f84d904aa78e934,supported).
node(n1979,refuted) :- status(o_20b77f84d904aa78e934,refuted).
node(n1979,unknown) :- status(o_20b77f84d904aa78e934,unknown).
node(n1978,supported) :- node(n1958,supported), node(n1959,supported), node(n1979,supported).
node(n1978,refuted) :- node(n1958,refuted).
node(n1978,refuted) :- node(n1959,refuted).
node(n1978,refuted) :- node(n1979,refuted).
node(n1978,unknown) :- \+ node(n1978,supported), \+ node(n1978,refuted).
node(n1981,supported) :- status(o_801c31918729886ff1e4,supported).
node(n1981,refuted) :- status(o_801c31918729886ff1e4,refuted).
node(n1981,unknown) :- status(o_801c31918729886ff1e4,unknown).
node(n1980,supported) :- node(n1962,supported), node(n1963,supported), node(n1981,supported).
node(n1980,refuted) :- node(n1962,refuted).
node(n1980,refuted) :- node(n1963,refuted).
node(n1980,refuted) :- node(n1981,refuted).
node(n1980,unknown) :- \+ node(n1980,supported), \+ node(n1980,refuted).
node(n1977,refuted) :- node(n1978,refuted), node(n1980,refuted), node(n9,refuted).
node(n1977,supported) :- node(n1978,supported).
node(n1977,supported) :- node(n1980,supported).
node(n1977,supported) :- node(n9,supported).
node(n1977,unknown) :- \+ node(n1977,supported), \+ node(n1977,refuted).
verdict(c_f0bec4908998e8e8,supported) :- node(n1977,supported).
query(verdict(c_f0bec4908998e8e8,supported)).
verdict(c_f0bec4908998e8e8,refuted) :- node(n1977,refuted).
query(verdict(c_f0bec4908998e8e8,refuted)).
verdict(c_f0bec4908998e8e8,unknown) :- node(n1977,unknown).
query(verdict(c_f0bec4908998e8e8,unknown)).
node(n1983,supported) :- node(n1958,supported), node(n1959,supported), node(n1960,supported), node(n1979,supported).
node(n1983,refuted) :- node(n1958,refuted).
node(n1983,refuted) :- node(n1959,refuted).
node(n1983,refuted) :- node(n1960,refuted).
node(n1983,refuted) :- node(n1979,refuted).
node(n1983,unknown) :- \+ node(n1983,supported), \+ node(n1983,refuted).
node(n1984,supported) :- node(n1962,supported), node(n1963,supported), node(n1964,supported), node(n1981,supported).
node(n1984,refuted) :- node(n1962,refuted).
node(n1984,refuted) :- node(n1963,refuted).
node(n1984,refuted) :- node(n1964,refuted).
node(n1984,refuted) :- node(n1981,refuted).
node(n1984,unknown) :- \+ node(n1984,supported), \+ node(n1984,refuted).
node(n1982,refuted) :- node(n1983,refuted), node(n1984,refuted), node(n9,refuted).
node(n1982,supported) :- node(n1983,supported).
node(n1982,supported) :- node(n1984,supported).
node(n1982,supported) :- node(n9,supported).
node(n1982,unknown) :- \+ node(n1982,supported), \+ node(n1982,refuted).
verdict(c_c8c9dba19d64debb,supported) :- node(n1982,supported).
query(verdict(c_c8c9dba19d64debb,supported)).
verdict(c_c8c9dba19d64debb,refuted) :- node(n1982,refuted).
query(verdict(c_c8c9dba19d64debb,refuted)).
verdict(c_c8c9dba19d64debb,unknown) :- node(n1982,unknown).
query(verdict(c_c8c9dba19d64debb,unknown)).
node(n1987,supported) :- status(o_9df46a7278c03fc421c0,supported).
node(n1987,refuted) :- status(o_9df46a7278c03fc421c0,refuted).
node(n1987,unknown) :- status(o_9df46a7278c03fc421c0,unknown).
node(n1988,supported) :- status(o_3eb98e1a537974471e6e,supported).
node(n1988,refuted) :- status(o_3eb98e1a537974471e6e,refuted).
node(n1988,unknown) :- status(o_3eb98e1a537974471e6e,unknown).
node(n1989,supported) :- status(o_4dff44d0f78f37e81bb1,supported).
node(n1989,refuted) :- status(o_4dff44d0f78f37e81bb1,refuted).
node(n1989,unknown) :- status(o_4dff44d0f78f37e81bb1,unknown).
node(n1986,supported) :- node(n1987,supported), node(n1988,supported), node(n1989,supported).
node(n1986,refuted) :- node(n1987,refuted).
node(n1986,refuted) :- node(n1988,refuted).
node(n1986,refuted) :- node(n1989,refuted).
node(n1986,unknown) :- \+ node(n1986,supported), \+ node(n1986,refuted).
node(n1991,supported) :- status(o_76f77003a5227f200728,supported).
node(n1991,refuted) :- status(o_76f77003a5227f200728,refuted).
node(n1991,unknown) :- status(o_76f77003a5227f200728,unknown).
node(n1992,supported) :- status(o_cbf23ee1358e61bea908,supported).
node(n1992,refuted) :- status(o_cbf23ee1358e61bea908,refuted).
node(n1992,unknown) :- status(o_cbf23ee1358e61bea908,unknown).
node(n1993,supported) :- status(o_023e48e2bb067f1e4c40,supported).
node(n1993,refuted) :- status(o_023e48e2bb067f1e4c40,refuted).
node(n1993,unknown) :- status(o_023e48e2bb067f1e4c40,unknown).
node(n1990,supported) :- node(n1991,supported), node(n1992,supported), node(n1993,supported).
node(n1990,refuted) :- node(n1991,refuted).
node(n1990,refuted) :- node(n1992,refuted).
node(n1990,refuted) :- node(n1993,refuted).
node(n1990,unknown) :- \+ node(n1990,supported), \+ node(n1990,refuted).
node(n1985,refuted) :- node(n1986,refuted), node(n1990,refuted), node(n9,refuted).
node(n1985,supported) :- node(n1986,supported).
node(n1985,supported) :- node(n1990,supported).
node(n1985,supported) :- node(n9,supported).
node(n1985,unknown) :- \+ node(n1985,supported), \+ node(n1985,refuted).
verdict(c_79f0e738329ea57a,supported) :- node(n1985,supported).
query(verdict(c_79f0e738329ea57a,supported)).
verdict(c_79f0e738329ea57a,refuted) :- node(n1985,refuted).
query(verdict(c_79f0e738329ea57a,refuted)).
verdict(c_79f0e738329ea57a,unknown) :- node(n1985,unknown).
query(verdict(c_79f0e738329ea57a,unknown)).
node(n1996,supported) :- status(o_e42bc9625d21172c97c6,supported).
node(n1996,refuted) :- status(o_e42bc9625d21172c97c6,refuted).
node(n1996,unknown) :- status(o_e42bc9625d21172c97c6,unknown).
node(n1995,supported) :- node(n1987,supported), node(n1988,supported), node(n1989,supported), node(n1996,supported).
node(n1995,refuted) :- node(n1987,refuted).
node(n1995,refuted) :- node(n1988,refuted).
node(n1995,refuted) :- node(n1989,refuted).
node(n1995,refuted) :- node(n1996,refuted).
node(n1995,unknown) :- \+ node(n1995,supported), \+ node(n1995,refuted).
node(n1998,supported) :- status(o_46880351d762613f194c,supported).
node(n1998,refuted) :- status(o_46880351d762613f194c,refuted).
node(n1998,unknown) :- status(o_46880351d762613f194c,unknown).
node(n1997,supported) :- node(n1991,supported), node(n1992,supported), node(n1993,supported), node(n1998,supported).
node(n1997,refuted) :- node(n1991,refuted).
node(n1997,refuted) :- node(n1992,refuted).
node(n1997,refuted) :- node(n1993,refuted).
node(n1997,refuted) :- node(n1998,refuted).
node(n1997,unknown) :- \+ node(n1997,supported), \+ node(n1997,refuted).
node(n1994,refuted) :- node(n1995,refuted), node(n1997,refuted), node(n9,refuted).
node(n1994,supported) :- node(n1995,supported).
node(n1994,supported) :- node(n1997,supported).
node(n1994,supported) :- node(n9,supported).
node(n1994,unknown) :- \+ node(n1994,supported), \+ node(n1994,refuted).
verdict(c_0eaac849de6fb367,supported) :- node(n1994,supported).
query(verdict(c_0eaac849de6fb367,supported)).
verdict(c_0eaac849de6fb367,refuted) :- node(n1994,refuted).
query(verdict(c_0eaac849de6fb367,refuted)).
verdict(c_0eaac849de6fb367,unknown) :- node(n1994,unknown).
query(verdict(c_0eaac849de6fb367,unknown)).
node(n2001,supported) :- status(o_4e8bde75705a59e53deb,supported).
node(n2001,refuted) :- status(o_4e8bde75705a59e53deb,refuted).
node(n2001,unknown) :- status(o_4e8bde75705a59e53deb,unknown).
node(n2002,supported) :- status(o_9658dae5abced03b0e3f,supported).
node(n2002,refuted) :- status(o_9658dae5abced03b0e3f,refuted).
node(n2002,unknown) :- status(o_9658dae5abced03b0e3f,unknown).
node(n2000,supported) :- node(n1987,supported), node(n1988,supported), node(n1989,supported), node(n1996,supported), node(n2001,supported), node(n2002,supported).
node(n2000,refuted) :- node(n1987,refuted).
node(n2000,refuted) :- node(n1988,refuted).
node(n2000,refuted) :- node(n1989,refuted).
node(n2000,refuted) :- node(n1996,refuted).
node(n2000,refuted) :- node(n2001,refuted).
node(n2000,refuted) :- node(n2002,refuted).
node(n2000,unknown) :- \+ node(n2000,supported), \+ node(n2000,refuted).
node(n2004,supported) :- status(o_0e3183f37adc7dd88ac9,supported).
node(n2004,refuted) :- status(o_0e3183f37adc7dd88ac9,refuted).
node(n2004,unknown) :- status(o_0e3183f37adc7dd88ac9,unknown).
node(n2005,supported) :- status(o_beca17c645ddd54bf4e6,supported).
node(n2005,refuted) :- status(o_beca17c645ddd54bf4e6,refuted).
node(n2005,unknown) :- status(o_beca17c645ddd54bf4e6,unknown).
node(n2003,supported) :- node(n1991,supported), node(n1992,supported), node(n1993,supported), node(n1998,supported), node(n2004,supported), node(n2005,supported).
node(n2003,refuted) :- node(n1991,refuted).
node(n2003,refuted) :- node(n1992,refuted).
node(n2003,refuted) :- node(n1993,refuted).
node(n2003,refuted) :- node(n1998,refuted).
node(n2003,refuted) :- node(n2004,refuted).
node(n2003,refuted) :- node(n2005,refuted).
node(n2003,unknown) :- \+ node(n2003,supported), \+ node(n2003,refuted).
node(n1999,refuted) :- node(n2000,refuted), node(n2003,refuted), node(n9,refuted).
node(n1999,supported) :- node(n2000,supported).
node(n1999,supported) :- node(n2003,supported).
node(n1999,supported) :- node(n9,supported).
node(n1999,unknown) :- \+ node(n1999,supported), \+ node(n1999,refuted).
verdict(c_0c457254985fbbe7,supported) :- node(n1999,supported).
query(verdict(c_0c457254985fbbe7,supported)).
verdict(c_0c457254985fbbe7,refuted) :- node(n1999,refuted).
query(verdict(c_0c457254985fbbe7,refuted)).
verdict(c_0c457254985fbbe7,unknown) :- node(n1999,unknown).
query(verdict(c_0c457254985fbbe7,unknown)).
node(n2008,supported) :- status(o_bb0f462adc4218b7c1b0,supported).
node(n2008,refuted) :- status(o_bb0f462adc4218b7c1b0,refuted).
node(n2008,unknown) :- status(o_bb0f462adc4218b7c1b0,unknown).
node(n2007,supported) :- node(n1987,supported), node(n1988,supported), node(n2008,supported).
node(n2007,refuted) :- node(n1987,refuted).
node(n2007,refuted) :- node(n1988,refuted).
node(n2007,refuted) :- node(n2008,refuted).
node(n2007,unknown) :- \+ node(n2007,supported), \+ node(n2007,refuted).
node(n2010,supported) :- status(o_b38e98b359e24159ffe7,supported).
node(n2010,refuted) :- status(o_b38e98b359e24159ffe7,refuted).
node(n2010,unknown) :- status(o_b38e98b359e24159ffe7,unknown).
node(n2009,supported) :- node(n1991,supported), node(n1992,supported), node(n2010,supported).
node(n2009,refuted) :- node(n1991,refuted).
node(n2009,refuted) :- node(n1992,refuted).
node(n2009,refuted) :- node(n2010,refuted).
node(n2009,unknown) :- \+ node(n2009,supported), \+ node(n2009,refuted).
node(n2006,refuted) :- node(n2007,refuted), node(n2009,refuted), node(n9,refuted).
node(n2006,supported) :- node(n2007,supported).
node(n2006,supported) :- node(n2009,supported).
node(n2006,supported) :- node(n9,supported).
node(n2006,unknown) :- \+ node(n2006,supported), \+ node(n2006,refuted).
verdict(c_d1d4b0f861b10d78,supported) :- node(n2006,supported).
query(verdict(c_d1d4b0f861b10d78,supported)).
verdict(c_d1d4b0f861b10d78,refuted) :- node(n2006,refuted).
query(verdict(c_d1d4b0f861b10d78,refuted)).
verdict(c_d1d4b0f861b10d78,unknown) :- node(n2006,unknown).
query(verdict(c_d1d4b0f861b10d78,unknown)).
node(n2012,supported) :- node(n1987,supported), node(n1988,supported), node(n1989,supported), node(n2008,supported).
node(n2012,refuted) :- node(n1987,refuted).
node(n2012,refuted) :- node(n1988,refuted).
node(n2012,refuted) :- node(n1989,refuted).
node(n2012,refuted) :- node(n2008,refuted).
node(n2012,unknown) :- \+ node(n2012,supported), \+ node(n2012,refuted).
node(n2013,supported) :- node(n1991,supported), node(n1992,supported), node(n1993,supported), node(n2010,supported).
node(n2013,refuted) :- node(n1991,refuted).
node(n2013,refuted) :- node(n1992,refuted).
node(n2013,refuted) :- node(n1993,refuted).
node(n2013,refuted) :- node(n2010,refuted).
node(n2013,unknown) :- \+ node(n2013,supported), \+ node(n2013,refuted).
node(n2011,refuted) :- node(n2012,refuted), node(n2013,refuted), node(n9,refuted).
node(n2011,supported) :- node(n2012,supported).
node(n2011,supported) :- node(n2013,supported).
node(n2011,supported) :- node(n9,supported).
node(n2011,unknown) :- \+ node(n2011,supported), \+ node(n2011,refuted).
verdict(c_ed95f11d04c42ac4,supported) :- node(n2011,supported).
query(verdict(c_ed95f11d04c42ac4,supported)).
verdict(c_ed95f11d04c42ac4,refuted) :- node(n2011,refuted).
query(verdict(c_ed95f11d04c42ac4,refuted)).
verdict(c_ed95f11d04c42ac4,unknown) :- node(n2011,unknown).
query(verdict(c_ed95f11d04c42ac4,unknown)).
node(n2016,supported) :- status(o_8baed694a0944fb7fb8d,supported).
node(n2016,refuted) :- status(o_8baed694a0944fb7fb8d,refuted).
node(n2016,unknown) :- status(o_8baed694a0944fb7fb8d,unknown).
node(n2017,supported) :- status(o_086165ba462a9247b42b,supported).
node(n2017,refuted) :- status(o_086165ba462a9247b42b,refuted).
node(n2017,unknown) :- status(o_086165ba462a9247b42b,unknown).
node(n2018,supported) :- status(o_db481b9f3c92f3c0d928,supported).
node(n2018,refuted) :- status(o_db481b9f3c92f3c0d928,refuted).
node(n2018,unknown) :- status(o_db481b9f3c92f3c0d928,unknown).
node(n2015,supported) :- node(n2016,supported), node(n2017,supported), node(n2018,supported).
node(n2015,refuted) :- node(n2016,refuted).
node(n2015,refuted) :- node(n2017,refuted).
node(n2015,refuted) :- node(n2018,refuted).
node(n2015,unknown) :- \+ node(n2015,supported), \+ node(n2015,refuted).
node(n2020,supported) :- status(o_8d97031b12b50ebc9bf5,supported).
node(n2020,refuted) :- status(o_8d97031b12b50ebc9bf5,refuted).
node(n2020,unknown) :- status(o_8d97031b12b50ebc9bf5,unknown).
node(n2021,supported) :- status(o_d694712a3037b095ce1a,supported).
node(n2021,refuted) :- status(o_d694712a3037b095ce1a,refuted).
node(n2021,unknown) :- status(o_d694712a3037b095ce1a,unknown).
node(n2022,supported) :- status(o_48d07ce9509d549dc25d,supported).
node(n2022,refuted) :- status(o_48d07ce9509d549dc25d,refuted).
node(n2022,unknown) :- status(o_48d07ce9509d549dc25d,unknown).
node(n2019,supported) :- node(n2020,supported), node(n2021,supported), node(n2022,supported).
node(n2019,refuted) :- node(n2020,refuted).
node(n2019,refuted) :- node(n2021,refuted).
node(n2019,refuted) :- node(n2022,refuted).
node(n2019,unknown) :- \+ node(n2019,supported), \+ node(n2019,refuted).
node(n2014,refuted) :- node(n2015,refuted), node(n2019,refuted), node(n9,refuted).
node(n2014,supported) :- node(n2015,supported).
node(n2014,supported) :- node(n2019,supported).
node(n2014,supported) :- node(n9,supported).
node(n2014,unknown) :- \+ node(n2014,supported), \+ node(n2014,refuted).
verdict(c_c712e78ce6ad9a3b,supported) :- node(n2014,supported).
query(verdict(c_c712e78ce6ad9a3b,supported)).
verdict(c_c712e78ce6ad9a3b,refuted) :- node(n2014,refuted).
query(verdict(c_c712e78ce6ad9a3b,refuted)).
verdict(c_c712e78ce6ad9a3b,unknown) :- node(n2014,unknown).
query(verdict(c_c712e78ce6ad9a3b,unknown)).
node(n2025,supported) :- status(o_e104d9720e2c174cf9e7,supported).
node(n2025,refuted) :- status(o_e104d9720e2c174cf9e7,refuted).
node(n2025,unknown) :- status(o_e104d9720e2c174cf9e7,unknown).
node(n2024,supported) :- node(n2016,supported), node(n2017,supported), node(n2018,supported), node(n2025,supported).
node(n2024,refuted) :- node(n2016,refuted).
node(n2024,refuted) :- node(n2017,refuted).
node(n2024,refuted) :- node(n2018,refuted).
node(n2024,refuted) :- node(n2025,refuted).
node(n2024,unknown) :- \+ node(n2024,supported), \+ node(n2024,refuted).
node(n2027,supported) :- status(o_44fcb59128352ed85c2a,supported).
node(n2027,refuted) :- status(o_44fcb59128352ed85c2a,refuted).
node(n2027,unknown) :- status(o_44fcb59128352ed85c2a,unknown).
node(n2026,supported) :- node(n2020,supported), node(n2021,supported), node(n2022,supported), node(n2027,supported).
node(n2026,refuted) :- node(n2020,refuted).
node(n2026,refuted) :- node(n2021,refuted).
node(n2026,refuted) :- node(n2022,refuted).
node(n2026,refuted) :- node(n2027,refuted).
node(n2026,unknown) :- \+ node(n2026,supported), \+ node(n2026,refuted).
node(n2023,refuted) :- node(n2024,refuted), node(n2026,refuted), node(n9,refuted).
node(n2023,supported) :- node(n2024,supported).
node(n2023,supported) :- node(n2026,supported).
node(n2023,supported) :- node(n9,supported).
node(n2023,unknown) :- \+ node(n2023,supported), \+ node(n2023,refuted).
verdict(c_a4be3ae6ef6d07fd,supported) :- node(n2023,supported).
query(verdict(c_a4be3ae6ef6d07fd,supported)).
verdict(c_a4be3ae6ef6d07fd,refuted) :- node(n2023,refuted).
query(verdict(c_a4be3ae6ef6d07fd,refuted)).
verdict(c_a4be3ae6ef6d07fd,unknown) :- node(n2023,unknown).
query(verdict(c_a4be3ae6ef6d07fd,unknown)).
node(n2030,supported) :- status(o_272248f7750133d23ce8,supported).
node(n2030,refuted) :- status(o_272248f7750133d23ce8,refuted).
node(n2030,unknown) :- status(o_272248f7750133d23ce8,unknown).
node(n2031,supported) :- status(o_7d886354deee17531da1,supported).
node(n2031,refuted) :- status(o_7d886354deee17531da1,refuted).
node(n2031,unknown) :- status(o_7d886354deee17531da1,unknown).
node(n2029,supported) :- node(n2016,supported), node(n2017,supported), node(n2018,supported), node(n2025,supported), node(n2030,supported), node(n2031,supported).
node(n2029,refuted) :- node(n2016,refuted).
node(n2029,refuted) :- node(n2017,refuted).
node(n2029,refuted) :- node(n2018,refuted).
node(n2029,refuted) :- node(n2025,refuted).
node(n2029,refuted) :- node(n2030,refuted).
node(n2029,refuted) :- node(n2031,refuted).
node(n2029,unknown) :- \+ node(n2029,supported), \+ node(n2029,refuted).
node(n2033,supported) :- status(o_1579904599b3c3065804,supported).
node(n2033,refuted) :- status(o_1579904599b3c3065804,refuted).
node(n2033,unknown) :- status(o_1579904599b3c3065804,unknown).
node(n2034,supported) :- status(o_3816a9ef8f5d9c8e70c5,supported).
node(n2034,refuted) :- status(o_3816a9ef8f5d9c8e70c5,refuted).
node(n2034,unknown) :- status(o_3816a9ef8f5d9c8e70c5,unknown).
node(n2032,supported) :- node(n2020,supported), node(n2021,supported), node(n2022,supported), node(n2027,supported), node(n2033,supported), node(n2034,supported).
node(n2032,refuted) :- node(n2020,refuted).
node(n2032,refuted) :- node(n2021,refuted).
node(n2032,refuted) :- node(n2022,refuted).
node(n2032,refuted) :- node(n2027,refuted).
node(n2032,refuted) :- node(n2033,refuted).
node(n2032,refuted) :- node(n2034,refuted).
node(n2032,unknown) :- \+ node(n2032,supported), \+ node(n2032,refuted).
node(n2028,refuted) :- node(n2029,refuted), node(n2032,refuted), node(n9,refuted).
node(n2028,supported) :- node(n2029,supported).
node(n2028,supported) :- node(n2032,supported).
node(n2028,supported) :- node(n9,supported).
node(n2028,unknown) :- \+ node(n2028,supported), \+ node(n2028,refuted).
verdict(c_69d88d88351737a4,supported) :- node(n2028,supported).
query(verdict(c_69d88d88351737a4,supported)).
verdict(c_69d88d88351737a4,refuted) :- node(n2028,refuted).
query(verdict(c_69d88d88351737a4,refuted)).
verdict(c_69d88d88351737a4,unknown) :- node(n2028,unknown).
query(verdict(c_69d88d88351737a4,unknown)).
node(n2037,supported) :- status(o_ff671b0846bc5ab76f41,supported).
node(n2037,refuted) :- status(o_ff671b0846bc5ab76f41,refuted).
node(n2037,unknown) :- status(o_ff671b0846bc5ab76f41,unknown).
node(n2036,supported) :- node(n2016,supported), node(n2017,supported), node(n2037,supported).
node(n2036,refuted) :- node(n2016,refuted).
node(n2036,refuted) :- node(n2017,refuted).
node(n2036,refuted) :- node(n2037,refuted).
node(n2036,unknown) :- \+ node(n2036,supported), \+ node(n2036,refuted).
node(n2039,supported) :- status(o_8ab6773296e4ff1ee812,supported).
node(n2039,refuted) :- status(o_8ab6773296e4ff1ee812,refuted).
node(n2039,unknown) :- status(o_8ab6773296e4ff1ee812,unknown).
node(n2038,supported) :- node(n2020,supported), node(n2021,supported), node(n2039,supported).
node(n2038,refuted) :- node(n2020,refuted).
node(n2038,refuted) :- node(n2021,refuted).
node(n2038,refuted) :- node(n2039,refuted).
node(n2038,unknown) :- \+ node(n2038,supported), \+ node(n2038,refuted).
node(n2035,refuted) :- node(n2036,refuted), node(n2038,refuted), node(n9,refuted).
node(n2035,supported) :- node(n2036,supported).
node(n2035,supported) :- node(n2038,supported).
node(n2035,supported) :- node(n9,supported).
node(n2035,unknown) :- \+ node(n2035,supported), \+ node(n2035,refuted).
verdict(c_8bc1af6c60a8d611,supported) :- node(n2035,supported).
query(verdict(c_8bc1af6c60a8d611,supported)).
verdict(c_8bc1af6c60a8d611,refuted) :- node(n2035,refuted).
query(verdict(c_8bc1af6c60a8d611,refuted)).
verdict(c_8bc1af6c60a8d611,unknown) :- node(n2035,unknown).
query(verdict(c_8bc1af6c60a8d611,unknown)).
node(n2041,supported) :- node(n2016,supported), node(n2017,supported), node(n2018,supported), node(n2037,supported).
node(n2041,refuted) :- node(n2016,refuted).
node(n2041,refuted) :- node(n2017,refuted).
node(n2041,refuted) :- node(n2018,refuted).
node(n2041,refuted) :- node(n2037,refuted).
node(n2041,unknown) :- \+ node(n2041,supported), \+ node(n2041,refuted).
node(n2042,supported) :- node(n2020,supported), node(n2021,supported), node(n2022,supported), node(n2039,supported).
node(n2042,refuted) :- node(n2020,refuted).
node(n2042,refuted) :- node(n2021,refuted).
node(n2042,refuted) :- node(n2022,refuted).
node(n2042,refuted) :- node(n2039,refuted).
node(n2042,unknown) :- \+ node(n2042,supported), \+ node(n2042,refuted).
node(n2040,refuted) :- node(n2041,refuted), node(n2042,refuted), node(n9,refuted).
node(n2040,supported) :- node(n2041,supported).
node(n2040,supported) :- node(n2042,supported).
node(n2040,supported) :- node(n9,supported).
node(n2040,unknown) :- \+ node(n2040,supported), \+ node(n2040,refuted).
verdict(c_74dedf202ea23862,supported) :- node(n2040,supported).
query(verdict(c_74dedf202ea23862,supported)).
verdict(c_74dedf202ea23862,refuted) :- node(n2040,refuted).
query(verdict(c_74dedf202ea23862,refuted)).
verdict(c_74dedf202ea23862,unknown) :- node(n2040,unknown).
query(verdict(c_74dedf202ea23862,unknown)).
node(n2045,supported) :- status(o_d07331ef307f5570fa81,supported).
node(n2045,refuted) :- status(o_d07331ef307f5570fa81,refuted).
node(n2045,unknown) :- status(o_d07331ef307f5570fa81,unknown).
node(n2046,supported) :- status(o_29bd8a4271e36d52eb72,supported).
node(n2046,refuted) :- status(o_29bd8a4271e36d52eb72,refuted).
node(n2046,unknown) :- status(o_29bd8a4271e36d52eb72,unknown).
node(n2047,supported) :- status(o_f11da506dd5b5b7d6bdd,supported).
node(n2047,refuted) :- status(o_f11da506dd5b5b7d6bdd,refuted).
node(n2047,unknown) :- status(o_f11da506dd5b5b7d6bdd,unknown).
node(n2044,supported) :- node(n2045,supported), node(n2046,supported), node(n2047,supported).
node(n2044,refuted) :- node(n2045,refuted).
node(n2044,refuted) :- node(n2046,refuted).
node(n2044,refuted) :- node(n2047,refuted).
node(n2044,unknown) :- \+ node(n2044,supported), \+ node(n2044,refuted).
node(n2049,supported) :- status(o_6f0b78e3f3c7386eddfe,supported).
node(n2049,refuted) :- status(o_6f0b78e3f3c7386eddfe,refuted).
node(n2049,unknown) :- status(o_6f0b78e3f3c7386eddfe,unknown).
node(n2050,supported) :- status(o_14b8f503dbeff36cd587,supported).
node(n2050,refuted) :- status(o_14b8f503dbeff36cd587,refuted).
node(n2050,unknown) :- status(o_14b8f503dbeff36cd587,unknown).
node(n2051,supported) :- status(o_8fc8b1fb5f088e985d0d,supported).
node(n2051,refuted) :- status(o_8fc8b1fb5f088e985d0d,refuted).
node(n2051,unknown) :- status(o_8fc8b1fb5f088e985d0d,unknown).
node(n2048,supported) :- node(n2049,supported), node(n2050,supported), node(n2051,supported).
node(n2048,refuted) :- node(n2049,refuted).
node(n2048,refuted) :- node(n2050,refuted).
node(n2048,refuted) :- node(n2051,refuted).
node(n2048,unknown) :- \+ node(n2048,supported), \+ node(n2048,refuted).
node(n2043,refuted) :- node(n2044,refuted), node(n2048,refuted), node(n9,refuted).
node(n2043,supported) :- node(n2044,supported).
node(n2043,supported) :- node(n2048,supported).
node(n2043,supported) :- node(n9,supported).
node(n2043,unknown) :- \+ node(n2043,supported), \+ node(n2043,refuted).
verdict(c_e078a1d1309f0a51,supported) :- node(n2043,supported).
query(verdict(c_e078a1d1309f0a51,supported)).
verdict(c_e078a1d1309f0a51,refuted) :- node(n2043,refuted).
query(verdict(c_e078a1d1309f0a51,refuted)).
verdict(c_e078a1d1309f0a51,unknown) :- node(n2043,unknown).
query(verdict(c_e078a1d1309f0a51,unknown)).
node(n2054,supported) :- status(o_bbd643ab513131d0dc7a,supported).
node(n2054,refuted) :- status(o_bbd643ab513131d0dc7a,refuted).
node(n2054,unknown) :- status(o_bbd643ab513131d0dc7a,unknown).
node(n2053,supported) :- node(n2045,supported), node(n2046,supported), node(n2047,supported), node(n2054,supported).
node(n2053,refuted) :- node(n2045,refuted).
node(n2053,refuted) :- node(n2046,refuted).
node(n2053,refuted) :- node(n2047,refuted).
node(n2053,refuted) :- node(n2054,refuted).
node(n2053,unknown) :- \+ node(n2053,supported), \+ node(n2053,refuted).
node(n2056,supported) :- status(o_7afa2df8d5dc0a6a4954,supported).
node(n2056,refuted) :- status(o_7afa2df8d5dc0a6a4954,refuted).
node(n2056,unknown) :- status(o_7afa2df8d5dc0a6a4954,unknown).
node(n2055,supported) :- node(n2049,supported), node(n2050,supported), node(n2051,supported), node(n2056,supported).
node(n2055,refuted) :- node(n2049,refuted).
node(n2055,refuted) :- node(n2050,refuted).
node(n2055,refuted) :- node(n2051,refuted).
node(n2055,refuted) :- node(n2056,refuted).
node(n2055,unknown) :- \+ node(n2055,supported), \+ node(n2055,refuted).
node(n2052,refuted) :- node(n2053,refuted), node(n2055,refuted), node(n9,refuted).
node(n2052,supported) :- node(n2053,supported).
node(n2052,supported) :- node(n2055,supported).
node(n2052,supported) :- node(n9,supported).
node(n2052,unknown) :- \+ node(n2052,supported), \+ node(n2052,refuted).
verdict(c_7078859f94a34ea0,supported) :- node(n2052,supported).
query(verdict(c_7078859f94a34ea0,supported)).
verdict(c_7078859f94a34ea0,refuted) :- node(n2052,refuted).
query(verdict(c_7078859f94a34ea0,refuted)).
verdict(c_7078859f94a34ea0,unknown) :- node(n2052,unknown).
query(verdict(c_7078859f94a34ea0,unknown)).
node(n2059,supported) :- status(o_a6d92bca5a7680c71b58,supported).
node(n2059,refuted) :- status(o_a6d92bca5a7680c71b58,refuted).
node(n2059,unknown) :- status(o_a6d92bca5a7680c71b58,unknown).
node(n2060,supported) :- status(o_ca4926d30f536418ea4f,supported).
node(n2060,refuted) :- status(o_ca4926d30f536418ea4f,refuted).
node(n2060,unknown) :- status(o_ca4926d30f536418ea4f,unknown).
node(n2058,supported) :- node(n2045,supported), node(n2046,supported), node(n2047,supported), node(n2054,supported), node(n2059,supported), node(n2060,supported).
node(n2058,refuted) :- node(n2045,refuted).
node(n2058,refuted) :- node(n2046,refuted).
node(n2058,refuted) :- node(n2047,refuted).
node(n2058,refuted) :- node(n2054,refuted).
node(n2058,refuted) :- node(n2059,refuted).
node(n2058,refuted) :- node(n2060,refuted).
node(n2058,unknown) :- \+ node(n2058,supported), \+ node(n2058,refuted).
node(n2062,supported) :- status(o_d1eecfd8faf69578c636,supported).
node(n2062,refuted) :- status(o_d1eecfd8faf69578c636,refuted).
node(n2062,unknown) :- status(o_d1eecfd8faf69578c636,unknown).
node(n2063,supported) :- status(o_9b7201b4fc8be9a32b76,supported).
node(n2063,refuted) :- status(o_9b7201b4fc8be9a32b76,refuted).
node(n2063,unknown) :- status(o_9b7201b4fc8be9a32b76,unknown).
node(n2061,supported) :- node(n2049,supported), node(n2050,supported), node(n2051,supported), node(n2056,supported), node(n2062,supported), node(n2063,supported).
node(n2061,refuted) :- node(n2049,refuted).
node(n2061,refuted) :- node(n2050,refuted).
node(n2061,refuted) :- node(n2051,refuted).
node(n2061,refuted) :- node(n2056,refuted).
node(n2061,refuted) :- node(n2062,refuted).
node(n2061,refuted) :- node(n2063,refuted).
node(n2061,unknown) :- \+ node(n2061,supported), \+ node(n2061,refuted).
node(n2057,refuted) :- node(n2058,refuted), node(n2061,refuted), node(n9,refuted).
node(n2057,supported) :- node(n2058,supported).
node(n2057,supported) :- node(n2061,supported).
node(n2057,supported) :- node(n9,supported).
node(n2057,unknown) :- \+ node(n2057,supported), \+ node(n2057,refuted).
verdict(c_4b5e1d8d53f6841c,supported) :- node(n2057,supported).
query(verdict(c_4b5e1d8d53f6841c,supported)).
verdict(c_4b5e1d8d53f6841c,refuted) :- node(n2057,refuted).
query(verdict(c_4b5e1d8d53f6841c,refuted)).
verdict(c_4b5e1d8d53f6841c,unknown) :- node(n2057,unknown).
query(verdict(c_4b5e1d8d53f6841c,unknown)).
node(n2066,supported) :- status(o_d381bbd170f5f33bc04e,supported).
node(n2066,refuted) :- status(o_d381bbd170f5f33bc04e,refuted).
node(n2066,unknown) :- status(o_d381bbd170f5f33bc04e,unknown).
node(n2065,supported) :- node(n2045,supported), node(n2046,supported), node(n2066,supported).
node(n2065,refuted) :- node(n2045,refuted).
node(n2065,refuted) :- node(n2046,refuted).
node(n2065,refuted) :- node(n2066,refuted).
node(n2065,unknown) :- \+ node(n2065,supported), \+ node(n2065,refuted).
node(n2068,supported) :- status(o_1d632313ab0d407dd8be,supported).
node(n2068,refuted) :- status(o_1d632313ab0d407dd8be,refuted).
node(n2068,unknown) :- status(o_1d632313ab0d407dd8be,unknown).
node(n2067,supported) :- node(n2049,supported), node(n2050,supported), node(n2068,supported).
node(n2067,refuted) :- node(n2049,refuted).
node(n2067,refuted) :- node(n2050,refuted).
node(n2067,refuted) :- node(n2068,refuted).
node(n2067,unknown) :- \+ node(n2067,supported), \+ node(n2067,refuted).
node(n2064,refuted) :- node(n2065,refuted), node(n2067,refuted), node(n9,refuted).
node(n2064,supported) :- node(n2065,supported).
node(n2064,supported) :- node(n2067,supported).
node(n2064,supported) :- node(n9,supported).
node(n2064,unknown) :- \+ node(n2064,supported), \+ node(n2064,refuted).
verdict(c_5450ba949d6ac3b3,supported) :- node(n2064,supported).
query(verdict(c_5450ba949d6ac3b3,supported)).
verdict(c_5450ba949d6ac3b3,refuted) :- node(n2064,refuted).
query(verdict(c_5450ba949d6ac3b3,refuted)).
verdict(c_5450ba949d6ac3b3,unknown) :- node(n2064,unknown).
query(verdict(c_5450ba949d6ac3b3,unknown)).
node(n2070,supported) :- node(n2045,supported), node(n2046,supported), node(n2047,supported), node(n2066,supported).
node(n2070,refuted) :- node(n2045,refuted).
node(n2070,refuted) :- node(n2046,refuted).
node(n2070,refuted) :- node(n2047,refuted).
node(n2070,refuted) :- node(n2066,refuted).
node(n2070,unknown) :- \+ node(n2070,supported), \+ node(n2070,refuted).
node(n2071,supported) :- node(n2049,supported), node(n2050,supported), node(n2051,supported), node(n2068,supported).
node(n2071,refuted) :- node(n2049,refuted).
node(n2071,refuted) :- node(n2050,refuted).
node(n2071,refuted) :- node(n2051,refuted).
node(n2071,refuted) :- node(n2068,refuted).
node(n2071,unknown) :- \+ node(n2071,supported), \+ node(n2071,refuted).
node(n2069,refuted) :- node(n2070,refuted), node(n2071,refuted), node(n9,refuted).
node(n2069,supported) :- node(n2070,supported).
node(n2069,supported) :- node(n2071,supported).
node(n2069,supported) :- node(n9,supported).
node(n2069,unknown) :- \+ node(n2069,supported), \+ node(n2069,refuted).
verdict(c_925200016d6ee2e2,supported) :- node(n2069,supported).
query(verdict(c_925200016d6ee2e2,supported)).
verdict(c_925200016d6ee2e2,refuted) :- node(n2069,refuted).
query(verdict(c_925200016d6ee2e2,refuted)).
verdict(c_925200016d6ee2e2,unknown) :- node(n2069,unknown).
query(verdict(c_925200016d6ee2e2,unknown)).
node(n2074,supported) :- status(o_6caf67aca4f84947a589,supported).
node(n2074,refuted) :- status(o_6caf67aca4f84947a589,refuted).
node(n2074,unknown) :- status(o_6caf67aca4f84947a589,unknown).
node(n2075,supported) :- status(o_3586b0880e9c45194d1e,supported).
node(n2075,refuted) :- status(o_3586b0880e9c45194d1e,refuted).
node(n2075,unknown) :- status(o_3586b0880e9c45194d1e,unknown).
node(n2076,supported) :- status(o_56a0272adfb08d9e9a92,supported).
node(n2076,refuted) :- status(o_56a0272adfb08d9e9a92,refuted).
node(n2076,unknown) :- status(o_56a0272adfb08d9e9a92,unknown).
node(n2073,supported) :- node(n2074,supported), node(n2075,supported), node(n2076,supported).
node(n2073,refuted) :- node(n2074,refuted).
node(n2073,refuted) :- node(n2075,refuted).
node(n2073,refuted) :- node(n2076,refuted).
node(n2073,unknown) :- \+ node(n2073,supported), \+ node(n2073,refuted).
node(n2078,supported) :- status(o_01fd2e559a2136193291,supported).
node(n2078,refuted) :- status(o_01fd2e559a2136193291,refuted).
node(n2078,unknown) :- status(o_01fd2e559a2136193291,unknown).
node(n2079,supported) :- status(o_71d8d78292bc7921cf92,supported).
node(n2079,refuted) :- status(o_71d8d78292bc7921cf92,refuted).
node(n2079,unknown) :- status(o_71d8d78292bc7921cf92,unknown).
node(n2080,supported) :- status(o_e1fe6768ac2fbc02beea,supported).
node(n2080,refuted) :- status(o_e1fe6768ac2fbc02beea,refuted).
node(n2080,unknown) :- status(o_e1fe6768ac2fbc02beea,unknown).
node(n2077,supported) :- node(n2078,supported), node(n2079,supported), node(n2080,supported).
node(n2077,refuted) :- node(n2078,refuted).
node(n2077,refuted) :- node(n2079,refuted).
node(n2077,refuted) :- node(n2080,refuted).
node(n2077,unknown) :- \+ node(n2077,supported), \+ node(n2077,refuted).
node(n2072,refuted) :- node(n2073,refuted), node(n2077,refuted), node(n9,refuted).
node(n2072,supported) :- node(n2073,supported).
node(n2072,supported) :- node(n2077,supported).
node(n2072,supported) :- node(n9,supported).
node(n2072,unknown) :- \+ node(n2072,supported), \+ node(n2072,refuted).
verdict(c_f71f7b971ab7d3b8,supported) :- node(n2072,supported).
query(verdict(c_f71f7b971ab7d3b8,supported)).
verdict(c_f71f7b971ab7d3b8,refuted) :- node(n2072,refuted).
query(verdict(c_f71f7b971ab7d3b8,refuted)).
verdict(c_f71f7b971ab7d3b8,unknown) :- node(n2072,unknown).
query(verdict(c_f71f7b971ab7d3b8,unknown)).
node(n2083,supported) :- status(o_3db708494f75baca5c3b,supported).
node(n2083,refuted) :- status(o_3db708494f75baca5c3b,refuted).
node(n2083,unknown) :- status(o_3db708494f75baca5c3b,unknown).
node(n2082,supported) :- node(n2074,supported), node(n2075,supported), node(n2076,supported), node(n2083,supported).
node(n2082,refuted) :- node(n2074,refuted).
node(n2082,refuted) :- node(n2075,refuted).
node(n2082,refuted) :- node(n2076,refuted).
node(n2082,refuted) :- node(n2083,refuted).
node(n2082,unknown) :- \+ node(n2082,supported), \+ node(n2082,refuted).
node(n2085,supported) :- status(o_dfe59f6ddd86e6df6e50,supported).
node(n2085,refuted) :- status(o_dfe59f6ddd86e6df6e50,refuted).
node(n2085,unknown) :- status(o_dfe59f6ddd86e6df6e50,unknown).
node(n2084,supported) :- node(n2078,supported), node(n2079,supported), node(n2080,supported), node(n2085,supported).
node(n2084,refuted) :- node(n2078,refuted).
node(n2084,refuted) :- node(n2079,refuted).
node(n2084,refuted) :- node(n2080,refuted).
node(n2084,refuted) :- node(n2085,refuted).
node(n2084,unknown) :- \+ node(n2084,supported), \+ node(n2084,refuted).
node(n2081,refuted) :- node(n2082,refuted), node(n2084,refuted), node(n9,refuted).
node(n2081,supported) :- node(n2082,supported).
node(n2081,supported) :- node(n2084,supported).
node(n2081,supported) :- node(n9,supported).
node(n2081,unknown) :- \+ node(n2081,supported), \+ node(n2081,refuted).
verdict(c_074dfc218bfd825b,supported) :- node(n2081,supported).
query(verdict(c_074dfc218bfd825b,supported)).
verdict(c_074dfc218bfd825b,refuted) :- node(n2081,refuted).
query(verdict(c_074dfc218bfd825b,refuted)).
verdict(c_074dfc218bfd825b,unknown) :- node(n2081,unknown).
query(verdict(c_074dfc218bfd825b,unknown)).
node(n2088,supported) :- status(o_e52c04cadc01e5365146,supported).
node(n2088,refuted) :- status(o_e52c04cadc01e5365146,refuted).
node(n2088,unknown) :- status(o_e52c04cadc01e5365146,unknown).
node(n2089,supported) :- status(o_30df118d33e1851c9db8,supported).
node(n2089,refuted) :- status(o_30df118d33e1851c9db8,refuted).
node(n2089,unknown) :- status(o_30df118d33e1851c9db8,unknown).
node(n2087,supported) :- node(n2074,supported), node(n2075,supported), node(n2076,supported), node(n2083,supported), node(n2088,supported), node(n2089,supported).
node(n2087,refuted) :- node(n2074,refuted).
node(n2087,refuted) :- node(n2075,refuted).
node(n2087,refuted) :- node(n2076,refuted).
node(n2087,refuted) :- node(n2083,refuted).
node(n2087,refuted) :- node(n2088,refuted).
node(n2087,refuted) :- node(n2089,refuted).
node(n2087,unknown) :- \+ node(n2087,supported), \+ node(n2087,refuted).
node(n2091,supported) :- status(o_f76aa5db32f83a40f739,supported).
node(n2091,refuted) :- status(o_f76aa5db32f83a40f739,refuted).
node(n2091,unknown) :- status(o_f76aa5db32f83a40f739,unknown).
node(n2092,supported) :- status(o_deb82273b78aa3a928db,supported).
node(n2092,refuted) :- status(o_deb82273b78aa3a928db,refuted).
node(n2092,unknown) :- status(o_deb82273b78aa3a928db,unknown).
node(n2090,supported) :- node(n2078,supported), node(n2079,supported), node(n2080,supported), node(n2085,supported), node(n2091,supported), node(n2092,supported).
node(n2090,refuted) :- node(n2078,refuted).
node(n2090,refuted) :- node(n2079,refuted).
node(n2090,refuted) :- node(n2080,refuted).
node(n2090,refuted) :- node(n2085,refuted).
node(n2090,refuted) :- node(n2091,refuted).
node(n2090,refuted) :- node(n2092,refuted).
node(n2090,unknown) :- \+ node(n2090,supported), \+ node(n2090,refuted).
node(n2086,refuted) :- node(n2087,refuted), node(n2090,refuted), node(n9,refuted).
node(n2086,supported) :- node(n2087,supported).
node(n2086,supported) :- node(n2090,supported).
node(n2086,supported) :- node(n9,supported).
node(n2086,unknown) :- \+ node(n2086,supported), \+ node(n2086,refuted).
verdict(c_00feb593fdbdc640,supported) :- node(n2086,supported).
query(verdict(c_00feb593fdbdc640,supported)).
verdict(c_00feb593fdbdc640,refuted) :- node(n2086,refuted).
query(verdict(c_00feb593fdbdc640,refuted)).
verdict(c_00feb593fdbdc640,unknown) :- node(n2086,unknown).
query(verdict(c_00feb593fdbdc640,unknown)).
node(n2095,supported) :- status(o_df0ea2915fd49492e497,supported).
node(n2095,refuted) :- status(o_df0ea2915fd49492e497,refuted).
node(n2095,unknown) :- status(o_df0ea2915fd49492e497,unknown).
node(n2094,supported) :- node(n2074,supported), node(n2075,supported), node(n2095,supported).
node(n2094,refuted) :- node(n2074,refuted).
node(n2094,refuted) :- node(n2075,refuted).
node(n2094,refuted) :- node(n2095,refuted).
node(n2094,unknown) :- \+ node(n2094,supported), \+ node(n2094,refuted).
node(n2097,supported) :- status(o_42fdcfd91b3bb54f75ec,supported).
node(n2097,refuted) :- status(o_42fdcfd91b3bb54f75ec,refuted).
node(n2097,unknown) :- status(o_42fdcfd91b3bb54f75ec,unknown).
node(n2096,supported) :- node(n2078,supported), node(n2079,supported), node(n2097,supported).
node(n2096,refuted) :- node(n2078,refuted).
node(n2096,refuted) :- node(n2079,refuted).
node(n2096,refuted) :- node(n2097,refuted).
node(n2096,unknown) :- \+ node(n2096,supported), \+ node(n2096,refuted).
node(n2093,refuted) :- node(n2094,refuted), node(n2096,refuted), node(n9,refuted).
node(n2093,supported) :- node(n2094,supported).
node(n2093,supported) :- node(n2096,supported).
node(n2093,supported) :- node(n9,supported).
node(n2093,unknown) :- \+ node(n2093,supported), \+ node(n2093,refuted).
verdict(c_df14e2f24100ed40,supported) :- node(n2093,supported).
query(verdict(c_df14e2f24100ed40,supported)).
verdict(c_df14e2f24100ed40,refuted) :- node(n2093,refuted).
query(verdict(c_df14e2f24100ed40,refuted)).
verdict(c_df14e2f24100ed40,unknown) :- node(n2093,unknown).
query(verdict(c_df14e2f24100ed40,unknown)).
node(n2099,supported) :- node(n2074,supported), node(n2075,supported), node(n2076,supported), node(n2095,supported).
node(n2099,refuted) :- node(n2074,refuted).
node(n2099,refuted) :- node(n2075,refuted).
node(n2099,refuted) :- node(n2076,refuted).
node(n2099,refuted) :- node(n2095,refuted).
node(n2099,unknown) :- \+ node(n2099,supported), \+ node(n2099,refuted).
node(n2100,supported) :- node(n2078,supported), node(n2079,supported), node(n2080,supported), node(n2097,supported).
node(n2100,refuted) :- node(n2078,refuted).
node(n2100,refuted) :- node(n2079,refuted).
node(n2100,refuted) :- node(n2080,refuted).
node(n2100,refuted) :- node(n2097,refuted).
node(n2100,unknown) :- \+ node(n2100,supported), \+ node(n2100,refuted).
node(n2098,refuted) :- node(n2099,refuted), node(n2100,refuted), node(n9,refuted).
node(n2098,supported) :- node(n2099,supported).
node(n2098,supported) :- node(n2100,supported).
node(n2098,supported) :- node(n9,supported).
node(n2098,unknown) :- \+ node(n2098,supported), \+ node(n2098,refuted).
verdict(c_8734b1878391f9aa,supported) :- node(n2098,supported).
query(verdict(c_8734b1878391f9aa,supported)).
verdict(c_8734b1878391f9aa,refuted) :- node(n2098,refuted).
query(verdict(c_8734b1878391f9aa,refuted)).
verdict(c_8734b1878391f9aa,unknown) :- node(n2098,unknown).
query(verdict(c_8734b1878391f9aa,unknown)).
node(n2103,supported) :- status(o_c7342ff157047269e43a,supported).
node(n2103,refuted) :- status(o_c7342ff157047269e43a,refuted).
node(n2103,unknown) :- status(o_c7342ff157047269e43a,unknown).
node(n2104,supported) :- status(o_83e1cd59886a1ae471bd,supported).
node(n2104,refuted) :- status(o_83e1cd59886a1ae471bd,refuted).
node(n2104,unknown) :- status(o_83e1cd59886a1ae471bd,unknown).
node(n2105,supported) :- status(o_d42deff94728076a9823,supported).
node(n2105,refuted) :- status(o_d42deff94728076a9823,refuted).
node(n2105,unknown) :- status(o_d42deff94728076a9823,unknown).
node(n2102,supported) :- node(n2103,supported), node(n2104,supported), node(n2105,supported).
node(n2102,refuted) :- node(n2103,refuted).
node(n2102,refuted) :- node(n2104,refuted).
node(n2102,refuted) :- node(n2105,refuted).
node(n2102,unknown) :- \+ node(n2102,supported), \+ node(n2102,refuted).
node(n2107,supported) :- status(o_10d9f513ed1fa08b6300,supported).
node(n2107,refuted) :- status(o_10d9f513ed1fa08b6300,refuted).
node(n2107,unknown) :- status(o_10d9f513ed1fa08b6300,unknown).
node(n2108,supported) :- status(o_96c3418f7ad073390db4,supported).
node(n2108,refuted) :- status(o_96c3418f7ad073390db4,refuted).
node(n2108,unknown) :- status(o_96c3418f7ad073390db4,unknown).
node(n2109,supported) :- status(o_d493d0a37cac3e84312b,supported).
node(n2109,refuted) :- status(o_d493d0a37cac3e84312b,refuted).
node(n2109,unknown) :- status(o_d493d0a37cac3e84312b,unknown).
node(n2106,supported) :- node(n2107,supported), node(n2108,supported), node(n2109,supported).
node(n2106,refuted) :- node(n2107,refuted).
node(n2106,refuted) :- node(n2108,refuted).
node(n2106,refuted) :- node(n2109,refuted).
node(n2106,unknown) :- \+ node(n2106,supported), \+ node(n2106,refuted).
node(n2101,refuted) :- node(n2102,refuted), node(n2106,refuted), node(n9,refuted).
node(n2101,supported) :- node(n2102,supported).
node(n2101,supported) :- node(n2106,supported).
node(n2101,supported) :- node(n9,supported).
node(n2101,unknown) :- \+ node(n2101,supported), \+ node(n2101,refuted).
verdict(c_9e1ac77ca694ae6f,supported) :- node(n2101,supported).
query(verdict(c_9e1ac77ca694ae6f,supported)).
verdict(c_9e1ac77ca694ae6f,refuted) :- node(n2101,refuted).
query(verdict(c_9e1ac77ca694ae6f,refuted)).
verdict(c_9e1ac77ca694ae6f,unknown) :- node(n2101,unknown).
query(verdict(c_9e1ac77ca694ae6f,unknown)).
node(n2112,supported) :- status(o_aa280bf8ca92eb393367,supported).
node(n2112,refuted) :- status(o_aa280bf8ca92eb393367,refuted).
node(n2112,unknown) :- status(o_aa280bf8ca92eb393367,unknown).
node(n2111,supported) :- node(n2103,supported), node(n2104,supported), node(n2105,supported), node(n2112,supported).
node(n2111,refuted) :- node(n2103,refuted).
node(n2111,refuted) :- node(n2104,refuted).
node(n2111,refuted) :- node(n2105,refuted).
node(n2111,refuted) :- node(n2112,refuted).
node(n2111,unknown) :- \+ node(n2111,supported), \+ node(n2111,refuted).
node(n2114,supported) :- status(o_e2a3493f0e611443c4a1,supported).
node(n2114,refuted) :- status(o_e2a3493f0e611443c4a1,refuted).
node(n2114,unknown) :- status(o_e2a3493f0e611443c4a1,unknown).
node(n2113,supported) :- node(n2107,supported), node(n2108,supported), node(n2109,supported), node(n2114,supported).
node(n2113,refuted) :- node(n2107,refuted).
node(n2113,refuted) :- node(n2108,refuted).
node(n2113,refuted) :- node(n2109,refuted).
node(n2113,refuted) :- node(n2114,refuted).
node(n2113,unknown) :- \+ node(n2113,supported), \+ node(n2113,refuted).
node(n2110,refuted) :- node(n2111,refuted), node(n2113,refuted), node(n9,refuted).
node(n2110,supported) :- node(n2111,supported).
node(n2110,supported) :- node(n2113,supported).
node(n2110,supported) :- node(n9,supported).
node(n2110,unknown) :- \+ node(n2110,supported), \+ node(n2110,refuted).
verdict(c_0353c933704280ec,supported) :- node(n2110,supported).
query(verdict(c_0353c933704280ec,supported)).
verdict(c_0353c933704280ec,refuted) :- node(n2110,refuted).
query(verdict(c_0353c933704280ec,refuted)).
verdict(c_0353c933704280ec,unknown) :- node(n2110,unknown).
query(verdict(c_0353c933704280ec,unknown)).
node(n2117,supported) :- status(o_4eff13f464b8361fe6a7,supported).
node(n2117,refuted) :- status(o_4eff13f464b8361fe6a7,refuted).
node(n2117,unknown) :- status(o_4eff13f464b8361fe6a7,unknown).
node(n2118,supported) :- status(o_e13d7089ad343a93054f,supported).
node(n2118,refuted) :- status(o_e13d7089ad343a93054f,refuted).
node(n2118,unknown) :- status(o_e13d7089ad343a93054f,unknown).
node(n2116,supported) :- node(n2103,supported), node(n2104,supported), node(n2105,supported), node(n2112,supported), node(n2117,supported), node(n2118,supported).
node(n2116,refuted) :- node(n2103,refuted).
node(n2116,refuted) :- node(n2104,refuted).
node(n2116,refuted) :- node(n2105,refuted).
node(n2116,refuted) :- node(n2112,refuted).
node(n2116,refuted) :- node(n2117,refuted).
node(n2116,refuted) :- node(n2118,refuted).
node(n2116,unknown) :- \+ node(n2116,supported), \+ node(n2116,refuted).
node(n2120,supported) :- status(o_150a3d72452880dbf010,supported).
node(n2120,refuted) :- status(o_150a3d72452880dbf010,refuted).
node(n2120,unknown) :- status(o_150a3d72452880dbf010,unknown).
node(n2121,supported) :- status(o_d76ea98883c307a83355,supported).
node(n2121,refuted) :- status(o_d76ea98883c307a83355,refuted).
node(n2121,unknown) :- status(o_d76ea98883c307a83355,unknown).
node(n2119,supported) :- node(n2107,supported), node(n2108,supported), node(n2109,supported), node(n2114,supported), node(n2120,supported), node(n2121,supported).
node(n2119,refuted) :- node(n2107,refuted).
node(n2119,refuted) :- node(n2108,refuted).
node(n2119,refuted) :- node(n2109,refuted).
node(n2119,refuted) :- node(n2114,refuted).
node(n2119,refuted) :- node(n2120,refuted).
node(n2119,refuted) :- node(n2121,refuted).
node(n2119,unknown) :- \+ node(n2119,supported), \+ node(n2119,refuted).
node(n2115,refuted) :- node(n2116,refuted), node(n2119,refuted), node(n9,refuted).
node(n2115,supported) :- node(n2116,supported).
node(n2115,supported) :- node(n2119,supported).
node(n2115,supported) :- node(n9,supported).
node(n2115,unknown) :- \+ node(n2115,supported), \+ node(n2115,refuted).
verdict(c_3e1d02f101eb8fbb,supported) :- node(n2115,supported).
query(verdict(c_3e1d02f101eb8fbb,supported)).
verdict(c_3e1d02f101eb8fbb,refuted) :- node(n2115,refuted).
query(verdict(c_3e1d02f101eb8fbb,refuted)).
verdict(c_3e1d02f101eb8fbb,unknown) :- node(n2115,unknown).
query(verdict(c_3e1d02f101eb8fbb,unknown)).
node(n2124,supported) :- status(o_3d4ff69b6aa37cceb461,supported).
node(n2124,refuted) :- status(o_3d4ff69b6aa37cceb461,refuted).
node(n2124,unknown) :- status(o_3d4ff69b6aa37cceb461,unknown).
node(n2123,supported) :- node(n2103,supported), node(n2104,supported), node(n2124,supported).
node(n2123,refuted) :- node(n2103,refuted).
node(n2123,refuted) :- node(n2104,refuted).
node(n2123,refuted) :- node(n2124,refuted).
node(n2123,unknown) :- \+ node(n2123,supported), \+ node(n2123,refuted).
node(n2126,supported) :- status(o_cc7292526013fa2a1a4c,supported).
node(n2126,refuted) :- status(o_cc7292526013fa2a1a4c,refuted).
node(n2126,unknown) :- status(o_cc7292526013fa2a1a4c,unknown).
node(n2125,supported) :- node(n2107,supported), node(n2108,supported), node(n2126,supported).
node(n2125,refuted) :- node(n2107,refuted).
node(n2125,refuted) :- node(n2108,refuted).
node(n2125,refuted) :- node(n2126,refuted).
node(n2125,unknown) :- \+ node(n2125,supported), \+ node(n2125,refuted).
node(n2122,refuted) :- node(n2123,refuted), node(n2125,refuted), node(n9,refuted).
node(n2122,supported) :- node(n2123,supported).
node(n2122,supported) :- node(n2125,supported).
node(n2122,supported) :- node(n9,supported).
node(n2122,unknown) :- \+ node(n2122,supported), \+ node(n2122,refuted).
verdict(c_4140a874f3571a5f,supported) :- node(n2122,supported).
query(verdict(c_4140a874f3571a5f,supported)).
verdict(c_4140a874f3571a5f,refuted) :- node(n2122,refuted).
query(verdict(c_4140a874f3571a5f,refuted)).
verdict(c_4140a874f3571a5f,unknown) :- node(n2122,unknown).
query(verdict(c_4140a874f3571a5f,unknown)).
node(n2128,supported) :- node(n2103,supported), node(n2104,supported), node(n2105,supported), node(n2124,supported).
node(n2128,refuted) :- node(n2103,refuted).
node(n2128,refuted) :- node(n2104,refuted).
node(n2128,refuted) :- node(n2105,refuted).
node(n2128,refuted) :- node(n2124,refuted).
node(n2128,unknown) :- \+ node(n2128,supported), \+ node(n2128,refuted).
node(n2129,supported) :- node(n2107,supported), node(n2108,supported), node(n2109,supported), node(n2126,supported).
node(n2129,refuted) :- node(n2107,refuted).
node(n2129,refuted) :- node(n2108,refuted).
node(n2129,refuted) :- node(n2109,refuted).
node(n2129,refuted) :- node(n2126,refuted).
node(n2129,unknown) :- \+ node(n2129,supported), \+ node(n2129,refuted).
node(n2127,refuted) :- node(n2128,refuted), node(n2129,refuted), node(n9,refuted).
node(n2127,supported) :- node(n2128,supported).
node(n2127,supported) :- node(n2129,supported).
node(n2127,supported) :- node(n9,supported).
node(n2127,unknown) :- \+ node(n2127,supported), \+ node(n2127,refuted).
verdict(c_0bd64ebb4c7eeb39,supported) :- node(n2127,supported).
query(verdict(c_0bd64ebb4c7eeb39,supported)).
verdict(c_0bd64ebb4c7eeb39,refuted) :- node(n2127,refuted).
query(verdict(c_0bd64ebb4c7eeb39,refuted)).
verdict(c_0bd64ebb4c7eeb39,unknown) :- node(n2127,unknown).
query(verdict(c_0bd64ebb4c7eeb39,unknown)).
node(n2132,supported) :- status(o_d1bf99e344a2702fcee1,supported).
node(n2132,refuted) :- status(o_d1bf99e344a2702fcee1,refuted).
node(n2132,unknown) :- status(o_d1bf99e344a2702fcee1,unknown).
node(n2133,supported) :- status(o_c53804bffb8ed0e4a968,supported).
node(n2133,refuted) :- status(o_c53804bffb8ed0e4a968,refuted).
node(n2133,unknown) :- status(o_c53804bffb8ed0e4a968,unknown).
node(n2134,supported) :- status(o_d71534db61997165694f,supported).
node(n2134,refuted) :- status(o_d71534db61997165694f,refuted).
node(n2134,unknown) :- status(o_d71534db61997165694f,unknown).
node(n2131,supported) :- node(n2132,supported), node(n2133,supported), node(n2134,supported).
node(n2131,refuted) :- node(n2132,refuted).
node(n2131,refuted) :- node(n2133,refuted).
node(n2131,refuted) :- node(n2134,refuted).
node(n2131,unknown) :- \+ node(n2131,supported), \+ node(n2131,refuted).
node(n2136,supported) :- status(o_a5b8218bfb8e5b4aa030,supported).
node(n2136,refuted) :- status(o_a5b8218bfb8e5b4aa030,refuted).
node(n2136,unknown) :- status(o_a5b8218bfb8e5b4aa030,unknown).
node(n2137,supported) :- status(o_dc5de3b50cc503b0b7c4,supported).
node(n2137,refuted) :- status(o_dc5de3b50cc503b0b7c4,refuted).
node(n2137,unknown) :- status(o_dc5de3b50cc503b0b7c4,unknown).
node(n2138,supported) :- status(o_efad762f582c0feddb14,supported).
node(n2138,refuted) :- status(o_efad762f582c0feddb14,refuted).
node(n2138,unknown) :- status(o_efad762f582c0feddb14,unknown).
node(n2135,supported) :- node(n2136,supported), node(n2137,supported), node(n2138,supported).
node(n2135,refuted) :- node(n2136,refuted).
node(n2135,refuted) :- node(n2137,refuted).
node(n2135,refuted) :- node(n2138,refuted).
node(n2135,unknown) :- \+ node(n2135,supported), \+ node(n2135,refuted).
node(n2130,refuted) :- node(n2131,refuted), node(n2135,refuted), node(n9,refuted).
node(n2130,supported) :- node(n2131,supported).
node(n2130,supported) :- node(n2135,supported).
node(n2130,supported) :- node(n9,supported).
node(n2130,unknown) :- \+ node(n2130,supported), \+ node(n2130,refuted).
verdict(c_40f028eeed635aff,supported) :- node(n2130,supported).
query(verdict(c_40f028eeed635aff,supported)).
verdict(c_40f028eeed635aff,refuted) :- node(n2130,refuted).
query(verdict(c_40f028eeed635aff,refuted)).
verdict(c_40f028eeed635aff,unknown) :- node(n2130,unknown).
query(verdict(c_40f028eeed635aff,unknown)).
node(n2141,supported) :- status(o_22a816de4bcca588aebf,supported).
node(n2141,refuted) :- status(o_22a816de4bcca588aebf,refuted).
node(n2141,unknown) :- status(o_22a816de4bcca588aebf,unknown).
node(n2140,supported) :- node(n2132,supported), node(n2133,supported), node(n2134,supported), node(n2141,supported).
node(n2140,refuted) :- node(n2132,refuted).
node(n2140,refuted) :- node(n2133,refuted).
node(n2140,refuted) :- node(n2134,refuted).
node(n2140,refuted) :- node(n2141,refuted).
node(n2140,unknown) :- \+ node(n2140,supported), \+ node(n2140,refuted).
node(n2143,supported) :- status(o_6fb68d5004e215a02ddf,supported).
node(n2143,refuted) :- status(o_6fb68d5004e215a02ddf,refuted).
node(n2143,unknown) :- status(o_6fb68d5004e215a02ddf,unknown).
node(n2142,supported) :- node(n2136,supported), node(n2137,supported), node(n2138,supported), node(n2143,supported).
node(n2142,refuted) :- node(n2136,refuted).
node(n2142,refuted) :- node(n2137,refuted).
node(n2142,refuted) :- node(n2138,refuted).
node(n2142,refuted) :- node(n2143,refuted).
node(n2142,unknown) :- \+ node(n2142,supported), \+ node(n2142,refuted).
node(n2139,refuted) :- node(n2140,refuted), node(n2142,refuted), node(n9,refuted).
node(n2139,supported) :- node(n2140,supported).
node(n2139,supported) :- node(n2142,supported).
node(n2139,supported) :- node(n9,supported).
node(n2139,unknown) :- \+ node(n2139,supported), \+ node(n2139,refuted).
verdict(c_cb0549ab4f2c6a8f,supported) :- node(n2139,supported).
query(verdict(c_cb0549ab4f2c6a8f,supported)).
verdict(c_cb0549ab4f2c6a8f,refuted) :- node(n2139,refuted).
query(verdict(c_cb0549ab4f2c6a8f,refuted)).
verdict(c_cb0549ab4f2c6a8f,unknown) :- node(n2139,unknown).
query(verdict(c_cb0549ab4f2c6a8f,unknown)).
node(n2146,supported) :- status(o_3f685faf47a733f1ec45,supported).
node(n2146,refuted) :- status(o_3f685faf47a733f1ec45,refuted).
node(n2146,unknown) :- status(o_3f685faf47a733f1ec45,unknown).
node(n2147,supported) :- status(o_b6592c0778d5ae83fbb6,supported).
node(n2147,refuted) :- status(o_b6592c0778d5ae83fbb6,refuted).
node(n2147,unknown) :- status(o_b6592c0778d5ae83fbb6,unknown).
node(n2145,supported) :- node(n2132,supported), node(n2133,supported), node(n2134,supported), node(n2141,supported), node(n2146,supported), node(n2147,supported).
node(n2145,refuted) :- node(n2132,refuted).
node(n2145,refuted) :- node(n2133,refuted).
node(n2145,refuted) :- node(n2134,refuted).
node(n2145,refuted) :- node(n2141,refuted).
node(n2145,refuted) :- node(n2146,refuted).
node(n2145,refuted) :- node(n2147,refuted).
node(n2145,unknown) :- \+ node(n2145,supported), \+ node(n2145,refuted).
node(n2149,supported) :- status(o_bd110358e590f87cabed,supported).
node(n2149,refuted) :- status(o_bd110358e590f87cabed,refuted).
node(n2149,unknown) :- status(o_bd110358e590f87cabed,unknown).
node(n2150,supported) :- status(o_a86a524061215ba5095a,supported).
node(n2150,refuted) :- status(o_a86a524061215ba5095a,refuted).
node(n2150,unknown) :- status(o_a86a524061215ba5095a,unknown).
node(n2148,supported) :- node(n2136,supported), node(n2137,supported), node(n2138,supported), node(n2143,supported), node(n2149,supported), node(n2150,supported).
node(n2148,refuted) :- node(n2136,refuted).
node(n2148,refuted) :- node(n2137,refuted).
node(n2148,refuted) :- node(n2138,refuted).
node(n2148,refuted) :- node(n2143,refuted).
node(n2148,refuted) :- node(n2149,refuted).
node(n2148,refuted) :- node(n2150,refuted).
node(n2148,unknown) :- \+ node(n2148,supported), \+ node(n2148,refuted).
node(n2144,refuted) :- node(n2145,refuted), node(n2148,refuted), node(n9,refuted).
node(n2144,supported) :- node(n2145,supported).
node(n2144,supported) :- node(n2148,supported).
node(n2144,supported) :- node(n9,supported).
node(n2144,unknown) :- \+ node(n2144,supported), \+ node(n2144,refuted).
verdict(c_9edec58c47f2f1a8,supported) :- node(n2144,supported).
query(verdict(c_9edec58c47f2f1a8,supported)).
verdict(c_9edec58c47f2f1a8,refuted) :- node(n2144,refuted).
query(verdict(c_9edec58c47f2f1a8,refuted)).
verdict(c_9edec58c47f2f1a8,unknown) :- node(n2144,unknown).
query(verdict(c_9edec58c47f2f1a8,unknown)).
node(n2153,supported) :- status(o_a07e57a096373f07e17a,supported).
node(n2153,refuted) :- status(o_a07e57a096373f07e17a,refuted).
node(n2153,unknown) :- status(o_a07e57a096373f07e17a,unknown).
node(n2152,supported) :- node(n2132,supported), node(n2133,supported), node(n2153,supported).
node(n2152,refuted) :- node(n2132,refuted).
node(n2152,refuted) :- node(n2133,refuted).
node(n2152,refuted) :- node(n2153,refuted).
node(n2152,unknown) :- \+ node(n2152,supported), \+ node(n2152,refuted).
node(n2155,supported) :- status(o_5eb6d9f8c62b4d939ce6,supported).
node(n2155,refuted) :- status(o_5eb6d9f8c62b4d939ce6,refuted).
node(n2155,unknown) :- status(o_5eb6d9f8c62b4d939ce6,unknown).
node(n2154,supported) :- node(n2136,supported), node(n2137,supported), node(n2155,supported).
node(n2154,refuted) :- node(n2136,refuted).
node(n2154,refuted) :- node(n2137,refuted).
node(n2154,refuted) :- node(n2155,refuted).
node(n2154,unknown) :- \+ node(n2154,supported), \+ node(n2154,refuted).
node(n2151,refuted) :- node(n2152,refuted), node(n2154,refuted), node(n9,refuted).
node(n2151,supported) :- node(n2152,supported).
node(n2151,supported) :- node(n2154,supported).
node(n2151,supported) :- node(n9,supported).
node(n2151,unknown) :- \+ node(n2151,supported), \+ node(n2151,refuted).
verdict(c_17776a84216581cf,supported) :- node(n2151,supported).
query(verdict(c_17776a84216581cf,supported)).
verdict(c_17776a84216581cf,refuted) :- node(n2151,refuted).
query(verdict(c_17776a84216581cf,refuted)).
verdict(c_17776a84216581cf,unknown) :- node(n2151,unknown).
query(verdict(c_17776a84216581cf,unknown)).
node(n2157,supported) :- node(n2132,supported), node(n2133,supported), node(n2134,supported), node(n2153,supported).
node(n2157,refuted) :- node(n2132,refuted).
node(n2157,refuted) :- node(n2133,refuted).
node(n2157,refuted) :- node(n2134,refuted).
node(n2157,refuted) :- node(n2153,refuted).
node(n2157,unknown) :- \+ node(n2157,supported), \+ node(n2157,refuted).
node(n2158,supported) :- node(n2136,supported), node(n2137,supported), node(n2138,supported), node(n2155,supported).
node(n2158,refuted) :- node(n2136,refuted).
node(n2158,refuted) :- node(n2137,refuted).
node(n2158,refuted) :- node(n2138,refuted).
node(n2158,refuted) :- node(n2155,refuted).
node(n2158,unknown) :- \+ node(n2158,supported), \+ node(n2158,refuted).
node(n2156,refuted) :- node(n2157,refuted), node(n2158,refuted), node(n9,refuted).
node(n2156,supported) :- node(n2157,supported).
node(n2156,supported) :- node(n2158,supported).
node(n2156,supported) :- node(n9,supported).
node(n2156,unknown) :- \+ node(n2156,supported), \+ node(n2156,refuted).
verdict(c_474be15f99f1ae30,supported) :- node(n2156,supported).
query(verdict(c_474be15f99f1ae30,supported)).
verdict(c_474be15f99f1ae30,refuted) :- node(n2156,refuted).
query(verdict(c_474be15f99f1ae30,refuted)).
verdict(c_474be15f99f1ae30,unknown) :- node(n2156,unknown).
query(verdict(c_474be15f99f1ae30,unknown)).
