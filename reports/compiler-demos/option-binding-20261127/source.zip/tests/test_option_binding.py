from math import isclose

from evaluate_binding_followup import solve
from evaluate_option_binding import speech_program
from prepare_option_binding import REPLACE


def test_speech_option_observations_require_one_eligible_span():
    scores = dict(whole_claim=1., alternatives=1., first_option=1., second_option=0., option_relation=0.1)
    case = dict(id='claim', content='A replaces B.', options=['A','B'], relation=REPLACE,
                query=dict(speaker='A', start=0, end=5), windows=[
                    dict(id='one', checks=dict(speaker=True,time=True), scores=scores),
                    dict(id='two', checks=dict(speaker=True,time=True),
                         scores=dict(scores,first_option=0.,second_option=1.,option_relation=0.)),
                    dict(id='three', checks=dict(speaker=False,time=True),
                         scores=dict(scores,second_option=1.,option_relation=1.)),
                ])
    programs = [speech_program(case, method) for method in ('separate_options','specific_relation')]
    results, _ = solve(programs)
    assert results['claim:separate_options']['supported'] == 0.
    assert isclose(results['claim:specific_relation']['supported'], 0.1, abs_tol=1e-10)
    assert any(o['predicate'].startswith('option_relation(U, A, B,')
               for o in programs[1].occurrences)
