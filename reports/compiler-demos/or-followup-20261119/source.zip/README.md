# Negation, shared words, and alternatives in speech

## Stopping criteria

The round checks both previously identified errors, preservation of the intended scope in unambiguous controls, all changed programs in a full corpus replay, and readings of new source claims. The speech pilot aims to recover at least four of five genuine excerpts expressing alternatives without the word “or,” return no false support for wrong-speaker or disjoint-time inputs, and retain every earlier correct transcript judgment. The exact criteria and per-case decisions are in the run directory.

## Compiler

The compiler uses source dependencies and the existing semantic roles to locate the alternatives. The basic dependency parse often attaches a shared dependent to just one conjunct. Enhanced dependencies can link that dependent to all conjuncts that share it. [Universal Dependencies guidelines](https://universaldependencies.org/u/overview/enhanced-syntax.html)

- A single negation over two coordinated actions requires both actions to be absent. An independently expressed subject, auxiliary, or clause boundary can keep negation local to one branch. The two-clause controls cover both readings.
- The shared location is retained for repeated predicates when the subject and final destination align and the first branch lacks a competing destination. “Has been flown back or is due to be flown back to the UK” keeps the completed and due readings as alternatives. The perfect aspect is read from the source auxiliaries on the correct token.
- In “public or private hospital,” an explicit modifier coordination refers to one hospital candidate. A modifier of a different noun stays with that noun.
- One earlier speech example had a repeated clause attached to the reporting verb. Matching the repeated subject, auxiliary, and predicate inside an overt “that” complement keeps both alternatives within the same report. The compiled speech predicate records the full source span.

Both original OR errors are fixed. All sixteen unambiguous authored cases preserve the intended scope. Two authored nominal cases need context about which material or modifier belongs to which noun. All 16 exact DeepProbLog controls on the repaired OR programs return their expected result. These use supplied evidence states.

The full fixed sequence produces 2,179 accepted programs from 2,375 inputs, with every program byte-identical to the prior version and the same 196 abstentions. The new cases with these specific patterns expose errors that the earlier corpus checks did not encounter. In the new AVeriTeC sample, seven of 12 compile under SRL followed by AMR. One is a full meaning match, two are partial, four are incorrect and five have no program. One program changes in this sample and makes the weapon modifiers explicit. The other errors include negation expressed by “without,” an obligation followed by its sanction, and reversed giver and recipient roles. One claim is split by Stanza inside a name. Rewriting was disabled for this new sample. References were frozen before parser outputs and reviewed by the implementing assistant. Source pages are distinct from the earlier audits. [AVeriTeC](https://fever.ai/dataset/averitec.html)

## Speech

The new sample includes five genuine AMI excerpts in which the speaker signals alternatives without using “or,” two excerpts with an incomplete or unrelated alternative, and paired crops, altered claim wording, and speaker and time shifts. The old exact alternative method matches 27 of 32 comparisons. Requiring entailment in both directions fails to recover the complete genuine excerpts when the claim omits detail. Comparing the transcript to the claim in one direction finds all five, but initially confuses one edited claim with its genuine counterpart. Checking reverse contradiction rejects that contrast. The final method matches all 32 expected labels. All ten wrong-speaker and disjoint-time controls return unknown. The score thresholds are 0.55 for forward entailment and a ceiling of 0.5 for reverse contradiction. The explicit “or” path retains the earlier bidirectional entailment comparison.

The test receives manual speaker IDs, word times, and whether the window is complete. It uses the same frozen MiniLM checkpoint as the earlier audit and uses selected transcripts during development. Four earlier claims now compile to the full speech condition. Exact DeepProbLog controls feed transcript judgments to those conditions and hold all other observations fixed. The report includes the per-case successes and misses. [AMI transcripts](https://groups.inf.ed.ac.uk/ami/download/)

AMI excerpts are licensed under CC BY 4.0. Crops are supplied as original text with word times. Wrong-speaker and disjoint-time controls reassign the original words, and claim contrasts change only the hypothesized alternatives. [License](https://creativecommons.org/licenses/by/4.0/)

## Replay

Run from the bundle root with Python 3.12 and the attached compilation requirements. Use saved parser results and entailment scores. The two corpus files in the bundle contain the program hashes and routing decisions.

```sh
export PYTHONHASHSEED=0
export PYTHONPATH=scripts
run=exp/probabilistic_verification/or_followup_20261119
prior=exp/probabilistic_verification/or_source_evaluation_20261119
python scripts/evaluate_or_followup_compilation.py "$run/controlled" "$run/amr.jsonl" "$run/controlled_after.json"
python scripts/evaluate_or_followup_compilation.py "$run/fresh" "$run/amr.jsonl" "$run/fresh_after.json"
python scripts/evaluate_or_followup_compilation.py "$prior/fresh" "$prior/fresh/amr.jsonl" "$run/prior_after.json"
python scripts/evaluate_or_followup_compilation.py "$prior/transcripts" "$prior/transcripts/amr.jsonl" "$run/transcript_prior_after.json"
python scripts/evaluate_implicit_alternatives.py evaluate
python scripts/check_or_followup_inference.py
python scripts/or_followup_report.py
python -m pytest -q tests/test_coordination.py tests/test_transcript_or.py
```

Compare the generated files to `REPLAY_SHA256.json`. The earlier report archive preserves the previous compiler. The run includes the previous outputs on the same annotations and the pinned speech model snapshot metadata. Source citations and case provenance are in `evaluation.json`.

## Next work

1. Add fresh evaluation cases for “without” and obligations with consequences. Use them to test whether the next compiler change preserves negative scope and avoids turning a consequence into a plain alternative.
2. Run an alignment comparison with automatically proposed speaker windows and a small independently reviewed set. Measure how much the reported-content result depends on the supplied alignment.
