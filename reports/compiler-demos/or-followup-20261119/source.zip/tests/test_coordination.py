import json
from pathlib import Path

import pytest

from probabilistic_verification.compiler_fallback import check_output, restore
from probabilistic_verification.compiler_repairs import compile_one

ROOT = Path(__file__).resolve().parents[1] / 'exp/probabilistic_verification'


@pytest.fixture(scope='module')
def compiled():
    files = [
        ROOT / 'or_followup_20261119/controlled/parsed.jsonl',
        ROOT / 'or_source_evaluation_20261119/fresh/parsed.jsonl',
        ROOT / 'or_source_evaluation_20261119/transcripts/parsed.jsonl',
    ]
    inputs = {row['claim_id']: dict(row['clauses'][0]['record'], claim_id=row['claim_id'])
              for f in files for row in map(json.loads, f.read_text().splitlines())}

    def get(cid):
        record = inputs[cid]
        output = check_output(record, compile_one(record))
        assert output['status'] == 'compiled', output.get('reason')
        return output, restore(output['compilation'])

    return get


@pytest.mark.parametrize('cid', ['neg_1', 'neg_2', 'neg_3', 'neg_4', 'or_averitec_train_4'])
def test_shared_negation_requires_both_denials(compiled, cid):
    output, _ = compiled(cid)
    group = output['proposed_form']['formula']
    assert group['op'] == 'and'
    assert all(node['op'] == 'not' for node in group['children'])


@pytest.mark.parametrize('cid', ['local_neg_1', 'local_neg_2', 'local_neg_3'])
def test_negation_with_independent_clause_stays_inside_or(compiled, cid):
    output, _ = compiled(cid)
    assert output['proposed_form']['formula']['op'] == 'or'
    assert all(c['kind'] != 'shared_negation' for c in output['changes'])


def test_due_coordination_preserves_shared_destination_and_different_status(compiled):
    output, claim = compiled('or_averitec_train_1752')
    formula = output['proposed_form']['formula']
    assert formula['op'] == 'or'
    completed, due = formula['children']
    assert due['operator'] == 'due'
    assert completed['arguments']['ARG1'] == due['body']['arguments']['ARG1']
    assert completed['arguments']['ARGM-DIR'] == due['body']['arguments']['ARGM-DIR']
    assert any(t['aspect'] == 'perfect' for t in claim.metadata['temporal'].values())


def test_noun_alternatives_share_one_candidate(compiled):
    _, claim = compiled('shared_noun_1')
    choices = [a for a in claim.atoms if a.predicate == 'property' and a.arguments[2] in {'public','private'}]
    assert len(choices) == 2
    assert choices[0].arguments[0] == choices[1].arguments[0]
    assert ' OR ' in claim.to_dict()['logical_form']


def test_same_report_owns_both_repeated_clauses(compiled):
    _, claim = compiled('reported_or_03')
    conditions = [a for a in claim.atoms if a.predicate == 'reported_disjunction']
    assert len(conditions) == 1
    assert conditions[0].arguments[2] == 'that you could have a broccoli, or you could have a mango'
    assert all(a.predicate != 'have' for a in claim.atoms)
