from probabilistic_verification.transcript_or import judge

SEGMENT = {'speaker': 'A', 'start': 10., 'end': 15.}
TARGET = 'The chair is in the hall or it is in the kitchen.'


def candidate(text, **changes):
    return dict(SEGMENT, text=text, target=TARGET, complete=True) | changes


def test_explicit_alternatives_are_live_in_both_orders():
    assert judge(SEGMENT, candidate(TARGET)) == 'supported'
    assert judge(SEGMENT, candidate('It is in the kitchen, or the chair is in the hall.')) == 'supported'


def test_complete_edit_and_genuine_crop_give_different_judgments():
    text = 'The chair is in the hall.'
    assert judge(SEGMENT, candidate(text)) == 'refuted'
    assert judge(SEGMENT, candidate(text, end=12., complete=False)) == 'unknown'
    assert judge(SEGMENT, candidate(text, end=12.)) == 'unknown'
    assert judge(SEGMENT, candidate('The chair is in the hall and it is in the kitchen.')) == 'refuted'


def test_wrong_speaker_and_disjoint_time_are_unknown():
    assert judge(SEGMENT, candidate(TARGET, speaker='B')) == 'unknown'
    assert judge(SEGMENT, candidate(TARGET, start=15., end=17.)) == 'unknown'


def test_unseen_wording_remains_unknown_with_literal_check():
    assert judge(SEGMENT, candidate('The hall is one possibility. The kitchen is another.')) == 'unknown'
    assert judge(SEGMENT, candidate('A box is inside or it is outside.')) == 'unknown'
    assert judge(SEGMENT, candidate('He read “the chair is in the hall or it is in the kitchen.”')) == 'unknown'


def test_branch_nli_requires_bidirectional_entailment():
    evidence = 'The chair is in the corridor or it is in the galley.'
    matching = {frozenset(('The chair is in the corridor', 'The chair is in the hall')),
                frozenset(('it is in the galley', 'it is in the kitchen'))}
    assert judge(SEGMENT, candidate(evidence),
                 lambda a, b: float(frozenset((a, b)) in matching)) == 'supported'
    assert judge(SEGMENT, candidate(evidence),
                 lambda a, b: float('corridor' in a or 'galley' in a)) == 'unknown'


def test_options_without_or_allow_detail_in_evidence_but_check_contradiction():
    text = 'The chair is in the corridor. Alternatively it is in the galley.'
    def entails(a, b):
        return float(a == 'The chair is in the corridor' and b == 'The chair is in the hall'
                     or a == 'it is in the galley' and b == 'it is in the kitchen')
    assert judge(SEGMENT, candidate(text), entails, allow_implicit=True) == 'supported'
    assert judge(SEGMENT, candidate(text), entails, allow_implicit=True,
                 contradiction=lambda a, b: float(a == 'it is in the kitchen')) == 'unknown'
    assert judge(SEGMENT, candidate(text, speaker='B'), entails, allow_implicit=True) == 'unknown'


def test_a_single_announced_option_does_not_supply_both():
    statement = 'The other option is to place it in the kitchen.'
    def entails(a, b):
        return float(a == statement and b == 'it is in the kitchen')
    assert judge(SEGMENT, candidate(statement), entails, allow_implicit=True) == 'unknown'
