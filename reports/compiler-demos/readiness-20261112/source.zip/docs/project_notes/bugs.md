# Bug Log — AViD Phase 1
_Terminology follows docs/project_notes/terminology.md._

### 2026-06-17 — v0 `na` label stored as stale key `not_annotatable`
- **Issue**: `exp/v0/affordance_llm.jsonl` uses the key `not_annotatable` instead of `na` (not applicable — a unit carrying no standalone probe) in distribution dicts; `affordance_annotation.tsv` was not regenerated after the key rename.
- **Root Cause**: Label rename (`not_annotatable` → `na`) was applied to scripts *after* the v0 Slurm job ran; the v0 cache is frozen read-only.
- **Solution**: Do not re-run v0. For any downstream code reading v0 raw jsonl, map `not_annotatable` → `na`. The v0 `affordance_annotation.tsv` also has not been regenerated with the new script; treat it as stale.
- **Prevention**: After any label rename, regenerate cached outputs or add a migration note to the version README before archiving.

### 2026-06-17 — v0 `na` over-prediction (11.1%) from ambiguous F-option wording
- **Issue**: v0's 6-class prompt option F read "cannot be verified in isolation without its arguments" — model applied this to context-dependent entities like "the typhoon" and "Alaska", yielding 530 `na` predictions (11.1%).
- **Root Cause**: Option F described a syntactic isolation criterion, but the model interpreted "without its arguments" broadly as "needs context to interpret", which applies to nearly everything.
- **Solution**: Redesigned `na` in v1/v2 pass-1 with two explicit criteria + a pointability test + a NEVER-na guard. See ADR-003.

### 2026-06-21 — v1 first run (job 357515) under-predicted `na` (0.1%)
- **Issue**: Initial pass-1 prompt defined `na` as "relational/incomplete — never a noun or noun phrase". Only 5 units labeled `na` (0.1%); vague referents like "the conditions", "anyone" were classified as `unverifiable`.
- **Root Cause**: "Never a noun or noun phrase" was too broad a restriction — it excluded the entire class of vague/underspecified referents.
- **Solution**: Revised pass-1 prompt; added criterion (2) for vague referents and the pointability test. Re-ran as job 357532; new `na` count = 104 (2.2%). Original run archived to `exp/v1/archive/`.

### 2026-06-22 — Phase 2 job 359161 crashed: logprobs=30 exceeds V1 engine limit
- **Issue**: `smoke_test_omni.py` and `verify_support.py` used `logprobs=30`. Qwen3-Omni is served by the vLLM V1 engine (despite `VLLM_USE_V1=0` in env — that var is unrecognized in this vLLM version). V1 engine caps `logprobs` at 20.
- **Root Cause**: vLLM 0.18 ignores `VLLM_USE_V1` (logs "Unknown vLLM environment variable detected: VLLM_USE_V1") and uses V1 by default. Phase 1 text-only model worked with `logprobs=20` (was already at the limit).
- **Solution**: Changed `logprobs` to 20 in `smoke_test_omni.py` and as the default in `verify_support.py --logprob-n`.
- **Prevention**: Always use `logprobs≤20` with vLLM 0.18+. Do not rely on `VLLM_USE_V1=0` — it is silently ignored in this version.

### 2026-06-22 — Phase 2 job 359190 crashed: VL decoder prompt exceeds max_model_len=16384

- **Issue**: `verify_support.py --modality visual` crashed on Batch 1/151 with `ValueError: The decoder prompt (length 24683) is longer than the maximum model length of 16384.`
- **Root Cause**: Qwen3-VL-8B expands each image into ~2,057 visual tokens in the decoder. 12 frames × 2,057 ≈ 24,683 tokens + text overhead, which exceeds `max_model_len=16384`.
- **Solution**: Increased `max_model_len` from 16384 to 32768 in `verify_support.py` VL model initialization. 24,683 < 32,768 fits cleanly; KV cache blocks are fixed at 512 regardless of `max_model_len`, so memory impact is minimal.
- **Prevention**: When using Qwen3-VL with multiple images, calculate expected token count first: `n_frames × ~2057 + ~700 text tokens`. For 12 frames, need `max_model_len ≥ 25400`. Keep at 32768 as default.

### 2026-06-23 — claim_text anchor triggers the claim-anchor collapse (81% same-status predictions across sub-units)

- **Issue**: All six prompt templates in `verify_support.py` begin with `Claim: "{claim_text}"`. The model uses this as its primary signal, applying the claim-level verdict to every sub-unit. Result (the claim-anchor collapse): 81% of multi-unit claims have ALL units receiving the same status, with individual unit text having no effect.
- **Root Cause**: Prompt design: the full claim is shown before the target unit. The model correctly identifies whether the overall claim is supported, then repeats that judgment for each sub-unit without re-evaluating.
- **Evidence**: Simple entity units like "A man" get P(no)=1.0000 when the full claim "A man is laying very close to the tracks" is unsupported — even though "is there a man visible?" is an independent question. Mixed-status claims exist but are the minority (19%).
- **Solution**: Remove the `Claim:` line from all six prompt templates. The `marked_context` field (which bolds the unit in the claim string) already supplies context without anchoring on truth value.
- **Prevention**: When designing verification prompts with sub-claim decomposition, never show the parent claim alongside the sub-unit — it causes the model to inherit the parent verdict.

### 2026-06-23 — verify_support.py passed unverifiable units to signal models

- **Issue**: `load_na_set()` in `verify_support.py` only excluded units where `pred_llm == "na"`. Units where `pred_llm == "unverifiable"` (154 full-claim rows, ~3.2% of units) were processed by Qwen3-VL and Qwen3-Omni despite the instruction to skip them.
- **Root Cause**: The skip-list build condition checked `== "na"` only. The `"unverifiable"` label was added in v2 but the filter was not updated.
- **Solution**: Changed the filter to `label in {"na", "unverifiable"}` in `load_na_set()`. Pre-built skip lists are regenerated on next job run. The existing pipeline output is valid for the verifiable subset; `full_claim_support.tsv` now explicitly filters to verifiable modality-need labels (the text-only judgment of which channel a unit needs) only.
- **Prevention**: Whenever a new skip-worthy modality-need label is added, update both the skip condition and the docstring. The label set `{"na", "unverifiable"}` is now documented in `load_na_set()`'s docstring.

### 2026-06-18 — H100 job (357471) stuck in pending — wrong GPU target
- **Issue**: Slurm job targeting `gpu:h100:1` waited indefinitely; both H100 nodes unavailable (rack3n06 DOWN, rack7n07 fully allocated). All A100-80GB and L40S nodes also fully occupied.
- **Root Cause**: Submitted without checking GPU availability; H100 headcount on this cluster is small (8 GPUs, 2 nodes).
- **Solution**: Cancelled 357471; resubmitted targeting `gpu:h200:1`. Job started immediately (H200 at rack3n05 had 3/8 free slots). Slurm scripts now use `--gres gpu:h200:1` as default.
- **Prevention**: Run `sinfo -o "%N %G %t" | grep h100` before assuming H100 availability. H200 is more available and has more VRAM (141 GB vs ~80 GB). Default new jobs to H200.

### 2026-06-26 — 45 claims falsely no_video=True due to claim-index misalignment

- **Issue**: 45 claims (255 rows in support_readable.tsv) showed `visual=no_video, audio=no_video, status=unknown`. The model explanations confirmed no media was provided ("no visual content provided to analyze").
- **Root Cause**: `verify_support.py` sets `no_video=True` when a claim ID isn't found in the step1 probing manifest. The AVID annotation pipeline (phase 1) assigned `claim_index` values that differ from what the probing manifest recorded for the same topics. E.g., claim text "The tram passes through the De La Reyweg rail station." has index 782 in annotation_units but 789 in the manifest. This affects 10 topics, 45 claims; the media files for these claims exist and are already extracted (for 36 of 45), just under different claim IDs.
- **Solution**: Built `scripts/build_manifest_patch.py` — generates `exp/phase2/manifest_avid.jsonl` (original manifest + 41 patch entries) using text-based claim matching. Updated `DEFAULT_MANIFEST` in both `verify_support.py` and `extract_media.py` to point to the patched manifest. Migrated existing r5e (the answer-first explanation prompt variant) cache to `r5e/cache/v5/` stripping stale entries for the 41 claims. Submitted job chain (365211–365214) to extract T8u81WMIyj18 media, re-run r5e visual+audio, and regenerate support_annotation.tsv + support_readable.tsv.
- **4 truly unmatched**: TMrQshDs8aH0_730, TQKCK6-tRaoE_644, Tsuk2uoYj-kc_596/597 — claim texts not found in manifest under their topics; remain no_video=True.
- **Prevention**: When building a new manifest, always verify that all annotation claim IDs match by running `build_manifest_patch.py`. The patched manifest at `exp/phase2/manifest_avid.jsonl` is now the single canonical source for all Phase 2 media lookups.

### 2026-06-24 — vLLM EngineCore "No CUDA GPUs are available" on H100 rack3n06
- **Issue**: verbalize job 361349 ran on `gpu:h100:1` (rack3n06). `nvidia-smi` in the job shell saw the H100 fine and unit filtering completed, but the vLLM **V1 EngineCore subprocess** crashed at `init_device → torch._C._cuda_init()` with `RuntimeError: No CUDA GPUs are available` — *before* model load. This cascaded `DependencyNeverSatisfied` to the whole afterok chain (361350–352).
- **Root Cause**: Node-specific to **rack3n06 (H100)** in the `vllm-omni` env — the spawned EngineCore worker could not acquire a CUDA context even though the parent shell saw the GPU (likely compute-mode / driver state on that node). Not a code/env-inheritance issue: submit-env was clean (only benign `VLLM_CACHE_ROOT`); the identical code ran fine on H200.
- **Solution**: Resubmitted the entire DAG on **H200** (`gpu:h200:1`, rack3n05). verbalize 361354 cleared `init_device` and loaded the 30B (56.9 GiB) immediately; chain proceeded.
- **Prevention**: For vLLM in this env, **target H200 (rack3n05)** — the proven node for both the 30B text/Omni models and Qwen3-VL. Avoid rack3n06 H100 for vLLM until confirmed healthy. Reinforces the 2026-06-18 "default to H200" rule, now for a CUDA-init (not just scheduling) reason. When babysitting an unattended DAG, verify the head job clears `Loading weights` before walking away.

### 2026-07-04 — Phase-3 negation never detected (UD v2 has no `neg` deprel) + operators probed
- **Issue**: `build_tree.py` detected negation via `deprel == "neg"` and via hypergraph `node_type` containing the substring `"negation"`. On this parser **neither ever matched**: negation surfaces as `advmod`/`det`/`case`/`mark`, and the operator node_type is `logical-op` (not `"negation"`). Result: **0 of 74 negated natural claims were flipped** (`is_negation`/`negated` = 0 everywhere in `trees_ud.jsonl`) — silently inverting the truth value on exactly the headline case. Separately, **191 operator-typed nodes** (relation-op 125 / logical-op 62 / coord-op 4) leaked into the probe surface `tree_units_ud.tsv` — the model would have probed "not" / "and" / particle "up" as if they were content.
- **Root Cause**: `neg` was **deprecated in UD v2** (negation is `advmod` on the head, etc.); the code was written against UD v1. And functional-ness was inferred from the UD deprel alone, so a negation word parsed as `advmod` fell through to `rel_class=modifier` → `probed=True`. The M0 negation gate passed only because it used a HAND-negated fixture, not the real detector.
- **Solution**: (1) detect negation by **lemma** (`NEG_LEMMAS`, any deprel); set `negated=True` on the nearest content-node scope (unary flip) and contract the distinct negation operator node; (2) treat all Phase-1 operator node_types (`relation-op`/`logical-op`/`coord-op`) as structural → `is_functional=True` (contracted; dropped from the CRF by `run_crf_inference.py:192`, excluded from the probe TSV). Re-ran `build_tree.py`: probe surface 13,771 → **13,580** (−191); negation now fires on **74 claims** (85 operator nodes, 87 scopes). Aggregate verdicts stable (61.3/19.0/19.6). See ADR-015.
- **Prevention**: This parser is **UD v2** — never key on the dead `neg` deprel; detect negation by lemma. Derive node role from the **Phase-1 node_type taxonomy** (entity/event/attribute/cardinality = content; relation/coord/logical-op = operators), not from the UD deprel alone. When a gate tests a headline behavior (the negation flip), test the **real detector output**, not a hand-built fixture — a hand-negated example masked this for two milestones (M0, M1).

### 2026-07-15 — GPU jobs stall forever on H200 (`QOSMaxGRESPerUser`) — H200 not in the QoS

- **Issue**: `sbatch --gres gpu:h200:1` jobs sit `PENDING` indefinitely with reason `QOSMaxGRESPerUser`,
  even with 0 running jobs of mine and H200s free — not contention, a **hard block** (study jobs
  399579/399580 never started).
- **Root Cause**: my QoS `cxiao_8gpu_tier` grants `gres/gpu:a100=4` and `gres/gpu:h100…` but **does NOT
  include h200** — check `sacctmgr -n show assoc user=$USER format=qos,maxtresperuser`. Any h200 request
  exceeds the (zero) h200 allowance → immediate `QOSMaxGRESPerUser`. HANDOFF/key_facts "H200 rack3n05 is
  the target" is **stale** (older jobs 370558 etc. must have run under different conditions).
- **Solution**: target **A100** (allowed; usually idle). Qwen3-VL-8B → **A100-40gb**; **Qwen3-Omni-30B
  needs ~60 GB → A100-80gb** (`--gres=gpu:a100:1 --constraint=80gb`) — the idle rack5 A100s are 40gb, too
  small for Omni. Always `--exclude rack3n06` (Omni vLLM CUDA-init bug — 2026-06-24 entry). Override
  `--gres/--constraint` at `sbatch` submit so slurm files stay untouched (note: the `run_phase2_*.slurm`
  wrappers hard-code `gpu:h200:1` and will stall unless overridden). Jobs 399673/399674 ran this way.
- **Prevention**: default GPU submissions to **A100** for this project, not H200; check
  `sacctmgr -n show assoc user=$USER format=qos,maxtresperuser` before assuming a GPU type is available.

### 2026-07-15 — Qwen3-30B-A3B OOM on A100-40gb (PN-2 job 400805)

- **Issue**: `run_pn2_srl.py` (PN-2 — parse-normalization, SRL role typing) crashed with CUDA OOM on rack5n06 (A100-40gb, 39.49 GB): model loaded 38.60 GB of weights, leaving only 371 MB — not enough for KV cache. Error at `SharedFusedMoE` allocation.
- **Root Cause**: Qwen3-30B-A3B is a MoE model with 30B total parameters. In bf16, weights alone are ~28 GB; with vLLM 0.18.0 framework overhead, CUDA context, and activation memory, total GPU use exceeds 39 GB, leaving insufficient headroom for KV cache at `gpu_memory_utilization=0.90`.
- **Solution**: Use **A100-80gb** (`--constraint=80gb`, rack7n05 or rack8n05). Resubmitted as job 400840 on rack8n05.
- **Prevention**: Qwen3-30B-A3B text inference needs A100-80gb or better, NOT A100-40gb. Rule: any 30B-class model → A100-80gb. Update any Slurm scripts that might reuse this model.

### 2026-07-16 — rack10n07 TMPDIR permission failure crashes vLLM audio job (401909)

- **Issue**: `sbatch --gres=gpu:a100:1 --constraint=80gb` job on rack10n07 fails with `slurmstepd: error: Unable to create TMPDIR [/scratch/jobs/cxiao/401909]: Permission denied`. vLLM then fails in `determine_available_memory()` with `RuntimeError: Engine core initialization failed. Failed core proc(s): {}`.
- **Root Cause**: rack10n07 has `/scratch/jobs/` as its job TMPDIR but the directory for user cxiao is not creatable (permissions). vLLM relies on TMPDIR for IPC/socket files and crashes when TMPDIR falls back to `/tmp`.
- **Solution**: Exclude rack10n07 (`--exclude=rack3n06,rack10n07`) for Qwen3-Omni audio jobs. Resubmitted as job 401967 on remaining A100-80gb nodes (rack7n05 or rack8n05).
- **Prevention**: Exclude rack10n07 from all vLLM jobs until permissions are fixed. Add to standard `--exclude` list alongside rack3n06.

### 2026-07-16 — gold pilot showed bare "hand" not "by hand" (build read pre-PN field)

- **Issue**: After PN ran, the regenerated pilot still showed `"hand"`, `"tram"`, `"correct position"` — the PN MERGE ("by hand") wasn't visible.
- **Root Cause**: PN did NOT restructure the tree; it wrote the merged unit into **sidecar fields** (`pn_unit_text`/`pn_unit_span`, `role`, `comp`). But `build_gold_pilot.py`/`build_gold_viewer.py` read the pre-PN `content_subtree_text`/`node_text` and derived kind from `probed`/`is_functional` — ignoring the PN fields. ~194/1048 (19%) probed pilot rows were wrong.
- **Solution**: Build scripts now read `pn_unit_text`/`pn_unit_span` and `role` (op/na/probeable) first, falling back to raw fields; default `--trees` → `trees_ud_star.jsonl`. `build_gold_viewer` tree SVG source → the checkable-unit tree T* too.
- **Prevention**: When a pass writes decisions to sidecar fields instead of mutating the base fields, every downstream reader must be updated to prefer the sidecar. Grep for `content_subtree_text` before trusting a "PN ran" claim.

### 2026-07-16 — malformed clause-length units (content_subtree over-capture + MERGE full-subtree)

- **Issue**: ~1,334 non-event units were clause-length, e.g. entity `"John Torpey is the World Central Kitchen response director"`, `"Many people are out of food and water"`; obl `"from the typhoon in Western Alaska"`.
- **Root Cause**: (a) `build_tree._compute_all_subtree_spans` folded **every** content descendant into `content_subtree_span`, so a copular/predicate root swallowed its `nsubj` subject and an `obl` swallowed a trailing `nmod` (336 root cases). (b) PN-1 MERGE set `pn_unit_text = subtree_text` (the **full** subtree) instead of just the case marker (519 widened).
- **Solution**: `UNIT_BOUNDARY_DEPRELS` gate — non-event units fold only tight modifiers (det/case/amod/compound/nummod/flat), excluding boundary children (nsubj/obj/obl/nmod/acl/appos/ccomp/…). **Events exempt** (keep the full proposition). PN-1 MERGE extends the tight content span left over the case marker only. Clause-units 1,334 → 147.
- **Prevention**: A node's *probe unit* is its local head phrase; nested arguments/obliques/clauses are their **own** nodes — never fold them into the parent unit. Filter `node_type=='event'` when auditing unit length (event propositions are legitimately long).

### 2026-07-16 — F₃ checkability v1 over-flipped named/concrete entities

- **Issue**: PN-3 F₃ v1 marked `Typhoon Halong`, `Dust storm`, `People`, `Movement`, `home floats away` as `na` (168/431 entity flips looked named/proper), contradicting the prompt's own "named entity → CHECKABLE" rule.
- **Root Cause**: v1 examples were microvent-flavored and the criterion under-specified concrete natural phenomena/events; the model treated large-scale/collective nouns (a storm, a movement) as abstract.
- **Solution**: prompt **v2** (`CHECKABLE_PROMPT_VERSION="v2"`) — principle-first, explicit "a concrete phenomenon/event or a named one is CHECKABLE; do not flip for sounding large/collective", `storm`/`crowd`→CHECKABLE examples. Result: 293 v1-NA rescued to CHECKABLE, proper-noun entity `na`s 168 → 64; normatives (`correct`, `beautiful`, `illegitimate`) still `na`.
- **Prevention**: keep F₃ examples domain-neutral; test both directions (normatives stay NA, concrete phenomena stay CHECKABLE) on the actual corpus before freezing. `na` is annotator-validated, so residual imprecision is recoverable but a high over-flip rate is bad pre-fill UX.

### 2026-07-20 — ADR-018 tight-unit fix TRUNCATED 1,375 event/root propositions

- **Issue**: after ADR-018, the claim proposition was missing for many claims — `Successful liftoff of rocket` → `Successful liftoff`, root `broadcast includes clips` dropped `of heavy rain…`. Only 48% of claims had any unit covering the full claim.
- **Root Cause**: ADR-018 gated the **shared** `content_subtree_span` computation for non-events. Because cssp is built recursively from children's cssp, a tightened child truncated its parent — propagating up to events and the ROOT, which should carry the full proposition.
- **Solution** (ADR-019): events + root use the **full subtree** (`cssp = ssp`); only non-root non-events use the tight span. Root-covers-full-claim 48% → 96%; truncations 1,375 → 0.
- **Prevention**: tightening is a NON-root NON-event concern only. The root and event nodes are propositions — never assemble their unit from tightened children; use their own full subtree span.

### 2026-07-20 — bare adj/adv/number probes are vacuous + redundant (incl. "1" in "Blue Ghost Mission 1")

- **Issue**: `clear`, `still`, `large`, and `1` (nummod of "Mission") were probed as standalone units. "is 'clear'/'1' present?" has no truth value alone.
- **Root Cause**: the pipeline probed every content node, including bare modifiers. 1,512/1,788 attribute units were strictly nested in their head noun's unit (`High` ⊂ `High winds`); the modifier's content was already in the head. The initial fix scoped by `node_type=='attribute'` and MISSED `nummod` (node_type `cardinality`) — hence `1` slipped through.
- **Solution** (ADR-019): suppress non-root modifiers **by deprel** (`amod`/`advmod`/`nummod`) → `probed=False, role=na`. Covers adjectives, adverbs, AND numbers. Probed amod/advmod/nummod now 0.
- **Prevention**: scope modifier rules by **deprel**, not node_type (cardinality vs attribute are different node_types but the same "bare modifier" phenomenon). A node whose span is subsumed by its head is not a standalone unit.

### 2026-07-20 — PN-1 MERGE + SRL over-attached prepositions / temporal na (with clear skies, as rocket lands)

- **Issue**: `with clear skies` (should be `clear skies`) and it was na; `as rocket lands` na (visible landing suppressed); `of rocket`/`in Western Alaska` carried needless prepositions.
- **Root Cause**: (a) PN-1 MERGE prepended the case marker to ALL obl/nmod, but only manner/instrument ("by hand") needs it; (b) SRL mislabeled the weather condition `with clear skies` as `TMP`→na; (c) TMP→na na'd temporal *clauses* wholesale.
- **Solution** (ADR-019): case marker kept only for MNR/INS (else bare content NP); SRL prompt v2 (weather/condition ≠ TMP → `with clear skies` now `OTHER`, kept as `clear skies`); TMP→na only when the unit's subtree has no finite verb.
- **Limitation**: a temporal clause the parser mis-grouped as a NOUN phrase (verb absorbed into the head, e.g. `rocket lands`) is NOT detected as clausal → still na. Mitigated: the proposition-root fix (above) captures it in the probeable root. A parse-layer grouping issue, not fixed in PN.

### 2026-07-20 — H100/H200 QoS-capped at 0; A100-80gb full → ran on 2× A100-40gb tp=2

- **Issue**: the PN regen (Qwen3-30B-A3B, needs 80GB) couldn't schedule — A100-80gb nodes (rack7n05/rack8n05) fully booked ~1 day; H100 (`--gres=gpu:h100:1`) and H200 both `(QOSMaxGRESPerUser)`.
- **Root Cause**: QoS `cxiao_8gpu_tier` MaxTRESPU = `gres/gpu:a100=4, gres/gpu:h100=0, gres/gpu:h200=0`; I have **no** `normal` QoS (`--qos=normal` → "Invalid qos"). So h100/h200 are hard-blocked; only A100 (and V100).
- **Solution**: request **2× A100-40gb with tensor-parallel (tp=2)** — 2×40GB shards the ~38GB weights and sidesteps the single-40gb OOM (bugs.md 2026-07-15). `run_pn2_srl.py`/`run_pn3_check.py` support `--tp 0` (auto from CUDA device count); `run_pn_regen.slurm` set to `--tp 0`. Job 413160 ran in ~16 min.
- **Prevention**: for the 30B on a busy cluster, `--gres=gpu:a100:2 --constraint=40gb` (tp=2) is a viable alternative to scarce A100-80gb. Never target h100/h200 — QoS cap 0. *(UPDATE 2026-07-23: the live QoS is now `h100=4` — H100 IS allocatable; verified by running job 418735 on rack7n07. Only h200=0. Re-check the live QoS.)*

### 2026-07-24 — `calibrate_m2.py` `--T-vis/--T-aud` override silently ignored when the dev set is empty
- **Issue**: the perturbation-faithfulness run calibrated the decoy probes at **T=1.0** despite passing `--T-vis 3.0 --T-aud 2.0` — the override was dropped, so the first decoy unaries were uncalibrated.
- **Root Cause**: `fit_and_report()` returns early with `T=1.0` when `train` is empty (`if not train: return 1.0`) **before** the `if T_override > 0` check. The perturb decoy probes are keyed by perturbed claim_id while the dev decomp is natural-keyed → **zero** dev pairs → empty train → override skipped. (Natural runs always have a non-empty dev set, so `unaries_ud_star.jsonl` was correctly T=3.0/2.0 — **not** affected; verified.)
- **Solution**: honor an explicit `--T-*` override even with no dev set (6-line guard, 2026-07-24). Re-ran → T_vis=3.0/T_aud=2.0 confirmed in the output; faithfulness recomputed on corrected unaries.
- **Prevention**: when passing an explicit temperature, assert it appears in the output rows (`T_vis`/`T_aud`) — don't trust silent fitting. Any calibrate run on a claim-id set disjoint from the dev decomp needs the override guard.

### 2026-07-29 — Binding/removal edits did not propagate to ancestor probe text

- **Issue**: binding and argument-removal perturbations changed the target node, but ancestor/root
  `subtree_text`, `content_subtree_text`, and `pn_unit_text` retained the natural claim. Because M2 (per-node probing)
  probes `unit_text`, AViD often saw the original root while the flat baseline saw the perturbed
  whole claim. This invalidated the earlier binding/removal comparison.
- **Root Cause**: `make_perturbations.py` replaced text only inside the target node and did not remap
  ancestor spans. It also used unconstrained first-occurrence string replacement for the claim text,
  which changed the wrong occurrence in 11 whole-claim baseline examples.
- **Solution**: added span-anchored `replace_target_in_tree`, which propagates the replacement through
  the target and every ancestor, updates all text fields, and remaps every span. Added unit-text hashes
  to M2 cache keys so corrected prompts cannot hit stale cache entries.
- **Verification**: validated all 3,760 binding/removal trees and 7,520 affected ancestors with zero
  stale texts or invalid spans. Re-probed only the 3,076 changed node prompts plus 11 corrected
  whole-claim prompts; reused 13,022 exact-text matches. Jobs 429036/429037/429038 completed with
  full coverage. Corrected lenient detection: binding **93.0% vs 75.5%**, removal
  **71.1% vs 31.1%**, overall **84.0% vs 63.3%**.
- **Prevention**: any perturbation of a tree node must be followed by a corpus-wide invariant check:
  every ancestor surface contains the edited text, no ancestor contains the stale text, all spans
  resolve exactly, and cache identity includes the actual prompt text.

### 2026-07-25 — `rsvg-convert` silently drops `feDropShadow`-filtered rects (pipeline stage boxes vanished)
- **Issue**: rendering `slides/figures/pipeline.svg` → PNG with `rsvg-convert -w N` produced a figure with **no stage boxes** — only the unfiltered text / arrows / numbered badges / mini-trees rendered; the light rounded stage panels disappeared entirely. Looked like a boxless floating-text diagram.
- **Root Cause**: the stage/input/output rects were the only elements carrying `filter="url(#ds)"` (an `feDropShadow`). `rsvg-convert` (librsvg) does not render an element referencing an `feDropShadow` filter — it drops the whole element rather than rendering it un-shadowed. (cairosvg/Chrome/Inkscape would render it; rsvg does not.)
- **Solution**: replaced the `feDropShadow` in `gen_pipeline.py:svg_box` with a renderer-safe manual shadow — an offset semi-transparent `#33415A` rounded rect drawn behind each box. Renders identically under any SVG rasterizer.
- **Prevention**: when the SVG→PNG path is `rsvg-convert`, avoid SVG filter effects (`feDropShadow`, `feGaussianBlur`); fake shadows with an offset semi-transparent shape. **Always visually inspect the rendered PNG**, not just the SVG preview — the SVG looked correct in a browser.

### 2026-08-13 — Hyphenated compounds split into false semantic targets

- **Issue:** the parser split `close-up` into independent `close` and `up` targets and fragmented `before-and-after`, producing nonsensical annotation rows and markers.
- **Root cause:** semantic compilation trusted parser token/node boundaries even when the literal claim surface contained a hyphen chain. A function-like fragment inside the chain could also leak out as a case/coordination marker.
- **Solution:** `semantic_factor_tree.normalize_hyphenated_lexemes` detects every literal alphanumeric hyphen chain before semantic normalization, keeps it on one representative node, contracts the other fragments, and prevents internal function tokens from becoming external markers. Pre-verbal modifier chains attach to the nearest following nominal host. The same pass also enabled the narrow, generic preposed-subject repair that reattaches `comparison` as the subject of `highlights` in the reported example.
- **Prevention:** lexical tokenization invariants precede semantic roles: a literal hyphen chain is one lexical target unless an explicit downstream rule proves otherwise. Audit repaired spans and never add claim-ID exceptions.

### 2026-10-15 — Pilot generation labels, decomposition, and seed descriptions need separate checks

- **Observed failures:** Free-form generation labels clause reordering as role swaps, changes extra attributes, or proposes refutation for still-true claims under another alignment. One visual JSON review labels a claim refuted while explaining it is supported. Automatic decomposition can invent ship-on-dock, substitute entity presence for relations, or leave color attachment in atomic controls. Thumbnail inspection initially put chair stacks on the sidewalk; full-resolution frame_099 shows them on the road. Shorts versus cropped trousers remained ambiguous.
- **Response:** Preserve all initial inputs/raw outputs; record assistant corrections separately. Revised prompts explicitly request intentional false assignments and label–reason consistency. Stronger small-pilot approach: specify checked source/target facts and fixed facts, then ask the LLM to write them. Keep a manually checked logical-form diagnostic separate from the automatic parser. Drop known invalid/uncertain supported seeds from the next generation batch.
- **Prevention:** Inspect full-resolution media for small geometry/attribute details. Model agreement is not truth. Check actual changes, all alternative supporting assignments, fixed attributes, and argument identity. Keep proposed/automatic/assistant/human label sources distinct. Compare missing-media controls to unknown, not to full-media labels. Never replace missing class scores with a uniform vector followed by a supported argmax. Preserve existing gold packages and split by source video.

### 2026-10-22 — DeepProbLog 2.0.6 simplifies confident probabilities to exact identities

- **Issue:** The first categorical S/R/U prototype discarded small outcomes for real scores near zero or one. A supported claim's computed distribution lost probability mass; a constructed event example also failed strict conservation. Ordinary mid-range probability tests had passed.
- **Root cause:** GraphSemiring's tolerance-based is_zero/is_one checks allow the ProbLog evaluator to treat values such as 0.999997 as exactly one. This is inappropriate when the other categorical outcomes must remain represented, and tensor simplifications can also cut gradient paths.
- **Solution:** backend.py supplies a local GraphSemiring subclass that recognizes only exact float constants as identities and uses double-precision classifier tensors. No installed library files are modified. Root distributions must sum to one within 1e-9 without renormalization.
- **Validation:** High-confidence conjunction test agrees with independent categorical-world enumeration within 1e-12. Duplicate/shared-proof, event-assignment, negation, and actual native-training gradient tests pass. The compatibility override applies to the pinned DeepProbLog 2.0.6 implementation; recheck when upgrading.

### 2026-10-22 — Automatic dependency parser reads waves as a noun in coordinated clauses

- **Issue:** Cached Stanza English models parse waves as a coordinated noun in Alice hugs Bob and waves, Alice hugs Bob and Alice waves, and Alice hugs Bob or Carol waves. Those intended simple clauses do not compile automatically.
- **Response:** Preserve the raw parses and reject with coordinated_arguments diagnostics. Do not infer a verb using a claim-specific repair. The report shows 15/18 expected automatic-pipeline outcomes, including eight intended unsupported cases and these three conservative rejections.
- **Scope:** Shared subjects and clause reference scope pass separate tests with specified correct UD structures. Those tests do not establish automatic parser accuracy. A future parser or constrained semantic-analysis fallback must be assessed separately.


### 2026-10-22 — Audio chat prefix and missing evidence expose unreliable readouts

- **Observed:** An inserted empty thinking block gives a whitespace-only free
  description on the main audio clip. Using the checkpoint's documented default
  template, an explicit EOS token and repetition penalty yields a coherent music
  description. Classification still assigns music support 0.997 to silence and
  0.9997 to text alone. This is an unresolved evidence-use failure, not fixed by
  logical probability normalization.
- **Handling:** Preserve initial/final outputs and control features. Use the
  documented default audio template; cast floating processor inputs to bf16 to
  match audio-tower weights. Known missing input is an explicit unknown state;
  raw silence-control scores remain visible. Do not turn verifier labels into gold.
- **Separate semantics fix:** The generic compiler made a mentioned place a
  physically present object. Reject mention until content/source scope is modeled.
  Use separate context IDs for matched and missing-input observations so canonical
  reuse cannot confuse different supplied evidence.


### 2026-10-28 — Semantic compiler guards and source normalization

- **Scope:** Fixes/guards in the new SemanticCompiler, not changes to frozen v1.
- An 8B proposal for people walking in the background had complete word coverage
  but no binding from the people/event to the location. Require both arguments
  of a location relation; retain this real output as a rejected regression.
- A media depiction was modeled as a world predicate. Enforce explicit source
  content and typed route/act. Content must include its complete dependency
  complement; referenced inner world predicates cannot escape scope. Unused inner
  annotations can be removed only after checking the boundary, with a recorded
  normalization. Actual three-case ablation: 3 compile with removal, 0 without.
- Keep prepositions and semantic role labels in executable arguments, not only
  metadata. This addresses a potential v1 role-key collision; no actual dataset
  collision was claimed. Recover attached markers without changing their role.
- A missing reference context must be unknown even if an empty context inventory
  is marked complete. Include the supplied context ID in temporal evidence keys;
  refuse multiple reference interpretations in one run. Tests cover both cases.
- Numeric names and harmless punctuation/identifier formatting must not be confused
  with quantities or semantic errors. Preserve exact source spelling, log every
  normalization, and still refuse unsupported counts and scope.
- Evidence: tests/test_semantic_compiler.py and its frozen model-error fixtures;
  exp/probabilistic_verification/semantic_compiler_20261028/.


### 2026-10-28: Written content can occupy read-01 ARG3

- **Symptom:** A generic ARG0-source/ARG1-content rule missed both the trained SRL
  and AMR analysis of “Text reads 'Myanmar earthquake death toll reaches 1600'.”
  It could assert inner reach/death events outside the written source.
- **Fix:** The new comparison compiler recognizes the frame-specific written
  source in ARG1 and content in ARG3. Its SRL adapter excludes contained frames
  and emits the original content role. Preserve the content proposition instead
  of asserting its inner events in the world. Duplicate core roles are refused.
- **Prevention:** Regression fixture tests/fixtures/srl_read_scope.json contains
  the actual trained-SRL record. Do not assume PropBank ARG0 always means agent
  or that every source frame uses the same complement slot. Legacy modules unchanged.


### 2026-10-28: Overlapping SRL mentions and AMR nominal parents

- **Observed in the first frozen new-source check:** People and People wearing
  white clothing received different variables, while an attached AMR state could
  compile without the noun it modified (fireworks/distance).
- **Fix:** Use the source noun-phrase head to identify overlapping SRL mentions;
  retain the nominal root and its relation to an attached event/state variable.
  Canonicalize inverse entity relations and repeated atoms.
- **Regression tests:** tests/test_logical_form.py and the actual trained-SRL
  fixture tests/fixtures/srl_relative_participant.json. First frozen results remain
  archived; fresh checks still expose broader scope/context failures. No rewriting.

### 2026-10-29 — Compilation census: source scope, values and references
- **Observed:** The neural parser invented conditional/modal structure, used source words as undeclared IDs, and confused times/counts. The SRL route also treated numeric name suffixes as quantities, retained whole complex noun phrases, and sometimes dropped negative quantifiers.
- **Changes:** Added typed source-matched argument normalization; proper-name/numeric-identifier handling; measurement ranges and temporal values; explicit source contexts; and guards for omitted polarity, unsupported no-NP negation, unlicensed scope and incorrect literal roles. Twenty-nine multi-sentence claims now retain all source tokens rather than empty parses. Missing SRL predicate spans produce an explicit error rather than a TypeError.
- **Quote cleanup:** Unused declarations that refer only to exact quoted words can be removed, including a whole unreachable declaration subgraph. Reachability must start from the actual formula, not from every declared entity's edges; otherwise dead references keep one another alive. Never remove an entity with a source occurrence outside that quote. Regression tests cover both cases.
- **Remaining:** These checks do not certify semantics; the fresh review still finds wrong roles/source scope and incomplete bindings. Some source guards over-refuse legitimate once/would constructions. Noun compounds, comparisons, event phases and source modality remain limited. Keep the v2 compiler opt-in.

### 2026-10-29 — Different claim contexts shared an evidence-cache key

- **Bug:** Local c1/q1 scope labels were reused across claims. Two modal/source contexts with otherwise identical media/candidate/predicate inputs could share the same observation key, merging incompatible scores.
- **Fix:** Namespace scoped observation identities by claim ID. Claim IDs are cache identities, not trainable input features. This conservatively forgoes cross-claim reuse for equivalent scopes. World-scope sharing and within-claim shared facts retain existing behavior.
- **Checks:** A native DeepProbLog two-claim test keeps distinct land probabilities for may/will contexts. All 2,375 census statuses, diagnostics and selections are unchanged. After removing only the scope namespace, all 1,934 prior generated-program hashes and the fresh twenty-case compiled structures match. See scope_namespace_recheck.json.

### 2026-10-29 — SRL frame-graph compilation and post-editing lessons

- An event-valued argument does not need blanket refusal when its SRL frame already exists. Connect frames with dependency clause relations and keep nonprojective content under its parent; do not promote every embedded frame to a world conjunct.
- Preserve split pieces of one source name (IM / - / 1), repeated time conditions, reference roles and complete quotations. A coordinated group is one participant; modifiers remain local to members.
- An empty model edit must preserve the exact original record, including R- roles. Rebuilding all frames through a reduced schema can reject legitimate reference labels or alter untouched data. `patched_record` now copies the original and changes only requested fields; tests cover this.
- Installed XGrammar's HF adapter passed a scalar torch.Tensor to C++ accept_token, which requires int. A local `SchemaLogitsProcessor` converts sampled tokens with .tolist()/int; installed libraries are unchanged. A GPU smoke test runs before checkpoint loading. Parallel checkpoint loading reduced the repeated cached load from about eight minutes to about sixteen seconds in these logs; this is an implementation observation, not a controlled benchmark.
- Remaining semantic defects: nominal source/participial scope, copular identity, opaque locations, idioms and controllers. A token-referenced edit can still add the wrong subject or remove a valid predicate. The AMR condition also produced one invalid argument-index reference, caught after generation. Do not interpret schema validity as semantic fidelity.


### 2026-10-29 — Source descriptions escaped context; copular descriptions used another referent

- **Issue:** Nominal forecast/image content and participial modifiers could become world facts. “Mississippi is a vessel registered…” could let the name and registration choose different vessels. A missing embedded performer could inherit the wrong participant.
- **Fix:** Opt-in semantic SRL argument construction retains source context, propagates evidence routes, unifies a/an predicational descriptions, exposes structured spatial nouns, and completes selected controllers from explicit/declared lexical links. Synthesized subjects use dependency nsubj/nsubj:pass rather than universal ARG0. Default legacy outputs are unchanged.
- **Checks/limits:** New semantic tests, 24 reference compilations and 16 constructed logical checks pass. Existing incorrect SRL roles, bare mass nouns and event-nominal identity remain open. Native nested image/damage inference hits30sec; do not report that as a pass. Reference21 is intentionally stricter than the automatic graph.


### 2026-10-30 — Native state-table joins, partial frame recovery and model-review failures

- **Native inference:** The16-observation image/damage case reaches initialization then exceeds35s in native inference. Equivalent explicit-state clauses in new direct_backend.py finish all three checked cases; image inference~0.135s. Probability sharing/unknown behavior and neural gradients pass separate checks. Old serializer remains unchanged for replay; broader scaling is unmeasured.
- **Compiler:** New event/nominal aliases must remove only the affected quantifiers and rebind the shared variable at its common logical ancestor, preserving unrelated negative existential scopes. Duration constraints must be injected at the event condition, not appended outside negation. Consume only entities replaced by typed literals; do not prune unrelated unused declarations and hide omissions. New tests check bindings, bounds, context and unchanged source records.
- **Frame recovery limits:** Recovered nominal OR groups would become AND under the existing nominal-group translation, so the new recovery declines that construction. Explicit roles alone do not recover adjunct times, appositions or obligation.10 newly accepted cases contain7 partial/1 incorrect outputs.
- **Review/resource:** L40S rack4n02 job1150081 fails CUDA smoke check before weights; V10032GB fallback1150087 completes. Frozen Qwen returns valid JSON but misses visible semantic omissions and confuses one explicit refusal with incorrect. Keep model judgments separate rather than treating structured output as faithful evaluation.


### 2026-11-01 — Media/label scope, conditions and expression shape

- **Fixes:** Keep a nominal footage description under depiction; retain viewpoint text. Protect exact label spans before predicate recovery, remove only unreachable declarations solely within protected text, and distinguish printed labels from name attribution. Reattach a following label modifier only under a recorded reading requiring review. Preserve enough-NP separately from its sufficiency goal, nominal OR alternatives, shared dates and nominal clocks. Unsupported interpretations produce named compilation refusals.
- **Regression avoided:** A parse can tag “Shows image of…” with a nominal root. A preceding retained source predicate must prevent treating the whole construction as a bare media description. Never copy an opening date over a second explicit date. A label’s OR is text rather than a disjunction; a quoted name is not automatically OCR evidence.
- **Native cost:** The new sufficiency graph has19 observations. Previous direct-state encoding completes simple states but stalls on unknown-query circuit compilation. Flattening associative AND/OR, deduplicating identical nodes, ordering by observation ID and balancing reduces native stages to~0.14s. NOT and evidence-combination boundaries stay intact; mixed probabilities and neural gradients pass. The changes are combined, not a separately established causal claim about balancing alone.
- **Human-data integrity:** Blank forms and automated browser-test values are not human gold. Browser testing used synthetic /tmp export only; project received-count status stays0. New packet IDs include both reserved-membership and compiler-freeze hashes, so restored answers cannot silently attach to another frozen revision. Actual returned data is validated before import.


### 2026-11-05 — Restrict newly recovered names and relative-clause actors

- **Observed:** The first reviewed_srl candidate could make a tool the actor of winning, Guangdong the reporter's name, and Trump the name of tariff rates. These errors were found in the changed-case audit, outside the reserved fresh review.
- **Cause:** Recovery crossed infinitival purpose boundaries or accepted distant proper nouns as appositions.
- **Fix:** Recover a controller only from an explicit participial relative; require adjacent apposition through punctuation, with list/colon and following-relative-subject guards. Preserve first outputs/source and disclose post-freeze restrictions.
- **Validation:** Counterexamples `TFgw4IaR9R8s_1677`, `Txf2EdqOg1SQ_2343`, `TFgw4IaR9R8s_1662` added;207 selected checks pass. All20 fresh programs unchanged. Full census shows29 changed programs, rather than35 in the first candidate. These guards are narrow; they do not establish a complete grammar.


### 2026-11-05 — Embedded nominal content projected as an assertion; silent content loss

- **Symptoms:** Preparation goal landing appears outside video/preparation; investigated violation becomes a person-relative assertion; dialogue WH content becomes world be. Creaks taggedNOUN causes the entire small-dolly sound clause to vanish; identifiers and partial proper names silently lose material.
- **Fix:** `scope_coverage` relocates existing event bodies using declared lexical/prepositional paths and existing context kinds; recovers a tightly constrained finite root; expands connected name spans and adds missing identifier properties. A strict reachable-value audit flags remaining omissions instead of silently accepting them. Default previous compilation stays byte-for-byte equivalent at record level.
- **Development regression prevented:** Name expansion must include the full earlier span. Taking only a proper-noun component shortened Blue Ghost Mission1 and LBHP Boat1; counterexamples were added before freeze. Existing quantity operators must account for at-least/approximate language to avoid straightforward false alerts.
- **Evidence/limits:**228 checks pass;11 programs change;260 candidates flagged. The check misses structural errors if words remain in a string or wrong role. Local coreference remains unresolved. No broad semantic-correctness claim.


### 2026-11-05 — Lost qualifiers/values, hidden clauses and source-label boundaries

- **Symptoms:** City/state appositions and coordinated participants dropped; ranges lose endpoints/locations; printed numeric rows lose values; banner reading lacks a frame; lands is a noun inside a time string; personal name and predicative label merge.
- **Fix:** Source-position/dependency normalization, declared measurement/source patterns, explicit label boundaries and structural review alerts in content_recovery. Original sentences are unchanged. Ambiguous source/column meanings are not invented. Clock/body-part/sign/parenthesis and earlier unsafe-name counterexamples guard changes.
- **Audit follow-up:** Next already present in obl:next_to was falsely flagged. Credit only actual source-anchored grammatical relation words on that event. Two old development statuses change, no program/fresh hashes; first freeze retained. This corrects an audit false positive, not a parsing gain.
- **Evidence/limits:**259 checks;1,866 pass;80 changed programs; full replay. Some matrix-scope/group-outcome and reciprocal cases remain wrong/partial despite lexical coverage. Reference resolution, cost and rewriting deferred.


### 2026-11-05 — Postposed numbers, bounded appositions and hidden list/clause content

- **Issue:** Labels lose numbers, scaled values lose multipliers, appositions after full names/inside parentheses disappear, and colon lists retain words without member bindings. A how clause can be projected outside its description.
- **Fix:** content_relations.py preserves declared labels/joined names, complete quantities/ranges, bounded nominal appositions, explicit list members and selected how/where structures. A broad numeric-identifier development rule was restricted after date/tally counterexamples. Six harder clause cases stay refused.
- **Prevention:**290 regression tests cover dates/tallies, wrong numeric attachment, ordinary counts/AND, local list parties/shared titles, scope, immutable inputs and native count bounds. All earlier user-faithful programs remain unchanged. Saved development and post-freeze review limits prevent treating local retention as whole-claim correctness.


### 2026-11-11 — Ambiguous pass metrics and missed clause bindings

- **Issue:** The old2099 schema/syntax count was compared with a stricter1924 word/structure count. Word retention also misses finite clauses tagged as nouns, e.g., while robot runs stored as time text. Some relation words and redundant markers cause overstrict lexical alerts.
- **Resolution:** Report generation and active content-check definitions separately, retain current statuses and expose all179 review diagnoses. This is a reporting/audit correction; compiler behavior is unchanged.
- **Open defects:** Source quote protection, time/unit alignment, no-NP quantified scope and accepted missing bindings require controlled treatment. A rewrite alone is not evidence of a correct logical form. Source audit and proposal are in compiler_alert_review_20261111.


###2026-11-11 —Rewrite explanations can claim nonexistent or unsafe repairs

- **Observed:** Seven initial and four revised responses label unchanged text as rewrite. Diagnostic-conditioned Qwen invents a signer for a signed document, mission/controller context and previous-year comparison, and changes exact names/quotes. A successful JSON/schema check does not establish a faithful edit.
- **Containment implemented:** Explicit unchanged-action, numeric/name/quote/modal checks; manual fidelity review at original→rewrite and original→predicates; SHA256 binds each judgment to the exact texts/compiler output. Only three revised-prompt outputs replace original failures. Both pilot gates fail, automatic expansion disabled.13 tests include a role-swap counterexample to surface checks.
- **Open compiler semantics:** Rate ranges can become count bounds on km/h; meters-per-second can split into meters and a second entity; no audio→does not have any audio still introduces audio existence outside event negation. Do not relax a surface check and call these fixed. Revised court compound retains words but does not expose the targeted cardinality group. No underlying compiler change in this pilot.
- **Evidence:** claim_rewrite_20261111/{pilot_compilation.jsonl,semantic_review.json,prompt_comparison.json}; docs/claim_rewrite_pilot_20261111.md. Proposed next work is bounded semantic contracts or a separate stronger-rewriter comparison, not more unchecked grammar rules.


###2026-11-12 —Generation entry point did not enforce failure-only routing

- **Issue:** The earlier full-corpus replacement code skipped successful originals, but the standalone generation runner queried every supplied pilot row, including passing diagnostic probes. Their hypothetical regressions could be confused with runtime fallback regressions.
- **Fix:** Direct-compile/filter before model import or loading; every compiled result is retained and skipped. Strict unsupported candidates remain eligible. Unknown statuses/mismatched IDs raise errors. An all-passing input exits without any model call even without plan-only. Historical artifacts remain unchanged and are labeled outside the fallback path.
- **Evidence:**17 tests;31/9 routing on40 inputs;0/8 requests/skips on passing controls; isolated replay verifies vLLM not imported. Report displays all80 exact historical requests and classifies rewrite changes versus compiler errors. No model/grammar change or new quality result.


### 2026-11-12 — Negation holder scope and media-source matching
- Issue: a no-NP holder with embedded propositions could negate the whole claim; clip sources were missed while livestream objects were confused with depiction sources.
- Fix: refuse embedded-proposition holders in the bounded absence transform; use the shared media lexicon plus syntactic source use, including show/depict subjects. Preserve original/excluded attempts and first evaluation; replay all449 fixed inputs after the fixes.
- Validation: explicit scope/source regressions;360 tests pass; historical2375defaultoutputs identical. Do not generalize NOT EXISTS to unsupported quantifier/negation structures or treat every media noun as a source.


###2026-11-12 — Repeated typed times and elapsed/clock confusion
- Issue: SRL conversion flattened repeated temporal arguments into property strings after normalization, losing type/source credit; barevideo times were incorrectly validatedasclocks. Initialaudit also demanded copiedquote events or normalization foralreadytypedrawtimes.
- Fix: optin repeateddate/time/duration adjuncts retain structuredvalues; distinguish explicitelapsed/clock and unspecifiedscale; preserve timezone labels withoutoffset guesses; recognize copiedverbatimspans andsourceanchors; require actual linkedconditions ratherthan successfulnormalization alone.
- Validation:385tests incl25new/nativebindings;2375defaultoutputs exact. Initial/second/third outputs+sources preserved, allfinalconditionsrerun. Remainingnominalevent/timecoreferenceproblemsnotrepaired.

## 2026-11-12 — Duplicate auxiliary frames and invalid smoke-fixture sharing

SRL sometimes emits both are and covered; the old converter treats the auxiliary complement as a competing unresolved clause. Opt-in repair removes auxiliary frames only when the lexical parent frame exists, retaining actualcopulas/tense. Paired regression cases cover both.

The frozen-feature smoke fixture initially reused variable-like IDs as actual candidates and assigned whole-clause features to noncolorproperties. This caused unintended observation sharing across entities/clauses. Fixed distinct actual aircraft/bus IDs, shared matching stateIDs, color-only neuralobservations, and collisionguard; exactly4distinctneuralfeatures required. Earlyoutputs excluded/preserved. Historical observation sharing semantics unchanged.

Interval lexical comparison mixed full calendar dates and bare clocks. Shared normalizer now resolves same-day omitted enddate, compares bareclocks numerically and preserves range timezone; ambiguous overnight refused. Nominal WordNet sense errors (riding/shot) make that option remain disabled.
