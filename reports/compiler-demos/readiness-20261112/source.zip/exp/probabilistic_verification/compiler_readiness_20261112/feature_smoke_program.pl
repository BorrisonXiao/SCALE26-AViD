% Explicit state heads; categorical observations remain shared.
nn(relation_net,[tensor(features(O))],Z,[supported,refuted,unknown]) :: learned_status(O,Z).
1::status(o_0570faf7c67543e05ee0,supported); 0::status(o_0570faf7c67543e05ee0,refuted); 0::status(o_0570faf7c67543e05ee0,unknown).
1::status(o_0d948514650482fdca5f,supported); 0::status(o_0d948514650482fdca5f,refuted); 0::status(o_0d948514650482fdca5f,unknown).
status(o_284aca57b07c517c97e5,Z) :- learned_status(o_284aca57b07c517c97e5,Z).
1::status(o_36c10454b7f4384b5687,supported); 0::status(o_36c10454b7f4384b5687,refuted); 0::status(o_36c10454b7f4384b5687,unknown).
1::status(o_50b29eb379eaf813e9bb,supported); 0::status(o_50b29eb379eaf813e9bb,refuted); 0::status(o_50b29eb379eaf813e9bb,unknown).
1::status(o_541cfef58691d490da22,supported); 0::status(o_541cfef58691d490da22,refuted); 0::status(o_541cfef58691d490da22,unknown).
status(o_671177db2d43a0561ca1,Z) :- learned_status(o_671177db2d43a0561ca1,Z).
status(o_7d6c38ba714319ca73d8,Z) :- learned_status(o_7d6c38ba714319ca73d8,Z).
status(o_e6b5e68d9ae8ab7b8146,Z) :- learned_status(o_e6b5e68d9ae8ab7b8146,Z).
node(n1,supported) :- status(o_50b29eb379eaf813e9bb,supported).
node(n1,refuted) :- status(o_50b29eb379eaf813e9bb,refuted).
node(n1,unknown) :- status(o_50b29eb379eaf813e9bb,unknown).
node(n3,supported) :- status(o_e6b5e68d9ae8ab7b8146,supported).
node(n3,refuted) :- status(o_e6b5e68d9ae8ab7b8146,refuted).
node(n3,unknown) :- status(o_e6b5e68d9ae8ab7b8146,unknown).
node(n4,supported) :- status(o_36c10454b7f4384b5687,supported).
node(n4,refuted) :- status(o_36c10454b7f4384b5687,refuted).
node(n4,unknown) :- status(o_36c10454b7f4384b5687,unknown).
node(n2,refuted) :- node(n3,refuted).
node(n2,refuted) :- node(n4,refuted).
node(n2,supported) :- node(n3,supported), node(n4,supported).
node(n2,unknown) :- node(n3,unknown), node(n4,supported).
node(n2,unknown) :- node(n3,supported), node(n4,unknown).
node(n2,unknown) :- node(n3,unknown), node(n4,unknown).
node(n0,refuted) :- node(n1,refuted).
node(n0,refuted) :- node(n2,refuted).
node(n0,supported) :- node(n1,supported), node(n2,supported).
node(n0,unknown) :- node(n1,unknown), node(n2,supported).
node(n0,unknown) :- node(n1,supported), node(n2,unknown).
node(n0,unknown) :- node(n1,unknown), node(n2,unknown).
verdict(c_db82d5eb95a22ee4,supported) :- node(n0,supported).
query(verdict(c_db82d5eb95a22ee4,supported)).
verdict(c_db82d5eb95a22ee4,refuted) :- node(n0,refuted).
query(verdict(c_db82d5eb95a22ee4,refuted)).
verdict(c_db82d5eb95a22ee4,unknown) :- node(n0,unknown).
query(verdict(c_db82d5eb95a22ee4,unknown)).
node(n7,supported) :- status(o_284aca57b07c517c97e5,supported).
node(n7,refuted) :- status(o_284aca57b07c517c97e5,refuted).
node(n7,unknown) :- status(o_284aca57b07c517c97e5,unknown).
node(n6,refuted) :- node(n7,refuted).
node(n6,refuted) :- node(n4,refuted).
node(n6,supported) :- node(n7,supported), node(n4,supported).
node(n6,unknown) :- node(n7,unknown), node(n4,supported).
node(n6,unknown) :- node(n7,supported), node(n4,unknown).
node(n6,unknown) :- node(n7,unknown), node(n4,unknown).
node(n5,refuted) :- node(n1,refuted).
node(n5,refuted) :- node(n6,refuted).
node(n5,supported) :- node(n1,supported), node(n6,supported).
node(n5,unknown) :- node(n1,unknown), node(n6,supported).
node(n5,unknown) :- node(n1,supported), node(n6,unknown).
node(n5,unknown) :- node(n1,unknown), node(n6,unknown).
verdict(c_a875174d5a1de593,supported) :- node(n5,supported).
query(verdict(c_a875174d5a1de593,supported)).
verdict(c_a875174d5a1de593,refuted) :- node(n5,refuted).
query(verdict(c_a875174d5a1de593,refuted)).
verdict(c_a875174d5a1de593,unknown) :- node(n5,unknown).
query(verdict(c_a875174d5a1de593,unknown)).
node(n9,supported) :- status(o_0570faf7c67543e05ee0,supported).
node(n9,refuted) :- status(o_0570faf7c67543e05ee0,refuted).
node(n9,unknown) :- status(o_0570faf7c67543e05ee0,unknown).
node(n10,supported) :- status(o_541cfef58691d490da22,supported).
node(n10,refuted) :- status(o_541cfef58691d490da22,refuted).
node(n10,unknown) :- status(o_541cfef58691d490da22,unknown).
node(n12,supported) :- status(o_671177db2d43a0561ca1,supported).
node(n12,refuted) :- status(o_671177db2d43a0561ca1,refuted).
node(n12,unknown) :- status(o_671177db2d43a0561ca1,unknown).
node(n13,supported) :- status(o_0d948514650482fdca5f,supported).
node(n13,refuted) :- status(o_0d948514650482fdca5f,refuted).
node(n13,unknown) :- status(o_0d948514650482fdca5f,unknown).
node(n11,refuted) :- node(n12,refuted).
node(n11,refuted) :- node(n13,refuted).
node(n11,supported) :- node(n12,supported), node(n13,supported).
node(n11,unknown) :- node(n12,unknown), node(n13,supported).
node(n11,unknown) :- node(n12,supported), node(n13,unknown).
node(n11,unknown) :- node(n12,unknown), node(n13,unknown).
node(n8_fold0,refuted) :- node(n9,refuted).
node(n8_fold0,refuted) :- node(n10,refuted).
node(n8_fold0,supported) :- node(n9,supported), node(n10,supported).
node(n8_fold0,unknown) :- node(n9,unknown), node(n10,supported).
node(n8_fold0,unknown) :- node(n9,supported), node(n10,unknown).
node(n8_fold0,unknown) :- node(n9,unknown), node(n10,unknown).
node(n8,refuted) :- node(n8_fold0,refuted).
node(n8,refuted) :- node(n11,refuted).
node(n8,supported) :- node(n8_fold0,supported), node(n11,supported).
node(n8,unknown) :- node(n8_fold0,unknown), node(n11,supported).
node(n8,unknown) :- node(n8_fold0,supported), node(n11,unknown).
node(n8,unknown) :- node(n8_fold0,unknown), node(n11,unknown).
verdict(c_396df75cfdc61355,supported) :- node(n8,supported).
query(verdict(c_396df75cfdc61355,supported)).
verdict(c_396df75cfdc61355,refuted) :- node(n8,refuted).
query(verdict(c_396df75cfdc61355,refuted)).
verdict(c_396df75cfdc61355,unknown) :- node(n8,unknown).
query(verdict(c_396df75cfdc61355,unknown)).
node(n16,supported) :- status(o_7d6c38ba714319ca73d8,supported).
node(n16,refuted) :- status(o_7d6c38ba714319ca73d8,refuted).
node(n16,unknown) :- status(o_7d6c38ba714319ca73d8,unknown).
node(n15,refuted) :- node(n16,refuted).
node(n15,refuted) :- node(n13,refuted).
node(n15,supported) :- node(n16,supported), node(n13,supported).
node(n15,unknown) :- node(n16,unknown), node(n13,supported).
node(n15,unknown) :- node(n16,supported), node(n13,unknown).
node(n15,unknown) :- node(n16,unknown), node(n13,unknown).
node(n14_fold0,refuted) :- node(n9,refuted).
node(n14_fold0,refuted) :- node(n10,refuted).
node(n14_fold0,supported) :- node(n9,supported), node(n10,supported).
node(n14_fold0,unknown) :- node(n9,unknown), node(n10,supported).
node(n14_fold0,unknown) :- node(n9,supported), node(n10,unknown).
node(n14_fold0,unknown) :- node(n9,unknown), node(n10,unknown).
node(n14,refuted) :- node(n14_fold0,refuted).
node(n14,refuted) :- node(n15,refuted).
node(n14,supported) :- node(n14_fold0,supported), node(n15,supported).
node(n14,unknown) :- node(n14_fold0,unknown), node(n15,supported).
node(n14,unknown) :- node(n14_fold0,supported), node(n15,unknown).
node(n14,unknown) :- node(n14_fold0,unknown), node(n15,unknown).
verdict(c_8d718caeff2802cc,supported) :- node(n14,supported).
query(verdict(c_8d718caeff2802cc,supported)).
verdict(c_8d718caeff2802cc,refuted) :- node(n14,refuted).
query(verdict(c_8d718caeff2802cc,refuted)).
verdict(c_8d718caeff2802cc,unknown) :- node(n14,unknown).
query(verdict(c_8d718caeff2802cc,unknown)).
