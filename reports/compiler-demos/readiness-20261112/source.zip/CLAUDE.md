# AViD — Claude Code Project Instructions

## Latest compiler stopping-point experiment — 12 November 2026

Read docs/compiler_readiness_20261112.md and exp/probabilistic_verification/compiler_readiness_20261112/summary.json. ADR-023 and failure-only rewriting remain unchanged. Proposed stopping point: freeze broad compiler optimization and begin a small, audited relation-learning experiment. Universal parsing and empirical training readiness are not established.

Completed: all 2,375 originals rerun. Direct automatic passes improve from 1,953 to 1,978 (83.28%); auxiliary filtering alone gives 1,960. Replaying the entire cached 449-case cohort gives 108 complete programs versus 87 (58 direct, 50 composed). All 25 changed complete programs were inspected: 12 retained, including two replacements of already accepted splits. Ten additions result; 83 exact program/form judgments are reused. The retained combined pool is 1,963/2,375 (82.65%), with 412 excluded. Most old passes were not re-reviewed. These are development judgments, not semantic accuracy, media labels or training eligibility.

General repairs filter duplicate auxiliary frames only with an existing lexical-head frame, retain attached adverbs as explicit conditions, and resolve a unique parent interval on an existing event. Scope-sensitive adverbs are excluded from the repair; missing events still cause refusal, including the whole focal terrain claim. Same-day omitted end dates are supported; midnight rollover is refused. Nominal event variables/event_type work on authored collapse checks, but WordNet typing confuses electoral riding and camera shot. Therefore nominals=False by default, excluded from the corpus gains; this is not a trained nominal SRL parser.

First stopping stages among 412 exclusions: component compilation 179, alignment 148 (including 126 noun-head failures), meaning review 68, composition 13, model refusal 1, uncached legacy cases 3. A concise new prompt is proposed but untested. H100 job1227635 and A100 job1227636 were cancelled while pending; the latter was estimated to start the next day. No new model or media requests ran. All 419 earlier responses were replayed with one fixed condition, without per-claim prompt selection.

Native DeepProbLog training was checked on four assistant-inspected color clauses from one development clip, using actual 4,096-dimensional frozen visual features and a 270,595-parameter MLP with 64 hidden units. Thirty CPU epochs use claim labels only; features and old eligibility flags remain unchanged. This is an engineering check that fits four examples, not held-out evidence. Referents, non-color conditions and time are stipulated; no audio or evidence-alignment learning. Initial fixture-sharing errors are preserved in development/ and excluded. All 411 tests pass; the 2,375 historical default outputs remain JSON-identical.

Keep work in the existing compiler-demos Overview, Examples, All claims, Daily log and History. The All claims viewer now shows the updated pool; historical archives/viewer JSONs remain unchanged. Proposed next: audit source-disjoint claims and evidence labels; create checked binding edits and cache features; then compare small classifiers against frozen-model and simple aggregation baselines on held-out videos. Do not wait for 100% parsing. Reopen compiler work for demonstrated experiment blockers, and continue to list concrete next steps and goals in completion reports.

## Latest shared-component experiment — 12 November 2026

User authorized a bounded test of general temporal/quantity normalization, phrase relations, source alignments and checks, then cached replay. Read docs/semantic_components_20261112.md and exp/probabilistic_verification/semantic_components_20261112/summary.json. No new model requests/media inference/empirical training. ADR-023 and direct-failure-only rewriting remain unchanged.

Completed:36 author-written construction probes (2motivating/34variants, not independent heldout) improve targeted checks10/36→34/36. Fixed1437cachedclauses1140→1147pass;87completeprograms on449(previous84). Nine changed/newprograms inspected;78exactprogram/form judgments reused. Thirtycohortoutputs approved(previous27),57notapproved. Three newdate/time recoveries are balanced by three newly reviewed legacy exclusions with opaque temporal/event content: TgR_u37mCoQ4_1831,_1908,_1924. Revised combined pool remains1953/2375=82.23%,422remaining. Do not claim1956 or that allprevious1926acceptedrows remain valid/unchanged.

Automatic DIRECT counts on2375originals also1953before/after, but membership/acceptance differs from reviewedcombinedpool;3newpasses/3newrefusals,123changedprograms. Neither is semanticaccuracy. Shared normalization is opt-in;385tests pass incl25new/2controllednativebindingchecks; default2375outputs exact. Three core files have compatible extensions, including phrase-marker deduplication. Baretimecodes retain unspecifiedscale; explicitT+ elapsed; timezone labels preserved without guessedoffsets. Repeatedtypedtimes keep their types. Bounded motion-reference/spatialphrase inventory, not generalprepositionunderstanding. Focalterrainclaim date/relative repairedlocally, wholeclaimstillfails Duringthis time/shift event reference. Nominalcollapse and ambiguous inrelationto remainprobelimitations.

Current report staysexistingOverview/Examples/fiveviews/twoReportscards. Old449model inspector/sourcebundles remain historical. Proposed next: event/interval coreference, bounded nominal-event analysis, then freeze components and evaluate newclaims before further expansion/training. Detailed provenance/development corrections in newRUN; do not rerun old packagers or overwrite historical proofs.


## Earlier full failure-cohort result — 12 November 2026

The user authorized the bounded role/identifier and measurement/absence repairs, plus rewrite+compilation on ALL449 previous rejects. This supersedes earlier restrictions against expanding the31-case experiment. Read docs/rewrite_all_20261112.md and exp/probabilistic_verification/rewrite_all_20261112/summary.json. ADR-023 and failure-only generation remain unchanged; no new empirical relation training or media inference is authorized by this compilation experiment.

Completed:30 direct automatic passes bypass the model;419 final frozen Qwen requests produce1,437 clauses.207 cases stop at component compilation,142 at alignment,14 at composition,2 at model refusal;54 composed programs plus30 direct programs receive hash-bound compiler-author meaning review.27 additions approved (14direct/13rewrite),57 not approved. Previous1,926 passes retained exactly:1,953/2,375=82.23%;422 remain. This is development compilation coverage with27 newly reviewed additions, NOT semantic accuracy; prior1,926 were not all re-reviewed. Automatic checks alone would retain2,010=84.63%, including unfaithful programs.

Current code adds opt-in repeated adjuncts, measurements/ranges/scalar magnitude, bounded NOT EXISTS absence, explicit participant IDs and source-use alignment. Five original core files have backward-compatible extensions; the historical default exactly reproduces all2,375 saved outputs. The old38-file snapshot is preserved in baseline_source; do not claim current files remain frozen.360 tests pass. Actual native absence checks use constructed inventories, not media. Final H100 job1226791 completed419 requests; initial1226788 completed418 and is entirely excluded. Resources released. One fixed final prompt; no per-claim attempt/prompt selection.

Keep current results and all449 examples in compiler-demos.html Overview/Examples (five views; two Reports cards). Earlier inspectors/URLs/25 archives/26 original viewer files remain. Proposed next: preserve OR/while/modality/source scope in composition; improve class-description/original-span/group reference resolution; replay cached419 responses and review any new programs before another model run or relation training. Keep completion next steps and goals explicit.


## Report organization and communication — confirmed12 November2026

Keep current compiler/rewrite work in the existing compiler-demos.html; do not create a new report page for every iteration. Reports/index.html has two main entries, with old reports under the compiler report History. Main report views: Overview, Examples, All claims, Daily log, History. Preserve old URLs, source bundles and case inspectors. The user also requested fewer interim progress updates: keep them brief and meaningful, and avoid repeating full experiment reports. Required tool/progress communication still applies.

Before the full-cohort experiment, the449 failures included29 tested unrecovered and420 never rewritten. Do not claim the rewrite failed on all19% or infer corpus recovery from the deliberately selected31-case pilot. First checks group227 parser/compiler predicate formation,173 omitted content,43 unsupported operators/types,6 explicit alignment/controller/media checks; these are not a full semantic taxonomy. No new model/compiler experiment in this consolidation. See docs/compiler_report_consolidation_20261112.md.


## Earlier alignment and full-corpus result —12 November2026

Read docs/split_alignment_20261112.md. The user authorized sentences-only generation plus separate original-mention alignment and a fixed evaluation/full-corpus rate. This completed experiment does not authorize unrestricted automatic fallback or new learning. One frozen Qwen prompt on the same31 direct failures returns only action/sentences; a separate module aligns unique original noun/event mentions and refuses ambiguous/unsupported cases. The38 direct-compiler files stay frozen.

Fresh2375 originals exactly reproduce1924 content-check passes (81.01%) and2103 candidates (88.55%). Two reviewed automatic outputs (Trump/image and police officers) in the fixed sentences-only condition yield1926/2375 passes (81.09%),2105 candidates (88.63%),449 failures. These are development compilation counts, not whole-corpus semantic accuracy. No manual clauses counted. The earlier1927 is a separate single-sentence diagnostic, not a cumulative production count.

Old sentences+new alignment recover2 (officers/robot); new sentences-only+alignment recover2 (Trump/officers), with different membership. Do not union best outputs across prompts. The new prompt still invents narration/construction and expands quotes; quantity/source/reference limitations remain. All62 comparisons are assistant reviewed, not independent gold.42 focused tests; source/browser/publication evidence logged separately. Next proposals: bounded participant-ID/source-frame handling, then typed measurement/absence contracts and another full census before expanded evaluation or DeepProbLog training.


## Sentence splitting fallback — user clarification12 November2026

The intended rewrite is split-and-rephrase: break a difficult claim into simpler subclaims while retaining meaning, shared entities/events and depiction/speech/OCR or other context links. The earlier one-sentence restriction was too narrow and is historical. Keep direct compilation first and never rewrite a passing original. No automatic scale-up is enabled.

Read docs/claim_split_20261112.md and the report Sentence splitting tab. One frozen Qwen prompt on31 previously inspected failures produces65/77 passing clauses and20 all-component passes, but0 approved complete automatic results. Seven selected assistant-written splits give18/18 component passes and4 faithful linked compositions; an eighth no-audio guard is refused. These are compiler-author diagnostics, not model gains, independent gold or corpus accuracy. Frozen38 direct-compiler files stay unchanged. New adapter preserves context and shared mentions; original corpus counts stay2103/1924. No new media/native inference/training. Proposed next: simplify generation/reference alignment, then repeat a fixed fidelity evaluation before scale-up.


## Current Paper Direction — accepted 2026-10-14

ADR-023 in docs/project_notes/decisions.md governs the paper: probabilistic parsing
for multimodal claim verification. Compile claims into probabilistic logic; keep
visual/audio models frozen; learn small relation classifiers; infer alternative
evidence assignments. Predefined and learned functions share an interface, and an
existing DeepProbLog-like inference/learning backend is valid. This is the user's
chosen direction, likely finalized; older CRF and temporal-only notes are historical.

The current design is site/proposals/probabilistic-verification.html, generated by
scripts/build_probabilistic_verification_proposal.py. Start with a linear classifier
and a small MLP; frozen BERT-style features are optional. Decoder-only models remain
frozen perception/parsing modules or baselines. No multimodal LLM fine-tuning is planned.

**Rewrite routing and inspection — confirmed2026-11-12:** The user requires rewriting only after strict direct compilation fails. Generation now filters before model loading; every compiled original is skipped unchanged, including imperfect passes flagged only by a separate semantic review. CPU check on40 historical inputs selects31 failures/skips9 passes; an all-passing8-case input returns without importing vLLM or requesting a model. Historical passing controls/one passing ambiguous guard are diagnostic probes outside this path; do not count their edits as operational fallback regressions. The underlying38 compiler files, experimental outputs/judgments and21 prior archives are unchanged.17 rewrite/routing tests pass. No new model/GPU/media/training run. The Rewrite pilot tab now defaults to failed originals and exposes five failure examples plus both exact saved prompts, model settings, responses and failure stages, unfolded. See docs/rewrite_inspection_20261112.md and rewrite_inspection_20261112 evidence.

**Current completed work — 2026-11-11:** The user authorized the checked rewrite pilot. Read `docs/claim_rewrite_pilot_20261111.md` and `claim_rewrite_20261111/WORK_STATUS.md`. Two fixed Qwen text-only prompts on the same40 development cases give1/24 and2/24 reviewed faithful target recoveries; the revised prompt also recovers one exact-quote guard. Ten revised targets pass automatic checks, but only two meet the structural fidelity requirement. Two proposed controls regress. Both predeclared gates fail; do not enable automatic corpus-wide rewriting or new relation training. Keep both prompts and broad grammar rules frozen. No per-claim prompt selection. The earlier rewrite prohibition is superseded for this authorized completed pilot, not for unreviewed scale-up.

The38 compiler source files remain unchanged. Both fresh full2375-record reruns complete: originals exactly reproduce2103 generated/1924 content-check passes; three reviewed revised-prompt replacements yield2105/1927,448 strict refusals. The1927 count is not certified semantic accuracy or a clean training-set size. All80 triples were reviewed by the compiler-author assistant, not independent human gold. Seven other original-video groups were reserved from prompt tuning; no held-out gain claim.13 new rewrite tests pass. No new media inference, relation training or native DeepProbLog inference experiment. Jobs1225132/1225198 completed on one80GB A100 in sequence and released resources. Source archives and original viewer data remain unchanged.

Next proposals/goals: review the three retained triples/rejections with the user; make a bounded decision about quantity/negation contracts or a separately evaluated stronger rewriter; repeat fidelity checks before new DeepProbLog learning. Current report Rewrite pilot / Daily log and checklist distinguish this completed negative-result pilot from the preceding audit proposal.

**Current audit and next-stage recommendation — 2026-11-11:** Read
`docs/compiler_alert_review_20261111.md` and the report Alert review / Results and
limits tabs. The compiler itself remains frozen at `content_relations_20261105`.
Current metrics are **2,103 programs generated; 1,924 pass current content checks**.
All original 2,099 candidates still generate. Generation means schema/syntax
success, not semantic accuracy or full native inference completion. Historical
content-check definitions changed; always display their active checks separately.

`compiler_alert_review_20261111` reviews all 179 candidate alerts: 166 apparent gaps,
5 likely overstrict word checks, 8 uncertain. These are assistant diagnostic
judgments, not human gold or whole-claim correctness. Five overstrict word alerts
are not automatic accepts; other errors can remain. 34 stratified no-program cases
and 23 one-per-original-video passing controls are separate diagnostics (passing:
18 faithful/4 partial/1 context-dependent). A 22-case targeted literal search finds
5 binding/source gaps, 2 review cases, 15 ordinary time/adjectival references. All
texts were processed earlier; no unseen-test or corpus-accuracy claim.

Recommendation: freeze broad grammar expansion now and make a 40-case checked text
rewrite pilot the next implementation. Keep core source/quote/type bug fixes
separate. 451 strict refusals are 19.0% of the corpus, not proven harmless outliers.
No diminishing-return curve was measured (the last repair batch added 58 checks).
The rewrite layer is **proposed and unimplemented**; the latest user requested
this readiness assessment, not a rewrite implementation in this audit. ADR-023
and the earlier prohibition on implementing rewriting yet remain in effect until
the user authorizes the next implementation phase.

Proposed pilot: 24 failed targets + 8 unchanged controls + 8 guard cases, one frozen
text model on claim/parses, no labels or media observations. Preserve false claims
rather than correcting their facts. Review original/rewrite/predicate triples;
check shared participants, quantities with their owners, dates, tense/aspect,
polarity, modality, exact quotes and source scope. Do not mask unsupported
quantified absence or ambiguous readings with a positive paraphrase. Proposed
development gates:12/24 faithful recoveries, no unchanged-control regressions,
zero accepted critical changes. These are planning gates, not results. Freeze
preparation before new relation learning / DeepProbLog experiments; automatic
passes are not clean training labels.

Update `docs/project_notes/daily_log.json`, then regenerate `compiler-demos.html`
and its Daily log for completed work. The new Alert
review tab preserves the 41 previous demos and all 2,375 viewer outputs. Original
compiler ZIPs remain unchanged; a small dated source overlay reproduces the audit
and updated report. No new compiler/model/GPU/media/training/inference run occurred.

**Current compiler status — numbers, appositions, lists and clauses, 2026-11-05:**
The latest completed compiler round is `content_relations_20261105`. Read
`docs/content_relations_compilation.md` and `site/reports/compiler-demos.html`.
ADR-023 is unchanged. Reference resolution, larger-program profiling and LLM
rewriting remain deferred; no new model/media request or relation training.

`compile_content_relations` uses one deterministic SRL/dependency path and unchanged
sentences. It retains declared numeric labels/joined names, scaled counts/amounts,
explicit ranges, bounded nominal appositions, colon-list members and selected
how/where clauses. A broader identifier rule was restricted after development
exposed dates/tallies. The optional earlier-compiler callback preserves every
preceding complete record by default. The old source ZIP is preserved at
`site/reports/compiler-demos/history/content-recovery-20261105-source.zip`.

All 2,375 inputs rerun: **1,924 pass checks**, versus 1,866; **2,103 executable
candidates** unchanged. 58 newly pass, no earlier pass lost; 67 program hashes change.
All 11 previously user-faithful programs are unchanged and pass. 173 lexical alerts,
6 hidden-clause alerts and 272 parser/compiler refusals remain. 291 tests pass,
including native count-bound and previous probability/gradient/OCR checks. These
are compilation counts, not semantic accuracy or evidence of a media capability.

A seeded post-freeze 12-case sample of newly passing claims retains all 12 local
repair targets, while other defects remain: nominal transition, opaque back-up
phrase, nominal suspicion semantics and unresolved references. This is a diagnostic
compiler-author review of previously processed texts, not independent human gold or
held-out semantic gain. The first 38-file freeze precedes that review. A later code audit adds an AND/OR
guard and one test, with no corpus output change; the final 291-test freeze follows
the review. Preserve pre_guard_frozen and guard_followup.json. The full first exploratory
output is preserved separately. Prior 20-case sample judgments remain historical.

**Standing report instruction — 2026-11-05:** Keep compiler changes and results on
`compiler-demos.html`. Its current tabs are Latest changes, Simple demos, Full saved
outputs, Results and limits, Alert review, Rewrite pilot, and Daily log. The 41 demos include 28 earlier cases.
Update the Daily log after future completed work: recent dates first, a concise
factual sentence per item, links opening the relevant tab/step/example, and proposed
work kept separate. Earlier daily entries are selected reconstructed milestones,
not a complete history. Keep original claims and historical baseline labels exact.

Next proposed work: obtain user review of recovered conditions; inspect remaining
measurements and mixed nominal/clausal objects to select another bounded repair set.
Keep ambiguous cases refused. Do not start rewriting/references/native profiling
from these compiler results alone.

The actual user review remains20/20 imported and agent-assisted; original bytes and
edits are preserved under `review_followup_20261104/received_review/`. Historical
report descriptions and assistant suggestions do not override those user labels.

**Explicit user constraint — 2026-10-28:** LLM sentence rewriting is reserved as a
LAST RESORT and must NOT be implemented yet. First improve the compiler on original
claims. A later rewrite must retain information and be checked for role, modifier,
name, quantity, polarity, modality, temporal, reference and source-scope changes.
No rewriting prompt, function or fallback call is implemented. Representation here
means an explicit logical form, not neural embeddings; interface means a component's
specified inputs, outputs and their meanings. ADR-023 remains unchanged.

**Prototype implemented 2026-10-22:** scripts/probabilistic_verification/ contains
the restricted UD-to-logic compiler and actual DeepProbLog inference/training.
Read docs/probabilistic_verification_implementation.md and the compiler_20261022
results in key_facts.md before extending or rerunning. The report is
site/reports/verification-pipeline.html. Sample training uses two development
claims and cached observations on CPU; it establishes no held-out method gain.

**Frozen feature and audio pilot, also 2026-10-22:** Read the
`av_features_20261022` entry in key_facts.md. The report's Visual and audio / Next
steps tabs contain real pre-answer feature caches and separate source trees.
Audio-dependent labels are provisional and not eligible for training. Silence
and text-only music false positives remain unresolved. New feature classifiers
are not implemented/trained yet; the tree prototype uses frozen model scores.

Use familiar NLP terms and plain explanations. Do not invent component names or new
acronyms. Read the terminology file below before writing; the older CRF vocabulary
applies when discussing that historical model, not as a constraint on the new method.

## Project Layout

- **Current shared source / scripts**: `/exp/cxiao/scale26/avid/`. The `site/` subdirectory is the Git repository; compiler source and cached inputs are preserved in report source ZIPs.
- **Experiments / outputs**: `/exp/cxiao/scale26/avid/` (large artifacts — all outputs go here)
- **Canonical annotation surface**: `exp/phase1/reports/annotation_units.tsv` (17,813 rows, 2,375 claims checked 2026-10-28) — never overwrite; the older annotation/claims.jsonl is a different 761-claim inventory
- **Experiment versions**: `exp/v0/` (frozen baseline), `exp/v1/` (4-class coarse), `exp/v2/` (2-pass fine-grained)

## Environments

- **LLM inference (vLLM)**: `/exp/cxiao/calm/tools/miniforge3/envs/vllm-omni` — activate on GPU node
- **Rule-based affordance**: `espnet` conda env (WordNet supersenses)
- GPU target: try the **`h100` tmux session** first (interactive H100 node) before submitting a Slurm job.
  - Check the session with `tmux capture-pane -t h100 -p | tail -20` before using it.
  - **Never interrupt a running job there** — if a job or process is active, leave it alone and fall back to `sbatch`.
  - Sbatch fallback: `--gres gpu:h100:1` (H100, rack3n06/rack7n07, 80 GB); `--gres gpu:h200:1` (H200, rack3n05, 141 GB) as secondary.

## Security

- `HF_TOKEN` is in `.bashrc` — **never echo into logs, transcripts, or commits**

## Language & Terminology Standard

**All docs use one plain, NLP-friendly vocabulary** — the standard in
`docs/project_notes/terminology.md`, matching the public site
(`site/reports/tree-crf.html`, `site/reports/interior-emissions.html`).

- Read `docs/project_notes/terminology.md` **before writing or editing any doc.**
- Write for an NLP reader who knows CRFs / SRL / UD but not our shorthand: define
  shorthand in plain words on first use (e.g. "parse normalization (PN)"), then reuse.
- Anchor to standard NLP terms (emission/transition, belief propagation with
  inside=upward / outside=downward, marginal, MAP, partition function).
- **Precise identifiers are immutable** — never alter an ADR number, file path,
  script/class name, job ID, number, percentage, date, or artifact label when
  rephrasing. Standardization changes wording, never facts.

## Project Memory System

Institutional knowledge lives in `docs/project_notes/` — check it before proposing changes or re-running experiments.

### Memory Files

- **terminology.md** — Plain-language vocabulary & writing standard (read first)
- **bugs.md** — Bug log with solutions and prevention notes
- **decisions.md** — Architectural Decision Records (ADRs)
- **key_facts.md** — Cluster config, model settings, experiment results, LLM prompts
- **issues.md** — Work log and open items

## Canonical Prompt Location

**All phase-2 prompts** — pass-1 stems, pass-2 question, system prompts, and any
LLM pre-pass templates (verbalization, question formulation) — live in one file:

```
scripts/prompts_phase2.py
```

Read this file before designing, modifying, or reviewing any phase-2 prompt.
Do **not** inline prompt strings in slurm scripts or other Python files — define
them in `prompts_phase2.py` and import. The file is organized as:

- **Active builders** (`pass1_user`, `pass2_user`) — call these from `verify_support.py`
- **Pre-pass templates** (`FORMULATE_VIS_SYSTEM` / `FORMULATE_AUD_SYSTEM` / `FORMULATE_USER_TMPL`
  for r5 — two single-modality calls per ADR-009;
  `_R3_VERBALIZE_SYSTEM` / `_R3_VERBALIZE_USER_TMPL` archived)
- **Archived strings** (v1 claim-anchor, v2 two-probe, r3 verbalized) — read-only

### Memory-Aware Protocols

**Before proposing architectural changes:**
- Check `docs/project_notes/decisions.md` for existing ADRs; acknowledge conflicts before proposing reversals.

**Before writing any inference code or slurm scripts:**
- Check `scripts/prompts_phase2.py` for current active variants and prompt text.
- Check `docs/project_notes/key_facts.md` for current model paths, conda env, and vLLM quirks.

**Before re-running any experiment:**
- Check `docs/project_notes/key_facts.md` (Experimental Results) — the run may already exist with logged results.

**When encountering errors:**
- Search `docs/project_notes/bugs.md` for prior occurrences; apply known solutions.

**After completing an experiment:**
- Append a row to the Experimental Results table in `key_facts.md`.
- Add an Analysis Notes entry if a cross-experiment pattern emerges.

**When completing significant work:**
- Log it in `docs/project_notes/issues.md`.
