"""Meaning-sensitive checks for the compiler freeze candidate."""
import copy,itertools,json
from pathlib import Path
import pytest
from probabilistic_verification.compiler_readiness import compile_ready,compile_one,remove_auxiliary_frames,interval_from_text
from probabilistic_verification.semantic_values import temporal_literal
from probabilistic_verification.compilation_followup import walk_events
from probabilistic_verification.logical_form import LogicalFormError

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compiler_readiness_20261112'
RECORDS={r['claim_id']:r for r in map(json.loads,(RUN/'probe_parsed.jsonl').read_text().splitlines())}
def record(name):return copy.deepcopy(RECORDS['ready_'+name])
def test_auxiliary_filter_keeps_lexical_predicate_and_copula():
    passive=record('passive');original=copy.deepcopy(passive);prepared,changes=remove_auxiliary_frames(passive)
    assert passive==original and changes
    claim,_=compile_ready(passive)
    events=list(walk_events(claim.metadata['logical_form']))
    assert [e['predicate']for e in events]==['cover']
    assert {e['text']for e in claim.metadata['logical_form']['entities']}=={'People','dust'}
    _,changes=remove_auxiliary_frames(record('copula'));assert not changes
    assert next(walk_events(compile_ready(record('copula'))[0].metadata['logical_form']))['predicate']=='be'
def test_auxiliary_without_a_body_frame_is_not_removed():
    r=record('passive');r['srl']['frames']=[f for f in r['srl']['frames']if f['verb']=='are']
    prepared,changes=remove_auxiliary_frames(r);assert not changes and prepared['srl']['frames']==r['srl']['frames']
def test_nominal_event_is_shared_with_its_parent_relation():
    claim,_=compile_ready(record('collapse'),nominals=True);f=claim.metadata['logical_form'];event=next(walk_events(f))
    collapse=next(e for e in f['entities']if e['text']=='collapse');road=next(e for e in f['entities']if e['text']=='road')
    assert collapse['type']=='event'and road['type']=='entity'
    assert event['arguments']['ARG0']==collapse['id']
    event_atoms=[a for a in claim.atoms if a.predicate=='event_type']
    assert len(event_atoms)==1 and event_atoms[0].arguments[1]=='collapse'
    variable=event_atoms[0].arguments[0];assert any(v.name==variable and v.kind=='event'for v in claim.variables)
    assert any(a.predicate=='block'and variable in a.arguments for a in claim.atoms)
@pytest.mark.parametrize('name',['planned','prevent','prevent_adj'])
def test_nonactual_nominals_do_not_become_actual_events(name):
    claim,_=compile_ready(record(name),nominals=True);assert not any(a.predicate=='event_type'and a.arguments[1]=='collapse'for a in claim.atoms)
def test_negative_parent_keeps_its_polarity():
    claim,_=compile_ready(record('negative'));assert claim.metadata['logical_form']['formula']['op']=='not'
def test_context_resolves_interval_on_the_same_event():
    r=record('interval');r['compiler_context']={'original_text':'Beginning at video timestamp 2025-03-28 12:46:35 and ending at video timestamp 12:46:37, a boat moves relative to a buoy.'}
    row=compile_one(r);assert row['status']=='compiled'
    event=next(walk_events(row['proposed_form']));value=event['arguments']['ARGM-TMP']
    assert value['lower']=='2025-03-28T12:46:35'and value['upper']=='2025-03-28T12:46:37'
    assert 'reference'in event['arguments']and 'ARGM-DIR'not in event['arguments']
    assert any(a.get('reference_resolution')for a in row['compilation']['metadata']['source_alignments'])
def test_no_interval_is_invented_without_parent_context():
    assert compile_one(record('interval'))['status']!='compiled'
@pytest.mark.parametrize('text',['From 2025-03-28 23:59:59 to 00:00:01','From 2025-03-28 12:00:00 to 2025-03-27 12:00:01'])
def test_ambiguous_or_reversed_interval_is_refused(text):
    with pytest.raises(LogicalFormError):temporal_literal(text)
def test_explicit_interval_does_not_compare_clock_and_date_as_strings():
    value=temporal_literal('From 2025-03-28 12:46:35 to 12:46:37')
    assert value['upper']=='2025-03-28T12:46:37'
    assert temporal_literal('from 9:00 to 10:00')['operator']=='range'
    assert compile_one(record('interval_explicit'))['status']=='compiled'
def test_multiple_intervals_are_not_arbitrarily_selected():
    assert interval_from_text('from 2025-03-28 12:00 to 12:01 and from 13:00 to 13:01')is None
@pytest.mark.parametrize('expected',['supported','refuted'])
def test_native_binding_does_not_detach_the_nominal_event(expected):
    from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground
    from probabilistic_verification.direct_backend import DirectVerifier
    claim,_=compile_ready(record('collapse'),nominals=True)
    domains={v.name:[v.name.lower()]for v in claim.variables};evidence=Evidence('constructed',domains,{v.name:True for v in claim.variables},{})
    for atom in claim.atoms:
        assignment={k:v[0]for k,v in domains.items()};key=canonical_key(evidence.media_id,atom,assignment,evidence.route)
        probs=(0.,1.,0.)if atom.predicate=='block'and expected=='refuted'else(1.,0.,0.)
        evidence.observations[key]=Observation(key,probs,False,'Constructed observation, not media evidence')
    result=DirectVerifier([ground(claim,evidence)],learned=False).predict()[0]['distribution'];assert result[expected]==pytest.approx(1.)
