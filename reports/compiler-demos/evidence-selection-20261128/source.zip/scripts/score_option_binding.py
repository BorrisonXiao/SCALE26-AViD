"""Run frozen scorers on the fixed report spans and visual crops."""
from argparse import ArgumentParser
from hashlib import sha256

from evaluate_ami_speech_scoring import MODELS
from evaluate_reported_or_transcripts import score_pairs
from prepare_binding_followup import ROOT
from prepare_compiler_fallback import dump
from prepare_option_binding import RUN
from prepare_or_source_evaluation import read
from score_binding_followup import CHOICES, QUESTION, load_qwen_scorer

PRESENCE = ('Is this specific option described or mentioned anywhere in the speaker’s words? '
            'Check details such as button type, count, and conditions. Option: {option}')
PRESENCE_CHOICES = ('The specific option is present.', 'The specific option is absent or different.',
                    'The evidence is unclear.')
RELATION = ('Does the speaker’s report support the stated relationship between these specific options? '
            'Read the roles, direction, negation, and details. Both options must match.\n'
            'First option: {first}\nSecond option: {second}\nRelationship: the speaker {relation}.')
RELATION_CHOICES = ('The stated relationship is supported.', 'The stated relationship is contradicted or missing.',
                    'The evidence is unclear.')
VISUAL_QUESTION = 'Which category fits the main object at the center of this crop?'


def speech_cases():
    return [c for r in read(RUN/'speech_inputs.json')['rows'] for c in r['cases']]


def nli():
    pairs = {(w['text'], c['content']) for c in speech_cases() for w in c['windows']}
    result = score_pairs(pairs, MODELS['deberta'])
    dump(RUN/'nli_scores.json', result)
    print('Whole-claim text pairs:', len(pairs), flush=True)


def speech_qwen(score, provenance):
    cases = speech_cases()
    texts = sorted({w['text'] for c in cases for w in c['windows']})
    global_scores = {t: score(QUESTION, CHOICES, text=t) for t in texts}
    option_keys = {(w['text'], option) for c in cases for w in c['windows'] for option in c['options']}
    option_scores = [dict(text=t, option=option, **score(PRESENCE.format(option=option), PRESENCE_CHOICES, text=t))
                     for t, option in sorted(option_keys)]
    relation_keys = {(w['text'], *c['options'], c['relation']) for c in cases for w in c['windows']}
    relation_scores = [dict(text=t, options=[first, second], relation=rel,
                            **score(RELATION.format(first=first, second=second, relation=rel), RELATION_CHOICES, text=t))
                       for t, first, second, rel in sorted(relation_keys)]
    dump(RUN/'qwen_speech.json', dict(provenance, global_scores=global_scores, options=option_scores,
                                    relations=relation_scores, prompts=dict(presence=PRESENCE, relation=RELATION,
                                    global_question=QUESTION, global_choices=CHOICES,
                                    presence_choices=PRESENCE_CHOICES, relation_choices=RELATION_CHOICES)))
    print('Qwen speech requests before answer-order swap:', len(texts), len(option_scores), len(relation_scores), flush=True)


def visual_qwen(score, provenance):
    from PIL import Image

    records = []
    for scene in read(RUN/'visual_inputs.json'):
        path = ROOT/scene['frame']['path']
        assert sha256(path.read_bytes()).hexdigest() == scene['frame']['sha256']
        with Image.open(path) as raw:
            frame = raw.convert('RGB')
        rows = [score(VISUAL_QUESTION, [*scene['labels'], 'Neither or unclear.'],
                      image=frame.crop(tuple(r['box']))) for r in scene['regions']]
        records.append(dict(id=scene['id'], scores=rows))
        print(scene['id'], 'scored', flush=True)
    dump(RUN/'qwen_visual.json', dict(provenance, records=records, question=VISUAL_QUESTION))


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('stage', choices=('nli','speech','visual'))
    stage = parser.parse_args().stage
    if stage == 'nli':
        nli()
    else:
        {'speech': speech_qwen, 'visual': visual_qwen}[stage](*load_qwen_scorer())
