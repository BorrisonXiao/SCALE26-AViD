"""Freeze fresh speech examples and real frames with several similar regions."""
import argparse
from hashlib import sha256
from zipfile import ZipFile

from evaluate_ami_implicit_binding import RUN as PREVIOUS, segments, phrase_index
from prepare_ami_probabilistic_binding import utterance, overlaps
from prepare_ami_window_comparison import series
from prepare_compiler_fallback import ROOT, dump
from prepare_or_source_evaluation import RUN as SOURCE, read

RUN = PREVIOUS.with_name('binding_followup_20261127')
CACHE = ROOT/'exp/phase2/media_cache_1fps/frames'

# The first 12 excerpts formulate actual choices or contrast two options.
# The final 12 describe additions, lists, or literals that resemble choice wording.
SPEECH = (
    (['ES2015b.sync.1018'], 'if instead', True,
     'The remote could light up briefly when touched instead of staying lit all the time.', ('briefly','for an hour')),
    (['TS3011d.sync.495'], None, True,
     'Plastic buttons could be used in place of rubber buttons.', ('Plastic','Glass')),
    (['ES2004d.sync.201'], None, True,
     'A standard battery could be used instead of a kinetic power source.', ('standard battery','solar panel')),
    (['ES2009a.sync.507'], None, True,
     'A PDA-style touchscreen could be used instead of physical buttons.', ('touchscreen','paper display')),
    (['IS1001c.sync.496'], None, True,
     'The system could record a simpler command in place of an answer.', ('a simpler command','the user’s fingerprint')),
    (['EN2006a.sync.2,013'], None, True,
     'We could change the rule instead of changing all the individual items.', ('change the rule','delete the collection')),
    (['TS3003d.sync.949'], None, True,
     'Pressing volume-down twice could replace a separate mute button.', ('volume-down','power')),
    (['EN2001a.sync.1,470'], 'So alternatively', True,
     'If the whole series cannot be processed in one go, we could process metadata instead.', ('metadata','only the video')),
    (['TS3007c.sync.720','TS3007c.sync.721'], None, True,
     'The remote could use kinetic power or a battery.', ('kinetic power','solar power')),
    (['ES2014b.sync.144'], None, True,
     'A clap could be used instead of a whistle if more people can clap than whistle.', ('A clap','A tap')),
    (['TS3012b.sync.1,050'], None, True,
     'If there is a space issue, we could use one rechargeable battery instead of two.', ('two','three')),
    (['EN2009c.sync.353'], None, True,
     'Why would using XHTML instead of XML help?', ('XHTML','JSON')),
    (['IS1006b.sync.1026'], None, False,
     'This functionality is a replacement for using the buttons.', None),
    (['ES2007d.sync.374','ES2007d.sync.376'], None, False,
     'The numeric keypad is proposed in place of the mute control.', None),
    (['ES2008b.sync.613'], None, False,
     'For the interface design, we can either consider technology or balance features against cost, but not both.', None),
    (['ES2003a.sync.67','ES2003a.sync.69'], None, False,
     'You can use a lapel microphone instead of clipping the equipment to your belt.', None),
    (['IS1001d.sync.21'], None, False,
     'The agenda calls for reviewing the prototype evaluation criteria instead of looking at the costs.', None),
    (['ES2010c.sync.701'], None, False,
     'The buttons should light up instead of having clear labels.', None),
    (['TS3012b.sync.816'], None, False,
     'A language-specific cover could be used instead of having interchangeable covers.', None),
    (['ES2015a.sync.326'], None, False,
     'The designer is responsible for conceptual design instead of the detailed design phase.', None),
    (['EN2001a.sync.323'], None, False,
     'We could use the hotspot measures instead of the other measure.', None),
    (['IS1006b.sync.702'], None, False,
     'We can train the recognizer for a particular user instead of incorporating speech recognition.', None),
    (['IS1009c.sync.446'], None, False,
     'A capacitor is offered in place of a transistor.', None),
    (['ES2013a.sync.88'], None, False,
     'The speaker proposed that the cat could face either direction.', None),
)

def freeze_speech():
    path=SOURCE/'source/ami_public_manual_1.6.2.zip'
    previous=read(PREVIOUS/'implicit_cases.json')['rows']
    reserved={series(r['meeting']) for r in previous}
    catalogue = []
    with ZipFile(path) as archive:
        meetings={}
        for ids,start,label,target,change in SPEECH:
            meeting=ids[-1].split('.')[0]
            assert series(meeting) not in reserved
            if meeting not in meetings:
                meetings[meeting]=segments(archive,meeting)
            s=meetings[meeting]
            speaker=s[ids[-1]][0]
            assert all(s[i][0]==speaker for i in ids)
            words=[w for i in ids for w in s[i][1]]
            if start:
                words=words[phrase_index(words,start):]
            assert all(w['text'].casefold()!='or' for w in words),ids
            focal=utterance(words,speaker,ids[-1])
            q=dict(speaker=speaker,start=focal['start']-2,end=focal['end']+2)
            others=[utterance(w,who,k) for k,(who,w) in s.items() if who!=speaker and len(w)>=6]
            in_time=[w for w in others if overlaps(w,q)]
            other=min(in_time or others,key=lambda w:(abs(w['start']-focal['start']),w['id']))
            windows=sorted([focal]+([other] if in_time else []),key=lambda w:w['start'])
            variants=[('faithful' if label else 'addition_or_no_choice',target,q,label)]
            if label:
                original,edit=change
                assert target.count(original)==1
                variants.extend((('changed_option',target.replace(original,edit),q,False),
                                 ('wrong_speaker',target,dict(q,speaker=other['speaker']),False)))
            cases=[dict(id=f'{ids[-1]}:{name}',variant=name,content=text,query=query,windows=windows,expected_support=gold)
                   for name,text,query,gold in variants]
            catalogue.append(dict(meeting=meeting,source=ids,focal=focal,choice=label,cases=cases))
    dump(RUN/'speech_inputs.json',dict(source_sha256=sha256(path.read_bytes()).hexdigest(),rows=catalogue))
    print('Speech spans',len(catalogue),'meetings',len({r['meeting'] for r in catalogue}),flush=True)


# Boxes use fractional coordinates in the original frame. The label list
# gives the object category plus its displayed value, as reviewed in the crop.
VISUAL = (
    ('stadium_spectators','L6eZr9s0nXqoRFQI_0000',2,'people wearing predominantly white tops','people wearing predominantly red tops',
     ((.145,.30,.287,.76,0),(.297,.315,.422,.728,0),(.550,.280,.704,.705,0),(.430,.465,.558,.770,1))),
    ('outdoor_crowd','cC0HR-woTQtlhHa0_0000',2,'people wearing predominantly white clothing','people wearing predominantly black clothing',
     ((.017,.251,.146,.624,0),(.280,.192,.587,1.0,0),(.651,.210,.881,.843,0),(.000,.537,.147,.845,1))),
    ('waterside_spectators','yUam8gg952dRMV4D_0000',2,'people wearing dark shirts','people wearing white shirts',
     ((.288,.603,.500,.999,0),(.498,.694,.659,.999,0),(.665,.763,.828,.999,0),(.00,.766,.097,.999,1))),
    ('crowd_flags','YfZM7b9aDCe2RTyB_0000',12,'predominantly white flags','predominantly red flags',
     ((.064,.292,.152,.418,0),(.354,.139,.444,.326,0),(.585,.062,.754,.265,0),(.630,.365,.715,.544,1))),
    ('airport_aircraft','0q2IOce9x5Po2d8F_0000',2,'aircraft with white fuselages','aircraft with blue fuselages',
     ((.011,.676,.191,.765,0),(.198,.559,.578,.790,1),(.562,.645,.872,.762,0))),
)


def freeze_visual():
    scenes=[]
    for name,clip,second,first,second_label,regions in VISUAL:
        path=CACHE/clip/f'frame_{second:03d}.jpg'
        labels=(first,second_label)
        counts=[sum(r[-1]==i for r in regions) for i in range(2)]
        assert counts[0]>=2 and counts[1]<2
        scenes.append(dict(id=name,frame=dict(path=str(path.relative_to(ROOT)),sha256=sha256(path.read_bytes()).hexdigest(),second=second),
                           labels=labels,regions=[dict(box=r[:4],label_index=r[-1]) for r in regions],
                           claims=[f'At least two of the marked regions show distinct {label}.' for label in labels]))
    dump(RUN/'visual_inputs.json',scenes)
    print('Visual scenes',len(scenes),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('stage',choices=('speech','visual'))
    RUN.mkdir(parents=True,exist_ok=True)
    {'speech':freeze_speech,'visual':freeze_visual}[p.parse_args().stage]()
