"""Report the evidence comparisons and show the scores behind example decisions."""
from html import escape
from shutil import copy2
from xml.etree import ElementTree as ET

from compiler_fallback_report import table
from evaluate_evidence_selection import SPEECH_CONDITIONS, VISUAL_CONDITIONS
from prepare_evidence_selection import ROOT, RUN
from prepare_or_source_evaluation import read

URL = 'compiler-demos/evidence-selection-20261128/'
SPEECH_LABELS = {
    'annotated':'Annotated excerpt',
    'turns_reference_names':'Selected windows · speaker labels in the query interval',
    'turns_earlier_names':'Selected windows · speaker labels from earlier audio',
    'turns_without_names':'Selected windows · disregard speaker',
    'turns_reference_names_asr':'Whisper · speaker labels in the query interval',
    'turns_earlier_names_asr':'Whisper · speaker labels from earlier audio',
}
VISUAL_LABELS = {'center':'Center frame','average':'Average across views','clearest':'Least uncertain view'}


def status_html():
    result = read(RUN/'evaluation.json')
    speech, visual = result['speech']['summary'], result['visual']['summary']
    return (f'<b>Speech evidence selection.</b> Annotated excerpts support {speech["annotated"]["true_support"]}/48 valid '
            f'queries. The selected Whisper windows with speaker names from earlier excerpts support '
            f'{speech["turns_earlier_names_asr"]["true_support"]}/48. '
            f'<b>Neighboring video frames.</b> All three conditions get {visual["center"]["correct"]}/16 decisions right.')


def overview_html():
    result = read(RUN/'evaluation.json')
    speech, visual = result['speech'], result['visual']
    s = speech['summary']
    v = visual['summary']
    coverage = speech['coverage']
    suite = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(key,0)) == 0 for key in ('errors','failures','skipped'))
    comparisons = [
        (SPEECH_LABELS[m],f'{x["true_support"]}/{x["valid"]}',f'{x["false_support"]}/{x["total"]-x["valid"]}',
         f'{x["correct"]}/{x["total"]}')
        for m in SPEECH_CONDITIONS for x in (s[m],)
    ]
    coverage_rows = [
        (SPEECH_LABELS[m],x['has_window'], x['has_target_words'],x['all_target_words'],
         x['all_target_words_before_ranking'],x['all_target_words_one_speaker'])
        for m,x in coverage.items()
    ]
    selected = coverage['turns_earlier_names']
    named = coverage['turns_reference_names']
    unnamed = coverage['turns_without_names']
    assert all((x['probability']>=0.5)==(x['strongest']>=0.5)
               for row in speech['rows'] for q in row['queries'] for x in q['results'].values())
    return (
        '<section><h2 id="remaining-failures">Evidence selection with fixed scorers</h2>'
        '<p>We changed the evidence passed to the frozen models. The claims, scores used by the logic '
        'program and decision threshold stayed fixed within each comparison.</p>'
        '<h3>Speech windows</h3><p>There are 24 AMI meeting excerpts with five claims each. Each excerpt has two valid '
        'wordings and three controls that change an option, change the context or name the wrong speaker. '
        'A valid claim says what a specific person said. The time interval is supplied. A diarizer, which '
        'estimates who spoke when, supplies the boundaries of the automatic windows. Each window covers up to '
        '12 seconds. We keep up to three windows nearest the middle of the supplied interval for the requested '
        'speaker. Speaker names come from either earlier annotated speech or annotations inside the supplied '
        'interval. The second option is a diagnostic that uses information the deployed system would need to infer. '
        'Whisper transcribes the mono audio of the supplied interval. For the comparison, we replace the manually '
        'transcribed words with Whisper words at the same times inside the same windows.</p>'
        +table('Results across the same 120 speech queries. A support score of at least 0.50 accepts a claim.',
               ['Evidence','Valid accepted','False support','Correct'],comparisons)
        +'<p>DeBERTa scores the whole claim. Qwen checks the relationship between the two specified options. '
         'Both must support the claim in the same window. DeepProbLog multiplies these two scores within a window '
         'and allows support from any eligible window. The program treats window outcomes as independent, though '
         'their audio can overlap. Using only the highest-scoring window gives the same decisions in this comparison.</p>'
        +table('Coverage of the original report in each of the 24 meetings, checked against manual word timestamps.',
               ['Evidence','Has window','Any target words','All target words','All words before ranking',
                'All words from one speaker'],coverage_rows)
        +f'<p>Earlier labels leave {24-selected["has_window"]}/24 requested speakers with zero eligible windows. '
         f'Naming speakers with in-interval annotations raises full-report coverage from '
         f'{selected["all_target_words"]}/24 to {named["all_target_words"]}/24 after ranking. '
         f'Before keeping the nearest three, {named["all_target_words_before_ranking"]}/24 reports are complete '
         f'with query-interval speaker labels and {unnamed["all_target_words_before_ranking"]}/24 are complete '
         'when speaker identity is ignored. A different ranking rule alone cannot supply a missing named window. '
         'The unnamed diagnostic lets the right excerpt support a claim for the wrong person. '
         'Manual transcripts of overlapping speech can contain words from multiple speakers. '
         f'Even on the annotated excerpt, {speech["by_variant"]["annotated"]["changed_context"]["false_support"]}/24 '
         'context edits receive false support. These errors require improving the claim or relation scoring as well. '
         '<a href="#speech-window-comparison">Speech examples and scores</a></p>'
        '<h3>Neighboring video frames</h3><p>For eight AViD scenes we marked the same physical objects up to one '
        'second before and after the center frame. We compare the center crop, the average category scores across '
        'matched crops, and the crop with the smallest Qwen score for “Neither or unclear.” Each object contributes '
        'one category distribution. Exact inference calculates the probability that at least two distinct marked '
        'objects belong to the requested category.</p>'
        +table('Results across the same 16 visual queries at a threshold of 0.50.',
               ['Views per object','Valid accepted','False support','Correct'],
               [(VISUAL_LABELS[m],f'{v[m]["true_support"]}/8',f'{v[m]["false_support"]}/8',f'{v[m]["correct"]}/16')
                for m in VISUAL_CONDITIONS])
        +'<p>The nearby views increase support for distant runners. The shields in smoke still fail because '
         'the model assigns low shield scores to multiple objects across the nearby frames. '
         'This comparison uses marked regions and manually matched objects. '
         '<a href="#neighboring-frame-comparison">Visual results and scores</a></p>'
        '<h3>Next experiment</h3><p>Test speaker assignment and claim-based window retrieval separately with '
        'the same three-window budget. Use a fixed test split to see whether they recover valid reports while '
        'rejecting wrong-speaker claims. For video, a short set of clips with visible-to-occluded transitions '
        'would test whether the additional frames can recover missing evidence.</p>'
        f'<p>All {suite.get("tests")} project tests passed. <a href="{URL}evaluation.json">All scores and inputs</a> · '
        f'<a href="{URL}source.zip">Source and replay</a> · <a href="{URL}tests.xml">Tests</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a> · '
        '<a href="#earlier-speech-option-alignment">Earlier speech model comparison</a></p></section>'
    )


def speech_example(row,variant,title,interpretation,modes):
    query = next(q for q in row['queries'] if q['variant']==variant)
    speaker = query['query']['speaker']
    results = []
    for mode in modes:
        res = query['results'][mode]
        strongest = max(res['windows'],key=lambda w:w['whole_claim']*w['option_relation'],default=None)
        if strongest is None:
            results.append((SPEECH_LABELS[mode],'No eligible window','—','—',f'{res["probability"]:.3f}'))
            continue
        span = next(w for w in row['windows'][speaker][mode] if w['id']==strongest['id'])
        text = escape(span['text']) or 'No transcribed words'
        results.append((SPEECH_LABELS[mode],text,f'{strongest["whole_claim"]:.3f}',
                        f'{strongest["option_relation"]:.3f}',f'{res["probability"]:.3f}'))
    expected = 'Supported' if query['expected_support'] else 'Unsupported'
    return (
        f'<article><h3>{escape(title)}</h3><p>{row["meeting"]} · Speaker {speaker} · Expected {expected}</p>'
        f'<blockquote>{escape(query["content"])}</blockquote><p>{escape(interpretation)}</p>'
        + table('The highest-scoring window in each condition and the final score over all selected windows.',
                ['Evidence','Text','Whole claim','Option relation','Final score'],results)
        + '</article>'
    )


def examples_html():
    result = read(RUN/'evaluation.json')
    speech = {r['meeting']:r for r in result['speech']['rows']}
    examples = [
        ('EN2005a','original','Speaker assignment and a transcription error',
         'Without a speaker name from earlier speech, the verifier gets no eligible window. Query-interval labels '
         'recover the intended excerpt. In the same window, Whisper changes “group process” to “good process.”',
         ('annotated','turns_earlier_names','turns_reference_names','turns_reference_names_asr')),
        ('TS3008a','original','A window drops the last word of an option',
         'The Whisper words inside this window end at “line.” The manually transcribed words include “line width.” '
         'Both frozen checks give lower scores to the shortened text.',
         ('annotated','turns_reference_names','turns_reference_names_asr')),
        ('EN2005a','wrong_speaker','The right words from the wrong speaker',
         'The claim changes the speaker from B to A. Removing the speaker constraint lets the same statement '
         'support the wrong person’s claim.',
         ('annotated','turns_without_names','turns_reference_names')),
        ('ES2007a','changed_context','The whole-claim check misses a changed detail',
         'The claim changes “thinner” to “thicker.” The two options are the same in both versions, so the '
         'whole-claim check must catch the error. It assigns enough support even with the exact excerpt.',
         ('annotated','turns_earlier_names')),
    ]
    output = ['<section id="speech-window-comparison"><h2>Speech window examples</h2>']
    output.extend(speech_example(speech[m],v,t,i,conditions) for m,v,t,i,conditions in examples)
    output.append('</section><section id="neighboring-frame-comparison"><h2>Neighboring video frames</h2>')
    output.append(table('Exact support scores for all positive visual queries.',
                        ['Scene','Claim',*(VISUAL_LABELS[m] for m in VISUAL_CONDITIONS)],
                        [(escape(r['id'].replace('_',' ')),escape(q['claim']),
                          *(f'{q["conditions"][m]["probability"]:.3f}' for m in VISUAL_CONDITIONS))
                         for r in result['visual']['rows'] for q in r['results'] if q['expected_support']]))
    smoke = next(r for r in result['visual']['rows'] if r['id']=='shields_in_smoke')
    output.append('<h3>Shields in smoke</h3><p>Three regions contain distinct shields. The fourth contains a '
                  'camera. The center frame gives useful support for object 2. The additional crops leave the '
                  'other two objects with low scores. Dashes indicate a missing or uncertain match.</p>')
    output.append(table('Qwen shield scores by object and frame time.',
                        ['Object','One second before','Center','One second after'],
                        [(f'{i+1}. {escape(smoke["labels"][r["label_index"]])}',
                          *(f'{r["scores"][offset][0]:.3f}' if offset in r['scores'] else '—' for offset in ('-1','0','1')))
                         for i,r in enumerate(smoke['regions'])]))
    output.append('</section>')
    return ''.join(output)


def write_downloads():
    target = ROOT/'site/reports'/URL
    target.mkdir(parents=True,exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,target/name)
