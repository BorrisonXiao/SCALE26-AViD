"""Compare evidence conditions while holding the claim and scorers fixed."""
from collections import Counter
from math import isclose, prod
from statistics import mean

from calibrate_ami_speech_scores import probabilities
from evaluate_binding_followup import pair_count_program, solve, tally
from evaluate_option_binding import speech_program
from prepare_ami_probabilistic_binding import overlaps
from prepare_compiler_fallback import dump
from prepare_evidence_selection import ASR_MODES, RUN, SPEECH_MODES
from prepare_or_source_evaluation import read
from probabilistic_verification.logic import enumerate_probability

SPEECH_CONDITIONS = (*SPEECH_MODES, *(f'{mode}_asr' for mode in ASR_MODES))
VISUAL_CONDITIONS = ('center', 'average', 'clearest')


def score_speech_windows(windows, query, condition, whole, relations):
    for window in windows:
        text = window['text']
        speaker = condition == 'turns_without_names' or window['speaker'] == query['query']['speaker']
        scores = dict(whole_claim=0.,option_relation=0.)
        if text:
            scores = dict(whole_claim=whole[text,query['content']]['entailment'],
                          option_relation=relations[text,*query['options'],query['relation']])
        yield dict(window, scores=scores, checks=dict(speaker=speaker,time=overlaps(window,query['query'])))


def evaluate_speech():
    inputs = read(RUN/'speech_inputs.json')
    whole = probabilities(RUN/'nli_scores.json')
    relations = {(r['text'],*r['options'],r['relation']):r['probabilities'][0]
                 for r in read(RUN/'qwen_speech.json')['records']}
    summary = {mode:Counter() for mode in SPEECH_CONDITIONS}
    strongest = {mode:Counter() for mode in SPEECH_CONDITIONS}
    by_variant = {mode:{} for mode in SPEECH_CONDITIONS}
    coverage = {mode:Counter() for mode in SPEECH_MODES}
    programs = []
    entries = []
    for row in inputs['rows']:
        for mode, q in row['quality'][row['speaker']].items():
            counts = coverage[mode]
            target_words = len(row['focal']['word_ids'])
            counts['has_window'] += q['windows'] > 0
            counts['has_target_words'] += q['max_gold_words'] > 0
            counts['all_target_words'] += q['max_gold_words'] == target_words
            counts['all_target_words_one_speaker'] += q['clean_full']
            all_candidates = q.get('before_ranking_max_gold_words',q['max_gold_words'])
            counts['has_target_words_before_ranking'] += all_candidates > 0
            counts['all_target_words_before_ranking'] += all_candidates == target_words
        for query in row['queries']:
            query['results'] = {}
            for mode in SPEECH_CONDITIONS:
                candidates = row['windows'][query['query']['speaker']][mode]
                windows = list(score_speech_windows(candidates,query,mode,whole,relations))
                case = dict(query,id=f'{query["id"]}:{mode}',windows=windows)
                program = speech_program(case,'specific_and_content')
                programs.append(program)
                entries.append((query,mode,windows,program.claim_id))
    distributions, prolog = solve(programs)
    for query, mode, windows, program_id in entries:
        eligible = [w for w in windows if all(w['checks'].values())]
        span_scores = [prod(w['scores'].values()) for w in eligible]
        p = distributions[program_id]['supported']
        assert isclose(1.-prod(1.-score for score in span_scores),p,abs_tol=1e-10), program_id
        strongest_p = max(span_scores,default=0.)
        expected = query['expected_support']
        tally(summary[mode],expected,p)
        tally(strongest[mode],expected,strongest_p)
        tally(by_variant[mode].setdefault(query['variant'],Counter()),expected,p)
        query['results'][mode] = dict(probability=p,strongest=strongest_p,windows=[
            dict(id=w['id'],**w['scores'],eligible=all(w['checks'].values())) for w in windows])
    (RUN/'speech_program.pl').write_text(prolog)
    return dict(inputs,summary=summary,strongest_summary=strongest,by_variant=by_variant,coverage=coverage,
                native=len(distributions))


def combine_views(views):
    """Return one categorical distribution per object in each condition."""
    return dict(center=views['0'], average=[mean(p[i] for p in views.values()) for i in range(3)],
                clearest=min(views.values(),key=lambda p:p[2]))


def evaluate_visual():
    scenes = read(RUN/'visual_inputs.json')
    raw = {r['id']:r['regions'] for r in read(RUN/'qwen_visual.json')['records']}
    programs = []
    entries = []
    summary = {condition:Counter() for condition in VISUAL_CONDITIONS}
    for scene in scenes:
        for region, scores in zip(scene['regions'],raw[scene['id']],strict=True):
            assert {str(v['offset']) for v in region['views']} == scores.keys()
            region['scores'] = {offset:r['probabilities'] for offset,r in scores.items()}
            region['combined'] = combine_views(region['scores'])
        scene['results'] = []
        for label, claim in enumerate(scene['claims']):
            expected = sum(r['label_index']==label for r in scene['regions']) >= 2
            query = dict(label=label,claim=claim,expected_support=expected,conditions={})
            scene['results'].append(query)
            for mode in VISUAL_CONDITIONS:
                regions = [r['combined'][mode] for r in scene['regions']]
                ident = f'{scene["id"]}:{mode}:{label}'
                program, pairs = pair_count_program(ident,regions,label)
                programs.append(program)
                entries.append((query,mode,pairs,program))
    result, prolog = solve(programs)
    for query, mode, pairs, program in entries:
        observed = result[program.claim_id]
        expected = enumerate_probability(program)
        assert all(isclose(expected[k],v,abs_tol=1e-10) for k,v in observed.items()),program.claim_id
        best = max(pair['score'] for pair in pairs)
        query['conditions'][mode] = dict(probability=observed['supported'],best_pair=best,pairs=pairs)
        tally(summary[mode],query['expected_support'],observed['supported'])
    (RUN/'visual_program.pl').write_text(prolog)
    return dict(rows=scenes,summary=summary,native=len(result))


if __name__=='__main__':
    result = dict(speech=evaluate_speech(),visual=evaluate_visual())
    dump(RUN/'evaluation.json',result)
    for stage, data in result.items():
        print(stage,data['summary'],flush=True)
