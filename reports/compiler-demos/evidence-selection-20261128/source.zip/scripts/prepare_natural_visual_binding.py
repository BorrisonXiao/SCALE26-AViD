"""Freeze manually reviewed crops with natural occlusion, blur, or distance."""
from hashlib import sha256

from PIL import Image

from prepare_binding_followup import CACHE, ROOT, RUN as PREVIOUS
from prepare_compiler_fallback import dump
from prepare_option_binding import RUN
from prepare_or_source_evaluation import read

# Each box uses fractional left, top, right, and bottom coordinates in the
# native frame. It centers on a distinct target, including the matched foil.
SCENES = (
    ('night_crowd', '0K1SM0svCw3VDcfW_0000', 12,
     'people wearing fluorescent safety vests', 'people wearing dark jackets with no safety vest',
     'The foreground and nearby people partly block fluorescent clothing in the crowded night scene.',
     ((.166,.48,.34,.91,0),(.16,.17,.292,.46,0),(.291,.39,.419,.641,0),(.62,.433,.839,.985,1))),
    ('hats_in_crowd', '8wx1Sw-1a9BaC7cM_0000', 12,
     'wide-brimmed hats', 'baseball caps',
     'The hat brims overlap heads and raised arms. One shape is visible behind a person in the foreground.',
     ((.241,.59,.412,.821,0),(.535,.556,.652,.716,0),(.826,.474,.937,.654,0),(.407,.517,.527,.667,1))),
    ('stadium_rows', 'OXGANlWINYFoTzZ5_0000', 2,
     'people wearing predominantly red tops', 'people wearing predominantly light blue tops',
     'Seating rows and other viewers partly cover spectators in a narrow original video frame.',
     ((.104,.53,.23,.626,0),(.312,.462,.453,.568,0),(.752,.52,.925,.647,0),(.32,.57,.48,.71,1))),
    ('night_response', 'WPDc_I950PFDVfbr_0000', 2,
     'people wearing yellow safety vests', 'people wearing orange safety vests',
     'People are small, partly blocked by vehicles, and lit by artificial lights at night.',
     ((.18,.54,.299,.639,0),(.51,.596,.653,.728,0),(.015,.578,.115,.694,1))),
    ('shields_in_smoke', 'Z4QDXPe6os_-Bdog_0000', 12,
     'upright riot shields', 'handheld video cameras',
     'Smoke obscures several of the shields. The matched claim counts distinct equipment silhouetted in the same scene.',
     ((.396,.485,.491,.737,0),(.47,.49,.57,.733,0),(.533,.477,.643,.758,0),(.088,.601,.189,.737,1))),
    ('distant_runners', 'f4w9RxVzmYksHpQf_0000', 12,
     'people racing on the track', 'people standing at the track edge',
     'The original wide shot shows small people with similar outfits in running and standing poses.',
     ((.063,.413,.113,.57,0),(.154,.4,.192,.54,0),(.244,.381,.31,.519,0),(.19,.277,.226,.416,1))),
    ('vans_in_rain', 'q31-ku3atOqc8j-N_0000', 2,
     'predominantly white vans', 'predominantly dark blue vans',
     'Two white vans are distant. The foreground police van is partly blocked and the far vans are seen from behind.',
     ((.285,.288,.556,.571,0),(.717,.209,.793,.314,0),(.799,.155,.856,.259,0),(.637,.247,.717,.41,1))),
    ('ringside_viewers', 'c0zHs25t-Ied7wyr_0000', 12,
     'people wearing predominantly purple tops', 'people wearing predominantly white tops',
     'Ring ropes, a busy background, and nearby people obscure parts of the tops.',
     ((.415,.303,.538,.494,0),(.541,.273,.705,.477,0),(.715,.31,.857,.489,0),(.849,.316,.968,.518,1))),
)


def freeze():
    previous = {row['frame']['path'].split('/')[-2] for row in read(PREVIOUS/'visual_inputs.json')}
    rows = []
    for name, clip, second, a, b, description, boxes in SCENES:
        assert clip not in previous, clip
        path = CACHE/clip/f'frame_{second:03d}.jpg'
        with Image.open(path) as image:
            w, h = image.size
        regions = [dict(box=[round(l*w), round(t*h), round(r*w), round(bottom*h)], label_index=target)
                   for l, t, r, bottom, target in boxes]
        assert sum(r['label_index'] == 0 for r in regions) >= 2
        assert sum(r['label_index'] == 1 for r in regions) == 1
        rows.append(dict(id=name, description=description, labels=[a,b], regions=regions,
                         frame=dict(path=str(path.relative_to(ROOT)), second=second, size=[w,h],
                                    sha256=sha256(path.read_bytes()).hexdigest()),
                         claims=[f'At least two marked regions show distinct {category}.' for category in (a,b)]))
    dump(RUN/'visual_inputs.json', rows)
    print('Visual frames:', len(rows))


if __name__ == '__main__':
    freeze()
