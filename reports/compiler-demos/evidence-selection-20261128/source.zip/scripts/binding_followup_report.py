"""Report the frozen speech scores and overlapping visual assignments."""
from html import escape
from shutil import copy2
from xml.etree import ElementTree as ET

from compiler_fallback_report import table
from evaluate_binding_followup import RELATIONS, SPEECH_METHODS, VISUAL_METHODS
from prepare_binding_followup import ROOT, RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read

URL = 'compiler-demos/binding-followup-20261127/'
LABELS = {'content_only': 'Content only', 'lexical': 'Wording rules',
          'deberta': 'DeBERTa entailment', 'qwen': 'Qwen text classification',
          'best': 'Best pair', 'assume_independent_pairs': 'Independent pairs',
          'exact': 'Exact inference'}
QUALITY = {'original': 'Original crops', 'reduced_resolution': 'Reduced resolution'}


def summarize():
    speech, visual = (read(RUN/name) for name in ('speech_evaluation.json', 'visual_evaluation.json'))
    suite = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(k, 0)) == 0 for k in ('failures', 'errors', 'skipped'))
    dump(RUN/'evaluation.json', dict(speech=speech, visual=visual, tests=int(suite.get('tests'))))


def status_html():
    result = read(RUN/'evaluation.json')
    before, after = (result['speech']['bound'][m] for m in ('content_only', 'qwen'))
    visual = result['visual']
    return (f'<b>Scoring whether a speaker presents alternatives improves {before["correct"]}/{before["total"]} '
            f'to {after["correct"]}/{after["total"]} grounded speech decisions.</b> '
            f'Exact inference and the best pair agree on all {visual["native"]} visual decisions.')


def support_counts(count):
    valid, total = count['valid'], count['total']
    return (f'{count["correct"]}/{total}', f'{count["true_support"]}/{valid}',
            f'{count["false_support"]}/{total-valid}')


def score_table(caption, results, methods):
    return table(caption, ['Method', 'Correct', 'Valid supported', 'False support'],
                 [(LABELS[m], *support_counts(results[m])) for m in methods])


def overview_html():
    r = read(RUN/'evaluation.json')
    speech, visual = r['speech'], r['visual']
    recordings = len({row['meeting'] for row in speech['rows']})
    return (
        '<h2 id="remaining-failures">Speech alternatives and overlapping visual assignments</h2>'
        f'<p>We froze {len(speech["rows"])} excerpts from {recordings} new AMI recordings before scoring. '
        'Twelve present alternatives without the word “or.” Twelve describe additions or have no choice. '
        'We also changed one option and queried a different speaker for each of the twelve valid reports. '
        'The labels come from our review of the transcripts. Speaker IDs, times, and report spans come from the '
        'annotations and our review, so this test starts with those fixed.</p>'
        '<p>Content matching uses a frozen DeBERTa entailment model. We compare the earlier wording rules, '
        'a DeBERTa entailment score for the presence of alternatives, and a Qwen3-VL text classification score '
        'that distinguishes alternatives from additions and unclear cases. In DeepProbLog, one candidate span '
        'must match the requested speaker and time. We multiply its content score by its alternatives score. '
        'Encoding them as separate observations assumes independence within the span. The models are frozen '
        'and we use their raw scores with the same 0.5 decision threshold.</p><div class="binding-result-tables">'
        + score_table('Does the focal excerpt present alternatives?', speech['span_relation'], RELATIONS)
        + score_table('Does the evidence support the claim about this speaker and time?', speech['bound'], SPEECH_METHODS)
        + '</div><p>Qwen retains the 11 valid reports supported by content alone. It removes four false '
        'positives that turn additions into choices and one attribution error. Two queries with a changed option '
        'and one vague directional claim still get false support. The discourse question can recognize that '
        'there is a choice, so the next test needs to check which options the speaker contrasted. '
        '<a href="#speech-alternative-score-cases">Speech examples</a></p>'
        '<h3>Several pairs can share the same region</h3>'
        '<p>We marked three or four distinct candidates in each of five real frames before scoring. Each claim '
        'requires at least two candidates in a category, such as two people in dark shirts. The frozen '
        'vision model gives each crop one categorical distribution over two labels and an unclear outcome. '
        'We assume different crops are independent. A region has a single label in each possible assignment, '
        'even when several candidate pairs use it.</p><div class="binding-result-tables">'
        + table('Correct decisions at the same threshold of 0.5.', ['Image condition', *(LABELS[m] for m in VISUAL_METHODS)],
                [(QUALITY[k], *(f'{value[m]["correct"]}/{value[m]["total"]}' for m in VISUAL_METHODS))
                 for k, value in visual['summary'].items()])
        + '</div><p>The best-pair baseline takes the largest pair score. Exact inference counts any successful pair '
        'and uses a shared observation whenever pairs reuse a region. '
        f'A second pair reaches at least 0.1 in {visual["checks"]["second_pair_at_least_0.1"]}/{visual["native"]} queries. '
        'For dark shirts by the water, support rises from 0.659 for the best pair to 0.902 under exact inference. '
        'Treating pairs as independent gives 0.962 because several pairs reuse the same observations. '
        'All methods still make the same decisions on this small set with manually selected candidates. '
        '<a href="#visual-overlapping-assignment-cases">Visual examples and region scores</a></p>'
        f'<p>All {r["tests"]} project tests passed. '
        f'<a href="{URL}evaluation.json">All cases and scores</a> · <a href="{URL}source.zip">Source and replay</a> · '
        f'<a href="{URL}tests.xml">Tests</a> · <a href="verification-pipeline.html#next-steps">Checklist</a> · '
        '<a href="#earlier-binding-generalization">Earlier comparison</a></p>'
    )


def speech_examples(speech):
    records = {row['focal']['id']: row for row in speech['rows']}
    examples = (
        ('TS3012b', 'addition_or_no_choice', 'An addition mistaken for a choice', 'language-specific'),
        ('ES2014b', 'wrong_speaker', 'A related remark from another speaker', 'clap'),
        ('TS3003d', 'changed_option', 'The wrong button survives the alternatives check', 'power'),
        ('IS1006b', 'addition_or_no_choice', 'A negated replacement', 'replacement for'),
        ('ES2013a', 'addition_or_no_choice', '“The other way” describes a direction', 'cat'),
        ('EN2009c', 'faithful', 'A valid contrast gets a low content score', 'XHTML'),
    )
    output = ['<section id="speech-alternative-score-cases"><h2>What changed in speech verification</h2>']
    for meeting, variant, title, phrase in examples:
        case, = (case for row in records.values() if row['meeting'] == meeting for case in row['cases']
                 if case['variant'] == variant and phrase in case['content'])
        output.append(f'<article class="box benchmark-case" id="speech-alternatives-{meeting}-{variant}">'
                      f'<h3>{escape(title)} · {meeting}</h3><p><strong>Claim about speaker '
                      f'{escape(case["query"]["speaker"])}</strong> {escape(case["content"])}</p>'
                      f'<p><strong>Expected</strong> {"Support" if case["expected_support"] else "No support"}</p>'
                      '<ul class="transcript-comparisons">')
        for w in case['windows']:
            output.append(f'<li><h4>Speaker {escape(w["speaker"])}</h4><p>{escape(w["text"])}</p>'
                          f'<p>Content {w["probability"]["content_only"]:.3f} · Qwen alternatives '
                          f'{w["relation"]["qwen"]:.3f} · '
                          f'{"Speaker matches" if w["checks"]["speaker"] else "Different speaker"}</p></li>')
        output.append('</ul><div class="binding-result-tables">'
                      + table('Support scores for the whole claim.', ['Method', 'Support'],
                              [(LABELS[m], f'{case["results"][m]:.3f}') for m in SPEECH_METHODS])
                      + '</div></article>')
    output.append('<p>AMI transcript excerpts © University of Edinburgh and partners under CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a>.</p></section>')
    return ''.join(output)


def visual_examples(visual):
    output = ['<section id="visual-overlapping-assignment-cases"><h2>Visual scores when several pairs fit</h2>'
              '<p>Each frame has a supported claim and a control about a category marked only once. '
              'The reduced crops were resized to fit within 28 × 24 pixels and then enlarged again. '
              'This tests a fixed image degradation on the same candidates.</p>']
    for scene in visual['rows']:
        ident = scene['id']
        output.append(f'<article class="box benchmark-case" id="overlapping-{ident}">'
                      f'<h3>{escape(ident.replace("_", " ").capitalize())}</h3><p>Frame time '
                      f'{scene["frame"]["second"]} s · {len(scene["regions"])} marked regions</p>'
                      f'<p><strong>Supported</strong> {escape(scene["claims"][0])}</p>'
                      f'<p><strong>Control</strong> {escape(scene["claims"][1])}</p><div class="binding-result-tables">')
        output.append(table('Scores from the same region observations.',
                            ['Image and claim', 'Best pair', 'Independent', 'Exact'],
                            [(f'{QUALITY[r["quality"]]}<br>{"Supported" if r["expected_support"] else "Control"}',
                              *(f'{r["probability"][m]:.3g}' for m in VISUAL_METHODS)) for r in scene['results']]))
        if ident == 'waterside_spectators':
            r, = (r for r in scene['results'] if r['quality'] == 'original' and r['expected_support'])
            output.append(table('Original crop scores for the dark-shirt claim.',
                                ['Region', 'Reviewed category', 'Model score for dark shirts'],
                                [(i, escape(scene['labels'][region['label_index']]), f'{p[0]:.3f}')
                                 for i, (region, p) in enumerate(zip(scene['regions'], r['regions'], strict=True), 1)]))
            output.append(table('Support from each candidate pair.', ['Distinct regions', 'Pair score'],
                                [(' and '.join(map(str, pair['regions'])), f'{pair["score"]:.3f}')
                                 for pair in r['pairs']]))
            output.append('<p>Pairs 1 and 2, 1 and 3, and 1 and 4 all need region 1. Exact inference '
                          'counts an assignment in which all three pairs succeed only once. The score for '
                          'region 4 also shows a perception error. The crop was marked as a white shirt and '
                          'the model gives dark a slight majority.</p>')
        output.append('</div></article>')
    output.append(f'<p><a href="{URL}evaluation.json">Crop coordinates, frame hashes, and all region and pair scores</a></p></section>')
    return ''.join(output)


def examples_html():
    r = read(RUN/'evaluation.json')
    return speech_examples(r['speech']) + visual_examples(r['visual'])


def write_downloads():
    target = ROOT/'site/reports'/URL
    target.mkdir(parents=True, exist_ok=True)
    for name in ('evaluation.json', 'tests.xml'):
        copy2(RUN/name, target/name)


if __name__ == '__main__':
    summarize()
