"""Show per-option speech checks and exact inference on fresh frame regions."""
from html import escape
from shutil import copy2
from xml.etree import ElementTree as ET

from binding_followup_report import LABELS as PRIOR_LABELS, support_counts
from compiler_fallback_report import table
from evaluate_option_binding import SPEECH_METHODS, VISUAL_METHODS
from prepare_option_binding import ROOT, RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read

URL = 'compiler-demos/option-binding-20261127/'
SPEECH_LABELS = {'content':'Whole claim', 'global_relation':'Whole claim + any alternatives',
                 'separate_options':'Also require each option', 'specific_relation':'Specific options and relation',
                 'specific_and_content':'Specific relation + whole claim'}
VISUAL_LABELS = {**{m:PRIOR_LABELS[m] for m in VISUAL_METHODS}, 'exact':'Exact inference'}
SPLITS = {'previous':'Previous reports', 'fresh':'New reports'}
VARIANTS = {'faithful':'Valid report', 'changed_option':'Changed option', 'wrong_speaker':'Wrong speaker',
            'addition_or_no_choice':'Addition or no choice', 'negated_replacement':'Negated replacement',
            'direction_reversal':'Reversed preference', 'negated_relation':'Inserted negation'}


def summarize():
    speech, visual = (read(RUN/name) for name in ('speech_evaluation.json','visual_evaluation.json'))
    suite = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(k,0)) == 0 for k in ('failures','errors','skipped'))
    dump(RUN/'evaluation.json', dict(speech=speech, visual=visual, tests=int(suite.get('tests'))))


def status_html():
    r = read(RUN/'evaluation.json')
    before, after = (r['speech']['summary']['fresh'][m] for m in ('global_relation','specific_and_content'))
    best, exact = (r['visual']['summary'][m] for m in ('best','exact'))
    return (f'<b>Checking the specific relationship alongside the whole claim gives {after["correct"]}/{after["total"]} '
            f'correct decisions on new speech queries, compared with {before["correct"]}/{before["total"]} for the earlier method.</b> '
            f'On the new frames, exact inference gives {exact["correct"]}/{exact["total"]} and the best pair gives '
            f'{best["correct"]}/{best["total"]}.')


def overview_html():
    r = read(RUN/'evaluation.json')
    speech, visual = r['speech'], r['visual']
    output = [
        '<h2 id="remaining-failures">Specific speech options and naturally difficult visual evidence</h2>'
        '<p>The earlier speech score asks whether a speaker presents any alternatives. The new check takes the two '
        'claimed options and asks whether the speaker relates those options as stated. For example, replacing a '
        'mute button by pressing volume-down twice differs from replacing it by pressing power twice. The same check '
        'can take a directional replacement, a contrast, or a denial of a replacement as input.</p>'
        '<p>The previous 48 queries show whether the changes address known errors. The 38 new queries use 12 different '
        'recordings and include substitutions, wrong speakers, reversed preferences, and inserted negation. '
        'We annotated the options and relation from the claim before scoring. Speaker, time, and candidate spans are fixed. '
        'All methods use frozen models and the same support threshold of 0.5.</p>'
        '<p>We compare whole-claim entailment from DeBERTa, the earlier check for any alternatives, '
        'and that earlier method with two additional Qwen scores for the presence of each option. '
        'We also test a single Qwen score for the specific options and their relationship, with and without the whole-claim score. '
        'Every required condition must use the same report span. When a method uses several scores, '
        'the logic program treats them as independent observations and multiplies them within the span.</p>'
    ]
    for split,label in SPLITS.items():
        output.append('<div class="binding-result-tables">'+table(f'{label}. False support counts rejected claims treated as supported.',
                      ['Method','Correct','Valid supported','False support'],
                      [(SPEECH_LABELS[m],*support_counts(speech['summary'][split][m])) for m in SPEECH_METHODS])+'</div>')
    output.append('<p>On the new reports, checking the specific relationship alongside the whole claim '
                  'supports 7/8 valid reports and 2/8 substitutions. The earlier check supports 5/8 valid reports '
                  'and 3/8 substitutions. In the previous set, the combined method rejects the swapped power button '
                  'and still accepts the swapped tap. The separate option scores reject every substitution and '
                  'keep just 4/20 valid reports across both sets. Testing each score against 0.5 individually '
                  'also keeps 4/20 valid reports. A low score for a valid option, such as a separate mute button '
                  'in the volume-down example, can block the claim. <a href="#specific-option-examples">Speech cases and error counts</a></p>'
                  '<h3>Visual evidence from original frames</h3>'
                  '<p>We selected eight frames with distance, motion blur, or occlusion before scoring. '
                  'Each has three or four distinct marked regions and two counting claims. The control asks for two '
                  'objects in a category marked once. The frozen vision model scores the original crops. The best pair '
                  'takes the highest product of two region scores. Exact inference computes the chance that at least '
                  'one pair succeeds and shares a region’s score wherever that region appears. The third method treats pair '
                  'successes as independent.</p><div class="binding-result-tables">')
    output.append(table('Correct decisions at three fixed thresholds and mean squared error of support scores.',
                        ['Method','0.25','0.50','0.75','Squared error'],
                        [(VISUAL_LABELS[m], *(f'{v[m]}/{visual["native"]}' for v in visual['threshold_results'].values()),
                          f'{visual["mean_squared_error"][m]:.3f}') for m in VISUAL_METHODS]))
    output.append('</div><p>Mean squared error is the average squared distance from the reference label, '
                  'with 1 for supported and 0 for unsupported. Lower is better on these examples. '
                  'All methods miss the shields in smoke. Two of the three reviewed shield regions have '
                  'scores below 0.004 for the shield label. The largest increase in exact support comes from the '
                  'white vans, where the best pair scores 0.979 and exact inference gives 0.998. '
                  'Both values support the claim at each tested threshold. This comparison uses marked regions '
                  'and predefined category options. '
                  '<a href="#natural-visual-evidence">Frame results</a></p>'
                  f'<p>All {r["tests"]} project tests passed. '
                  f'<a href="{URL}evaluation.json">All cases and scores</a> · <a href="{URL}source.zip">Source and replay</a> · '
                  f'<a href="{URL}tests.xml">Tests</a> · <a href="verification-pipeline.html#next-steps">Checklist</a> · '
                  '<a href="#earlier-binding-followup">Earlier comparison</a></p>')
    return ''.join(output)


def speech_examples(speech):
    output = ['<section id="specific-option-examples"><h2>Which options did the speaker relate?</h2>',
              '<div class="binding-result-tables">']
    counts = speech['by_variant']['fresh']
    compared = ('global_relation','separate_options','specific_and_content')
    output.append(table('Errors by query type on the new reports.', ['Query', *(SPEECH_LABELS[m] for m in compared)],
                        [(VARIANTS[k], *(f'{counts[m][k]["total"]-counts[m][k]["correct"]}/{counts[m][k]["total"]}'
                                         for m in compared)) for k in counts[compared[0]]]))
    output.append('</div>')
    examples = (('TS3003d','faithful'),('TS3003d','changed_option'),('ES2014b','changed_option'),('EN2009c','faithful'),
                ('IS1006b','negated_replacement'),('ES2016b','direction_reversal'),('ES2012a','negated_relation'),
                ('ES2002b','addition_or_no_choice'),('ES2004b','faithful'))
    for meeting,variant in examples:
        case, = (c for row in speech['rows'] if row['meeting']==meeting for c in row['cases'] if c['variant']==variant)
        a,b = case['options']
        output.append(f'<article class="box benchmark-case" id="option-{meeting}-{variant}">'
                      f'<h3>{VARIANTS[variant]} · {meeting}</h3>'
                      f'<p><strong>Claim about speaker {escape(case["query"]["speaker"])}</strong> {escape(case["content"])}</p>'
                      f'<p><strong>Expected</strong> {"Support" if case["expected_support"] else "No support"}</p>'
                      f'<ul><li>First option · {escape(a)}</li><li>Second option · {escape(b)}</li>'
                      f'<li>Claimed relation · the speaker {escape(case["relation"])}</li></ul>'
                      '<ul class="transcript-comparisons">')
        for w in case['windows']:
            output.append(f'<li><h4>Speaker {escape(w["speaker"])} · {w["start"]:.2f}–{w["end"]:.2f} s</h4>'
                          f'<p>{escape(w["text"])}</p><p>First option {w["scores"]["first_option"]:.3f} · '
                          f'Second option {w["scores"]["second_option"]:.3f} · '
                          f'Specific relation {w["scores"]["option_relation"]:.3f}</p></li>')
        output.append('</ul><div class="binding-result-tables">'+table('Claim support by method.', ['Method','Support'],
                      [(SPEECH_LABELS[m],f'{case["results"][m]:.3f}') for m in SPEECH_METHODS])+'</div></article>')
    output.append('<p>AMI transcript excerpts © University of Edinburgh and partners under CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a>.</p></section>')
    return ''.join(output)


def visual_examples(visual):
    output = ['<section id="natural-visual-evidence"><h2>Original frames with naturally difficult crops</h2>']
    for scene in visual['rows']:
        ident = scene['id']
        output.append(f'<article class="box benchmark-case" id="natural-{ident}">'
                      f'<h3>{escape(ident.replace("_"," ").capitalize())}</h3><p>{escape(scene["description"])}</p>'
                      f'<p><strong>Supported</strong> {escape(scene["claims"][0])}</p>'
                      f'<p><strong>Control</strong> {escape(scene["claims"][1])}</p><div class="binding-result-tables">')
        output.append(table('Support from the same region observations.', ['Claim','Best pair','Independent','Exact'],
                            [('Supported' if row['expected_support'] else 'Control',
                              *(f'{row["summary"][m]:.3g}' for m in VISUAL_METHODS)) for row in scene['results']]))
        for row in scene['results']:
            if row['expected_support'] and ident in ('shields_in_smoke','vans_in_rain'):
                label = row['label']
                output.append(table(f'Model score for {escape(scene["labels"][label])} by region.',
                                    ['Region','Reviewed category','Score'],
                                    [(i,escape(scene['labels'][r['label_index']]),f'{p[label]:.3f}')
                                     for i,(r,p) in enumerate(zip(scene['regions'],scene['scores'],strict=True),1)]))
        output.append('</div></article>')
    output.append(f'<p><a href="{URL}evaluation.json">Frame timestamps, crop coordinates, and all scores</a></p></section>')
    return ''.join(output)


def examples_html():
    r = read(RUN/'evaluation.json')
    return speech_examples(r['speech']) + visual_examples(r['visual'])


def write_downloads():
    target = ROOT/'site/reports'/URL
    target.mkdir(parents=True, exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,target/name)


if __name__ == '__main__':
    summarize()
