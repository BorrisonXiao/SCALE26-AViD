"""Transcribe the fixed AMI query intervals with the local Whisper checkpoint."""
import os
from pathlib import Path

import soundfile
import torch
from transformers import AutoModelForSpeechSeq2Seq, AutoProcessor, pipeline

from prepare_ami_window_comparison import RUN as SPEECH, frozen_cases
from prepare_compiler_fallback import dump
from prepare_evidence_selection import RUN
from prepare_or_source_evaluation import read
from prepare_speech_relation_training import digest


def main():
    folder = Path(os.environ['HF_HOME'])/'hub/models--openai--whisper-base/snapshots'
    checkpoint, = sorted(folder.glob('*'))
    processor = AutoProcessor.from_pretrained(checkpoint,local_files_only=True)
    model = AutoModelForSpeechSeq2Seq.from_pretrained(checkpoint,local_files_only=True,torch_dtype=torch.float16,
                                                     attn_implementation='eager').eval().requires_grad_(False)
    transcribe = pipeline('automatic-speech-recognition',model=model,tokenizer=processor.tokenizer,
                          feature_extractor=processor.feature_extractor,device=0)
    settings = dict(chunk_length_s=24,stride_length_s=4,return_timestamps='word')
    audio = {r['meeting']:r['sha256'] for r in read(SPEECH/'audio/manifest.json')}
    records = []
    for case in frozen_cases():
        meeting=case['meeting']
        path=SPEECH/'audio'/f'{meeting}.wav'
        assert digest(path)==audio[meeting]
        signal,rate=soundfile.read(path,dtype='float32')
        assert signal.ndim==1 and rate==16000
        start,end=(round((case[k]-case['clip_start'])*rate) for k in ('query_start','query_end'))
        assert 0<=start<end<=len(signal)
        offset = case['clip_start']+start/rate
        with torch.inference_mode():
            output=transcribe({'raw':signal[start:end],'sampling_rate':rate},**settings,generate_kwargs={'language':'en','task':'transcribe'})
        words=[]
        dropped=0
        for chunk in output['chunks']:
            lower,upper=chunk['timestamp']
            if lower is None or upper is None or not chunk['text'].strip():
                dropped+=1
                continue
            words.append(dict(start=float(lower)+offset,end=float(upper)+offset,text=chunk['text']))
        records.append(dict(meeting=meeting,start=offset,end=case['query_end'],text=output['text'],words=words,
                            omitted_timestamp_chunks=dropped,audio_sha256=audio[meeting]))
        print(meeting,len(words),'timed words',flush=True)
    dump(RUN/'asr.json',dict(model='openai/whisper-base',revision=checkpoint.name,
                            generation_config_sha256=digest(checkpoint/'generation_config.json'),
                            weights_sha256=digest(checkpoint/'model.safetensors'),settings=settings,records=records))


if __name__=='__main__':
    main()
