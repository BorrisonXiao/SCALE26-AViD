"""Check speech relation scores and exact support for overlapping visual assignments."""
import argparse
from collections import Counter
from itertools import combinations
from math import isclose, prod

from calibrate_ami_speech_scores import probabilities
from evaluate_ami_probabilistic_binding import grounded_case, has_alternatives
from prepare_ami_probabilistic_binding import overlaps
from prepare_binding_followup import RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import GroundProgram, Observation, enumerate_probability
from probabilistic_verification.ordered_circuit import OrderedSolver
from probabilistic_verification.representation import Expression as E
from score_binding_followup import NLI_RELATION

RELATIONS = ('lexical','deberta','qwen')
SPEECH_METHODS = ('content_only',*RELATIONS)
VISUAL_METHODS = ('best','assume_independent_pairs','exact')


def solve(programs):
    model = DirectVerifier(programs,learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver)
    return {r['claim_id']:r['distribution'] for r in model.predict()},model.program


def tally(count, expected, probability):
    positive = probability>=0.5
    count['total'] += 1
    count['correct'] += positive==expected
    count['true_support'] += positive and expected
    count['false_support'] += positive and not expected
    count['valid'] += expected


def speech():
    data = read(RUN/'speech_inputs.json')
    nli = probabilities(RUN/'nli_scores.json')
    raw = read(RUN/'qwen_speech.json')
    qwen = {r['text']:r['probabilities'][0] for r in raw['records']}

    def scores(text):
        return dict(lexical=float(has_alternatives(text)),deberta=nli[text,NLI_RELATION]['entailment'],qwen=qwen[text])

    lexical_summary = {m:Counter() for m in RELATIONS}
    bound_summary = {m:Counter() for m in SPEECH_METHODS}
    programs = []
    for row in data['rows']:
        row['cue_probabilities'] = scores(row['focal']['text'])
        for m,p in row['cue_probabilities'].items():
            tally(lexical_summary[m],row['choice'],p)
        for case in row['cases']:
            q = case['query']
            for w in case['windows']:
                content = nli[w['text'],case['content']]['entailment']
                w['probability'] = dict.fromkeys(SPEECH_METHODS,content)
                w['relation'] = scores(w['text'])
                w['checks'] = dict(speaker=w['speaker']==q['speaker'],time=overlaps(w,q),cue=bool(w['relation']['lexical']))
            for m in SPEECH_METHODS:
                if m=='content_only':
                    program = grounded_case(case,'shared_without_cue',m)
                else:
                    program = grounded_case(case,'shared_witness',m,cue_probability=lambda w: w['relation'][m])
                programs.append(program)
    dist,pl = solve(programs)
    for row in data['rows']:
        for case in row['cases']:
            out = {}
            for m in SPEECH_METHODS:
                branch = 'shared_without_cue' if m=='content_only' else 'shared_witness'
                p = dist[f'{case["id"]}:{m}:{branch}']['supported']
                candidates = [w for w in case['windows'] if w['checks']['speaker'] and w['checks']['time']]
                independent = 1-prod(1-w['probability'][m]*(1 if m=='content_only' else w['relation'][m])
                                     for w in candidates)
                assert isclose(p,independent,abs_tol=1e-10)
                tally(bound_summary[m],case['expected_support'],p)
                bound_summary[m][case['variant']+'_errors'] += (p>=0.5)!=case['expected_support']
                out[m] = p
            case['results'] = out
    dump(RUN/'speech_evaluation.json',dict(source=data['source_sha256'],rows=data['rows'],
                                           span_relation=lexical_summary,bound=bound_summary,native=len(dist)))
    (RUN/'speech_program.pl').write_text(pl)
    print('Speech relation',lexical_summary,'bound',bound_summary,flush=True)


def pair_count_program(cid, regions, label):
    """Make one observation per region and share it across candidate pairs."""
    observations = [Observation(f'{cid.rsplit(":",1)[0]}:{i}',tuple(p),False,f'Region {i+1}')
                    for i,p in enumerate(regions)]
    atoms = [E.atom(o.id) for o in observations]
    if label==1:
        atoms = [E.negate(a) for a in atoms]
    pairs = list(combinations(range(len(atoms)),2))
    expression = E.combine('or',(E.combine('and',(atoms[i],atoms[j])) for i,j in pairs))
    scores = [regions[i][label]*regions[j][label] for i,j in pairs]
    program = GroundProgram(cid,expression,{o.id:o for o in observations},[],[])
    return program,[dict(regions=[i+1,j+1],score=v) for (i,j),v in zip(pairs,scores,strict=True)]


def visual():
    data = read(RUN/'visual_inputs.json')
    raw = read(RUN/'qwen_visual.json')
    scores = {r['id']:r['results'] for r in raw['records']}
    programs = []
    by_quality = {k:{m:Counter() for m in VISUAL_METHODS} for k in ('original','reduced_resolution')}
    checks = Counter()
    for scene in data:
        scene['results'] = []
        for quality, records in scores[scene['id']].items():
            p = [r['probabilities'] for r in records]
            assert len(p)==len(scene['regions'])
            for label,claim in enumerate(scene['claims']):
                cid = f'{scene["id"]}:{quality}:{label}'
                task,pairs = pair_count_program(cid,p,label)
                expected = sum(r['label_index']==label for r in scene['regions'])>=2
                scene['results'].append(dict(id=cid,claim=claim,quality=quality,expected_support=expected,
                                             pairs=pairs,regions=p,label=label))
                programs.append(task)
    observed,pl = solve(programs)
    for program in programs:
        oracle = enumerate_probability(program)
        assert all(isclose(oracle[k],v,abs_tol=1e-10) for k,v in observed[program.claim_id].items())
    for scene in data:
        for r in scene['results']:
            exact = observed[r['id']]['supported']
            ranking = sorted((d['score'] for d in r['pairs']),reverse=True)
            p = dict(best=ranking[0],assume_independent_pairs=1-prod(1-x for x in ranking),exact=exact)
            r['probability'] = p
            group = by_quality[r['quality']]
            for method,v in p.items():
                tally(group[method],r['expected_support'],v)
            best_correct = (p['best']>=0.5)==r['expected_support']
            exact_correct = (exact>=0.5)==r['expected_support']
            checks['second_pair_at_least_0.1'] += ranking[1]>=0.1
            checks['changed_decisions'] += best_correct!=exact_correct
            checks['exact_changes_correctly'] += exact_correct and not best_correct
            checks['exact_changes_incorrectly'] += best_correct and not exact_correct
    dump(RUN/'visual_evaluation.json',dict(rows=data,summary=by_quality,checks=checks,native=len(observed)))
    (RUN/'visual_program.pl').write_text(pl)
    print('Visual',by_quality,checks,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('stage',choices=('speech','visual'))
    {'speech':speech,'visual':visual}[p.parse_args().stage]()
