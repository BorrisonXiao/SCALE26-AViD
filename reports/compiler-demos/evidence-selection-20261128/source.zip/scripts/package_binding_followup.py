"""Package the two comparisons for replay from cached model scores."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from binding_followup_report import ROOT, RUN, URL

REPLAY = ('speech_evaluation.json', 'speech_program.pl', 'visual_evaluation.json',
          'visual_program.pl', 'evaluation.json')


def main():
    paths = [ROOT/name for name in ('requirements-compilation.txt', 'requirements-verification.txt',
                                   'tests/test_binding_followup.py')]
    paths.extend(RUN/name for name in (*REPLAY, 'speech_inputs.json', 'visual_inputs.json', 'nli_scores.json',
                                      'qwen_speech.json', 'qwen_visual.json', 'tests.xml'))
    prior_path = ROOT/'site/reports/compiler-demos/binding-generalization-20261127/source.zip'
    with ZipFile(prior_path) as prior:
        paths.extend(ROOT/name for name in prior.namelist() if name.startswith('scripts/'))
    paths.extend(ROOT/'scripts'/f'{name}.py' for name in ('prepare_binding_followup', 'score_binding_followup',
                 'evaluate_binding_followup', 'binding_followup_report', 'package_binding_followup'))
    data = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    data['README.md'] = (ROOT/'docs/binding_followup_20261127.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({
        name: sha256((RUN/name).read_bytes()).hexdigest() for name in REPLAY
    }, indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(target, 'w') as archive:
        for name, contents in sorted(data.items()):
            member = ZipInfo(name, date_time=(2026, 11, 27, 0, 0, 0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, contents)
    print(f'Archived {len(data)} files for replay.')


if __name__ == '__main__':
    main()
