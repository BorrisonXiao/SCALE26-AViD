"""Archive cached inputs, code, and exact outputs for offline replay."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from option_binding_report import ROOT, RUN, URL
from prepare_option_binding import PREVIOUS

OUTPUTS = ('speech_evaluation.json', 'speech_program.pl', 'visual_evaluation.json',
           'visual_program.pl', 'evaluation.json')


def main():
    paths = [ROOT/name for name in ('requirements-compilation.txt', 'requirements-verification.txt', 'tests/test_option_binding.py')]
    paths.extend(RUN/name for name in (*OUTPUTS, 'speech_inputs.json', 'visual_inputs.json', 'input_sha256.txt',
                                       'nli_scores.json', 'qwen_speech.json', 'qwen_visual.json', 'tests.xml'))
    paths.append(PREVIOUS/'speech_evaluation.json')
    with ZipFile(ROOT/'site/reports/compiler-demos/binding-followup-20261127/source.zip') as prior:
        paths.extend(ROOT/name for name in prior.namelist() if name.startswith('scripts/'))
    paths.extend(ROOT/'scripts'/f'{name}.py' for name in ('prepare_option_binding', 'prepare_natural_visual_binding',
                 'score_option_binding', 'evaluate_option_binding', 'option_binding_report', 'package_option_binding'))
    data = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    data['README.md'] = (ROOT/'docs/option_binding_20261127.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({name: sha256((RUN/name).read_bytes()).hexdigest() for name in OUTPUTS}, indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(exist_ok=True, parents=True)
    with ZipFile(target,'w') as archive:
        for name, contents in sorted(data.items()):
            member = ZipInfo(name, date_time=(2026,11,27,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, contents)
    print(f'Archived {len(data)} files for replay.')


if __name__ == '__main__':
    main()
