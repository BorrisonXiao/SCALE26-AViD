"""Archive the data and code used to replay both inference comparisons."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from evidence_selection_report import ROOT, RUN, URL

OUTPUTS = ('evaluation.json', 'speech_program.pl', 'visual_program.pl')


def main():
    prior = ROOT/'site/reports/compiler-demos/option-binding-20261127/source.zip'
    with ZipFile(prior) as archive:
        paths = {ROOT/name for name in archive.namelist() if name.startswith('scripts/')}
    paths.update(ROOT/'scripts'/f'{stage}_evidence_selection.py' for stage in
                 ('prepare','transcribe','score','evaluate','package'))
    paths.add(ROOT/'scripts/evidence_selection_report.py')
    paths.update(ROOT/name for name in ('requirements-compilation.txt','requirements-verification.txt'))
    paths.update(RUN/name for name in ('speech_inputs.json','visual_inputs.json','asr.json','qwen_speech.json',
                                      'qwen_visual.json','nli_scores.json','tests.xml',*OUTPUTS))
    data = {str(path.relative_to(ROOT)):path.read_bytes() for path in paths}
    data['README.md'] = (ROOT/'docs/evidence_selection_20261128.md').read_bytes()
    data['REPLAY_SHA256.json'] = (json.dumps({name:sha256((RUN/name).read_bytes()).hexdigest()
                                            for name in OUTPUTS},indent=2)+'\n').encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(exist_ok=True,parents=True)
    with ZipFile(target,'w') as archive:
        for name, contents in sorted(data.items()):
            member = ZipInfo(name,date_time=(2026,11,28,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member,contents)
    print(f'Archived {len(data)} files for replay.')


if __name__=='__main__':
    main()
