"""Freeze transcript windows and annotated neighboring views before scoring."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256

from PIL import Image

from collect_ami_or_candidates import detokenize
from evaluate_ami_alignment import match_speakers
from evaluate_ami_speaker_binding import load_turns
from evaluate_ami_window_comparison import BUDGET, WINDOW_SECONDS, WINDOW_STRIDE
from prepare_ami_window_comparison import RUN as SPEECH, frozen_cases
from prepare_compiler_fallback import ROOT, dump
from prepare_option_binding import RUN as VISION
from prepare_or_source_evaluation import read

RUN = VISION.with_name('evidence_selection_20261128')
SPEECH_MODES = ('annotated','turns_reference_names','turns_earlier_names','turns_without_names')
ASR_MODES = ('turns_reference_names','turns_earlier_names')
CHOICE = 'presents or contrasts both of the stated alternatives'
# The two option phrases are checked independently of the surrounding claim wording.
# Each edit replaces one option phrase and the whole claim preserves all context.
OPTIONS = {
    'EN2005a':('a contribution of knowledge','a contribution of an opinion',1,'a contribution of an instruction'),
    'EN2006b':('keeping both items','removing both items',1,'removing only one item'),
    'EN2009b':('returning next Wednesday','returning next Thursday',1,'returning next Friday'),
    'ES2002d':('picking three','picking four',1,'picking six'),
    'ES2003d':('preventing remotes from becoming lost','finding remotes after they are lost',1,'replacing remotes after they are lost'),
    'ES2005c':('requiring a hand-held device','requiring a nearby device',1,'requiring a plugged-in device'),
    'ES2006d':('returning to the other room','remaining here now',0,'returning to the lobby'),
    'ES2007a':('putting three remotes together','putting four remotes together',1,'putting five remotes together'),
    'ES2009d':('getting a response after two months','getting a response after three months',1,'getting a response after four months'),
    'ES2012b':('a unit like a satellite box','a unit like a cable box',1,'a unit like a DVD player'),
    'ES2015d':('pressing six and then Enter','pressing one and two and then Enter',1,'pressing one and three and then Enter'),
    'IB4001':('reserving the room for reading and studying only','booking the room for meetings',1,'booking the room for rehearsals'),
    'IB4010':('each person nominating one movie','each person nominating two movies',1,'each person nominating three movies'),
    'IB4011':('using two sentences','using three sentences',1,'using four sentences'),
    'IN1002':('waiting one week','waiting two weeks',1,'waiting two months'),
    'IN1007':('a noise signal','a sequence of pulses',1,'a steady tone'),
    'IN1012':('receiving training data','receiving development data',1,'receiving test data'),
    'IN1013':('using four bits for quantization','using five bits for quantization',1,'using six bits for quantization'),
    'IS1001b':('implementing it numerically only','implementing it with an incremental option',1,'implementing it with a voice-controlled option'),
    'IS1005b':('having one minute left to talk','having two minutes left to talk',1,'having three minutes left to talk'),
    'TS3007d':('making it with a single curve','leaving it without a curve',1,'making it with two curves'),
    'TS3008a':('selecting the current color','selecting the line width',1,'selecting the font size'),
    'TS3011c':('pairing gray with yellow','pairing black with yellow',0,'pairing white with yellow'),
    'TS3012c':('a black cover with yellow buttons','a yellow cover with black buttons',0,'a black cover with green buttons'),
}
CONTEXT = {'EN2009b':('leaving next Wednesday','leaving next Thursday'),
           'ES2003d':('causing remotes to get lost','finding remotes after they are lost'),
           'ES2006d':('returning to the other room','remaining here overnight'),
           'IB4001':('reserving the room for reading and studying only','walking in without booking for meetings'),
           'IN1012':('taking away training data','taking away development data'),
           'IN1013':('using four bits for transmission','using five bits for transmission'),
           'TS3008a':('saving the current color','saving the line width'),
           'TS3011c':('pairing gray with blue','pairing black with blue')}
RELATIONS = {'ES2005c':'says that neither of these is a requirement for picking up speech',
             'ES2007a':'mentions these possible numbers of remotes while saying the design goes beyond simply combining them'}


def temporal_rank(candidates, center):
    return sorted(candidates,key=lambda w:(abs((w['start']+w['end'])/2-center),
                    -(w['end']-w['start']), w['start'],w['cluster']))[:BUDGET]


def words_in_window(words, start, end):
    return [word for word in words if start <= (word['start']+word['end'])/2 < end]


def turn_windows(turns, query, words):
    """Set audio window boundaries without consulting the transcript."""
    for turn in turns:
        start = max(query['start'],turn['start'])
        end = min(query['end'],turn['end'])
        while start < end:
            stop = min(end,start+WINDOW_SECONDS)
            selected = words_in_window(words,start,stop)
            yield dict(start=start,end=stop,cluster=turn['cluster'],
                       text=detokenize(selected),word_ids=[w['word_id'] for w in selected])
            if stop == end:
                break
            start += WINDOW_STRIDE


def speech():
    source = frozen_cases()
    track = load_turns(SPEECH/'diarization.json')
    assert {r['meeting'] for r in source}==set(OPTIONS)
    records=[]
    for case in source:
        meeting = case['meeting']
        turns = track[meeting]
        query = dict(start=case['query_start'],end=case['query_end'])
        center = (query['start']+query['end'])/2
        earlier, enrollment = match_speakers(case,turns)
        reference, _ = match_speakers(case,turns,interval=(query['start'],query['end']))
        original = dict(id=case['segment_id'],start=case['start'],end=case['end'],text=case['text'],
                        speaker=case['speaker'],word_ids=[w['word_id'] for w in case['words']])
        word_speakers = {w['word_id']:w['speaker'] for w in case['clip_words']}
        candidates = list(turn_windows(turns,query,case['clip_words']))
        for i,w in enumerate(candidates):
            w['id'] = f'{meeting}:window:{i}'
        # In the annotated condition other-speaker evidence comes from the same
        # fixed query interval and speaker annotation, without using claim words.
        other = [w for w in case['clip_words'] if w['speaker']==case['wrong_speaker'] and query['start']<=w['start']<query['end']]
        alt=[]
        if other:
            lookup = [w for w in other if abs((w['start']+w['end'])/2-center)<=6]
            if lookup:
                alt.append(dict(id=f'{meeting}:annotated_other',start=lookup[0]['start'],end=max(w['end'] for w in lookup),
                                text=detokenize(lookup),speaker=case['wrong_speaker'],word_ids=[w['word_id'] for w in lookup]))
        base_a,base_b,i,change=OPTIONS[meeting]
        annotated = {}
        quality = {}
        gold = set(original['word_ids'])
        for window in (original,*alt,*candidates):
            window['matched_gold_words'] = len(gold.intersection(window['word_ids']))
            window['word_speakers'] = dict(Counter(word_speakers[word] for word in window['word_ids']))
        named = {
            mode:[dict(w,speaker=mapping.get(w['cluster'])) for w in candidates]
            for mode,mapping in (('turns_reference_names',reference),('turns_earlier_names',earlier),('turns_without_names',{}))
        }
        for speaker in (case['speaker'],case['wrong_speaker']):
            modes = {'annotated':[w for w in (original,*alt) if w['speaker']==speaker]}
            quality[speaker] = {}
            for mode, windows in named.items():
                eligible = [w for w in windows if mode=='turns_without_names' or w['speaker']==speaker]
                modes[mode] = temporal_rank(eligible,center)
                quality[speaker][mode] = dict(
                    before_ranking_windows=len(eligible),
                    before_ranking_max_gold_words=max((x['matched_gold_words'] for x in eligible),default=0))
            annotated[speaker] = modes
            for mode, windows in modes.items():
                quality[speaker].setdefault(mode,{}).update(
                    windows=len(windows),max_gold_words=max((x['matched_gold_words'] for x in windows),default=0),
                    clean_full=any(x['matched_gold_words']==len(gold) and x['word_speakers'].keys()=={speaker}
                                   for x in windows))
        claims=[]
        variants=[*case['variants'],dict(case['variants'][1],variant='wrong_speaker',expected_support=False)]
        for row in variants:
            variant = row['variant']
            options=[base_a,base_b]
            if variant=='changed_option':
                options[i] = change
            elif variant=='changed_context':
                options=list(CONTEXT.get(meeting,options))
            speaker=case['wrong_speaker'] if variant=='wrong_speaker' else case['speaker']
            claims.append(dict(row,id=f'{meeting}:{variant}',options=options,relation=RELATIONS.get(meeting,CHOICE),
                               query=dict(query,speaker=speaker),expected_support=row['expected_support']))
        records.append(dict(meeting=meeting,split=case['split'],speaker=case['speaker'],wrong_speaker=case['wrong_speaker'],
                            focal=original,queries=claims,windows=annotated,quality=quality, earlier_names=earlier,
                            reference_names=reference,enrollment=enrollment))
    dump(RUN/'speech_inputs.json', dict(rows=records,budget=BUDGET,selection='distance to center of fixed query interval',
         transcript_sha256=sha256((SPEECH/'speech_cases.json').read_bytes()).hexdigest(),
         diarization_sha256=sha256((SPEECH/'diarization.json').read_bytes()).hexdigest()))
    print('Speech',len(records),'meetings',sum(len(r['queries']) for r in records),'queries',flush=True)


def attach_asr():
    inputs = read(RUN/'speech_inputs.json')
    transcripts = {r['meeting']:r for r in read(RUN/'asr.json')['records']}
    assert transcripts.keys() == {r['meeting'] for r in inputs['rows']}
    for row in inputs['rows']:
        transcript = transcripts[row['meeting']]
        for modes in row['windows'].values():
            for mode in ASR_MODES:
                windows = []
                for w in modes[mode]:
                    assert transcript['start'] <= w['start']+1/16000 and w['end'] <= transcript['end']
                    words = words_in_window(transcript['words'],w['start'],w['end'])
                    windows.append(dict(id=w['id'],start=w['start'],end=w['end'],
                                        speaker=w['speaker'],cluster=w['cluster'],
                                        text=''.join(word['text'] for word in words).strip()))
                modes[f'{mode}_asr'] = windows
    inputs['asr_sha256'] = sha256((RUN/'asr.json').read_bytes()).hexdigest()
    dump(RUN/'speech_inputs.json',inputs)


# Boxes in the immediately preceding and following frame for the same center-frame
# objects. A missing box records an occlusion or an uncertain identity.
VIEWS = {
    'night_crowd':{-1:[(.145,.457,.324,.895),(.14,.215,.257,.460),(.25,.38,.397,.69),(.57,.429,.802,.982)],
                   1:[(.17,.43,.343,.901),(.153,.17,.292,.449),(.29,.365,.420,.634),(.61,.36,.837,.986)]},
    'hats_in_crowd':{-1:[(.188,.549,.313,.70),(.535,.55,.663,.719),None,(.391,.493,.514,.654)],
                     1:[(.541,.66,.744,.932),(.797,.665,.936,.816),None,None]},
    'stadium_rows':{-1:[(.15,.543,.277,.655),(.381,.477,.485,.597),(.817,.54,.996,.681),(.34,.602,.492,.729)],
                     1:[None,(.366,.549,.491,.639),None,None]},
    'night_response':{-1:[None,None,(.414,.57,.524,.696)],1:[None,(.065,.579,.161,.734),None]},
    'shields_in_smoke':{-1:[None,(.474,.494,.559,.756),(.606,.481,.702,.806),None],
                       1:[(.375,.474,.474,.756),(.458,.493,.546,.774),(.531,.482,.622,.774),(.048,.54,.163,.726)]},
    'distant_runners':{-1:[(.052,.404,.104,.557),(.144,.395,.192,.525),None,None],
                        1:[(.095,.431,.172,.604),(.159,.383,.214,.568),(.237,.379,.294,.517),None]},
    'vans_in_rain':{-1:[(.291,.272,.556,.573),(.695,.208,.779,.322),(.809,.149,.884,.255),(.609,.258,.708,.463)],
                     1:[(.289,.279,.561,.57),(.722,.197,.799,.318),(.811,.157,.87,.255),(.679,.218,.759,.355)]},
    'ringside_viewers':{-1:[(.365,.308,.494,.496),(.482,.27,.667,.482),(.66,.303,.8,.504),None],
                        1:[(.455,.342,.588,.538),(.575,.301,.713,.493),(.773,.331,.913,.527),None]},
}


def frames():
    scenes = read(VISION/'visual_inputs.json')
    for row in scenes:
        center = row['frame']
        base = ROOT/center['path']
        assert sha256(base.read_bytes()).hexdigest()==center['sha256']
        for region in row['regions']:
            region['views'] = [dict(center,box=region['box'],offset=0)]
        for offset, boxes in VIEWS[row['id']].items():
            second = center['second']+offset
            path = base.with_name(f'frame_{second:03d}.jpg')
            with Image.open(path) as image:
                width,height = image.size
            metadata = dict(path=str(path.relative_to(ROOT)),second=second,size=[width,height],offset=offset,
                            sha256=sha256(path.read_bytes()).hexdigest())
            for region, box in zip(row['regions'],boxes,strict=True):
                if box is None:
                    continue
                l,t,r,b = box
                assert 0<=l<r<=1 and 0<=t<b<=1
                region['views'].append(dict(metadata,box=[round(l*width),round(t*height),round(r*width),round(b*height)]))
    dump(RUN/'visual_inputs.json',scenes)
    print('Visual',len(scenes),'scenes',sum(len(r['views']) for row in scenes for r in row['regions']),'crops',flush=True)


if __name__=='__main__':
    p = ArgumentParser()
    stages = {'speech':speech,'attach-asr':attach_asr,'visual':frames}
    p.add_argument('stage',choices=stages)
    RUN.mkdir(parents=True,exist_ok=True)
    stages[p.parse_args().stage]()
