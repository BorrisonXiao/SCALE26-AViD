"""Score the selected transcripts and views with frozen model checkpoints."""
from argparse import ArgumentParser
from hashlib import sha256

from PIL import Image

from evaluate_ami_speech_scoring import MODELS
from evaluate_reported_or_transcripts import score_pairs
from prepare_compiler_fallback import ROOT, dump
from prepare_evidence_selection import RUN, VISION
from prepare_or_source_evaluation import read
from score_binding_followup import load_qwen_scorer
from score_option_binding import RELATION, RELATION_CHOICES, VISUAL_QUESTION


def text_requests():
    for row in read(RUN/'speech_inputs.json')['rows']:
        for claim in row['queries']:
            for windows in row['windows'][claim['query']['speaker']].values():
                for window in windows:
                    if window['text']:
                        yield window['text'], claim


def nli():
    pairs = {(text, claim['content']) for text, claim in text_requests()}
    dump(RUN/'nli_scores.json', score_pairs(pairs, MODELS['deberta']))
    print('DeBERTa requests:', len(pairs), flush=True)


def speech(score, provenance):
    requests = {(text, *c['options'], c['relation']) for text, c in text_requests()}
    print('Qwen transcript requests:', len(requests), flush=True)
    records = []
    for i, (text, first, second, relation) in enumerate(sorted(requests), 1):
        prompt = RELATION.format(first=first, second=second, relation=relation)
        records.append(dict(text=text, options=[first,second], relation=relation,
                            **score(prompt, RELATION_CHOICES, text=text)))
        if i % 100 == 0:
            print(i, 'speech requests complete', flush=True)
    dump(RUN/'qwen_speech.json', dict(provenance, prompt=RELATION, choices=RELATION_CHOICES, records=records))


def visual(score, provenance):
    cached_path = VISION/'qwen_visual.json'
    center = read(cached_path)
    assert all(center[key] == value for key,value in provenance.items())
    assert center['question'] == VISUAL_QUESTION
    cached = {r['id']:r['scores'] for r in center['records']}
    rows = []
    for scene in read(RUN/'visual_inputs.json'):
        regions = []
        for region, prior in zip(scene['regions'],cached[scene['id']],strict=True):
            scores = {'0':prior}
            for view in region['views']:
                if view['offset'] == 0:
                    continue
                path = ROOT/view['path']
                assert sha256(path.read_bytes()).hexdigest() == view['sha256']
                with Image.open(path) as raw:
                    crop = raw.convert('RGB').crop(tuple(view['box']))
                scores[str(view['offset'])] = score(VISUAL_QUESTION,[*scene['labels'],'Neither or unclear.'],image=crop)
            regions.append(scores)
        rows.append(dict(id=scene['id'],regions=regions))
    dump(RUN/'qwen_visual.json',dict(provenance, question=VISUAL_QUESTION,
                                    center_scores_sha256=sha256(cached_path.read_bytes()).hexdigest(),records=rows))
    print('Visual scenes:', len(rows), flush=True)


if __name__=='__main__':
    parser = ArgumentParser()
    parser.add_argument('stage',choices=('nli','qwen'))
    if parser.parse_args().stage == 'nli':
        nli()
    else:
        score, provenance = load_qwen_scorer()
        visual(score, provenance)
        speech(score, provenance)
