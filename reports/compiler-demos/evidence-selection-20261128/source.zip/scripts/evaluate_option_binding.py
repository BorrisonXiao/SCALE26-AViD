"""Compare fixed speech checks and exact aggregation on naturally difficult crops."""
from argparse import ArgumentParser
from collections import Counter, defaultdict
from math import isclose, prod

from calibrate_ami_speech_scores import probabilities
from evaluate_ami_probabilistic_binding import state
from evaluate_binding_followup import VISUAL_METHODS, pair_count_program, solve, tally
from prepare_ami_probabilistic_binding import overlaps
from prepare_compiler_fallback import dump
from prepare_option_binding import PREVIOUS, RUN
from prepare_or_source_evaluation import read
from probabilistic_verification.logic import Evidence, Observation, canonical_key, enumerate_probability, ground
from probabilistic_verification.representation import Atom, CompiledClaim, Expression as E, Variable

SPEECH_METHODS = {
    'content': ('whole_claim',),
    'global_relation': ('whole_claim', 'alternatives'),
    'separate_options': ('whole_claim', 'alternatives', 'first_option', 'second_option'),
    'specific_relation': ('option_relation',),
    'specific_and_content': ('whole_claim', 'option_relation'),
}
THRESHOLDS = (0.25, 0.5, 0.75)


def speech_program(case, method):
    query = case['query']
    a, b = case['options']
    specs = {
        'speaker': ('speaker_matches', query['speaker']),
        'time': ('within_time', f'{query["start"]:g} to {query["end"]:g} seconds'),
        'whole_claim': ('reported_disjunction', case['content']),
        'alternatives': ('presents_alternatives',),
        'first_option': ('mentions_option', a),
        'second_option': ('mentions_option', b),
        'option_relation': ('option_relation', a, b, case['relation']),
    }
    features = ('speaker', 'time', *SPEECH_METHODS[method])
    atoms = tuple(Atom(name, predicate, ('U', *args), 'relation', (),
                       ' '.join((predicate, *args)), (), False)
                  for name in features for predicate, *args in (specs[name],))
    expression = E.exists(('U',), E.combine('and', (E.atom(a.id) for a in atoms)))
    form = CompiledClaim(f'{case["id"]}:{method}', case['content'], (),
                         (Variable('U','utterance','Candidate report span',()),), atoms, expression, ())
    evidence = Evidence(case['id'], {'U': [w['id'] for w in case['windows']]}, {'U': False}, {}, route='speech_assertion')
    for w in case['windows']:
        for atom in atoms:
            key = canonical_key(evidence.media_id, atom, {'U': w['id']}, evidence.route)
            if atom.id in ('speaker','time'):
                dist = state(w['checks'][atom.id])
            else:
                p = w['scores'][atom.id]
                dist = (p, 0., 1.-p)
            evidence.observations[key] = Observation(key, dist, False, atom.text, {'utterance': w['id']})
    return ground(form, evidence)


def speech():
    inputs = read(RUN/'speech_inputs.json')
    content = probabilities(RUN/'nli_scores.json')
    qwen = read(RUN/'qwen_speech.json')
    options = {(r['text'],r['option']): r['probabilities'][0] for r in qwen['options']}
    relations = {(r['text'],*r['options'],r['relation']): r['probabilities'][0] for r in qwen['relations']}
    summaries = {split: {m: Counter() for m in SPEECH_METHODS} for split in ('previous','fresh','all')}
    by_variant = {split: {m: defaultdict(Counter) for m in SPEECH_METHODS} for split in summaries}
    entries = []
    programs = []
    for row in inputs['rows']:
        for case in row['cases']:
            # A transcript span can be offered to several queries. Scores are query specific.
            case['windows'] = [dict(w) for w in case['windows']]
            a,b = case['options']
            for w in case['windows']:
                t = w['text']
                w['checks'] = dict(speaker=w['speaker']==case['query']['speaker'], time=overlaps(w,case['query']))
                w['scores'] = dict(whole_claim=content[t,case['content']]['entailment'],
                                   alternatives=qwen['global_scores'][t]['probabilities'][0],
                                   first_option=options[t,a], second_option=options[t,b],
                                   option_relation=relations[t,a,b,case['relation']])
            programs.extend(speech_program(case, method) for method in SPEECH_METHODS)
            entries.append((row['split'], case))
    results, code = solve(programs)
    thresholded_options = {split: Counter() for split in summaries}
    for split, case in entries:
        case['results'] = {}
        eligible = [w for w in case['windows'] if all(w['checks'].values())]
        for method, keys in SPEECH_METHODS.items():
            p = results[f'{case["id"]}:{method}']['supported']
            reference = 1.-prod(1.-prod(w['scores'][k] for k in keys) for w in eligible)
            assert isclose(reference, p, abs_tol=1e-10), (case['id'],method,p,reference)
            for group in (split,'all'):
                tally(summaries[group][method],case['expected_support'],p)
                tally(by_variant[group][method][case['variant']],case['expected_support'],p)
            case['results'][method] = p
        # A diagnostic using individual thresholds isolates failures already
        # present in the raw option scores from the effect of multiplication.
        min_score = max((min(w['scores'][k] for k in SPEECH_METHODS['separate_options'])
                         for w in eligible), default=0.)
        for group in (split, 'all'):
            tally(thresholded_options[group], case['expected_support'], min_score)
        case['individual_threshold_score'] = min_score
    # Check that rescoring produces the old baseline's decisions on all old queries.
    earlier = {c['id']:c['results']['qwen'] for r in read(PREVIOUS/'speech_evaluation.json')['rows'] for c in r['cases']}
    assert all((c['results']['global_relation']>=0.5)==(earlier[c['id']]>=0.5) for split,c in entries if split=='previous')
    dump(RUN/'speech_evaluation.json',dict(inputs,summary=summaries,by_variant=by_variant,native=len(results),
                                         individual_thresholds=thresholded_options))
    (RUN/'speech_program.pl').write_text(code)
    print('Speech:', summaries, flush=True)


def visual():
    scenes = read(RUN/'visual_inputs.json')
    raw = read(RUN/'qwen_visual.json')
    scores = {r['id']:r['scores'] for r in raw['records']}
    programs = []
    records = []
    for scene in scenes:
        scene['scores'] = [r['probabilities'] for r in scores[scene['id']]]
        assert len(scene['scores']) == len(scene['regions'])
        scene['results'] = []
        for label, claim in enumerate(scene['claims']):
            ident = f'{scene["id"]}:original:{label}'
            program, pairs = pair_count_program(ident, scene['scores'], label)
            expected = sum(r['label_index']==label for r in scene['regions'])>=2
            row = dict(id=ident,label=label,claim=claim,expected_support=expected,pairs=pairs)
            scene['results'].append(row)
            records.append(row)
            programs.append(program)
    result, code = solve(programs)
    for program in programs:
        oracle = enumerate_probability(program)
        assert all(isclose(oracle[k],v,abs_tol=1e-10) for k,v in result[program.claim_id].items())
    summary = {method: Counter() for method in VISUAL_METHODS}
    squared = dict.fromkeys(VISUAL_METHODS, 0.)
    threshold_results = {str(t): Counter() for t in THRESHOLDS}
    different = []
    for row in records:
        expected = row['expected_support']
        scores = sorted((p['score'] for p in row['pairs']), reverse=True)
        row['summary'] = dict(best=scores[0], assume_independent_pairs=1-prod(1-p for p in scores),
                              exact=result[row['id']]['supported'])
        for method,p in row['summary'].items():
            tally(summary[method],expected,p)
            squared[method] += (p-float(expected))**2
            for t in THRESHOLDS:
                threshold_results[str(t)][method] += (p>=t)==expected
        if (row['summary']['exact']>=0.5)!=(row['summary']['best']>=0.5):
            different.append(row['id'])
    dump(RUN/'visual_evaluation.json', dict(rows=scenes, summary=summary, threshold_results=threshold_results,
                                           mean_squared_error={k:v/len(records) for k,v in squared.items()},
                                           changed=different,native=len(result)))
    (RUN/'visual_program.pl').write_text(code)
    print('Visual:', summary, 'thresholds:', threshold_results, 'changed:', different, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('stage', choices=('speech','visual'))
    {'speech': speech, 'visual': visual}[parser.parse_args().stage]()
