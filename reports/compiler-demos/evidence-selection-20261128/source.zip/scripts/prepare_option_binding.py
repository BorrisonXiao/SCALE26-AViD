"""Freeze option readings and natural visual evidence before scoring."""
from hashlib import sha256
from zipfile import ZipFile

from evaluate_ami_implicit_binding import segments
from prepare_ami_probabilistic_binding import overlaps, utterance
from prepare_binding_followup import CACHE, ROOT, RUN as PREVIOUS, SOURCE
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read

RUN = PREVIOUS.with_name('option_binding_20261127')
REPLACE = 'proposes or prefers the first option in place of the second'
CONTRAST = 'presents the two options as alternatives or contrasts them'
DENY = 'explicitly denies that the first option should replace the second'

# Option phrases retain the details and roles that distinguish the claims.
PREVIOUS_OPTIONS = (
    ('the remote lighting up briefly when touched', 'the remote staying lit all the time', REPLACE, 0, 'the remote lighting up for an hour when touched'),
    ('plastic buttons', 'rubber buttons', REPLACE, 0, 'glass buttons'),
    ('a standard battery', 'a kinetic power source', REPLACE, 0, 'a solar panel'),
    ('a PDA-style touchscreen', 'physical buttons', REPLACE, 0, 'a PDA-style paper display'),
    ('recording a simpler command', 'recording an answer', REPLACE, 0, 'recording the user’s fingerprint'),
    ('changing the rule', 'changing all the individual items', REPLACE, 0, 'deleting the collection'),
    ('pressing volume-down twice', 'having a separate mute button', REPLACE, 0, 'pressing power twice'),
    ('processing metadata if the whole series cannot be processed in one go', 'processing the whole series in one go', CONTRAST, 0, 'processing only the video if the whole series cannot be processed in one go'),
    ('kinetic power', 'a battery', CONTRAST, 0, 'solar power'),
    ('using a clap if more people can clap than whistle', 'using a whistle', REPLACE, 0, 'using a tap if more people can clap than whistle'),
    ('one rechargeable battery if there is a space issue', 'two batteries', REPLACE, 1, 'three batteries'),
    ('using XHTML', 'using XML', CONTRAST, 0, 'using JSON'),
    ('using the additional functionality', 'using the buttons', REPLACE),
    ('using the numeric keypad', 'using the mute control', REPLACE),
    ('considering current technology', 'balancing features against cost', CONTRAST),
    ('wearing a lapel microphone', 'clipping the equipment to a belt', REPLACE),
    ('reviewing the prototype evaluation criteria', 'looking at the costs', REPLACE),
    ('buttons that light up', 'buttons with clear labels', REPLACE),
    ('a language-specific cover', 'interchangeable covers', REPLACE),
    ('responsibility for conceptual design', 'responsibility for the detailed design phase', REPLACE),
    ('using the hotspot measures', 'using the other measure', REPLACE),
    ('training the recognizer for a particular user', 'incorporating speech recognition', REPLACE),
    ('using a capacitor', 'using a transistor', REPLACE),
    ('the cat facing one direction', 'the cat facing the opposite direction', CONTRAST),
)

# Each tuple freezes one excerpt, its annotated options, and the planned edit.
# A reversal is used only when the source clearly favors one direction.
FRESH = (
    (('ES2016b.sync.690',), 'The speaker suggests using one multifunctional remote in place of five separate remotes.',
     'using one multifunctional remote', 'using five separate remotes', REPLACE, (1, 'five separate remotes', 'two separate remotes'), True),
    (('ES2003b.sync.332',), 'The speaker proposes putting two Rs on the remote in place of the full company name.',
     'putting two Rs on the remote', 'putting the full company name on the remote', REPLACE, (0, 'two Rs', 'two Ss'), True),
    (('TS3006c.sync.1,428',), 'The speaker favors a fancy look and feel over the current functional look and feel.',
     'a fancy look and feel', 'the current functional look and feel', REPLACE, (1, 'the current functional look and feel', 'the current minimalist look and feel'), True),
    (('ES2007b.sync.432',), 'The speaker says the numeric keypad can be used to select a channel directly instead of cycling up and down.',
     'selecting a channel directly with the numeric keypad', 'cycling up and down through channels', CONTRAST, (0, 'the numeric keypad', 'voice commands'), False),
    (('ES2012a.sync.217',), 'The speaker proposes concave buttons instead of buttons that stick up.',
     'concave buttons', 'buttons that stick up', REPLACE, (0, 'concave buttons', 'flat buttons'), True),
    (('IS1007c.sync.566',), 'Solar energy and a hand dynamo are among the alternatives discussed for powering the remote.',
     'using solar energy to power the remote', 'using a hand dynamo to power the remote', CONTRAST, (1, 'a hand dynamo', 'a fuel cell'), False),
    (('ES2005b.sync.640',), 'The speaker reports that corporate colors and a slogan are wanted in place of color choices.',
     'using corporate colors and a slogan', 'offering color choices', REPLACE, (0, 'a slogan', 'an audio jingle'), True),
    (('ES2004b.sync.328',), 'The speaker considers a small touch panel rather than a physical button.',
     'a small touch panel', 'a physical button', CONTRAST, (0, 'a small touch panel', 'a voice command'), False),
    (('ES2002b.sync.578',), 'The speaker proposes presenting market research instead of giving personal preferences.',
     'presenting market research', 'giving personal preferences', REPLACE, None, False),
    (('ES2006b.sync.104',), 'The speaker contrasts having an LCD with making the remote fashionable.',
     'having an LCD', 'making the remote fashionable', CONTRAST, None, False),
    (('TS3008c.sync.336',), 'The speaker proposes a teletext button in place of the power button.',
     'a teletext button', 'a power button', REPLACE, None, False),
    (('ES2005d.sync.397',), 'The speaker proposes meeting customer requirements instead of making the product environmentally safe.',
     'meeting customer requirements', 'making the product environmentally safe', REPLACE, None, False),
)


def assign(case, options, relation):
    return dict(case, options=list(options), relation=relation)


def freeze_speech():
    original = read(PREVIOUS/'speech_inputs.json')
    records = []
    for row, (a, b, relation, *edit) in zip(original['rows'], PREVIOUS_OPTIONS, strict=True):
        cases = []
        for case in row['cases']:
            options = [a, b]
            if case['variant'] == 'changed_option':
                i, phrase = edit
                options[i] = phrase
            variant = 'negated_replacement' if row['source'] == ['IS1006b.sync.1026'] else case['variant']
            cases.append(assign(dict(case, variant=variant), options, relation))
        records.append(dict(row, split='previous', cases=cases))

    path = SOURCE/'source/ami_public_manual_1.6.2.zip'
    assert sha256(path.read_bytes()).hexdigest() == original['source_sha256']
    with ZipFile(path) as archive:
        for ids, claim, a, b, relation, edit, reverse in FRESH:
            meeting = ids[-1].split('.')[0]
            assert meeting not in {r['meeting'] for r in original['rows']}
            source = segments(archive, meeting)
            speaker = source[ids[-1]][0]
            assert all(source[i][0] == speaker for i in ids)
            focal = utterance([w for i in ids for w in source[i][1]], speaker, ids[-1])
            query = dict(speaker=speaker, start=focal['start']-2, end=focal['end']+2)
            nearby = [utterance(words, who, ident) for ident, (who, words) in source.items()
                      if who != speaker and len(words) >= 6]
            candidates = [r for r in nearby if overlaps(r, query)]
            windows = [focal]
            if candidates:
                windows.append(min(candidates, key=lambda r: (abs(r['start']-focal['start']), r['id'])))

            def make(variant, content, options, kind, expected, current_query=query):
                case = dict(id=f'{focal["id"]}:{variant}', variant=variant, content=content, query=current_query,
                            windows=windows, expected_support=expected)
                return assign(case, options, kind)

            positive = edit is not None
            cases = [make('faithful' if positive else 'addition_or_no_choice', claim, (a,b), relation, positive)]
            if edit:
                i, orig, changed = edit
                options = [a, b]
                assert claim.count(orig) == options[i].count(orig) == 1, (meeting, orig, claim, options[i])
                options[i] = options[i].replace(orig, changed)
                cases.append(make('changed_option', claim.replace(orig, changed), options, relation, False))
                other = min(nearby, key=lambda r: (abs(r['start']-focal['start']), r['id']))
                cases.append(make('wrong_speaker', claim, (a,b), relation, False, dict(query, speaker=other['speaker'])))
            if reverse:
                cases.append(make('direction_reversal', f'The speaker favors {b} instead of {a}.', (b,a), REPLACE, False))
                cases.append(make('negated_relation', f'The speaker explicitly rejects {a} as a replacement for {b}.',
                                  (a,b), DENY, False))
            records.append(dict(meeting=meeting, source=list(ids), focal=focal, split='fresh', cases=cases))
    dump(RUN/'speech_inputs.json', dict(source_sha256=original['source_sha256'], rows=records))
    print('Speech excerpts:', len(records), 'queries:', sum(len(r['cases']) for r in records))


if __name__ == '__main__':
    RUN.mkdir(exist_ok=True, parents=True)
    freeze_speech()
