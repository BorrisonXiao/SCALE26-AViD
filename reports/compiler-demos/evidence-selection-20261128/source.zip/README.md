# Evidence selection with fixed scorers

The speech comparison uses 24 AMI recordings and 120 queries. The visual comparison uses eight AViD scenes and 16 queries. These small experiments measure how the evidence presented to a verifier affects its decisions.

## Speech

Each meeting contributes one annotated report, a paraphrase, and edits that change an option, change part of the context, or change the speaker. Each query provides the 35-second search interval. Pyannote diarization estimates anonymous speaker turns. The code proposes up to 12-second windows with a 4-second stride within those turns. The nearest three eligible windows are kept, ranked by distance from the query midpoint. Neither the claims nor the word annotations are used to set the window boundaries or rank them.

The main automatic condition assigns names by comparing diarization turns with the times of previously labeled speech, ending five seconds before the search interval. The diagnostic condition uses labeled words inside the interval to assign names. Another diagnostic disregards names. These comparisons use manually transcribed words read from the chosen windows. For the two named conditions, we also run Whisper base on the mono recording in the query interval and replace the words in the selected windows with its output. The candidate times and assigned speaker stay fixed for that comparison. Words are assigned to a window by their midpoint. An audio window can contain overlapping speakers.

DeepProbLog evaluates whether any one window meets the time and speaker constraints and supports both the whole claim and the relation between the specified options. In each window, DeBERTa scores whole-claim entailment and Qwen3-VL-8B-Instruct scores the option relation using a fixed multiple-choice prompt. Inference treats the scores as probabilities and assumes independence across window outcomes, even for overlapping windows. The highest-scoring window gives the same binary decisions on all 720 evaluations. The threshold is 0.50. A verdict of unsupported means support stays below threshold in the supplied evidence.

## Findings from the reviewed cases

- **Observed.** Annotated excerpts give 39/48 valid acceptances and 11/72 false acceptances. With diarized windows and manual words, names assigned from within the query interval give 14/48 valid acceptances and names assigned from earlier speech give 3/48. Earlier names leave 20/24 requested speakers with no eligible window at all. There are six complete target reports among all in-interval named candidates and five among the top three. Ignoring names yields 15 complete reports before ranking and four after. See `evaluation.json`, fields `speech.summary` and `speech.coverage`.
- **Observed.** Replacing manual words with Whisper words at the same boundaries gives 8/48 valid acceptances with names from the query interval and 2/48 with names from earlier speech. With query-interval names, nine valid queries lose support and three gain it. EN2005a shows a word substitution that lowers whole-claim support. In TS3008a the Whisper text within the chosen window stops at “line,” losing “width.” See `speech.rows[].queries[].results` and `speech.rows[].windows`.
- **Observed.** Nine of 24 changed-context controls receive support with the original annotated excerpt. On ES2007a, DeBERTa gives 0.632 to a claim with “thicker” when the speaker says “thinner.” Qwen's relation check is about the two quantities, which the edit preserves. Three wrong-speaker controls receive support when the speaker constraint is disabled. See `speech.by_variant` and `speech.rows`.
- **Inferred.** Missing windows and missing speaker assignments limit performance before the relation model can help. Improving assignment should be tested first with candidate times held fixed. Try claim-based retrieval and windows that span short turn gaps, with no more than three windows scored per query. Measure full-excerpt coverage and acceptance of valid claims alongside wrong-speaker controls on a held-out group.

## Video

Manually match each center-frame object to crops one second before or after when its identity is clear. Reuse the frozen center-frame scores and run the identical prompt and checkpoint on the 45 additional crops. Compare the center scores with averaging the three category probabilities across each object's available crops and selecting the one crop with the lowest “Neither or unclear” score. Each individual object keeps one categorical distribution, which exact inference uses wherever it occurs in a pair. Claim labels depend on the presence of at least two distinct marked objects in the requested category at the center frame.

- **Observed.** All three settings give the same 15/16 decisions. For distant runners, exact support rises from 0.697 to 0.997 with the least uncertain views. Smoke obscures the shields throughout the tested frames and the score stays between 0.002 and 0.011. See `evaluation.json`, fields `visual.rows[].results` and `visual.rows[].regions[].scores`.
- **Open question.** A video search can help if an additional frame does show the objects clearly. A follow-up should include clips where visibility actually changes and should verify any assignments with a shared time constraint when the claim calls for it.

## Replay from cached scores

Unzip the archive and run from its root using Python 3.12 and the project verification dependencies. The speech preparation and model scoring scripts are included for inspection. The replay uses the cached windows, crops and scores in the archive. Re-running the perception models also requires the original audio, frames, and pinned local model files.

```sh
PYTHONPATH=scripts PYTHONHASHSEED=0 python scripts/evaluate_evidence_selection.py
python - <<'PY'
import hashlib
import json
from pathlib import Path

root = Path("exp/probabilistic_verification/evidence_selection_20261128")
manifest = json.loads(Path("REPLAY_SHA256.json").read_text())
for name, expected in manifest.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
    print("Verified", name)
PY
```
