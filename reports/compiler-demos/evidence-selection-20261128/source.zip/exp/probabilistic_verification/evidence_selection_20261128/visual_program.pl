% Exact categorical evidence; internal unknown = neither supported nor refuted.
0.99999766063913031::status(o_0077992c2dd07923811f,supported); 8.8540331465474787e-07::status(o_0077992c2dd07923811f,refuted); 1.4539575551961634e-06::status(o_0077992c2dd07923811f,unknown).
0.99996695699724603::status(o_0110942a620524b2cb54,supported); 1.0895409873261196e-05::status(o_0110942a620524b2cb54,refuted); 2.2147592880807152e-05::status(o_0110942a620524b2cb54,unknown).
0.86999035199371444::status(o_035ef8a8274268977a78,supported); 0.0010556393817732349::status(o_035ef8a8274268977a78,refuted); 0.12895400862451228::status(o_035ef8a8274268977a78,unknown).
0.0072527257772495302::status(o_08e3014139f4747bd3b5,supported); 0.00022003620036650245::status(o_08e3014139f4747bd3b5,refuted); 0.99252723802238396::status(o_08e3014139f4747bd3b5,unknown).
0.00015126360204912616::status(o_0cb51d1b7766e40ec8e3,supported); 0.00067177790167186643::status(o_0cb51d1b7766e40ec8e3,refuted); 0.99917695849627908::status(o_0cb51d1b7766e40ec8e3,unknown).
0.93900851507933913::status(o_108d1756f4fda83847ee,supported); 0.00020676114090330318::status(o_108d1756f4fda83847ee,refuted); 0.060784723779757542::status(o_108d1756f4fda83847ee,unknown).
0.00092654705394887846::status(o_15c5bdb8bab4f383f2b4,supported); 0.00025189841119446635::status(o_15c5bdb8bab4f383f2b4,refuted); 0.99882155453485666::status(o_15c5bdb8bab4f383f2b4,unknown).
0.022702313895761439::status(o_16665718e95953f50900,supported); 0.15870277315476669::status(o_16665718e95953f50900,refuted); 0.81859491294947184::status(o_16665718e95953f50900,unknown).
0.98446540739465438::status(o_173c616f86ae6679553f,supported); 0.00019708112461295067::status(o_173c616f86ae6679553f,refuted); 0.015337511480732709::status(o_173c616f86ae6679553f,unknown).
0.99995107750197731::status(o_18cb0c45e9731232ad20,supported); 3.5247893382378775e-06::status(o_18cb0c45e9731232ad20,refuted); 4.5397708684510821e-05::status(o_18cb0c45e9731232ad20,unknown).
0.99985375852844061::status(o_197ef76e6781d94cf259,supported); 1.878953452120089e-06::status(o_197ef76e6781d94cf259,refuted); 0.00014436251810732667::status(o_197ef76e6781d94cf259,unknown).
0.99988098051293117::status(o_1a7c1118e49b0e4029d6,supported); 2.2919274166924988e-05::status(o_1a7c1118e49b0e4029d6,refuted); 9.6100212901865006e-05::status(o_1a7c1118e49b0e4029d6,unknown).
0.00041289431108849141::status(o_1ca0bd4332f923ee499d,supported); 0.016230945401086085::status(o_1ca0bd4332f923ee499d,refuted); 0.98335616028782535::status(o_1ca0bd4332f923ee499d,unknown).
0.00015126360204912616::status(o_20a9e4a206b7079a7d14,supported); 0.00067177790167186643::status(o_20a9e4a206b7079a7d14,refuted); 0.99917695849627908::status(o_20a9e4a206b7079a7d14,unknown).
0.99827045427729555::status(o_245d75c35aeefaa09ec4,supported); 3.780128048710888e-05::status(o_245d75c35aeefaa09ec4,refuted); 0.001691744442217345::status(o_245d75c35aeefaa09ec4,unknown).
0.8764569784702132::status(o_25ad875bbee7cacd6c5f,supported); 0.0011907525153204044::status(o_25ad875bbee7cacd6c5f,refuted); 0.12235226901446636::status(o_25ad875bbee7cacd6c5f,unknown).
0.99907571739511336::status(o_27a6edf84dec1d3edee9,supported); 3.0360277327016936e-05::status(o_27a6edf84dec1d3edee9,refuted); 0.00089392232755960499::status(o_27a6edf84dec1d3edee9,unknown).
0.0030641257988218611::status(o_2a165be752498d6e38fe,supported); 0.00045773833686497912::status(o_2a165be752498d6e38fe,refuted); 0.99647813586431333::status(o_2a165be752498d6e38fe,unknown).
0.99996695699724603::status(o_2dac2e5b602846cc1458,supported); 1.0895409873261196e-05::status(o_2dac2e5b602846cc1458,refuted); 2.2147592880807152e-05::status(o_2dac2e5b602846cc1458,unknown).
1.010883089635087e-06::status(o_3347e9b71f63dc4370c1,supported); 0.99962145569095273::status(o_3347e9b71f63dc4370c1,refuted); 0.00037753342595766513::status(o_3347e9b71f63dc4370c1,unknown).
0.99989764748784893::status(o_33625c58fdb67d6debb6,supported); 1.0700811956182508e-05::status(o_33625c58fdb67d6debb6,refuted); 9.1651700194944635e-05::status(o_33625c58fdb67d6debb6,unknown).
0.014536130428962984::status(o_35c816db24007efae70c,supported); 0.49516893591683031::status(o_35c816db24007efae70c,refuted); 0.49029493365420668::status(o_35c816db24007efae70c,unknown).
0.025386456604970027::status(o_36ace0521f337d23a149,supported); 1.2934561443631332e-05::status(o_36ace0521f337d23a149,refuted); 0.97460060883358635::status(o_36ace0521f337d23a149,unknown).
6.6083035276998767e-06::status(o_3758b2c1958632072a84,supported); 0.99994864549030349::status(o_3758b2c1958632072a84,refuted); 4.4746206168765391e-05::status(o_3758b2c1958632072a84,unknown).
0.99995107750197731::status(o_388f6261bcb3fc52f9b2,supported); 3.5247893382378775e-06::status(o_388f6261bcb3fc52f9b2,refuted); 4.5397708684510821e-05::status(o_388f6261bcb3fc52f9b2,unknown).
0.98123011024925977::status(o_3e49668aa5250ea5d329,supported); 4.9146010576566414e-06::status(o_3e49668aa5250ea5d329,refuted); 0.018764975149682679::status(o_3e49668aa5250ea5d329,unknown).
0.25000152074821363::status(o_3e4f49b9aa5c69df4678,supported); 0.6916609475738994::status(o_3e4f49b9aa5c69df4678,refuted); 0.058337531677887119::status(o_3e4f49b9aa5c69df4678,unknown).
2.7175559872138484e-06::status(o_3e54cf53a07ea34fa31c,supported); 0.99970278696179049::status(o_3e54cf53a07ea34fa31c,refuted); 0.00029449548222246555::status(o_3e54cf53a07ea34fa31c,unknown).
0.024733827954867317::status(o_3ffe1649755bc66186d6,supported); 0.31580827921852989::status(o_3ffe1649755bc66186d6,refuted); 0.65945789282660283::status(o_3ffe1649755bc66186d6,unknown).
1.8719338336741049e-06::status(o_43c82a9fe913bca202f4,supported); 0.99999290280849007::status(o_43c82a9fe913bca202f4,refuted); 5.2252576762988611e-06::status(o_43c82a9fe913bca202f4,unknown).
4.7825575023665984e-06::status(o_44b489bc95da13879422,supported); 0.99709277670514951::status(o_44b489bc95da13879422,refuted); 0.0029024407373482051::status(o_44b489bc95da13879422,unknown).
0.00015126360204912616::status(o_46dba06b165d57aa4621,supported); 0.00067177790167186643::status(o_46dba06b165d57aa4621,refuted); 0.99917695849627908::status(o_46dba06b165d57aa4621,unknown).
0.00030251015302320568::status(o_481587c2751e7e967b7f,supported); 0.014085442391110942::status(o_481587c2751e7e967b7f,refuted); 0.98561204745586584::status(o_481587c2751e7e967b7f,unknown).
0.99998488566934807::status(o_48a66537dd5f172751a8,supported); 4.1409713296408536e-06::status(o_48a66537dd5f172751a8,refuted); 1.0973359322300011e-05::status(o_48a66537dd5f172751a8,unknown).
0.97950576308347281::status(o_4a854b906931f569c802,supported); 1.2735289872338148e-05::status(o_4a854b906931f569c802,refuted); 0.020481501626654873::status(o_4a854b906931f569c802,unknown).
0.99999932396004065::status(o_4b52a89314c504da16a7,supported); 2.040079441715807e-07::status(o_4b52a89314c504da16a7,refuted); 4.7203201506238835e-07::status(o_4b52a89314c504da16a7,unknown).
5.4633950241361201e-07::status(o_4c964da788666ffe8ef5,supported); 8.1960123587964296e-07::status(o_4c964da788666ffe8ef5,refuted); 0.9999986340592617::status(o_4c964da788666ffe8ef5,unknown).
0.13226882558858832::status(o_51c044b6f7b9de127f83,supported); 0.59341494174536491::status(o_51c044b6f7b9de127f83,refuted); 0.27431623266604688::status(o_51c044b6f7b9de127f83,unknown).
0.99999864420589524::status(o_59a964dd043e27dc26cb,supported); 4.7392304816839078e-07::status(o_59a964dd043e27dc26cb,refuted); 8.8187105657447131e-07::status(o_59a964dd043e27dc26cb,unknown).
0.99911293867548534::status(o_633f39be7c02bb1fae9c,supported); 5.8836794648953013e-06::status(o_633f39be7c02bb1fae9c,refuted); 0.00088117764504974921::status(o_633f39be7c02bb1fae9c,unknown).
0.01223779853186327::status(o_6546f5207e0ce48d2eae,supported); 0.00012188449802538753::status(o_6546f5207e0ce48d2eae,refuted); 0.98764031697011123::status(o_6546f5207e0ce48d2eae,unknown).
0.99999822036673092::status(o_6643bd77329be59bf5aa,supported); 8.8376730496136608e-07::status(o_6643bd77329be59bf5aa,refuted); 8.9586596409473318e-07::status(o_6643bd77329be59bf5aa,unknown).
0.99997815699947501::status(o_6bda11af09b135c6acc4,supported); 2.7138150209336167e-06::status(o_6bda11af09b135c6acc4,refuted); 1.9129185504069502e-05::status(o_6bda11af09b135c6acc4,unknown).
0.99999678606816544::status(o_6ca7bfd28ca2c43e66bb,supported); 1.2838112919065826e-06::status(o_6ca7bfd28ca2c43e66bb,refuted); 1.9301205427395543e-06::status(o_6ca7bfd28ca2c43e66bb,unknown).
0.00041289431108849141::status(o_702aca30bf7fa48f7baa,supported); 0.016230945401086085::status(o_702aca30bf7fa48f7baa,refuted); 0.98335616028782535::status(o_702aca30bf7fa48f7baa,unknown).
6.6083035276998767e-06::status(o_70790248370857c30d70,supported); 0.99994864549030349::status(o_70790248370857c30d70,refuted); 4.4746206168765391e-05::status(o_70790248370857c30d70,unknown).
0.99996681408624122::status(o_7544502bb23b229499a0,supported); 3.3577527695711081e-06::status(o_7544502bb23b229499a0,refuted); 2.9828160989165669e-05::status(o_7544502bb23b229499a0,unknown).
1.3598552396390207e-05::status(o_85cc797ecc72b84f0ddf,supported); 0.99990007655255708::status(o_85cc797ecc72b84f0ddf,refuted); 8.6324895046553375e-05::status(o_85cc797ecc72b84f0ddf,unknown).
1.8719338336741049e-06::status(o_86e076c2592528498df6,supported); 0.99999290280849007::status(o_86e076c2592528498df6,refuted); 5.2252576762988611e-06::status(o_86e076c2592528498df6,unknown).
2.7385307039413592e-06::status(o_8729e55094dfcd9ab67f,supported); 0.99871290537348534::status(o_8729e55094dfcd9ab67f,refuted); 0.0012843560958108306::status(o_8729e55094dfcd9ab67f,unknown).
0.99997752041714616::status(o_873f2b77559bca4c1463,supported); 5.1152507492739168e-06::status(o_873f2b77559bca4c1463,refuted); 1.7364332104503767e-05::status(o_873f2b77559bca4c1463,unknown).
0.99991123155128925::status(o_90ffc6d5a99f7097f9c3,supported); 3.2943785074807338e-06::status(o_90ffc6d5a99f7097f9c3,refuted); 8.5474070203288158e-05::status(o_90ffc6d5a99f7097f9c3,unknown).
0.97303489343600269::status(o_929e3d634609adcd1640,supported); 0.00064830207596652486::status(o_929e3d634609adcd1640,refuted); 0.026316804488030737::status(o_929e3d634609adcd1640,unknown).
0.7099108872917107::status(o_94f5d6de366d5af262fc,supported); 1.6979460463061213e-05::status(o_94f5d6de366d5af262fc,refuted); 0.29007213324782616::status(o_94f5d6de366d5af262fc,unknown).
0.99999672839110687::status(o_9642216e7b21e53e3be9,supported); 6.8907277187088689e-07::status(o_9642216e7b21e53e3be9,refuted); 2.5825361212444672e-06::status(o_9642216e7b21e53e3be9,unknown).
0.99999782738784748::status(o_9cd2e05f628093dab0d3,supported); 6.4285621378782958e-07::status(o_9cd2e05f628093dab0d3,refuted); 1.5297559387018153e-06::status(o_9cd2e05f628093dab0d3,unknown).
0.99994701833820265::status(o_9f5cf0ec083ea2d6c9ad,supported); 4.836416226010334e-06::status(o_9f5cf0ec083ea2d6c9ad,refuted); 4.8145245571322711e-05::status(o_9f5cf0ec083ea2d6c9ad,unknown).
0.99994589034868486::status(o_a0e8aa7dabb39f9cf972,supported); 2.1140151870417085e-06::status(o_a0e8aa7dabb39f9cf972,refuted); 5.1995636128011824e-05::status(o_a0e8aa7dabb39f9cf972,unknown).
0.99792472984941272::status(o_a48ef75b39de6af3268c,supported); 2.2615179348301157e-05::status(o_a48ef75b39de6af3268c,refuted); 0.0020526549712390689::status(o_a48ef75b39de6af3268c,unknown).
0.99995107750197731::status(o_a6dbad0ba4ea67bb7f8c,supported); 3.5247893382378775e-06::status(o_a6dbad0ba4ea67bb7f8c,refuted); 4.5397708684510821e-05::status(o_a6dbad0ba4ea67bb7f8c,unknown).
0.9999990604489617::status(o_a787c08c410b9eedad23,supported); 3.2739419493243186e-07::status(o_a787c08c410b9eedad23,refuted); 6.1215684330632182e-07::status(o_a787c08c410b9eedad23,unknown).
5.4633950241361201e-07::status(o_ab2e10a770ac43eb37ec,supported); 8.1960123587964296e-07::status(o_ab2e10a770ac43eb37ec,refuted); 0.9999986340592617::status(o_ab2e10a770ac43eb37ec,unknown).
2.7175559872138484e-06::status(o_abdd61eb753c0d21cdc5,supported); 0.99970278696179049::status(o_abdd61eb753c0d21cdc5,refuted); 0.00029449548222246555::status(o_abdd61eb753c0d21cdc5,unknown).
0.99996202367407994::status(o_ae7d33e5cae5fce9a0fc,supported); 2.4139151039876626e-06::status(o_ae7d33e5cae5fce9a0fc,refuted); 3.556241081604066e-05::status(o_ae7d33e5cae5fce9a0fc,unknown).
0.0016759758572304985::status(o_b12445cf14954ec4d967,supported); 0.00046550287250007297::status(o_b12445cf14954ec4d967,refuted); 0.99785852127026931::status(o_b12445cf14954ec4d967,unknown).
0.0016759758572304985::status(o_b63d70c3222fdf4e1bcd,supported); 0.00046550287250007297::status(o_b63d70c3222fdf4e1bcd,refuted); 0.99785852127026931::status(o_b63d70c3222fdf4e1bcd,unknown).
0.99999678606816544::status(o_b65da667539233f33625,supported); 1.2838112919065826e-06::status(o_b65da667539233f33625,refuted); 1.9301205427395543e-06::status(o_b65da667539233f33625,unknown).
0.83968355348842338::status(o_ba3583c2b9aa6cf77b0a,supported); 3.875883607054637e-05::status(o_ba3583c2b9aa6cf77b0a,refuted); 0.16027768767550615::status(o_ba3583c2b9aa6cf77b0a,unknown).
0.99750280214079501::status(o_bb86839361e2e1b1eb9c,supported); 6.6299059412779302e-06::status(o_bb86839361e2e1b1eb9c,refuted); 0.0024905679532637556::status(o_bb86839361e2e1b1eb9c,unknown).
0.69959869231869787::status(o_c9643773605f271664d9,supported); 0.00043392339591235738::status(o_c9643773605f271664d9,refuted); 0.29996738428538972::status(o_c9643773605f271664d9,unknown).
0.83407188630522877::status(o_ca71854d54bea8ad5bb7,supported); 2.6155845746732833e-05::status(o_ca71854d54bea8ad5bb7,refuted); 0.16590195784902448::status(o_ca71854d54bea8ad5bb7,unknown).
0.7963827132774377::status(o_cad644316ed5bbedc01f,supported); 1.1243452706186568e-05::status(o_cad644316ed5bbedc01f,refuted); 0.2036060432698561::status(o_cad644316ed5bbedc01f,unknown).
0.9999973280865867::status(o_d6801a16f4b4111c432b,supported); 7.0374374763622552e-07::status(o_d6801a16f4b4111c432b,refuted); 1.9681696656431377e-06::status(o_d6801a16f4b4111c432b,unknown).
0.99985297200382228::status(o_d7faa4127e1a53f57c69,supported); 6.1134106074153932e-06::status(o_d7faa4127e1a53f57c69,refuted); 0.00014091458557021288::status(o_d7faa4127e1a53f57c69,unknown).
5.4633950241361201e-07::status(o_d88294be4a96dfc6867d,supported); 8.1960123587964296e-07::status(o_d88294be4a96dfc6867d,refuted); 0.9999986340592617::status(o_d88294be4a96dfc6867d,unknown).
0.99999822036673092::status(o_dbbe07b9d478ad551d5d,supported); 8.8376730496136608e-07::status(o_dbbe07b9d478ad551d5d,refuted); 8.9586596409473318e-07::status(o_dbbe07b9d478ad551d5d,unknown).
0.0026429969159723942::status(o_e1f0f86cf3f435212b96,supported); 2.0657730964523812e-05::status(o_e1f0f86cf3f435212b96,refuted); 0.99733634535306304::status(o_e1f0f86cf3f435212b96,unknown).
1.8719338336741049e-06::status(o_e23d3c31812a001540ca,supported); 0.99999290280849007::status(o_e23d3c31812a001540ca,refuted); 5.2252576762988611e-06::status(o_e23d3c31812a001540ca,unknown).
0.99991240806544468::status(o_e2e0510e6c9fbce7ab72,supported); 1.9361864969378769e-05::status(o_e2e0510e6c9fbce7ab72,refuted); 6.8230069585920077e-05::status(o_e2e0510e6c9fbce7ab72,unknown).
0.048129916293967658::status(o_e32b3c7687fd35bd5de2,supported); 5.2113919227388523e-06::status(o_e32b3c7687fd35bd5de2,refuted); 0.95186487231410966::status(o_e32b3c7687fd35bd5de2,unknown).
0.99998729065413894::status(o_eb1c97946ee94be80798,supported); 1.647538523820949e-06::status(o_eb1c97946ee94be80798,refuted); 1.1061807337352302e-05::status(o_eb1c97946ee94be80798,unknown).
0.27873530649242173::status(o_ebfe58364e6a1aeccac3,supported); 0.00051799488248431395::status(o_ebfe58364e6a1aeccac3,refuted); 0.72074669862509388::status(o_ebfe58364e6a1aeccac3,unknown).
0.99996643854799749::status(o_ec97b5b8b60b39959730,supported); 4.402827719809577e-06::status(o_ec97b5b8b60b39959730,refuted); 2.9158624282732836e-05::status(o_ec97b5b8b60b39959730,unknown).
0.69959869231869787::status(o_efed71f20d65d95692a0,supported); 0.00043392339591235738::status(o_efed71f20d65d95692a0,refuted); 0.29996738428538972::status(o_efed71f20d65d95692a0,unknown).
0.99996979526977436::status(o_f2a8269a08096cc41128,supported); 6.9744985363340567e-06::status(o_f2a8269a08096cc41128,refuted); 2.3230231689214993e-05::status(o_f2a8269a08096cc41128,unknown).
0.98524057440712043::status(o_f36afea2013bce9ea56d,supported); 6.7876293092214099e-05::status(o_f36afea2013bce9ea56d,refuted); 0.014691549299787394::status(o_f36afea2013bce9ea56d,unknown).
2.1204479499420466e-06::status(o_f4aecd5e996e881b2cc3,supported); 0.49988543497528792::status(o_f4aecd5e996e881b2cc3,refuted); 0.50011244457676218::status(o_f4aecd5e996e881b2cc3,unknown).
0.98878705684283796::status(o_f5a61990bfb414022dc0,supported); 4.470313781851859e-05::status(o_f5a61990bfb414022dc0,refuted); 0.0111682400193435::status(o_f5a61990bfb414022dc0,unknown).
0.024733827954867317::status(o_f87dd23eda457eaac6b4,supported); 0.31580827921852989::status(o_f87dd23eda457eaac6b4,refuted); 0.65945789282660283::status(o_f87dd23eda457eaac6b4,unknown).
0.90245968895728024::status(o_f98bb31a8cb169f5bf80,supported); 1.0593261219545221e-05::status(o_f98bb31a8cb169f5bf80,refuted); 0.097529717781500352::status(o_f98bb31a8cb169f5bf80,unknown).
0.95570379457323684::status(o_fa2ef3b59a4dcf25c9a5,supported); 7.5384339888324976e-06::status(o_fa2ef3b59a4dcf25c9a5,refuted); 0.044288666992774395::status(o_fa2ef3b59a4dcf25c9a5,unknown).
0.99999682905549159::status(o_fbf720997f233ed04793,supported); 1.0034698809021009e-06::status(o_fbf720997f233ed04793,refuted); 2.1674746275261603e-06::status(o_fbf720997f233ed04793,unknown).
0.93507270847804391::status(o_fd287189348bd1bc6e3a,supported); 0.06356955416396895::status(o_fd287189348bd1bc6e3a,refuted); 0.0013577373579871015::status(o_fd287189348bd1bc6e3a,unknown).
node(n2,supported) :- status(o_d6801a16f4b4111c432b,supported).
node(n2,refuted) :- status(o_d6801a16f4b4111c432b,refuted).
node(n2,unknown) :- status(o_d6801a16f4b4111c432b,unknown).
node(n3,supported) :- status(o_035ef8a8274268977a78,supported).
node(n3,refuted) :- status(o_035ef8a8274268977a78,refuted).
node(n3,unknown) :- status(o_035ef8a8274268977a78,unknown).
node(n1,supported) :- node(n2,supported), node(n3,supported).
node(n1,refuted) :- node(n2,refuted).
node(n1,refuted) :- node(n3,refuted).
node(n1,unknown) :- \+ node(n1,supported), \+ node(n1,refuted).
node(n5,supported) :- status(o_0110942a620524b2cb54,supported).
node(n5,refuted) :- status(o_0110942a620524b2cb54,refuted).
node(n5,unknown) :- status(o_0110942a620524b2cb54,unknown).
node(n4,supported) :- node(n2,supported), node(n5,supported).
node(n4,refuted) :- node(n2,refuted).
node(n4,refuted) :- node(n5,refuted).
node(n4,unknown) :- \+ node(n4,supported), \+ node(n4,refuted).
node(n7,supported) :- status(o_8729e55094dfcd9ab67f,supported).
node(n7,refuted) :- status(o_8729e55094dfcd9ab67f,refuted).
node(n7,unknown) :- status(o_8729e55094dfcd9ab67f,unknown).
node(n6,supported) :- node(n2,supported), node(n7,supported).
node(n6,refuted) :- node(n2,refuted).
node(n6,refuted) :- node(n7,refuted).
node(n6,unknown) :- \+ node(n6,supported), \+ node(n6,refuted).
node(n8,supported) :- node(n3,supported), node(n5,supported).
node(n8,refuted) :- node(n3,refuted).
node(n8,refuted) :- node(n5,refuted).
node(n8,unknown) :- \+ node(n8,supported), \+ node(n8,refuted).
node(n9,supported) :- node(n3,supported), node(n7,supported).
node(n9,refuted) :- node(n3,refuted).
node(n9,refuted) :- node(n7,refuted).
node(n9,unknown) :- \+ node(n9,supported), \+ node(n9,refuted).
node(n10,supported) :- node(n5,supported), node(n7,supported).
node(n10,refuted) :- node(n5,refuted).
node(n10,refuted) :- node(n7,refuted).
node(n10,unknown) :- \+ node(n10,supported), \+ node(n10,refuted).
node(n0,refuted) :- node(n1,refuted), node(n4,refuted), node(n6,refuted), node(n8,refuted), node(n9,refuted), node(n10,refuted).
node(n0,supported) :- node(n1,supported).
node(n0,supported) :- node(n4,supported).
node(n0,supported) :- node(n6,supported).
node(n0,supported) :- node(n8,supported).
node(n0,supported) :- node(n9,supported).
node(n0,supported) :- node(n10,supported).
node(n0,unknown) :- \+ node(n0,supported), \+ node(n0,refuted).
verdict(c_d6801a16f4b4111c,supported) :- node(n0,supported).
query(verdict(c_d6801a16f4b4111c,supported)).
verdict(c_d6801a16f4b4111c,refuted) :- node(n0,refuted).
query(verdict(c_d6801a16f4b4111c,refuted)).
verdict(c_d6801a16f4b4111c,unknown) :- node(n0,unknown).
query(verdict(c_d6801a16f4b4111c,unknown)).
node(n13,supported) :- status(o_9cd2e05f628093dab0d3,supported).
node(n13,refuted) :- status(o_9cd2e05f628093dab0d3,refuted).
node(n13,unknown) :- status(o_9cd2e05f628093dab0d3,unknown).
node(n14,supported) :- status(o_25ad875bbee7cacd6c5f,supported).
node(n14,refuted) :- status(o_25ad875bbee7cacd6c5f,refuted).
node(n14,unknown) :- status(o_25ad875bbee7cacd6c5f,unknown).
node(n12,supported) :- node(n13,supported), node(n14,supported).
node(n12,refuted) :- node(n13,refuted).
node(n12,refuted) :- node(n14,refuted).
node(n12,unknown) :- \+ node(n12,supported), \+ node(n12,refuted).
node(n16,supported) :- status(o_33625c58fdb67d6debb6,supported).
node(n16,refuted) :- status(o_33625c58fdb67d6debb6,refuted).
node(n16,unknown) :- status(o_33625c58fdb67d6debb6,unknown).
node(n15,supported) :- node(n13,supported), node(n16,supported).
node(n15,refuted) :- node(n13,refuted).
node(n15,refuted) :- node(n16,refuted).
node(n15,unknown) :- \+ node(n15,supported), \+ node(n15,refuted).
node(n18,supported) :- status(o_44b489bc95da13879422,supported).
node(n18,refuted) :- status(o_44b489bc95da13879422,refuted).
node(n18,unknown) :- status(o_44b489bc95da13879422,unknown).
node(n17,supported) :- node(n13,supported), node(n18,supported).
node(n17,refuted) :- node(n13,refuted).
node(n17,refuted) :- node(n18,refuted).
node(n17,unknown) :- \+ node(n17,supported), \+ node(n17,refuted).
node(n19,supported) :- node(n14,supported), node(n16,supported).
node(n19,refuted) :- node(n14,refuted).
node(n19,refuted) :- node(n16,refuted).
node(n19,unknown) :- \+ node(n19,supported), \+ node(n19,refuted).
node(n20,supported) :- node(n14,supported), node(n18,supported).
node(n20,refuted) :- node(n14,refuted).
node(n20,refuted) :- node(n18,refuted).
node(n20,unknown) :- \+ node(n20,supported), \+ node(n20,refuted).
node(n21,supported) :- node(n16,supported), node(n18,supported).
node(n21,refuted) :- node(n16,refuted).
node(n21,refuted) :- node(n18,refuted).
node(n21,unknown) :- \+ node(n21,supported), \+ node(n21,refuted).
node(n11,refuted) :- node(n12,refuted), node(n15,refuted), node(n17,refuted), node(n19,refuted), node(n20,refuted), node(n21,refuted).
node(n11,supported) :- node(n12,supported).
node(n11,supported) :- node(n15,supported).
node(n11,supported) :- node(n17,supported).
node(n11,supported) :- node(n19,supported).
node(n11,supported) :- node(n20,supported).
node(n11,supported) :- node(n21,supported).
node(n11,unknown) :- \+ node(n11,supported), \+ node(n11,refuted).
verdict(c_9cd2e05f628093da,supported) :- node(n11,supported).
query(verdict(c_9cd2e05f628093da,supported)).
verdict(c_9cd2e05f628093da,refuted) :- node(n11,refuted).
query(verdict(c_9cd2e05f628093da,refuted)).
verdict(c_9cd2e05f628093da,unknown) :- node(n11,unknown).
query(verdict(c_9cd2e05f628093da,unknown)).
node(n24,supported) :- status(o_4b52a89314c504da16a7,supported).
node(n24,refuted) :- status(o_4b52a89314c504da16a7,refuted).
node(n24,unknown) :- status(o_4b52a89314c504da16a7,unknown).
node(n25,supported) :- status(o_929e3d634609adcd1640,supported).
node(n25,refuted) :- status(o_929e3d634609adcd1640,refuted).
node(n25,unknown) :- status(o_929e3d634609adcd1640,unknown).
node(n23,supported) :- node(n24,supported), node(n25,supported).
node(n23,refuted) :- node(n24,refuted).
node(n23,refuted) :- node(n25,refuted).
node(n23,unknown) :- \+ node(n23,supported), \+ node(n23,refuted).
node(n27,supported) :- status(o_2dac2e5b602846cc1458,supported).
node(n27,refuted) :- status(o_2dac2e5b602846cc1458,refuted).
node(n27,unknown) :- status(o_2dac2e5b602846cc1458,unknown).
node(n26,supported) :- node(n24,supported), node(n27,supported).
node(n26,refuted) :- node(n24,refuted).
node(n26,refuted) :- node(n27,refuted).
node(n26,unknown) :- \+ node(n26,supported), \+ node(n26,refuted).
node(n29,supported) :- status(o_3347e9b71f63dc4370c1,supported).
node(n29,refuted) :- status(o_3347e9b71f63dc4370c1,refuted).
node(n29,unknown) :- status(o_3347e9b71f63dc4370c1,unknown).
node(n28,supported) :- node(n24,supported), node(n29,supported).
node(n28,refuted) :- node(n24,refuted).
node(n28,refuted) :- node(n29,refuted).
node(n28,unknown) :- \+ node(n28,supported), \+ node(n28,refuted).
node(n30,supported) :- node(n25,supported), node(n27,supported).
node(n30,refuted) :- node(n25,refuted).
node(n30,refuted) :- node(n27,refuted).
node(n30,unknown) :- \+ node(n30,supported), \+ node(n30,refuted).
node(n31,supported) :- node(n25,supported), node(n29,supported).
node(n31,refuted) :- node(n25,refuted).
node(n31,refuted) :- node(n29,refuted).
node(n31,unknown) :- \+ node(n31,supported), \+ node(n31,refuted).
node(n32,supported) :- node(n27,supported), node(n29,supported).
node(n32,refuted) :- node(n27,refuted).
node(n32,refuted) :- node(n29,refuted).
node(n32,unknown) :- \+ node(n32,supported), \+ node(n32,refuted).
node(n22,refuted) :- node(n23,refuted), node(n26,refuted), node(n28,refuted), node(n30,refuted), node(n31,refuted), node(n32,refuted).
node(n22,supported) :- node(n23,supported).
node(n22,supported) :- node(n26,supported).
node(n22,supported) :- node(n28,supported).
node(n22,supported) :- node(n30,supported).
node(n22,supported) :- node(n31,supported).
node(n22,supported) :- node(n32,supported).
node(n22,unknown) :- \+ node(n22,supported), \+ node(n22,refuted).
verdict(c_4b52a89314c504da,supported) :- node(n22,supported).
query(verdict(c_4b52a89314c504da,supported)).
verdict(c_4b52a89314c504da,refuted) :- node(n22,refuted).
query(verdict(c_4b52a89314c504da,refuted)).
verdict(c_4b52a89314c504da,unknown) :- node(n22,unknown).
query(verdict(c_4b52a89314c504da,unknown)).
node(n35,supported) :- node(n2,refuted).
node(n35,refuted) :- node(n2,supported).
node(n35,unknown) :- \+ node(n35,supported), \+ node(n35,refuted).
node(n36,supported) :- node(n3,refuted).
node(n36,refuted) :- node(n3,supported).
node(n36,unknown) :- \+ node(n36,supported), \+ node(n36,refuted).
node(n34,supported) :- node(n35,supported), node(n36,supported).
node(n34,refuted) :- node(n35,refuted).
node(n34,refuted) :- node(n36,refuted).
node(n34,unknown) :- \+ node(n34,supported), \+ node(n34,refuted).
node(n38,supported) :- node(n5,refuted).
node(n38,refuted) :- node(n5,supported).
node(n38,unknown) :- \+ node(n38,supported), \+ node(n38,refuted).
node(n37,supported) :- node(n35,supported), node(n38,supported).
node(n37,refuted) :- node(n35,refuted).
node(n37,refuted) :- node(n38,refuted).
node(n37,unknown) :- \+ node(n37,supported), \+ node(n37,refuted).
node(n40,supported) :- node(n7,refuted).
node(n40,refuted) :- node(n7,supported).
node(n40,unknown) :- \+ node(n40,supported), \+ node(n40,refuted).
node(n39,supported) :- node(n35,supported), node(n40,supported).
node(n39,refuted) :- node(n35,refuted).
node(n39,refuted) :- node(n40,refuted).
node(n39,unknown) :- \+ node(n39,supported), \+ node(n39,refuted).
node(n41,supported) :- node(n36,supported), node(n38,supported).
node(n41,refuted) :- node(n36,refuted).
node(n41,refuted) :- node(n38,refuted).
node(n41,unknown) :- \+ node(n41,supported), \+ node(n41,refuted).
node(n42,supported) :- node(n36,supported), node(n40,supported).
node(n42,refuted) :- node(n36,refuted).
node(n42,refuted) :- node(n40,refuted).
node(n42,unknown) :- \+ node(n42,supported), \+ node(n42,refuted).
node(n43,supported) :- node(n38,supported), node(n40,supported).
node(n43,refuted) :- node(n38,refuted).
node(n43,refuted) :- node(n40,refuted).
node(n43,unknown) :- \+ node(n43,supported), \+ node(n43,refuted).
node(n33,refuted) :- node(n34,refuted), node(n37,refuted), node(n39,refuted), node(n41,refuted), node(n42,refuted), node(n43,refuted).
node(n33,supported) :- node(n34,supported).
node(n33,supported) :- node(n37,supported).
node(n33,supported) :- node(n39,supported).
node(n33,supported) :- node(n41,supported).
node(n33,supported) :- node(n42,supported).
node(n33,supported) :- node(n43,supported).
node(n33,unknown) :- \+ node(n33,supported), \+ node(n33,refuted).
verdict(c_035ef8a827426897,supported) :- node(n33,supported).
query(verdict(c_035ef8a827426897,supported)).
verdict(c_035ef8a827426897,refuted) :- node(n33,refuted).
query(verdict(c_035ef8a827426897,refuted)).
verdict(c_035ef8a827426897,unknown) :- node(n33,unknown).
query(verdict(c_035ef8a827426897,unknown)).
node(n46,supported) :- node(n13,refuted).
node(n46,refuted) :- node(n13,supported).
node(n46,unknown) :- \+ node(n46,supported), \+ node(n46,refuted).
node(n47,supported) :- node(n14,refuted).
node(n47,refuted) :- node(n14,supported).
node(n47,unknown) :- \+ node(n47,supported), \+ node(n47,refuted).
node(n45,supported) :- node(n46,supported), node(n47,supported).
node(n45,refuted) :- node(n46,refuted).
node(n45,refuted) :- node(n47,refuted).
node(n45,unknown) :- \+ node(n45,supported), \+ node(n45,refuted).
node(n49,supported) :- node(n16,refuted).
node(n49,refuted) :- node(n16,supported).
node(n49,unknown) :- \+ node(n49,supported), \+ node(n49,refuted).
node(n48,supported) :- node(n46,supported), node(n49,supported).
node(n48,refuted) :- node(n46,refuted).
node(n48,refuted) :- node(n49,refuted).
node(n48,unknown) :- \+ node(n48,supported), \+ node(n48,refuted).
node(n51,supported) :- node(n18,refuted).
node(n51,refuted) :- node(n18,supported).
node(n51,unknown) :- \+ node(n51,supported), \+ node(n51,refuted).
node(n50,supported) :- node(n46,supported), node(n51,supported).
node(n50,refuted) :- node(n46,refuted).
node(n50,refuted) :- node(n51,refuted).
node(n50,unknown) :- \+ node(n50,supported), \+ node(n50,refuted).
node(n52,supported) :- node(n47,supported), node(n49,supported).
node(n52,refuted) :- node(n47,refuted).
node(n52,refuted) :- node(n49,refuted).
node(n52,unknown) :- \+ node(n52,supported), \+ node(n52,refuted).
node(n53,supported) :- node(n47,supported), node(n51,supported).
node(n53,refuted) :- node(n47,refuted).
node(n53,refuted) :- node(n51,refuted).
node(n53,unknown) :- \+ node(n53,supported), \+ node(n53,refuted).
node(n54,supported) :- node(n49,supported), node(n51,supported).
node(n54,refuted) :- node(n49,refuted).
node(n54,refuted) :- node(n51,refuted).
node(n54,unknown) :- \+ node(n54,supported), \+ node(n54,refuted).
node(n44,refuted) :- node(n45,refuted), node(n48,refuted), node(n50,refuted), node(n52,refuted), node(n53,refuted), node(n54,refuted).
node(n44,supported) :- node(n45,supported).
node(n44,supported) :- node(n48,supported).
node(n44,supported) :- node(n50,supported).
node(n44,supported) :- node(n52,supported).
node(n44,supported) :- node(n53,supported).
node(n44,supported) :- node(n54,supported).
node(n44,unknown) :- \+ node(n44,supported), \+ node(n44,refuted).
verdict(c_25ad875bbee7cacd,supported) :- node(n44,supported).
query(verdict(c_25ad875bbee7cacd,supported)).
verdict(c_25ad875bbee7cacd,refuted) :- node(n44,refuted).
query(verdict(c_25ad875bbee7cacd,refuted)).
verdict(c_25ad875bbee7cacd,unknown) :- node(n44,unknown).
query(verdict(c_25ad875bbee7cacd,unknown)).
node(n57,supported) :- node(n24,refuted).
node(n57,refuted) :- node(n24,supported).
node(n57,unknown) :- \+ node(n57,supported), \+ node(n57,refuted).
node(n58,supported) :- node(n25,refuted).
node(n58,refuted) :- node(n25,supported).
node(n58,unknown) :- \+ node(n58,supported), \+ node(n58,refuted).
node(n56,supported) :- node(n57,supported), node(n58,supported).
node(n56,refuted) :- node(n57,refuted).
node(n56,refuted) :- node(n58,refuted).
node(n56,unknown) :- \+ node(n56,supported), \+ node(n56,refuted).
node(n60,supported) :- node(n27,refuted).
node(n60,refuted) :- node(n27,supported).
node(n60,unknown) :- \+ node(n60,supported), \+ node(n60,refuted).
node(n59,supported) :- node(n57,supported), node(n60,supported).
node(n59,refuted) :- node(n57,refuted).
node(n59,refuted) :- node(n60,refuted).
node(n59,unknown) :- \+ node(n59,supported), \+ node(n59,refuted).
node(n62,supported) :- node(n29,refuted).
node(n62,refuted) :- node(n29,supported).
node(n62,unknown) :- \+ node(n62,supported), \+ node(n62,refuted).
node(n61,supported) :- node(n57,supported), node(n62,supported).
node(n61,refuted) :- node(n57,refuted).
node(n61,refuted) :- node(n62,refuted).
node(n61,unknown) :- \+ node(n61,supported), \+ node(n61,refuted).
node(n63,supported) :- node(n58,supported), node(n60,supported).
node(n63,refuted) :- node(n58,refuted).
node(n63,refuted) :- node(n60,refuted).
node(n63,unknown) :- \+ node(n63,supported), \+ node(n63,refuted).
node(n64,supported) :- node(n58,supported), node(n62,supported).
node(n64,refuted) :- node(n58,refuted).
node(n64,refuted) :- node(n62,refuted).
node(n64,unknown) :- \+ node(n64,supported), \+ node(n64,refuted).
node(n65,supported) :- node(n60,supported), node(n62,supported).
node(n65,refuted) :- node(n60,refuted).
node(n65,refuted) :- node(n62,refuted).
node(n65,unknown) :- \+ node(n65,supported), \+ node(n65,refuted).
node(n55,refuted) :- node(n56,refuted), node(n59,refuted), node(n61,refuted), node(n63,refuted), node(n64,refuted), node(n65,refuted).
node(n55,supported) :- node(n56,supported).
node(n55,supported) :- node(n59,supported).
node(n55,supported) :- node(n61,supported).
node(n55,supported) :- node(n63,supported).
node(n55,supported) :- node(n64,supported).
node(n55,supported) :- node(n65,supported).
node(n55,unknown) :- \+ node(n55,supported), \+ node(n55,refuted).
verdict(c_929e3d634609adcd,supported) :- node(n55,supported).
query(verdict(c_929e3d634609adcd,supported)).
verdict(c_929e3d634609adcd,refuted) :- node(n55,refuted).
query(verdict(c_929e3d634609adcd,refuted)).
verdict(c_929e3d634609adcd,unknown) :- node(n55,unknown).
query(verdict(c_929e3d634609adcd,unknown)).
node(n68,supported) :- status(o_7544502bb23b229499a0,supported).
node(n68,refuted) :- status(o_7544502bb23b229499a0,refuted).
node(n68,unknown) :- status(o_7544502bb23b229499a0,unknown).
node(n69,supported) :- status(o_d7faa4127e1a53f57c69,supported).
node(n69,refuted) :- status(o_d7faa4127e1a53f57c69,refuted).
node(n69,unknown) :- status(o_d7faa4127e1a53f57c69,unknown).
node(n67,supported) :- node(n68,supported), node(n69,supported).
node(n67,refuted) :- node(n68,refuted).
node(n67,refuted) :- node(n69,refuted).
node(n67,unknown) :- \+ node(n67,supported), \+ node(n67,refuted).
node(n71,supported) :- status(o_ab2e10a770ac43eb37ec,supported).
node(n71,refuted) :- status(o_ab2e10a770ac43eb37ec,refuted).
node(n71,unknown) :- status(o_ab2e10a770ac43eb37ec,unknown).
node(n70,supported) :- node(n68,supported), node(n71,supported).
node(n70,refuted) :- node(n68,refuted).
node(n70,refuted) :- node(n71,refuted).
node(n70,unknown) :- \+ node(n70,supported), \+ node(n70,refuted).
node(n73,supported) :- status(o_f87dd23eda457eaac6b4,supported).
node(n73,refuted) :- status(o_f87dd23eda457eaac6b4,refuted).
node(n73,unknown) :- status(o_f87dd23eda457eaac6b4,unknown).
node(n72,supported) :- node(n68,supported), node(n73,supported).
node(n72,refuted) :- node(n68,refuted).
node(n72,refuted) :- node(n73,refuted).
node(n72,unknown) :- \+ node(n72,supported), \+ node(n72,refuted).
node(n74,supported) :- node(n69,supported), node(n71,supported).
node(n74,refuted) :- node(n69,refuted).
node(n74,refuted) :- node(n71,refuted).
node(n74,unknown) :- \+ node(n74,supported), \+ node(n74,refuted).
node(n75,supported) :- node(n69,supported), node(n73,supported).
node(n75,refuted) :- node(n69,refuted).
node(n75,refuted) :- node(n73,refuted).
node(n75,unknown) :- \+ node(n75,supported), \+ node(n75,refuted).
node(n76,supported) :- node(n71,supported), node(n73,supported).
node(n76,refuted) :- node(n71,refuted).
node(n76,refuted) :- node(n73,refuted).
node(n76,unknown) :- \+ node(n76,supported), \+ node(n76,refuted).
node(n66,refuted) :- node(n67,refuted), node(n70,refuted), node(n72,refuted), node(n74,refuted), node(n75,refuted), node(n76,refuted).
node(n66,supported) :- node(n67,supported).
node(n66,supported) :- node(n70,supported).
node(n66,supported) :- node(n72,supported).
node(n66,supported) :- node(n74,supported).
node(n66,supported) :- node(n75,supported).
node(n66,supported) :- node(n76,supported).
node(n66,unknown) :- \+ node(n66,supported), \+ node(n66,refuted).
verdict(c_7544502bb23b2294,supported) :- node(n66,supported).
query(verdict(c_7544502bb23b2294,supported)).
verdict(c_7544502bb23b2294,refuted) :- node(n66,refuted).
query(verdict(c_7544502bb23b2294,refuted)).
verdict(c_7544502bb23b2294,unknown) :- node(n66,unknown).
query(verdict(c_7544502bb23b2294,unknown)).
node(n79,supported) :- status(o_108d1756f4fda83847ee,supported).
node(n79,refuted) :- status(o_108d1756f4fda83847ee,refuted).
node(n79,unknown) :- status(o_108d1756f4fda83847ee,unknown).
node(n80,supported) :- status(o_f5a61990bfb414022dc0,supported).
node(n80,refuted) :- status(o_f5a61990bfb414022dc0,refuted).
node(n80,unknown) :- status(o_f5a61990bfb414022dc0,unknown).
node(n78,supported) :- node(n79,supported), node(n80,supported).
node(n78,refuted) :- node(n79,refuted).
node(n78,refuted) :- node(n80,refuted).
node(n78,unknown) :- \+ node(n78,supported), \+ node(n78,refuted).
node(n82,supported) :- status(o_4c964da788666ffe8ef5,supported).
node(n82,refuted) :- status(o_4c964da788666ffe8ef5,refuted).
node(n82,unknown) :- status(o_4c964da788666ffe8ef5,unknown).
node(n81,supported) :- node(n79,supported), node(n82,supported).
node(n81,refuted) :- node(n79,refuted).
node(n81,refuted) :- node(n82,refuted).
node(n81,unknown) :- \+ node(n81,supported), \+ node(n81,refuted).
node(n84,supported) :- status(o_16665718e95953f50900,supported).
node(n84,refuted) :- status(o_16665718e95953f50900,refuted).
node(n84,unknown) :- status(o_16665718e95953f50900,unknown).
node(n83,supported) :- node(n79,supported), node(n84,supported).
node(n83,refuted) :- node(n79,refuted).
node(n83,refuted) :- node(n84,refuted).
node(n83,unknown) :- \+ node(n83,supported), \+ node(n83,refuted).
node(n85,supported) :- node(n80,supported), node(n82,supported).
node(n85,refuted) :- node(n80,refuted).
node(n85,refuted) :- node(n82,refuted).
node(n85,unknown) :- \+ node(n85,supported), \+ node(n85,refuted).
node(n86,supported) :- node(n80,supported), node(n84,supported).
node(n86,refuted) :- node(n80,refuted).
node(n86,refuted) :- node(n84,refuted).
node(n86,unknown) :- \+ node(n86,supported), \+ node(n86,refuted).
node(n87,supported) :- node(n82,supported), node(n84,supported).
node(n87,refuted) :- node(n82,refuted).
node(n87,refuted) :- node(n84,refuted).
node(n87,unknown) :- \+ node(n87,supported), \+ node(n87,refuted).
node(n77,refuted) :- node(n78,refuted), node(n81,refuted), node(n83,refuted), node(n85,refuted), node(n86,refuted), node(n87,refuted).
node(n77,supported) :- node(n78,supported).
node(n77,supported) :- node(n81,supported).
node(n77,supported) :- node(n83,supported).
node(n77,supported) :- node(n85,supported).
node(n77,supported) :- node(n86,supported).
node(n77,supported) :- node(n87,supported).
node(n77,unknown) :- \+ node(n77,supported), \+ node(n77,refuted).
verdict(c_108d1756f4fda838,supported) :- node(n77,supported).
query(verdict(c_108d1756f4fda838,supported)).
verdict(c_108d1756f4fda838,refuted) :- node(n77,refuted).
query(verdict(c_108d1756f4fda838,refuted)).
verdict(c_108d1756f4fda838,unknown) :- node(n77,unknown).
query(verdict(c_108d1756f4fda838,unknown)).
node(n90,supported) :- status(o_eb1c97946ee94be80798,supported).
node(n90,refuted) :- status(o_eb1c97946ee94be80798,refuted).
node(n90,unknown) :- status(o_eb1c97946ee94be80798,unknown).
node(n91,supported) :- status(o_9f5cf0ec083ea2d6c9ad,supported).
node(n91,refuted) :- status(o_9f5cf0ec083ea2d6c9ad,refuted).
node(n91,unknown) :- status(o_9f5cf0ec083ea2d6c9ad,unknown).
node(n89,supported) :- node(n90,supported), node(n91,supported).
node(n89,refuted) :- node(n90,refuted).
node(n89,refuted) :- node(n91,refuted).
node(n89,unknown) :- \+ node(n89,supported), \+ node(n89,refuted).
node(n93,supported) :- status(o_d88294be4a96dfc6867d,supported).
node(n93,refuted) :- status(o_d88294be4a96dfc6867d,refuted).
node(n93,unknown) :- status(o_d88294be4a96dfc6867d,unknown).
node(n92,supported) :- node(n90,supported), node(n93,supported).
node(n92,refuted) :- node(n90,refuted).
node(n92,refuted) :- node(n93,refuted).
node(n92,unknown) :- \+ node(n92,supported), \+ node(n92,refuted).
node(n95,supported) :- status(o_3ffe1649755bc66186d6,supported).
node(n95,refuted) :- status(o_3ffe1649755bc66186d6,refuted).
node(n95,unknown) :- status(o_3ffe1649755bc66186d6,unknown).
node(n94,supported) :- node(n90,supported), node(n95,supported).
node(n94,refuted) :- node(n90,refuted).
node(n94,refuted) :- node(n95,refuted).
node(n94,unknown) :- \+ node(n94,supported), \+ node(n94,refuted).
node(n96,supported) :- node(n91,supported), node(n93,supported).
node(n96,refuted) :- node(n91,refuted).
node(n96,refuted) :- node(n93,refuted).
node(n96,unknown) :- \+ node(n96,supported), \+ node(n96,refuted).
node(n97,supported) :- node(n91,supported), node(n95,supported).
node(n97,refuted) :- node(n91,refuted).
node(n97,refuted) :- node(n95,refuted).
node(n97,unknown) :- \+ node(n97,supported), \+ node(n97,refuted).
node(n98,supported) :- node(n93,supported), node(n95,supported).
node(n98,refuted) :- node(n93,refuted).
node(n98,refuted) :- node(n95,refuted).
node(n98,unknown) :- \+ node(n98,supported), \+ node(n98,refuted).
node(n88,refuted) :- node(n89,refuted), node(n92,refuted), node(n94,refuted), node(n96,refuted), node(n97,refuted), node(n98,refuted).
node(n88,supported) :- node(n89,supported).
node(n88,supported) :- node(n92,supported).
node(n88,supported) :- node(n94,supported).
node(n88,supported) :- node(n96,supported).
node(n88,supported) :- node(n97,supported).
node(n88,supported) :- node(n98,supported).
node(n88,unknown) :- \+ node(n88,supported), \+ node(n88,refuted).
verdict(c_eb1c97946ee94be8,supported) :- node(n88,supported).
query(verdict(c_eb1c97946ee94be8,supported)).
verdict(c_eb1c97946ee94be8,refuted) :- node(n88,refuted).
query(verdict(c_eb1c97946ee94be8,refuted)).
verdict(c_eb1c97946ee94be8,unknown) :- node(n88,unknown).
query(verdict(c_eb1c97946ee94be8,unknown)).
node(n101,supported) :- node(n68,refuted).
node(n101,refuted) :- node(n68,supported).
node(n101,unknown) :- \+ node(n101,supported), \+ node(n101,refuted).
node(n102,supported) :- node(n69,refuted).
node(n102,refuted) :- node(n69,supported).
node(n102,unknown) :- \+ node(n102,supported), \+ node(n102,refuted).
node(n100,supported) :- node(n101,supported), node(n102,supported).
node(n100,refuted) :- node(n101,refuted).
node(n100,refuted) :- node(n102,refuted).
node(n100,unknown) :- \+ node(n100,supported), \+ node(n100,refuted).
node(n104,supported) :- node(n71,refuted).
node(n104,refuted) :- node(n71,supported).
node(n104,unknown) :- \+ node(n104,supported), \+ node(n104,refuted).
node(n103,supported) :- node(n101,supported), node(n104,supported).
node(n103,refuted) :- node(n101,refuted).
node(n103,refuted) :- node(n104,refuted).
node(n103,unknown) :- \+ node(n103,supported), \+ node(n103,refuted).
node(n106,supported) :- node(n73,refuted).
node(n106,refuted) :- node(n73,supported).
node(n106,unknown) :- \+ node(n106,supported), \+ node(n106,refuted).
node(n105,supported) :- node(n101,supported), node(n106,supported).
node(n105,refuted) :- node(n101,refuted).
node(n105,refuted) :- node(n106,refuted).
node(n105,unknown) :- \+ node(n105,supported), \+ node(n105,refuted).
node(n107,supported) :- node(n102,supported), node(n104,supported).
node(n107,refuted) :- node(n102,refuted).
node(n107,refuted) :- node(n104,refuted).
node(n107,unknown) :- \+ node(n107,supported), \+ node(n107,refuted).
node(n108,supported) :- node(n102,supported), node(n106,supported).
node(n108,refuted) :- node(n102,refuted).
node(n108,refuted) :- node(n106,refuted).
node(n108,unknown) :- \+ node(n108,supported), \+ node(n108,refuted).
node(n109,supported) :- node(n104,supported), node(n106,supported).
node(n109,refuted) :- node(n104,refuted).
node(n109,refuted) :- node(n106,refuted).
node(n109,unknown) :- \+ node(n109,supported), \+ node(n109,refuted).
node(n99,refuted) :- node(n100,refuted), node(n103,refuted), node(n105,refuted), node(n107,refuted), node(n108,refuted), node(n109,refuted).
node(n99,supported) :- node(n100,supported).
node(n99,supported) :- node(n103,supported).
node(n99,supported) :- node(n105,supported).
node(n99,supported) :- node(n107,supported).
node(n99,supported) :- node(n108,supported).
node(n99,supported) :- node(n109,supported).
node(n99,unknown) :- \+ node(n99,supported), \+ node(n99,refuted).
verdict(c_d7faa4127e1a53f5,supported) :- node(n99,supported).
query(verdict(c_d7faa4127e1a53f5,supported)).
verdict(c_d7faa4127e1a53f5,refuted) :- node(n99,refuted).
query(verdict(c_d7faa4127e1a53f5,refuted)).
verdict(c_d7faa4127e1a53f5,unknown) :- node(n99,unknown).
query(verdict(c_d7faa4127e1a53f5,unknown)).
node(n112,supported) :- node(n79,refuted).
node(n112,refuted) :- node(n79,supported).
node(n112,unknown) :- \+ node(n112,supported), \+ node(n112,refuted).
node(n113,supported) :- node(n80,refuted).
node(n113,refuted) :- node(n80,supported).
node(n113,unknown) :- \+ node(n113,supported), \+ node(n113,refuted).
node(n111,supported) :- node(n112,supported), node(n113,supported).
node(n111,refuted) :- node(n112,refuted).
node(n111,refuted) :- node(n113,refuted).
node(n111,unknown) :- \+ node(n111,supported), \+ node(n111,refuted).
node(n115,supported) :- node(n82,refuted).
node(n115,refuted) :- node(n82,supported).
node(n115,unknown) :- \+ node(n115,supported), \+ node(n115,refuted).
node(n114,supported) :- node(n112,supported), node(n115,supported).
node(n114,refuted) :- node(n112,refuted).
node(n114,refuted) :- node(n115,refuted).
node(n114,unknown) :- \+ node(n114,supported), \+ node(n114,refuted).
node(n117,supported) :- node(n84,refuted).
node(n117,refuted) :- node(n84,supported).
node(n117,unknown) :- \+ node(n117,supported), \+ node(n117,refuted).
node(n116,supported) :- node(n112,supported), node(n117,supported).
node(n116,refuted) :- node(n112,refuted).
node(n116,refuted) :- node(n117,refuted).
node(n116,unknown) :- \+ node(n116,supported), \+ node(n116,refuted).
node(n118,supported) :- node(n113,supported), node(n115,supported).
node(n118,refuted) :- node(n113,refuted).
node(n118,refuted) :- node(n115,refuted).
node(n118,unknown) :- \+ node(n118,supported), \+ node(n118,refuted).
node(n119,supported) :- node(n113,supported), node(n117,supported).
node(n119,refuted) :- node(n113,refuted).
node(n119,refuted) :- node(n117,refuted).
node(n119,unknown) :- \+ node(n119,supported), \+ node(n119,refuted).
node(n120,supported) :- node(n115,supported), node(n117,supported).
node(n120,refuted) :- node(n115,refuted).
node(n120,refuted) :- node(n117,refuted).
node(n120,unknown) :- \+ node(n120,supported), \+ node(n120,refuted).
node(n110,refuted) :- node(n111,refuted), node(n114,refuted), node(n116,refuted), node(n118,refuted), node(n119,refuted), node(n120,refuted).
node(n110,supported) :- node(n111,supported).
node(n110,supported) :- node(n114,supported).
node(n110,supported) :- node(n116,supported).
node(n110,supported) :- node(n118,supported).
node(n110,supported) :- node(n119,supported).
node(n110,supported) :- node(n120,supported).
node(n110,unknown) :- \+ node(n110,supported), \+ node(n110,refuted).
verdict(c_f5a61990bfb41402,supported) :- node(n110,supported).
query(verdict(c_f5a61990bfb41402,supported)).
verdict(c_f5a61990bfb41402,refuted) :- node(n110,refuted).
query(verdict(c_f5a61990bfb41402,refuted)).
verdict(c_f5a61990bfb41402,unknown) :- node(n110,unknown).
query(verdict(c_f5a61990bfb41402,unknown)).
node(n123,supported) :- node(n90,refuted).
node(n123,refuted) :- node(n90,supported).
node(n123,unknown) :- \+ node(n123,supported), \+ node(n123,refuted).
node(n124,supported) :- node(n91,refuted).
node(n124,refuted) :- node(n91,supported).
node(n124,unknown) :- \+ node(n124,supported), \+ node(n124,refuted).
node(n122,supported) :- node(n123,supported), node(n124,supported).
node(n122,refuted) :- node(n123,refuted).
node(n122,refuted) :- node(n124,refuted).
node(n122,unknown) :- \+ node(n122,supported), \+ node(n122,refuted).
node(n126,supported) :- node(n93,refuted).
node(n126,refuted) :- node(n93,supported).
node(n126,unknown) :- \+ node(n126,supported), \+ node(n126,refuted).
node(n125,supported) :- node(n123,supported), node(n126,supported).
node(n125,refuted) :- node(n123,refuted).
node(n125,refuted) :- node(n126,refuted).
node(n125,unknown) :- \+ node(n125,supported), \+ node(n125,refuted).
node(n128,supported) :- node(n95,refuted).
node(n128,refuted) :- node(n95,supported).
node(n128,unknown) :- \+ node(n128,supported), \+ node(n128,refuted).
node(n127,supported) :- node(n123,supported), node(n128,supported).
node(n127,refuted) :- node(n123,refuted).
node(n127,refuted) :- node(n128,refuted).
node(n127,unknown) :- \+ node(n127,supported), \+ node(n127,refuted).
node(n129,supported) :- node(n124,supported), node(n126,supported).
node(n129,refuted) :- node(n124,refuted).
node(n129,refuted) :- node(n126,refuted).
node(n129,unknown) :- \+ node(n129,supported), \+ node(n129,refuted).
node(n130,supported) :- node(n124,supported), node(n128,supported).
node(n130,refuted) :- node(n124,refuted).
node(n130,refuted) :- node(n128,refuted).
node(n130,unknown) :- \+ node(n130,supported), \+ node(n130,refuted).
node(n131,supported) :- node(n126,supported), node(n128,supported).
node(n131,refuted) :- node(n126,refuted).
node(n131,refuted) :- node(n128,refuted).
node(n131,unknown) :- \+ node(n131,supported), \+ node(n131,refuted).
node(n121,refuted) :- node(n122,refuted), node(n125,refuted), node(n127,refuted), node(n129,refuted), node(n130,refuted), node(n131,refuted).
node(n121,supported) :- node(n122,supported).
node(n121,supported) :- node(n125,supported).
node(n121,supported) :- node(n127,supported).
node(n121,supported) :- node(n129,supported).
node(n121,supported) :- node(n130,supported).
node(n121,supported) :- node(n131,supported).
node(n121,unknown) :- \+ node(n121,supported), \+ node(n121,refuted).
verdict(c_9f5cf0ec083ea2d6,supported) :- node(n121,supported).
query(verdict(c_9f5cf0ec083ea2d6,supported)).
verdict(c_9f5cf0ec083ea2d6,refuted) :- node(n121,refuted).
query(verdict(c_9f5cf0ec083ea2d6,refuted)).
verdict(c_9f5cf0ec083ea2d6,unknown) :- node(n121,unknown).
query(verdict(c_9f5cf0ec083ea2d6,unknown)).
node(n134,supported) :- status(o_a0e8aa7dabb39f9cf972,supported).
node(n134,refuted) :- status(o_a0e8aa7dabb39f9cf972,refuted).
node(n134,unknown) :- status(o_a0e8aa7dabb39f9cf972,unknown).
node(n135,supported) :- status(o_f36afea2013bce9ea56d,supported).
node(n135,refuted) :- status(o_f36afea2013bce9ea56d,refuted).
node(n135,unknown) :- status(o_f36afea2013bce9ea56d,unknown).
node(n133,supported) :- node(n134,supported), node(n135,supported).
node(n133,refuted) :- node(n134,refuted).
node(n133,refuted) :- node(n135,refuted).
node(n133,unknown) :- \+ node(n133,supported), \+ node(n133,refuted).
node(n137,supported) :- status(o_b65da667539233f33625,supported).
node(n137,refuted) :- status(o_b65da667539233f33625,refuted).
node(n137,unknown) :- status(o_b65da667539233f33625,unknown).
node(n136,supported) :- node(n134,supported), node(n137,supported).
node(n136,refuted) :- node(n134,refuted).
node(n136,refuted) :- node(n137,refuted).
node(n136,unknown) :- \+ node(n136,supported), \+ node(n136,refuted).
node(n139,supported) :- status(o_3e54cf53a07ea34fa31c,supported).
node(n139,refuted) :- status(o_3e54cf53a07ea34fa31c,refuted).
node(n139,unknown) :- status(o_3e54cf53a07ea34fa31c,unknown).
node(n138,supported) :- node(n134,supported), node(n139,supported).
node(n138,refuted) :- node(n134,refuted).
node(n138,refuted) :- node(n139,refuted).
node(n138,unknown) :- \+ node(n138,supported), \+ node(n138,refuted).
node(n140,supported) :- node(n135,supported), node(n137,supported).
node(n140,refuted) :- node(n135,refuted).
node(n140,refuted) :- node(n137,refuted).
node(n140,unknown) :- \+ node(n140,supported), \+ node(n140,refuted).
node(n141,supported) :- node(n135,supported), node(n139,supported).
node(n141,refuted) :- node(n135,refuted).
node(n141,refuted) :- node(n139,refuted).
node(n141,unknown) :- \+ node(n141,supported), \+ node(n141,refuted).
node(n142,supported) :- node(n137,supported), node(n139,supported).
node(n142,refuted) :- node(n137,refuted).
node(n142,refuted) :- node(n139,refuted).
node(n142,unknown) :- \+ node(n142,supported), \+ node(n142,refuted).
node(n132,refuted) :- node(n133,refuted), node(n136,refuted), node(n138,refuted), node(n140,refuted), node(n141,refuted), node(n142,refuted).
node(n132,supported) :- node(n133,supported).
node(n132,supported) :- node(n136,supported).
node(n132,supported) :- node(n138,supported).
node(n132,supported) :- node(n140,supported).
node(n132,supported) :- node(n141,supported).
node(n132,supported) :- node(n142,supported).
node(n132,unknown) :- \+ node(n132,supported), \+ node(n132,refuted).
verdict(c_a0e8aa7dabb39f9c,supported) :- node(n132,supported).
query(verdict(c_a0e8aa7dabb39f9c,supported)).
verdict(c_a0e8aa7dabb39f9c,refuted) :- node(n132,refuted).
query(verdict(c_a0e8aa7dabb39f9c,refuted)).
verdict(c_a0e8aa7dabb39f9c,unknown) :- node(n132,unknown).
query(verdict(c_a0e8aa7dabb39f9c,unknown)).
node(n145,supported) :- status(o_ae7d33e5cae5fce9a0fc,supported).
node(n145,refuted) :- status(o_ae7d33e5cae5fce9a0fc,refuted).
node(n145,unknown) :- status(o_ae7d33e5cae5fce9a0fc,unknown).
node(n146,supported) :- status(o_ba3583c2b9aa6cf77b0a,supported).
node(n146,refuted) :- status(o_ba3583c2b9aa6cf77b0a,refuted).
node(n146,unknown) :- status(o_ba3583c2b9aa6cf77b0a,unknown).
node(n144,supported) :- node(n145,supported), node(n146,supported).
node(n144,refuted) :- node(n145,refuted).
node(n144,refuted) :- node(n146,refuted).
node(n144,unknown) :- \+ node(n144,supported), \+ node(n144,refuted).
node(n148,supported) :- status(o_e2e0510e6c9fbce7ab72,supported).
node(n148,refuted) :- status(o_e2e0510e6c9fbce7ab72,refuted).
node(n148,unknown) :- status(o_e2e0510e6c9fbce7ab72,unknown).
node(n147,supported) :- node(n145,supported), node(n148,supported).
node(n147,refuted) :- node(n145,refuted).
node(n147,refuted) :- node(n148,refuted).
node(n147,unknown) :- \+ node(n147,supported), \+ node(n147,refuted).
node(n150,supported) :- status(o_f4aecd5e996e881b2cc3,supported).
node(n150,refuted) :- status(o_f4aecd5e996e881b2cc3,refuted).
node(n150,unknown) :- status(o_f4aecd5e996e881b2cc3,unknown).
node(n149,supported) :- node(n145,supported), node(n150,supported).
node(n149,refuted) :- node(n145,refuted).
node(n149,refuted) :- node(n150,refuted).
node(n149,unknown) :- \+ node(n149,supported), \+ node(n149,refuted).
node(n151,supported) :- node(n146,supported), node(n148,supported).
node(n151,refuted) :- node(n146,refuted).
node(n151,refuted) :- node(n148,refuted).
node(n151,unknown) :- \+ node(n151,supported), \+ node(n151,refuted).
node(n152,supported) :- node(n146,supported), node(n150,supported).
node(n152,refuted) :- node(n146,refuted).
node(n152,refuted) :- node(n150,refuted).
node(n152,unknown) :- \+ node(n152,supported), \+ node(n152,refuted).
node(n153,supported) :- node(n148,supported), node(n150,supported).
node(n153,refuted) :- node(n148,refuted).
node(n153,refuted) :- node(n150,refuted).
node(n153,unknown) :- \+ node(n153,supported), \+ node(n153,refuted).
node(n143,refuted) :- node(n144,refuted), node(n147,refuted), node(n149,refuted), node(n151,refuted), node(n152,refuted), node(n153,refuted).
node(n143,supported) :- node(n144,supported).
node(n143,supported) :- node(n147,supported).
node(n143,supported) :- node(n149,supported).
node(n143,supported) :- node(n151,supported).
node(n143,supported) :- node(n152,supported).
node(n143,supported) :- node(n153,supported).
node(n143,unknown) :- \+ node(n143,supported), \+ node(n143,refuted).
verdict(c_ae7d33e5cae5fce9,supported) :- node(n143,supported).
query(verdict(c_ae7d33e5cae5fce9,supported)).
verdict(c_ae7d33e5cae5fce9,refuted) :- node(n143,refuted).
query(verdict(c_ae7d33e5cae5fce9,refuted)).
verdict(c_ae7d33e5cae5fce9,unknown) :- node(n143,unknown).
query(verdict(c_ae7d33e5cae5fce9,unknown)).
node(n156,supported) :- status(o_6bda11af09b135c6acc4,supported).
node(n156,refuted) :- status(o_6bda11af09b135c6acc4,refuted).
node(n156,unknown) :- status(o_6bda11af09b135c6acc4,unknown).
node(n157,supported) :- status(o_a48ef75b39de6af3268c,supported).
node(n157,refuted) :- status(o_a48ef75b39de6af3268c,refuted).
node(n157,unknown) :- status(o_a48ef75b39de6af3268c,unknown).
node(n155,supported) :- node(n156,supported), node(n157,supported).
node(n155,refuted) :- node(n156,refuted).
node(n155,refuted) :- node(n157,refuted).
node(n155,unknown) :- \+ node(n155,supported), \+ node(n155,refuted).
node(n159,supported) :- status(o_6ca7bfd28ca2c43e66bb,supported).
node(n159,refuted) :- status(o_6ca7bfd28ca2c43e66bb,refuted).
node(n159,unknown) :- status(o_6ca7bfd28ca2c43e66bb,unknown).
node(n158,supported) :- node(n156,supported), node(n159,supported).
node(n158,refuted) :- node(n156,refuted).
node(n158,refuted) :- node(n159,refuted).
node(n158,unknown) :- \+ node(n158,supported), \+ node(n158,refuted).
node(n161,supported) :- status(o_abdd61eb753c0d21cdc5,supported).
node(n161,refuted) :- status(o_abdd61eb753c0d21cdc5,refuted).
node(n161,unknown) :- status(o_abdd61eb753c0d21cdc5,unknown).
node(n160,supported) :- node(n156,supported), node(n161,supported).
node(n160,refuted) :- node(n156,refuted).
node(n160,refuted) :- node(n161,refuted).
node(n160,unknown) :- \+ node(n160,supported), \+ node(n160,refuted).
node(n162,supported) :- node(n157,supported), node(n159,supported).
node(n162,refuted) :- node(n157,refuted).
node(n162,refuted) :- node(n159,refuted).
node(n162,unknown) :- \+ node(n162,supported), \+ node(n162,refuted).
node(n163,supported) :- node(n157,supported), node(n161,supported).
node(n163,refuted) :- node(n157,refuted).
node(n163,refuted) :- node(n161,refuted).
node(n163,unknown) :- \+ node(n163,supported), \+ node(n163,refuted).
node(n164,supported) :- node(n159,supported), node(n161,supported).
node(n164,refuted) :- node(n159,refuted).
node(n164,refuted) :- node(n161,refuted).
node(n164,unknown) :- \+ node(n164,supported), \+ node(n164,refuted).
node(n154,refuted) :- node(n155,refuted), node(n158,refuted), node(n160,refuted), node(n162,refuted), node(n163,refuted), node(n164,refuted).
node(n154,supported) :- node(n155,supported).
node(n154,supported) :- node(n158,supported).
node(n154,supported) :- node(n160,supported).
node(n154,supported) :- node(n162,supported).
node(n154,supported) :- node(n163,supported).
node(n154,supported) :- node(n164,supported).
node(n154,unknown) :- \+ node(n154,supported), \+ node(n154,refuted).
verdict(c_6bda11af09b135c6,supported) :- node(n154,supported).
query(verdict(c_6bda11af09b135c6,supported)).
verdict(c_6bda11af09b135c6,refuted) :- node(n154,refuted).
query(verdict(c_6bda11af09b135c6,refuted)).
verdict(c_6bda11af09b135c6,unknown) :- node(n154,unknown).
query(verdict(c_6bda11af09b135c6,unknown)).
node(n167,supported) :- node(n134,refuted).
node(n167,refuted) :- node(n134,supported).
node(n167,unknown) :- \+ node(n167,supported), \+ node(n167,refuted).
node(n168,supported) :- node(n135,refuted).
node(n168,refuted) :- node(n135,supported).
node(n168,unknown) :- \+ node(n168,supported), \+ node(n168,refuted).
node(n166,supported) :- node(n167,supported), node(n168,supported).
node(n166,refuted) :- node(n167,refuted).
node(n166,refuted) :- node(n168,refuted).
node(n166,unknown) :- \+ node(n166,supported), \+ node(n166,refuted).
node(n170,supported) :- node(n137,refuted).
node(n170,refuted) :- node(n137,supported).
node(n170,unknown) :- \+ node(n170,supported), \+ node(n170,refuted).
node(n169,supported) :- node(n167,supported), node(n170,supported).
node(n169,refuted) :- node(n167,refuted).
node(n169,refuted) :- node(n170,refuted).
node(n169,unknown) :- \+ node(n169,supported), \+ node(n169,refuted).
node(n172,supported) :- node(n139,refuted).
node(n172,refuted) :- node(n139,supported).
node(n172,unknown) :- \+ node(n172,supported), \+ node(n172,refuted).
node(n171,supported) :- node(n167,supported), node(n172,supported).
node(n171,refuted) :- node(n167,refuted).
node(n171,refuted) :- node(n172,refuted).
node(n171,unknown) :- \+ node(n171,supported), \+ node(n171,refuted).
node(n173,supported) :- node(n168,supported), node(n170,supported).
node(n173,refuted) :- node(n168,refuted).
node(n173,refuted) :- node(n170,refuted).
node(n173,unknown) :- \+ node(n173,supported), \+ node(n173,refuted).
node(n174,supported) :- node(n168,supported), node(n172,supported).
node(n174,refuted) :- node(n168,refuted).
node(n174,refuted) :- node(n172,refuted).
node(n174,unknown) :- \+ node(n174,supported), \+ node(n174,refuted).
node(n175,supported) :- node(n170,supported), node(n172,supported).
node(n175,refuted) :- node(n170,refuted).
node(n175,refuted) :- node(n172,refuted).
node(n175,unknown) :- \+ node(n175,supported), \+ node(n175,refuted).
node(n165,refuted) :- node(n166,refuted), node(n169,refuted), node(n171,refuted), node(n173,refuted), node(n174,refuted), node(n175,refuted).
node(n165,supported) :- node(n166,supported).
node(n165,supported) :- node(n169,supported).
node(n165,supported) :- node(n171,supported).
node(n165,supported) :- node(n173,supported).
node(n165,supported) :- node(n174,supported).
node(n165,supported) :- node(n175,supported).
node(n165,unknown) :- \+ node(n165,supported), \+ node(n165,refuted).
verdict(c_f36afea2013bce9e,supported) :- node(n165,supported).
query(verdict(c_f36afea2013bce9e,supported)).
verdict(c_f36afea2013bce9e,refuted) :- node(n165,refuted).
query(verdict(c_f36afea2013bce9e,refuted)).
verdict(c_f36afea2013bce9e,unknown) :- node(n165,unknown).
query(verdict(c_f36afea2013bce9e,unknown)).
node(n178,supported) :- node(n145,refuted).
node(n178,refuted) :- node(n145,supported).
node(n178,unknown) :- \+ node(n178,supported), \+ node(n178,refuted).
node(n179,supported) :- node(n146,refuted).
node(n179,refuted) :- node(n146,supported).
node(n179,unknown) :- \+ node(n179,supported), \+ node(n179,refuted).
node(n177,supported) :- node(n178,supported), node(n179,supported).
node(n177,refuted) :- node(n178,refuted).
node(n177,refuted) :- node(n179,refuted).
node(n177,unknown) :- \+ node(n177,supported), \+ node(n177,refuted).
node(n181,supported) :- node(n148,refuted).
node(n181,refuted) :- node(n148,supported).
node(n181,unknown) :- \+ node(n181,supported), \+ node(n181,refuted).
node(n180,supported) :- node(n178,supported), node(n181,supported).
node(n180,refuted) :- node(n178,refuted).
node(n180,refuted) :- node(n181,refuted).
node(n180,unknown) :- \+ node(n180,supported), \+ node(n180,refuted).
node(n183,supported) :- node(n150,refuted).
node(n183,refuted) :- node(n150,supported).
node(n183,unknown) :- \+ node(n183,supported), \+ node(n183,refuted).
node(n182,supported) :- node(n178,supported), node(n183,supported).
node(n182,refuted) :- node(n178,refuted).
node(n182,refuted) :- node(n183,refuted).
node(n182,unknown) :- \+ node(n182,supported), \+ node(n182,refuted).
node(n184,supported) :- node(n179,supported), node(n181,supported).
node(n184,refuted) :- node(n179,refuted).
node(n184,refuted) :- node(n181,refuted).
node(n184,unknown) :- \+ node(n184,supported), \+ node(n184,refuted).
node(n185,supported) :- node(n179,supported), node(n183,supported).
node(n185,refuted) :- node(n179,refuted).
node(n185,refuted) :- node(n183,refuted).
node(n185,unknown) :- \+ node(n185,supported), \+ node(n185,refuted).
node(n186,supported) :- node(n181,supported), node(n183,supported).
node(n186,refuted) :- node(n181,refuted).
node(n186,refuted) :- node(n183,refuted).
node(n186,unknown) :- \+ node(n186,supported), \+ node(n186,refuted).
node(n176,refuted) :- node(n177,refuted), node(n180,refuted), node(n182,refuted), node(n184,refuted), node(n185,refuted), node(n186,refuted).
node(n176,supported) :- node(n177,supported).
node(n176,supported) :- node(n180,supported).
node(n176,supported) :- node(n182,supported).
node(n176,supported) :- node(n184,supported).
node(n176,supported) :- node(n185,supported).
node(n176,supported) :- node(n186,supported).
node(n176,unknown) :- \+ node(n176,supported), \+ node(n176,refuted).
verdict(c_ba3583c2b9aa6cf7,supported) :- node(n176,supported).
query(verdict(c_ba3583c2b9aa6cf7,supported)).
verdict(c_ba3583c2b9aa6cf7,refuted) :- node(n176,refuted).
query(verdict(c_ba3583c2b9aa6cf7,refuted)).
verdict(c_ba3583c2b9aa6cf7,unknown) :- node(n176,unknown).
query(verdict(c_ba3583c2b9aa6cf7,unknown)).
node(n189,supported) :- node(n156,refuted).
node(n189,refuted) :- node(n156,supported).
node(n189,unknown) :- \+ node(n189,supported), \+ node(n189,refuted).
node(n190,supported) :- node(n157,refuted).
node(n190,refuted) :- node(n157,supported).
node(n190,unknown) :- \+ node(n190,supported), \+ node(n190,refuted).
node(n188,supported) :- node(n189,supported), node(n190,supported).
node(n188,refuted) :- node(n189,refuted).
node(n188,refuted) :- node(n190,refuted).
node(n188,unknown) :- \+ node(n188,supported), \+ node(n188,refuted).
node(n192,supported) :- node(n159,refuted).
node(n192,refuted) :- node(n159,supported).
node(n192,unknown) :- \+ node(n192,supported), \+ node(n192,refuted).
node(n191,supported) :- node(n189,supported), node(n192,supported).
node(n191,refuted) :- node(n189,refuted).
node(n191,refuted) :- node(n192,refuted).
node(n191,unknown) :- \+ node(n191,supported), \+ node(n191,refuted).
node(n194,supported) :- node(n161,refuted).
node(n194,refuted) :- node(n161,supported).
node(n194,unknown) :- \+ node(n194,supported), \+ node(n194,refuted).
node(n193,supported) :- node(n189,supported), node(n194,supported).
node(n193,refuted) :- node(n189,refuted).
node(n193,refuted) :- node(n194,refuted).
node(n193,unknown) :- \+ node(n193,supported), \+ node(n193,refuted).
node(n195,supported) :- node(n190,supported), node(n192,supported).
node(n195,refuted) :- node(n190,refuted).
node(n195,refuted) :- node(n192,refuted).
node(n195,unknown) :- \+ node(n195,supported), \+ node(n195,refuted).
node(n196,supported) :- node(n190,supported), node(n194,supported).
node(n196,refuted) :- node(n190,refuted).
node(n196,refuted) :- node(n194,refuted).
node(n196,unknown) :- \+ node(n196,supported), \+ node(n196,refuted).
node(n197,supported) :- node(n192,supported), node(n194,supported).
node(n197,refuted) :- node(n192,refuted).
node(n197,refuted) :- node(n194,refuted).
node(n197,unknown) :- \+ node(n197,supported), \+ node(n197,refuted).
node(n187,refuted) :- node(n188,refuted), node(n191,refuted), node(n193,refuted), node(n195,refuted), node(n196,refuted), node(n197,refuted).
node(n187,supported) :- node(n188,supported).
node(n187,supported) :- node(n191,supported).
node(n187,supported) :- node(n193,supported).
node(n187,supported) :- node(n195,supported).
node(n187,supported) :- node(n196,supported).
node(n187,supported) :- node(n197,supported).
node(n187,unknown) :- \+ node(n187,supported), \+ node(n187,refuted).
verdict(c_a48ef75b39de6af3,supported) :- node(n187,supported).
query(verdict(c_a48ef75b39de6af3,supported)).
verdict(c_a48ef75b39de6af3,refuted) :- node(n187,refuted).
query(verdict(c_a48ef75b39de6af3,refuted)).
verdict(c_a48ef75b39de6af3,unknown) :- node(n187,unknown).
query(verdict(c_a48ef75b39de6af3,unknown)).
node(n200,supported) :- status(o_388f6261bcb3fc52f9b2,supported).
node(n200,refuted) :- status(o_388f6261bcb3fc52f9b2,refuted).
node(n200,unknown) :- status(o_388f6261bcb3fc52f9b2,unknown).
node(n201,supported) :- status(o_245d75c35aeefaa09ec4,supported).
node(n201,refuted) :- status(o_245d75c35aeefaa09ec4,refuted).
node(n201,unknown) :- status(o_245d75c35aeefaa09ec4,unknown).
node(n199,supported) :- node(n200,supported), node(n201,supported).
node(n199,refuted) :- node(n200,refuted).
node(n199,refuted) :- node(n201,refuted).
node(n199,unknown) :- \+ node(n199,supported), \+ node(n199,refuted).
node(n203,supported) :- status(o_35c816db24007efae70c,supported).
node(n203,refuted) :- status(o_35c816db24007efae70c,refuted).
node(n203,unknown) :- status(o_35c816db24007efae70c,unknown).
node(n202,supported) :- node(n200,supported), node(n203,supported).
node(n202,refuted) :- node(n200,refuted).
node(n202,refuted) :- node(n203,refuted).
node(n202,unknown) :- \+ node(n202,supported), \+ node(n202,refuted).
node(n204,supported) :- node(n201,supported), node(n203,supported).
node(n204,refuted) :- node(n201,refuted).
node(n204,refuted) :- node(n203,refuted).
node(n204,unknown) :- \+ node(n204,supported), \+ node(n204,refuted).
node(n198,refuted) :- node(n199,refuted), node(n202,refuted), node(n204,refuted).
node(n198,supported) :- node(n199,supported).
node(n198,supported) :- node(n202,supported).
node(n198,supported) :- node(n204,supported).
node(n198,unknown) :- \+ node(n198,supported), \+ node(n198,refuted).
verdict(c_388f6261bcb3fc52,supported) :- node(n198,supported).
query(verdict(c_388f6261bcb3fc52,supported)).
verdict(c_388f6261bcb3fc52,refuted) :- node(n198,refuted).
query(verdict(c_388f6261bcb3fc52,refuted)).
verdict(c_388f6261bcb3fc52,unknown) :- node(n198,unknown).
query(verdict(c_388f6261bcb3fc52,unknown)).
node(n207,supported) :- status(o_a6dbad0ba4ea67bb7f8c,supported).
node(n207,refuted) :- status(o_a6dbad0ba4ea67bb7f8c,refuted).
node(n207,unknown) :- status(o_a6dbad0ba4ea67bb7f8c,unknown).
node(n208,supported) :- status(o_27a6edf84dec1d3edee9,supported).
node(n208,refuted) :- status(o_27a6edf84dec1d3edee9,refuted).
node(n208,unknown) :- status(o_27a6edf84dec1d3edee9,unknown).
node(n206,supported) :- node(n207,supported), node(n208,supported).
node(n206,refuted) :- node(n207,refuted).
node(n206,refuted) :- node(n208,refuted).
node(n206,unknown) :- \+ node(n206,supported), \+ node(n206,refuted).
node(n210,supported) :- status(o_51c044b6f7b9de127f83,supported).
node(n210,refuted) :- status(o_51c044b6f7b9de127f83,refuted).
node(n210,unknown) :- status(o_51c044b6f7b9de127f83,unknown).
node(n209,supported) :- node(n207,supported), node(n210,supported).
node(n209,refuted) :- node(n207,refuted).
node(n209,refuted) :- node(n210,refuted).
node(n209,unknown) :- \+ node(n209,supported), \+ node(n209,refuted).
node(n211,supported) :- node(n208,supported), node(n210,supported).
node(n211,refuted) :- node(n208,refuted).
node(n211,refuted) :- node(n210,refuted).
node(n211,unknown) :- \+ node(n211,supported), \+ node(n211,refuted).
node(n205,refuted) :- node(n206,refuted), node(n209,refuted), node(n211,refuted).
node(n205,supported) :- node(n206,supported).
node(n205,supported) :- node(n209,supported).
node(n205,supported) :- node(n211,supported).
node(n205,unknown) :- \+ node(n205,supported), \+ node(n205,refuted).
verdict(c_a6dbad0ba4ea67bb,supported) :- node(n205,supported).
query(verdict(c_a6dbad0ba4ea67bb,supported)).
verdict(c_a6dbad0ba4ea67bb,refuted) :- node(n205,refuted).
query(verdict(c_a6dbad0ba4ea67bb,refuted)).
verdict(c_a6dbad0ba4ea67bb,unknown) :- node(n205,unknown).
query(verdict(c_a6dbad0ba4ea67bb,unknown)).
node(n214,supported) :- status(o_18cb0c45e9731232ad20,supported).
node(n214,refuted) :- status(o_18cb0c45e9731232ad20,refuted).
node(n214,unknown) :- status(o_18cb0c45e9731232ad20,unknown).
node(n215,supported) :- status(o_1a7c1118e49b0e4029d6,supported).
node(n215,refuted) :- status(o_1a7c1118e49b0e4029d6,refuted).
node(n215,unknown) :- status(o_1a7c1118e49b0e4029d6,unknown).
node(n213,supported) :- node(n214,supported), node(n215,supported).
node(n213,refuted) :- node(n214,refuted).
node(n213,refuted) :- node(n215,refuted).
node(n213,unknown) :- \+ node(n213,supported), \+ node(n213,refuted).
node(n217,supported) :- status(o_3e4f49b9aa5c69df4678,supported).
node(n217,refuted) :- status(o_3e4f49b9aa5c69df4678,refuted).
node(n217,unknown) :- status(o_3e4f49b9aa5c69df4678,unknown).
node(n216,supported) :- node(n214,supported), node(n217,supported).
node(n216,refuted) :- node(n214,refuted).
node(n216,refuted) :- node(n217,refuted).
node(n216,unknown) :- \+ node(n216,supported), \+ node(n216,refuted).
node(n218,supported) :- node(n215,supported), node(n217,supported).
node(n218,refuted) :- node(n215,refuted).
node(n218,refuted) :- node(n217,refuted).
node(n218,unknown) :- \+ node(n218,supported), \+ node(n218,refuted).
node(n212,refuted) :- node(n213,refuted), node(n216,refuted), node(n218,refuted).
node(n212,supported) :- node(n213,supported).
node(n212,supported) :- node(n216,supported).
node(n212,supported) :- node(n218,supported).
node(n212,unknown) :- \+ node(n212,supported), \+ node(n212,refuted).
verdict(c_18cb0c45e9731232,supported) :- node(n212,supported).
query(verdict(c_18cb0c45e9731232,supported)).
verdict(c_18cb0c45e9731232,refuted) :- node(n212,refuted).
query(verdict(c_18cb0c45e9731232,refuted)).
verdict(c_18cb0c45e9731232,unknown) :- node(n212,unknown).
query(verdict(c_18cb0c45e9731232,unknown)).
node(n221,supported) :- node(n200,refuted).
node(n221,refuted) :- node(n200,supported).
node(n221,unknown) :- \+ node(n221,supported), \+ node(n221,refuted).
node(n222,supported) :- node(n201,refuted).
node(n222,refuted) :- node(n201,supported).
node(n222,unknown) :- \+ node(n222,supported), \+ node(n222,refuted).
node(n220,supported) :- node(n221,supported), node(n222,supported).
node(n220,refuted) :- node(n221,refuted).
node(n220,refuted) :- node(n222,refuted).
node(n220,unknown) :- \+ node(n220,supported), \+ node(n220,refuted).
node(n224,supported) :- node(n203,refuted).
node(n224,refuted) :- node(n203,supported).
node(n224,unknown) :- \+ node(n224,supported), \+ node(n224,refuted).
node(n223,supported) :- node(n221,supported), node(n224,supported).
node(n223,refuted) :- node(n221,refuted).
node(n223,refuted) :- node(n224,refuted).
node(n223,unknown) :- \+ node(n223,supported), \+ node(n223,refuted).
node(n225,supported) :- node(n222,supported), node(n224,supported).
node(n225,refuted) :- node(n222,refuted).
node(n225,refuted) :- node(n224,refuted).
node(n225,unknown) :- \+ node(n225,supported), \+ node(n225,refuted).
node(n219,refuted) :- node(n220,refuted), node(n223,refuted), node(n225,refuted).
node(n219,supported) :- node(n220,supported).
node(n219,supported) :- node(n223,supported).
node(n219,supported) :- node(n225,supported).
node(n219,unknown) :- \+ node(n219,supported), \+ node(n219,refuted).
verdict(c_245d75c35aeefaa0,supported) :- node(n219,supported).
query(verdict(c_245d75c35aeefaa0,supported)).
verdict(c_245d75c35aeefaa0,refuted) :- node(n219,refuted).
query(verdict(c_245d75c35aeefaa0,refuted)).
verdict(c_245d75c35aeefaa0,unknown) :- node(n219,unknown).
query(verdict(c_245d75c35aeefaa0,unknown)).
node(n228,supported) :- node(n207,refuted).
node(n228,refuted) :- node(n207,supported).
node(n228,unknown) :- \+ node(n228,supported), \+ node(n228,refuted).
node(n229,supported) :- node(n208,refuted).
node(n229,refuted) :- node(n208,supported).
node(n229,unknown) :- \+ node(n229,supported), \+ node(n229,refuted).
node(n227,supported) :- node(n228,supported), node(n229,supported).
node(n227,refuted) :- node(n228,refuted).
node(n227,refuted) :- node(n229,refuted).
node(n227,unknown) :- \+ node(n227,supported), \+ node(n227,refuted).
node(n231,supported) :- node(n210,refuted).
node(n231,refuted) :- node(n210,supported).
node(n231,unknown) :- \+ node(n231,supported), \+ node(n231,refuted).
node(n230,supported) :- node(n228,supported), node(n231,supported).
node(n230,refuted) :- node(n228,refuted).
node(n230,refuted) :- node(n231,refuted).
node(n230,unknown) :- \+ node(n230,supported), \+ node(n230,refuted).
node(n232,supported) :- node(n229,supported), node(n231,supported).
node(n232,refuted) :- node(n229,refuted).
node(n232,refuted) :- node(n231,refuted).
node(n232,unknown) :- \+ node(n232,supported), \+ node(n232,refuted).
node(n226,refuted) :- node(n227,refuted), node(n230,refuted), node(n232,refuted).
node(n226,supported) :- node(n227,supported).
node(n226,supported) :- node(n230,supported).
node(n226,supported) :- node(n232,supported).
node(n226,unknown) :- \+ node(n226,supported), \+ node(n226,refuted).
verdict(c_27a6edf84dec1d3e,supported) :- node(n226,supported).
query(verdict(c_27a6edf84dec1d3e,supported)).
verdict(c_27a6edf84dec1d3e,refuted) :- node(n226,refuted).
query(verdict(c_27a6edf84dec1d3e,refuted)).
verdict(c_27a6edf84dec1d3e,unknown) :- node(n226,unknown).
query(verdict(c_27a6edf84dec1d3e,unknown)).
node(n235,supported) :- node(n214,refuted).
node(n235,refuted) :- node(n214,supported).
node(n235,unknown) :- \+ node(n235,supported), \+ node(n235,refuted).
node(n236,supported) :- node(n215,refuted).
node(n236,refuted) :- node(n215,supported).
node(n236,unknown) :- \+ node(n236,supported), \+ node(n236,refuted).
node(n234,supported) :- node(n235,supported), node(n236,supported).
node(n234,refuted) :- node(n235,refuted).
node(n234,refuted) :- node(n236,refuted).
node(n234,unknown) :- \+ node(n234,supported), \+ node(n234,refuted).
node(n238,supported) :- node(n217,refuted).
node(n238,refuted) :- node(n217,supported).
node(n238,unknown) :- \+ node(n238,supported), \+ node(n238,refuted).
node(n237,supported) :- node(n235,supported), node(n238,supported).
node(n237,refuted) :- node(n235,refuted).
node(n237,refuted) :- node(n238,refuted).
node(n237,unknown) :- \+ node(n237,supported), \+ node(n237,refuted).
node(n239,supported) :- node(n236,supported), node(n238,supported).
node(n239,refuted) :- node(n236,refuted).
node(n239,refuted) :- node(n238,refuted).
node(n239,unknown) :- \+ node(n239,supported), \+ node(n239,refuted).
node(n233,refuted) :- node(n234,refuted), node(n237,refuted), node(n239,refuted).
node(n233,supported) :- node(n234,supported).
node(n233,supported) :- node(n237,supported).
node(n233,supported) :- node(n239,supported).
node(n233,unknown) :- \+ node(n233,supported), \+ node(n233,refuted).
verdict(c_1a7c1118e49b0e40,supported) :- node(n233,supported).
query(verdict(c_1a7c1118e49b0e40,supported)).
verdict(c_1a7c1118e49b0e40,refuted) :- node(n233,refuted).
query(verdict(c_1a7c1118e49b0e40,refuted)).
verdict(c_1a7c1118e49b0e40,unknown) :- node(n233,unknown).
query(verdict(c_1a7c1118e49b0e40,unknown)).
node(n242,supported) :- status(o_b12445cf14954ec4d967,supported).
node(n242,refuted) :- status(o_b12445cf14954ec4d967,refuted).
node(n242,unknown) :- status(o_b12445cf14954ec4d967,unknown).
node(n243,supported) :- status(o_efed71f20d65d95692a0,supported).
node(n243,refuted) :- status(o_efed71f20d65d95692a0,refuted).
node(n243,unknown) :- status(o_efed71f20d65d95692a0,unknown).
node(n241,supported) :- node(n242,supported), node(n243,supported).
node(n241,refuted) :- node(n242,refuted).
node(n241,refuted) :- node(n243,refuted).
node(n241,unknown) :- \+ node(n241,supported), \+ node(n241,refuted).
node(n245,supported) :- status(o_2a165be752498d6e38fe,supported).
node(n245,refuted) :- status(o_2a165be752498d6e38fe,refuted).
node(n245,unknown) :- status(o_2a165be752498d6e38fe,unknown).
node(n244,supported) :- node(n242,supported), node(n245,supported).
node(n244,refuted) :- node(n242,refuted).
node(n244,refuted) :- node(n245,refuted).
node(n244,unknown) :- \+ node(n244,supported), \+ node(n244,refuted).
node(n247,supported) :- status(o_702aca30bf7fa48f7baa,supported).
node(n247,refuted) :- status(o_702aca30bf7fa48f7baa,refuted).
node(n247,unknown) :- status(o_702aca30bf7fa48f7baa,unknown).
node(n246,supported) :- node(n242,supported), node(n247,supported).
node(n246,refuted) :- node(n242,refuted).
node(n246,refuted) :- node(n247,refuted).
node(n246,unknown) :- \+ node(n246,supported), \+ node(n246,refuted).
node(n248,supported) :- node(n243,supported), node(n245,supported).
node(n248,refuted) :- node(n243,refuted).
node(n248,refuted) :- node(n245,refuted).
node(n248,unknown) :- \+ node(n248,supported), \+ node(n248,refuted).
node(n249,supported) :- node(n243,supported), node(n247,supported).
node(n249,refuted) :- node(n243,refuted).
node(n249,refuted) :- node(n247,refuted).
node(n249,unknown) :- \+ node(n249,supported), \+ node(n249,refuted).
node(n250,supported) :- node(n245,supported), node(n247,supported).
node(n250,refuted) :- node(n245,refuted).
node(n250,refuted) :- node(n247,refuted).
node(n250,unknown) :- \+ node(n250,supported), \+ node(n250,refuted).
node(n240,refuted) :- node(n241,refuted), node(n244,refuted), node(n246,refuted), node(n248,refuted), node(n249,refuted), node(n250,refuted).
node(n240,supported) :- node(n241,supported).
node(n240,supported) :- node(n244,supported).
node(n240,supported) :- node(n246,supported).
node(n240,supported) :- node(n248,supported).
node(n240,supported) :- node(n249,supported).
node(n240,supported) :- node(n250,supported).
node(n240,unknown) :- \+ node(n240,supported), \+ node(n240,refuted).
verdict(c_b12445cf14954ec4,supported) :- node(n240,supported).
query(verdict(c_b12445cf14954ec4,supported)).
verdict(c_b12445cf14954ec4,refuted) :- node(n240,refuted).
query(verdict(c_b12445cf14954ec4,refuted)).
verdict(c_b12445cf14954ec4,unknown) :- node(n240,unknown).
query(verdict(c_b12445cf14954ec4,unknown)).
node(n253,supported) :- status(o_15c5bdb8bab4f383f2b4,supported).
node(n253,refuted) :- status(o_15c5bdb8bab4f383f2b4,refuted).
node(n253,unknown) :- status(o_15c5bdb8bab4f383f2b4,unknown).
node(n254,supported) :- status(o_ebfe58364e6a1aeccac3,supported).
node(n254,refuted) :- status(o_ebfe58364e6a1aeccac3,refuted).
node(n254,unknown) :- status(o_ebfe58364e6a1aeccac3,unknown).
node(n252,supported) :- node(n253,supported), node(n254,supported).
node(n252,refuted) :- node(n253,refuted).
node(n252,refuted) :- node(n254,refuted).
node(n252,unknown) :- \+ node(n252,supported), \+ node(n252,refuted).
node(n256,supported) :- status(o_08e3014139f4747bd3b5,supported).
node(n256,refuted) :- status(o_08e3014139f4747bd3b5,refuted).
node(n256,unknown) :- status(o_08e3014139f4747bd3b5,unknown).
node(n255,supported) :- node(n253,supported), node(n256,supported).
node(n255,refuted) :- node(n253,refuted).
node(n255,refuted) :- node(n256,refuted).
node(n255,unknown) :- \+ node(n255,supported), \+ node(n255,refuted).
node(n258,supported) :- status(o_481587c2751e7e967b7f,supported).
node(n258,refuted) :- status(o_481587c2751e7e967b7f,refuted).
node(n258,unknown) :- status(o_481587c2751e7e967b7f,unknown).
node(n257,supported) :- node(n253,supported), node(n258,supported).
node(n257,refuted) :- node(n253,refuted).
node(n257,refuted) :- node(n258,refuted).
node(n257,unknown) :- \+ node(n257,supported), \+ node(n257,refuted).
node(n259,supported) :- node(n254,supported), node(n256,supported).
node(n259,refuted) :- node(n254,refuted).
node(n259,refuted) :- node(n256,refuted).
node(n259,unknown) :- \+ node(n259,supported), \+ node(n259,refuted).
node(n260,supported) :- node(n254,supported), node(n258,supported).
node(n260,refuted) :- node(n254,refuted).
node(n260,refuted) :- node(n258,refuted).
node(n260,unknown) :- \+ node(n260,supported), \+ node(n260,refuted).
node(n261,supported) :- node(n256,supported), node(n258,supported).
node(n261,refuted) :- node(n256,refuted).
node(n261,refuted) :- node(n258,refuted).
node(n261,unknown) :- \+ node(n261,supported), \+ node(n261,refuted).
node(n251,refuted) :- node(n252,refuted), node(n255,refuted), node(n257,refuted), node(n259,refuted), node(n260,refuted), node(n261,refuted).
node(n251,supported) :- node(n252,supported).
node(n251,supported) :- node(n255,supported).
node(n251,supported) :- node(n257,supported).
node(n251,supported) :- node(n259,supported).
node(n251,supported) :- node(n260,supported).
node(n251,supported) :- node(n261,supported).
node(n251,unknown) :- \+ node(n251,supported), \+ node(n251,refuted).
verdict(c_15c5bdb8bab4f383,supported) :- node(n251,supported).
query(verdict(c_15c5bdb8bab4f383,supported)).
verdict(c_15c5bdb8bab4f383,refuted) :- node(n251,refuted).
query(verdict(c_15c5bdb8bab4f383,refuted)).
verdict(c_15c5bdb8bab4f383,unknown) :- node(n251,unknown).
query(verdict(c_15c5bdb8bab4f383,unknown)).
node(n264,supported) :- status(o_b63d70c3222fdf4e1bcd,supported).
node(n264,refuted) :- status(o_b63d70c3222fdf4e1bcd,refuted).
node(n264,unknown) :- status(o_b63d70c3222fdf4e1bcd,unknown).
node(n265,supported) :- status(o_c9643773605f271664d9,supported).
node(n265,refuted) :- status(o_c9643773605f271664d9,refuted).
node(n265,unknown) :- status(o_c9643773605f271664d9,unknown).
node(n263,supported) :- node(n264,supported), node(n265,supported).
node(n263,refuted) :- node(n264,refuted).
node(n263,refuted) :- node(n265,refuted).
node(n263,unknown) :- \+ node(n263,supported), \+ node(n263,refuted).
node(n267,supported) :- status(o_6546f5207e0ce48d2eae,supported).
node(n267,refuted) :- status(o_6546f5207e0ce48d2eae,refuted).
node(n267,unknown) :- status(o_6546f5207e0ce48d2eae,unknown).
node(n266,supported) :- node(n264,supported), node(n267,supported).
node(n266,refuted) :- node(n264,refuted).
node(n266,refuted) :- node(n267,refuted).
node(n266,unknown) :- \+ node(n266,supported), \+ node(n266,refuted).
node(n269,supported) :- status(o_1ca0bd4332f923ee499d,supported).
node(n269,refuted) :- status(o_1ca0bd4332f923ee499d,refuted).
node(n269,unknown) :- status(o_1ca0bd4332f923ee499d,unknown).
node(n268,supported) :- node(n264,supported), node(n269,supported).
node(n268,refuted) :- node(n264,refuted).
node(n268,refuted) :- node(n269,refuted).
node(n268,unknown) :- \+ node(n268,supported), \+ node(n268,refuted).
node(n270,supported) :- node(n265,supported), node(n267,supported).
node(n270,refuted) :- node(n265,refuted).
node(n270,refuted) :- node(n267,refuted).
node(n270,unknown) :- \+ node(n270,supported), \+ node(n270,refuted).
node(n271,supported) :- node(n265,supported), node(n269,supported).
node(n271,refuted) :- node(n265,refuted).
node(n271,refuted) :- node(n269,refuted).
node(n271,unknown) :- \+ node(n271,supported), \+ node(n271,refuted).
node(n272,supported) :- node(n267,supported), node(n269,supported).
node(n272,refuted) :- node(n267,refuted).
node(n272,refuted) :- node(n269,refuted).
node(n272,unknown) :- \+ node(n272,supported), \+ node(n272,refuted).
node(n262,refuted) :- node(n263,refuted), node(n266,refuted), node(n268,refuted), node(n270,refuted), node(n271,refuted), node(n272,refuted).
node(n262,supported) :- node(n263,supported).
node(n262,supported) :- node(n266,supported).
node(n262,supported) :- node(n268,supported).
node(n262,supported) :- node(n270,supported).
node(n262,supported) :- node(n271,supported).
node(n262,supported) :- node(n272,supported).
node(n262,unknown) :- \+ node(n262,supported), \+ node(n262,refuted).
verdict(c_b63d70c3222fdf4e,supported) :- node(n262,supported).
query(verdict(c_b63d70c3222fdf4e,supported)).
verdict(c_b63d70c3222fdf4e,refuted) :- node(n262,refuted).
query(verdict(c_b63d70c3222fdf4e,refuted)).
verdict(c_b63d70c3222fdf4e,unknown) :- node(n262,unknown).
query(verdict(c_b63d70c3222fdf4e,unknown)).
node(n275,supported) :- node(n242,refuted).
node(n275,refuted) :- node(n242,supported).
node(n275,unknown) :- \+ node(n275,supported), \+ node(n275,refuted).
node(n276,supported) :- node(n243,refuted).
node(n276,refuted) :- node(n243,supported).
node(n276,unknown) :- \+ node(n276,supported), \+ node(n276,refuted).
node(n274,supported) :- node(n275,supported), node(n276,supported).
node(n274,refuted) :- node(n275,refuted).
node(n274,refuted) :- node(n276,refuted).
node(n274,unknown) :- \+ node(n274,supported), \+ node(n274,refuted).
node(n278,supported) :- node(n245,refuted).
node(n278,refuted) :- node(n245,supported).
node(n278,unknown) :- \+ node(n278,supported), \+ node(n278,refuted).
node(n277,supported) :- node(n275,supported), node(n278,supported).
node(n277,refuted) :- node(n275,refuted).
node(n277,refuted) :- node(n278,refuted).
node(n277,unknown) :- \+ node(n277,supported), \+ node(n277,refuted).
node(n280,supported) :- node(n247,refuted).
node(n280,refuted) :- node(n247,supported).
node(n280,unknown) :- \+ node(n280,supported), \+ node(n280,refuted).
node(n279,supported) :- node(n275,supported), node(n280,supported).
node(n279,refuted) :- node(n275,refuted).
node(n279,refuted) :- node(n280,refuted).
node(n279,unknown) :- \+ node(n279,supported), \+ node(n279,refuted).
node(n281,supported) :- node(n276,supported), node(n278,supported).
node(n281,refuted) :- node(n276,refuted).
node(n281,refuted) :- node(n278,refuted).
node(n281,unknown) :- \+ node(n281,supported), \+ node(n281,refuted).
node(n282,supported) :- node(n276,supported), node(n280,supported).
node(n282,refuted) :- node(n276,refuted).
node(n282,refuted) :- node(n280,refuted).
node(n282,unknown) :- \+ node(n282,supported), \+ node(n282,refuted).
node(n283,supported) :- node(n278,supported), node(n280,supported).
node(n283,refuted) :- node(n278,refuted).
node(n283,refuted) :- node(n280,refuted).
node(n283,unknown) :- \+ node(n283,supported), \+ node(n283,refuted).
node(n273,refuted) :- node(n274,refuted), node(n277,refuted), node(n279,refuted), node(n281,refuted), node(n282,refuted), node(n283,refuted).
node(n273,supported) :- node(n274,supported).
node(n273,supported) :- node(n277,supported).
node(n273,supported) :- node(n279,supported).
node(n273,supported) :- node(n281,supported).
node(n273,supported) :- node(n282,supported).
node(n273,supported) :- node(n283,supported).
node(n273,unknown) :- \+ node(n273,supported), \+ node(n273,refuted).
verdict(c_efed71f20d65d956,supported) :- node(n273,supported).
query(verdict(c_efed71f20d65d956,supported)).
verdict(c_efed71f20d65d956,refuted) :- node(n273,refuted).
query(verdict(c_efed71f20d65d956,refuted)).
verdict(c_efed71f20d65d956,unknown) :- node(n273,unknown).
query(verdict(c_efed71f20d65d956,unknown)).
node(n286,supported) :- node(n253,refuted).
node(n286,refuted) :- node(n253,supported).
node(n286,unknown) :- \+ node(n286,supported), \+ node(n286,refuted).
node(n287,supported) :- node(n254,refuted).
node(n287,refuted) :- node(n254,supported).
node(n287,unknown) :- \+ node(n287,supported), \+ node(n287,refuted).
node(n285,supported) :- node(n286,supported), node(n287,supported).
node(n285,refuted) :- node(n286,refuted).
node(n285,refuted) :- node(n287,refuted).
node(n285,unknown) :- \+ node(n285,supported), \+ node(n285,refuted).
node(n289,supported) :- node(n256,refuted).
node(n289,refuted) :- node(n256,supported).
node(n289,unknown) :- \+ node(n289,supported), \+ node(n289,refuted).
node(n288,supported) :- node(n286,supported), node(n289,supported).
node(n288,refuted) :- node(n286,refuted).
node(n288,refuted) :- node(n289,refuted).
node(n288,unknown) :- \+ node(n288,supported), \+ node(n288,refuted).
node(n291,supported) :- node(n258,refuted).
node(n291,refuted) :- node(n258,supported).
node(n291,unknown) :- \+ node(n291,supported), \+ node(n291,refuted).
node(n290,supported) :- node(n286,supported), node(n291,supported).
node(n290,refuted) :- node(n286,refuted).
node(n290,refuted) :- node(n291,refuted).
node(n290,unknown) :- \+ node(n290,supported), \+ node(n290,refuted).
node(n292,supported) :- node(n287,supported), node(n289,supported).
node(n292,refuted) :- node(n287,refuted).
node(n292,refuted) :- node(n289,refuted).
node(n292,unknown) :- \+ node(n292,supported), \+ node(n292,refuted).
node(n293,supported) :- node(n287,supported), node(n291,supported).
node(n293,refuted) :- node(n287,refuted).
node(n293,refuted) :- node(n291,refuted).
node(n293,unknown) :- \+ node(n293,supported), \+ node(n293,refuted).
node(n294,supported) :- node(n289,supported), node(n291,supported).
node(n294,refuted) :- node(n289,refuted).
node(n294,refuted) :- node(n291,refuted).
node(n294,unknown) :- \+ node(n294,supported), \+ node(n294,refuted).
node(n284,refuted) :- node(n285,refuted), node(n288,refuted), node(n290,refuted), node(n292,refuted), node(n293,refuted), node(n294,refuted).
node(n284,supported) :- node(n285,supported).
node(n284,supported) :- node(n288,supported).
node(n284,supported) :- node(n290,supported).
node(n284,supported) :- node(n292,supported).
node(n284,supported) :- node(n293,supported).
node(n284,supported) :- node(n294,supported).
node(n284,unknown) :- \+ node(n284,supported), \+ node(n284,refuted).
verdict(c_ebfe58364e6a1aec,supported) :- node(n284,supported).
query(verdict(c_ebfe58364e6a1aec,supported)).
verdict(c_ebfe58364e6a1aec,refuted) :- node(n284,refuted).
query(verdict(c_ebfe58364e6a1aec,refuted)).
verdict(c_ebfe58364e6a1aec,unknown) :- node(n284,unknown).
query(verdict(c_ebfe58364e6a1aec,unknown)).
node(n297,supported) :- node(n264,refuted).
node(n297,refuted) :- node(n264,supported).
node(n297,unknown) :- \+ node(n297,supported), \+ node(n297,refuted).
node(n298,supported) :- node(n265,refuted).
node(n298,refuted) :- node(n265,supported).
node(n298,unknown) :- \+ node(n298,supported), \+ node(n298,refuted).
node(n296,supported) :- node(n297,supported), node(n298,supported).
node(n296,refuted) :- node(n297,refuted).
node(n296,refuted) :- node(n298,refuted).
node(n296,unknown) :- \+ node(n296,supported), \+ node(n296,refuted).
node(n300,supported) :- node(n267,refuted).
node(n300,refuted) :- node(n267,supported).
node(n300,unknown) :- \+ node(n300,supported), \+ node(n300,refuted).
node(n299,supported) :- node(n297,supported), node(n300,supported).
node(n299,refuted) :- node(n297,refuted).
node(n299,refuted) :- node(n300,refuted).
node(n299,unknown) :- \+ node(n299,supported), \+ node(n299,refuted).
node(n302,supported) :- node(n269,refuted).
node(n302,refuted) :- node(n269,supported).
node(n302,unknown) :- \+ node(n302,supported), \+ node(n302,refuted).
node(n301,supported) :- node(n297,supported), node(n302,supported).
node(n301,refuted) :- node(n297,refuted).
node(n301,refuted) :- node(n302,refuted).
node(n301,unknown) :- \+ node(n301,supported), \+ node(n301,refuted).
node(n303,supported) :- node(n298,supported), node(n300,supported).
node(n303,refuted) :- node(n298,refuted).
node(n303,refuted) :- node(n300,refuted).
node(n303,unknown) :- \+ node(n303,supported), \+ node(n303,refuted).
node(n304,supported) :- node(n298,supported), node(n302,supported).
node(n304,refuted) :- node(n298,refuted).
node(n304,refuted) :- node(n302,refuted).
node(n304,unknown) :- \+ node(n304,supported), \+ node(n304,refuted).
node(n305,supported) :- node(n300,supported), node(n302,supported).
node(n305,refuted) :- node(n300,refuted).
node(n305,refuted) :- node(n302,refuted).
node(n305,unknown) :- \+ node(n305,supported), \+ node(n305,refuted).
node(n295,refuted) :- node(n296,refuted), node(n299,refuted), node(n301,refuted), node(n303,refuted), node(n304,refuted), node(n305,refuted).
node(n295,supported) :- node(n296,supported).
node(n295,supported) :- node(n299,supported).
node(n295,supported) :- node(n301,supported).
node(n295,supported) :- node(n303,supported).
node(n295,supported) :- node(n304,supported).
node(n295,supported) :- node(n305,supported).
node(n295,unknown) :- \+ node(n295,supported), \+ node(n295,refuted).
verdict(c_c9643773605f2716,supported) :- node(n295,supported).
query(verdict(c_c9643773605f2716,supported)).
verdict(c_c9643773605f2716,refuted) :- node(n295,refuted).
query(verdict(c_c9643773605f2716,refuted)).
verdict(c_c9643773605f2716,unknown) :- node(n295,unknown).
query(verdict(c_c9643773605f2716,unknown)).
node(n308,supported) :- status(o_3e49668aa5250ea5d329,supported).
node(n308,refuted) :- status(o_3e49668aa5250ea5d329,refuted).
node(n308,unknown) :- status(o_3e49668aa5250ea5d329,unknown).
node(n309,supported) :- status(o_94f5d6de366d5af262fc,supported).
node(n309,refuted) :- status(o_94f5d6de366d5af262fc,refuted).
node(n309,unknown) :- status(o_94f5d6de366d5af262fc,unknown).
node(n307,supported) :- node(n308,supported), node(n309,supported).
node(n307,refuted) :- node(n308,refuted).
node(n307,refuted) :- node(n309,refuted).
node(n307,unknown) :- \+ node(n307,supported), \+ node(n307,refuted).
node(n311,supported) :- status(o_e1f0f86cf3f435212b96,supported).
node(n311,refuted) :- status(o_e1f0f86cf3f435212b96,refuted).
node(n311,unknown) :- status(o_e1f0f86cf3f435212b96,unknown).
node(n310,supported) :- node(n308,supported), node(n311,supported).
node(n310,refuted) :- node(n308,refuted).
node(n310,refuted) :- node(n311,refuted).
node(n310,unknown) :- \+ node(n310,supported), \+ node(n310,refuted).
node(n313,supported) :- status(o_0cb51d1b7766e40ec8e3,supported).
node(n313,refuted) :- status(o_0cb51d1b7766e40ec8e3,refuted).
node(n313,unknown) :- status(o_0cb51d1b7766e40ec8e3,unknown).
node(n312,supported) :- node(n308,supported), node(n313,supported).
node(n312,refuted) :- node(n308,refuted).
node(n312,refuted) :- node(n313,refuted).
node(n312,unknown) :- \+ node(n312,supported), \+ node(n312,refuted).
node(n314,supported) :- node(n309,supported), node(n311,supported).
node(n314,refuted) :- node(n309,refuted).
node(n314,refuted) :- node(n311,refuted).
node(n314,unknown) :- \+ node(n314,supported), \+ node(n314,refuted).
node(n315,supported) :- node(n309,supported), node(n313,supported).
node(n315,refuted) :- node(n309,refuted).
node(n315,refuted) :- node(n313,refuted).
node(n315,unknown) :- \+ node(n315,supported), \+ node(n315,refuted).
node(n316,supported) :- node(n311,supported), node(n313,supported).
node(n316,refuted) :- node(n311,refuted).
node(n316,refuted) :- node(n313,refuted).
node(n316,unknown) :- \+ node(n316,supported), \+ node(n316,refuted).
node(n306,refuted) :- node(n307,refuted), node(n310,refuted), node(n312,refuted), node(n314,refuted), node(n315,refuted), node(n316,refuted).
node(n306,supported) :- node(n307,supported).
node(n306,supported) :- node(n310,supported).
node(n306,supported) :- node(n312,supported).
node(n306,supported) :- node(n314,supported).
node(n306,supported) :- node(n315,supported).
node(n306,supported) :- node(n316,supported).
node(n306,unknown) :- \+ node(n306,supported), \+ node(n306,refuted).
verdict(c_3e49668aa5250ea5,supported) :- node(n306,supported).
query(verdict(c_3e49668aa5250ea5,supported)).
verdict(c_3e49668aa5250ea5,refuted) :- node(n306,refuted).
query(verdict(c_3e49668aa5250ea5,refuted)).
verdict(c_3e49668aa5250ea5,unknown) :- node(n306,unknown).
query(verdict(c_3e49668aa5250ea5,unknown)).
node(n319,supported) :- status(o_fa2ef3b59a4dcf25c9a5,supported).
node(n319,refuted) :- status(o_fa2ef3b59a4dcf25c9a5,refuted).
node(n319,unknown) :- status(o_fa2ef3b59a4dcf25c9a5,unknown).
node(n320,supported) :- status(o_cad644316ed5bbedc01f,supported).
node(n320,refuted) :- status(o_cad644316ed5bbedc01f,refuted).
node(n320,unknown) :- status(o_cad644316ed5bbedc01f,unknown).
node(n318,supported) :- node(n319,supported), node(n320,supported).
node(n318,refuted) :- node(n319,refuted).
node(n318,refuted) :- node(n320,refuted).
node(n318,unknown) :- \+ node(n318,supported), \+ node(n318,refuted).
node(n322,supported) :- status(o_36ace0521f337d23a149,supported).
node(n322,refuted) :- status(o_36ace0521f337d23a149,refuted).
node(n322,unknown) :- status(o_36ace0521f337d23a149,unknown).
node(n321,supported) :- node(n319,supported), node(n322,supported).
node(n321,refuted) :- node(n319,refuted).
node(n321,refuted) :- node(n322,refuted).
node(n321,unknown) :- \+ node(n321,supported), \+ node(n321,refuted).
node(n324,supported) :- status(o_20a9e4a206b7079a7d14,supported).
node(n324,refuted) :- status(o_20a9e4a206b7079a7d14,refuted).
node(n324,unknown) :- status(o_20a9e4a206b7079a7d14,unknown).
node(n323,supported) :- node(n319,supported), node(n324,supported).
node(n323,refuted) :- node(n319,refuted).
node(n323,refuted) :- node(n324,refuted).
node(n323,unknown) :- \+ node(n323,supported), \+ node(n323,refuted).
node(n325,supported) :- node(n320,supported), node(n322,supported).
node(n325,refuted) :- node(n320,refuted).
node(n325,refuted) :- node(n322,refuted).
node(n325,unknown) :- \+ node(n325,supported), \+ node(n325,refuted).
node(n326,supported) :- node(n320,supported), node(n324,supported).
node(n326,refuted) :- node(n320,refuted).
node(n326,refuted) :- node(n324,refuted).
node(n326,unknown) :- \+ node(n326,supported), \+ node(n326,refuted).
node(n327,supported) :- node(n322,supported), node(n324,supported).
node(n327,refuted) :- node(n322,refuted).
node(n327,refuted) :- node(n324,refuted).
node(n327,unknown) :- \+ node(n327,supported), \+ node(n327,refuted).
node(n317,refuted) :- node(n318,refuted), node(n321,refuted), node(n323,refuted), node(n325,refuted), node(n326,refuted), node(n327,refuted).
node(n317,supported) :- node(n318,supported).
node(n317,supported) :- node(n321,supported).
node(n317,supported) :- node(n323,supported).
node(n317,supported) :- node(n325,supported).
node(n317,supported) :- node(n326,supported).
node(n317,supported) :- node(n327,supported).
node(n317,unknown) :- \+ node(n317,supported), \+ node(n317,refuted).
verdict(c_fa2ef3b59a4dcf25,supported) :- node(n317,supported).
query(verdict(c_fa2ef3b59a4dcf25,supported)).
verdict(c_fa2ef3b59a4dcf25,refuted) :- node(n317,refuted).
query(verdict(c_fa2ef3b59a4dcf25,refuted)).
verdict(c_fa2ef3b59a4dcf25,unknown) :- node(n317,unknown).
query(verdict(c_fa2ef3b59a4dcf25,unknown)).
node(n330,supported) :- status(o_197ef76e6781d94cf259,supported).
node(n330,refuted) :- status(o_197ef76e6781d94cf259,refuted).
node(n330,unknown) :- status(o_197ef76e6781d94cf259,unknown).
node(n331,supported) :- status(o_bb86839361e2e1b1eb9c,supported).
node(n331,refuted) :- status(o_bb86839361e2e1b1eb9c,refuted).
node(n331,unknown) :- status(o_bb86839361e2e1b1eb9c,unknown).
node(n329,supported) :- node(n330,supported), node(n331,supported).
node(n329,refuted) :- node(n330,refuted).
node(n329,refuted) :- node(n331,refuted).
node(n329,unknown) :- \+ node(n329,supported), \+ node(n329,refuted).
node(n333,supported) :- status(o_e32b3c7687fd35bd5de2,supported).
node(n333,refuted) :- status(o_e32b3c7687fd35bd5de2,refuted).
node(n333,unknown) :- status(o_e32b3c7687fd35bd5de2,unknown).
node(n332,supported) :- node(n330,supported), node(n333,supported).
node(n332,refuted) :- node(n330,refuted).
node(n332,refuted) :- node(n333,refuted).
node(n332,unknown) :- \+ node(n332,supported), \+ node(n332,refuted).
node(n335,supported) :- status(o_46dba06b165d57aa4621,supported).
node(n335,refuted) :- status(o_46dba06b165d57aa4621,refuted).
node(n335,unknown) :- status(o_46dba06b165d57aa4621,unknown).
node(n334,supported) :- node(n330,supported), node(n335,supported).
node(n334,refuted) :- node(n330,refuted).
node(n334,refuted) :- node(n335,refuted).
node(n334,unknown) :- \+ node(n334,supported), \+ node(n334,refuted).
node(n336,supported) :- node(n331,supported), node(n333,supported).
node(n336,refuted) :- node(n331,refuted).
node(n336,refuted) :- node(n333,refuted).
node(n336,unknown) :- \+ node(n336,supported), \+ node(n336,refuted).
node(n337,supported) :- node(n331,supported), node(n335,supported).
node(n337,refuted) :- node(n331,refuted).
node(n337,refuted) :- node(n335,refuted).
node(n337,unknown) :- \+ node(n337,supported), \+ node(n337,refuted).
node(n338,supported) :- node(n333,supported), node(n335,supported).
node(n338,refuted) :- node(n333,refuted).
node(n338,refuted) :- node(n335,refuted).
node(n338,unknown) :- \+ node(n338,supported), \+ node(n338,refuted).
node(n328,refuted) :- node(n329,refuted), node(n332,refuted), node(n334,refuted), node(n336,refuted), node(n337,refuted), node(n338,refuted).
node(n328,supported) :- node(n329,supported).
node(n328,supported) :- node(n332,supported).
node(n328,supported) :- node(n334,supported).
node(n328,supported) :- node(n336,supported).
node(n328,supported) :- node(n337,supported).
node(n328,supported) :- node(n338,supported).
node(n328,unknown) :- \+ node(n328,supported), \+ node(n328,refuted).
verdict(c_197ef76e6781d94c,supported) :- node(n328,supported).
query(verdict(c_197ef76e6781d94c,supported)).
verdict(c_197ef76e6781d94c,refuted) :- node(n328,refuted).
query(verdict(c_197ef76e6781d94c,refuted)).
verdict(c_197ef76e6781d94c,unknown) :- node(n328,unknown).
query(verdict(c_197ef76e6781d94c,unknown)).
node(n341,supported) :- node(n308,refuted).
node(n341,refuted) :- node(n308,supported).
node(n341,unknown) :- \+ node(n341,supported), \+ node(n341,refuted).
node(n342,supported) :- node(n309,refuted).
node(n342,refuted) :- node(n309,supported).
node(n342,unknown) :- \+ node(n342,supported), \+ node(n342,refuted).
node(n340,supported) :- node(n341,supported), node(n342,supported).
node(n340,refuted) :- node(n341,refuted).
node(n340,refuted) :- node(n342,refuted).
node(n340,unknown) :- \+ node(n340,supported), \+ node(n340,refuted).
node(n344,supported) :- node(n311,refuted).
node(n344,refuted) :- node(n311,supported).
node(n344,unknown) :- \+ node(n344,supported), \+ node(n344,refuted).
node(n343,supported) :- node(n341,supported), node(n344,supported).
node(n343,refuted) :- node(n341,refuted).
node(n343,refuted) :- node(n344,refuted).
node(n343,unknown) :- \+ node(n343,supported), \+ node(n343,refuted).
node(n346,supported) :- node(n313,refuted).
node(n346,refuted) :- node(n313,supported).
node(n346,unknown) :- \+ node(n346,supported), \+ node(n346,refuted).
node(n345,supported) :- node(n341,supported), node(n346,supported).
node(n345,refuted) :- node(n341,refuted).
node(n345,refuted) :- node(n346,refuted).
node(n345,unknown) :- \+ node(n345,supported), \+ node(n345,refuted).
node(n347,supported) :- node(n342,supported), node(n344,supported).
node(n347,refuted) :- node(n342,refuted).
node(n347,refuted) :- node(n344,refuted).
node(n347,unknown) :- \+ node(n347,supported), \+ node(n347,refuted).
node(n348,supported) :- node(n342,supported), node(n346,supported).
node(n348,refuted) :- node(n342,refuted).
node(n348,refuted) :- node(n346,refuted).
node(n348,unknown) :- \+ node(n348,supported), \+ node(n348,refuted).
node(n349,supported) :- node(n344,supported), node(n346,supported).
node(n349,refuted) :- node(n344,refuted).
node(n349,refuted) :- node(n346,refuted).
node(n349,unknown) :- \+ node(n349,supported), \+ node(n349,refuted).
node(n339,refuted) :- node(n340,refuted), node(n343,refuted), node(n345,refuted), node(n347,refuted), node(n348,refuted), node(n349,refuted).
node(n339,supported) :- node(n340,supported).
node(n339,supported) :- node(n343,supported).
node(n339,supported) :- node(n345,supported).
node(n339,supported) :- node(n347,supported).
node(n339,supported) :- node(n348,supported).
node(n339,supported) :- node(n349,supported).
node(n339,unknown) :- \+ node(n339,supported), \+ node(n339,refuted).
verdict(c_94f5d6de366d5af2,supported) :- node(n339,supported).
query(verdict(c_94f5d6de366d5af2,supported)).
verdict(c_94f5d6de366d5af2,refuted) :- node(n339,refuted).
query(verdict(c_94f5d6de366d5af2,refuted)).
verdict(c_94f5d6de366d5af2,unknown) :- node(n339,unknown).
query(verdict(c_94f5d6de366d5af2,unknown)).
node(n352,supported) :- node(n319,refuted).
node(n352,refuted) :- node(n319,supported).
node(n352,unknown) :- \+ node(n352,supported), \+ node(n352,refuted).
node(n353,supported) :- node(n320,refuted).
node(n353,refuted) :- node(n320,supported).
node(n353,unknown) :- \+ node(n353,supported), \+ node(n353,refuted).
node(n351,supported) :- node(n352,supported), node(n353,supported).
node(n351,refuted) :- node(n352,refuted).
node(n351,refuted) :- node(n353,refuted).
node(n351,unknown) :- \+ node(n351,supported), \+ node(n351,refuted).
node(n355,supported) :- node(n322,refuted).
node(n355,refuted) :- node(n322,supported).
node(n355,unknown) :- \+ node(n355,supported), \+ node(n355,refuted).
node(n354,supported) :- node(n352,supported), node(n355,supported).
node(n354,refuted) :- node(n352,refuted).
node(n354,refuted) :- node(n355,refuted).
node(n354,unknown) :- \+ node(n354,supported), \+ node(n354,refuted).
node(n357,supported) :- node(n324,refuted).
node(n357,refuted) :- node(n324,supported).
node(n357,unknown) :- \+ node(n357,supported), \+ node(n357,refuted).
node(n356,supported) :- node(n352,supported), node(n357,supported).
node(n356,refuted) :- node(n352,refuted).
node(n356,refuted) :- node(n357,refuted).
node(n356,unknown) :- \+ node(n356,supported), \+ node(n356,refuted).
node(n358,supported) :- node(n353,supported), node(n355,supported).
node(n358,refuted) :- node(n353,refuted).
node(n358,refuted) :- node(n355,refuted).
node(n358,unknown) :- \+ node(n358,supported), \+ node(n358,refuted).
node(n359,supported) :- node(n353,supported), node(n357,supported).
node(n359,refuted) :- node(n353,refuted).
node(n359,refuted) :- node(n357,refuted).
node(n359,unknown) :- \+ node(n359,supported), \+ node(n359,refuted).
node(n360,supported) :- node(n355,supported), node(n357,supported).
node(n360,refuted) :- node(n355,refuted).
node(n360,refuted) :- node(n357,refuted).
node(n360,unknown) :- \+ node(n360,supported), \+ node(n360,refuted).
node(n350,refuted) :- node(n351,refuted), node(n354,refuted), node(n356,refuted), node(n358,refuted), node(n359,refuted), node(n360,refuted).
node(n350,supported) :- node(n351,supported).
node(n350,supported) :- node(n354,supported).
node(n350,supported) :- node(n356,supported).
node(n350,supported) :- node(n358,supported).
node(n350,supported) :- node(n359,supported).
node(n350,supported) :- node(n360,supported).
node(n350,unknown) :- \+ node(n350,supported), \+ node(n350,refuted).
verdict(c_cad644316ed5bbed,supported) :- node(n350,supported).
query(verdict(c_cad644316ed5bbed,supported)).
verdict(c_cad644316ed5bbed,refuted) :- node(n350,refuted).
query(verdict(c_cad644316ed5bbed,refuted)).
verdict(c_cad644316ed5bbed,unknown) :- node(n350,unknown).
query(verdict(c_cad644316ed5bbed,unknown)).
node(n363,supported) :- node(n330,refuted).
node(n363,refuted) :- node(n330,supported).
node(n363,unknown) :- \+ node(n363,supported), \+ node(n363,refuted).
node(n364,supported) :- node(n331,refuted).
node(n364,refuted) :- node(n331,supported).
node(n364,unknown) :- \+ node(n364,supported), \+ node(n364,refuted).
node(n362,supported) :- node(n363,supported), node(n364,supported).
node(n362,refuted) :- node(n363,refuted).
node(n362,refuted) :- node(n364,refuted).
node(n362,unknown) :- \+ node(n362,supported), \+ node(n362,refuted).
node(n366,supported) :- node(n333,refuted).
node(n366,refuted) :- node(n333,supported).
node(n366,unknown) :- \+ node(n366,supported), \+ node(n366,refuted).
node(n365,supported) :- node(n363,supported), node(n366,supported).
node(n365,refuted) :- node(n363,refuted).
node(n365,refuted) :- node(n366,refuted).
node(n365,unknown) :- \+ node(n365,supported), \+ node(n365,refuted).
node(n368,supported) :- node(n335,refuted).
node(n368,refuted) :- node(n335,supported).
node(n368,unknown) :- \+ node(n368,supported), \+ node(n368,refuted).
node(n367,supported) :- node(n363,supported), node(n368,supported).
node(n367,refuted) :- node(n363,refuted).
node(n367,refuted) :- node(n368,refuted).
node(n367,unknown) :- \+ node(n367,supported), \+ node(n367,refuted).
node(n369,supported) :- node(n364,supported), node(n366,supported).
node(n369,refuted) :- node(n364,refuted).
node(n369,refuted) :- node(n366,refuted).
node(n369,unknown) :- \+ node(n369,supported), \+ node(n369,refuted).
node(n370,supported) :- node(n364,supported), node(n368,supported).
node(n370,refuted) :- node(n364,refuted).
node(n370,refuted) :- node(n368,refuted).
node(n370,unknown) :- \+ node(n370,supported), \+ node(n370,refuted).
node(n371,supported) :- node(n366,supported), node(n368,supported).
node(n371,refuted) :- node(n366,refuted).
node(n371,refuted) :- node(n368,refuted).
node(n371,unknown) :- \+ node(n371,supported), \+ node(n371,refuted).
node(n361,refuted) :- node(n362,refuted), node(n365,refuted), node(n367,refuted), node(n369,refuted), node(n370,refuted), node(n371,refuted).
node(n361,supported) :- node(n362,supported).
node(n361,supported) :- node(n365,supported).
node(n361,supported) :- node(n367,supported).
node(n361,supported) :- node(n369,supported).
node(n361,supported) :- node(n370,supported).
node(n361,supported) :- node(n371,supported).
node(n361,unknown) :- \+ node(n361,supported), \+ node(n361,refuted).
verdict(c_bb86839361e2e1b1,supported) :- node(n361,supported).
query(verdict(c_bb86839361e2e1b1,supported)).
verdict(c_bb86839361e2e1b1,refuted) :- node(n361,refuted).
query(verdict(c_bb86839361e2e1b1,refuted)).
verdict(c_bb86839361e2e1b1,unknown) :- node(n361,unknown).
query(verdict(c_bb86839361e2e1b1,unknown)).
node(n374,supported) :- status(o_f2a8269a08096cc41128,supported).
node(n374,refuted) :- status(o_f2a8269a08096cc41128,refuted).
node(n374,unknown) :- status(o_f2a8269a08096cc41128,unknown).
node(n375,supported) :- status(o_4a854b906931f569c802,supported).
node(n375,refuted) :- status(o_4a854b906931f569c802,refuted).
node(n375,unknown) :- status(o_4a854b906931f569c802,unknown).
node(n373,supported) :- node(n374,supported), node(n375,supported).
node(n373,refuted) :- node(n374,refuted).
node(n373,refuted) :- node(n375,refuted).
node(n373,unknown) :- \+ node(n373,supported), \+ node(n373,refuted).
node(n377,supported) :- status(o_f98bb31a8cb169f5bf80,supported).
node(n377,refuted) :- status(o_f98bb31a8cb169f5bf80,refuted).
node(n377,unknown) :- status(o_f98bb31a8cb169f5bf80,unknown).
node(n376,supported) :- node(n374,supported), node(n377,supported).
node(n376,refuted) :- node(n374,refuted).
node(n376,refuted) :- node(n377,refuted).
node(n376,unknown) :- \+ node(n376,supported), \+ node(n376,refuted).
node(n379,supported) :- status(o_70790248370857c30d70,supported).
node(n379,refuted) :- status(o_70790248370857c30d70,refuted).
node(n379,unknown) :- status(o_70790248370857c30d70,unknown).
node(n378,supported) :- node(n374,supported), node(n379,supported).
node(n378,refuted) :- node(n374,refuted).
node(n378,refuted) :- node(n379,refuted).
node(n378,unknown) :- \+ node(n378,supported), \+ node(n378,refuted).
node(n380,supported) :- node(n375,supported), node(n377,supported).
node(n380,refuted) :- node(n375,refuted).
node(n380,refuted) :- node(n377,refuted).
node(n380,unknown) :- \+ node(n380,supported), \+ node(n380,refuted).
node(n381,supported) :- node(n375,supported), node(n379,supported).
node(n381,refuted) :- node(n375,refuted).
node(n381,refuted) :- node(n379,refuted).
node(n381,unknown) :- \+ node(n381,supported), \+ node(n381,refuted).
node(n382,supported) :- node(n377,supported), node(n379,supported).
node(n382,refuted) :- node(n377,refuted).
node(n382,refuted) :- node(n379,refuted).
node(n382,unknown) :- \+ node(n382,supported), \+ node(n382,refuted).
node(n372,refuted) :- node(n373,refuted), node(n376,refuted), node(n378,refuted), node(n380,refuted), node(n381,refuted), node(n382,refuted).
node(n372,supported) :- node(n373,supported).
node(n372,supported) :- node(n376,supported).
node(n372,supported) :- node(n378,supported).
node(n372,supported) :- node(n380,supported).
node(n372,supported) :- node(n381,supported).
node(n372,supported) :- node(n382,supported).
node(n372,unknown) :- \+ node(n372,supported), \+ node(n372,refuted).
verdict(c_f2a8269a08096cc4,supported) :- node(n372,supported).
query(verdict(c_f2a8269a08096cc4,supported)).
verdict(c_f2a8269a08096cc4,refuted) :- node(n372,refuted).
query(verdict(c_f2a8269a08096cc4,refuted)).
verdict(c_f2a8269a08096cc4,unknown) :- node(n372,unknown).
query(verdict(c_f2a8269a08096cc4,unknown)).
node(n385,supported) :- status(o_873f2b77559bca4c1463,supported).
node(n385,refuted) :- status(o_873f2b77559bca4c1463,refuted).
node(n385,unknown) :- status(o_873f2b77559bca4c1463,unknown).
node(n386,supported) :- status(o_173c616f86ae6679553f,supported).
node(n386,refuted) :- status(o_173c616f86ae6679553f,refuted).
node(n386,unknown) :- status(o_173c616f86ae6679553f,unknown).
node(n384,supported) :- node(n385,supported), node(n386,supported).
node(n384,refuted) :- node(n385,refuted).
node(n384,refuted) :- node(n386,refuted).
node(n384,unknown) :- \+ node(n384,supported), \+ node(n384,refuted).
node(n388,supported) :- status(o_ca71854d54bea8ad5bb7,supported).
node(n388,refuted) :- status(o_ca71854d54bea8ad5bb7,refuted).
node(n388,unknown) :- status(o_ca71854d54bea8ad5bb7,unknown).
node(n387,supported) :- node(n385,supported), node(n388,supported).
node(n387,refuted) :- node(n385,refuted).
node(n387,refuted) :- node(n388,refuted).
node(n387,unknown) :- \+ node(n387,supported), \+ node(n387,refuted).
node(n390,supported) :- status(o_85cc797ecc72b84f0ddf,supported).
node(n390,refuted) :- status(o_85cc797ecc72b84f0ddf,refuted).
node(n390,unknown) :- status(o_85cc797ecc72b84f0ddf,unknown).
node(n389,supported) :- node(n385,supported), node(n390,supported).
node(n389,refuted) :- node(n385,refuted).
node(n389,refuted) :- node(n390,refuted).
node(n389,unknown) :- \+ node(n389,supported), \+ node(n389,refuted).
node(n391,supported) :- node(n386,supported), node(n388,supported).
node(n391,refuted) :- node(n386,refuted).
node(n391,refuted) :- node(n388,refuted).
node(n391,unknown) :- \+ node(n391,supported), \+ node(n391,refuted).
node(n392,supported) :- node(n386,supported), node(n390,supported).
node(n392,refuted) :- node(n386,refuted).
node(n392,refuted) :- node(n390,refuted).
node(n392,unknown) :- \+ node(n392,supported), \+ node(n392,refuted).
node(n393,supported) :- node(n388,supported), node(n390,supported).
node(n393,refuted) :- node(n388,refuted).
node(n393,refuted) :- node(n390,refuted).
node(n393,unknown) :- \+ node(n393,supported), \+ node(n393,refuted).
node(n383,refuted) :- node(n384,refuted), node(n387,refuted), node(n389,refuted), node(n391,refuted), node(n392,refuted), node(n393,refuted).
node(n383,supported) :- node(n384,supported).
node(n383,supported) :- node(n387,supported).
node(n383,supported) :- node(n389,supported).
node(n383,supported) :- node(n391,supported).
node(n383,supported) :- node(n392,supported).
node(n383,supported) :- node(n393,supported).
node(n383,unknown) :- \+ node(n383,supported), \+ node(n383,refuted).
verdict(c_873f2b77559bca4c,supported) :- node(n383,supported).
query(verdict(c_873f2b77559bca4c,supported)).
verdict(c_873f2b77559bca4c,refuted) :- node(n383,refuted).
query(verdict(c_873f2b77559bca4c,refuted)).
verdict(c_873f2b77559bca4c,unknown) :- node(n383,unknown).
query(verdict(c_873f2b77559bca4c,unknown)).
node(n396,supported) :- status(o_48a66537dd5f172751a8,supported).
node(n396,refuted) :- status(o_48a66537dd5f172751a8,refuted).
node(n396,unknown) :- status(o_48a66537dd5f172751a8,unknown).
node(n397,supported) :- status(o_633f39be7c02bb1fae9c,supported).
node(n397,refuted) :- status(o_633f39be7c02bb1fae9c,refuted).
node(n397,unknown) :- status(o_633f39be7c02bb1fae9c,unknown).
node(n395,supported) :- node(n396,supported), node(n397,supported).
node(n395,refuted) :- node(n396,refuted).
node(n395,refuted) :- node(n397,refuted).
node(n395,unknown) :- \+ node(n395,supported), \+ node(n395,refuted).
node(n399,supported) :- status(o_90ffc6d5a99f7097f9c3,supported).
node(n399,refuted) :- status(o_90ffc6d5a99f7097f9c3,refuted).
node(n399,unknown) :- status(o_90ffc6d5a99f7097f9c3,unknown).
node(n398,supported) :- node(n396,supported), node(n399,supported).
node(n398,refuted) :- node(n396,refuted).
node(n398,refuted) :- node(n399,refuted).
node(n398,unknown) :- \+ node(n398,supported), \+ node(n398,refuted).
node(n401,supported) :- status(o_3758b2c1958632072a84,supported).
node(n401,refuted) :- status(o_3758b2c1958632072a84,refuted).
node(n401,unknown) :- status(o_3758b2c1958632072a84,unknown).
node(n400,supported) :- node(n396,supported), node(n401,supported).
node(n400,refuted) :- node(n396,refuted).
node(n400,refuted) :- node(n401,refuted).
node(n400,unknown) :- \+ node(n400,supported), \+ node(n400,refuted).
node(n402,supported) :- node(n397,supported), node(n399,supported).
node(n402,refuted) :- node(n397,refuted).
node(n402,refuted) :- node(n399,refuted).
node(n402,unknown) :- \+ node(n402,supported), \+ node(n402,refuted).
node(n403,supported) :- node(n397,supported), node(n401,supported).
node(n403,refuted) :- node(n397,refuted).
node(n403,refuted) :- node(n401,refuted).
node(n403,unknown) :- \+ node(n403,supported), \+ node(n403,refuted).
node(n404,supported) :- node(n399,supported), node(n401,supported).
node(n404,refuted) :- node(n399,refuted).
node(n404,refuted) :- node(n401,refuted).
node(n404,unknown) :- \+ node(n404,supported), \+ node(n404,refuted).
node(n394,refuted) :- node(n395,refuted), node(n398,refuted), node(n400,refuted), node(n402,refuted), node(n403,refuted), node(n404,refuted).
node(n394,supported) :- node(n395,supported).
node(n394,supported) :- node(n398,supported).
node(n394,supported) :- node(n400,supported).
node(n394,supported) :- node(n402,supported).
node(n394,supported) :- node(n403,supported).
node(n394,supported) :- node(n404,supported).
node(n394,unknown) :- \+ node(n394,supported), \+ node(n394,refuted).
verdict(c_48a66537dd5f1727,supported) :- node(n394,supported).
query(verdict(c_48a66537dd5f1727,supported)).
verdict(c_48a66537dd5f1727,refuted) :- node(n394,refuted).
query(verdict(c_48a66537dd5f1727,refuted)).
verdict(c_48a66537dd5f1727,unknown) :- node(n394,unknown).
query(verdict(c_48a66537dd5f1727,unknown)).
node(n407,supported) :- node(n374,refuted).
node(n407,refuted) :- node(n374,supported).
node(n407,unknown) :- \+ node(n407,supported), \+ node(n407,refuted).
node(n408,supported) :- node(n375,refuted).
node(n408,refuted) :- node(n375,supported).
node(n408,unknown) :- \+ node(n408,supported), \+ node(n408,refuted).
node(n406,supported) :- node(n407,supported), node(n408,supported).
node(n406,refuted) :- node(n407,refuted).
node(n406,refuted) :- node(n408,refuted).
node(n406,unknown) :- \+ node(n406,supported), \+ node(n406,refuted).
node(n410,supported) :- node(n377,refuted).
node(n410,refuted) :- node(n377,supported).
node(n410,unknown) :- \+ node(n410,supported), \+ node(n410,refuted).
node(n409,supported) :- node(n407,supported), node(n410,supported).
node(n409,refuted) :- node(n407,refuted).
node(n409,refuted) :- node(n410,refuted).
node(n409,unknown) :- \+ node(n409,supported), \+ node(n409,refuted).
node(n412,supported) :- node(n379,refuted).
node(n412,refuted) :- node(n379,supported).
node(n412,unknown) :- \+ node(n412,supported), \+ node(n412,refuted).
node(n411,supported) :- node(n407,supported), node(n412,supported).
node(n411,refuted) :- node(n407,refuted).
node(n411,refuted) :- node(n412,refuted).
node(n411,unknown) :- \+ node(n411,supported), \+ node(n411,refuted).
node(n413,supported) :- node(n408,supported), node(n410,supported).
node(n413,refuted) :- node(n408,refuted).
node(n413,refuted) :- node(n410,refuted).
node(n413,unknown) :- \+ node(n413,supported), \+ node(n413,refuted).
node(n414,supported) :- node(n408,supported), node(n412,supported).
node(n414,refuted) :- node(n408,refuted).
node(n414,refuted) :- node(n412,refuted).
node(n414,unknown) :- \+ node(n414,supported), \+ node(n414,refuted).
node(n415,supported) :- node(n410,supported), node(n412,supported).
node(n415,refuted) :- node(n410,refuted).
node(n415,refuted) :- node(n412,refuted).
node(n415,unknown) :- \+ node(n415,supported), \+ node(n415,refuted).
node(n405,refuted) :- node(n406,refuted), node(n409,refuted), node(n411,refuted), node(n413,refuted), node(n414,refuted), node(n415,refuted).
node(n405,supported) :- node(n406,supported).
node(n405,supported) :- node(n409,supported).
node(n405,supported) :- node(n411,supported).
node(n405,supported) :- node(n413,supported).
node(n405,supported) :- node(n414,supported).
node(n405,supported) :- node(n415,supported).
node(n405,unknown) :- \+ node(n405,supported), \+ node(n405,refuted).
verdict(c_4a854b906931f569,supported) :- node(n405,supported).
query(verdict(c_4a854b906931f569,supported)).
verdict(c_4a854b906931f569,refuted) :- node(n405,refuted).
query(verdict(c_4a854b906931f569,refuted)).
verdict(c_4a854b906931f569,unknown) :- node(n405,unknown).
query(verdict(c_4a854b906931f569,unknown)).
node(n418,supported) :- node(n385,refuted).
node(n418,refuted) :- node(n385,supported).
node(n418,unknown) :- \+ node(n418,supported), \+ node(n418,refuted).
node(n419,supported) :- node(n386,refuted).
node(n419,refuted) :- node(n386,supported).
node(n419,unknown) :- \+ node(n419,supported), \+ node(n419,refuted).
node(n417,supported) :- node(n418,supported), node(n419,supported).
node(n417,refuted) :- node(n418,refuted).
node(n417,refuted) :- node(n419,refuted).
node(n417,unknown) :- \+ node(n417,supported), \+ node(n417,refuted).
node(n421,supported) :- node(n388,refuted).
node(n421,refuted) :- node(n388,supported).
node(n421,unknown) :- \+ node(n421,supported), \+ node(n421,refuted).
node(n420,supported) :- node(n418,supported), node(n421,supported).
node(n420,refuted) :- node(n418,refuted).
node(n420,refuted) :- node(n421,refuted).
node(n420,unknown) :- \+ node(n420,supported), \+ node(n420,refuted).
node(n423,supported) :- node(n390,refuted).
node(n423,refuted) :- node(n390,supported).
node(n423,unknown) :- \+ node(n423,supported), \+ node(n423,refuted).
node(n422,supported) :- node(n418,supported), node(n423,supported).
node(n422,refuted) :- node(n418,refuted).
node(n422,refuted) :- node(n423,refuted).
node(n422,unknown) :- \+ node(n422,supported), \+ node(n422,refuted).
node(n424,supported) :- node(n419,supported), node(n421,supported).
node(n424,refuted) :- node(n419,refuted).
node(n424,refuted) :- node(n421,refuted).
node(n424,unknown) :- \+ node(n424,supported), \+ node(n424,refuted).
node(n425,supported) :- node(n419,supported), node(n423,supported).
node(n425,refuted) :- node(n419,refuted).
node(n425,refuted) :- node(n423,refuted).
node(n425,unknown) :- \+ node(n425,supported), \+ node(n425,refuted).
node(n426,supported) :- node(n421,supported), node(n423,supported).
node(n426,refuted) :- node(n421,refuted).
node(n426,refuted) :- node(n423,refuted).
node(n426,unknown) :- \+ node(n426,supported), \+ node(n426,refuted).
node(n416,refuted) :- node(n417,refuted), node(n420,refuted), node(n422,refuted), node(n424,refuted), node(n425,refuted), node(n426,refuted).
node(n416,supported) :- node(n417,supported).
node(n416,supported) :- node(n420,supported).
node(n416,supported) :- node(n422,supported).
node(n416,supported) :- node(n424,supported).
node(n416,supported) :- node(n425,supported).
node(n416,supported) :- node(n426,supported).
node(n416,unknown) :- \+ node(n416,supported), \+ node(n416,refuted).
verdict(c_173c616f86ae6679,supported) :- node(n416,supported).
query(verdict(c_173c616f86ae6679,supported)).
verdict(c_173c616f86ae6679,refuted) :- node(n416,refuted).
query(verdict(c_173c616f86ae6679,refuted)).
verdict(c_173c616f86ae6679,unknown) :- node(n416,unknown).
query(verdict(c_173c616f86ae6679,unknown)).
node(n429,supported) :- node(n396,refuted).
node(n429,refuted) :- node(n396,supported).
node(n429,unknown) :- \+ node(n429,supported), \+ node(n429,refuted).
node(n430,supported) :- node(n397,refuted).
node(n430,refuted) :- node(n397,supported).
node(n430,unknown) :- \+ node(n430,supported), \+ node(n430,refuted).
node(n428,supported) :- node(n429,supported), node(n430,supported).
node(n428,refuted) :- node(n429,refuted).
node(n428,refuted) :- node(n430,refuted).
node(n428,unknown) :- \+ node(n428,supported), \+ node(n428,refuted).
node(n432,supported) :- node(n399,refuted).
node(n432,refuted) :- node(n399,supported).
node(n432,unknown) :- \+ node(n432,supported), \+ node(n432,refuted).
node(n431,supported) :- node(n429,supported), node(n432,supported).
node(n431,refuted) :- node(n429,refuted).
node(n431,refuted) :- node(n432,refuted).
node(n431,unknown) :- \+ node(n431,supported), \+ node(n431,refuted).
node(n434,supported) :- node(n401,refuted).
node(n434,refuted) :- node(n401,supported).
node(n434,unknown) :- \+ node(n434,supported), \+ node(n434,refuted).
node(n433,supported) :- node(n429,supported), node(n434,supported).
node(n433,refuted) :- node(n429,refuted).
node(n433,refuted) :- node(n434,refuted).
node(n433,unknown) :- \+ node(n433,supported), \+ node(n433,refuted).
node(n435,supported) :- node(n430,supported), node(n432,supported).
node(n435,refuted) :- node(n430,refuted).
node(n435,refuted) :- node(n432,refuted).
node(n435,unknown) :- \+ node(n435,supported), \+ node(n435,refuted).
node(n436,supported) :- node(n430,supported), node(n434,supported).
node(n436,refuted) :- node(n430,refuted).
node(n436,refuted) :- node(n434,refuted).
node(n436,unknown) :- \+ node(n436,supported), \+ node(n436,refuted).
node(n437,supported) :- node(n432,supported), node(n434,supported).
node(n437,refuted) :- node(n432,refuted).
node(n437,refuted) :- node(n434,refuted).
node(n437,unknown) :- \+ node(n437,supported), \+ node(n437,refuted).
node(n427,refuted) :- node(n428,refuted), node(n431,refuted), node(n433,refuted), node(n435,refuted), node(n436,refuted), node(n437,refuted).
node(n427,supported) :- node(n428,supported).
node(n427,supported) :- node(n431,supported).
node(n427,supported) :- node(n433,supported).
node(n427,supported) :- node(n435,supported).
node(n427,supported) :- node(n436,supported).
node(n427,supported) :- node(n437,supported).
node(n427,unknown) :- \+ node(n427,supported), \+ node(n427,refuted).
verdict(c_633f39be7c02bb1f,supported) :- node(n427,supported).
query(verdict(c_633f39be7c02bb1f,supported)).
verdict(c_633f39be7c02bb1f,refuted) :- node(n427,refuted).
query(verdict(c_633f39be7c02bb1f,refuted)).
verdict(c_633f39be7c02bb1f,unknown) :- node(n427,unknown).
query(verdict(c_633f39be7c02bb1f,unknown)).
node(n440,supported) :- status(o_dbbe07b9d478ad551d5d,supported).
node(n440,refuted) :- status(o_dbbe07b9d478ad551d5d,refuted).
node(n440,unknown) :- status(o_dbbe07b9d478ad551d5d,unknown).
node(n441,supported) :- status(o_0077992c2dd07923811f,supported).
node(n441,refuted) :- status(o_0077992c2dd07923811f,refuted).
node(n441,unknown) :- status(o_0077992c2dd07923811f,unknown).
node(n439,supported) :- node(n440,supported), node(n441,supported).
node(n439,refuted) :- node(n440,refuted).
node(n439,refuted) :- node(n441,refuted).
node(n439,unknown) :- \+ node(n439,supported), \+ node(n439,refuted).
node(n443,supported) :- status(o_9642216e7b21e53e3be9,supported).
node(n443,refuted) :- status(o_9642216e7b21e53e3be9,refuted).
node(n443,unknown) :- status(o_9642216e7b21e53e3be9,unknown).
node(n442,supported) :- node(n440,supported), node(n443,supported).
node(n442,refuted) :- node(n440,refuted).
node(n442,refuted) :- node(n443,refuted).
node(n442,unknown) :- \+ node(n442,supported), \+ node(n442,refuted).
node(n445,supported) :- status(o_e23d3c31812a001540ca,supported).
node(n445,refuted) :- status(o_e23d3c31812a001540ca,refuted).
node(n445,unknown) :- status(o_e23d3c31812a001540ca,unknown).
node(n444,supported) :- node(n440,supported), node(n445,supported).
node(n444,refuted) :- node(n440,refuted).
node(n444,refuted) :- node(n445,refuted).
node(n444,unknown) :- \+ node(n444,supported), \+ node(n444,refuted).
node(n446,supported) :- node(n441,supported), node(n443,supported).
node(n446,refuted) :- node(n441,refuted).
node(n446,refuted) :- node(n443,refuted).
node(n446,unknown) :- \+ node(n446,supported), \+ node(n446,refuted).
node(n447,supported) :- node(n441,supported), node(n445,supported).
node(n447,refuted) :- node(n441,refuted).
node(n447,refuted) :- node(n445,refuted).
node(n447,unknown) :- \+ node(n447,supported), \+ node(n447,refuted).
node(n448,supported) :- node(n443,supported), node(n445,supported).
node(n448,refuted) :- node(n443,refuted).
node(n448,refuted) :- node(n445,refuted).
node(n448,unknown) :- \+ node(n448,supported), \+ node(n448,refuted).
node(n438,refuted) :- node(n439,refuted), node(n442,refuted), node(n444,refuted), node(n446,refuted), node(n447,refuted), node(n448,refuted).
node(n438,supported) :- node(n439,supported).
node(n438,supported) :- node(n442,supported).
node(n438,supported) :- node(n444,supported).
node(n438,supported) :- node(n446,supported).
node(n438,supported) :- node(n447,supported).
node(n438,supported) :- node(n448,supported).
node(n438,unknown) :- \+ node(n438,supported), \+ node(n438,refuted).
verdict(c_dbbe07b9d478ad55,supported) :- node(n438,supported).
query(verdict(c_dbbe07b9d478ad55,supported)).
verdict(c_dbbe07b9d478ad55,refuted) :- node(n438,refuted).
query(verdict(c_dbbe07b9d478ad55,refuted)).
verdict(c_dbbe07b9d478ad55,unknown) :- node(n438,unknown).
query(verdict(c_dbbe07b9d478ad55,unknown)).
node(n451,supported) :- status(o_fd287189348bd1bc6e3a,supported).
node(n451,refuted) :- status(o_fd287189348bd1bc6e3a,refuted).
node(n451,unknown) :- status(o_fd287189348bd1bc6e3a,unknown).
node(n452,supported) :- status(o_fbf720997f233ed04793,supported).
node(n452,refuted) :- status(o_fbf720997f233ed04793,refuted).
node(n452,unknown) :- status(o_fbf720997f233ed04793,unknown).
node(n450,supported) :- node(n451,supported), node(n452,supported).
node(n450,refuted) :- node(n451,refuted).
node(n450,refuted) :- node(n452,refuted).
node(n450,unknown) :- \+ node(n450,supported), \+ node(n450,refuted).
node(n454,supported) :- status(o_ec97b5b8b60b39959730,supported).
node(n454,refuted) :- status(o_ec97b5b8b60b39959730,refuted).
node(n454,unknown) :- status(o_ec97b5b8b60b39959730,unknown).
node(n453,supported) :- node(n451,supported), node(n454,supported).
node(n453,refuted) :- node(n451,refuted).
node(n453,refuted) :- node(n454,refuted).
node(n453,unknown) :- \+ node(n453,supported), \+ node(n453,refuted).
node(n456,supported) :- status(o_43c82a9fe913bca202f4,supported).
node(n456,refuted) :- status(o_43c82a9fe913bca202f4,refuted).
node(n456,unknown) :- status(o_43c82a9fe913bca202f4,unknown).
node(n455,supported) :- node(n451,supported), node(n456,supported).
node(n455,refuted) :- node(n451,refuted).
node(n455,refuted) :- node(n456,refuted).
node(n455,unknown) :- \+ node(n455,supported), \+ node(n455,refuted).
node(n457,supported) :- node(n452,supported), node(n454,supported).
node(n457,refuted) :- node(n452,refuted).
node(n457,refuted) :- node(n454,refuted).
node(n457,unknown) :- \+ node(n457,supported), \+ node(n457,refuted).
node(n458,supported) :- node(n452,supported), node(n456,supported).
node(n458,refuted) :- node(n452,refuted).
node(n458,refuted) :- node(n456,refuted).
node(n458,unknown) :- \+ node(n458,supported), \+ node(n458,refuted).
node(n459,supported) :- node(n454,supported), node(n456,supported).
node(n459,refuted) :- node(n454,refuted).
node(n459,refuted) :- node(n456,refuted).
node(n459,unknown) :- \+ node(n459,supported), \+ node(n459,refuted).
node(n449,refuted) :- node(n450,refuted), node(n453,refuted), node(n455,refuted), node(n457,refuted), node(n458,refuted), node(n459,refuted).
node(n449,supported) :- node(n450,supported).
node(n449,supported) :- node(n453,supported).
node(n449,supported) :- node(n455,supported).
node(n449,supported) :- node(n457,supported).
node(n449,supported) :- node(n458,supported).
node(n449,supported) :- node(n459,supported).
node(n449,unknown) :- \+ node(n449,supported), \+ node(n449,refuted).
verdict(c_fd287189348bd1bc,supported) :- node(n449,supported).
query(verdict(c_fd287189348bd1bc,supported)).
verdict(c_fd287189348bd1bc,refuted) :- node(n449,refuted).
query(verdict(c_fd287189348bd1bc,refuted)).
verdict(c_fd287189348bd1bc,unknown) :- node(n449,unknown).
query(verdict(c_fd287189348bd1bc,unknown)).
node(n462,supported) :- status(o_6643bd77329be59bf5aa,supported).
node(n462,refuted) :- status(o_6643bd77329be59bf5aa,refuted).
node(n462,unknown) :- status(o_6643bd77329be59bf5aa,unknown).
node(n463,supported) :- status(o_59a964dd043e27dc26cb,supported).
node(n463,refuted) :- status(o_59a964dd043e27dc26cb,refuted).
node(n463,unknown) :- status(o_59a964dd043e27dc26cb,unknown).
node(n461,supported) :- node(n462,supported), node(n463,supported).
node(n461,refuted) :- node(n462,refuted).
node(n461,refuted) :- node(n463,refuted).
node(n461,unknown) :- \+ node(n461,supported), \+ node(n461,refuted).
node(n465,supported) :- status(o_a787c08c410b9eedad23,supported).
node(n465,refuted) :- status(o_a787c08c410b9eedad23,refuted).
node(n465,unknown) :- status(o_a787c08c410b9eedad23,unknown).
node(n464,supported) :- node(n462,supported), node(n465,supported).
node(n464,refuted) :- node(n462,refuted).
node(n464,refuted) :- node(n465,refuted).
node(n464,unknown) :- \+ node(n464,supported), \+ node(n464,refuted).
node(n467,supported) :- status(o_86e076c2592528498df6,supported).
node(n467,refuted) :- status(o_86e076c2592528498df6,refuted).
node(n467,unknown) :- status(o_86e076c2592528498df6,unknown).
node(n466,supported) :- node(n462,supported), node(n467,supported).
node(n466,refuted) :- node(n462,refuted).
node(n466,refuted) :- node(n467,refuted).
node(n466,unknown) :- \+ node(n466,supported), \+ node(n466,refuted).
node(n468,supported) :- node(n463,supported), node(n465,supported).
node(n468,refuted) :- node(n463,refuted).
node(n468,refuted) :- node(n465,refuted).
node(n468,unknown) :- \+ node(n468,supported), \+ node(n468,refuted).
node(n469,supported) :- node(n463,supported), node(n467,supported).
node(n469,refuted) :- node(n463,refuted).
node(n469,refuted) :- node(n467,refuted).
node(n469,unknown) :- \+ node(n469,supported), \+ node(n469,refuted).
node(n470,supported) :- node(n465,supported), node(n467,supported).
node(n470,refuted) :- node(n465,refuted).
node(n470,refuted) :- node(n467,refuted).
node(n470,unknown) :- \+ node(n470,supported), \+ node(n470,refuted).
node(n460,refuted) :- node(n461,refuted), node(n464,refuted), node(n466,refuted), node(n468,refuted), node(n469,refuted), node(n470,refuted).
node(n460,supported) :- node(n461,supported).
node(n460,supported) :- node(n464,supported).
node(n460,supported) :- node(n466,supported).
node(n460,supported) :- node(n468,supported).
node(n460,supported) :- node(n469,supported).
node(n460,supported) :- node(n470,supported).
node(n460,unknown) :- \+ node(n460,supported), \+ node(n460,refuted).
verdict(c_6643bd77329be59b,supported) :- node(n460,supported).
query(verdict(c_6643bd77329be59b,supported)).
verdict(c_6643bd77329be59b,refuted) :- node(n460,refuted).
query(verdict(c_6643bd77329be59b,refuted)).
verdict(c_6643bd77329be59b,unknown) :- node(n460,unknown).
query(verdict(c_6643bd77329be59b,unknown)).
node(n473,supported) :- node(n440,refuted).
node(n473,refuted) :- node(n440,supported).
node(n473,unknown) :- \+ node(n473,supported), \+ node(n473,refuted).
node(n474,supported) :- node(n441,refuted).
node(n474,refuted) :- node(n441,supported).
node(n474,unknown) :- \+ node(n474,supported), \+ node(n474,refuted).
node(n472,supported) :- node(n473,supported), node(n474,supported).
node(n472,refuted) :- node(n473,refuted).
node(n472,refuted) :- node(n474,refuted).
node(n472,unknown) :- \+ node(n472,supported), \+ node(n472,refuted).
node(n476,supported) :- node(n443,refuted).
node(n476,refuted) :- node(n443,supported).
node(n476,unknown) :- \+ node(n476,supported), \+ node(n476,refuted).
node(n475,supported) :- node(n473,supported), node(n476,supported).
node(n475,refuted) :- node(n473,refuted).
node(n475,refuted) :- node(n476,refuted).
node(n475,unknown) :- \+ node(n475,supported), \+ node(n475,refuted).
node(n478,supported) :- node(n445,refuted).
node(n478,refuted) :- node(n445,supported).
node(n478,unknown) :- \+ node(n478,supported), \+ node(n478,refuted).
node(n477,supported) :- node(n473,supported), node(n478,supported).
node(n477,refuted) :- node(n473,refuted).
node(n477,refuted) :- node(n478,refuted).
node(n477,unknown) :- \+ node(n477,supported), \+ node(n477,refuted).
node(n479,supported) :- node(n474,supported), node(n476,supported).
node(n479,refuted) :- node(n474,refuted).
node(n479,refuted) :- node(n476,refuted).
node(n479,unknown) :- \+ node(n479,supported), \+ node(n479,refuted).
node(n480,supported) :- node(n474,supported), node(n478,supported).
node(n480,refuted) :- node(n474,refuted).
node(n480,refuted) :- node(n478,refuted).
node(n480,unknown) :- \+ node(n480,supported), \+ node(n480,refuted).
node(n481,supported) :- node(n476,supported), node(n478,supported).
node(n481,refuted) :- node(n476,refuted).
node(n481,refuted) :- node(n478,refuted).
node(n481,unknown) :- \+ node(n481,supported), \+ node(n481,refuted).
node(n471,refuted) :- node(n472,refuted), node(n475,refuted), node(n477,refuted), node(n479,refuted), node(n480,refuted), node(n481,refuted).
node(n471,supported) :- node(n472,supported).
node(n471,supported) :- node(n475,supported).
node(n471,supported) :- node(n477,supported).
node(n471,supported) :- node(n479,supported).
node(n471,supported) :- node(n480,supported).
node(n471,supported) :- node(n481,supported).
node(n471,unknown) :- \+ node(n471,supported), \+ node(n471,refuted).
verdict(c_0077992c2dd07923,supported) :- node(n471,supported).
query(verdict(c_0077992c2dd07923,supported)).
verdict(c_0077992c2dd07923,refuted) :- node(n471,refuted).
query(verdict(c_0077992c2dd07923,refuted)).
verdict(c_0077992c2dd07923,unknown) :- node(n471,unknown).
query(verdict(c_0077992c2dd07923,unknown)).
node(n484,supported) :- node(n451,refuted).
node(n484,refuted) :- node(n451,supported).
node(n484,unknown) :- \+ node(n484,supported), \+ node(n484,refuted).
node(n485,supported) :- node(n452,refuted).
node(n485,refuted) :- node(n452,supported).
node(n485,unknown) :- \+ node(n485,supported), \+ node(n485,refuted).
node(n483,supported) :- node(n484,supported), node(n485,supported).
node(n483,refuted) :- node(n484,refuted).
node(n483,refuted) :- node(n485,refuted).
node(n483,unknown) :- \+ node(n483,supported), \+ node(n483,refuted).
node(n487,supported) :- node(n454,refuted).
node(n487,refuted) :- node(n454,supported).
node(n487,unknown) :- \+ node(n487,supported), \+ node(n487,refuted).
node(n486,supported) :- node(n484,supported), node(n487,supported).
node(n486,refuted) :- node(n484,refuted).
node(n486,refuted) :- node(n487,refuted).
node(n486,unknown) :- \+ node(n486,supported), \+ node(n486,refuted).
node(n489,supported) :- node(n456,refuted).
node(n489,refuted) :- node(n456,supported).
node(n489,unknown) :- \+ node(n489,supported), \+ node(n489,refuted).
node(n488,supported) :- node(n484,supported), node(n489,supported).
node(n488,refuted) :- node(n484,refuted).
node(n488,refuted) :- node(n489,refuted).
node(n488,unknown) :- \+ node(n488,supported), \+ node(n488,refuted).
node(n490,supported) :- node(n485,supported), node(n487,supported).
node(n490,refuted) :- node(n485,refuted).
node(n490,refuted) :- node(n487,refuted).
node(n490,unknown) :- \+ node(n490,supported), \+ node(n490,refuted).
node(n491,supported) :- node(n485,supported), node(n489,supported).
node(n491,refuted) :- node(n485,refuted).
node(n491,refuted) :- node(n489,refuted).
node(n491,unknown) :- \+ node(n491,supported), \+ node(n491,refuted).
node(n492,supported) :- node(n487,supported), node(n489,supported).
node(n492,refuted) :- node(n487,refuted).
node(n492,refuted) :- node(n489,refuted).
node(n492,unknown) :- \+ node(n492,supported), \+ node(n492,refuted).
node(n482,refuted) :- node(n483,refuted), node(n486,refuted), node(n488,refuted), node(n490,refuted), node(n491,refuted), node(n492,refuted).
node(n482,supported) :- node(n483,supported).
node(n482,supported) :- node(n486,supported).
node(n482,supported) :- node(n488,supported).
node(n482,supported) :- node(n490,supported).
node(n482,supported) :- node(n491,supported).
node(n482,supported) :- node(n492,supported).
node(n482,unknown) :- \+ node(n482,supported), \+ node(n482,refuted).
verdict(c_fbf720997f233ed0,supported) :- node(n482,supported).
query(verdict(c_fbf720997f233ed0,supported)).
verdict(c_fbf720997f233ed0,refuted) :- node(n482,refuted).
query(verdict(c_fbf720997f233ed0,refuted)).
verdict(c_fbf720997f233ed0,unknown) :- node(n482,unknown).
query(verdict(c_fbf720997f233ed0,unknown)).
node(n495,supported) :- node(n462,refuted).
node(n495,refuted) :- node(n462,supported).
node(n495,unknown) :- \+ node(n495,supported), \+ node(n495,refuted).
node(n496,supported) :- node(n463,refuted).
node(n496,refuted) :- node(n463,supported).
node(n496,unknown) :- \+ node(n496,supported), \+ node(n496,refuted).
node(n494,supported) :- node(n495,supported), node(n496,supported).
node(n494,refuted) :- node(n495,refuted).
node(n494,refuted) :- node(n496,refuted).
node(n494,unknown) :- \+ node(n494,supported), \+ node(n494,refuted).
node(n498,supported) :- node(n465,refuted).
node(n498,refuted) :- node(n465,supported).
node(n498,unknown) :- \+ node(n498,supported), \+ node(n498,refuted).
node(n497,supported) :- node(n495,supported), node(n498,supported).
node(n497,refuted) :- node(n495,refuted).
node(n497,refuted) :- node(n498,refuted).
node(n497,unknown) :- \+ node(n497,supported), \+ node(n497,refuted).
node(n500,supported) :- node(n467,refuted).
node(n500,refuted) :- node(n467,supported).
node(n500,unknown) :- \+ node(n500,supported), \+ node(n500,refuted).
node(n499,supported) :- node(n495,supported), node(n500,supported).
node(n499,refuted) :- node(n495,refuted).
node(n499,refuted) :- node(n500,refuted).
node(n499,unknown) :- \+ node(n499,supported), \+ node(n499,refuted).
node(n501,supported) :- node(n496,supported), node(n498,supported).
node(n501,refuted) :- node(n496,refuted).
node(n501,refuted) :- node(n498,refuted).
node(n501,unknown) :- \+ node(n501,supported), \+ node(n501,refuted).
node(n502,supported) :- node(n496,supported), node(n500,supported).
node(n502,refuted) :- node(n496,refuted).
node(n502,refuted) :- node(n500,refuted).
node(n502,unknown) :- \+ node(n502,supported), \+ node(n502,refuted).
node(n503,supported) :- node(n498,supported), node(n500,supported).
node(n503,refuted) :- node(n498,refuted).
node(n503,refuted) :- node(n500,refuted).
node(n503,unknown) :- \+ node(n503,supported), \+ node(n503,refuted).
node(n493,refuted) :- node(n494,refuted), node(n497,refuted), node(n499,refuted), node(n501,refuted), node(n502,refuted), node(n503,refuted).
node(n493,supported) :- node(n494,supported).
node(n493,supported) :- node(n497,supported).
node(n493,supported) :- node(n499,supported).
node(n493,supported) :- node(n501,supported).
node(n493,supported) :- node(n502,supported).
node(n493,supported) :- node(n503,supported).
node(n493,unknown) :- \+ node(n493,supported), \+ node(n493,refuted).
verdict(c_59a964dd043e27dc,supported) :- node(n493,supported).
query(verdict(c_59a964dd043e27dc,supported)).
verdict(c_59a964dd043e27dc,refuted) :- node(n493,refuted).
query(verdict(c_59a964dd043e27dc,refuted)).
verdict(c_59a964dd043e27dc,unknown) :- node(n493,unknown).
query(verdict(c_59a964dd043e27dc,unknown)).
