# AViD project guidance

## Sentence splitting fallback — user clarification12 November2026

The intended rewrite is split-and-rephrase: break a difficult claim into simpler subclaims while retaining meaning, shared entities/events and depiction/speech/OCR or other context links. The earlier one-sentence restriction was too narrow and is historical. Keep direct compilation first and never rewrite a passing original. No automatic scale-up is enabled.

Read docs/claim_split_20261112.md and the report Sentence splitting tab. One frozen Qwen prompt on31 previously inspected failures produces65/77 passing clauses and20 all-component passes, but0 approved complete automatic results. Seven selected assistant-written splits give18/18 component passes and4 faithful linked compositions; an eighth no-audio guard is refused. These are compiler-author diagnostics, not model gains, independent gold or corpus accuracy. Frozen38 direct-compiler files stay unchanged. New adapter preserves context and shared mentions; original corpus counts stay2103/1924. No new media/native inference/training. Proposed next: simplify generation/reference alignment, then repeat a fixed fidelity evaluation before scale-up.


## Current paper direction — accepted 2026-10-14

Follow ADR-023 in docs/project_notes/decisions.md: probabilistic parsing for multimodal claim verification. Compile claims into probabilistic logic, keep media models frozen, and learn small relation classifiers. Predefined and learned functions are interchangeable; inference considers alternative evidence assignments. An existing DeepProbLog-like backend is a valid implementation choice.

The user selected this as the paper direction, likely finalized. Earlier tree-CRF and temporal-only proposals are historical comparisons. Experimental results can refine the design; do not automatically reopen the paper direction from old notes.

Read site/proposals/probabilistic-verification.html or its generator scripts/build_probabilistic_verification_proposal.py for the current design. Logistic regression and a small MLP are the initial classifiers; frozen BERT-style features are optional. Decoder-only models remain frozen evidence/parsing modules or baselines.

## Terminology and memory

- Read docs/project_notes/terminology.md and CLAUDE.md before writing documentation or implementation.
- Use standard NLP terms and plain language. Define semantic roles, logical forms, neural predicates, and calibration when needed. Do not invent labels or acronyms for familiar components.
- Check decisions.md before architecture changes, key_facts.md before experiments, and bugs.md when diagnosing known failures. Log significant work in issues.md.
- Keep supported/refuted/insufficient evidence distinct, preserve evidence-route meaning, and distinguish source assertions from direct event evidence.
- Keep proposed methods and resource estimates separate from completed experiments. Never infer new accuracy results from this design page.
- Preserve existing evaluation annotations and artifacts. Use separate training/calibration data and split by source video.

## Rewrite fallback — confirmed12 November2026

Compile the original claim first. Only a strict unsupported result may trigger rewriting; this includes a diagnostic candidate rejected by content checks. A compiled original must be returned unchanged, without loading/querying the rewriter. A separate semantic concern is not a trigger when direct compilation passes. Historical passing-control/guard model probes are diagnostic records, not exceptions to this policy. Keep exact prompts, model settings, raw responses and failure reasons inspectable.
