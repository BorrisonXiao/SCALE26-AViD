"""Parse each short output sentence with the unchanged Stanza/BERT-SRL models."""
import argparse,hashlib,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/claim_split_20261112'
def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def main():
 global RUN
 p=argparse.ArgumentParser();p.add_argument('--srl',action='store_true');p.add_argument('--run',type=Path,default=RUN);a=p.parse_args();RUN=a.run;started=time.perf_counter()
 if not a.srl:
  from probabilistic_verification.parsing import DependencyParser
  from probabilistic_verification.claim_split import validate_split
  parser=DependencyParser();rows=[]
  for raw in read(RUN/'raw.jsonl'):
   row=dict(claim_id=raw['claim_id'],proposal=json.loads(raw['raw']),clauses=[])
   try:validate_split(row['proposal'])
   except Exception as e:row['validation_error']=str(e)
   for c in row['proposal']['clauses']:
    part=dict(c)
    try:part['record']=dict(claim_id=row['claim_id']+'__'+c['id'],text=c['text'],tokens=parser.parse(c['text']),srl=None)
    except ValueError as e:part['parse_error']=str(e)
    row['clauses'].append(part)
   rows.append(row)
  write(RUN/'dependencies.jsonl',rows);(RUN/'dependency_provenance.json').write_text(json.dumps(dict(parser.provenance,elapsed_seconds=time.perf_counter()-started),indent=2)+'\n')
 else:
  import torch
  from allennlp.predictors.predictor import Predictor
  from run_srl_baseline import bio_to_spans
  torch.set_num_threads(2);meta=next(json.loads(p.read_text())for p in Path('/home/hltcoe/cxiao/.allennlp/cache').glob('*.json')if 'structured-prediction-srl-bert'in p.read_text());model=Path(meta['cached_path']);predictor=Predictor.from_path(str(model),cuda_device=-1)
  rows=read(RUN/'dependencies.jsonl');pending=[c for r in rows for c in r['clauses']if 'record'in c]
  for start in range(0,len(pending),8):
   batch=pending[start:start+8];outputs=predictor.predict_batch_json([dict(sentence=c['text'])for c in batch])
   for part,out in zip(batch,outputs):
    words=out['words'];frames=[]
    for v in out['verbs']:
     spans=bio_to_spans(v['tags']);verb=next(([s,e]for role,s,e in spans if role=='V'),None)
     frames.append(dict(verb=v['verb'],verb_span=verb,args=[dict(role=role,start=s,end=e,text=' '.join(words[s:e+1]))for role,s,e in spans if role!='V']))
    part['record']['srl']=dict(words=words,frames=frames)
   print('SRL',min(start+8,len(pending)),'/',len(pending),flush=True)
  write(RUN/'parsed.jsonl',rows);(RUN/'srl_provenance.json').write_text(json.dumps(dict(model=meta,sha256=hashlib.sha256(model.read_bytes()).hexdigest(),device='cpu',claims=len(pending),elapsed_seconds=time.perf_counter()-started),indent=2)+'\n')
if __name__=='__main__':main()
