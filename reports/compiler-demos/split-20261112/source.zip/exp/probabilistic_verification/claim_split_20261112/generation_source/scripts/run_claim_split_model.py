"""Frozen text-only split-and-rephrase, strictly after direct compilation fails."""
import argparse,hashlib,importlib.metadata,json,os,shutil,time
from pathlib import Path
from probabilistic_verification.claim_rewrite import prepare_rewrite_inputs
from probabilistic_verification.claim_split import SCHEMA,messages
from run_content_relations_census import compile_one
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--input',type=Path,required=True);a=p.parse_args();a.run.mkdir(parents=True,exist_ok=True)
 records=list(map(json.loads,a.input.read_text().splitlines()));records,routes=prepare_rewrite_inputs(records,compile_one);output=a.run/'raw.jsonl';assert not output.exists()
 (a.run/'routing.json').write_text(json.dumps(routes,indent=2)+'\n')
 if not records:return
 source={}
 for name in ['scripts/run_claim_split_model.py','scripts/probabilistic_verification/claim_split.py','scripts/prompts_phase2.py']:
  path=ROOT/name;target=a.run/'generation_source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target);source[name]=hashlib.sha256(path.read_bytes()).hexdigest()
 from vllm import LLM,SamplingParams
 from vllm.sampling_params import StructuredOutputsParams
 import torch
 path=Path('/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507')
 config=dict(model=str(path),dtype='float16',temperature=0,seed=42,max_tokens=2048,vllm=importlib.metadata.version('vllm'),transformers=importlib.metadata.version('transformers'),
   job_id=os.getenv('SLURM_JOB_ID'),gpu_names=[torch.cuda.get_device_name(i)for i in range(torch.cuda.device_count())],source_sha256=source,
   model_config_sha256=hashlib.sha256((path/'config.json').read_bytes()).hexdigest(),input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),eligible=len(records))
 (a.run/'model_config.json').write_text(json.dumps(config,indent=2)+'\n')
 llm=LLM(model=str(path),dtype='float16',tensor_parallel_size=1,max_model_len=8192,max_num_seqs=16,gpu_memory_utilization=.90,enforce_eager=True,enable_prefix_caching=True,seed=42)
 tok=llm.get_tokenizer();params=SamplingParams(temperature=0,seed=42,max_tokens=2048,structured_outputs=StructuredOutputsParams(json=SCHEMA))
 by_id={r['claim_id']:r for r in routes}
 for start in range(0,len(records),32):
  batch=records[start:start+32];requests=[messages(r,dict(error=by_id[r['claim_id']]['direct_code'],message=by_id[r['claim_id']]['direct_reason']))for r in batch]
  prompts=[tok.apply_chat_template(m,tokenize=False,add_generation_prompt=True)for m in requests];begun=time.perf_counter();outputs=llm.generate(prompts,params,use_tqdm=False);elapsed=time.perf_counter()-begun
  with output.open('a')as f:
   for row,request,out in zip(batch,requests,outputs):
    result=out.outputs[0];f.write(json.dumps(dict(claim_id=row['claim_id'],messages=request,raw=result.text,finish_reason=result.finish_reason,input_tokens=len(out.prompt_token_ids),output_tokens=len(result.token_ids),batch_seconds=elapsed,batch_size=len(batch)),ensure_ascii=False)+'\n')
  print('Saved',min(start+32,len(records)),'/',len(records),'in',round(elapsed,2),'seconds',flush=True)
if __name__=='__main__':main()
