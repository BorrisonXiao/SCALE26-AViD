"""Sentence splitting proposals; composition uses existing logical-form operators."""
import json
import prompts_phase2 as P
from .claim_rewrite import request_data

def obj(properties):return dict(type='object',properties=properties,required=list(properties),additionalProperties=False)
STR=dict(type='string')
SCHEMA=obj(dict(action=dict(type='string',enum=['split','keep','refuse']),
    clauses=dict(type='array',maxItems=8,items=obj(dict(id=STR,text=STR,parent=dict(type=['string','null']),
        relation=dict(type='string',enum=['root','and','depiction','speech','ocr','purpose','relative','before','after','while']),target=STR))),
    shared=dict(type='array',items=obj(dict(mentions=dict(type='array',minItems=2,items=obj(dict(clause=STR,text=STR)))))),reason=STR))

def messages(record, diagnostic):
    return [dict(role='system',content=P.CLAIM_SPLIT_SYSTEM),dict(role='user',content=json.dumps(dict(request_data(record),compiler_diagnostic=diagnostic),ensure_ascii=False,separators=(',',':')))]

def validate_split(proposal):
    import jsonschema
    jsonschema.validate(proposal,SCHEMA)
    clauses=proposal['clauses'];seen=set()
    if proposal['action']!='split':
        if clauses or proposal['shared']:raise ValueError('keep/refuse must not add clauses.')
        return
    if len(clauses)<2:raise ValueError('A split needs at least two clauses.')
    for c in clauses:
        if c['id']in seen or not c['text'].strip():raise ValueError('Clause ID repeated or text empty.')
        if c['parent']is None:
            if seen or c['relation']!='root':raise ValueError('Exactly one first root is required.')
        elif c['parent']not in seen or c['relation']=='root':raise ValueError('A parent must precede its child.')
        seen.add(c['id'])
    for group in proposal['shared']:
        if len({m['clause']for m in group['mentions']})<2:raise ValueError('Shared mention groups must connect different clauses.')
        for mention in group['mentions']:
            c=next((c for c in clauses if c['id']==mention['clause']),None)
            if not c or not mention['text'] or mention['text']not in c['text']:raise ValueError('A shared mention must occur in its clause.')
