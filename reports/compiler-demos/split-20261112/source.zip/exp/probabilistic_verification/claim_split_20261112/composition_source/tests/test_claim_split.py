"""Context and identity invariants on supplied simple-sentence logical forms."""
import copy
import pytest
from probabilistic_verification.claim_split import validate_split
from probabilistic_verification.split_composition import compose_split,CompositionError
from probabilistic_verification.logical_form_v2 import ScopedCompiler
from test_scoped_srl import constructed_record

def components():
 definitions=[('c1','A photo depicts Alice.',[
  ('A','a','DET',2,'det'),('photo','photo','NOUN',3,'nsubj'),('depicts','depict','VERB',0,'root'),('Alice','Alice','PROPN',3,'obj'),('.','.','PUNCT',3,'punct')],
  [dict(id='x2',text='photo'),dict(id='x4',text='Alice')],dict(op='event',id='e3',predicate='depict',anchor='depicts',arguments=dict(ARG0='x2',ARG1='x4'))),
 ('c2','Alice holds a blue cup.',[
  ('Alice','Alice','PROPN',2,'nsubj'),('holds','hold','VERB',0,'root'),('a','a','DET',5,'det'),('blue','blue','ADJ',5,'amod'),('cup','cup','NOUN',2,'obj'),('.','.','PUNCT',2,'punct')],
  [dict(id='x1',text='Alice'),dict(id='x5',text='cup',properties=[dict(role='mod',value='blue')])],dict(op='event',id='e2',predicate='hold',anchor='holds',arguments=dict(ARG0='x1',ARG1='x5')))]
 rows={}
 for cid,text,specs,entities,formula in definitions:
  r=constructed_record(text,specs,[]);c=ScopedCompiler().compile(cid,text,r['tokens'],dict(version='logical-form-v2',kind='claim',entities=entities,formula=formula));rows[cid]=dict(status='compiled',compilation=c.to_dict())
 return rows
def proposal():return dict(action='split',clauses=[dict(id='c1',text='A photo depicts Alice.',parent=None,relation='root',target=''),dict(id='c2',text='Alice holds a blue cup.',parent='c1',relation='depiction',target='Alice')],shared=[dict(mentions=[dict(clause='c1',text='Alice'),dict(clause='c2',text='Alice')])],reason='Test')

def test_depicted_event_never_becomes_world_event():
 c=compose_split('test',proposal(),components());hold=next(e for e in c.metadata['events'].values()if e['predicate']=='hold')
 assert hold['scope']!='world'and hold['route']=='visual_depiction'
 assert all(a.arguments[a.arguments.index('route')+1]=='visual_depiction'for a in c.atoms if a.predicate=='property'and 'blue'in a.arguments)
 assert sum(a.predicate=='referent'and 'Alice'in a.arguments for a in c.atoms)==1

def test_flat_and_loses_depiction_context():
 c=compose_split('test',proposal(),components(),flat=True);hold=next(e for e in c.metadata['events'].values()if e['predicate']=='hold')
 assert hold['scope']=='world'

def test_missing_identity_link_is_refused():
 p=proposal();p['shared']=[]
 with pytest.raises(CompositionError,match='reuse'):compose_split('test',p,components())

def test_different_entities_cannot_be_merged():
 p=proposal();p['shared'][0]['mentions'][0]['text']='photo'
 with pytest.raises(CompositionError,match='different compiled descriptions'):compose_split('test',p,components())

def test_component_failure_remains_a_refusal():
 rows=components();rows['c2']=dict(status='unsupported',reason='Missing role')
 with pytest.raises(CompositionError,match='Missing role'):compose_split('test',proposal(),rows)

def test_parent_negation_is_not_bypassed():
 rows=components();f=rows['c1']['compilation']['metadata']['logical_form'];f['formula']=dict(op='not',child=f['formula'])
 with pytest.raises(CompositionError,match='affirmative'):compose_split('test',proposal(),rows)

def test_shared_mentions_cannot_drop_a_modifier():
 rows=components();rows['c2']['compilation']['metadata']['logical_form']['entities'][0]['properties']=[dict(role='mod',value='tall')]
 with pytest.raises(CompositionError,match='different compiled descriptions'):compose_split('test',proposal(),rows)

def test_parent_must_precede_child():
 p=proposal();p['clauses'][1]['parent']='c9'
 with pytest.raises(ValueError):validate_split(p)

def test_keep_cannot_silently_add_clauses():
 p=proposal();p['action']='keep'
 with pytest.raises(ValueError):validate_split(p)

def test_shared_group_must_cross_clauses():
 p=proposal();p['shared'][0]['mentions'][1]=dict(clause='c1',text='Alice')
 with pytest.raises(ValueError):validate_split(p)

def test_shared_description_difference_is_not_silently_ignored_by_flat_baseline():
 rows=components();rows['c2']['compilation']['metadata']['logical_form']['entities'][0]['type']='group'
 with pytest.raises(CompositionError):compose_split('test',proposal(),rows,flat=True)
