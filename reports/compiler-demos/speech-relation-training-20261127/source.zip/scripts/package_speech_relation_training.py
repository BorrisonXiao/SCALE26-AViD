"""Archive the reviewed dataset, frozen features, and offline replay."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from speech_relation_training_report import ROOT, RUN, URL

OUTPUTS = ('train.jsonl','calibration.jsonl','audit.json','summary.json','features.npy','features_index.json')


def main():
    paths = [ROOT/name for name in ('requirements-compilation.txt','requirements-verification.txt')]
    paths.extend(RUN/name for name in (*OUTPUTS,'annotations.tsv','context_pairs.tsv','spans.json',
                                       'source_manifest.json','source_overlap.json','tests.xml'))
    with ZipFile(ROOT/'site/reports/compiler-demos/option-binding-20261127/source.zip') as prior:
        paths.extend(ROOT/name for name in prior.namelist() if name.startswith('scripts/'))
    paths.extend(ROOT/'scripts'/f'{name}.py' for name in ('prepare_speech_relation_training',
                 'cache_speech_relation_features','speech_relation_training_report','package_speech_relation_training'))
    data = {str(path.relative_to(ROOT)):path.read_bytes() for path in paths}
    data['README.md'] = (ROOT/'docs/speech_relation_training_20261127.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({name:sha256((RUN/name).read_bytes()).hexdigest()
                                            for name in OUTPUTS}, indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(exist_ok=True, parents=True)
    with ZipFile(target,'w') as archive:
        for name, contents in sorted(data.items()):
            member = ZipInfo(name, date_time=(2026,11,27,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member,contents)
    print(f'Archived {len(data)} files for replay.')


if __name__ == '__main__':
    main()
