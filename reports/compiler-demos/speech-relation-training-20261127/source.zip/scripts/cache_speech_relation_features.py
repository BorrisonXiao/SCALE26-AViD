"""Extract label-free transcript/claim features from a frozen DeBERTa encoder."""
import json

import numpy as np
import torch

from evaluate_ami_speech_scoring import MODELS
from evaluate_reported_or_transcripts import load_nli_model
from prepare_compiler_fallback import dump
from prepare_speech_relation_training import RUN, SPLITS, digest, render

VIEWS = ('claim', 'relation')


def read_pairs():
    pairs = []
    keys = []
    for split in SPLITS:
        with (RUN/f'{split}.jsonl').open(encoding='utf-8') as file:
            for line in file:
                row = json.loads(line)
                assert row['split'] == split
                keys.append(dict(id=row['id'], split=split))
                text = row['evidence']['text']
                structured = render(row['options'], row['relation'], row['qualifier'])
                pairs.append(((text, row['claim']), (text, structured)))
    return keys, pairs


def main():
    rows, pairs = read_pairs()
    unique = sorted({pair for views in pairs for pair in views})
    tokenizer, model, snapshot = load_nli_model(MODELS['deberta'])
    model.requires_grad_(False)
    device_limit = min(tokenizer.model_max_length, model.config.max_position_embeddings)
    encoded = {}
    maximum = 0
    with torch.inference_mode():
        for start in range(0, len(unique), 16):
            batch = unique[start:start+16]
            premises, hypotheses = zip(*batch)
            inputs = tokenizer(list(premises), list(hypotheses), padding=True, truncation=False, return_tensors='pt')
            maximum = max(maximum, inputs['input_ids'].shape[1])
            assert maximum <= device_limit, (maximum, device_limit)
            hidden = model.deberta(**inputs).last_hidden_state
            pooled = model.pooler(hidden)
            values = pooled.float().cpu().numpy()
            encoded.update(zip(batch, values, strict=True))
    features = np.asarray([[encoded[p] for p in row] for row in pairs], dtype=np.float32)
    assert features.shape[:2] == (len(rows), len(VIEWS)) and np.isfinite(features).all()
    target = RUN/'features.npy'
    np.save(target, features, allow_pickle=False)
    dump(RUN/'features_index.json', dict(rows=rows, views=list(VIEWS), shape=list(features.shape),
         dtype=str(features.dtype), unique_inputs=len(unique), max_input_tokens=maximum, max_model_tokens=device_limit,
         feature_sha256=digest(target), checkpoint=snapshot, torch_version=torch.__version__))
    print(f'Saved {features.shape} frozen features for {len(rows)} rows ({len(unique)} unique input pairs).', flush=True)


if __name__ == '__main__':
    main()
