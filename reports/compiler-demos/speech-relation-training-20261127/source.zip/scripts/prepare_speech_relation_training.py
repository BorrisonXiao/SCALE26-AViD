"""Prepare grouped transcript examples for a small speech relation classifier."""
from argparse import ArgumentParser
from collections import Counter
import csv
from hashlib import sha256
import json
from pathlib import Path
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from evaluate_ami_implicit_binding import segments
from prepare_ami_probabilistic_binding import utterance
from prepare_ami_window_comparison import series
from prepare_compiler_fallback import ROOT, dump
from prepare_or_source_evaluation import RUN as TRANSCRIPTS, read

BASE = TRANSCRIPTS.parent
RUN = BASE/'speech_relation_training_20261127'
SOURCE = TRANSCRIPTS/'source/ami_public_manual_1.6.2.zip'
RESERVED_PATHS = {
    'ami_probabilistic_binding_20261126/cases.json': None,
    'ami_speaker_binding_20261126/binding_cases.json': None,
    'ami_speech_verification_20261126/cases.json': 'rows',
    'ami_window_comparison_20261126/speech_cases.json': None,
    'binding_followup_20261127/speech_inputs.json': 'rows',
    'binding_generalization_20261127/implicit_cases.json': 'rows',
    'option_binding_20261127/speech_inputs.json': 'rows',
    'or_followup_20261119/transcripts/segments.json': None,
    'or_source_evaluation_20261119/transcripts/cases.json': 'cases',
    'scope_and_alignment_20261119/speech_cases.json': None,
    'scope_and_alignment_20261119/speech_inputs.json': None,
}
MARKERS = {
    'contrast': re.compile(r'\b(?:instead of|rather than|prefer|alternativ\w*|choice|choose|versus|one way|the other way|\w+ than|\w+ better|replac\w*)\b', re.I),
    'explicit_or': re.compile(r'\b(?:or)\b', re.I),
    'addition': re.compile(r'\b(?:(?:and|but) also|as well as|together with|in addition to|(?:can|could|should|would) also)\b', re.I),
}
SPLITS = {'train': ('IB4002', 'IB4004', 'IB4005'), 'calibration': ('IN1005', 'IN1014')}
RELATIONS = {
    'alternatives': 'The speaker presents {first} and {second} as alternatives.',
    'preference': 'The speaker presents {first} as preferable to {second}.',
    'together': 'The speaker presents {first} together with {second}, as a combination.',
}


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def reservations():
    records = []
    for path, key in RESERVED_PATHS.items():
        full = BASE/path
        data = read(full)
        meetings = sorted({row['meeting'] for row in (data if key is None else data[key])})
        records.append(dict(path=path, sha256=digest(full), meetings=meetings))
    return records


def archive_meetings(archive):
    return sorted({Path(name).name.split('.')[0] for name in archive.namelist()
                   if name.startswith('segments/') and name.endswith('.segments.xml')})


def mine():
    evaluation = reservations()
    excluded = {series(m) for entry in evaluation for m in entry['meetings']}
    grouped = {}
    with ZipFile(SOURCE) as archive:
        meetings = archive_meetings(archive)
        for meeting in meetings:
            if series(meeting) in excluded:
                continue
            rows = []
            previous = {}
            for ident, (speaker, words) in sorted(segments(archive, meeting).items(), key=lambda row: row[1][1][0]['start']):
                row = utterance(words,speaker,ident)
                prior = previous.get(speaker)
                previous[speaker] = row
                kinds = [name for name,p in MARKERS.items() if p.search(row['text'])]
                if kinds and 7 <= len(words) <= 125:
                    if prior and row['start']-prior['end'] < 3:
                        row['previous'] = dict(id=prior['id'], text=prior['text'])
                    rows.append(dict(row, markers=kinds))
            grouped[meeting] = rows
    manifest = dict(source_sha256=digest(SOURCE), inventories=evaluation, corpus_recordings=meetings,
                    reserved_series=sorted(excluded), available_series=sorted({series(m) for m in grouped}))
    dump(RUN/'source_manifest.json', manifest)
    dump(RUN/'candidates.json', grouped)
    print('Corpus recordings', len(meetings), 'Reserved series', len(excluded), 'Candidate excerpts:',
          {meeting:len(rows) for meeting, rows in grouped.items()}, flush=True)


def read_tsv(name):
    with (RUN/name).open(encoding='utf-8', newline='') as file:
        return list(csv.DictReader(file, delimiter='\t'))


def extract():
    manifest = read(RUN/'source_manifest.json')
    assert digest(SOURCE) == manifest['source_sha256']
    wanted = {row['segment'] for row in read_tsv('annotations.tsv')}
    wanted.update(row['other_segment'] for row in read_tsv('context_pairs.tsv'))
    result = {}
    with ZipFile(SOURCE) as archive:
        for meeting in sorted({ident.split('.')[0] for ident in wanted}):
            assert series(meeting) not in manifest['reserved_series'], meeting
            source = segments(archive, meeting)
            for ident in sorted(i for i in wanted if i.split('.')[0] == meeting):
                speaker, words = source[ident]
                row = utterance(words, speaker, ident)
                result[ident] = dict(row, meeting=meeting, series=series(meeting))
    dump(RUN/'spans.json', result)


def render(options, relation, condition):
    text = RELATIONS[relation].format(first=options[0], second=options[1])
    return f'{condition}, {text[0].lower()}{text[1:]}' if condition else text


def jsonl(path, rows):
    with path.open('w', encoding='utf-8') as file:
        for row in rows:
            file.write(json.dumps(row, ensure_ascii=False)+'\n')


def normalized(text):
    return ' '.join(re.findall(r'\w+', text.casefold()))


def compare_sources():
    """Check exact 12-word fragments against all recordings in reserved series."""
    manifest = read(RUN/'source_manifest.json')
    assert digest(SOURCE) == manifest['source_sha256']
    reserved = set(manifest['reserved_series'])
    size = 12
    fragments = {}
    for ident, span in read(RUN/'spans.json').items():
        words = normalized(span['text']).split()
        for index in range(len(words)-size+1):
            fragments.setdefault(tuple(words[index:index+size]), set()).add(ident)
    matches = []
    checked = set()
    with ZipFile(SOURCE) as archive:
        for name in sorted(archive.namelist()):
            if not name.startswith('words/') or not name.endswith('.words.xml'):
                continue
            meeting = Path(name).name.split('.')[0]
            if series(meeting) not in reserved:
                continue
            checked.add(meeting)
            tokens = ET.fromstring(archive.read(name))
            words = normalized(' '.join(w.text for w in tokens if w.tag == 'w' and w.text)).split()
            found = set(fragments).intersection(tuple(words[i:i+size]) for i in range(len(words)-size+1))
            for fragment in sorted(found):
                matches.append(dict(words=' '.join(fragment), source=name, new_spans=sorted(fragments[fragment])))
    dump(RUN/'source_overlap.json', dict(fragment_size=size, checked_recordings=sorted(checked), matches=matches))
    print(f'Compared fragments with {len(checked)} recordings in reserved series. Found {len(matches)} matches.')


def build():
    manifest = read(RUN/'source_manifest.json')
    spans = read(RUN/'spans.json')
    annotations = read_tsv('annotations.tsv')
    contexts = read_tsv('context_pairs.tsv')
    context_for = {row['segment']: row for row in contexts}
    assert len(contexts) == len(context_for)
    assert len({a['segment'] for a in annotations}) == len(annotations)
    assert context_for.keys() <= {a['segment'] for a in annotations}
    split_for = {meeting: name for name, meetings in SPLITS.items() for meeting in meetings}
    assert len(split_for) == sum(map(len, SPLITS.values()))
    assert set(split_for) <= set(manifest['available_series'])
    rows = []
    for a in annotations:
        ident, relation, condition = a['segment'], a['relation'], a['condition']
        span = spans[ident]
        split = split_for[span['series']]
        options = [a['first_option'], a['second_option']]
        assert len(set(map(normalized, options))) == 2 and all(options), ident

        def add(variant, claim, args, predicate, evidence, supported, why):
            rows.append(dict(id=f'{ident}:{variant}', pair_id=ident, split=split, claim=claim,
                             options=args, relation=predicate, qualifier=condition, evidence=evidence,
                             is_supported=supported, variant=variant, review_reason=why))

        reference = render(options, relation, condition)
        add('reference', reference, options, relation, span, True, 'The excerpt states the annotated relation.')
        add('paraphrase', a['paraphrase'], options, relation, span, True, 'The wording changes and the annotated reading is preserved.')
        assert a['old_phrase'] and a['new_phrase'] and a['paraphrase'].count(a['old_phrase']) == 1, ident
        side = int(a['edit_side'])-1
        assert side in (0,1) and a['replacement'] != options[side] and a['old_phrase'] != a['new_phrase'], ident
        modified = options.copy()
        modified[side] = a['replacement']
        changed = a['paraphrase'].replace(a['old_phrase'], a['new_phrase'])
        add(a['edit_type'], changed, modified, relation, span, False,
            f'The supported paraphrase uses “{a["old_phrase"]}.” The edit uses “{a["new_phrase"]}.”')
        if relation == 'preference':
            variant, foil, swapped = 'reversed_preference', relation, options[::-1]
            reason = 'The excerpt gives the preference in the opposite direction.'
        elif relation == 'together':
            variant, foil, swapped = 'addition_as_alternatives', 'alternatives', options
            reason = 'The excerpt describes these items in combination.'
        else:
            variant, foil, swapped = 'alternatives_as_addition', 'together', options
            reason = 'The excerpt presents these items as choices.'
        add(variant, render(swapped, foil, condition), swapped, foil, span, False, reason)
        if ident in context_for:
            contrast = context_for[ident]
            other = spans[contrast['other_segment']]
            assert other['meeting'] == span['meeting'] and other['speaker'] == span['speaker'], ident
            assert other['id'] != span['id'] and set(other['word_ids']).isdisjoint(span['word_ids']), ident
            add('different_span', a['paraphrase'], options, relation, other, False, contrast['reason'])

    audit(rows, manifest)
    for split in SPLITS:
        jsonl(RUN/f'{split}.jsonl', (r for r in rows if r['split'] == split))
    print(f'Exported {len(rows)} reviewed claim and transcript pairs.', flush=True)


def audit(rows, manifest):
    assert len({r['id'] for r in rows}) == len(rows)
    assert len({(normalized(r['claim']), normalized(r['evidence']['text'])) for r in rows}) == len(rows)
    reference = {r['pair_id']: r for r in rows if r['variant'] == 'reference'}
    paraphrases = {r['pair_id']: r for r in rows if r['variant'] == 'paraphrase'}
    assert len(reference) == len(paraphrases)
    for r in rows:
        assert len(r['evidence']['word_ids']) > 0 and r['evidence']['start'] < r['evidence']['end']
        assert r['evidence']['series'] in SPLITS[r['split']]
        assert r['evidence']['series'] not in manifest['reserved_series']
        if r['variant'] == 'reversed_preference':
            assert normalized(r['claim']).split() and Counter(normalized(r['claim']).split()) == Counter(
                normalized(reference[r['pair_id']]['claim']).split())
        if r['variant'] == 'different_span':
            assert r['claim'] == paraphrases[r['pair_id']]['claim'] and r['relation'] == paraphrases[r['pair_id']]['relation']
    known = {field: set() for field in ('claim','transcript','words')}
    stats = {}
    for split in SPLITS:
        subset = [r for r in rows if r['split'] == split]
        fields = {
            'claim': {normalized(r['claim']) for r in subset},
            'transcript': {normalized(r['evidence']['text']) for r in subset},
            'words': {w for r in subset for w in r['evidence']['word_ids']},
        }
        for field,value in fields.items():
            assert known[field].isdisjoint(value), field
            known[field].update(value)
        counters = Counter(r['variant'] for r in subset)
        pos = [r for r in subset if r['is_supported']]
        stats[split] = dict(rows=len(subset), spans=len({r['evidence']['id'] for r in subset}),
                            recordings=list(SPLITS[split]), reviewed_reports=counters['reference'],
                            supported=len(pos), unsupported=len(subset)-len(pos),
                            variants=dict(sorted(counters.items())),
                            positive_relations=dict(sorted(Counter(r['relation'] for r in pos).items())),
                            speakers=len({(r['evidence']['meeting'],r['evidence']['speaker']) for r in subset}))
    dump(RUN/'audit.json', dict(splits=stats, exact_cross_split_overlap=0,
                               reserved_series_used=0, reviewed_by='implementing assistant',
                               source_sha256=manifest['source_sha256']))


if __name__ == '__main__':
    parser = ArgumentParser()
    stages = {'mine': mine, 'extract': extract, 'build': build, 'compare': compare_sources}
    parser.add_argument('stage', choices=stages)
    RUN.mkdir(exist_ok=True, parents=True)
    stages[parser.parse_args().stage]()
