"""Present the speech relation training pilot and its data checks."""
from html import escape
import json
from shutil import copy2
from xml.etree import ElementTree as ET

import numpy as np

from compiler_fallback_report import table
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from prepare_speech_relation_training import ROOT, RUN, SPLITS, digest

URL = 'compiler-demos/speech-relation-training-20261127/'
LABELS = {'train':'Training', 'calibration':'Calibration'}
RELATIONS = {'alternatives':'Alternatives', 'preference':'Preference', 'together':'Combination'}
VARIANTS = {'reference':'Reference claim', 'paraphrase':'Supported paraphrase',
            'description':'Changed description', 'quantity':'Changed quantity', 'option':'Changed option',
            'polarity':'Changed polarity', 'reversed_preference':'Reversed preference',
            'alternatives_as_addition':'Choice described as a combination',
            'addition_as_alternatives':'Combination described as a choice',
            'different_span':'Same claim with a different excerpt'}


def dataset_rows():
    return [json.loads(line) for split in SPLITS
            for line in (RUN/f'{split}.jsonl').read_text(encoding='utf-8').splitlines()]


def summarize():
    keys = [dict(id=r['id'], split=r['split']) for r in dataset_rows()]
    index = read(RUN/'features_index.json')
    features = np.load(RUN/'features.npy', allow_pickle=False)
    assert keys == index['rows'] and index['views'] == ['claim','relation']
    assert list(features.shape) == index['shape'] and features.shape[:2] == (len(keys),2)
    assert str(features.dtype) == index['dtype'] and np.isfinite(features).all()
    assert index['feature_sha256'] == digest(RUN/'features.npy')
    assert index['max_input_tokens'] <= index['max_model_tokens']
    # Both supported wordings share their structured relation input.
    by_id = {row['id']: i for i,row in enumerate(keys)}
    for key, i in by_id.items():
        if key.endswith(':reference'):
            j = by_id[key.replace(':reference', ':paraphrase')]
            assert np.array_equal(features[i,1], features[j,1])
    suite = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(k,0)) == 0 for k in ('failures','errors','skipped'))
    audit = read(RUN/'audit.json')
    manifest = read(RUN/'source_manifest.json')
    overlap = read(RUN/'source_overlap.json')
    summary = dict(audit, reserved_series=len(manifest['reserved_series']), corpus_recordings=len(manifest['corpus_recordings']),
                   checked_recordings=len(overlap['checked_recordings']), overlap_matches=len(overlap['matches']),
                   fragment_size=overlap['fragment_size'], features={k:index[k] for k in (
                       'views','shape','unique_inputs','max_input_tokens','max_model_tokens','feature_sha256')},
                   tests=int(suite.get('tests')))
    dump(RUN/'summary.json', summary)


def status_html():
    s = read(RUN/'summary.json')['splits']
    return (f'<b>{s["train"]["rows"]} training examples and {s["calibration"]["rows"]} calibration examples are ready.</b> '
            'Each example comes with the checked transcript span and frozen text features.')


def overview_html():
    r = read(RUN/'summary.json')
    return (
        '<h2 id="remaining-failures">Training data for spoken alternatives</h2>'
        '<p>The classifier will receive a report excerpt and a claim about two options. '
        'Its target is whether that excerpt supports the relationship in the claim. '
        'The target concerns what the speaker said, including preferences and suggestions.</p>'
        f'<p>Earlier experiments reserve {r["reserved_series"]} of the 59 meeting series in the local AMI archive. '
        'Training uses the three remaining office-planning recordings. They share participants and a topic, so '
        'we kept them in the same split. Calibration uses two technical discussions about web-page classification '
        'and meeting-room recording. Calibration is where we will adjust prediction probabilities after fitting. '
        'Two calibration recordings and the change in topic make this a small pilot.</p><div class="binding-result-tables">'
        + table('Reviewed reports and exported examples.', ['Split','Sources','Examples'],
                [(LABELS[k], f'{len(s["recordings"])} recordings<br>{s["reviewed_reports"]} reports',
                  f'{s["rows"]} examples<br>{s["supported"]} supported · {s["unsupported"]} unsupported')
                 for k,s in r['splits'].items()])
        + '</div><p>For each report we reviewed two supported wordings and two edits. One edit changes a detail '
        'in the paraphrase, such as a number or description. The other reverses a preference or switches between '
        'a choice and a combination while keeping the option phrases. Fourteen additional examples reuse the '
        'exact same claim with a different, related excerpt from the same speaker. Every label is based on '
        'our review of the transcript. <a href="#speech-training-examples">Examples and edit counts</a></p>'
        f'<p>There are zero shared series, repeated complete claims, or repeated transcript spans between training and calibration. '
        f'Scanning the {r["checked_recordings"]} recordings in earlier series found {r["overlap_matches"]} exact '
        f'{r["fragment_size"]}-word fragments from the new excerpts. These checks address recording and text overlap.</p>'
        f'<p>Frozen DeBERTa features come from two text pairs per example. One pairs the transcript with the '
        'claim as written. The other pairs it with a sentence that spells out the two options and their relationship. '
        f'Each feature vector has {r["features"]["shape"][2]} values. The encoder sees only the text pair. '
        'This is a preparation run. Fitting and evaluation on the existing benchmark are the next stages.</p>'
        f'<p>All {r["tests"]} project tests passed. '
        f'<a href="{URL}source.zip">Dataset, frozen features, and replay</a> · '
        f'<a href="{URL}summary.json">Counts and data checks</a> · <a href="{URL}tests.xml">Tests</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a> · '
        '<a href="#earlier-option-binding">Earlier speech and visual comparison</a></p>'
    )


def examples_html():
    rows = dataset_rows()
    stats = read(RUN/'summary.json')['splits']
    output = ['<section id="speech-training-examples"><h2>What goes into the speech training data</h2>',
              '<div class="binding-result-tables">']
    output.append(table('Examples by edit type and split.', ['Type','Training','Calibration'],
                        [(label,*(s['variants'].get(variant,0) for s in stats.values()))
                         for variant,label in VARIANTS.items()]))
    output.append('</div>')
    examples = (
        ('IB4002.sync.1,158','Office size and preference'),
        ('IB4004.sync.948','The same claim with a different excerpt'),
        ('IN1005.sync.270','Incoming links versus outgoing links'),
        ('IN1014.sync.375','Starting and stopping the machine'),
    )
    for ident,title in examples:
        group = [r for r in rows if r['pair_id']==ident]
        first = group[0]
        span = first['evidence']
        anchor = escape(ident.replace('.','-').replace(',',''))
        output.append(f'<article id="training-{anchor}" class="box benchmark-case"><h3>{escape(title)}</h3>'
                      f'<p>{LABELS[first["split"]]} · {escape(span["meeting"])} · speaker {escape(span["speaker"])} '
                      f'· {span["start"]:.1f}–{span["end"]:.1f} s</p><blockquote>{escape(span["text"])}</blockquote>'
                      '<ul class="transcript-comparisons">')
        for row in group:
            if row['variant'] == 'different_span':
                continue
            label = 'Supported' if row['is_supported'] else 'Unsupported'
            output.append(f'<li><h4>{VARIANTS[row["variant"]]} · {label}</h4><p>{escape(row["claim"])}</p></li>')
        output.append('</ul>')
        for row in group:
            if row['variant'] != 'different_span':
                continue
            other = row['evidence']
            output.append(f'<p><strong>Same speaker, different excerpt at {other["start"]:.1f} s</strong></p>'
                          f'<blockquote>{escape(other["text"])}</blockquote>'
                          f'<p>The supported paraphrase above is unsupported here. {escape(row["review_reason"])}</p>')
        output.append('</article>')
    output.append('<p>AMI transcript excerpts © University of Edinburgh and partners under CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a>.</p></section>')
    return ''.join(output)


def write_downloads():
    dest = ROOT/'site/reports'/URL
    dest.mkdir(parents=True,exist_ok=True)
    for name in ('summary.json','tests.xml'):
        copy2(RUN/name,dest/name)


if __name__ == '__main__':
    summarize()
