# Speech relation training data

## Task and split

The input is one annotated transcript excerpt and a claim about alternatives, a directional preference, or a combination of two options. The target marks whether the excerpt supports the claim. An unsupported label can mean the excerpt gives another value or leaves the claim unresolved. It is a local speech label. Each row keeps the claim, the ordered option phrases, the relation, an optional condition, the original excerpt, the source segment and word IDs, speaker and timestamps, the label, and the reason for the label.

The local AMI 1.6.2 annotations contain 171 recordings in 59 series. The 11 existing speech inventories use 54 series, which we reserved before selecting data. The five remaining recordings supply the pilot. Training uses three related office-planning meetings together. Calibration uses one meeting on classifying web pages and one on recording meetings. Those two recordings have different technical topics from the training group. This gives a source-disjoint pilot with limited recording and topic coverage. Nearby AMI meetings can cover the same project or people across recording IDs. All selected segments are timed manual annotations. [AMI corpus](https://groups.inf.ed.ac.uk/ami/download/)

| Split | Recordings | Annotated reports | Supported | Unsupported | Total |
| --- | ---: | ---: | ---: | ---: | ---: |
| Training | 3 | 24 | 48 | 56 | 104 |
| Calibration | 2 | 14 | 28 | 34 | 62 |

## Review and labels

For each of 38 reports, the implementing assistant checked the source, the preferred and alternative roles, the paraphrase, and two edits. A detail edit changes one phrase in its supported paraphrase, for example a two-person office to a four-person office. The other edit reverses a preference while keeping the same words, or changes alternatives into a combination or vice versa. For 14 more examples, the same speaker supplies a different excerpt about the same topic. The claim and option phrases stay identical to the supported example and its label changes. The annotation source for every label is assistant review of the excerpt. The benchmark can still benefit from independent labels. The edited claims are synthetic, and the speech excerpts are real. Transcript excerpts are © the University of Edinburgh and partners under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

The export checks for duplicate claim/excerpt pairs and shared normalized claims, excerpts, word IDs, and series across the two splits. It checks equality of the claim in each changed-excerpt pair and equality of the words in each preference reversal. Scanning the 166 recordings in reserved series found zero exact 12-word fragments from the selected excerpts. The checks track recording and transcript overlap.

## Features and first training comparison

The cache contains two 768-value vectors per example. The frozen DeBERTa cross-encoder reads the quoted span with either the claim as written or a sentence spelling out the options and relation. We take its pooled representation before the classification head. The cache has 166 rows with two views and 218 unique input text pairs. Input labels, split, edit types, speaker IDs, and timestamps stay outside the encoder. The existing logic program can keep the speaker and time checks. [DeBERTa checkpoint](https://huggingface.co/cross-encoder/nli-deberta-v3-small)

For the first fit, use a regularized logistic classifier on the frozen relation features. Use the two calibration recordings to adjust probabilities with a single scalar and report results by edit type. Use the existing frozen whole-claim plus specific-relation score as the main baseline. A claim-only control and the 14 identical-claim pairs will help check reliance on the evidence. If the simple classifier shows a useful signal, compare it with a small MLP and test the same predicate in the full inference program. The classifier, calibration parameters, and benchmark scores are future work.

## Files and replay

`train.jsonl` and `calibration.jsonl` contain one example per line. `features.npy` stores float32 arrays with shape `(166, 2, 768)`. `features_index.json` lists the example IDs in order and the two feature views in order. Align features by ID, and keep rows with the same `pair_id` together for any resampling. Reference and paraphrase share the structured vector on purpose. `annotations.tsv`, `context_pairs.tsv`, and `spans.json` retain the review and source text. `source_manifest.json` records the prior evaluation inventories, and `source_overlap.json` retains the overlap search. The archive contains the cached features. Optional feature extraction uses the local checkpoint recorded in `features_index.json`.

Use Python 3.12, the bundled requirements, NumPy 2.2.6, and SciPy 1.17.1. The replay rebuilds both JSONL files from the included excerpts and annotations, checks the feature cache, and verifies the published hashes.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
python scripts/prepare_speech_relation_training.py build
python scripts/speech_relation_training_report.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/speech_relation_training_20261127')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```
