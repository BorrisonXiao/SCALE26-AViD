#!/bin/bash
#SBATCH --job-name=avid-amr-correction
#SBATCH --partition=gpu
#SBATCH --gres=gpu:a100:2
#SBATCH --constraint=40gb
#SBATCH --exclude=rack3n06
#SBATCH --cpus-per-task=8
#SBATCH --mem=100G
#SBATCH --time=00:15:00
#SBATCH --output=/exp/cxiao/scale26/avid/exp/probabilistic_verification/amr_correction_20261114/model_%j.out
#SBATCH --error=/exp/cxiao/scale26/avid/exp/probabilistic_verification/amr_correction_20261114/model_%j.err
set -euo pipefail
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4 PYTHONDONTWRITEBYTECODE=1
cd /exp/cxiao/scale26/avid
exec envs/probabilistic-verification/bin/python -u scripts/run_amr_correction.py "$@"
