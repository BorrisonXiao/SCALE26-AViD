"""Source-anchored checks for a small set of graph/grammar disagreements.

These checks request correction; they do not prove a unique intended meaning.
They never use claim labels or manual review judgments.
"""
import re
from .amr_source_alignment import prepare_source,literal
from .amr_composition import EVENT

MEDIA={'video','clip','footage','image','picture','photograph','recording'}

def semantic_checks(record,graph_text,alignment=None):
 import penman
 from penman.models.amr import model
 g=penman.decode(graph_text,model=model);concepts={s:t for s,r,t in g.instances()};edges={n:[]for n in concepts}
 for s,r,t in g.triples:
  if r!=':instance':edges[s].append((r,t))
 if alignment is None:_,_,alignment=prepare_source(record,graph_text)
 tokens=record.get('tokens',[]);by={t['id']:t for t in tokens};issues=[]
 def flag(code,node,message,ts=(),**extra):
  issues.append(dict(code=code,node=node,reason=message,token_ids=[t['id']for t in ts],source_words=' '.join(t['text']for t in ts),**extra))
 for n,p in concepts.items():
  t=alignment.unique(n)
  if t and t.get('upos')=='ADJ'and t.get('deprel')=='amod'and by.get(t.get('head'),{}).get('upos')in{'NOUN','PROPN'}:
   # A source adjective attached to a noun is not a participant of an event.
   for parent,rs in edges.items():
    for role,target in rs:
     if target==n and re.fullmatch(r':ARG\d',role)and EVENT.search(concepts[parent]):
      flag('adjective_argument',n,'A noun-attached adjective is used as an event participant; preserve the property on its noun.',[t,by[t['head']]],parent=parent,role=role)
  if t and EVENT.search(p)and'VerbForm=Part'in(t.get('feats')or'')and t.get('deprel')in{'xcomp','amod','acl'}:
   head=by.get(t.get('head'),{});have_state=head.get('lemma')=='have'and t.get('deprel')=='xcomp'
   if have_state and any(role==':ARG0'for role,_ in edges[n]):
    flag('result_state_agent',n,'A have-object-participle construction can describe a result state. The graph adds an agentive action; state versus action needs an explicit source reading.',[head,t])
  if p=='be-located-at-91':
   locations=[v for r,v in edges[n]if r==':ARG2'and concepts.get(v)in MEDIA]
   if locations:
    flag('media_location',n,'Content in a video/image needs depiction or containment scope; a media item is being used as a physical location.',[u for loc in locations for u in alignment.matches(loc)])
  if p=='date-entity':
   times=[v for r,v in edges[n]if r==':time']
   if len(times)>1:flag('time_cardinality',n,'One date-entity has several time values; keep one complete timecode or represent an interval explicitly.',values=[literal(v)for v in times])
 # The source's temporal boundary must not become an event acting on a value.
 for m in re.finditer(r'\b(beginning|start|end|middle)\s+of\s+(?:the\s+)?(video|clip|recording)\b',record['text'],re.I):
  for n,p in concepts.items():
   t=alignment.unique(n)
   if t and m.start()<=t.get('start_char',-1)<m.end()and EVENT.search(p):
    objects=[v for r,v in edges[n]if r==':ARG1']
    if objects and all(concepts.get(v)not in MEDIA for v in objects):
     flag('media_time_attachment',n,'The source names a boundary of the media, but the graph makes a non-media value the boundary event argument.',[t],objects=objects)
 return issues
