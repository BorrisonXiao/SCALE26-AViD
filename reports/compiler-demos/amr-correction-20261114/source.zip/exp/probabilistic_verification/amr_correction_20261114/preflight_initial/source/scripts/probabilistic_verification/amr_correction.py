"""Bounded edits of the supplied AMR; never generate a free-form replacement."""
import hashlib,json,re
import jsonschema
from .amr_source_alignment import prepare_source,literal,SourceAlignment
from .amr_semantic_checks import semantic_checks
from .amr_checked import compile_checked
from .amr_composition import COMPLEMENTS
from .amr_scope import CLASSES
from .logic import Evidence,ground
from .compact_backend import compact_prolog_program
from prompts_phase2 import AMR_CORRECTION_SYSTEM as SYSTEM

def graph_data(raw):
 import penman
 from penman.models.amr import model
 g=penman.decode(raw,model=model)
 return dict(top=g.top,triples=[list(t)for t in g.triples])

def output_schema(graph):
 variables=[t[0]for t in graph['triples']if t[1]==':instance'];allowed=sorted(set(variables)|{'x'+str(i)for i in range(1,9)})
 triple=dict(type='array',prefixItems=[dict(type='string',enum=allowed),dict(type='string',pattern=r'^:[A-Za-z][A-Za-z0-9-]*$'),dict(type='string',maxLength=256)],items=False,minItems=3,maxItems=3)
 def obj(props,required):return dict(type='object',properties=props,required=required,additionalProperties=False)
 index=dict(type='integer',minimum=0,maximum=len(graph['triples'])-1)
 edit=dict(anyOf=[obj(dict(op=dict(type='string',const='replace'),index=index,triple=triple),['op','index','triple']),obj(dict(op=dict(type='string',const='remove'),index=index),['op','index']),obj(dict(op=dict(type='string',const='add'),triple=triple),['op','triple'])])
 return obj(dict(top=dict(type='string',enum=allowed),edits=dict(type='array',maxItems=8,items=edit)),['top','edits'])

def apply_edits(graph,response):
 import penman
 from penman.models.amr import model
 jsonschema.validate(response,output_schema(graph));triples=[tuple(t)for t in graph['triples']];changes={};extra=[]
 if not response['edits']:raise ValueError('model_refuse: no edits proposed')
 for edit in response['edits']:
  if edit['op']=='add':extra.append(tuple(edit['triple']));continue
  i=edit['index']
  if i in changes:raise ValueError('One original triple index was edited twice.')
  changes[i]=None if edit['op']=='remove'else tuple(edit['triple'])
 triples=[changes.get(i,t)for i,t in enumerate(triples)if changes.get(i,t)is not None]+extra
 instances=[(s,t)for s,r,t in triples if r==':instance'];nodes=dict(instances)
 if len(nodes)!=len(instances)or len(triples)!=len(set(triples)):raise ValueError('Repeated node declarations or repeated triples.')
 if response['top']not in nodes:raise ValueError('The root needs a declared node.')
 for s,r,t in triples:
  if s not in nodes or not model.has_role(r):raise ValueError('Undeclared source node or unsupported AMR role.')
  if r==':instance':
   if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*',t):raise ValueError('A concept must be an AMR label, not a quoted sentence.')
  elif t not in nodes and not(t.startswith('"')and t.endswith('"')or re.fullmatch(r'[-+]?\d+(?:\.\d+)?|[-+]',t)):
   raise ValueError('Undeclared target node: '+t)
 return penman.encode(penman.Graph(triples,top=response['top']),model=model)

def edit_source_checks(record,old,new):
 old_nodes={s:t for s,r,t in old['triples']if r==':instance'};new_nodes={s:t for s,r,t in new['triples']if r==':instance'}
 before=SourceAlignment(record,old_nodes);after=SourceAlignment(record,new_nodes);covered={t['id']for n in new_nodes for t in after.matches(n)};issues=[]
 for n in old_nodes:
  t=before.unique(n)
  if t and t.get('upos')in{'NOUN','VERB','ADJ','ADV'}and t['id']not in covered:
   issues.append(dict(code='dropped_aligned_content',reason='The edit removes the only graph alignment for source word '+repr(t['text'])+'.',token_ids=[t['id']]))
 scope_heads=set(COMPLEMENTS)|{p for ps in CLASSES.values()for p in ps}
 for p in sorted(set(old_nodes.values())&scope_heads-set(new_nodes.values())):
  issues.append(dict(code='dropped_scope_head',reason='The edit removes scope predicate '+p+' without a checked equivalent.'))
 return issues

def inspect(record,raw):
 """Return a diagnostic candidate and all current automatic errors."""
 out=dict(claim_id=record['claim_id'],text=record['text'],status='unsupported',raw=raw);errors=[]
 try:
  prepared=prepare_source(record,raw);out.update(normalised_amr=prepared[0],source_trace=prepared[1]);errors+=semantic_checks(record,prepared[0],prepared[2])
  c=compile_checked(record,raw,strict=False,prepared=prepared);errors=c.metadata['source_checks']+c.metadata['semantic_checks']
  e=Evidence('compilation_only',{v.name:['placeholder:'+v.name]for v in c.variables},{v.name:True for v in c.variables},{})
  gp=ground(c,e,max_expansions=3000);program=compact_prolog_program([gp],learned=False)[0]
  from problog.program import PrologString
  list(PrologString(program));out.update(compilation=c.to_dict(),program=program,program_sha256=hashlib.sha256(program.encode()).hexdigest(),status='compiled'if not errors else'unsupported')
 except Exception as e:errors.append(dict(code=getattr(e,'code',type(e).__name__),reason=str(e)))
 out['errors']=errors
 if errors:out.update(code=errors[0]['code'],reason=errors[0]['reason'])
 return out

def request(record,initial,current,*,previous=None,feedback=True):
 graph=graph_data(current['normalised_amr']);data=dict(claim=record['text'],dependencies=[[t['id'],t['text'],t['upos'],t['head'],t['deprel']]for t in record['tokens']],graph=graph,original_direct_error=initial['original_direct_error'],initial_amr_errors=initial['output']['errors'])
 if previous is not None:
  if feedback:data['compiler_errors']=current['errors']
  else:data['instruction']='The previous edits failed. Correct the graph faithfully; the original errors remain above.'
 return [dict(role='system',content=SYSTEM),dict(role='user',content=json.dumps(data,ensure_ascii=False,separators=(',',':')))],output_schema(graph)

def evaluate(record,current,raw,*,original_graph=None):
 graph=graph_data(current['normalised_amr']);amr=current['normalised_amr']
 try:
  response=json.loads(raw);changed=apply_edits(graph,response);out=inspect(record,changed);extra=edit_source_checks(record,original_graph or graph,graph_data(changed))
  if extra:out.update(status='unsupported',errors=out['errors']+extra,code=extra[0]['code'],reason=extra[0]['reason'])
  return out
 except Exception as e:
  return dict(current,status='unsupported',code='model_refuse'if str(e).startswith('model_refuse:')else'edit_error',reason=str(e),errors=[dict(code='edit_error',reason=str(e))])
