"""Equivalent binary-factor encoding of each categorical observation.

Choose support first; conditional on no support, choose refutation. This retains
the original three probabilities and shared observation IDs without a three-way
annotated-disjunction constraint. All logic rules are the compact backend's.
"""
from .compact_backend import compact_prolog_program

def binary_prolog_program(programs,*,learned=True):
 def observation_rules(observations,learned):
  lines=['% P(support)=s; P(refute|not support)=r/(r+u).']
  if learned and any(o.trainable and o.available for o in observations.values()):
   lines.append('nn(relation_net,[tensor(features(O)),Choice]) :: learned_coin(O,Choice).')
  for oid,o in sorted(observations.items()):
   if learned and o.trainable and o.available:
    lines +=[f'coin({oid},support) :- learned_coin({oid},support).',f'coin({oid},refute) :- learned_coin({oid},refute).']
   else:
    s,r,u=o.distribution;q=r/(r+u)if r+u>0 else 0.
    lines +=[f'{s:.17g}::coin({oid},support).',f'{q:.17g}::coin({oid},refute).']
   lines +=[f'status({oid},supported) :- coin({oid},support).',f'status({oid},refuted) :- \\+ coin({oid},support), coin({oid},refute).',f'status({oid},unknown) :- \\+ coin({oid},support), \\+ coin({oid},refute).']
  return lines
 return compact_prolog_program(programs,learned=learned,observation_rules=observation_rules)

def conditional_classifier(classifier):
 """Wrap an existing three-probability classifier without changing its weights."""
 import torch
 from torch import nn
 class ConditionalClassifier(nn.Module):
  def __init__(self):super().__init__();self.base=classifier
  def forward(self,features,choices):
   p=self.base(features);den=p[...,1]+p[...,2]
   q=p[...,1]/den.clamp_min(torch.finfo(p.dtype).tiny)
   mask=torch.tensor([str(c)=='support'for c in choices],device=p.device)
   # q is irrelevant when support has probability1. No neural outcome is
   # removed from the program or detached from the gradient graph.
   return torch.where(mask,p[...,0],torch.where(den>0,q,torch.zeros_like(q))).unsqueeze(-1)
 return ConditionalClassifier()
