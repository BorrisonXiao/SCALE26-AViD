import json,sys,time
sys.path.insert(0,'scripts')
from prepare_amr_refinement import RUN
from deepproblog.model import Model
from deepproblog.engines import ExactEngine
from deepproblog.query import Query
from deepproblog.semiring.graph_semiring import GraphSemiring
from problog.logic import Term,Var
import torch
class Exact(GraphSemiring):
 def is_zero(self,x):return type(x)is float and x==0.
 def is_one(self,x):return type(x)is float and x==1.
torch.set_num_threads(2)
r=next(r for r in json.loads((RUN/'cases.json').read_text())if r['claim_id']=='Txf2EdqOg1SQ_2176');m=Model(r['program'],[],load=False);m.set_engine(ExactEngine(m),cache=True,semiring=Exact,sdd_auto_gc=True)
n='c_'+__import__('hashlib').sha256(r['claim_id'].encode()).hexdigest()[:16];t=time.perf_counter();z=m.solve([Query(Term('verdict',Term(n),Var('State')))])[0];print('RESULT',time.perf_counter()-t,z.result,z.ground_time,z.compile_time,z.eval_time,flush=True)
