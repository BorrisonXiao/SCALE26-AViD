# AViD terminology & writing standard

_Adopted 2026-08-12. The canonical plain, NLP-friendly vocabulary for every project
doc. It matches the public method note and design note
(`site/reports/tree-crf.html`, `site/reports/interior-emissions.html`). Read this
before writing or editing any doc; new docs follow it, and existing docs are being
brought into line._

## User preference reaffirmed 2026-10-14

Using familiar terms and clear explanations is VITAL to the user. Prefer terms used
in NLP and machine learning; do not invent names, labels, or acronyms for ordinary
components. Explain a term in plain words before relying on it. Novelty should come
from the method and evidence, not its vocabulary.

The current paper direction is ADR-023: probabilistic parsing for multimodal claim
verification. Use semantic parsing, logical form, semantic role, grounding, candidate
assignment, relation classifier, neural predicate, conditional distribution,
probabilistic inference, and calibration where appropriate. A binding is how parts
are related—for example, who did what to whom. A neural predicate is a predicate whose
probabilities come from a neural network. A predefined rule can be a deterministic
conditional distribution; a learned function can use the same interface.

The older CRF-specific terms below remain valid when describing that model. They do
not require the new paper to use a CRF, exclusive modality states, immediate-endpoint
probes, or a fixed tree. Do not use “kernel” when “conditional distribution,”
“classifier,” or “factor” states the intended meaning more clearly.

## Why

Write for an NLP reader who knows conditional random fields, semantic role labelling,
and Universal Dependencies, but **not** our internal shorthand. The goal is that a
first-time reader understands a doc without a decoder ring. Prefer the plain term;
introduce any shorthand in plain words on first use.

## Style rules

1. **Define shorthand on first use, then reuse it.** e.g. "we rewrite the parse into
   checkable units (parse normalization, PN)" — after that, "PN" is fine.
2. **Precise identifiers are immutable.** Never change or drop an ADR number
   (`ADR-016`), a file path, a script/class name (`affordance_llm.py`), a job ID, a
   number, a percentage, a date, or an artifact label (`T*`, `trees_ud_star.jsonl`).
   Standardization changes *wording*, never *facts*.
3. **Anchor to standard NLP vocabulary.** conditional random field (CRF); emission /
   unary factor; transition / pairwise factor; belief propagation (sum-product,
   max-product; the upward pass is *inside*, the downward pass is *outside*);
   partition function; marginal; MAP; semantic role labelling (SRL); Universal
   Dependencies (UD); entailment; calibration.
4. **No invented jargon, no status words.** Avoid "best", "frontier", "SOTA" unless
   the status is the point and is precisely defined. Say what a thing *is*.
5. **Put the number next to the thing it measures.** Don't rely on column order.

## Canonical terms

| Plain term | What it means | Shorthand it replaces / introduces |
|---|---|---|
| the multimodal model | the vision- or audio-language model that answers a probe | MLLM; "the VL/Omni model" |
| a probe | one yes / no / can't-tell question asked of the multimodal model about a single unit, against the clip | (per-unit query) |
| emission (unary factor) | the multimodal model's probe distribution for a node | `φ_v`, `e_v` |
| support marginal | a node's support probability after belief propagation | `s_v` |
| transition (pairwise factor) | a compatibility table between a parent label and a child label, keyed by the dependency relation | `ψ`, `ψ_rel` |
| necessity edge / strength (λ) | the one knob that discourages "supported parent, absent required child" | `λ` |
| checkable-unit tree (T\*) | the parse rewritten into semantically checkable units | `T*` |
| parse normalization (PN) | the step that rewrites the raw UD parse into the checkable-unit tree (rules → SRL → model) | `PN`, `Φ` |
| per-node probing (M2) | running the multimodal model on every node | `M2` |
| tree-CRF inference (M3) | belief propagation over the tree for marginals + the verdict | `M3` |
| modality need / text-only prior | which channel a claim part *would* need, judged from text alone | "affordance" (the concept — **not** the file names) |
| grounded / supported | present in the evidence | SUP |
| verifiably absent (refuted) | the scene or audio is available and the thing is not there | REF |
| can't-tell / not-enough-info | the view or audio is unavailable (off-screen, occluded, silent) | NEI |
| existence | whether a part is present at all | — |
| binding | whether the parts are composed the way the claim says | — |
| not a checkable unit (na) | decided upstream to carry no independent probe | `na` |
| the claim-anchor collapse | the model copies the whole-claim verdict onto every part when the claim is in the prompt | "same-prediction phenomenon" |

## Framing phrases from the historical tree-CRF site

These describe the earlier model, not general guarantees for ADR-023. Inference
exactness depends on the actual graph and variable domains; structural consistency
does not guarantee correct perception or calibrated probabilities.

- "a CRF like the ones used for POS tagging or NER, but the tokens sit in a tree
  instead of a left-to-right chain."
- "the multimodal model does the perceiving (the emissions); the tree does the logic
  (the transitions: necessity, negation, coordination)."
- "belief propagation: the upward pass is inside, the downward is outside; on a fixed
  tree it is exact and linear."
- "faithful by construction: the sub-part labels compose into the claim verdict."
- "a part is supported only if it *exists* and is *bound* correctly."
- "checkable units", "the claim's parse tree", "the composed-span probe".

## Replace on sight

| Avoid | Use |
|---|---|
| MLLM | the multimodal model |
| affordance (the concept) | modality need / text-only modality prior — **but keep `affordance_*.py`, `affordance_annotation.tsv`, etc. verbatim** |
| bare `φ`, `ψ`, `λ`, `e_v`, `s_v` with no gloss | introduce in plain words first, then the symbol |
| "same-prediction phenomenon" | the claim-anchor collapse |
| run labels (`r5e`, `W0`, `v6`) used cold | keep the label, but gloss it on first use |

**Invariant for every edit:** the multiset of numbers, percentages, dates, ADR
references, job IDs, file paths, and code spans in a doc must be identical before and
after standardization. If a rewrite would change any of those, it is wrong.
