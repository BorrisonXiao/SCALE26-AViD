"""Bounded extensions for adjuncts, measurements, IDs and negative existentials.

The historical compiler remains the default path. This entry point enables the
new argument handling and transforms its copied logical form before compilation.
"""
import copy,re
from .content_relations import compile_content_relations,recover_identifiers,LABEL_NOUNS
from .scoped_srl import SourceSyntax
from .split_composition import nodes
from .typed_literals import measurement_literal
from .logical_form import LogicalFormError

OPTIONS=dict(multiple_adjuncts=True,typed_measurements=True,participant_identifiers=True)


def participant_identifier(head,tokens,entity=None):
    if entity:
        values=[str(p['value'])for p in entity.get('properties',[])if p['role']=='identifier']
        if len(values)==1:return values[0].casefold()
    values=[t['text'].casefold()for t in tokens if t['head']==head['id'] and t['upos']=='NUM'
            and t['start_char']>=head['end_char'] and t['deprel'] in {'nummod','appos','dep'}]
    return values[0]if len(values)==1 else None


def explicit_identifiers(record,form,notes):
    recover_identifiers(record,form,notes)
    s=SourceSyntax(record)
    for entity in form['entities']:
        match=re.fullmatch(r'x(\d+)',entity['id'])
        if not match:continue
        head=s.by_id.get(int(match[1]))
        if not head or head['lemma'].casefold()not in LABEL_NOUNS:continue
        ident=participant_identifier(head,s.tokens,entity)
        suffix=[t for t in s.children[head['id']]if t['text'].casefold()==ident and t['start_char']>=head['end_char']]
        if len(suffix)!=1:continue
        end=suffix[0]['end_char'];start=head['start_char']
        if not re.fullmatch(r'\s*[-–]?\s*',record['text'][head['end_char']:suffix[0]['start_char']]):continue
        if entity['text']==head['text']:
            entity['text']=record['text'][start:end]
            notes.append(dict(kind='participant_identifier_span',entity=entity['id'],text=entity['text']))


def nominal_measurements(record,form,notes):
    s=SourceSyntax(record)
    for entity in form['entities']:
        quantity=entity.get('quantity');match=re.fullmatch(r'x(\d+)',entity['id'])
        if not quantity or quantity.get('operator')!='exact' or not match:continue
        head=s.by_id.get(int(match[1]));value=str(quantity['value'])
        measured=measurement_literal(value)
        if not measured or not head:continue
        anchored=[t for t in s.children[head['id']]if t['deprel']=='nummod' and t['text']==value]
        if len(anchored)!=1:continue
        entity.pop('quantity');entity['type']='group'if 'Number=Plur'in(head.get('feats')or'')else'entity'
        import json
        entity.setdefault('properties',[]).append(dict(role='measurement',value=json.dumps(measured,sort_keys=True)))
        notes.append(dict(kind='nominal_measurement',entity=entity['id'],measurement=measured))


def negative_existentials(record,form,notes):
    s=SourceSyntax(record)
    negatives=[t for t in s.tokens if t['text'].casefold()=='no' and t['upos']=='DET' and t['deprel']=='det']
    if not negatives:return
    # Multiple no-NPs and threshold idioms need a joint reading, not a local patch.
    if len(negatives)!=1:return
    token=negatives[0];eid='x'+str(token['head']);entity=next((e for e in form['entities']if e['id']==eid),None)
    if not entity:return
    if any(p.get('role')=='identifier'for p in entity.get('properties',[])):return
    holders=[n for n in nodes(form['formula'])if n.get('op')=='event'and eid in n.get('arguments',{}).values()]
    if len(holders)!=1:return
    target=holders[0]
    if target.get('propositions'):
        # In "no X implies P", the absence is an antecedent. Negating the
        # whole implication would reverse the claim. Leave nested cases refused.
        return
    # Preserve the positive participants outside the negative existential. The
    # absent participant and all new event witnesses stay inside NOT EXISTS.
    outer=[dict(op='entity',ref=v)for v in target['arguments'].values()if isinstance(v,str)and v!=eid]
    body=copy.deepcopy(target)
    negative=dict(op='not_exists',entities=[eid],body=body)
    if target is form['formula'] and entity['text'].casefold() in {'audio','narration','music','speech','sound'}:
        containers=[e for e in form['entities']if e['id']in target['arguments'].values()and e['id']!=eid]
        if any(e['text'].casefold() in {'video','clip','recording','file'}for e in containers):
            negative['route']='audio_event'
    target.clear();target.update(dict(op='and',children=outer+[negative])if outer else negative)
    entity['properties']=[p for p in entity.get('properties',[])if not(p.get('role')=='quantifier'and str(p['value']).casefold()=='no')]
    if entity.get('quantity',{}).get('operator')=='no':entity.pop('quantity')
    notes.append(dict(kind='negative_existential',entity=eid,source_token=token['id']))


def compile_extended_relations(record,*,strict=True):
    prepared=copy.deepcopy(record);prepared['compiler_options']=dict(OPTIONS)
    def transform(r,form,notes):
        explicit_identifiers(r,form,notes)
        nominal_measurements(r,form,notes)
        negative_existentials(r,form,notes)
    return compile_content_relations(prepared,strict=strict,transform_form=transform)


def compile_one(record):
    from run_scope_coverage_census import compile_one as compile_record
    return compile_record(record,compiler=compile_extended_relations)
