"""JSON Schema used only to constrain semantic-parser output syntax."""
def obj(properties,required=()):
    return dict(type='object',properties=properties,required=list(required),additionalProperties=False)
def array(items):return dict(type='array',items=items)
def enum(values):return dict(type='string',enum=list(values))
S=dict(type='string')
REF=lambda name:{'$ref':'#/$defs/'+name}
PROPERTY=obj(dict(role=S,value=S),('role','value'))
LITERAL=obj(dict(value=S,kind=enum(['measurement','duration','date','time','manner','text','verbatim_text','ordinal','frequency','comparison','direction']),unit=S),('value','kind'))
PROPOSITION=obj(dict(role=S,kind=enum(['assertion','depiction','question','reason','purpose','belief','condition','temporal']),route=enum(['unspecified','speech_assertion','ocr_assertion','visual_depiction','audio_event']),body=REF('node')),('role','kind','route','body'))
ENTITY=obj(dict(id=S,text=S,type=enum(['entity','group','pronoun','context','event']),properties=array(PROPERTY),
    relations=array(obj(dict(role=S,target=S),('role','target'))),propositions=array(PROPOSITION),
    quantity=obj(dict(operator=enum(['exact','at_least','more_than','approx','all','multiple','at_most','less_than','most','some','no']),value=S),('operator','value'))),('id','text','type'))
EVENT=obj(dict(op=enum(['event']),id=S,predicate=S,anchor=S,arguments=dict(type='object',additionalProperties=dict(anyOf=[S,LITERAL])),properties=array(PROPERTY),propositions=array(PROPOSITION),sense=S),('op','id','predicate','anchor','arguments'))
NODE=dict(anyOf=[EVENT,obj(dict(op=enum(['entity']),ref=S),('op','ref')),
    obj(dict(op=enum(['and','or']),children=dict(type='array',items=REF('node'),minItems=2)),('op','children')),
    obj(dict(op=enum(['not']),child=REF('node')),('op','child')),
    obj(dict(op=enum(['qualified']),operator=enum(['possible','likely','future','obligation','ability','condition','uncertain']),body=REF('node')),('op','operator','body'))])
SCHEMA=obj(dict(version=enum(['logical-form-v2']),kind=enum(['claim','mention']),entities=array(ENTITY),formula=REF('node'),
    status=enum(['ok','abstain']),reason=S,requires_context=dict(type='boolean'),warnings=array(S)),('version','kind','entities','formula'))
SCHEMA['$defs']={'node':NODE}
