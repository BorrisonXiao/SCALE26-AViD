"""Keep embedded content in context and audit source content before acceptance.

This is one SRL/dependency compilation path. Repairs use source positions and
explicit dependency relations; unresolved omissions are reported, not filled by
a language model. A coverage pass detects omissions, not semantic equivalence.
"""
from __future__ import annotations

import copy
import re
from dataclasses import replace

from .compilation_followup import walk_events
from .compilation_checks_v2 import words
from .logical_form import LogicalFormError
from .reviewed_srl import compile_reviewed_srl, _prune_entities
from .scoped_srl import SourceSyntax, quoted_spans
from .semantic_srl import inherit_routes

# These lexical entries specify only the containing context, not the truth of
# its content. Factive nouns such as fact/proof are deliberately not included.
CONTENT_NOUNS = {
    'investigation': {'into'}, 'inquiry': {'into'},
    'allegation': {'of', 'about'}, 'accusation': {'of', 'about'},
    'claim': {'of', 'about', 'that'}, 'rumor': {'of', 'about', 'that'},
    'report': {'of', 'about'}, 'description': {'of'},
    'discussion': {'of', 'about'}, 'dialogue': {'of', 'about'},
    'conversation': {'of', 'about'}, 'question': {'of', 'about'},
}
QUESTION_NOUNS = {'question', 'discussion', 'dialogue', 'conversation'}
GOAL_PREPOSITIONS = {'prepare': {'for'}, 'preparation': {'for'}}
IDENTIFIER_NOUNS = {'news', 'channel', 'flight', 'route', 'highway', 'model', 'apollo'}
CONTENT_POS = {'NOUN', 'PROPN', 'VERB', 'ADJ', 'ADV', 'NUM'}


def _tid(value, prefix):
    return int(value[len(prefix):]) if re.fullmatch(re.escape(prefix)+r'\d+', value) else None


def prepare_root_predicate(record):
    """Recover a finite root mis-tagged as a plural noun, only with strong syntax.

    Require a singular nominal immediately before it, a third-person verb form
    in WordNet, and an explicitly marked finite temporal subordinate clause.
    Ordinary noun phrases, gerunds and quoted text do not meet these conditions.
    """
    r = copy.deepcopy(record)
    s = SourceSyntax(r)
    notes = []
    for token in s.tokens:
        if token['head'] or token['upos'] != 'NOUN' or not token['text'].casefold().endswith('s'):
            continue
        if any(lo <= token['start_char'] < hi for lo, hi, _ in quoted_spans(r['text'])):
            continue
        subjects = [c for c in s.children[token['id']] if c['deprel'] == 'compound'
                    and c['upos'] in {'NOUN', 'PROPN'} and 'Number=Sing' in (c.get('feats') or '')
                    and c['end_char'] <= token['start_char']
                    and not r['text'][c['end_char']:token['start_char']].strip()]
        temporal = [c for c in s.children[token['id']] if c['deprel'] == 'advcl'
                    and c['upos'] == 'VERB' and 'VerbForm=Fin' in (c.get('feats') or '')
                    and any(u['deprel'] == 'mark' and u['lemma'].casefold() in {'while', 'when'}
                            for u in s.children[c['id']])]
        if len(subjects) != 1 or not temporal:
            continue
        from nltk.corpus import wordnet
        lemma = wordnet.morphy(token['text'].casefold(), wordnet.VERB)
        if not lemma or lemma == token['text'].casefold() or not wordnet.synsets(lemma, pos=wordnet.VERB):
            continue
        subject = subjects[0]
        # Do not reinterpret counts or a prepositional nominal as a subject.
        if any(c['deprel'] in {'case', 'nummod', 'nmod', 'nmod:poss'} for c in s.children[token['id']]):
            continue
        subject['deprel'] = 'nsubj'
        for child in s.children[token['id']]:
            if child['end_char'] <= subject['start_char'] and child['deprel'] in {'det', 'amod'}:
                child['head'] = subject['id']
        token.update(upos='VERB', lemma=lemma,
                     feats='Mood=Ind|Number=Sing|Person=3|Tense=Pres|VerbForm=Fin')
        notes.append(dict(kind='finite_root_recovery', token=token['id'], subject=subject['id'],
                          basis='adjacent singular nominal, finite temporal clause and inflected verb lexicon'))
    return r, notes


def _detach_assertion(form, eid):
    """Remove a whole event branch from the main assertion, keeping its operators.

    Nested propositions are not searched: moving between arbitrary contexts would
    require a semantic decision beyond these source-aligned repairs.
    """
    found = []
    def remove(node):
        inner = node
        while inner.get('op') in {'not', 'qualified'}:
            inner = inner['child'] if inner['op'] == 'not' else inner['body']
        if inner.get('op') == 'event' and inner['id'] == eid:
            found.append(node)
            return None
        if node.get('op') == 'and':
            children = [v for c in node['children'] if (v := remove(c)) is not None]
            if not children:
                return None
            if len(children) == 1:
                return children[0]
            node['children'] = children
        return node
    root = remove(form['formula'])
    if len(found) != 1 or root is None:
        raise LogicalFormError('content_scope', 'Embedded content has no unique detachable assertion: '+eid)
    form['formula'] = root
    return found[0]


def preserve_content_scope(record, form, notes):
    s = SourceSyntax(record)
    entities = {e['id']: e for e in form['entities']}
    events = {e['id']: e for e in walk_events(form)}

    # "prepare for landing": replace the nominal argument by goal content and
    # move its existing SRL event into that goal, rather than adding a world event.
    for parent in list(events.values()):
        markers = GOAL_PREPOSITIONS.get(parent['predicate'], set())
        if not markers:
            continue
        for role, value in list(parent['arguments'].items()):
            tid = _tid(value, 'x') if isinstance(value, str) else None
            token = s.by_id.get(tid)
            if not token or token['upos'] != 'NOUN' or token['head'] != _tid(parent['id'], 'e'):
                continue
            cases = {c['lemma'].casefold() for c in s.children[tid] if c['deprel'] == 'case'}
            if not cases & markers:
                continue
            eid = 'e'+str(tid)
            body = _detach_assertion(form, eid) if eid in events else dict(op='entity', ref=value)
            del parent['arguments'][role]
            parent.setdefault('propositions', []).append(dict(role=role, kind='purpose', route='unspecified', body=body))
            notes.append(dict(kind='nominal_goal_scope', parent=parent['id'], content=eid if eid in events else value,
                              role=role, preposition=sorted(cases & markers)[0]))

    # "investigation into [person violating ...]": a subject plus a gerund is
    # investigation content, not a relative clause asserting the person's guilt.
    for owner in list(entities.values()):
        tid = _tid(owner['id'], 'x')
        token = s.by_id.get(tid)
        markers = CONTENT_NOUNS.get(token['lemma'].casefold(), set()) if token else set()
        for relation in list(owner.get('relations', [])):
            participant = entities.get(relation['target'])
            if relation['role'] not in markers or not participant:
                continue
            matches = []
            for prop in participant.get('propositions', []):
                body = prop.get('body', {})
                ct = s.by_id.get(_tid(body.get('id', ''), 'e'))
                if (prop['kind'] == 'relative' and body.get('op') == 'event' and ct
                        and ct['head'] == _tid(participant['id'], 'x')
                        and 'VerbForm=Ger' in (ct.get('feats') or '')
                        and not any(c['deprel'] in {'ref', 'nsubj'} and c['text'].casefold() in {'who','which','that'}
                                    for c in s.children[ct['id']])):
                    matches.append(prop)
            if len(matches) == 1:
                prop = matches[0]
                participant['propositions'].remove(prop)
                owner['relations'].remove(relation)
                owner.setdefault('propositions', []).append(dict(role=relation['role'], kind='complement',
                                                                 route='unspecified', body=prop['body']))
                notes.append(dict(kind='nominal_content_scope', owner=owner['id'], content=prop['body']['id'],
                                  basis=token['lemma']+' '+relation['role']+' subject-gerund content'))
            elif len(matches) > 1:
                raise LogicalFormError('content_scope', 'Several gerund clauses compete for nominal content.')

    # "dialogue of why they are there": follow the copula/WH dependency path
    # to its content noun. Keep the WH word as a question property, not a cause.
    for event in list(events.values()):
        token = s.by_id.get(_tid(event['id'], 'e'))
        if not token:
            continue
        current = s.by_id.get(token['head']) if token['deprel'] == 'cop' else token
        path, seen = [], set()
        owner = None
        while current and current['id'] not in seen:
            seen.add(current['id']);path.append(current)
            if current['lemma'].casefold() in QUESTION_NOUNS and 'x'+str(current['id']) in entities:
                owner = entities['x'+str(current['id'])]
                break
            if current is not token and current['upos'] == 'VERB':
                break
            current = s.by_id.get(current['head'])
        wh = [t for t in path if t['text'].casefold() in {'why','whether','how','where','when','who','what'}]
        if owner and len(wh) == 1:
            # Only a detached main-assertion branch needs relocating. Already
            # nested questions are left in their existing context.
            if any(p.get('kind') == 'question' and any(e['id'] == event['id'] for e in walk_events(p['body']))
                   for p in owner.get('propositions', [])):
                continue
            body = _detach_assertion(form, event['id'])
            for role, arg in list(event['arguments'].items()):
                if isinstance(arg, dict) and str(arg.get('value', '')).casefold() == wh[0]['text'].casefold():
                    del event['arguments'][role]
            event.setdefault('properties', []).append(dict(role='question_word', value=wh[0]['text']))
            owner.setdefault('propositions', []).append(dict(role='content', kind='question', route='unspecified', body=body))
            notes.append(dict(kind='nominal_question_scope', owner=owner['id'], content=event['id'], wh=wh[0]['text']))
    _prune_entities(form)
    inherit_routes(form)


def preserve_names_and_identifiers(record, form, notes):
    s = SourceSyntax(record)
    entities = {e['id']: e for e in form['entities']}
    for entity in form['entities']:
        tid = _tid(entity['id'], 'x')
        token = s.by_id.get(tid)
        if not token:
            continue
        if token['upos'] == 'PROPN':
            component, pending = {tid}, [tid]
            while pending:
                current = pending.pop()
                neighbors = s.children[current]+([s.by_id[s.by_id[current]['head']]] if s.by_id[current]['head'] in s.by_id else [])
                for other in neighbors:
                    edge = other if other['head'] == current else s.by_id[current]
                    if (other['id'] not in component and other['upos'] == 'PROPN'
                            and (edge['deprel'].startswith('flat') or edge['deprel'] == 'compound')):
                        component.add(other['id']);pending.append(other['id'])
            if len(component) > 1:
                # Expanding a partial span must never shorten an existing name
                # such as Blue Ghost Mission 1 or LBHP Boat 1.
                occurrences = list(re.finditer(re.escape(entity['text']), record['text'], re.I))
                if len(occurrences) != 1:
                    continue
                lo, hi = occurrences[0].span()
                component.update(t['id'] for t in s.tokens if lo <= t['start_char'] and t['end_char'] <= hi)
                ordered = [s.by_id[i] for i in sorted(component)]
                between = [t for t in s.tokens if ordered[0]['start_char'] <= t['start_char'] < ordered[-1]['end_char']]
                conflicts = [e for e in entities if _tid(e, 'x') in component and e != entity['id']]
                if {t['id'] for t in between} == component and not conflicts:
                    name = s.surface(component)
                    if entity['text'] != name:
                        entity['text'] = name
                        notes.append(dict(kind='complete_proper_name', entity=entity['id'], text=name,
                                          basis='connected, contiguous proper-name dependency component'))
        if token['lemma'].casefold() in IDENTIFIER_NOUNS:
            suffixes = [t for t in s.children[tid] if t['upos'] == 'NUM' and t['deprel'] in {'dep','nummod'}
                        and t['start_char'] >= token['end_char']
                        and not record['text'][token['end_char']:t['start_char']].strip()]
            if len(suffixes) == 1 and not entity.get('quantity'):
                if set(words(suffixes[0]['text'])) <= set(words(entity['text'])):
                    continue  # Already retained in the complete name, e.g. Apollo 11.
                prop = dict(role='identifier', value=suffixes[0]['text'])
                if prop not in entity.setdefault('properties', []):
                    entity['properties'].append(prop)
                    notes.append(dict(kind='postnominal_identifier', entity=entity['id'], text=suffixes[0]['text']))


def audit_content_coverage(record, form):
    """Compare lexical content with reachable, translated values only.

    Schema keys, IDs, unlinked declarations and warnings never count as content.
    Lemmas/stems allow ordinary inflection. Passing does not prove correct roles,
    senses, scope, coreference, or complete preservation of functional operators.
    """
    values = []
    def collect(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {'text','anchor','predicate','value','unit','operator'} and isinstance(item, (str,int,float)):
                    values.append(str(item))
                    if key == 'operator':
                        # These words are represented by the existing numeric
                        # operator, not omitted lexical modifiers.
                        values.extend({'more_than':['over'], 'less_than':['under'],
                                       'approx':['about','around','approximately','nearly','almost']}.get(item, []))
                elif isinstance(item, (dict,list)) and key not in {'warnings'}:
                    collect(item)
        elif isinstance(value, list):
            for item in value:
                collect(item)
    copy_form = copy.deepcopy(form)
    _prune_entities(copy_form)
    collect(copy_form)
    # A source never attached to the same negated predicate is represented by
    # NOT in the existing model. This is not a new temporal interpretation.
    negated = set()
    def negations(node):
        if isinstance(node, dict):
            if node.get('op') == 'not' and node.get('child',{}).get('op') == 'event':
                negated.add(_tid(node['child']['id'], 'e'))
            for item in node.values():
                negations(item)
        elif isinstance(node, list):
            for item in node:
                negations(item)
    negations(copy_form)
    values.extend(t['text'] for t in record['tokens']
                  if t['text'].casefold() in {'not',"n't",'never'} and t['head'] in negated)
    represented = set(words(' '.join(values)))
    missing = []
    for token in record['tokens']:
        if token['upos'] not in CONTENT_POS:
            continue
        alternatives = [set(words(token.get('lemma') or token['text'])), set(words(token['text']))]
        if not any(a and a <= represented for a in alternatives):
            missing.append(dict(id=token['id'], text=token['text'], pos=token['upos'], relation=token['deprel']))
    return dict(complete=not missing, missing=missing,
                method='Source lexical content compared with reachable translated values, allowing inflection.',
                limitation='Necessary coverage check, not a semantic-equivalence or role/scope check.')


def compile_scope_coverage(record, *, strict=True, transform_form=None):
    prepared, additions = prepare_root_predicate(record)
    def transform(r, form, notes):
        notes.extend(additions)
        preserve_content_scope(r, form, notes)
        preserve_names_and_identifiers(r, form, notes)
        if transform_form is not None:
            transform_form(r, form, notes)
    claim, notes = compile_reviewed_srl(prepared, transform_form=transform)
    coverage = audit_content_coverage(record, claim.metadata['logical_form'])
    metadata = dict(claim.metadata, content_coverage=coverage)
    claim = replace(claim, metadata=metadata)
    if strict and not coverage['complete']:
        error = LogicalFormError('coverage_omission', 'Unrepresented source content: '+', '.join(t['text'] for t in coverage['missing']))
        error.candidate = claim
        error.changes = notes
        raise error
    return claim, notes
