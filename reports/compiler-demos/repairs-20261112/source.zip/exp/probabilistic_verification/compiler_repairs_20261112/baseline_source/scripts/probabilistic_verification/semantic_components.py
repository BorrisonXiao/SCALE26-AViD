"""Opt-in value/phrase normalization and source-aligned semantic checks.

Reuse the existing compiler and backend. No parser or prompt selection, inferred
dates, invented events, or word-ignore list. Every credited span has an emitted
typed value or an explicit bound relation in the compiled form.
"""
import copy,json,re
from dataclasses import replace
from .compiler_extensions import OPTIONS,explicit_identifiers,nominal_measurements,negative_existentials
from .content_relations import compile_content_relations
from .content_recovery import _add_nominal,tid
from .compilation_followup import walk_events
from .scoped_srl import SourceSyntax,quoted_spans
from .semantic_values import DATE_TIME,normalized_literal,temporal_literal
from .logical_form import LogicalFormError

MOTION={'shift','move','rotate','turn','travel','slide','drift','accelerate','revolve','spin'}
PHRASES={
    'relative to':('reference',MOTION),
    'with respect to':('reference',MOTION),
    'in relation to':('reference',MOTION),
    'in front of':('location',None),
    'next to':('location',None),
}

def json_value(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))

def value_spans(record):
    return [dict(start=m.start(),end=m.end(),text=m[0])for m in DATE_TIME.finditer(record['text'])
            if not any(lo<=m.start()<hi for lo,hi,_ in quoted_spans(record['text']))]

def normalize_values(record,form,notes,alignments):
    s=SourceSyntax(record)
    by_entity={e['id']:e for e in form['entities']}
    def record_value(raw,value,target):
        matches=list(re.finditer(re.escape(raw),record['text']))
        if len(matches)==1:
            m=matches[0];alignments.append(dict(start=m.start(),end=m.end(),text=raw,target=target,kind=value['kind'],value=value))
    def clean(value,target):
        if isinstance(value,str)and value in by_entity:
            entity=by_entity[value]
            if any(entity.get(k)for k in ['properties','relations','propositions','quantity']):return value
            parsed=normalized_literal(entity['text'])
            if parsed:
                parsed.pop('text',None);record_value(entity['text'],parsed,target)
                notes.append(dict(kind='typed_value_argument',target=target,source=entity['text'],value=parsed))
                return parsed
        if not isinstance(value,dict)or value.get('kind')=='verbatim_text':return value
        raw=value.get('text')
        if not raw and value.get('kind')in{'date','time','duration'}:
            raw=str(value['value'])+(' '+str(value['unit'])if value.get('unit')else'')
        parsed=normalized_literal(raw,temporal=value.get('kind')in{'time','date'})if raw else None
        if not parsed:return value
        parsed.pop('text',None);record_value(raw,parsed,target)
        if parsed!=value:notes.append(dict(kind='normalized_value',target=target,source=raw,value=parsed))
        return parsed
    for event in walk_events(form):
        for role,value in list(event.get('arguments',{}).items()):event['arguments'][role]=clean(value,event['id']+'/'+role)
        for a in event.get('adjuncts',[]):a['target']=clean(a['target'],event['id']+'/'+a['role'])
    # Attach each explicit date/time span to the nominal head supplied by the
    # dependency parse. Never assign every date to every event in the sentence.
    for entity in form['entities']:
        for prop in entity.get('properties',[]):
            if prop['role']=='measurement':
                try:prop['value']=json_value(clean(json.loads(prop['value']),entity['id']+'/measurement'))
                except (ValueError,TypeError):pass
    spans=value_spans(record)
    for t in s.tokens:
        if not re.fullmatch(r'\d{4}',t['text']):continue
        parent=s.by_id.get(t['head']);cues={c['text'].lower()for c in s.children[t['id']]if c['deprel']=='case'}
        if t['deprel']=='nmod:tmod' or cues&{'in','from','before','after','during','since','until'} or parent and parent['lemma'].lower()in{'date','year','timestamp'}:
            if not any(a['start']<=t['start_char']<a['end']for a in spans):spans.append(dict(start=t['start_char'],end=t['end_char'],text=t['text']))
    for span in spans:
        selected=[t for t in s.tokens if span['start']<=t['start_char']and t['end_char']<=span['end']]
        if not selected:continue
        ids={t['id']for t in selected};heads={t['head']for t in selected if t['head']not in ids}
        if len(heads)!=1:continue
        head=next(iter(heads));entity=by_entity.get('x'+str(head))
        if not entity:continue
        # A postnominal label such as Flight2025 is not a calendar date. Full
        # dates/clock spans are handled here; isolated years require a time cue.
        parsed=temporal_literal(span['text'],allow_year=True)
        if not parsed:continue
        entity.pop('quantity',None)
        entity['properties']=[p for p in entity.get('properties',[])if not(p['role']=='time'and str(p['value'])in span['text'])]
        prop=dict(role='time',value=json_value(parsed))
        if prop not in entity['properties']:entity['properties'].append(prop)
        record_value(span['text'],parsed,entity['id']+'/time')
        notes.append(dict(kind='normalized_nominal_time',entity=entity['id'],source=span['text'],value=parsed))

def phrase_relations(record,form,notes,alignments):
    s=SourceSyntax(record);events={tid(e['id'],'e'):e for e in walk_events(form)}
    for phrase,(role,predicates)in PHRASES.items():
        for match in re.finditer(r'\b'+re.escape(phrase)+r'\b',record['text'],re.I):
            if any(lo<=match.start()<hi for lo,hi,_ in quoted_spans(record['text'])):continue
            words=[t for t in s.tokens if match.start()<=t['start_char']and t['end_char']<=match.end()]
            if not words:continue
            target=s.by_id.get(words[-1]['head']);phrase_ids={t['id']for t in words}
            if not target or target['id']in phrase_ids or target['upos']not in{'NOUN','PROPN','PRON'}:continue
            trail=set();current=target
            while current and current['id']not in trail and current['id']not in events:
                trail.add(current['id']);current=s.by_id.get(current['head'])
            if not current:continue
            event=events.get(current['id'])
            if not event or predicates is not None and event['predicate']not in predicates:continue
            eid=_add_nominal(s,form,target['id'])
            candidates={eid}|{'x'+str(i)for i in phrase_ids}
            # SRL can retain this whole prepositional phrase as an entity span.
            # Replace that argument rather than adding a second, opaque object.
            candidates.update(e['id']for e in form['entities']
                if re.match(r'^'+re.escape(phrase)+r'\b',e['text'],re.I))
            previous=[r for r,v in event['arguments'].items()if isinstance(v,str)and v in candidates or isinstance(v,dict)and phrase in str(v.get('value','')).casefold()]
            if len(previous)>1 or role in event['arguments']and role not in previous:
                raise LogicalFormError('phrase_alignment','Several arguments compete for '+phrase)
            for old in previous:del event['arguments'][old]
            event['arguments'][role]=eid
            event['properties']=[p for p in event.get('properties',[])if p['role']not in{'preposition:'+r for r in previous}]
            event['properties'].append(dict(role='preposition:'+role,value=phrase))
            alignments.append(dict(start=match.start(),end=match.end(),text=match[0],target=event['id']+'/'+role,kind='relation',value=eid))
            notes.append(dict(kind='phrase_relation',event=event['id'],role=role,target=eid,source=match[0]))

def valid_alignment(form,item):
    node_id,role=item['target'].split('/',1)
    event=next((e for e in walk_events(form)if e['id']==node_id),None)
    if event:
        return event.get('arguments',{}).get(role)==item['value'] or any(a['role']==role and a['target']==item['value']for a in event.get('adjuncts',[]))
    entity=next((e for e in form['entities']if e['id']==node_id),None)
    if entity:
        return any(p['role']==role and p['value']==json_value(item['value'])for p in entity.get('properties',[]))
    return False

def semantic_alerts(record,form,alignments):
    """Catch explicit values or finite frames lost after compilation; no repairs."""
    s=SourceSyntax(record);alerts=[];events=list(walk_events(form));event_ids={tid(e['id'],'e')for e in events}
    protected=[];typed=[]
    def visit(value):
        if isinstance(value,dict):
            if value.get('kind')=='verbatim_text':protected.append(str(value['value']))
            if value.get('kind')in{'time','date','duration'}:typed.append(str(value['value']))
            if value.get('role')=='time'and 'value'in value:typed.append(str(value['value']))
            for v in value.values():visit(v)
        elif isinstance(value,list):
            for v in value:visit(v)
    visit(form)
    protected_spans=[m.span()for text in protected for m in re.finditer(re.escape(text),record['text'])]
    # Inflectional events in the source should not survive merely as noun text.
    # Nominal events/label fragments are allowed; no verb is invented from a noun.
    from .reviewed_srl import _frames
    for i,frame in _frames(s).items():
        token=s.by_id[i]
        represented=i in event_ids or any(e.get('anchor','').casefold()==token['text'].casefold()for e in events)
        copied=any(lo<=token['start_char']and token['end_char']<=hi for lo,hi in protected_spans)
        if not represented and not copied and token['upos']=='VERB' and 'VerbForm=Fin'in(token.get('feats')or''):
            alerts.append(dict(code='missing_event',event=s.by_id[i]['text'],reason='An explicit finite SRL event has no event node.'))
    for span in value_spans(record):
        preserved=any(span['text']in text for text in typed+protected)
        # A date label/fragment need not assert an event-time relation. Typed
        # raw time values are also valid when normalization (e.g.UTC) is pending.
        if not preserved and form.get('kind')!='mention'and not any(a['start']<=span['start']and span['end']<=a['end']for a in alignments):
            alerts.append(dict(code='unlinked_temporal_value',text=span['text'],reason='An explicit time span has no normalized linked value.'))
    if re.search(r'\b(?:during|before|after|until|since)\s+(?:this|that|the same)\s+(?:time|period|interval)\b',record['text'],re.I)and not any(a.get('reference_resolution')for a in alignments):
        alerts.append(dict(code='unresolved_time_reference',reason='A deictic time expression needs an explicit interval reference; a time noun alone is insufficient.'))
    return alerts

def compile_components(record,*,strict=True,values=True,relations=True,audit=True,transform_form=None):
    prepared=copy.deepcopy(record);prepared['compiler_options']=dict(OPTIONS,semantic_literals=values)
    alignments=[]
    def transform(r,form,notes):
        explicit_identifiers(r,form,notes);nominal_measurements(r,form,notes);negative_existentials(r,form,notes)
        if values:normalize_values(r,form,notes,alignments)
        if relations:phrase_relations(r,form,notes,alignments)
        if transform_form:transform_form(r,form,notes,alignments)
    claim,notes=compile_content_relations(prepared,strict=False,transform_form=transform)
    metadata=copy.deepcopy(claim.metadata);coverage=metadata['content_coverage'];credited=set()
    alignments=[a for a in alignments if valid_alignment(metadata['logical_form'],a)]
    for a in alignments:
        credited.update(t['id']for t in record['tokens']if a['start']<=t['start_char']and t['end_char']<=a['end'])
    coverage['missing']=[t for t in coverage['missing']if t['id']not in credited];coverage['complete']=not coverage['missing']
    metadata['source_alignments']=alignments
    if audit:metadata.setdefault('structural_alerts',[]).extend(semantic_alerts(record,metadata['logical_form'],alignments))
    claim=replace(claim,metadata=metadata)
    if strict and (not coverage['complete']or metadata.get('structural_alerts')):
        raise LogicalFormError('coverage_omission'if not coverage['complete']else metadata['structural_alerts'][0]['code'],'Source meaning requires review.')
    return claim,notes

def compile_one(record,**options):
    from run_scope_coverage_census import compile_one as compile_record
    row=compile_record(record,compiler=lambda r,strict:compile_components(r,strict=strict,**options))
    if row.get('code')in{'missing_event','unlinked_temporal_value','unresolved_time_reference'}:
        row['reason']=row['structural_alerts'][0]['reason']
    return row
