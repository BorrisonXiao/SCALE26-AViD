"""Small, source-aligned logical-form normalizations, without sentence rewriting.

Only complete simple dependency noun phrases are split. If any source token is
unaccounted for, the proposed phrase is left intact for diagnostics/review.
"""
import copy,re

MEDIA=re.compile(r'\b(footage|video|videos|clip|clips|photo|photos|photograph|photographs|picture|pictures|image|images|imagery|livestream)\b',re.I)

def normalize_form(text,tokens,proposal):
    form=copy.deepcopy(proposal);notes=[];entities=form.get('entities',[])
    if not all(isinstance(e,dict) and isinstance(e.get('id'),str) and isinstance(e.get('text'),str) for e in entities):return form,notes
    by_id={t['id']:t for t in tokens}
    def fresh(base):
        candidate=base
        while any(e.get('id')==candidate for e in entities):candidate+='x'
        return candidate
    def source_span(value):
        matches=list(re.finditer(r'(?<!\w)'+re.escape(value)+r'(?!\w)',text,re.I))
        if len(matches)!=1:return []
        lo,hi=matches[0].span()
        return [t for t in tokens if lo<=t['start_char'] and t['end_char']<=hi]
    def inline(value,role,predicate=''):
        existing=[e for e in entities if e['id'].casefold()==value.casefold() or e['text'].casefold()==value.casefold()]
        if len(existing)==1:return existing[0]['id']
        ts=source_span(value)
        if not ts or any(t.get('upos') in {'VERB','AUX'} for t in ts):return None
        if role.lower() in {'time','date','duration','argm-tmp'}:
            return dict(kind='duration' if role.lower()=='duration' else 'time',value=value)
        if role.lower() in {'manner','argm-mnr','state','attribute','complement','value','degree','extent','frequency','speed','distance','height','temperature','type','classification'}:
            return dict(kind='manner' if role.lower() in {'manner','argm-mnr'} else 'text',value=value)
        if all(t.get('upos') in {'ADV','ADJ','PART','PUNCT'} for t in ts) and role.lower() not in {'agent','patient','theme','arg0','arg1'}:
            return dict(kind='manner' if role.lower()=='manner' else 'text',value=value)
        ids={t['id'] for t in ts};roots=[t for t in ts if t['head'] not in ids]
        if len(roots)!=1 or roots[0].get('upos') not in {'NOUN','PROPN','PRON'}:return None
        root=roots[0]
        if predicate=='be' and root.get('upos')=='NOUN' and any(t['head']==root['id'] and t.get('deprel')=='cop' for t in tokens) and any(t['head']==root['id'] and t['text'].lower() in {'a','an'} for t in tokens):
            return dict(kind='text',value=value)
        # Match the same original mention by its dependency head, not merely by
        # two phrases containing the same noun somewhere in the sentence.
        aliases=[]
        for e in entities:
            ets=source_span(e['text']);eids={t['id'] for t in ets};eroots=[t for t in ets if t['head'] not in eids]
            if len(eroots)==1 and eroots[0]['id']==root['id']:aliases.append(e)
        if len(aliases)==1:
            aliases[0]['text']=value;return aliases[0]['id']
        if len(aliases)>1:return None
        data=dict(id=fresh('inline_'+str(root['id'])),text=value,type='pronoun' if root.get('upos')=='PRON' else 'group' if 'Number=Plur' in (root.get('feats') or '') else 'entity')
        if any(t.get('upos')=='PRON' for t in ts) and root.get('upos')!='PRON':
            form['requires_context']=True
        entities.append(data);return data['id']
    def references(node):
        if not isinstance(node,dict):return
        if node.get('op')=='event':
            for role,value in list(node.get('arguments',{}).items()):
                if not isinstance(value,str) or any(e['id']==value for e in entities):continue
                target=inline(value,role,node.get('predicate',''))
                if target is not None:
                    if role.lower() in {'purpose','goal','reason'} and isinstance(target,str):
                        node.setdefault('propositions',[]).append(dict(role=role,kind='purpose' if role.lower() in {'purpose','goal'} else 'reason',route='unspecified',body=dict(op='entity',ref=target)))
                        del node['arguments'][role]
                    else:node['arguments'][role]=target
                    notes.append(dict(kind='inline_argument',event=node['id'],role=role,original=value,target=target))
        if node.get('op')=='entity' and not any(e['id']==node.get('ref') for e in entities):
            target=inline(str(node.get('ref','')),'referent')
            if isinstance(target,str):node['ref']=target
        for value in list(node.values()):
            if isinstance(value,dict):references(value)
            elif isinstance(value,list):
                for child in value:references(child)
    references(form.get('formula'))
    # Unused declarations entirely inside an exact quote do not add assertions;
    # its contents are already retained as words. Keep all other unused entities
    # so that the compiler can catch a genuinely omitted participant/clause.
    referenced=set();quoted=[]
    def quote_inventory(node):
        if not isinstance(node,dict):return
        if node.get('op')=='entity':referenced.add(node.get('ref'))
        if node.get('op')=='event':referenced.update(v for v in node.get('arguments',{}).values() if isinstance(v,str))
        if node.get('kind')=='verbatim_text':quoted.append(str(node.get('value','')))
        for v in node.values():
            if isinstance(v,dict):quote_inventory(v)
            elif isinstance(v,list):
                for child in v:quote_inventory(child)
    quote_inventory(form.get('formula'))
    visited=set()
    while referenced-visited:
        pending=referenced-visited;visited|=pending
        for e in entities:
            if e['id'] in pending:
                referenced.update(r.get('target') for r in e.get('relations',[]))
                for p in e.get('propositions',[]):quote_inventory(p.get('body'))
    if quoted:
        quote_spans=[m.span() for q in quoted for m in re.finditer(re.escape(q),text,re.I)]
        def solely_quoted(e):
            mentions=list(re.finditer(r'(?<!\w)'+re.escape(e['text'])+r'(?!\w)',text,re.I))
            return mentions and all(any(lo<=m.start() and m.end()<=hi for lo,hi in quote_spans) for m in mentions)
        removed=[e for e in entities if e['id'] not in referenced and solely_quoted(e)]
        entities[:]=[e for e in entities if e not in removed]
        for e in removed:notes.append(dict(kind='quoted_entity_declaration',entity=e['id'],text=e['text']))
    # Keep a capitalized modifier with an adjacent proper-name head (Blue Ghost,
    # White House), rather than turning the name into a color assertion.
    for e in entities:
        ts=source_span(e['text'])
        if len(ts)!=1 or ts[0].get('upos')!='PROPN':continue
        t=ts[0];modifiers=[m for m in tokens if m['head']==t['id'] and m.get('deprel')=='amod' and m['text'][:1].isupper() and m['end_char']<=t['start_char'] and not text[m['end_char']:t['start_char']].strip()]
        if len(modifiers)==1:
            m=modifiers[0];matched=[p for p in e.get('properties',[]) if p.get('role')=='mod' and p.get('value')==m['text']]
            if matched:
                e['text']=text[m['start_char']:t['end_char']];e['properties']=[p for p in e['properties'] if p not in matched]
                notes.append(dict(kind='proper_name',entity=e['id'],name=e['text']))
    # Measurement ranges are values, not cardinalities of groups of objects.
    measurements={}
    units=r'mph|km/h|kmh|knots?|feet|ft|inches|inch|cm|meters?|metres?|miles?|hours?|days?|minutes?|seconds?|degrees?|%|percent'
    for e in entities:
        match=re.fullmatch(r'\s*((?:(?:almost|nearly|about|around)\s+)?(?:[\d,.]+(?:\s*[-–]\s*[\d,.]+)?|one|two|three|four|five|six|seven|eight|nine|ten))\s*('+units+r')\s*',e['text'],re.I)
        if match:
            measurements[e['id']]=dict(value=match[1],unit=match[2],kind='duration' if re.search('hour|day|minute|second',match[2],re.I) else 'measurement')
    if measurements:
        def replace_measurements(node):
            if not isinstance(node,dict):return
            if node.get('op')=='event':
                for role,target in list(node.get('arguments',{}).items()):
                    if isinstance(target,str) and target in measurements:
                        node['arguments'][role]=measurements[target];notes.append(dict(kind='measurement_literal',event=node['id'],role=role,value=measurements[target]))
            for v in node.values():
                if isinstance(v,dict):replace_measurements(v)
                elif isinstance(v,list):
                    for child in v:replace_measurements(child)
        replace_measurements(form.get('formula'))
        # Delete only replaced definitions with no remaining references.
        remaining={r.get('target') for e in entities for r in e.get('relations',[])}
        def collect(node):
            if not isinstance(node,dict):return
            if node.get('op')=='entity':remaining.add(node.get('ref'))
            if node.get('op')=='event':remaining.update(v for v in node.get('arguments',{}).values() if isinstance(v,str))
            for v in node.values():
                if isinstance(v,dict):collect(v)
                elif isinstance(v,list):
                    for child in v:collect(child)
        collect(form.get('formula'))
        for e in entities:
            for p in e.get('propositions',[]):collect(p.get('body'))
        entities[:]=[e for e in entities if e['id'] not in measurements or e['id'] in remaining]
    # A phrase such as "eye of the typhoon" contains separate referents. Split
    # only noun/adjective/name/preposition structures with complete token coverage.
    def split_entity(e,depth=0):
        if depth>5 or not isinstance(e.get('text'),str):return
        phrase=e['text'];positions=[m.start() for m in re.finditer(re.escape(phrase),text,re.I)]
        if len(positions)!=1:return
        start=positions[0];end=start+len(phrase)
        ts=[t for t in tokens if start<=t['start_char'] and t['end_char']<=end]
        ids={t['id'] for t in ts};roots=[t for t in ts if t['head'] not in ids]
        if len(roots)!=1 or roots[0].get('upos')!='NOUN':return
        root=roots[0];relations=[t for t in ts if t['head']==root['id'] and t.get('deprel') in {'nmod','obl'}]
        if not relations and len(ts)<=1:return
        if any(t.get('upos') not in {'NOUN','PROPN','ADJ','ADP','DET','PUNCT','NUM','PART'} for t in ts):return
        covered={root['id']};pending=[];properties=[]
        def subtree(tid):
            found={tid};changed=True
            while changed:
                old=len(found);found|={t['id'] for t in ts if t['head'] in found};changed=len(found)!=old
            return found
        for child in relations:
            branch=subtree(child['id']);case=[t for t in ts if t['head']==child['id'] and t.get('deprel')=='case']
            if not case:return
            marker=' '.join(t['text'] for t in case)
            content=[t for t in ts if t['id'] in branch and t['id'] not in {c['id'] for c in case}]
            while content and content[0].get('upos')=='DET':content=content[1:]
            if not content:return
            target_text=text[min(t['start_char'] for t in content):max(t['end_char'] for t in content)]
            existing=[x for x in entities if x is not e and x.get('text','').casefold()==target_text.casefold()]
            target=existing[0] if len(existing)==1 else dict(id=fresh(e['id']+'_n'+str(child['id'])),text=target_text,type='entity')
            pending.append((marker,target));covered|=branch
        for t in ts:
            if t['id'] in covered:continue
            if t.get('upos') in {'DET','PUNCT'}:covered.add(t['id']);continue
            if t['head']==root['id'] and t.get('deprel') in {'amod','compound'}:
                properties.append(dict(role='mod' if t['deprel']=='amod' else 'compound',value=t['text']));covered.add(t['id'])
        if covered!=ids:return
        original=e['text'];e['text']=root['text']
        for p in properties:
            if p not in e.setdefault('properties',[]):e['properties'].append(p)
        for marker,target in pending:
            if target not in entities:entities.append(target)
            relation=dict(role=marker,target=target['id'])
            if relation not in e.setdefault('relations',[]):e['relations'].append(relation)
            split_entity(target,depth+1)
        notes.append(dict(kind='noun_phrase',original=original,head=e['text'],relations=e.get('relations',[])))
    for e in list(entities):split_entity(e)
    # A nominal media complement is content of that source, not a world-level
    # physical participant. Retain its identity and the source's exact noun.
    for e in entities:
        if not MEDIA.search(e.get('text','')):continue
        retained=[]
        for rel in e.get('relations',[]):
            if rel.get('role') in {'of','about','content','depicts','depicting'}:
                e.setdefault('propositions',[]).append(dict(role='content',kind='depiction',route='visual_depiction',body=dict(op='entity',ref=rel['target'])))
                notes.append(dict(kind='nominal_media_content',source=e['id'],content=rel['target']))
            else:retained.append(rel)
        if e.get('relations') is not None:e['relations']=retained
    # Caption pattern: "clips of smoke coming ..." describes a depiction. The
    # clips themselves are not the participant that comes out of the building.
    root=form.get('formula');action=root.get('child') if isinstance(root,dict) and root.get('op')=='not' else root
    if isinstance(action,dict) and action.get('op')=='event':
        matches=[t for t in tokens if t['text'].casefold()==action.get('anchor','').casefold()]
        if len(matches)==1:
            t=matches[0];chain=[t]+[a for a in tokens if a['head']==t['id'] and a.get('deprel','').startswith('aux')]
            nonfinite='VerbForm=Part' in (t.get('feats') or '') or 'VerbForm=Ger' in (t.get('feats') or '')
            if nonfinite and not any('VerbForm=Fin' in (a.get('feats') or '') for a in chain):
                for role,target in list(action.get('arguments',{}).items()):
                    if role not in {'ARG0','ARG1','agent','theme','patient'}:continue
                    source=next((e for e in entities if e['id']==target and MEDIA.search(e['text'])),None)
                    source_tokens=source_span(source['text']) if source else []
                    if not source_tokens:continue
                    first=min(t['start_char'] for t in source_tokens)
                    if any(p.get('upos') in {'NOUN','PROPN','PRON','VERB','AUX'} for p in tokens if p['end_char']<=first):continue
                    contents=[p for p in source.get('propositions',[]) if p.get('kind')=='depiction' and p.get('body',{}).get('op')=='entity'] if source else []
                    if len(contents)==1:
                        content=contents[0];action['arguments'][role]=content['body']['ref']
                        source['propositions']=[p for p in source['propositions'] if p is not content]+[dict(content,body=root)]
                        form['formula']=dict(op='entity',ref=source['id'])
                        notes.append(dict(kind='nominal_media_clause',source=source['id'],participant=content['body']['ref'],event=action['id']))
                        break
    # Vague mass amounts are attributes, not cardinalities of object groups.
    for e in entities:
        q=e.get('quantity')
        if isinstance(q,dict) and re.search(r'\bamounts?\b',str(q.get('value','')),re.I) and not re.search(r'\d',str(q['value'])) and str(q['value']).casefold() in text.casefold():
            e.setdefault('properties',[]).append(dict(role='amount',value=q['value']));del e['quantity']
            notes.append(dict(kind='mass_amount',entity=e['id'],value=q['value']))
    def head(node):
        anchor=node.get('anchor','')
        found=[t for t in tokens if t['text'].casefold()==anchor.casefold()]
        if len(found)==1:
            token=found[0]
            return by_id.get(token['head'],token) if token.get('deprel') in {'cop','aux','aux:pass'} else token
        found=[t for t in tokens if t.get('lemma','').casefold()==node.get('predicate','').casefold()]
        return found[0] if len(found)==1 else None
    def event_body(node):
        while isinstance(node,dict) and node.get('op') in {'not','qualified'}:node=node.get('child',node.get('body'))
        return node if isinstance(node,dict) and node.get('op')=='event' else None
    def temporal(node):
        if not isinstance(node,dict):return
        if node.get('op')=='event':
            parent=head(node)
            if node.get('predicate') in {"'s",'’s'} and any(t.get('deprel')=='expl' and t['text'].lower()=='there' for t in tokens):
                node['predicate']='be';notes.append(dict(kind='verb_lemma',original="'s",corrected='be',anchor=node.get('anchor')))
            if parent and parent.get('upos')=='VERB' and node.get('predicate')==parent.get('lemma'):
                from nltk.stem import WordNetLemmatizer
                corrected=WordNetLemmatizer().lemmatize(parent['text'].lower(),'v')
                if corrected!=node['predicate']:
                    notes.append(dict(kind='verb_lemma',original=node['predicate'],corrected=corrected,anchor=parent['text']));node['predicate']=corrected
            if parent:
                for particle in [t for t in tokens if t['head']==parent['id'] and t.get('deprel')=='compound:prt']:
                    prop=dict(role='particle',value=particle['text'])
                    if prop not in node.setdefault('properties',[]):node['properties'].append(prop)
            for role,target in node.get('arguments',{}).items():
                mention=next((e.get('text') for e in entities if e['id']==target),None) if isinstance(target,str) else target.get('value') if isinstance(target,dict) else None
                if not parent or not mention:continue
                occurrences=list(re.finditer(re.escape(str(mention)),text,re.I))
                if len(occurrences)!=1:continue
                lo,hi=occurrences[0].span();span=[t for t in tokens if lo<=t['start_char'] and t['end_char']<=hi];ids={t['id'] for t in span}
                roots=[t for t in span if t['head'] not in ids]
                if len(roots)!=1:continue
                target_head=roots[0]
                if target_head['head']!=parent['id'] and target_head['id']!=parent['id']:continue
                markers=[t for t in tokens if t['head']==target_head['id'] and t.get('deprel')=='case']
                marker_ids={t['id'] for t in markers}
                markers +=[t for t in tokens if t['head'] in marker_ids and t.get('deprel')=='fixed']
                marker=' '.join(t['text'] for t in sorted(markers,key=lambda t:t['id']))
                if not marker or role in {'agent','ARG0'} and marker.lower()=='by':continue
                # A converter may already have retained the complete phrase,
                # e.g.relative to. Do not add its final word as a second condition.
                existing=[p['value']for p in node.get('properties',[])if p['role']=='preposition:'+role and isinstance(p['value'],str)]
                if any(len(v.split())>len(marker.split())and v.casefold().endswith(' '+marker.casefold())and re.search(r'\b'+re.escape(v)+r'\b',text,re.I)for v in existing):continue
                p=dict(role='preposition:'+role,value=marker)
                if p not in node.setdefault('properties',[]):
                    node['properties'].append(p);notes.append(dict(kind='argument_preposition',event=node['id'],role=role,value=marker))
            for p in node.get('propositions',[]):
                child=event_body(p.get('body'));aligned=head(child) if child else None
                if parent and aligned and aligned.get('head')==parent['id'] and aligned.get('deprel')=='advcl':
                    markers=[t['text'].lower() for t in tokens if t['head']==aligned['id'] and t.get('deprel')=='mark' and t['text'].lower() in {'before','after','while','until','since','when'}]
                    if len(markers)==1:
                        old=(p.get('kind'),p.get('role'));p.update(kind='temporal',role=markers[0],route='unspecified')
                        if old!=('temporal',markers[0]):notes.append(dict(kind='temporal_clause',parent=node['id'],child=child['id'],relation=markers[0]))
                        for role,arg in list(node.get('arguments',{}).items()):
                            if role=='time' and isinstance(arg,dict) and arg.get('value','').casefold()==markers[0]:del node['arguments'][role]
        for value in list(node.values()):
            if isinstance(value,dict):temporal(value)
            elif isinstance(value,list):
                for child in value:temporal(child)
    temporal(form.get('formula'))
    for e in entities:
        for p in e.get('propositions',[]):temporal(p.get('body'))
    return form,notes
