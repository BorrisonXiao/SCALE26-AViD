"""Actual DeepProbLog exact inference and a small PyTorch relation classifier."""
from __future__ import annotations

import importlib.metadata
import time

import torch
from torch import nn

from .logic import GroundProgram, prolog_program
from .representation import STATES

FEATURE_NAMES = ("log_support", "log_refutation", "log_unknown", "support", "refutation", "unknown")


class RelationClassifier(nn.Module):
    """Residual MLP: initialized to reproduce frozen tuple-specific scores.

This first model is mainly a learned score calibrator. Media IDs, candidate IDs,
claim IDs, and target labels never enter its feature vector.
"""
    def __init__(self, hidden=64):
        super().__init__()
        self.layers = nn.Sequential(nn.Linear(len(FEATURE_NAMES), hidden), nn.Tanh(), nn.Linear(hidden, 3))
        nn.init.zeros_(self.layers[-1].weight)
        nn.init.zeros_(self.layers[-1].bias)

    def forward(self, features):
        return torch.softmax(features[..., :3] + self.layers(features), dim=-1)


class FeatureSource:
    def __init__(self, observations):
        self.values = {}
        for oid, observation in observations.items():
            probabilities = torch.tensor(observation.distribution, dtype=torch.float64)
            self.values[oid] = torch.cat([probabilities.clamp(min=1e-8).log(), probabilities])

    def __getitem__(self, arguments):
        return self.values[str(arguments[0])]


class DeepProbLogVerifier:
    def __init__(self, programs: list[GroundProgram], *, learned=True, seed=7, hidden=64):
        from deepproblog.engines import ExactEngine
        from deepproblog.model import Model
        from deepproblog.network import Network
        from deepproblog.semiring.graph_semiring import GraphSemiring

        class ExactGraphSemiring(GraphSemiring):
            # DeepProbLog 2.0.6 uses a tolerance for is_zero/is_one. With highly
            # confident cached scores, treating 0.999997 as exactly one discards
            # legitimate outcomes and can make the root states fail to sum to 1.
            # Only literal constants are simplification identities; tensors must
            # remain connected to autograd even when their value is 0 or 1.
            def is_zero(self, value):
                return type(value) is float and value == 0.
            def is_one(self, value):
                return type(value) is float and value == 1.

        torch.manual_seed(seed)
        torch.set_num_threads(2)
        self.program, self.claim_names = prolog_program(programs, learned=learned)
        self.observations = {oid: obs for p in programs for oid, obs in p.observations.items()}
        self.classifier = RelationClassifier(hidden).double()
        self.optimizer = torch.optim.Adam(self.classifier.parameters(), lr=0.01)
        network = Network(self.classifier, "relation_net", optimizer=self.optimizer, batching=True)
        self.model = Model(self.program, [network] if learned else [], load=False)
        self.model.set_engine(ExactEngine(self.model), cache=True, semiring=ExactGraphSemiring)
        self.feature_source = FeatureSource(self.observations)
        self.model.add_tensor_source("features", self.feature_source)
        self.learned = learned
        self.seed = seed

    def query(self, claim_id, state):
        from deepproblog.query import Query
        from problog.logic import Term
        return Query(Term("verdict", Term(self.claim_names[claim_id]), Term(state)))

    def predict(self, claim_ids=None):
        claim_ids = list(self.claim_names) if claim_ids is None else list(claim_ids)
        self.model.eval()
        rows = []
        with torch.no_grad():
            for claim_id in claim_ids:
                started = time.perf_counter()
                distribution, timing = {}, {"ground_seconds": 0., "compile_seconds": 0., "evaluate_seconds": 0.}
                for state in STATES:
                    query = self.query(claim_id, state)
                    r = self.model.solve([query])[0]
                    distribution[state] = float(r.result.get(query.query, 0.))
                    for key, attr in (("ground_seconds", "ground_time"), ("compile_seconds", "compile_time"), ("evaluate_seconds", "eval_time")):
                        timing[key] += float(getattr(r, attr, 0.) or 0.)
                total = sum(distribution.values())
                if abs(total - 1.) > 1e-9:
                    raise ArithmeticError(f"Root states must partition probability mass: {distribution}")
                rows.append(dict(claim_id=claim_id, distribution=distribution,
                                 prediction=max(distribution, key=distribution.get), timing=timing,
                                 wall_seconds=time.perf_counter() - started))
        return rows

    def fit(self, labels: dict[str, str], *, epochs=40):
        """Claim-level negative log likelihood using DeepProbLog's native loop.

        A categorical label trains the probability of that root state toward one.
        Local relation labels are never supplied to this training loop.
        """
        from deepproblog.dataset import DataLoader, Dataset
        if not self.learned:
            raise ValueError("A fixed-probability program has no classifier to train.")
        verifier = self
        queries = [self.query(cid, state) for cid, state in labels.items()]
        class ClaimDataset(Dataset):
            def __len__(self):
                return len(queries)
            def to_query(self, index):
                return queries[index]
        history = []
        last_accumulated = 0.
        previous = torch.cat([p.detach().flatten().clone() for p in self.classifier.parameters()])
        started = time.perf_counter()
        gradient_checks = []
        def capture_gradient(gradient):
            gradient_checks.append(dict(finite=bool(torch.isfinite(gradient).all()), norm=float(gradient.norm())))
        hook = self.classifier.layers[-1].weight.register_hook(capture_gradient)
        def record_epoch(train):
            nonlocal last_accumulated
            if (train.i - 1) % len(queries) == 0:
                current = torch.cat([p.detach().flatten() for p in verifier.classifier.parameters()])
                history.append(dict(epoch=train.epoch + 1, mean_nll=float((train.accumulated_loss - last_accumulated) / len(queries)),
                                    parameter_change_l2=float((current - previous).norm())))
                last_accumulated = train.accumulated_loss
        loader = DataLoader(ClaimDataset(), 1, shuffle=False)
        # A hook after every iteration captures the actual native training loss.
        from deepproblog.train import TrainObject
        trainer = TrainObject(self.model)
        trainer.hooks.append((1, record_epoch))
        trainer.train(loader, epochs, verbose=0, log_iter=10 ** 9, initial_test=False)
        hook.remove()
        current = torch.cat([p.detach().flatten() for p in self.classifier.parameters()])
        return dict(epochs=epochs, training_examples=len(labels), elapsed_seconds=time.perf_counter() - started,
                    history=history, parameter_change_l2=float((current - previous).norm()),
                    gradient_checks=gradient_checks, trainable_parameters=sum(p.numel() for p in self.classifier.parameters()),
                    feature_names=list(getattr(self.feature_source, 'feature_names', FEATURE_NAMES)), loss="negative log probability of the supplied root state",
                    label_scope="claim only", device="cpu", seed=self.seed)

    def local_predictions(self):
        result = {}
        with torch.no_grad():
            for oid, obs in self.observations.items():
                result[oid] = (self.classifier(self.feature_source.values[oid].unsqueeze(0))[0].tolist()
                               if self.learned and obs.trainable and obs.available else list(obs.distribution))
        return result

    @staticmethod
    def versions():
        return {name: importlib.metadata.version(name) for name in ("deepproblog", "problog", "pysdd", "torch")}
