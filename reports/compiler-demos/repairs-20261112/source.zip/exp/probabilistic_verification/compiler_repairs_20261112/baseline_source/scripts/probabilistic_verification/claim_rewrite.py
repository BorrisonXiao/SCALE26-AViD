"""Text rewrite proposals and conservative checks, separate from compilation.

Checks can reject obvious changes. They cannot certify semantic equivalence;
accepting a rewritten logical form also requires an explicit saved review.
"""
import hashlib
import json
import re
from collections import Counter

SYSTEM = """Rewrite a claim only when a small syntax change makes its participants and clauses clearer. Return one sentence, or keep/refuse. Preserve the original meaning, even if the claim is false. Do not check or correct facts. Keep names, numbers, units, dates, tense, aspect, negation, uncertainty, comparisons, and who does what to whom. Keep quotation wording exactly and keep speech, printed text, and depicted content in their original scope. Do not turn an image of an event or someone's assertion into an assertion that the event happened. Do not guess missing subjects or pronoun referents. Do not replace absence with a positive assertion. Prefer explicit verbs and repeated subjects over fragments or long attachments; change as little as possible. Keep already clear claims unchanged. Refuse when clarification would require choosing an ambiguous meaning. The supplied dependency and semantic-role parses may contain errors. Return JSON with action (keep, rewrite, or refuse), text (original text for keep/refuse), and a short reason."""

SCHEMA = dict(type='object', properties={
    'action':dict(type='string',enum=['keep','rewrite','refuse']),
    'text':dict(type='string'), 'reason':dict(type='string')},
    required=['action','text','reason'], additionalProperties=False)


def request_data(record):
    """Only original claim and text parses; no IDs, verdicts, or review labels."""
    return dict(claim=record['text'],
        dependencies=[[t['id'],t['text'],t['upos'],t['head'],t['deprel']] for t in record['tokens']],
        semantic_roles=[dict(predicate=f['verb'],arguments=[dict(role=a['role'],text=a['text'])
            for a in f.get('args',[])]) for f in (record.get('srl') or {}).get('frames',[])])


def messages(record, *, system=SYSTEM, diagnostic=None):
    data=request_data(record)
    if diagnostic is not None:data['compiler_diagnostic']=diagnostic
    return [dict(role='system',content=system),dict(role='user',content=json.dumps(data,ensure_ascii=False,separators=(',',':')))]


def needs_rewrite(direct_result):
    """Only a failed strict compilation is eligible, even if a candidate exists."""
    status=direct_result['status']
    if status not in {'compiled','unsupported'}:
        raise ValueError('Unknown direct-compilation status: '+str(status))
    return status=='unsupported'


def prepare_rewrite_inputs(records, compile_direct):
    """Compile first; exclude all passes before any rewriter is initialized."""
    pending=[];routes=[]
    for record in records:
        result=compile_direct(record)
        if result['claim_id']!=record['claim_id']:
            raise ValueError('Direct result belongs to a different claim.')
        eligible=needs_rewrite(result)
        routes.append(dict(claim_id=record['claim_id'],direct_status=result['status'],
            direct_code=result.get('code'),direct_reason=result.get('reason'),
            has_diagnostic_candidate='program' in result,
            rewrite_eligible=eligible,action='request_rewrite' if eligible else 'keep_direct_result'))
        if eligible:pending.append(record)
    return pending,routes


def quotes(text):
    # Apostrophes within words are not quotation marks.
    return re.findall(r'"([^"\n]+)"|(?<!\w)\x27([^\x27\n]+)\x27(?!\w)|“([^”\n]+)”',text)


def surface_checks(record, proposal):
    import jsonschema
    jsonschema.validate(proposal,SCHEMA)
    old=record['text'];new=proposal['text'];issues=[]
    if not new.strip():issues.append('empty_text')
    if proposal['action'] in ('keep','refuse') and new!=old:issues.append('changed_keep_or_refusal')
    if proposal['action']=='rewrite' and new==old:issues.append('rewrite_is_unchanged')
    if new==old:return issues
    if quotes(old)!=quotes(new):issues.append('quotation_changed')
    numeric=lambda s:Counter(re.findall(r'(?<![\w])[+-]?\d+(?:[.,:/-]\d+)*(?:%|°[CF])?',s))
    if numeric(old)!=numeric(new):issues.append('numeric_surface_changed')
    # Names may be reordered or repeated when a subject is made explicit.
    for t in record['tokens']:
        if t['upos']=='PROPN' and not re.search(r'(?<!\w)'+re.escape(t['text'])+r'(?!\w)',new,re.I):
            issues.append('proper_name_missing:'+t['text'])
    markers={'no','not','never','without','may','might','could','would','must','should','will','likely','unlikely','perhaps','presumably'}
    words=lambda s:Counter(re.findall(r'\b[\w]+\b',s.casefold()))
    a,b=words(old),words(new)
    for marker in sorted(markers):
        if a[marker]!=b[marker]:issues.append('polarity_or_modality_changed:'+marker)
    return list(dict.fromkeys(issues))


def review_key(original, proposal, rewritten):
    """Attach a judgment to these exact texts and compiled output."""
    value=dict(original_text=original['text'],proposal=proposal,rewritten=rewritten)
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def reviewed_acceptance(original, proposal, rewritten, review):
    """Fail closed: no automatic use of model output as a trusted logical form."""
    issues=surface_checks(original,proposal)
    return (proposal['action']=='rewrite' and not issues
        and rewritten['status']=='compiled'
        and review.get('artifact_sha256')==review_key(original,proposal,rewritten)
        and review.get('rewrite_faithful') is True
        and review.get('compiled_faithful') is True
        and review.get('critical_change') is False)
