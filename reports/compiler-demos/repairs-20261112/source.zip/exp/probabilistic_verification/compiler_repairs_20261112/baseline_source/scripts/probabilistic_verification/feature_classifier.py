"""Small relation classifier over frozen, media-conditioned representations."""
import torch
from torch import nn


class FrozenFeatureSource:
    """Map a grounded observation to its cached representation, never its label."""
    def __init__(self, values):
        if not values:
            raise ValueError('At least one feature vector is required.')
        self.values = {key: value.detach().clone().double() for key, value in values.items()}
        dimensions = {value.shape for value in self.values.values()}
        if len(dimensions) != 1 or len(next(iter(dimensions))) != 1:
            raise ValueError('Expected feature vectors of one shared dimension.')
        if not all(torch.isfinite(value).all() for value in self.values.values()):
            raise ValueError('Features must be finite.')
        self.feature_names = ('frozen media-and-proposition representation',)

    def __getitem__(self, arguments):
        return self.values[str(arguments[0])]


class FeatureRelationClassifier(nn.Module):
    def __init__(self, input_dim, hidden=64):
        super().__init__()
        self.layers = nn.Sequential(nn.LayerNorm(input_dim), nn.Linear(input_dim, hidden),
                                    nn.GELU(), nn.Linear(hidden, 3))

    def forward(self, features):
        return torch.softmax(self.layers(features), dim=-1)
