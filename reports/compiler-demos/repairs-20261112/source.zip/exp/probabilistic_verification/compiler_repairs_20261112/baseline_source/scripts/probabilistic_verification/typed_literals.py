"""Parse complete physical-quantity phrases; never reinterpret object counts."""
import re

NUMBER=r'\d+(?:,\d{3})*(?:\.\d+)?'
UNITS={
 'mm':'mm','millimeter':'mm','millimeters':'mm','millimetre':'mm','millimetres':'mm',
 'cm':'cm','centimeter':'cm','centimeters':'cm','m':'m','meter':'m','meters':'m','metre':'m','metres':'m',
 'km':'km','kilometer':'km','kilometers':'km','kilometre':'km','kilometres':'km',
 'mile':'mile','miles':'mile','feet':'ft','foot':'ft','ft':'ft','inch':'in','inches':'in',
 'kg':'kg','kilogram':'kg','kilograms':'kg','g':'g','gram':'g','grams':'g',
 'mph':'mph','knots':'knot','knot':'knot','%':'%','percent':'%',
}
UNIT=r'(?:'+ '|'.join(sorted(map(re.escape,UNITS),key=len,reverse=True))+')'
PATTERN=re.compile(r'(?P<value>'+NUMBER+r')\s*(?:(?:-|–|—|to|and)\s*(?P<upper>'+NUMBER+r')\s*)?(?P<unit>'+UNIT+r')(?:\s*(?:/|per)\s*(?P<denominator>h|hr|hours?|s|sec|seconds?))?',re.I)
PREFIX=re.compile(r'^(?:(?:at|to|by|of|in|with)\s+)?(?:(?:a|the)\s+)?(?:(?P<attribute>speed|distance|height|length|depth|weight|mass|velocity)\s+of\s+)?(?P<operator>about|around|approximately|roughly|over|under|at least|at most|more than|less than|between|from)?\s*',re.I)


def measurement_literal(text):
    raw=text.strip().rstrip('.,')
    # Magnitude is a named scalar attribute, not a new physical unit.
    scalar=re.fullmatch(r'(?:a\s+)?magnitude\s+(?:of\s+)?('+NUMBER+r')',raw,re.I)
    if scalar:
        return dict(kind='measurement',attribute='magnitude',operator='exact',value=scalar[1],unit='',text=raw)
    prefix=PREFIX.match(raw);rest=raw[prefix.end():]
    match=PATTERN.fullmatch(rest)
    if not match:return None
    value=match['value'].replace(',','');upper=match['upper']
    cue=(prefix['operator']or'').lower()
    if cue in {'between','from'} and not upper:return None
    unit=UNITS[match['unit'].lower()]
    if match['denominator']:
        unit+='/h'if match['denominator'].lower().startswith('h')else'/s'
    operator={'about':'approx','around':'approx','approximately':'approx','roughly':'approx','over':'more_than','under':'less_than','at least':'at_least','at most':'at_most','more than':'more_than','less than':'less_than'}.get(cue,'exact')
    result=dict(kind='measurement',operator='range'if upper else operator,value=value,unit=unit,text=raw)
    if upper:
        if operator!='exact':return None # Keep uncertain bounds unsupported.
        upper=upper.replace(',','')
        if float(value)>float(upper):return None
        result.update(lower=value,upper=upper)
    if prefix['attribute']:result['attribute']=prefix['attribute'].lower()
    return result
