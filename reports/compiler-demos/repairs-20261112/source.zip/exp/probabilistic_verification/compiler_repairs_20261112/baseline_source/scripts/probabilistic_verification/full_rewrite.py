"""Full-cohort sentence simplification, separate from reference alignment."""
import json,jsonschema
import prompts_phase2 as prompts
from .claim_rewrite import request_data

SCHEMA=dict(type='object',properties={
    'action':dict(type='string',enum=['rewrite','keep','refuse']),
    'sentences':dict(type='array',maxItems=12,items=dict(type='string'))},
    required=['action','sentences'],additionalProperties=False)


def messages(record,diagnostic):
    return [dict(role='system',content=prompts.CLAIM_FULL_FALLBACK_SYSTEM),
        dict(role='user',content=json.dumps(dict(request_data(record),compiler_diagnostic=diagnostic),ensure_ascii=False,separators=(',',':')))]


def proposal(data):
    jsonschema.validate(data,SCHEMA)
    if data['action']=='rewrite' and not data['sentences']:raise ValueError('Rewrite requires sentences.')
    if data['action']!='rewrite'and data['sentences']:raise ValueError('Keep/refuse cannot add sentences.')
    return dict(action='split'if len(data['sentences'])>1 else'rewrite'if data['sentences']else data['action'],
        clauses=[dict(id=f'c{i+1}',text=text,parent='c1'if i else None,relation='and'if i else'root',target='')for i,text in enumerate(data['sentences'])],shared=[],reason='Frozen-model sentences; references inferred separately.')
