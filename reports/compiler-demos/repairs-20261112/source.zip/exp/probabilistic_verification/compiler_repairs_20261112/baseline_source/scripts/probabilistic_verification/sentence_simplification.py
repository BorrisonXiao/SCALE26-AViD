"""Sentence generation without model-generated entity IDs or logical links."""
import json
import jsonschema
import prompts_phase2 as prompts
from .claim_rewrite import request_data

SCHEMA = dict(type='object', properties={
    'action': dict(type='string', enum=['split', 'keep', 'refuse']),
    'sentences': dict(type='array', maxItems=8, items=dict(type='string'))},
    required=['action', 'sentences'], additionalProperties=False)


def messages(record, diagnostic):
    # The same original text/parses/error as the previous experiment; no labels.
    return [dict(role='system', content=prompts.CLAIM_SENTENCES_SYSTEM),
            dict(role='user', content=json.dumps(dict(request_data(record),
                 compiler_diagnostic=diagnostic), ensure_ascii=False, separators=(',', ':')))]


def to_proposal(data):
    jsonschema.validate(data, SCHEMA)
    if data['action'] == 'split' and len(data['sentences']) < 2:
        raise ValueError('A split requires at least two sentences.')
    if data['action'] != 'split' and data['sentences']:
        raise ValueError('Keep/refuse must not add sentences.')
    return dict(action=data['action'], clauses=[dict(id=f'c{i+1}', text=text,
        parent='c1' if i else None, relation='and' if i else 'root', target='')
        for i, text in enumerate(data['sentences'])], shared=[],
        reason='Sentences-only model output; links inferred separately from original mentions.')
