"""Compose compiled simple sentences with explicit shared mentions and context.

This adapter does not decide whether a proposed split preserves its source claim.
It reuses the existing operators and refuses unsupported attachment/identity cases.
"""
import copy,json,re
from .claim_split import validate_split
from .logical_form_v2 import ScopedCompiler,normalized
from .semantic_srl import inherit_routes

class CompositionError(ValueError):
    def __init__(self,code,message):super().__init__(message);self.code=code

def fail(code,message):raise CompositionError(code,message)
def nodes(value):
    if isinstance(value,dict):
        yield value
        for v in value.values():yield from nodes(v)
    elif isinstance(value,list):
        for v in value:yield from nodes(v)
def conjunction(parts):return parts[0]if len(parts)==1 else dict(op='and',children=parts)

def compose_split(claim_id,proposal,results,*,flat=False,max_clauses=8):
    validate_split(proposal,max_clauses=max_clauses)
    if proposal['action']!='split':fail('no_split','No split was proposed.')
    clauses=proposal['clauses'];forms={};tokens=[];texts=[];offset=0;characters=0;entity_map={};event_maps={}
    for c in clauses:
        cid=c['id'];row=results[cid]
        if row['status']!='compiled':fail('component_refusal',cid+': '+row.get('reason',row.get('code','refused')))
        forms[cid]=copy.deepcopy(row['compilation']['metadata']['logical_form'])
        local=row['compilation']['tokens'];event_maps[cid]={}
        for n in nodes(forms[cid]):
            if n.get('op')=='event':
                match=re.fullmatch(r'e(\d+)',n['id'])
                if match and int(match[1])in {t['id']for t in local}:index=int(match[1])
                else:
                    anchors=[t['id']for t in local if t['text']==n.get('anchor')]
                    if len(anchors)!=1:fail('event_alignment','Cannot identify one token for '+cid+'/'+n['id'])
                    index=anchors[0]
                event_maps[cid][n['id']]='e'+str(offset+index)
        for e in forms[cid]['entities']:entity_map[(cid,e['id'])]=cid+'_'+e['id']
        for t in local:
            tokens.append(dict(t,id=t['id']+offset,head=t['head']+offset if t['head']else 0,
                start_char=t['start_char']+characters,end_char=t['end_char']+characters))
        offset+=max(t['id']for t in local);characters+=len(c['text'])+1;texts.append(c['text'])
    parent={v:v for v in entity_map.values()}
    def find(x):
        while parent[x]!=x:x=parent[x]
        return x
    def mention(cid,text):
        entities=forms[cid]['entities'];exact=[e for e in entities if normalized(e['text'])==normalized(text)]
        candidates=exact or [e for e in entities if (' '+normalized(e['text'])+' ')in(' '+normalized(text)+' ')]
        if len(candidates)!=1:fail('mention_alignment','Shared/target mention is not one compiled entity: '+cid+'/'+text)
        return entity_map[(cid,candidates[0]['id'])]
    for group in proposal['shared']:
        ids=[mention(m['clause'],m['text'])for m in group['mentions']]
        for v in ids[1:]:parent[find(v)]=find(ids[0])
    entity_map={k:find(v)for k,v in entity_map.items()}
    def transform(value,cid):
        if isinstance(value,list):return [transform(v,cid)for v in value]
        if not isinstance(value,dict):return value
        out={}
        for k,v in value.items():
            if k=='id' and value.get('op')=='event':out[k]=event_maps[cid][v]
            elif k in {'ref','target'} and isinstance(v,str):out[k]=entity_map.get((cid,v),v)
            elif k=='arguments':out[k]={role:entity_map.get((cid,a),a)if isinstance(a,str)else transform(a,cid)for role,a in v.items()}
            else:out[k]=transform(v,cid)
        return out
    entities={};bodies={}
    for c in clauses:
        cid=c['id'];bodies[cid]=transform(forms[cid]['formula'],cid)
        for e in forms[cid]['entities']:
            new=transform(e,cid);new['id']=entity_map[(cid,e['id'])]
            if new['id']in entities:
                old=entities[new['id']]
                # Do not move a modifier from one context into another by merging.
                signature=lambda e:json.dumps({k:v for k,v in e.items()if k!='id'},sort_keys=True,ensure_ascii=False)
                if signature(old)!=signature(new):fail('shared_description','Shared mentions have different compiled descriptions; merging could move modifiers across contexts.')
            else:entities[new['id']]=new
    children={c['id']:[]for c in clauses}
    for c in clauses[1:]:children[c['parent']].append(c)
    def main_event(body):
        while body.get('op')=='qualified':body=body['body']
        if body.get('op')!='event':fail('parent_structure','A context attachment needs one affirmative parent event; do not move it across AND/NOT.')
        return body
    def refs(body):
        found={v for n in nodes(body)for v in n.get('arguments',{}).values()if isinstance(v,str)}|{n['ref']for n in nodes(body)if n.get('op')=='entity'}
        pending=list(found)
        while pending:
            eid=pending.pop()
            for rel in entities.get(eid,{}).get('relations',[]):
                if rel['target']not in found:found.add(rel['target']);pending.append(rel['target'])
        return found
    kinds={'depiction':('depiction','visual_depiction'),'speech':('assertion','speech_assertion'),'ocr':('assertion','ocr_assertion'),
           'purpose':('purpose','unspecified'),'before':('temporal','unspecified'),'after':('temporal','unspecified'),'while':('temporal','unspecified')}
    def build(cid):
        body=bodies[cid];parts=[body];attachments={}
        for c in children[cid]:
            child=build(c['id']);relation=c['relation']
            if relation=='and':parts.append(child);continue
            if relation=='relative':
                target=find(mention(cid,c['target']))
                if target not in refs(child):fail('missing_shared_participant','A relative description must reuse its parent participant.')
                entities[target].setdefault('propositions',[]).append(dict(role='acl:relcl',kind='relative',route='unspecified',body=child));continue
            event=main_event(body);kind,route=kinds[relation]
            if relation in {'depiction','speech','ocr'}:
                licensed={'depiction':{'show','depict','feature','display','illustrate','portray','present'},
                    'speech':{'say','claim','report','state','tell','announce','explain','ask','shout','mention'},
                    'ocr':{'read','say','state','show','display','contain'}}
                if event['predicate'].casefold()not in licensed[relation]:fail('source_predicate','A '+relation+' child cannot replace an argument of '+event['predicate'])
                target=find(mention(cid,c['target']))
                if target not in refs(child):fail('missing_shared_participant','Content must reuse the focal parent entity; do not assert an unrelated event.')
                key=(relation,target)
                if key in attachments:attachments[key]['body']=conjunction([attachments[key]['body'],child]);continue
                existing=[p for p in event.get('propositions',[])if p.get('kind')==kind and p.get('route','unspecified')==route
                    and p.get('body',{}).get('op')=='entity'and p['body'].get('ref')==target]
                if len(existing)==1:
                    # The frozen compiler already turns "image depicts Alice"
                    # into a depiction context containing Alice. Extend that
                    # existing context rather than adding a second one.
                    existing[0]['body']=conjunction([existing[0]['body'],child]);attachments[key]=existing[0];continue
                roles=[r for r,v in event['arguments'].items()if v==target]
                if len(roles)!=1:fail('context_target','The focal mention must occupy one direct parent argument; nested source phrases need another attachment rule.')
                role=roles[0];del event['arguments'][role]
            else:role='ARGM-PRP'if relation=='purpose'else relation;key=(relation,'')
            prop=dict(role=role,kind=kind,route=route,body=child);event.setdefault('propositions',[]).append(prop);attachments[key]=prop
        return conjunction(parts)
    formula=conjunction(list(bodies.values()))if flat else build(clauses[0]['id'])
    form=dict(version='logical-form-v2',kind='claim',entities=list(entities.values()),formula=formula,
        warnings=['Composed from simple sentences; shared mentions and clause context are explicit proposals, not semantic gold.'])
    inherit_routes(form)
    extra={n['kind']for f in forms.values()for n in nodes(f)if 'body'in n and 'kind'in n}|{'relative','complement'}
    claim=ScopedCompiler().compile(claim_id,' '.join(texts),tokens,form,additional_proposition_kinds=extra)
    claim.metadata['split_composition']=dict(flat=flat,clauses=clauses,shared=proposal['shared'])
    return claim
