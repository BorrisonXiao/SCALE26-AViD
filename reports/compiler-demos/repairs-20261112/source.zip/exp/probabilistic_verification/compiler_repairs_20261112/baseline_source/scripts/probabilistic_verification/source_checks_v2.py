"""Targeted source checks motivated by inspected compiler-development failures.

These catch some added qualifiers and type errors. Passing is not a semantic
equivalence proof; lexical licensing is deliberately more limited than parsing.
"""
import re
from .logical_form import LogicalFormError

LICENSES={
 'possible':r'\b(may|might|could|can|possib\w*|potential\w*|perhaps|maybe|uncertain|unclear)\b',
 'likely':r'\b(likely|probably|expect\w*|presum\w*)\b',
 'future':r'\b(will|shall|soon|tomorrow|next|scheduled|expect\w*|plan\w*|intend\w*|before)\b|going to|about to',
 'obligation':r'\b(must|should|need\w*|require\w*|obligat\w*|ought)\b|ha(?:ve|s|d) to',
 'ability':r'\b(can|could|able|ability|capable)\b',
 'condition':r'\b(if|unless|provided|when|without)\b',
 'uncertain':r'\b(uncertain|unclear|unknown|unconfirmed|unverified|apparently|alleged\w*|reportedly|seem\w*|appear\w*)\b'}
CARDINAL=r'(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|trillion|and|[-\s\d,.])+'

def source_checks(text,tokens,form):
    def fail(code,message):raise LogicalFormError(code,message)
    for e in form.get('entities',[]):
        if not isinstance(e,dict):fail('schema','Entities must be objects.')
        q=e.get('quantity')
        if not q:continue
        if not isinstance(q,dict):fail('quantity','Quantity must contain an operator and value.')
        value=str(q.get('value',''))
        if re.search(r'\d\s+\d',value):fail('quantity_type','Several separate numeric values are not a single cardinality. Preserve a range, ratio or separate measurements.')
        if e.get('type')=='context' or re.search(r'\d:\d|\bamounts?\b',value,re.I):
            fail('quantity_type','A time value or amount is not a counted group. Use a typed time/measurement literal or an amount property: '+e.get('text',''))
        if q.get('operator') in {'exact','at_least','more_than','at_most','less_than'} and not re.fullmatch(CARDINAL,value,re.I):
            fail('quantity_type','A numeric group operator needs a cardinal value, not '+value)
    operations=[];verbatim=[]
    def inventory(node):
        if isinstance(node,dict):
            if node.get('op'):operations.append(node['op'])
            if node.get('kind')=='verbatim_text':verbatim.append(str(node.get('value','')))
            for v in node.values():inventory(v)
        elif isinstance(node,list):
            for v in node:inventory(v)
    inventory(form)
    quoted_spans=[m.span() for q in verbatim for m in re.finditer(re.escape(q),text,re.I)]
    def in_quote(t):return any(lo<=t.get('start_char',-1) and t.get('end_char',-1)<=hi for lo,hi in quoted_spans)
    negatives=[t for t in tokens if t['text'].lower() in {'not',"n't",'never'} and not in_quote(t)]
    if negatives and not {'not','not_exists'}&set(operations) and not re.search(r'\bnot only\b',text,re.I):
        fail('polarity_omission','A source negation is absent from the logical operators. Preserve the intended negated clause.')
    if any(t['text'].lower()=='no' and t.get('upos')=='DET' and t.get('deprel')=='det' and not in_quote(t) for t in tokens) and 'not_exists'not in operations:
        fail('negative_quantifier','A no-NP claim requires entity and event existence under joint negation; that quantified construction is not implemented.')
    def visit(node):
        if not isinstance(node,dict):return
        if node.get('op')=='not_exists' and not any(t['text'].casefold()=='no' and t.get('upos')=='DET' and not in_quote(t) for t in tokens):
            fail('unlicensed_quantifier','A negative existential requires an explicit no-NP in this compiler version.')
        if node.get('op')=='qualified':
            op=node.get('operator')
            if op in LICENSES and not re.search(LICENSES[op],text,re.I):
                fail('unlicensed_qualification','The source does not license '+op+' qualification. Do not add a modal/future/conditional event.')
        if node.get('kind')=='condition' and 'body' in node and not re.search(LICENSES['condition']+r'|\bcondition\w*\b',text,re.I):
            fail('unlicensed_condition','The source does not license a conditional clause. A relative clause or an ongoing event is not an IF condition.')
        if node.get('op')=='event':
            predicate=node.get('predicate','');anchor=node.get('anchor','')
            exact=[t for t in tokens if t['text'].casefold()==anchor.casefold()]
            if len(exact)==1 and exact[0].get('upos') in {'ADP','DET','CCONJ','SCONJ','PART'}:
                if predicate.replace('_','-') not in {anchor,'be-'+anchor,'located-'+anchor,'part-'+anchor}:
                    fail('predicate_alignment','A function word does not license this event predicate: '+anchor+' -> '+predicate)
            for role,arg in node.get('arguments',{}).items():
                if role=='agent' and isinstance(arg,dict):
                    fail('literal_role_type','An agent must refer to an entity, not a measurement/text literal.')
                if role=='location' and isinstance(arg,dict) and str(arg.get('value','')).lower() in {'missing','dead','dangerous','safe','closed','open','injured'}:
                    fail('literal_role_type','A state such as '+arg['value']+' is not a location. Keep it as a state/property of its participant.')
                if isinstance(arg,dict) and arg.get('kind')=='verbatim_text':
                    positions=list(re.finditer(re.escape(str(arg.get('value',''))),text,re.I))
                    indirect=any(re.search(r'\b(that|whether)\s*$',text[:m.start()],re.I) for m in positions)
                    if not re.search('["“”]',text) and indirect:
                        fail('indirect_verbatim','An indirect report does not certify exact spoken wording. Parse its content as a proposition, without a verbatim-text argument.')
        for value in node.values():
            if isinstance(value,dict):visit(value)
            elif isinstance(value,list):
                for child in value:visit(child)
    visit(form)
