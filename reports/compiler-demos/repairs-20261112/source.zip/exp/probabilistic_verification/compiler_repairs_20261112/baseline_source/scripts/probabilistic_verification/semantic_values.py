"""Shared normalization of explicit dates, clock times, durations and quantities.

No reference date, timezone or video offset is guessed. Original spans are kept
by the caller as alignment metadata, separately from the normalized condition.
"""
import re
from datetime import date,datetime
from .typed_literals import measurement_literal
from .logical_form import LogicalFormError

MONTHS={name:i for i,names in enumerate([
    ('January','Jan'),('February','Feb'),('March','Mar'),('April','Apr'),('May',),
    ('June','Jun'),('July','Jul'),('August','Aug'),('September','Sep','Sept'),
    ('October','Oct'),('November','Nov'),('December','Dec')],1)for name in names}
MONTH='(?:'+'|'.join(sorted(MONTHS,key=len,reverse=True))+')'
DAY=r'\d{1,2}(?:st|nd|rd|th)?'
DATE=rf'(?:\d{{4}}[-/]\d{{2}}[-/]\d{{2}}|{MONTH}\.?\s+{DAY},?\s+\d{{4}}|{DAY}\s+{MONTH}\.?[,]?\s+\d{{4}})'
CLOCK=r'\d{1,2}:\d{2}(?::\d{2})?(?:\s*[AP]M)?'
ZONE=r'(?:UTC|GMT|BJT|ET|Z)'
DATE_TIME=re.compile(rf'(?<![\w:])(?:{DATE}(?:[ T,]+{CLOCK})?|{CLOCK})(?:\s*{ZONE})?(?![\w:])',re.I)
NUMBERS=dict(zero='0',one='1',two='2',three='3',four='4',five='5',six='6',seven='7',eight='8',nine='9',ten='10',eleven='11',twelve='12')

def _point(text,allow_year=False,clock_only=False):
    raw=text.strip().rstrip('.')
    zone=re.fullmatch(rf'(.+?)\s*({ZONE})',raw,re.I)
    if zone:
        value=_point(zone[1],allow_year,clock_only=True)
        if value and value['kind']=='time':return dict(value,timezone=zone[2].upper())
        return None
    if allow_year and re.fullmatch(r'\d{4}',raw):
        if int(raw)==0:raise LogicalFormError('temporal_value','Calendar year zero is unsupported.')
        return dict(kind='date',value=raw)
    dm=re.fullmatch(rf'({DATE})(?:[ T,]+({CLOCK}))?',raw,re.I)
    if dm:
        daytext=re.sub(r'(\d)(?:st|nd|rd|th)\b',r'\1',dm[1],flags=re.I).replace(',','').replace('.','')
        try:
            if re.fullmatch(r'\d{4}[-/]\d{2}[-/]\d{2}',daytext):
                y,m,d=map(int,re.split('[-/]',daytext));value=date(y,m,d)
            else:
                bits=daytext.split();month=next((i for name,i in MONTHS.items()if name.casefold()==(bits[0]if bits[0].isalpha()else bits[1]).casefold()),None)
                d=int(bits[1]if bits[0].isalpha()else bits[0]);value=date(int(bits[2]),month,d)
            clock=_point(dm[2],clock_only=True)['value']if dm[2]else None
        except (ValueError,TypeError):raise LogicalFormError('temporal_value','Invalid explicit calendar date: '+raw)
        return dict(kind='time'if clock else'date',value=value.isoformat()+('T'+clock if clock else''))
    if re.fullmatch(CLOCK,raw,re.I):
        clean=re.sub(r'\s+','',raw).upper();fmt='%I:%M:%S%p'if clean.endswith(('AM','PM'))and clean.count(':')==2 else'%I:%M%p'if clean.endswith(('AM','PM'))else'%H:%M:%S'if clean.count(':')==2 else'%H:%M'
        if not clock_only and not clean.endswith(('AM','PM')):
            parts=list(map(int,clean.split(':')))
            if any(p>59 for p in parts[1:]):raise LogicalFormError('temporal_value','Invalid time component: '+raw)
            return dict(kind='time',value=clean,attribute='unspecified_time_scale')
        try:return dict(kind='time',value=datetime.strptime(clean,fmt).strftime('%H:%M:%S'))
        except ValueError:raise LogicalFormError('temporal_value','Invalid explicit clock time: '+raw)
    return None

def temporal_literal(text,*,allow_year=False):
    raw=text.strip().rstrip('.')
    interval=re.fullmatch(r'(?:from|between)\s+(.+?)\s+(?:to|and)\s+(.+)',raw,re.I)
    if interval:
        lo=_point(interval[1],allow_year);hi=_point(interval[2],allow_year)
        if lo and hi and lo['kind']==hi['kind']:
            lower,upper=lo['value'],hi['value']
            # A date on the start can license an omitted same-day end date.
            # An earlier end clock could mean the next day; do not guess it.
            if 'T' in lower and re.fullmatch(CLOCK,interval[2],re.I):
                clock=_point(interval[2],clock_only=True)
                if not clock or clock['value']<lower.split('T')[1]:
                    raise LogicalFormError('temporal_value','End date is ambiguous: '+raw)
                upper=lower.split('T')[0]+'T'+clock['value']
            elif ('T' in lower)!=('T' in upper):
                raise LogicalFormError('temporal_value','Interval endpoints use different time scales: '+raw)
            def ordering(value):
                if re.fullmatch(r'\d+:\d+(?::\d+)?',value):
                    parts=tuple(map(int,value.split(':')))
                    return parts+(0,)*(3-len(parts))
                return value
            if ordering(lower)>ordering(upper):raise LogicalFormError('temporal_value','Explicit interval has reversed endpoints: '+raw)
            if lo.get('timezone') and hi.get('timezone') and lo['timezone']!=hi['timezone']:
                raise LogicalFormError('temporal_value','Interval timezone labels differ: '+raw)
            result=dict(kind=lo['kind'],value=lower,operator='range',lower=lower,upper=upper)
            if lo.get('attribute'):result['attribute']=lo['attribute']
            # A single zone after the range scopes both endpoints.
            if lo.get('timezone') or hi.get('timezone'):result['timezone']=lo.get('timezone')or hi['timezone']
            return result
        return None
    cue=re.match(r'^(before|after|since|until|during|on|at|from|in|around|about)\s+',raw,re.I)
    body=raw[cue.end():]if cue else raw
    body=re.sub(r'^(?:the\s+)?(?:video\s+)?(?:timestamp|date|time)\s+','',body,flags=re.I)
    elapsed=re.match(r'^T\+\s*',body,re.I)
    if elapsed:
        value=_point(body[elapsed.end():])
        if value:value['attribute']='elapsed';return value
    result=_point(body,allow_year)
    if result and cue and cue[1].lower()in{'before','after','since','until','around','about'}:
        result['operator']={'around':'approx','about':'approx'}.get(cue[1].lower(),cue[1].lower())
    return result

def normalized_literal(text,*,temporal=False):
    value=temporal_literal(text,allow_year=temporal)
    if value:return dict(value,text=text)
    raw=text.strip().rstrip('.')
    normalized=re.sub(r'\b('+'|'.join(NUMBERS)+r')\b',lambda m:NUMBERS[m[0].lower()],raw,flags=re.I)
    duration=re.fullmatch(r'(?:(?:for|during)\s+)?(?:(about|around|approximately|at least|at most)\s+)?(\d+(?:\.\d+)?)\s+(seconds?|minutes?|hours?|days?|weeks?|months?|years?)',normalized,re.I)
    if duration:
        op={None:'exact','about':'approx','around':'approx','approximately':'approx','at least':'at_least','at most':'at_most'}[duration[1].lower()if duration[1]else None]
        return dict(kind='duration',value=duration[2],unit=duration[3].lower().rstrip('s'),operator=op,text=text)
    measured=measurement_literal(normalized)
    if measured:return dict(measured,text=text)
    return None
