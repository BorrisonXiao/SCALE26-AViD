"""The same three-state semantics, with constant states in generated rule heads.

This serializer avoids an unbound state join at each internal expression node.
Overlapping proofs retain exact ProbLog semantics and shared observation IDs.
No probability is pruned, including zero/one neural outputs during learning.
"""
import hashlib
import itertools

from .backend import DeepProbLogVerifier, FeatureSource, RelationClassifier
from .logic import combine_states
from .representation import STATES


def direct_prolog_program(programs, *, learned=True):
    observations = {}
    for program in programs:
        for oid, observation in program.observations.items():
            if oid in observations and observations[oid] != observation:
                raise ValueError('Conflicting shared observations.')
            observations[oid] = observation
    lines = ['% Explicit state heads; categorical observations remain shared.']
    if learned and any(o.trainable and o.available for o in observations.values()):
        lines.append('nn(relation_net,[tensor(features(O))],Z,[supported,refuted,unknown]) :: learned_status(O,Z).')
    for oid, observation in sorted(observations.items()):
        if learned and observation.trainable and observation.available:
            lines.append(f'status({oid},Z) :- learned_status({oid},Z).')
        else:
            lines.append('; '.join(f'{p:.17g}::status({oid},{s})' for p, s in zip(observation.distribution, STATES))+'.')
    nodes, names = {}, {}

    def emit(expr):
        if expr in nodes:
            return nodes[expr]
        name = 'n'+str(len(nodes))
        nodes[expr] = name
        if expr.op == 'atom':
            for state in STATES:
                lines.append(f'node({name},{state}) :- status({expr.atom_id},{state}).')
        elif expr.op == 'constant':
            lines.append(f'node({name},{expr.state}).')
        elif expr.op == 'not':
            child = emit(expr.children[0])
            for state in STATES:
                lines.append(f'node({name},{combine_states("not", [state])}) :- node({child},{state}).')
        elif expr.op in {'and', 'or', 'evidence'}:
            children = [emit(c) for c in expr.children]
            current = children[0]
            for i, right in enumerate(children[1:]):
                target = name if i == len(children)-2 else f'{name}_fold{i}'
                if expr.op in {'and', 'or'}:
                    decisive = 'refuted' if expr.op == 'and' else 'supported'
                    neutral = 'supported' if expr.op == 'and' else 'refuted'
                    rules = [(decisive, [(current, decisive)]), (decisive, [(right, decisive)]),
                             (neutral, [(current, neutral), (right, neutral)]),
                             ('unknown', [(current, 'unknown'), (right, neutral)]),
                             ('unknown', [(current, neutral), (right, 'unknown')]),
                             ('unknown', [(current, 'unknown'), (right, 'unknown')])]
                    for state, body in rules:
                        lines.append(f'node({target},{state}) :- '+', '.join(f'node({c},{s})' for c, s in body)+'.')
                else:
                    for a, b in itertools.product(STATES, repeat=2):
                        lines.append(f'node({target},{combine_states("evidence", [a,b])}) :- node({current},{a}), node({right},{b}).')
                current = target
        else:
            raise ValueError('Expression must be grounded.')
        return name

    for program in programs:
        if program.claim_id in names:
            raise ValueError('Repeated claim ID.')
        name = 'c_'+hashlib.sha256(program.claim_id.encode()).hexdigest()[:16]
        names[program.claim_id] = name
        root = emit(program.expression)
        for state in STATES:
            lines.append(f'verdict({name},{state}) :- node({root},{state}).')
            lines.append(f'query(verdict({name},{state})).')
    return '\n'.join(lines)+'\n', names


class DirectVerifier(DeepProbLogVerifier):
    """Existing PyTorch/DeepProbLog inference and training with the new serializer."""
    def __init__(self, programs, *, learned=True, seed=7, hidden=64,
                 classifier=None, feature_source=None, learning_rate=0.01):
        import torch
        from deepproblog.engines import ExactEngine
        from deepproblog.model import Model
        from deepproblog.network import Network
        from deepproblog.semiring.graph_semiring import GraphSemiring

        class ExactSemiring(GraphSemiring):
            def is_zero(self, value):
                return type(value) is float and value == 0.

            def is_one(self, value):
                return type(value) is float and value == 1.

        torch.manual_seed(seed)
        torch.set_num_threads(2)
        self.program, self.claim_names = direct_prolog_program(programs, learned=learned)
        self.observations = {oid: obs for p in programs for oid, obs in p.observations.items()}
        self.classifier = (classifier if classifier is not None else RelationClassifier(hidden)).double()
        self.optimizer = torch.optim.Adam(self.classifier.parameters(), lr=learning_rate)
        network = Network(self.classifier, 'relation_net', optimizer=self.optimizer, batching=True)
        self.model = Model(self.program, [network] if learned else [], load=False)
        self.model.set_engine(ExactEngine(self.model), cache=True, semiring=ExactSemiring)
        self.feature_source = feature_source if feature_source is not None else FeatureSource(self.observations)
        self.model.add_tensor_source('features', self.feature_source)
        self.learned, self.seed = learned, seed
