"""Check current examples, failure ledger, corpus pool and legacy navigation."""
import functools,http.server,json,threading
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_readiness_20261112'
def main():
 class Handler(http.server.SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'site')));threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
 with sync_playwright()as p:
  browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(base+'/reports/',wait_until='networkidle');assert page.locator('.card-link').count()==2
  page.goto(base+'/reports/compiler-demos.html#remaining-failures',wait_until='networkidle');page.wait_for_function('document.querySelector("#ready-select").options.length===38')
  assert page.locator('[role="tab"]').all_text_contents()==['Overview','Examples','All claims','Daily log','History']
  assert all(x in page.locator('#current-work').inner_text()for x in ['1,963','82.65%','1,978','411','off by default'])
  page.screenshot(path=str(RUN/'overview_desktop.png'))
  page.goto(base+'/reports/compiler-demos.html#ready-example',wait_until='networkidle');cases=json.loads((RUN/'cases.json').read_text())
  checked=page.evaluate('''rows=>{for(const r of rows){const s=document.querySelector('#ready-select');s.value=r.id;s.dispatchEvent(new Event('change'));if(document.querySelector('#ready-text').textContent!==r.text)throw Error(r.id+' text');const x=JSON.parse(document.querySelector('#ready-exact').textContent);if(JSON.stringify(x.previous)!==JSON.stringify(r.before)||JSON.stringify(x.current_or_diagnostic)!==JSON.stringify(r.after))throw Error(r.id+' artifacts');}return rows.length;}''',cases)
  ledger=json.loads((RUN/'remaining_cases.json').read_text());count=page.evaluate('''rows=>{for(const r of rows){const s=document.querySelector('#ready-failure-select');s.value=r.claim_id;s.dispatchEvent(new Event('change'));if(document.querySelector('#ready-failure-text').textContent!==r.text||!document.querySelector('#ready-failure-reason').textContent.endsWith(r.reason))throw Error(r.claim_id);}return rows.length;}''',ledger)
  page.fill('#ready-search','TjHepwuhkYFA_1016');assert page.locator('#ready-failure-select option').count()==1
  page.goto(base+'/reports/compiler-demos.html?ready=ready_collapse#ready-example',wait_until='networkidle');assert page.locator('#ready-select').input_value()=='ready_collapse';assert 'nominal event'in page.locator('#ready-after').inner_text().lower();page.screenshot(path=str(RUN/'nominal_example.png'))
  page.goto(base+'/reports/compiler-demos.html#outputs',wait_until='networkidle');page.select_option('#all-filter','accepted');page.wait_for_timeout(300);assert page.locator('#all-select option').count()==1963
  page.select_option('#all-filter','recovered');page.wait_for_timeout(200);assert page.locator('#all-select option').count()==10
  for fragment,panel in [('component-example','walkthroughs'),('full-rewrite-example','walkthroughs'),('syntax-demos','walkthroughs'),('components-before-readiness','history'),('full-rewrite-before-components','history'),('alignment-example','history'),('outputs','outputs'),('daily-progress','daily-progress')]:
   page.goto(base+'/reports/compiler-demos.html#'+fragment,wait_until='networkidle');assert page.locator('#'+panel).is_visible()
  assert page.locator('#component-select option').count()==47 and page.locator('#full-case option').count()==449 and page.locator('#demo-select option').count()==41
  page.goto(base+'/reports/compiler-demos.html?ready=TzF9M4kZ3Pys_239#ready-example',wait_until='networkidle');page.set_viewport_size({'width':390,'height':844});page.emulate_media(color_scheme='dark');assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');page.screenshot(path=str(RUN/'example_mobile_dark.png'))
  page.goto(base+'/reports/verification-pipeline.html#next-steps',wait_until='networkidle');assert '1,963'in page.locator('#next-steps').inner_text()
  for n in ['summary.json','cases.json','semantic_review.json','remaining_cases.json','feature_training_smoke.json','tests.xml','README.md','source.zip']:assert page.request.get(base+'/reports/compiler-demos/readiness-20261112/'+n).ok,n
  assert not errors,errors;proof=dict(comparisons=checked,exclusions=count,retained_viewer=1963,recoveries_viewer=10,main_reports=2,views=5,old_components=47,old_model_cases=449,old_demos=41,mobile_overflow=False,page_errors=errors);(RUN/'browser_checks.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof);browser.close()
 server.shutdown()
if __name__=='__main__':main()
