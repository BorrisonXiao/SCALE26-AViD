"""Current report sections for the complete, previously rejected cohort."""
import json
import shutil
from html import escape as esc
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/rewrite_all_20261112'
DOWNLOAD = 'compiler-demos/full-rewrite-20261112/'


def link(cid, text):
    return '<a href="?rewrite_all=' + esc(cid) + '#full-rewrite-example">' + esc(text) + '</a>'


def table(title, headers, rows):
    return '<div class="table-wrap"><table><caption>Table 1. ' + title + '</caption><thead><tr>' + ''.join('<th>' + h + '</th>' for h in headers) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join('<td>' + str(v) + '</td>' for v in row) + '</tr>' for row in rows) + '</tbody></table></div>'


def status_html():
    s = json.loads((RUN / 'summary.json').read_text())
    return f'<b>{s["reviewed_full_passes"]:,}/2,375 retained compilations ({s["reviewed_full_rate"]:.2%})</b>: the previous 1,926 passes plus 27 newly reviewed additions. All 449 previous rejects have now been tested; 422 remain. These are development compilation results, not semantic accuracy or media-verification results.'


def next_steps():
    return '''<ol><li><b>Preserve operators when composing clauses.</b> Keep OR, temporal overlap (while), modality and quoted/source content attached to their original clauses. Goal: stop a successful compilation from silently changing meaning.</li><li><b>Resolve references to original participants more accurately.</b> Start with class descriptions such as “the court is a panel” followed by “the panel,” original noun-phrase spans and numbered/group references. Goal: reduce false alignment refusals and disconnected participants without merging different entities.</li><li><b>Replay the saved 419 model responses after these changes and review new programs.</b> Goal: measure compiler gains with a fixed prompt and fixed text; establish a safe stopping point before new model runs or relation training.</li></ol>'''


def overview_html():
    s = json.loads((RUN / 'summary.json').read_text())
    h = '<h2 id="remaining-failures">All 449 previous rejects tested</h2><p>' + status_html() + '</p>'
    h += '<p><b>The main bottlenecks are compiling the subclaims and aligning their entities, followed by meaning lost in the final program.</b> Shorter sentences help some cases, but sentence splitting alone does not preserve logical relationships.</p>'
    h += table('Complete pipeline on the fixed 449 previous rejects. Counts are disjoint first-stop outcomes; later problems can also exist.', ['Outcome', 'Claims', 'Meaning'], [
        ('Direct compilation now passes checks', 30, 'No model request; 14 approved on meaning review, 16 not approved.'),
        ('At least one rewritten subclaim fails compilation', 207, 'Missing content, unresolved clauses, modal scope and other compiler checks.'),
        ('Subclaims pass, original-reference alignment fails', 142, '119 entity-reference failures; other failures involve events, descriptions or source context.'),
        ('Alignment passes, composition fails', 14, 'Mostly conflicting descriptions when combining the clauses.'),
        ('Model explicitly refuses', 2, 'No complete proposal.'),
        ('Rewritten, composed program passes automatic checks', 54, '13 approved on meaning review; 41 not approved.')])
    h += '<p>30 originals bypass the model; the remaining 419 receive one fixed prompt. The model proposes 1,437 clauses; 1,140 pass component checks. In 210 rewrites every subclaim passes, but only 54 yield a complete program. All 84 final programs (30 direct + 54 rewritten) were inspected with their original claims: <b>27 faithful additions, 57 not approved</b>. The other 365 cases have failure diagnostics, not blanket semantic judgments.</p>'
    h += table('Corpus counts with different acceptance requirements. All 1,926 earlier passes are retained exactly; their meaning was not re-reviewed in this run.', ['Condition', 'Retained claims', 'Remaining'], [
        ('Previous compiler plus two reviewed splits', '1,926/2,375 (81.09%)', 449),
        ('New automatic checks only; includes unfaithful programs', '2,010/2,375 (84.63%)', 365),
        ('Previous passes plus 27 newly reviewed additions', '1,953/2,375 (82.23%)', 422)])
    h += '<p>The reviewed increase is 27 claims, or 1.14 percentage points. Reviews are compiler-author assistant judgments on development data, not independent human gold. Do not describe 82.23% as semantic accuracy. The 422 remaining cases comprise 207 component failures, 142 alignment failures, 14 composition failures, 2 model refusals and 57 reviewed rejections.</p>'
    h += '<h3>What was implemented</h3><ul><li><b>Multiple adjuncts on one event:</b> “drive along a dock towards the ship” keeps both directions on the same driving event. Duplicate core participants are still checked.</li><li><b>Measurements:</b> preserve values, both range bounds and units; distinguish four robots from a 100 m dash, and scalar magnitude 7.7 from an object count.</li><li><b>Absence:</b> “no narration” means no matching narration/event exists. It does not introduce positive narration. Incomplete audio candidates give insufficient evidence.</li><li><b>Participant and source alignment:</b> use explicit participant IDs; distinguish a clip depicting an event from a camera broadcasting a livestream as its object.</li></ul><p>These are opt-in compiler extensions. The historical default compiler reproduces all 2,375 saved outputs exactly. All 360 regression and extension tests pass. Some direct automatic passes still have incorrect meaning; those 16 are excluded from the 27 additions.</p>'
    h += '<h3>Examples that explain the bottleneck</h3><ul>'
    for cid, text in [('TbJqMFkNxARY_132', 'Two trucks: one event, two directions; direct repair, no model.'), ('TgR_u37mCoQ4_1916', 'No narration: quantified absence, with no positive narration.'), ('Txf2EdqOg1SQ_2236', 'Boat capsizing: the event stays inside the clip’s depiction.'), ('TzF9M4kZ3Pys_239', 'People covered in dust: even this short unchanged sentence lacks an attached semantic-role frame.'), ('Tg0UxWYuPeJ0_433', 'Robot 1/Robot 2: the split still fails participant alignment; explicit-ID support does not fix every parser analysis.'), ('TbJqMFkNxARY_160', 'No containers fully in the water: the model adds “There are no containers,” which loses the restriction. This proposal also stops at composition.'), ('TFgw4IaR9R8s_1612', 'Court/panel: both sentences compile, but the judges are attached to a disconnected panel.')]:
        h += '<li>' + link(cid, text) + '</li>'
    h += '</ul><h3>Recommendation and proposed next steps</h3><p>Pause prompt changes. The next useful work is reference resolution and preservation of the original operators during composition. Reuse this fixed output set to tell whether compiler changes help.</p>' + next_steps()
    h += '<p><a href="#full-rewrite-example">Inspect all 449 outcomes, exact prompts and programs</a> · <a href="#syntax-demos">Earlier compiler demos</a> · <a href="#history">Earlier experiments</a> · <a href="verification-pipeline.html#next-steps">Project checklist</a></p>'
    return h


def examples_html():
    h = '''<section id="full-rewrite"><h2>Original claim → direct compiler → fallback → program</h2><p>All 449 cases were earlier strict failures. The improved compiler is tried first; 30 now pass and never reach the model. The other 419 are sent to frozen Qwen3-30B-A3B-Instruct-2507. It returns sentences, not logical identifiers or predicates. A separate step compiles those sentences, matches their participants to the original, preserves context and composes the program.</p><figure><div class="flow"><div><b>1. Original claim</b><small>Unchanged text; direct compilation first.</small></div><div><b>2. Failure-only rewrite</b><small>One fixed prompt; 1–12 sentences.</small></div><div><b>3. Compile and align</b><small>Keep participants, events and context linked.</small></div><div><b>4. Program and review</b><small>Compare the complete result with the original.</small></div></div><figcaption>Figure 1. Compilation flow. Automatic acceptance means compiler checks passed; it does not certify preserved meaning or media support.</figcaption></figure><div class="box" id="full-rewrite-example"><h3>Inspect a case</h3><div class="toolbar"><label>Subset<select id="full-filter"><option value="all">All 449 cases</option><option value="faithful">27 reviewed additions</option><option value="review_rejected">57 generated programs not approved</option><option value="direct_pass">30 direct passes; model skipped</option><option value="component_compilation">207 component failures</option><option value="alignment">142 alignment failures</option><option value="composition">14 composition failures</option><option value="model_refuse">2 model refusals</option></select></label><label>Search<input id="full-search" type="search" placeholder="Claim text or ID"></label></div><p id="full-count" role="status"></p><label for="full-case">Claim</label><select id="full-case"></select><p id="full-id" class="muted"></p><blockquote id="full-original"></blockquote><h4>Direct compilation and fallback decision</h4><p id="full-direct"></p><details><summary>Direct compiler structure or failure</summary><div id="full-direct-graph"></div></details><h4>Proposed sentences and component checks</h4><p id="full-generation"></p><div id="full-components"></div><h4>Inferred references and clause relationships</h4><p>c1, c2, etc. identify sentences; x and e identifiers name entities and events. “Original token” refers to a word in the unchanged original. Repeated mentions must identify the same original participant. Depiction means that the nested event is shown in a source, rather than asserted independently.</p><div id="full-links"></div><h4>Final compilation and meaning review</h4><p id="full-review" class="note"></p><div id="full-graph"></div><details><summary>Exact predicates, logical form and generated program</summary><p>These are compiled requirements, not predictions from a media model.</p><pre id="full-predicates"></pre><pre id="full-form"></pre><pre id="full-program"></pre></details><h4>Exact model request and response</h4><p id="full-model"></p><div id="full-request"><h5>System instruction</h5><p id="full-system" style="white-space:pre-wrap"></p><h5>User message</h5><pre id="full-user"></pre><h5>Raw response</h5><pre id="full-response"></pre></div><p><a id="full-share" href="#full-rewrite-example">Link to this case</a></p></div><h3>What absence means in native DeepProbLog</h3><p>“The video features no narration” requires absence of matching narration/event witnesses. NOT EXISTS is the standard logical operation for this. The table below uses <b>constructed candidate inventories and fixed observations</b>, not audio extracted from a video. A complete inventory is an explicit input assumption; an empty detector output alone cannot establish absence.</p>'''
    native = json.loads((RUN / 'native_absence.json').read_text())
    h += table('Actual native DeepProbLog results with supplied observations. Each displayed distribution has probability 1 on the named outcome.', ['Supplied audio inventory', 'Complete inventory?', 'Result'], [('Empty' if r['empty_audio_inventory'] else 'Matching narration/event present', 'Yes' if r['inventory_complete'] else 'No', 'Insufficient evidence' if r['expected'] == 'unknown' else r['expected'].capitalize()) for r in native['cases']])
    h += '''<h3>Protocol and limits</h3><p>One final prompt, temperature 0, seed 42, float16, maximum 3,072 output tokens and 32,768-token context. No truth labels, media or reference judgments were supplied. Final generation used one H100 for 134 allocated seconds, including 84.29 seconds of generation. An earlier 418-request attempt completed in 133 allocated seconds before its stop request arrived; its outputs are preserved and entirely excluded. Both jobs are released.</p><p>After the first complete evaluation, source-use matching was corrected for clip/footage and media objects; the same cached responses were re-evaluated. The first evaluation and source snapshots are retained. No best-of-prompts selection, new media experiment or empirical relation training was run. All 84 generated final programs were reviewed by the compiler-author assistant. Failed candidates may contain further errors beyond the first reported check.</p><h3>Proposed next steps and goals</h3>''' + next_steps()
    downloads = [('summary.json', 'Counts'), ('cases.json', 'All 449 case records'), ('raw.jsonl', '419 exact requests/responses'), ('semantic_review.json', 'Meaning reviews'), ('recoveries.json', '27 additions'), ('remaining.json', '422 remaining cases'), ('native_absence.json', 'Native absence checks'), ('model_config.json', 'Model settings'), ('tests.xml', '360 tests'), ('README.md', 'Design and reproduction'), ('source.zip', 'Source and cached experiment')]
    h += '<p>' + ' · '.join('<a href="' + DOWNLOAD + name + '">' + label + '</a>' for name, label in downloads) + '</p></section>'
    return h


def write_downloads():
    folder = ROOT / 'site/reports/compiler-demos/full-rewrite-20261112'
    folder.mkdir(parents=True, exist_ok=True)
    for name in ['summary.json', 'cases.json', 'raw.jsonl', 'semantic_review.json', 'recoveries.json', 'remaining.json', 'native_absence.json', 'model_config.json', 'tests.xml', 'historical_regression.json', 'resource_usage.json']:
        shutil.copy2(RUN / name, folder / name)
    shutil.copy2(ROOT / 'docs/rewrite_all_20261112.md', folder / 'README.md')
