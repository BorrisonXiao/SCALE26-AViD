"""Compile a fixed structured-rewrite round and emit actual retry diagnostics."""
import argparse,copy,json
from pathlib import Path
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.split_alignment import compose_aligned
from probabilistic_verification.compiler_extensions import OPTIONS
from compile_claim_splits import serialize

def evaluate(record,parsed):
 cid=record['claim_id'];row=dict(claim_id=cid,original=record['text'],components=[],proposal=parsed['proposal']);proposal=parsed['proposal']
 if parsed.get('validation_error'):return dict(row,stage='validation',output=dict(status='unsupported',code='rewrite_schema',reason=parsed['validation_error']))
 if proposal['action']in{'refuse','keep'}:return dict(row,stage='model_'+proposal['action'],output=dict(status='unsupported',code='model_'+proposal['action'],reason='No simpler sentence returned.'))
 for c in parsed['clauses']:
  r=copy.deepcopy(c.get('record'))
  if r:
   r['compiler_context']=dict(original_text=record['text'])
   if len(parsed['clauses'])==1:r['claim_id']=cid
  q=compile_one(r)if r else dict(status='unsupported',code='sentence_parse',reason=c['parse_error'])
  row['components'].append(dict(id=c['id'],text=c['text'],result=q))
 failures=[c for c in row['components']if c['result']['status']!='compiled']
 if failures:return dict(row,stage='component_compilation',output=dict(status='unsupported',code=failures[0]['result'].get('code'),reason=failures[0]['id']+': '+failures[0]['result']['reason']))
 if len(row['components'])==1:return dict(row,stage='compiled_single',output=row['components'][0]['result'])
 try:
  r=copy.deepcopy(record);r['compiler_options']=dict(OPTIONS,event_coreference=True,logical_operators=True)
  claim,proposal,trace=compose_aligned(cid,r,parsed['clauses'],{c['id']:c['result']for c in row['components']},max_clauses=8,formula=proposal['formula'])
  row.update(stage='compiled_composed',proposal=proposal,alignment=trace,output=serialize(claim))
 except Exception as e:row.update(stage='composition',output=dict(status='unsupported',code=getattr(e,'code',type(e).__name__),reason=str(e)))
 return row

def main():
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--input',type=Path,required=True);a=p.parse_args();records={r['claim_id']:r for r in map(json.loads,a.input.read_text().splitlines())};rows=[evaluate(records[r['claim_id']],r)for r in map(json.loads,(a.run/'parsed.jsonl').read_text().splitlines())]
 (a.run/'pipeline.jsonl').write_text(''.join(json.dumps(r)+'\n'for r in rows));print('Complete',sum(r['output']['status']=='compiled'for r in rows),'/',len(rows),flush=True)
if __name__=='__main__':main()
