#!/usr/bin/env python3
"""
AViD Phase 2 — build_manifest_patch.py

The AVID annotation pipeline (phase 1) assigned claim_index values that differ
from the ones the step1 probing pipeline wrote to manifest.jsonl, for a subset
of claims.  This creates a false no_video=True flag in verify_support.py
(the claim ID is looked up in the manifest and not found, so no chunks are
returned and the unit is treated as having no media).

This script creates manifest_avid.jsonl = original manifest + new entries for
the annotation claim IDs that are missing from the manifest.  Each new entry is
built by finding the same claim text under the same topic in the original
manifest and copying its video/chunk metadata.

Unmatched claims (no entry with identical text in the original manifest) are
skipped; they will continue to carry no_video=True.

Output: /exp/cxiao/scale26/avid/exp/phase2/manifest_avid.jsonl
"""

import argparse
import csv
import json
from pathlib import Path

_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_ORIG_MANIFEST = "/exp/cxiao/scale26/probing/exp/step1/manifests/manifest.jsonl"
DEFAULT_HYPERGRAPH    = str(_AVID / "exp/phase1/hypergraph.jsonl")
DEFAULT_ANN_UNITS     = str(_AVID / "exp/phase1/reports/annotation_units.tsv")
DEFAULT_OUTPUT        = str(_AVID / "exp/phase2/manifest_avid.jsonl")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--manifest",         default=DEFAULT_ORIG_MANIFEST)
    ap.add_argument("--hypergraph",       default=DEFAULT_HYPERGRAPH)
    ap.add_argument("--annotation-units", default=DEFAULT_ANN_UNITS)
    ap.add_argument("--output",           default=DEFAULT_OUTPUT)
    args = ap.parse_args()

    # 1. Load original manifest
    orig: dict[str, dict] = {}
    with open(args.manifest, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            cid = f"{r['topic_id']}_{r['claim_index']}"
            orig[cid] = r

    # 2. Load claim texts from hypergraph (covers annotation-only claims)
    hg_texts: dict[str, str] = {}
    with open(args.hypergraph, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            hg_texts[r["claim_id"]] = r["claim_text"]

    # 3. Load all annotation claim IDs
    ann_claim_ids: set[str] = set()
    with open(args.annotation_units, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            if cid:
                ann_claim_ids.add(cid)

    # 4. Build per-topic text->manifest_entry index
    from collections import defaultdict
    text_to_entry: dict[str, dict[str, dict]] = defaultdict(dict)
    for cid, rec in orig.items():
        topic = rec["topic_id"]
        text = rec["claim_text"].strip()
        text_to_entry[topic][text] = rec

    # 5. Find missing annotation claims and build patch entries
    patch: list[dict] = []
    n_matched = 0
    n_unmatched = 0
    print("\nMatching missing annotation claims to manifest entries:")
    for cid in sorted(ann_claim_ids):
        if cid in orig:
            continue  # already in manifest — no patch needed
        topic, idx_str = cid.rsplit("_", 1)
        claim_text = hg_texts.get(cid, "")
        if not claim_text:
            print(f"  SKIP {cid} — claim text not in hypergraph")
            n_unmatched += 1
            continue
        matched = text_to_entry.get(topic, {}).get(claim_text.strip())
        if matched is None:
            print(f"  UNMATCHED {cid} — no entry with same text under {topic}")
            n_unmatched += 1
            continue
        # Build a new entry that preserves all media metadata but uses the
        # annotation claim's own claim_index so the lookup finds it.
        new_entry = dict(matched)
        new_entry["claim_index"] = int(idx_str)
        patch.append(new_entry)
        n_matched += 1
        print(f"  PATCH {cid} -> {matched['topic_id']}_{matched['claim_index']} "
              f"({len(matched.get('chunks', []))} chunk(s))")

    print(f"\nPatch summary: {n_matched} matched, {n_unmatched} unmatched (remain no_video)")

    # 6. Write merged manifest: original first, then patch entries
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    n_written = 0
    with open(out_path, "w", encoding="utf-8") as f:
        for rec in orig.values():
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n_written += 1
        for rec in patch:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n_written += 1

    print(f"\nWrote {n_written} entries ({len(orig)} original + {len(patch)} patch) → {out_path}")


if __name__ == "__main__":
    main()
