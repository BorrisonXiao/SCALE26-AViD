#!/usr/bin/env python3
"""Constituency parse of AViD claims (AllenNLP elmo-constituency-parser) → const_parses.jsonl.

Env: envs/srl-eval (reuses the AllenNLP install from the trained-SRL baseline — no new
dependency). For the constituency + trained-SRL alternative annotation surface
(docs/plans/avid_phase3_constituency_srl_annotation_v1.md).

Emits per claim {claim_id, claim_text, tokens, trees (bracketed), hierplane_tree}; the
surface builder (build_gold_const_pilot.py) does char-span mapping + pruning + SRL overlay.
Resumable.
"""
import json, argparse
from pathlib import Path

AVID = Path("/exp/cxiao/scale26/avid")
HYPERGRAPH = AVID / "exp/phase1/hypergraph.jsonl"
OUT = AVID / "exp/phase3/const/const_parses.jsonl"
MODEL = "https://storage.googleapis.com/allennlp-public-models/elmo-constituency-parser-2020.02.10.tar.gz"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0, help="parse only first N claims (smoke)")
    ap.add_argument("--claim-ids", nargs="*", default=[], help="restrict to these claim ids")
    ap.add_argument("--out", default=str(OUT))
    ap.add_argument("--cuda-device", type=int, default=-1)
    args = ap.parse_args()

    from allennlp.predictors.predictor import Predictor
    import torch
    dev = args.cuda_device if (args.cuda_device >= 0 and torch.cuda.is_available()) else -1
    print(f"Loading constituency parser (cuda_device={dev}; downloads ~1GB first run)…", flush=True)
    predictor = Predictor.from_path(MODEL, cuda_device=dev)
    print("Model loaded.", flush=True)

    claims = [json.loads(l) for l in open(HYPERGRAPH)]
    if args.claim_ids:
        want = set(args.claim_ids)
        claims = [c for c in claims if c["claim_id"] in want]
    if args.limit:
        claims = claims[:args.limit]

    outp = Path(args.out); outp.parent.mkdir(parents=True, exist_ok=True)
    done = set()
    if outp.exists():
        for l in open(outp):
            try: done.add(json.loads(l)["claim_id"])
            except Exception: pass
    todo = [c for c in claims if c["claim_id"] not in done]
    print(f"{len(claims)} claims | {len(todo)} to parse | {len(done)} cached", flush=True)

    with open(outp, "a", encoding="utf-8") as f:
        for i, c in enumerate(todo):
            try:
                r = predictor.predict(sentence=c["claim_text"])
                rec = {"claim_id": c["claim_id"], "claim_text": c["claim_text"],
                       "tokens": r.get("tokens", []), "trees": r.get("trees", ""),
                       "hierplane_tree": r.get("hierplane_tree", {})}
            except Exception as e:
                rec = {"claim_id": c["claim_id"], "claim_text": c["claim_text"], "error": str(e)}
                print(f"  ERR {c['claim_id']}: {e}", flush=True)
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            f.flush()
            if (i + 1) % 20 == 0:
                print(f"  {i+1}/{len(todo)}", flush=True)
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
