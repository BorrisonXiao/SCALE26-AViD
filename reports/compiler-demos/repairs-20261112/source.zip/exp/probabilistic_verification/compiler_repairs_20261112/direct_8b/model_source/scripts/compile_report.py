#!/usr/bin/env python
"""
AViD Phase 1 — compile_report.py

Reads hypergraph + V1 + V2 outputs and produces:
  reports/figures/        : PNG visualizations
  reports/annotation.tsv : compact annotation-ready TSV (human-facing)
  reports/phase1_report.md: markdown summary report

Usage:
    python scripts/compile_report.py
"""
import csv
import json
import math
import os
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import seaborn as sns

# ── Paths ──────────────────────────────────────────────────────────────────
ROOT        = Path("/exp/cxiao/scale26/avid")
PHASE1      = ROOT / "exp/phase1"
REPORT_DIR  = PHASE1 / "reports"
FIG_DIR     = REPORT_DIR / "figures"
ANNOT_TSV   = REPORT_DIR / "annotation.tsv"
REPORT_MD   = REPORT_DIR / "phase1_report.md"

HYPERGRAPH  = PHASE1 / "hypergraph.jsonl"
V1_PATH     = PHASE1 / "affordance_rules.jsonl"
V2_PATH     = PHASE1 / "affordance_llm.jsonl"

CHANNELS    = ["visual_other", "visual_ocr", "audio_speech", "audio_other", "unverifiable"]
CH_SHORT    = {"visual_other": "vis-obj", "visual_ocr": "vis-ocr",
               "audio_speech": "aud-sp", "audio_other": "aud-oth",
               "unverifiable": "unverif"}
CH_COLORS   = {
    "visual_other":  "#4C72B0",
    "visual_ocr":    "#55A868",
    "audio_speech":  "#C44E52",
    "audio_other":   "#DD8452",
    "unverifiable":  "#8172B2",
}
NODE_TYPES   = ["entity", "event", "attribute", "relation-op",
                "coord-op", "logical-op", "cardinality"]
FACTOR_TYPES = ["predicate_argument", "prepositional_relation", "entity_attribute",
                "temporal_relation", "coordination", "negation",
                "relative_clause", "cardinality", "full_claim"]

# ── Load data ──────────────────────────────────────────────────────────────

def load_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f]

print("Loading data ...")
claims = load_jsonl(HYPERGRAPH)
v1_raw = {r["claim_id"]: r for r in load_jsonl(V1_PATH)}
v2_raw = {r["claim_id"]: r for r in load_jsonl(V2_PATH)}

REPORT_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

# ── Aggregate stats ────────────────────────────────────────────────────────

node_type_cnt   = Counter()
factor_type_cnt = Counter()
nodes_per_claim = []
factors_per_claim = []
manifest_modalities = Counter()
multi_sent_count = 0

# V1: per-unit channel lists (multi-label)
v1_node_ch   = Counter()   # channel -> count
v1_factor_ch = Counter()

# V2: per-unit argmax channel
v2_node_ch   = Counter()
v2_factor_ch = Counter()
v2_node_entropy   = []
v2_factor_entropy = []

# V1 vs V2 agreement (argmax match for nodes)
agree_count = 0
total_paired = 0

for rec in claims:
    cid = rec["claim_id"]
    nodes   = rec["nodes"]
    factors = rec["factors"]

    nodes_per_claim.append(len(nodes))
    factors_per_claim.append(len(factors))
    if rec.get("multi_sentence"):
        multi_sent_count += 1

    for m in rec.get("modalities", []):
        manifest_modalities[m] += 1

    for n in nodes:
        node_type_cnt[n["node_type"]] += 1

    for f in factors:
        factor_type_cnt[f["factor_type"]] += 1

    # V1 channels
    v1 = v1_raw.get(cid, {})
    for nid, chs in v1.get("affordance_nodes", {}).items():
        for ch in chs:
            v1_node_ch[ch] += 1
    for fid, chs in v1.get("affordance_factors", {}).items():
        for ch in chs:
            v1_factor_ch[ch] += 1

    # V2 distributions
    v2 = v2_raw.get(cid, {})
    v2_nodes_dists = v2.get("affordance_llm_nodes", {})
    v2_factor_dists = v2.get("affordance_llm_factors", {})

    for nid, dist in v2_nodes_dists.items():
        top = max(dist, key=dist.get)
        v2_node_ch[top] += 1
        probs = list(dist.values())
        ent = -sum(p * math.log(p + 1e-12) for p in probs)
        v2_node_entropy.append(ent)

        # V1 vs V2 agreement
        v1_chs = set(v1.get("affordance_nodes", {}).get(nid, []))
        if v1_chs:
            total_paired += 1
            if top in v1_chs:
                agree_count += 1

    for fid, dist in v2_factor_dists.items():
        top = max(dist, key=dist.get)
        v2_factor_ch[top] += 1
        probs = list(dist.values())
        ent = -sum(p * math.log(p + 1e-12) for p in probs)
        v2_factor_entropy.append(ent)

total_nodes   = sum(nodes_per_claim)
total_factors = sum(factors_per_claim)
n_claims      = len(claims)

# ── Plotting helpers ────────────────────────────────────────────────────────

sns.set_theme(style="whitegrid", font_scale=1.1)
plt.rcParams.update({"figure.dpi": 120, "savefig.bbox": "tight"})

def savefig(name):
    p = FIG_DIR / name
    plt.savefig(p, dpi=120, bbox_inches="tight")
    plt.close()
    print(f"  saved {p.name}")
    return p.name

# ── Fig 1: Node type distribution ─────────────────────────────────────────
print("Plotting ...")
fig, ax = plt.subplots(figsize=(8, 4))
labels = [t for t in NODE_TYPES if node_type_cnt[t] > 0]
vals   = [node_type_cnt[t] for t in labels]
colors = sns.color_palette("Blues_d", len(labels))
bars   = ax.barh(labels[::-1], vals[::-1], color=colors[::-1])
for bar, v in zip(bars, vals[::-1]):
    ax.text(bar.get_width() + 10, bar.get_y() + bar.get_height()/2,
            f"{v:,}", va="center", fontsize=9)
ax.set_xlabel("Count")
ax.set_title(f"Node Type Distribution  (n={total_nodes:,} nodes, {n_claims} claims)")
ax.set_xlim(0, max(vals) * 1.15)
fig1 = savefig("fig1_node_types.png")

# ── Fig 2: Factor type distribution ───────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 4))
labels = [t for t in FACTOR_TYPES if factor_type_cnt[t] > 0]
vals   = [factor_type_cnt[t] for t in labels]
colors = sns.color_palette("Greens_d", len(labels))
bars   = ax.barh(labels[::-1], vals[::-1], color=colors[::-1])
for bar, v in zip(bars, vals[::-1]):
    ax.text(bar.get_width() + 5, bar.get_y() + bar.get_height()/2,
            f"{v:,}", va="center", fontsize=9)
ax.set_xlabel("Count")
ax.set_title(f"Factor Type Distribution  (n={total_factors:,} factors, {n_claims} claims)")
ax.set_xlim(0, max(vals) * 1.15)
fig2 = savefig("fig2_factor_types.png")

# ── Fig 3: Manifest modality distribution ─────────────────────────────────
fig, ax = plt.subplots(figsize=(7, 3.5))
mod_labels = sorted(manifest_modalities, key=manifest_modalities.get, reverse=True)
mod_vals   = [manifest_modalities[m] for m in mod_labels]
short_labels = [m.replace("video-", "vid-").replace("audio-", "aud-") for m in mod_labels]
bars = ax.bar(short_labels, mod_vals, color=sns.color_palette("Set2", len(mod_labels)))
for bar, v in zip(bars, mod_vals):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
            str(v), ha="center", va="bottom", fontsize=9)
ax.set_ylabel("Claim count")
ax.set_title("Manifest Modality Tags  (multi-label; sum > n_claims)")
ax.tick_params(axis="x", rotation=20)
fig3 = savefig("fig3_modalities.png")

# ── Fig 4: Nodes/factors per claim histograms ──────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
for ax, data, label, color in zip(
    axes,
    [nodes_per_claim, factors_per_claim],
    ["Nodes per claim", "Factors per claim"],
    ["#4C72B0", "#55A868"],
):
    ax.hist(data, bins=range(0, max(data)+2), color=color, edgecolor="white", alpha=0.85)
    ax.axvline(np.mean(data), color="red", linestyle="--", linewidth=1.5,
               label=f"mean={np.mean(data):.1f}")
    ax.axvline(np.median(data), color="orange", linestyle=":", linewidth=1.5,
               label=f"median={np.median(data):.0f}")
    ax.set_xlabel(label)
    ax.set_ylabel("Claims")
    ax.legend(fontsize=8)
plt.suptitle("Hypergraph Size Distribution", y=1.02)
fig4 = savefig("fig4_size_distribution.png")

# ── Fig 5: V1 channel distribution (nodes) ────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
for ax, cnt, title in zip(
    axes,
    [v1_node_ch, v1_factor_ch],
    ["V1 Affordance — Nodes (multi-label)", "V1 Affordance — Factors (multi-label)"]
):
    vals   = [cnt[ch] for ch in CHANNELS]
    colors = [CH_COLORS[ch] for ch in CHANNELS]
    xlabels = [CH_SHORT[ch] for ch in CHANNELS]
    bars = ax.bar(xlabels, vals, color=colors)
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
                str(v), ha="center", va="bottom", fontsize=9)
    ax.set_ylabel("Assignments (multi-label)")
    ax.set_title(title)
plt.suptitle("V1 Lexicon+WordNet Affordance", y=1.02)
fig5 = savefig("fig5_v1_affordance.png")

# ── Fig 6: V2 channel distribution (nodes + factors) ──────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
for ax, cnt, title in zip(
    axes,
    [v2_node_ch, v2_factor_ch],
    ["V2 LLM — Nodes (argmax)", "V2 LLM — Factors (argmax)"]
):
    vals   = [cnt[ch] for ch in CHANNELS]
    colors = [CH_COLORS[ch] for ch in CHANNELS]
    xlabels = [CH_SHORT[ch] for ch in CHANNELS]
    bars = ax.bar(xlabels, vals, color=colors)
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
                str(v), ha="center", va="bottom", fontsize=9)
    ax.set_ylabel("Units (argmax label)")
    ax.set_title(title)
plt.suptitle("V2 Qwen3-30B-A3B LLM Affordance", y=1.02)
fig6 = savefig("fig6_v2_affordance.png")

# ── Fig 7: V1 vs V2 comparison (node-level argmax) ────────────────────────
# For V1 multi-label: use the first (most specific) channel as argmax proxy
v1_argmax = Counter()
v2_given_v1 = defaultdict(Counter)   # v1_ch -> v2_ch -> count
for rec in claims:
    cid = rec["claim_id"]
    v1  = v1_raw.get(cid, {})
    v2  = v2_raw.get(cid, {})
    for nid in [n["id"] for n in rec["nodes"]]:
        v1_chs = v1.get("affordance_nodes", {}).get(nid, [])
        v2_dist = v2.get("affordance_llm_nodes", {}).get(nid, {})
        if not v1_chs or not v2_dist:
            continue
        v1_top = v1_chs[0]
        v2_top = max(v2_dist, key=v2_dist.get)
        v1_argmax[v1_top] += 1
        v2_given_v1[v1_top][v2_top] += 1

# Confusion-style heatmap: rows=V1, cols=V2
fig, ax = plt.subplots(figsize=(7, 5.5))
present_chs = [ch for ch in CHANNELS if v1_argmax[ch] > 0]
mat = np.zeros((len(present_chs), len(CHANNELS)))
for i, v1ch in enumerate(present_chs):
    total = sum(v2_given_v1[v1ch].values())
    for j, v2ch in enumerate(CHANNELS):
        mat[i, j] = v2_given_v1[v1ch].get(v2ch, 0) / max(total, 1)

sns.heatmap(
    mat, annot=True, fmt=".2f", cmap="Blues",
    xticklabels=[CH_SHORT[c] for c in CHANNELS],
    yticklabels=[CH_SHORT[c] for c in present_chs],
    ax=ax, vmin=0, vmax=1, linewidths=0.5,
)
ax.set_xlabel("V2 argmax channel")
ax.set_ylabel("V1 top channel")
ax.set_title("V1 → V2 Channel Agreement (row-normalized, nodes only)")
fig7 = savefig("fig7_v1v2_agreement.png")

# ── Fig 8: V2 entropy distribution ────────────────────────────────────────
fig, ax = plt.subplots(figsize=(7, 3.5))
ax.hist(v2_node_entropy, bins=30, color="#4C72B0", edgecolor="white", alpha=0.85,
        label=f"nodes (n={len(v2_node_entropy):,})")
ax.hist(v2_factor_entropy, bins=30, color="#C44E52", edgecolor="white", alpha=0.6,
        label=f"factors (n={len(v2_factor_entropy):,})")
ax.axvline(np.mean(v2_node_entropy), color="#4C72B0", linestyle="--", linewidth=1.5)
ax.axvline(np.mean(v2_factor_entropy), color="#C44E52", linestyle="--", linewidth=1.5)
ax.set_xlabel("Shannon entropy (nats)")
ax.set_ylabel("Units")
ax.set_title("V2 Distribution Entropy  (lower = more confident)")
ax.legend()
fig8 = savefig("fig8_v2_entropy.png")

# ── Fig 9: Per-claim channel coverage (V2 argmax pie) ─────────────────────
fig, axes = plt.subplots(1, 2, figsize=(11, 5))
for ax, cnt, title in zip(
    axes,
    [v2_node_ch, v2_factor_ch],
    ["Nodes", "Factors"],
):
    vals   = [cnt[ch] for ch in CHANNELS if cnt[ch] > 0]
    labels = [f"{CH_SHORT[ch]}\n{cnt[ch]:,}" for ch in CHANNELS if cnt[ch] > 0]
    colors = [CH_COLORS[ch] for ch in CHANNELS if cnt[ch] > 0]
    ax.pie(vals, labels=labels, colors=colors, autopct="%1.1f%%",
           startangle=140, textprops={"fontsize": 9})
    ax.set_title(f"V2 Channel Mix — {title}")
fig9 = savefig("fig9_v2_pie.png")

# ── Fig 10: Sample dependency graph (text-based ASCII via networkx) ─────────
# Node-factor bipartite sketch for 1 example claim
import networkx as nx
sample = claims[2]  # "Waves are crashing into shore."
G = nx.DiGraph()
node_ids   = [n["id"] for n in sample["nodes"]]
factor_ids = [f["id"] for f in sample["factors"]]
node_labels  = {n["id"]: f"{n['id']}\n{n['text']}\n({n['node_type']})" for n in sample["nodes"]}
factor_labels = {f["id"]: f"{f['id']}\n({f['factor_type']})" for f in sample["factors"]}

for n in sample["nodes"]:
    G.add_node(n["id"], kind="node")
for f in sample["factors"]:
    G.add_node(f["id"], kind="factor")
    for nid in f.get("node_ids", []):
        if nid in node_ids:
            G.add_edge(f["id"], nid)

fig, ax = plt.subplots(figsize=(10, 5))
pos = nx.shell_layout(G)
nx.draw_networkx_nodes(G, pos,
    nodelist=node_ids,
    node_color="#4C72B0", node_size=1400, ax=ax, alpha=0.9)
nx.draw_networkx_nodes(G, pos,
    nodelist=factor_ids,
    node_color="#C44E52", node_shape="s", node_size=1600, ax=ax, alpha=0.8)
nx.draw_networkx_labels(G, pos,
    labels={**node_labels, **factor_labels},
    font_size=7, ax=ax)
nx.draw_networkx_edges(G, pos, ax=ax, arrows=True,
    arrowstyle="->", edge_color="#666666", width=1.2)
legend_els = [
    mpatches.Patch(color="#4C72B0", label="Node (circle)"),
    mpatches.Patch(color="#C44E52", label="Factor (square)"),
]
ax.legend(handles=legend_els, loc="upper right", fontsize=9)
ax.set_title(f'Hypergraph: "{sample["claim_text"]}"')
ax.axis("off")
fig10 = savefig("fig10_sample_graph.png")

print("All figures saved.")

# ── Annotation TSV ─────────────────────────────────────────────────────────
print("Writing annotation TSV ...")

TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted",
    "gold_channels", "notes",
]

# Factor type priority for dedup (lower index = kept when texts collide)
FACTOR_PRIORITY = [
    "predicate_argument", "entity_attribute", "prepositional_relation",
    "temporal_relation", "coordination", "negation", "relative_clause",
    "cardinality", "full_claim",
]

def _factor_rank(ft):
    try:
        return FACTOR_PRIORITY.index(ft)
    except ValueError:
        return len(FACTOR_PRIORITY)

def highlighted(text, span):
    idx = text.lower().find(span.lower())
    if idx == -1:
        return text
    return text[:idx] + "**" + text[idx:idx+len(span)] + "**" + text[idx+len(span):]

skipped_relop = 0
skipped_dedup = 0
rows = []

for rec in claims:
    cid        = rec["claim_id"]
    claim_text = rec["claim_text"]

    # Collect candidate rows for this claim, keyed by normalised unit_text.
    # Value: best row so far + list of all node_type values seen for that span.
    seen: dict[str, dict] = {}   # norm_text -> row dict (best candidate)
    seen_types: dict[str, list[str]] = {}

    # ── Nodes (skip relation-op: prepositions / conjunctions as single words) ──
    for n in rec["nodes"]:
        if n["node_type"] == "relation-op":
            skipped_relop += 1
            continue
        norm = n["text"].strip().lower()
        row = {
            "claim_id":          cid,
            "unit_id":           n["id"],
            "unit_type":         "node",
            "node_type":         n["node_type"],
            "claim_text":        claim_text,
            "unit_text":         n["text"],
            "claim_highlighted": highlighted(claim_text, n["text"]),
            "gold_channels":     "",
            "notes":             "",
        }
        if norm not in seen:
            seen[norm]       = row
            seen_types[norm] = [n["node_type"]]
        else:
            seen_types[norm].append(n["node_type"])
            # Prefer node over factor for same span; among nodes keep first seen

    # ── Factors ───────────────────────────────────────────────────────────────
    for f in rec["factors"]:
        norm = f["surface_span"].strip().lower()
        row = {
            "claim_id":          cid,
            "unit_id":           f["id"],
            "unit_type":         "factor",
            "node_type":         f["factor_type"],
            "claim_text":        claim_text,
            "unit_text":         f["surface_span"],
            "claim_highlighted": highlighted(claim_text, f["surface_span"]),
            "gold_channels":     "",
            "notes":             "",
        }
        if norm not in seen:
            seen[norm]       = row
            seen_types[norm] = [f["factor_type"]]
        else:
            seen_types[norm].append(f["factor_type"])
            existing = seen[norm]
            # Prefer node over factor for the same span
            if existing["unit_type"] == "factor" and row["unit_type"] == "node":
                seen[norm] = row
            # Among factors, prefer the more specific type
            elif existing["unit_type"] == "factor" and row["unit_type"] == "factor":
                if _factor_rank(f["factor_type"]) < _factor_rank(existing["node_type"]):
                    seen[norm] = row

    # Emit one row per unique span; record merged types in node_type if > 1
    for norm, row in seen.items():
        all_types = seen_types[norm]
        if len(all_types) > 1:
            unique_types = list(dict.fromkeys(all_types))  # preserve order, dedupe
            row = dict(row)
            row["node_type"] = "|".join(unique_types)
            skipped_dedup += len(all_types) - 1
        rows.append(row)

with open(ANNOT_TSV, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=TSV_COLS, delimiter="\t")
    writer.writeheader()
    writer.writerows(rows)

print(f"  relation-op nodes dropped:  {skipped_relop}")
print(f"  duplicate spans collapsed:  {skipped_dedup}")
print(f"  annotation.tsv: {len(rows)} rows → {ANNOT_TSV}")

# ── Stats summary ──────────────────────────────────────────────────────────
v1v2_agree_pct = 100 * agree_count / max(total_paired, 1)

# Top-channel entropy averages
mean_node_ent   = np.mean(v2_node_entropy)
mean_factor_ent = np.mean(v2_factor_entropy)

# Peaked (>0.95) fraction
peaked_nodes   = sum(1 for e in v2_node_entropy   if e < 0.15)  # ~p=0.97 → H≈0.11
peaked_factors = sum(1 for e in v2_factor_entropy if e < 0.15)

# ── Markdown report ────────────────────────────────────────────────────────
print("Writing markdown report ...")

report = f"""\
# AViD Phase 1 — Results Report

Generated: 2026-06-16

---

## 1. Dataset Overview

| Metric | Value |
|---|---|
| Claims | {n_claims:,} |
| Multi-sentence claims | {multi_sent_count} |
| Total nodes | {total_nodes:,} |
| Total factors | {total_factors:,} |
| Avg nodes / claim | {np.mean(nodes_per_claim):.1f} (median {int(np.median(nodes_per_claim))}) |
| Avg factors / claim | {np.mean(factors_per_claim):.1f} (median {int(np.median(factors_per_claim))}) |
| Annotation units (nodes + factors) | {total_nodes + total_factors:,} |

---

## 2. Hypergraph Structure

### 2.1 Node Types

![Node type distribution](figures/fig1_node_types.png)

| Type | Count | % |
|---|---|---|
{"".join(f"| {t} | {node_type_cnt[t]:,} | {100*node_type_cnt[t]/max(total_nodes,1):.1f}% |{chr(10)}" for t in NODE_TYPES if node_type_cnt[t] > 0)}

### 2.2 Factor Types

![Factor type distribution](figures/fig2_factor_types.png)

| Type | Count | % |
|---|---|---|
{"".join(f"| {t} | {factor_type_cnt[t]:,} | {100*factor_type_cnt[t]/max(total_factors,1):.1f}% |{chr(10)}" for t in FACTOR_TYPES if factor_type_cnt[t] > 0)}

### 2.3 Size Distribution

![Claim size histogram](figures/fig4_size_distribution.png)

### 2.4 Example Hypergraph

![Sample hypergraph](figures/fig10_sample_graph.png)

*Claim: "Waves are crashing into shore."*
Blue circles = nodes; red squares = factors; arrows = membership edges.

---

## 3. Manifest Modality Tags

![Modality distribution](figures/fig3_modalities.png)

| Modality Tag | Claim count |
|---|---|
{"".join(f"| {m} | {c} |{chr(10)}" for m, c in sorted(manifest_modalities.items(), key=lambda x: -x[1]))}

*Tags are multi-label (one claim can match multiple modalities).*

---

## 4. V1 Affordance (Lexicon + WordNet)

![V1 affordance](figures/fig5_v1_affordance.png)

V1 assigns hard channel sets per unit using:
- UPOS-based rules (NOUN/PROPN → visual\\_other, VERB → depends on lemma, etc.)
- WordNet supersenses (sound hyponyms → audio\\_other, communication lemmas → audio\\_speech)
- Hand-crafted lexicons (visual\\_ocr words, unverifiable markers)

Multi-label: a node can appear in multiple channels.

| Channel | Node assignments | Factor assignments |
|---|---|---|
{"".join(f"| {ch} | {v1_node_ch[ch]:,} | {v1_factor_ch[ch]:,} |{chr(10)}" for ch in CHANNELS)}

---

## 5. V2 Affordance (Qwen3-30B-A3B via vLLM)

![V2 affordance](figures/fig6_v2_affordance.png)
![V2 channel pie](figures/fig9_v2_pie.png)

V2 uses a 5-option MCQ prompt (A=vis-obj, B=vis-ocr, C=aud-sp, D=aud-oth, E=unverif).
Top-30 logprobs at first generated position → renormalized soft distribution.

**Node coverage:** {len(v2_node_entropy):,}/{total_nodes:,} (100%)
**Factor coverage:** {len(v2_factor_entropy):,}/{total_factors:,} (100%)

### 5.1 Argmax distribution (nodes)

| Channel | Count | % |
|---|---|---|
{"".join(f"| {ch} | {v2_node_ch[ch]:,} | {100*v2_node_ch[ch]/max(len(v2_node_entropy),1):.1f}% |{chr(10)}" for ch in CHANNELS)}

### 5.2 Confidence (entropy)

![V2 entropy](figures/fig8_v2_entropy.png)

| Metric | Nodes | Factors |
|---|---|---|
| Mean entropy (nats) | {mean_node_ent:.3f} | {mean_factor_ent:.3f} |
| Peaked (H < 0.15) | {peaked_nodes:,} ({100*peaked_nodes/max(len(v2_node_entropy),1):.0f}%) | {peaked_factors:,} ({100*peaked_factors/max(len(v2_factor_entropy),1):.0f}%) |

H < 0.15 nats corresponds approximately to a single channel with p ≥ 0.95.

---

## 6. V1 ↔ V2 Agreement

![V1 vs V2 agreement](figures/fig7_v1v2_agreement.png)

Metric: V2 argmax ∈ V1 hard channel set (multi-label match).
**Agreement: {agree_count:,}/{total_paired:,} ({v1v2_agree_pct:.1f}%)**

The heatmap (Fig 7) shows row-normalized confusion: for each V1 top channel, what does V2 predict?

---

## 7. Annotation Package

Output file: `reports/annotation.tsv`

| Column | Description |
|---|---|
| claim\\_id | Unique claim identifier |
| unit\\_id | Node (n\\*) or factor (f\\*) ID |
| unit\\_type | `node` or `factor` |
| node\\_type | Semantic role — see README in reports/ for definitions |
| claim\\_text | Full claim text |
| unit\\_text | Surface text of the unit |
| claim\\_highlighted | Claim with unit span in **bold** |
| gold\\_channels | **← Fill in** (pipe-separated, e.g. `visual_other\\|audio_other`) |
| notes | **← Optional** free-text notes / structure flags |

Total rows: {len(rows):,}

---

## 8. Known Limitations

- **Brysbaert concreteness norms** not loaded — V1 concreteness feature is inactive.
  Download CSV from Brysbaert et al. (2014) → `data/brysbaert_concreteness.csv`.
- **3 claims missing `full_claim` factor** (copular/existential roots not covered):
  `TzF9M4kZ3Pys_285`, `TFOEIehBwT8Q_522`, `TKCfkoNUssZI_723`.
- **`unverifiable` under-predicted by V2** (0.7% of nodes) — model may be biased
  toward assigning evidence channels; annotation will calibrate.
- **V1 `relation-op` nodes** (prepositions, conjunctions) get empty channel sets —
  they are function words and should be annotated based on their arguments.

---

## 9. Next Steps

1. **Human annotation pilot**: 20 claims from `annotation.tsv` → fill `gold_channels`.
2. **V1/V2 eval vs gold**: per-channel precision/recall once gold labels exist.
3. **Fetch Brysbaert CSV** and re-run `affordance_rules.py` for improved V1 coverage.
4. **Phase 2**: connect to audio/visual evidence extraction per unit.
"""

REPORT_MD.write_text(report, encoding="utf-8")
print(f"  report: {REPORT_MD}")

print("\nDone. Summary:")
print(f"  Figures:        {FIG_DIR}  ({len(list(FIG_DIR.glob('*.png')))} PNGs)")
print(f"  Annotation TSV: {ANNOT_TSV}  ({len(rows):,} rows)")
print(f"  Report:         {REPORT_MD}")
