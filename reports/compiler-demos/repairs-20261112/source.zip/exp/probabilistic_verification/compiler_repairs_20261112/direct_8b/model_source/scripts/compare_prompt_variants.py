#!/usr/bin/env python3
"""
AViD Phase 2 — prompt-variant ablation comparison.

Reads per-variant support_annotation.tsv (built by build_support_annotation.py for
each of base/r1/r2/r3) plus the affordance prior, and emits a cross-variant
comparison: support distributions, per-channel fire rates, affordance↔support
agreement, the per-claim same-status rate (the de-anchoring health check), and a
per-unit wide table for drill-down.

NOTE: with no human gold yet, this compares variants to EACH OTHER and to the
affordance prior. It shows how prompt framing shifts the measurement; it does not
by itself certify which framing is most correct — that needs the gold pilot.

Outputs (under --output-dir):
  variant_comparison.tsv   one row per variant (summary metrics)
  variant_per_unit.tsv     one row per unit, status+channels for every variant
  variant_comparison.md    human-readable summary

Usage:
    python scripts/compare_prompt_variants.py \\
        --ablation-dir exp/phase2/prompt_ablation \\
        --affordance-tsv exp/phase1/affordance_v2/affordance_annotation.tsv \\
        --variants base,r1,r2,r3
"""

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_ABLATION_DIR = str(_AVID / "exp/phase2/prompt_ablation")
DEFAULT_AFF_TSV      = str(_AVID / "exp/phase1/affordance_v2/affordance_annotation.tsv")

CHANNELS = ["visual_ocr", "visual_other", "audio_speech", "audio_other"]


def load_formulated(path: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    if not path:
        return out
    p = Path(path)
    if not p.exists():
        print(f"  WARNING: --formulated path not found: {path}")
        return out
    for line in open(p, encoding="utf-8"):
        try:
            o = json.loads(line)
        except json.JSONDecodeError:
            continue
        cid = (o.get("claim_id") or "").strip()
        uid = (o.get("unit_id") or "").strip()
        if cid and uid:
            out[f"{cid}|{uid}"] = {
                "visual_question": (o.get("visual_question") or "").strip(),
                "audio_question":  (o.get("audio_question") or "").strip(),
            }
    return out


def load_affordance(path: str) -> dict[str, str]:
    out = {}
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid:
                out[f"{cid}|{uid}"] = (row.get("pred_llm") or "").strip()
    return out


def load_support(path: str) -> dict[str, dict]:
    out = {}
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid:
                out[f"{cid}|{uid}"] = row
    return out


def _prf(tp, fp, fn):
    p = tp / max(1, tp + fp)
    r = tp / max(1, tp + fn)
    f = 2 * p * r / max(1e-9, p + r)
    return p, r, f


def summarize(sup: dict[str, dict], aff: dict[str, str]) -> dict:
    n = len(sup)
    status_c = defaultdict(int)
    ch_yes = {c: 0 for c in CHANNELS}
    vis_yes = vis_unk = vis_tot = 0
    aud_yes = aud_unk = aud_tot = 0
    hit = defaultdict(int)
    ch_tp = {c: 0 for c in CHANNELS}; ch_fp = {c: 0 for c in CHANNELS}; ch_fn = {c: 0 for c in CHANNELS}
    by_claim_status = defaultdict(list)

    for key, row in sup.items():
        no_video = (row.get("no_video", "false").lower() == "true")
        status_c[row.get("status", "unknown")] += 1
        verd = {c: row.get(f"support_{c}", "unknown") for c in CHANNELS}
        for c in CHANNELS:
            if verd[c] == "yes":
                ch_yes[c] += 1

        if not no_video:
            vtot = verd["visual_ocr"], verd["visual_other"]
            vis_tot += 1
            if "yes" in vtot:
                vis_yes += 1
            elif all(v == "unknown" for v in vtot):
                vis_unk += 1
            atot = verd["audio_speech"], verd["audio_other"]
            aud_tot += 1
            if "yes" in atot:
                aud_yes += 1
            elif all(v == "unknown" for v in atot):
                aud_unk += 1

        prior = aff.get(key, "")
        if prior in CHANNELS:
            hit[verd.get(prior, "unknown")] += 1
        for c in CHANNELS:
            g = (verd[c] == "yes"); pdt = (prior == c)
            if pdt and g: ch_tp[c] += 1
            elif pdt and not g: ch_fp[c] += 1
            elif not pdt and g: ch_fn[c] += 1

        cid = key.split("|", 1)[0]
        by_claim_status[cid].append(row.get("status", "unknown"))

    # per-claim same-status rate over multi-unit claims
    multi = [v for v in by_claim_status.values() if len(v) >= 2]
    same = sum(1 for v in multi if len(set(v)) == 1)
    same_rate = same / max(1, len(multi))

    macro_f1 = sum(_prf(ch_tp[c], ch_fp[c], ch_fn[c])[2] for c in CHANNELS) / len(CHANNELS)
    hit_tot = sum(hit.values())

    return {
        "n_units": n,
        "supported_pct": 100 * status_c.get("supported", 0) / max(1, n),
        "unsupported_pct": 100 * status_c.get("unsupported", 0) / max(1, n),
        "unknown_pct": 100 * status_c.get("unknown", 0) / max(1, n),
        "vis_p1_yes_pct": 100 * vis_yes / max(1, vis_tot),
        "vis_p1_unk_pct": 100 * vis_unk / max(1, vis_tot),
        "aud_p1_yes_pct": 100 * aud_yes / max(1, aud_tot),
        "aud_p1_unk_pct": 100 * aud_unk / max(1, aud_tot),
        "visual_ocr_yes": ch_yes["visual_ocr"],
        "visual_other_yes": ch_yes["visual_other"],
        "audio_speech_yes": ch_yes["audio_speech"],
        "audio_other_yes": ch_yes["audio_other"],
        "aff_hit_yes_pct": 100 * hit.get("yes", 0) / max(1, hit_tot),
        "aff_hit_no_pct": 100 * hit.get("no", 0) / max(1, hit_tot),
        "aff_hit_unk_pct": 100 * hit.get("unknown", 0) / max(1, hit_tot),
        "aff_macro_f1": macro_f1,
        "same_status_rate_pct": 100 * same_rate,
        "n_multiunit_claims": len(multi),
    }


def setup_parser():
    p = argparse.ArgumentParser(description="AViD Phase 2 — prompt-variant comparison")
    p.add_argument("--ablation-dir",  default=DEFAULT_ABLATION_DIR)
    p.add_argument("--affordance-tsv", default=DEFAULT_AFF_TSV)
    p.add_argument("--variants",      default="base,r1,r2,r4,r5",
                   help="Comma-separated variants to compare. r3 is deprecated "
                        "(ADR-008) and excluded from the default.")
    p.add_argument("--formulated",   default="",
                   help="Path to formulated_questions.jsonl (r5 pre-pass output). "
                        "When provided, adds visual_question/audio_question columns "
                        "to variant_per_unit.tsv.")
    p.add_argument("--output-dir",    default="")
    return p


def main():
    args = setup_parser().parse_args()
    ablation_dir = Path(args.ablation_dir)
    out_dir = Path(args.output_dir) if args.output_dir else ablation_dir / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    variants = [v.strip() for v in args.variants.split(",") if v.strip()]

    print("=" * 60)
    print("AViD Phase 2 — compare_prompt_variants.py")
    print(f"  Ablation dir: {ablation_dir}")
    print(f"  Variants:     {variants}")
    print("=" * 60)

    aff = load_affordance(args.affordance_tsv)
    formulated = load_formulated(args.formulated)
    print(f"  Formulated questions: {len(formulated)} units loaded")

    sup_by_variant: dict[str, dict] = {}
    summary: dict[str, dict] = {}
    for v in variants:
        sp = ablation_dir / v / "support_annotation.tsv"
        if not sp.exists():
            print(f"  WARNING: missing {sp}; skipping {v}")
            continue
        sup = load_support(str(sp))
        sup_by_variant[v] = sup
        summary[v] = summarize(sup, aff)
        print(f"  {v}: {len(sup)} units loaded")

    present = list(summary.keys())
    if not present:
        print("ERROR: no variants found. Did build_support_annotation run per variant?")
        return

    # status stability vs base
    base = "base" if "base" in sup_by_variant else present[0]
    for v in present:
        if v == base:
            summary[v]["status_match_vs_base_pct"] = 100.0
            continue
        a, b = sup_by_variant[base], sup_by_variant[v]
        keys = set(a) & set(b)
        match = sum(1 for k in keys if a[k].get("status") == b[k].get("status"))
        summary[v]["status_match_vs_base_pct"] = 100 * match / max(1, len(keys))

    # ---- summary TSV ----
    cols = ["variant", "n_units", "supported_pct", "unsupported_pct", "unknown_pct",
            "vis_p1_yes_pct", "vis_p1_unk_pct", "aud_p1_yes_pct", "aud_p1_unk_pct",
            "visual_ocr_yes", "visual_other_yes", "audio_speech_yes", "audio_other_yes",
            "aff_hit_yes_pct", "aff_hit_no_pct", "aff_hit_unk_pct", "aff_macro_f1",
            "same_status_rate_pct", "n_multiunit_claims", "status_match_vs_base_pct"]
    tsv_path = out_dir / "variant_comparison.tsv"
    with open(tsv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter="\t", lineterminator="\n")
        w.writerow(cols)
        for v in present:
            s = summary[v]
            w.writerow([v] + [
                (f"{s[c]:.2f}" if isinstance(s[c], float) else s[c]) for c in cols[1:]
            ])
    print(f"\n  Wrote {tsv_path}")

    # ---- per-unit wide TSV ----
    all_keys = set()
    for sup in sup_by_variant.values():
        all_keys |= set(sup)
    pu_path = out_dir / "variant_per_unit.tsv"
    meta_src = sup_by_variant[base]
    with open(pu_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter="\t", lineterminator="\n")
        head = ["claim_id", "unit_id", "node_type", "unit_text", "affordance",
                "visual_question", "audio_question"]
        for v in present:
            head += [f"{v}_status", f"{v}_channels"]
        w.writerow(head)
        for key in sorted(all_keys):
            cid, uid = key.split("|", 1)
            ref = meta_src.get(key) or next((sv[key] for sv in sup_by_variant.values()
                                             if key in sv), {})
            fq = formulated.get(key, {})
            base_row = [cid, uid, ref.get("node_type", ""), ref.get("unit_text", ""),
                        aff.get(key, ""),
                        fq.get("visual_question", ""), fq.get("audio_question", "")]
            for v in present:
                r = sup_by_variant[v].get(key, {})
                base_row += [r.get("status", ""), r.get("supporting_channels", "")]
            w.writerow(base_row)
    print(f"  Wrote {pu_path}")

    # ---- markdown ----
    md_path = out_dir / "variant_comparison.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# AViD Phase 2 — Prompt-Variant Ablation\n\n")
        f.write("Binary pass-2 (symmetric MCQ) + UUID filter, across pass-1 stem "
                "variants. No human gold yet: this compares variants to each other "
                "and to the affordance prior.\n\n")
        f.write(
            "- **base** = v2 union stem (with context)  "
            "· **r1** = de-jargoned (with context)  "
            "· **r2** = type-aware (with context)  "
            "· **r4** = type-aware, NO context  "
            "· **r5** = LLM-formulated question, NO context  "
            "· *(r3 deprecated — ADR-008)*\n\n"
        )

        f.write("## Support distribution & channel fire-rate\n\n")
        f.write("| Variant | n | supported% | unsup% | unk% | vis P1-yes% | aud P1-yes% | "
                "ocr=yes | other=yes | speech=yes | aud_other=yes |\n")
        f.write("|" + "---|" * 11 + "\n")
        for v in present:
            s = summary[v]
            f.write(f"| {v} | {s['n_units']} | {s['supported_pct']:.1f} | "
                    f"{s['unsupported_pct']:.1f} | {s['unknown_pct']:.1f} | "
                    f"{s['vis_p1_yes_pct']:.1f} | {s['aud_p1_yes_pct']:.1f} | "
                    f"{s['visual_ocr_yes']} | {s['visual_other_yes']} | "
                    f"{s['audio_speech_yes']} | {s['audio_other_yes']} |\n")
        f.write("\n")

        f.write("## Affordance ↔ support agreement & health\n\n")
        f.write("| Variant | hit-yes% | hit-no% | hit-unk% | macro-F1 | "
                "same-status-rate% | match-vs-base% |\n")
        f.write("|" + "---|" * 7 + "\n")
        for v in present:
            s = summary[v]
            f.write(f"| {v} | {s['aff_hit_yes_pct']:.1f} | {s['aff_hit_no_pct']:.1f} | "
                    f"{s['aff_hit_unk_pct']:.1f} | {s['aff_macro_f1']:.3f} | "
                    f"{s['same_status_rate_pct']:.1f} | "
                    f"{s['status_match_vs_base_pct']:.1f} |\n")
        f.write("\n")
        f.write("- **hit-yes%**: prior argmax channel verified as supported.\n")
        f.write("- **macro-F1**: prior-as-predictor of measured support (4-channel mean).\n")
        f.write("- **same-status-rate%**: of multi-unit claims, fraction where all units "
                "share one status — a *lower* value means the verifier is reasoning per-unit "
                "(the de-anchoring health check; v1 claim-anchor hit 81%).\n")
        f.write("- **match-vs-base%**: per-unit status agreement with the base stem.\n")

    print(f"  Wrote {md_path}")
    print("\nDone.")


if __name__ == "__main__":
    main()
