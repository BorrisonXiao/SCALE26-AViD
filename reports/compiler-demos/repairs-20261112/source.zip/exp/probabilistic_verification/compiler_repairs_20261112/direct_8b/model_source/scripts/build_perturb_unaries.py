#!/usr/bin/env python3
"""
AViD Phase 3 — Build combined perturbed-tree unaries (compositional faithfulness).

For each perturbed tree, assemble a per-node unary keyed by the *perturbed*
claim_id, drawing from two sources:

  1. Calibrated DECOY probes (unaries_perturb_decoy.jsonl) — nodes that the
     perturbation actually changed and that were re-probed against the media,
     keyed by (perturbed_claim_id, node_id).  Binding/removal only.
  2. NATURAL calibrated unaries (unaries_ud_star.jsonl) — every other node is
     unchanged from the original claim, so we copy the natural unary keyed by
     (original_claim_id, node_id).

Negation perturbations have NO decoy probes: every node copies its natural
unary.  We do NOT flip anything here — run_crf_inference.py applies the support
flip per-node using the tree's `negated` flag (tree_crf.unary_from_probe
negated=True).  Copying the *unflipped* natural unary is therefore correct.

Both sources share the identical schema (visual_3way / audio_3way / visual /
audio / T_vis / T_aud), so output rows are schema-compatible with
run_crf_inference.py's load_calibrated_unaries (which reads `visual`/`audio`).

Output: exp/phase3/perturb_star/unaries_perturb.jsonl
        one row per probed node, keyed by (perturbed_claim_id, node_id).

Usage:
    python scripts/build_perturb_unaries.py
"""

import argparse
import json
from collections import Counter
from pathlib import Path

_AVID = Path("/exp/cxiao/scale26/avid")

TREES_IN   = str(_AVID / "exp/phase3/perturb_star/perturbed_trees.jsonl")
DECOY_IN   = str(_AVID / "exp/phase3/perturb_star/unaries_perturb_decoy.jsonl")
NATURAL_IN = str(_AVID / "exp/phase3/nodes/unaries_ud_star.jsonl")
OUT        = str(_AVID / "exp/phase3/perturb_star/unaries_perturb.jsonl")

# Fields copied verbatim from a source unary row (claim_id/unit_id set by us).
_CARRY = ["visual_3way", "audio_3way", "visual", "audio", "T_vis", "T_aud"]


def load_unaries(path: str) -> dict:
    """Load a *_unaries file → {(claim_id, unit_id): row}."""
    out = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            out[(r["claim_id"], r["unit_id"])] = r
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--trees",   default=TREES_IN)
    ap.add_argument("--decoy",   default=DECOY_IN)
    ap.add_argument("--natural", default=NATURAL_IN)
    ap.add_argument("--output",  default=OUT)
    args = ap.parse_args()

    print("Loading sources ...")
    decoy   = load_unaries(args.decoy)
    natural = load_unaries(args.natural)
    print(f"  decoy unaries:   {len(decoy)} (perturbed_claim_id, node) rows")
    print(f"  natural unaries: {len(natural)} (natural_claim_id, node) rows")

    src_counter = Counter()          # decoy / natural / missing
    per_type_src = {}                # perturb_type -> Counter
    covered_cids = set()
    missing_examples = []
    n_rows = 0

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.trees, encoding="utf-8") as fin, \
         open(args.output, "w", encoding="utf-8") as fout:
        for line in fin:
            tree = json.loads(line)
            pcid = tree["claim_id"]                     # perturbed id (X__neg/…)
            ocid = tree["original_claim_id"]            # natural id (X)
            ptype = tree.get("perturb_type", "?")
            per_type_src.setdefault(ptype, Counter())

            for node in tree["nodes"]:
                nid = node["node_id"]
                # Only probed, non-functional nodes carry a unary; unprobed /
                # functional nodes are handled as uniform inside the CRF and
                # never appear in either source.
                if node.get("is_functional") or not node.get("probed", False):
                    continue

                if (pcid, nid) in decoy:
                    src = decoy[(pcid, nid)]
                    origin = "decoy"
                elif (ocid, nid) in natural:
                    src = natural[(ocid, nid)]
                    origin = "natural"
                else:
                    src_counter["missing"] += 1
                    per_type_src[ptype]["missing"] += 1
                    if len(missing_examples) < 10:
                        missing_examples.append((pcid, nid, node.get("node_text")))
                    continue

                row = {"claim_id": pcid, "unit_id": nid}
                for k in _CARRY:
                    if k in src:
                        row[k] = src[k]
                row["unary_source"] = origin
                fout.write(json.dumps(row, ensure_ascii=False) + "\n")
                n_rows += 1
                src_counter[origin] += 1
                per_type_src[ptype][origin] += 1
                covered_cids.add(pcid)

    print(f"\nWrote {n_rows} rows → {args.output}")
    print(f"  sources: decoy={src_counter['decoy']}  "
          f"natural={src_counter['natural']}  missing={src_counter['missing']}")
    print(f"  distinct perturbed claim_ids covered: {len(covered_cids)}")
    print("  by perturb_type:")
    for t in sorted(per_type_src):
        c = per_type_src[t]
        print(f"    {t:9s}: decoy={c['decoy']:5d}  natural={c['natural']:5d}  "
              f"missing={c['missing']}")
    if missing_examples:
        print("  missing examples (no decoy & no natural unary):")
        for pcid, nid, txt in missing_examples:
            print(f"    {pcid} / {nid} / {txt!r}")


if __name__ == "__main__":
    main()
