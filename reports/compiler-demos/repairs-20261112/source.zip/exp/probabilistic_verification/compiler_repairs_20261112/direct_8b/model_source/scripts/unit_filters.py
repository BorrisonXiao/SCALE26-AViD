"""
AViD Phase 2 — deterministic unit filtering for signal verification.

Excludes annotation units that are not meaningfully verifiable against the
signal, using only parser output (UPOS, lemma, node_type, character spans) and
the affordance prediction — no model calls, fully reproducible.

See docs/project_notes/unit_filtering.md for the full rule catalogue with
real examples.

Rule order (precedence):
  1. na          — affordance model said "na" (relational/functional/vague). [external set]
  2. pronoun     — head node UPOS == PRON (bare unresolved referent).
  3. empty       — unit_text is empty/whitespace.
  4. uuid        — unit_text is only a UUID (anonymization artifact; nothing to verify).
  5. negation    — node_type contains 'negation', IFF subsumed by a larger
                   meaningful unit (so the negated content is still verified there).
  6. light_verb  — standalone event node whose lemma is a light/copular verb,
                   IFF subsumed by a larger meaningful unit.
  7. duplicate   — same claim, identical unit_text after punctuation/quote
                   normalization; keep one canonical copy.

The negation/light rules are *subsumption-guarded*: a fragment is only dropped
when a larger surviving unit (predicate_argument or full_claim) strictly
contains its character span. Empirically every candidate is covered, but the
guard makes the rule self-justifying and safe against degenerate parses.
"""

import csv
import json
import re
from collections import defaultdict
from pathlib import Path

# Light / copular / semantically-thin verbs. A bare event node with one of
# these lemmas carries little standalone visual/audio content; the contentful
# claim lives in the predicate_argument / full_claim factor that contains it.
# NOTE: "say" is deliberately excluded — it is a speech act, verifiable via audio.
LIGHT_VERB_LEMMAS = {
    "be", "do", "go", "have", "get", "make",
    "take", "come", "become", "seem", "appear",
}

# UUID anonymization artifact (named entities/usernames replaced by UUIDs in the
# source claims). A unit that is *only* a UUID has nothing to verify against the
# signal. Units that merely *contain* a UUID but carry other content are kept
# (the rest is still verifiable) — only UUID-only spans are dropped.
UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
)


def is_uuid_only(text: str) -> bool:
    """True if text is empty once all UUIDs and surrounding punctuation are stripped."""
    stripped = UUID_RE.sub("", text or "")
    stripped = re.sub(r"[\s\W_]+", "", stripped)
    return bool((text or "").strip()) and stripped == ""


# Drop reasons, in precedence order (first match wins for content rules).
REASONS = ["na", "pronoun", "empty", "uuid", "negation", "light_verb", "duplicate"]


def normalize_text(s: str) -> str:
    """Lowercase; strip leading/trailing quotes and terminal punctuation.

    Used for intra-claim duplicate detection so that
      'Jose Enrique".'  and  '"Jose Enrique"'  and  'Jose Enrique'
    collapse to the same key.
    """
    s = s.strip()
    s = re.sub(r"[‘’“”'\".,;:!?]+$", "", s)
    s = re.sub(r"^[‘’“”'\"]+", "", s)
    return s.lower().strip()


def load_hypergraph_index(path: str) -> dict:
    """Per-claim index: node lemma/upos + character spans for every unit_id.

    Returns {claim_id: {"lemma": {nid: lemma}, "upos": {nid: upos},
                         "spans": {unit_id: (start, end)}}}
    Spans cover both unit_id forms: pu_n<X> / n<X> (nodes) and f<N> (factors).
    Factor spans use the factor's surface_span text located in claim_text
    (falls back to the union of head+arg node spans).
    """
    index: dict[str, dict] = {}
    p = Path(path)
    if not p.exists():
        return index
    with open(p, encoding="utf-8") as f:
        for line in f:
            hg = json.loads(line)
            cid = hg["claim_id"]
            ct = hg.get("claim_text", "")
            nmap = {n["id"]: n for n in hg.get("nodes", [])}
            lemma = {nid: n.get("lemma", "") for nid, n in nmap.items()}
            upos = {nid: n.get("upos", "") for nid, n in nmap.items()}
            spans: dict[str, tuple[int, int]] = {}
            for nid, n in nmap.items():
                sp = (n.get("span_start", -1), n.get("span_end", -1))
                spans[nid] = sp           # node unit form  n<X>
                spans[f"pu_{nid}"] = sp    # phrase form     pu_n<X>
            for fac in hg.get("factors", []):
                ss = fac.get("surface_span", "")
                j = ct.find(ss) if ss else -1
                if j >= 0:
                    spans[fac["id"]] = (j, j + len(ss))
                else:
                    ids = [fac.get("head", "")] + fac.get("args", [])
                    sp = [(nmap[i]["span_start"], nmap[i]["span_end"])
                          for i in ids if i in nmap]
                    if sp:
                        spans[fac["id"]] = (min(s for s, _ in sp),
                                            max(e for _, e in sp))
            index[cid] = {"lemma": lemma, "upos": upos, "spans": spans}
    return index


def _head_lemma(cid: str, uid: str, hg_index: dict) -> str:
    """Lemma of a node unit (pu_n<X> / n<X>). Factors return ''."""
    idx = hg_index.get(cid)
    if not idx:
        return ""
    nid = uid[3:] if uid.startswith("pu_") else uid
    return idx["lemma"].get(nid, "")


def _head_upos(cid: str, uid: str, hg_index: dict) -> str:
    """UPOS of the unit's node (phrase/node) or factor head node."""
    idx = hg_index.get(cid)
    if not idx:
        return ""
    if uid.startswith("pu_"):
        return idx["upos"].get(uid[3:], "")
    if uid.startswith("f"):
        # factor: resolve head via spans is not enough; re-read not needed here
        # because pronoun units are always phrase/node, never factors of interest.
        return idx["upos"].get(uid, "")  # factors absent → "" (handled elsewhere)
    return idx["upos"].get(uid, "")


def filter_units(raw_units: list[dict], hypergraph_path: str,
                 na_keys: set[str]) -> tuple[list[dict], dict]:
    """Apply all deterministic filters.

    raw_units: list of dicts with at least
        claim_id, unit_id, unit_type, node_type, unit_text
    na_keys:   set of "claim_id|unit_id" already classified na (external).

    Returns (surviving_units, stats) where stats maps reason -> count and
    includes 'total_in', 'total_out', and 'examples' (reason -> sample row).
    """
    hg = load_hypergraph_index(hypergraph_path)

    # Pre-compute pronoun (PRON) keys from the hypergraph for the units present.
    by_claim: dict[str, list[dict]] = defaultdict(list)
    for u in raw_units:
        by_claim[u["claim_id"]].append(u)

    # UPOS for a unit: phrase/node via node id; factor via head node id.
    def upos_of(u: dict) -> str:
        cid, uid = u["claim_id"], u["unit_id"]
        idx = hg.get(cid)
        if not idx:
            return ""
        if uid.startswith("pu_"):
            return idx["upos"].get(uid[3:], "")
        if not uid.startswith("f"):
            return idx["upos"].get(uid, "")
        return ""  # factors: pronoun rule doesn't apply

    drop: dict[tuple[str, str], str] = {}

    # ---- Phase A: na, pronoun, empty, uuid (independent content rules) ----
    for u in raw_units:
        cid, uid = u["claim_id"], u["unit_id"]
        key = (cid, uid)
        if f"{cid}|{uid}" in na_keys:
            drop[key] = "na"
        elif upos_of(u) == "PRON":
            drop[key] = "pronoun"
        elif not (u.get("unit_text") or "").strip():
            drop[key] = "empty"
        elif is_uuid_only(u.get("unit_text") or ""):
            drop[key] = "uuid"

    # ---- Phase B: negation + light_verb, guarded by subsumption ----
    # "Meaningful" covering units: not dropped in Phase A and not themselves a
    # negation factor or light-verb event node.
    def is_negation(u):
        return "negation" in (u.get("node_type") or "")

    def is_light(u):
        return (u["unit_type"] == "node"
                and _head_lemma(u["claim_id"], u["unit_id"], hg) in LIGHT_VERB_LEMMAS)

    def meaningful(u):
        return ((u["claim_id"], u["unit_id"]) not in drop
                and not is_negation(u) and not is_light(u))

    def covered(u) -> bool:
        idx = hg.get(u["claim_id"])
        if not idx:
            return False
        s = idx["spans"].get(u["unit_id"])
        if not s or s[0] < 0:
            return False
        for v in by_claim[u["claim_id"]]:
            if v["unit_id"] == u["unit_id"] or not meaningful(v):
                continue
            sv = idx["spans"].get(v["unit_id"])
            if sv and sv[0] <= s[0] and sv[1] >= s[1] and (sv[1] - sv[0]) > (s[1] - s[0]):
                return True
        return False

    for u in raw_units:
        key = (u["claim_id"], u["unit_id"])
        if key in drop:
            continue
        if is_negation(u) and covered(u):
            drop[key] = "negation"
        elif is_light(u) and covered(u):
            drop[key] = "light_verb"

    # ---- Phase C: intra-claim duplicate (keep one canonical copy) ----
    # Among units not yet dropped, group by normalized text within a claim;
    # keep the most canonical (prefer full_claim, then longest raw text, then
    # stable unit_id), drop the rest.
    groups: dict[str, dict[str, list[dict]]] = defaultdict(lambda: defaultdict(list))
    for u in raw_units:
        if (u["claim_id"], u["unit_id"]) in drop:
            continue
        k = normalize_text(u.get("unit_text") or "")
        if k:
            groups[u["claim_id"]][k].append(u)
    for cid, gmap in groups.items():
        for k, members in gmap.items():
            if len(members) <= 1:
                continue
            members.sort(key=lambda v: (
                0 if "full_claim" in (v.get("node_type") or "") else 1,
                -len(v.get("unit_text") or ""),
                v["unit_id"],
            ))
            for v in members[1:]:
                drop[(v["claim_id"], v["unit_id"])] = "duplicate"

    # ---- Assemble survivors + stats ----
    survivors = [u for u in raw_units
                 if (u["claim_id"], u["unit_id"]) not in drop]

    stats = {r: 0 for r in REASONS}
    examples: dict[str, dict] = {}
    for u in raw_units:
        r = drop.get((u["claim_id"], u["unit_id"]))
        if r:
            stats[r] += 1
            examples.setdefault(r, u)
    stats["total_in"] = len(raw_units)
    stats["total_out"] = len(survivors)
    stats["examples"] = examples
    return survivors, stats


def format_stats(stats: dict) -> str:
    lines = [f"    units in:  {stats['total_in']}"]
    for r in REASONS:
        if stats.get(r):
            lines.append(f"      - {r:11s}: -{stats[r]}")
    lines.append(f"    units out: {stats['total_out']}")
    return "\n".join(lines)
