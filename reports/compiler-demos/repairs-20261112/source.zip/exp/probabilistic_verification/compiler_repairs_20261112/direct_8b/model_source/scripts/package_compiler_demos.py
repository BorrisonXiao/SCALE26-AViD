#!/usr/bin/env python3
"""Bundle new compiler evidence and demos, preserving every earlier archive."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_recovery_20261105'
BASE=ROOT/'site/reports/scope-coverage/source.zip'


def main():
    manifest=RUN/'package_manifest.json'
    if BASE.exists():
        with zipfile.ZipFile(BASE)as z:contents={n:z.read(n)for n in z.namelist()if not n.endswith('/')}
        names=sorted(contents)
    else:
        names=json.loads(manifest.read_text())['base_paths'];contents={n:(ROOT/n).read_bytes()for n in names}
    manifest.write_text(json.dumps(dict(base_paths=names,statement='Prior source bundle overlaid with current compiler and demo evidence; original ZIP unchanged.'),indent=2)+'\n')
    files=[ROOT/n for n in ['scripts/probabilistic_verification/content_recovery.py','scripts/probabilistic_verification/scope_coverage.py',
        'scripts/run_scope_coverage_census.py','scripts/run_content_recovery_census.py','scripts/analyze_content_recovery.py',
        'scripts/replay_content_recovery.py','scripts/run_compiler_demo_checks.py','scripts/build_compiler_demos.py',
        'scripts/package_compiler_demos.py','scripts/report_assets/compiler_demos.js','tests/test_content_recovery.py','docs/content_recovery_compilation.md',
        'scripts/build_av_feature_sections.py','scripts/build_compilation_methods_report.py',
        'exp/probabilistic_verification/av_features_20261022/checklist.json']]
    excluded={'WORK_STATUS.md','publication.json','browser_checks.json','archive_verification.json','replay_verification.json'}
    files += [p for p in RUN.rglob('*')if p.is_file()and p.suffix in {'.json','.jsonl','.py','.md','.xml'}and p.name not in excluded]
    for p in files:contents[str(p.relative_to(ROOT))]=p.read_bytes()
    contents['README_COMPILER_DEMOS.md']=(ROOT/'docs/content_recovery_compilation.md').read_bytes()
    contents['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n'for name,data in sorted(contents.items())if name!='SHA256SUMS').encode()
    target=ROOT/'site/reports/compiler-demos/source.zip';target.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED)as z:
        for name,data in sorted(contents.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,5,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
    print('Packaged',len(contents),'files;',round(target.stat().st_size/1048576,2),'MiB')


if __name__=='__main__':main()
