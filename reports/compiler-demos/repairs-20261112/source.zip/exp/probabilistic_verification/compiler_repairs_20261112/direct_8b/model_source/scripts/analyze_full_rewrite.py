"""Audit the full449-case sweep and assemble reviewed full-corpus outputs."""
import hashlib,json
from collections import Counter
from pathlib import Path
from build_reviewed_compilation_report import slim

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/rewrite_all_20261112'


def main():
    rows=list(map(json.loads,(RUN/'pipeline.jsonl').read_text().splitlines()))
    reviews={r['claim_id']:r for r in json.loads((RUN/'semantic_review.json').read_text())['cases']}
    raw={r['claim_id']:r for r in map(json.loads,(RUN/'raw.jsonl').read_text().splitlines())}
    previous=list(map(json.loads,(RUN/'previous_corpus.jsonl').read_text().splitlines()))
    old={r['claim_id']:r for r in previous};cases=[];approved={}
    for row in rows:
        cid=row['claim_id'];review=reviews[cid]
        assert review['artifact_sha256']==hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        assert review['reviewed']==(row['output']['status']=='compiled')
        if review['faithful']:
            assert row['output']['status']=='compiled';approved[cid]=row
        cases.append(dict(claim_id=cid,original=row['original'],previous_code=old[cid].get('code'),previous_reason=old[cid].get('reason'),stage=row['stage'],
            direct=slim(row['direct']),proposal=row.get('proposal'),alignment=row.get('alignment'),
            components=[dict(id=c['id'],text=c['text'],output=slim(c['result']))for c in row['components']],
            output=slim(row['output']),program=row['output'].get('program'),review=review,request=raw.get(cid),surface_checks=row.get('surface_checks',[])))
    combined=[]
    for row in previous:
        cid=row['claim_id']
        if cid in approved:
            assert row['status']=='unsupported'
            row=dict(approved[cid]['output'],claim_id=cid,text=row['text'],
                acceptance='Hash-bound compiler-author fidelity review; diagnostic, not independent gold.')
        combined.append(row)
    assert len(rows)==449 and len(raw)==419 and sum(r['stage']=='direct_pass'for r in rows)==30
    assert all(new==before for new,before in zip(combined,previous)if before['status']=='compiled')
    components=[c for row in rows for c in row['components']]
    automatic=sum(r['output']['status']=='compiled'for r in rows)
    summary=dict(total=2375,cohort=449,previous_passes=1926,direct_passes=30,model_requests=len(raw),
        model_actions=dict(Counter(json.loads(r['raw'])['action']for r in raw.values())),
        generated_clauses=len(components),component_passes=sum(c['result']['status']=='compiled'for c in components),
        all_components_pass=sum(bool(r['components'])and all(c['result']['status']=='compiled'for c in r['components'])for r in rows),
        automatic_programs=automatic,automatic_full_passes=1926+automatic,automatic_full_rate=(1926+automatic)/2375,
        reviewed_programs=sum(r['reviewed']for r in reviews.values()),reviewed_new_passes=len(approved),
        reviewed_direct=sum(r['stage']=='direct_pass'for r in approved.values()),reviewed_rewrites=sum(r['stage']!='direct_pass'for r in approved.values()),
        reviewed_full_passes=sum(r['status']=='compiled'for r in combined),reviewed_full_rate=sum(r['status']=='compiled'for r in combined)/2375,
        remaining=2375-sum(r['status']=='compiled'for r in combined),
        stages=dict(Counter(r['stage']for r in rows)),
        remaining_stages=dict(Counter('review_rejected'if r['output']['status']=='compiled'else r['stage']for r in rows if not reviews[r['claim_id']]['faithful'])),
        failure_codes=dict(Counter(r['output'].get('code')for r in rows if r['output']['status']!='compiled')),
        component_failure_codes=dict(Counter(c['result'].get('code')for c in components if c['result']['status']!='compiled')),
        surface_flags=dict(Counter(flag for row in rows for flag in row.get('surface_checks',[]))),
        limits=['Full previously rejected cohort, not a held-out test.','All84 programs reviewed by compiler-author assistant; not independent human gold.','Other failed proposals have pipeline diagnostics, not blanket semantic judgments.','No new media inference or empirical relation training. Controlled native tests are separate.'])
    assert summary['reviewed_full_passes']==1953 and summary['remaining']==422
    (RUN/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    (RUN/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
    (RUN/'corpus_reviewed.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in combined))
    (RUN/'remaining.json').write_text(json.dumps([dict(claim_id=r['claim_id'],text=r['original'],stage='review_rejected'if r['output']['status']=='compiled'else r['stage'],reason=reviews[r['claim_id']]['reason'])for r in rows if not reviews[r['claim_id']]['faithful']],ensure_ascii=False,indent=2)+'\n')
    (RUN/'recoveries.json').write_text(json.dumps([c for c in cases if c['review']['faithful']],ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
