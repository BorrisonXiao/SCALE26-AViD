#!/usr/bin/env python3
"""
AViD Phase 3 — M2 3-way W0 verification for tabular probe targets.

Reads a TSV containing claim_id, unit_id/target_id, and unit_text.  When the TSV
provides visual_question and audio_question, the corresponding natural question
is sent to the model and included in the cache identity.  Otherwise the legacy
unit-text question is used.  Each target receives one pass-1 answer (yes / no /
can't tell); no pass-2 subtype is needed.

Outputs (one per modality, resumable):
  exp/phase3/nodes/verify_visual_star.jsonl
  exp/phase3/nodes/verify_audio_star.jsonl

Each row: {claim_id, unit_id, unit_text, pass1_verdict, pass1_dist, no_video,
            wording, prompt_version}

pass1_dist keys: {yes, no, cant_tell}
  yes       = supported (→ SUP in CRF)
  no        = refuted   (→ REF, veto)
  cant_tell = NEI/abstain

Cache: exp/phase3/nodes/m2_cache_{modality}.jsonl  (per-unit, resumable)
Cache key: target text plus the formulated modality question when provided.

Usage (vllm-omni env, GPU node):
    # Visual — A100-40gb
    python scripts/run_m2_probe.py --modality visual --tp 1 --batch-size 16

    # Audio — A100-80gb
    python scripts/run_m2_probe.py --modality audio  --tp 1 --batch-size 8
"""

import argparse
import csv
import hashlib
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("VLLM_USE_V1", "0")

_AVID = Path("/exp/cxiao/scale26/avid")
TREES_TSV   = str(_AVID / "exp/phase3/nodes/tree_units_ud.tsv")
MANIFEST    = "/exp/cxiao/scale26/probing/exp/step1/manifests/manifest.jsonl"
MEDIA_DIR   = str(_AVID / "exp/phase2/media_cache_1fps")
OUT_VIS     = str(_AVID / "exp/phase3/nodes/verify_visual_star.jsonl")
OUT_AUD     = str(_AVID / "exp/phase3/nodes/verify_audio_star.jsonl")
CACHE_VIS   = str(_AVID / "exp/phase3/nodes/m2_cache_visual.jsonl")
CACHE_AUD   = str(_AVID / "exp/phase3/nodes/m2_cache_audio.jsonl")

VL_MODEL    = "/home/hltcoe/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct"
OMNI_MODEL  = "/home/hltcoe/cxiao/calm/downloads/models/qwen3-omni/30B-A3B-Instruct"

sys.path.insert(0, str(Path(__file__).parent))
import verify_support as V
from prompts_phase2 import (
    pass1_user, get_p1_system, get_3way_opts,
    VERDICTS_3WAY, VRD_LTRS_3WAY, PROMPT_VERSION,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

WORDING = "w0"
M2_PROMPT_VERSION = f"{PROMPT_VERSION}-m2-{WORDING}"   # scopes cache; bump on prompt change


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def cache_key(
    claim_id: str, unit_id: str, unit_text: str, formulated_question: str = "",
) -> str:
    """Target/question-scoped key so edited probes cannot reuse stale answers.

    The empty-question branch preserves the original M2 cache keys.  Semantic
    factor-tree runs provide a natural question and therefore receive a new,
    question-specific cache namespace even when a target id happens to match an
    older dependency-tree node.
    """
    text_hash = hashlib.sha1(
        unit_text.encode("utf-8")).hexdigest()[:16]
    key = (
        f"{claim_id}|{unit_id}|{M2_PROMPT_VERSION}|"
        f"text={text_hash}|pass1"
    )
    if formulated_question:
        question_hash = hashlib.sha1(
            formulated_question.encode("utf-8")).hexdigest()[:16]
        key += f"|question={question_hash}"
    return key


def load_cache(path: str) -> dict[str, dict]:
    cache: dict[str, dict] = {}
    p = Path(path)
    if not p.exists():
        return cache
    with open(p, encoding="utf-8") as f:
        for line in f:
            try:
                rec = json.loads(line)
                k = rec.get("_cache_key", "")
                if k:
                    cache[k] = rec
            except json.JSONDecodeError:
                pass
    return cache


def simple_question(modality: str, unit_text: str) -> str:
    """Targeted yes/no question for the unit in the given modality.

    For tree units the unit_text is already contextual (e.g. "by hand",
    "into the shore", "of the typhoon") so a direct question is informative.
    """
    if modality == "visual":
        return f'Is "{unit_text}" visible in the video clip?'
    return f'Is "{unit_text}" audible in the clip, or mentioned in speech?'


def load_units(tsv_path: str) -> list[dict]:
    units: list[dict] = []
    with open(tsv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or row.get("target_id") or "").strip()
            if not cid or not uid:
                continue
            units.append({
                "claim_id":   cid,
                "unit_id":    uid,
                "unit_type":  (row.get("unit_type") or "").strip(),
                "node_type":  (row.get("node_type") or "").strip(),
                "unit_text":  (row.get("unit_text") or "").strip(),
                "claim_text": (row.get("claim_text") or "").strip(),
                "visual_question": (row.get("visual_question") or "").strip(),
                "audio_question": (row.get("audio_question") or "").strip(),
            })
    return units


def formulated_question(modality: str, unit: dict) -> str:
    """Use the semantic target's natural question, with a legacy fallback."""
    question = unit.get(f"{modality}_question", "").strip()
    return question or simple_question(modality, unit["unit_text"])


# ---------------------------------------------------------------------------
# Inference
# ---------------------------------------------------------------------------

def _media_cid(claim_id: str) -> str:
    """Strip perturbed-claim suffixes (__bind/__rem/__neg) for media lookup."""
    for sfx in ("__bind", "__rem", "__neg"):
        if claim_id.endswith(sfx):
            return claim_id[: -len(sfx)]
    return claim_id


def run_probe(
    modality: str,
    units: list[dict],
    llm,
    tokenizer,
    sampling_params,
    cache: dict,
    cache_path: str,
    media_dir: Path,
    manifest_path: str,
    args,
) -> None:
    """Run 3-way pass-1 for all uncached units; append to cache file."""
    system = get_p1_system(modality, wording=WORDING)
    verdicts, letters = VERDICTS_3WAY, VRD_LTRS_3WAY

    # Build pending requests
    pending = []
    for u in units:
        q = formulated_question(modality, u)
        cache_question = u.get(f"{modality}_question", "").strip()
        ck = cache_key(
            u["claim_id"], u["unit_id"], u["unit_text"], cache_question,
        )
        if ck in cache:
            continue
        user_text = pass1_user(
            modality, "r5e",
            unit_text=u["unit_text"],
            marked_context=u["unit_text"],
            formulated=q,
            three_way=True,
            wording=WORDING,
        )
        pending.append({**u, "question": q, "user_text": user_text, "_ck": ck})

    n_cached = len(units) - len(pending)
    print(f"  Pending: {len(pending)} | Cached: {n_cached}", flush=True)
    if not pending:
        return

    bs = args.batch_size
    n_batches = (len(pending) + bs - 1) // bs
    frames_root = media_dir / "frames"
    wav_root    = media_dir / "wav"

    Path(cache_path).parent.mkdir(parents=True, exist_ok=True)
    with open(cache_path, "a", encoding="utf-8") as cf:
        for b_idx in range(n_batches):
            batch = pending[b_idx * bs : (b_idx + 1) * bs]
            prompts_mm = []

            for req in batch:
                cid = req["claim_id"]
                if modality == "visual":
                    chunks = V._get_chunks_for_claim(_media_cid(cid), manifest_path)
                    frames = []
                    for chunk_id in chunks:
                        fd = frames_root / chunk_id
                        frames.extend(V._load_frames_safe(
                            fd, args.n_frames // max(1, len(chunks)),
                            frame_size=args.frame_size))
                    frames = frames[: args.n_frames]
                    if not frames:
                        from PIL import Image
                        import numpy as np
                        frames = [Image.fromarray(
                            np.zeros((64, 64, 3), dtype=np.uint8))]
                    prompt = V._build_vl_prompt(
                        tokenizer, system, req["user_text"], len(frames))
                    prompts_mm.append({"prompt": prompt,
                                       "multi_modal_data": {"image": frames}})
                else:
                    chunks = V._get_chunks_for_claim(_media_cid(cid), manifest_path)
                    wav_data = None
                    for chunk_id in chunks:
                        wp = wav_root / f"{chunk_id}.wav"
                        if wp.exists():
                            wav_data = V._load_wav_safe(wp)
                            break
                    if wav_data is None:
                        import numpy as np
                        wav_data = (np.zeros(16000, dtype=np.float32), 16000)
                    prompt = V._build_omni_prompt(
                        tokenizer, system, req["user_text"])
                    prompts_mm.append({"prompt": prompt,
                                       "multi_modal_data": {"audio": [wav_data]}})

            print(f"  [pass1] Batch {b_idx + 1}/{n_batches}: {len(batch)} …",
                  flush=True)
            outputs = llm.generate(prompts_mm, sampling_params=sampling_params)

            for req, out in zip(batch, outputs):
                try:
                    lp_dict = V._verdict_logprobs(out, letters, tokenizer)
                    dist = V.extract_option_distribution(
                        lp_dict, tokenizer, verdicts, letters)
                except Exception as e:
                    print(f"  WARNING logprob {req['claim_id']}|{req['unit_id']}: {e}",
                          file=sys.stderr)
                    dist = {v: 1.0 / len(verdicts) for v in verdicts}

                verdict = V.argmax_dist(dist)
                entry = {
                    "_cache_key":    req["_ck"],
                    "claim_id":      req["claim_id"],
                    "unit_id":       req["unit_id"],
                    "unit_text":     req["unit_text"],
                    "question":      req["question"],
                    "pass1_verdict": verdict,
                    "pass1_dist":    dist,
                    "no_video":      not bool(V._get_chunks_for_claim(
                                         _media_cid(req["claim_id"]), manifest_path)),
                    "wording":       WORDING,
                    "prompt_version": M2_PROMPT_VERSION,
                }
                cf.write(json.dumps(entry, ensure_ascii=False) + "\n")
                cache[req["_ck"]] = entry
            cf.flush()


def write_output(modality: str, units: list[dict], cache: dict, out_path: str) -> int:
    """Write final output JSONL from cache entries for all units."""
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    n_written = 0
    with open(out_path, "w", encoding="utf-8") as f:
        for u in units:
            q = formulated_question(modality, u)
            cache_question = u.get(f"{modality}_question", "").strip()
            ck = cache_key(
                u["claim_id"], u["unit_id"], u["unit_text"], cache_question,
            )
            entry = cache.get(ck)
            if entry is None:
                continue
            # Write clean output row (drop internal cache key)
            row = {k: v for k, v in entry.items() if not k.startswith("_")}
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            n_written += 1
    return n_written


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--modality",    required=True, choices=["visual", "audio"])
    ap.add_argument("--tsv",         default=TREES_TSV,   help="T* v1 probe TSV")
    ap.add_argument("--manifest",    default=MANIFEST)
    ap.add_argument("--media-dir",   default=MEDIA_DIR)
    ap.add_argument("--output",      default="",
                    help="Output JSONL path (default: exp/phase3/nodes/verify_{modality}_star.jsonl)")
    ap.add_argument("--cache",       default="",
                    help="Cache JSONL path (default: exp/phase3/nodes/m2_cache_{modality}.jsonl)")
    ap.add_argument("--vl-model",    default=VL_MODEL)
    ap.add_argument("--omni-model",  default=OMNI_MODEL)
    ap.add_argument("--tp",          type=int, default=0)
    ap.add_argument("--batch-size",  type=int, default=16)
    ap.add_argument("--logprob-n",   type=int, default=20)
    ap.add_argument("--n-frames",    type=int, default=250)
    ap.add_argument("--frame-size",  default="672x378")
    ap.add_argument("--limit",       type=int, default=0,
                    help="Process only the first N units (smoke test).")
    args = ap.parse_args()

    modality = args.modality
    out_path   = args.output or (OUT_VIS if modality == "visual" else OUT_AUD)
    cache_path = args.cache  or (CACHE_VIS if modality == "visual" else CACHE_AUD)

    # Parse frame size
    try:
        fw, fh = args.frame_size.lower().split("x")
        args.frame_size = (int(fw), int(fh))
    except ValueError:
        args.frame_size = None

    print("=" * 60)
    print(f"AViD M2 re-probe  (modality={modality}, wording={WORDING})")
    print(f"  TSV:       {args.tsv}")
    print(f"  Output:    {out_path}")
    print(f"  Cache:     {cache_path}")
    print(f"  Prompt:    {M2_PROMPT_VERSION}")
    print("=" * 60)

    # Load units
    print("\n[1] Loading tree units …")
    units = load_units(args.tsv)
    if args.limit > 0:
        units = units[: args.limit]
    print(f"  {len(units)} units loaded from {args.tsv}")

    # Load cache
    cache = load_cache(cache_path)
    print(f"  Cache entries: {len(cache)}")

    # Load model
    print("\n[2] Loading model …")
    import torch
    from vllm import LLM, SamplingParams

    tp = args.tp if args.tp > 0 else torch.cuda.device_count()
    if tp == 0:
        print("ERROR: No GPUs found.", file=sys.stderr)
        sys.exit(1)

    if modality == "visual":
        from transformers import AutoTokenizer
        model_path = args.vl_model
        tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        llm = LLM(
            model=model_path, trust_remote_code=True,
            gpu_memory_utilization=0.90, tensor_parallel_size=tp,
            dtype="bfloat16", seed=42, max_model_len=65536,
            limit_mm_per_prompt={"image": args.n_frames},
        )
    else:
        from transformers import AutoProcessor
        model_path = args.omni_model
        tokenizer = AutoProcessor.from_pretrained(model_path, trust_remote_code=True)
        llm = LLM(
            model=model_path, trust_remote_code=True,
            gpu_memory_utilization=0.90, tensor_parallel_size=tp,
            dtype="bfloat16", seed=42, max_model_len=4096,
            limit_mm_per_prompt={"audio": 1},
        )
    print(f"  Model loaded: {model_path}")

    # Sampling params: 1 token (logprobs only; no generation needed for pass-1)
    sp = SamplingParams(temperature=0.0, max_tokens=1, logprobs=args.logprob_n)

    # Run probe
    print("\n[3] Running 3-way W0 pass-1 …")
    run_probe(
        modality=modality,
        units=units,
        llm=llm,
        tokenizer=tokenizer,
        sampling_params=sp,
        cache=cache,
        cache_path=cache_path,
        media_dir=Path(args.media_dir),
        manifest_path=args.manifest,
        args=args,
    )

    # Write output
    print("\n[4] Writing output …")
    n_written = write_output(modality, units, cache, out_path)
    print(f"  {n_written} rows → {out_path}")

    # Summary stats
    verdict_counts: dict[str, int] = {}
    for u in units:
        q = formulated_question(modality, u)
        cache_question = u.get(f"{modality}_question", "").strip()
        ck = cache_key(
            u["claim_id"], u["unit_id"], u["unit_text"], cache_question,
        )
        e = cache.get(ck)
        if e:
            v = e.get("pass1_verdict", "?")
            verdict_counts[v] = verdict_counts.get(v, 0) + 1

    total = sum(verdict_counts.values())
    print("\nPass-1 verdict distribution:")
    for v, cnt in sorted(verdict_counts.items(), key=lambda x: -x[1]):
        print(f"  {v:12s}: {cnt:5d} ({100*cnt/max(1,total):.1f}%)")


if __name__ == "__main__":
    main()
