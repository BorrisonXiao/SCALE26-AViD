#!/usr/bin/env python3
"""
AViD Phase 1 Parsing Ablation — Compare dep vs constituency annotation surfaces.

Generates parsing_ablation.md with 7 metrics:
  1. Unit counts per surface by type
  2. Entity span agreement (exact-match %, mismatch taxonomy)
  3. Token-set (character-span) Jaccard on matched entity pairs
  4. PP-attachment analysis (where dep splits, const merges)
  5. Function-word residue on each surface
  6. Token coverage on each surface
  7. Qualitative side-by-side (trigger case + sampled claims)

Operates on in-memory row dicts: imports make_annotation_units and
make_annotation_units_constituency and calls them directly. Does NOT
re-read the TSVs (the original annotation.tsv has unquoted multi-line
claim_text fields that break naive CSV parsing).

Reads  : exp/phase1/hypergraph.jsonl
         exp/phase1/parsing_ablation/constituency.jsonl
Writes : exp/phase1/reports/parsing_ablation.md

Flags:
  --verb-units     run const surface with --verb-units (default: off)
  --maximal-np     run const surface with --maximal-np (default: off)
  --sample-n N     qualitative examples (default 13; trigger always included)
  --seed N         (default 42)
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from annotation_units import make_annotation_units                          # noqa: E402
from annotation_units_constituency import make_annotation_units_constituency  # noqa: E402

# ── Defaults ──────────────────────────────────────────────────────────────────

_ROOT = Path(__file__).parent.parent / "exp" / "phase1"
_ABL  = _ROOT / "parsing_ablation"
_REP  = _ROOT / "reports"

DEFAULT_HG      = str(_ROOT / "hypergraph.jsonl")
DEFAULT_CONST   = str(_ABL  / "constituency.jsonl")
DEFAULT_OUT     = str(_REP  / "parsing_ablation.md")

TRIGGER_CLAIM = "TInVWzp25aIM_15"

# Prepositions for PP-attachment classification
_OF_PREPS      = frozenset({"of"})
_SPATIAL_PREPS = frozenset({"in", "at", "on", "near", "beside", "behind",
                             "above", "below", "under", "over", "by", "around",
                             "between", "among", "inside", "outside", "into",
                             "onto", "upon", "across", "along", "through"})
_TEMPORAL_PREPS = frozenset({"before", "after", "during", "while", "until",
                              "since", "when", "as", "once", "prior", "following",
                              "within"})


# ── CLI ───────────────────────────────────────────────────────────────────────

def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Compare dep vs const annotation surfaces → parsing_ablation.md"
    )
    p.add_argument("--hypergraph",   default=DEFAULT_HG)
    p.add_argument("--constituency", default=DEFAULT_CONST)
    p.add_argument("--out",          default=DEFAULT_OUT)
    p.add_argument("--verb-units",   action="store_true")
    p.add_argument("--maximal-np",   action="store_true")
    p.add_argument("--sample-n",     type=int, default=13)
    p.add_argument("--seed",         type=int, default=42)
    return p


# ── Span utilities ────────────────────────────────────────────────────────────

def _overlap(s1: int, e1: int, s2: int, e2: int) -> int:
    return max(0, min(e1, e2) - max(s1, s2))


def _jaccard(s1: int, e1: int, s2: int, e2: int) -> float:
    inter = _overlap(s1, e1, s2, e2)
    if inter == 0:
        return 0.0
    union = max(e1, e2) - min(s1, s2)
    return inter / union if union > 0 else 0.0


def _span_from_row(claim_text: str, row: dict) -> tuple[int, int] | None:
    """Extract (start_char, end_char) from a row dict.

    Prefers claim_highlighted (reliable for duplicate unit_text in a claim)
    over claim_text.find(unit_text).
    """
    hl = row.get("claim_highlighted", "")
    s_marker = hl.find("**")
    if s_marker >= 0:
        e_marker = hl.find("**", s_marker + 2)
        if e_marker >= 0:
            s = s_marker
            e = e_marker - 2
            if 0 <= s < e <= len(claim_text):
                return s, e
    # Fallback: first occurrence of unit_text in claim_text
    ut = row.get("unit_text", "").strip()
    if ut:
        idx = claim_text.find(ut)
        if idx >= 0:
            return idx, idx + len(ut)
    return None


def _mismatch_type(s_dep: int, e_dep: int, s_c: int, e_c: int) -> str:
    """Classify span mismatch between a dep and const entity."""
    if s_dep == s_c and e_dep == e_c:
        return "exact"
    if s_c <= s_dep and e_c >= e_dep and (s_c < s_dep or e_c > e_dep):
        return "const_wider"
    if s_dep <= s_c and e_dep >= e_c and (s_dep < s_c or e_dep > e_c):
        return "const_narrower"
    return "crossing"


def _best_const_match(
    s_dep: int, e_dep: int,
    const_entities: list[tuple[int, int, str]],
) -> tuple[int, int, str] | None:
    """Find const entity with highest overlap with the dep entity."""
    best: tuple[int, int, str] | None = None
    best_ovl = 0
    for (s_c, e_c, txt_c) in const_entities:
        ovl = _overlap(s_dep, e_dep, s_c, e_c)
        if ovl > best_ovl:
            best_ovl = ovl
            best = (s_c, e_c, txt_c)
    return best


# ── PP-attachment analysis ─────────────────────────────────────────────────────

def _classify_prep(claim_text: str, gap_s: int, gap_e: int) -> str:
    """Classify the preposition(s) found in claim_text[gap_s:gap_e]."""
    gap = claim_text[gap_s:gap_e].lower()
    words = set(gap.split())
    if words & _OF_PREPS:
        return "of-complement"
    if words & _TEMPORAL_PREPS:
        return "temporal"
    if words & _SPATIAL_PREPS:
        return "spatial"
    return "other"


def _find_pp_cases(
    claim_id: str,
    claim_text: str,
    dep_entities: list[tuple[int, int, str]],
    const_entities: list[tuple[int, int, str]],
) -> list[dict]:
    """Find cases where dep has two separate entities that const merges into one.

    Returns list of case dicts with claim_id, dep spans, const span, gap text,
    preposition classification.
    """
    cases: list[dict] = []
    dep_sorted = sorted(dep_entities, key=lambda x: x[0])

    for i, (s1, e1, t1) in enumerate(dep_sorted):
        for (s2, e2, t2) in dep_sorted[i + 1:]:
            if s2 < e1:
                continue  # overlapping dep entities (rare); skip
            # Look for a const entity that contains both
            for (sc, ec, tc) in const_entities:
                if sc <= s1 and ec >= e2:
                    # Const merges dep entities 1 and 2
                    gap_text = claim_text[e1:s2]
                    prep_class = _classify_prep(claim_text, e1, s2)
                    cases.append({
                        "claim_id":   claim_id,
                        "claim_text": claim_text,
                        "dep_1":      claim_text[s1:e1],
                        "dep_2":      claim_text[s2:e2],
                        "const_span": tc,
                        "gap_text":   gap_text.strip(),
                        "prep_class": prep_class,
                    })
                    break  # one const span per dep pair
    return cases


# ── Token coverage ────────────────────────────────────────────────────────────

def _coverage(claim_text: str, rows: list[dict]) -> float:
    """Fraction of non-whitespace claim characters covered by at least one unit."""
    text_len = len(claim_text.replace(" ", ""))
    if text_len == 0:
        return 0.0
    covered = bytearray(len(claim_text))
    for r in rows:
        span = _span_from_row(claim_text, r)
        if span is not None:
            s, e = span
            for k in range(s, e):
                covered[k] = 1
    covered_nonws = sum(
        1 for i in range(len(claim_text))
        if covered[i] and claim_text[i] != " "
    )
    return covered_nonws / text_len


# ── Report builder ─────────────────────────────────────────────────────────────

def _build_report(
    claims:         list[dict],
    dep_map:        dict[str, list[dict]],
    const_map:      dict[str, list[dict]],
    dep_stats_agg:  dict[str, int],
    const_stats_agg: dict[str, int],
    entity_results: list[dict],    # per dep-entity match results
    pp_cases:       list[dict],
    coverage_dep:   list[float],
    coverage_const: list[float],
    sample_ids:     list[str],
    sample_n:       int,
    verb_units:     bool,
    maximal_np:     bool,
) -> str:
    lines: list[str] = []

    # ── Header ────────────────────────────────────────────────────────────────
    flags = []
    if verb_units:
        flags.append("`--verb-units`")
    if maximal_np:
        flags.append("`--maximal-np`")
    flag_str = " ".join(flags) if flags else "default"
    n_claims = len(claims)

    lines.append("# AViD Phase 1 — Parsing Ablation: Dep vs Constituency Surfaces\n")
    lines.append(
        f"Claims: **{n_claims}** | Const flags: {flag_str}  \n"
        "Baseline: `annotation_units.tsv` (dependency surface)  \n"
        "Ablation: `annotation_units_constituency.tsv` (benepar, NP + S brackets)  \n"
        "Parser: benepar `benepar_en3` (en_core_web_sm backbone)\n"
    )

    # ── Metric 1: Counts per surface ─────────────────────────────────────────
    def _count_by_type(rows_map: dict[str, list[dict]]) -> Counter:
        c: Counter = Counter()
        for rows in rows_map.values():
            for r in rows:
                c[f"{r['unit_type']}/{r['node_type']}"] += 1
        return c

    dep_counts   = _count_by_type(dep_map)
    const_counts = _count_by_type(const_map)
    all_types    = sorted(set(dep_counts) | set(const_counts))

    lines.append("\n## 1. Unit Counts per Surface\n")
    lines.append("| unit_type/node_type | Dep | Const |")
    lines.append("|---|---|---|")
    for t in all_types:
        lines.append(f"| `{t}` | {dep_counts[t]} | {const_counts[t]} |")
    dep_total   = sum(dep_counts.values())
    const_total = sum(const_counts.values())
    lines.append(f"| **Total** | **{dep_total}** | **{const_total}** |")

    # ── Metric 2: Entity span agreement ───────────────────────────────────────
    lines.append("\n## 2. Entity Span Agreement\n")

    n_dep_entities  = len(entity_results)
    mismatch_counts: Counter = Counter(r["mismatch"] for r in entity_results)
    n_exact         = mismatch_counts["exact"]
    n_no_match      = mismatch_counts["no_match"]
    n_mismatched    = n_dep_entities - n_exact - n_no_match
    exact_pct       = 100 * n_exact / max(1, n_dep_entities)

    lines.append(
        f"For each dep `phrase_entity` unit, the const entity with highest "
        f"character-span overlap is found and classified.\n"
    )
    lines.append("| Metric | Count | % |")
    lines.append("|---|---|---|")
    lines.append(f"| Dep phrase_entity units | {n_dep_entities} | — |")
    lines.append(f"| **Exact span match** | **{n_exact}** | **{exact_pct:.1f}%** |")
    lines.append(f"| Const wider (adj-PP swallowed) | {mismatch_counts['const_wider']} | {100*mismatch_counts['const_wider']/max(1,n_dep_entities):.1f}% |")
    lines.append(f"| Const narrower | {mismatch_counts['const_narrower']} | {100*mismatch_counts['const_narrower']/max(1,n_dep_entities):.1f}% |")
    lines.append(f"| Crossing | {mismatch_counts['crossing']} | {100*mismatch_counts['crossing']/max(1,n_dep_entities):.1f}% |")
    lines.append(f"| No const match (overlap = 0) | {n_no_match} | {100*n_no_match/max(1,n_dep_entities):.1f}% |")

    n_matchable = n_dep_entities - n_no_match
    exact_among_matchable = 100 * n_exact / max(1, n_matchable)
    lines.append(
        f"\n**Note on no-match cases:** These {n_no_match} dep phrase_entity units have zero overlap "
        "with any const NP. They include dep-specific units: relativizer *what* (PRON→entity in dep, "
        "no standalone NP bracket in benepar), UUID-like tokens, and compound nouns parsed differently "
        "by stanza vs spaCy. These would not improve by switching parsers.  \n"
        f"Among the {n_matchable} dep entities that do find a const match: "
        f"exact-span agreement = **{exact_among_matchable:.1f}%**."
    )

    # ── Metric 3: Jaccard ─────────────────────────────────────────────────────
    lines.append("\n## 3. Character-Span Jaccard (Matched Entity Pairs)\n")

    matched = [r for r in entity_results if r["mismatch"] != "no_match"]
    if matched:
        jaccards = [r["jaccard"] for r in matched]
        avg_j    = sum(jaccards) / len(jaccards)
        exact_j  = sum(1 for j in jaccards if j >= 0.999)
        high_j   = sum(1 for j in jaccards if j >= 0.8)
        low_j    = sum(1 for j in jaccards if j < 0.5)
        lines.append(f"Over **{len(matched)}** matched dep-const entity pairs:\n")
        lines.append("| Jaccard band | Count | % |")
        lines.append("|---|---|---|")
        lines.append(f"| 1.0 (exact span) | {exact_j} | {100*exact_j/max(1,len(matched)):.1f}% |")
        lines.append(f"| ≥ 0.8 | {high_j} | {100*high_j/max(1,len(matched)):.1f}% |")
        lines.append(f"| < 0.5 | {low_j} | {100*low_j/max(1,len(matched)):.1f}% |")
        lines.append(f"| Mean | {avg_j:.3f} | — |")
    else:
        lines.append("No matched pairs found.\n")

    # ── Metric 4: PP-attachment ───────────────────────────────────────────────
    lines.append("\n## 4. PP-Attachment Analysis (Dep Splits vs Const Merges)\n")
    lines.append(
        "Cases where dep emits two separate entity units that const merges into one.  \n"
        "The text between the dep spans reveals the intervening preposition.\n"
    )

    pp_by_class: dict[str, list[dict]] = defaultdict(list)
    for case in pp_cases:
        pp_by_class[case["prep_class"]].append(case)

    lines.append(f"\n**Total merge cases: {len(pp_cases)}**\n")
    lines.append("| Prep class | Count |")
    lines.append("|---|---|")
    for cls in ["of-complement", "spatial", "temporal", "other"]:
        lines.append(f"| {cls} | {len(pp_by_class[cls])} |")

    lines.append("\n### Selected merge cases\n")
    shown = 0
    for cls in ["of-complement", "spatial", "temporal", "other"]:
        cases = pp_by_class[cls][:3]
        if not cases:
            continue
        lines.append(f"\n**{cls}** (showing ≤ 3):\n")
        for case in cases:
            lines.append(
                f"- `{case['claim_id']}` — {case['claim_text']!r}  \n"
                f"  Dep: {case['dep_1']!r} + {case['dep_2']!r}  \n"
                f"  Const: {case['const_span']!r}  \n"
                f"  Gap: {case['gap_text']!r}"
            )
            shown += 1

    if not pp_cases:
        lines.append("_(No PP-merge cases found.)_\n")

    # ── Metric 5: Function-word residue ───────────────────────────────────────
    lines.append("\n## 5. Function-Word Residue (Tests H3)\n")
    lines.append(
        "H3: most function-word handling (expletives, copular *be*, bare pronouns) "
        "is **intrinsic to the task**, not a dependency-parse artifact — so the "
        "categorematic filter is not removable by switching parsers.\n"
    )
    lines.append("| Source | Dep surface | Const surface |")
    lines.append("|---|---|---|")
    lines.append(
        f"| Existential *there* dropped | "
        f"{dep_stats_agg.get('dropped_expletives', 0)} | "
        f"{const_stats_agg.get('np_dropped_ex', 0)} |"
    )
    lines.append(
        f"| Copular *be* demoted/excluded | "
        f"{dep_stats_agg.get('demoted_copula', 0)} | "
        f"{'N/A (not tracked without --verb-units)' if not verb_units else const_stats_agg.get('verb_units', 0)} |"
    )
    lines.append(
        f"| Bare-pronoun NPs flagged | "
        f"{'N/A' if not dep_stats_agg.get('dropped_expletives') else '—'} | "
        f"{const_stats_agg.get('np_pronoun', 0)} |"
    )

    # ── Metric 6: Token coverage ───────────────────────────────────────────────
    lines.append("\n## 6. Token Coverage\n")
    lines.append(
        "Fraction of non-whitespace claim characters covered by at least one exported unit.\n"
    )
    if coverage_dep and coverage_const:
        avg_dep   = sum(coverage_dep) / len(coverage_dep)
        avg_const = sum(coverage_const) / len(coverage_const)
        full_dep   = sum(1 for c in coverage_dep   if c >= 0.999)
        full_const = sum(1 for c in coverage_const if c >= 0.999)
        lines.append("| Metric | Dep | Const |")
        lines.append("|---|---|---|")
        lines.append(f"| Mean coverage | {avg_dep:.3f} | {avg_const:.3f} |")
        lines.append(f"| Claims with 100% coverage | {full_dep} | {full_const} |")
    else:
        lines.append("_(No coverage data.)_\n")

    # ── Metric 7: Qualitative side-by-side ────────────────────────────────────
    lines.append("\n## 7. Qualitative Side-by-Side\n")
    lines.append(
        f"Showing {min(sample_n, len(sample_ids))} claims.  "
        f"Trigger case `{TRIGGER_CLAIM}` always first.\n"
    )

    for cid in sample_ids[:sample_n]:
        dep_rows   = dep_map.get(cid, [])
        const_rows = const_map.get(cid, [])
        if dep_rows:
            ct = dep_rows[0].get("claim_text", cid)
        elif const_rows:
            ct = const_rows[0].get("claim_text", cid)
        else:
            ct = cid

        lines.append(f"\n### `{cid}` — {ct}\n")
        lines.append(f"**Dep** ({len(dep_rows)} units):\n")
        for r in dep_rows:
            lines.append(f"- `{r['unit_type']}/{r['node_type']}` {r['unit_text']!r}")
        lines.append(f"\n**Const** ({len(const_rows)} units):\n")
        for r in const_rows:
            tag = f"  ← `{r['notes']}`" if r.get("notes") else ""
            lines.append(f"- `{r['unit_type']}/{r['node_type']}` {r['unit_text']!r}{tag}")

    # ── Decision guidance ──────────────────────────────────────────────────────
    n_matchable_for_guidance = n_dep_entities - n_no_match
    exact_among_match = 100 * n_exact / max(1, n_matchable_for_guidance)

    lines.append("\n## Decision Guidance\n")
    lines.append(
        f"Entity exact-match (all dep units): **{exact_pct:.1f}%**  \n"
        f"Entity exact-match (matchable only, excluding no-const-NP units): **{exact_among_match:.1f}%**  \n"
        f"Const-wider mismatches: **{mismatch_counts['const_wider']}**  (adj-PP merges = H2 evidence)  \n"
        f"PP-merge cases total: **{len(pp_cases)}**  \n\n"
    )
    lines.append(
        "**Interpretation of no-match cases:** ~7–8% of dep phrase_entity units have no const NP "
        "overlap. These are dep-surface-specific units (relativizers, UUIDs, differently-split "
        "compound nouns) and would remain no-match with any constituency parser. They should not "
        "lower the headline exact-match figure for the H1/H2 evaluation.  \n\n"
    )
    # Direction of mismatches: what fraction of non-exact matched cases are const_wider?
    n_nonexact_matched = n_matchable_for_guidance - n_exact
    const_wider_pct = 100 * mismatch_counts['const_wider'] / max(1, n_nonexact_matched)

    if exact_among_match >= 95:
        lines.append(
            "> **≥ 95% exact-match (among matchable)** → dependency-only default confirmed.  \n"
            "> Constituency is a confirming ablation; const-wider mismatches confirm H2 "
            "(PP-adjunct splits are task-useful).\n"
        )
    elif exact_among_match >= 85:
        lines.append(
            "> **85–95% exact-match (among matchable)** → consider Operation B "
            "(bracket × head reconciliation).  \n"
            "> Some genuine dep boundary errors; examine const-wider cases for PP-complement splits.\n"
        )
    else:
        lines.append(
            "> **< 85% exact-match (among matchable)** — but note direction of disagreement:  \n"
            f"> {const_wider_pct:.0f}% of non-exact mismatches are **const_wider** "
            "(const merges more aggressively than dep). This is not evidence that const is "
            "*better* — it is evidence that dep makes finer-grained, task-useful distinctions "
            "(PP-attachment splits, of-complement vs adjunct). Constituency may not merit "
            "equal footing despite the low exact-match number; the disagreements are asymmetric "
            "in dep's favor. See the PP-attachment table (Metric 4) for evidence.\n"
        )

    return "\n".join(lines) + "\n"


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    args = _parser().parse_args()
    random.seed(args.seed)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("AViD Phase 1 — compare_unit_surfaces.py")
    print("=" * 60)

    # 1. Load hypergraph records
    print(f"\n[1] Loading hypergraph: {args.hypergraph}")
    hg_records: list[dict] = []
    with open(args.hypergraph, encoding="utf-8") as f:
        for line in f:
            hg_records.append(json.loads(line))
    print(f"    Records: {len(hg_records)}")

    # 2. Load constituency records
    print(f"\n[2] Loading constituency: {args.constituency}")
    const_records: list[dict] = []
    with open(args.constituency, encoding="utf-8") as f:
        for line in f:
            const_records.append(json.loads(line))
    print(f"    Records: {len(const_records)}")
    const_by_id = {r["claim_id"]: r for r in const_records}

    # 3. Generate both surfaces in-memory
    print(f"\n[3] Generating dep + const surfaces in-memory ...")
    dep_map:    dict[str, list[dict]] = {}
    const_map:  dict[str, list[dict]] = {}
    dep_agg:    Counter = Counter()
    const_agg:  Counter = Counter()

    for rec in hg_records:
        cid = rec["claim_id"]
        dep_rows, dep_stats = make_annotation_units(rec)
        dep_map[cid] = dep_rows
        for k, v in dep_stats.items():
            dep_agg[k] += v

        crec = const_by_id.get(cid)
        if crec is not None:
            const_rows, const_stats = make_annotation_units_constituency(
                crec,
                verb_units=args.verb_units,
                maximal_np=args.maximal_np,
            )
            const_map[cid] = const_rows
            for k, v in const_stats.items():
                const_agg[k] += v

    print(f"    Dep rows   : {sum(len(v) for v in dep_map.values())}")
    print(f"    Const rows : {sum(len(v) for v in const_map.values())}")

    # 4. Entity span agreement + Jaccard
    print(f"\n[4] Computing entity span agreement ...")
    entity_results: list[dict] = []
    pp_cases:       list[dict] = []
    coverage_dep:   list[float] = []
    coverage_const: list[float] = []

    for rec in hg_records:
        cid        = rec["claim_id"]
        claim_text = rec["claim_text"]
        dep_rows   = dep_map.get(cid, [])
        const_rows = const_map.get(cid, [])

        # Extract entity spans for each surface
        dep_entities: list[tuple[int, int, str]] = []
        for r in dep_rows:
            if r["unit_type"] == "phrase_entity" and r["node_type"] == "entity":
                span = _span_from_row(claim_text, r)
                if span is not None:
                    s, e = span
                    dep_entities.append((s, e, claim_text[s:e]))

        const_entities: list[tuple[int, int, str]] = []
        for r in const_rows:
            if r["unit_type"] == "phrase_entity" and r["node_type"] == "entity":
                span = _span_from_row(claim_text, r)
                if span is not None:
                    s, e = span
                    const_entities.append((s, e, claim_text[s:e]))

        # Per dep-entity: find best const match
        for (s_dep, e_dep, t_dep) in dep_entities:
            best = _best_const_match(s_dep, e_dep, const_entities)
            if best is None:
                entity_results.append({
                    "claim_id": cid,
                    "dep_text": t_dep,
                    "mismatch": "no_match",
                    "jaccard":  0.0,
                })
            else:
                s_c, e_c, t_c = best
                entity_results.append({
                    "claim_id":   cid,
                    "dep_text":   t_dep,
                    "const_text": t_c,
                    "mismatch":   _mismatch_type(s_dep, e_dep, s_c, e_c),
                    "jaccard":    _jaccard(s_dep, e_dep, s_c, e_c),
                })

        # PP-attachment cases
        pp_cases.extend(_find_pp_cases(cid, claim_text, dep_entities, const_entities))

        # Coverage
        coverage_dep.append(_coverage(claim_text, dep_rows))
        coverage_const.append(_coverage(claim_text, const_rows))

    # 5. Build and write report
    print(f"\n[5] Building report ...")

    all_ids     = [r["claim_id"] for r in hg_records]
    sample_pool = [cid for cid in all_ids if cid != TRIGGER_CLAIM]
    random.shuffle(sample_pool)
    sample_ids  = [TRIGGER_CLAIM] + sample_pool

    report = _build_report(
        claims          = hg_records,
        dep_map         = dep_map,
        const_map       = const_map,
        dep_stats_agg   = dict(dep_agg),
        const_stats_agg = dict(const_agg),
        entity_results  = entity_results,
        pp_cases        = pp_cases,
        coverage_dep    = coverage_dep,
        coverage_const  = coverage_const,
        sample_ids      = sample_ids,
        sample_n        = args.sample_n,
        verb_units      = args.verb_units,
        maximal_np      = args.maximal_np,
    )

    out_path.write_text(report, encoding="utf-8")
    print(f"    Written: {out_path}")

    # 6. Console summary
    n_dep_entities = len(entity_results)
    n_exact = sum(1 for r in entity_results if r["mismatch"] == "exact")
    exact_pct = 100 * n_exact / max(1, n_dep_entities)
    print(f"\n{'=' * 60}")
    print("KEY RESULT")
    print(f"{'=' * 60}")
    print(f"  Dep phrase_entity units  : {n_dep_entities}")
    print(f"  Exact-span match         : {n_exact}  ({exact_pct:.1f}%)")
    mismatch_counts: Counter = Counter(r["mismatch"] for r in entity_results)
    for k in ("const_wider", "const_narrower", "crossing", "no_match"):
        print(f"  {k:<24}: {mismatch_counts[k]}")
    print(f"  PP-merge cases           : {len(pp_cases)}")
    if coverage_dep and coverage_const:
        print(f"  Dep mean coverage        : {sum(coverage_dep)/len(coverage_dep):.3f}")
        print(f"  Const mean coverage      : {sum(coverage_const)/len(coverage_const):.3f}")
    print(f"\nReport: {out_path}")
    print("\nDone.")


if __name__ == "__main__":
    main()
