"""
AViD Phase 1 (Complement) — Annotation Unit Construction.

Pure functions over a single hypergraph record; no I/O.

Two operations (plan: avid_phase1_complement_annotation_units_v1.md):
  (A) Phrasal grouping: emit phrase-level NP units from the dependency parse.
      Head + premodifiers (det/amod/nummod/compound/flat/appos) + of-complement
      (nmod whose case is 'of'). All other PPs, relcl, conj cut.
  (2) Categorematic filter: export only self-contained units.
      entity (phrase-level) and event → export.
      attribute, cardinality, coord-op, logical-op → demote (judged via factor).
      relation-op → dropped (unchanged).
      expletive subjects (deprel 'expl': "there", pleonastic "it") → dropped.
      copular/existential "be" (is/are/was/were/been) → demoted (judged via factor).
      Factors NOT entirely within a single phrase unit → kept.
      Coverage invariant: demoted items with no covering exported unit → orphan tag.
      Dedup by normalised surface span.
"""

from __future__ import annotations

# ── Deprel sets ──────────────────────────────────────────────────────────────

# Deprels expanded inside an NP (premodifiers)
_NP_EXPAND = frozenset({"det", "amod", "nummod", "compound", "flat", "appos"})

# Node types to demote (not shown standalone unless orphaned)
_DEMOTE_NODE_TYPES = frozenset({"attribute", "cardinality", "coord-op", "logical-op"})

# Node types to drop entirely (never exported)
_DROP_NODE_TYPES = frozenset({"relation-op"})

# Deprel marking an expletive subject (existential "there", pleonastic "it") → drop.
# These are tagged PRON → entity by the POS tagger but carry no content.
_EXPLETIVE_DEPREL = "expl"

# Verb lemmas that are copular/existential "be" (functional) → demote, judged via
# the unit's factor + full_claim. Only "be" is matched; lexical "have"/"do"
# (possession, "do a handstand") are content and intentionally kept.
_COPULA_LEMMAS = frozenset({"be"})


# ── Helper utilities ─────────────────────────────────────────────────────────

def _build_children(parse: list[dict]) -> dict[int, list[dict]]:
    """Return dict mapping token index → list of child token dicts."""
    ch: dict[int, list[dict]] = {}
    for tok in parse:
        if tok["i"] != tok["head"]:  # skip root self-reference
            ch.setdefault(tok["head"], []).append(tok)
    return ch


def _token_char_offsets(parse: list[dict], claim_text: str) -> list[tuple[int, int]]:
    """Sequential left-to-right match of parse tokens → (char_start, char_end) list."""
    offsets: list[tuple[int, int]] = []
    pos = 0
    for tok in parse:
        text = tok["text"]
        idx = claim_text.find(text, pos)
        if idx == -1:
            idx = claim_text.lower().find(text.lower(), pos)
        if idx != -1:
            offsets.append((idx, idx + len(text)))
            pos = idx + len(text)
        else:
            # Fallback: zero-width at current position
            offsets.append((pos, pos + len(text)))
            pos += len(text)
    return offsets


def _entity_head_ti(node: dict, parse: list[dict]) -> int:
    """Find the UD head token index of an entity node (handles merged multi-token nodes).

    The head is the token whose syntactic head lies outside the node's token set.
    """
    tids = node["token_indices"]
    tids_set = set(tids)
    for ti in tids:
        if parse[ti]["head"] not in tids_set:
            return ti
    return tids[0]


def _is_expletive(node: dict, parse: list[dict]) -> bool:
    """True if the node's head token is an expletive subject (deprel 'expl').

    Catches existential "there" and pleonastic "it" that the POS tagger labels
    PRON → entity. These are pure function words and are dropped.
    """
    ti = _entity_head_ti(node, parse)
    return parse[ti]["deprel"] == _EXPLETIVE_DEPREL


def _is_copula_be(node: dict, parse: list[dict]) -> bool:
    """True if the node's head token is a copular/existential form of "be".

    Catches is/are/was/were/been tagged VERB → event (e.g. "There are X",
    "It is windy"). Functional: demoted, judged via its factor + full_claim.
    Lexical "have"/"do" (possession, "do a handstand") are intentionally NOT
    matched — only "be" is unambiguously non-content.
    """
    ti = _entity_head_ti(node, parse)
    return parse[ti]["lemma"] in _COPULA_LEMMAS


# ── NP token-set construction (Operation A) ──────────────────────────────────

def _np_token_set(head_ti: int, children_of: dict[int, list[dict]]) -> frozenset[int]:
    """Collect token indices for the NP rooted at head_ti.

    Keep: premodifiers (det/amod/nummod/compound/flat/appos)
          and of-complements (nmod whose direct case child has lemma 'of').
    Cut: all other relations (obl, acl:relcl, conj, non-of nmod, cc, punct, mark, …).
    The 'of' case token itself is included when its nmod is kept.
    """
    result: set[int] = set()

    def _expand(idx: int) -> None:
        result.add(idx)
        for child in children_of.get(idx, []):
            d  = child["deprel"]
            ci = child["i"]
            if d in _NP_EXPAND:
                _expand(ci)
            elif d == "nmod":
                case_kids = [t for t in children_of.get(ci, []) if t["deprel"] == "case"]
                if any(t["lemma"] == "of" for t in case_kids):
                    _expand(ci)
                    for t in case_kids:
                        if t["lemma"] == "of":
                            result.add(t["i"])
            # All other deprels: cut

    _expand(head_ti)
    return frozenset(result)


def _span_from_token_set(
    token_set: frozenset[int], offsets: list[tuple[int, int]]
) -> tuple[int, int]:
    """(char_start, char_end) for a set of token indices using pre-built offsets."""
    starts = [offsets[i][0] for i in token_set]
    ends   = [offsets[i][1] for i in token_set]
    return min(starts), max(ends)


# ── Highlighting ─────────────────────────────────────────────────────────────

def _highlight(text: str, start: int, end: int) -> str:
    return text[:start] + "**" + text[start:end] + "**" + text[end:]


def _highlight_surface(claim_text: str, surface: str) -> str:
    idx = claim_text.lower().find(surface.strip().lower())
    if idx == -1:
        return claim_text
    return _highlight(claim_text, idx, idx + len(surface.strip()))


# ── Main entry point ─────────────────────────────────────────────────────────

def make_annotation_units(rec: dict) -> tuple[list[dict], dict]:
    """Build annotation unit rows for one hypergraph record.

    Returns:
        rows  — list of row dicts (same 9-column schema as annotation.tsv).
        stats — counters for the diff report.
    """
    claim_id   = rec["claim_id"]
    claim_text = rec["claim_text"]
    parse      = rec["parse"]
    nodes      = rec["nodes"]
    factors    = rec["factors"]

    children_of = _build_children(parse)
    tok_off     = _token_char_offsets(parse, claim_text)

    # ── Step 1: Build NP token sets for every entity node ────────────────────
    # Expletive subjects ("there", pleonastic "it"; deprel 'expl') are function
    # words — dropped here so they never become phrase units.
    entity_np: dict[str, frozenset[int]] = {}  # node_id → np_token_set
    dropped_expletives = 0
    for n in nodes:
        if n["node_type"] != "entity":
            continue
        if _is_expletive(n, parse):
            dropped_expletives += 1
            continue
        head_ti  = _entity_head_ti(n, parse)
        np_toks  = _np_token_set(head_ti, children_of)
        # Ensure the node's own token_indices are included (guard for edge cases)
        np_toks  = frozenset(np_toks | set(n["token_indices"]))
        entity_np[n["id"]] = np_toks

    # ── Step 2: Determine absorbed entities ──────────────────────────────────
    # Entity A is absorbed if all its token_indices are inside another entity B's NP.
    absorbed_ids: set[str] = set()
    node_by_id   = {n["id"]: n for n in nodes}

    for nid_a, np_a in entity_np.items():
        tids_a = set(node_by_id[nid_a]["token_indices"])
        for nid_b, np_b in entity_np.items():
            if nid_b == nid_a:
                continue
            if tids_a <= np_b:
                absorbed_ids.add(nid_a)
                break

    # ── Step 3: Build phrase units for non-absorbed (maximal) entities ────────
    # {unit_id, unit_text, span_start, span_end, source_id, token_set}
    phrase_units: list[dict] = []
    for n in nodes:
        if n["node_type"] != "entity":
            continue
        if n["id"] not in entity_np:   # expletive entities were dropped in Step 1
            continue
        if n["id"] in absorbed_ids:
            continue
        np_toks = entity_np[n["id"]]
        s, e    = _span_from_token_set(np_toks, tok_off)
        unit_text = claim_text[s:e]
        phrase_units.append({
            "unit_id":    f"pu_{n['id']}",
            "unit_text":  unit_text,
            "span_start": s,
            "span_end":   e,
            "source_id":  n["id"],
            "token_set":  np_toks,
        })

    # ── Step 4: Collect rows ─────────────────────────────────────────────────
    # seen_spans: norm_text → row dict (dedup by surface span)
    seen: dict[str, dict] = {}

    def _add(row: dict) -> None:
        """Insert row; on duplicate span merge node_type strings."""
        norm = row["unit_text"].strip().lower()
        if norm not in seen:
            seen[norm] = row
        else:
            existing = seen[norm]
            new_type = row["node_type"]
            existing_types = set(existing["node_type"].split("|"))
            # Merge factor_type labels (e.g. predicate_argument|full_claim)
            if existing["unit_type"] == "factor" and row["unit_type"] == "factor":
                if new_type not in existing_types:
                    existing["node_type"] = "|".join(
                        list(existing_types) + [new_type]
                    )
            # node/phrase_entity beats factor for same span
            elif existing["unit_type"] == "factor" and row["unit_type"] != "factor":
                seen[norm] = row
            # full_claim factor always merges into existing row (mirrors baseline dedup)
            elif row["unit_type"] == "factor" and new_type == "full_claim":
                if new_type not in existing_types:
                    existing["node_type"] = "|".join(
                        list(existing_types) + [new_type]
                    )

    # (a) Phrase-level entity units
    for pu in phrase_units:
        _add({
            "claim_id":          claim_id,
            "unit_id":           pu["unit_id"],
            "unit_type":         "phrase_entity",
            "node_type":         "entity",
            "claim_text":        claim_text,
            "unit_text":         pu["unit_text"],
            "claim_highlighted": _highlight(claim_text, pu["span_start"], pu["span_end"]),
            "gold_channels":     "",
            "notes":             "",
        })

    # (b) Event nodes — except copular/existential "be" (functional; judged via
    #     its factor + full_claim, like prepositions/conjunctions).
    demoted_copula = 0
    for n in nodes:
        if n["node_type"] != "event":
            continue
        if _is_copula_be(n, parse):
            demoted_copula += 1
            continue
        _add({
            "claim_id":          claim_id,
            "unit_id":           n["id"],
            "unit_type":         "node",
            "node_type":         "event",
            "claim_text":        claim_text,
            "unit_text":         n["text"],
            "claim_highlighted": _highlight(claim_text, n["span_start"], n["span_end"]),
            "gold_channels":     "",
            "notes":             "",
        })

    # (c) Factors: keep those NOT entirely within a single phrase unit's span.
    #     full_claim is never subsumed (it covers the whole claim by definition).
    subsumed_factor_count = 0
    for f in factors:
        surf   = f["surface_span"].strip()
        f_low  = surf.lower()
        f_idx  = claim_text.lower().find(f_low)
        if f_idx == -1:
            f_idx = claim_text.find(surf)
        f_start = f_idx if f_idx != -1 else 0
        f_end   = f_start + len(surf)

        # full_claim must always appear in the output
        is_full_claim = f["factor_type"] == "full_claim"

        within_pu = (not is_full_claim) and any(
            pu["span_start"] <= f_start and f_end <= pu["span_end"]
            for pu in phrase_units
        )
        if within_pu:
            subsumed_factor_count += 1
            continue

        _add({
            "claim_id":          claim_id,
            "unit_id":           f["id"],
            "unit_type":         "factor",
            "node_type":         f["factor_type"],
            "claim_text":        claim_text,
            "unit_text":         surf,
            "claim_highlighted": _highlight_surface(claim_text, surf),
            "gold_channels":     "",
            "notes":             "",
        })

    # ── Step 5: Coverage check for demoted nodes ─────────────────────────────
    # Demoted types: attribute, cardinality, coord-op, logical-op.
    # Each demoted node must appear as a substring in at least one exported unit.
    exported_texts = {v["unit_text"].lower() for v in seen.values()}

    orphan_count = 0
    demoted_count = 0
    for n in nodes:
        if n["node_type"] not in _DEMOTE_NODE_TYPES:
            continue
        demoted_count += 1
        node_text_low = n["text"].strip().lower()
        covered = any(node_text_low in exp for exp in exported_texts)
        if not covered:
            # Orphan: emit standalone with tag
            orphan_count += 1
            _add({
                "claim_id":          claim_id,
                "unit_id":           n["id"],
                "unit_type":         "node",
                "node_type":         n["node_type"],
                "claim_text":        claim_text,
                "unit_text":         n["text"],
                "claim_highlighted": _highlight(
                    claim_text, n["span_start"], n["span_end"]
                ),
                "gold_channels":     "",
                "notes":             f"orphan:{n['node_type']}",
            })

    # ── Step 6: Sort by first-occurrence position in claim_text ───────────────
    def _pos(row: dict) -> int:
        idx = claim_text.lower().find(row["unit_text"].strip().lower())
        return idx if idx != -1 else len(claim_text)

    rows = sorted(seen.values(), key=_pos)

    stats = {
        "phrase_units":        len(phrase_units),
        "absorbed_entities":   len(absorbed_ids),
        "demoted_nodes":       demoted_count,
        "orphaned_nodes":      orphan_count,
        "subsumed_factors":    subsumed_factor_count,
        "dropped_expletives":  dropped_expletives,
        "demoted_copula":      demoted_copula,
        "rows_out":            len(rows),
    }

    return rows, stats
