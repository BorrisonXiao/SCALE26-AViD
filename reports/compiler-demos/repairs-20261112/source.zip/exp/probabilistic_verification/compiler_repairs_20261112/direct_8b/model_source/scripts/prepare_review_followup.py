#!/usr/bin/env python3
"""Reserve fresh review cases before compiler changes, without judging their meaning."""
import hashlib
import json
import random
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PREVIOUS = ROOT / 'exp/probabilistic_verification/scope_compilation_20261101'
RUN = ROOT / 'exp/probabilistic_verification/review_followup_20261104'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def text_key(text):
    return ' '.join(text.casefold().split())


def select_cases(records, excluded_ids, excluded_sources, count=20, seed=202611041):
    old_texts = {text_key(r['text']) for r in records if r['claim_id'] in excluded_ids}
    eligible = [r for r in records if r['claim_id'] not in excluded_ids
                and r.get('source_videos') and not set(r['source_videos']) & excluded_sources
                and text_key(r['text']) not in old_texts]
    candidates = sorted(eligible, key=lambda r: r['claim_id'])
    random.Random(seed).shuffle(candidates)
    selected, used_sources, used_texts = [], set(), set()
    for record in candidates:
        sources = set(record['source_videos'])
        key = text_key(record['text'])
        if sources & used_sources or key in used_texts:
            continue
        selected.append(record)
        used_sources.update(sources)
        used_texts.add(key)
        if len(selected) == count:
            break
    if len(selected) != count:
        raise ValueError(f'Only {len(selected)} eligible cases could be selected; requested {count}.')
    return selected, len(eligible)


def main():
    RUN.mkdir(parents=True, exist_ok=True)
    target = RUN / 'sample_manifest.json'
    if target.exists():
        manifest = json.loads(target.read_text())
        for name, digest in manifest['frozen_files_sha256'].items():
            if sha(ROOT / name) != digest:
                raise ValueError('A frozen input changed: ' + name)
        print('Existing twenty-case reservation verified; no reselection.')
        return
    old = json.loads((PREVIOUS / 'sample_manifest.json').read_text())
    records = [json.loads(s) for s in (PREVIOUS / 'inputs.jsonl').read_text().splitlines()]
    excluded_ids = set(old['development_ids'] + old['previous_review_ids'] + old['human_review_ids'])
    excluded_sources = set(old['previous_review_sources'] + old['human_review_sources'])
    selected, eligible = select_cases(records, excluded_ids, excluded_sources)
    selected_ids = {r['claim_id'] for r in selected}
    baseline = [json.loads(s) for s in (PREVIOUS / 'results.jsonl').read_text().splitlines()]
    baseline = [r for r in baseline if r['claim_id'] in selected_ids]
    assert len(baseline) == len(selected)
    compiler_freeze = json.loads((PREVIOUS / 'frozen_manifest.json').read_text())
    for name, digest in compiler_freeze['source_sha256'].items():
        assert sha(ROOT / name) == digest, name
    def write_rows(name, rows):
        (RUN / name).write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in rows))
    write_rows('fresh_inputs.jsonl', selected)
    write_rows('fresh_baseline.jsonl', baseline)
    paths = [PREVIOUS / name for name in ('inputs.jsonl', 'results.jsonl', 'sample_manifest.json', 'frozen_manifest.json')]
    paths += [RUN / 'fresh_inputs.jsonl', RUN / 'fresh_baseline.jsonl']
    manifest = dict(seed=202611041, count=20, reserved_at=datetime.now(timezone.utc).isoformat(),
        eligible_claims=eligible, excluded_review_ids=sorted(excluded_ids),
        excluded_review_sources=sorted(excluded_sources),
        cases=[dict(claim_id=r['claim_id'], source_videos=r['source_videos'],
                    text_sha256=hashlib.sha256(r['text'].encode()).hexdigest()) for r in selected],
        compiler_source_sha256=compiler_freeze['source_sha256'],
        frozen_files_sha256={str(p.relative_to(ROOT)): sha(p) for p in paths},
        protocol='Seeded random claim order; select twenty cases with mutually disjoint actual source_videos, excluding recorded earlier review sources/IDs and normalized duplicate texts. No output-based selection or semantic review. All corpus texts were parsed previously; this is a fresh review sample, not a fully held-out corpus or a uniform corpus sample.')
    target.write_text(json.dumps(manifest, indent=2) + '\n')
    status = dict(status='awaiting_review_export', user_reports_twenty_reviews_complete=True,
        human_export_received=False, fresh_cases_reserved=20, compiler_changes_started=False,
        semantic_results=None,
        next_steps=['Receive and validate the completed export; analyze paired judgments and disagreements.',
                    'Trace confirmed failures and choose two or three recurring patterns.',
                    'Implement one bounded revision; rerun all 2375 claims and evaluate the reserved sample.'])
    (RUN / 'status.json').write_text(json.dumps(status, indent=2) + '\n')
    print(json.dumps(dict(reserved=20, eligible=eligible, source_overlap_with_recorded_reviews=0,
                          source_overlap_between_reserved_cases=0, semantic_review_performed=False)))


if __name__ == '__main__':
    main()
