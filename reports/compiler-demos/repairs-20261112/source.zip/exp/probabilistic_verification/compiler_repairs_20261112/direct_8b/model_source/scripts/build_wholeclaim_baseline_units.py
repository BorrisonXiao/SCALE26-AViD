#!/usr/bin/env python3
"""Build the flat whole-claim baseline probe surface.

The flat baseline = ask the MLLM about the ENTIRE claim as one unit
("Is '<full claim>' visible/audible?"), with no tree decomposition. This is the
"what you'd do without AViD" comparison for the perturbation faithfulness eval.

Emits one row per claim (natural + perturbed) in the tree_units_ud.tsv schema so
`run_m2_probe.py` can probe it unchanged. For PERTURBED claims the media must be
the ORIGINAL video (perturbation only edits text), so claim_id = original_claim_id
(valid for the manifest/media lookup) and unit_id = the unique perturb_id.

Output: exp/phase3/baseline/wholeclaim_units.tsv
"""
import json, csv
from pathlib import Path

AVID = Path("/exp/cxiao/scale26/avid")
NAT_TREES = AVID / "exp/phase3/trees/trees_ud_star.jsonl"
PERT_TREES = AVID / "exp/phase3/perturb_star/perturbed_trees.jsonl"
OUT = AVID / "exp/phase3/baseline/wholeclaim_units.tsv"

COLS = ["claim_id", "unit_id", "unit_type", "node_type", "claim_text",
        "unit_text", "claim_highlighted", "gold_channels", "notes"]

def row(claim_id, unit_id, claim_text, note):
    return {"claim_id": claim_id, "unit_id": unit_id, "unit_type": "whole_claim",
            "node_type": "full_claim", "claim_text": claim_text,
            "unit_text": claim_text, "claim_highlighted": claim_text,
            "gold_channels": "", "notes": note}

def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    rows = []

    # Natural whole claims: unit_id "full"
    n_nat = 0
    for line in open(NAT_TREES):
        r = json.loads(line)
        rows.append(row(r["claim_id"], "full", r["claim_text"], "baseline:natural"))
        n_nat += 1

    # Perturbed whole claims: claim_id = original (media), unit_id = perturb_id (unique)
    n_pert = 0
    for line in open(PERT_TREES):
        r = json.loads(line)
        pid = r["claim_id"]                    # e.g. TInVWzp25aIM_0__neg
        orig = r["original_claim_id"]
        rows.append(row(orig, pid, r["claim_text"], f"baseline:{r['perturb_type']}"))
        n_pert += 1

    with open(OUT, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS, delimiter="\t")
        w.writeheader()
        w.writerows(rows)

    print(f"  natural whole-claims : {n_nat}")
    print(f"  perturbed whole-claims: {n_pert}")
    print(f"  total rows            : {len(rows)}")
    print(f"  -> {OUT}")

if __name__ == "__main__":
    main()
