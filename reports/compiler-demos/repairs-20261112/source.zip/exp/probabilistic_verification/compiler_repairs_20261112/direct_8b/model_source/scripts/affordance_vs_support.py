#!/usr/bin/env python3
"""
AViD Phase 2 — Step 4: affordance prior × signal-side support agreement.

This is the ONLY script that joins affordance and support data.
Reads:
  exp/phase1/affordance_v2/affordance_annotation.tsv       (text-only prior; pred_llm column)
  exp/phase2/support_annotation.tsv      (measured support, blind to prior)

Reports:
  (a) Overall hit-rate: affordance argmax channel ∈ supporting_channels (yes set)
  (b) Per-channel precision / recall / F1:
        prior=argmax=<channel>  →  support=yes for that channel (gold)
  (c) Breakdown by affordance class: for units prior predicts as <class>, what
      fraction verified as supported in that channel / other / not at all

Output:
  exp/phase2/reports/affordance_vs_support.tsv
  exp/phase2/reports/affordance_vs_support.md

Usage:
    python scripts/affordance_vs_support.py
    python scripts/affordance_vs_support.py \\
        --affordance-tsv exp/phase1/affordance_v2/affordance_annotation.tsv \\
        --support-tsv    exp/phase2/support_annotation.tsv \\
        --output-dir     exp/phase2/reports
"""

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_AFF_TSV    = str(_AVID / "exp/phase1/affordance_v2/affordance_annotation.tsv")
DEFAULT_SUP_TSV    = str(_AVID / "exp/phase2/support_annotation.tsv")
DEFAULT_OUTPUT_DIR = str(_AVID / "exp/phase2/reports")

CHANNELS = ["visual_ocr", "visual_other", "audio_speech", "audio_other"]
PRIOR_LABELS = ["visual_other", "visual_ocr", "audio_speech", "audio_other",
                "unverifiable", "na"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_affordance(path: str) -> dict[str, str]:
    """Load affordance TSV → {claim_id|unit_id: pred_llm label}."""
    out: dict[str, str] = {}
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid:
                out[f"{cid}|{uid}"] = (row.get("pred_llm") or "").strip()
    return out


def load_support(path: str) -> dict[str, dict]:
    """Load support TSV → {claim_id|unit_id: row}."""
    out: dict[str, dict] = {}
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid:
                out[f"{cid}|{uid}"] = row
    return out


def _prf(tp: int, fp: int, fn: int) -> tuple[float, float, float]:
    p = tp / max(1, tp + fp)
    r = tp / max(1, tp + fn)
    f = 2 * p * r / max(1e-9, p + r)
    return p, r, f


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def setup_parser():
    p = argparse.ArgumentParser(
        description="AViD Phase 2 — Step 4: affordance × support agreement"
    )
    p.add_argument("--affordance-tsv", default=DEFAULT_AFF_TSV)
    p.add_argument("--support-tsv",    default=DEFAULT_SUP_TSV)
    p.add_argument("--output-dir",     default=DEFAULT_OUTPUT_DIR)
    return p


def main():
    args = setup_parser().parse_args()
    out_dir = Path(args.output_dir)

    print("=" * 60)
    print("AViD Phase 2 — affordance_vs_support.py")
    print(f"  Affordance TSV: {args.affordance_tsv}")
    print(f"  Support TSV:    {args.support_tsv}")
    print(f"  Output dir:     {out_dir}")
    print("=" * 60)

    # 1. Load data
    print("\n[1] Loading data ...")
    aff_data = load_affordance(args.affordance_tsv)
    sup_data = load_support(args.support_tsv)
    print(f"    Affordance rows: {len(aff_data)}")
    print(f"    Support rows:    {len(sup_data)}")

    # 2. Join on (claim_id|unit_id) — support is the authoritative key set
    # (na-filtered units are in aff_data but NOT in sup_data)
    joined_keys = [k for k in sup_data if k in aff_data]
    print(f"    Joined rows:     {len(joined_keys)}")

    # 3. Compute metrics
    # (a) Hit-rate
    hit_yes  = 0   # prior argmax channel ∈ supporting_channels (support=yes)
    hit_unk  = 0   # prior argmax channel has support=unknown
    hit_no   = 0   # prior argmax channel has support=no

    # (b) Per-channel P/R/F1: prior predicts channel → support gold=yes
    #     tp = prior=ch AND support_ch=yes
    #     fp = prior=ch AND support_ch≠yes
    #     fn = prior≠ch AND support_ch=yes
    ch_tp: dict[str, int] = {ch: 0 for ch in CHANNELS}
    ch_fp: dict[str, int] = {ch: 0 for ch in CHANNELS}
    ch_fn: dict[str, int] = {ch: 0 for ch in CHANNELS}

    # (c) Breakdown by affordance class
    # aff_class → {matched_channel_verdict: count}
    # where matched_channel = same channel as aff_class (e.g. aff=visual_ocr → look at visual_ocr verdict)
    class_breakdown: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    # Also: aff_class → status counts
    class_status: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))

    no_video_count = 0

    for key in joined_keys:
        prior_label = aff_data[key]
        sup_row     = sup_data[key]
        no_video    = sup_row.get("no_video", "false").lower() == "true"
        if no_video:
            no_video_count += 1

        sup_channels = {ch: sup_row.get(f"support_{ch}", "unknown") for ch in CHANNELS}
        sup_yes_set  = {ch for ch in CHANNELS if sup_channels[ch] == "yes"}
        status       = sup_row.get("status", "unknown")

        # (a) hit-rate: does prior argmax channel appear in support=yes set?
        if prior_label in CHANNELS:
            verdict_for_prior = sup_channels.get(prior_label, "unknown")
            if verdict_for_prior == "yes":
                hit_yes += 1
            elif verdict_for_prior == "unknown":
                hit_unk += 1
            else:
                hit_no += 1

        # (b) per-channel P/R/F1
        for ch in CHANNELS:
            gold_yes = (sup_channels[ch] == "yes")
            pred_yes = (prior_label == ch)
            if pred_yes and gold_yes:
                ch_tp[ch] += 1
            elif pred_yes and not gold_yes:
                ch_fp[ch] += 1
            elif not pred_yes and gold_yes:
                ch_fn[ch] += 1

        # (c) breakdown by affordance class
        class_status[prior_label][status] += 1
        if prior_label in CHANNELS:
            # For the predicted channel, record its support verdict
            ch_verdict = sup_channels.get(prior_label, "unknown")
            class_breakdown[prior_label][ch_verdict] += 1

    n_joined = max(1, len(joined_keys))
    n_prior_verifiable = sum(
        1 for k in joined_keys if aff_data[k] in CHANNELS
    )

    print(f"\n[2] Agreement metrics ...")
    print(f"    Total joined units:     {len(joined_keys)}")
    print(f"    Prior in CHANNELS:      {n_prior_verifiable}")
    print(f"    No-video units:         {no_video_count}")

    hit_total = hit_yes + hit_unk + hit_no
    print(f"\n    Hit-rate (prior argmax ∈ support=yes):")
    print(f"      yes:     {hit_yes}/{hit_total} ({100*hit_yes/max(1,hit_total):.1f}%)")
    print(f"      unknown: {hit_unk}/{hit_total} ({100*hit_unk/max(1,hit_total):.1f}%)")
    print(f"      no:      {hit_no}/{hit_total} ({100*hit_no/max(1,hit_total):.1f}%)")

    prf_rows = []
    print(f"\n    Per-channel P/R/F1 (prior=channel → support=yes gold):")
    for ch in CHANNELS:
        p, r, f = _prf(ch_tp[ch], ch_fp[ch], ch_fn[ch])
        n_pred = ch_tp[ch] + ch_fp[ch]
        n_gold = ch_tp[ch] + ch_fn[ch]
        print(f"      {ch:18s}  P={p:.3f}  R={r:.3f}  F1={f:.3f}  "
              f"(pred={n_pred}, gold={n_gold})")
        prf_rows.append({"channel": ch, "precision": p, "recall": r, "f1": f,
                         "n_pred": n_pred, "n_gold": n_gold,
                         "tp": ch_tp[ch], "fp": ch_fp[ch], "fn": ch_fn[ch]})

    print(f"\n    Breakdown by affordance class (→ support verdict for that channel):")
    for label in PRIOR_LABELS:
        n_tot = sum(class_status[label].values())
        if n_tot == 0:
            continue
        breakdown_str = "  ".join(
            f"{v}={cnt}({100*cnt/n_tot:.0f}%)"
            for v, cnt in sorted(class_status[label].items())
        )
        print(f"      {label:18s} (n={n_tot}): {breakdown_str}")

    # 4. Write TSV report
    out_dir.mkdir(parents=True, exist_ok=True)
    tsv_path = out_dir / "affordance_vs_support.tsv"
    with open(tsv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=[
            "channel", "precision", "recall", "f1",
            "n_pred", "n_gold", "tp", "fp", "fn",
        ], delimiter="\t", lineterminator="\n")
        w.writeheader()
        for row in prf_rows:
            w.writerow({k: f"{v:.4f}" if isinstance(v, float) else v
                        for k, v in row.items()})
    print(f"\n[3] Wrote TSV: {tsv_path}")

    # 5. Write Markdown report
    md_path = out_dir / "affordance_vs_support.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# AViD Phase 2 — Affordance × Support Agreement\n\n")
        f.write(f"- Affordance TSV: `{args.affordance_tsv}`\n")
        f.write(f"- Support TSV:    `{args.support_tsv}`\n")
        f.write(f"- Joined units:   {len(joined_keys)}\n")
        f.write(f"- No-video units: {no_video_count}\n\n")

        f.write("## Hit-rate\n\n")
        f.write("Prior argmax channel ∈ support=yes set:\n\n")
        f.write(f"| Verdict | Count | % |\n|---|---|---|\n")
        for lbl, cnt in [("yes", hit_yes), ("unknown", hit_unk), ("no", hit_no)]:
            f.write(f"| {lbl} | {cnt} | {100*cnt/max(1,hit_total):.1f}% |\n")
        f.write("\n")

        f.write("## Per-channel P/R/F1\n\n")
        f.write("| Channel | P | R | F1 | Pred | Gold | TP | FP | FN |\n")
        f.write("|---|---|---|---|---|---|---|---|---|\n")
        for row in prf_rows:
            f.write(
                f"| {row['channel']} | {row['precision']:.3f} | {row['recall']:.3f} | "
                f"{row['f1']:.3f} | {row['n_pred']} | {row['n_gold']} | "
                f"{row['tp']} | {row['fp']} | {row['fn']} |\n"
            )
        f.write("\n")

        f.write("## Breakdown by Affordance Class\n\n")
        f.write("For each affordance class, distribution of support status:\n\n")
        f.write("| Affordance class | n | supported | unsupported | unknown |\n")
        f.write("|---|---|---|---|---|\n")
        for label in PRIOR_LABELS:
            n_tot = sum(class_status[label].values())
            if n_tot == 0:
                continue
            s = class_status[label].get("supported", 0)
            u = class_status[label].get("unsupported", 0)
            k = class_status[label].get("unknown", 0)
            f.write(f"| {label} | {n_tot} | {s}({100*s/n_tot:.0f}%) | "
                    f"{u}({100*u/n_tot:.0f}%) | {k}({100*k/n_tot:.0f}%) |\n")
        f.write("\n")

        f.write("## Channel Verdict for Predicted Channel\n\n")
        f.write("For units where affordance prior = a verifiable channel, "
                "support verdict for that channel:\n\n")
        f.write("| Affordance class | yes | no | unknown |\n|---|---|---|---|\n")
        for ch in CHANNELS:
            n_tot = sum(class_breakdown[ch].values())
            if n_tot == 0:
                continue
            y = class_breakdown[ch].get("yes", 0)
            n_ = class_breakdown[ch].get("no", 0)
            u = class_breakdown[ch].get("unknown", 0)
            f.write(f"| {ch} | {y}({100*y/n_tot:.0f}%) | "
                    f"{n_}({100*n_/n_tot:.0f}%) | {u}({100*u/n_tot:.0f}%) |\n")

    print(f"    Wrote MD:  {md_path}")
    print("\nDone.")


if __name__ == "__main__":
    main()
