"""Controlled DeepProbLog checks of absence, not predictions about any real clip."""
import itertools,json
from pathlib import Path
from probabilistic_verification.compiler_extensions import compile_extended_relations
from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground
from probabilistic_verification.direct_backend import DirectVerifier
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/rewrite_all_20261112'


def main():
    record=next(r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())if r['claim_id']=='TgR_u37mCoQ4_1901')
    claim,_=compile_extended_relations(record);audio=next(k for k,e in claim.metadata['entities'].items()if e['text']=='audio');rows=[]
    for empty,complete,expected in [(True,True,'supported'),(True,False,'unknown'),(False,True,'refuted')]:
        domains={v.name:[v.name.lower()]for v in claim.variables}
        if empty:domains[audio]=[]
        evidence=Evidence('controlled-absence',domains,{v.name:complete if v.name==audio else True for v in claim.variables},{})
        for atom in claim.atoms:
            names=[v.name for v in claim.variables if v.name in atom.arguments]
            for values in itertools.product(*(domains[n]for n in names)):
                key=canonical_key(evidence.media_id,atom,dict(zip(names,values)),evidence.route)
                evidence.observations[key]=Observation(key,(1.,0.,0.),False,'Constructed supported observation')
        verifier=DirectVerifier([ground(claim,evidence)],learned=False)
        result=verifier.predict()[0]['distribution'];assert max(result,key=result.get)==expected
        rows.append(dict(empty_audio_inventory=empty,inventory_complete=complete,expected=expected,distribution=result))
    (RUN/'native_absence.json').write_text(json.dumps(dict(provenance='Constructed candidate inventories and observations; no media model is called.',cases=rows),indent=2)+'\n')
    print(rows)


if __name__=='__main__':main()
