"""Reproducible experiment overlay; preserve every published earlier archive."""
import argparse,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/claim_rewrite_20261111'
def main():
 p=argparse.ArgumentParser();p.add_argument('--allow-missing-history',action='store_true',help='For isolated reproduction only; present historical files are always checked.');args=p.parse_args()
 paths=['scripts/probabilistic_verification/claim_rewrite.py','scripts/prepare_claim_rewrite_pilot.py','scripts/run_claim_rewrite_model.py','scripts/run_claim_rewrite_model.slurm',
 'scripts/parse_claim_rewrites.py','scripts/compile_claim_rewrite_pilot.py','scripts/analyze_claim_rewrite_pilot.py','scripts/claim_rewrite_report.py','scripts/package_claim_rewrite_pilot.py','scripts/check_claim_rewrite_browser.py',
 'scripts/report_assets/claim_rewrite.js','tests/test_claim_rewrite.py','scripts/build_compiler_demos.py','scripts/compiler_alert_review_report.py',
 'scripts/report_assets/compiler_demos.js','scripts/report_assets/compiler_demos_template.html','scripts/build_av_feature_sections.py','scripts/build_compilation_methods_report.py',
 'docs/claim_rewrite_pilot_20261111.md','docs/project_notes/daily_log.json','exp/probabilistic_verification/av_features_20261022/checklist.json']
 files=[ROOT/p for p in paths]
 excluded={'baseline_replay.jsonl','reviewed_corpus.jsonl','WORK_STATUS.md','publication.json','browser_checks.json','archive_verification.json','package_manifest.json'}
 files.extend(p for p in RUN.rglob('*') if p.is_file() and p.suffix in {'.json','.jsonl','.py','.md','.xml','.out','.err','.txt'} and p.name not in excluded)
 data={str(p.relative_to(ROOT)):p.read_bytes() for p in files}
 data['README_CLAIM_REWRITE.md']=(ROOT/'docs/claim_rewrite_pilot_20261111.md').read_bytes()
 hashes={k:hashlib.sha256(v).hexdigest() for k,v in sorted(data.items())}
 data['CLAIM_REWRITE_SHA256SUMS']=''.join(v+'  '+k+'\n'for k,v in hashes.items()).encode()
 target=ROOT/'site/reports/compiler-demos/rewrite-20261111/source.zip';target.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for name,body in sorted(data.items()):
   info=zipfile.ZipInfo(name,date_time=(2026,11,11,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,body)
 (RUN/'package_manifest.json').write_text(json.dumps(dict(files=hashes,archive_sha256=hashlib.sha256(target.read_bytes()).hexdigest()),indent=2)+'\n')
 missing=[]
 for name,digest in json.loads((RUN/'preserved_artifacts.json').read_text()).items():
  if (ROOT/name).exists():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
  else:missing.append(name)
 assert args.allow_missing_history or not missing,missing
 for name,digest in json.loads((RUN/'viewer_sha256.json').read_text()).items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
 print('Packaged',len(data),'files;',round(target.stat().st_size/1048576,2),'MiB; original archives/viewer files unchanged.')
 if missing:print('Isolated reproduction: historical archives absent:',len(missing))
if __name__=='__main__':main()
