"""Run the bounded content-relation repairs on all original cached inputs."""
import json,time
from collections import Counter
from pathlib import Path
from probabilistic_verification.content_relations import compile_content_relations
from run_scope_coverage_census import compile_one as compile_record

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_relations_20261105'

def compile_one(record):return compile_record(record,compiler=compile_content_relations)

def main():
    records=list(map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines()))
    started=time.perf_counter();rows=[compile_one(r) for r in records]
    (RUN/'results.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    summary=dict(total=len(rows),accepted=sum(r['status']=='compiled' for r in rows),executable_candidates=sum('program' in r for r in rows),
        refusal_reasons=dict(Counter(r['code']for r in rows if r['status']!='compiled')),elapsed_seconds=time.perf_counter()-started)
    (RUN/'results.summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
