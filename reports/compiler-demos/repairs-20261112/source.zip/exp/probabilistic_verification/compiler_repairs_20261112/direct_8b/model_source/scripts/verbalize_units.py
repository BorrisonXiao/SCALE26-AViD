#!/usr/bin/env python3
"""
AViD Phase 2 — R3 pre-pass: verbalize each verifiable unit into a concise,
self-contained statement of what to check (proposal §7).

Text-only Qwen3-30B-A3B-Instruct via vLLM. For each unit that survives the
deterministic filters (so the verbalized set == the verification set), rewrite
the highlighted span into a short modality-NEUTRAL description, resolving
pronouns/fragments from the claim. The verifier (verify_support.py --prompt-variant r3)
substitutes this for the raw fragment in both passes.

Output JSONL (resumable): {claim_id, unit_id, unit_text, node_type, verbalized}
Cache key: claim_id|unit_id.

Usage (vllm-omni env, GPU node):
    python scripts/verbalize_units.py \\
        --output exp/phase2/prompt_ablation/verbalized_units.jsonl \\
        --cache  exp/phase2/prompt_ablation/cache/verbalized_cache.jsonl --tp 1
"""

import argparse
import csv
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("VLLM_USE_V1", "0")

_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_ANN_UNITS  = str(_AVID / "exp/phase1/reports/annotation_units.tsv")
DEFAULT_HYPERGRAPH = str(_AVID / "exp/phase1/hypergraph.jsonl")
DEFAULT_AFF_TSV    = str(_AVID / "exp/phase1/affordance_v2/affordance_annotation.tsv")
DEFAULT_NA_LIST    = str(_AVID / "exp/phase2/na_unit_ids.txt")
DEFAULT_OUTPUT     = str(_AVID / "exp/phase2/prompt_ablation/verbalized_units.jsonl")
MODEL_PATH         = "/home/hltcoe/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507"

from unit_filters import filter_units, format_stats  # noqa: E402

SYSTEM = (
    "You rewrite one highlighted span of a news claim into a short, self-contained "
    "statement of what to check against a recording. You output only the statement."
)

USER_TMPL = """\
Claim: "{claim_text}"
Highlighted part (marked with **): "{marked_context}"
Part type: {node_type}

Rewrite ONLY the highlighted part into a concise, self-contained description of \
what to check, so it can be looked for or listened for in a recording. Resolve \
pronouns and sentence fragments using the full claim. Do NOT use the words \
"video", "audio", "visible", "audible", "shown", or "heard". Keep it under 15 \
words. Output only the description.

Description:"""


def make_marked_context(claim_text: str, unit_text: str) -> str:
    idx = claim_text.lower().find(unit_text.lower())
    if idx == -1:
        return claim_text
    return (claim_text[:idx] + "**" + claim_text[idx: idx + len(unit_text)] + "**"
            + claim_text[idx + len(unit_text):])


def load_na_set(na_list_path: str, affordance_tsv: str) -> set[str]:
    p = Path(na_list_path)
    if p.exists():
        return {ln.strip() for ln in open(p, encoding="utf-8") if ln.strip()}
    keys = set()
    ap = Path(affordance_tsv)
    if ap.exists():
        for row in csv.DictReader(open(ap, newline="", encoding="utf-8"), delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid and (row.get("pred_llm") or "").strip() == "na":
                keys.add(f"{cid}|{uid}")
    return keys


def load_cache(path: str) -> dict[str, dict]:
    cache: dict[str, dict] = {}
    p = Path(path)
    if not p.exists():
        return cache
    for line in open(p, encoding="utf-8"):
        o = json.loads(line)
        k = o.get("_cache_key", "")
        if k:
            cache[k] = o
    return cache


def clean_output(text: str) -> str:
    """Take the first non-empty line, strip quotes/labels."""
    t = (text or "").strip()
    for line in t.splitlines():
        line = line.strip()
        if line:
            t = line
            break
    t = t.strip().strip('"').strip()
    for pre in ("Description:", "Statement:", "Answer:"):
        if t.lower().startswith(pre.lower()):
            t = t[len(pre):].strip()
    return t.strip('"').strip()


def setup_parser():
    p = argparse.ArgumentParser(description="AViD Phase 2 — R3 unit verbalization")
    p.add_argument("--annotation-units", default=DEFAULT_ANN_UNITS)
    p.add_argument("--hypergraph",       default=DEFAULT_HYPERGRAPH)
    p.add_argument("--affordance-tsv",   default=DEFAULT_AFF_TSV)
    p.add_argument("--na-list",          default=DEFAULT_NA_LIST)
    p.add_argument("--output",           default=DEFAULT_OUTPUT)
    p.add_argument("--cache",            default="")
    p.add_argument("--model",            default=MODEL_PATH)
    p.add_argument("--tp",               type=int, default=0)
    p.add_argument("--batch-size",       type=int, default=256)
    p.add_argument("--max-tokens",       type=int, default=48)
    p.add_argument("--limit",            type=int, default=0)
    return p


def main():
    args = setup_parser().parse_args()
    out_path = Path(args.output)
    cache_path = Path(args.cache or str(out_path.parent / "cache" / "verbalized_cache.jsonl"))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("AViD Phase 2 — verbalize_units.py (R3 pre-pass)")
    print(f"  Output: {out_path}")
    print(f"  Cache:  {cache_path}")
    print("=" * 60)

    na_keys = load_na_set(args.na_list, args.affordance_tsv)
    raw_units = []
    with open(args.annotation_units, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if not cid or not uid:
                continue
            raw_units.append({
                "claim_id": cid, "unit_id": uid,
                "unit_type": (row.get("unit_type") or "").strip(),
                "node_type": (row.get("node_type") or "").strip(),
                "unit_text": (row.get("unit_text") or "").strip(),
                "claim_text": (row.get("claim_text") or "").strip(),
                "claim_highlighted": (row.get("claim_highlighted") or "").strip(),
            })
    units, stats = filter_units(raw_units, args.hypergraph, na_keys)
    print(format_stats(stats))
    if args.limit > 0:
        units = units[:args.limit]

    cache = load_cache(str(cache_path))
    print(f"    Cache entries: {len(cache)}")

    todo = [u for u in units if f"{u['claim_id']}|{u['unit_id']}" not in cache]
    print(f"    To verbalize:  {len(todo)} / {len(units)}")

    if todo:
        import torch
        from vllm import LLM, SamplingParams
        from transformers import AutoTokenizer
        tp = args.tp if args.tp > 0 else torch.cuda.device_count()
        tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
        llm = LLM(model=args.model, trust_remote_code=True, gpu_memory_utilization=0.90,
                  tensor_parallel_size=tp, dtype="bfloat16", seed=42, max_model_len=4096)
        sp = SamplingParams(temperature=0.0, max_tokens=args.max_tokens)

        def build_prompt(u):
            marked = u["claim_highlighted"] or make_marked_context(u["claim_text"], u["unit_text"])
            user = USER_TMPL.format(claim_text=u["claim_text"], marked_context=marked,
                                    node_type=u["node_type"] or "phrase")
            msgs = [{"role": "system", "content": SYSTEM},
                    {"role": "user", "content": user}]
            try:
                return tok.apply_chat_template(msgs, tokenize=False,
                                               add_generation_prompt=True, enable_thinking=False)
            except TypeError:
                return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)

        bs = args.batch_size
        with open(cache_path, "a", encoding="utf-8") as cf:
            for i in range(0, len(todo), bs):
                batch = todo[i:i + bs]
                prompts = [build_prompt(u) for u in batch]
                print(f"  Batch {i//bs + 1}/{(len(todo)+bs-1)//bs}: {len(batch)} ...", flush=True)
                outs = llm.generate(prompts, sampling_params=sp)
                for u, o in zip(batch, outs):
                    vb = clean_output(o.outputs[0].text)
                    if not vb:
                        vb = u["claim_highlighted"] or u["unit_text"]
                    key = f"{u['claim_id']}|{u['unit_id']}"
                    entry = {"_cache_key": key, "claim_id": u["claim_id"],
                             "unit_id": u["unit_id"], "unit_text": u["unit_text"],
                             "node_type": u["node_type"], "verbalized": vb}
                    cf.write(json.dumps(entry, ensure_ascii=False) + "\n")
                    cache[key] = entry

    # Write final output (one row per unit, ordered)
    n = 0
    with open(out_path, "w", encoding="utf-8") as f:
        for u in units:
            e = cache.get(f"{u['claim_id']}|{u['unit_id']}")
            if not e:
                continue
            f.write(json.dumps({k: e[k] for k in
                                ("claim_id", "unit_id", "unit_text", "node_type", "verbalized")},
                               ensure_ascii=False) + "\n")
            n += 1
    print(f"\n    Rows written: {n} → {out_path}")
    print("Done.")


if __name__ == "__main__":
    main()
