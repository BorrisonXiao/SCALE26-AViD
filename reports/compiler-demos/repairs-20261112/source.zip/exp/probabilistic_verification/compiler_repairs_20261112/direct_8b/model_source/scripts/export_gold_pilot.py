#!/usr/bin/env python3
"""
AViD Phase 2 — Step 5: build self-contained gold pilot annotation package.

Stratified sample of ~20-25 claims (~130 units):
  - Oversample has_audio_modality=true claims (audio is rare, ~10%)
  - Cover all four verifiable affordance classes + some unverifiable
  - Include several visual_ocr units

Output package: exp/phase2/gold_pilot/
  - copies of subset .mp4 and .wav files
  - index.html: per claim, embedded <video controls> + <audio controls>,
    per unit: two-pass annotation form with Download CSV button
  - annotation_template.tsv: blank spreadsheet fallback

Usage:
    python scripts/export_gold_pilot.py
    python scripts/export_gold_pilot.py \\
        --n-claims 25 \\
        --output-dir exp/phase2/gold_pilot
"""

import argparse
import csv
import html
import json
import shutil
from collections import defaultdict
from pathlib import Path

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_ANN_UNITS  = str(_AVID / "exp/phase1/reports/annotation_units.tsv")
DEFAULT_AFF_TSV    = str(_AVID / "exp/v2/affordance_annotation.tsv")
DEFAULT_MANIFEST   = "/exp/cxiao/scale26/probing/exp/step1/manifests/manifest.jsonl"
DEFAULT_VIDEO_DIR  = "/exp/cxiao/scale26/data/extracted/microvent/videos"
DEFAULT_MEDIA_DIR  = str(_AVID / "exp/phase2/media_cache")
DEFAULT_OUTPUT_DIR = str(_AVID / "exp/phase2/gold_pilot")

CHANNELS = ["visual_ocr", "visual_other", "audio_speech", "audio_other"]
AFF_CLASSES = ["visual_other", "visual_ocr", "audio_speech", "audio_other",
               "unverifiable"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_manifest(path: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            cid = f"{r['topic_id']}_{r['claim_index']}"
            out[cid] = r
    return out


def load_affordance(path: str) -> dict[str, str]:
    out: dict[str, str] = {}
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid:
                out[f"{cid}|{uid}"] = (row.get("pred_llm") or "").strip()
    return out


def load_ann_units(path: str) -> dict[str, list[dict]]:
    """Return {claim_id: [unit_rows]}."""
    out: dict[str, list[dict]] = defaultdict(list)
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid:
                out[cid].append(dict(row))
    return out


def stratified_sample(
    manifest: dict[str, dict],
    ann_units: dict[str, list[dict]],
    affordance: dict[str, str],
    n_claims: int,
) -> list[str]:
    """Return a stratified list of claim_ids."""
    import random
    random.seed(42)

    # Index claims by audio modality and affordance class
    has_audio: list[str] = []
    no_audio:  list[str] = []
    # Also track which claims cover each aff class
    aff_class_claims: dict[str, list[str]] = defaultdict(list)

    for cid in ann_units:
        rec = manifest.get(cid)
        if rec is None:
            continue  # no video, skip

        classes_in_claim = set()
        for unit in ann_units[cid]:
            uid = (unit.get("unit_id") or "").strip()
            label = affordance.get(f"{cid}|{uid}", "")
            if label:
                classes_in_claim.add(label)

        if rec.get("has_audio_modality", False):
            has_audio.append(cid)
        else:
            no_audio.append(cid)

        for cls in classes_in_claim:
            aff_class_claims[cls].append(cid)

    # Strategy: 40% audio claims, 60% non-audio; ensure coverage of aff classes
    n_audio    = max(1, int(n_claims * 0.40))
    n_no_audio = n_claims - n_audio

    selected: set[str] = set()

    # First: guarantee at least 2 claims per aff class
    for cls in AFF_CLASSES:
        cands = [c for c in aff_class_claims[cls] if c not in selected]
        cands_audio = [c for c in cands if c in has_audio]
        cands_other = [c for c in cands if c not in has_audio]
        picks = random.sample(cands_audio, min(1, len(cands_audio)))
        picks += random.sample(cands_other, min(1, len(cands_other)))
        selected.update(picks[:2])

    # Fill up audio quota
    remaining_audio = [c for c in has_audio if c not in selected]
    random.shuffle(remaining_audio)
    for c in remaining_audio:
        if len([s for s in selected if s in has_audio]) >= n_audio:
            break
        selected.add(c)

    # Fill remaining from no-audio
    remaining = [c for c in no_audio if c not in selected]
    random.shuffle(remaining)
    for c in remaining:
        if len(selected) >= n_claims:
            break
        selected.add(c)

    return sorted(selected)


# ---------------------------------------------------------------------------
# HTML generator
# ---------------------------------------------------------------------------

def _highlight_unit(claim_text: str, unit_text: str) -> str:
    """Return claim_text with unit_text wrapped in <mark>."""
    idx = claim_text.lower().find(unit_text.lower())
    if idx == -1:
        return html.escape(claim_text)
    before = html.escape(claim_text[:idx])
    marked = html.escape(claim_text[idx: idx + len(unit_text)])
    after  = html.escape(claim_text[idx + len(unit_text):])
    return f'{before}<mark class="unit-highlight">{marked}</mark>{after}'


def generate_html(
    selected_claims: list[str],
    ann_units: dict[str, list[dict]],
    affordance: dict[str, str],
    manifest: dict[str, dict],
    media_rel_dir: str = "media",
) -> str:
    """Build the index.html content."""
    units_per_claim = []
    for cid in selected_claims:
        units = ann_units.get(cid, [])
        rec   = manifest.get(cid, {})
        chunks = rec.get("chunks", [])
        has_audio = rec.get("has_audio_modality", False)
        units_per_claim.append({
            "claim_id": cid,
            "units": units,
            "chunks": chunks,
            "has_audio": has_audio,
        })

    rows_js = []
    for claim_data in units_per_claim:
        cid = claim_data["claim_id"]
        for unit in claim_data["units"]:
            uid   = (unit.get("unit_id") or "").strip()
            label = affordance.get(f"{cid}|{uid}", "")
            rows_js.append({"claim_id": cid, "unit_id": uid, "affordance": label})

    js_rows = json.dumps(rows_js, ensure_ascii=False, indent=2)

    claim_html_parts = []
    for i, claim_data in enumerate(units_per_claim):
        cid       = claim_data["claim_id"]
        chunks    = claim_data["chunks"]
        has_audio = claim_data["has_audio"]
        units     = claim_data["units"]

        # Media elements
        video_tags = ""
        audio_tags = ""
        for chunk_name in chunks:
            chunk_id  = chunk_name.removesuffix(".mp4")
            video_src = f"{media_rel_dir}/{chunk_name}"
            video_tags += (
                f'<video controls style="max-width:720px;width:100%;margin:4px 0">'
                f'<source src="{video_src}" type="video/mp4"></video>\n'
            )
            if has_audio:
                wav_src = f"{media_rel_dir}/{chunk_id}.wav"
                audio_tags += (
                    f'<audio controls style="width:100%;margin:4px 0">'
                    f'<source src="{wav_src}" type="audio/wav"></audio>\n'
                )

        claim_text = units[0]["claim_text"] if units else cid

        # Unit forms
        unit_forms = []
        for unit in units:
            uid   = (unit.get("unit_id") or "").strip()
            ut    = html.escape((unit.get("unit_text") or "").strip())
            aff   = affordance.get(f"{cid}|{uid}", "")
            hl    = _highlight_unit(claim_text, (unit.get("unit_text") or "").strip())
            form_id = f"form_{cid}_{uid}".replace("-", "_")

            unit_forms.append(f"""
  <div class="unit-form" id="{form_id}" data-claim="{html.escape(cid)}" data-unit="{html.escape(uid)}">
    <p><strong>Unit:</strong> <code>{ut}</code> &nbsp;
       <span class="aff-badge aff-{aff}">{html.escape(aff) if aff else '(no affordance)'}</span></p>
    <p class="claim-hl">{hl}</p>
    <table class="annot-table">
      <thead><tr>
        <th>Question</th>
        <th>Yes</th><th>No</th><th>Unknown</th>
      </tr></thead>
      <tbody>
        <tr><td>Supported by anything <em>visible</em> in the video?</td>
          <td><input type="radio" name="{form_id}_pass1_v" value="yes"></td>
          <td><input type="radio" name="{form_id}_pass1_v" value="no"></td>
          <td><input type="radio" name="{form_id}_pass1_v" value="unknown"></td>
        </tr>
        <tr><td>&nbsp;&nbsp;↳ Supported by <em>on-screen text</em> (signs, captions)?</td>
          <td><input type="radio" name="{form_id}_visual_ocr" value="yes"></td>
          <td><input type="radio" name="{form_id}_visual_ocr" value="no"></td>
          <td><input type="radio" name="{form_id}_visual_ocr" value="unknown"></td>
        </tr>
        <tr><td>&nbsp;&nbsp;↳ Supported by <em>non-text visuals</em> (objects/people/actions)?</td>
          <td><input type="radio" name="{form_id}_visual_other" value="yes"></td>
          <td><input type="radio" name="{form_id}_visual_other" value="no"></td>
          <td><input type="radio" name="{form_id}_visual_other" value="unknown"></td>
        </tr>
        <tr><td>Supported by anything <em>audible</em> in the video?</td>
          <td><input type="radio" name="{form_id}_pass1_a" value="yes"></td>
          <td><input type="radio" name="{form_id}_pass1_a" value="no"></td>
          <td><input type="radio" name="{form_id}_pass1_a" value="unknown"></td>
        </tr>
        <tr><td>&nbsp;&nbsp;↳ Supported by <em>speech</em> (dialogue/announcements)?</td>
          <td><input type="radio" name="{form_id}_audio_speech" value="yes"></td>
          <td><input type="radio" name="{form_id}_audio_speech" value="no"></td>
          <td><input type="radio" name="{form_id}_audio_speech" value="unknown"></td>
        </tr>
        <tr><td>&nbsp;&nbsp;↳ Supported by <em>non-speech audio</em> (sounds/music)?</td>
          <td><input type="radio" name="{form_id}_audio_other" value="yes"></td>
          <td><input type="radio" name="{form_id}_audio_other" value="no"></td>
          <td><input type="radio" name="{form_id}_audio_other" value="unknown"></td>
        </tr>
      </tbody>
    </table>
  </div>""")

        unit_forms_html = "\n".join(unit_forms)
        claim_html_parts.append(f"""
<section class="claim-section" id="claim_{i}">
  <h2>Claim {i+1}: <code>{html.escape(cid)}</code>
    {'<span class="audio-badge">🔊 has audio</span>' if has_audio else ''}
  </h2>
  <p class="claim-text">{html.escape(claim_text)}</p>
  <div class="media-block">
    {video_tags}
    {audio_tags if audio_tags else '<p class="muted">(No audio track)</p>'}
  </div>
  <h3>Units ({len(units)})</h3>
  {unit_forms_html}
</section>
""")

    claims_html = "\n".join(claim_html_parts)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AViD Phase 2 — Gold Pilot Annotation</title>
<style>
body {{ font-family: system-ui, sans-serif; max-width: 960px; margin: 0 auto; padding: 16px; }}
h1   {{ color: #2c3e50; }}
h2   {{ border-bottom: 2px solid #3498db; padding-bottom: 4px; }}
h3   {{ color: #555; margin-top: 16px; }}
.claim-section {{ margin-bottom: 40px; padding: 16px; border: 1px solid #ddd; border-radius: 8px; }}
.claim-text   {{ background: #f8f9fa; padding: 8px 12px; border-left: 4px solid #3498db; }}
.media-block  {{ margin: 12px 0; }}
.unit-form    {{ background: #fafafa; border: 1px solid #eee; border-radius: 6px;
                 margin: 12px 0; padding: 12px 16px; }}
.claim-hl     {{ margin: 4px 0 8px; }}
mark.unit-highlight {{ background: #ffe066; }}
.aff-badge    {{ display: inline-block; padding: 2px 8px; border-radius: 4px;
                 font-size: 0.8em; font-weight: bold; }}
.aff-visual_ocr   {{ background: #d5e8d4; color: #274e13; }}
.aff-visual_other {{ background: #dae8fc; color: #0d3349; }}
.aff-audio_speech {{ background: #fff2cc; color: #7d4e00; }}
.aff-audio_other  {{ background: #f8cecc; color: #67000d; }}
.aff-unverifiable {{ background: #e8e8e8; color: #333; }}
.annot-table  {{ border-collapse: collapse; width: 100%; font-size: 0.9em; }}
.annot-table th, .annot-table td {{ padding: 4px 8px; border: 1px solid #ddd; }}
.annot-table th {{ background: #f0f0f0; }}
.audio-badge  {{ background: #f39c12; color: white; padding: 2px 6px; border-radius: 4px;
                 font-size: 0.75em; margin-left: 8px; }}
.muted        {{ color: #999; font-style: italic; }}
#download-bar {{ position: sticky; top: 0; background: white; padding: 8px 0;
                 border-bottom: 1px solid #ddd; z-index: 100; }}
button        {{ background: #3498db; color: white; border: none; padding: 8px 16px;
                 border-radius: 4px; cursor: pointer; font-size: 1em; }}
button:hover  {{ background: #2980b9; }}
</style>
</head>
<body>
<h1>AViD Phase 2 — Gold Pilot Annotation</h1>
<p>Annotate {len(selected_claims)} claims ({sum(len(ann_units.get(c,[])) for c in selected_claims)} units).
For each unit, watch the video (and listen to audio if present), then answer the support questions.</p>
<div id="download-bar">
  <button onclick="downloadCSV()">⬇ Download annotations (CSV)</button>
  &nbsp;<span id="progress-label"></span>
</div>

{claims_html}

<script>
const ROWS = {js_rows};

function getVal(name) {{
  const el = document.querySelector('input[name="' + name + '"]:checked');
  return el ? el.value : '';
}}

function downloadCSV() {{
  const header = ['claim_id','unit_id',
    'pass1_visual','visual_ocr','visual_other',
    'pass1_audio','audio_speech','audio_other'];
  const lines = [header.join('\\t')];
  for (const row of ROWS) {{
    const cid = row.claim_id;
    const uid = row.unit_id;
    const fid = 'form_' + cid.replace(/-/g,'_') + '_' + uid.replace(/-/g,'_');
    lines.push([
      cid, uid,
      getVal(fid+'_pass1_v'),
      getVal(fid+'_visual_ocr'),
      getVal(fid+'_visual_other'),
      getVal(fid+'_pass1_a'),
      getVal(fid+'_audio_speech'),
      getVal(fid+'_audio_other'),
    ].join('\\t'));
  }}
  const blob = new Blob([lines.join('\\n')], {{type: 'text/tab-separated-values'}});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'gold_annotations.tsv';
  a.click();
}}

// Progress counter
function updateProgress() {{
  let filled = 0;
  for (const row of ROWS) {{
    const cid = row.claim_id;
    const uid = row.unit_id;
    const fid = 'form_' + cid.replace(/-/g,'_') + '_' + uid.replace(/-/g,'_');
    if (getVal(fid+'_pass1_v') && getVal(fid+'_pass1_a')) filled++;
  }}
  document.getElementById('progress-label').textContent =
    filled + ' / ' + ROWS.length + ' units annotated (pass-1)';
}}
document.querySelectorAll('input[type=radio]').forEach(el =>
  el.addEventListener('change', updateProgress));
updateProgress();
</script>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def setup_parser():
    p = argparse.ArgumentParser(
        description="AViD Phase 2 — Step 5: build gold pilot annotation package"
    )
    p.add_argument("--n-claims",        type=int, default=25)
    p.add_argument("--annotation-units", default=DEFAULT_ANN_UNITS)
    p.add_argument("--affordance-tsv",  default=DEFAULT_AFF_TSV)
    p.add_argument("--manifest",        default=DEFAULT_MANIFEST)
    p.add_argument("--video-dir",       default=DEFAULT_VIDEO_DIR)
    p.add_argument("--media-dir",       default=DEFAULT_MEDIA_DIR)
    p.add_argument("--output-dir",      default=DEFAULT_OUTPUT_DIR)
    return p


def main():
    args = setup_parser().parse_args()
    out_dir = Path(args.output_dir)

    print("=" * 60)
    print("AViD Phase 2 — export_gold_pilot.py")
    print(f"  N claims: {args.n_claims}")
    print(f"  Output:   {out_dir}")
    print("=" * 60)

    # 1. Load data
    print("\n[1] Loading data ...")
    manifest   = load_manifest(args.manifest)
    affordance = load_affordance(args.affordance_tsv)
    ann_units  = load_ann_units(args.annotation_units)
    print(f"    Claims: {len(ann_units)}, affordance: {len(affordance)}")

    # 2. Stratified sample
    print(f"\n[2] Stratified sample ({args.n_claims} claims) ...")
    selected = stratified_sample(manifest, ann_units, affordance, args.n_claims)
    print(f"    Selected: {len(selected)} claims")
    n_units = sum(len(ann_units.get(c, [])) for c in selected)
    n_audio = sum(1 for c in selected
                  if manifest.get(c, {}).get("has_audio_modality", False))
    print(f"    Units: {n_units}, audio claims: {n_audio}")

    # 3. Copy media
    print(f"\n[3] Copying media files ...")
    media_out = out_dir / "media"
    media_out.mkdir(parents=True, exist_ok=True)
    video_dir  = Path(args.video_dir)
    media_dir  = Path(args.media_dir)
    n_video = n_wav = 0
    for cid in selected:
        rec = manifest.get(cid, {})
        for chunk_name in rec.get("chunks", []):
            chunk_id = chunk_name.removesuffix(".mp4")
            # Video
            src_mp4 = video_dir / chunk_name
            dst_mp4 = media_out / chunk_name
            if src_mp4.exists() and not dst_mp4.exists():
                shutil.copy2(src_mp4, dst_mp4)
                n_video += 1
            # WAV
            src_wav = media_dir / "wav" / f"{chunk_id}.wav"
            dst_wav = media_out / f"{chunk_id}.wav"
            if src_wav.exists() and not dst_wav.exists():
                shutil.copy2(src_wav, dst_wav)
                n_wav += 1
    print(f"    Copied {n_video} mp4s, {n_wav} wavs")

    # 4. Generate HTML
    print(f"\n[4] Generating index.html ...")
    html_content = generate_html(selected, ann_units, affordance, manifest,
                                 media_rel_dir="media")
    (out_dir / "index.html").write_text(html_content, encoding="utf-8")
    print(f"    Written: {out_dir / 'index.html'}")

    # 5. Generate blank annotation template TSV
    print(f"\n[5] Writing annotation_template.tsv ...")
    tsv_path = out_dir / "annotation_template.tsv"
    cols = ["claim_id", "unit_id", "unit_text", "claim_text", "affordance",
            "pass1_visual", "visual_ocr", "visual_other",
            "pass1_audio", "audio_speech", "audio_other", "notes"]
    with open(tsv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, delimiter="\t",
                           lineterminator="\n", quoting=csv.QUOTE_MINIMAL)
        w.writeheader()
        for cid in selected:
            for unit in ann_units.get(cid, []):
                uid = (unit.get("unit_id") or "").strip()
                w.writerow({
                    "claim_id":    cid,
                    "unit_id":     uid,
                    "unit_text":   (unit.get("unit_text") or "").strip(),
                    "claim_text":  (unit.get("claim_text") or "").strip(),
                    "affordance":  affordance.get(f"{cid}|{uid}", ""),
                    **{c: "" for c in ["pass1_visual", "visual_ocr", "visual_other",
                                        "pass1_audio", "audio_speech", "audio_other", "notes"]},
                })
    print(f"    Written: {tsv_path}")

    # Summary
    print(f"\n{'=' * 40}")
    print(f"Gold pilot package: {out_dir}")
    print(f"  {len(selected)} claims, {n_units} units")
    print(f"  {n_audio} audio-modality claims")
    from collections import Counter
    aff_dist = Counter(
        affordance.get(f"{cid}|{unit.get('unit_id','').strip()}", "unknown")
        for cid in selected
        for unit in ann_units.get(cid, [])
    )
    print(f"  Affordance distribution: {dict(aff_dist.most_common())}")
    print(f"\nDone.")


if __name__ == "__main__":
    main()
