"""Cache dependency/SRL parses for a declared structured-rewrite round."""
import argparse,json
from pathlib import Path
from probabilistic_verification.structured_rewrite import proposal
from probabilistic_verification.parsing import DependencyParser

def main():
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);a=p.parse_args();parser=DependencyParser();rows=[]
 for r in map(json.loads,(a.run/'raw.jsonl').read_text().splitlines()):
  row=dict(claim_id=r['claim_id'],clauses=[])
  try:row['proposal']=proposal(json.loads(r['raw']))
  except Exception as e:row.update(proposal=dict(action='refuse',clauses=[],formula=None),validation_error=str(e))
  for c in row['proposal']['clauses']:
   part=dict(c)
   try:part['record']=dict(claim_id=row['claim_id']+'__'+c['id'],text=c['text'],tokens=parser.parse(c['text']),srl=None)
   except Exception as e:part['parse_error']=str(e)
   row['clauses'].append(part)
  rows.append(row)
 (a.run/'dependencies.jsonl').write_text(''.join(json.dumps(r)+'\n'for r in rows));(a.run/'dependency_provenance.json').write_text(json.dumps(parser.provenance,indent=2)+'\n')
if __name__=='__main__':main()
