"""Compile components, then compare flat conjunction with linked composition."""
import argparse,hashlib,json,time
from pathlib import Path
from problog.program import PrologString
from probabilistic_verification.split_composition import compose_split
from probabilistic_verification.balanced_logic import balanced_prolog_program
from probabilistic_verification.logic import Evidence,ground
from run_content_relations_census import compile_one
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/claim_split_20261112'
def read(p):return list(map(json.loads,p.read_text().splitlines()))
def serialize(claim):
 evidence=Evidence('compilation-check',{v.name:[v.name.lower()]for v in claim.variables},{v.name:True for v in claim.variables},{})
 program,_=balanced_prolog_program([ground(claim,evidence,max_expansions=10000)],learned=False);assert list(PrologString(program))
 return dict(status='compiled',compilation=claim.to_dict(),program=program,program_sha256=hashlib.sha256(program.encode()).hexdigest())
def main():
 global RUN
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,default=RUN);a=p.parse_args();RUN=a.run
 for name,digest in json.loads((RUN/'compiler_freeze.json').read_text())['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
 baseline={r['claim_id']:r for r in read(ROOT/'exp/probabilistic_verification/content_relations_20261105/results.jsonl')};rows=[];started=time.perf_counter()
 for parsed in read(RUN/'parsed.jsonl'):
  cid=parsed['claim_id'];row=dict(claim_id=cid,original=baseline[cid],proposal=parsed['proposal'],components=[],flat=dict(status='unsupported'),linked=dict(status='unsupported'))
  if parsed.get('validation_error'):row['validation_error']=parsed['validation_error']
  for c in parsed['clauses']:
   result=compile_one(c['record'])if 'record'in c else dict(status='unsupported',code='sentence_parse',reason=c['parse_error'])
   row['components'].append(dict(id=c['id'],text=c['text'],result=result))
  if row['proposal']['action']=='split' and not parsed.get('validation_error'):
   parts={c['id']:c['result']for c in row['components']}
   for label,flat in [('flat',True),('linked',False)]:
    try:row[label]=serialize(compose_split(cid+'__'+label,row['proposal'],parts,flat=flat))
    except Exception as e:row[label]=dict(status='unsupported',code=getattr(e,'code',type(e).__name__),reason=str(e))
  rows.append(row)
 (RUN/'results.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows));print('Compiled',len(rows),'cases in',round(time.perf_counter()-started,2),'seconds')
if __name__=='__main__':main()
