#!/usr/bin/env python
"""
AViD — build_affordance_annotation.py

Merges annotation_units.tsv + affordance_rules.jsonl + affordance_llm.jsonl
(and optionally affordance_llm_pass2.jsonl for v2) into affordance_annotation.tsv.

12-column schema:
  claim_id, unit_id, unit_type, node_type, claim_text, unit_text,
  claim_highlighted, gold_channels, notes, pred_rules, pred_llm, pred_llm_prob

Works for any version:
  v0: --affordance-rules v0/affordance_rules.jsonl
      --affordance-llm   v0/affordance_llm.jsonl
  v1: same, different paths
  v2: same as v1 + --affordance-llm-pass2 v2/affordance_llm_pass2.jsonl

For v2, pred_llm uses the fine-grained pass-2 label when available (visual/audio
units), and falls back to the pass-1 coarse label for unverifiable/na units.

Usage:
    python scripts/build_affordance_annotation.py \\
        --annotation-units exp/phase1/reports/annotation_units.tsv \\
        --affordance-rules exp/v1/affordance_rules.jsonl \\
        --affordance-llm   exp/v1/affordance_llm.jsonl \\
        --output           exp/v1/affordance_annotation.tsv

    # v2 (2-pass):
    python scripts/build_affordance_annotation.py \\
        --annotation-units     exp/phase1/reports/annotation_units.tsv \\
        --affordance-rules     exp/phase1/affordance_v2/affordance_rules.jsonl \\
        --affordance-llm       exp/phase1/affordance_v2/affordance_llm_pass1.jsonl \\
        --affordance-llm-pass2 exp/phase1/affordance_v2/affordance_llm_pass2.jsonl \\
        --output               exp/phase1/affordance_v2/affordance_annotation.tsv
"""
import argparse
import csv
import json
import sys
from pathlib import Path

# Default paths (v1)
ANN_UNITS_PATH  = "/exp/cxiao/scale26/avid/exp/phase1/reports/annotation_units.tsv"
RULES_PATH      = "/exp/cxiao/scale26/avid/exp/v1/affordance_rules.jsonl"
LLM_PATH        = "/exp/cxiao/scale26/avid/exp/v1/affordance_llm.jsonl"
OUTPUT_PATH     = "/exp/cxiao/scale26/avid/exp/v1/affordance_annotation.tsv"

FIELDNAMES = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted",
    "gold_channels", "notes", "pred_rules", "pred_llm", "pred_llm_prob",
]


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------

def load_rules(path: str) -> dict[str, dict[str, list[str]]]:
    """Load rules jsonl → {claim_id: {unit_id: [channels]}}."""
    out: dict[str, dict[str, list[str]]] = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            cid = rec["claim_id"]
            # New annotation-units format: "affordance_units"
            if "affordance_units" in rec:
                out[cid] = rec["affordance_units"]
            # Legacy format: "affordance_nodes" + "affordance_factors"
            else:
                merged: dict[str, list[str]] = {}
                merged.update(rec.get("affordance_nodes", {}))
                merged.update(rec.get("affordance_factors", {}))
                out[cid] = merged
    return out


def load_llm(path: str) -> dict[str, dict[str, dict[str, float]]]:
    """Load LLM jsonl → {claim_id: {unit_id: {channel: prob}}}."""
    out: dict[str, dict[str, dict[str, float]]] = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            cid = rec["claim_id"]
            out[cid] = rec.get("affordance_llm_units", {})
    return out


def argmax_dist(dist: dict[str, float]) -> tuple[str, float]:
    """Return (top_label, probability) from a distribution dict."""
    if not dist:
        return "", 0.0
    top = max(dist, key=dist.get)
    return top, round(dist[top], 4)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def setup_parser():
    p = argparse.ArgumentParser(description="Build affordance_annotation.tsv")
    p.add_argument("--annotation-units",     default=ANN_UNITS_PATH)
    p.add_argument("--affordance-rules",     default=RULES_PATH)
    p.add_argument("--affordance-llm",       default=LLM_PATH,
                   help="Pass-1 (or v0/v1) LLM output.")
    p.add_argument("--affordance-llm-pass2", default="",
                   help="(v2 only) Pass-2 fine-grained LLM output. When provided, "
                        "pred_llm uses this for visual/audio units and falls back to "
                        "pass-1 label for unverifiable/na units.")
    p.add_argument("--output",               default=OUTPUT_PATH)
    return p


def main():
    args = setup_parser().parse_args()

    print("=" * 60)
    print("AViD — build_affordance_annotation.py")
    print(f"  Annotation units: {args.annotation_units}")
    print(f"  Rules:            {args.affordance_rules}")
    print(f"  LLM (pass1/v0):   {args.affordance_llm}")
    if args.affordance_llm_pass2:
        print(f"  LLM pass-2:       {args.affordance_llm_pass2}")
    print(f"  Output:           {args.output}")
    print("=" * 60)

    # 1. Load prediction data
    print("\n[1] Loading predictions ...")
    rules_data = load_rules(args.affordance_rules)
    llm_data   = load_llm(args.affordance_llm)
    pass2_data: dict[str, dict[str, dict[str, float]]] = {}
    if args.affordance_llm_pass2:
        pass2_data = load_llm(args.affordance_llm_pass2)

    # 2. Stream annotation_units.tsv and merge
    print("\n[2] Merging and writing output ...")
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    n_rows = 0
    n_rules_hit = 0
    n_llm_hit = 0
    n_pass2_hit = 0

    with open(args.annotation_units, newline="", encoding="utf-8") as in_f, \
         open(out_path, "w", newline="", encoding="utf-8") as out_f:

        reader = csv.DictReader(in_f, delimiter="\t")
        writer = csv.DictWriter(out_f, fieldnames=FIELDNAMES, delimiter="\t",
                                lineterminator="\n")
        writer.writeheader()

        for row in reader:
            cid = row.get("claim_id", "")
            uid = row.get("unit_id", "")
            if not cid or not uid:
                continue  # skip malformed rows (multiline claim_text artifacts)

            # Rules prediction: list → join with |, or empty string
            rules_chs = rules_data.get(cid, {}).get(uid, [])
            pred_rules = "|".join(rules_chs) if rules_chs else ""
            if pred_rules:
                n_rules_hit += 1

            # LLM prediction (pass-1 or v0/v1 distribution)
            llm_dist = llm_data.get(cid, {}).get(uid, {})

            # Pass-2 override for visual/audio units
            p2_dist = pass2_data.get(cid, {}).get(uid, {}) if pass2_data else {}
            if p2_dist:
                # Pass-2 has fine-grained distribution (visual_other/visual_ocr or audio_speech/audio_other)
                pred_llm, pred_llm_prob = argmax_dist(p2_dist)
                n_pass2_hit += 1
            elif llm_dist:
                pred_llm, pred_llm_prob = argmax_dist(llm_dist)
                n_llm_hit += 1
            else:
                pred_llm = ""
                pred_llm_prob = 0.0

            writer.writerow({
                "claim_id":        cid,
                "unit_id":         uid,
                "unit_type":       row.get("unit_type", ""),
                "node_type":       row.get("node_type", ""),
                "claim_text":      row.get("claim_text", ""),
                "unit_text":       row.get("unit_text", ""),
                "claim_highlighted": row.get("claim_highlighted", ""),
                "gold_channels":   row.get("gold_channels", ""),
                "notes":           row.get("notes", ""),
                "pred_rules":      pred_rules,
                "pred_llm":        pred_llm,
                "pred_llm_prob":   f"{pred_llm_prob:.4f}" if pred_llm_prob else "",
            })
            n_rows += 1

    print(f"\n    Rows written:    {n_rows}")
    print(f"    Rules coverage:  {n_rules_hit}/{n_rows} ({100*n_rules_hit/max(1,n_rows):.1f}%)")
    print(f"    LLM coverage:    {n_llm_hit}/{n_rows} ({100*n_llm_hit/max(1,n_rows):.1f}%)")
    if pass2_data:
        print(f"    Pass-2 coverage: {n_pass2_hit}/{n_rows} ({100*n_pass2_hit/max(1,n_rows):.1f}%)")
    print(f"    Output: {out_path}")
    print("\nDone.")


if __name__ == "__main__":
    main()
