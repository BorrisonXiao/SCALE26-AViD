#!/usr/bin/env python3
"""
AViD Phase 3 — Parse Normalization PN-2: LLM-SRL adjunct role typing.

Reads T* v0 (trees_ud_star.jsonl) produced by normalize_parse.py (PN-1).
For each unresolved adjunct edge (bare obl/nmod/advcl with comp=inert-mod,
role=probeable), calls Qwen3-30B with the frozen SRL_ROLE prompt (prompts_phase2.py)
to classify the modifier's semantic role against its predicate.

Applies role → edit rules (deterministic over the role, per impl-plan §3):
  MNR / INS → comp=verif-mod, role=probeable  (soft-gate manner/instrument unit)
  PRP + advcl → comp=core, role=probeable      (purpose clause → necessity)
  TMP        → comp=inert-mod, role=na, probed=False  (temporal NP residue)
  LOC / DIR / CAU / PRP+non-advcl → keep comp=inert-mod, role=probeable
  CORE       → comp=core, role=probeable       (UD-mislabel corrected)
  OTHER      → no change (leave as PN-1 provisional inert-mod)

Emits:
  trees_ud_star.jsonl  (T* v1, overwrites in-place by default)
  pn_roles.jsonl       — per-edge role labels + metadata
  tree_units_ud.tsv    — regenerated probe TSV (pn_unit_text, role-aware)

Cache key: claim_id|node_id|SRL_ROLE_PROMPT_VERSION  (resumable)

Usage (vllm-omni env, A100-40gb GPU node):
    python scripts/run_pn2_srl.py \\
        --input-trees  exp/phase3/trees/trees_ud_star.jsonl \\
        --output-trees exp/phase3/trees/trees_ud_star.jsonl \\
        --output-roles exp/phase3/trees/pn_roles.jsonl \\
        --output-tsv   exp/phase3/nodes/tree_units_ud.tsv \\
        --cache        exp/phase3/trees/pn2_cache.jsonl \\
        --batch-size 64
"""

import argparse
import copy
import csv
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("VLLM_USE_V1", "0")

_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_IN_TREES = str(_AVID / "exp/phase3/trees/trees_ud_star.jsonl")
DEFAULT_OUT_TREES = str(_AVID / "exp/phase3/trees/trees_ud_star.jsonl")
DEFAULT_ROLES = str(_AVID / "exp/phase3/trees/pn_roles.jsonl")
DEFAULT_TSV = str(_AVID / "exp/phase3/nodes/tree_units_ud.tsv")
DEFAULT_CACHE = str(_AVID / "exp/phase3/trees/pn2_cache.jsonl")
MODEL_PATH = "/home/hltcoe/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507"

TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted", "gold_channels", "notes",
]

sys.path.insert(0, str(Path(__file__).parent))
from prompts_phase2 import (
    SRL_ROLE_SYSTEM, SRL_ROLE_USER_TMPL,
    SRL_ROLE_PROMPT_VERSION, SRL_ROLE_LABELS,
    srl_role_user,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Bare deprels eligible for PN-2 SRL typing
PN2_TARGET_DEPRELS = frozenset({"obl", "nmod", "advcl"})

# Role → comp mapping
ROLE_TO_COMP = {
    "MNR": "verif-mod",
    "INS": "verif-mod",
    "PRP": "core",      # advcl only; obl/nmod PRP stays inert-mod (see logic below)
    "TMP": "inert-mod",
    "LOC": "inert-mod",
    "DIR": "inert-mod",
    "CAU": "inert-mod",
    "CORE": "core",
    "OTHER": "inert-mod",
}

# Roles that should make a node non-probed (na)
NA_ROLES = frozenset({"TMP"})

# Roles that upgrade edge to necessity (core); for advcl PRP only
CORE_ROLES_ADVCL = frozenset({"PRP", "CORE"})
CORE_ROLES_ALL = frozenset({"CORE"})

# Default label on parse failure
FALLBACK_LABEL = "OTHER"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def cache_key(claim_id: str, node_id: str) -> str:
    return f"{claim_id}|{node_id}|{SRL_ROLE_PROMPT_VERSION}"


def load_cache(path: str) -> dict[str, dict]:
    cache: dict[str, dict] = {}
    p = Path(path)
    if not p.exists():
        return cache
    for line in open(p, encoding="utf-8"):
        try:
            rec = json.loads(line)
            k = rec.get("_cache_key", "")
            if k:
                cache[k] = rec
        except json.JSONDecodeError:
            pass
    return cache


def parse_role(text: str) -> str:
    """Parse JSON {\"role\": \"MNR\"} from LLM output. Falls back to FALLBACK_LABEL."""
    text = (text or "").strip()
    # Try JSON parse
    try:
        obj = json.loads(text)
        label = (obj.get("role") or "").strip().upper()
        if label in SRL_ROLE_LABELS:
            return label
    except (json.JSONDecodeError, AttributeError):
        pass
    # Try extracting label from raw text (e.g. "{\"role\": \"MNR\"}" with extra whitespace)
    for label in SRL_ROLE_LABELS:
        if f'"{label}"' in text or f"'{label}'" in text:
            return label
    return FALLBACK_LABEL


def highlight_span(claim_text: str, s: int, e: int) -> str:
    if s < 0 or e <= s:
        return claim_text
    s = max(0, s)
    e = min(len(claim_text), e)
    return claim_text[:s] + "**" + claim_text[s:e] + "**" + claim_text[e:]


def get_predicate_text(node: dict, node_by_id: dict[str, dict]) -> str:
    """Return the parent node's text (the predicate for this adjunct)."""
    pid = node.get("parent_id")
    if pid is None:
        return ""
    parent = node_by_id.get(pid, {})
    return parent.get("node_text") or parent.get("pn_unit_text") or ""


def _subtree_has_verb(nid: str, node_by_id: dict[str, dict],
                      seen: set | None = None) -> bool:
    """True if the node's subtree contains a finite-verb / event node — i.e. the unit is
    a CLAUSE ("as rocket lands"), not a bare temporal NP/adverb ("at night"). Used by the
    TMP→na rule (FIX 2026-07-20): a temporal clause with an embedded event stays
    probeable because the event is checkable."""
    if seen is None:
        seen = set()
    if nid in seen:
        return False
    seen.add(nid)
    n = node_by_id.get(nid)
    if not n:
        return False
    if n.get("head_upos") == "VERB" or n.get("node_type") == "event":
        return True
    return any(_subtree_has_verb(c, node_by_id, seen) for c in n.get("children", []))


# ---------------------------------------------------------------------------
# PN-2 target extraction
# ---------------------------------------------------------------------------

def collect_pn2_targets(trees: list[dict]) -> list[dict]:
    """Extract (claim_id, node_id, predicate, modifier, deprel, claim_text) jobs."""
    jobs = []
    for tree in trees:
        cid = tree["claim_id"]
        claim_text = tree["claim_text"]
        node_by_id = {n["node_id"]: n for n in tree["nodes"]}
        for node in tree["nodes"]:
            dep = node.get("deprel", "")
            comp = node.get("comp", "")
            role = node.get("role", "")
            if (dep in PN2_TARGET_DEPRELS
                    and comp == "inert-mod"
                    and role == "probeable"):
                pred_text = get_predicate_text(node, node_by_id)
                mod_text = node.get("pn_unit_text") or node.get("node_text", "")
                jobs.append({
                    "claim_id": cid,
                    "node_id": node["node_id"],
                    "claim_text": claim_text,
                    "predicate": pred_text,
                    "modifier": mod_text,
                    "deprel": dep,
                })
    return jobs


# ---------------------------------------------------------------------------
# Apply role → edit
# ---------------------------------------------------------------------------

def apply_role_edits(trees: list[dict], role_map: dict[str, str]) -> tuple[list[dict], list[dict]]:
    """Apply role→edit rules to trees; return (updated_trees, role_records).

    role_map: {cache_key: role_label}
    role_records: list of {claim_id, node_id, deprel, role, comp_before, comp_after, ...}
    """
    updated_trees = []
    role_records = []
    stats = {"MNR": 0, "INS": 0, "PRP": 0, "TMP": 0, "LOC": 0,
             "DIR": 0, "CAU": 0, "CORE": 0, "OTHER": 0, "MISS": 0}

    for tree in trees:
        t = copy.deepcopy(tree)
        cid = t["claim_id"]
        node_by_id = {n["node_id"]: n for n in t["nodes"]}
        for node in t["nodes"]:
            nid = node["node_id"]
            dep = node.get("deprel", "")
            if (dep not in PN2_TARGET_DEPRELS
                    or node.get("comp") != "inert-mod"
                    or node.get("role") != "probeable"):
                continue

            ck = cache_key(cid, nid)
            if ck not in role_map:
                stats["MISS"] += 1
                continue

            role = role_map[ck]
            stats[role] = stats.get(role, 0) + 1

            comp_before = node["comp"]
            role_before = node["role"]
            probed_before = node.get("probed", True)

            # Determine new comp based on role + deprel
            if role in ("MNR", "INS"):
                new_comp = "verif-mod"
                new_role = "probeable"
                new_probed = True
            elif role == "PRP" and dep == "advcl":
                # Purpose clause (advcl) carrying asserted content → core necessity
                new_comp = "core"
                new_role = "probeable"
                new_probed = True
            elif role == "PRP":
                # Purpose NP (obl/nmod) → keep as probeable entity (inert-mod)
                new_comp = "inert-mod"
                new_role = "probeable"
                new_probed = True
            elif role == "TMP":
                # FIX (2026-07-20): na ONLY a non-clausal temporal (an NP/adverb like
                # "at night", "on Oct 12"). A temporal CLAUSE with an embedded event
                # ("as rocket lands") stays probeable — the event is checkable even if
                # the framing is temporal.
                if _subtree_has_verb(nid, node_by_id):
                    new_comp = "inert-mod"
                    new_role = "probeable"
                    new_probed = True
                else:
                    new_comp = "inert-mod"
                    new_role = "na"
                    new_probed = False
            elif role == "CORE":
                new_comp = "core"
                new_role = "probeable"
                new_probed = True
            else:
                # LOC, DIR, CAU, OTHER → no upgrade; keep inert-mod probeable
                new_comp = "inert-mod"
                new_role = "probeable"
                new_probed = True

            node["comp"] = new_comp
            node["role"] = new_role
            node["probed"] = new_probed
            node["pn_stage"] = "pn2"

            # FIX (2026-07-20): keep the PN-1 case marker (e.g. "by hand") ONLY for
            # MNR/INS manner units; for every other obl/nmod entity the bare NP is the
            # unit ("clear skies" not "with clear skies"; "Western Alaska" not "in
            # Western Alaska"). content_subtree_text excludes the case marker.
            if dep in ("obl", "nmod") and role not in ("MNR", "INS"):
                bare = node.get("content_subtree_text") or node.get("node_text", "")
                if bare:
                    node["pn_unit_text"] = bare
                    node["pn_unit_span"] = (node.get("content_subtree_span")
                                            or node.get("span", [-1, -1]))

            role_records.append({
                "claim_id": cid,
                "node_id": nid,
                "deprel": dep,
                "srl_role": role,
                "comp_before": comp_before,
                "comp_after": new_comp,
                "role_before": role_before,
                "role_after": new_role,
                "predicate": get_predicate_text(
                    node, {n["node_id"]: n for n in t["nodes"]}
                ),
                "modifier": node.get("pn_unit_text") or node.get("node_text", ""),
            })

        updated_trees.append(t)

    print(f"  Role edits: {len(role_records)} edges processed.", file=sys.stderr)
    print(f"  Stats: {stats}", file=sys.stderr)
    return updated_trees, role_records


# ---------------------------------------------------------------------------
# TSV emission
# ---------------------------------------------------------------------------

def write_tsv(trees: list[dict], tsv_path: str) -> int:
    """Write regenerated probe TSV from T* v1. Returns probed count."""
    probed_total = 0
    with open(tsv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=TSV_COLS, delimiter="\t")
        writer.writeheader()
        for tree in trees:
            cid = tree["claim_id"]
            claim_text = tree["claim_text"]
            for node in tree["nodes"]:
                if not node.get("probed"):
                    continue
                unit_text = (node.get("pn_unit_text") or
                             node.get("content_subtree_text") or
                             node.get("node_text", ""))
                unit_span = (node.get("pn_unit_span") or
                             node.get("content_subtree_span") or
                             node.get("span", [-1, -1]))
                s, e = unit_span[0], unit_span[1]
                claim_hl = highlight_span(claim_text, s, e)
                writer.writerow({
                    "claim_id": cid,
                    "unit_id": node["node_id"],
                    "unit_type": "tree_node",
                    "node_type": node.get("node_type", ""),
                    "claim_text": claim_text,
                    "unit_text": unit_text,
                    "claim_highlighted": claim_hl,
                    "gold_channels": "",
                    "notes": "",
                })
                probed_total += 1
    return probed_total


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input-trees", default=DEFAULT_IN_TREES)
    ap.add_argument("--output-trees", default=DEFAULT_OUT_TREES,
                    help="T* v1 output (overwrites input by default).")
    ap.add_argument("--output-roles", default=DEFAULT_ROLES)
    ap.add_argument("--output-tsv", default=DEFAULT_TSV)
    ap.add_argument("--cache", default=DEFAULT_CACHE,
                    help="Resumable LLM role cache (JSONL, append mode).")
    ap.add_argument("--model", default=MODEL_PATH)
    ap.add_argument("--tp", type=int, default=0,
                    help="Tensor-parallel size (0 = auto-detect from CUDA_VISIBLE_DEVICES).")
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--max-tokens", type=int, default=32,
                    help="Max tokens per role call (JSON is short).")
    ap.add_argument("--limit", type=int, default=None,
                    help="Process only the first N claims (smoke test).")
    args = ap.parse_args()

    # ---- Load trees ----
    print("Loading T* v0 trees …", file=sys.stderr)
    trees: list[dict] = []
    with open(args.input_trees, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if args.limit is not None and i >= args.limit:
                break
            trees.append(json.loads(line))
    print(f"  {len(trees)} claims loaded.", file=sys.stderr)

    # ---- Collect PN-2 targets ----
    jobs = collect_pn2_targets(trees)
    print(f"  PN-2 targets: {len(jobs)} adjunct edges to type.", file=sys.stderr)

    # ---- Load cache ----
    cache = load_cache(args.cache)
    print(f"  Cache entries: {len(cache)}", file=sys.stderr)

    # ---- Identify uncached jobs ----
    pending = [j for j in jobs if cache_key(j["claim_id"], j["node_id"]) not in cache]
    print(f"  To run: {len(pending)} (cached: {len(jobs) - len(pending)})", file=sys.stderr)

    # ---- vLLM inference ----
    if pending:
        import torch
        from vllm import LLM, SamplingParams
        from transformers import AutoTokenizer

        tp = args.tp if args.tp > 0 else torch.cuda.device_count()
        print(f"  Loading {args.model} (tp={tp}) …", file=sys.stderr)
        tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
        llm = LLM(
            model=args.model,
            trust_remote_code=True,
            gpu_memory_utilization=0.90,
            tensor_parallel_size=tp,
            dtype="bfloat16",
            seed=42,
            max_model_len=2048,
            disable_log_stats=True,
        )
        sp = SamplingParams(temperature=0.0, max_tokens=args.max_tokens)

        def make_prompt(j: dict) -> str:
            user = srl_role_user(
                claim_text=j["claim_text"],
                predicate=j["predicate"],
                modifier=j["modifier"],
                deprel=j["deprel"],
            )
            msgs = [
                {"role": "system", "content": SRL_ROLE_SYSTEM},
                {"role": "user",   "content": user},
            ]
            return tok.apply_chat_template(
                msgs, tokenize=False, add_generation_prompt=True,
                enable_thinking=False,
            )

        bs = args.batch_size
        n_batches = (len(pending) + bs - 1) // bs
        cache_path = Path(args.cache)
        cache_path.parent.mkdir(parents=True, exist_ok=True)

        with open(cache_path, "a", encoding="utf-8") as cf:
            for b_idx in range(n_batches):
                batch = pending[b_idx * bs: (b_idx + 1) * bs]
                prompts = [make_prompt(j) for j in batch]
                print(f"  [SRL] batch {b_idx + 1}/{n_batches}: {len(batch)} …",
                      file=sys.stderr, flush=True)
                outputs = llm.generate(prompts, sampling_params=sp)
                for j, out in zip(batch, outputs):
                    raw = out.outputs[0].text.strip() if out.outputs else ""
                    role = parse_role(raw)
                    ck = cache_key(j["claim_id"], j["node_id"])
                    entry = {
                        "_cache_key": ck,
                        "claim_id": j["claim_id"],
                        "node_id": j["node_id"],
                        "deprel": j["deprel"],
                        "predicate": j["predicate"],
                        "modifier": j["modifier"],
                        "role": role,
                        "raw": raw,
                    }
                    cf.write(json.dumps(entry, ensure_ascii=False) + "\n")
                    cache[ck] = entry

        print(f"  LLM inference done. {len(pending)} roles generated.", file=sys.stderr)
    else:
        print("  All roles already cached; skipping LLM.", file=sys.stderr)

    # ---- Build role_map {cache_key: role} ----
    role_map: dict[str, str] = {
        k: v["role"] for k, v in cache.items() if "role" in v
    }

    # ---- Apply role edits to T* v0 → T* v1 ----
    print("Applying PN-2 role edits …", file=sys.stderr)
    # Count stats before applying
    verif_mod_before = sum(
        1 for t in trees for n in t["nodes"] if n.get("comp") == "verif-mod"
    )
    core_upgrade_before = sum(
        1 for t in trees for n in t["nodes"]
        if n.get("deprel") in PN2_TARGET_DEPRELS and n.get("comp") == "inert-mod"
    )

    updated_trees, role_records = apply_role_edits(trees, role_map)

    verif_mod_after = sum(
        1 for t in updated_trees for n in t["nodes"] if n.get("comp") == "verif-mod"
    )

    # ---- Write T* v1 ----
    for path in [args.output_trees, args.output_roles, args.output_tsv]:
        Path(path).parent.mkdir(parents=True, exist_ok=True)

    with open(args.output_trees, "w", encoding="utf-8") as f:
        for t in updated_trees:
            f.write(json.dumps(t, ensure_ascii=False) + "\n")
    print(f"  T* v1 → {args.output_trees}", file=sys.stderr)

    # ---- Write pn_roles.jsonl ----
    with open(args.output_roles, "w", encoding="utf-8") as f:
        for rec in role_records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"  Roles log → {args.output_roles} ({len(role_records)} edges)", file=sys.stderr)

    # ---- Write TSV ----
    probed_count = write_tsv(updated_trees, args.output_tsv)
    print(f"  TSV → {args.output_tsv} ({probed_count} probed rows)", file=sys.stderr)

    # ---- Summary ----
    role_dist: dict[str, int] = {}
    for rec in role_records:
        r = rec["srl_role"]
        role_dist[r] = role_dist.get(r, 0) + 1

    comp_changes: dict[str, int] = {}
    for rec in role_records:
        key = f"{rec['comp_before']} → {rec['comp_after']}"
        comp_changes[key] = comp_changes.get(key, 0) + 1

    print(f"\nPN-2 complete: {len(updated_trees)} claims, {len(jobs)} targets",
          file=sys.stderr)
    print(f"  Role distribution:", file=sys.stderr)
    for role, cnt in sorted(role_dist.items(), key=lambda x: -x[1]):
        print(f"    {role:6s}: {cnt}", file=sys.stderr)
    print(f"  Comp changes:", file=sys.stderr)
    for key, cnt in sorted(comp_changes.items(), key=lambda x: -x[1]):
        print(f"    {key}: {cnt}", file=sys.stderr)
    print(f"  verif-mod edges: {verif_mod_before} → {verif_mod_after}", file=sys.stderr)
    print(f"  Probed TSV rows: {probed_count}", file=sys.stderr)


if __name__ == "__main__":
    main()
