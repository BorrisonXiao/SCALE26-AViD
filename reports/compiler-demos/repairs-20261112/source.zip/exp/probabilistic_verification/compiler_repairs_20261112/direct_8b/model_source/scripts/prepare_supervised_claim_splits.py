"""Eight transparent assistant-written splits to test the idea independently of Qwen bookkeeping.

These are controlled development diagnostics, not generated model outputs/gold.
"""
import json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/claim_split_20261112'
def clauses(items):return [dict(id='c'+str(i+1),text=t,parent=p,relation=r,target=target)for i,(t,p,r,target)in enumerate(items)]
def group(*pairs):return dict(mentions=[dict(clause=c,text=t)for c,t in pairs])
def main():
    sub=RUN/'supervised';sub.mkdir(exist_ok=True);original={r['claim_id']:r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())};rows=[]
    drafts={
    'TFgw4IaR9R8s_1587':([('An image depicts Trump.',None,'root',''),('Trump is holding up a signed document.','c1','depiction','Trump')],[group(('c1','Trump'),('c2','Trump'))]),
    'Txf2EdqOg1SQ_2185':([('Meishan Township in Chiayi received 149.0 mm.',None,'root',''),("The day's highest rainfall accumulation was in Meishan Township in Chiayi.",'c1','and','')],[group(('c1','Meishan Township'),('c2','Meishan Township')),group(('c1','Chiayi'),('c2','Chiayi'))]),
    'TgR_u37mCoQ4_1860':([('The second shot shows an emergency vehicle.',None,'root',''),('The emergency vehicle is on the side of the road.','c1','depiction','an emergency vehicle'),("The emergency vehicle's emergency lights are flashing.",'c2','and','')],[group(('c1','an emergency vehicle'),('c2','The emergency vehicle'),('c3','The emergency vehicle'))]),
    'TMrQshDs8aH0_750':([('There are multiple additional police officers.',None,'root',''),('The multiple additional police officers are helping.','c1','and',''),('The multiple additional police officers are clearing space.','c1','and',''),('The multiple additional police officers are in the immediate vicinity of the police van.','c1','and','')],[group(('c1','multiple additional police officers'),('c2','multiple additional police officers'),('c3','multiple additional police officers'),('c4','multiple additional police officers'))]),
    'TW4OYA3RN-Hw_1766':([('A building houses Kantipur Publications.',None,'root',''),('The building is in Kathmandu.','c1','and',''),('The building is on fire.','c1','and','')],[group(('c1','building'),('c2','building'),('c3','building'))]),
    'Txf2EdqOg1SQ_2350':([('Wipha is moving northwest.',None,'root',''),('Wipha is moving at a speed of 20 to 25 km per hour.','c1','and','')],[group(('c1','Wipha'),('c2','Wipha'))]),
    'TFOEIehBwT8Q_504':([('A protester holds a sign.',None,'root',''),('The sign reads, "They shut down my voice without realizing that they would awaken the voice of all of Mexico."','c1','relative','a sign')],[group(('c1','a sign'),('c2','The sign'))]),
    'TgR_u37mCoQ4_1901':([],[])}
    for cid,(items,shared)in drafts.items():
        p=dict(action='split'if items else'refuse',clauses=clauses(items),shared=shared,reason='Assistant-written controlled split; no model call.'if items else'Quantified absence should not be expanded into a positive audio assertion.')
        rows.append(dict(claim_id=cid,raw=json.dumps(p,ensure_ascii=False),author='compiler-author assistant; controlled diagnostic, not a Qwen output'))
    (sub/'raw.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows));shutil.copy2(RUN/'compiler_freeze.json',sub/'compiler_freeze.json')
    (sub/'inputs.jsonl').write_text(''.join(json.dumps(original[r['claim_id']],ensure_ascii=False)+'\n'for r in rows))
    (sub/'protocol.json').write_text(json.dumps(dict(provenance='Purposively chosen8-case assistant-written development diagnostic after inspecting Qwen proposals. Tests whether clean clause decomposition works; no automatic-success claim or independent human gold.',cases=[r['claim_id']for r in rows]),indent=2)+'\n')
    print('Prepared',len(rows),'supervised diagnostics.')
if __name__=='__main__':main()
