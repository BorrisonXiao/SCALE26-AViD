"""Native DeepProbLog gradient check using real cached visual representations.

Four cases from one development clip are deliberately overfit. This checks the
training interface, not accuracy, calibration, or readiness of the full corpus.
"""
import hashlib,itertools,json,math
from pathlib import Path
import torch
from probabilistic_verification.compiler_readiness import compile_ready
from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.feature_classifier import FrozenFeatureSource,FeatureRelationClassifier
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compiler_readiness_20261112'
PILOT=ROOT/'exp/probabilistic_verification/av_features_20261022'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    path=PILOT/'visual_features.pt';before=sha(path);review_path=PILOT/'reviewed_claims.json';review_before=sha(review_path)
    cache=torch.load(path,map_location='cpu',weights_only=True)
    references=json.loads(review_path.read_text());parses={r['claim_id']:r for r in map(json.loads,(RUN/'feature_parsed.jsonl').read_text().splitlines())}
    names={'aircraft_original':'aircraft_gray','aircraft_edit':'aircraft_yellow','bus_original':'bus_yellow','bus_edit':'bus_gray'}
    programs=[];features={};labels={};cases=[]
    for r in references['claims']:
        cid=r['id']
        if cid not in names:continue
        claim,_=compile_ready(parses[cid])
        referent='aircraft'if cid.startswith('aircraft')else'bus_group'
        domains={v.name:[referent if v.kind in{'entity','group'}else
                         referent+'_color_state'if v.kind=='event'else'clip_time']for v in claim.variables}
        evidence=Evidence(references['source_video'],domains,{v.name:True for v in claim.variables},{})
        assignment={k:v[0]for k,v in domains.items()};feature_id='visual__'+names[cid]+'__matched__joint'
        for atom in claim.atoms:
            key=canonical_key(evidence.media_id,atom,assignment,evidence.route)
            # Entity identity and reference time are stipulated for this API check.
            # Only the color relation is learned from media/proposition features.
            learned=atom.predicate=='be'and atom.kind=='relation'
            obs=Observation(key,(1/3,1/3,1/3)if learned else(1.,0.,0.),learned,'Cached feature smoke test')
            evidence.observations[key]=obs
            if learned:
                if obs.id in features and not torch.equal(features[obs.id],cache[feature_id]):
                    raise ValueError('Conflicting representations for one grounded observation.')
                features[obs.id]=cache[feature_id]
        programs.append(ground(claim,evidence));labels[cid]={'S':'supported','R':'refuted'}[r['reference']['visual']]
        cases.append(dict(claim_id=cid,text=r['text'],root_label=labels[cid],feature_id=feature_id,reference=r['reason'],claim=claim.to_dict()))
    assert len(features)==4,'Each color/referent tuple must have its own representation.'
    torch.manual_seed(7);source=FrozenFeatureSource(features);original_features={k:v.clone()for k,v in source.values.items()}
    classifier=FeatureRelationClassifier(4096,64)
    verifier=DirectVerifier(programs,classifier=classifier,feature_source=source,learning_rate=.001)
    initial=verifier.predict();fit=verifier.fit(labels,epochs=30);final=verifier.predict()
    assert fit['parameter_change_l2']>0 and any(g['finite']and g['norm']>0 for g in fit['gradient_checks'])
    assert all(torch.equal(v,original_features[k])and not v.requires_grad for k,v in source.values.items())
    assert sha(path)==before and sha(review_path)==review_before
    nll=lambda rows:sum(-math.log(max(r['distribution'][labels[r['claim_id']]],1e-12))for r in rows)/len(rows)
    assert nll(final)<nll(initial)
    assert all(r['prediction']==labels[r['claim_id']]for r in final)
    (RUN/'feature_smoke_program.pl').write_text(verifier.program)
    torch.save(verifier.classifier.state_dict(),RUN/'feature_smoke_classifier.pt')
    result=dict(purpose='Engineering smoke test and deliberate overfit, not an empirical method result.',source_video=references['source_video'],examples=len(cases),feature_dim=4096,hidden=64,parameters=fit['trainable_parameters'],source_model='Frozen Qwen3-VL-8B-Instruct',feature_description='Last prompt-token decoder state conditioned on proposition and video frames; no answer probabilities or labels as classifier inputs.',network='LayerNorm(4096) -> Linear(4096,64) -> GELU -> Linear(64,3) -> softmax',initial_mean_nll=nll(initial),final_mean_nll=nll(final),initial=initial,final=final,training=fit,features_unchanged=True,reference_file_unchanged=True,audio_used=False,versions=verifier.versions(),feature_sha256=before,reference_sha256=review_before,cases=cases,limits=['One previously inspected development clip; no held-out videos or generalization claim.','Four assistant-reviewed visual color labels are used only for this engineering check; original training-eligibility flags remain false.','Entity identities, candidate inventory and time conditions are stipulated; no evidence alignment learning is demonstrated.','Audio labels remain provisional and excluded. Full-corpus media/feature extraction and empirical binding training have not begun.'])
    (RUN/'feature_training_smoke.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:result[k]for k in ['examples','feature_dim','parameters','initial_mean_nll','final_mean_nll','features_unchanged']})
if __name__=='__main__':main()
