"""Summarize existing failures; no compilation, model calls or new gold labels."""
import hashlib,json
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/report_cleanup_20261112'
SOURCE=ROOT/'exp/probabilistic_verification/split_alignment_20261112'
GROUPS={
    'Parser or compiler cannot form all required predicates': ['unresolved_clause','duplicate_role','missing_predicate','missing_srl','predicate_type','opaque_clause'],
    'Generated structure omits source content': ['coverage_omission'],
    'Unsupported operators or value types': ['negative_quantifier','modal_scope','nominal_disjunction','quantity_type','threshold_scope','polarity_omission','temporal_scope'],
    'Explicit reference or media-context checks': ['mention_alignment','unresolved_controller','media_modifier'],
}


def main():
    RUN.mkdir(parents=True,exist_ok=True)
    rows=list(map(json.loads,(SOURCE/'corpus_reviewed.jsonl').read_text().splitlines()))
    failed=[r for r in rows if r['status']!='compiled']
    tested={r['claim_id']for r in map(json.loads,(SOURCE/'inputs.jsonl').read_text().splitlines())}
    codes=Counter(r['code']for r in failed)
    assert set(codes)=={c for group in GROUPS.values()for c in group}
    groups=[dict(name=name,count=sum(codes[c]for c in values),codes={c:codes[c]for c in values})for name,values in GROUPS.items()]
    assert sum(g['count']for g in groups)==len(failed)==449
    prior=json.loads((ROOT/'exp/probabilistic_verification/compiler_alert_review_20261111/review_annotations.json').read_text())
    assert {r['claim_id']for r in prior['alerts']}=={r['claim_id']for r in failed if 'program'in r}
    evidence=dict(total=len(rows),passes=len(rows)-len(failed),remaining=len(failed),
        failure_rate=len(failed)/len(rows),tested_remaining=sum(r['claim_id']in tested for r in failed),
        untested_remaining=sum(r['claim_id']not in tested for r in failed),tested_originals=len(tested),recoveries=2,
        with_flagged_program=sum('program'in r for r in failed),without_program=sum('program'not in r for r in failed),
        groups=groups,first_failure_codes=dict(codes),
        prior_alert_review=dict(total=len(prior['alerts']),families=dict(Counter(r['family']for r in prior['alerts'])),verdicts=dict(Counter(r['verdict']for r in prior['alerts'])),provenance=prior['provenance']),
        pilot_failure_stages=json.loads((SOURCE/'summary.json').read_text())['sentences']['failures'],
        limits=['Counts are first failing checks, not a complete semantic taxonomy.','Only31 original failures were rewritten;420 of449 remaining failures are untested.','The prior179-alert review was local compiler-author diagnosis, not independent whole-claim correctness.','No new model/GPU/compiler run or semantic accuracy measurement.'])
    evidence['source_sha256']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [SOURCE/'corpus_reviewed.jsonl',SOURCE/'inputs.jsonl',SOURCE/'summary.json']}
    (RUN/'failure_audit.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
    (RUN/'remaining.json').write_text(json.dumps([dict(claim_id=r['claim_id'],text=r['text'],code=r['code'],reason=r['reason'],has_program='program'in r,tested=r['claim_id']in tested)for r in failed],ensure_ascii=False,indent=2)+'\n')
    print('449 remaining =',evidence['tested_remaining'],'tested failures +',evidence['untested_remaining'],'untested;',[(g['count'],g['name'])for g in groups])


if __name__=='__main__':main()
