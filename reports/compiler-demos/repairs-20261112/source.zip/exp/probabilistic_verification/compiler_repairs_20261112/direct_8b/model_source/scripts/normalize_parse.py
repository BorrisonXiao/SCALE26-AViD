#!/usr/bin/env python3
"""
AViD Phase 3 — Parse Normalization (PN-1): deterministic pass.

Reads trees_ud.jsonl (built by build_tree.py) and hypergraph.jsonl (for lemma
info needed in REATTACH). Applies deterministic PN-1 rules (F0+F1):

  TYPE     : obl:tmod / nmod:tmod → comp=inert-mod, role=na, probed=False
  MERGE    : obl/nmod with case/mark child → pn_unit_text = subtree_text (full PP)
  REATTACH : light-verb root with xcomp/ccomp content child → re-root onto predicate

Emits three artifacts:
  trees_ud_star.jsonl  (T* v0) — same schema as trees_ud.jsonl + comp, role,
                                  pn_unit_text, pn_unit_span, pn_stage fields
  pn_edits.jsonl               — per-claim edit log
  tree_units_ud.tsv            — regenerated probe TSV (9-col schema, pn_unit_text)

Usage:
    python scripts/normalize_parse.py \\
        [--trees PATH] [--hypergraph PATH] \\
        [--output-trees PATH] [--output-edits PATH] [--output-tsv PATH] \\
        [--limit N]
"""

import argparse
import copy
import csv
import json
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

IN_TREES = "/exp/cxiao/scale26/avid/exp/phase3/trees/trees_ud.jsonl"
HYPERGRAPH = "/exp/cxiao/scale26/avid/exp/phase1/hypergraph.jsonl"
OUT_TREES = "/exp/cxiao/scale26/avid/exp/phase3/trees/trees_ud_star.jsonl"
OUT_EDITS = "/exp/cxiao/scale26/avid/exp/phase3/trees/pn_edits.jsonl"
OUT_TSV = "/exp/cxiao/scale26/avid/exp/phase3/nodes/tree_units_ud.tsv"

TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted", "gold_channels", "notes",
]

# Light / copular verbs (mirrors LIGHT_VERB_LEMMAS in build_tree.py)
LIGHT_VERB_LEMMAS = frozenset({
    "be", "do", "go", "have", "get", "make",
    "take", "come", "become", "seem", "appear",
})

# Deprels typed as temporal adjuncts → inert-mod / na (F0-resolvable)
TEMPORAL_DEPRELS = frozenset({"obl:tmod", "nmod:tmod"})

# Deprels of case/mark functional tokens
CASE_MARK_DEPRELS = frozenset({"case", "mark"})

# Deprels of content-predicate children eligible for light-verb REATTACH
REATTACH_DEPRELS = frozenset({"xcomp", "ccomp"})

# Bare obl/nmod — subtypes excluded so "obl:tmod" and "obl:agent" don't match
MERGE_TARGET_DEPRELS = frozenset({"obl", "nmod"})

# rel_class → edge composition type (comp) mapping
REL_CLASS_TO_COMP = {
    "root": "root",
    "structural": "drop",
    "core-arg": "core",
    "coordination-and": "coord",
    "coordination-or": "coord",
    "modifier": "inert-mod",
    "oblique": "inert-mod",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def highlight_span(claim_text: str, s: int, e: int) -> str:
    """Wrap [s:e] in ** for claim_highlighted column."""
    if s < 0 or e <= s:
        return claim_text
    s = max(0, s)
    e = min(len(claim_text), e)
    return claim_text[:s] + "**" + claim_text[s:e] + "**" + claim_text[e:]


def _unit_text_for_node(node: dict) -> str:
    """Return the probe unit text before any PN edit (content_subtree_text fallback)."""
    return (node.get("content_subtree_text") or node.get("node_text") or "")


def _unit_span_for_node(node: dict) -> list:
    """Return the probe unit span before any PN edit."""
    sp = node.get("content_subtree_span")
    if sp and sp[0] >= 0:
        return sp
    return node.get("span", [-1, -1])


# ---------------------------------------------------------------------------
# PN-1: deterministic normalisation
# ---------------------------------------------------------------------------

def pn1_deterministic(tree: dict, hg_lemmas: dict[str, str]) -> tuple[dict, list[dict]]:
    """Apply PN-1 deterministic rules to one claim tree.

    Args:
        tree     : tree dict from trees_ud.jsonl
        hg_lemmas: {node_id: lemma} from the corresponding hypergraph record

    Returns:
        (tree_star, edits)
        tree_star — deep copy of tree with comp/role/pn_* fields added/updated
        edits     — list of edit dicts {node_id, edit, detail, ...}
    """
    tree_star = copy.deepcopy(tree)
    edits: list[dict] = []

    nodes = tree_star["nodes"]
    node_by_id: dict[str, dict] = {n["node_id"]: n for n in nodes}

    # ------------------------------------------------------------------
    # Step 1: Initialise comp / role / pn_unit_text for every node
    # ------------------------------------------------------------------
    for node in nodes:
        rel_class = node.get("rel_class", "modifier")
        node["comp"] = REL_CLASS_TO_COMP.get(rel_class, "inert-mod")

        if node.get("is_functional"):
            node["role"] = "op"
        elif not node.get("probed"):
            node["role"] = "na"
        else:
            node["role"] = "probeable"

        node["pn_unit_text"] = _unit_text_for_node(node)
        node["pn_unit_span"] = _unit_span_for_node(node)
        node["pn_stage"] = "pn1"

    # ------------------------------------------------------------------
    # Step 2: TYPE — temporal adjuncts → inert-mod / na / probed=False
    # obl:tmod ×36 and nmod:tmod ×17 in trees_ud.jsonl (F0-resolvable)
    # ------------------------------------------------------------------
    for node in nodes:
        deprel = node.get("deprel", "")
        if deprel not in TEMPORAL_DEPRELS:
            continue
        if node.get("is_functional"):
            continue  # already structural; don't override

        prev = {
            "comp": node["comp"],
            "role": node["role"],
            "probed": node.get("probed", False),
        }
        node["comp"] = "inert-mod"
        node["role"] = "na"
        node["probed"] = False
        edits.append({
            "node_id": node["node_id"],
            "edit": "TYPE",
            "detail": "temporal_adjunct",
            "deprel": deprel,
            "node_text": node.get("node_text", ""),
            "prev": prev,
        })

    # ------------------------------------------------------------------
    # Step 3: MERGE case→head — obl/nmod with a case/mark child
    # Updates pn_unit_text to the full PP (subtree_text) so the bare
    # noun atom is replaced by the preposition-bearing phrase.
    # ------------------------------------------------------------------
    for node in nodes:
        nid = node["node_id"]
        deprel = node.get("deprel", "")

        # Only bare obl/nmod, must be probed content (not already na)
        if deprel not in MERGE_TARGET_DEPRELS:
            continue
        if not node.get("probed"):
            continue
        if node.get("role") == "na":
            continue

        # Find case/mark functional children in the tree
        case_children = [
            node_by_id[cid]
            for cid in node.get("children", [])
            if cid in node_by_id
            and node_by_id[cid].get("deprel") in CASE_MARK_DEPRELS
            and node_by_id[cid].get("is_functional")
        ]
        if not case_children:
            continue

        # Fold ONLY the case/mark marker into the node's TIGHT content span (NOT the full
        # subtree_text, which would swallow trailing nmod/acl children that are their own
        # units). "hand"+case "by" -> "by hand"; tight "typhoon"+"from" -> "from the typhoon".
        css = node.get("content_subtree_span") or node.get("span", [-1, -1])
        if not css or css[0] is None or css[0] < 0 or css[1] <= css[0]:
            continue
        case_starts = [
            c.get("span", [-1, -1])[0] for c in case_children
            if c.get("span") and c["span"][0] is not None and c["span"][0] >= 0
        ]
        new_start = min([css[0]] + case_starts)
        new_end = css[1]
        claim_text = tree_star.get("claim_text", "")
        if not (0 <= new_start < new_end <= len(claim_text)):
            continue
        new_unit_text = claim_text[new_start:new_end]
        prev_unit_text = node["pn_unit_text"]
        if new_unit_text and new_unit_text != prev_unit_text:
            node["pn_unit_text"] = new_unit_text
            node["pn_unit_span"] = [new_start, new_end]
            edits.append({
                "node_id": nid,
                "edit": "MERGE",
                "detail": "case_to_head",
                "deprel": deprel,
                "case_children": [c["node_id"] for c in case_children],
                "prev_unit_text": prev_unit_text,
                "new_unit_text": new_unit_text,
            })

    # ------------------------------------------------------------------
    # Step 4: REATTACH — light-verb root with xcomp/ccomp content child
    # Re-roots the tree onto the content predicate; demotes the light verb.
    # Uses hypergraph lemmas for reliable light-verb detection.
    # ------------------------------------------------------------------
    root_id = tree_star.get("root_id")
    if root_id and root_id in node_by_id:
        root_node = node_by_id[root_id]
        lemma = hg_lemmas.get(root_id, "").lower()

        is_light_verb_root = (
            not root_node.get("probed")
            and not root_node.get("is_functional")
            and root_node.get("head_upos") == "VERB"
            and lemma in LIGHT_VERB_LEMMAS
        )

        if is_light_verb_root:
            # Find the first xcomp/ccomp content child (probed)
            content_child = None
            for cid in root_node.get("children", []):
                if cid not in node_by_id:
                    continue
                child = node_by_id[cid]
                if (child.get("deprel") in REATTACH_DEPRELS
                        and child.get("probed")):
                    content_child = child
                    break

            if content_child is not None:
                new_root_id = content_child["node_id"]

                # 1. New root: detach from old root, become tree root
                content_child["parent_id"] = None
                content_child["comp"] = "root"
                # rel_class stays as-is (was core-arg); comp overrides

                # 2. Old root: demote to child of new root
                root_node["parent_id"] = new_root_id
                root_node["rel_class"] = "modifier"   # was "root"; CRF reads rel_class
                root_node["comp"] = "inert-mod"
                root_node["role"] = "op"
                root_node["probed"] = False

                # 3. Remove content_child from old root's children
                if new_root_id in root_node.get("children", []):
                    root_node["children"].remove(new_root_id)

                # 4. Add old root to new root's children
                new_root_children = content_child.setdefault("children", [])
                if root_id not in new_root_children:
                    new_root_children.append(root_id)

                # 5. Update tree root pointer
                tree_star["root_id"] = new_root_id

                edits.append({
                    "node_id": root_id,
                    "edit": "REATTACH",
                    "detail": "light_verb_root",
                    "old_root": root_id,
                    "new_root": new_root_id,
                    "light_verb_text": root_node.get("node_text", ""),
                    "light_verb_lemma": lemma,
                    "content_deprel": content_child.get("deprel"),
                    "content_text": content_child.get("node_text", ""),
                })

    return tree_star, edits


# ---------------------------------------------------------------------------
# TSV emission (same 9-col schema as build_tree.py)
# ---------------------------------------------------------------------------

def tree_star_tsv_rows(tree_star: dict) -> list[dict]:
    """Emit TSV rows for all probed nodes in T*, using pn_unit_text/span."""
    claim_id = tree_star["claim_id"]
    claim_text = tree_star["claim_text"]
    rows = []
    for node in tree_star["nodes"]:
        if not node.get("probed"):
            continue
        unit_text = node.get("pn_unit_text") or node.get("content_subtree_text") or node.get("node_text", "")
        unit_span = node.get("pn_unit_span") or node.get("content_subtree_span") or node.get("span", [-1, -1])
        s, e = unit_span[0], unit_span[1]
        claim_hl = highlight_span(claim_text, s, e)
        rows.append({
            "claim_id": claim_id,
            "unit_id": node["node_id"],
            "unit_type": "tree_node",
            "node_type": node.get("node_type", ""),
            "claim_text": claim_text,
            "unit_text": unit_text,
            "claim_highlighted": claim_hl,
            "gold_channels": "",
            "notes": "",
        })
    return rows


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--trees", default=IN_TREES,
                    help="Input trees_ud.jsonl (from build_tree.py)")
    ap.add_argument("--hypergraph", default=HYPERGRAPH,
                    help="Input hypergraph.jsonl (for node lemmas)")
    ap.add_argument("--output-trees", default=OUT_TREES,
                    help="Output trees_ud_star.jsonl (T* v0)")
    ap.add_argument("--output-edits", default=OUT_EDITS,
                    help="Output pn_edits.jsonl")
    ap.add_argument("--output-tsv", default=OUT_TSV,
                    help="Output tree_units_ud.tsv (regenerated probe TSV)")
    ap.add_argument("--limit", type=int, default=None,
                    help="Process only the first N claims (for smoke tests).")
    args = ap.parse_args()

    # ---- Load hypergraph lemmas ----
    print("Loading hypergraph lemmas …", file=sys.stderr)
    hg_lemmas_by_claim: dict[str, dict[str, str]] = {}
    with open(args.hypergraph, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            cid = rec["claim_id"]
            hg_lemmas_by_claim[cid] = {
                n["id"]: (n.get("lemma") or "")
                for n in rec.get("nodes", [])
            }
    print(f"  {len(hg_lemmas_by_claim)} claims loaded.", file=sys.stderr)

    # ---- Create output dirs ----
    for path in [args.output_trees, args.output_edits, args.output_tsv]:
        Path(path).parent.mkdir(parents=True, exist_ok=True)

    # ---- Process trees ----
    n_claims = 0
    n_nodes_total = 0
    n_probed_before = 0
    n_probed_after = 0
    edit_counts: dict[str, int] = {}

    with (open(args.trees, encoding="utf-8") as fin,
          open(args.output_trees, "w", encoding="utf-8") as fout_trees,
          open(args.output_edits, "w", encoding="utf-8") as fout_edits,
          open(args.output_tsv, "w", encoding="utf-8", newline="") as fout_tsv):

        writer = csv.DictWriter(fout_tsv, fieldnames=TSV_COLS, delimiter="\t")
        writer.writeheader()

        for line in fin:
            if args.limit is not None and n_claims >= args.limit:
                break
            tree = json.loads(line)
            cid = tree["claim_id"]
            hg_lemmas = hg_lemmas_by_claim.get(cid, {})

            # Count probed nodes before PN-1
            n_probed_before += sum(1 for n in tree["nodes"] if n.get("probed"))

            tree_star, edits = pn1_deterministic(tree, hg_lemmas)

            fout_trees.write(json.dumps(tree_star, ensure_ascii=False) + "\n")
            fout_edits.write(json.dumps(
                {"claim_id": cid, "edits": edits}, ensure_ascii=False
            ) + "\n")

            rows = tree_star_tsv_rows(tree_star)
            for row in rows:
                writer.writerow(row)

            n_claims += 1
            n_nodes_total += len(tree_star["nodes"])
            n_probed_after += sum(1 for n in tree_star["nodes"] if n.get("probed"))
            for e in edits:
                k = e["edit"]
                edit_counts[k] = edit_counts.get(k, 0) + 1

            if n_claims % 500 == 0:
                print(f"  {n_claims} claims …", file=sys.stderr)

    # ---- Summary ----
    type_cnt = edit_counts.get("TYPE", 0)
    merge_cnt = edit_counts.get("MERGE", 0)
    reattach_cnt = edit_counts.get("REATTACH", 0)
    total_edits = sum(edit_counts.values())

    print(f"\nPN-1 complete: {n_claims} claims, {n_nodes_total} nodes", file=sys.stderr)
    print(f"  Probed nodes: {n_probed_before} → {n_probed_after} "
          f"(Δ {n_probed_after - n_probed_before:+d})", file=sys.stderr)
    print(f"  Edits: {total_edits} total", file=sys.stderr)
    print(f"    TYPE     (temporal → inert): {type_cnt}", file=sys.stderr)
    print(f"    MERGE    (case→head, full PP): {merge_cnt}", file=sys.stderr)
    print(f"    REATTACH (light-verb re-root): {reattach_cnt}", file=sys.stderr)
    print(f"  TSV rows (probed): {n_probed_after}", file=sys.stderr)
    print(f"\nOutputs:", file=sys.stderr)
    print(f"  T* v0   : {args.output_trees}", file=sys.stderr)
    print(f"  Edits   : {args.output_edits}", file=sys.stderr)
    print(f"  TSV     : {args.output_tsv}", file=sys.stderr)


if __name__ == "__main__":
    main()
