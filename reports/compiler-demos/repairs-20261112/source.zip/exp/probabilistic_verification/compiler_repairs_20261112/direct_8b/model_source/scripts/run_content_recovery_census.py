#!/usr/bin/env python3
"""Run content recovery on original claims, keeping every candidate and alert."""
import argparse
import json
import time
from collections import Counter
from pathlib import Path

from probabilistic_verification.content_recovery import compile_content_recovery
from run_scope_coverage_census import compile_one as compile_record

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_recovery_20261105'


def compile_one(record):return compile_record(record,compiler=compile_content_recovery)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--development',action='store_true')
    parser.add_argument('--output',type=Path,default=RUN/'results.jsonl')
    args=parser.parse_args();records=list(map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines()))
    if args.development:
        sources={s for c in json.loads((RUN/'sample_manifest.json').read_text())['cases'] for s in c['source_videos']}
        records=[r for r in records if not set(r['source_videos'])&sources]
    start=time.perf_counter();rows=[compile_one(r) for r in records]
    args.output.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    summary=dict(total=len(rows),accepted=sum(r['status']=='compiled' for r in rows),
        executable_candidates=sum('program' in r for r in rows),
        refusal_reasons=dict(Counter(r['code'] for r in rows if r['status']!='compiled')),
        kinds=dict(Counter(r['compilation']['metadata']['kind'] for r in rows if r['status']=='compiled')),
        elapsed_seconds=time.perf_counter()-start)
    args.output.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
