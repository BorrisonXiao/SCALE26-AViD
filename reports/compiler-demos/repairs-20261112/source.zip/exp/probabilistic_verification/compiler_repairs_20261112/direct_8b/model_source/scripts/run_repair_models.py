"""Frozen Qwen comparison: structured sentences, one error retry, direct logical forms."""
import argparse,copy,hashlib,importlib.metadata,json,os,subprocess,time
from pathlib import Path
import torch,xgrammar as xgr
from transformers import AutoTokenizer,AutoModelForCausalLM,Qwen3VLForConditionalGeneration
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.structured_rewrite import SCHEMA,SYSTEM,REVISED_SYSTEM,request
from probabilistic_verification.direct_form_generation import SCHEMA as DIRECT_SCHEMA,SYSTEM as DIRECT_SYSTEM,evaluate as evaluate_direct
from probabilistic_verification.schema_logits import SchemaLogitsProcessor

def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def main():
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--model',choices=['text30b','vl8b'],default='text30b');p.add_argument('--revised',action='store_true');p.add_argument('--skip-direct',action='store_true');p.add_argument('--direct-only',action='store_true');a=p.parse_args();run=a.run.resolve();root=a.root.resolve();source=Path(__file__).resolve().parent;records=read(run/'pilot_inputs.jsonl');routes=[];eligible=[]
 for r in records:
  out=compile_one(r);routes.append(dict(claim_id=r['claim_id'],status=out['status'],code=out.get('code'),reason=out.get('reason')))
  if out['status']!='compiled':eligible.append(r)
 (run/'model_routing.json').write_text(json.dumps(routes,indent=2)+'\n')
 if not eligible:return
 amrs={r['request']['task']['claim_id']:r['raw']for i in range(4)for r in read(root/f'exp/probabilistic_verification/full_compilation_20261029/amr_{i}_raw.jsonl')}
 path=Path('/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507'if a.model=='text30b'else'/exp/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct');torch.set_num_threads(4)
 tok=AutoTokenizer.from_pretrained(path,local_files_only=True,padding_side='left');tok.pad_token=tok.eos_token
 model_config=json.loads((path/'config.json').read_text());vocab_size=model_config.get('vocab_size')or model_config['text_config']['vocab_size']
 compiler=xgr.GrammarCompiler(xgr.TokenizerInfo.from_huggingface(tok,vocab_size=vocab_size))
 grammars={k:compiler.compile_json_schema(s,any_whitespace=False,separators=(',',':'))for k,s in [('rewrite',SCHEMA),('direct',DIRECT_SCHEMA)]}
 smoke=SchemaLogitsProcessor([grammars['rewrite']]);ids=torch.tensor([[0]],device='cuda');smoke(ids,torch.zeros((1,vocab_size),device='cuda'))
 cls=AutoModelForCausalLM if a.model=='text30b'else Qwen3VLForConditionalGeneration
 model=cls.from_pretrained(path,local_files_only=True,dtype=torch.float16,attn_implementation='sdpa',device_map='balanced',max_memory={i:'28GiB'for i in range(torch.cuda.device_count())}).eval()
 config=dict(model=str(path),backend='transformers+xgrammar',dtype='float16',do_sample=False,max_new_tokens=1536,batch_size=4,device_map='balanced',gpu_names=[torch.cuda.get_device_name(i)for i in range(torch.cuda.device_count())],job_id=os.getenv('SLURM_JOB_ID'),torch=torch.__version__,transformers=importlib.metadata.version('transformers'),source_root=str(source),model_config_sha256=hashlib.sha256((path/'config.json').read_bytes()).hexdigest(),eligible=len(eligible),maximum_feedback_retries=1)
 config.update(revised_prompt=a.revised,modality='text only; no media inputs',skip_direct=a.skip_direct,direct_only=a.direct_only)
 (run/'model_config.json').write_text(json.dumps(config,indent=2)+'\n')
 def generate(rows,kind,folder,feedback=None):
  folder.mkdir(exist_ok=True);out=[]
  for start in range(0,len(rows),4):
   batch=rows[start:start+4];messages=[]
   for r in batch:
    data=request(r,amrs.get(r['claim_id']))
    if a.revised:data['direct_compiler_error']=next(x for x in routes if x['claim_id']==r['claim_id'])
    if feedback and r['claim_id']in feedback:
     prior=feedback[r['claim_id']];data['previous_output']=prior['raw'];data['compiler_feedback']=prior['error'];data['instruction']='Revise the original claim using this error. Preserve its meaning; do not delete the troublesome content or invent information.'
    messages.append([dict(role='system',content=(REVISED_SYSTEM if a.revised else SYSTEM)if kind=='rewrite'else DIRECT_SYSTEM),dict(role='user',content=json.dumps(data,ensure_ascii=False,separators=(',',':')))])
   prompts=[tok.apply_chat_template(m,tokenize=False,add_generation_prompt=True)for m in messages];inputs=tok(prompts,padding=True,return_tensors='pt').to(model.get_input_embeddings().weight.device);started=time.perf_counter()
   with torch.inference_mode():outputs=model.generate(**inputs,do_sample=False,num_beams=1,max_new_tokens=1536,logits_processor=[SchemaLogitsProcessor([grammars[kind]]*len(batch))],pad_token_id=tok.pad_token_id)
   elapsed=time.perf_counter()-started
   for r,m,ids in zip(batch,messages,outputs[:,inputs.input_ids.shape[1]:]):
    tokens=ids.tolist()
    if tok.eos_token_id in tokens:tokens=tokens[:tokens.index(tok.eos_token_id)]
    out.append(dict(claim_id=r['claim_id'],messages=m,raw=tok.decode(tokens,skip_special_tokens=True),finish_reason='length'if len(tokens)>=1536 else'stop',output_tokens=len(tokens),batch_seconds=elapsed))
   write(folder/'raw.jsonl',out);print(kind,folder.name,min(start+4,len(rows)),'/',len(rows),'seconds',round(elapsed,2),flush=True)
  return out
 env=dict(os.environ,PYTHONPATH=str(source),PYTHONDONTWRITEBYTECODE='1')
 def evaluate_round(folder):
  commands=[(root/'envs/probabilistic-verification/bin/python',source/'parse_repair_outputs.py','--run',folder),(root/'envs/srl-eval/bin/python',source/'parse_claim_splits.py','--run',folder,'--srl'),(root/'envs/probabilistic-verification/bin/python',source/'evaluate_repair_outputs.py','--run',folder,'--input',run/'pilot_inputs.jsonl')]
  for command in commands:
   done=subprocess.run(list(map(str,command)),cwd=root,env=env,capture_output=True,text=True)
   with(folder/'evaluation.log').open('a')as f:f.write(done.stdout+'\n'+done.stderr+'\n')
   if done.returncode:raise RuntimeError('Evaluation failed: '+str(command)+'; see '+str(folder/'evaluation.log'))
  return read(folder/'pipeline.jsonl')
 if not a.direct_only:
  first_raw=generate(eligible,'rewrite',run/'rewrite_first');first=evaluate_round(run/'rewrite_first');by_raw={r['claim_id']:r for r in first_raw};failed={r['claim_id']:dict(raw=by_raw[r['claim_id']]['raw'],error={k:r['output'].get(k)for k in ['code','reason']})for r in first if r['output']['status']!='compiled'and r['output'].get('code')!='model_refuse'}
  if failed:
   retry_rows=[r for r in eligible if r['claim_id']in failed];generate(retry_rows,'rewrite',run/'rewrite_retry',failed);second=evaluate_round(run/'rewrite_retry');by_second={r['claim_id']:r for r in second}
  else:by_second={}
  write(run/'rewrite_final.jsonl',[dict(by_second.get(r['claim_id'],r),attempt=2 if r['claim_id']in by_second else 1)for r in first])
  if a.skip_direct:
   print('Structured rewrite conditions complete.',flush=True);return
 manifest=json.loads((run/'pilot_manifest.json').read_text());direct_rows=[r for r in eligible if r['claim_id']in manifest['direct_predicate_comparison']];raw=generate(direct_rows,'direct',run/'direct_forms');by_id={r['claim_id']:r for r in direct_rows};out=[]
 for r in raw:
  try:result=evaluate_direct(by_id[r['claim_id']],json.loads(r['raw']))
  except Exception as e:result=dict(status='unsupported',code=getattr(e,'code',type(e).__name__),reason=str(e))
  out.append(dict(claim_id=r['claim_id'],original=by_id[r['claim_id']]['text'],output=result))
 write(run/'direct_forms/pipeline.jsonl',out)
 print('All fixed conditions complete.',flush=True)
if __name__=='__main__':main()
