#!/usr/bin/env python3
"""
AViD Phase 3 — Compositional faithfulness eval.

Question: does the tree-CRF correctly flag perturbed (false-by-construction)
claims as NOT supported, and does it beat a flat whole-claim baseline?

Perturbations (negation / binding / removal) are false claims manufactured from
true ones; gold verdict = "unsupported" by construction.  The natural split is
a control with no gold (want supported = few false flags).

Detection rate = fraction the system labels NOT supported, two ways:
  strict  = fraction verdict == "unsupported"
  lenient = fraction verdict != "supported"  (partial counts as detected)

(The flat baseline is binary supported/unsupported, so strict == lenient there.)

Systems compared:
  CRF  — tree-CRF root_verdict
         natural   from exp/phase3/crf/decomp_m3.jsonl
         perturbed from exp/phase3/perturb_star/decomp_m3_perturb.jsonl
  flat — whole-claim baseline (exp/phase3/baseline/flat_verdicts.jsonl):
         supported iff (visual==yes OR audio==yes)

Outputs: exp/phase3/reports/faithfulness/{summary.md, table.tsv}

Usage:
    python scripts/eval_phase3.py
"""

import argparse
import json
from collections import Counter
from pathlib import Path

_AVID = Path("/exp/cxiao/scale26/avid")

GOLD        = str(_AVID / "exp/phase3/perturb_star/gold.jsonl")
CRF_PERT    = str(_AVID / "exp/phase3/perturb_star/decomp_m3_perturb.jsonl")
CRF_NAT     = str(_AVID / "exp/phase3/crf/decomp_m3.jsonl")
FLAT        = str(_AVID / "exp/phase3/baseline/flat_verdicts.jsonl")
OUT_DIR     = str(_AVID / "exp/phase3/reports/faithfulness")

TREES_PERT  = str(_AVID / "exp/phase3/perturb_star/perturbed_trees.jsonl")


def load_verdicts(path: str) -> dict:
    """{claim_id: root_verdict}."""
    out = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            out[r["claim_id"]] = r.get("root_verdict", "")
    return out


def load_flat(path: str) -> dict:
    out = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            out[r["id"]] = r["flat_verdict"]
    return out


def rate(ids, verdicts, pred):
    """Fraction of ids whose verdict satisfies pred(v); ignores missing ids
    (counted separately by caller)."""
    vals = [verdicts.get(i) for i in ids]
    present = [v for v in vals if v is not None]
    if not present:
        return 0.0, 0, len(vals)
    hit = sum(1 for v in present if pred(v))
    return hit / len(present), len(present), len(vals) - len(present)


def breakdown(ids, verdicts):
    c = Counter()
    miss = 0
    for i in ids:
        v = verdicts.get(i)
        if v is None:
            miss += 1
        else:
            c[v] += 1
    return c, miss


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--gold", default=GOLD)
    ap.add_argument("--crf-perturb", default=CRF_PERT)
    ap.add_argument("--crf-natural", default=CRF_NAT)
    ap.add_argument("--flat", default=FLAT)
    ap.add_argument("--trees-perturb", default=TREES_PERT)
    ap.add_argument("--out-dir", default=OUT_DIR)
    args = ap.parse_args()

    # --- Load ---
    gold_type = {}
    with open(args.gold, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            gold_type[r["perturb_id"]] = r["perturb_type"]

    crf_pert = load_verdicts(args.crf_perturb)
    crf_nat = load_verdicts(args.crf_natural)
    flat = load_flat(args.flat)

    # id sets
    natural_ids = sorted(crf_nat)                       # 2375 natural claims
    ptype_ids = {"negation": [], "binding": [], "removal": []}
    for pid, t in gold_type.items():
        ptype_ids.setdefault(t, []).append(pid)
    for t in ptype_ids:
        ptype_ids[t].sort()
    all_pert_ids = sorted(gold_type)

    is_unsup = lambda v: v == "unsupported"
    not_sup = lambda v: v != "supported"

    # --- Build table ---
    rows = []  # (split, n, crf_strict, crf_lenient, flat_strict, flat_lenient)

    def add_row(label, ids, crf_map):
        cs, cn, cmiss = rate(ids, crf_map, is_unsup)
        cl, _, _ = rate(ids, crf_map, not_sup)
        fs, fn, fmiss = rate(ids, flat, is_unsup)
        fl, _, _ = rate(ids, flat, not_sup)
        rows.append({
            "split": label, "n": len(ids),
            "crf_strict": cs, "crf_lenient": cl,
            "flat_strict": fs, "flat_lenient": fl,
            "crf_present": cn, "crf_missing": cmiss,
            "flat_present": fn, "flat_missing": fmiss,
        })

    add_row("natural", natural_ids, crf_nat)
    for t in ["negation", "binding", "removal"]:
        add_row(t, ptype_ids[t], crf_pert)
    add_row("ALL-perturbed", all_pert_ids, crf_pert)

    # --- 3-way verdict breakdowns (for context) ---
    bd = {}
    bd["natural"] = breakdown(natural_ids, crf_nat)
    for t in ["negation", "binding", "removal"]:
        bd[t] = breakdown(ptype_ids[t], crf_pert)
    bd["ALL-perturbed"] = breakdown(all_pert_ids, crf_pert)

    flat_bd = {}
    flat_bd["natural"] = breakdown(natural_ids, flat)
    for t in ["negation", "binding", "removal"]:
        flat_bd[t] = breakdown(ptype_ids[t], flat)
    flat_bd["ALL-perturbed"] = breakdown(all_pert_ids, flat)

    # --- Complementarity: CRF catches vs flat, on perturbed (lenient) ---
    both = crf_only = flat_only = neither = 0
    for pid in all_pert_ids:
        c = crf_pert.get(pid)
        fv = flat.get(pid)
        c_det = (c is not None and c != "supported")
        f_det = (fv is not None and fv != "supported")
        if c_det and f_det:
            both += 1
        elif c_det:
            crf_only += 1
        elif f_det:
            flat_only += 1
        else:
            neither += 1

    # --- Example rows (deterministic) ---
    # Load perturbed claim texts for readability.
    ptext = {}
    with open(args.trees_perturb, encoding="utf-8") as f:
        for line in f:
            t = json.loads(line)
            ptext[t["claim_id"]] = t.get("claim_text", "")

    examples = []
    # 1) the requested known negation example
    for want in ["TInVWzp25aIM_2__neg"]:
        if want in gold_type:
            examples.append(want)
    # 2) first diverging case per type where CRF detects (lenient) but flat misses
    for t in ["negation", "binding", "removal"]:
        for pid in ptype_ids[t]:
            if pid in examples:
                continue
            c = crf_pert.get(pid)
            fv = flat.get(pid)
            if c is not None and c != "supported" and fv == "supported":
                examples.append(pid)
                break

    ex_rows = []
    for pid in examples:
        ex_rows.append({
            "perturb_id": pid,
            "perturb_type": gold_type.get(pid),
            "claim_text": ptext.get(pid, ""),
            "gold": "unsupported",
            "crf_verdict": crf_pert.get(pid),
            "flat_verdict": flat.get(pid),
        })

    # --- Write table.tsv ---
    Path(args.out_dir).mkdir(parents=True, exist_ok=True)
    tsv_path = str(Path(args.out_dir) / "table.tsv")
    with open(tsv_path, "w", encoding="utf-8") as f:
        f.write("split\tn\tCRF_strict\tCRF_lenient\tflat_strict\tflat_lenient\n")
        for r in rows:
            f.write(f"{r['split']}\t{r['n']}\t"
                    f"{r['crf_strict']:.3f}\t{r['crf_lenient']:.3f}\t"
                    f"{r['flat_strict']:.3f}\t{r['flat_lenient']:.3f}\n")

    # --- Write summary.md ---
    md_path = str(Path(args.out_dir) / "summary.md")
    L = []
    L.append("# AViD Phase 3 — Compositional Faithfulness\n")
    L.append("**Question.** Do perturbed (false-by-construction) claims get flagged "
             "NOT supported by the tree-CRF, and does the CRF beat a flat "
             "whole-claim baseline?\n")
    L.append("Perturbations manufacture a false claim from a true one "
             "(negation / entity-swap *binding* / argument *removal*); "
             "**gold verdict = unsupported** for all of them. `natural` is a "
             "control (want supported — few false flags).\n")
    L.append("- **Detection rate** = fraction labeled NOT supported.")
    L.append("- **strict** = verdict == `unsupported`; **lenient** = verdict != "
             "`supported` (i.e. `partial` also counts as detected).")
    L.append("- Flat baseline is binary (`supported` iff visual==yes OR audio==yes), "
             "so its strict == lenient.\n")

    # main table
    L.append("## Table\n")
    L.append("For perturbed rows the cells are **detection rates** (higher = better). "
             "For the `natural` row they are **false-flag rates** (lower = better); "
             "the natural supported-rate = 1 − lenient.\n")
    L.append("| split | n | CRF strict | CRF lenient | flat strict | flat lenient |")
    L.append("|---|---:|---:|---:|---:|---:|")
    for r in rows:
        L.append(f"| {r['split']} | {r['n']} | {r['crf_strict']:.1%} | "
                 f"{r['crf_lenient']:.1%} | {r['flat_strict']:.1%} | "
                 f"{r['flat_lenient']:.1%} |")
    L.append("")

    # natural supported-rate note
    nat = rows[0]
    L.append(f"**Natural control** — supported-rate: "
             f"CRF = {1-nat['crf_lenient']:.1%} (1 − lenient), "
             f"flat = {1-nat['flat_lenient']:.1%}. "
             f"CRF 3-way: {dict(bd['natural'][0])}.\n")

    # 3-way CRF breakdown per split
    L.append("## CRF 3-way verdict breakdown\n")
    L.append("| split | n | supported | partial | unsupported | missing |")
    L.append("|---|---:|---:|---:|---:|---:|")
    order = ["natural", "negation", "binding", "removal", "ALL-perturbed"]
    for s in order:
        c, miss = bd[s]
        tot = sum(c.values())
        sup = c.get("supported", 0)
        par = c.get("partially_supported", 0)
        uns = c.get("unsupported", 0)
        n = tot + miss
        def pct(x):
            return f"{x} ({x/n:.1%})" if n else str(x)
        L.append(f"| {s} | {n} | {pct(sup)} | {pct(par)} | {pct(uns)} | {miss} |")
    L.append("")

    # complementarity
    L.append("## CRF vs flat on perturbed detection (lenient = not-supported)\n")
    L.append(f"- both detect: {both} ({both/len(all_pert_ids):.1%})")
    L.append(f"- CRF only (flat misses): {crf_only} ({crf_only/len(all_pert_ids):.1%})")
    L.append(f"- flat only (CRF misses): {flat_only} ({flat_only/len(all_pert_ids):.1%})")
    L.append(f"- neither: {neither} ({neither/len(all_pert_ids):.1%})\n")

    # examples
    L.append("## Example rows (perturbed → gold=unsupported)\n")
    L.append("| perturb_id | type | claim text | CRF | flat |")
    L.append("|---|---|---|---|---|")
    for e in ex_rows:
        txt = e["claim_text"].replace("|", "\\|")
        L.append(f"| {e['perturb_id']} | {e['perturb_type']} | {txt} | "
                 f"{e['crf_verdict']} | {e['flat_verdict']} |")
    L.append("")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")

    # --- Console report ---
    print("=" * 74)
    print("COMPOSITIONAL FAITHFULNESS")
    print("=" * 74)
    hdr = f"{'split':14s} {'n':>5s}  {'CRF-str':>8s} {'CRF-len':>8s}  {'flat-str':>8s} {'flat-len':>8s}"
    print(hdr)
    print("-" * len(hdr))
    for r in rows:
        print(f"{r['split']:14s} {r['n']:5d}  "
              f"{r['crf_strict']:8.1%} {r['crf_lenient']:8.1%}  "
              f"{r['flat_strict']:8.1%} {r['flat_lenient']:8.1%}")
    print()
    print(f"Natural supported-rate: CRF={1-nat['crf_lenient']:.1%}  flat={1-nat['flat_lenient']:.1%}")
    print(f"CRF natural 3-way: {dict(bd['natural'][0])}")
    print()
    print("Perturbed detection complementarity (lenient):")
    print(f"  both={both}  CRF-only={crf_only}  flat-only={flat_only}  neither={neither}")
    print()
    print("Examples:")
    for e in ex_rows:
        print(f"  [{e['perturb_type']:8s}] {e['perturb_id']}")
        print(f"      '{e['claim_text']}'")
        print(f"      gold=unsupported  CRF={e['crf_verdict']}  flat={e['flat_verdict']}")
    print()
    # coverage sanity
    print("Coverage:")
    for r in rows:
        print(f"  {r['split']:14s} crf_present={r['crf_present']}/{r['n']} "
              f"(missing {r['crf_missing']})  flat_present={r['flat_present']}/{r['n']} "
              f"(missing {r['flat_missing']})")
    print(f"\nWrote:\n  {tsv_path}\n  {md_path}")


if __name__ == "__main__":
    main()
