"""Align compiled subclaims to original noun and event mentions.

This is a conservative text alignment step, not an equivalence checker. It never
uses model-generated shared IDs, labels, reference readings or media evidence.
"""
import copy
import json
import re
from collections import defaultdict
from .split_composition import compose_split, fail, nodes
from .logical_form_v2 import ScopedCompiler
from .normalize_form_v2 import MEDIA as MEDIA_PATTERN

MEDIA = {'image', 'photo', 'photograph', 'picture', 'shot', 'video', 'frame'}
SOURCE_VERBS = {'depict', 'show', 'display', 'feature', 'illustrate', 'portray', 'present'}


def lemma(token):
    return token.get('lemma', token['text']).casefold()


def is_source_mention(token,tokens):
    """Identify a source use, not every occurrence of a media noun.

    A livestream broadcast by a camera is an object of broadcast, whereas a clip
    that shows an event or a map that shows seats supplies depicted content.
    """
    parent=next((t for t in tokens if t['id']==token['head']),None)
    subject=token['deprel'].startswith('nsubj') and parent and lemma(parent)in SOURCE_VERBS
    media=lemma(token)in MEDIA or MEDIA_PATTERN.fullmatch(lemma(token))
    if subject:return True
    if not media:return False
    children=[t for t in tokens if t['head']==token['id']]
    return token['head']==0 or any(t['deprel'].startswith('acl')for t in children)or any(t['deprel']=='case'and lemma(t)=='in'for t in children)


def head_for(entity, tokens):
    match = re.fullmatch(r'x(\d+)', entity['id'])
    if match:
        return next((t for t in tokens if t['id'] == int(match[1])), None)
    # Compilers can assign a non-numeric ID to an appositive/name span. Recover
    # its UD head from the contiguous token span rather than guessing the last word.
    target=re.findall(r'\w+|[^\w\s]',entity['text'].casefold())
    for start in range(len(tokens)):
        words=[]
        for end in range(start,len(tokens)):
            words.extend(re.findall(r'\w+|[^\w\s]',tokens[end]['text'].casefold()))
            if words==target:
                span=tokens[start:end+1];ids={t['id']for t in span}
                heads=[t for t in span if t['head']not in ids and t['upos'] in {'NOUN','PROPN','PRON','NUM'}]
                if len(heads)==1:return heads[0]
            if len(words)>=len(target):break
    words = entity['text'].casefold().split()
    hits = [t for t in tokens if t['text'].casefold() in words and t['upos'] in {'NOUN','PROPN','PRON'}]
    return hits[0] if len(hits) == 1 else None


def align(original, clauses, components):
    """Return an ordinary clause proposal plus an inspectable alignment record."""
    original_tokens = original['tokens']
    groups = defaultdict(list)
    entity_anchor = {}
    event_anchor = {}
    event_trace = []
    event_reference_trace=[]
    prepared = copy.deepcopy(components)
    forms = {}
    for clause in clauses:
        cid = clause['id']
        row = prepared[cid]
        if row['status'] != 'compiled':
            fail('component_refusal', cid + ': ' + row.get('reason', row.get('code','refused')))
        form = row['compilation']['metadata']['logical_form']
        forms[cid] = form
        tokens = row['compilation']['tokens']
        for entity in form['entities']:
            head = head_for(entity, tokens)
            if not head:
                fail('entity_alignment', 'No unique compiled noun head: '+cid+'/'+entity['text'])
            candidates = [t for t in original_tokens if t['upos'] in {'NOUN','PROPN','PRON','NUM'} and lemma(t)==lemma(head)]
            if not candidates and original.get('compiler_options',{}).get('event_coreference')and head['upos']=='NOUN':
                from nltk.corpus import wordnet
                related={l.name().replace('_',' ')for syn in wordnet.synsets(lemma(head),pos=wordnet.NOUN)
                         for noun in syn.lemmas()for l in noun.derivationally_related_forms()if l.synset().pos()=='v'}
                source_events=[t for t in original_tokens if t['upos']=='VERB'and lemma(t)in related]
                earlier=[]
                if len(source_events)==1:
                    predicate=lemma(source_events[0])
                    for prior in clauses[:clauses.index(clause)]:
                        root=forms[prior['id']]['formula']
                        affirmative=root.get('children',[])if root.get('op')=='and'else[root]
                        earlier.extend((prior['id'],n)for n in affirmative if n.get('op')=='event'and n['predicate']==predicate)
                if len(earlier)==1:
                    part,event=earlier[0];entity['event_ref']=part+'/'+event['id']
                    candidates=source_events
                    event_reference_trace.append(dict(clause=cid,mention=entity['text'],event_clause=part,event=event['id'],original_token=source_events[0]['id'],basis='Unique derivational verb and earlier affirmative event'))
            if original.get('compiler_options',{}).get('participant_identifiers'):
                from .compiler_extensions import participant_identifier
                ident=participant_identifier(head,tokens,entity)
                if ident is not None:
                    candidates=[t for t in candidates if participant_identifier(t,original_tokens)==ident]
            if len(candidates) != 1:
                fail('entity_alignment', 'Original noun head is absent or ambiguous: '+cid+'/'+entity['text'])
            anchor = candidates[0]['id']
            entity_anchor[cid,entity['id']] = anchor
            groups[anchor].append((cid,entity))
        for event in [n for n in nodes(form) if n.get('op')=='event']:
            candidates = [t for t in original_tokens if t['upos'] in {'VERB','AUX','ADJ'} and lemma(t)==event['predicate'].casefold()]
            if len(candidates)==1 and event['predicate']!='be':
                event_anchor[cid,event['id']] = candidates[0]['id']
            event_trace.append(dict(clause=cid,event=event['id'],predicate=event['predicate'],
                original_token=candidates[0]['id'] if len(candidates)==1 else None))
    shared = []
    for anchor, members in groups.items():
        if len({cid for cid,_ in members})<2:
            continue
        if len({cid for cid,_ in members})!=len(members):
            fail('entity_alignment', 'Two compiled entities in one clause map to one original mention.')
        # Different descriptions may be compatible when they refer to the same
        # original noun: e.g., additional police officers / police officers.
        # Only simple, source-anchored properties are combined. More complex
        # relative clauses and relations keep the previous conservative checks.
        signatures = [json.dumps({k:v for k,v in e.items() if k not in {'id','text','properties'}},sort_keys=True) for _,e in members]
        props = []
        for _, entity in members:
            for prop in entity.get('properties',[]):
                if prop not in props:
                    props.append(prop)
        if len(set(signatures))==1:
            source_words={t['text'].casefold() for t in original_tokens if t['id']==anchor or
                          (t['head']==anchor and t['deprel'] in {'amod','compound','nummod','flat','flat:name'})}
            if any(str(p['value']).casefold() not in source_words for p in props):
                fail('description_alignment','A shared property is not anchored in the original text.')
            spelling = members[0][1]['text']
            for _,entity in members:
                entity['text']=spelling
                if props:entity['properties']=copy.deepcopy(props)
                else:entity.pop('properties',None)
        shared.append(dict(mentions=[dict(clause=cid,text=e['text']) for cid,e in members]))
    proposal=dict(action='split',clauses=[dict(id=c['id'],text=c['text'],parent='c1' if i else None,
        relation='and' if i else 'root',target='') for i,c in enumerate(clauses)],shared=shared,
        reason='Links inferred from unique original mentions, not generated by the model.')
    if original.get('compiler_options',{}).get('logical_operators')and len(clauses)==2:
        from .scoped_srl import quoted_spans
        disjunctions=[t for t in original_tokens if lemma(t)=='or'and not any(lo<=t.get('start_char',-1)<hi for lo,hi,_ in quoted_spans(original['text']))]
        if len(disjunctions)==1 and re.match(r'^\s*Or\b',clauses[1]['text'],re.I):
            proposal['formula']=dict(op='or',children=[1,2])
    media = [t for t in original_tokens if t['upos']in {'NOUN','PROPN'} and is_source_mention(t,original_tokens)]
    if media:
        if len(media)!=1:
            fail('source_alignment','Multiple original media descriptions need an explicit disambiguation.')
        source=media[0]['id']
        frames=[]
        for cid,form in forms.items():
            root=form['formula']
            if root.get('op')=='event' and root['predicate'] in SOURCE_VERBS:
                if any(entity_anchor.get((cid,eid))==source for eid in root['arguments'].values() if isinstance(eid,str)):
                    focal=[n['ref'] for p in root.get('propositions',[]) for n in nodes(p['body']) if n.get('op')=='entity']
                    focal += [eid for role,eid in root['arguments'].items() if role!='ARG0' and isinstance(eid,str)]
                    if len(focal)==1:frames.append((cid,focal[0]))
        if len(frames)!=1:
            fail('source_alignment','No unique simple source sentence for the original media description.')
        parent,focal=frames[0]
        if parent!=clauses[0]['id']:
            fail('source_alignment','Source sentence must precede its content.')
        target=next(e['text'] for e in forms[parent]['entities'] if e['id']==focal)
        for c in proposal['clauses'][1:]:
            c.update(parent=parent,relation='depiction',target=target)
    # A modifier predicate such as signed is a description of its original noun,
    # not an independent action by a newly guessed subject.
    by_original={t['id']:t for t in original_tokens}
    for c in proposal['clauses'][1:]:
        root=forms[c['id']]['formula']
        anchor=event_anchor.get((c['id'],root.get('id')))
        token=by_original.get(anchor,{})
        if token.get('deprel') in {'amod','acl','acl:relcl'} and by_original.get(token.get('head'),{}).get('upos') in {'NOUN','PROPN'}:
            noun=token['head']
            child_mentions={entity_anchor[c['id'],eid] for n in nodes(root) for eid in n.get('arguments',{}).values() if isinstance(eid,str) and (c['id'],eid) in entity_anchor}
            if noun not in child_mentions:
                continue
            earlier=[(cid,e) for cid,e in groups.get(noun,[]) if next(i for i,x in enumerate(clauses) if x['id']==cid)<next(i for i,x in enumerate(clauses) if x['id']==c['id'])]
            if earlier:
                parent,e=earlier[-1]
                c.update(parent=parent,relation='relative',target=e['text'])
    trace=dict(entities=[dict(original_token=a,original_text=by_original[a]['text'],mentions=[dict(clause=c,entity=e['id'],text=e['text']) for c,e in ms])for a,ms in groups.items()],events=event_trace)
    if event_reference_trace:trace['event_references']=event_reference_trace
    return proposal,prepared,trace,event_anchor


def compose_aligned(claim_id, original, clauses, components,*,max_clauses=8,formula=None):
    proposal,prepared,trace,anchors=align(original,clauses,components)
    if formula is not None:proposal['formula']=copy.deepcopy(formula)
    claim=compose_split(claim_id,proposal,prepared,max_clauses=max_clauses)
    # Merge only affirmative sibling events assigned to one original predicate.
    # Conflicting roles, separate contexts and negation are never collapsed.
    offsets={};offset=0
    global_anchors={}
    for c in clauses:
        cid=c['id'];offsets[cid]=offset
        for (part,event),anchor in anchors.items():
            if part==cid:
                match=re.fullmatch(r'e(\d+)',event)
                if match:global_anchors['e'+str(offset+int(match[1]))]=anchor
        offset+=max(t['id'] for t in components[cid]['compilation']['tokens'])
    merges=[]
    def combine(node):
        if not isinstance(node,dict):return node
        node={k:([combine(x)for x in v]if isinstance(v,list)else combine(v)if isinstance(v,dict)else v) for k,v in node.items()}
        if node.get('op')!='and':return node
        seen={};kept=[]
        for child in node['children']:
            anchor=global_anchors.get(child.get('id')) if child.get('op')=='event' else None
            key=(anchor,child.get('predicate'))
            if anchor is None or key not in seen:
                kept.append(child)
                if anchor is not None:seen[key]=child
                continue
            first=seen[key]
            if first.get('propositions') or child.get('propositions'):
                fail('event_alignment','Repeated events with embedded contexts need separate alignment.')
            for role,value in child['arguments'].items():
                if role in first['arguments'] and first['arguments'][role]!=value:
                    fail('event_alignment','Repeated original event has conflicting '+role+' arguments.')
                first['arguments'][role]=value
            for prop in child.get('properties',[]):
                if prop not in first.setdefault('properties',[]):first['properties'].append(prop)
            merges.append(dict(original_token=anchor,first=first['id'],second=child['id']))
        return kept[0]if len(kept)==1 else dict(op='and',children=kept)
    form=copy.deepcopy(claim.metadata['logical_form']);form['formula']=combine(form['formula'])
    if merges:
        kinds={n['kind']for n in nodes(form)if 'kind'in n and 'body'in n}
        claim=ScopedCompiler().compile(claim_id,claim.text,list(claim.tokens),form,additional_proposition_kinds=kinds)
        # Repeated surface anchors cannot currently recover tense reliably.
        # Refuse rather than silently accept loss of an explicit time condition.
        from .semantic import temporal_features
        for merge in merges:
            time=temporal_features(original['tokens'],merge['original_token'])
            if time['tense']!='unspecified' or time['aspect']!='simple':
                fail('event_time_alignment','Event identity aligned, but repeated-clause tense needs an original-token time attachment.')
    trace['event_merges']=merges
    claim.metadata['original_alignment']=trace
    claim.metadata['split_composition']=dict(flat=False,clauses=proposal['clauses'],shared=proposal['shared'])
    return claim,proposal,trace
