#!/usr/bin/env python
"""
AViD Phase 1 — Step 3 V1: Lexicon+rules affordance prior (hard channel set).

Reads hypergraph.jsonl and assigns each lexical unit a set of evidence channels
from the 6-way label space:
    {visual_other, visual_ocr, audio_speech, audio_other, unverifiable,
     na}

  na: the unit cannot be presented to an annotator as a standalone
  item — it is a relational/function verb (copular "be", causal "cause", etc.)
  or an expletive pronoun (existential "there", pleonastic "it").

When --annotation-units is provided, processes rows from annotation_units.tsv
(phrase_entity / node / factor rows) instead of raw hypergraph nodes/factors.
Output is keyed by unit_id.  When not provided, falls back to the original
per-node/factor output keyed by node_id / factor_id.

Usage:
    # new mode (annotation units):
    python affordance_rules.py \\
        --annotation-units exp/phase1/reports/annotation_units.tsv \\
        --output exp/phase1/affordance_rules_units.jsonl

    # legacy mode (hypergraph nodes/factors):
    python affordance_rules.py
    python affordance_rules.py --hypergraph <path> --output <path>
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Dict, FrozenSet, List, Optional, Tuple

# -- Default paths -----------------------------------------------------------
HYPERGRAPH_PATH   = "/exp/cxiao/scale26/avid/exp/phase1/hypergraph.jsonl"
OUTPUT_PATH       = "/exp/cxiao/scale26/avid/exp/phase1/affordance_rules.jsonl"
OUTPUT_UNITS_PATH = "/exp/cxiao/scale26/avid/exp/phase1/affordance_rules_units.jsonl"
BRYSBAERT_PATH    = "/exp/cxiao/scale26/avid/data/brysbaert_concreteness.csv"
LEXICON_DIR       = Path(__file__).parent / "lexicons"
NLTK_DATA_DIR     = "/home/hltcoe/cxiao/nltk_data"

# -- Channel labels ----------------------------------------------------------
CHANNELS = ("visual_other", "visual_ocr", "audio_speech", "audio_other",
            "unverifiable", "na")

# -- na detection constants ------------------------------------
# Copular/existential "be": functional verb — demoted in annotation_units too.
_COPULA_LEMMAS = frozenset({"be"})

# Expletive deprel: existential "there", pleonastic "it".
_EXPLETIVE_DEPREL = "expl"

# -- WordNet supersenses for each channel ------------------------------------
VISUAL_OTHER_NOUN_SS = frozenset({
    "noun.artifact", "noun.animal", "noun.person", "noun.body",
    "noun.food", "noun.plant", "noun.object", "noun.location",
    "noun.quantity",   # physical quantities
})
VISUAL_OTHER_VERB_SS = frozenset({
    "verb.motion", "verb.contact", "verb.body", "verb.competition",
    "verb.change",     # physical change
    "verb.possession", # physical exchange
})
UNVERIFIABLE_NOUN_SS = frozenset({
    "noun.cognition", "noun.feeling", "noun.state", "noun.motive",
    "noun.act",        # abstract acts
    "noun.attribute",  # abstract attributes
})
AUDIO_OTHER_NOUN_SS = frozenset({
    "noun.phenomenon",  # includes natural sound phenomena
    "noun.event",       # sudden events often have sound
})

# Brysbaert threshold for visual_other
CONCRETENESS_THRESHOLD = 3.5


# -- Lexicon loading ---------------------------------------------------------

def load_lexicon_file(path: Path) -> frozenset[str]:
    """Load a lexicon text file; one lemma/phrase per line, # = comment."""
    words = set()
    if not path.exists():
        print(f"  WARNING: lexicon not found: {path}", file=sys.stderr)
        return frozenset()
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                words.add(line.lower())
    return frozenset(words)


def load_brysbaert(path: str) -> dict[str, float]:
    """Load Brysbaert concreteness norms CSV → {word: mean_concreteness}."""
    if not Path(path).exists():
        print(f"  WARNING: Brysbaert CSV not found at {path}. "
              "Run setup_env.sh to fetch it.", file=sys.stderr)
        return {}
    import csv
    ratings = {}
    with open(path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Column name varies by source; try common variants
            word = (row.get("Word") or row.get("word") or "").lower().strip()
            val  = row.get("Conc.M") or row.get("conc.m") or row.get("Rating") or ""
            try:
                ratings[word] = float(val)
            except (ValueError, TypeError):
                pass
    return ratings


def load_wordnet(nltk_data_dir: str):
    """Load NLTK WordNet; returns the wn module."""
    import nltk
    nltk.data.path.insert(0, nltk_data_dir)
    from nltk.corpus import wordnet as wn
    # Pre-expand sound hyponyms for audio_other
    return wn


def build_sound_hyponyms(wn) -> frozenset[str]:
    """Collect lemma strings from sound.n.04 and noise hyponym subtrees."""
    lemmas: set[str] = set()
    roots = []
    for name in ("sound.n.04", "noise.n.01", "noise.n.04"):
        try:
            roots.append(wn.synset(name))
        except Exception:
            pass
    queue = list(roots)
    visited: set[str] = set()
    while queue:
        ss = queue.pop()
        if ss.name() in visited:
            continue
        visited.add(ss.name())
        for lm in ss.lemmas():
            lemmas.add(lm.name().lower().replace("_", " "))
        queue.extend(ss.hyponyms())
    return frozenset(lemmas)


# -- Parse helpers for na detection ----------------------------

def _entity_head_ti(node: dict, parse: List[dict]) -> int:
    """Return the UD-head token index of a (possibly merged) node.

    The head is the token whose own `.head` lies outside the node's token set.
    """
    tids = node["token_indices"]
    tids_set = set(tids)
    for ti in tids:
        if parse[ti]["head"] not in tids_set:
            return ti
    return tids[0]


def _is_na(node: dict, parse: Optional[List[dict]],
                         relational_verbs: FrozenSet) -> bool:
    """Return True when node is a function/relational word that should not be
    presented as a standalone annotation unit.

    Covers:
    - Copular/existential "be" events (is/are/was/were/been)
    - Relational verb events (cause, involve, consist, …)
    - Expletive entity pronouns (existential "there", pleonastic "it"; deprel=expl)
    """
    lemma = node.get("lemma", "").lower()
    upos  = node.get("upos", "")

    if upos == "VERB":
        if lemma in _COPULA_LEMMAS:
            return True
        if lemma in relational_verbs:
            return True

    # Expletive pronouns: entity nodes with head token deprel == "expl"
    if upos in ("PRON", "NOUN", "PROPN") and parse is not None:
        ti = _entity_head_ti(node, parse)
        if parse[ti]["deprel"] == _EXPLETIVE_DEPREL:
            return True

    return False


# -- Per-token affordance lookup ---------------------------------------------

def supersenses_for(lemma: str, pos_filter, wn) -> set[str]:
    """Return lexname set (e.g. {'noun.artifact'}) for a lemma under pos_filter."""
    ss_set: set[str] = set()
    for ss in wn.synsets(lemma, pos=pos_filter):
        ss_set.add(ss.lexname())
    return ss_set


def node_channels(
    node: dict,
    *,
    wn,
    sound_hyps: frozenset[str],
    brysbaert: dict[str, float],
    ocr_lex: frozenset[str],
    speech_verbs: frozenset[str],
    sound_lex: frozenset[str],
    unverif_lex: frozenset[str],
    language_names: frozenset[str],
    claim_text: str,
    parse: Optional[List[dict]] = None,
    relational_verbs: FrozenSet = frozenset(),
) -> list[str]:
    """
    Return list of channel strings for a single node (multi-label).

    If the node is a relational/function word (copular be, expletive pronoun,
    relational verb), returns ["na"] immediately and skips all
    other channel lookups.
    """
    lemma  = node["lemma"].lower()
    upos   = node["upos"]
    text   = node["text"].lower()
    channels: set[str] = set()

    # na: highest priority, early-exit (no other channels assigned)
    if _is_na(node, parse, relational_verbs):
        return ["na"]

    # --- visual_other ---
    if upos in ("NOUN", "PROPN"):
        ss = supersenses_for(lemma, "n", wn)
        if ss & VISUAL_OTHER_NOUN_SS:
            channels.add("visual_other")
        # Brysbaert: use text first, then lemma
        conc = brysbaert.get(text, brysbaert.get(lemma, 0.0))
        if conc >= CONCRETENESS_THRESHOLD:
            channels.add("visual_other")
    elif upos == "VERB":
        ss = supersenses_for(lemma, "v", wn)
        if ss & VISUAL_OTHER_VERB_SS:
            channels.add("visual_other")

    # --- visual_ocr ---
    if lemma in ocr_lex or text in ocr_lex:
        channels.add("visual_ocr")

    # --- audio_speech ---
    if upos == "VERB" and lemma in speech_verbs:
        channels.add("audio_speech")
    # "in <language>" cue: check claim text for this node's neighborhood
    if upos in ("NOUN", "PROPN") and text in language_names:
        channels.add("audio_speech")

    # --- audio_other ---
    if lemma in sound_lex or text in sound_lex:
        channels.add("audio_other")
    if upos in ("NOUN", "PROPN"):
        if lemma in sound_hyps or text in sound_hyps:
            channels.add("audio_other")
        ss = supersenses_for(lemma, "n", wn)
        if ss & AUDIO_OTHER_NOUN_SS and not (ss & VISUAL_OTHER_NOUN_SS):
            channels.add("audio_other")

    # --- unverifiable ---
    if lemma in unverif_lex or text in unverif_lex:
        channels.add("unverifiable")
    if upos in ("NOUN", "PROPN"):
        ss = supersenses_for(lemma, "n", wn)
        if ss & UNVERIFIABLE_NOUN_SS:
            channels.add("unverifiable")

    # No channel assigned → default to visual_other for concrete nouns,
    # unverifiable for abstract/ADJ, skip for operators
    if not channels and upos in ("NOUN", "PROPN"):
        channels.add("visual_other")  # default for nouns without any match
    if not channels and upos in ("ADJ", "ADV"):
        channels.add("unverifiable")  # default for adjectives without match

    return sorted(channels)


def factor_channels(factor: dict, node_channels_map: dict[str, list[str]]) -> list[str]:
    """Factor channels = union of all arg node channels (excluding na).

    Factors are always complete semantic predicates; na is not
    propagated from individual argument nodes to the factor level.
    """
    channels: set[str] = set()
    for arg_nid in factor.get("args", []):
        for ch in node_channels_map.get(arg_nid, []):
            if ch != "na":
                channels.add(ch)
    # Also include head node
    for ch in node_channels_map.get(factor.get("head", ""), []):
        if ch != "na":
            channels.add(ch)
    return sorted(channels)


# -- Main --------------------------------------------------------------------

def _merge_to_pass1(chs: list[str]) -> list[str]:
    """Merge 6-chan labels to 4-class pass-1 label space.

    visual_other + visual_ocr → visual
    audio_speech + audio_other → audio
    unverifiable, na           → unchanged
    """
    merged: set[str] = set()
    for ch in chs:
        if ch in ("visual_other", "visual_ocr"):
            merged.add("visual")
        elif ch in ("audio_speech", "audio_other"):
            merged.add("audio")
        else:
            merged.add(ch)
    return sorted(merged)


def setup_parser():
    p = argparse.ArgumentParser(
        description="V1/V2 lexicon+rules affordance (AViD Phase 1)"
    )
    p.add_argument("--hypergraph",        default=HYPERGRAPH_PATH)
    p.add_argument("--annotation-units",  default="",
                   help="Path to annotation_units.tsv.  When provided, processes "
                        "TSV rows (phrase_entity/node/factor) instead of raw "
                        "hypergraph nodes/factors.")
    p.add_argument("--output",            default="")
    p.add_argument("--brysbaert",         default=BRYSBAERT_PATH)
    p.add_argument("--nltk-data",         default=NLTK_DATA_DIR)
    p.add_argument("--lexicon-dir",       default=str(LEXICON_DIR))
    p.add_argument("--label-space",       choices=["6chan", "pass1"], default="6chan",
                   help="6chan (default): full 6-channel output. "
                        "pass1: merge visual_other+visual_ocr→visual, "
                        "audio_speech+audio_other→audio (4-class coarse output).")
    return p


def _node_channels_kwargs(wn, sound_hyps, brysbaert, ocr_lex, speech_verbs,
                           sound_lex, unverif_lex, language_names,
                           relational_verbs):
    """Bundle keyword args for node_channels() calls."""
    return dict(
        wn=wn, sound_hyps=sound_hyps, brysbaert=brysbaert,
        ocr_lex=ocr_lex, speech_verbs=speech_verbs, sound_lex=sound_lex,
        unverif_lex=unverif_lex, language_names=language_names,
        relational_verbs=relational_verbs,
    )


def main():
    args = setup_parser().parse_args()
    lexdir = Path(args.lexicon_dir)

    units_mode = bool(args.annotation_units)
    if not args.output:
        out_default = OUTPUT_UNITS_PATH if units_mode else OUTPUT_PATH
        out_path = Path(out_default)
    else:
        out_path = Path(args.output)

    print("=" * 60)
    print("AViD Phase 1 — affordance_rules.py")
    print(f"  Mode: {'annotation-units' if units_mode else 'legacy (hypergraph nodes)'}")
    print("=" * 60)

    # 1. Load resources
    print("\n[1] Loading resources ...")
    wn = load_wordnet(args.nltk_data)
    print("  WordNet loaded.")

    brysbaert = load_brysbaert(args.brysbaert)
    print(f"  Brysbaert: {len(brysbaert):,} words.")

    sound_hyps = build_sound_hyponyms(wn)
    print(f"  Sound hyponyms: {len(sound_hyps)} lemmas.")

    ocr_lex          = load_lexicon_file(lexdir / "visual_ocr.txt")
    speech_verbs     = load_lexicon_file(lexdir / "audio_speech_verbs.txt")
    sound_lex        = load_lexicon_file(lexdir / "audio_other_sounds.txt")
    unverif_lex      = load_lexicon_file(lexdir / "unverifiable_terms.txt")
    language_names   = load_lexicon_file(lexdir / "language_names.txt")
    relational_verbs = load_lexicon_file(lexdir / "relational_verbs.txt")
    print(f"  Lexicons: OCR={len(ocr_lex)}, speech={len(speech_verbs)}, "
          f"sound={len(sound_lex)}, unverif={len(unverif_lex)}, "
          f"lang={len(language_names)}, relational={len(relational_verbs)}")

    nch_kw = _node_channels_kwargs(
        wn, sound_hyps, brysbaert, ocr_lex, speech_verbs,
        sound_lex, unverif_lex, language_names, relational_verbs,
    )

    # 2. Load hypergraph (needed in both modes)
    print(f"\n[2] Loading hypergraph: {args.hypergraph}")
    claims: list[dict] = []
    with open(args.hypergraph, encoding="utf-8") as f:
        for line in f:
            claims.append(json.loads(line))
    print(f"    Claims: {len(claims)}")

    # Index hypergraph by claim_id for fast lookup (units mode)
    hg_index: dict[str, dict] = {r["claim_id"]: r for r in claims}

    out_path.parent.mkdir(parents=True, exist_ok=True)

    label_space = args.label_space
    if units_mode:
        _run_units_mode(args, out_path, hg_index, nch_kw, label_space)
    else:
        _run_legacy_mode(args, out_path, claims, nch_kw, label_space)

    print("\nDone.")


def _run_legacy_mode(args, out_path, claims, nch_kw, label_space="6chan"):
    """Original mode: process all hypergraph nodes + factors per claim."""
    print(f"\n[3] Processing hypergraph nodes/factors → {out_path}")
    if label_space == "pass1":
        print("    Label space: pass1 (4-class merged)")

    out_channels = ["visual", "audio", "unverifiable", "na"] if label_space == "pass1" else list(CHANNELS)
    stats = {ch: 0 for ch in out_channels}
    stats.update({"total_claims": 0, "total_nodes": 0, "total_factors": 0,
                  "multi_channel_nodes": 0, "no_channel_nodes": 0})

    with open(out_path, "w", encoding="utf-8") as out_f:
        for rec in claims:
            claim_text = rec["claim_text"]
            parse      = rec.get("parse", [])

            node_ch_map: dict[str, list[str]] = {}
            for node in rec["nodes"]:
                chs = node_channels(
                    node, claim_text=claim_text, parse=parse, **nch_kw
                )
                if label_space == "pass1":
                    chs = _merge_to_pass1(chs)
                node_ch_map[node["id"]] = chs
                for ch in chs:
                    stats[ch] = stats.get(ch, 0) + 1
                if len(chs) > 1:
                    stats["multi_channel_nodes"] += 1
                if not chs:
                    stats["no_channel_nodes"] += 1
                stats["total_nodes"] += 1

            factor_ch_map: dict[str, list[str]] = {}
            for fac in rec["factors"]:
                fchs = factor_channels(fac, node_ch_map)
                if label_space == "pass1":
                    fchs = _merge_to_pass1(fchs)
                factor_ch_map[fac["id"]] = fchs
                stats["total_factors"] += 1

            out_f.write(json.dumps({
                "claim_id":           rec["claim_id"],
                "affordance_nodes":   node_ch_map,
                "affordance_factors": factor_ch_map,
            }, ensure_ascii=False) + "\n")
            stats["total_claims"] += 1

    print("\n" + "=" * 60)
    print("LEGACY MODE SUMMARY")
    print("=" * 60)
    print(f"  Claims: {stats['total_claims']}  "
          f"Nodes: {stats['total_nodes']}  Factors: {stats['total_factors']}")
    for ch in out_channels:
        n = stats.get(ch, 0)
        pct = 100 * n / max(1, stats["total_nodes"])
        print(f"    {ch:<22} {n:>6}  ({pct:.1f}%)")
    print(f"  Output: {out_path}")


def _run_units_mode(args, out_path, hg_index, nch_kw, label_space="6chan"):
    """Annotation-units mode: process rows from annotation_units.tsv."""
    import csv as _csv

    print(f"\n[3] Reading annotation units: {args.annotation_units}")
    if label_space == "pass1":
        print("    Label space: pass1 (4-class merged)")
    # Group rows by claim_id
    rows_by_claim: dict[str, list[dict]] = {}
    with open(args.annotation_units, newline="", encoding="utf-8") as f:
        for row in _csv.DictReader(f, delimiter="\t"):
            rows_by_claim.setdefault(row["claim_id"], []).append(row)
    n_claims = len(rows_by_claim)
    n_rows   = sum(len(v) for v in rows_by_claim.values())
    print(f"    {n_rows} rows across {n_claims} claims.")

    out_channels = ["visual", "audio", "unverifiable", "na"] if label_space == "pass1" else list(CHANNELS)
    stats = {ch: 0 for ch in out_channels}
    stats.update({"total_claims": 0, "total_units": 0})

    print(f"\n[4] Computing affordances → {out_path}")
    with open(out_path, "w", encoding="utf-8") as out_f:
        for cid, rows in rows_by_claim.items():
            rec = hg_index.get(cid, {})
            if not rec:
                print(f"  WARNING: claim {cid} not in hypergraph — skipping.",
                      file=sys.stderr)
                continue

            parse      = rec.get("parse", [])
            claim_text = rec.get("claim_text", "")

            # Build node and factor lookup for this claim
            node_by_id   = {n["id"]: n for n in rec.get("nodes", [])}
            factor_by_id = {f["id"]: f for f in rec.get("factors", [])}

            # Pre-compute node_ch_map (needed for factors)
            node_ch_map: dict[str, list[str]] = {}
            for nid, node in node_by_id.items():
                node_ch_map[nid] = node_channels(
                    node, claim_text=claim_text, parse=parse, **nch_kw
                )

            unit_affordances: dict[str, list[str]] = {}

            for row in rows:
                uid  = row["unit_id"]
                utype = row["unit_type"]

                if utype == "phrase_entity":
                    # uid = "pu_{node_id}"; strip prefix to get source node
                    src_nid = uid[3:]   # e.g. "pu_n0" → "n0"
                    node = node_by_id.get(src_nid)
                    if node is None:
                        chs = []
                    else:
                        chs = node_channels(
                            node, claim_text=claim_text, parse=parse, **nch_kw
                        )
                        # Phrase entities are concrete NPs — never na
                        # (expletives were already dropped by annotation_units.py)
                        chs = [c for c in chs if c != "na"]
                        if not chs:
                            chs = ["visual_other"]

                elif utype == "node":
                    node = node_by_id.get(uid)
                    if node is None:
                        chs = []
                    else:
                        chs = node_channels(
                            node, claim_text=claim_text, parse=parse, **nch_kw
                        )

                elif utype == "factor":
                    fac = factor_by_id.get(uid)
                    if fac is None:
                        chs = []
                    else:
                        chs = factor_channels(fac, node_ch_map)

                else:
                    chs = []

                if label_space == "pass1":
                    chs = _merge_to_pass1(chs)
                unit_affordances[uid] = chs
                for ch in chs:
                    stats[ch] = stats.get(ch, 0) + 1
                stats["total_units"] += 1

            out_f.write(json.dumps({
                "claim_id":         cid,
                "affordance_units": unit_affordances,
            }, ensure_ascii=False) + "\n")
            stats["total_claims"] += 1

    print("\n" + "=" * 60)
    print("ANNOTATION-UNITS MODE SUMMARY")
    print("=" * 60)
    print(f"  Claims: {stats['total_claims']}  Units: {stats['total_units']}")
    for ch in out_channels:
        n = stats.get(ch, 0)
        pct = 100 * n / max(1, stats["total_units"])
        print(f"    {ch:<22} {n:>6}  ({pct:.1f}%)")
    print(f"  Output: {out_path}")


if __name__ == "__main__":
    main()
