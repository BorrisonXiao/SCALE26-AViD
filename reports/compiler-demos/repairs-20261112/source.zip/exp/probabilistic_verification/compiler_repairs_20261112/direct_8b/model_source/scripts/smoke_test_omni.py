#!/usr/bin/env python3
"""
AViD Phase 2 — Step 0: Qwen3-Omni vLLM audio smoke test.

Loads the Omni model, feeds one audio clip, asks a yes/no/unknown question,
and verifies that first-token logprob extraction returns sensible results.

Run this on a GPU node (H200 preferred) BEFORE investing in the full audio leg.

Usage (vllm-omni env, GPU node):
    python scripts/smoke_test_omni.py
    python scripts/smoke_test_omni.py --wav /path/to/any.wav
"""

import argparse
import json
import math
import os
import sys
from pathlib import Path

os.environ.setdefault("VLLM_USE_V1", "0")

DEFAULT_MODEL = "/home/hltcoe/cxiao/calm/downloads/models/qwen3-omni/30B-A3B-Instruct"
_AVID_MEDIA   = Path("/exp/cxiao/scale26/avid/exp/phase2/media_cache/wav")

VERDICTS = ["yes", "no", "unknown"]
LETTERS  = ["A", "B", "C"]

SYSTEM = (
    "You are a precise media analysis assistant. "
    "Answer with exactly one letter (A, B, or C)."
)
USER = """\
Is speech audible in this audio clip?

A) yes      — clearly audible speech
B) no       — no speech present
C) unknown  — cannot determine

Answer:"""


def extract_option_distribution(logprobs_dict, tokenizer):
    option_logprob = {L: float("-inf") for L in LETTERS}
    for tok_id, lp_obj in logprobs_dict.items():
        decoded = (
            lp_obj.decoded_token if hasattr(lp_obj, "decoded_token")
            else tokenizer.decode([tok_id])
        ) or ""
        c = decoded.strip().upper().rstrip(":).")
        if c in option_logprob:
            lp = lp_obj.logprob if hasattr(lp_obj, "logprob") else lp_obj
            cur = option_logprob[c]
            option_logprob[c] = (
                lp if cur == float("-inf")
                else cur + math.log1p(math.exp(lp - cur))
            )
    valid = {L: lp for L, lp in option_logprob.items() if lp != float("-inf")}
    if not valid:
        return {v: 1.0 / 3 for v in VERDICTS}
    max_lp = max(valid.values())
    exp_v  = {L: math.exp(lp - max_lp) for L, lp in valid.items()}
    total  = sum(exp_v.values())
    probs  = {L: v / total for L, v in exp_v.items()}
    return {VERDICTS[i]: probs.get(L, 0.0) for i, L in enumerate(LETTERS)}


def load_or_generate_wav(wav_path: str | None) -> tuple:
    """Return (np.ndarray, sample_rate).  Generates silence if no path given."""
    if wav_path and Path(wav_path).exists():
        import soundfile as sf
        data, sr = sf.read(wav_path, dtype="float32", always_2d=False)
        if data.ndim > 1:
            data = data.mean(axis=1)
        print(f"  Loaded wav: {wav_path} ({len(data)/sr:.1f}s, {sr} Hz)")
        return data, sr

    # Try to find any cached wav
    if _AVID_MEDIA.exists():
        wavs = list(_AVID_MEDIA.glob("*.wav"))
        if wavs:
            import soundfile as sf
            data, sr = sf.read(str(wavs[0]), dtype="float32", always_2d=False)
            if data.ndim > 1:
                data = data.mean(axis=1)
            print(f"  Using cached wav: {wavs[0]} ({len(data)/sr:.1f}s)")
            return data, sr

    # Fall back to 3 seconds of silence
    import numpy as np
    print("  No wav found — using 3s of silence as fallback.")
    return np.zeros(48000, dtype=np.float32), 16000


def main():
    p = argparse.ArgumentParser(description="Qwen3-Omni vLLM audio smoke test")
    p.add_argument("--model", default=DEFAULT_MODEL)
    p.add_argument("--wav",   default="", help="Path to a WAV file to test with")
    p.add_argument("--tp",    type=int, default=0)
    args = p.parse_args()

    print("=" * 60)
    print("AViD Phase 2 — Qwen3-Omni smoke test")
    print(f"  Model: {args.model}")
    print("=" * 60)

    # Load audio
    print("\n[1] Loading audio ...")
    wav_data, wav_sr = load_or_generate_wav(args.wav or None)

    # Load model
    print(f"\n[2] Loading Qwen3-Omni via vLLM ...")
    import torch
    from vllm import LLM, SamplingParams
    from transformers import AutoProcessor

    tp_size = args.tp if args.tp > 0 else torch.cuda.device_count()
    if tp_size == 0:
        print("ERROR: No GPUs found.", file=sys.stderr)
        sys.exit(1)

    print(f"  TP size: {tp_size}")
    processor = AutoProcessor.from_pretrained(args.model, trust_remote_code=True)
    llm = LLM(
        model=args.model,
        trust_remote_code=True,
        gpu_memory_utilization=0.90,
        tensor_parallel_size=tp_size,
        dtype="bfloat16",
        seed=42,
        max_model_len=4096,
        limit_mm_per_prompt={"audio": 1},
    )
    print("  Model loaded.")

    sampling_params = SamplingParams(
        temperature=0.0,
        max_tokens=1,
        logprobs=20,    # V1 engine max is 20
    )

    # Build prompt
    messages = [
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": [
            {"type": "audio"},
            {"type": "text", "text": USER},
        ]},
    ]
    # enable_thinking=False → empty <think></think> prefix → model generates answer
    prompt = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True,
        enable_thinking=False,
    )
    print(f"\n[3] Prompt (last 100 chars): ...{repr(prompt[-100:])}")

    # Run inference
    print("\n[4] Running inference ...")
    outputs = llm.generate(
        [{"prompt": prompt, "multi_modal_data": {"audio": [(wav_data, wav_sr)]}}],
        sampling_params=sampling_params,
    )

    out = outputs[0]
    generated_text = out.outputs[0].text
    print(f"  Generated text: {repr(generated_text)}")

    # Extract logprob distribution
    try:
        lp_dict = out.outputs[0].logprobs[0]
        dist = extract_option_distribution(lp_dict, processor)
        print(f"\n[5] Verdict distribution:")
        for v, prob in dist.items():
            print(f"    {v}: {prob:.4f}")
        verdict = max(dist, key=dist.get)
        print(f"\n  → Verdict: {verdict}")
        print("\nSmoke test PASSED: logprob extraction works for Qwen3-Omni.")
    except Exception as e:
        print(f"\n  ERROR extracting logprobs: {e}", file=sys.stderr)
        print("Smoke test FAILED.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
