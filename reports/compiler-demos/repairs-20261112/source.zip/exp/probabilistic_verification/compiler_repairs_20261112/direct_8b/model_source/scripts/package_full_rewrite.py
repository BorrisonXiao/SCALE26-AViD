"""Publish a deterministic overlay; preserve earlier experiments and downloads."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/rewrite_all_20261112'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--allow-missing-history', action='store_true')
    args = parser.parse_args()
    names = [
        'scripts/prompts_phase2.py', 'scripts/prepare_full_rewrite.py',
        'scripts/run_claim_split_model.py', 'scripts/parse_claim_splits.py',
        'scripts/evaluate_full_rewrite.py', 'scripts/analyze_full_rewrite.py',
        'scripts/check_historical_compiler.py', 'scripts/check_native_absence.py',
        'scripts/full_rewrite_report.py', 'scripts/package_full_rewrite.py',
        'scripts/check_full_rewrite_browser.py', 'scripts/check_full_rewrite_archive.py', 'scripts/build_compiler_demos.py',
        'scripts/build_verification_pipeline_report.py',
        'scripts/build_av_feature_sections.py',
        'docs/rewrite_all_20261112.md', 'docs/project_notes/daily_log.json',
        'AGENTS.md', 'CLAUDE.md', 'docs/project_notes/key_facts.md',
        'docs/project_notes/decisions.md', 'docs/project_notes/bugs.md',
        'docs/project_notes/issues.md', 'docs/project_notes/terminology.md',
        'site/reports/index.html',
        'site/reports/verification-pipeline.html',
        'site/reports/verification-pipeline/av/checklist.json',
        'exp/probabilistic_verification/av_features_20261022/checklist.json']
    names += [str(p.relative_to(ROOT)) for folder, pattern in [
        ('scripts/probabilistic_verification', '*.py'),
        ('scripts/report_assets', '*'), ('tests', 'test_*.py')]
        for p in sorted((ROOT / folder).glob(pattern)) if p.is_file()]
    data = {name: (ROOT / name).read_bytes() for name in names}
    # Include prior post-publication proofs needed by the earlier preservation
    # manifest. Earlier bundles intentionally predate their own publication.
    old = ROOT / 'exp/probabilistic_verification/report_cleanup_20261112/frozen_artifacts.json'
    for name in json.loads(old.read_text()):
        if Path(name).name in {'publication.json', 'browser_checks.json', 'archive_verification.json'}:
            data[name] = (ROOT / name).read_bytes()
    for name in ['publication.json', 'browser_checks.json', 'archive_verification.json']:
        path = old.parent / name
        data[str(path.relative_to(ROOT))] = path.read_bytes()
    excluded = {'publication.json', 'browser_checks.json', 'archive_verification.json',
                'final_source_sha256.json', 'WORK_STATUS.md'}
    for path in sorted(RUN.rglob('*')):
        if path.is_file() and path.suffix in {'.json', '.jsonl', '.xml', '.py', '.out', '.err'} and path.name not in excluded:
            data[str(path.relative_to(ROOT))] = path.read_bytes()
    freeze = {name: hashlib.sha256(body).hexdigest() for name, body in data.items()}
    (RUN / 'final_source_sha256.json').write_text(json.dumps(freeze, indent=2) + '\n')
    data[str((RUN / 'final_source_sha256.json').relative_to(ROOT))] = (RUN / 'final_source_sha256.json').read_bytes()
    data['README_FULL_REWRITE.md'] = (ROOT / 'docs/rewrite_all_20261112.md').read_bytes()
    data['FULL_REWRITE_SHA256SUMS'] = ''.join(hashlib.sha256(body).hexdigest() + '  ' + name + '\n' for name, body in sorted(data.items())).encode()
    target = ROOT / 'site/reports/compiler-demos/full-rewrite-20261112/source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, body in sorted(data.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, body)
    missing = []
    for name, digest in json.loads((RUN / 'preserved_archives.json').read_text()).items():
        path = ROOT / name
        if not path.exists():
            missing.append(name)
        else:
            assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
    assert args.allow_missing_history or not missing, missing
    baseline = json.loads((RUN / 'previous_compiler_freeze.json').read_text())['source_sha256']
    for name, digest in baseline.items():
        assert hashlib.sha256((RUN / 'baseline_source' / name).read_bytes()).hexdigest() == digest, name
    viewers = ROOT / 'exp/probabilistic_verification/claim_rewrite_20261111/viewer_sha256.json'
    for name, digest in json.loads(viewers.read_text()).items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    print('Packaged', len(data), 'files;', round(target.stat().st_size / 1048576, 2),
          'MiB; historical archives, baseline source and original viewers preserved.')


if __name__ == '__main__':
    main()
