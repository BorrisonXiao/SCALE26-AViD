#!/usr/bin/env python
"""Render a FULL parse tree (every word = a node) for an example claim, with
per-node source-modality annotation, and export it as an editable draw.io file.

Two annotations are shown per node:
  * BORDER  = the word's OWN channel      (visual / audio / speech / na-grey)
  * FILL    = the COMPOSITION at that node = blend of the channels present in its
              whole subtree, drawn semi-transparent so mixed nodes read as an
              overlap (e.g. root "honks" = audio (loudly, honks) blended with the
              visual "man crossing ..." subtree -> purple).
  * na (function words) are grey and do NOT tint their parents' composition.

Outputs (into slides/figures/):
  * <base>.drawio  -- mxGraph XML, opens/edits directly in draw.io / diagrams.net
  * <base>.png/.svg -- graphviz preview (same colours) for a quick look / QA

Layout coordinates for the .drawio come from graphviz (`dot`), so the tree is
already tidily laid out on import; you can then re-style freely in draw.io.
"""
import json
import subprocess
from html import escape as h
from xml.sax.saxutils import quoteattr

OUTDIR = "slides/figures"
BASE = "composition_tree_car_honks"
CLAIM = "A car loudly honks at a man crossing the street while pushing a baby stroller."

# ---- the (hand-built, standard-UD) parse: idx, word, head, deprel, own channel
# head = -1 for the root.  channel in {visual, audio, speech, na}
TOKENS = [
    (0,  "A",        1,  "det",      "na"),
    (1,  "car",      3,  "nsubj",    "visual"),
    (2,  "loudly",   3,  "advmod",   "audio"),
    (3,  "honks",   -1,  "root",     "audio"),
    (4,  "at",       6,  "case",     "na"),
    (5,  "a",        6,  "det",      "na"),
    (6,  "man",      3,  "obl",      "visual"),
    (7,  "crossing", 6,  "acl",      "visual"),
    (8,  "the",      9,  "det",      "na"),
    (9,  "street",   7,  "obj",      "visual"),
    (10, "while",   11,  "mark",     "na"),
    (11, "pushing",  7,  "advcl",    "visual"),
    (12, "a",       14,  "det",      "na"),
    (13, "baby",    14,  "compound", "visual"),
    (14, "stroller", 11, "obj",      "visual"),
    (15, ".",        3,  "punct",    "na"),
]

# base channel colours (RGB)
RGB = {
    "visual": (0x5B, 0x9B, 0xD5),   # blue
    "audio":  (0xE8, 0x61, 0x8C),   # rose / pink
    "speech": (0x57, 0xB3, 0x6B),   # green (unused here, kept for reuse)
    "na":     (0x9E, 0x9E, 0x9E),   # grey
}
FILL_ALPHA = 0x8C          # ~55% for the graphviz preview
FILL_OPACITY = 55          # draw.io fillOpacity (0-100)
CH_LABEL = {"visual": "Visual", "audio": "Audio", "speech": "Speech", "na": "na (not checkable)"}

idx2word = {i: w for i, w, *_ in TOKENS}
own = {i: ch for i, _, _, _, ch in TOKENS}
children = {i: [] for i, *_ in TOKENS}
root = None
for i, w, head, dep, ch in TOKENS:
    if head == -1:
        root = i
    else:
        children[head].append(i)


def subtree_channels(i):
    """set of non-na OWN channels present in the subtree rooted at i."""
    chs = set()
    if own[i] != "na":
        chs.add(own[i])
    for c in children[i]:
        chs |= subtree_channels(c)
    return chs


def avg(colors):
    n = len(colors)
    return tuple(round(sum(c[k] for c in colors) / n) for k in range(3))


def comp_rgb(i):
    """composition fill colour for node i (blend of subtree channels)."""
    chs = subtree_channels(i)
    if not chs:
        return RGB["na"]
    if len(chs) == 1:
        return RGB[next(iter(chs))]
    return avg([RGB[c] for c in sorted(chs)])


def hx(rgb):
    return "#%02X%02X%02X" % rgb


def hxa(rgb, a):
    return "#%02X%02X%02X%02X" % (rgb[0], rgb[1], rgb[2], a)


# ---------- graphviz core (layout + preview) ----------
def build_dot():
    L = [
        "digraph T {",
        "  rankdir=TB; nodesep=0.35; ranksep=0.55; pad=0.2; bgcolor=transparent;",
        f'  graph [fontname="Helvetica", fontsize=14, labelloc="t", '
        f'label=<<FONT POINT-SIZE="14" COLOR="#333333"><I>&#8220;{h(CLAIM)}&#8221;</I></FONT>>];',
        '  node [shape=box, style="rounded,filled", fontname="Helvetica", '
        'fontsize=14, height=0.5, margin="0.12,0.06"];',
        '  edge [color="#AEB4BB", penwidth=1.2, arrowsize=0.6, fontname="Helvetica", '
        'fontsize=10, fontcolor="#8A9199"];',
    ]
    for i, w, head, dep, ch in TOKENS:
        fill = hxa(comp_rgb(i), FILL_ALPHA)
        border = hx(RGB[own[i]])
        L.append(f'  n{i} [label=<<B>{h(w)}</B>>, fillcolor="{fill}", '
                 f'color="{border}", penwidth=2.0];')
    for i, w, head, dep, ch in TOKENS:
        if head != -1:
            L.append(f'  n{head} -> n{i} [label=" {dep}"];')
    L.append("}")
    return "\n".join(L)


def gv(dot, fmt, extra=None):
    args = ["dot", f"-T{fmt}"] + (extra or [])
    return subprocess.run(args, input=dot.encode("utf-8"), capture_output=True,
                          check=True).stdout            # bytes


# ---------- draw.io (mxGraph XML) ----------
def cell(id_, value, style, x, y, w, hgt, vertex=True, parent="1", source=None, target=None):
    if vertex:
        return (f'        <mxCell id={quoteattr(id_)} value={quoteattr(value)} '
                f'style={quoteattr(style)} vertex="1" parent={quoteattr(parent)}>'
                f'<mxGeometry x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{hgt:.1f}" '
                f'as="geometry"/></mxCell>')
    return (f'        <mxCell id={quoteattr(id_)} value={quoteattr(value)} '
            f'style={quoteattr(style)} edge="1" parent={quoteattr(parent)} '
            f'source={quoteattr(source)} target={quoteattr(target)}>'
            f'<mxGeometry relative="1" as="geometry"/></mxCell>')


def build_drawio(pos):
    xs = [p[0] for p in pos.values()]
    ys = [p[1] for p in pos.values()]
    ws = [p[2] for p in pos.values()]
    hs = [p[3] for p in pos.values()]
    margin = 40.0
    minx, miny = min(xs), min(ys)
    dx, dy = margin - minx, margin + 34 - miny        # leave room for the title
    maxy = max(y + hh for (x, y), hh in zip([(p[0], p[1]) for p in pos.values()], hs))
    width_total = max(x + w for x, w in zip(xs, ws)) + dx + margin

    out = ['<mxfile host="app.diagrams.net" type="device">',
           '  <diagram id="parse_tree" name="Parse tree">',
           '    <mxGraphModel dx="900" dy="600" grid="1" gridSize="10" guides="1" '
           'tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" '
           'pageWidth="1100" pageHeight="850" math="0" shadow="0">',
           '      <root>',
           '        <mxCell id="0"/>',
           '        <mxCell id="1" parent="0"/>']

    # title
    out.append(cell("title", f"“{CLAIM}”",
                    "text;html=1;align=center;verticalAlign=middle;fontSize=15;"
                    "fontStyle=2;fontColor=#333333;",
                    margin, 6, max(width_total - 2 * margin, 400), 26))

    # nodes
    for i, w, head, dep, ch in TOKENS:
        x, y, ww, hh = pos[f"n{i}"]
        style = (f"rounded=1;whiteSpace=wrap;html=1;fontSize=14;fontStyle=1;"
                 f"fontColor=#333333;fillColor={hx(comp_rgb(i))};fillOpacity={FILL_OPACITY};"
                 f"strokeColor={hx(RGB[own[i]])};strokeWidth=2;")
        out.append(cell(f"n{i}", w, style, x + dx, y + dy, ww, hh))

    # edges (head -> dependent), labelled with the UD relation
    for i, w, head, dep, ch in TOKENS:
        if head != -1:
            style = ("edgeStyle=none;html=1;endArrow=block;endFill=1;endSize=5;"
                     "strokeColor=#AEB4BB;fontSize=10;fontColor=#8A9199;"
                     "labelBackgroundColor=#FFFFFF;")
            out.append(cell(f"e{head}_{i}", dep, style, 0, 0, 0, 0,
                            vertex=False, source=f"n{head}", target=f"n{i}"))

    # legend (single html text cell, fully editable)
    legend_html = (
        '<b>Colour = grounding channel</b> <font color=\'#999999\'>(illustrative)</font><br>'
        '<span style=\'background-color:#5B9BD5;\'>&nbsp;&nbsp;&nbsp;</span> Visual &nbsp;&nbsp;'
        '<span style=\'background-color:#E8618C;\'>&nbsp;&nbsp;&nbsp;</span> Audio &nbsp;&nbsp;'
        '<span style=\'background-color:#9E9E9E;\'>&nbsp;&nbsp;&nbsp;</span> na (not checkable)<br>'
        '<i>Border = the word&#39;s own channel &nbsp;&bull;&nbsp; fill = composition of its '
        'subtree (blended &amp; semi-transparent where channels mix).</i>')
    out.append(cell("legend", legend_html,
                    "text;html=1;align=left;verticalAlign=top;spacing=6;fontSize=11;"
                    "fontColor=#333333;rounded=1;strokeColor=#DDDDDD;fillColor=#FFFFFF;",
                    margin, maxy + dy + 24, 560, 66))

    out += ['      </root>', '    </mxGraphModel>', '  </diagram>', '</mxfile>']
    return "\n".join(out)


def main():
    import os
    os.makedirs(OUTDIR, exist_ok=True)
    dot = build_dot()

    j = json.loads(gv(dot, "json").decode("utf-8"))
    bb = list(map(float, j["bb"].split(",")))
    Ht = bb[3]
    pos = {}
    for o in j.get("objects", []):
        if "pos" not in o or not o.get("name", "").startswith("n"):
            continue
        cx, cy = map(float, o["pos"].split(","))
        w = float(o["width"]) * 72.0
        hh = float(o["height"]) * 72.0
        pos[o["name"]] = (cx - w / 2, (Ht - cy) - hh / 2, w, hh)

    base = os.path.join(OUTDIR, BASE)
    with open(base + ".drawio", "w") as f:
        f.write(build_drawio(pos))
    with open(base + ".png", "wb") as f:
        f.write(gv(dot, "png", ["-Gdpi=170"]))
    with open(base + ".svg", "wb") as f:
        f.write(gv(dot, "svg"))
    print("wrote:", base + ".{drawio,png,svg}")
    print("nodes:", len(pos), " root comp colour:", hx(comp_rgb(root)))


if __name__ == "__main__":
    main()
