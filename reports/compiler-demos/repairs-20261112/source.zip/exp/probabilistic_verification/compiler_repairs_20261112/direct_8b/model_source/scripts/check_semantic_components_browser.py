"""Check all47 comparisons and the retained report navigation/inspectors."""
import functools,http.server,json,threading
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/semantic_components_20261112'

def main():
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'site')))
    threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
    with sync_playwright()as p:
        browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(base+'/reports/',wait_until='networkidle');assert page.locator('.card-link').count()==2
        page.goto(base+'/reports/compiler-demos.html#remaining-failures',wait_until='networkidle')
        page.wait_for_function('document.querySelector("#component-select").options.length===47')
        assert page.locator('[role="tab"]').all_text_contents()==['Overview','Examples','All claims','Daily log','History']
        assert all(t in page.locator('#current-work').inner_text()for t in ['34/36','1,147','1,953','82.23%','no net coverage gain','385'])
        page.evaluate('document.querySelector("#remaining-failures").scrollIntoView({behavior:"instant",block:"start"})');page.screenshot(path=str(RUN/'overview_desktop.png'))
        page.goto(base+'/reports/compiler-demos.html#component-example',wait_until='networkidle')
        cases=json.loads((RUN/'cases.json').read_text())
        checked=page.evaluate('''rows=>{const el=id=>document.getElementById(id);for(const r of rows){el('component-select').value=r.id;el('component-select').dispatchEvent(new Event('change'));if(el('component-text').textContent!==r.text)throw Error(r.id+' text');if(el('component-note').textContent!==r.note)throw Error(r.id+' note');const exact=JSON.parse(el('component-exact').textContent);if(JSON.stringify(exact.previous)!==JSON.stringify(r.before)||JSON.stringify(exact.shared_components)!==JSON.stringify(r.after))throw Error(r.id+' artifacts');}return rows.length;}''',cases)
        for cid in ['TjHepwuhkYFA_1016__c1','TjHepwuhkYFA_1016__c5','TjHepwuhkYFA_1016__c3','TgR_u37mCoQ4_1908','Txf2EdqOg1SQ_2324']:
            page.goto(base+'/reports/compiler-demos.html?component='+cid+'#component-example',wait_until='networkidle');assert page.locator('#component-select').input_value()==cid
            page.evaluate('document.querySelector("#component-text").scrollIntoView({behavior:"instant",block:"start"})');page.screenshot(path=str(RUN/(cid+'_desktop.png')))
        for fragment,panel in [('full-rewrite-example','walkthroughs'),('syntax-demos','walkthroughs'),('alignment-example','history'),('full-rewrite-before-components','history'),('results','history'),('alert-review','history'),('rewrite-pilot','history'),('split-example','history'),('outputs','outputs'),('daily-progress','daily-progress')]:
            page.goto(base+'/reports/compiler-demos.html#'+fragment,wait_until='networkidle');page.wait_for_selector('#'+panel,state='visible');assert page.locator('[role="tabpanel"]:visible').count()==1
        assert page.locator('#demo-select option').count()==41
        assert page.locator('#full-case option').count()==449
        page.goto(base+'/reports/compiler-demos.html?rewrite_all=Txf2EdqOg1SQ_2236#full-rewrite-example',wait_until='networkidle');assert page.locator('#full-case').input_value()=='Txf2EdqOg1SQ_2236';assert page.locator('#full-response').text_content()
        page.goto(base+'/reports/compiler-demos.html?component=TjHepwuhkYFA_1016__c5#component-example',wait_until='networkidle');page.set_viewport_size({'width':390,'height':844});page.emulate_media(color_scheme='dark');assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');page.evaluate('document.querySelector("#component-text").scrollIntoView({behavior:"instant",block:"start"})');page.screenshot(path=str(RUN/'example_mobile_dark.png'))
        page.goto(base+'/reports/verification-pipeline.html#next-steps',wait_until='networkidle');assert 'Shared values and phrase-relation experiment'in page.locator('#next-steps').inner_text()
        for name in ['summary.json','cases.json','semantic_review.json','direct_changes.json','tests.xml','README.md','source.zip']:assert page.request.get(base+'/reports/compiler-demos/components-20261112/'+name).ok,name
        assert not errors,errors
        proof=dict(comparisons=checked,main_reports=2,compiler_views=5,old_demos=41,old_full_cases=449,legacy_fragments=10,case_deep_links=5,mobile_overflow=False,page_errors=errors)
        (RUN/'browser_checks.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof);browser.close()
    server.shutdown()

if __name__=='__main__':main()
