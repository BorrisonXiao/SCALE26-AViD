"""Reparse changed proposals using the same frozen Stanza and BERT-SRL models.

Run dependency stage in probabilistic-verification, then --srl in srl-eval.
All proposals remain diagnostic until the separate semantic review.
"""
import argparse,hashlib,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/claim_rewrite_20261111'
def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
def main():
 p=argparse.ArgumentParser();p.add_argument('--srl',action='store_true');p.add_argument('--run',type=Path,default=RUN);a=p.parse_args();run=a.run
 if not a.srl:
  from probabilistic_verification.parsing import DependencyParser
  from probabilistic_verification.claim_rewrite import surface_checks
  parser=DependencyParser();original={r['claim_id']:r for r in read(run/'pilot_inputs.jsonl')};rows=[];started=time.perf_counter()
  for raw in read(run/'pilot_raw.jsonl'):
   old=original[raw['claim_id']];proposal=json.loads(raw['raw']);issues=surface_checks(old,proposal)
   row=dict(claim_id=old['claim_id'],original_text=old['text'],text=proposal['text'],proposal=proposal,surface_issues=issues)
   if proposal['text']==old['text']:row['record']=old
   else:
    try:row['record']=dict(old,text=proposal['text'],tokens=parser.parse(proposal['text']),srl=None)
    except ValueError as e:row['parse_error']=str(e)
   rows.append(row)
  write(run/'dependency_proposals.jsonl',rows)
  (run/'dependency_provenance.json').write_text(json.dumps(dict(parser.provenance,elapsed_seconds=time.perf_counter()-started),indent=2)+'\n')
 else:
  import torch
  from allennlp.predictors.predictor import Predictor
  from run_srl_baseline import bio_to_spans
  torch.set_num_threads(2)
  meta=next(json.loads(p.read_text()) for p in Path('/home/hltcoe/cxiao/.allennlp/cache').glob('*.json') if 'structured-prediction-srl-bert' in p.read_text())
  model=Path(meta['cached_path']);predictor=Predictor.from_path(str(model),cuda_device=-1)
  rows=read(run/'dependency_proposals.jsonl');pending=[r for r in rows if r.get('record') and r['record']['srl'] is None];started=time.perf_counter()
  for start in range(0,len(pending),8):
   batch=pending[start:start+8];outputs=predictor.predict_batch_json([dict(sentence=r['text']) for r in batch])
   for row,out in zip(batch,outputs):
    words=out['words'];frames=[]
    for v in out['verbs']:
     spans=bio_to_spans(v['tags']);verb=next(([s,e] for role,s,e in spans if role=='V'),None)
     frames.append(dict(verb=v['verb'],verb_span=verb,args=[dict(role=role,start=s,end=e,text=' '.join(words[s:e+1])) for role,s,e in spans if role!='V']))
    row['record']['srl']=dict(claim_id=row['claim_id'],words=words,frames=frames)
   print('SRL',min(start+8,len(pending)),'/',len(pending),flush=True)
  write(run/'parsed_proposals.jsonl',rows)
  (run/'srl_provenance.json').write_text(json.dumps(dict(model_metadata=meta,model_sha256=hashlib.sha256(model.read_bytes()).hexdigest(),torch=torch.__version__,device='cpu',claims=len(pending),elapsed_seconds=time.perf_counter()-started),indent=2)+'\n')
if __name__=='__main__':main()
