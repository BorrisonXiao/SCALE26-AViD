#!/usr/bin/env python3
"""
AViD Phase 1 (Complement) — Build annotation_units.tsv + diff report.

Reads  : avid/exp/phase1/hypergraph.jsonl
Writes : avid/exp/phase1/reports/annotation_units.tsv  (same 9-col schema as annotation.tsv)
         avid/exp/phase1/reports/annotation_units_diff.md

Flags:
  --hypergraph PATH   (default: exp/phase1/hypergraph.jsonl)
  --baseline PATH     (default: exp/phase1/reports/annotation.tsv)
  --out-tsv  PATH     (default: exp/phase1/reports/annotation_units.tsv)
  --diff     PATH     (default: exp/phase1/reports/annotation_units_diff.md)
  --sample-n N        claims to show side-by-side in diff (default 12)
"""

import argparse
import csv
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

# Allow running from the repo root or from the scripts/ dir
sys.path.insert(0, str(Path(__file__).parent))
from annotation_units import make_annotation_units  # noqa: E402

# ── Defaults ─────────────────────────────────────────────────────────────────

_ROOT  = Path(__file__).parent.parent / "exp" / "phase1"
_REP   = _ROOT / "reports"

DEFAULT_HG       = str(_ROOT / "hypergraph.jsonl")
DEFAULT_BASELINE = str(_REP  / "annotation.tsv")
DEFAULT_OUT_TSV  = str(_REP  / "annotation_units.tsv")
DEFAULT_DIFF     = str(_REP  / "annotation_units_diff.md")

TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted",
    "gold_channels", "notes",
]


# ── CLI ───────────────────────────────────────────────────────────────────────

def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Build annotation_units.tsv + diff")
    p.add_argument("--hypergraph", default=DEFAULT_HG)
    p.add_argument("--baseline",   default=DEFAULT_BASELINE)
    p.add_argument("--out-tsv",    default=DEFAULT_OUT_TSV)
    p.add_argument("--diff",       default=DEFAULT_DIFF)
    p.add_argument("--sample-n",   type=int, default=12)
    p.add_argument("--seed",       type=int, default=42)
    return p


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_baseline(path: str) -> dict[str, list[dict]]:
    """Load annotation.tsv → {claim_id: [rows]}."""
    result: dict[str, list[dict]] = defaultdict(list)
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            result[row["claim_id"]].append(row)
    return result


def _write_tsv(path: str, rows: list[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=TSV_COLS, delimiter="\t")
        w.writeheader()
        w.writerows(rows)


# ── Diff report ───────────────────────────────────────────────────────────────

def _diff_report(
    claims: list[dict],
    all_new_rows: list[dict],
    baseline_map: dict[str, list[dict]],
    global_stats: dict,
    sample_ids: list[str],
    sample_n: int,
) -> str:
    """Build the markdown diff report."""
    lines: list[str] = []

    # Aggregate removed-per-class from baseline
    removed_classes: Counter = Counter()
    for cid, old_rows in baseline_map.items():
        for r in old_rows:
            nt = r["node_type"]
            ut = r["unit_type"]
            # check if this row is in new_rows for this claim
            new_texts = {
                nr["unit_text"].strip().lower()
                for nr in all_new_rows
                if nr["claim_id"] == cid
            }
            old_text = r["unit_text"].strip().lower()
            if old_text not in new_texts:
                if ut == "node":
                    removed_classes[f"node/{nt}"] += 1
                else:
                    removed_classes[f"factor/{nt}"] += 1

    total_before = sum(len(v) for v in baseline_map.values())
    total_after  = len(all_new_rows)

    lines.append("# AViD Phase 1 — Annotation Units Diff\n")
    lines.append(
        f"Transform: `annotation.tsv` → `annotation_units.tsv`  \n"
        f"Rows before: **{total_before}** | Rows after: **{total_after}** "
        f"({total_after - total_before:+d})\n"
    )

    lines.append("\n## Counts\n")
    lines.append("| Metric | Value |")
    lines.append("|---|---|")
    lines.append(f"| Claims | {len(claims)} |")
    lines.append(f"| Rows before | {total_before} |")
    lines.append(f"| Rows after  | {total_after}  |")
    lines.append(f"| Net change  | {total_after - total_before:+d} |")
    lines.append(f"| Phrase-level entity units added | {global_stats['phrase_units']} |")
    lines.append(f"| Entity nodes absorbed into phrases | {global_stats['absorbed_entities']} |")
    lines.append(f"| Demoted nodes (attr/card/coord/neg) | {global_stats['demoted_nodes']} |")
    lines.append(f"| Expletives dropped (there/it, `expl`) | {global_stats.get('dropped_expletives', 0)} |")
    lines.append(f"| Copular/existential 'be' demoted | {global_stats.get('demoted_copula', 0)} |")
    lines.append(f"| Factors subsumed by phrase units | {global_stats['subsumed_factors']} |")
    lines.append(f"| Orphaned nodes (emitted with tag) | {global_stats['orphaned_nodes']} |")

    lines.append("\n## Removed rows per class (baseline rows absent from new output)\n")
    lines.append("| class | removed |")
    lines.append("|---|---|")
    for cls, cnt in sorted(removed_classes.items(), key=lambda x: -x[1]):
        lines.append(f"| {cls} | {cnt} |")

    lines.append("\n## Sampled claim comparisons (before → after)\n")
    lines.append(
        f"Showing {min(sample_n, len(sample_ids))} claims.  "
        f"Trigger case `TInVWzp25aIM_15` always included.\n"
    )

    new_by_claim: dict[str, list[dict]] = defaultdict(list)
    for r in all_new_rows:
        new_by_claim[r["claim_id"]].append(r)

    for cid in sample_ids[:sample_n]:
        old = baseline_map.get(cid, [])
        new = new_by_claim.get(cid, [])
        ct  = old[0]["claim_text"] if old else (new[0]["claim_text"] if new else cid)

        lines.append(f"\n### `{cid}` — {ct}\n")
        lines.append(f"**Before** ({len(old)} rows):\n")
        for r in old:
            lines.append(f"- `{r['unit_type']}/{r['node_type']}` {r['unit_text']!r}")
        lines.append(f"\n**After** ({len(new)} rows):\n")
        for r in new:
            tag = f"  ← `{r['notes']}`" if r.get("notes") else ""
            lines.append(f"- `{r['unit_type']}/{r['node_type']}` {r['unit_text']!r}{tag}")

    return "\n".join(lines) + "\n"


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    args = _parser().parse_args()
    random.seed(args.seed)

    out_tsv  = Path(args.out_tsv)
    diff_out = Path(args.diff)
    out_tsv.parent.mkdir(parents=True, exist_ok=True)
    diff_out.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("AViD Phase 1 — make_annotation_units.py")
    print("=" * 60)

    # 1. Load hypergraph
    print(f"\n[1] Loading hypergraph: {args.hypergraph}")
    claims: list[dict] = []
    with open(args.hypergraph, encoding="utf-8") as f:
        for line in f:
            claims.append(json.loads(line))
    print(f"    Claims: {len(claims)}")

    # 2. Load baseline
    print(f"\n[2] Loading baseline: {args.baseline}")
    baseline_map = _load_baseline(args.baseline)
    print(f"    Rows: {sum(len(v) for v in baseline_map.values())}")

    # 3. Process each claim
    print(f"\n[3] Building annotation units ...")
    all_rows: list[dict] = []
    agg: dict[str, int] = Counter()  # type: ignore[assignment]

    trigger_claim = "TInVWzp25aIM_15"
    trigger_rows: list[dict] = []

    for rec in claims:
        rows, stats = make_annotation_units(rec)
        all_rows.extend(rows)
        for k, v in stats.items():
            agg[k] += v
        if rec["claim_id"] == trigger_claim:
            trigger_rows = rows

    print(f"    Total output rows: {len(all_rows)}")

    # 4. Write TSV
    print(f"\n[4] Writing {out_tsv} ...")
    _write_tsv(str(out_tsv), all_rows)

    # 5. Summary stats
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    baseline_total = sum(len(v) for v in baseline_map.values())
    print(f"  Rows before (annotation.tsv) : {baseline_total}")
    print(f"  Rows after  (annotation_units): {len(all_rows)}")
    print(f"  Net change                   : {len(all_rows) - baseline_total:+d}")
    print(f"  Phrase-level entity units    : {agg['phrase_units']}")
    print(f"  Entity nodes absorbed        : {agg['absorbed_entities']}")
    print(f"  Demoted nodes (attr/card/…)  : {agg['demoted_nodes']}")
    print(f"  Expletives dropped (expl)    : {agg['dropped_expletives']}")
    print(f"  Copular 'be' demoted         : {agg['demoted_copula']}")
    print(f"  Factors subsumed             : {agg['subsumed_factors']}")
    print(f"  Orphaned nodes               : {agg['orphaned_nodes']}")

    # 6. Trigger case verification
    print(f"\n[5] Trigger case {trigger_claim}:")
    if trigger_rows:
        for r in trigger_rows:
            tag = f"  [{r['notes']}]" if r.get("notes") else ""
            print(f"    {r['unit_type']:14s} {r['node_type']:30s} {r['unit_text']!r}{tag}")
    else:
        print("    (claim not found)")

    # 7. Build diff report
    print(f"\n[6] Writing diff report: {diff_out} ...")

    # Sample: always include trigger claim; fill rest randomly
    all_claim_ids = [c["claim_id"] for c in claims]
    sample_pool = [cid for cid in all_claim_ids if cid != trigger_claim]
    random.shuffle(sample_pool)
    sample_ids = [trigger_claim] + sample_pool

    diff_md = _diff_report(
        claims        = claims,
        all_new_rows  = all_rows,
        baseline_map  = baseline_map,
        global_stats  = dict(agg),
        sample_ids    = sample_ids,
        sample_n      = args.sample_n,
    )
    diff_out.write_text(diff_md, encoding="utf-8")

    print("\nDone.")


if __name__ == "__main__":
    main()
