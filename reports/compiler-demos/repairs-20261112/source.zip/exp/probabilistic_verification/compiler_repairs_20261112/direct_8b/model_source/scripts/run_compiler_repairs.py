"""Evaluate one fixed compiler and one failure-only simplification condition."""
import argparse,copy,json,time
from collections import Counter
from pathlib import Path
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.compiler_extensions import OPTIONS
from probabilistic_verification.split_alignment import compose_aligned
from compile_claim_splits import serialize
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compiler_repairs_20261112'
OLD=ROOT/'exp/probabilistic_verification/compiler_readiness_20261112'
def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def corpus():
    started=time.perf_counter();rows=[compile_one(r)for r in read(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')]
    write(RUN/'direct_all.jsonl',rows)
    stats=dict(total=len(rows),compiled=sum(r['status']=='compiled'for r in rows),codes=dict(Counter(r.get('code')for r in rows if r['status']!='compiled')),elapsed_seconds=time.perf_counter()-started)
    (RUN/'direct_summary.json').write_text(json.dumps(stats,indent=2)+'\n');print(stats,flush=True)
def replay(filename,parsed_path,originals_path):
    parsed={r['claim_id']:r for r in read(parsed_path)};direct={r['claim_id']:r for r in read(RUN/'direct_all.jsonl')};out=[];started=time.perf_counter()
    for record in read(originals_path):
        cid=record['claim_id'];d=direct[cid];row=dict(claim_id=cid,original=record['text'],direct=d,components=[],proposal=None)
        if d['status']=='compiled':row.update(stage='direct_pass',output=d)
        elif cid not in parsed:row.update(stage='uncached_fallback',output=dict(status='unsupported',code='uncached_fallback',reason='No saved response: this original passed the generation-time direct compiler.'))
        else:
            source=parsed[cid];row['proposal']=source['proposal']
            if source['proposal']['action']in{'keep','refuse'}:row.update(stage='model_'+source['proposal']['action'],output=dict(status='unsupported',code='model_'+source['proposal']['action'],reason='Model returned no simpler sentence.'))
            else:
                for clause in source['clauses']:
                    part=copy.deepcopy(clause.get('record'))
                    if part:
                        part['compiler_context']=dict(original_text=record['text'])
                        if len(source['clauses'])==1:part['claim_id']=cid
                    result=compile_one(part)if part else dict(status='unsupported',code='sentence_parse',reason=clause['parse_error'])
                    row['components'].append(dict(id=clause['id'],text=clause['text'],result=result))
                failed=[c for c in row['components']if c['result']['status']!='compiled']
                if failed:row.update(stage='component_compilation',output=dict(status='unsupported',code=failed[0]['result'].get('code'),reason=failed[0]['id']+': '+failed[0]['result']['reason']))
                elif len(row['components'])==1:row.update(stage='compiled_single',output=row['components'][0]['result'])
                else:
                    try:
                        original=copy.deepcopy(record);original['compiler_options']=dict(OPTIONS,event_coreference=True,logical_operators=True)
                        claim,proposal,trace=compose_aligned(cid,original,source['clauses'],{c['id']:c['result']for c in row['components']},max_clauses=12)
                        row.update(stage='compiled_composed',proposal=proposal,alignment=trace,output=serialize(claim))
                    except Exception as error:
                        code=getattr(error,'code',type(error).__name__)
                        row.update(stage='alignment'if code in{'entity_alignment','mention_alignment','event_alignment','event_time_alignment','description_alignment','source_alignment'}else'composition',output=dict(status='unsupported',code=code,reason=str(error)))
        out.append(row)
    write(RUN/filename,out);print(filename,dict(Counter(r['stage']for r in out)),round(time.perf_counter()-started,2),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['corpus','cached','fresh']);a=p.parse_args()
    if a.action=='corpus':corpus()
    elif a.action=='cached':replay('cached_pipeline.jsonl',ROOT/'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl',ROOT/'exp/probabilistic_verification/rewrite_all_20261112/inputs.jsonl')
    else:replay('pipeline.jsonl',RUN/'parsed.jsonl',RUN/'inputs.jsonl')
