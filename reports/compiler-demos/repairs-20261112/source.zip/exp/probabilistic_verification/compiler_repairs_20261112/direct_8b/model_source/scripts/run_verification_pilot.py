#!/usr/bin/env python3
"""Small local-model generation/review pilot for ADR-023; no model training.

All language instructions are imported from prompts_phase2. Raw outputs and exact
prompts are saved before validation. Review labels are automatic, never gold.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
import time
from pathlib import Path

import prompts_phase2 as P

LABELS = ('supported', 'refuted', 'unknown')
ROOT = Path('/exp/cxiao/scale26/avid')
DEFAULT = ROOT / 'exp/probabilistic_verification/pilot_20261015'
TEXT_MODEL = '/home/hltcoe/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507'
VL_MODEL = '/home/hltcoe/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct'


def read(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]


def write(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(''.join(json.dumps(r, ensure_ascii=False, allow_nan=False)+'\n' for r in rows))


def digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def parse_json(raw):
    raw = raw.strip()
    if raw.startswith('```'):
        raw = raw.split('\n', 1)[1].rsplit('```', 1)[0]
    return json.loads(raw)


def validate_candidate(c, seed):
    errors = []
    required = {'candidate_text', 'edit_type', 'changed_relation', 'unchanged_content',
                'evidence_ids', 'proposed_label', 'review_questions'}
    if not required <= set(c):
        errors.append('missing_required_fields')
    if c.get('edit_type') not in {'role_swap', 'event_reassignment', 'attribute_reassignment', 'paraphrase'}:
        errors.append('invalid_edit_type')
    if c.get('proposed_label') not in LABELS:
        errors.append('invalid_label')
    if not isinstance(c.get('changed_relation'), str):
        errors.append('invalid_changed_relation_type')
    for field in ('unchanged_content', 'review_questions'):
        if not isinstance(c.get(field), list) or any(not isinstance(x,str) for x in c.get(field, [])):
            errors.append('invalid_'+field+'_type')
    ids = {e['evidence_id'] for e in seed['evidence_observations']}
    if not isinstance(c.get('evidence_ids'), list) or not set(c.get('evidence_ids', [])) <= ids:
        errors.append('invalid_evidence_ids')
    if not isinstance(c.get('candidate_text'), str) or not c.get('candidate_text', '').strip():
        errors.append('missing_text')
    return errors


class LocalModel:
    def __init__(self, model, visual, batch_size):
        from transformers import AutoTokenizer
        from vllm import LLM
        self.model_path, self.visual, self.batch_size = model, visual, batch_size
        self.tokenizer = AutoTokenizer.from_pretrained(model, local_files_only=True)
        config_files = {}
        for name in ('config.json', 'generation_config.json', 'tokenizer_config.json'):
            p = Path(model) / name
            if p.exists():
                config_files[name] = hashlib.sha256(p.read_bytes()).hexdigest()
        self.config = dict(model_path=str(Path(model).resolve()), model_config_hashes=config_files,
                           vllm=importlib.metadata.version('vllm'),
                           transformers=importlib.metadata.version('transformers'),
                           dtype='bfloat16', seed=42, max_model_len=16384,
                           frame_thumbnail=[384, 384], frame_selection='explicit_saved_paths',
                           enforce_eager=True, logprobs_mode='processed_logprobs')
        kw = dict(model=model, trust_remote_code=True, tensor_parallel_size=1,
                  dtype='bfloat16', seed=42, max_model_len=16384,
                  gpu_memory_utilization=0.90, enforce_eager=True,
                  logprobs_mode='processed_logprobs')
        if visual:
            kw['limit_mm_per_prompt'] = {'image': 8}
        self.llm = LLM(**kw)
        self.choice_ids = [self.tokenizer.encode(s, add_special_tokens=False) for s in 'ABC']
        if any(len(x) != 1 for x in self.choice_ids):
            raise ValueError('A/B/C must be individual tokens')
        self.choice_ids = [x[0] for x in self.choice_ids]

    def run(self, tasks, path, *, choices=False, max_tokens=1500):
        from PIL import Image
        from vllm import SamplingParams
        path = Path(path)
        previous = {r['request_hash']: r for r in read(path)} if path.exists() else {}
        rows, pending = [], []
        for task in tasks:
            frame_hashes = [dict(path=p, sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest())
                            for p in task.get('frame_paths', [])]
            spec = dict(task=task, config=self.config, frame_hashes=frame_hashes,
                        decoding=dict(temperature=0, max_tokens=1 if choices else max_tokens,
                                      allowed_token_ids=self.choice_ids if choices else None))
            key = digest(spec)
            if key in previous:
                rows.append(previous[key])
            else:
                pending.append((task, spec, key))
        print(f'{path.name}: {len(tasks)} requests, {len(pending)} uncached', flush=True)
        for offset in range(0, len(pending), self.batch_size):
            batch = pending[offset:offset+self.batch_size]
            requests = []
            for task, spec, key in batch:
                paths = task.get('frame_paths', [])
                if paths:
                    if not self.visual:
                        raise ValueError('Images supplied to text-only model')
                    content, images = [], []
                    for p in paths:
                        im = Image.open(p).convert('RGB')
                        im.thumbnail((384, 384), Image.Resampling.LANCZOS)
                        images.append(im)
                        content.extend([{'type':'text', 'text':Path(p).name}, {'type':'image'}])
                    content.append({'type':'text', 'text':task['user']})
                else:
                    content = task['user']
                messages = [{'role':'system', 'content':task['system']}, {'role':'user', 'content':content}]
                prompt = self.tokenizer.apply_chat_template(messages, tokenize=False,
                    add_generation_prompt=True, enable_thinking=False)
                request = {'prompt':prompt}
                if paths:
                    request['multi_modal_data'] = {'image':images}
                requests.append(request)
            sp = SamplingParams(temperature=0, max_tokens=1 if choices else max_tokens,
                                logprobs=3 if choices else None,
                                allowed_token_ids=self.choice_ids if choices else None)
            start = time.monotonic()
            outputs = self.llm.generate(requests, sp)
            elapsed = time.monotonic()-start
            with path.open('a') as f:
                for (task, spec, key), out in zip(batch, outputs):
                    generated = out.outputs[0]
                    r = dict(request_id=task['request_id'], request_hash=key,
                             request=spec, raw_text=generated.text,
                             prompt_tokens=len(out.prompt_token_ids),
                             generated_tokens=len(generated.token_ids),
                             finish_reason=generated.finish_reason,
                             batch_elapsed_seconds=elapsed, batch_size=len(batch),
                             status='ok')
                    if choices:
                        lp = generated.logprobs[0] if generated.logprobs else {}
                        values = [lp.get(tid) for tid in self.choice_ids]
                        if any(v is None for v in values):
                            r.update(status='missing_class_scores', distribution=None)
                        else:
                            scores = [v.logprob for v in values]
                            vals = [math.exp(x-max(scores)) for x in scores]
                            probs = [x/sum(vals) for x in vals]
                            r['distribution'] = dict(zip(LABELS, probs))
                            r['prediction'] = LABELS[max(range(3), key=lambda i:probs[i])]
                            r['score_semantics'] = 'uncalibrated probabilities normalized over constrained A/B/C tokens'
                    else:
                        try:
                            r['parsed'] = parse_json(generated.text)
                        except (ValueError, IndexError) as e:
                            r.update(status='invalid_json', parse_error=str(e))
                    f.write(json.dumps(r, ensure_ascii=False, allow_nan=False)+'\n')
                    f.flush()
                    rows.append(r)
            print(f'{path.name}: {min(offset+len(batch),len(pending))}/{len(pending)}, batch {elapsed:.1f}s', flush=True)
        return rows


def prepare_generation(seeds, system):
    tasks = []
    for s in seeds:
        record = {k:s[k] for k in ('seed_id','claim_text','review_status','evidence_observations','coverage_note','evidence_policy')}
        for e in record['evidence_observations']:
            e.pop('frame_paths', None)
        chosen_system = system
        if s.get('target_facts'):
            record.update({k:s[k] for k in ('source_facts','target_facts','fixed_facts')})
            chosen_system = P.VERIFICATION_REALIZE_SYSTEM
        tasks.append(dict(request_id=s['seed_id'], system=chosen_system,
                          user=P.verification_data_generation_user(record)))
    return tasks


def compile_claims(seeds, generated):
    byid = {r['request_id']:r for r in generated}
    claims, audit = [], []
    for seed in seeds:
        common = {k:seed[k] for k in ('seed_id','video_id','chunks','frame_paths','coverage_note','evidence_policy','partition')}
        claims.append(dict(common, sample_id=seed['seed_id']+':seed', claim_text=seed['claim_text'],
                           edit_type='seed', proposed_label='supported', label_source='assistant_frame_review_not_human_gold'))
        row = byid[seed['seed_id']]
        parsed = row.get('parsed', {})
        if seed.get('target_facts') and isinstance(parsed, dict):
            common_fields = dict(unchanged_content=seed['fixed_facts'],
                                 evidence_ids=[e['evidence_id'] for e in seed['evidence_observations']],
                                 review_questions=['Does the realized sentence preserve every supplied assignment?'])
            parsed = dict(seed_id=parsed.get('seed_id'),candidates=[
                dict(common_fields,candidate_text=parsed.get('negative_text',''),
                     edit_type='attribute_reassignment',changed_relation=seed['planned_change'],
                     proposed_label='refuted'),
                dict(common_fields,candidate_text=parsed.get('paraphrase_text',''),
                     edit_type='paraphrase',changed_relation='none',proposed_label='supported')])
        candidates = parsed.get('candidates', []) if isinstance(parsed, dict) else []
        if not isinstance(candidates, list):
            candidates = []
        seen = {seed['claim_text'].strip().casefold()}
        for i, c in enumerate(candidates):
            errors = validate_candidate(c, seed) if isinstance(c, dict) else ['invalid_object']
            text = c.get('candidate_text', '').strip() if isinstance(c, dict) else ''
            if text.casefold() in seen:
                errors.append('duplicate_text')
            if parsed.get('seed_id') != seed['seed_id']:
                errors.append('seed_id_mismatch')
            if len(candidates) > 3:
                errors.append('too_many_candidates')
            audit.append(dict(seed_id=seed['seed_id'], candidate_index=i, errors=errors,
                              candidate=c, structurally_valid=not errors))
            if errors:
                continue
            seen.add(text.casefold())
            claims.append(dict(common, sample_id=f"{seed['seed_id']}:variant:{i}", claim_text=text,
                               edit_type=c['edit_type'], proposed_label=c['proposed_label'],
                               changed_relation=c['changed_relation'], review_questions=c['review_questions'],
                               label_source='text_model_proposal_not_gold'))
    return claims, audit


def media_task(claim, system, suffix='', text=None, text_only=False):
    return dict(request_id=claim['sample_id']+suffix, system=system,
                frame_paths=[] if text_only else claim['frame_paths'],
                user=P.verification_media_review_user(claim_text=text or claim['claim_text'],
                    media_id=claim['video_id'], available_routes=[] if text_only else ['visual_depiction'],
                    evidence_policy=claim['evidence_policy'],
                    coverage_note='No media supplied: text-only control.' if text_only else claim['coverage_note']))


def visual_pass(model, run, *, review=True):
    claims = read(run/'claims.jsonl')
    if review:
        review_system = (P.VERIFICATION_DATA_REVIEW_SYSTEM if run.name=='v1'
                         else P.VERIFICATION_DATA_REVIEW_V2_SYSTEM)
        model.run([media_task(c, review_system) for c in claims], run/'review_raw.jsonl', max_tokens=768)
    model.run([media_task(c, P.VERIFICATION_BASELINE_SYSTEM) for c in claims], run/'whole_claim_raw.jsonl', choices=True)
    model.run([media_task(c, P.VERIFICATION_BASELINE_SYSTEM, text_only=True) for c in claims], run/'text_only_raw.jsonl', choices=True)
    decomposition_path = run/'decomposition_checked.jsonl'
    if not decomposition_path.exists():
        decomposition_path = run/'decomposition_raw.jsonl'
    print(f'Baseline decomposition: {decomposition_path}', flush=True)
    decomps = {r['request_id']:r for r in read(decomposition_path)}
    tasks, mapping = [], []
    shared = {}
    for c in claims:
        d = decomps[c['sample_id']].get('parsed', {})
        for kind in ('relations','atoms'):
            parts = d.get(kind, []) if isinstance(d, dict) else []
            if not isinstance(parts, list) or not parts or any(not isinstance(x,str) or not x.strip() for x in parts):
                mapping.append(dict(sample_id=c['sample_id'], kind=kind, error='invalid_decomposition'))
                continue
            for index, text in enumerate(parts):
                key = digest([c['video_id'], c['frame_paths'], text])
                rid = shared.get(key)
                if rid is None:
                    rid = key
                    shared[key] = rid
                    task = media_task(c, P.VERIFICATION_BASELINE_SYSTEM, text=text)
                    task['request_id'] = rid
                    tasks.append(task)
                mapping.append(dict(sample_id=c['sample_id'], kind=kind, part_index=index,
                                    text=text, request_id=rid))
    write(run/'part_mapping.jsonl', mapping)
    model.run(tasks, run/'parts_raw.jsonl', choices=True)


def main():
    a = argparse.ArgumentParser()
    a.add_argument('--stage', choices=['generate','visual','all'], required=True)
    a.add_argument('--run-dir', type=Path, default=DEFAULT)
    a.add_argument('--version', choices=['v1','v2','v3'], default='v1')
    a.add_argument('--model')
    a.add_argument('--compare-v1', action='store_true')
    a.add_argument('--batch-size', type=int, default=4)
    args = a.parse_args()
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    args.run_dir.mkdir(parents=True, exist_ok=True)
    run = args.run_dir / args.version
    run.mkdir(exist_ok=True)
    model = None
    if args.stage in ('generate','all'):
        seed_path = args.run_dir/'seeds_eligible.jsonl'
        if not seed_path.exists():
            seed_path = args.run_dir/'seeds_reviewed.jsonl'
        print(f'Generation inputs: {seed_path}', flush=True)
        seeds = read(seed_path)
        system = {'v1':P.VERIFICATION_DATA_GENERATE_SYSTEM,
                  'v2':P.VERIFICATION_DATA_GENERATE_V2_SYSTEM,
                  'v3':P.VERIFICATION_DATA_GENERATE_V3_SYSTEM}[args.version]
        model = LocalModel(args.model or (VL_MODEL if args.stage=='all' else TEXT_MODEL),
                           args.stage=='all', args.batch_size)
        generated = model.run(prepare_generation(seeds, system), run/'generation_raw.jsonl')
        claims, audit = compile_claims(seeds, generated)
        write(run/'claims.jsonl', claims)
        write(run/'generation_validation.jsonl', audit)
        decomposition_system = {'v1':P.VERIFICATION_DECOMPOSE_SYSTEM,
                                'v2':P.VERIFICATION_DECOMPOSE_V2_SYSTEM,
                                'v3':P.VERIFICATION_DECOMPOSE_V3_SYSTEM}[args.version]
        tasks = [dict(request_id=c['sample_id'], system=decomposition_system,
                      user=json.dumps({'claim_text':c['claim_text']}, ensure_ascii=False)) for c in claims]
        model.run(tasks, run/'decomposition_raw.jsonl', max_tokens=512)
        print(f'Prepared {len(claims)} claims; schema-valid variants {sum(not r["errors"] for r in audit)}', flush=True)
    if args.stage in ('visual','all'):
        claims = read(run/'claims.jsonl')
        model = model or LocalModel(args.model or VL_MODEL, True, args.batch_size)
        visual_pass(model, run)
        if args.compare_v1 and args.version != 'v1':
            visual_pass(model, args.run_dir/'v1', review=False)


if __name__ == '__main__':
    main()
