#!/usr/bin/env python3
"""Build the simplified gold-v3 semantic-unit annotation page.

The executable factor graph keeps latent/fixed composition machinery, but the
human surface deliberately hides it.  Annotators see only meaningful candidate
units and answer one binary applicability question (applicable vs NA), followed
by simple per-channel evidence labels for applicable units.
"""

from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from semantic_factor_tree import read_jsonl
from semantic_factor_tree_viz import build_factor_tree_svg


ROOT = Path("/exp/cxiao/scale26/avid")
DEFAULT_INPUT = ROOT / "exp/phase3/semantic_v1/semantic_factor_trees.jsonl"
DEFAULT_CLAIMS = ROOT / "exp/phase3/gold_v2/claims.tsv"
DEFAULT_OUTPUT = ROOT / "exp/phase3/gold_v3"
MANIFEST = ROOT / "exp/phase2/manifest_avid.jsonl"
SRC_VIDEOS = Path("/exp/cxiao/scale26/data/extracted/microvent/videos")
ASR_DIR = Path("/exp/cxiao/scale26/data/extracted/microvent/asr")
ASR_SYSTEMS = ["whisperxlargev3", "qwen3asr1p7b"]
M2_VISUAL = ROOT / "exp/phase3/semantic_v1/m2/verify_visual.jsonl"
M2_AUDIO = ROOT / "exp/phase3/semantic_v1/m2/verify_audio.jsonl"
M2_VISUAL_SOURCE = ROOT / "exp/phase3/semantic_v1/m2/verify_visual_source.jsonl"
M2_AUDIO_SOURCE = ROOT / "exp/phase3/semantic_v1/m2/verify_audio_source.jsonl"
LEGACY_M2_VISUAL = ROOT / "exp/phase3/nodes/verify_visual_star.jsonl"
LEGACY_M2_AUDIO = ROOT / "exp/phase3/nodes/verify_audio_star.jsonl"
T_STAR = ROOT / "exp/phase3/trees/trees_ud_star.jsonl"

SERVE_PY = '''#!/usr/bin/env python3
"""Localhost-only range-capable server for semantic gold-v3.

POST /save persists the annotation JSON to human_annotations.json (atomic write,
rolling .bak + one dated snapshot under backups/). The viewer saves completed
examples automatically; later corrections use Save example.
"""
import http.server, os, re, sys, json, shutil, datetime
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 9000
class H(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        if self.path.endswith(("/", ".html")):
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        super().end_headers()
    def do_GET(self):
        path = self.translate_path(self.path)
        if os.path.isdir(path) or not os.path.exists(path): return super().do_GET()
        size, ctype, rng = os.path.getsize(path), self.guess_type(path), self.headers.get("Range")
        if not rng: return super().do_GET()
        m = re.match(r"bytes=(\\d+)-(\\d*)", rng)
        if not m: return super().do_GET()
        start = int(m.group(1)); end = int(m.group(2)) if m.group(2) else size - 1
        end = min(end, size - 1); length = end - start + 1
        self.send_response(206); self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes"); self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Content-Length", str(length)); self.end_headers()
        with open(path, "rb") as f:
            f.seek(start)
            while length:
                buf = f.read(min(65536, length))
                if not buf: break
                try: self.wfile.write(buf)
                except (BrokenPipeError, ConnectionResetError): break
                length -= len(buf)
    def do_POST(self):
        if self.path.rstrip("/") != "/save":
            self.send_response(404); self.end_headers(); return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0 or n > 50_000_000:
                raise ValueError("bad content length")
            body = self.rfile.read(n)
            json.loads(body.decode("utf-8"))  # reject anything that is not valid JSON
            d = os.path.dirname(os.path.abspath(__file__))
            dst = os.path.join(d, "human_annotations.json")
            tmp = dst + ".tmp"
            with open(tmp, "wb") as f:
                f.write(body)
            if os.path.exists(dst):
                shutil.copy2(dst, dst + ".bak")
                bdir = os.path.join(d, "backups")
                os.makedirs(bdir, exist_ok=True)
                snap = os.path.join(bdir, "human_annotations." + datetime.date.today().isoformat() + ".json")
                if not os.path.exists(snap):
                    shutil.copy2(dst, snap)
            os.replace(tmp, dst)
            self.send_response(200); self.send_header("Content-Length", "2"); self.end_headers()
            self.wfile.write(b"ok")
        except Exception as exc:
            self.send_response(500); self.end_headers()
            try:
                self.wfile.write(str(exc).encode())
            except Exception:
                pass
if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), H)
    print(f"Serving {os.getcwd()} on http://127.0.0.1:{PORT}  (Ctrl-C to stop)")
    srv.serve_forever()
'''


def read_claim_order(path: Path) -> list[str]:
    with path.open(encoding="utf-8", newline="") as f:
        return [row["claim_id"] for row in csv.DictReader(f, delimiter="\t")]


def load_asr(chunk: str) -> list[dict[str, str]]:
    stem = chunk.removesuffix(".mp4")
    for system in ASR_SYSTEMS:
        path = ASR_DIR / system / f"{stem}.asr_{system}.json"
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            segs = (data.get("transcript") or {}).get("segments") or []
            text = " ".join((s.get("text") or "").strip() for s in segs if (s.get("text") or "").strip())
            if text:
                return [{"system": system, "text": text}]
        except (OSError, json.JSONDecodeError):
            pass
    return []


def _prediction_text(text: str) -> str:
    return " ".join((text or "").lower().split())


def load_model_predictions() -> dict[str, Any]:
    """Index fresh semantic-target predictions plus legacy root references."""
    visual_rows = read_jsonl(M2_VISUAL)
    audio_rows = read_jsonl(M2_AUDIO)
    visual_id = {(r["claim_id"], r["unit_id"]): r for r in visual_rows}
    audio_id = {(r["claim_id"], r["unit_id"]): r for r in audio_rows}
    visual_source_id = {
        (r["claim_id"], r["unit_id"]): r for r in read_jsonl(M2_VISUAL_SOURCE)
    }
    audio_source_id = {
        (r["claim_id"], r["unit_id"]): r for r in read_jsonl(M2_AUDIO_SOURCE)
    }
    legacy_visual = {
        (r["claim_id"], r["unit_id"]): r for r in read_jsonl(LEGACY_M2_VISUAL)
    }
    legacy_audio = {
        (r["claim_id"], r["unit_id"]): r for r in read_jsonl(LEGACY_M2_AUDIO)
    }
    roots = {r["claim_id"]: r.get("root_id", "") for r in read_jsonl(T_STAR)}
    return {
        "visual_id": visual_id, "audio_id": audio_id,
        "visual_source_id": visual_source_id, "audio_source_id": audio_source_id,
        "legacy_visual": legacy_visual, "legacy_audio": legacy_audio,
        "roots": roots,
    }


def _m2_prefill(
    record: dict[str, Any], target: dict[str, Any], predictions: dict[str, Any],
) -> tuple[str, str, str, str, str, str]:
    """Return exact semantic-target predictions and their provenance."""
    if target.get("evidence_role") == "abstain":
        return "", "", "", "", "Normalization predicts NA; channel probe not applicable", ""
    cid = record["claim_id"]
    key = (cid, target["id"])
    vrec = predictions["visual_id"].get(key)
    arec = predictions["audio_id"].get(key)
    if not vrec or not arec:
        return "", "", "", "", "", ""
    target_text = vrec.get("unit_text", "")
    evidence = {"yes": "yes", "no": "no", "cant_tell": "cannot_tell"}
    vsource = predictions["visual_source_id"].get(key, {}).get("source_pred", "")
    asource = predictions["audio_source_id"].get(key, {}).get("source_pred", "")
    return (
        evidence.get(vrec.get("pass1_verdict", ""), ""),
        evidence.get(arec.get("pass1_verdict", ""), ""),
        vsource, asource,
        "M2 semantic-v1 · exact target and natural question · pass-2 evidence source",
        target_text,
    )


def _claim_prefill(claim_id: str, predictions: dict[str, Any]) -> tuple[str, str, str]:
    root_id = predictions["roots"].get(claim_id, "")
    visual = predictions["legacy_visual"].get((claim_id, root_id), {}).get("pass1_verdict", "")
    audio = predictions["legacy_audio"].get((claim_id, root_id), {}).get("pass1_verdict", "")
    verdict = {"yes": "supported", "no": "unsupported", "cant_tell": "cannot_tell"}
    if not visual or not audio:
        return "", "", ""
    return (
        verdict.get(visual, ""), verdict.get(audio, ""),
        "Legacy whole-claim M2 reference; not composed from semantic-v1 targets",
    )


def annotation_items(record: dict[str, Any], predictions: dict[str, Any]) -> list[dict[str, Any]]:
    """Return only human-judged targets; hide latent, fixed, and root machinery."""
    rows: list[dict[str, Any]] = []
    for var in record["variables"]:
        if var["id"] == "y:claim" or var["evidence_role"] in {"latent_output", "contract"}:
            continue
        visual_pred, audio_pred, visual_source_pred, audio_source_pred, pred_source, pred_target_text = _m2_prefill(
            record, var, predictions
        )
        rows.append({
            "claim_id": record["claim_id"], "target_id": var["id"],
            "level": max(0, var["level"] - 1), "item_kind": "unit",
            "unit_text": var.get("display_text") or var["unit_text"],
            "relation_pred": "", "role_pred": "na" if var["evidence_role"] == "abstain" else "applicable",
            "visual_pred": visual_pred, "audio_pred": audio_pred,
            "visual_source_pred": visual_source_pred, "audio_source_pred": audio_source_pred,
            "prediction_source": pred_source, "prediction_target_text": pred_target_text,
            "visual_question": var["visual_question"], "audio_question": var["audio_question"],
            "role_gold": "", "visual_gold": "", "audio_gold": "", "notes": "",
        })
    for factor in record["factors"]:
        if factor["factor_scope"] == "root" or factor["evidence_role"] in {"fixed_factor", "contract"}:
            continue
        visual_pred, audio_pred, visual_source_pred, audio_source_pred, pred_source, pred_target_text = _m2_prefill(
            record, factor, predictions
        )
        rows.append({
            "claim_id": record["claim_id"], "target_id": factor["id"],
            "level": max(0, factor["level"] - 1), "item_kind": "relation",
            "unit_text": factor.get("display_text") or factor["unit_text"],
            "relation_pred": factor["semantic_relation"],
            "role_pred": "na" if factor["evidence_role"] == "abstain" else "applicable",
            "visual_pred": visual_pred, "audio_pred": audio_pred,
            "visual_source_pred": visual_source_pred, "audio_source_pred": audio_source_pred,
            "prediction_source": pred_source, "prediction_target_text": pred_target_text,
            "visual_question": factor["visual_question"], "audio_question": factor["audio_question"],
            "role_gold": "", "visual_gold": "", "audio_gold": "", "notes": "",
        })
    return sorted(rows, key=lambda r: (r["level"], r["target_id"]))


def build_data(records: list[dict[str, Any]], order: list[str], output: Path) -> list[dict[str, Any]]:
    by_claim = {r["claim_id"]: r for r in records}
    manifest = {(r["topic_id"], r["claim_index"]): r for r in read_jsonl(MANIFEST)}
    media = output / "media"
    media.mkdir(parents=True, exist_ok=True)
    predictions = load_model_predictions()
    claims = []
    for cid in order:
        rec = by_claim[cid]
        topic, _, index = cid.rpartition("_")
        meta = manifest.get((topic, int(index)), {})
        chunks = meta.get("chunks", [])
        for chunk in chunks:
            dst, src = media / chunk, SRC_VIDEOS / chunk
            if not dst.exists() and src.exists():
                dst.symlink_to(src)
        items = annotation_items(rec, predictions)
        visual_verdict_pred, audio_verdict_pred, verdict_prediction_source = _claim_prefill(
            cid, predictions
        )
        claims.append({
            "claim_id": cid, "claim_text": rec["claim_text"], "chunks": chunks,
            "asr": [a for chunk in chunks for a in load_asr(chunk)],
            "visual_verdict_pred": visual_verdict_pred,
            "audio_verdict_pred": audio_verdict_pred,
            "verdict_prediction_source": verdict_prediction_source,
            "items": items,
            "factor_tree_svg": build_factor_tree_svg(
                rec, {item["target_id"] for item in items}
            ),
        })
    return claims


HTML = r'''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AViD Gold v3 — Simplified semantic-unit annotation</title>
<style>
:root{--bg:#0e1117;--card:#171b24;--line:#303746;--fg:#e8ecf4;--mut:#99a3b6;--blue:#72a7ff;--purple:#c99cff;--green:#59d0aa;--orange:#ffb86b}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.48 system-ui,sans-serif}header{position:sticky;top:0;z-index:9;display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:10px 16px;background:#111620;border-bottom:1px solid var(--line)}header b{font-size:15px}.sp{flex:1}button,select,input,textarea{color:var(--fg);background:#10141c;border:1px solid #3a4354;border-radius:6px;padding:6px 8px}button{cursor:pointer}button:hover{border-color:var(--blue)}#jump{max-width:330px}main{max-width:1120px;margin:auto;padding:16px}.intro,.claim{background:var(--card);border:1px solid var(--line);border-radius:11px;padding:16px;margin-bottom:20px}.intro h2{margin:0 0 8px}.intro p{margin:6px 0;color:#cbd2df}.claim.done{outline:2px solid var(--green)}.chead{display:flex;gap:9px;align-items:center}.cid{font:12px ui-monospace,monospace;color:var(--mut)}.badge{border:1px solid var(--line);border-radius:10px;padding:2px 7px;color:var(--mut);font-size:11px}.ctext{font-size:17px;font-weight:650;margin:9px 0}video{width:100%;max-height:58vh;background:#000;border-radius:8px}audio{height:31px;vertical-align:middle}.media-row{margin:7px 0}.asr{padding:8px 10px;background:#111620;border-radius:7px;color:#cbd2df;max-height:180px;overflow:auto}.grp{margin-top:12px;padding:11px;background:#121720;border-radius:8px}.grp h3{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--mut);margin:0 0 8px}.factor-figure{margin:0}.treewrap{overflow:auto;padding:8px 4px 5px;border:1px solid #252d3a;border-radius:8px;background:#0e131b}.factor-tree{display:block;margin:auto}.factor-node.annotatable:hover rect{stroke-width:2.8}.treelegend{display:flex;gap:14px;flex-wrap:wrap;margin-top:9px;color:var(--mut);font-size:11px}.treelegend span{display:inline-flex;align-items:center;gap:6px}.treelegend i{display:inline-block;width:16px;height:12px;border-radius:4px}.tree-caption{margin:8px 0 0;color:var(--mut);font-size:11px}.tree-caption b{color:#cbd2df}table{width:100%;border-collapse:collapse;min-width:1040px}th,td{text-align:left;vertical-align:top;border-top:1px solid var(--line);padding:8px}th{color:var(--mut);font-size:10px;text-transform:uppercase;letter-spacing:.04em}.table-scroll{overflow:auto}.target{font-weight:650}.kind{font-size:10px;color:var(--mut)}.questions{font-size:12px;color:#cbd2df}.questions div+div{margin-top:5px}.questions b{color:var(--mut);font-size:10px;text-transform:uppercase}.gold select{width:100px}.evidence{display:grid;grid-template-columns:1fr 1fr;gap:6px}.evidence label{font-size:10px;color:var(--mut)}.evidence select{display:block;width:100%;margin-top:2px}.disabled{opacity:.38}.notes-input{width:100%}.flash{animation:flash 1.2s}@keyframes flash{0%{background:#40547b}100%{background:transparent}}.verdicts{display:flex;gap:14px;flex-wrap:wrap;align-items:center}.verdicts label{color:var(--mut)}.verdicts select{margin-left:4px}.claim-notes{width:100%;min-height:42px;margin-top:7px}.rule{display:grid;grid-template-columns:24px 1fr;gap:8px;margin:8px 0}.rule strong{color:var(--green)}.model-ref{min-width:180px;padding:7px 8px;border:1px solid #4a3b28;border-radius:7px;background:#1e1913;color:#d7c6aa;font-size:11px}.model-ref b{display:block;color:var(--orange);font-size:10px;text-transform:uppercase;letter-spacing:.04em}.model-ref .predrow{margin-top:3px}.model-ref .missing{color:#8f96a3}.human-cell{min-width:215px}.human-role{margin-bottom:6px}.human-role label{font-size:10px;color:var(--mut);text-transform:uppercase}.human-role select{display:block;margin-top:2px;width:100%}.separation-note{color:var(--orange)}.badge.ok{color:var(--green);border-color:var(--green)}.badge.warn{color:var(--orange);border-color:var(--orange)}
</style></head><body><header><b>AViD Gold v3 · simplified annotation</b><span class="badge">build __BUILD__</span><span id="progress"></span><span id="savestat" class="badge"></span><span class="sp"></span><select id="jump"></select><button onclick="exportTSV()">Export annotations TSV</button><button onclick="exportJSON()">Download annotations JSON</button><button onclick="exportPredictions()">Download model predictions</button><button onclick="document.getElementById('load').click()">Load annotations</button><input id="load" type="file" accept=".json" hidden></header>
<main><section class="intro"><h2>Simple target annotation</h2><p><b>Each example saves automatically when all targets and both claim verdicts are filled.</b> For later corrections or notes, click <b>Save example</b>. Unfinished edits stay in this tab until the example is complete; closing or reloading discards them. Download annotations JSON to keep a draft.</p><div class="rule"><strong>1</strong><span>Choose <b>applicable</b> if the displayed target has a meaningful audio-visual truth value; otherwise choose <b>NA</b>.</span></div><div class="rule"><strong>2</strong><span>For <b>applicable</b> targets, pick the <b>visual</b> evidence subtype: <b>no</b> / <b>OCR</b> (on-screen text) / <b>other visual</b> / <b>both</b> / <b>can't tell</b>.</span></div><div class="rule"><strong>3</strong><span>Pick the <b>audio</b> evidence the same way: <b>no</b> / <b>speech</b> / <b>other audio</b> / <b>both</b> / <b>can't tell</b>. Use <b>both</b> when two subtypes co-occur (captioned sign = OCR + other visual; chant = speech + other audio). Judge each row independently.</span></div><p class="separation-note"><b>Model predictions are read-only references.</b> Human annotation controls always start blank and are stored separately. Downloading annotations never includes model answers. OCR/other-visual and speech/other-audio source hints appear only when the corresponding model support prediction is yes.</p><p>The tree shows internal claim composition and fixed grammatical operators as muted orientation boxes, but they never appear in the annotation controls.</p></section><div id="claims"></div></main>
<script>const DATA=__DATA__;const KEY="avid_gold_v3_simple_v4";const PREVKEYS=["avid_gold_v3_simple_v3","avid_gold_v3_simple_v2"];const OLDKEY="avid_gold_v3_semantic_factor_tree_v1";const ROLES=["applicable","na"];const EV_VIS=["no","ocr","other_visual","both","cannot_tell"];const EV_AUD=["no","speech","other_audio","both","cannot_tell"];const VERDICTS=["supported","partially_supported","unsupported","cannot_tell"];let S=loadState();
function normRole(x){if(x==='not_na')return'applicable';if(x==='na'||x==='abstain'||x==='contract')return'na';return x==='applicable'?x:''}function cleanState(x){if(x&&x.annotations)x=x.annotations;const out={claims:(x&&x.claims)||{},items:{}};Object.entries((x&&x.items)||{}).forEach(([k,v])=>out.items[k]=Object.assign({},v,{role:normRole(v.role)}));return out}function loadState(){try{const current=JSON.parse(localStorage.getItem(KEY));if(current)return cleanState(current);for(const key of PREVKEYS){const previous=JSON.parse(localStorage.getItem(key));if(previous)return cleanState(previous)}const old=JSON.parse(localStorage.getItem(OLDKEY));if(!old)return{claims:{},items:{}};const migrated={claims:old.claims||{},items:{}};Object.entries(old.items||{}).forEach(([k,v])=>{migrated.items[k]={role:normRole(v.role),visual:v.visual==='no'?'no':(v.visual?'yes':''),audio:v.audio==='no'?'no':(v.audio?'yes':''),notes:v.notes||''}});return migrated}catch(e){return{claims:{},items:{}}}}// C holds the persisted snapshot; unfinished edits stay only in S.
let C={claims:{},items:{}}, dirty=new Set(), saveQueue=Promise.resolve();
let pendingSaves=0, unsynced=false, browserSaved=true;
function copy(x){return JSON.parse(JSON.stringify(x))}
function _payload(){return JSON.stringify({schema_version:'semantic-human-annotation-v5',annotation_only:true,annotations:C})}
function setStat(t,c){const e=document.getElementById('savestat');if(e){e.textContent=t;e.className='badge'+(c?' '+c:'')}}
function saveStatus(){
    if(pendingSaves)setStat('saving completed example…');
    else if(unsynced)setStat(browserSaved?'Save failed · browser copy kept · Save example to retry':'Save failed · Save example to retry','warn');
    else if(dirty.size)setStat('Unsaved edits · finish example or Save example','warn');
    else setStat('✔ saved examples','ok');
}
function serverSave(body){
    return fetch('/save',{method:'POST',headers:{'Content-Type':'application/json'},body}).then(r=>{if(!r.ok)throw new Error('Save failed');unsynced=false}).catch(()=>{unsynced=true});
}
function claimDone(c){const cs=claimState(c.claim_id);return !!(c.items.every(x=>itemDone(c,x))&&cs.visual_verdict&&cs.audio_verdict)}
function claimSnapshot(s,c){return JSON.stringify([s.claims[c.claim_id]||{},c.items.map(x=>s.items[ik(c.claim_id,x.target_id)]||{})])}
function markDirty(c){if(claimSnapshot(S,c)===claimSnapshot(C,c))dirty.delete(c.claim_id);else dirty.add(c.claim_id)}
function saveClaims(claims){
    const complete=claims.filter(claimDone);
    if(!complete.length)return saveQueue;
    complete.forEach(c=>{
        C.claims[c.claim_id]=copy(S.claims[c.claim_id]||{});
        c.items.forEach(x=>{const k=ik(c.claim_id,x.target_id);C.items[k]=copy(S.items[k]||{})});
        dirty.delete(c.claim_id);
    });
    // Never include a different example's in-progress edits in this request.
    const body=_payload();
    try{localStorage.setItem(KEY,JSON.stringify(C));browserSaved=true}catch(e){browserSaved=false}
    pendingSaves++;
    saveQueue=saveQueue.then(()=>serverSave(body)).finally(()=>{pendingSaves--;update();saveStatus()});
    update();saveStatus();
    return saveQueue;
}
function saveClaim(id){const c=DATA.claims.find(c=>c.claim_id===id);if(c)return saveClaims([c])}
function changed(c,wasDone){markDirty(c);update();if(!wasDone&&claimDone(c))saveClaims([c]);else saveStatus()}
window.addEventListener('beforeunload',e=>{if(dirty.size||pendingSaves||unsynced){e.preventDefault();e.returnValue=''}});
function esc(x){return String(x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function escAttr(x){return esc(x).replace(/"/g,"&quot;")}function label(x){const M={na:'NA',ocr:'OCR',other_visual:'other visual',other_audio:'other audio',speech:'speech',both:'both',no:'no',cannot_tell:"can't tell"};return M[x]||String(x||'').replaceAll('_',' ')}function opts(xs,selected=""){return '<option value=""></option>'+xs.map(x=>`<option value="${x}"${x===selected?' selected':''}>${label(x)}</option>`).join('')}function ik(c,t){return c+"\t"+t}function state(c,t){return Object.assign({role:'',visual:'',audio:'',notes:''},S.items[ik(c,t)]||{})}function claimState(c){return Object.assign({visual_verdict:'',audio_verdict:'',notes:''},S.claims[c]||{})}function pv(x){return x?esc(label(x)):'<span class="missing">—</span>'}function sourceLabel(x){return({ocr:'OCR',other_visual:'other visual',speech:'speech',other_audio:'other audio'})[x]||label(x)}function supportLine(name,support,source){const suffix=support==='yes'&&source?` · source: ${esc(sourceLabel(source))}`:'';return`${name}: ${pv(support)}${suffix}`}
function itemRow(c,x){const st=state(c.claim_id,x.target_id),active=st.role==='applicable',channels=x.role_pred==='na'?'<span class="missing">Visual/audio: NA</span>':`${supportLine('Visual',x.visual_pred,x.visual_source_pred)}<br>${supportLine('Audio',x.audio_pred,x.audio_source_pred)}`,src=x.prediction_source||'Prediction unavailable';return `<tr id="row-${esc(c.claim_id)}-${esc(x.target_id)}"><td><div class="target">${esc(x.unit_text)}</div><div class="kind">${x.item_kind==='unit'?'object / action':'relationship / property'}</div></td><td class="questions"><div><b>Visual</b> ${esc(x.visual_question)||'—'}</div><div><b>Audio</b> ${esc(x.audio_question)||'—'}</div></td><td><div class="model-ref" title="${escAttr(src)}"><b>Model reference</b><div class="predrow">Applicability: ${pv(x.role_pred)}</div><div class="predrow">${channels}</div></div></td><td class="human-cell"><div class="human-role"><label>applicability<select data-c="${esc(c.claim_id)}" data-t="${esc(x.target_id)}" data-f="role">${opts(ROLES,st.role)}</select></label></div><div class="evidence ${active?'':'disabled'}"><label>visual<select data-c="${esc(c.claim_id)}" data-t="${esc(x.target_id)}" data-f="visual" ${active?'':'disabled'}>${opts(EV_VIS,st.visual)}</select></label><label>audio<select data-c="${esc(c.claim_id)}" data-t="${esc(x.target_id)}" data-f="audio" ${active?'':'disabled'}>${opts(EV_AUD,st.audio)}</select></label></div></td><td><input class="notes-input" data-c="${esc(c.claim_id)}" data-t="${esc(x.target_id)}" data-f="notes" value="${esc(st.notes)}" placeholder="optional"></td></tr>`}
function render(){const root=document.getElementById('claims'),jump=document.getElementById('jump');root.innerHTML='';jump.innerHTML='';DATA.claims.forEach((c,i)=>{jump.insertAdjacentHTML('beforeend',`<option value="c${i}">${i+1}. ${esc(c.claim_id)}</option>`);const cs=claimState(c.claim_id),videos=c.chunks.map(ch=>`<video controls preload="none" src="media/${esc(ch)}"></video>`).join(''),audios=c.chunks.map(ch=>`<audio controls preload="none" src="media/${esc(ch)}"></audio>`).join(' '),asr=c.asr.length?c.asr.map(a=>`<div><span class="kind">[${esc(a.system)}]</span> ${esc(a.text)}</div>`).join(''):'<span class="kind">No ASR transcript.</span>',claimPred=c.visual_verdict_pred||c.audio_verdict_pred?`<div class="model-ref" title="${escAttr(c.verdict_prediction_source)}"><b>Legacy model reference</b><div class="predrow">V: ${pv(c.visual_verdict_pred)} · A: ${pv(c.audio_verdict_pred)}</div></div>`:'<div class="model-ref"><b>Model reference</b><span class="missing">not available</span></div>';const sec=document.createElement('section');sec.className='claim';sec.id='c'+i;sec.innerHTML=`<div class="chead"><span class="cid">#${i+1} · ${esc(c.claim_id)}</span><span class="badge">${c.items.length} targets</span><button data-save-claim="${esc(c.claim_id)}" disabled>Save example</button></div><div class="ctext">${esc(c.claim_text)}</div>${videos}<div class="media-row">🔊 ${audios}</div><details><summary>ASR transcript</summary><div class="asr">${asr}</div></details><div class="grp"><h3>Claim-level verdicts</h3><div class="verdicts">${claimPred}<label>human visual<select data-c="${esc(c.claim_id)}" data-cf="visual_verdict">${opts(VERDICTS,cs.visual_verdict)}</select></label><label>human audio<select data-c="${esc(c.claim_id)}" data-cf="audio_verdict">${opts(VERDICTS,cs.audio_verdict)}</select></label></div><textarea class="claim-notes" data-c="${esc(c.claim_id)}" data-cf="notes" placeholder="optional claim notes">${esc(cs.notes)}</textarea></div><div class="grp"><h3>Factor tree · click a colored target to jump to its row</h3><figure class="factor-figure"><div class="treewrap" data-claim="${esc(c.claim_id)}">${c.factor_tree_svg}</div><div class="treelegend"><span><i style="background:#1c2d49;border:2px solid var(--blue)"></i>content target</span><span><i style="background:#302443;border:2px solid var(--purple);border-radius:8px"></i>relationship / property target</span><span><i style="background:#1b202a;border:2px dashed #667085"></i>internal · not annotated</span><span><i style="background:#2a2320;border:2px dashed #b08a4a"></i>na · dropped as not checkable</span></div><figcaption class="tree-caption"><b>Figure ${i+1}.</b> Executable factor tree for this claim. Branches carry evidence upward; gray/green bookkeeping boxes are shown for orientation but have no annotation row.</figcaption></figure></div><div class="grp"><h3>Target annotation</h3><div class="table-scroll"><table><thead><tr><th>target</th><th>natural questions</th><th>model prediction</th><th>human annotation</th><th>notes</th></tr></thead><tbody>${c.items.map(x=>itemRow(c,x)).join('')}</tbody></table></div></div>`;root.appendChild(sec)});bind();update();jump.onchange=()=>document.getElementById(jump.value).scrollIntoView({behavior:'smooth'})}
function bind(){
    document.querySelectorAll('[data-f]').forEach(e=>{
        const handler=()=>{
            const c=DATA.claims.find(c=>c.claim_id===e.dataset.c),wasDone=claimDone(c),k=ik(e.dataset.c,e.dataset.t);
            S.items[k]=S.items[k]||{};S.items[k][e.dataset.f]=e.value;
            if(e.dataset.f==='role'){
                const active=e.value==='applicable',row=e.closest('tr');
                if(!active){S.items[k].visual='';S.items[k].audio=''}
                row.querySelector('.evidence').classList.toggle('disabled',!active);
                row.querySelectorAll('[data-f="visual"],[data-f="audio"]').forEach(field=>{field.disabled=!active;field.value=S.items[k][field.dataset.f]||''});
            }
            changed(c,wasDone);
        };
        if(e.dataset.f==='notes')e.oninput=handler;else e.onchange=handler;
    });
    document.querySelectorAll('[data-cf]').forEach(e=>{
        const handler=()=>{
            const c=DATA.claims.find(c=>c.claim_id===e.dataset.c),wasDone=claimDone(c);
            S.claims[e.dataset.c]=S.claims[e.dataset.c]||{};S.claims[e.dataset.c][e.dataset.cf]=e.value;
            changed(c,wasDone);
        };
        if(e.dataset.cf==='notes')e.oninput=handler;else e.onchange=handler;
    });
    document.querySelectorAll('[data-save-claim]').forEach(e=>e.onclick=()=>saveClaim(e.dataset.saveClaim));
    document.querySelectorAll('.factor-node.annotatable').forEach(g=>g.onclick=()=>{const wrap=g.closest('.treewrap'),row=document.getElementById('row-'+wrap.dataset.claim+'-'+g.dataset.target);if(row){row.scrollIntoView({behavior:'smooth',block:'center'});row.classList.remove('flash');void row.offsetWidth;row.classList.add('flash')}});
}
function itemDone(c,x){const s=state(c.claim_id,x.target_id);return s.role==='na'||(s.role==='applicable'&&s.visual&&s.audio)}function update(){let done=0,total=0,cdone=0;DATA.claims.forEach((c,i)=>{const cs=claimState(c.claim_id),ok=claimDone(c);total+=c.items.length+1;done+=c.items.filter(x=>itemDone(c,x)).length+(cs.visual_verdict&&cs.audio_verdict?1:0);if(ok)cdone++;document.getElementById('c'+i)?.classList.toggle('done',!!ok);const button=document.querySelector('[data-save-claim=\"'+c.claim_id+'\"]');if(button){button.disabled=!ok||(!dirty.has(c.claim_id)&&!unsynced);button.textContent=unsynced?'Retry save':'Save example'}});document.getElementById('progress').textContent=`${done}/${total} decisions · ${cdone}/${DATA.claims.length} claims complete`}
function tsv(rows){return rows.map(r=>r.map(x=>'"'+String(x??'').replace(/"/g,'""')+'"').join('\t')).join('\n')+'\n'}function dl(name,text,type='text/tab-separated-values'){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}function exportTSV(){const ch=[["claim_id","claim_text","visual_gold","audio_gold","notes"]],it=[["claim_id","target_id","unit_text","role_gold","visual_gold","audio_gold","notes"]];DATA.claims.forEach(c=>{const cs=claimState(c.claim_id);ch.push([c.claim_id,c.claim_text,cs.visual_verdict,cs.audio_verdict,cs.notes]);c.items.forEach(x=>{const s=state(c.claim_id,x.target_id);it.push([c.claim_id,x.target_id,x.unit_text,s.role,s.visual,s.audio,s.notes])})});dl('human_claim_annotations.tsv',tsv(ch));setTimeout(()=>dl('human_target_annotations.tsv',tsv(it)),250)}function exportPredictions(){const rows=[["claim_id","target_id","unit_text","role_pred","visual_pred","visual_source_pred","audio_pred","audio_source_pred","prediction_source","visual_question","audio_question"]];DATA.claims.forEach(c=>c.items.forEach(x=>rows.push([c.claim_id,x.target_id,x.unit_text,x.role_pred,x.visual_pred,x.visual_source_pred,x.audio_pred,x.audio_source_pred,x.prediction_source,x.visual_question,x.audio_question])));dl('model_predictions.tsv',tsv(rows))}function exportJSON(){const out={schema_version:'semantic-human-annotation-v5',annotation_only:true,annotations:{claims:S.claims,items:S.items}};dl('human_annotations.json',JSON.stringify(out,null,2),'application/json')}document.getElementById('load').onchange=e=>{
    const r=new FileReader();
    r.onload=()=>{try{S=cleanState(JSON.parse(r.result));DATA.claims.forEach(markDirty);render();saveClaims(DATA.claims.filter(c=>dirty.has(c.claim_id)));saveStatus()}catch(_){alert('Invalid annotation JSON')}};
    if(e.target.files[0])r.readAsText(e.target.files[0]);
};
function stateSize(x){return Object.keys((x&&x.items)||{}).length+Object.keys((x&&x.claims)||{}).length}
function boot(){
    document.getElementById('load').disabled=true;
    setStat('loading saved annotations…');
    fetch('/human_annotations.json',{cache:'no-store'}).then(r=>{if(r.status===404)return null;if(!r.ok)throw new Error('Load failed');return r.json()}).then(srv=>{
        C=copy(srv?cleanState(srv):S);
        if(srv){
            const ss=cleanState(srv);
            // Retain the old browser draft when it has more entries, but preserve
            // all cluster annotations in the snapshot sent on the next completion.
            S=stateSize(ss)>=stateSize(S)?copy(ss):{claims:Object.assign({},ss.claims,S.claims),items:Object.assign({},ss.items,S.items)};
        }
        DATA.claims.forEach(markDirty);render();saveStatus();document.getElementById('load').disabled=false;
    }).catch(()=>setStat('Could not load saved annotations · reload to retry','warn'));
}
boot();
</script></body></html>'''


def write_tsv(output: Path, claims: list[dict[str, Any]]) -> None:
    claim_fields = ["claim_id", "claim_text", "visual_gold", "audio_gold", "notes"]
    item_fields = [
        "claim_id", "target_id", "unit_text", "visual_question", "audio_question",
        "role_gold", "visual_gold", "audio_gold", "notes",
    ]
    prediction_fields = [
        "claim_id", "target_id", "level", "item_kind", "unit_text", "relation_pred",
        "role_pred", "visual_pred", "visual_source_pred", "audio_pred",
        "audio_source_pred", "prediction_source",
        "prediction_target_text", "visual_question", "audio_question",
    ]
    probe_fields = [
        "claim_id", "target_id", "unit_id", "unit_text", "claim_text", "item_kind",
        "role_pred", "visual_question", "audio_question",
    ]
    with (output / "claims.tsv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=claim_fields, delimiter="\t")
        writer.writeheader()
        for claim in claims:
            writer.writerow({
                "claim_id": claim["claim_id"], "claim_text": claim["claim_text"],
                "visual_gold": "", "audio_gold": "", "notes": "",
            })
    with (output / "semantic_units.tsv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=item_fields, delimiter="\t")
        writer.writeheader()
        for claim in claims:
            for item in claim["items"]:
                writer.writerow({k: item.get(k, "") for k in item_fields})
    with (output / "model_predictions.tsv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=prediction_fields, delimiter="\t")
        writer.writeheader()
        for claim in claims:
            for item in claim["items"]:
                writer.writerow({k: item.get(k, "") for k in prediction_fields})
    with (output / "probe_targets.tsv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=probe_fields, delimiter="\t")
        writer.writeheader()
        for claim in claims:
            for item in claim["items"]:
                if item["role_pred"] == "na":
                    continue
                writer.writerow({
                    "claim_id": claim["claim_id"], "target_id": item["target_id"],
                    "unit_id": item["target_id"], "unit_text": item["unit_text"],
                    "claim_text": claim["claim_text"], "item_kind": item["item_kind"],
                    "role_pred": item["role_pred"],
                    "visual_question": item["visual_question"],
                    "audio_question": item["audio_question"],
                })
    prediction_payload = {
        "schema_version": "semantic-model-predictions-v2",
        "prediction_only": True,
        "claims": [
            {
                "claim_id": claim["claim_id"],
                "claim_text": claim["claim_text"],
                "visual_verdict_pred": claim["visual_verdict_pred"],
                "audio_verdict_pred": claim["audio_verdict_pred"],
                "verdict_prediction_source": claim["verdict_prediction_source"],
                "items": [
                    {k: item.get(k, "") for k in prediction_fields if k != "claim_id"}
                    for item in claim["items"]
                ],
            }
            for claim in claims
        ],
    }
    (output / "model_predictions.json").write_text(
        json.dumps(prediction_payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (output / "annotation_template.json").write_text(
        json.dumps({
            "schema_version": "semantic-human-annotation-v5",
            "annotation_only": True,
            "annotations": {"claims": {}, "items": {}},
        }, indent=2) + "\n",
        encoding="utf-8",
    )
    old = output / "semantic_items.tsv"
    if old.exists():
        old.rename(output / "semantic_items.v1.tsv")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    ap.add_argument("--claims", type=Path, default=DEFAULT_CLAIMS)
    ap.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    claims = build_data(read_jsonl(args.input), read_claim_order(args.claims), args.output)
    write_tsv(args.output, claims)
    build = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%SZ")
    payload = json.dumps({"schema_version": "semantic-unit-annotation-v4", "claims": claims},
                         ensure_ascii=False).replace("</", "<\\/")
    (args.output / "index.html").write_text(
        HTML.replace("__BUILD__", build).replace("__DATA__", payload), encoding="utf-8"
    )
    (args.output / "serve.py").write_text(SERVE_PY, encoding="utf-8")
    manifest = {
        "schema_version": "semantic-unit-annotation-v4", "built_at": build,
        "input": str(args.input), "claim_sample": str(args.claims),
        "claim_count": len(claims), "item_count": sum(len(c["items"]) for c in claims),
        "hidden_internal_targets": ["latent claim output", "root composition", "fixed operators"],
        "factor_tree_visualization": True,
        "gold_role_labels": ["applicable", "na"], "evidence_labels": ["yes", "no", "cannot_tell"],
        "role_prediction_count": sum(len(c["items"]) for c in claims),
        "channel_prediction_count": sum(
            1 for c in claims for item in c["items"]
            if item["visual_pred"] and item["audio_pred"]
        ),
        "visual_source_prediction_count": sum(
            1 for c in claims for item in c["items"] if item["visual_source_pred"]
        ),
        "audio_source_prediction_count": sum(
            1 for c in claims for item in c["items"] if item["audio_source_pred"]
        ),
        "claim_verdict_prediction_count": sum(
            1 for c in claims if c["visual_verdict_pred"] and c["audio_verdict_pred"]
        ),
        "annotation_defaults": "blank; predictions are read-only and separately exported",
        "channel_prediction_policy": (
            "Fresh semantic-v1 M2 inference for every normalized probe target, keyed "
            "by exact target id, target text, and natural modality-specific question; "
            "normalization-predicted NA targets show channels as not applicable; "
            "pass-1 yes targets also receive an OCR/other-visual or speech/other-audio source prediction"
        ),
        "question_quality_annotation": False,
    }
    (args.output / "build_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"simplified gold-v3: {len(claims)} claims, {manifest['item_count']} items -> {args.output}")


if __name__ == "__main__":
    main()
