#!/usr/bin/env python3
"""
AViD Phase 3 — Build the gold-pilot annotation surface (ADR-015, frozen contract).

Samples N claims and emits the span-anchored gold surface on the *tree-node* set
(NOT the legacy r5e pilot template, which is retired). Two files:

  nodes.tsv   — one row per CONTENT tree node (probeable + na; structural operators are
                parser-determined by deprel and excluded), span-anchored.
                * node_kind_pred is shown so the annotator VALIDATES it → role_gold
                  (probeable vs na — the check-worthiness / na-detection validation of fix (i)).
                * per-modality gold (visual_gold/audio_gold in {no,A,B}) is collected ONLY for
                  probed-content rows (video-grounded, the modality-attribution headline);
                  na-content rows' modality cells are pre-filled "—".
  claims.tsv  — one row per sampled claim: verdict_visual + verdict_audio (per-channel root gold).

Only STRUCTURAL predictions (node_kind_pred) are shown; support/modality/verdict
model predictions are withheld to keep the gold blind (per annotation_guidelines).

Gold is for EVALUATION, not training — so we never emit full-tree video-grounded
modality gold; the perturbation set carries node-level compositional gold.

Usage:
    python scripts/build_gold_pilot.py [--n 200] [--seed 20260704]
"""

import argparse
import csv
import json
import random
from pathlib import Path

# Default to the parse-normalized tree (T*): its nodes carry pn_unit_text/pn_unit_span
# (merged units, e.g. "by hand") and role (probeable/na/op from PN-1/2/3). Pass
# --trees .../trees_ud.jsonl to build from the raw pre-PN surface instead.
TREES_UD = "/exp/cxiao/scale26/avid/exp/phase3/trees/trees_ud_star.jsonl"
OUTDIR = "/exp/cxiao/scale26/avid/exp/phase3/gold_pilot"

# Per-modality node gold states. The CRF emission is 3-state {no, A, B} (exclusive
# subtype — ADR-006 forced-choice pass-2), but a unit can be grounded by BOTH
# sub-channels (captioned sign = ocr+other; chant = speech+other), so the GOLD adds
# "both". support(M) := gold_M != "no"; eval scores the model's single subtype by
# membership in the gold set (ADR-015).
VISUAL_STATES = ["no", "other", "ocr", "both"]     # A=ocr, B=other, both=ocr+other
AUDIO_STATES = ["no", "speech", "other", "both"]   # A=speech, B=other, both=speech+other

NODE_COLS = [
    "claim_id", "node_id", "node_kind_pred", "node_type", "deprel",
    "span_start", "span_end", "unit_text", "claim_highlighted",
    "under_negation",          # auto: 1 if this node's unary is flipped (scope of a neg)
    "role_gold",               # ANNOTATE (content rows): probeable | na  (check-worthiness;
                               #   structural operators are parser-set by deprel and excluded)
    "visual_gold",             # ANNOTATE (probed rows): no | other | ocr
    "audio_gold",              # ANNOTATE (probed rows): no | speech | other
    "notes",
]

CLAIM_COLS = [
    "claim_id", "claim_text", "n_nodes", "n_probed",
    "verdict_visual",          # ANNOTATE: supported | partially_supported | unsupported
    "verdict_audio",           # ANNOTATE: supported | partially_supported | unsupported
    "notes",
]


def node_kind(n: dict) -> str:
    # Prefer the PN role (op/na/probeable) from T* (parse normalization: PN-1 sets it,
    # PN-2 SRL + PN-3 F₃ refine it). Fall back to the pre-PN probed/is_functional flags
    # when building from a raw trees_ud.jsonl input that has no role field.
    role = n.get("role")
    if role == "op":
        return "structural-op"
    if role == "na":
        return "na-content"
    if role == "probeable":
        return "probed-content"
    if n.get("probed"):
        return "probed-content"
    if n.get("is_functional"):
        return "structural-op"
    return "na-content"


def highlight_span(claim_text: str, s: int, e: int) -> str:
    if s is None or e is None or s < 0 or e <= s:
        return claim_text
    s = max(0, s)
    e = min(len(claim_text), e)
    return claim_text[:s] + "**" + claim_text[s:e] + "**" + claim_text[e:]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--trees", default=TREES_UD)
    ap.add_argument("--outdir", default=OUTDIR)
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--seed", type=int, default=20260704)
    args = ap.parse_args()

    trees = {}
    with open(args.trees, encoding="utf-8") as f:
        for line in f:
            t = json.loads(line)
            trees[t["claim_id"]] = t

    all_ids = sorted(trees)
    n = min(args.n, len(all_ids))
    sampled = sorted(random.Random(args.seed).sample(all_ids, n))

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    n_node_rows = n_probed_rows = 0
    with open(outdir / "nodes.tsv", "w", encoding="utf-8", newline="") as fn:
        w = csv.DictWriter(fn, fieldnames=NODE_COLS, delimiter="\t")
        w.writeheader()
        for cid in sampled:
            t = trees[cid]
            ct = t["claim_text"]
            for node in t["nodes"]:
                kind = node_kind(node)
                if kind == "structural-op":
                    continue   # operators are parser-determined (deprel); not annotated
                probed = kind == "probed-content"
                if probed:
                    sp = (node.get("pn_unit_span") or node.get("content_subtree_span")
                          or node.get("span") or [-1, -1])
                    utext = (node.get("pn_unit_text") or node.get("content_subtree_text")
                             or node.get("node_text", ""))
                else:
                    sp = (node.get("pn_unit_span") or node.get("span") or [-1, -1])
                    utext = (node.get("pn_unit_text") or node.get("node_text", ""))
                row = {
                    "claim_id": cid,
                    "node_id": node["node_id"],
                    "node_kind_pred": kind,
                    "node_type": node.get("node_type", ""),
                    "deprel": node.get("deprel", ""),
                    "span_start": sp[0],
                    "span_end": sp[1],
                    "unit_text": utext,
                    "claim_highlighted": highlight_span(ct, sp[0], sp[1]),
                    "under_negation": 1 if node.get("negated") else 0,
                    "role_gold": "",
                    "visual_gold": "" if probed else "—",
                    "audio_gold": "" if probed else "—",
                    "notes": "",
                }
                w.writerow(row)
                n_node_rows += 1
                if probed:
                    n_probed_rows += 1

    with open(outdir / "claims.tsv", "w", encoding="utf-8", newline="") as fc:
        w = csv.DictWriter(fc, fieldnames=CLAIM_COLS, delimiter="\t")
        w.writeheader()
        for cid in sampled:
            t = trees[cid]
            nodes = t["nodes"]
            w.writerow({
                "claim_id": cid,
                "claim_text": t["claim_text"],
                "n_nodes": len(nodes),
                "n_probed": sum(1 for x in nodes if x.get("probed")),
                "verdict_visual": "",
                "verdict_audio": "",
                "notes": "",
            })

    print(f"Sampled {n} claims (seed={args.seed}).")
    print(f"nodes.tsv:  {n_node_rows} rows  ({n_probed_rows} probed-content, "
          f"{n_node_rows - n_probed_rows} na-content; structural operators excluded)")
    print(f"claims.tsv: {n} rows")
    print(f"→ {outdir}")


if __name__ == "__main__":
    main()
