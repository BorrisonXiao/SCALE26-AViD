"""Fixed automatic comparison: discard model links, align to original mentions."""
import argparse
import hashlib
import json
from pathlib import Path
from compile_claim_splits import serialize
from run_content_relations_census import compile_one
from probabilistic_verification.split_alignment import compose_aligned

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/split_alignment_20261112'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--condition', choices=['old_sentences','sentences'], required=True)
    args=parser.parse_args()
    original={r['claim_id']:r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())}
    source=ROOT/'exp/probabilistic_verification/claim_split_20261112/parsed.jsonl'if args.condition=='old_sentences'else RUN/'parse_input/parsed.jsonl'
    rows=[]
    for parsed in map(json.loads,source.read_text().splitlines()):
        cid=parsed['claim_id']
        parts=[dict(id=c['id'],text=c['text'],result=compile_one(c['record'])if 'record'in c else dict(status='unsupported',reason=c['parse_error']))for c in parsed['clauses']]
        row=dict(claim_id=cid,clauses=parsed['proposal']['clauses'],components=parts,
                 output=dict(status='unsupported',code='no_split',reason='No multi-sentence split proposed.'))
        if parsed['proposal']['action']=='split' and len(parts)>=2:
            try:
                claim,proposal,trace=compose_aligned(cid,original[cid],row['clauses'],{c['id']:c['result']for c in parts})
                row.update(proposal=proposal,alignment=trace,output=serialize(claim))
            except Exception as error:
                row['output']=dict(status='unsupported',code=getattr(error,'code',type(error).__name__),reason=str(error))
        rows.append(row)
    path=RUN/(args.condition+'_results.jsonl')
    path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
    print(args.condition,len(rows),'cases;',sum(r['output']['status']=='compiled'for r in rows),'programs')


if __name__=='__main__':main()
