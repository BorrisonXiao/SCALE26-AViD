"""Check every saved case, exact model messages, old navigation and mobile layout."""
import functools
import http.server
import json
import threading
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/rewrite_all_20261112'


def main():
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *args):
            pass
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Handler, directory=str(ROOT / 'site')))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f'http://127.0.0.1:{server.server_port}'
    cases = json.loads((RUN / 'cases.json').read_text())
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1100})
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto(base + '/reports/', wait_until='networkidle')
        assert page.locator('.card-link').count() == 2
        page.goto(base + '/reports/compiler-demos.html#remaining-failures', wait_until='networkidle')
        page.wait_for_function('document.querySelector("#full-case").options.length===449')
        assert page.locator('[role="tab"]').all_text_contents() == ['Overview', 'Examples', 'All claims', 'Daily log', 'History']
        text = page.locator('#current-work').inner_text()
        assert all(t in text for t in ['1,953', '82.23%', '419', '207', '142', '84', '27', '57', '422', '360'])
        page.evaluate('document.querySelector("#remaining-failures").scrollIntoView({behavior:"instant",block:"start"})')
        page.screenshot(path=str(RUN / 'overview_desktop.png'))
        for fragment, panel in [('full-rewrite-example','walkthroughs'), ('split-alignment','history'), ('alignment-example','history'), ('syntax-demos','walkthroughs'), ('outputs','outputs'), ('results','history'), ('alert-review','history'), ('rewrite-pilot','history'), ('split-example','history'), ('initial-splitting','history'), ('metric-history','history'), ('step-omissions','history'), ('daily-progress','daily-progress')]:
            page.goto(base + '/reports/compiler-demos.html#' + fragment, wait_until='networkidle')
            page.wait_for_selector('#' + panel, state='visible')
            assert page.locator('[role="tabpanel"]:visible').count() == 1, fragment
        page.goto(base + '/reports/compiler-demos.html#full-rewrite-example', wait_until='networkidle')
        page.wait_for_function('document.querySelector("#full-case").options.length===449')
        for value, count in [('faithful',27), ('review_rejected',57), ('direct_pass',30), ('component_compilation',207), ('alignment',142), ('composition',14), ('model_refuse',2), ('all',449)]:
            page.select_option('#full-filter', value)
            assert page.locator('#full-case option').count() == count, value
        proof = page.evaluate('''rows=>{
            let prompts=0,skips=0,programs=0;
            const el=id=>document.getElementById(id),ok=(x,m)=>{if(!x)throw Error(m);};
            for(const r of rows){
                el('full-case').value=r.claim_id;el('full-case').dispatchEvent(new Event('change'));
                ok(el('full-original').textContent===r.original,r.claim_id+' original');
                ok(el('full-review').textContent.includes(r.review.reason),r.claim_id+' review');
                ok(el('full-program').textContent===(r.program||'No final program.'),r.claim_id+' program');
                if(r.request){prompts++;ok(!el('full-request').hidden,r.claim_id+' hidden request');
                    ok(el('full-system').textContent===r.request.messages[0].content,r.claim_id+' system');
                    ok(el('full-user').textContent===r.request.messages[1].content,r.claim_id+' user');
                    ok(el('full-response').textContent===r.request.raw,r.claim_id+' response');
                }else{skips++;ok(el('full-request').hidden,r.claim_id+' skip');}
                if(r.output.status==='compiled'){programs++;ok(el('full-predicates').textContent===r.output.predicates.join('\\n'),r.claim_id+' predicates');}
            }
            return {cases:rows.length,exact_requests:prompts,model_skips:skips,programs};
        }''', cases)
        for cid in ['TbJqMFkNxARY_132','TgR_u37mCoQ4_1916','Txf2EdqOg1SQ_2236','TFgw4IaR9R8s_1612']:
            page.goto(base + '/reports/compiler-demos.html?rewrite_all=' + cid + '#full-rewrite-example', wait_until='networkidle')
            assert page.locator('#full-case').input_value() == cid
            if cid.endswith('_1916'):
                assert 'NOT EXISTS' in page.locator('#full-graph').inner_text()
            if cid.endswith('_1612'):
                assert 'not approved' in page.locator('#full-review').inner_text()
            page.evaluate('document.querySelector("#full-original").scrollIntoView({behavior:"instant",block:"start"})')
            page.screenshot(path=str(RUN / (cid + '_desktop.png')))
        page.goto(base + '/reports/compiler-demos.html?alignment=TFgw4IaR9R8s_1587&alignment_condition=sentences#alignment-example', wait_until='networkidle')
        assert 'Approved as a faithful' in page.locator('#alignment-review').inner_text()
        assert page.locator('#history').is_visible()
        page.goto(base + '/reports/compiler-demos.html?claim=Tg0UxWYuPeJ0_385#walkthroughs', wait_until='networkidle')
        assert page.locator('#demo-select option').count() == 41
        assert page.locator('#demo-select').input_value() == 'Tg0UxWYuPeJ0_385'
        page.goto(base + '/reports/compiler-demos.html#split-example', wait_until='networkidle')
        assert page.locator('#split-case option').count() == 8
        archive_links = page.locator('#history > ul a').evaluate_all('(links)=>links.map(x=>x.getAttribute("href"))')
        assert len(archive_links) == 11
        for href in archive_links:
            assert page.request.get(base + '/reports/' + href).ok, href
        page.goto(base + '/reports/compiler-demos.html?rewrite_all=TgR_u37mCoQ4_1916#full-rewrite-example', wait_until='networkidle')
        page.set_viewport_size({'width':390,'height':844})
        page.emulate_media(color_scheme='dark')
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
        page.evaluate('document.querySelector("#full-original").scrollIntoView({behavior:"instant",block:"start"})')
        page.screenshot(path=str(RUN / 'example_mobile_dark.png'))
        page.goto(base + '/reports/verification-pipeline.html#next-steps', wait_until='networkidle')
        assert '1953/2375' in page.locator('#next-steps').inner_text()
        for name in ['summary.json','cases.json','raw.jsonl','semantic_review.json','recoveries.json','remaining.json','native_absence.json','model_config.json','tests.xml','README.md','source.zip']:
            assert page.request.get(base + '/reports/compiler-demos/full-rewrite-20261112/' + name).ok, name
        assert not errors, errors
        proof.update(main_reports=2,report_views=5,legacy_fragments=13,historical_pages=11,old_demos=41,manual_cases=8,mobile_overflow=False,page_errors=errors)
        (RUN / 'browser_checks.json').write_text(json.dumps(proof, indent=2) + '\n')
        print(proof)
        browser.close()
    server.shutdown()


if __name__ == '__main__':
    main()
