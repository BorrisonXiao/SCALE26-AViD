#!/usr/bin/env python3
"""
AViD Phase 1 Parsing Ablation — Build annotation_units_constituency.tsv + diff.

Reads  : exp/phase1/parsing_ablation/constituency.jsonl
         exp/phase1/reports/annotation_units.tsv  (dep baseline for diff)
Writes : exp/phase1/reports/annotation_units_constituency.tsv  (9-col schema)
         exp/phase1/reports/annotation_units_constituency_diff.md

Flags:
  --verb-units          add clause-head verb as event unit (default: off)
  --maximal-np          emit only maximal NPs (default: off — all brackets)
  --constituency PATH   (default: parsing_ablation/constituency.jsonl)
  --dep-tsv  PATH       (default: reports/annotation_units.tsv)
  --out-tsv  PATH       (default: reports/annotation_units_constituency.tsv)
  --diff     PATH       (default: reports/annotation_units_constituency_diff.md)
  --sample-n N          claims to show side-by-side in diff (default 13)
  --seed     N          (default 42)
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from annotation_units_constituency import make_annotation_units_constituency  # noqa: E402

# ── Defaults ──────────────────────────────────────────────────────────────────

_ROOT = Path(__file__).parent.parent / "exp" / "phase1"
_ABL  = _ROOT / "parsing_ablation"
_REP  = _ROOT / "reports"

DEFAULT_CONSTITUENCY = str(_ABL / "constituency.jsonl")
DEFAULT_DEP_TSV      = str(_REP / "annotation_units.tsv")
DEFAULT_OUT_TSV      = str(_REP / "annotation_units_constituency.tsv")
DEFAULT_DIFF         = str(_REP / "annotation_units_constituency_diff.md")

TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted",
    "gold_channels", "notes",
]

TRIGGER_CLAIM = "TInVWzp25aIM_15"


# ── CLI ───────────────────────────────────────────────────────────────────────

def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Build annotation_units_constituency.tsv + diff report"
    )
    p.add_argument("--verb-units",    action="store_true",
                   help="Add clause-head verb as event unit")
    p.add_argument("--maximal-np",    action="store_true",
                   help="Emit only maximal NP brackets (drop nested)")
    p.add_argument("--constituency",  default=DEFAULT_CONSTITUENCY)
    p.add_argument("--dep-tsv",       default=DEFAULT_DEP_TSV,
                   help="Dep annotation_units.tsv for diff comparison")
    p.add_argument("--out-tsv",       default=DEFAULT_OUT_TSV)
    p.add_argument("--diff",          default=DEFAULT_DIFF)
    p.add_argument("--sample-n",      type=int, default=13)
    p.add_argument("--seed",          type=int, default=42)
    return p


# ── I/O helpers ───────────────────────────────────────────────────────────────

def _load_dep_tsv(path: str) -> dict[str, list[dict]]:
    """Load annotation_units.tsv → {claim_id: [rows]}."""
    result: dict[str, list[dict]] = defaultdict(list)
    try:
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f, delimiter="\t"):
                result[row["claim_id"]].append(row)
    except FileNotFoundError:
        pass
    return result


def _write_tsv(path: str, rows: list[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=TSV_COLS, delimiter="\t")
        w.writeheader()
        w.writerows(rows)


# ── Diff report ───────────────────────────────────────────────────────────────

def _diff_report(
    records:     list[dict],
    all_rows:    list[dict],
    dep_map:     dict[str, list[dict]],
    agg:         dict[str, int],
    sample_ids:  list[str],
    sample_n:    int,
    verb_units:  bool,
    maximal_np:  bool,
) -> str:
    n_claims = len(records)
    n_out    = len(all_rows)
    n_dep    = sum(len(v) for v in dep_map.values())

    rows_by_claim: dict[str, list[dict]] = defaultdict(list)
    for r in all_rows:
        rows_by_claim[r["claim_id"]].append(r)

    flags = []
    if verb_units:
        flags.append("`--verb-units`")
    if maximal_np:
        flags.append("`--maximal-np`")
    flag_str = " ".join(flags) if flags else "default (NP + clause only)"

    lines: list[str] = []
    lines.append("# AViD Phase 1 — Constituency Annotation Units Diff\n")
    lines.append(
        f"Flags: {flag_str}  \n"
        f"Dep surface rows (annotation_units.tsv): **{n_dep}** | "
        f"Const surface rows: **{n_out}**\n"
    )

    lines.append("\n## Counts\n")
    lines.append("| Metric | Value |")
    lines.append("|---|---|")
    lines.append(f"| Claims | {n_claims} |")
    lines.append(f"| Dep rows (annotation_units.tsv) | {n_dep} |")
    lines.append(f"| Const rows out | {n_out} |")
    lines.append(f"| NP constituents total | {agg['np_total']} |")
    lines.append(f"| NP-EX dropped (existential 'there') | {agg['np_dropped_ex']} |")
    lines.append(f"| Bare-pronoun NPs flagged | {agg['np_pronoun']} |")
    if maximal_np:
        lines.append(f"| Nested NPs dropped (--maximal-np) | {agg['np_nested']} |")
    lines.append(f"| NP units emitted (entity) | {agg['np_emitted']} |")
    lines.append(f"| Clause spans total | {agg['clause_total']} |")
    lines.append(f"| Clause units emitted | {agg['clause_emitted']} |")
    lines.append(f"| Full-claim units | {agg['full_claim']} |")
    if verb_units:
        lines.append(f"| Verb units emitted (--verb-units) | {agg['verb_units']} |")

    lines.append(f"\n## Sampled claim comparisons (dep → const)\n")
    lines.append(
        f"Showing {min(sample_n, len(sample_ids))} claims.  "
        f"Trigger case `{TRIGGER_CLAIM}` always first.\n"
    )

    for cid in sample_ids[:sample_n]:
        dep_rows   = dep_map.get(cid, [])
        const_rows = rows_by_claim.get(cid, [])
        if dep_rows:
            ct = dep_rows[0].get("claim_text", cid)
        elif const_rows:
            ct = const_rows[0].get("claim_text", cid)
        else:
            ct = cid

        lines.append(f"\n### `{cid}` — {ct}\n")
        lines.append(f"**Dep** ({len(dep_rows)} rows):\n")
        for r in dep_rows:
            lines.append(f"- `{r['unit_type']}/{r['node_type']}` {r['unit_text']!r}")
        lines.append(f"\n**Const** ({len(const_rows)} rows):\n")
        for r in const_rows:
            tag = f"  ← `{r['notes']}`" if r.get("notes") else ""
            lines.append(f"- `{r['unit_type']}/{r['node_type']}` {r['unit_text']!r}{tag}")

    return "\n".join(lines) + "\n"


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    args = _parser().parse_args()
    random.seed(args.seed)

    out_tsv  = Path(args.out_tsv)
    diff_out = Path(args.diff)
    out_tsv.parent.mkdir(parents=True, exist_ok=True)
    diff_out.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("AViD Phase 1 — make_annotation_units_constituency.py")
    print("=" * 60)
    flags = []
    if args.verb_units:
        flags.append("--verb-units")
    if args.maximal_np:
        flags.append("--maximal-np")
    print(f"Flags: {' '.join(flags) if flags else '(default)'}")

    # 1. Load constituency records
    print(f"\n[1] Loading constituency records: {args.constituency}")
    records: list[dict] = []
    with open(args.constituency, encoding="utf-8") as f:
        for line in f:
            records.append(json.loads(line))
    print(f"    Records: {len(records)}")

    # 2. Load dep TSV for diff comparison
    print(f"\n[2] Loading dep surface: {args.dep_tsv}")
    dep_map = _load_dep_tsv(args.dep_tsv)
    dep_total = sum(len(v) for v in dep_map.values())
    print(f"    Dep rows loaded: {dep_total}")

    # 3. Generate const annotation units
    print(f"\n[3] Building constituency annotation units ...")
    all_rows: list[dict] = []
    agg: Counter = Counter()
    trigger_rows: list[dict] = []

    for rec in records:
        rows, stats = make_annotation_units_constituency(
            rec,
            verb_units=args.verb_units,
            maximal_np=args.maximal_np,
        )
        all_rows.extend(rows)
        for k, v in stats.items():
            agg[k] += v
        if rec["claim_id"] == TRIGGER_CLAIM:
            trigger_rows = rows

    print(f"    Total output rows: {len(all_rows)}")

    # 4. Write TSV
    print(f"\n[4] Writing {out_tsv} ...")
    _write_tsv(str(out_tsv), all_rows)

    # 5. Summary
    print(f"\n{'=' * 60}")
    print("SUMMARY")
    print(f"{'=' * 60}")
    print(f"  Claims            : {len(records)}")
    print(f"  Dep rows (tsv)    : {dep_total}")
    print(f"  Const rows out    : {len(all_rows)}")
    print(f"  NP total          : {agg['np_total']}")
    print(f"  NP-EX dropped     : {agg['np_dropped_ex']}")
    print(f"  Pronoun flagged   : {agg['np_pronoun']}")
    print(f"  NP emitted        : {agg['np_emitted']}")
    print(f"  Clause total      : {agg['clause_total']}")
    print(f"  Clause emitted    : {agg['clause_emitted']}")
    print(f"  Full-claim        : {agg['full_claim']}")
    if args.verb_units:
        print(f"  Verb units        : {agg['verb_units']}")

    # 6. Trigger case
    print(f"\n[5] Trigger case {TRIGGER_CLAIM}:")
    if trigger_rows:
        for r in trigger_rows:
            tag = f"  [{r['notes']}]" if r.get("notes") else ""
            print(f"    {r['unit_type']:14s} {r['node_type']:20s} {r['unit_text']!r}{tag}")
    else:
        print("    (claim not found in constituency.jsonl)")

    # 7. Diff report
    print(f"\n[6] Writing diff: {diff_out} ...")
    all_ids    = [r["claim_id"] for r in records]
    sample_pool = [cid for cid in all_ids if cid != TRIGGER_CLAIM]
    random.shuffle(sample_pool)
    sample_ids = [TRIGGER_CLAIM] + sample_pool

    diff_md = _diff_report(
        records    = records,
        all_rows   = all_rows,
        dep_map    = dep_map,
        agg        = dict(agg),
        sample_ids = sample_ids,
        sample_n   = args.sample_n,
        verb_units = args.verb_units,
        maximal_np = args.maximal_np,
    )
    diff_out.write_text(diff_md, encoding="utf-8")

    print("\nDone.")


if __name__ == "__main__":
    main()
