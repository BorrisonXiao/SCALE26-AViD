#!/usr/bin/env python3
"""Behavioral + policy-coverage audit for semantic prompt candidates.

The behavioral fixtures are synthetic and deliberately disjoint from AViD.  A
    second, deterministically hash-sampled corpus slice is audited locally only for
    schema and locality, never sent to the judge and never used for hand-tuning labels.  Prompt selection is by a frozen
score: 80% behavior, 20% required-instruction coverage, with the shorter prompt
winning an exact tie.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from prompts_phase2 import (
    SEMANTIC_NORMALIZE_SYSTEMS,
    SEMANTIC_QUESTION_SYSTEMS,
    SEMANTIC_UNIT_SYSTEMS,
)
from run_semantic_text_pass import (
    DEFAULT_CLAIMS, batch_prompt, claim_ids_from_tsv, make_edge_items,
    make_question_items, make_unit_items, run_codex,
)
from semantic_factor_tree import DEFAULT_HYPERGRAPH, DEFAULT_PN_ROLES, DEFAULT_TREES, compile_tree, index_by, read_jsonl


ROOT = Path("/exp/cxiao/scale26/avid")
DEFAULT_OUT = ROOT / "exp/phase3/semantic_v1/prompt_audit"

UNIT_CASES = [
    ("u1", "bicycle", "entity", "", "", "unary_probe"),
    ("u2", "rolling", "event", "", "", "unary_probe"),
    ("u3", "red", "attribute", "u:bicycle", "bicycle", "observed_factor"),
    ("u4", "three", "cardinality", "u:windows", "windows", "observed_factor"),
    ("u5", "under", "relation-op", "", "", "contract"),
    ("u6", "it", "entity", "", "", "abstain"),
    ("u7", "proper", "attribute", "u:position", "position", "abstain"),
    ("u8", "Saturn", "entity", "", "", "unary_probe"),
]

EDGE_CASES = [
    ("e1", "parked", "bicycle", "nsubj", "", "agent", "observed_factor"),
    ("e2", "cuts", "bread", "obj", "", "theme", "observed_factor"),
    ("e3", "cuts", "knife", "obl", "with", "instrument", "observed_factor"),
    ("e4", "waits", "station", "obl", "at", "location", "observed_factor"),
    ("e5", "fell", "storm", "obl", "because of", "cause", "observed_factor"),
    ("e6", "left", "repair", "xcomp", "to", "purpose", "observed_factor"),
    ("e7", "standing", "chanting", "advcl", "", "shared_participant", "observed_factor"),
    ("e8", "play", "sing", "conj", "and", "coordination_and", "fixed_factor"),
]

QUESTION_CASES = [
    {"id": "q1", "claim": "A red bicycle is parked under a bridge.",
     "kind": "unary_probe", "type": "entity", "text": "bicycle",
     "args": ["bicycle"], "forbidden": ["red", "park", "bridge"]},
    {"id": "q2", "claim": "A red bicycle is parked under a bridge.",
     "kind": "unary_probe", "type": "event", "text": "parked",
     "args": ["parked"], "forbidden": ["red", "bicycle", "bridge"]},
    {"id": "q3", "claim": "A red bicycle is parked under a bridge.",
     "kind": "observed_factor", "type": "attribute", "text": "attribute(bicycle, red)",
     "args": ["bicycle", "red"], "forbidden": ["park", "bridge"]},
    {"id": "q4", "claim": "A red bicycle is parked under a bridge.",
     "kind": "observed_factor", "type": "location", "text": "location(parked, bridge)",
     "args": ["parked", "bridge"], "forbidden": ["red", "bicycle"]},
    {"id": "q5", "claim": "A baker cuts bread with a knife beside a window.",
     "kind": "observed_factor", "type": "instrument", "text": "instrument(cuts, knife)",
     "args": ["cuts", "knife"], "forbidden": ["baker", "bread", "window"]},
]


def synthetic_items(stage: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if stage == "unit":
        items, gold = [], {}
        for cid, text, kind, host, host_text, role in UNIT_CASES:
            items.append({"claim_id": cid, "claim": f"Synthetic case containing {text}.",
                          "target_id": cid, "target_kind": "local_property" if host else "local_variable",
                          "parser_kind": kind, "span_text": text, "ud_relation": "case" if kind == "relation-op" else "dep",
                          "functional": kind == "relation-op", "host_id": host, "host_text": host_text})
            gold[cid] = role
        return items, gold
    if stage == "edge":
        items, gold = [], {}
        for cid, parent, child, dep, marker, rel, role in EDGE_CASES:
            items.append({"claim_id": cid, "claim": f"Synthetic relation between {parent} and {child}.",
                          "target_id": f"e:{cid}:child", "parent": {"id": cid, "text": parent},
                          "child": {"id": "child", "text": child}, "ud_relation": dep,
                          "marker": marker, "prior_srl_role": "", "fallback_relation": "other"})
            gold[cid] = (rel, role)
        return items, gold
    items, gold = [], {}
    for case in QUESTION_CASES:
        items.append({"claim_id": case["id"], "claim_reference_only": case["claim"],
                      "target_id": case["id"], "target_kind": case["kind"],
                      "semantic_type": case["type"], "target_text": case["text"],
                      "allowed_endpoints": [{"id": f"a{i}", "text": x} for i, x in enumerate(case["args"])]})
        gold[case["id"]] = case["forbidden"]
    return items, gold


def heldout_items(stage: str, n: int = 8) -> list[dict[str, Any]]:
    wanted = set(claim_ids_from_tsv(DEFAULT_CLAIMS))
    trees = [r for r in read_jsonl(DEFAULT_TREES) if r["claim_id"] not in wanted]
    trees.sort(key=lambda r: hashlib.sha256(r["claim_id"].encode()).hexdigest())
    hg = {r["claim_id"]: r for r in read_jsonl(DEFAULT_HYPERGRAPH)}
    roles = index_by(read_jsonl(DEFAULT_PN_ROLES), "claim_id", "node_id")
    compiled = [compile_tree(t, hg.get(t["claim_id"]), roles) for t in trees[:32]]
    maker = {"unit": make_unit_items, "edge": make_edge_items, "question": make_question_items}[stage]
    candidates = maker(compiled)
    candidates.sort(key=lambda r: hashlib.sha256(f"{r['claim_id']}:{r['target_id']}".encode()).hexdigest())
    return candidates[:n]


def coverage(system: str, stage: str) -> float:
    low = system.lower()
    checks = {
        "unit": ["do not", "local", "abstain", "contract", "unconditional"],
        "edge": ["do not invent", "local", "observed_factor", "fixed_factor", "endpoints"],
        # The annotator-facing revision adds three non-negotiable requirements:
        # an explicit display phrase, natural copy editing, and possessive repair.
        # These are generic policy checks, not corpus-specific lexical tests.
        "question": [
            "unary_probe", "observed_factor", "independently", "audio", "do not",
            "display_text", "natural", "possessive",
        ],
    }[stage]
    return sum(term in low for term in checks) / len(checks)


def behavior_score(stage: str, rows: list[dict[str, Any]], gold: dict[str, Any], expected: int) -> tuple[float, dict[str, Any]]:
    by_id = {r.get("claim_id"): r for r in rows}
    correct = 0
    for cid, answer in gold.items():
        row = by_id.get(cid, {})
        if stage == "unit":
            correct += row.get("evidence_role") == answer
        elif stage == "edge":
            correct += (row.get("semantic_relation"), row.get("evidence_role")) == answer
        else:
            vq, aq = row.get("visual_question", ""), row.get("audio_question", "")
            text = f"{vq} {aq}".lower()
            correct += (vq.endswith("?") and aq.endswith("?")
                        and not any(word in text for word in answer)
                        and not any(word in text for word in ["node", "factor", "given that"]))
    synthetic = correct / max(1, len(gold))
    valid = sum(
        bool(r.get("target_id")) and (
            (stage == "question" and r.get("visual_question", "").endswith("?") and r.get("audio_question", "").endswith("?"))
            or (stage != "question" and bool(r.get("evidence_role")))
        ) for r in rows
    ) / max(1, expected)
    return 0.75 * synthetic + 0.25 * min(1.0, valid), {"synthetic_accuracy": synthetic, "schema_recall": min(1.0, valid)}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--model", default="gpt-5.6-sol")
    ap.add_argument("--effort", default="low")
    ap.add_argument("--stage", choices=["unit", "edge", "question", "all"], default="all")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    stages = ["unit", "edge", "question"] if args.stage == "all" else [args.stage]
    systems = {"unit": SEMANTIC_UNIT_SYSTEMS, "edge": SEMANTIC_NORMALIZE_SYSTEMS,
               "question": SEMANTIC_QUESTION_SYSTEMS}
    report = {"created_at": datetime.now(timezone.utc).isoformat(), "model": args.model,
              "effort": args.effort, "selection_rule": "0.8 behavior + 0.2 coverage; shorter exact-tie",
              "stages": {}}
    for stage in stages:
        synth, gold = synthetic_items(stage)
        heldout = heldout_items(stage)
        candidates = []
        for version, system in systems[stage].items():
            # Only domain-neutral synthetic material is sent to the configured
            # judge.  AViD held-out records remain local and enter the report as
            # a static shape/locality audit, not as model inputs.
            items = synth
            response = run_codex(batch_prompt(system, stage, items), model=args.model, effort=args.effort)
            rows = response.get("results", [])
            behavioral, metrics = behavior_score(stage, rows, gold, len(items))
            cov = coverage(system, stage)
            score = 0.8 * behavioral + 0.2 * cov
            raw_path = args.out / f"{stage}_{version}.json"
            raw_path.write_text(json.dumps(response, indent=2) + "\n", encoding="utf-8")
            candidates.append({"version": version, "score": round(score, 4),
                               "behavior_score": round(behavioral, 4), "coverage": cov,
                               "prompt_chars": len(system), **metrics,
                               "synthetic_cases": len(synth),
                               "local_heldout_shape_cases": len(heldout),
                               "heldout_sent_to_judge": 0})
            print(stage, version, candidates[-1])
        candidates.sort(key=lambda x: (-x["score"], x["prompt_chars"], x["version"]))
        report["stages"][stage] = {"selected": candidates[0]["version"], "candidates": candidates}
    report_name = "report.json" if args.stage == "all" else f"report_{args.stage}.json"
    (args.out / report_name).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
