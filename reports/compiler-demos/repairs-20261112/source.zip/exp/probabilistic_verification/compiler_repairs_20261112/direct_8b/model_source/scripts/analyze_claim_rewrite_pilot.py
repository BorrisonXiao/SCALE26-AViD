"""Recompute accepted recoveries from saved proposals, compilations and reviews."""
import argparse,hashlib,json
from collections import Counter
from pathlib import Path
from probabilistic_verification.claim_rewrite import reviewed_acceptance,surface_checks,review_key,messages
from compile_claim_rewrite_pilot import verify_freeze
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/claim_rewrite_20261111'
BASE=ROOT/'exp/probabilistic_verification/content_relations_20261105'
def read(n):return list(map(json.loads,(RUN/n).read_text().splitlines()))
def main():
 global RUN
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,default=RUN);a=p.parse_args();RUN=a.run
 verify_freeze();manifest=json.loads((RUN/'pilot_manifest.json').read_text());membership={r['claim_id']:r for r in manifest['cases']}
 initial=json.loads((RUN/'initial_freeze.json').read_text())
 assert hashlib.sha256((RUN/'pilot_manifest.json').read_bytes()).hexdigest()==initial['pilot_manifest.json']
 inputs={r['claim_id']:r for r in read('pilot_inputs.jsonl')};rows=read('pilot_compilation.jsonl');review=json.loads((RUN/'semantic_review.json').read_text());judgments={r['claim_id']:r for r in review['cases']}
 raw={r['claim_id']:r for r in read('pilot_raw.jsonl')}
 config=json.loads((RUN/'pilot_raw.config.json').read_text());diags=json.loads((RUN/'diagnostics.json').read_text())if (RUN/'diagnostics.json').exists()else{}
 from probabilistic_verification.claim_rewrite import SYSTEM
 assert set(inputs)==set(membership)==set(judgments)=={r['claim_id']for r in rows} and len(rows)==40
 accepted=[];controls=0;shadow=0;critical=0
 for row in rows:
  cid=row['claim_id'];j=judgments[cid]
  assert raw[cid]['messages']==messages(inputs[cid],system=config.get('system_prompt',SYSTEM),diagnostic=diags.get(cid)),(cid,'generation messages changed')
  assert raw[cid]['finish_reason']=='stop' and json.loads(raw[cid]['raw'])==row['proposal']
  assert j['artifact_sha256']==review_key(inputs[cid],row['proposal'],row['rewritten']),cid
  assert row['surface_issues']==surface_checks(inputs[cid],row['proposal'])
  a=reviewed_acceptance(inputs[cid],row['proposal'],row['rewritten'],j)
  assert j['accepted']==a,(cid,'review acceptance inconsistent')
  assert j['reason'] and j['outcome']
  if a:accepted.append(cid)
  if j['critical_change']:critical+=1
  if membership[cid]['group']=='control' and (j['rewrite_faithful'] is False or j['compiled_faithful'] is False or row['rewritten']['status']!='compiled'):shadow+=1
 targets=[r for r in rows if membership[r['claim_id']]['group']=='target']
 recovered=[cid for cid in accepted if membership[cid]['group']=='target']
 guards=[cid for cid in accepted if membership[cid]['group']=='guard']
 # Controls are never routed through rewriting in the candidate pipeline.
 baseline=list(map(json.loads,(BASE/'results.jsonl').read_text().splitlines()));replacements={r['claim_id']:r['rewritten']for r in rows if r['claim_id']in accepted and r['original']['status']!='compiled'}
 full=[dict(r,original_text=r['text'],rewrite_reviewed=False)if r['claim_id']not in replacements else dict(replacements[r['claim_id']],original_text=r['text'],rewrite_reviewed=True)for r in baseline]
 (RUN/'reviewed_corpus.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in full))
 original_pass=sum(r['status']=='compiled'for r in baseline);new_pass=sum(r['status']=='compiled'for r in full)
 assert new_pass==original_pass+len(replacements)
 passed=len(recovered)>=12 and shadow==0 and not any(judgments[cid]['critical_change']for cid in accepted)
 s=dict(total_cases=40,targets=24,controls=8,guards=8,faithful_target_recoveries=len(recovered),recovered_ids=recovered,
  rewritten_targets_pass_checks=sum(r['rewritten']['status']=='compiled'for r in targets),
  actual_text_changes=sum(r['proposal']['text']!=r['original']['text']for r in rows),
  identical_rewrite_actions=sum(r['proposal']['action']=='rewrite'and r['proposal']['text']==r['original']['text']for r in rows),
  reviewed_recoveries_total=len(replacements),guard_recovered_ids=guards,
  control_regressions=shadow,operational_control_regressions=controls,guard_acceptances=len(guards),
  model_proposed_critical_changes=critical,accepted_critical_changes=sum(judgments[c]['critical_change']for c in accepted),
  actions=dict(Counter(r['proposal']['action']for r in rows)),
  target_outcomes=dict(Counter(judgments[r['claim_id']]['outcome']for r in targets)),
  original_corpus=dict(total=2375,generated=2103,pass_content_checks=1924),
  reviewed_corpus=dict(total=len(full),generated=sum('program'in r for r in full),pass_content_checks=new_pass,remaining_strict_refusals=2375-new_pass,reviewed_replacements=len(replacements)),
  pilot_gate_passed=passed,compiler_changed=False,broader_rewrite_run=False,new_relation_training=False,new_deepproblog_inference=False,
  evidence='Compiler-author assistant semantic judgments; no independent human gold or unseen-test accuracy.',
  decision=review['decision'],interpretation=review['interpretation'],failure_patterns=review['failure_patterns'],next_steps=review['next_steps'])
 (RUN/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n');print(json.dumps(s,indent=2))
if __name__=='__main__':main()
