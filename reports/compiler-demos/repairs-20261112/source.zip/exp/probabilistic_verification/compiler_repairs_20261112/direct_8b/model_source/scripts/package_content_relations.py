"""Bundle the current compiler work without modifying historical source archives."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_relations_20261105'
BASE=ROOT/'site/reports/compiler-demos/history/content-recovery-20261105-source.zip'

def main():
    manifest=RUN/'package_manifest.json'
    if BASE.exists():
        with zipfile.ZipFile(BASE)as z:contents={n:z.read(n)for n in z.namelist()if not n.endswith('/')}
        names=sorted(contents)
    else:
        names=json.loads(manifest.read_text())['base_paths'];contents={n:(ROOT/n).read_bytes()for n in names}
    manifest.write_text(json.dumps(dict(base_paths=names,statement='Prior original source bundle overlaid with current compiler, report and daily-log evidence. The historical ZIP is unchanged.'),indent=2)+'\n')
    paths=['scripts/probabilistic_verification/content_recovery.py','scripts/probabilistic_verification/content_relations.py',
        'scripts/run_content_relations_census.py','scripts/analyze_content_relations.py','scripts/replay_content_relations.py',
        'tests/test_content_relations.py','scripts/build_compiler_demos.py','scripts/package_content_relations.py',
        'scripts/report_assets/compiler_demos.js','scripts/report_assets/compiler_demos.css','scripts/report_assets/compiler_demos_template.html',
        'scripts/build_av_feature_sections.py','scripts/build_compilation_methods_report.py',
        'docs/content_relations_compilation.md','exp/probabilistic_verification/av_features_20261022/checklist.json']
    files=[ROOT/p for p in paths]
    excluded={'WORK_STATUS.md','publication.json','browser_checks.json','archive_verification.json','replay_verification.json'}
    files.extend(p for p in RUN.rglob('*')if p.is_file()and p.suffix in {'.json','.jsonl','.py','.md','.xml'}and p.name not in excluded)
    for p in files:contents[str(p.relative_to(ROOT))]=p.read_bytes()
    contents['README_COMPILER_DEMOS.md']=(ROOT/'docs/content_relations_compilation.md').read_bytes()
    contents['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n'for name,data in sorted(contents.items())if name!='SHA256SUMS').encode()
    target=ROOT/'site/reports/compiler-demos/source.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED)as z:
        for name,data in sorted(contents.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,5,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
    print('Packaged',len(contents),'files;',round(target.stat().st_size/1048576,2),'MiB')
if __name__=='__main__':main()
