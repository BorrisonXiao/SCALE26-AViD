#!/usr/bin/env python3
"""Render saved pilot data, labels, and observations for inspection."""
from __future__ import annotations
import argparse
import base64
from collections import Counter
from html import escape as E
import json
from pathlib import Path

from run_verification_pilot import read
from build_verification_examples import sample_anchor

ROOT = Path(__file__).resolve().parents[1]


def optional(path):
    return read(path) if path.exists() else []


def distribution(row):
    d = row.get('distribution') or {}
    return ' / '.join(f'{100*d[s]:.1f}%' for s in ('supported','refuted','unknown')) if d else 'Unavailable'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pilot',type=Path,default=ROOT/'exp/probabilistic_verification/pilot_20261015')
    ap.add_argument('--output',type=Path,default=ROOT/'site/reports/verification-pilot.html')
    args = ap.parse_args()
    sections, totals = [], []
    # Keep this report tied to the five inspected pilot configurations. Later
    # model runs require their own quality review before joining this report.
    for config in ('smoke/v1','smoke/v2','smoke/v3','guided/v3','guided_checked/v3'):
        d = args.pilot/config
        claims = optional(d/'claims.jsonl')
        if not claims:
            continue
        reviews = {r['request_id']:r for r in optional(d/'review_raw.jsonl')}
        whole = {r['request_id']:r for r in optional(d/'whole_claim_raw.jsonl')}
        manual = {r['sample_id']:r for r in optional(d/'assistant_reviews.jsonl')}
        summary = json.loads((d/'summary.json').read_text()) if (d/'summary.json').exists() else {}
        rows = []
        for c in claims:
            cid = c['sample_id']; m=manual.get(cid,{})
            r = reviews.get(cid,{}).get('parsed',{})
            rows.append('<article id="'+E(sample_anchor(config,cid),quote=True)+'" class="sample" data-config="'+E(config)+'" data-quality="'+E(m.get('quality','unreviewed'))+'">'
                '<h4>'+E(cid)+'</h4><p class="claim">'+E(c['claim_text'])+'</p>'
                '<dl><dt>Edit</dt><dd>'+E(c['edit_type'])+'</dd><dt>Proposed label</dt><dd>'+E(c['proposed_label'])+'</dd>'
                '<dt>Model review</dt><dd>'+E(r.get('label','Pending or invalid JSON'))+'</dd>'
                '<dt>Assistant review</dt><dd>'+E(m.get('quality','Unreviewed'))+'; '+E(m.get('label','no label'))+'</dd>'
                '<dt>Whole-claim S / R / U</dt><dd>'+distribution(whole.get(cid,{}))+'</dd></dl>'
                '<p>'+E(m.get('reason',''))+'</p><details><summary>Model review and provenance</summary><pre>'
                +E(json.dumps(dict(review=r,source_video=c['video_id'],frame_paths=c['frame_paths'],
                                   proposed_label_source=c['label_source']),ensure_ascii=False,indent=2))+'</pre></details></article>')
        tables = []
        for method,m in summary.get('methods',{}).items():
            agreement=m.get('agreement')
            tables.append('<tr><td>'+E(method)+'</td><td>'+str(m['n_valid_distributions'])+'</td><td>'
                          +str(m.get('n_labeled_predictions',0))+'</td><td>'
                          +(f'{100*agreement:.1f}%' if agreement is not None else 'No checked labels')+'</td></tr>')
        totals.append(dict(configuration=config,claims=len(claims),model_reviews=len(reviews),
                           checked_variants=sum(c['edit_type']!='seed' and c['sample_id'] in manual for c in claims),
                           quality_counts=dict(Counter(m['quality'] for m in manual.values() if m.get('quality')))))
        sections.append('<section><h2>'+E(config)+'</h2><p>'+str(len(claims))+' claims; '
                        +str(len(reviews))+' saved model-review calls. Counts below include seed claims.</p>'
                        '<div class="table-wrap"><table><caption>Table '+str(len(sections)+1)+'. Saved baseline outputs for '+E(config)
                        +'. Agreement uses only the explicitly checked assistant development labels.</caption>'
                        '<thead><tr><th>Method</th><th>Valid scores</th><th>Checked labels</th><th>Label agreement</th></tr></thead><tbody>'
                        +''.join(tables)+'</tbody></table></div><div class="samples">'+''.join(rows)+'</div></section>')
    figures = []
    for i,seed in enumerate(optional(args.pilot/'seeds_reviewed.jsonl'),1):
        p = args.pilot/(seed['seed_id']+'.jpg')
        if not p.exists():
            continue
        uri = 'data:image/jpeg;base64,'+base64.b64encode(p.read_bytes()).decode()
        figures.append('<details><summary>'+E(seed['seed_id'])+': '+E(seed['claim_text'])+'</summary><figure>'
                       '<img loading="lazy" src="'+uri+'" alt="Eight inspected frames for '+E(seed['seed_id'])+'">'
                       '<figcaption>Figure '+str(i)+'. '+E(seed['seed_id'])+'. '+E(seed['coverage_note'])
                       +' The heading on the contact sheet preserves the unverified original claim.</figcaption></figure></details>')
    full_resolution = [
        ('PxRXEWfLiL3w_E7y_0000/frame_099.jpg', 'The chair stacks occupy the road beside the curb. This corrects the initial sidewalk description.'),
        ('12Nvpg23obr7TIhT_0000/frame_012.jpg', 'The shorter person wears dark below-knee clothing; shorts versus cropped trousers remains ambiguous.'),
        ('eHObCbLbueu90y1g_0000/frame_010.jpg', 'The short-haired person has a white outer shirt and a red hood; the nearby man wears red.'),
        ('zlD_zgNiYJkRV1PS_0000/frame_000.jpg', 'The aircraft is gray in this shot.'),
        ('zlD_zgNiYJkRV1PS_0000/frame_005.jpg', 'A yellow school bus appears in a different shot.')]
    for rel,description in full_resolution:
        p = ROOT/'exp/phase2/media_cache_1fps/frames'/rel
        if not p.exists():
            continue
        uri='data:image/jpeg;base64,'+base64.b64encode(p.read_bytes()).decode()
        figures.append('<details><summary>Full-resolution check: '+E(rel)+'</summary><figure><img loading="lazy" src="'+uri+'" alt="'+E(description)+'"><figcaption>Figure '+str(len(figures)+1)+'. '+E(description)+' These are source-cache frames used for assistant inspection; model images were capped at 384 pixels on the long side.</figcaption></figure></details>')
    analysis_path = args.pilot/'report_summary.html'
    analysis_html = analysis_path.read_text() if analysis_path.exists() else ''
    body = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Local-model verification pilot — 15 October 2026</title><style>
:root{color-scheme:light dark;--bg:#f7f8fa;--fg:#202630;--card:#fff;--line:#cbd2dc;--accent:#215db0}
@media(prefers-color-scheme:dark){:root{--bg:#10151d;--fg:#e3eaf4;--card:#1b2330;--line:#445166;--accent:#9cc4ff}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.6 system-ui,sans-serif}
main{max-width:1120px;margin:auto;padding:32px 22px}a{color:var(--accent)}h1{font-size:clamp(28px,5vw,44px);line-height:1.2}
section{margin:40px 0}table{border-collapse:collapse;width:100%;font-size:14px}th,td{border:1px solid var(--line);padding:10px;text-align:left}
caption{text-align:left;padding:12px 0}.table-wrap{overflow:auto}.notice,.sample{background:var(--card);border:1px solid var(--line);padding:20px;border-radius:10px}
.samples{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,430px),1fr));gap:15px;margin-top:20px}
.sample{scroll-margin-top:120px}.sample h4{margin:0;overflow-wrap:anywhere}.claim{font-size:18px;font-weight:600}dl{display:grid;grid-template-columns:145px 1fr;gap:5px 12px}
dt{font-weight:600}dd{margin:0}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px}details{margin:15px 0}summary{cursor:pointer}
img{max-width:100%;height:auto}figure{margin:15px 0}figcaption{font-size:14px}select,input{font:inherit;padding:8px;max-width:100%}
.controls{display:flex;gap:12px;flex-wrap:wrap;position:sticky;top:0;background:var(--bg);padding:12px 0}.hidden{display:none}
</style></head><body><main><nav><a href="../proposals/probabilistic-verification.html">Paper design</a> · <a href="../index.html">Project reports</a></nav>
<h1>Local-model generation and verification pilot</h1><p>15 October 2026 · Development experiment under ADR-023.</p>
<p><a href="../proposals/probabilistic-verification.html#generated-examples">Start with five selected generated examples and their evidence.</a></p>
<p><a href="verification-pipeline.html">Implementation: automatic claim compilation, frozen observations, DeepProbLog inference, and sample training</a> (22 October 2026).</p>
<p>This report covers the five inspected L40S pilot configurations. Later A100 outputs require a separate sample-quality review and are not included in these counts.</p>
<div class="notice"><strong>Evidence and label limits.</strong> The assistant inspected eight sampled frames per clip. The generation model
received descriptions; visual reviews and baselines received the saved frames. No audio was supplied. Proposed labels and model reviews
are automatic. Assistant checks are development annotations, not independent human gold. These results do not establish paper accuracy
or a benefit from probabilistic inference. Whole-claim scores are uncalibrated probabilities normalized over A/B/C output tokens.</div>
<p>The source-video IDs are outside the 102 videos in existing phase-3 gold packages. This checks those packages only, not all possible duplicates.
The report shows all schema-valid candidates, including poor edits and disagreements. The text-only control receives an explicit statement
that no media is available; it checks abstention rather than measuring a trained linguistic shortcut detector.</p>
''' + analysis_html + '''<h2>Recorded configurations</h2><pre>''' + E(json.dumps(totals,indent=2)) + '''</pre>
<div class="controls"><label>Show <select id="quality"><option value="all">All samples</option><option value="usable">Usable edits/controls</option><option value="reject">Rejected edits</option><option value="uncertain">Uncertain</option><option value="unreviewed">Unreviewed</option></select></label>
<label>Find <input id="search" type="search" placeholder="Claim, ID, or edit type"></label><span id="count"></span></div>
''' + ''.join(sections) + '<section><h2>Inspected media</h2><p>Expand a seed to see the exact contact sheet used for the assistant review.</p>'+''.join(figures)+'''</section>
<script>const samples=[...document.querySelectorAll('.sample')];function filter(){const q=document.querySelector('#quality').value,s=document.querySelector('#search').value.toLowerCase();let n=0;for(const el of samples){const show=(q==='all'||el.dataset.quality===q)&&el.textContent.toLowerCase().includes(s);el.classList.toggle('hidden',!show);n+=show;}document.querySelector('#count').textContent=n+' samples shown';}document.querySelector('#quality').addEventListener('change',filter);document.querySelector('#search').addEventListener('input',filter);filter();</script>
</main></body></html>'''
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(body)
    print(args.output, len(body.encode()), 'bytes')


if __name__=='__main__':
    main()
