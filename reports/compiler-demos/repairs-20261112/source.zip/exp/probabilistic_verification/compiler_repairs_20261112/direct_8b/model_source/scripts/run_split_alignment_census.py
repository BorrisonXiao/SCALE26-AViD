"""Fresh full-corpus compilation; add only hash-bound, reviewed fallback results."""
import argparse
import hashlib
import json
import time
from collections import Counter
from pathlib import Path
from run_content_relations_census import compile_one

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/split_alignment_20261112'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--combine', action='store_true')
    args = parser.parse_args()
    source = ROOT / 'exp/probabilistic_verification/content_relations_20261105'
    baseline = list(map(json.loads, (source / 'results.jsonl').read_text().splitlines()))
    if not args.combine:
        begun = time.perf_counter()
        records = list(map(json.loads, (source / 'inputs.jsonl').read_text().splitlines()))
        with (RUN / 'corpus_direct.jsonl').open('w') as out:
            for record, before in zip(records, baseline):
                row = json.loads(json.dumps(compile_one(record)))
                assert row == before, record['claim_id']
                out.write(json.dumps(row, ensure_ascii=False) + '\n')
        (RUN / 'corpus_timing.json').write_text(json.dumps(dict(
            records=len(records), seconds=time.perf_counter()-begun, exact_baseline_match=True), indent=2)+'\n')
    direct = list(map(json.loads, (RUN / 'corpus_direct.jsonl').read_text().splitlines()))
    approved = {}
    if args.combine:
        rows = list(map(json.loads, (RUN / 'sentences_results.jsonl').read_text().splitlines()))
        reviews = {r['claim_id']: r for r in json.loads((RUN / 'semantic_review.json').read_text())['cases']}
        for row in rows:
            review = reviews[row['claim_id']]
            assert review['artifact_sha256'] == hashlib.sha256(json.dumps(row, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
            if review['faithful']:
                assert row['output']['status'] == 'compiled'
                approved[row['claim_id']] = row['output']
    combined = []
    for row in direct:
        if row['claim_id'] in approved:
            assert row['status'] == 'unsupported'
            row = dict(approved[row['claim_id']], claim_id=row['claim_id'], text=row['text'],
                       provenance='Reviewed automatic sentences-only fallback; original claim retained.')
        combined.append(row)
    def counts(rows):
        return dict(total=len(rows), passes=sum(r['status']=='compiled' for r in rows),
                    candidates=sum('program' in r for r in rows),
                    failures=dict(Counter(r.get('code') for r in rows if r['status']!='compiled')))
    summary = dict(direct=counts(direct), reviewed_fallback_additions=len(approved), combined=counts(combined),
                   limits='Content checks are not semantic accuracy. Only the fixed31 failures receive this fallback; no extrapolation to untested failures. No manual clauses counted.')
    for key in ['direct','combined']:
        summary[key]['pass_rate'] = summary[key]['passes']/summary[key]['total']
        summary[key]['candidate_rate'] = summary[key]['candidates']/summary[key]['total']
    (RUN / 'corpus_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    if args.combine:
        (RUN / 'corpus_reviewed.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in combined))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
