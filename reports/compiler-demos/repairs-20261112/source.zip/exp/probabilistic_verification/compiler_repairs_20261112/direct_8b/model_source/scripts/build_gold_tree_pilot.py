#!/usr/bin/env python3
"""
AViD Phase 3 — Gold Schema v2 surface generator (ADR-020, multi-granularity tree).

Extension of build_gold_pilot.py (which emits the FLAT post-PN node surface). This
script emits the **multi-granularity compositional tree** from
`exp/phase1/hypergraph.jsonl`: one annotatable row per **content node**
(node_type ∈ {entity, event, attribute, cardinality}) AND one row per **factor**
(predicate_argument, entity_attribute, prepositional_relation, temporal_relation,
coordination, negation, relative_clause, full_claim). Structural operators
(relation-op / coord-op / logical-op / functional) are parser-determined `na` and
are NOT annotated (ADR-020) — they fold into their factor's label as ‹markers›.

Tree structure. The hypergraph's factor head/args reference ONLY content-node /
operator ids (never other factor ids — verified corpus-wide), so head/args alone is
a flat forest, not a connected tree. To render the nested compositional tree the
annotator reads, we nest factors by **span containment**: the full_claim factor
(span = whole claim) is the root, and every factor / content node attaches under the
tightest factor whose char-span contains it. This superset of the head/args relation
(a factor's head+args all fall within its span) yields one connected nested tree.

PN prediction as the default. Each content node's `role` (probeable/na) and `comp`
are read from `exp/phase3/trees/trees_ud_star.jsonl` (same claim_id + node id) and
attached as `pn_role_pred` — so the annotator CORRECTS PN rather than labelling from
scratch, and PN-vs-gold unit-selection agreement (ADR-020 primary metric) falls out
directly. Factors have no PN node-role, so their default is a factor-type heuristic
(compositions probeable; bare relational / temporal / negation glue na) — a starting
point the annotator overrides.

Outputs (exp/phase3/gold_v2/):
  claims.tsv       — claim_id, claim_text, verdict_visual, verdict_audio, notes
  nodes_tree.tsv   — one row per content node + factor (pre-order), span-anchored,
                     with level/parent_id, kind, node_type/factor_type, unit_text,
                     span, pn_role_pred, comp, and blank role/visual/audio_gold.

Usage:
    python scripts/build_gold_tree_pilot.py [--n 40] [--seed 20260723]
"""

import argparse
import csv
import json
import random
from pathlib import Path

HYPERGRAPH = "/exp/cxiao/scale26/avid/exp/phase1/hypergraph.jsonl"
TREES_UD = "/exp/cxiao/scale26/avid/exp/phase3/trees/trees_ud_star.jsonl"
MANIFEST = "/exp/cxiao/scale26/avid/exp/phase2/manifest_avid.jsonl"
SRC_VIDEOS = "/exp/cxiao/scale26/data/extracted/microvent/videos"
OUTDIR = "/exp/cxiao/scale26/avid/exp/phase3/gold_v2"

# Content node types are annotated; everything else (relation-op / coord-op /
# logical-op / functional) is a parser-determined operator → excluded (ADR-020).
CONTENT_NODE_TYPES = {"entity", "event", "attribute", "cardinality"}

# Per-modality gold states (ADR-015 refinement; support(M) := gold_M != "no").
VISUAL_STATES = ["no", "other", "ocr", "both"]     # both = ocr+other
AUDIO_STATES = ["no", "speech", "other", "both"]   # both = speech+other

# Factor-type default role (annotator overrides). Meaningful compositions probeable;
# bare relational / temporal glue + negation operator na by default (ADR-020 guideline).
FACTOR_DEFAULT_ROLE = {
    "full_claim": "probeable",
    "predicate_argument": "probeable",
    "entity_attribute": "probeable",
    "coordination": "probeable",
    "relative_clause": "probeable",
    "cardinality": "probeable",
    "prepositional_relation": "na",
    "temporal_relation": "na",
    "negation": "na",
}

# Total-order tiebreak when two factors share the same char span: higher priority =
# larger "size" = sits higher in the tree (so, e.g., a predicate_argument contains a
# co-spanning prepositional_relation). full_claim always wins → guaranteed root.
FACTOR_PRIORITY = {
    "full_claim": 90,
    "predicate_argument": 80,
    "relative_clause": 70,
    "coordination": 60,
    "entity_attribute": 50,
    "temporal_relation": 40,
    "prepositional_relation": 30,
    "negation": 20,
    "cardinality": 10,
}

CLAIM_COLS = ["claim_id", "claim_text", "verdict_visual", "verdict_audio", "notes"]

NODE_COLS = [
    "claim_id", "node_id", "level", "parent_id", "kind",
    "node_type", "factor_type", "unit_text", "span_start", "span_end",
    "pn_role_pred", "comp",
    "pn_src",          # provenance of pn_role_pred: pn-node | pn-sub | pn-merge |
                       #   pn-stamp | "" (heuristic factor default)
    "role_gold",       # ANNOTATE: probeable | na   (default = pn_role_pred)
    "visual_gold",     # ANNOTATE (probeable only): no | other | ocr | both
    "audio_gold",      # ANNOTATE (probeable only): no | speech | other | both
    "notes",
]


def load_jsonl(path):
    d = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            d[r["claim_id"]] = r
    return d


def load_manifest(path):
    man = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            man[(d["topic_id"], d["claim_index"])] = d
    return man


def chunks_for(cid, man):
    tid, _, idx = cid.rpartition("_")
    try:
        rec = man.get((tid, int(idx)), {})
    except ValueError:
        rec = {}
    return rec.get("chunks", []), rec


def has_media(cid, man, src_videos):
    chs, _ = chunks_for(cid, man)
    if not chs:
        return False
    return all((Path(src_videos) / ch).exists() for ch in chs)


def factor_span(fa, claim_text, nodes_by_id):
    """Char span for a factor. full_claim = whole claim; else the node-derived
    [min-start, max-end] over head+args (operators included — they carry spans),
    snapped to the nearest verbatim occurrence of surface_span (always a substring)."""
    if fa.get("factor_type") == "full_claim":
        return 0, len(claim_text)
    starts, ends = [], []
    for ref in [fa.get("head")] + list(fa.get("args", [])):
        n = nodes_by_id.get(ref)
        if n and n.get("span_start") is not None:
            starts.append(n["span_start"])
            ends.append(n["span_end"])
    cmin = min(starts) if starts else 0
    cmax = max(ends) if ends else len(claim_text)
    ss = (fa.get("surface_span") or "").strip()
    if ss:
        best = None
        idx = claim_text.find(ss)
        while idx != -1:
            if best is None or abs(idx - cmin) < abs(best - cmin):
                best = idx
            idx = claim_text.find(ss, idx + 1)
        if best is not None:
            return best, best + len(ss)
    return cmin, cmax


def op_markers(fa, nodes_by_id):
    """Operator words among head+args (relation-op/coord-op/logical-op), span-ordered,
    to fold into the factor's label (e.g. 'by', 'into', 'and')."""
    ops = []
    for ref in [fa.get("head")] + list(fa.get("args", [])):
        n = nodes_by_id.get(ref)
        if n and n.get("node_type") not in CONTENT_NODE_TYPES and n.get("text"):
            ops.append((n.get("span_start", 0), n["text"]))
    ops.sort()
    seen, out = set(), []
    for _, t in ops:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return " ".join(out)


# Boundary punctuation/whitespace trimmed before dedup so "…moon." and "…moon"
# (same unit, differing only by a trailing period/quote) collapse to ONE row.
_TRIM_CHARS = " \t\n\r.,;:!?\"'“”‘’`()[]{}"
def _norm_span(span, ct):
    s, e = int(span[0]), int(span[1])
    s = max(0, min(s, len(ct))); e = max(0, min(e, len(ct)))
    while s < e and ct[s] in _TRIM_CHARS: s += 1
    while e > s and ct[e - 1] in _TRIM_CHARS: e -= 1
    return (s, e)


def build_claim_tree(rec, pn_nodes):
    """Return (items_in_preorder, root_id). Each item is a dict with tree + schema
    fields. `pn_nodes` = {node_id: T* node} for this claim (PN role/comp source)."""
    ct = rec["claim_text"]
    nodes_by_id = {n["id"]: n for n in rec["nodes"]}

    items = {}   # id -> dict
    # content nodes (leaves) ------------------------------------------------
    for n in rec["nodes"]:
        if n.get("node_type") not in CONTENT_NODE_TYPES:
            continue   # operator / function word → not annotated (ADR-020)
        pn = pn_nodes.get(n["id"], {})
        role = pn.get("role")
        pn_role = "probeable" if role == "probeable" else ("na" if role == "na" else
                  ("probeable" if n["node_type"] in ("entity", "event") else "na"))
        items[n["id"]] = {
            "id": n["id"], "kind": "node",
            "node_type": n.get("node_type", ""), "factor_type": "",
            "unit_text": n.get("text", ""),
            "span": (n.get("span_start", -1), n.get("span_end", -1)),
            "pn_role_pred": pn_role, "comp": pn.get("comp", ""),
            "marker": "", "pn_src": "pn-node",
        }
    # factors (internal) ----------------------------------------------------
    for fa in rec["factors"]:
        s, e = factor_span(fa, ct, nodes_by_id)
        ftype = fa.get("factor_type", "")
        items[fa["id"]] = {
            "id": fa["id"], "kind": "factor",
            "node_type": "", "factor_type": ftype,
            "unit_text": (fa.get("surface_span") or ct[s:e]).strip(),
            "span": (s, e),
            "pn_role_pred": FACTOR_DEFAULT_ROLE.get(ftype, "probeable"),
            "comp": ftype,
            "marker": op_markers(fa, nodes_by_id), "pn_src": "",
        }

    # --- dedup exact-span duplicates: ONE annotatable row per unique char span ---
    # The hypergraph emits overlapping factors over an IDENTICAL span (e.g.
    # predicate_argument + coordination + temporal_relation all on [65,207]), and the
    # root predicate_argument co-spans the full_claim. Those are duplicate annotation
    # targets (same text → same probeable/na + modality judgment). Collapse each span
    # group to one representative (priority below); genuinely-nested DIFFERENT-span
    # levels (e.g. "position" vs "correct position") are untouched. Collapsed types are
    # recorded in `collapsed` (→ notes) so nothing is silently lost.
    _DEDUP_PRIO = {"full_claim": 100, "predicate_argument": 90, "relative_clause": 85,
                   "coordination": 80, "entity_attribute": 75, "_node": 60,
                   "temporal_relation": 40, "prepositional_relation": 30, "negation": 20}
    def _prio(it):
        return _DEDUP_PRIO["_node"] if it["kind"] == "node" else _DEDUP_PRIO.get(it["factor_type"], 5)
    by_span = {}
    for it in items.values():
        by_span.setdefault(_norm_span(it["span"], ct), []).append(it)   # punct-normalized key
    deduped = {}
    for _span, group in by_span.items():
        rep = max(group, key=_prio)
        if len(group) > 1:
            alt = sorted({(g["factor_type"] or g["node_type"]) for g in group
                          if g["id"] != rep["id"] and (g["factor_type"] or g["node_type"])})
            rep["collapsed"] = "same-span collapsed: " + ", ".join(alt) if alt else ""
        deduped[rep["id"]] = rep
    items = deduped

    # --- PN merged units (ADR-020): surface PN's ACTUAL units, not just raw atoms ---
    # A PN node whose pn_unit_span grew beyond its raw atom is a MERGE — e.g. hand→"by
    # hand", position→"correct position", a root event→the whole proposition. The raw
    # surface only shows the atom, hiding what PN actually decided to check; that defeats
    # the ADR-020 goal of auditing PN's unit construction. So we surface each merged unit
    # as its own annotatable target and DEMOTE the subsumed raw atom to na (the bare
    # component is not PN's checked unit). Merges are grouped by merged span (a
    # coordination can fuse two atoms into one unit); probeable wins if any contributor is.
    merges = {}   # merged-span tuple -> {roles:set, comp, text, atoms:[node_id]}
    for nid_pn, pn in pn_nodes.items():
        if pn.get("role") not in ("probeable", "na"):
            continue
        raw = nodes_by_id.get(nid_pn)
        if raw is None or raw.get("node_type") not in CONTENT_NODE_TYPES:
            continue
        pns = pn.get("pn_unit_span")
        if not pns:
            continue
        sp = (pns[0], pns[1])
        if sp == (raw.get("span_start"), raw.get("span_end")):
            continue   # span unchanged → the atom already IS PN's unit; nothing merged
        atom = items.get(nid_pn)   # demote the subsumed atom (if it survived dedup)
        if atom is not None and atom["kind"] == "node":
            atom["pn_role_pred"] = "na"
            atom["pn_src"] = "pn-sub"
        m = merges.setdefault(sp, {"roles": set(), "comp": pn.get("comp", ""),
                                   "text": pn.get("pn_unit_text", ""), "atoms": []})
        m["roles"].add(pn["role"])
        m["atoms"].append(nid_pn)
        if pn["role"] == "probeable":   # prefer a probeable contributor's comp/text
            m["comp"] = pn.get("comp", m["comp"])
            m["text"] = pn.get("pn_unit_text", m["text"])

    for sp, m in merges.items():
        role = "probeable" if "probeable" in m["roles"] else "na"
        nsp = _norm_span(sp, ct)
        here = [it for it in items.values()
                if _norm_span(it["span"], ct) == nsp and it["kind"] != "pn_unit"]
        if here:
            # (1a) PN unit coincides with an existing factor/node span → STAMP it (no
            #      duplicate row): the existing item IS PN's unit; carry PN's role onto it.
            tgt = max(here, key=lambda it: (it["kind"] == "factor",
                      FACTOR_PRIORITY.get(it.get("factor_type", ""), 0)))
            if tgt.get("factor_type") == "full_claim" and role == "na":
                pass   # never demote the proposition / verdict target below probeable
            elif tgt.get("pn_src") == "pn-stamp":
                if role == "probeable":
                    tgt["pn_role_pred"] = "probeable"   # probeable wins across stamps
            else:
                tgt["pn_role_pred"] = role      # PN's role overrides the heuristic default
                tgt["pn_src"] = "pn-stamp"
                tgt["pn_note"] = "[PN unit]"
        else:
            # (1b) free span (e.g. "by hand" [78,85]) → add a new annotatable PN-unit row;
            #      it renders/annotates like a factor and nests by span (under its factor,
            #      above its atom) via the size() ordering below.
            pid = "pn_" + m["atoms"][0]
            items[pid] = {
                "id": pid, "kind": "pn_unit",
                "node_type": "", "factor_type": "pn_merge",
                "unit_text": (m["text"] or ct[sp[0]:sp[1]]).strip(),
                "span": sp, "pn_role_pred": role, "comp": m["comp"],
                "marker": "", "pn_src": "pn-merge", "pn_note": "[PN unit]",
            }

    # root = the full_claim factor
    root_id = next((fa["id"] for fa in rec["factors"]
                    if fa.get("factor_type") == "full_claim"), None)
    if root_id is None:   # degenerate: pick the widest-spanning factor, else bail
        facs = [it for it in items.values() if it["kind"] == "factor"]
        root_id = max(facs, key=lambda it: it["span"][1] - it["span"][0])["id"] if facs else None

    # total-order "size" so containment is a strict tree. Width dominates; the priority
    # field only breaks exact-width ties: factors > pn_units > co-spanning content nodes
    # (so an atom nests under its PN merged unit, which nests under its factor).
    def size(it):
        w = it["span"][1] - it["span"][0]
        if it["kind"] == "factor":
            return (w, FACTOR_PRIORITY.get(it["factor_type"], 5), 1, it["id"])
        if it["kind"] == "pn_unit":
            return (w, 5, 1, it["id"])   # 5 < any FACTOR_PRIORITY, > node's 0
        return (w, 0, 0, it["id"])

    # containers = anything that can hold children (factors + PN merged units)
    containers = [it for it in items.values() if it["kind"] in ("factor", "pn_unit")]

    def contains(a, b):   # does container a's span contain item b's span?
        return a["span"][0] <= b["span"][0] and a["span"][1] >= b["span"][1]

    parent = {}
    for it in items.values():
        if it["id"] == root_id:
            parent[it["id"]] = None
            continue
        cands = [f for f in containers
                 if f["id"] != it["id"] and contains(f, it) and size(f) > size(it)]
        if cands:
            parent[it["id"]] = min(cands, key=size)["id"]
        else:
            parent[it["id"]] = root_id   # everything is inside full_claim

    children = {i: [] for i in items}
    for i, p in parent.items():
        if p is not None and p in children:
            children[p].append(i)
    # order siblings left→right by span start then start-of-text
    for i in children:
        children[i].sort(key=lambda c: (items[c]["span"][0], items[c]["span"][1]))

    # pre-order DFS with depth (level); cycle-safe visited guard
    order, level = [], {}
    seen = set()
    stack = [(root_id, 0)] if root_id else []
    # DFS that keeps sibling order: use explicit recursion
    def dfs(nid, d):
        if nid in seen or nid not in items:
            return
        seen.add(nid)
        level[nid] = d
        order.append(nid)
        for c in children.get(nid, []):
            dfs(c, d + 1)
    if root_id:
        dfs(root_id, 0)
    # append any unreached items (shouldn't happen; safety)
    for i in items:
        if i not in seen:
            level[i] = 0
            order.append(i)

    rows = []
    for nid in order:
        it = items[nid]
        rows.append({
            **it,
            "level": level.get(nid, 0),
            "parent_id": parent.get(nid) or "",
        })
    return rows, root_id


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--hypergraph", default=HYPERGRAPH)
    ap.add_argument("--trees", default=TREES_UD)
    ap.add_argument("--manifest", default=MANIFEST)
    ap.add_argument("--src-videos", default=SRC_VIDEOS)
    ap.add_argument("--outdir", default=OUTDIR)
    ap.add_argument("--n", type=int, default=40)
    ap.add_argument("--seed", type=int, default=20260723)
    ap.add_argument("--require", nargs="*", default=["T1JQ-aG78Zuc_794", "TInVWzp25aIM_2"],
                    help="claim_ids to force-include (tram + waves prototypes)")
    ap.add_argument("--first", default="TQKCK6-tRaoE_665",
                    help="claim_id placed FIRST on the site (featured example; force-included). "
                         "TQKCK6-tRaoE_665 = 'Huge crowd standing together chanting.' "
                         "(chanting=audio, standing together=visual, root=both — the poster worked example)")
    args = ap.parse_args()

    hg = load_jsonl(args.hypergraph)
    trees = load_jsonl(args.trees)
    man = load_manifest(args.manifest)

    # PN node lookup per claim
    pn_by_claim = {cid: {n["node_id"]: n for n in t["nodes"]}
                   for cid, t in trees.items()}

    # prefer claims with available media so modality is annotatable
    all_ids = sorted(hg)
    media_ids = [c for c in all_ids if has_media(c, man, args.src_videos)]
    pool = media_ids if media_ids else all_ids

    forced = [c for c in args.require if c in hg]
    n = min(args.n, len(pool))
    rng = random.Random(args.seed)
    sample = set(rng.sample(pool, n))
    for c in forced:
        sample.add(c)
    if args.first and args.first in hg:
        sample.add(args.first)
    # featured claim FIRST (for annotating ground-truth of the poster example), rest sorted
    first = [args.first] if (args.first and args.first in hg) else []
    sampled = first + sorted(sample - set(first))

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    n_node_rows = n_factor_rows = n_pn_rows = n_stamp = 0
    with open(outdir / "nodes_tree.tsv", "w", encoding="utf-8", newline="") as fn, \
         open(outdir / "claims.tsv", "w", encoding="utf-8", newline="") as fc:
        wn = csv.DictWriter(fn, fieldnames=NODE_COLS, delimiter="\t")
        wn.writeheader()
        wc = csv.DictWriter(fc, fieldnames=CLAIM_COLS, delimiter="\t")
        wc.writeheader()
        for cid in sampled:
            rec = hg[cid]
            rows, _ = build_claim_tree(rec, pn_by_claim.get(cid, {}))
            for r in rows:
                s, e = r["span"]
                note = "; ".join(x for x in (r.get("collapsed", ""), r.get("pn_note", "")) if x)
                wn.writerow({
                    "claim_id": cid, "node_id": r["id"],
                    "level": r["level"], "parent_id": r["parent_id"],
                    "kind": r["kind"], "node_type": r["node_type"],
                    "factor_type": r["factor_type"], "unit_text": r["unit_text"],
                    "span_start": s, "span_end": e,
                    "pn_role_pred": r["pn_role_pred"], "comp": r["comp"],
                    "pn_src": r.get("pn_src", ""),
                    "role_gold": "", "visual_gold": "", "audio_gold": "",
                    "notes": note,
                })
                if r["kind"] == "node":
                    n_node_rows += 1
                elif r["kind"] == "pn_unit":
                    n_pn_rows += 1
                else:
                    n_factor_rows += 1
                if r.get("pn_src") == "pn-stamp":
                    n_stamp += 1
            wc.writerow({
                "claim_id": cid, "claim_text": rec["claim_text"],
                "verdict_visual": "", "verdict_audio": "", "notes": "",
            })

    print(f"Sampled {len(sampled)} claims (n={args.n}, seed={args.seed}, "
          f"forced={forced}).")
    print(f"nodes_tree.tsv: {n_node_rows + n_factor_rows + n_pn_rows} rows "
          f"({n_node_rows} content nodes, {n_factor_rows} factors, "
          f"{n_pn_rows} PN merged-unit rows added; {n_stamp} factors stamped as PN units)")
    print(f"claims.tsv:     {len(sampled)} rows")
    print(f"pool: {len(pool)} claims with available media "
          f"(of {len(all_ids)} total)")
    print(f"→ {outdir}")


if __name__ == "__main__":
    main()
