"""Create a deterministic experiment overlay without changing older archives."""
import argparse,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/semantic_components_20261112'

def main():
    p=argparse.ArgumentParser();p.add_argument('--allow-missing-history',action='store_true');args=p.parse_args()
    names=['scripts/parse_component_probes.py','scripts/run_semantic_components.py','scripts/analyze_semantic_components.py','scripts/check_semantic_default.py','scripts/semantic_components_report.py','scripts/package_semantic_components.py','scripts/check_semantic_components_browser.py','scripts/check_semantic_components_archive.py','scripts/build_compiler_demos.py','scripts/build_verification_pipeline_report.py','scripts/build_av_feature_sections.py','tests/test_semantic_components.py','docs/semantic_components_20261112.md','docs/project_notes/daily_log.json','AGENTS.md','CLAUDE.md','docs/project_notes/key_facts.md','docs/project_notes/decisions.md','docs/project_notes/bugs.md','docs/project_notes/issues.md','docs/project_notes/terminology.md','site/reports/index.html','site/reports/verification-pipeline.html','site/reports/verification-pipeline/av/checklist.json','exp/probabilistic_verification/av_features_20261022/checklist.json']
    names +=[str(x.relative_to(ROOT))for folder,pattern in [('scripts/probabilistic_verification','*.py'),('scripts/report_assets','*')]for x in sorted((ROOT/folder).glob(pattern))if x.is_file()]
    data={n:(ROOT/n).read_bytes()for n in names}
    for n in ['publication.json','archive_verification.json','browser_checks.json']:
        path=ROOT/'exp/probabilistic_verification/rewrite_all_20261112'/n;data[str(path.relative_to(ROOT))]=path.read_bytes()
    excluded={'publication.json','archive_verification.json','browser_checks.json','final_source_sha256.json','WORK_STATUS.md'}
    for path in sorted(RUN.rglob('*')):
        if path.is_file()and path.suffix in{'.py','.json','.jsonl','.xml'}and path.name not in excluded:data[str(path.relative_to(ROOT))]=path.read_bytes()
    freeze={n:hashlib.sha256(b).hexdigest()for n,b in data.items()}
    (RUN/'final_source_sha256.json').write_text(json.dumps(freeze,indent=2)+'\n')
    data[str((RUN/'final_source_sha256.json').relative_to(ROOT))]=(RUN/'final_source_sha256.json').read_bytes()
    data['README_SEMANTIC_COMPONENTS.md']=(ROOT/'docs/semantic_components_20261112.md').read_bytes()
    data['SEMANTIC_COMPONENTS_SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+n+'\n'for n,b in sorted(data.items())).encode()
    target=ROOT/'site/reports/compiler-demos/components-20261112/source.zip';target.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED)as archive:
        for n,b in sorted(data.items()):
            info=zipfile.ZipInfo(n,date_time=(2026,11,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,b)
    manifest=json.loads((RUN/'manifest.json').read_text())
    for n,h in manifest['baseline_sha256'].items():assert hashlib.sha256((RUN/'baseline_source'/n).read_bytes()).hexdigest()==h,n
    for n,h in manifest['inputs_sha256'].items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
    for n,h in json.loads((RUN/'preserved_archives.json').read_text()).items():
        path=ROOT/n
        if path.exists():assert hashlib.sha256(path.read_bytes()).hexdigest()==h,n
        else:assert args.allow_missing_history,n
    for n,h in json.loads((ROOT/'exp/probabilistic_verification/claim_rewrite_20261111/viewer_sha256.json').read_text()).items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
    print('Packaged',len(data),'files;',round(target.stat().st_size/1048576,2),'MiB; historical archives/inputs/viewers preserved.')

if __name__=='__main__':main()
