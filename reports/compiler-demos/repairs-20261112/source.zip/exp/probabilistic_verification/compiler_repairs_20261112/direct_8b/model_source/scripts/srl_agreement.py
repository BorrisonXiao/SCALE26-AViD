#!/usr/bin/env python3
"""Agreement between PN-2's LLM adjunct-role labels and the trained SRL baseline.

Aligns each PN-2 adjunct edge (predicate, modifier) to the trained-SRL argument of the
matching predicate by TEXT overlap (tokenizer-agnostic), maps PropBank labels to our
9-way set, and reports agreement — overall, per-label confusion, and the headline
MNR/INS (manner-instrument) precision/recall + alignment coverage.

Inputs : exp/phase3/trees/pn_roles.jsonl        (our labels)
         exp/phase3/srl_baseline/srl_frames.jsonl (trained SRL)
Output : exp/phase3/reports/srl_agreement/{summary.md,confusion.tsv,disagreements.tsv}
See docs/plans/avid_phase3_srl_validation_v1.md.
"""
import json, re, collections
from pathlib import Path

AVID = Path("/exp/cxiao/scale26/avid")
ROLES  = AVID / "exp/phase3/trees/pn_roles.jsonl"
FRAMES = AVID / "exp/phase3/srl_baseline/srl_frames.jsonl"
OUT    = AVID / "exp/phase3/reports/srl_agreement"

# PropBank → our 9-way label set
PB2OURS = {
    "ARGM-MNR": "MNR", "ARGM-DIR": "DIR", "ARGM-GOL": "DIR", "ARGM-LOC": "LOC",
    "ARGM-TMP": "TMP", "ARGM-CAU": "CAU", "ARGM-PRP": "PRP", "ARGM-PNC": "PRP",
}
def map_pb(role):
    if role in PB2OURS: return PB2OURS[role]
    if re.fullmatch(r"ARG[0-5A]", role): return "CORE"
    return "OTHER"

MANNER = {"MNR", "INS"}          # headline bucket (PropBank folds INS into MNR/ARG2)
def norm(t): return set(re.sub(r"[^\w\s]", " ", (t or "").lower()).split())

def jacc(a, b):
    if not a or not b: return 0.0
    return len(a & b) / len(a | b)

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    frames_by_claim = collections.defaultdict(list)   # claim_id → list of FRAMES (flattened)
    for l in open(FRAMES):
        r = json.loads(l); frames_by_claim[r["claim_id"]].extend(r.get("frames", []))

    rows = [json.loads(l) for l in open(ROLES)]
    aligned = []            # (our_role, srl_ours, our_mod, srl_text, srl_pb, claim_id)
    cov = collections.Counter()
    for e in rows:
        cid = e["claim_id"]; our_role = e.get("srl_role", "?")
        pred_w = norm(e.get("predicate")); mod_w = norm(e.get("modifier"))
        claim_frames = frames_by_claim.get(cid, [])
        if not claim_frames: cov["no_claim"] += 1; continue
        # Align by the MODIFIER span's text overlap across ALL frames' args; the SRL
        # predicate (verb) often differs from the UD parent (e.g. adjunct on "qualified"
        # but SRL frames it under "were"), so predicate is only a tiebreak, not a gate.
        best = None  # (score, pb_role, text, raw_jaccard)
        for fr in claim_frames:
            vmatch = 0.05 if (norm(fr.get("verb")) & pred_w) else 0.0
            for a in fr.get("args", []):
                j = jacc(mod_w, norm(a.get("text")))
                score = j + vmatch
                if best is None or score > best[0]:
                    best = (score, a.get("role"), a.get("text"), j)
        if best is None: cov["no_arg"] += 1; continue
        if best[3] < 0.34: cov["no_arg_overlap"] += 1; continue
        cov["aligned"] += 1
        aligned.append((our_role, map_pb(best[1]), e.get("modifier"), best[2], best[1], cid))

    n = len(aligned)
    exact = sum(1 for o, s, *_ in aligned if o == s)
    manner_agree = sum(1 for o, s, *_ in aligned if (o in MANNER) == (s in MANNER))
    # MNR/INS as a detection task (our label = "positive")
    tp = sum(1 for o, s, *_ in aligned if o in MANNER and s in MANNER)
    fp = sum(1 for o, s, *_ in aligned if o in MANNER and s not in MANNER)
    fn = sum(1 for o, s, *_ in aligned if o not in MANNER and s in MANNER)
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec  = tp / (tp + fn) if tp + fn else 0.0

    # confusion (our rows × srl cols)
    labels = ["MNR", "INS", "PRP", "TMP", "LOC", "DIR", "CAU", "CORE", "OTHER"]
    conf = collections.Counter((o, s) for o, s, *_ in aligned)

    with open(OUT / "confusion.tsv", "w") as f:
        f.write("our\\srl\t" + "\t".join(labels) + "\ttotal\n")
        for o in labels:
            r = [conf.get((o, s), 0) for s in labels]
            f.write(f"{o}\t" + "\t".join(map(str, r)) + f"\t{sum(r)}\n")

    with open(OUT / "disagreements.tsv", "w") as f:
        f.write("claim_id\tour_role\tsrl_role\tour_modifier\tsrl_arg_text\n")
        for o, s, mod, stext, pb, cid in aligned:
            if (o in MANNER) != (s in MANNER):
                f.write(f"{cid}\t{o}\t{pb}\t{mod}\t{stext}\n")

    tot = sum(cov.values())
    with open(OUT / "summary.md", "w") as f:
        f.write("# PN-2 LLM role typing vs. trained SRL (AllenNLP BERT-SRL) — agreement\n\n")
        f.write(f"- Edges: {tot} | **aligned: {cov['aligned']} ({cov['aligned']/max(tot,1):.1%})** "
                f"| no-arg-in-frames {cov['no_arg']} | modifier-overlap<0.34 {cov['no_arg_overlap']} "
                f"| no-SRL-frame-for-claim {cov['no_claim']}\n")
        f.write(f"- **Exact 9-way agreement (aligned): {exact}/{n} = {exact/n:.1%}**\n")
        f.write(f"- **Manner/Instrument (MNR∪INS) agreement: {manner_agree}/{n} = {manner_agree/n:.1%}**\n")
        f.write(f"- **MNR/INS as detection — precision {prec:.1%}, recall {rec:.1%}** "
                f"(tp={tp} fp={fp} fn={fn}) — the case-keep linchpin\n\n")
        f.write("Confusion (our rows × SRL cols) → `confusion.tsv`; MNR/INS disagreements → `disagreements.tsv`.\n\n")
        f.write("Interpretation: agreement between two *systems*, not accuracy vs gold. Coverage < 100% is "
                "expected (label-scheme + span differences — the reason UD, not SRL, is the backbone). "
                "High MNR/INS agreement validates the ADR-019 case-keep rule; the disagreement dump is the "
                "human-adjudication / manner-MWE-allowlist candidate set.\n")

    print(f"aligned {cov['aligned']}/{tot} ({cov['aligned']/tot:.1%}) | exact {exact/n:.1%} | "
          f"manner-agree {manner_agree/n:.1%} | MNR/INS P {prec:.1%} R {rec:.1%}")
    print(f"→ {OUT}/summary.md")

if __name__ == "__main__":
    main()
