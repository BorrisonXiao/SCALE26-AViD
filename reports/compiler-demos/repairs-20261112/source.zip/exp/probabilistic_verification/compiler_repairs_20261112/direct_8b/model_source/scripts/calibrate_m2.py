#!/usr/bin/env python3
"""
AViD Phase 3 — 3-way temperature calibration for M2 probe distributions.

Problem: Qwen3-VL/Omni at temperature=0 produces saturated 3-way distributions
(43% of visual units have entropy < 0.1; bimodal near 0/1). Temperature scaling
T > 1 spreads these toward proper probabilities.

Dev set (weak supervision):
  Root-node gold from tree-CRF verdicts on T* v1 (decomp_ud_star_v1.jsonl):
    supported   → root gold = "yes"   (SUP)
    unsupported → root gold = "no"    (REF)
    partial     → skip (ambiguous)
  Root node identified via trees_ud_star.jsonl root_id.
  80/20 stratified split by claim_id for fitting / validation.

Method:
  Temperature scaling: calibrated_P(s) = softmax(log(P(s)) / T)
  Fit T per modality by minimizing NLL on 80% dev root nodes.
  Secondary: Brier score + ECE (15-bin) on 20% held-out.

Output:
  exp/phase3/nodes/calibrated_visual_star.jsonl
  exp/phase3/nodes/calibrated_audio_star.jsonl
  Schema per row: {claim_id, unit_id, visual: {yes,no,cant_tell},
                   audio: {yes,no,cant_tell}, T_vis, T_aud}

Usage:
    python scripts/calibrate_m2.py
    python scripts/calibrate_m2.py --plot          # reliability diagram (matplotlib)
    python scripts/calibrate_m2.py --T-vis 1.5 --T-aud 1.0  # fixed T override
"""

import argparse
import json
import math
import random
from collections import defaultdict
from pathlib import Path

_AVID = Path("/exp/cxiao/scale26/avid")

DECOMP_V1     = str(_AVID / "exp/phase3/crf/decomp_ud_star_v1.jsonl")
TREES         = str(_AVID / "exp/phase3/trees/trees_ud_star.jsonl")
VIS_IN        = str(_AVID / "exp/phase3/nodes/verify_visual_star.jsonl")
AUD_IN        = str(_AVID / "exp/phase3/nodes/verify_audio_star.jsonl")
VIS_OUT       = str(_AVID / "exp/phase3/nodes/calibrated_visual_star.jsonl")
AUD_OUT       = str(_AVID / "exp/phase3/nodes/calibrated_audio_star.jsonl")
COMBINED_OUT  = str(_AVID / "exp/phase3/nodes/unaries_ud_star.jsonl")

KEYS_3WAY = ["yes", "no", "cant_tell"]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def entropy(dist: dict) -> float:
    return -sum(p * math.log(max(p, 1e-12)) for p in dist.values())


def temp_scale(dist: dict, T: float) -> dict:
    """Apply temperature scaling: calibrated_P(s) = softmax(log(P(s)) / T)."""
    logits = {k: math.log(max(dist.get(k, 1e-10), 1e-10)) / T for k in KEYS_3WAY}
    mx = max(logits.values())
    exp_l = {k: math.exp(v - mx) for k, v in logits.items()}
    Z = sum(exp_l.values())
    return {k: v / Z for k, v in exp_l.items()}


def nll_loss(T: float, pairs: list) -> float:
    """Mean NLL for temperature T on a list of (dist, gold_key) pairs."""
    total = 0.0
    for dist, gold in pairs:
        cal = temp_scale(dist, T)
        total -= math.log(max(cal[gold], 1e-12))
    return total / max(len(pairs), 1)


def brier_score(pairs: list, T: float = 1.0) -> float:
    """Multi-class Brier score."""
    total = 0.0
    for dist, gold in pairs:
        cal = temp_scale(dist, T)
        for k in KEYS_3WAY:
            y = 1.0 if k == gold else 0.0
            total += (cal[k] - y) ** 2
    return total / max(len(pairs), 1)


def ece(pairs: list, T: float = 1.0, n_bins: int = 15) -> float:
    """Expected calibration error (max-class confidence vs accuracy)."""
    bins = [[] for _ in range(n_bins)]
    for dist, gold in pairs:
        cal = temp_scale(dist, T)
        conf = max(cal.values())
        pred = max(cal, key=cal.get)
        acc = 1.0 if pred == gold else 0.0
        b = min(int(conf * n_bins), n_bins - 1)
        bins[b].append((conf, acc))
    ece_val = 0.0
    n = sum(len(b) for b in bins)
    for b in bins:
        if not b:
            continue
        avg_conf = sum(x[0] for x in b) / len(b)
        avg_acc  = sum(x[1] for x in b) / len(b)
        ece_val += len(b) / n * abs(avg_conf - avg_acc)
    return ece_val


def grid_search_T(pairs: list, T_min: float = 0.5, T_max: float = 4.0,
                  n_steps: int = 70) -> tuple[float, float]:
    """Grid search for optimal temperature minimizing NLL."""
    best_T = 1.0
    best_nll = nll_loss(1.0, pairs)
    step = (T_max - T_min) / n_steps
    for i in range(n_steps + 1):
        T = T_min + i * step
        loss = nll_loss(T, pairs)
        if loss < best_nll:
            best_nll = loss
            best_T = T
    # Refine around best_T
    lo, hi = max(T_min, best_T - step), min(T_max, best_T + step)
    for i in range(50):
        T = lo + (hi - lo) * i / 49
        loss = nll_loss(T, pairs)
        if loss < best_nll:
            best_nll = loss
            best_T = T
    return best_T, best_nll


# ---------------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------------

def load_crf_verdicts(path: str) -> dict[str, str]:
    """Load claim-level CRF verdicts from decomp jsonl."""
    verdicts: dict[str, str] = {}
    with open(path) as f:
        for line in f:
            r = json.loads(line)
            verdicts[r["claim_id"]] = r.get("root_verdict", "")
    return verdicts


def load_root_ids(path: str) -> dict[str, str]:
    """Load {claim_id: root_node_id} from trees_ud_star.jsonl."""
    roots: dict[str, str] = {}
    with open(path) as f:
        for line in f:
            t = json.loads(line)
            if t.get("root_id"):
                roots[t["claim_id"]] = t["root_id"]
    return roots


def load_m2(path: str) -> dict[str, dict]:
    """{claim_id: {unit_id: pass1_dist}} from verify_*_star.jsonl."""
    data: dict[str, dict] = {}
    with open(path) as f:
        for line in f:
            r = json.loads(line)
            data.setdefault(r["claim_id"], {})[r["unit_id"]] = r["pass1_dist"]
    return data


# ---------------------------------------------------------------------------
# Build dev set
# ---------------------------------------------------------------------------

def build_dev_pairs(crf_verdicts, root_ids, m2_data, seed=42) -> tuple[list, list]:
    """Build (dist, gold_key) pairs; split 80/20 into train/val."""
    all_pairs: list[tuple[dict, str, str]] = []  # (dist, gold, claim_id)
    for cid, verdict in crf_verdicts.items():
        if verdict == "supported":
            gold = "yes"
        elif verdict == "unsupported":
            gold = "no"
        else:
            continue   # partial → skip (ambiguous)
        root_id = root_ids.get(cid)
        if root_id is None:
            continue
        dist = m2_data.get(cid, {}).get(root_id)
        if dist is None:
            continue
        all_pairs.append((dist, gold, cid))

    rng = random.Random(seed)
    rng.shuffle(all_pairs)
    split = int(0.8 * len(all_pairs))
    train = [(d, g) for d, g, _ in all_pairs[:split]]
    val   = [(d, g) for d, g, _ in all_pairs[split:]]
    return train, val


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--decomp",   default=DECOMP_V1)
    ap.add_argument("--trees",    default=TREES)
    ap.add_argument("--vis-in",   default=VIS_IN)
    ap.add_argument("--aud-in",   default=AUD_IN)
    ap.add_argument("--vis-out",  default=VIS_OUT)
    ap.add_argument("--aud-out",  default=AUD_OUT)
    ap.add_argument("--combined", default=COMBINED_OUT,
                    help="Combined per-node unaries (visual+audio in one row).")
    ap.add_argument("--T-vis",    type=float, default=0.0,
                    help="Override visual temperature (0 = auto-fit).")
    ap.add_argument("--T-aud",    type=float, default=0.0,
                    help="Override audio temperature (0 = auto-fit).")
    ap.add_argument("--plot",     action="store_true",
                    help="Emit reliability diagram (requires matplotlib).")
    args = ap.parse_args()

    print("=" * 60)
    print("AViD M2 — 3-way temperature calibration")
    print("=" * 60)

    # --- Load ---
    print("\n[1] Loading data …")
    crf_verdicts = load_crf_verdicts(args.decomp)
    root_ids     = load_root_ids(args.trees)
    m2_vis       = load_m2(args.vis_in)
    m2_aud       = load_m2(args.aud_in)
    print(f"  CRF verdicts: {len(crf_verdicts)} claims")
    print(f"  Root IDs:     {len(root_ids)} claims")
    print(f"  Visual M2:    {sum(len(v) for v in m2_vis.values())} units")
    print(f"  Audio M2:     {sum(len(v) for v in m2_aud.values())} units")

    # --- Distribution stats ---
    print("\n[2] Raw distribution stats …")
    for label, m2 in [("Visual", m2_vis), ("Audio", m2_aud)]:
        all_dists = [d for uid_map in m2.values() for d in uid_map.values()]
        ents = [entropy(d) for d in all_dists]
        maxps = [max(d.values()) for d in all_dists]
        n = len(all_dists)
        print(f"  {label} ({n} units):")
        print(f"    entropy:  mean={sum(ents)/n:.3f}  "
              f"frac<0.1={sum(e<0.1 for e in ents)/n:.1%}  "
              f"frac<0.3={sum(e<0.3 for e in ents)/n:.1%}")
        print(f"    P(argmax)>0.95: {sum(p>0.95 for p in maxps)/n:.1%}  "
              f"  >0.99: {sum(p>0.99 for p in maxps)/n:.1%}")

    # --- Build dev sets ---
    print("\n[3] Building dev sets (root nodes, CRF-verdict gold) …")
    train_vis, val_vis = build_dev_pairs(crf_verdicts, root_ids, m2_vis)
    train_aud, val_aud = build_dev_pairs(crf_verdicts, root_ids, m2_aud)
    print(f"  Visual: train={len(train_vis)}  val={len(val_vis)}")
    print(f"  Audio:  train={len(train_aud)}  val={len(val_aud)}")

    verdict_dist = {v: 0 for v in ["supported", "unsupported", "partially_supported"]}
    for v in crf_verdicts.values():
        verdict_dist[v] = verdict_dist.get(v, 0) + 1
    print(f"  CRF verdict distribution: "
          + "  ".join(f"{k}={v}" for k, v in verdict_dist.items()))

    # --- Fit temperature ---
    print("\n[4] Fitting temperature …")

    def fit_and_report(label, train, val, T_override):
        print(f"\n  --- {label} ---")
        if T_override > 0 and not train:
            # Explicit temperature override with no dev set available (e.g.
            # calibrating decoy/perturb probes whose claim_ids do not match the
            # natural dev decomp). Honor the override directly — there is nothing
            # to fit or evaluate. (Natural runs always have a non-empty dev set,
            # so this branch never triggers there; behavior is unchanged for them.)
            print(f"  T={T_override:.3f} (override; no dev set to fit/eval)")
            return T_override
        if not train:
            print("  WARNING: no training pairs; using T=1.0")
            return 1.0

        # Baseline (T=1.0)
        nll_base = nll_loss(1.0, val)
        brier_base = brier_score(val, T=1.0)
        ece_base = ece(val, T=1.0)
        print(f"  T=1.0 (raw):  NLL={nll_base:.4f}  Brier={brier_base:.4f}  ECE={ece_base:.4f}")

        if T_override > 0:
            T = T_override
            print(f"  T={T:.3f} (override; not fitted)")
        else:
            T, _ = grid_search_T(train)
            print(f"  T={T:.3f} (fitted on {len(train)} root-node pairs)")

        nll_cal = nll_loss(T, val)
        brier_cal = brier_score(val, T=T)
        ece_cal = ece(val, T=T)
        print(f"  T={T:.3f}:      NLL={nll_cal:.4f}  Brier={brier_cal:.4f}  ECE={ece_cal:.4f}")
        print(f"  ΔNLL={nll_cal-nll_base:+.4f}  ΔBrier={brier_cal-brier_base:+.4f}  "
              f"ΔECE={ece_cal-ece_base:+.4f}")
        return T

    T_vis = fit_and_report("Visual", train_vis, val_vis, args.T_vis)
    T_aud = fit_and_report("Audio",  train_aud, val_aud, args.T_aud)

    print(f"\n  Calibration temperatures: T_vis={T_vis:.3f}  T_aud={T_aud:.3f}")

    # --- Write calibrated outputs ---
    print("\n[5] Writing calibrated outputs …")

    def write_calibrated(m2_data, T, out_path, label):
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        n = 0
        with open(out_path, "w") as f:
            for cid, uid_map in m2_data.items():
                for uid, dist in uid_map.items():
                    cal = temp_scale(dist, T)
                    row = {
                        "claim_id": cid,
                        "unit_id":  uid,
                        "verdict":  max(cal, key=cal.get),
                        "dist":     cal,
                        "T":        round(T, 4),
                        "raw_dist": dist,
                    }
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")
                    n += 1
        print(f"  {label}: {n} rows → {out_path}")
        return n

    write_calibrated(m2_vis, T_vis, args.vis_out, "Visual")
    write_calibrated(m2_aud, T_aud, args.aud_out, "Audio")

    # --- Write combined unaries (for CRF) ---
    print(f"\n[6] Writing combined unaries → {args.combined}")
    # Map 3-way {yes, no, cant_tell} → CRF 3-state arrays [NO, A, B]:
    #   φ(NO) = P(no) + P(cant_tell)/3     ← NEI is partially "no signal" (uniform)
    #   φ(A)  = P(yes)/2 + P(cant_tell)/3  ← 50/50 split of YES between visual subtypes
    #   φ(B)  = P(yes)/2 + P(cant_tell)/3
    # CRF state names: visual: NO=no, A=ocr, B=other; audio: NO=no, A=speech, B=other
    def to_crf_states(cal_dist: dict, vis_or_aud: str) -> dict:
        p_yes = cal_dist.get("yes", 1/3)
        p_no  = cal_dist.get("no", 1/3)
        p_ct  = cal_dist.get("cant_tell", 1/3)
        phi_no = p_no + p_ct / 3
        phi_a  = p_yes / 2 + p_ct / 3
        phi_b  = p_yes / 2 + p_ct / 3
        if vis_or_aud == "visual":
            return {"no": phi_no, "ocr": phi_a, "other": phi_b}
        return {"no": phi_no, "speech": phi_a, "other": phi_b}

    all_keys: set = set()
    for cid, uid_map in m2_vis.items():
        for uid in uid_map:
            all_keys.add((cid, uid))
    for cid, uid_map in m2_aud.items():
        for uid in uid_map:
            all_keys.add((cid, uid))

    Path(args.combined).parent.mkdir(parents=True, exist_ok=True)
    n_combined = 0
    with open(args.combined, "w") as f:
        for cid, uid in sorted(all_keys):
            vis_raw = m2_vis.get(cid, {}).get(uid)
            aud_raw = m2_aud.get(cid, {}).get(uid)
            vis_cal = temp_scale(vis_raw, T_vis) if vis_raw else None
            aud_cal = temp_scale(aud_raw, T_aud) if aud_raw else None
            row = {
                "claim_id": cid,
                "unit_id":  uid,
                # 3-way calibrated distributions (for reference / calibration eval)
                "visual_3way": vis_cal,
                "audio_3way":  aud_cal,
                # CRF-compatible [NO, A, B] distributions (for run_crf_inference.py)
                "visual": to_crf_states(vis_cal, "visual") if vis_cal else None,
                "audio":  to_crf_states(aud_cal, "audio")  if aud_cal else None,
                "T_vis":  round(T_vis, 4),
                "T_aud":  round(T_aud, 4),
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            n_combined += 1
    print(f"  {n_combined} (claim, unit) pairs → {args.combined}")

    # --- Distribution stats after calibration ---
    print("\n[7] Calibrated distribution stats …")
    for label, m2, T in [("Visual", m2_vis, T_vis), ("Audio", m2_aud, T_aud)]:
        all_dists = [d for uid_map in m2.values() for d in uid_map.values()]
        cal_dists = [temp_scale(d, T) for d in all_dists]
        ents = [entropy(d) for d in cal_dists]
        maxps = [max(d.values()) for d in cal_dists]
        n = len(cal_dists)
        print(f"  {label} (T={T:.3f}, {n} units):")
        print(f"    entropy:  mean={sum(ents)/n:.3f}  "
              f"frac<0.1={sum(e<0.1 for e in ents)/n:.1%}")
        print(f"    P(argmax)>0.95: {sum(p>0.95 for p in maxps)/n:.1%}")

    # --- Reliability diagram ---
    if args.plot:
        try:
            import matplotlib.pyplot as plt
            fig, axes = plt.subplots(1, 2, figsize=(10, 4))
            for ax, label, val, T in [
                (axes[0], "Visual", val_vis, T_vis),
                (axes[1], "Audio",  val_aud, T_aud),
            ]:
                n_bins = 15
                for T_val, style, lbl in [(1.0, "--", "Raw T=1"), (T, "-", f"Cal T={T:.2f}")]:
                    bins_conf = [[] for _ in range(n_bins)]
                    bins_acc  = [[] for _ in range(n_bins)]
                    for dist, gold in val:
                        cal = temp_scale(dist, T_val)
                        conf = max(cal.values())
                        pred = max(cal, key=cal.get)
                        acc = 1.0 if pred == gold else 0.0
                        b = min(int(conf * n_bins), n_bins - 1)
                        bins_conf[b].append(conf)
                        bins_acc[b].append(acc)
                    xs = [sum(bc)/len(bc) if bc else (i+0.5)/n_bins
                          for i, bc in enumerate(bins_conf)]
                    ys = [sum(ba)/len(ba) if ba else 0
                          for ba in bins_acc]
                    ax.plot(xs, ys, style, label=lbl)
                ax.plot([0, 1], [0, 1], "k:", alpha=0.5, label="Perfect")
                ax.set_xlabel("Confidence")
                ax.set_ylabel("Accuracy")
                ax.set_title(f"{label} reliability diagram")
                ax.legend()
            plt.tight_layout()
            fig_path = str(_AVID / "exp/phase3/reports/calibration_reliability.png")
            Path(fig_path).parent.mkdir(parents=True, exist_ok=True)
            plt.savefig(fig_path, dpi=120, bbox_inches="tight")
            print(f"\n  Reliability diagram → {fig_path}")
        except ImportError:
            print("  matplotlib not available; skipping plot.")

    print("\nDone.")
    print(f"  Calibrated outputs:")
    print(f"    {args.vis_out}")
    print(f"    {args.aud_out}")
    print(f"    {args.combined}  ← CRF unaries input")


if __name__ == "__main__":
    main()
