"""Verify the consolidated views, historical URLs and existing case inspectors."""
import functools,http.server,json,threading
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/report_cleanup_20261112'


def main():
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'site')))
    threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
    with sync_playwright()as p:
        browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1100})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(base+'/reports/',wait_until='networkidle');assert page.locator('.card-link').count()==2
        page.locator('a[href="compiler-demos.html#history"]').click();page.wait_for_selector('#history',state='visible')
        assert page.locator('[role="tab"]').all_text_contents()==['Overview','Examples','All claims','Daily log','History']
        assert page.locator('[role="tabpanel"]').count()==5
        assert page.locator('[role="tabpanel"] [role="tabpanel"]').count()==0
        page.click('[data-tab="current-work"]')
        text=page.locator('#current-work').inner_text();assert all(t in text for t in ['449','420','29','227','173','43','81.09%'])
        page.evaluate('document.documentElement.style.scrollBehavior="auto";document.querySelector("#remaining-failures").scrollIntoView({behavior:"instant",block:"start"})');page.screenshot(path=str(RUN/'overview_desktop.png'))
        for fragment,panel in [('remaining-failures','current-work'),('split-alignment','walkthroughs'),('alignment-example','walkthroughs'),('syntax-demos','walkthroughs'),('outputs','outputs'),('results','history'),('alert-review','history'),('rewrite-pilot','history'),('split-example','history'),('initial-splitting','history'),('metric-history','history'),('step-omissions','history'),('daily-progress','daily-progress')]:
            page.goto(base+'/reports/compiler-demos.html#'+fragment,wait_until='networkidle');page.wait_for_selector('#'+panel,state='visible')
            assert page.locator('[role="tabpanel"]:visible').count()==1,fragment
        page.goto(base+'/reports/compiler-demos.html?alignment=TFgw4IaR9R8s_1587&alignment_condition=sentences#alignment-example',wait_until='networkidle')
        assert page.locator('#alignment-case').input_value()=='TFgw4IaR9R8s_1587'
        assert 'Approved as a faithful'in page.locator('#alignment-review').inner_text()
        assert page.locator('#alignment-system').text_content()
        page.select_option('#alignment-case','TgR_u37mCoQ4_1916');assert 'Not approved'in page.locator('#alignment-review').inner_text()
        page.goto(base+'/reports/compiler-demos.html?claim=Tg0UxWYuPeJ0_385#walkthroughs',wait_until='networkidle')
        assert page.locator('#demo-select').input_value()=='Tg0UxWYuPeJ0_385'
        assert page.locator('#demo-select option').count()==41
        page.goto(base+'/reports/compiler-demos.html?rewrite=TFgw4IaR9R8s_1587&rewrite_prompt=revised#rewrite-case-inspector',wait_until='networkidle')
        assert page.locator('#history').is_visible();assert 'which he signed'in page.locator('#rewrite-raw-response').inner_text()
        page.goto(base+'/reports/compiler-demos.html#split-example',wait_until='networkidle');assert page.locator('#split-case option').count()==8
        archive_links=page.locator('#history > ul a').evaluate_all('(links)=>links.map(x=>x.getAttribute("href"))')
        assert len(archive_links)==11
        for href in archive_links:assert page.request.get(base+'/reports/'+href).ok,href
        page.goto(base+'/reports/compiler-demos.html#remaining-failures',wait_until='networkidle')
        page.set_viewport_size({'width':390,'height':844});page.emulate_media(color_scheme='dark');page.wait_for_timeout(150)
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
        page.evaluate('document.querySelector("#remaining-failures").scrollIntoView({behavior:"instant",block:"start"})');page.screenshot(path=str(RUN/'overview_mobile_dark.png'))
        for name in ['failure_audit.json','remaining.json','README.md','source.zip']:
            assert page.request.get(base+'/reports/compiler-demos/maintenance-20261112/'+name).ok,name
        assert not errors,errors
        proof=dict(main_reports=2,report_views=5,historical_pages=len(archive_links),legacy_fragments_checked=13,old_demos=41,manual_cases=8,current_and_historical_inspectors=True,mobile_overflow=False,page_errors=errors)
        (RUN/'browser_checks.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof);browser.close()
    server.shutdown()


if __name__=='__main__':main()
