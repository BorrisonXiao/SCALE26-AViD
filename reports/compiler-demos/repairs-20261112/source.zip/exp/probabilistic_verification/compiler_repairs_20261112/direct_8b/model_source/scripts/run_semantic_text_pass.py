#!/usr/bin/env python3
"""Run the semantic-v1 text-only normalization and question pass.

The preferred production backend is the frozen Qwen model used by the earlier
pipeline.  This script also supports the configured Codex CLI as a deterministic
pilot fallback when the GPU scheduler is unavailable.  In either case, graph
normalization and question wording are separate calls and separate caches.

The runner batches *records*, but tells the model to apply the single-target
canonical prompt independently to every record.  Outputs are validated against
closed roles/relations and malformed items fall back to the deterministic
compiler rather than silently changing graph structure.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from prompts_phase2 import (
    SEMANTIC_EVIDENCE_ROLES,
    SEMANTIC_NORMALIZE_PROMPT_VERSION,
    SEMANTIC_NORMALIZE_SYSTEMS,
    SEMANTIC_QUESTION_PROMPT_VERSION,
    SEMANTIC_QUESTION_SYSTEMS,
    SEMANTIC_RELATION_LABELS,
    SEMANTIC_UNIT_PROMPT_VERSION,
    SEMANTIC_UNIT_SYSTEMS,
)
from semantic_factor_tree import (
    DEFAULT_HYPERGRAPH,
    DEFAULT_PN_ROLES,
    DEFAULT_TREES,
    compile_tree,
    index_by,
    read_jsonl,
    write_jsonl,
)


ROOT = Path("/exp/cxiao/scale26/avid")
DEFAULT_CLAIMS = ROOT / "exp/phase3/gold_v2/claims.tsv"
DEFAULT_RUN_DIR = ROOT / "exp/phase3/semantic_v1/text_pass_pilot"


def claim_ids_from_tsv(path: Path) -> list[str]:
    with path.open(encoding="utf-8", newline="") as f:
        return [row["claim_id"] for row in csv.DictReader(f, delimiter="\t")]


def chunks(rows: list[dict[str, Any]], n: int) -> Iterable[list[dict[str, Any]]]:
    for i in range(0, len(rows), n):
        yield rows[i:i + n]


def _json_from_text(text: str) -> dict[str, Any]:
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start:end + 1])
        raise


def run_codex(prompt: str, *, model: str, effort: str) -> dict[str, Any]:
    """Run one read-only Codex call and return its final JSON object."""
    with tempfile.NamedTemporaryFile(prefix="avid-semantic-", suffix=".json", delete=False) as tmp:
        out_path = Path(tmp.name)
    cmd = [
        "codex", "exec", "--ephemeral", "--skip-git-repo-check",
        "-s", "read-only", "-C", str(ROOT), "-m", model,
        "-c", f'model_reasoning_effort="{effort}"',
        "-o", str(out_path), "-",
    ]
    try:
        proc = subprocess.run(
            cmd, input=prompt, text=True, capture_output=True, check=False,
        )
        if proc.returncode:
            raise RuntimeError(
                f"codex exited {proc.returncode}: {(proc.stderr or proc.stdout)[-2000:]}"
            )
        return _json_from_text(out_path.read_text(encoding="utf-8"))
    finally:
        out_path.unlink(missing_ok=True)


def batch_prompt(system: str, stage: str, items: list[dict[str, Any]]) -> str:
    schemas = {
        "unit": (
            '{"results":[{"claim_id":"...","target_id":"...",'
            '"evidence_role":"unary_probe|observed_factor|contract|abstain",'
            '"semantic_relation":"attribute|cardinality|manner|temporal|other",'
            '"reason":"12 words or fewer"}]}'
        ),
        "edge": (
            '{"results":[{"claim_id":"...","target_id":"...",'
            '"semantic_relation":"<allowed label>",'
            '"evidence_role":"observed_factor|fixed_factor|abstain",'
            '"reason":"12 words or fewer"}]}'
        ),
        "question": (
            '{"results":[{"claim_id":"...","target_id":"...",'
            '"display_text":"natural target phrase",'
            '"visual_question":"...?","audio_question":"...?"}]}'
        ),
    }
    return (
        f"{system}\n\n"
        "BATCH WRAPPER: The records below are independent. Apply the instruction "
        "to each record in isolation. Never transfer words, endpoints, or decisions "
        "between records. Preserve claim_id and target_id exactly. Return every record "
        "once, in input order.\n"
        f"Return exactly this JSON shape: {schemas[stage]}\n\n"
        f"RECORDS:\n{json.dumps(items, ensure_ascii=False, indent=2)}"
    )


def call_batches(
    *, stage: str, system: str, items: list[dict[str, Any]], batch_size: int,
    model: str, effort: str, dry_run: bool,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    outputs, failures = [], []
    for batch_no, batch in enumerate(chunks(items, batch_size), 1):
        prompt = batch_prompt(system, stage, batch)
        if dry_run:
            print(f"[{stage}] batch {batch_no}: {len(batch)} records, {len(prompt)} chars")
            continue
        try:
            response = run_codex(prompt, model=model, effort=effort)
            got = response.get("results", [])
            expected = {(r["claim_id"], r["target_id"]) for r in batch}
            seen = set()
            for row in got:
                key = (row.get("claim_id"), row.get("target_id"))
                if key in expected and key not in seen:
                    outputs.append(row)
                    seen.add(key)
            for key in sorted(expected - seen):
                failures.append({"stage": stage, "claim_id": key[0], "target_id": key[1],
                                 "reason": "missing_or_duplicate_model_output"})
            print(f"[{stage}] batch {batch_no}: accepted {len(seen)}/{len(batch)}")
        except Exception as exc:  # fallback is intentional and recorded
            print(f"[{stage}] batch {batch_no}: ERROR {exc}")
            failures.extend({
                "stage": stage, "claim_id": r["claim_id"], "target_id": r["target_id"],
                "reason": f"call_error:{type(exc).__name__}",
            } for r in batch)
    return outputs, failures


def make_unit_items(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    items = []
    for rec in records:
        cid = rec["claim_id"]
        for var in rec["variables"]:
            if var["id"] == "y:claim":
                continue
            items.append({
                "claim_id": cid, "claim": rec["claim_text"], "target_id": var["id"],
                "target_kind": "local_variable", "parser_kind": var["semantic_type"],
                "span_text": var["unit_text"], "ud_relation": var["source_deprel"],
                "host_id": "", "host_text": "",
            })
        for factor in rec["factors"]:
            if factor["id"].startswith("p:"):
                items.append({
                    "claim_id": cid, "claim": rec["claim_text"], "target_id": factor["id"],
                    "target_kind": "local_property", "parser_kind": factor["semantic_relation"],
                    "span_text": factor["predicate_text"], "ud_relation": factor["source_deprel"],
                    "host_id": factor["argument_ids"][0],
                    "host_text": factor["argument_texts"][0],
                })
    return items


def make_edge_items(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    items = []
    for rec in records:
        for factor in rec["factors"]:
            if factor["factor_scope"] != "edge" or not factor.get("needs_review"):
                continue
            items.append({
                "claim_id": rec["claim_id"], "claim": rec["claim_text"],
                "target_id": factor["id"],
                "parent": {"id": factor["source_node_ids"][0],
                           "text": factor["argument_texts"][0]},
                "child": {"id": factor["source_node_ids"][1],
                          "text": factor["argument_texts"][1]},
                "ud_relation": factor["source_deprel"], "marker": factor["marker"],
                "prior_srl_role": factor.get("prior_srl_role", ""),
                "fallback_relation": factor["semantic_relation"],
            })
    return items


def valid_normalization(rows: list[dict[str, Any]], unit_targets: set[tuple[str, str]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    units, edges = [], []
    relation_labels = set(SEMANTIC_RELATION_LABELS) | {"composition", "negation"}
    for row in rows:
        key = (row.get("claim_id"), row.get("target_id"))
        role = row.get("evidence_role")
        if key in unit_targets:
            if role not in {"unary_probe", "observed_factor", "contract", "abstain"}:
                continue
            out = {"claim_id": key[0], "target_id": key[1], "evidence_role": role,
                   "reason": row.get("reason", "")}
            if row.get("semantic_relation") in relation_labels:
                out["semantic_relation"] = row["semantic_relation"]
            units.append(out)
        else:
            target = row.get("target_id", "")
            parts = target.split(":", 2)
            if len(parts) != 3 or parts[0] != "e":
                continue
            if row.get("semantic_relation") not in relation_labels or role not in SEMANTIC_EVIDENCE_ROLES:
                continue
            edges.append({
                "claim_id": key[0], "parent_id": parts[1], "child_id": parts[2],
                "target_id": target, "semantic_relation": row["semantic_relation"],
                "evidence_role": role, "reason": row.get("reason", ""),
            })
    return units, edges


def make_question_items(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    items = []
    for rec in records:
        for target in rec["variables"] + rec["factors"]:
            role = target["evidence_role"]
            if role not in {"unary_probe", "observed_factor"}:
                continue
            is_var = "semantic_type" in target
            items.append({
                "claim_id": rec["claim_id"], "claim_reference_only": rec["claim_text"],
                "target_id": target["id"], "target_kind": role,
                "semantic_type": target.get("semantic_type", target.get("semantic_relation", "")),
                "target_text": target.get("display_text") or target["unit_text"],
                "allowed_endpoints": ([{"id": target["id"], "text": target["unit_text"]}]
                                      if is_var else [
                                          {"id": i, "text": t}
                                          for i, t in zip(target["argument_ids"], target["argument_texts"])
                                          if i != "y:claim"
                                      ]),
            })
    return items


def valid_questions(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    bad_terms = {"node", "factor", "whole claim", "given that"}
    out = []
    for row in rows:
        display = row.get("display_text", "").strip()
        vq, aq = row.get("visual_question", "").strip(), row.get("audio_question", "").strip()
        joined = f"{display} {vq} {aq}".lower()
        if not display or not vq.endswith("?") or not aq.endswith("?") or any(t in joined for t in bad_terms):
            continue
        out.append({
            "claim_id": row.get("claim_id"), "target_id": row.get("target_id"),
            "display_text": display,
            "visual_question": vq, "audio_question": aq,
            "source": f"codex:{SEMANTIC_QUESTION_PROMPT_VERSION}",
        })
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--claims-tsv", type=Path, default=DEFAULT_CLAIMS)
    ap.add_argument("--run-dir", type=Path, default=DEFAULT_RUN_DIR)
    ap.add_argument("--model", default="gpt-5.6-sol")
    ap.add_argument("--effort", choices=["low", "medium", "high", "xhigh"], default="low")
    ap.add_argument("--batch-size", type=int, default=24)
    ap.add_argument("--limit", type=int)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    wanted = claim_ids_from_tsv(args.claims_tsv)
    if args.limit:
        wanted = wanted[:args.limit]
    wanted_set = set(wanted)
    trees = [r for r in read_jsonl(DEFAULT_TREES) if r["claim_id"] in wanted_set]
    trees.sort(key=lambda r: wanted.index(r["claim_id"]))
    hg = {r["claim_id"]: r for r in read_jsonl(DEFAULT_HYPERGRAPH)}
    roles = index_by(read_jsonl(DEFAULT_PN_ROLES), "claim_id", "node_id")
    fallback = [compile_tree(t, hg.get(t["claim_id"]), roles) for t in trees]

    unit_items = make_unit_items(fallback)
    edge_items = make_edge_items(fallback)
    print(f"claims={len(trees)} unit_targets={len(unit_items)} ambiguous_edges={len(edge_items)}")
    unit_rows, failures_u = call_batches(
        stage="unit", system=SEMANTIC_UNIT_SYSTEMS[SEMANTIC_UNIT_PROMPT_VERSION],
        items=unit_items, batch_size=args.batch_size, model=args.model,
        effort=args.effort, dry_run=args.dry_run,
    )
    edge_rows, failures_e = call_batches(
        stage="edge", system=SEMANTIC_NORMALIZE_SYSTEMS[SEMANTIC_NORMALIZE_PROMPT_VERSION],
        items=edge_items, batch_size=args.batch_size, model=args.model,
        effort=args.effort, dry_run=args.dry_run,
    )
    if args.dry_run:
        return

    normalization, relation_decisions = valid_normalization(
        unit_rows + edge_rows,
        {(r["claim_id"], r["target_id"]) for r in unit_items},
    )
    normalized = [
        compile_tree(
            t, hg.get(t["claim_id"]), roles,
            {(r["claim_id"], r["target_id"]): r for r in normalization},
            {(r["claim_id"], r["parent_id"], r["child_id"]): r for r in relation_decisions},
        )
        for t in trees
    ]
    question_items = make_question_items(normalized)
    question_rows, failures_q = call_batches(
        stage="question", system=SEMANTIC_QUESTION_SYSTEMS[SEMANTIC_QUESTION_PROMPT_VERSION],
        items=question_items, batch_size=args.batch_size, model=args.model,
        effort=args.effort, dry_run=False,
    )
    questions = valid_questions(question_rows)
    final = [
        compile_tree(
            t, hg.get(t["claim_id"]), roles,
            {(r["claim_id"], r["target_id"]): r for r in normalization},
            {(r["claim_id"], r["parent_id"], r["child_id"]): r for r in relation_decisions},
            {(r["claim_id"], r["target_id"]): r for r in questions},
        )
        for t in trees
    ]

    args.run_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.run_dir / "normalization_decisions.jsonl", normalization)
    write_jsonl(args.run_dir / "relation_decisions.jsonl", relation_decisions)
    write_jsonl(args.run_dir / "questions.jsonl", questions)
    write_jsonl(args.run_dir / "semantic_factor_trees.jsonl", final)
    failures = failures_u + failures_e + failures_q
    write_jsonl(args.run_dir / "failures.jsonl", failures)
    manifest = {
        "schema_version": "semantic-text-pass-v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "backend": "codex-cli", "model": args.model, "reasoning_effort": args.effort,
        "unit_prompt_version": SEMANTIC_UNIT_PROMPT_VERSION,
        "edge_prompt_version": SEMANTIC_NORMALIZE_PROMPT_VERSION,
        "question_prompt_version": SEMANTIC_QUESTION_PROMPT_VERSION,
        "claim_count": len(final), "unit_target_count": len(unit_items),
        "ambiguous_edge_count": len(edge_items), "question_target_count": len(question_items),
        "accepted_unit_decisions": len(normalization),
        "accepted_edge_decisions": len(relation_decisions),
        "accepted_questions": len(questions), "fallback_count": len(failures),
        "claims_sha256": hashlib.sha256("\n".join(wanted).encode()).hexdigest(),
        "note": "Codex pilot fallback; production Qwen pass deferred only if scheduler unavailable.",
    }
    (args.run_dir / "run_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
