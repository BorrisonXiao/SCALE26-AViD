"""Fixed-condition experiments on authored probes and cached real claims."""
import argparse,copy,hashlib,json,time
from collections import Counter
from pathlib import Path
from probabilistic_verification.semantic_components import compile_one
from probabilistic_verification.compiler_extensions import compile_one as previous,OPTIONS
from probabilistic_verification.split_alignment import compose_aligned
from probabilistic_verification.split_composition import nodes
from probabilistic_verification.compilation_followup import walk_events
from compile_claim_splits import serialize

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/semantic_components_20261112'
OLD=ROOT/'exp/probabilistic_verification/rewrite_all_20261112'
CONDITIONS={'previous':None,'values':dict(relations=False,audit=False),'relations':dict(audit=False),'checked':{}}
def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
def compile_condition(r,condition):return previous(r)if condition=='previous'else compile_one(r,**CONDITIONS[condition])
def form(r):return r.get('compilation',{}).get('metadata',{}).get('logical_form',r.get('proposed_form',{}))

def literals(value):
    found=[]
    if isinstance(value,dict):
        if value.get('kind')in{'time','date','duration','measurement'}:found.append(value)
        for k,v in value.items():
            if k=='value'and isinstance(v,str)and v.startswith('{'):
                try:found+=literals(json.loads(v))
                except ValueError:pass
            else:found+=literals(v)
    elif isinstance(value,list):
        for v in value:found+=literals(v)
    return found

def probe_check(row,expected):
    f=form(row);ns=list(nodes(f.get('formula',{})));events=list(walk_events(f));vals=literals(f);results={}
    if 'refuse'in expected:return dict(expected_refusal=row['status']!='compiled'and row.get('code')==expected['refuse'])
    if 'temporal'in expected:results['temporal']=all(any(v['kind']in{'time','date'}and v['value']==x for v in vals)for x in expected['temporal'])
    if 'operator'in expected:results['operator']=any(v.get('operator')==expected['operator']for v in vals)
    if 'relation'in expected:results['relation']=any(expected['relation']in e.get('arguments',{})for e in events)
    if 'not_relation'in expected:results['not_relation']=all(expected['not_relation']not in e.get('arguments',{})for e in events)
    if expected.get('no_year_date'):results['no_year_date']=not any(v['kind']=='date'and v['value']=='2025'for v in vals)
    if 'duration'in expected:results['duration']=any(v['kind']=='duration'and v['value']==expected['duration']for v in vals)
    if 'quantity'in expected:results['quantity']=any(v['kind']=='measurement'and v['value']==expected['quantity']and v['unit']==expected['unit']and ('upper'not in expected or v.get('upper')==expected['upper'])for v in vals)
    if 'event'in expected:results['event']=any(e['predicate']==expected['event']for e in events)
    if 'source'in expected:results['source']=any(e.get('route')==expected['source']and expected['relation']in e.get('arguments',{})for e in row.get('compilation',{}).get('metadata',{}).get('events',{}).values())
    if expected.get('negative'):results['negative']=any(n.get('op')=='not'for n in ns)
    if expected.get('qualified'):results['qualified']=any(n.get('op')=='qualified'for n in ns)
    if expected.get('temporal_scope'):results['temporal_scope']=any(p.get('kind')=='temporal'for e in events for p in e.get('propositions',[]))
    if 'subject'in expected:
        entities={e['id']:e['text'].lower()for e in f.get('entities',[])}
        results['binding']=any(entities.get(e.get('arguments',{}).get('reference'))==expected['reference']and any(entities.get(v)==expected['subject']for k,v in e.get('arguments',{}).items()if k!='reference'and isinstance(v,str))for e in events)
    return results

def probes():
    inputs={r['claim_id']:r for r in read(RUN/'probe_parsed.jsonl')};spec=json.loads((RUN/'probes.json').read_text());out=[]
    for c in CONDITIONS:
        for item in spec:
            record=inputs[item['claim_id']];row=compile_condition(record,c)if 'tokens'in record else dict(status='unsupported',code='sentence_parse',reason=record['parse_error'])
            checks=probe_check(row,item['expected'])
            out.append(dict(condition=c,claim_id=item['claim_id'],text=item['text'],expected=item['expected'],checks=checks,target_ok=bool(checks)and all(checks.values()),compiled=row['status']=='compiled',output=row))
    write(RUN/'probe_results.jsonl',out)
    print({c:dict(compiled=sum(r['compiled']for r in out if r['condition']==c),target_ok=sum(r['target_ok']for r in out if r['condition']==c))for c in CONDITIONS})

def corpus():
    records=read(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl');out=[];start=time.perf_counter()
    for i,r in enumerate(records):
        out.append(compile_one(r))
        if (i+1)%500==0:print('Originals',i+1,flush=True)
    write(RUN/'direct_all.jsonl',out)
    summary=dict(total=len(out),compiled=sum(r['status']=='compiled'for r in out),candidates=sum('program'in r for r in out),codes=dict(Counter(r.get('code')for r in out if r['status']!='compiled')),elapsed_seconds=time.perf_counter()-start)
    (RUN/'direct_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary)

def replay():
    originals={r['claim_id']:r for r in read(OLD/'inputs.jsonl')};parsed={r['claim_id']:r for r in read(OLD/'parsed.jsonl')};old={r['claim_id']:r for r in read(OLD/'pipeline.jsonl')}
    for condition in CONDITIONS:
        if condition=='previous':continue
        out=[];start=time.perf_counter()
        for cid,record in originals.items():
            direct=compile_condition(record,condition);row=dict(claim_id=cid,original=record['text'],direct=direct,components=[],proposal=None)
            if direct['status']=='compiled':row.update(stage='direct_pass',output=direct)
            elif cid not in parsed:row.update(stage='uncached_fallback',output=dict(status='unsupported',code='uncached_fallback',reason='New direct refusal; no cached rewrite exists because the prior direct compiler passed. No model called.'))
            else:
                source=parsed[cid];row['proposal']=source['proposal']
                if source['proposal']['action']in{'keep','refuse'}:
                    row.update(stage='model_'+source['proposal']['action'],output=dict(status='unsupported',code='model_'+source['proposal']['action'],reason='Saved model proposed no sentences.'))
                else:
                    for clause in source['clauses']:
                        part=copy.deepcopy(clause.get('record'))
                        if part and len(source['clauses'])==1:part['claim_id']=cid
                        result=compile_condition(part,condition)if part else dict(status='unsupported',code='sentence_parse',reason=clause['parse_error'])
                        row['components'].append(dict(id=clause['id'],text=clause['text'],result=result))
                    failed=[c for c in row['components']if c['result']['status']!='compiled']
                    if failed:row.update(stage='component_compilation',output=dict(status='unsupported',code=failed[0]['result'].get('code'),reason=failed[0]['id']+': '+failed[0]['result']['reason']))
                    elif len(row['components'])==1:row.update(stage='compiled_single',output=row['components'][0]['result'])
                    else:
                        try:
                            original=copy.deepcopy(record);original['compiler_options']=dict(OPTIONS)
                            claim,proposal,trace=compose_aligned(cid,original,source['clauses'],{c['id']:c['result']for c in row['components']},max_clauses=12)
                            row.update(stage='compiled_composed',proposal=proposal,alignment=trace,output=serialize(claim))
                        except Exception as error:
                            code=getattr(error,'code',type(error).__name__)
                            row.update(stage='alignment'if code in{'entity_alignment','mention_alignment','event_alignment','event_time_alignment','description_alignment','source_alignment'}else'composition',output=dict(status='unsupported',code=code,reason=str(error)))
            out.append(row)
        write(RUN/('pipeline_'+condition+'.jsonl'),out)
        print(condition,dict(Counter(r['stage']for r in out)),'seconds',round(time.perf_counter()-start,2),flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['probes','corpus','replay']);a=p.parse_args()
    {'probes':probes,'corpus':corpus,'replay':replay}[a.action]()

if __name__=='__main__':main()
