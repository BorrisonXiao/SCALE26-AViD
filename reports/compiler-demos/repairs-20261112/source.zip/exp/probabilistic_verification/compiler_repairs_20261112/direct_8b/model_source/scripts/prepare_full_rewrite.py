"""Run improved direct compilation on exactly the previous449 rejected claims."""
import hashlib,json,time
from collections import Counter
from pathlib import Path
from probabilistic_verification.compiler_extensions import compile_one

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/rewrite_all_20261112'


def main():
    rows=list(map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines()));started=time.perf_counter()
    out=[compile_one(r)for r in rows]
    (RUN/'direct.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in out))
    summary=dict(cohort=len(out),direct_passes=sum(r['status']=='compiled'for r in out),
        candidates=sum('program'in r for r in out),failures=dict(Counter(r['code']for r in out if r['status']!='compiled')),seconds=time.perf_counter()-started)
    (RUN/'direct_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    files=['scripts/probabilistic_verification/'+n+'.py'for n in ['content_relations','srl_graph','logical_form_v2','source_checks_v2','semantic_srl','compiler_extensions','typed_literals','split_alignment']]
    (RUN/'compiler_freeze.json').write_text(json.dumps(dict(source_sha256={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest()for n in files}),indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
