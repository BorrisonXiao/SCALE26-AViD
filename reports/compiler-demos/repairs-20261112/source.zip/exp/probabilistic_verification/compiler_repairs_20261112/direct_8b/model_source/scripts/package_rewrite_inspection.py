"""Small dated source overlay; previous experiment bundles remain immutable."""
import argparse,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/rewrite_inspection_20261112'
def main():
    p=argparse.ArgumentParser();p.add_argument('--allow-missing-history',action='store_true');a=p.parse_args()
    names=['scripts/probabilistic_verification/claim_rewrite.py','scripts/run_claim_rewrite_model.py',
        'scripts/claim_rewrite_report.py','scripts/claim_rewrite_inspection.py','scripts/report_assets/claim_rewrite.js',
        'scripts/report_assets/compiler_demos_template.html','scripts/package_rewrite_inspection.py',
        'scripts/check_rewrite_inspection_browser.py','tests/test_claim_rewrite.py',
        'docs/rewrite_inspection_20261112.md','docs/project_notes/daily_log.json','site/reports/index.html',
        'exp/probabilistic_verification/av_features_20261022/checklist.json']
    data={n:(ROOT/n).read_bytes()for n in names}
    excluded={'publication.json','browser_checks.json','archive_verification.json','WORK_STATUS.md'}
    data.update({str(p.relative_to(ROOT)):p.read_bytes()for p in RUN.glob('*')if p.is_file() and p.suffix in {'.json','.jsonl','.xml'}and p.name not in excluded})
    data['README_REWRITE_INSPECTION.md']=(ROOT/'docs/rewrite_inspection_20261112.md').read_bytes()
    data['REWRITE_INSPECTION_SHA256SUMS']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n'for k,v in sorted(data.items())).encode()
    target=ROOT/'site/reports/compiler-demos/rewrite-inspection-20261112/source.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED)as z:
        for name,body in sorted(data.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,body)
    missing=[]
    for name,digest in json.loads((RUN/'preserved_archives.json').read_text()).items():
        if (ROOT/name).exists():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
        else:missing.append(name)
    assert a.allow_missing_history or not missing,missing
    for name,digest in json.loads((RUN/'frozen_artifacts.json').read_text()).items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    compiler=ROOT/'exp/probabilistic_verification/content_relations_20261105/frozen_manifest.json'
    for name,digest in json.loads(compiler.read_text())['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    viewer=ROOT/'exp/probabilistic_verification/claim_rewrite_20261111/viewer_sha256.json'
    for name,digest in json.loads(viewer.read_text()).items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    print('Packaged',len(data),'files;',round(target.stat().st_size/1048576,2),'MiB. Earlier artifacts unchanged; missing historical archives:',len(missing))
if __name__=='__main__':main()
