#!/usr/bin/env python3
"""Compile the normalized UD tree into a conjunct-local semantic factor tree.

The compiler preserves the normalized Universal Dependencies (UD) backbone but
changes what is observed:

* retained entity/event/state nodes receive independent unary probes;
* attributes and cardinalities become node-local observed factors;
* every retained parent-child edge becomes one observed or fixed relation factor;
* the claim verdict is the recursively composed truth at the semantic root;
* no whole-subtree text is emitted as a probe target.

The output is a tree, not the span-containment annotation tree in gold_v2.  A
relation factor scopes over the immediate semantic endpoints; the endpoints'
subtree evidence reaches it through belief-propagation messages.

This module is deliberately deterministic given optional, versioned text-model
decisions.  Missing model decisions fall back to parser/SRL rules and are marked
``needs_review`` so a pilot can be generated before a full GPU pass completes.
"""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Iterable


ROOT = Path("/exp/cxiao/scale26/avid")
DEFAULT_TREES = ROOT / "exp/phase3/trees/trees_ud_star.jsonl"
DEFAULT_HYPERGRAPH = ROOT / "exp/phase1/hypergraph.jsonl"
DEFAULT_PN_ROLES = ROOT / "exp/phase3/trees/pn_roles.jsonl"
DEFAULT_OUTPUT = ROOT / "exp/phase3/semantic_v1/semantic_factor_trees.jsonl"

VARIABLE_KINDS = {"entity", "event", "state"}
PROPERTY_TYPES = {"attribute", "cardinality"}
SEMANTIC_RELATION_LABELS = {
    "agent", "theme", "recipient", "attribute", "cardinality", "location",
    "direction", "instrument", "manner", "temporal", "cause", "purpose",
    "shared_participant", "coordination_and", "coordination_or", "coreference",
    "possessive", "complement", "composition", "negation", "inert", "other",
}
PROBED_ROLES = {"unary_probe", "observed_factor"}
EVIDENCE_ROLES = PROBED_ROLES | {"fixed_factor", "abstain", "contract", "latent_output"}

# Directional particles that carry a light/motion verb's meaning ("get out", "fall off").
# Only the particle is folded into the event surface; the argument stays its own node.
DIR_PARTICLES = {"out", "up", "down", "off", "away", "back", "apart", "aside"}
# Body-part / means nouns that are vacuous on their own inside a manner PP
# ("by hand", "in part"). Gated by the SRL manner role so ordinary uses are untouched.
MANNER_NOUNS = {"hand", "hands", "foot", "feet", "part"}
# Single-word abstract/relational nouns with no independent audio-visual referent
# ("Is a position visible?" is vacuous). Multiword / proper phrases are left alone so
# concrete compounds ("entry way", "Narco state") are not wrongly dropped.
ABSTRACT_NOUNS = {"position", "situation", "situations", "condition", "conditions",
                  "circumstance", "circumstances", "way", "ways", "manner", "role", "roles",
                  "matter", "matters", "extent", "degree", "aspect", "aspects", "respect",
                  "regard", "sense", "tendency", "phase", "status"}

AMBIGUOUS_DEPRELS = {
    "acl", "acl:relcl", "advcl", "obl", "nmod", "parataxis", "xcomp", "ccomp"
}

_PREP_LOCATION = {
    "at", "in", "inside", "on", "near", "beside", "by", "under", "above",
    "behind", "between", "around", "within", "outside", "over",
}
_PREP_DIRECTION = {
    "to", "toward", "towards", "into", "onto", "from", "through", "across",
    "out", "off", "up", "down",
}
_PRONOUNS = {
    "it", "this", "that", "these", "those", "something", "someone", "anything",
    "anyone", "everything", "everyone",
}


def read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return []
    rows = []
    with p.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def write_jsonl(path: str | Path, rows: Iterable[dict[str, Any]]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def index_by(rows: Iterable[dict[str, Any]], *keys: str) -> dict[tuple[Any, ...], dict[str, Any]]:
    return {tuple(row.get(k) for k in keys): row for row in rows}


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip(" \t\r\n.,;:!?\"'“”‘’"))


def _article(text: str) -> str:
    text = _clean(text)
    if not text:
        return "the item"
    low = text.lower()
    if low.startswith(("a ", "an ", "the ", "this ", "that ", "these ", "those ")):
        return text
    if text[:1].isupper() or any(ch.isdigit() for ch in text):
        return text
    if low in {"people", "men", "women", "children", "police", "cattle"} or low.endswith("s"):
        return text
    return ("an " if low[0] in "aeiou" else "a ") + text


def _the(text: str) -> str:
    text = _clean(text)
    low = text.lower()
    if not text or low.startswith(("a ", "an ", "the ", "this ", "that ", "these ", "those ")):
        return text or "the item"
    if text[:1].isupper():
        return text
    return f"the {text}"


def semantic_kind(node: dict[str, Any]) -> str | None:
    """Return the retained local-truth kind, or None for a contracted property."""
    nt = node.get("node_type", "")
    dep = node.get("deprel", "")
    text = _clean(node.get("node_text", ""))
    if node.get("is_functional"):
        return None
    if nt == "event":
        return "event"
    # English parsers frequently tag gerundive reduced clauses as NOUN, e.g.
    # "crowd standing".  Restrict the correction to clause-bearing relations.
    if nt == "entity" and dep in {"acl", "acl:relcl", "advcl", "xcomp", "ccomp"}:
        if text.lower().endswith(("ing", "ed")):
            return "event"
    if nt == "entity":
        return "entity"
    # Adjectival roots such as "Smoke visible" denote a checkable state and need
    # their own local truth rather than disappearing into an attribute fragment.
    if nt == "attribute" and node.get("parent_id") is None:
        return "state"
    return None


def marker_map(hypergraph: dict[str, Any]) -> dict[str, str]:
    """Map content-node id to its local case/mark/coord operator text."""
    parse = hypergraph.get("parse", [])
    nodes = {n["id"]: n for n in hypergraph.get("nodes", [])}
    out: dict[str, str] = {}
    for nid, node in nodes.items():
        toks = set(node.get("token_indices", []))
        markers = [
            (tok.get("i", -1), tok.get("text", ""))
            for tok in parse
            if tok.get("head") in toks and tok.get("deprel", "").split(":")[0]
            in {"case", "mark", "cc"}
        ]
        if markers:
            out[nid] = " ".join(t for _, t in sorted(markers))
    return out


_HYPHENATED_LEXEME = re.compile(
    r"(?<![\w])(?:[A-Za-z0-9]+)(?:-(?:(?:and|or)-)?[A-Za-z0-9]+)+(?![\w])"
)


def normalize_hyphenated_lexemes(
    source_nodes: dict[str, dict[str, Any]],
    hypergraph: dict[str, Any],
    claim_text: str,
) -> tuple[dict[str, dict[str, Any]], dict[str, str], list[dict[str, Any]]]:
    """Collapse parser-split hyphenated lexemes before semantic normalization.

    Tokenizers often split ``close-up`` into ``close`` and ``up`` and split
    ``before-and-after`` even more aggressively.  These are lexical units, not
    separate truth conditions.  The repair is surface-driven and claim-agnostic:
    every literal hyphen chain is collapsed onto one parser node.  A pre-verbal
    adjectival chain is attached to the nearest following entity in the same
    nominal region (e.g. both modifiers attach to ``comparison``).
    """
    repaired = {nid: dict(node) for nid, node in source_nodes.items()}
    hg_nodes = {n["id"]: n for n in hypergraph.get("nodes", [])}
    root = next((n for n in repaired.values() if n.get("parent_id") is None), {})
    root_start = root.get("span", [len(claim_text), len(claim_text)])[0]
    marker_overrides: dict[str, str] = {}
    audit: list[dict[str, Any]] = []

    for match in _HYPHENATED_LEXEME.finditer(claim_text):
        start, end = match.span()
        overlapping = [
            nid for nid, node in repaired.items()
            if node.get("span", [-1, -1])[0] < end
            and node.get("span", [-1, -1])[1] > start
        ]
        content = [nid for nid in overlapping if not repaired[nid].get("is_functional")]
        if not content:
            continue
        # Prefer the syntactic head when it lies inside the compound; otherwise
        # the rightmost content fragment is the least surprising representative.
        content_set = set(content)
        representative = next(
            (nid for nid in content if repaired[nid].get("parent_id") not in content_set),
            max(content, key=lambda nid: repaired[nid].get("span", [0])[0]),
        )
        if len(content) > 1:
            representative = max(content, key=lambda nid: repaired[nid].get("span", [0])[0])
        rep = repaired[representative]
        rep["node_text"] = match.group(0)
        rep["span"] = [start, end]
        rep["lexical_normalization"] = "hyphenated_lexeme"
        contracted = []
        for nid in content:
            if nid == representative:
                continue
            repaired[nid]["is_functional"] = True
            repaired[nid]["lexical_contract"] = representative
            contracted.append(nid)

        host = ""
        if rep.get("node_type") in PROPERTY_TYPES and end <= root_start:
            candidates = [
                (node.get("span", [0])[0], nid)
                for nid, node in repaired.items()
                if nid not in content_set
                and not node.get("is_functional")
                and node.get("node_type") == "entity"
                and end <= node.get("span", [0, 0])[0] < root_start
            ]
            if candidates:
                _, host = min(candidates)
                rep["parent_id"] = host
                # A case/coord token inside the compound is lexical material,
                # not a marker on the following noun (``after comparison``).
                if any(repaired[n].get("is_functional") for n in overlapping):
                    marker_overrides[host] = ""
        audit.append({
            "surface": match.group(0), "span": [start, end],
            "representative_id": representative, "contracted_ids": contracted,
            "host_override": host,
        })
    return repaired, marker_overrides, audit


def rescue_preposed_subject(
    source_nodes: dict[str, dict[str, Any]], markers: dict[str, str], root_id: str | None,
) -> list[dict[str, str]]:
    """Repair a narrow class of pre-verbal nominal subjects misparsed as obliques."""
    if not root_id or root_id not in source_nodes or source_nodes[root_id].get("node_type") != "event":
        return []
    if any(
        n.get("parent_id") == root_id and n.get("deprel") in {"nsubj", "csubj"}
        for n in source_nodes.values()
    ):
        return []
    root_start = source_nodes[root_id].get("span", [0])[0]
    candidates = [
        n for n in source_nodes.values()
        if n.get("parent_id") == root_id
        and n.get("node_type") == "entity"
        and n.get("deprel", "").split(":", 1)[0] in {"obl", "nmod"}
        and n.get("span", [0, 0])[1] <= root_start
        and not markers.get(n["node_id"], "")
    ]
    if not candidates:
        return []
    node = max(candidates, key=lambda n: n.get("span", [0, 0])[1])
    old = node.get("deprel", "")
    node["deprel"] = "nsubj"
    return [{"node_id": node["node_id"], "from": old, "to": "nsubj"}]


def local_role(
    claim_id: str,
    node: dict[str, Any],
    decisions: dict[tuple[str, str], dict[str, Any]],
) -> tuple[str, str]:
    target_id = f"u:{node['node_id']}"
    decision = decisions.get((claim_id, target_id), {})
    if decision.get("evidence_role") in {"unary_probe", "abstain", "contract"}:
        return decision["evidence_role"], decision.get("reason", "text-model normalization")
    text = _clean(node.get("node_text", "")).lower()
    dep = node.get("deprel", "")
    if dep == "expl":
        return "contract", "expletive has no local truth"
    if text in _PRONOUNS and node.get("node_type") == "entity":
        return "abstain", "underspecified referent"
    return "unary_probe", ""


def _srl_relation(srl_role: str) -> str | None:
    return {
        "MNR": "manner", "INS": "instrument", "PRP": "purpose",
        "TMP": "temporal", "LOC": "location", "DIR": "direction",
        "CAU": "cause", "CORE": "other",
    }.get(srl_role)


def default_relation(
    *, deprel: str, marker: str, srl_role: str,
    parent_kind: str, child_kind: str,
) -> tuple[str, str, bool]:
    """Return (semantic relation, evidence role, needs text-model review)."""
    dep = deprel.lower()
    base = dep.split(":", 1)[0]
    mk = marker.lower().strip()
    if dep in {"nsubj", "csubj", "obl:agent"}:
        return "agent", "observed_factor", False
    if dep in {"nsubj:pass", "csubj:pass"}:
        return "theme", "observed_factor", False
    if base == "obj":
        return "theme", "observed_factor", False
    if base == "iobj":
        return "recipient", "observed_factor", False
    if base == "conj":
        return ("coordination_or" if mk in {"or", "nor"} else "coordination_and",
                "fixed_factor", False)
    if base == "appos":
        return "coreference", "fixed_factor", False
    if dep == "nmod:poss":
        return "possessive", "observed_factor", False
    if dep in {"acl", "acl:relcl"} and parent_kind == "entity" and child_kind == "event":
        return "agent", "observed_factor", True
    if base == "advcl":
        prior = _srl_relation(srl_role)
        if prior in {"temporal", "cause", "purpose"}:
            return prior, "observed_factor", True
        if parent_kind in {"event", "state"} and child_kind in {"event", "state"}:
            return "shared_participant", "observed_factor", True
        return prior or "other", "observed_factor", True
    if base in {"xcomp", "ccomp"}:
        return ("purpose" if mk == "to" else "complement"), "observed_factor", True
    if base in {"obl", "nmod"}:
        prior = _srl_relation(srl_role)
        if prior and prior != "other":
            return prior, "observed_factor", True
        if mk in _PREP_DIRECTION:
            return "direction", "observed_factor", True
        if mk in _PREP_LOCATION:
            # Passive "by" is handled by obl:agent above; remaining "by" is spatial.
            return "location", "observed_factor", True
        if mk in {"with", "using", "via"}:
            return "instrument", "observed_factor", True
        if mk in {"because", "because of", "due to"}:
            return "cause", "observed_factor", True
        return "other", "observed_factor", True
    if base == "parataxis":
        return "other", "observed_factor", True
    if base in {"vocative", "discourse", "dep"}:
        return "inert", "abstain", True
    return "other", "observed_factor", True


def _gerund(text: str) -> str:
    word = _clean(text).lower()
    if not word:
        return "happening"
    if word == "be":
        return "being"
    if word == "have":
        return "having"
    if word == "lie":
        return "lying"
    if word.endswith("ing"):
        return word
    if word.endswith("ie"):
        return word[:-2] + "ying"
    if word in {"get", "run", "sit", "cut", "put", "stop", "drop", "swim", "hit"}:
        return word + word[-1] + "ing"
    if word.endswith("e") and not word.endswith(("ee", "ye")):
        return word[:-1] + "ing"
    return word + "ing"


def _past_participle(text: str) -> str:
    """Small deterministic fallback; the LLM copy-edit pass can refine it."""
    word = _clean(text).lower()
    if not word:
        return "acted on"
    irregular = {
        "be": "shown", "build": "built", "buy": "bought", "catch": "caught",
        "choose": "chosen", "cut": "cut", "do": "done", "draw": "drawn",
        "drive": "driven", "eat": "eaten", "find": "found", "get": "gotten",
        "give": "given", "go": "gone", "have": "had", "hear": "heard",
        "hit": "hit", "hold": "held", "lead": "led", "leave": "left",
        "make": "made", "put": "put", "read": "read", "run": "run",
        "say": "said", "see": "seen", "show": "shown", "speak": "spoken",
        "stand": "stood", "take": "taken", "tell": "told", "write": "written",
    }
    if word in irregular:
        return irregular[word]
    if word.endswith("e"):
        return word + "d"
    if word.endswith("y") and len(word) > 1 and word[-2] not in "aeiou":
        return word[:-1] + "ied"
    if word.endswith(("ed", "en")):
        return word
    return word + "ed"


def _node_questions(text: str, kind: str, lemma: str = "", particle: str = "") -> tuple[str, str]:
    label = _article(text)
    if kind == "entity":
        return (
            f"Is {label} visible in the video, or named in on-screen text (a caption, sign, or title)?",
            f"Can {label} be identified from speech or sound in the audio?",
        )
    if kind == "event":
        action = _gerund(lemma or text)
        stated = text  # surface form carries the claim's tense (e.g. "landed"), unlike the gerund
        if particle:  # fold only the particle ("getting" -> "getting out"), never the argument
            action = f"{action} {particle}"
            stated = f"{stated} {particle}"
        return (
            f"Does the video show the action of {action}, or does on-screen text state that it {stated}?",
            f"Can the action of {action} be heard or explicitly mentioned in the audio?",
        )
    return (
        f"Is the state '{_clean(text)}' visibly evident, or stated in on-screen text?",
        f"Is the state '{_clean(text)}' evident in sound or explicitly described in speech?",
    )


def _factor_questions(
    relation: str,
    parent_text: str,
    child_text: str,
    marker: str = "",
    parent_kind: str = "",
    child_kind: str = "",
    parent_lemma: str = "",
    child_lemma: str = "",
    parent_particle: str = "",
) -> tuple[str, str]:
    p, c = _clean(parent_text), _clean(child_text)
    def _pg(base: str) -> str:
        g = _gerund(base)
        if parent_particle and parent_particle != marker:  # skip the particle-source edge
            g = f"{g} {parent_particle}"
        return g
    def _ps(base: str) -> str:  # surface (finite) form + particle — tense-faithful, for the on-screen-text route
        s = _clean(base)
        if parent_particle and parent_particle != marker:
            s = f"{s} {parent_particle}"
        return s
    if relation == "attribute":
        phrase = f"{c} {p}".strip()
        return (f"Is {_article(phrase)} visible in the video, or stated in on-screen text?",
                f"Is {_article(phrase)} mentioned or described in the audio?")
    if relation == "cardinality":
        return (f"Does the visible number or amount associated with {p} match {c}, or is that number stated in on-screen text?",
                f"Is the number or amount {c} for {p} stated in speech or sound?")
    if relation == "agent":
        event = p if parent_kind == "event" else c
        participant = c if parent_kind == "event" else p
        lemma = parent_lemma if parent_kind == "event" else child_lemma
        action = _pg(lemma or event)
        stated = _ps(event)  # surface form -> claim tense on the text route ("... landed")
        return (f"Is {_the(participant)} the one {action} in the video, or does on-screen text state that {_the(participant)} {stated}?",
                f"Does the audio identify {_the(participant)} as the one {action}?")
    if relation == "theme":
        event = p if parent_kind == "event" else c
        theme = c if parent_kind == "event" else p
        lemma = parent_lemma if parent_kind == "event" else child_lemma
        action = _past_participle(lemma or event)
        return (f"Is {_the(theme)} what is being {action} in the video, or does on-screen text state that {_the(theme)} was {action}?",
                f"Does the audio identify {_the(theme)} as what is being {action}?")
    if relation == "recipient":
        return (f"Does the clip show that {c} receives or benefits from {p}, or is that stated in on-screen text?",
                f"Does the audio establish that {c} receives or benefits from {p}?")
    if relation == "shared_participant":
        return (f"Do {p} and {c} visibly involve the same participant, or does on-screen text state so?",
                f"Does the audio establish that {p} and {c} involve the same participant?")
    if relation == "possessive":
        possessor = c + ("'" if c.lower().endswith("s") else "'s")
        phrase = f"{possessor} {p}"
        return (f"Is the {phrase} visible in the video, or stated in on-screen text?",
                f"Is the {phrase} mentioned or described in the audio?")
    if relation == "manner":
        action = _pg(parent_lemma or p) if parent_kind == "event" else p
        phrase = f"{action} {marker} {c}".replace("  ", " ").strip()
        stated_phrase = (f"{_ps(p)} {marker} {c}".replace("  ", " ").strip()
                         if parent_kind == "event" else phrase)
        subject = "someone or something " if parent_kind == "event" else ""
        return (f"Does the video show {subject}{phrase}, or does on-screen text state that {subject or 'it '}{stated_phrase}?",
                f"Can {subject}{phrase} be heard or explicitly mentioned in the audio?")
    if relation in {"location", "direction", "instrument", "temporal", "cause", "purpose"}:
        if parent_kind == "event":
            action = _pg(parent_lemma or p)
            prep = "out of" if marker.lower() == "out" else marker
            complement = _the(c) if child_kind == "entity" else c
            gloss = f"{action} {prep} {complement}".replace("  ", " ").strip()
            stated_gloss = f"{_ps(p)} {prep} {complement}".replace("  ", " ").strip()
            return (f"Does the video show someone or something {gloss}, or does on-screen text state that something {stated_gloss}?",
                    f"Can someone or something {gloss} be heard or explicitly mentioned in the audio?")
        gloss = f"{p} {marker} {c}".replace("  ", " ").strip()
        return (f"Does the video show {gloss}, or state it in on-screen text?",
                f"Is {gloss} heard or explicitly mentioned in the audio?")
    gloss = f"{p} {marker} {c}".replace("  ", " ").strip()
    return (f"Is {_article(gloss)} visible in the video, or stated in on-screen text?",
            f"Is {_article(gloss)} heard or explicitly mentioned in the audio?")


def _factor_display_text(
    relation: str, parent_text: str, child_text: str, marker: str = "",
    parent_kind: str = "", child_kind: str = "",
    parent_lemma: str = "", child_lemma: str = "", parent_particle: str = "",
) -> str:
    """Human-readable target phrase; never expose predicate-style debug syntax."""
    p, c = _clean(parent_text), _clean(child_text)
    def _pg(base: str) -> str:
        g = _gerund(base)
        if parent_particle and parent_particle != marker:
            g = f"{g} {parent_particle}"
        return g
    if relation == "attribute":
        return f"{c} {p}".strip()
    if relation == "cardinality":
        return f"{c} {p}".strip()
    if relation == "possessive":
        suffix = "'" if c.lower().endswith("s") else "'s"
        return f"{c}{suffix} {p}".strip()
    if relation == "agent":
        event = p if parent_kind == "event" else c
        participant = c if parent_kind == "event" else p
        lemma = parent_lemma if parent_kind == "event" else child_lemma
        return f"{participant} doing the {_pg(lemma or event)}"
    if relation == "theme":
        event = p if parent_kind == "event" else c
        theme = c if parent_kind == "event" else p
        lemma = parent_lemma if parent_kind == "event" else child_lemma
        return f"{theme} being {_past_participle(lemma or event)}"
    if relation == "shared_participant":
        return f"same participant: {p} and {c}"
    if parent_kind == "event" and relation in {
        "location", "direction", "instrument", "manner", "temporal", "cause", "purpose"
    }:
        prep = "out of" if marker.lower() == "out" else marker
        return f"{_pg(parent_lemma or p)} {prep} {c}".replace("  ", " ").strip()
    return f"{p} {marker} {c}".replace("  ", " ").strip()


def compile_tree(
    tree: dict[str, Any],
    hypergraph: dict[str, Any] | None = None,
    pn_roles: dict[tuple[str, str], dict[str, Any]] | None = None,
    normalization_decisions: dict[tuple[str, str], dict[str, Any]] | None = None,
    relation_decisions: dict[tuple[str, str, str], dict[str, Any]] | None = None,
    questions: dict[tuple[str, str], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    cid = tree["claim_id"]
    claim_text = tree["claim_text"]
    pn_roles = pn_roles or {}
    normalization_decisions = normalization_decisions or {}
    relation_decisions = relation_decisions or {}
    questions = questions or {}
    hypergraph = hypergraph or {}
    source_nodes = {n["node_id"]: n for n in tree.get("nodes", [])}
    for node in source_nodes.values():
        hg_node = next((h for h in hypergraph.get("nodes", []) if h.get("id") == node["node_id"]), {})
        node["lemma"] = hg_node.get("lemma", node.get("node_text", ""))
    source_nodes, marker_overrides, lexical_repairs = normalize_hyphenated_lexemes(
        source_nodes, hypergraph, claim_text,
    )
    markers = marker_map(hypergraph)
    markers.update(marker_overrides)
    subject_repairs = rescue_preposed_subject(source_nodes, markers, tree.get("root_id"))
    kinds = {nid: semantic_kind(n) for nid, n in source_nodes.items()}
    retained = {nid for nid, kind in kinds.items() if kind in VARIABLE_KINDS}

    def nearest_retained_ancestor(nid: str) -> str | None:
        seen: set[str] = set()
        pid = source_nodes[nid].get("parent_id")
        while pid is not None and pid not in seen:
            seen.add(pid)
            if pid in retained:
                return pid
            parent = source_nodes.get(pid)
            pid = parent.get("parent_id") if parent else None
        return None

    semantic_parent = {nid: nearest_retained_ancestor(nid) for nid in retained}
    roots = sorted(nid for nid, pid in semantic_parent.items() if pid is None)
    source_root_id = tree.get("root_id")
    source_root = source_nodes.get(source_root_id, {})

    # Tree depth after property/operator contraction.
    def depth(nid: str) -> int:
        d, seen, cur = 0, set(), semantic_parent.get(nid)
        while cur is not None and cur not in seen:
            seen.add(cur)
            d += 1
            cur = semantic_parent.get(cur)
        return d

    # The claim output is a latent variable, never a whole-claim probe.  A root
    # composition factor connects it to the semantic root frontier.  This also
    # preserves a tree when a contracted copular/property root has several
    # retained children.
    variables = [{
        "id": "y:claim",
        "source_node_id": "",
        "parent_variable_id": "",
        "level": 0,
        "semantic_type": "claim_output",
        "unit_text": "claim verdict",
        "span": [0, len(claim_text)],
        "evidence_role": "latent_output",
        "role_reason": "computed recursively; never directly probed",
        "visual_question": "",
        "audio_question": "",
        "question_source": "",
        "source_deprel": "",
        "source_node_type": "",
    }]
    accounted: dict[str, str] = {}
    # Per-event directional particle ("get" + "out" -> "getting out"), taken from a
    # directional child. Only the particle is folded into the event surface; the
    # argument ("the tram") stays its own node and the binding factor is untouched.
    event_particle: dict[str, str] = {}
    for _cnid, _p in semantic_parent.items():
        if _p is not None and kinds.get(_p) == "event":
            _mk = (markers.get(_cnid, "") or "").lower()
            if _mk in DIR_PARTICLES:
                event_particle.setdefault(_p, _mk)
    for nid in sorted(retained, key=lambda x: (depth(x), source_nodes[x].get("span", [0])[0], x)):
        node = source_nodes[nid]
        kind = kinds[nid]
        role, reason = local_role(cid, node, normalization_decisions)
        text = _clean(node.get("node_text", ""))
        # Fix A: a manner adjunct's object ("by hand" -> bare "hand") has no standalone
        # value; the manner factor already carries the phrase, so don't probe the bare noun.
        _htail = text.lower().split()[-1] if text.split() else ""
        if (role == "unary_probe"
                and pn_roles.get((cid, nid), {}).get("srl_role") == "MNR"
                and _htail in MANNER_NOUNS):
            role, reason = "abstain", "manner adjunct (e.g. by hand); carried by manner factor"
        # Fix C: single-word abstract/relational nouns ("position") have no AV referent.
        elif role == "unary_probe" and kind == "entity":
            _w = text.lower().split()
            if _w and _w[0] in {"a", "an", "the"}:
                _w = _w[1:]
            if len(_w) == 1 and _w[0] in ABSTRACT_NOUNS:
                role, reason = "abstain", "abstract/relational noun; no AV referent"
        vq, aq = _node_questions(text, kind or "entity", node.get("lemma", ""), event_particle.get(nid, ""))
        qrec = questions.get((cid, f"u:{nid}"), {})
        variables.append({
            "id": f"u:{nid}",
            "source_node_id": nid,
            "parent_variable_id": f"u:{semantic_parent[nid]}" if semantic_parent[nid] else "",
            "level": depth(nid) + 1,
            "semantic_type": kind,
            "unit_text": text,
            # Display label folds the particle in ("gets" -> "gets out") to match the
            # probe question; unit_text/id stay the bare parse anchor (stable cache/spans).
            "display_text": qrec.get(
                "display_text",
                f"{text} {event_particle[nid]}"
                if (kind == "event" and event_particle.get(nid)) else text,
            ),
            "span": node.get("span", [-1, -1]),
            "evidence_role": role,
            "role_reason": reason,
            "visual_question": qrec.get("visual_question", vq) if role == "unary_probe" else "",
            "audio_question": qrec.get("audio_question", aq) if role == "unary_probe" else "",
            "question_source": qrec.get("source", "fallback") if role == "unary_probe" else "",
            "source_deprel": node.get("deprel", ""),
            "source_node_type": node.get("node_type", ""),
        })
        accounted[nid] = "variable"

    factors = []
    # Property/cardinality nodes become local observed factors on their nearest
    # retained host.  Their text is not queried as a stand-alone unary.
    for nid, node in sorted(source_nodes.items(), key=lambda kv: (kv[1].get("span", [0])[0], kv[0])):
        if nid in retained or node.get("is_functional"):
            continue
        nt = node.get("node_type", "")
        if nt not in PROPERTY_TYPES:
            accounted[nid] = "contract"
            continue
        host = nearest_retained_ancestor(nid)
        if host is None and node.get("parent_id") is None:
            # Accounted by the root composition factor below.
            continue
        if host is None:
            accounted[nid] = "abstain"
            continue
        relation = "cardinality" if nt == "cardinality" else "attribute"
        needs_review = False
        if relation == "attribute" and kinds.get(host) in {"event", "state"}:
            prior = _srl_relation(pn_roles.get((cid, nid), {}).get("srl_role", ""))
            relation = prior if prior in {"manner", "temporal"} else "manner"
            needs_review = True
        role = "observed_factor"
        reason = ""
        fid = f"p:{nid}"
        decision = normalization_decisions.get((cid, fid), {})
        if decision.get("evidence_role") in {"observed_factor", "abstain", "contract"}:
            role = decision["evidence_role"]
            reason = decision.get("reason", "text-model normalization")
        if decision.get("semantic_relation") in SEMANTIC_RELATION_LABELS:
            relation = decision["semantic_relation"]
            needs_review = False
        host_text = _clean(source_nodes[host].get("node_text", ""))
        pred_text = _clean(node.get("node_text", ""))
        vq, aq = _factor_questions(
            relation, host_text, pred_text,
            parent_kind=kinds.get(host, ""),
            parent_lemma=source_nodes[host].get("lemma", ""),
        )
        qrec = questions.get((cid, fid), {})
        factors.append({
            "id": fid,
            "factor_scope": "local",
            "semantic_relation": relation,
            "evidence_role": role,
            "argument_ids": [f"u:{host}"],
            "argument_texts": [host_text],
            "predicate_text": pred_text,
            "marker": "",
            "unit_text": f"{relation}({host_text}, {pred_text})",
            "display_text": qrec.get(
                "display_text", _factor_display_text(
                    relation, host_text, pred_text,
                    parent_kind=kinds.get(host, ""),
                    parent_lemma=source_nodes[host].get("lemma", ""),
                )
            ),
            "span": node.get("span", [-1, -1]),
            "level": depth(host) + 2,
            "source_node_ids": [nid, host],
            "source_deprel": node.get("deprel", ""),
            "needs_review": needs_review,
            "role_reason": reason,
            "visual_question": qrec.get("visual_question", vq) if role == "observed_factor" else "",
            "audio_question": qrec.get("audio_question", aq) if role == "observed_factor" else "",
            "question_source": qrec.get("source", "fallback") if role == "observed_factor" else "",
        })
        accounted[nid] = "property_factor"

    # One edge factor per retained parent-child connection.  This is the topology
    # that keeps the graph singly connected; factors replace rather than duplicate
    # the corresponding dependency connection.
    for child in sorted(retained, key=lambda x: (depth(x), source_nodes[x].get("span", [0])[0], x)):
        parent = semantic_parent[child]
        if parent is None:
            continue
        cn, pn = source_nodes[child], source_nodes[parent]
        dep = cn.get("deprel", "")
        marker = markers.get(child, "")
        srl = pn_roles.get((cid, child), {}).get("srl_role", "")
        relation, role, needs_review = default_relation(
            deprel=dep,
            marker=marker,
            srl_role=srl,
            parent_kind=kinds[parent] or "entity",
            child_kind=kinds[child] or "entity",
        )
        decision = relation_decisions.get((cid, parent, child), {})
        if decision:
            relation = decision.get("semantic_relation", relation)
            role = decision.get("evidence_role", role)
            needs_review = False
        if role not in {"observed_factor", "fixed_factor", "abstain"}:
            role = "abstain"
            needs_review = True
        fid = f"e:{parent}:{child}"
        ptext = _clean(pn.get("node_text", ""))
        ctext = _clean(cn.get("node_text", ""))
        vq, aq = _factor_questions(
            relation, ptext, ctext, marker,
            kinds[parent] or "entity", kinds[child] or "entity",
            pn.get("lemma", ""), cn.get("lemma", ""),
            event_particle.get(parent, ""),
        )
        qrec = questions.get((cid, fid), {})
        factors.append({
            "id": fid,
            "factor_scope": "edge",
            "semantic_relation": relation,
            "evidence_role": role,
            "argument_ids": [f"u:{parent}", f"u:{child}"],
            "argument_texts": [ptext, ctext],
            "predicate_text": marker or relation,
            "marker": marker,
            "unit_text": f"{relation}({ptext}, {ctext})",
            "display_text": qrec.get(
                "display_text",
                _factor_display_text(
                    relation, ptext, ctext, marker,
                    kinds[parent] or "entity", kinds[child] or "entity",
                    pn.get("lemma", ""), cn.get("lemma", ""),
                    event_particle.get(parent, ""),
                ),
            ),
            "span": [
                min(pn.get("span", [0, 0])[0], cn.get("span", [0, 0])[0]),
                max(pn.get("span", [0, 0])[1], cn.get("span", [0, 0])[1]),
            ],
            "level": depth(child) + 1,
            "source_node_ids": [parent, child],
            "source_deprel": dep,
            "prior_srl_role": srl,
            "needs_review": needs_review,
            "role_reason": decision.get("reason", "parser/SRL fallback") if needs_review or decision else "",
            "visual_question": qrec.get("visual_question", vq) if role == "observed_factor" else "",
            "audio_question": qrec.get("audio_question", aq) if role == "observed_factor" else "",
            "question_source": qrec.get("source", "fallback") if role == "observed_factor" else "",
        })

    # Negation is a fixed logical factor on the scoped local/subtree truth.  The
    # original operator token may already be contracted by PN.
    for nid in retained:
        node = source_nodes[nid]
        if not node.get("negated"):
            continue
        factors.append({
            "id": f"logic:neg:{nid}",
            "factor_scope": "local",
            "semantic_relation": "negation",
            "evidence_role": "fixed_factor",
            "argument_ids": [f"u:{nid}"],
            "argument_texts": [_clean(node.get("node_text", ""))],
            "predicate_text": "not",
            "marker": "not",
            "unit_text": f"negation({_clean(node.get('node_text', ''))})",
            "display_text": f"not {_clean(node.get('node_text', ''))}",
            "span": node.get("span", [-1, -1]),
            "level": depth(nid) + 2,
            "source_node_ids": [nid],
            "source_deprel": "neg",
            "needs_review": False,
            "role_reason": "grammar supplies polarity reversal",
            "visual_question": "",
            "audio_question": "",
            "question_source": "",
        })

    # One root composition factor connects the latent output to the nearest
    # retained semantic frontier.  If the UD root survived normalization, this
    # is a fixed identity/composition factor.  If it was contracted (commonly a
    # copular adjective or cardinality), its predicate is observed here.
    top_variables = roots
    root_retained = source_root_id in retained
    root_relation = "composition" if root_retained else source_root.get("node_type", "composition")
    if root_relation not in PROPERTY_TYPES:
        root_relation = "composition"
    root_role = "fixed_factor" if root_retained else "observed_factor"
    root_decision = normalization_decisions.get((cid, "compose:root"), {})
    if root_decision.get("evidence_role") in {"observed_factor", "fixed_factor", "abstain"}:
        root_role = root_decision["evidence_role"]
    root_texts = [_clean(source_nodes[n].get("node_text", "")) for n in top_variables]
    root_predicate = _clean(source_root.get("node_text", ""))
    root_q = questions.get((cid, "compose:root"), {})
    if root_role == "observed_factor":
        joined = " and ".join(root_texts) or "the retained units"
        fallback_vq = f"Does the visible evidence establish the '{root_predicate}' relation among {joined}?"
        fallback_aq = f"Does sound or speech establish the '{root_predicate}' relation among {joined}?"
    else:
        fallback_vq = fallback_aq = ""
    factors.append({
        "id": "compose:root",
        "factor_scope": "root",
        "semantic_relation": root_relation,
        "evidence_role": root_role,
        "argument_ids": ["y:claim"] + [f"u:{n}" for n in top_variables],
        "argument_texts": ["claim verdict"] + root_texts,
        "predicate_text": root_predicate or "compose",
        "marker": "",
        "unit_text": f"{root_relation}({', '.join(root_texts)})",
        "display_text": "claim composition",
        "span": source_root.get("span", [0, len(claim_text)]),
        "level": 1,
        "source_node_ids": [source_root_id] if source_root_id else [],
        "source_deprel": "root",
        "needs_review": not root_retained,
        "role_reason": root_decision.get(
            "reason",
            "unprobed output composition" if root_retained else "contracted root predicate",
        ),
        "visual_question": root_q.get("visual_question", fallback_vq) if root_role == "observed_factor" else "",
        "audio_question": root_q.get("audio_question", fallback_aq) if root_role == "observed_factor" else "",
        "question_source": root_q.get("source", "fallback") if root_role == "observed_factor" else "",
    })
    if source_root_id and not root_retained:
        accounted[source_root_id] = "root_factor"

    # Coverage and topology checks are materialized in every record so downstream
    # annotation and inference cannot silently consume malformed trees.
    content_ids = {
        nid for nid, n in source_nodes.items()
        if not n.get("is_functional") and n.get("node_type") in (VARIABLE_KINDS | PROPERTY_TYPES)
    }
    uncovered = sorted(content_ids - set(accounted))
    edge_count = sum(1 for f in factors if f["factor_scope"] == "edge")
    graph: dict[str, set[str]] = {v["id"]: set() for v in variables}
    graph.update({f["id"]: set() for f in factors})
    for factor in factors:
        for argument_id in factor["argument_ids"]:
            if argument_id not in graph:
                continue
            graph[factor["id"]].add(argument_id)
            graph[argument_id].add(factor["id"])
    graph_edges = sum(len(v) for v in graph.values()) // 2
    seen = set()
    stack = ["y:claim"]
    while stack:
        current = stack.pop()
        if current in seen:
            continue
        seen.add(current)
        stack.extend(graph.get(current, ()) - seen)
    topology_ok = len(seen) == len(graph) and graph_edges == max(0, len(graph) - 1)
    # A binary relation question can legitimately paraphrase an entire short
    # atomic claim.  The prohibited case is instead a *target unit* copied from
    # a multi-unit subtree (the old contextualized-probe behavior).
    whole = _clean(claim_text).lower()
    overlaps = [
        item["id"]
        for item in variables
        if item["id"] != "y:claim"
        and len(variables) > 2
        and _clean(item.get("unit_text", "")).lower() == whole
    ]

    return {
        "schema_version": "semantic-factor-tree-v1",
        "claim_id": cid,
        "claim_text": claim_text,
        "root_variable_id": "y:claim",
        "variables": variables,
        "factors": sorted(factors, key=lambda x: (x["level"], x["span"][0], x["id"])),
        "audit": {
            "source_content_nodes": len(content_ids),
            "accounted_content_nodes": len(content_ids) - len(uncovered),
            "uncovered_node_ids": uncovered,
            "n_variables": len(variables) - 1,
            "n_latent_variables": 1,
            "n_edge_factors": edge_count,
            "n_local_factors": sum(1 for f in factors if f["factor_scope"] == "local"),
            "n_observed_factors": sum(1 for f in factors if f["evidence_role"] == "observed_factor"),
            "n_fixed_factors": sum(1 for f in factors if f["evidence_role"] == "fixed_factor"),
            "n_needs_review": sum(1 for f in factors if f.get("needs_review")),
            "tree_topology_ok": topology_ok,
            "factor_graph_vertices": len(graph),
            "factor_graph_edges": graph_edges,
            "whole_claim_question_overlaps": overlaps,
            "lexical_repairs": lexical_repairs,
            "subject_repairs": subject_repairs,
        },
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--trees", default=str(DEFAULT_TREES))
    ap.add_argument("--hypergraph", default=str(DEFAULT_HYPERGRAPH))
    ap.add_argument("--pn-roles", default=str(DEFAULT_PN_ROLES))
    ap.add_argument("--normalization-decisions", default="")
    ap.add_argument("--relation-decisions", default="")
    ap.add_argument("--questions", default="")
    ap.add_argument("--output", default=str(DEFAULT_OUTPUT))
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    trees = read_jsonl(args.trees)
    if args.limit is not None:
        trees = trees[: args.limit]
    hg = {r["claim_id"]: r for r in read_jsonl(args.hypergraph)}
    roles = index_by(read_jsonl(args.pn_roles), "claim_id", "node_id")
    normalization = index_by(
        read_jsonl(args.normalization_decisions), "claim_id", "target_id"
    ) if args.normalization_decisions else {}
    decisions = index_by(read_jsonl(args.relation_decisions), "claim_id", "parent_id", "child_id") if args.relation_decisions else {}
    questions = index_by(read_jsonl(args.questions), "claim_id", "target_id") if args.questions else {}

    compiled = [
        compile_tree(t, hg.get(t["claim_id"]), roles, normalization, decisions, questions)
        for t in trees
    ]
    write_jsonl(args.output, compiled)

    totals = Counter()
    bad = []
    for rec in compiled:
        audit = rec["audit"]
        totals.update({k: v for k, v in audit.items() if isinstance(v, int)})
        if not audit["tree_topology_ok"] or audit["uncovered_node_ids"] or audit["whole_claim_question_overlaps"]:
            bad.append(rec["claim_id"])
    print(f"semantic factor trees: {len(compiled)} -> {args.output}")
    print(f"variables={totals['n_variables']} edge_factors={totals['n_edge_factors']} "
          f"local_factors={totals['n_local_factors']} observed={totals['n_observed_factors']} "
          f"fixed={totals['n_fixed_factors']} needs_review={totals['n_needs_review']}")
    print(f"audit failures: {len(bad)}" + (f" (first: {bad[:10]})" if bad else ""))


if __name__ == "__main__":
    main()
