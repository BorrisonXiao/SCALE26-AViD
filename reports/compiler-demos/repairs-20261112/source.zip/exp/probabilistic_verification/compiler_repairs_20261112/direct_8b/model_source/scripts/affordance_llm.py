#!/usr/bin/env python
"""
AViD Phase 1 — LLM soft affordance prior via vLLM.

Queries Qwen3-30B-A3B and reads first-token logprobs → renormalized soft
distribution per unit.  Three pass modes via --pass:

  --pass 0  (legacy/v0): 6-option MCQ (A–F) — visual_other, visual_ocr,
                          audio_speech, audio_other, unverifiable, na.
                          Default when --annotation-units is NOT used.

  --pass 1  (v1/v2):     4-option MCQ (A–D) — visual, audio, unverifiable, na.
                          Tighter na description ("never a noun or noun phrase").
                          Default when --annotation-units IS used.

  --pass 2  (v2 only):   2-option MCQ per unit type:
                            visual units → A=visual_other / B=visual_ocr
                            audio units  → A=audio_speech / B=audio_other
                          Requires --pass1-output (jsonl from a --pass 1 run)
                          to determine which units to process and which prompt.
                          unverifiable/na units are skipped.

Caches per (claim_id, unit_id) → resumable.

Usage (vllm-omni env, GPU node):
    # v1 / pass-1:
    python affordance_llm.py \\
        --annotation-units exp/phase1/reports/annotation_units.tsv \\
        --pass 1 --output exp/v1/affordance_llm.jsonl \\
        --cache exp/v1/cache/affordance_llm_cache.jsonl --tp 1

    # v2 / pass-2 (run after pass-1 completes):
    python affordance_llm.py \\
        --annotation-units exp/phase1/reports/annotation_units.tsv \\
        --pass 2 \\
        --pass1-output exp/phase1/affordance_v2/affordance_llm_pass1.jsonl \\
        --output exp/phase1/affordance_v2/affordance_llm_pass2.jsonl \\
        --cache exp/phase1/affordance_v2/cache/affordance_llm_pass2_cache.jsonl --tp 1

    # legacy mode (v0, do not rerun):
    python affordance_llm.py --pass 0 --tp 1
"""
import argparse
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("VLLM_USE_V1", "0")  # v1 engine compatibility

# -- Default paths -----------------------------------------------------------
HYPERGRAPH_PATH      = "/exp/cxiao/scale26/avid/exp/phase1/hypergraph.jsonl"
OUTPUT_PATH          = "/exp/cxiao/scale26/avid/exp/phase1/affordance_llm.jsonl"
CACHE_PATH           = "/exp/cxiao/scale26/avid/exp/phase1/affordance_llm_cache.jsonl"
OUTPUT_UNITS_PATH    = "/exp/cxiao/scale26/avid/exp/phase1/affordance_llm_units.jsonl"
CACHE_UNITS_PATH     = "/exp/cxiao/scale26/avid/exp/phase1/affordance_llm_units_cache.jsonl"
MODEL_PATH           = "/home/hltcoe/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507"

# ---------------------------------------------------------------------------
# Pass 0 — legacy 6-channel (A–F)
# ---------------------------------------------------------------------------
CHANNELS = ["visual_other", "visual_ocr", "audio_speech", "audio_other",
            "unverifiable", "na"]
OPTION_LETTERS = ["A", "B", "C", "D", "E", "F"]

SYSTEM_PROMPT = (
    "You are a precise media analysis assistant. "
    "Answer each question with exactly one letter (A, B, C, D, E, or F)."
)

USER_TEMPLATE = """\
Claim: "{claim_text}"

Target unit: "{unit_text}"
Context (unit marked with **): "{marked_context}"

Which single evidence channel is most likely needed to verify this unit?

A) visual_other      — visible objects, people, actions, scenes, locations
B) visual_ocr        — on-screen text, signs, captions, titles, numbers
C) audio_speech      — spoken words, dialogue, speech, announcements
D) audio_other       — non-speech sounds (music, noise, environmental audio)
E) unverifiable      — intent, cause, subjective judgment, background knowledge
F) na   — unit is relational or incomplete; cannot be verified in
                       isolation without its arguments (e.g. bare "causing", "is",
                       "involving"; expletive "there" or "it")

Answer:"""

# ---------------------------------------------------------------------------
# Pass 1 — 4-class coarse (A–D)
# ---------------------------------------------------------------------------
PASS1_CHANNELS = ["visual", "audio", "unverifiable", "na"]
PASS1_OPTION_LETTERS = ["A", "B", "C", "D"]

PASS1_SYSTEM_PROMPT = (
    "You are a precise media analysis assistant. "
    "Answer each question with exactly one letter (A, B, C, or D)."
)

PASS1_USER_TEMPLATE = """\
Claim: "{claim_text}"

Target unit: "{unit_text}"
Context (unit marked with **): "{marked_context}"

Which single evidence channel is most likely needed to verify this unit?

A) visual       — any visible thing: a specific object, person, action, scene,
                  location, on-screen text, sign, or caption that can be pointed
                  to in a video frame
B) audio        — any audible thing: speech, dialogue, announcement, sound, music,
                  or environmental audio that can be heard in the recording
C) unverifiable — a specific, identifiable referent exists, but what is claimed
                  about it cannot be confirmed from audio-visual evidence alone:
                  internal states ("scared", "determined"), motives, subjective
                  judgments, background knowledge ("is a veteran")
D) na           — unit is NOT a useful annotation target. Use na for:
                  (1) relational/functional words: "is", "are", "caused",
                      "affecting", "involving", "resulting in", expletive
                      "there", pleonastic "it"
                  (2) vague or underspecified referents that do not identify a
                      specific locatable thing — indefinite pronouns ("anyone",
                      "someone", "everyone", "something", "those" without clear
                      antecedent), and vague nouns ("the conditions", "the
                      situation", "the matter", "a role", "things",
                      "circumstances", "what happened")
                  TEST: can an annotator point to a specific object, person,
                  sound, or moment in the video to verify this unit? If not → na.
                  NEVER na for specific named entities or concrete objects
                  ("the typhoon", "Alaska", "the protesters", "the fire").

Answer:"""

# ---------------------------------------------------------------------------
# Pass 2 — visual refinement (A–B) and audio refinement (A–B)
# ---------------------------------------------------------------------------
PASS2_VISUAL_CHANNELS = ["visual_other", "visual_ocr"]
PASS2_VISUAL_OPTION_LETTERS = ["A", "B"]

PASS2_VISUAL_SYSTEM_PROMPT = (
    "You are a precise media analysis assistant. "
    "Answer each question with exactly one letter (A or B)."
)

PASS2_VISUAL_USER_TEMPLATE = """\
Claim: "{claim_text}"

Target unit: "{unit_text}"
Context (unit marked with **): "{marked_context}"

This unit requires visual evidence. Which specific type?

A) visual_other  — visible objects, people, actions, scenes, locations
B) visual_ocr    — on-screen text, signs, captions, titles, numbers

Answer:"""

PASS2_AUDIO_CHANNELS = ["audio_speech", "audio_other"]
PASS2_AUDIO_OPTION_LETTERS = ["A", "B"]

PASS2_AUDIO_SYSTEM_PROMPT = (
    "You are a precise media analysis assistant. "
    "Answer each question with exactly one letter (A or B)."
)

PASS2_AUDIO_USER_TEMPLATE = """\
Claim: "{claim_text}"

Target unit: "{unit_text}"
Context (unit marked with **): "{marked_context}"

This unit requires audio evidence. Which specific type?

A) audio_speech  — spoken words, dialogue, speech, announcements
B) audio_other   — non-speech sounds (music, noise, environmental audio)

Answer:"""


def make_marked_context(claim_text: str, unit_text: str) -> str:
    """Mark the first occurrence of unit_text in the claim with **...**."""
    idx = claim_text.lower().find(unit_text.lower())
    if idx == -1:
        return claim_text
    return (
        claim_text[:idx]
        + "**" + claim_text[idx: idx + len(unit_text)] + "**"
        + claim_text[idx + len(unit_text):]
    )


# -- vLLM helpers ------------------------------------------------------------

def build_prompts(tokenizer, requests: list[dict],
                  default_system: str = SYSTEM_PROMPT) -> list[str]:
    """Apply Qwen3 chat template (non-thinking mode) to all requests.

    If a request has a 'system_text' key it overrides default_system (used for
    pass-2 which has different system prompts for visual vs audio).
    """
    prompts = []
    for req in requests:
        system = req.get("system_text") or default_system
        messages = [
            {"role": "system", "content": system},
            {"role": "user",   "content": req["user_text"]},
        ]
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
        prompts.append(text)
    return prompts


def extract_option_distribution(
    logprobs_dict: dict,   # token_id -> Logprob object
    tokenizer,
    channels: list[str] | None = None,
    option_letters: list[str] | None = None,
) -> dict[str, float]:
    """
    Given vLLM logprob dict at first generated position, extract logprobs for
    the given option letters (and variants like ' A', 'A:'), renormalize.
    Returns {channel: probability}.  Defaults to pass-0 6-channel layout.
    """
    import math

    if channels is None:
        channels = CHANNELS
    if option_letters is None:
        option_letters = OPTION_LETTERS

    # Map option letter -> accumulated log-probability (log-sum-exp over variants)
    option_logprob: dict[str, float] = {L: float("-inf") for L in option_letters}

    for tok_id, logprob_obj in logprobs_dict.items():
        decoded = logprob_obj.decoded_token if hasattr(logprob_obj, "decoded_token") else ""
        if decoded is None:
            decoded = tokenizer.decode([tok_id])
        cleaned = decoded.strip().upper().rstrip(":).")
        if cleaned in option_letters:
            L = cleaned
            lp = logprob_obj.logprob if hasattr(logprob_obj, "logprob") else logprob_obj
            current = option_logprob[L]
            if current == float("-inf"):
                option_logprob[L] = lp
            else:
                option_logprob[L] = current + math.log1p(math.exp(lp - current))

    # Normalize to probabilities
    valid = {L: lp for L, lp in option_logprob.items() if lp != float("-inf")}
    if not valid:
        return {ch: 1.0 / len(channels) for ch in channels}

    max_lp = max(valid.values())
    exp_vals = {L: math.exp(lp - max_lp) for L, lp in valid.items()}
    total = sum(exp_vals.values())
    probs = {L: v / total for L, v in exp_vals.items()}

    return {channels[i]: probs.get(L, 0.0) for i, L in enumerate(option_letters)}


# -- Cache helpers -----------------------------------------------------------

def load_cache(cache_path: str) -> dict[str, dict]:
    """Load existing cache: {claim_id|unit_id -> dist}."""
    cache = {}
    p = Path(cache_path)
    if not p.exists():
        return cache
    with open(p, encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            key = f"{obj['claim_id']}|{obj['unit_id']}"
            cache[key] = obj["distribution"]
    return cache


# -- Main --------------------------------------------------------------------

def setup_parser():
    p = argparse.ArgumentParser(
        description="LLM soft affordance (AViD Phase 1) — multi-pass"
    )
    p.add_argument("--hypergraph",        default=HYPERGRAPH_PATH)
    p.add_argument("--annotation-units",  default="",
                   help="Path to annotation_units.tsv.  When provided, processes "
                        "TSV rows using their unit_text/claim_highlighted directly.")
    p.add_argument("--pass",              dest="pass_num", type=int, default=None,
                   choices=[0, 1, 2],
                   help="0=legacy 6-chan (default when no --annotation-units), "
                        "1=4-class coarse (default when --annotation-units given), "
                        "2=2-class fine-grained per unit type (requires --pass1-output).")
    p.add_argument("--pass1-output",      default="",
                   help="Path to pass-1 affordance_llm.jsonl; required for --pass 2.")
    p.add_argument("--output",            default="")
    p.add_argument("--cache",             default="")
    p.add_argument("--model-path",        default=MODEL_PATH)
    p.add_argument("--tp",                type=int, default=0,
                   help="Tensor parallel size (0 = auto from GPU count)")
    p.add_argument("--batch-size",        type=int, default=64)
    p.add_argument("--logprob-n",         type=int, default=30,
                   help="Number of top logprobs to request per generated position")
    p.add_argument("--limit-claims",      type=int, default=0,
                   help="Process only first N claims (0 = all; for testing)")
    p.add_argument("--units",             choices=["nodes", "factors", "both"],
                   default="both",
                   help="(Legacy mode only) which unit types to process")
    return p


def _build_requests_from_hypergraph(claims, cache, args):
    """Build request list from hypergraph nodes/factors (legacy mode)."""
    requests = []
    for rec in claims:
        units_to_process = []
        if args.units in ("nodes", "both"):
            for node in rec["nodes"]:
                units_to_process.append(("node", node["id"], node["text"],
                                         rec["claim_text"], rec["claim_text"]))
        if args.units in ("factors", "both"):
            for fac in rec["factors"]:
                units_to_process.append(("factor", fac["id"], fac["surface_span"],
                                         rec["claim_text"], rec["claim_text"]))

        for unit_type, unit_id, unit_text, claim_text, _ in units_to_process:
            key = f"{rec['claim_id']}|{unit_id}"
            if key in cache:
                continue
            marked = make_marked_context(claim_text, unit_text)
            requests.append({
                "claim_id":   rec["claim_id"],
                "unit_id":    unit_id,
                "unit_type":  unit_type,
                "unit_text":  unit_text,
                "claim_text": claim_text,
                "user_text":  USER_TEMPLATE.format(
                    claim_text=claim_text,
                    unit_text=unit_text,
                    marked_context=marked,
                ),
            })
    return requests


def _build_requests_from_annotation_units(ann_units_path, cache, template=None):
    """Build request list from annotation_units.tsv rows (pass 0 or pass 1)."""
    import csv as _csv
    if template is None:
        template = USER_TEMPLATE
    requests = []
    with open(ann_units_path, newline="", encoding="utf-8") as f:
        for row in _csv.DictReader(f, delimiter="\t"):
            if not row.get("unit_id") or not row.get("unit_text") or not row.get("claim_text"):
                continue
            key = f"{row['claim_id']}|{row['unit_id']}"
            if key in cache:
                continue
            marked = row.get("claim_highlighted") or make_marked_context(
                row["claim_text"], row["unit_text"]
            )
            requests.append({
                "claim_id":   row["claim_id"],
                "unit_id":    row["unit_id"],
                "unit_type":  row["unit_type"],
                "unit_text":  row["unit_text"],
                "claim_text": row["claim_text"],
                "user_text":  template.format(
                    claim_text=row["claim_text"],
                    unit_text=row["unit_text"],
                    marked_context=marked,
                ),
            })
    return requests


def _load_pass1_top_labels(pass1_output_path: str) -> dict[str, str]:
    """Load pass-1 output → {claim_id|unit_id: top_label}."""
    top: dict[str, str] = {}
    with open(pass1_output_path, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            cid = rec["claim_id"]
            for uid, dist in rec.get("affordance_llm_units", {}).items():
                top[f"{cid}|{uid}"] = max(dist, key=dist.get)
    return top


def _build_requests_pass2(ann_units_path, cache, pass1_top_labels):
    """Build pass-2 request list: only for visual/audio units from pass-1.

    Each request gets the appropriate 2-class template and stores which
    pass-2 subtype it is ('visual' or 'audio') in req['pass2_type'].
    """
    import csv as _csv
    requests = []
    with open(ann_units_path, newline="", encoding="utf-8") as f:
        for row in _csv.DictReader(f, delimiter="\t"):
            if not row.get("unit_id") or not row.get("unit_text") or not row.get("claim_text"):
                continue
            key = f"{row['claim_id']}|{row['unit_id']}"
            top_label = pass1_top_labels.get(key, "")
            if top_label not in ("visual", "audio"):
                continue  # unverifiable/na — no pass-2 needed
            if key in cache:
                continue
            marked = row.get("claim_highlighted") or make_marked_context(
                row["claim_text"], row["unit_text"]
            )
            if top_label == "visual":
                template = PASS2_VISUAL_USER_TEMPLATE
                system   = PASS2_VISUAL_SYSTEM_PROMPT
            else:
                template = PASS2_AUDIO_USER_TEMPLATE
                system   = PASS2_AUDIO_SYSTEM_PROMPT
            requests.append({
                "claim_id":   row["claim_id"],
                "unit_id":    row["unit_id"],
                "unit_type":  row["unit_type"],
                "unit_text":  row["unit_text"],
                "claim_text": row["claim_text"],
                "pass2_type": top_label,          # 'visual' or 'audio'
                "system_text": system,
                "user_text":  template.format(
                    claim_text=row["claim_text"],
                    unit_text=row["unit_text"],
                    marked_context=marked,
                ),
            })
    return requests


def _run_inference(llm, tokenizer, requests, sampling_params, cache, cache_f,
                   channels, option_letters):
    """Run vLLM batched inference and write results to cache_f.  Updates cache in-place."""
    n_batches = (len(requests) + 63) // 64  # internal batch size for progress reporting
    batch_size = min(64, max(1, len(requests)))
    n_batches = (len(requests) + batch_size - 1) // batch_size

    for b_idx in range(n_batches):
        batch = requests[b_idx * batch_size: (b_idx + 1) * batch_size]
        prompts = build_prompts(tokenizer, batch)
        print(f"  Batch {b_idx + 1}/{n_batches}: {len(batch)} requests ...", flush=True)
        outputs = llm.generate(prompts, sampling_params=sampling_params)

        for req, out in zip(batch, outputs):
            try:
                lp_dict = out.outputs[0].logprobs[0]
                dist = extract_option_distribution(lp_dict, tokenizer, channels, option_letters)
            except Exception as e:
                print(f"  WARNING: logprob extraction failed for "
                      f"{req['claim_id']}|{req['unit_id']}: {e}", file=sys.stderr)
                dist = {ch: 1.0 / len(channels) for ch in channels}

            cache_entry = {
                "claim_id":     req["claim_id"],
                "unit_id":      req["unit_id"],
                "unit_type":    req["unit_type"],
                "distribution": dist,
            }
            cache_f.write(json.dumps(cache_entry) + "\n")
            cache[f"{req['claim_id']}|{req['unit_id']}"] = dist


def _write_units_output(out_path, ann_units_path, cache):
    """Write per-claim affordance_llm_units output from cache."""
    import csv as _csv
    from collections import defaultdict
    rows_by_claim: dict[str, list[dict]] = defaultdict(list)
    with open(ann_units_path, newline="", encoding="utf-8") as f:
        for row in _csv.DictReader(f, delimiter="\t"):
            if not row.get("unit_id") or not row.get("claim_id"):
                continue
            rows_by_claim[row["claim_id"]].append(row)

    with open(out_path, "w", encoding="utf-8") as out_f:
        for cid, rows in rows_by_claim.items():
            unit_dists: dict[str, dict] = {}
            for row in rows:
                key = f"{cid}|{row['unit_id']}"
                if key in cache:
                    unit_dists[row["unit_id"]] = cache[key]
            out_f.write(json.dumps({
                "claim_id":             cid,
                "affordance_llm_units": unit_dists,
            }, ensure_ascii=False) + "\n")

    n_covered = sum(
        1 for rows in rows_by_claim.values()
        for row in rows
        if f"{row['claim_id']}|{row['unit_id']}" in cache
    )
    n_total = sum(len(v) for v in rows_by_claim.values())
    print(f"    Unit coverage: {n_covered}/{n_total} ({100*n_covered/max(1,n_total):.1f}%)")


def main():
    args = setup_parser().parse_args()

    units_mode = bool(args.annotation_units)

    # Resolve pass number
    if args.pass_num is None:
        pass_num = 1 if units_mode else 0
    else:
        pass_num = args.pass_num

    # Validate pass-2 requirements
    if pass_num == 2:
        if not units_mode:
            print("ERROR: --pass 2 requires --annotation-units", file=sys.stderr)
            sys.exit(1)
        if not args.pass1_output:
            print("ERROR: --pass 2 requires --pass1-output", file=sys.stderr)
            sys.exit(1)
        if not Path(args.pass1_output).exists():
            print(f"ERROR: --pass1-output not found: {args.pass1_output}", file=sys.stderr)
            sys.exit(1)

    # Select channel/letter sets and prompts for this pass
    if pass_num == 0:
        active_channels = CHANNELS
        active_letters  = OPTION_LETTERS
        active_system   = SYSTEM_PROMPT
        active_template = USER_TEMPLATE
    elif pass_num == 1:
        active_channels = PASS1_CHANNELS
        active_letters  = PASS1_OPTION_LETTERS
        active_system   = PASS1_SYSTEM_PROMPT
        active_template = PASS1_USER_TEMPLATE
    else:  # pass 2 — channels/letters are per-unit; set to None, handled in builder
        active_channels = None
        active_letters  = None
        active_system   = None
        active_template = None

    # Default output/cache paths
    if pass_num == 0:
        default_out   = OUTPUT_UNITS_PATH if units_mode else OUTPUT_PATH
        default_cache = CACHE_UNITS_PATH  if units_mode else CACHE_PATH
    elif pass_num == 1:
        default_out   = ""   # caller must provide --output
        default_cache = ""   # caller must provide --cache
    else:  # pass 2
        default_out   = ""
        default_cache = ""

    out_path   = Path(args.output or default_out or "affordance_llm_pass1.jsonl")
    cache_path = Path(args.cache  or default_cache or "affordance_llm_pass1_cache.jsonl")
    if pass_num == 2:
        out_path   = Path(args.output or "affordance_llm_pass2.jsonl")
        cache_path = Path(args.cache  or "affordance_llm_pass2_cache.jsonl")

    print("=" * 60)
    print(f"AViD Phase 1 — affordance_llm.py (pass {pass_num})")
    pass_desc = {0: "6-class legacy", 1: "4-class coarse", 2: "2-class fine-grained"}
    print(f"  Mode:   {pass_desc[pass_num]} | "
          f"{'annotation-units' if units_mode else 'legacy (hypergraph)'}")
    print(f"  Output: {out_path}")
    print(f"  Cache:  {cache_path}")
    print("=" * 60)

    # 1. Load hypergraph (always needed for legacy; optional otherwise but cheap)
    print(f"\n[1] Loading hypergraph: {args.hypergraph}")
    claims = []
    with open(args.hypergraph, encoding="utf-8") as f:
        for line in f:
            claims.append(json.loads(line))
    if args.limit_claims > 0:
        claims = claims[: args.limit_claims]
    print(f"    Claims: {len(claims)}")

    # 2. Load cache
    cache = load_cache(str(cache_path))
    print(f"    Cache hits: {len(cache)}")

    # 3. Build request list
    if pass_num == 2:
        print(f"\n[2] Loading pass-1 top labels from: {args.pass1_output}")
        pass1_top = _load_pass1_top_labels(args.pass1_output)
        print(f"    Pass-1 top labels loaded: {len(pass1_top)}")
        print(f"    Building pass-2 requests from {args.annotation_units} ...")
        requests = _build_requests_pass2(args.annotation_units, cache, pass1_top)
    elif units_mode:
        print(f"\n[2] Building requests from {args.annotation_units} ...")
        requests = _build_requests_from_annotation_units(
            args.annotation_units, cache, template=active_template
        )
    else:
        print(f"\n[2] Building requests from hypergraph nodes/factors ...")
        requests = _build_requests_from_hypergraph(claims, cache, args)

    print(f"    Requests to process: {len(requests)} (cached: {len(cache)})")
    if not requests:
        print("    All requests already cached → writing output directly.")

    # 4. Load vLLM and run inference
    if requests:
        import torch
        from vllm import LLM, SamplingParams
        from transformers import AutoTokenizer

        tp_size = args.tp if args.tp > 0 else torch.cuda.device_count()
        if tp_size == 0:
            print("ERROR: No GPUs found.", file=sys.stderr)
            sys.exit(1)
        print(f"\n[3] Loading model (tp={tp_size}): {args.model_path}")

        tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
        llm = LLM(
            model=args.model_path,
            trust_remote_code=True,
            gpu_memory_utilization=0.90,
            tensor_parallel_size=tp_size,
            dtype="bfloat16",
            seed=42,
            max_model_len=4096,
        )
        print("    vLLM engine ready.")

        sampling_params = SamplingParams(
            temperature=0.0,
            max_tokens=1,
            logprobs=args.logprob_n,
        )

        print(f"\n[4] Running vLLM batches (batch_size={args.batch_size}) ...")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.parent.mkdir(parents=True, exist_ok=True)

        if pass_num == 2:
            # Pass-2: each request carries its own channel set (visual or audio)
            with open(cache_path, "a", encoding="utf-8") as cache_f:
                batch_size = args.batch_size
                n_batches = (len(requests) + batch_size - 1) // batch_size
                for b_idx in range(n_batches):
                    batch = requests[b_idx * batch_size: (b_idx + 1) * batch_size]
                    prompts = build_prompts(tokenizer, batch)
                    print(f"  Batch {b_idx + 1}/{n_batches}: {len(batch)} requests ...",
                          flush=True)
                    outputs = llm.generate(prompts, sampling_params=sampling_params)
                    for req, out in zip(batch, outputs):
                        p2type = req["pass2_type"]
                        if p2type == "visual":
                            chs, ltrs = PASS2_VISUAL_CHANNELS, PASS2_VISUAL_OPTION_LETTERS
                        else:
                            chs, ltrs = PASS2_AUDIO_CHANNELS, PASS2_AUDIO_OPTION_LETTERS
                        try:
                            lp_dict = out.outputs[0].logprobs[0]
                            dist = extract_option_distribution(lp_dict, tokenizer, chs, ltrs)
                        except Exception as e:
                            print(f"  WARNING: {req['claim_id']}|{req['unit_id']}: {e}",
                                  file=sys.stderr)
                            dist = {ch: 1.0 / len(chs) for ch in chs}
                        cache_entry = {
                            "claim_id":     req["claim_id"],
                            "unit_id":      req["unit_id"],
                            "unit_type":    req["unit_type"],
                            "pass2_type":   p2type,
                            "distribution": dist,
                        }
                        cache_f.write(json.dumps(cache_entry) + "\n")
                        cache[f"{req['claim_id']}|{req['unit_id']}"] = dist
        else:
            with open(cache_path, "a", encoding="utf-8") as cache_f:
                _run_inference(llm, tokenizer, requests, sampling_params, cache, cache_f,
                               active_channels, active_letters)

    # 5. Write per-claim output
    print(f"\n[5] Writing per-claim output: {out_path}")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if pass_num == 2:
        # Write pass-2 output; units not in cache (unverifiable/na) are omitted
        _write_units_output(out_path, args.annotation_units, cache)

    elif units_mode:
        _write_units_output(out_path, args.annotation_units, cache)

    else:
        # Legacy hypergraph mode
        with open(out_path, "w", encoding="utf-8") as out_f:
            for rec in claims:
                node_dists:   dict[str, dict] = {}
                factor_dists: dict[str, dict] = {}
                for node in rec["nodes"]:
                    key = f"{rec['claim_id']}|{node['id']}"
                    if key in cache:
                        node_dists[node["id"]] = cache[key]
                for fac in rec["factors"]:
                    key = f"{rec['claim_id']}|{fac['id']}"
                    if key in cache:
                        factor_dists[fac["id"]] = cache[key]
                out_f.write(json.dumps({
                    "claim_id":               rec["claim_id"],
                    "affordance_llm_nodes":   node_dists,
                    "affordance_llm_factors": factor_dists,
                }, ensure_ascii=False) + "\n")

    print(f"    Output: {out_path}")
    print(f"    Cache:  {cache_path}")
    print("\nDone.")


if __name__ == "__main__":
    main()
