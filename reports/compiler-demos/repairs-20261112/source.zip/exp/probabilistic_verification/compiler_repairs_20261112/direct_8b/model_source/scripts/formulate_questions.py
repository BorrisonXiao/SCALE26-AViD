#!/usr/bin/env python3
"""
AViD Phase 2 — R5 pre-pass: formulate per-unit, per-modality verification questions.

For each verifiable unit, uses Qwen3-30B (text-only) to generate two targeted
yes/no questions — one for visual checking, one for audio — by reading the full
claim to understand what the unit refers to, then writing a unit-focused question.
This replaces r3 (verbalize_units.py) which collapsed atomic nodes to full-claim
paraphrases.  See ADR-008 and prompts_phase2.py for rationale.

Per ADR-009 the two questions come from two INDEPENDENT single-modality calls
(visual system prompt, audio system prompt) rather than one call emitting both
lines — independence prevents the questions from anchoring on each other and keeps
the formulator blind to modality fit.

Per ADR-011, each unit first goes through a modality-agnostic na TRIAGE call
(pointability test, ADR-003) run BEFORE the two question calls. A unit judged na
(e.g. a verb in a light/abstract sense like "leaves" = "produces") skips both
question calls, is recorded with a reason, and is filtered from r5/r5e
verification (its visual/audio questions stay empty, which verify_support skips).
The model is loaded once and used for both sweeps (triage, then formulate).

Output JSONL (resumable):
  {claim_id, unit_id, unit_text, node_type, na, na_reason,
   visual_question, audio_question}   # questions empty when na=true
Cache keys: claim_id|unit_id|triage  and  claim_id|unit_id|{visual,audio}.
Also writes: <output_dir>/na_units_r5.txt (ids) + na_units_r5.tsv (ids + reasons).

Prompts live in prompts_phase2.py
  (TRIAGE_SYSTEM / TRIAGE_USER_TMPL; FORMULATE_VIS_SYSTEM / FORMULATE_AUD_SYSTEM /
   FORMULATE_USER_TMPL).

Usage (vllm-omni env, GPU node):
    python scripts/formulate_questions.py \\
        --output exp/phase2/prompt_ablation/formulated_questions.jsonl \\
        --cache  exp/phase2/prompt_ablation/cache/formulated_cache.jsonl \\
        --tp 1 --batch-size 128
"""

import argparse
import csv
import json
import os
import re
import sys
from pathlib import Path

os.environ.setdefault("VLLM_USE_V1", "0")

_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_ANN_UNITS  = str(_AVID / "exp/phase1/reports/annotation_units.tsv")
DEFAULT_HYPERGRAPH = str(_AVID / "exp/phase1/hypergraph.jsonl")
DEFAULT_AFF_TSV    = str(_AVID / "exp/phase1/affordance_v2/affordance_annotation.tsv")
DEFAULT_NA_LIST    = str(_AVID / "exp/phase2/na_unit_ids.txt")
DEFAULT_OUTPUT     = str(_AVID / "exp/phase2/prompt_ablation/formulated_questions.jsonl")
MODEL_PATH         = "/home/hltcoe/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507"

sys.path.insert(0, str(Path(__file__).parent))
from prompts_phase2 import (FORMULATE_VIS_SYSTEM, FORMULATE_AUD_SYSTEM,
                            FORMULATE_USER_TMPL, TRIAGE_SYSTEM, TRIAGE_USER_TMPL,
                            FORMULATE_PROMPT_VERSION, _node_kind, _NODE_KIND_DESC)
from unit_filters import filter_units, format_stats

MODALITIES = ("visual", "audio")
_FORMULATE_SYSTEMS = {"visual": FORMULATE_VIS_SYSTEM, "audio": FORMULATE_AUD_SYSTEM}


def ck(claim_id: str, unit_id: str, tag: str) -> str:
    """Version-tagged cache key. Bumping FORMULATE_PROMPT_VERSION (prompts_phase2.py)
    auto-invalidates stale cached entries when the prompts change; resume stays
    valid within a version. tag ∈ {triage, visual, audio}."""
    return f"{claim_id}|{unit_id}|{FORMULATE_PROMPT_VERSION}|{tag}"


def is_factor(unit_id: str) -> bool:
    """f<N> = composition factor (predicate_argument / relation / full_claim);
    n<X> / pu_n<X> = atomic lexical node. na TRIAGE runs on ATOMS ONLY — factors
    are AViD's compositional-support targets and are always probed (ADR-011)."""
    return unit_id.startswith("f")


def make_marked_context(claim_text: str, unit_text: str) -> str:
    idx = claim_text.lower().find(unit_text.lower())
    if idx == -1:
        return claim_text
    return (claim_text[:idx] + "**" + claim_text[idx: idx + len(unit_text)] + "**"
            + claim_text[idx + len(unit_text):])


def load_na_set(na_list_path: str, affordance_tsv: str) -> set[str]:
    p = Path(na_list_path)
    if p.exists():
        return {ln.strip() for ln in open(p, encoding="utf-8") if ln.strip()}
    keys: set[str] = set()
    ap = Path(affordance_tsv)
    if ap.exists():
        for row in csv.DictReader(open(ap, newline="", encoding="utf-8"), delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid and (row.get("pred_llm") or "").strip() == "na":
                keys.add(f"{cid}|{uid}")
    return keys


def load_cache(path: str) -> dict[str, dict]:
    cache: dict[str, dict] = {}
    p = Path(path)
    if not p.exists():
        return cache
    for line in open(p, encoding="utf-8"):
        o = json.loads(line)
        k = o.get("_cache_key", "")
        if k:
            cache[k] = o
    return cache


def parse_one(text: str) -> str:
    """Parse the single-line question from one single-modality formulation call.

    Each call (FORMULATE_VIS_SYSTEM / FORMULATE_AUD_SYSTEM) is asked for exactly one
    labeled line ("Visual: ..." or "Audio: ..."). We take the first non-empty line
    and strip a leading channel/question label defensively.
    """
    for line in (text or "").strip().splitlines():
        s = line.strip()
        if not s:
            continue
        lo = s.lower()
        for pre in ("visual:", "audio:", "question:", "q:"):
            if lo.startswith(pre):
                return s[len(pre):].strip().strip('"')
        return s.strip('"')   # unlabeled first line
    return ""


def parse_triage(text: str) -> tuple[bool, str]:
    """Parse a triage call → (is_na, reason).

    Recognizes a leading 'NA[: reason]' (→ na) or 'PROBE' (→ keep). Anything
    unrecognized defaults to (False, "") — safer to PROBE than to wrongly drop a
    unit. ADR-011.
    """
    for line in (text or "").strip().splitlines():
        s = line.strip()
        if not s:
            continue
        if re.match(r'^\s*na\b', s, flags=re.I):
            reason = re.sub(r'^\s*na\b[\s:.\-—)]*', '', s, count=1, flags=re.I).strip()
            return True, reason.strip('"')
        return False, ""   # 'PROBE' or any other first line → keep
    return False, ""


def setup_parser():
    p = argparse.ArgumentParser(description="AViD Phase 2 — R5 question formulation")
    p.add_argument("--annotation-units", default=DEFAULT_ANN_UNITS)
    p.add_argument("--hypergraph",       default=DEFAULT_HYPERGRAPH)
    p.add_argument("--affordance-tsv",   default=DEFAULT_AFF_TSV)
    p.add_argument("--na-list",          default=DEFAULT_NA_LIST)
    p.add_argument("--output",           default=DEFAULT_OUTPUT)
    p.add_argument("--cache",            default="")
    p.add_argument("--model",            default=MODEL_PATH)
    p.add_argument("--tp",               type=int, default=0)
    p.add_argument("--batch-size",       type=int, default=128)
    p.add_argument("--max-tokens",       type=int, default=96)
    p.add_argument("--limit",            type=int, default=0)
    return p


def main():
    args = setup_parser().parse_args()
    out_path = Path(args.output)
    cache_path = Path(args.cache or str(out_path.parent / "cache" / "formulated_cache.jsonl"))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("AViD Phase 2 — formulate_questions.py (R5 pre-pass)")
    print(f"  Output: {out_path}")
    print(f"  Cache:  {cache_path}")
    print("=" * 60)

    na_keys = load_na_set(args.na_list, args.affordance_tsv)
    raw_units: list[dict] = []
    with open(args.annotation_units, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if not cid or not uid:
                continue
            raw_units.append({
                "claim_id":   cid, "unit_id": uid,
                "unit_type":  (row.get("unit_type") or "").strip(),
                "node_type":  (row.get("node_type") or "").strip(),
                "unit_text":  (row.get("unit_text") or "").strip(),
                "claim_text": (row.get("claim_text") or "").strip(),
                "claim_highlighted": (row.get("claim_highlighted") or "").strip(),
            })
    units, stats = filter_units(raw_units, args.hypergraph, na_keys)
    print(format_stats(stats))
    if args.limit > 0:
        units = units[:args.limit]

    cache = load_cache(str(cache_path))
    print(f"    Cache entries: {len(cache)}")

    # The model is loaded ONCE; we run TWO sweeps with it (ADR-011 + ADR-009):
    #   (1) triage   — one modality-agnostic na decision per unit (key u|triage)
    #   (2) formulate — two single-modality questions per NON-na unit (u|visual, u|audio)
    # Cache keys keep each call independently resumable.
    llm = tok = sp = None

    def ensure_llm():
        nonlocal llm, tok, sp
        if llm is not None:
            return
        import torch
        from vllm import LLM, SamplingParams
        from transformers import AutoTokenizer
        tp = args.tp if args.tp > 0 else torch.cuda.device_count()
        tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
        llm = LLM(model=args.model, trust_remote_code=True, gpu_memory_utilization=0.90,
                  tensor_parallel_size=tp, dtype="bfloat16", seed=42, max_model_len=4096,
                  disable_log_stats=True)
        sp = SamplingParams(temperature=0.0, max_tokens=args.max_tokens)

    def chat(system: str, user: str) -> str:
        msgs = [{"role": "system", "content": system},
                {"role": "user",   "content": user}]
        return tok.apply_chat_template(msgs, tokenize=False,
                                       add_generation_prompt=True, enable_thinking=False)

    def kd(u: dict) -> tuple[str, str]:
        kind = _node_kind(u["node_type"], u["unit_type"])
        return kind, _NODE_KIND_DESC.get(kind, kind)

    def run_sweep(jobs, make_prompt, make_entry, label):
        if not jobs:
            return
        ensure_llm()
        bs = args.batch_size
        n_batches = (len(jobs) + bs - 1) // bs
        with open(cache_path, "a", encoding="utf-8") as cf:
            for b_idx in range(n_batches):
                batch = jobs[b_idx * bs: (b_idx + 1) * bs]
                prompts = [make_prompt(j) for j in batch]
                print(f"  [{label}] batch {b_idx + 1}/{n_batches}: {len(batch)} ...",
                      flush=True)
                outputs = llm.generate(prompts, sampling_params=sp)
                for j, out in zip(batch, outputs):
                    raw = out.outputs[0].text.strip() if out.outputs else ""
                    entry = make_entry(j, raw)
                    cf.write(json.dumps(entry, ensure_ascii=False) + "\n")
                    cache[entry["_cache_key"]] = entry

    # ---- Sweep 1: na triage — ATOMIC nodes only (factors always probed) ----
    atoms = [u for u in units if not is_factor(u["unit_id"])]
    triage_jobs = [u for u in atoms
                   if ck(u["claim_id"], u["unit_id"], "triage") not in cache]
    print(f"    Atoms: {len(atoms)} | Factors (always probed): {len(units) - len(atoms)}")
    print(f"    Triage to run: {len(triage_jobs)} "
          f"(cached: {len(atoms) - len(triage_jobs)})")

    def triage_prompt(u):
        kind, desc = kd(u)
        return chat(TRIAGE_SYSTEM, TRIAGE_USER_TMPL.format(
            claim_text=u["claim_text"], unit_text=u["unit_text"],
            node_kind=kind, node_kind_desc=desc))

    def triage_entry(u, raw):
        is_na, reason = parse_triage(raw)
        return {"_cache_key": ck(u["claim_id"], u["unit_id"], "triage"),
                "claim_id": u["claim_id"], "unit_id": u["unit_id"],
                "na": is_na, "na_reason": reason}

    run_sweep(triage_jobs, triage_prompt, triage_entry, "triage")

    def is_na(u) -> bool:
        t = cache.get(ck(u["claim_id"], u["unit_id"], "triage"))
        return bool(t and t.get("na"))

    print(f"    Triage na: {sum(1 for u in atoms if is_na(u))} / {len(atoms)} atoms "
          f"(factors never na)")

    # ---- Sweep 2: formulate questions for NON-na units (both modalities) ----
    q_jobs = [(u, m) for u in units if not is_na(u) for m in MODALITIES
              if ck(u["claim_id"], u["unit_id"], m) not in cache]
    print(f"    Questions to formulate: {len(q_jobs)}")

    def q_prompt(job):
        u, m = job
        kind, desc = kd(u)
        return chat(_FORMULATE_SYSTEMS[m], FORMULATE_USER_TMPL.format(
            claim_text=u["claim_text"], unit_text=u["unit_text"],
            node_kind=kind, node_kind_desc=desc))

    def q_entry(job, raw):
        u, m = job
        return {"_cache_key": ck(u["claim_id"], u["unit_id"], m),
                "claim_id": u["claim_id"], "unit_id": u["unit_id"],
                "modality": m, "question": parse_one(raw)}

    run_sweep(q_jobs, q_prompt, q_entry, "formulate")

    # ---- Write output: JSONL + TSV + na report (idempotent rewrite from cache) ----
    tsv_path = out_path.with_suffix(".tsv")
    na_txt = out_path.parent / "na_units_r5.txt"
    na_tsv = out_path.parent / "na_units_r5.tsv"
    n_written = n_na = 0
    with open(out_path, "w", encoding="utf-8") as jf, \
         open(tsv_path, "w", newline="", encoding="utf-8") as tf, \
         open(na_txt, "w", encoding="utf-8") as nf, \
         open(na_tsv, "w", newline="", encoding="utf-8") as ntf:
        tw = csv.writer(tf, delimiter="\t", lineterminator="\n")
        tw.writerow(["claim_id", "unit_id", "unit_text", "node_type",
                     "na", "na_reason", "visual_question", "audio_question"])
        ntw = csv.writer(ntf, delimiter="\t", lineterminator="\n")
        ntw.writerow(["claim_id", "unit_id", "unit_text", "node_type",
                      "na_reason", "claim_text"])
        for u in units:
            t = cache.get(ck(u["claim_id"], u["unit_id"], "triage"))
            ve = cache.get(ck(u["claim_id"], u["unit_id"], "visual"))
            ae = cache.get(ck(u["claim_id"], u["unit_id"], "audio"))
            na_flag = bool(t and t.get("na"))
            if not na_flag and ve is None and ae is None:
                continue   # not processed yet
            na_reason = (t or {}).get("na_reason", "") if na_flag else ""
            vq = "" if na_flag else (ve or {}).get("question", "")
            aq = "" if na_flag else (ae or {}).get("question", "")
            jf.write(json.dumps({
                "claim_id":        u["claim_id"],
                "unit_id":         u["unit_id"],
                "unit_text":       u["unit_text"],
                "node_type":       u["node_type"],
                "na":              na_flag,
                "na_reason":       na_reason,
                "visual_question": vq,
                "audio_question":  aq,
            }, ensure_ascii=False) + "\n")
            tw.writerow([u["claim_id"], u["unit_id"], u["unit_text"], u["node_type"],
                         "true" if na_flag else "false", na_reason, vq, aq])
            n_written += 1
            if na_flag:
                nf.write(f"{u['claim_id']}|{u['unit_id']}\n")
                ntw.writerow([u["claim_id"], u["unit_id"], u["unit_text"],
                              u["node_type"], na_reason, u["claim_text"]])
                n_na += 1

    print(f"  Final output: {n_written} rows → {out_path}")
    print(f"  TSV output:   {n_written} rows → {tsv_path}")
    print(f"  na units:     {n_na} → {na_txt}  (+ reasons in {na_tsv.name})")


if __name__ == "__main__":
    main()
