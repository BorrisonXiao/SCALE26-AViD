#!/usr/bin/env python3
"""
tree_viz.py — Render an AViD CRF merged-tree as a self-contained inline SVG.

The tree drawn is the *content-node* tree the CRF operates on (from
`trees_ud.jsonl`), NOT the token-level UD arc diagram. Its node IDs and spans
map 1:1 to the gold-pilot annotation rows, so an annotator can read the
compositional structure of exactly what they are labeling:

  - function words (case / cc / mark / det …) fold into their content head as
    ‹by›-style markers (they are contracted in the CRF and not annotated);
  - edges are labelled with the CRF `rel_class` and styled by semantics:
        solid  = necessity / veto-capable (core-arg, coordination-*)
        dashed = decoupled                (modifier, oblique, root)
  - the root carries a ring; a node under negation is marked ⊘ (warn colour) —
    reinforcing the "annotate existence, the CRF flips polarity" instruction.

Pure functions, no I/O. `build_tree_svg(tree_record) -> str`.
Cycle-safe (a handful of parses contain merged-token cycles; see M0 notes).
"""

from html import escape

# ── geometry ────────────────────────────────────────────────────────────────
Y_SPACING = 74          # vertical gap between tree levels (px)
NODE_H = 34             # node box height
CHAR_W = 7.1            # approx char advance at the node font size
NODE_PAD = 18           # horizontal padding inside a node box
NODE_MIN_W = 52
NODE_MAX_W = 172        # cap; text beyond this is truncated
COL_GAP = 26            # gap between adjacent leaf columns
MARGIN = 16             # svg outer margin

# rel_class → (is_necessity, short label)
_REL_LABEL = {
    "core-arg": "core-arg",
    "coordination-and": "and",
    "coordination-or": "or",
    "modifier": "mod",
    "oblique": "obl",
    "root": "",
    "structural": "",
}
_NECESSITY = {"core-arg", "coordination-and", "coordination-or"}
_FUNC_MARKER_DEPRELS = {"case", "cc", "mark", "det", "aux", "cop"}


def _truncate(s: str, max_chars: int) -> str:
    s = " ".join(s.split())
    return s if len(s) <= max_chars else s[: max_chars - 1].rstrip() + "…"


def _node_width(label: str) -> float:
    w = len(label) * CHAR_W + NODE_PAD * 2
    return max(NODE_MIN_W, min(NODE_MAX_W, w))


def _content_children(nodes_by_id: dict) -> dict:
    """Build the *content-node* children map: functional nodes are contracted
    (a content node's parent = its nearest non-functional ancestor). Cycle-safe."""
    children: dict[str, list[str]] = {nid: [] for nid, n in nodes_by_id.items()
                                      if not n["is_functional"]}
    for nid, n in nodes_by_id.items():
        if n["is_functional"]:
            continue
        # walk up through functional parents to the nearest content ancestor
        pid = n["parent_id"]
        seen = {nid}
        while pid is not None and pid in nodes_by_id and nodes_by_id[pid]["is_functional"]:
            if pid in seen:
                pid = None
                break
            seen.add(pid)
            pid = nodes_by_id[pid]["parent_id"]
        if pid is not None and pid in children and pid != nid:
            children[pid].append(nid)
    return children


def _func_markers(nid: str, nodes_by_id: dict) -> str:
    """Collect function-word markers (case/cc/mark/…) that are children of `nid`."""
    marks = []
    for cid, c in nodes_by_id.items():
        if c["parent_id"] == nid and c["is_functional"] \
                and c.get("deprel") in _FUNC_MARKER_DEPRELS:
            marks.append((c["span"][0] if c.get("span") else 0, c["node_text"]))
    marks.sort()
    return " ".join(m[1] for m in marks)


def _layout(root: str, children: dict) -> tuple[dict, dict, int]:
    """Assign (depth, leaf-x-index) per node. Returns (depth, xidx, n_leaves).
    Iterative + cycle-safe (visited guard)."""
    depth: dict[str, int] = {}
    # BFS for depth
    q = [(root, 0)]
    seen = set()
    while q:
        nid, d = q.pop(0)
        if nid in seen:
            continue
        seen.add(nid)
        depth[nid] = d
        for c in children.get(nid, []):
            if c not in seen:
                q.append((c, d + 1))

    # post-order x assignment: leaves get sequential slots, parents centre over kids
    xidx: dict[str, float] = {}
    counter = [0]
    visited: set[str] = set()

    def visit(nid: str):
        if nid in visited:
            return
        visited.add(nid)
        kids = [c for c in children.get(nid, []) if c not in visited]
        if not kids:
            xidx[nid] = counter[0]
            counter[0] += 1
            return
        for c in kids:
            visit(c)
        placed = [xidx[c] for c in kids if c in xidx]
        xidx[nid] = sum(placed) / len(placed) if placed else counter[0]

    visit(root)
    # any nodes not reached (disconnected/cyclic) → append as extra leaf columns
    for nid in depth:
        if nid not in xidx:
            xidx[nid] = counter[0]
            counter[0] += 1
    return depth, xidx, max(counter[0], 1)


def build_tree_svg(tree: dict, highlight_prefix: str = "tn") -> str:
    """Return an inline SVG string for one tree record from trees_ud.jsonl.

    `highlight_prefix` seeds per-node element IDs (`{prefix}-{claim}-{node}`) so a
    host page can cross-highlight the annotation table. Falls back gracefully on
    malformed / empty trees.
    """
    nodes_by_id = {n["node_id"]: n for n in tree.get("nodes", [])}
    root = tree.get("root_id")
    if not nodes_by_id or root not in nodes_by_id:
        return '<svg xmlns="http://www.w3.org/2000/svg" width="120" height="24">' \
               '<text x="4" y="16" font-size="12" fill="#8b93a7">no tree</text></svg>'

    children = _content_children(nodes_by_id)
    depth, xidx, n_leaves = _layout(root, children)

    # per-node label + width
    label: dict[str, str] = {}
    width: dict[str, float] = {}
    for nid in depth:
        n = nodes_by_id[nid]
        mk = _func_markers(nid, nodes_by_id)
        main = _truncate(n["node_text"], 20)
        lab = f"‹{mk}› {main}" if mk else main
        label[nid] = lab
        width[nid] = _node_width(lab)

    pitch = max(width.values(), default=NODE_MIN_W) + COL_GAP
    max_depth = max(depth.values(), default=0)

    # pixel coords (centre of each node box)
    cx = {nid: MARGIN + xidx[nid] * pitch + pitch / 2 for nid in depth}
    cy = {nid: MARGIN + depth[nid] * Y_SPACING + NODE_H / 2 for nid in depth}

    svg_w = int(MARGIN * 2 + n_leaves * pitch)
    svg_h = int(MARGIN * 2 + max_depth * Y_SPACING + NODE_H)

    claim_id = escape(str(tree.get("claim_id", "")))
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{svg_w}" height="{svg_h}" '
        f'viewBox="0 0 {svg_w} {svg_h}" class="crftree" '
        f'font-family="system-ui,sans-serif">'
    ]

    # ── edges (drawn first, under nodes) ──
    for nid in depth:
        for c in children.get(nid, []):
            if c not in cx:
                continue
            n = nodes_by_id[c]
            rel = n["rel_class"]
            necess = rel in _NECESSITY
            x1, y1 = cx[nid], cy[nid] + NODE_H / 2
            x2, y2 = cx[c], cy[c] - NODE_H / 2
            stroke = "#6ea8fe" if necess else "#59617a"
            dash = "" if necess else ' stroke-dasharray="4 3"'
            parts.append(
                f'<line x1="{x1:.0f}" y1="{y1:.0f}" x2="{x2:.0f}" y2="{y2:.0f}" '
                f'stroke="{stroke}" stroke-width="1.6"{dash}/>'
            )
            lab = _REL_LABEL.get(rel, rel)
            if lab:
                mx, my = (x1 + x2) / 2, (y1 + y2) / 2
                tw = len(lab) * 6 + 8
                lcol = "#6ea8fe" if necess else "#8b93a7"
                parts.append(
                    f'<rect x="{mx - tw/2:.0f}" y="{my - 8:.0f}" width="{tw}" height="15" '
                    f'rx="3" fill="#141720" opacity="0.92"/>'
                    f'<text x="{mx:.0f}" y="{my + 3:.0f}" text-anchor="middle" '
                    f'font-size="10" fill="{lcol}">{escape(lab)}</text>'
                )

    # ── nodes ──
    for nid in depth:
        n = nodes_by_id[nid]
        w = width[nid]
        x = cx[nid] - w / 2
        y = cy[nid] - NODE_H / 2
        is_root = nid == root
        is_na = (not n["probed"]) or n["node_type"] in ("", None)
        negated = bool(n.get("negated"))
        # colours
        if negated:
            border, tcol = "#ffb454", "#ffd9a0"
        elif is_na:
            border, tcol = "#59617a", "#8b93a7"
        else:
            border, tcol = "#6ea8fe", "#e6e9ef"
        dash = ' stroke-dasharray="4 3"' if is_na else ""
        ring = (f'<rect x="{x-3:.0f}" y="{y-3:.0f}" width="{w+6:.0f}" height="{NODE_H+6}" '
                f'rx="9" fill="none" stroke="#4ec9a5" stroke-width="1.3"/>') if is_root else ""
        eid = f'{highlight_prefix}-{claim_id}-{escape(nid)}'
        parts.append(
            f'<g id="{eid}" class="crfnode" data-node="{escape(nid)}">'
            f'{ring}'
            f'<rect x="{x:.0f}" y="{y:.0f}" width="{w:.0f}" height="{NODE_H}" rx="7" '
            f'fill="#242833" stroke="{border}" stroke-width="1.5"{dash}/>'
            f'<text x="{cx[nid]:.0f}" y="{cy[nid]-3:.0f}" text-anchor="middle" '
            f'font-size="12" fill="{tcol}">{escape(label[nid])}</text>'
            f'<text x="{cx[nid]:.0f}" y="{cy[nid]+10:.0f}" text-anchor="middle" '
            f'font-size="9" fill="#8b93a7">{escape(nid)}'
            f'{" ⊘" if negated else ""}{" · root" if is_root else ""}</text>'
            f'</g>'
        )

    parts.append("</svg>")
    return "".join(parts)


# ── smoke test ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import json
    import sys

    path = sys.argv[1] if len(sys.argv) > 1 else \
        "/exp/cxiao/scale26/avid/exp/phase3/trees/trees_ud.jsonl"
    want = sys.argv[2] if len(sys.argv) > 2 else None
    with open(path) as f:
        for line in f:
            t = json.loads(line)
            if want and t["claim_id"] != want:
                continue
            svg = build_tree_svg(t)
            print(f"<!-- {t['claim_id']}: {t['claim_text']} -->")
            print(svg)
            if want:
                break
