"""Summarize the fixed comparison without mixing successes across prompts."""
import hashlib
import json
from collections import Counter
from pathlib import Path
from build_reviewed_compilation_report import slim

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/split_alignment_20261112'


def main():
    original={r['claim_id']:r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())}
    raw={r['claim_id']:r for r in map(json.loads,(RUN/'raw.jsonl').read_text().splitlines())}
    old_raw={r['claim_id']:r for r in map(json.loads,(ROOT/'exp/probabilistic_verification/claim_split_20261112/raw.jsonl').read_text().splitlines())}
    summary={};cases=[];recoveries=[]
    for condition,review_file in [('old_sentences','old_sentences_review.json'),('sentences','semantic_review.json')]:
        rows=list(map(json.loads,(RUN/(condition+'_results.jsonl')).read_text().splitlines()))
        reviews={r['claim_id']:r for r in json.loads((RUN/review_file).read_text())['cases']}
        for row in rows:
            review=reviews[row['claim_id']]
            assert review['artifact_sha256']==hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
            assert not review['faithful'] or row['output']['status']=='compiled'
            cid=row['claim_id']
            cases.append(dict(condition=condition,claim_id=cid,original=original[cid]['text'],
                clauses=[dict(id=c['id'],text=c['text'])for c in row['clauses']],
                component_statuses=[dict(id=c['id'],status=c['result']['status'],reason=c['result'].get('reason'))for c in row['components']],
                proposal=row.get('proposal'),alignment=row.get('alignment'),review=review,
                output=slim(row['output']),request=(raw if condition=='sentences'else old_raw)[cid]))
            if condition=='sentences' and review['faithful']:
                recoveries.append(dict(claim_id=cid,original=original[cid]['text'],clauses=row['clauses'],output=row['output'],review=review))
        parts=[c for row in rows for c in row['components']]
        summary[condition]=dict(cases=len(rows),components=len(parts),component_passes=sum(c['result']['status']=='compiled'for c in parts),
            all_components_pass=sum(len(row['components'])>=2 and all(c['result']['status']=='compiled'for c in row['components'])for row in rows),
            programs=sum(row['output']['status']=='compiled'for row in rows),faithful=sum(r['faithful']for r in reviews.values()),
            faithful_ids=[r['claim_id']for r in reviews.values()if r['faithful']],
            failures=dict(Counter(row['output'].get('code','review_rejection')for row in rows if not reviews[row['claim_id']]['faithful'])))
    summary['previous_all_links']=dict(cases=31,components=77,component_passes=65,all_components_pass=20,programs=6,faithful=0)
    summary['corpus']=json.loads((RUN/'corpus_summary.json').read_text())
    summary['limits']=['Previously inspected development data; compiler-author review, not independent human gold.','One fixed sentences-only condition for corpus substitution, with exact-output review; no per-claim prompt selection.','No whole-corpus semantic accuracy, media verification, native DeepProbLog inference or relation training result.']
    for name,digest in json.loads((RUN/'compiler_freeze.json').read_text())['source_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    for name,value in [('summary.json',summary),('cases.json',cases),('recoveries.json',recoveries)]:
        (RUN/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
