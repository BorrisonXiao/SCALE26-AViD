#!/usr/bin/env python3
"""
Generate an HTML report visualizing AViD parse trees with verification results.

Output: /exp/cxiao/scale26/avid/exp/reports/parse_tree_report.html
"""

import csv
import json
import html
import re
from collections import defaultdict
from pathlib import Path
import random

# ─── Paths ──────────────────────────────────────────────────────────────────
HYPERGRAPH   = Path('/exp/cxiao/scale26/avid/exp/phase1/hypergraph.jsonl')
ANN_UNITS    = Path('/exp/cxiao/scale26/avid/exp/phase1/reports/annotation_units.tsv')
SUPPORT_TSV  = Path('/exp/cxiao/scale26/avid/exp/phase2/prompt_ablation/r5e/support_readable.tsv')
OUT_HTML     = Path('/exp/cxiao/scale26/avid/exp/reports/parse_tree_report.html')
OUT_HTML.parent.mkdir(parents=True, exist_ok=True)

# ─── Color scheme ───────────────────────────────────────────────────────────
# visual / audio verdict → CSS class name
def verdict_class(visual: str, audio: str, status: str) -> str:
    if status == 'unsupported':
        return 'ch-unsupported'
    if visual in ('other',) and audio in ('speech', 'other'):
        return 'ch-both'
    if visual == 'other':
        return 'ch-visual-other'
    if visual == 'text':
        return 'ch-visual-ocr'
    if audio == 'speech':
        return 'ch-audio-speech'
    if audio == 'other':
        return 'ch-audio-other'
    return 'ch-unsupported'

CHANNEL_LABEL = {
    'ch-visual-other':  'visual',
    'ch-visual-ocr':    'visual-OCR',
    'ch-audio-speech':  'audio-speech',
    'ch-audio-other':   'audio-other',
    'ch-both':          'visual+audio',
    'ch-unsupported':   'unsupported',
}

# ─── Load data ───────────────────────────────────────────────────────────────
print("Loading hypergraph …")
hypergraph: dict = {}   # claim_id → {claim_text, parse, nodes}
with open(HYPERGRAPH) as f:
    for line in f:
        e = json.loads(line)
        hypergraph[e['claim_id']] = {
            'claim_text': e['claim_text'],
            'parse': e['parse'],
            'nodes': e.get('nodes', []),
        }

print("Loading annotation units …")
ann_units: dict = defaultdict(list)   # claim_id → list[dict]
with open(ANN_UNITS) as f:
    for row in csv.DictReader(f, delimiter='\t'):
        ann_units[row['claim_id']].append(row)

print("Loading support results …")
support: dict = defaultdict(list)     # claim_id → list[dict]
with open(SUPPORT_TSV) as f:
    for row in csv.DictReader(f, delimiter='\t'):
        support[row['claim_id']].append(row)

print("Loading manifest …")
MANIFEST  = Path('/exp/cxiao/scale26/probing/exp/step1/manifests/manifest.jsonl')
VIDEO_DIR = '/exp/cxiao/scale26/data/extracted/microvent/videos'
WAV_DIR   = '/exp/cxiao/scale26/avid/exp/phase2/media_cache/wav'
claim_chunks: dict = {}   # claim_id → list of chunk stems (no .mp4)
with open(MANIFEST) as f:
    for line in f:
        e = json.loads(line)
        cid = f"{e['topic_id']}_{e['claim_index']}"
        claim_chunks[cid] = [c.replace('.mp4', '') for c in e.get('chunks', [])]

# ─── Build token char-spans from parse ───────────────────────────────────────
def token_char_spans(claim_text: str, parse_tokens: list) -> list:
    """Return [(start, end)] character spans for each parse token."""
    spans = []
    pos = 0
    for tok in parse_tokens:
        t = tok['text']
        idx = claim_text.find(t, pos)
        if idx == -1:               # fallback: just advance
            idx = pos
        spans.append((idx, idx + len(t)))
        pos = idx + len(t)
    return spans

def parse_highlighted(claim_text: str, highlighted: str) -> tuple:
    """Parse **...** marker → (char_start, char_end) in claim_text.
    Falls back to full-claim span if not found.
    """
    m = re.search(r'\*\*(.+?)\*\*', highlighted, re.DOTALL)
    if not m:
        return (0, len(claim_text))
    span_text = m.group(1)
    idx = claim_text.find(span_text)
    if idx == -1:
        return (0, len(claim_text))
    return (idx, idx + len(span_text))

def unit_tok_indices(char_span: tuple, tok_spans: list) -> list:
    """Return token indices that overlap with char_span."""
    s, e = char_span
    return [i for i, (ts, te) in enumerate(tok_spans) if ts < e and te > s]

# ─── SVG dependency tree renderer ────────────────────────────────────────────
TOK_W = 80          # token box width (px)
TOK_H = 30          # token box height
ARC_BASE_Y = 10     # y at which arcs land (above token row)
MIN_ARC_H = 18
ARC_H_PER_SPAN = 22
MAX_ARC_H = 130
UNIT_BAR_H = 8      # height of unit annotation bar
UNIT_BAR_GAP = 4    # gap between bars

def _arc_h(span: int) -> int:
    return min(MIN_ARC_H + span * ARC_H_PER_SPAN, MAX_ARC_H)

def render_dep_tree(claim_id: str, claim_text: str, parse_tokens: list,
                    units_with_verdicts: list) -> str:
    """Return an SVG string for the dependency arc diagram."""
    n = len(parse_tokens)
    if n == 0:
        return '<svg><text x="5" y="20">No parse data</text></svg>'

    tok_spans = token_char_spans(claim_text, parse_tokens)

    # Map token index → unit verdict class (use smallest-span unit for conflicts)
    tok_class: dict = {}   # tok_idx → verdict_class str
    tok_unit_id: dict = {} # tok_idx → unit index in units_with_verdicts
    for uid, u in enumerate(units_with_verdicts):
        toks = u.get('tok_indices', [])
        span_len = len(toks)
        for ti in toks:
            if ti not in tok_class:
                tok_class[ti] = u['cls']
                tok_unit_id[ti] = (span_len, uid)
            else:
                prev_len, _ = tok_unit_id[ti]
                if span_len < prev_len:
                    tok_class[ti] = u['cls']
                    tok_unit_id[ti] = (span_len, uid)

    # Compute arc area height
    arc_heights = []
    for tok in parse_tokens:
        if tok['deprel'] == 'root':
            continue
        span = abs(tok['i'] - tok['head'])
        arc_heights.append(_arc_h(span))
    max_arc = max(arc_heights, default=40)
    arc_area_h = max_arc + ARC_BASE_Y + 10

    # Unit bars area
    n_units = len([u for u in units_with_verdicts if u.get('tok_indices')])
    unit_area_h = n_units * (UNIT_BAR_H + UNIT_BAR_GAP) + 16

    tok_row_y = arc_area_h
    svg_h = tok_row_y + TOK_H + unit_area_h
    svg_w = n * TOK_W + 20

    lines = []
    lines.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{svg_w}" height="{svg_h}" '
                 f'class="deptree" viewBox="0 0 {svg_w} {svg_h}">')

    # CSS inside SVG
    lines.append('''<defs><style>
.tok-box { stroke:#888; stroke-width:1; }
.tok-text { font:12px monospace; fill:#111; }
.pos-text { font:9px sans-serif; fill:#888; }
.arc { fill:none; stroke:#666; stroke-width:1.4; }
.arc-lbl { font:9px sans-serif; fill:#555; }
.ch-visual-other  { fill:#BBDEFB; }
.ch-visual-ocr    { fill:#B3E5FC; }
.ch-audio-speech  { fill:#C8E6C9; }
.ch-audio-other   { fill:#FFE0B2; }
.ch-both          { fill:#E1BEE7; }
.ch-unsupported   { fill:#FFCDD2; }
.ch-none          { fill:#F5F5F5; }
.unit-bar { opacity:0.85; rx:2; ry:2; }
.unit-bar-lbl { font:8px sans-serif; fill:#fff; dominant-baseline:central; }
.bar-visual-other  { fill:#1565C0; }
.bar-visual-ocr    { fill:#0288D1; }
.bar-audio-speech  { fill:#1B5E20; }
.bar-audio-other   { fill:#E65100; }
.bar-both          { fill:#6A1B9A; }
.bar-unsupported   { fill:#B71C1C; }
</style></defs>''')

    # ── Token boxes ──
    for tok in parse_tokens:
        ti = tok['i']
        x = 10 + ti * TOK_W
        y = tok_row_y
        cls = tok_class.get(ti, 'ch-none')
        word = html.escape(tok['text'])
        upos = tok.get('upos', '')
        lines.append(
            f'<rect x="{x}" y="{y}" width="{TOK_W-4}" height="{TOK_H}" rx="4" ry="4" class="tok-box {cls}"/>'
        )
        lines.append(
            f'<text x="{x + (TOK_W-4)//2}" y="{y + 16}" text-anchor="middle" class="tok-text">{word}</text>'
        )
        lines.append(
            f'<text x="{x + (TOK_W-4)//2}" y="{y + 27}" text-anchor="middle" class="pos-text">{upos}</text>'
        )

    # ── Dependency arcs ──
    for tok in parse_tokens:
        if tok['deprel'] == 'root':
            # Draw a small downward arrow or crown marker above root token
            ri = tok['i']
            rx = 10 + ri * TOK_W + (TOK_W - 4) // 2
            ry = tok_row_y
            lines.append(
                f'<text x="{rx}" y="{ry - 3}" text-anchor="middle" '
                f'class="arc-lbl" fill="#999">ROOT</text>'
            )
            continue
        src = tok['i']
        dst = tok['head']
        dep = html.escape(tok['deprel'])
        span = abs(src - dst)
        ah = _arc_h(span)
        x1 = 10 + src * TOK_W + (TOK_W - 4) // 2
        x2 = 10 + dst * TOK_W + (TOK_W - 4) // 2
        base_y = tok_row_y
        cy = base_y - ah
        # Quadratic bezier: M x1 base_y Q cx cy x2 base_y
        cx = (x1 + x2) / 2
        mid_x = cx
        mid_y = cy + ah * 0.3  # midpoint of arc for label
        # Arrow direction marker
        arrow = '→' if src < dst else '←'
        lines.append(
            f'<path d="M {x1} {base_y} Q {cx} {cy} {x2} {base_y}" class="arc"/>'
        )
        lines.append(
            f'<text x="{mid_x:.0f}" y="{mid_y:.0f}" text-anchor="middle" class="arc-lbl">'
            f'{dep}</text>'
        )

    # ── Unit annotation bars (below token row) ──
    bar_y = tok_row_y + TOK_H + 6
    bar_cls_map = {
        'ch-visual-other': 'bar-visual-other',
        'ch-visual-ocr':   'bar-visual-ocr',
        'ch-audio-speech': 'bar-audio-speech',
        'ch-audio-other':  'bar-audio-other',
        'ch-both':         'bar-both',
        'ch-unsupported':  'bar-unsupported',
    }
    for u in units_with_verdicts:
        toks = u.get('tok_indices', [])
        if not toks:
            continue
        t_min = min(toks)
        t_max = max(toks)
        bx = 10 + t_min * TOK_W + 2
        bw = (t_max - t_min + 1) * TOK_W - 8
        barcls = bar_cls_map.get(u['cls'], 'bar-unsupported')
        lbl = html.escape(u['cls'].replace('ch-', '').replace('-', ' '))
        data_unit = html.escape(u['unit_text'][:40])
        lines.append(
            f'<rect x="{bx}" y="{bar_y}" width="{bw}" height="{UNIT_BAR_H}" '
            f'class="unit-bar {barcls}" data-unit="{data_unit}"/>'
        )
        if bw > 30:
            lines.append(
                f'<text x="{bx + 3}" y="{bar_y + UNIT_BAR_H//2 + 1}" class="unit-bar-lbl">{lbl}</text>'
            )
        bar_y += UNIT_BAR_H + UNIT_BAR_GAP

    lines.append('</svg>')
    return '\n'.join(lines)

# ─── Build unit verdict map ───────────────────────────────────────────────────
def get_units_with_verdicts(claim_id: str) -> list:
    """Return list of unit dicts with tok_indices + verdict class."""
    claim_data = hypergraph.get(claim_id)
    if not claim_data:
        return []
    claim_text = claim_data['claim_text']
    parse_tokens = claim_data['parse']
    tok_spans = token_char_spans(claim_text, parse_tokens)

    # Build support lookup: unit_text → row
    supp_by_unit: dict = {}
    for row in support.get(claim_id, []):
        supp_by_unit[row['unit']] = row

    result = []
    for au in ann_units.get(claim_id, []):
        unit_text = au['unit_text']
        highlighted = au.get('claim_highlighted', '')
        char_span = parse_highlighted(claim_text, highlighted)
        toks = unit_tok_indices(char_span, tok_spans)

        supp = supp_by_unit.get(unit_text)
        if supp:
            vis = supp.get('visual', 'no')
            aud = supp.get('audio', 'no')
            status = supp.get('status', 'unsupported')
            cls = verdict_class(vis, aud, status)
        else:
            vis, aud, status, cls = 'no', 'no', 'na', 'ch-none'

        result.append({
            'unit_id': au['unit_id'],
            'unit_text': unit_text,
            'unit_type': au['unit_type'],
            'node_type': au['node_type'],
            'highlighted': highlighted,
            'visual': vis,
            'audio': aud,
            'status': status,
            'cls': cls,
            'tok_indices': toks,
            'visual_q': supp.get('visual_q', '') if supp else '',
            'visual_why': supp.get('visual_why', '') if supp else '',
            'audio_q': supp.get('audio_q', '') if supp else '',
            'audio_why': supp.get('audio_why', '') if supp else '',
        })
    return result

# ─── Sample claims ───────────────────────────────────────────────────────────
# 3 claims per topic, prefer mix of supported/unsupported
print("Sampling representative claims …")
random.seed(42)

topic_claim_ids: dict = defaultdict(list)
for cid in support:
    topic = cid.rsplit('_', 1)[0]
    topic_claim_ids[topic].append(cid)

selected_claims = []
for topic, cids in sorted(topic_claim_ids.items()):
    # Sort by claim index for determinism
    cids_sorted = sorted(cids, key=lambda c: int(c.rsplit('_', 1)[1]))
    # Take up to 3, spread across range
    n = len(cids_sorted)
    if n <= 3:
        chosen = cids_sorted
    else:
        idxs = [0, n // 2, n - 1]
        chosen = [cids_sorted[i] for i in idxs]
    selected_claims.extend(chosen)

print(f"  Selected {len(selected_claims)} claims from {len(topic_claim_ids)} topics")

# ─── Compute overall stats ───────────────────────────────────────────────────
total_units = sum(len(v) for v in support.values())
status_counts: dict = defaultdict(int)
visual_counts: dict = defaultdict(int)
audio_counts: dict = defaultdict(int)
for rows in support.values():
    for r in rows:
        status_counts[r['status']] += 1
        visual_counts[r['visual']] += 1
        audio_counts[r['audio']] += 1

# ─── HTML template helpers ────────────────────────────────────────────────────
def pct(num, denom):
    return f"{100*num/denom:.1f}%" if denom else "0%"

def render_claim_card(claim_id: str) -> str:
    """Return HTML block for one claim."""
    claim_data = hypergraph.get(claim_id)
    if not claim_data:
        return ''
    claim_text = claim_data['claim_text']
    parse_tokens = claim_data['parse']
    topic_id = claim_id.rsplit('_', 1)[0]

    units = get_units_with_verdicts(claim_id)
    supp_rows = support.get(claim_id, [])

    svg = render_dep_tree(claim_id, claim_text, parse_tokens, units)

    # Media links (video + audio)
    chunks = claim_chunks.get(claim_id, [])
    media_html = ''
    if chunks:
        parts = []
        for ch in chunks:
            parts.append(
                f'<a href="file://{VIDEO_DIR}/{ch}.mp4" class="media-link vid-link">&#9654; video</a>'
                f'<a href="file://{WAV_DIR}/{ch}.wav"  class="media-link wav-link">&#9836; audio</a>'
                f'<span class="chunk-id">{ch}</span>'
            )
        media_html = '<div class="media-links">' + ' &nbsp; '.join(parts) + '</div>'

    # Unit table rows
    unit_rows = []
    for u in units:
        if u['cls'] == 'ch-none':
            status_badge = '<span class="badge badge-na">na / filtered</span>'
        else:
            status_badge = f'<span class="badge badge-{u["status"]}">{u["status"]}</span>'
        vis_cell = u['visual'] if u['visual'] != 'no' else '–'
        aud_cell = u['audio'] if u['audio'] != 'no' else '–'
        vq = html.escape(u['visual_q'][:120]) if u['visual_q'] else ''
        vw = html.escape(u['visual_why'])      if u['visual_why'] else ''
        aq = html.escape(u['audio_q'][:120])   if u['audio_q'] else ''
        aw = html.escape(u['audio_why'])        if u['audio_why'] else ''

        vis_td = f'<td class="ch-cell {u["cls"]}">'
        vis_td += f'<span class="verdict-lbl">{vis_cell}</span>'
        if vq:
            vis_td += f'<div class="why-inline"><span class="ql">Q</span> {vq}</div>'
        if vw:
            vis_td += f'<div class="why-inline ans"><span class="al">A</span> {vw}</div>'
        vis_td += '</td>'

        aud_td = '<td class="ch-cell">'
        aud_td += f'<span class="verdict-lbl">{aud_cell}</span>'
        if aq:
            aud_td += f'<div class="why-inline"><span class="ql">Q</span> {aq}</div>'
        if aw:
            aud_td += f'<div class="why-inline ans"><span class="al">A</span> {aw}</div>'
        aud_td += '</td>'

        unit_rows.append(
            f'<tr class="unit-row {u["cls"]}">'
            f'<td class="unit-text-cell">{html.escape(u["unit_text"])}</td>'
            f'<td class="type-cell">{html.escape(u["unit_type"])}</td>'
            f'{vis_td}'
            f'{aud_td}'
            f'<td>{status_badge}</td>'
            f'</tr>'
        )
    unit_table = '\n'.join(unit_rows)

    # Channel distribution pill
    supp_n = sum(1 for r in supp_rows if r['status'] == 'supported')
    unsupp_n = len(supp_rows) - supp_n
    dist_html = (
        f'<span class="pill pill-supported">{supp_n} supported</span> '
        f'<span class="pill pill-unsupported">{unsupp_n} unsupported</span>'
    )

    return f'''
<div class="claim-card" data-topic="{html.escape(topic_id)}" data-claim="{html.escape(claim_id)}">
  <div class="claim-header">
    <span class="claim-id">{html.escape(claim_id)}</span>
    {dist_html}
  </div>
  <div class="claim-text">"{html.escape(claim_text)}"</div>
  {media_html}
  <div class="tree-scroll">
    {svg}
  </div>
  <details class="unit-details">
    <summary>Unit verification table ({len(units)} units)</summary>
    <table class="unit-table">
      <thead>
        <tr>
          <th>Unit text</th><th>Type</th>
          <th>Visual</th>
          <th>Audio</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        {unit_table}
      </tbody>
    </table>
  </details>
</div>'''

# ─── Render all claim cards ───────────────────────────────────────────────────
print("Rendering claim cards …")
cards_html_parts = []
for cid in selected_claims:
    cards_html_parts.append(render_claim_card(cid))
cards_html = '\n'.join(cards_html_parts)

# ─── Stats summary ────────────────────────────────────────────────────────────
total_claims_count = len(support)
total_units_count = total_units
supp_total = status_counts.get('supported', 0)
unsupp_total = status_counts.get('unsupported', 0)

stats_html = f'''
<div class="stats-grid">
  <div class="stat-box">
    <div class="stat-num">{total_claims_count:,}</div>
    <div class="stat-lbl">verified claims</div>
  </div>
  <div class="stat-box">
    <div class="stat-num">{total_units_count:,}</div>
    <div class="stat-lbl">annotation units</div>
  </div>
  <div class="stat-box stat-supported">
    <div class="stat-num">{pct(supp_total, total_units_count)}</div>
    <div class="stat-lbl">supported ({supp_total:,})</div>
  </div>
  <div class="stat-box stat-unsupported">
    <div class="stat-num">{pct(unsupp_total, total_units_count)}</div>
    <div class="stat-lbl">unsupported ({unsupp_total:,})</div>
  </div>
</div>
<div class="channel-breakdown">
  <div class="cb-section"><b>Visual channel:</b>
    <span class="pill vis-other">visual_other {pct(visual_counts.get("other",0), total_units_count)}</span>
    <span class="pill vis-ocr">visual_ocr {pct(visual_counts.get("text",0), total_units_count)}</span>
    <span class="pill vis-no">visual=no {pct(visual_counts.get("no",0), total_units_count)}</span>
  </div>
  <div class="cb-section"><b>Audio channel:</b>
    <span class="pill aud-speech">audio_speech {pct(audio_counts.get("speech",0), total_units_count)}</span>
    <span class="pill aud-other">audio_other {pct(audio_counts.get("other",0), total_units_count)}</span>
    <span class="pill aud-no">audio=no {pct(audio_counts.get("no",0), total_units_count)}</span>
  </div>
</div>
<div class="legend">
  <b>Parse tree color legend:</b>
  <span class="legend-box ch-visual-other">visual_other</span>
  <span class="legend-box ch-visual-ocr">visual_ocr</span>
  <span class="legend-box ch-audio-speech">audio_speech</span>
  <span class="legend-box ch-audio-other">audio_other</span>
  <span class="legend-box ch-both">visual+audio</span>
  <span class="legend-box ch-unsupported">unsupported</span>
  <span class="legend-box ch-none">filtered / na</span>
  <br>
  <span style="font-size:11px;color:#666">Token background = most-specific annotation unit that covers it.
  Colored bars below tokens = each unit's channel.
  Unit table (expandable per card) shows Q/A rationale inline for each unit.</span>
</div>'''

# ─── Full HTML ────────────────────────────────────────────────────────────────
_topic_options = '\n'.join(
    f'<option value="{t}">{t}</option>'
    for t in sorted(topic_claim_ids.keys())
)

HTML = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AViD Parse Tree Report — r5e Verification Results</title>
<style>
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ font-family: system-ui, sans-serif; background: #FAFAFA; color: #222; padding: 20px; }}
h1 {{ font-size: 1.4rem; margin-bottom: 6px; color: #1a237e; }}
.subtitle {{ font-size:0.9rem; color:#555; margin-bottom:18px; }}

/* Stats */
.stats-grid {{ display:flex; gap:12px; margin-bottom:14px; flex-wrap:wrap; }}
.stat-box {{ background:#fff; border:1px solid #ddd; border-radius:8px; padding:12px 18px; min-width:120px; text-align:center; }}
.stat-num {{ font-size:1.6rem; font-weight:700; color:#1565C0; }}
.stat-lbl {{ font-size:0.78rem; color:#666; }}
.stat-supported .stat-num {{ color:#2E7D32; }}
.stat-unsupported .stat-num {{ color:#C62828; }}

.channel-breakdown {{ font-size:0.85rem; margin-bottom:10px; }}
.cb-section {{ margin-bottom:4px; }}
.pill {{ display:inline-block; border-radius:10px; padding:1px 8px; font-size:0.78rem; margin:2px; color:#fff; }}
.vis-other {{ background:#1565C0; }}
.vis-ocr   {{ background:#0288D1; }}
.vis-no    {{ background:#90A4AE; }}
.aud-speech {{ background:#2E7D32; }}
.aud-other  {{ background:#E65100; }}
.aud-no     {{ background:#90A4AE; }}
.pill-supported   {{ background:#2E7D32; font-size:0.75rem; padding:1px 6px; border-radius:8px; color:#fff; }}
.pill-unsupported {{ background:#C62828; font-size:0.75rem; padding:1px 6px; border-radius:8px; color:#fff; }}

/* Legend */
.legend {{ font-size:0.8rem; margin:10px 0 18px 0; }}
.legend-box {{ display:inline-block; border-radius:3px; padding:1px 6px; margin:2px; border:1px solid #aaa; }}
.ch-visual-other {{ background:#BBDEFB; }}
.ch-visual-ocr   {{ background:#B3E5FC; }}
.ch-audio-speech {{ background:#C8E6C9; }}
.ch-audio-other  {{ background:#FFE0B2; }}
.ch-both         {{ background:#E1BEE7; }}
.ch-unsupported  {{ background:#FFCDD2; }}
.ch-none         {{ background:#F5F5F5; }}

/* Search */
.search-bar {{ margin-bottom:18px; display:flex; gap:10px; align-items:center; flex-wrap:wrap; }}
.search-bar input {{ border:1px solid #ccc; border-radius:6px; padding:6px 10px; font-size:0.9rem; width:280px; }}
.search-bar select {{ border:1px solid #ccc; border-radius:6px; padding:6px 8px; font-size:0.9rem; }}
.search-bar label {{ font-size:0.85rem; color:#555; }}

/* Claim cards */
.claim-card {{
  background:#fff; border:1px solid #E0E0E0; border-radius:8px;
  margin-bottom:22px; padding:14px 16px;
  box-shadow:0 1px 3px rgba(0,0,0,.06);
}}
.claim-card[hidden] {{ display:none; }}
.claim-header {{ display:flex; align-items:center; gap:10px; margin-bottom:8px; }}
.claim-id {{ font-family:monospace; font-size:0.78rem; color:#888; }}
.claim-text {{ font-size:0.95rem; color:#333; margin-bottom:10px;
               background:#F8F8F8; border-left:3px solid #90CAF9;
               padding:6px 10px; border-radius:3px; }}

/* Parse tree */
.tree-scroll {{ overflow-x:auto; margin-bottom:10px; }}
.deptree {{ display:block; }}

/* Media links */
.media-links {{ margin-bottom:10px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }}
.media-link {{ display:inline-block; border-radius:5px; padding:3px 9px;
               font-size:0.78rem; font-weight:500; text-decoration:none; }}
.vid-link {{ background:#E3F2FD; color:#0D47A1; border:1px solid #90CAF9; }}
.vid-link:hover {{ background:#BBDEFB; }}
.wav-link {{ background:#E8F5E9; color:#1B5E20; border:1px solid #A5D6A7; }}
.wav-link:hover {{ background:#C8E6C9; }}
.chunk-id {{ font-family:monospace; font-size:0.72rem; color:#AAA; }}

/* Unit table */
.unit-details {{ margin-top:6px; }}
.unit-details summary {{ cursor:pointer; font-size:0.84rem; color:#555; padding:4px 0; }}
.unit-table {{ width:100%; border-collapse:collapse; font-size:0.82rem; margin-top:6px; }}
.unit-table th {{ background:#EEE; padding:5px 8px; text-align:left; font-weight:600;
                  white-space:nowrap; }}
.unit-table td {{ padding:5px 8px; border-bottom:1px solid #F0F0F0; vertical-align:top; }}
.unit-text-cell {{ font-family:monospace; max-width:200px; word-break:break-word; }}
.type-cell {{ color:#888; font-size:0.76rem; max-width:120px; }}
.ch-cell {{ vertical-align:top; }}
.verdict-lbl {{ font-weight:600; font-size:0.8rem; }}
.why-inline {{ font-size:0.76rem; color:#555; margin-top:2px; line-height:1.4; }}
.why-inline.ans {{ color:#333; }}
.ql {{ display:inline-block; background:#E3F2FD; color:#0D47A1; border-radius:3px;
       font-size:0.68rem; font-weight:700; padding:0 4px; margin-right:2px; }}
.al {{ display:inline-block; background:#E8F5E9; color:#1B5E20; border-radius:3px;
       font-size:0.68rem; font-weight:700; padding:0 4px; margin-right:2px; }}
.badge {{ display:inline-block; border-radius:10px; padding:1px 7px; font-size:0.75rem; font-weight:600; }}
.badge-supported   {{ background:#C8E6C9; color:#1B5E20; }}
.badge-unsupported {{ background:#FFCDD2; color:#B71C1C; }}
.badge-na          {{ background:#EEE; color:#888; }}

/* Row highlight colors  */
.unit-row.ch-visual-other {{ background:#EEF6FF; }}
.unit-row.ch-visual-ocr   {{ background:#E8F5FF; }}
.unit-row.ch-audio-speech {{ background:#F0FFF0; }}
.unit-row.ch-audio-other  {{ background:#FFF8EE; }}
.unit-row.ch-both         {{ background:#F8F0FF; }}
.unit-row.ch-unsupported  {{ background:#FFF5F5; }}

/* Count label */
#count-label {{ font-size:0.82rem; color:#888; margin-bottom:8px; }}
</style>
</head>
<body>
<h1>AViD Parse Tree Report</h1>
<p class="subtitle">
  Dependency parse trees with per-unit AV verification results (r5e, v6).
  Each token is colored by the verification verdict of the most specific
  annotation unit that covers it. Colored bars below tokens = each unit's channel.
</p>

{stats_html}

<div class="search-bar">
  <label>Search claim text:
    <input type="text" id="search-box" placeholder="e.g. protesters, fire, Ukraine …"
           oninput="filterCards()">
  </label>
  <label>Topic:
    <select id="topic-select" onchange="filterCards()">
      <option value="">All topics</option>
      {_topic_options}
    </select>
  </label>
  <label>Status:
    <select id="status-select" onchange="filterCards()">
      <option value="">All</option>
      <option value="supported">Has supported units</option>
      <option value="unsupported">All unsupported</option>
    </select>
  </label>
</div>
<div id="count-label"></div>

<div id="cards-container">
{cards_html}
</div>

<script>
function filterCards() {{
  const q = document.getElementById('search-box').value.toLowerCase();
  const topic = document.getElementById('topic-select').value;
  const status = document.getElementById('status-select').value;
  const cards = document.querySelectorAll('.claim-card');
  let visible = 0;
  cards.forEach(c => {{
    const claimText = (c.querySelector('.claim-text') || {{}}).textContent || '';
    const cardTopic = c.dataset.topic || '';
    const cardClaim = c.dataset.claim || '';
    const pills = c.querySelectorAll('.pill-supported, .pill-unsupported');
    const hasSup = [...pills].some(p => p.classList.contains('pill-supported') &&
                                        parseInt(p.textContent) > 0);
    const show = (!q || claimText.toLowerCase().includes(q) || cardClaim.toLowerCase().includes(q))
              && (!topic || cardTopic === topic)
              && (!status
                  || (status === 'supported' && hasSup)
                  || (status === 'unsupported' && !hasSup));
    c.hidden = !show;
    if (show) visible++;
  }});
  document.getElementById('count-label').textContent =
    `Showing ${{visible}} of ${{cards.length}} sampled claims`;
}}
filterCards();
</script>
</body>
</html>'''

# ─── Write output ─────────────────────────────────────────────────────────────
print(f"Writing {OUT_HTML} …")
OUT_HTML.write_text(HTML, encoding='utf-8')
size_kb = OUT_HTML.stat().st_size // 1024
print(f"Done. File size: {size_kb} KB")
print(f"Report: {OUT_HTML}")
