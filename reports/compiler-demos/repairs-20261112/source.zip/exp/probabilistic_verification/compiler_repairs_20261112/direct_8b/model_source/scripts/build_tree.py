#!/usr/bin/env python3
"""
AViD Phase 3 — M0 Step 1: Build UD dependency trees from hypergraph.

Reads exp/phase1/hypergraph.jsonl (2,375 claims); per claim:
  - builds a rooted dependency tree over the hypergraph content nodes;
  - marks structural operators (structural deprels + Phase-1 operator node_types
    relation-op/logical-op/coord-op → contract), negation scopes (detected by
    LEMMA — UD v2 dropped the "neg" deprel), and unprobeable content
    (pronoun/uuid/light-verb → uniform emission);
  - computes char-span and subtree char-span for each node;
  - emits the tree skeleton to exp/phase3/trees/trees_ud.jsonl;
  - emits probed nodes (content, non-functional, non-na) in annotation-units
    schema to exp/phase3/nodes/tree_units_ud.tsv (for M2+ GPU probing).

Usage:
    python scripts/build_tree.py [--hypergraph PATH] [--output-trees PATH]
                                  [--output-tsv PATH] [--limit N]
"""

import argparse
import csv
import json
import re
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HYPERGRAPH = "/exp/cxiao/scale26/avid/exp/phase1/hypergraph.jsonl"
OUT_TREES = "/exp/cxiao/scale26/avid/exp/phase3/trees/trees_ud.jsonl"
OUT_TSV = "/exp/cxiao/scale26/avid/exp/phase3/nodes/tree_units_ud.tsv"

TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted", "gold_channels", "notes",
]

# Negation lemmas (from parse_claims.py)
NEG_LEMMAS = frozenset({
    "not", "never", "no", "n't", "neither", "nor", "without", "hardly",
})

# Light / copular verbs → unprobeable content (from unit_filters.py)
LIGHT_VERB_LEMMAS = frozenset({
    "be", "do", "go", "have", "get", "make",
    "take", "come", "become", "seem", "appear",
})

# UD deprels that mark structural / functional tokens → contract (no CRF variable)
STRUCTURAL_DEPRELS = frozenset({
    "aux", "aux:pass", "cop",
    "case", "det", "punct", "mark",
    "cc", "expl",
    "dep",                     # catch-all fallback
    "fixed",                   # fixed multi-word expressions
})

# UD deprels that map to core-arg rel_class (necessity edges)
CORE_ARG_DEPRELS = frozenset({
    "nsubj", "nsubj:pass",
    "obj", "iobj",
    "csubj", "csubj:pass",
    "ccomp", "xcomp",
    "acl:relcl",
    "obl:agent",               # passive agent is a required argument
})

# Modifier deprels (ψ = 1; child support reported but not gated)
MODIFIER_DEPRELS = frozenset({
    "amod", "advmod", "nummod", "acl", "appos",
})

# Oblique / adjunct deprels (ψ = 1; child entity is its own node)
OBLIQUE_DEPRELS = frozenset({
    "obl", "nmod", "advcl",
})

# Deprels of children that are their OWN probed unit (arguments, obliques, clausal,
# coordination, apposition) → NOT folded into a node's content/unit span. Keeps each
# node's unit its TIGHT head phrase: det/case/amod/compound/nummod/flat DO fold in;
# these do NOT. Without this gate a copular root swallows its subject ("John Torpey is
# the director") and an obl swallows a trailing nmod ("from the typhoon in W. Alaska").
# Only the content/unit span is gated; the full subtree_span is unchanged.
UNIT_BOUNDARY_DEPRELS = frozenset({
    "nsubj", "nsubj:pass", "csubj", "csubj:pass",
    "obj", "iobj",
    "obl", "obl:agent", "obl:arg", "obl:tmod", "obl:npmod",
    "nmod", "nmod:tmod", "nmod:npmod", "nmod:poss",
    "acl", "acl:relcl", "appos",
    "ccomp", "xcomp", "advcl", "conj", "parataxis", "dislocated", "list", "orphan",
})

# Bare-modifier deprels whose content folds into the HEAD unit → NOT separately probed.
# A bare adjective/adverb/number has no audio-visual truth value alone ("is 'clear'
# present?") and its content is already in the head's unit ("clear skies" contains
# "clear"; "Blue Ghost Mission 1" / "Robot 1" contains "1"; "2 boats" contains "2").
# 85% of such units were strictly nested in their head's unit (bugs.md 2026-07-20).
# Roots (predicate adjectives, e.g. "the skies are clear") never carry these deprels,
# so they are unaffected and still surface as the full claim.
MODIFIER_NOPROBE_DEPRELS = frozenset({"amod", "advmod", "nummod"})

# Merge deprels (already handled in hypergraph node grouping)
MERGE_DEPRELS = frozenset({
    "compound", "flat", "flat:name", "flat:foreign",
})

# Phase-1 operator node_types → structural operators (never probed; contracted).
# Composition semantics live in the edge potentials (rel_class), not in probing
# the operator token itself. Aligning to the Phase-1 taxonomy is robust to UD
# deprel drift (UD v2 dropped "neg"; particles surface as compound:prt). ADR-015.
OPERATOR_NODE_TYPES = frozenset({"relation-op", "logical-op", "coord-op"})

# UUID pattern (from unit_filters.py)
_UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def rel_class_from_deprel(deprel: str) -> str:
    """Map a UD deprel to CRF relation class."""
    if deprel == "root":
        return "root"
    if deprel in STRUCTURAL_DEPRELS or deprel in MERGE_DEPRELS:
        return "structural"
    if deprel in CORE_ARG_DEPRELS:
        return "core-arg"
    if deprel == "conj":
        return "coordination-and"   # cc lemma check done by caller
    if deprel in MODIFIER_DEPRELS:
        return "modifier"
    if deprel in OBLIQUE_DEPRELS:
        return "oblique"
    # parataxis, vocative, dislocated, discourse, reparandum, orphan, goeswith → modifier
    return "modifier"


def find_head_token_idx(token_indices: list, parse: list) -> int:
    """Find the token in the group whose head is outside the group.

    The parse root token has head == self; it counts as 'outside the group'
    for this purpose — its deprel is "root" and its parent is None.
    """
    group = set(token_indices)
    # Prioritize: if any token in the group is the parse root (head == self), return it.
    for ti in token_indices:
        if parse[ti]["head"] == ti:
            return ti
    # Otherwise: find the token whose head is outside the group.
    for ti in token_indices:
        if parse[ti]["head"] not in group:
            return ti
    return token_indices[0]


def is_uuid_only(text: str) -> bool:
    stripped = _UUID_RE.sub("", text or "")
    stripped = re.sub(r"[\s\W_]+", "", stripped)
    return bool((text or "").strip()) and stripped == ""


def is_unprobeable_content(node: dict) -> bool:
    """True if node is content but should get uniform emission (no MLLM call)."""
    upos = node.get("upos", "")
    if upos == "PRON":
        return True
    lemma = (node.get("lemma") or "").lower()
    if node.get("node_type") == "event" and lemma in LIGHT_VERB_LEMMAS:
        return True
    text = (node.get("text") or "").strip()
    if not text:
        return True
    if is_uuid_only(text):
        return True
    return False


def highlight_span(claim_text: str, s: int, e: int) -> str:
    """Wrap [s:e] in ** for claim_highlighted."""
    if s < 0 or e <= s:
        return claim_text
    s = max(0, s)
    e = min(len(claim_text), e)
    return claim_text[:s] + "**" + claim_text[s:e] + "**" + claim_text[e:]


# ---------------------------------------------------------------------------
# Tree construction (per claim)
# ---------------------------------------------------------------------------

def build_tree(claim: dict) -> dict:
    """Build the CRF tree for one claim.

    Returns a tree dict matching the trees_ud.jsonl schema (§4.1 of impl plan).
    """
    claim_id = claim["claim_id"]
    claim_text = claim["claim_text"]
    parse = claim["parse"]      # list of token dicts
    hg_nodes = claim["nodes"]   # list of hypergraph node dicts

    # ---- 1. Token → node id mapping ----------------------------------------
    tok2node: dict[int, str] = {}
    for n in hg_nodes:
        for ti in n["token_indices"]:
            tok2node[ti] = n["id"]

    # ---- 2. Detect negation tokens -----------------------------------------
    # UD v2 has NO "neg" deprel (deprecated); negation surfaces as advmod/det/
    # case/mark, so detect by LEMMA. (ADR-015 / bugs.md — the old deprel=="neg"
    # gate never fired on this parser, leaving all 74 negated claims un-flipped.)
    #   negation_node_ids: the operator node that IS the neg token → contract.
    #   negated_node_ids:  the scope node (nearest content head) → unary flip.
    negation_node_ids: set[str] = set()
    negated_node_ids: set[str] = set()

    for tok in parse:
        if (tok.get("lemma") or "").lower() not in NEG_LEMMAS:
            continue
        neg_nid = tok2node.get(tok["i"])
        # Scope = nearest content-node ancestor of the neg token.
        cur = tok["head"]
        visited: set = set()
        while cur not in tok2node and parse[cur]["head"] != cur and cur not in visited:
            visited.add(cur)
            cur = parse[cur]["head"]
        scope_nid = tok2node.get(cur)
        # Contract the neg token's own node only if it is a DISTINCT operator
        # node (not a negation determiner merged into the content it negates,
        # e.g. "no luggage" — there we flip the merged node in place).
        if neg_nid is not None and neg_nid != scope_nid:
            negation_node_ids.add(neg_nid)
        if scope_nid is not None:
            negated_node_ids.add(scope_nid)

    # ---- 3. Find root token(s) ---------------------------------------------
    root_tokens = [t for t in parse if t["head"] == t["i"]]
    # If multiple (multi-sentence), use first as primary root
    primary_root_ti = root_tokens[0]["i"] if root_tokens else 0

    # ---- 4. For each hypergraph node: find head token, parent, deprel ------
    parent_of: dict[str, str | None] = {}
    deprel_of: dict[str, str] = {}
    rel_class_of: dict[str, str] = {}
    head_upos_of: dict[str, str] = {}
    children_of: dict[str, list] = {n["id"]: [] for n in hg_nodes}

    for n in hg_nodes:
        nid = n["id"]
        head_ti = find_head_token_idx(n["token_indices"], parse)
        head_tok = parse[head_ti]
        head_upos_of[nid] = head_tok.get("upos", "")
        parent_ti = head_tok["head"]
        deprel = head_tok["deprel"]
        deprel_of[nid] = deprel

        if parent_ti == head_ti:
            # This is the root node (or a node in a root group)
            parent_of[nid] = None
            rel_class_of[nid] = "root"
            continue

        # Check cc lemma for coordination
        cc_lemma = None
        if deprel == "conj":
            # Find the cc sibling (cc child of this node's parent token)
            for tok in parse:
                if tok["head"] == parent_ti and tok["deprel"] == "cc":
                    cc_lemma = tok.get("lemma", "").lower()
                    break
            if cc_lemma in ("or", "nor"):
                rel_class_of[nid] = "coordination-or"
            else:
                rel_class_of[nid] = "coordination-and"
        else:
            rel_class_of[nid] = rel_class_from_deprel(deprel)

        # Traverse up through structural tokens to find content-node parent
        cur = parent_ti
        visited: set = set()
        while cur not in tok2node and parse[cur]["head"] != cur and cur not in visited:
            visited.add(cur)
            cur = parse[cur]["head"]

        if cur in tok2node:
            parent_of[nid] = tok2node[cur]
        else:
            # No content parent found; for multi-sentence cases, check if we
            # need to connect to primary root's node
            root_nid = tok2node.get(primary_root_ti)
            if root_nid and root_nid != nid:
                parent_of[nid] = root_nid
                # Keep existing rel_class (deprel-based)
            else:
                parent_of[nid] = None  # this node is also a root

    # ---- 5. Handle multi-root: connect secondary roots to primary root ------
    root_nodes = [nid for nid, p in parent_of.items() if p is None]
    primary_root_nid: str | None = tok2node.get(primary_root_ti)

    if primary_root_nid is None and root_nodes:
        primary_root_nid = root_nodes[0]

    for nid in root_nodes:
        if nid != primary_root_nid and primary_root_nid is not None:
            parent_of[nid] = primary_root_nid
            deprel_of[nid] = "parataxis"
            rel_class_of[nid] = "modifier"

    # ---- 6. Build children map ---------------------------------------------
    for nid, pid in parent_of.items():
        if pid is not None:
            children_of[pid].append(nid)

    # ---- 7. Classify each node ---------------------------------------------
    node_type_crf: dict[str, str] = {}  # "probed", "na", "structural"
    is_functional: dict[str, bool] = {}
    is_negation_flag: dict[str, bool] = {}
    negated_flag: dict[str, bool] = {}
    probed_flag: dict[str, bool] = {}

    for n in hg_nodes:
        nid = n["id"]
        rc = rel_class_of.get(nid, "modifier")
        node_type = n.get("node_type") or ""
        is_operator = node_type in OPERATOR_NODE_TYPES
        is_neg_tok = nid in negation_node_ids
        # Contract (no CRF variable) if: UD structural deprel, the negation
        # token, or any Phase-1 operator-typed node (relation/coord/logical-op).
        is_func = rc == "structural" or is_neg_tok or is_operator
        is_negation_flag[nid] = is_neg_tok or node_type == "logical-op"
        is_functional[nid] = is_func
        # A content node in the scope of negation gets its unary flipped (only
        # if it survives as a CRF variable — a contracted node is never flipped).
        negated_flag[nid] = nid in negated_node_ids and not is_func
        if is_func:
            probed_flag[nid] = False
        elif (deprel_of.get(nid, "") in MODIFIER_NOPROBE_DEPRELS
              and parent_of.get(nid) is not None):
            # Bare modifier (amod/advmod/nummod) — folds into its head; not a unit.
            probed_flag[nid] = False
        elif is_unprobeable_content(n):
            probed_flag[nid] = False
        else:
            probed_flag[nid] = True

    # ---- 7b. Cycle detection: remove back-edges (should not occur in a tree
    #          built from a DAG parse, but can arise from malformed parses) ----
    def _detect_and_break_cycles():
        """Iterative DFS from root; any edge that creates a cycle is removed."""
        visited_global: set[str] = set()
        all_roots = [nid for nid, p in parent_of.items() if p is None]
        for start in all_roots:
            stack = [start]
            on_path: set[str] = set()
            while stack:
                nid = stack[-1]
                if nid not in visited_global:
                    visited_global.add(nid)
                    on_path.add(nid)
                    bad = [c for c in children_of.get(nid, []) if c in on_path]
                    for c in bad:
                        children_of[nid].remove(c)
                        parent_of[c] = None  # orphan the back-edge child
                    stack.extend(c for c in children_of.get(nid, [])
                                 if c not in visited_global)
                else:
                    stack.pop()
                    on_path.discard(nid)

    _detect_and_break_cycles()

    # node_type per id: EVENTS keep their full-proposition unit (fold all args/obliques);
    # only NON-event units (entities/attributes/cardinality) tighten to the head phrase.
    node_type_of = {n["id"]: (n.get("node_type") or "") for n in hg_nodes}

    # ---- 8. Compute subtree char-spans (iterative, post-order) -------------
    node_spans: dict[str, tuple] = {}
    for n in hg_nodes:
        s, e = n.get("span_start", -1), n.get("span_end", -1)
        node_spans[n["id"]] = (s, e)

    def _compute_all_subtree_spans() -> tuple[dict, dict]:
        """Iterative post-order traversal to compute subtree spans for all nodes."""
        ssp: dict[str, tuple] = {}   # full subtree
        cssp: dict[str, tuple] = {}  # content-only subtree

        all_roots = [n["id"] for n in hg_nodes if parent_of.get(n["id"]) is None]
        # Process each subtree
        for root_nid in all_roots:
            order = []
            stack = [root_nid]
            visited_s: set = set()
            while stack:
                nid = stack.pop()
                if nid in visited_s:
                    continue
                visited_s.add(nid)
                order.append(nid)
                for c in children_of.get(nid, []):
                    if c not in visited_s:
                        stack.append(c)
            # Post-order: process leaves first (reverse of DFS pre-order)
            for nid in reversed(order):
                sp = node_spans.get(nid, (-1, -1))
                min_s_f = sp[0] if sp[0] >= 0 else float("inf")
                max_e_f = sp[1] if sp[1] >= 0 else float("-inf")
                is_func = is_functional.get(nid, False)
                min_s_c = min_s_f if not is_func else float("inf")
                max_e_c = max_e_f if not is_func else float("-inf")
                for c in children_of.get(nid, []):
                    cf = ssp.get(c, (-1, -1))
                    if cf[0] >= 0:
                        min_s_f = min(min_s_f, cf[0])
                        max_e_f = max(max_e_f, cf[1])
                    # Content/unit span: for a NON-event node, fold a child in only if it
                    # is a TIGHT modifier, not a boundary child (its own probed unit) —
                    # prevents clause-length entity units (e.g. a copular root swallowing
                    # its subject). EVENTS are exempt: they keep the full proposition
                    # (verb + all args/obliques), which is the intended event probe. ssp
                    # (full subtree, above) is unaffected either way.
                    if (node_type_of.get(nid, "") != "event"
                            and deprel_of.get(c, "") in UNIT_BOUNDARY_DEPRELS):
                        continue
                    cc = cssp.get(c, (-1, -1))
                    if cc[0] >= 0:
                        min_s_c = min(min_s_c, cc[0])
                        max_e_c = max(max_e_c, cc[1])
                ssp[nid] = (
                    int(min_s_f) if min_s_f != float("inf") else -1,
                    int(max_e_f) if max_e_f != float("-inf") else -1,
                )
                # FIX (2026-07-20): events AND the root keep the FULL proposition as
                # their unit (cssp = full subtree). ADR-018's gated cssp propagated
                # upward and TRUNCATED event/root units via their tightened children
                # (e.g. root "broadcast includes clips" dropped "of heavy rain…";
                # 1,375 claims). Only NON-root NON-event units use the tight span.
                if node_type_of.get(nid, "") == "event" or parent_of.get(nid) is None:
                    cssp[nid] = ssp[nid]
                else:
                    cssp[nid] = (
                        int(min_s_c) if min_s_c != float("inf") else -1,
                        int(max_e_c) if max_e_c != float("-inf") else -1,
                    )
        # Fill any nodes not reached (orphans after cycle break)
        for n in hg_nodes:
            nid = n["id"]
            if nid not in ssp:
                sp = node_spans.get(nid, (-1, -1))
                ssp[nid] = sp
                cssp[nid] = sp if not is_functional.get(nid, False) else (-1, -1)
        return ssp, cssp

    subtree_span_cache, content_subtree_span_cache = _compute_all_subtree_spans()

    # ---- 9. Assemble tree nodes list ---------------------------------------

    nmap = {n["id"]: n for n in hg_nodes}
    tree_nodes = []
    for n in hg_nodes:
        nid = n["id"]
        sp = node_spans[nid]
        ssp = subtree_span_cache[nid]         # full subtree (incl. structural)
        cssp = content_subtree_span_cache[nid]  # content-only subtree (for probing)
        node_text = n.get("text", "")
        subtree_text = claim_text[ssp[0]:ssp[1]] if ssp[0] >= 0 and ssp[1] > ssp[0] else node_text
        content_subtree_text = (claim_text[cssp[0]:cssp[1]]
                                if cssp[0] >= 0 and cssp[1] > cssp[0] else node_text)
        tree_nodes.append({
            "node_id": nid,
            "parent_id": parent_of.get(nid),
            "children": children_of.get(nid, []),
            "rel_class": rel_class_of.get(nid, "modifier"),
            "deprel": deprel_of.get(nid, ""),
            "head_upos": head_upos_of.get(nid, n.get("upos", "")),
            "node_type": n.get("node_type", ""),
            "span": list(sp),
            "subtree_span": list(ssp),
            "content_subtree_span": list(cssp),
            "node_text": node_text,
            "subtree_text": subtree_text,
            "content_subtree_text": content_subtree_text,
            "is_functional": is_functional.get(nid, False),
            "is_negation": is_negation_flag.get(nid, False),
            "negated": negated_flag.get(nid, False),
            "probed": probed_flag.get(nid, False),
        })

    return {
        "claim_id": claim_id,
        "claim_text": claim_text,
        "root_id": primary_root_nid,
        "nodes": tree_nodes,
    }


def tree_tsv_rows(tree: dict) -> list[dict]:
    """Emit annotation-units-schema TSV rows for probed nodes."""
    claim_id = tree["claim_id"]
    claim_text = tree["claim_text"]
    rows = []
    for n in tree["nodes"]:
        if not n["probed"]:
            continue
        # Use content_subtree for unit_text and highlighting (excludes structural tokens)
        cssp = n.get("content_subtree_span", n["subtree_span"])
        unit_text = n.get("content_subtree_text", n["node_text"])
        if not unit_text:
            unit_text = n["node_text"]
        claim_hl = highlight_span(claim_text, cssp[0], cssp[1])
        rows.append({
            "claim_id": claim_id,
            "unit_id": n["node_id"],
            "unit_type": "tree_node",
            "node_type": n["node_type"],
            "claim_text": claim_text,
            "unit_text": unit_text,
            "claim_highlighted": claim_hl,
            "gold_channels": "",
            "notes": "",
        })
    return rows


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--hypergraph", default=HYPERGRAPH)
    ap.add_argument("--output-trees", default=OUT_TREES)
    ap.add_argument("--output-tsv", default=OUT_TSV)
    ap.add_argument("--limit", type=int, default=None,
                    help="Process only the first N claims (for testing).")
    args = ap.parse_args()

    Path(args.output_trees).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output_tsv).parent.mkdir(parents=True, exist_ok=True)

    n_claims = 0
    n_nodes_total = 0
    n_probed_total = 0
    n_functional_total = 0
    n_na_total = 0

    with open(args.hypergraph, encoding="utf-8") as fin, \
         open(args.output_trees, "w", encoding="utf-8") as fout_trees, \
         open(args.output_tsv, "w", encoding="utf-8", newline="") as fout_tsv:

        writer = csv.DictWriter(fout_tsv, fieldnames=TSV_COLS, delimiter="\t")
        writer.writeheader()

        for line in fin:
            if args.limit and n_claims >= args.limit:
                break
            claim = json.loads(line)
            tree = build_tree(claim)
            fout_trees.write(json.dumps(tree, ensure_ascii=False) + "\n")

            rows = tree_tsv_rows(tree)
            for row in rows:
                writer.writerow(row)

            n_claims += 1
            n_nodes_total += len(tree["nodes"])
            n_probed_total += sum(1 for n in tree["nodes"] if n["probed"])
            n_functional_total += sum(1 for n in tree["nodes"] if n["is_functional"])
            n_na_total += sum(
                1 for n in tree["nodes"]
                if not n["probed"] and not n["is_functional"]
            )
            if n_claims % 500 == 0:
                print(f"  {n_claims} claims processed...", file=sys.stderr)

    print(f"Done: {n_claims} claims, {n_nodes_total} nodes total", file=sys.stderr)
    print(f"  probed:     {n_probed_total} ({100*n_probed_total/max(1,n_nodes_total):.1f}%)", file=sys.stderr)
    print(f"  functional: {n_functional_total} ({100*n_functional_total/max(1,n_nodes_total):.1f}%)", file=sys.stderr)
    print(f"  na/uniform: {n_na_total} ({100*n_na_total/max(1,n_nodes_total):.1f}%)", file=sys.stderr)
    print(f"  TSV rows (probed): {n_probed_total}", file=sys.stderr)


if __name__ == "__main__":
    main()
