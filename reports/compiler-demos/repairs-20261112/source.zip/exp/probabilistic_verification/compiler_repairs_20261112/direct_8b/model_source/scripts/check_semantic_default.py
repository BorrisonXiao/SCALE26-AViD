"""Verify default behavior without overwriting any earlier experiment proof."""
import json,time
from pathlib import Path
from run_content_relations_census import compile_one
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/semantic_components_20261112'

def main():
    src=ROOT/'exp/probabilistic_verification/content_relations_20261105';read=lambda p:list(map(json.loads,p.read_text().splitlines()))
    before=read(src/'results.jsonl');records=read(src/'inputs.jsonl');start=time.perf_counter()
    changed=[r['claim_id']for r,b in zip(records,before)if json.loads(json.dumps(compile_one(r)))!=b]
    proof=dict(records=len(records),changed=changed,exact_json_match=not changed,seconds=time.perf_counter()-start)
    (RUN/'historical_regression.json').write_text(json.dumps(proof,indent=2)+'\n');assert not changed,changed;print(proof)

if __name__=='__main__':main()
