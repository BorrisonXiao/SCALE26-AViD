#!/usr/bin/env python
"""
AViD Phase 1 — Step 4: Build annotation export.

Merges hypergraph + V1 + V2 affordances into a unit-centric annotation package:
    - annotation/units.jsonl      : one record per (claim, unit), no machine preds
    - annotation/claims.jsonl     : one record per claim (for context)
    - annotation/displacy/        : displaCy dep-parse HTML per claim
    - annotation/v1_affordance.jsonl  : V1 hard channel sets (for post-hoc eval)
    - annotation/v2_affordance.jsonl  : V2 soft distributions (for post-hoc eval)
    - annotation/README.txt       : annotation instructions summary

The units.jsonl file is intentionally BLIND to machine predictions — it only
shows the claim text with the unit span highlighted, the unit type, and a blank
`gold_channels` field for annotators to fill in.

Usage:
    python build_annotation_export.py
    python build_annotation_export.py --hypergraph <p> --v1 <p> --v2 <p>
"""
import argparse
import json
import sys
from pathlib import Path

# Stanza 1.6 + PyTorch 2.6+ compatibility
try:
    import torch as _torch
    _orig_torch_load = _torch.load
    def _patched_torch_load(*args, **kwargs):
        kwargs.setdefault("weights_only", False)
        return _orig_torch_load(*args, **kwargs)
    _torch.load = _patched_torch_load
except Exception:
    pass

# -- Default paths -----------------------------------------------------------
HYPERGRAPH_PATH = "/exp/cxiao/scale26/avid/exp/phase1/hypergraph.jsonl"
V1_PATH         = "/exp/cxiao/scale26/avid/exp/phase1/affordance_rules.jsonl"
V2_PATH         = "/exp/cxiao/scale26/avid/exp/phase1/affordance_llm.jsonl"
EXPORT_DIR      = "/exp/cxiao/scale26/avid/exp/phase1/annotation"

CHANNELS = ["visual_other", "visual_ocr", "audio_speech", "audio_other", "unverifiable"]


# -- Helpers -----------------------------------------------------------------

def highlight_span(claim_text: str, span_start: int, span_end: int,
                   mode: str = "markdown") -> str:
    """Highlight a character span in the claim text."""
    before = claim_text[:span_start]
    span   = claim_text[span_start:span_end]
    after  = claim_text[span_end:]
    if mode == "markdown":
        return f"{before}**{span}**{after}"
    elif mode == "html":
        return (f"{before}<span class='highlight'>{span}</span>{after}")
    return f"{before}[{span}]{after}"


def highlight_factor_span(claim_text: str, surface_span: str,
                          mode: str = "markdown") -> str:
    """Highlight first occurrence of surface_span in claim_text."""
    idx = claim_text.lower().find(surface_span.lower())
    if idx == -1:
        return claim_text
    return highlight_span(claim_text, idx, idx + len(surface_span), mode)


def render_displacy(doc, path: Path) -> None:
    from spacy import displacy
    html = displacy.render(
        doc, style="dep", page=True, jupyter=False,
        options={"compact": True, "distance": 90, "bg": "#f8f8f8"},
    )
    path.write_text(html, encoding="utf-8")


# -- Main --------------------------------------------------------------------

def setup_parser():
    p = argparse.ArgumentParser(
        description="Build annotation export (AViD Phase 1 Step 4)"
    )
    p.add_argument("--hypergraph",   default=HYPERGRAPH_PATH)
    p.add_argument("--v1",           default=V1_PATH,
                   help="V1 affordance_rules.jsonl (optional for blind export)")
    p.add_argument("--v2",           default=V2_PATH,
                   help="V2 affordance_llm.jsonl (optional for blind export)")
    p.add_argument("--export-dir",   default=EXPORT_DIR)
    p.add_argument("--displacy",     action="store_true",
                   help="Render displaCy HTML (requires avid-phase1 env)")
    p.add_argument("--displacy-n",   type=int, default=50,
                   help="Number of claims to render (default: 50, 0=all)")
    return p


def main():
    args = setup_parser().parse_args()
    export_dir = Path(args.export_dir)
    export_dir.mkdir(parents=True, exist_ok=True)
    displacy_dir = export_dir / "displacy"
    if args.displacy:
        displacy_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("AViD Phase 1 — build_annotation_export.py")
    print("=" * 60)

    # 1. Load hypergraph
    print(f"\n[1] Loading hypergraph: {args.hypergraph}")
    claims = []
    with open(args.hypergraph, encoding="utf-8") as f:
        for line in f:
            claims.append(json.loads(line))
    print(f"  Claims: {len(claims)}")

    # 2. Load V1 / V2 if present
    v1_map: dict[str, dict] = {}
    if Path(args.v1).exists():
        with open(args.v1, encoding="utf-8") as f:
            for line in f:
                obj = json.loads(line)
                v1_map[obj["claim_id"]] = obj
        print(f"  V1 loaded: {len(v1_map)} claims.")
    else:
        print(f"  V1 not found ({args.v1}); skipping machine preds.")

    v2_map: dict[str, dict] = {}
    if Path(args.v2).exists():
        with open(args.v2, encoding="utf-8") as f:
            for line in f:
                obj = json.loads(line)
                v2_map[obj["claim_id"]] = obj
        print(f"  V2 loaded: {len(v2_map)} claims.")
    else:
        print(f"  V2 not found ({args.v2}); skipping machine preds.")

    # 3. Load NLP pipeline for displaCy (optional)
    nlp = None
    if args.displacy:
        print("\n[2] Loading spacy-stanza for displaCy renders ...")
        import spacy_stanza
        stanza_dir = "/exp/cxiao/.cache/stanza"
        nlp = spacy_stanza.load_pipeline(
            "en",
            dir=stanza_dir,
            processors="tokenize,mwt,pos,lemma,depparse",
            use_gpu=False,
            verbose=False,
        )
        print("  Pipeline ready.")

    # 4. Build unit-centric records (BLIND to machine preds)
    print(f"\n[3] Building annotation records ...")
    unit_records: list[dict] = []
    claim_records: list[dict] = []
    v1_records: list[dict] = []
    v2_records: list[dict] = []

    displacy_render_count = 0
    displacy_limit = args.displacy_n if args.displacy_n > 0 else float("inf")

    for claim_idx, rec in enumerate(claims):
        cid         = rec["claim_id"]
        claim_text  = rec["claim_text"]

        # Claim-level record (context)
        claim_records.append({
            "claim_id":    cid,
            "topic_id":    rec["topic_id"],
            "claim_index": rec["claim_index"],
            "claim_text":  claim_text,
            "modalities":  rec["modalities"],   # human ground-truth channel tags
            "n_nodes":     len(rec["nodes"]),
            "n_factors":   len(rec["factors"]),
        })

        # V1 / V2 records (separate, not in blind export)
        v1_rec = v1_map.get(cid, {})
        v2_rec = v2_map.get(cid, {})
        v1_records.append({
            "claim_id":          cid,
            "affordance_nodes":  v1_rec.get("affordance_nodes", {}),
            "affordance_factors": v1_rec.get("affordance_factors", {}),
        })
        v2_records.append({
            "claim_id":               cid,
            "affordance_llm_nodes":   v2_rec.get("affordance_llm_nodes", {}),
            "affordance_llm_factors": v2_rec.get("affordance_llm_factors", {}),
        })

        # Node unit records
        for node in rec["nodes"]:
            highlighted = highlight_span(
                claim_text, node["span_start"], node["span_end"]
            )
            unit_records.append({
                "claim_id":           cid,
                "unit_id":            node["id"],
                "unit_type":          "node",
                "node_type":          node["node_type"],
                "unit_text":          node["text"],
                "claim_text":         claim_text,
                "claim_highlighted":  highlighted,
                "gold_channels":      [],   # to be filled by annotator
                # annotation instructions hint
                "channels_available": CHANNELS,
            })

        # Factor unit records
        for fac in rec["factors"]:
            highlighted = highlight_factor_span(claim_text, fac["surface_span"])
            unit_records.append({
                "claim_id":           cid,
                "unit_id":            fac["id"],
                "unit_type":          "factor",
                "node_type":          fac["factor_type"],
                "unit_text":          fac["surface_span"],
                "claim_text":         claim_text,
                "claim_highlighted":  highlighted,
                "gold_channels":      [],   # to be filled by annotator
                "channels_available": CHANNELS,
            })

        # displaCy render
        if nlp and displacy_render_count < displacy_limit:
            try:
                doc = nlp(claim_text)
                cid_safe = cid.replace("/", "_")
                html_path = displacy_dir / f"{claim_idx:04d}_{cid_safe}.html"
                render_displacy(doc, html_path)
                displacy_render_count += 1
            except Exception as e:
                print(f"  WARNING: displaCy failed for {cid}: {e}", file=sys.stderr)

    # 5. Write outputs
    print(f"\n[4] Writing export to {export_dir} ...")

    def write_jsonl(path: Path, records: list[dict]) -> None:
        with open(path, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")

    write_jsonl(export_dir / "units.jsonl",       unit_records)
    write_jsonl(export_dir / "claims.jsonl",       claim_records)
    write_jsonl(export_dir / "v1_affordance.jsonl", v1_records)
    write_jsonl(export_dir / "v2_affordance.jsonl", v2_records)

    # 6. README
    readme = f"""\
AViD Phase 1 — Annotation Export
==================================
Generated: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M')}

Files
-----
units.jsonl       : {len(unit_records)} unit records (BLIND to machine preds)
                    One record per (claim, unit) — nodes + factors.
                    Fill in `gold_channels` field (list, multi-label).

claims.jsonl      : {len(claim_records)} claim records
                    Context and human modality tags from the manifest.

v1_affordance.jsonl : Machine V1 predictions (lexicon+rules hard sets)
v2_affordance.jsonl : Machine V2 predictions (LLM soft distributions)
displacy/           : Dependency parse HTML visualizations
                    (if --displacy flag was used)

Channel Labels (5-way, multi-label)
------------------------------------
visual_other   : Verifiable from visible objects, actions, scenes, people,
                  locations, animals, text overlays (physical appearance).
visual_ocr     : Verifiable from on-screen text — signs, captions, titles,
                  scoreboards, banners, numbers displayed on screen.
audio_speech   : Verifiable from spoken words — dialogue, announcements,
                  narration, interviews, chants, commentary.
audio_other    : Verifiable from non-speech sounds — music, noise,
                  environmental audio, animals, machinery.
unverifiable   : Cannot be verified from audio-visual signal alone —
                  intent, cause, subjective judgment, background knowledge.

Annotation Instructions
------------------------
For each unit (node or factor), assign one or more gold_channels.
A unit may be multi-label (e.g., both visual_other and audio_speech if
it describes an action that produces sound AND is visible).

Unit types:
  - node/entity       : person, object, location, pronoun
  - node/event        : verb or action
  - node/attribute    : adjective, adverb
  - node/relation-op  : preposition
  - node/coord-op     : coordinating conjunction
  - node/logical-op   : negation word
  - node/cardinality  : number
  - factor/*          : composition of multiple nodes (predicate-argument, etc.)

For structure validation: also note if the node/factor decomposition
seems wrong or missing important units (free-text `structure_note` field).

Boundary Cases
--------------
- Captions of speech (e.g., a subtitle): → visual_ocr (text on screen)
  NOT audio_speech (even though it captures speech).
- "A man says ..." — the VERB "says" → audio_speech;
  the NOUN "man" → visual_other.
- "the sign reads 'Stop'" — "sign" → visual_other; "Stop" → visual_ocr.
- Person identity (name/face) → visual_other.
- Emotion / intent ("he was angry") → unverifiable unless a visible
  expression cue is present.
"""
    (export_dir / "README.txt").write_text(readme, encoding="utf-8")

    # 7. Summary
    node_units   = sum(1 for r in unit_records if r["unit_type"] == "node")
    factor_units = sum(1 for r in unit_records if r["unit_type"] == "factor")
    print("\n" + "=" * 60)
    print("ANNOTATION EXPORT SUMMARY")
    print("=" * 60)
    print(f"  Claims:              {len(claim_records)}")
    print(f"  Unit records:        {len(unit_records)}")
    print(f"    └─ node units:     {node_units}")
    print(f"    └─ factor units:   {factor_units}")
    if args.displacy:
        print(f"  displaCy HTML:       {displacy_render_count} files")
    print(f"  Output dir:          {export_dir}")
    print("\nDone.")


if __name__ == "__main__":
    main()
