"""Render every pilot comparison and exercise report navigation and downloads."""
import functools,http.server,json,threading
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/claim_rewrite_20261111'
def main():
 class Handler(http.server.SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'site')));threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(base+'/reports/compiler-demos.html#rewrite-pilot',wait_until='networkidle');page.wait_for_selector('#rewrite-case option',state='attached')
  assert page.locator('[role="tab"]').count()==7 and page.locator('#rewrite-pilot').is_visible()
  rows=json.loads((RUN/'pilot_cases.json').read_text());s=json.loads((RUN/'summary.json').read_text())
  for row in rows:
   page.select_option('#rewrite-case',row['claim_id']);assert page.locator('#rewrite-original').text_content()==row['text'];assert page.locator('#rewrite-text').text_content()==row['proposal']['text'];assert page.locator('#rewrite-review').text_content()==row['review']['reason']
   assert page.locator('#rewrite-initial-review').text_content()==row['initial_review']['reason']
   assert page.locator('#rewrite-graphs .output').count()==2
  for group,n in [('target',24),('control',8),('guard',8),('accepted',s['reviewed_recoveries_total']),('all',40)]:
   page.select_option('#rewrite-group',group);assert page.locator('#rewrite-case option').count()==n
  selected=s['recovered_ids'][0] if s['recovered_ids'] else rows[0]['claim_id']
  page.goto(base+'/reports/compiler-demos.html?rewrite='+selected+'#rewrite-pilot',wait_until='networkidle');page.wait_for_function('(cid)=>document.querySelector("#rewrite-case").value===cid',arg=selected)
  page.locator('#rewrite-pilot h2').scroll_into_view_if_needed();page.screenshot(path=str(RUN/'rewrite_desktop.png'))
  page.locator('#rewrite-original').evaluate('(el)=>el.scrollIntoView({block:"start"})');page.screenshot(path=str(RUN/'rewrite_case_desktop.png'))
  page.set_viewport_size({'width':390,'height':844});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.screenshot(path=str(RUN/'rewrite_mobile.png'));page.emulate_media(color_scheme='dark');page.screenshot(path=str(RUN/'rewrite_dark.png'))
  page.click('[data-tab="daily-progress"]');assert page.locator('#day-2026-11-11 a[href="#rewrite-pilot"]').count()>=1;page.locator('#day-2026-11-11 a[href="#rewrite-pilot"]').first.click();page.wait_for_selector('#rewrite-pilot',state='visible')
  page.click('[data-tab="walkthroughs"]');assert page.locator('#demo-select option').count()==41
  for demo in json.loads((ROOT/'site/reports/compiler-demos/examples.json').read_text()):
   page.select_option('#demo-select',demo['claim_id']);assert page.locator('#demo-claim').text_content()==demo['text'];assert page.locator('#fix-steps li').count()==3
  page.click('[data-tab="results"]');assert page.locator('#results table').first.locator('tbody tr').count()==4
  downloads=[]
  for name in ['summary.json','pilot_cases.json','semantic_review.json','pilot_raw.jsonl','source.zip','README.md']:
   relative='reports/compiler-demos/rewrite-20261111/'+name;r=page.request.get(base+'/'+relative);assert r.status==200 and r.body()==(ROOT/'site'/relative).read_bytes();downloads.append(relative)
  assert not errors,errors
  proof=dict(pilot_cases_rendered=40,all41_demos_preserved=True,seven_tabs=True,history_preserved=True,deep_links=True,daily_log_link=True,mobile_overflow=False,page_errors=errors,downloads_byte_exact=downloads)
  (RUN/'browser_checks.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof);browser.close()
 server.shutdown()
if __name__=='__main__':main()
