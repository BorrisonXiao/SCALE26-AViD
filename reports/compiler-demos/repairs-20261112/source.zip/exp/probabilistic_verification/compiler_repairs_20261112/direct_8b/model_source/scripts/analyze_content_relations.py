"""Compare the entire saved census; keep semantic review separate from checks."""
import hashlib,json
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_relations_20261105'
def rows(name):return {r['claim_id']:r for r in map(json.loads,(RUN/name).read_text().splitlines())}
def main():
    before,after=rows('baseline.jsonl'),rows('results.jsonl');assert set(before)==set(after)and len(after)==2375
    freeze=json.loads((RUN/'frozen_manifest.json').read_text())
    for p,h in freeze['source_sha256'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
    old={c for c,r in before.items()if 'program'in r};new={c for c,r in after.items()if 'program'in r}
    changed=[c for c in after if after[c].get('program_sha256')!=before[c].get('program_sha256')]
    recovered=[c for c in after if after[c]['status']=='compiled'and before[c]['status']!='compiled']
    lost=[c for c in after if after[c]['status']!='compiled'and before[c]['status']=='compiled']
    human=json.loads((ROOT/'exp/probabilistic_verification/review_followup_20261104/human_analysis/analysis.json').read_text())
    faithful=[r['claim_id']for r in human['cases']if r['by_condition']['revised']['rating']=='faithful']
    assert len(faithful)==11 and all(c not in changed and after[c]['status']=='compiled'for c in faithful)
    lexical=[r for r in after.values()if r.get('code')=='coverage_omission']
    summary=dict(total=len(after),before_accepted=sum(r['status']=='compiled'for r in before.values()),accepted=sum(r['status']=='compiled'for r in after.values()),
        before_executable=len(old),executable=len(new),lost_executable=sorted(old-new),new_executable=sorted(new-old),
        recovered=len(recovered),new_review_flags=len(lost),changed_programs=len(changed),unchanged_user_faithful=11,
        refusal_reasons=dict(Counter(r['code']for r in after.values()if r['status']!='compiled')),
        previous_alert_outcomes=dict(Counter('accepted'if after[c]['status']=='compiled'else after[c]['code']for c,r in before.items()if r.get('code')in {'coverage_omission','opaque_clause','incomplete_enumeration'})),
        lexical_alert_categories=dict(Counter(pos for r in lexical for pos in sorted({t['pos']for t in r['coverage']['missing']}))),
        new_change_kinds=dict(Counter(n['kind']for c in changed for n in after[c].get('changes',[])if n not in before[c].get('changes',[]))),
        unexpected_errors=[c for c,r in after.items()if r.get('code','')[:1].isupper()],tests=freeze['tests'],
        interpretation='Compilation checks, not corpus semantic accuracy. All source texts were processed previously. No new human labels or held-out semantic gain are claimed.')
    assert not summary['unexpected_errors'] and not summary['lost_executable'] and not lost
    (RUN/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
    for name,ids in [('changed_cases.json',changed),('recovered_cases.json',recovered),('new_review_flags.json',lost)]:
        (RUN/name).write_text(json.dumps([dict(claim_id=c,text=after[c]['text'],before=before[c]['status'],before_code=before[c].get('code'),after=after[c]['status'],code=after[c].get('code'))for c in ids],ensure_ascii=False,indent=2)+'\n')
    remaining=[dict(claim_id=c,text=r['text'],code=r['code'],missing=r.get('coverage',{}).get('missing',[]),alerts=r.get('structural_alerts',[]))for c,r in after.items()if r['status']!='compiled']
    (RUN/'remaining_cases.json').write_text(json.dumps(remaining,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
