#!/usr/bin/env python3
"""
AViD Phase 2 — Step 1: extract frames and audio from video chunks.

Groups annotation_units by video chunk (to decode each chunk only once), then
for each chunk:
  - Samples N_FRAMES frames (uniform) → JPEG under media_cache/frames/<chunk_id>/
  - Extracts 16 kHz mono WAV → media_cache/wav/<chunk_id>.wav

Output goes to EXP_DIR/media_cache/{frames,wav}/.  Skips chunks that are already
fully processed (resumable).

Usage:
    python scripts/extract_media.py
    python scripts/extract_media.py \\
        --annotation-units exp/phase1/reports/annotation_units.tsv \\
        --manifest         /exp/cxiao/scale26/probing/exp/step1/manifests/manifest.jsonl \\
        --video-dir        /exp/cxiao/scale26/data/extracted/microvent/videos \\
        --out-dir          exp/phase2/media_cache \\
        --n-frames         12 \\
        --sample-rate      16000
"""

import argparse
import csv
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

# cv2 and numpy are imported lazily (only available in vllm-omni env)

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_ANN_UNITS = str(_AVID / "exp/phase1/reports/annotation_units.tsv")
DEFAULT_MANIFEST  = "/exp/cxiao/scale26/probing/exp/step1/manifests/manifest.jsonl"
DEFAULT_VIDEO_DIR = "/exp/cxiao/scale26/data/extracted/microvent/videos"
DEFAULT_OUT_DIR   = str(_AVID / "exp/phase2/media_cache_1fps")
DEFAULT_N_FRAMES  = 12
DEFAULT_SR        = 16000


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_manifest(path: str) -> dict[str, dict]:
    """Load manifest.jsonl → {claim_id: record}."""
    out: dict[str, dict] = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            cid = f"{r['topic_id']}_{r['claim_index']}"
            out[cid] = r
    return out


def load_claim_ids(ann_units_path: str) -> set[str]:
    """Return set of claim_ids from annotation_units.tsv (valid rows only)."""
    ids: set[str] = set()
    with open(ann_units_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid:
                ids.add(cid)
    return ids


def chunk_already_done(frames_dir: Path, wav_path: Path, n_frames: int) -> bool:
    """True if frames dir has n_frames JPEGs and wav exists."""
    if not wav_path.exists():
        return False
    if not frames_dir.exists():
        return False
    jpegs = list(frames_dir.glob("frame_*.jpg"))
    return len(jpegs) >= n_frames


def extract_frames(video_path: str, out_dir: Path, n_frames: int,
                   max_size: tuple[int, int] | None = None) -> int:
    """Sample n_frames uniformly from video, save as frame_000.jpg.

    max_size: if set, shrink frames to fit within (max_w, max_h) while preserving
    aspect ratio. Never upscales.
    """
    import cv2
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"  WARNING: cannot open video: {video_path}", file=sys.stderr)
        return 0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if total <= 0:
        cap.release()
        return 0

    indices = [int(round(total * i / n_frames)) for i in range(n_frames)]
    indices = [min(max(i, 0), total - 1) for i in indices]
    out_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    for idx_frame, frame_num in enumerate(indices):
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_num)  # noqa: F821 (cv2 imported above)
        ret, frame = cap.read()
        if not ret:
            continue
        if max_size is not None:
            max_w, max_h = max_size
            fh, fw = frame.shape[:2]
            scale = min(max_w / fw, max_h / fh)
            if scale < 1.0:
                new_w = max(1, int(fw * scale))
                new_h = max(1, int(fh * scale))
                frame = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_AREA)
        out_path = out_dir / f"frame_{idx_frame:03d}.jpg"
        cv2.imwrite(str(out_path), frame, [cv2.IMWRITE_JPEG_QUALITY, 90])
        count += 1
    cap.release()
    return count


def extract_wav(video_path: str, wav_path: Path, sample_rate: int) -> bool:
    """Extract mono WAV at sample_rate Hz using ffmpeg. Returns True on success."""
    wav_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-y", "-loglevel", "error",
        "-i", video_path,
        "-ac", "1",             # mono
        "-ar", str(sample_rate),
        "-vn",                  # drop video
        str(wav_path),
    ]
    result = subprocess.run(cmd, capture_output=True)
    if result.returncode != 0:
        # No audio track is common; produce a 1-second silent WAV so downstream
        # has a valid file (marks "no audio" without breaking the pipeline).
        _write_silent_wav(wav_path, sample_rate, duration_s=1)
    return True


def _write_silent_wav(path: Path, sample_rate: int, duration_s: float = 1.0) -> None:
    """Write a minimal silent WAV file (no external deps)."""
    import struct
    n_samples = int(sample_rate * duration_s)
    data = bytes(2 * n_samples)          # 16-bit zeros
    chunk_size = 36 + len(data)
    with open(path, "wb") as f:
        f.write(b"RIFF")
        f.write(struct.pack("<I", chunk_size))
        f.write(b"WAVE")
        f.write(b"fmt ")
        f.write(struct.pack("<I", 16))           # subchunk1size
        f.write(struct.pack("<H", 1))            # PCM
        f.write(struct.pack("<H", 1))            # mono
        f.write(struct.pack("<I", sample_rate))
        f.write(struct.pack("<I", sample_rate * 2))  # byte rate
        f.write(struct.pack("<H", 2))            # block align
        f.write(struct.pack("<H", 16))           # bits per sample
        f.write(b"data")
        f.write(struct.pack("<I", len(data)))
        f.write(data)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def setup_parser():
    p = argparse.ArgumentParser(
        description="AViD Phase 2 — Step 1: extract frames + WAV from video chunks"
    )
    p.add_argument("--annotation-units", default=DEFAULT_ANN_UNITS)
    p.add_argument("--manifest",         default=DEFAULT_MANIFEST)
    p.add_argument("--video-dir",        default=DEFAULT_VIDEO_DIR)
    p.add_argument("--out-dir",          default=DEFAULT_OUT_DIR)
    p.add_argument("--n-frames",         type=int, default=DEFAULT_N_FRAMES,
                   help="Number of uniformly-sampled frames per chunk (default 12); "
                        "overridden by --fps if --fps > 0")
    p.add_argument("--fps",              type=float, default=0.0,
                   help="Target frame rate (frames/sec); if > 0, overrides --n-frames; "
                        "reads chunk JSON for duration to compute n_frames dynamically")
    p.add_argument("--max-frames",       type=int, default=250,
                   help="Cap on frames per chunk when using --fps (default 250)")
    p.add_argument("--frame-size",       default="",
                   help="Shrink frames to fit within WxH, e.g. '448x252'; "
                        "preserves aspect ratio, never upscales")
    p.add_argument("--skip-wav",         action="store_true",
                   help="Skip WAV extraction (frames only)")
    p.add_argument("--sample-rate",      type=int, default=DEFAULT_SR,
                   help="WAV sample rate in Hz (default 16000)")
    p.add_argument("--force",            action="store_true",
                   help="Re-extract even if output already exists")
    return p


def main():
    args = setup_parser().parse_args()

    out_dir   = Path(args.out_dir)
    frames_root = out_dir / "frames"
    wav_root    = out_dir / "wav"
    video_dir   = Path(args.video_dir)

    # Parse --frame-size
    max_size: tuple[int, int] | None = None
    if args.frame_size:
        try:
            fw, fh = args.frame_size.lower().split("x")
            max_size = (int(fw), int(fh))
        except ValueError:
            print(f"ERROR: --frame-size must be WxH (e.g. '448x252'), got: {args.frame_size!r}",
                  file=sys.stderr)
            sys.exit(1)

    frames_label = (f"~{args.fps}fps (max {args.max_frames})" if args.fps > 0
                    else str(args.n_frames))
    print("=" * 60)
    print("AViD Phase 2 — extract_media.py")
    print(f"  Annotation units: {args.annotation_units}")
    print(f"  Manifest:         {args.manifest}")
    print(f"  Video dir:        {args.video_dir}")
    print(f"  Out dir:          {args.out_dir}")
    print(f"  Frames/chunk:     {frames_label}")
    print(f"  Frame size:       {args.frame_size or '(native)'}")
    print(f"  Skip WAV:         {args.skip_wav}")
    print(f"  Sample rate:      {args.sample_rate} Hz")
    print("=" * 60)

    # 1. Load claim_ids and manifest
    print("\n[1] Loading annotation_units and manifest ...")
    claim_ids = load_claim_ids(args.annotation_units)
    manifest  = load_manifest(args.manifest)
    print(f"    Claims in annotation_units: {len(claim_ids)}")
    print(f"    Claims in manifest:         {len(manifest)}")

    # 2. Collect chunks needed for annotation_units claims
    chunk_to_claims: dict[str, list[str]] = {}
    no_video_claims: list[str] = []
    for cid in sorted(claim_ids):
        rec = manifest.get(cid)
        if rec is None:
            no_video_claims.append(cid)
            continue
        for chunk_name in rec["chunks"]:
            chunk_id = chunk_name.removesuffix(".mp4")
            chunk_to_claims.setdefault(chunk_id, []).append(cid)

    print(f"\n[2] Coverage:")
    print(f"    Claims with video:    {len(claim_ids) - len(no_video_claims)}")
    print(f"    Claims without video: {len(no_video_claims)}")
    print(f"    Unique chunks needed: {len(chunk_to_claims)}")
    if no_video_claims:
        print(f"    No-video examples:    {no_video_claims[:3]}")

    # 3. Extract per chunk
    print(f"\n[3] Extracting media ...")
    n_done = n_skip = n_err = 0
    for chunk_id in sorted(chunk_to_claims):
        video_path = video_dir / f"{chunk_id}.mp4"
        if not video_path.exists():
            print(f"  WARNING: video not found: {video_path}", file=sys.stderr)
            n_err += 1
            continue

        # Compute target frame count for this chunk
        if args.fps > 0:
            json_path = video_dir / f"{chunk_id}.json"
            try:
                meta = json.loads(json_path.read_text())
                duration = float(meta.get("duration_sec", 30.0))
            except Exception:
                duration = 30.0
            n_frames_chunk = min(args.max_frames, max(1, int(duration * args.fps)))
        else:
            n_frames_chunk = args.n_frames

        frames_dir = frames_root / chunk_id
        wav_path   = wav_root / f"{chunk_id}.wav"

        if not args.force:
            frames_ok = frames_dir.exists() and len(list(frames_dir.glob("frame_*.jpg"))) >= n_frames_chunk
            wav_ok    = args.skip_wav or wav_path.exists()
            if frames_ok and wav_ok:
                n_skip += 1
                continue

        # Frames
        n_saved = extract_frames(str(video_path), frames_dir, n_frames_chunk, max_size=max_size)

        # WAV
        if not args.skip_wav:
            extract_wav(str(video_path), wav_path, args.sample_rate)

        n_done += 1
        if n_done % 50 == 0:
            print(f"    Processed {n_done} chunks so far (skipped {n_skip}) ...",
                  flush=True)

    print(f"\n    Extracted: {n_done} chunks")
    print(f"    Skipped (already done): {n_skip}")
    print(f"    Missing videos: {n_err}")

    # 4. Write no-video list for downstream scripts
    no_video_path = out_dir / "no_video_claims.txt"
    no_video_path.parent.mkdir(parents=True, exist_ok=True)
    with open(no_video_path, "w", encoding="utf-8") as f:
        for cid in sorted(no_video_claims):
            f.write(cid + "\n")
    print(f"\n[4] No-video claims list: {no_video_path} ({len(no_video_claims)} claims)")

    print("\nDone.")


if __name__ == "__main__":
    main()
