"""Small report-source overlay; the original compiler archive stays unchanged."""
import hashlib,json,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compiler_alert_review_20261111'

def main():
    paths=['scripts/analyze_compiler_alert_review.py','scripts/compiler_alert_review_report.py','scripts/package_compiler_alert_review.py',
        'scripts/build_compiler_demos.py','scripts/report_assets/compiler_demos.js','scripts/report_assets/compiler_alert_review.js',
        'scripts/report_assets/compiler_demos_template.html','scripts/report_assets/compiler_demos.css',
        'scripts/build_av_feature_sections.py','scripts/build_compilation_methods_report.py',
        'docs/compiler_alert_review_20261111.md','docs/project_notes/daily_log.json','exp/probabilistic_verification/av_features_20261022/checklist.json']
    files=[ROOT/p for p in paths]
    excluded={'WORK_STATUS.md','publication.json','browser_checks.json','archive_verification.json'}
    files.extend(p for p in RUN.rglob('*')if p.is_file()and p.suffix in {'.json','.jsonl','.md','.py'}and p.name not in excluded)
    data={str(p.relative_to(ROOT)):p.read_bytes()for p in files}
    data['README_ALERT_REVIEW.md']=(ROOT/'docs/compiler_alert_review_20261111.md').read_bytes()
    data['ALERT_REVIEW_SHA256SUMS']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n'for k,v in sorted(data.items())).encode()
    target=ROOT/'site/reports/compiler-demos/alert-review-20261111/source.zip';target.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED)as z:
        for name,body in sorted(data.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,11,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,body)
    print('Packaged',len(data),'report/audit files;',round(target.stat().st_size/1048576,2),'MiB. Original compiler ZIP unchanged.')

if __name__=='__main__':main()
