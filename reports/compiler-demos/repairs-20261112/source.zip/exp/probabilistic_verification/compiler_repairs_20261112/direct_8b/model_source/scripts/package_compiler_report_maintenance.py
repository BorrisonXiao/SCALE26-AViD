"""Package a dated experiment overlay without replacing historical bundles."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/report_cleanup_20261112'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--allow-missing-history', action='store_true')
    args = parser.parse_args()
    names = ['scripts/analyze_remaining_claims.py', 'scripts/compiler_report_summary.py', 'scripts/package_compiler_report_maintenance.py', 'scripts/check_compiler_report_navigation.py', 'scripts/build_compiler_demos.py', 'scripts/build_verification_pipeline_report.py', 'scripts/split_alignment_report.py', 'scripts/report_assets/compiler_demos_template.html', 'scripts/report_assets/compiler_demos.js', 'docs/compiler_report_consolidation_20261112.md', 'docs/project_notes/daily_log.json', 'AGENTS.md', 'CLAUDE.md', 'docs/project_notes/key_facts.md', 'docs/project_notes/decisions.md', 'docs/project_notes/issues.md', 'docs/project_notes/terminology.md', 'site/reports/index.html', 'exp/probabilistic_verification/av_features_20261022/checklist.json']
    data = {n: (ROOT / n).read_bytes() for n in names}
    # Historical publication/browser proofs were produced after their original
    # bundles. Include these small records so all frozen hashes can be checked
    # during an isolated replay without weakening the preservation check.
    for name in json.loads((RUN/'frozen_artifacts.json').read_text()):
        if Path(name).name in {'publication.json','browser_checks.json','archive_verification.json'}:
            data[name]=(ROOT/name).read_bytes()
    excluded = {'publication.json', 'browser_checks.json', 'archive_verification.json',
                'final_source_sha256.json', 'WORK_STATUS.md'}
    for path in sorted(RUN.rglob('*')):
        if path.is_file() and path.suffix in {'.json', '.jsonl', '.xml', '.py', '.out', '.err'} and path.name not in excluded:
            data[str(path.relative_to(ROOT))] = path.read_bytes()
    freeze = {n: hashlib.sha256(body).hexdigest() for n, body in data.items()}
    (RUN / 'final_source_sha256.json').write_text(json.dumps(freeze, indent=2) + '\n')
    data[str((RUN / 'final_source_sha256.json').relative_to(ROOT))] = (RUN / 'final_source_sha256.json').read_bytes()
    data['README_REPORT_MAINTENANCE.md'] = (ROOT / 'docs/compiler_report_consolidation_20261112.md').read_bytes()
    data['REPORT_MAINTENANCE_SHA256SUMS'] = ''.join(
        hashlib.sha256(body).hexdigest() + '  ' + name + '\n'
        for name, body in sorted(data.items())).encode()
    target = ROOT / 'site/reports/compiler-demos/maintenance-20261112/source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, body in sorted(data.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, body)
    missing = []
    for name, digest in json.loads((RUN / 'preserved_archives.json').read_text()).items():
        path = ROOT / name
        if path.exists():
            assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
        else:
            missing.append(name)
    assert args.allow_missing_history or not missing, missing
    for name,digest in json.loads((RUN/'frozen_artifacts.json').read_text()).items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    for name, digest in json.loads((RUN / 'compiler_freeze.json').read_text())['source_sha256'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    for name, digest in json.loads((ROOT / 'exp/probabilistic_verification/claim_rewrite_20261111/viewer_sha256.json').read_text()).items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    print('Packaged', len(data), 'files;', round(target.stat().st_size / 1048576, 2),
          'MiB. Frozen compiler, historical archives and original viewer data preserved.')


if __name__ == '__main__':
    main()
