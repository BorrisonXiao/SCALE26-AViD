#!/usr/bin/env python3
"""
AViD Phase 2 — Step 3: merge visual + audio verification results into support_annotation.tsv.

Joins:
  verify_visual.jsonl  (produced by verify_support.py --modality visual)
  verify_audio.jsonl   (produced by verify_support.py --modality audio)
  annotation_units.tsv (metadata)

Output: exp/phase2/support_annotation.tsv
Columns:
  claim_id, unit_id, unit_type, node_type, claim_text, unit_text, claim_highlighted,
  no_video,
  support_visual_ocr, support_visual_ocr_prob,
  support_visual_other, support_visual_other_prob,
  support_audio_speech, support_audio_speech_prob,
  support_audio_other, support_audio_other_prob,
  supporting_channels,   ← pipe-separated list of channels where verdict=yes
  status                 ← supported|unsupported|unknown (per proposal §3.2)

Verdicts are {yes, no, unknown}.
status = supported   if any channel has verdict=yes
status = unsupported if all channels have verdict=no
status = unknown     if no channel=yes and at least one=unknown

Units not in verify_visual.jsonl (na-filtered) are skipped.
Units with no_video=True: all channel verdicts are forced to "unknown".

Usage:
    python scripts/build_support_annotation.py
    python scripts/build_support_annotation.py \\
        --verify-visual exp/phase2/verify_visual.jsonl \\
        --verify-audio  exp/phase2/verify_audio.jsonl \\
        --annotation-units exp/phase1/reports/annotation_units.tsv \\
        --output exp/phase2/support_annotation.tsv
"""

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_VERIFY_VISUAL = str(_AVID / "exp/phase2/verify_visual.jsonl")
DEFAULT_VERIFY_AUDIO  = str(_AVID / "exp/phase2/verify_audio.jsonl")
DEFAULT_ANN_UNITS     = str(_AVID / "exp/phase1/reports/annotation_units.tsv")
DEFAULT_OUTPUT        = str(_AVID / "exp/phase2/support_annotation.tsv")

FIELDNAMES = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted",
    "no_video",
    "support_visual_ocr",   "support_visual_ocr_prob",
    "support_visual_other", "support_visual_other_prob",
    "support_audio_speech", "support_audio_speech_prob",
    "support_audio_other",  "support_audio_other_prob",
    "supporting_channels",
    "status",
]

CHANNELS = ["visual_ocr", "visual_other", "audio_speech", "audio_other"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_verify_jsonl(path: str) -> dict[str, dict]:
    """Load verify_*.jsonl → {claim_id|unit_id: row}."""
    out: dict[str, dict] = {}
    p = Path(path)
    if not p.exists():
        print(f"  WARNING: verify file not found: {path}")
        return out
    with open(p, encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)
            key = f"{row['claim_id']}|{row['unit_id']}"
            out[key] = row
    return out


def verdict_to_status(verdicts: dict[str, str]) -> str:
    """Compute status from {channel: verdict}."""
    vals = list(verdicts.values())
    if any(v == "yes" for v in vals):
        return "supported"
    if all(v == "no" for v in vals):
        return "unsupported"
    return "unknown"


def load_ann_units(path: str) -> dict[str, dict]:
    """Load annotation_units.tsv → {claim_id|unit_id: row}."""
    out: dict[str, dict] = {}
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if cid and uid:
                out[f"{cid}|{uid}"] = row
    return out


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def setup_parser():
    p = argparse.ArgumentParser(
        description="AViD Phase 2 — Step 3: build support_annotation.tsv"
    )
    p.add_argument("--verify-visual",   default=DEFAULT_VERIFY_VISUAL)
    p.add_argument("--verify-audio",    default=DEFAULT_VERIFY_AUDIO)
    p.add_argument("--annotation-units", default=DEFAULT_ANN_UNITS)
    p.add_argument("--output",          default=DEFAULT_OUTPUT)
    return p


def main():
    args = setup_parser().parse_args()
    out_path = Path(args.output)

    print("=" * 60)
    print("AViD Phase 2 — build_support_annotation.py")
    print(f"  Visual verify:    {args.verify_visual}")
    print(f"  Audio verify:     {args.verify_audio}")
    print(f"  Annotation units: {args.annotation_units}")
    print(f"  Output:           {out_path}")
    print("=" * 60)

    # 1. Load data
    print("\n[1] Loading data ...")
    vis_data = load_verify_jsonl(args.verify_visual)
    aud_data = load_verify_jsonl(args.verify_audio)
    ann_data = load_ann_units(args.annotation_units)
    print(f"    Visual verify: {len(vis_data)} rows")
    print(f"    Audio verify:  {len(aud_data)} rows")
    print(f"    Ann units:     {len(ann_data)} rows")

    # 2. Use visual verify as the primary key set (all non-na units processed)
    key_set = set(vis_data.keys()) | set(aud_data.keys())
    print(f"    Unique units to merge: {len(key_set)}")

    # 3. Write output
    out_path.parent.mkdir(parents=True, exist_ok=True)
    n_written = 0
    status_counts: dict[str, int] = defaultdict(int)

    with open(out_path, "w", newline="", encoding="utf-8") as out_f:
        writer = csv.DictWriter(out_f, fieldnames=FIELDNAMES, delimiter="\t",
                                lineterminator="\n", quoting=csv.QUOTE_MINIMAL)
        writer.writeheader()

        for key in sorted(key_set):
            vis_row = vis_data.get(key, {})
            aud_row = aud_data.get(key, {})
            ann_row = ann_data.get(key, {})

            cid, uid = key.split("|", 1)
            no_video = vis_row.get("no_video", aud_row.get("no_video", False))

            # Per-channel verdicts and probs
            ch_verdicts: dict[str, str] = {}
            ch_probs:    dict[str, float] = {}

            def _get(row: dict, channel: str) -> tuple[str, float]:
                verdict = row.get(f"{channel}_verdict", "unknown")
                dist    = row.get(f"{channel}_dist", {})
                prob    = dist.get(verdict, 0.0) if dist else 0.0
                # If no video, force unknown
                if no_video:
                    return "unknown", 0.0
                return verdict, round(prob, 4)

            for ch in ["visual_ocr", "visual_other"]:
                ch_verdicts[ch], ch_probs[ch] = _get(vis_row, ch)
            for ch in ["audio_speech", "audio_other"]:
                ch_verdicts[ch], ch_probs[ch] = _get(aud_row, ch)

            supporting = [ch for ch in CHANNELS if ch_verdicts[ch] == "yes"]
            status = verdict_to_status(ch_verdicts)
            status_counts[status] += 1

            writer.writerow({
                "claim_id":             cid,
                "unit_id":              uid,
                "unit_type":            ann_row.get("unit_type", vis_row.get("unit_type", "")),
                "node_type":            ann_row.get("node_type", ""),
                "claim_text":           ann_row.get("claim_text", ""),
                "unit_text":            ann_row.get("unit_text", ""),
                "claim_highlighted":    ann_row.get("claim_highlighted", ""),
                "no_video":             str(no_video).lower(),
                "support_visual_ocr":   ch_verdicts["visual_ocr"],
                "support_visual_ocr_prob":  f"{ch_probs['visual_ocr']:.4f}",
                "support_visual_other": ch_verdicts["visual_other"],
                "support_visual_other_prob": f"{ch_probs['visual_other']:.4f}",
                "support_audio_speech": ch_verdicts["audio_speech"],
                "support_audio_speech_prob": f"{ch_probs['audio_speech']:.4f}",
                "support_audio_other":  ch_verdicts["audio_other"],
                "support_audio_other_prob":  f"{ch_probs['audio_other']:.4f}",
                "supporting_channels":  "|".join(supporting),
                "status":               status,
            })
            n_written += 1

    print(f"\n    Rows written: {n_written}")
    print(f"    Status distribution:")
    for st, cnt in sorted(status_counts.items()):
        pct = 100 * cnt / max(1, n_written)
        print(f"      {st}: {cnt} ({pct:.1f}%)")
    print(f"\n    Output: {out_path}")
    print("\nDone.")


if __name__ == "__main__":
    main()
