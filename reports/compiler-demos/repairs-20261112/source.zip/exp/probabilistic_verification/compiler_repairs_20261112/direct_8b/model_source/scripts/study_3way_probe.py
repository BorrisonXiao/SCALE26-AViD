#!/usr/bin/env python3
"""
AViD Phase-3 — NEI/REF elicitation study (nei_elicitation_v1).

Tests whether the 3-way pass-1 prompt (yes / no / can't-tell) separates
B = no / REFUTED (clear absence) from C = can't-tell / NEI (view/audio
unavailable), per ADR-017. Implements Stages A/B of the systematic protocol.

Conditions (ground truth by construction):
  normal    : own clip, no manipulation   → expect A (present) or B
  mismatch  : partner clip, no manip.     → expect B  [REF control]
  blank     : own clip, black frames (vis) / silence (aud) — legacy baseline
  blur_heavy: own clip, heavy Gaussian blur (vis)          → expect C
  blur_med  : own clip, medium Gaussian blur (vis)         → expect C
  pixelate  : own clip, extreme downscale+upscale (vis)    → expect C
  cropaway  : own clip, corner crop (vis)                  → expect C or B
  mute      : own clip, zero audio (aud)                   → expect C
  noise     : own clip, 0 dB-SNR white noise (aud)         → expect C
  lowpass   : own clip, 300 Hz FIR lowpass (aud)           → expect C
  clip_short: own clip, truncated to 0.25 s (aud)          → expect C

Metrics (pre-registered, §4 of the plan):
  S = C(ablation) − max(C(normal), C(mismatch))  — large → NEI fires on ablation
  R = B(mismatch) − C(mismatch)                  — > 0  → REF fires for absence
  U = C(normal)                                  — small → NEI not over-used

Stage A gate: best_S ≥ 0.5 AND R > 0 AND U ≤ 0.2  (real-NEI slice is Stage D).

Usage:
  # Stage A — sweep full ablation ladder, W0/E0
  python scripts/study_3way_probe.py --modality visual --n 40  [--dry-run]
  python scripts/study_3way_probe.py --modality audio  --n 40  [--dry-run]

  # Stage B — specific wording variant
  python scripts/study_3way_probe.py --modality visual --n 40 --wording w1

  # Subset of ablations (faster iteration)
  python scripts/study_3way_probe.py --modality visual --n 40 --ablations blank,blur_heavy,normal,mismatch

Outputs (under exp/phase3/reports/nei_study/):
  {modality}__{wording}__{elicit}.jsonl          — per-request rows (claim/unit/condition/dist/argmax)
  {modality}__{wording}__{elicit}__summary.json  — per-condition rates + S/R/U + gate verdict
"""
import argparse, csv, json, random, sys
from pathlib import Path

_AVID = Path("/exp/cxiao/scale26/avid")
sys.path.insert(0, str(_AVID / "scripts"))
import prompts_phase2 as P
import verify_support as V

TREES_TSV  = _AVID / "exp/phase3/nodes/tree_units_ud.tsv"
MANIFEST   = V.DEFAULT_MANIFEST
MEDIA      = Path(V.DEFAULT_MEDIA_DIR)
OUTDIR     = _AVID / "exp/phase3/reports/nei_study"

VISUAL_ABLATIONS_DEFAULT = ["normal", "mismatch", "blank", "blur_heavy", "blur_med",
                             "pixelate", "cropaway"]
AUDIO_ABLATIONS_DEFAULT  = ["normal", "mismatch", "mute", "noise", "lowpass", "clip_short"]

_PRON = {"them", "it", "this", "that", "they", "he", "she", "him", "her", "us", "we", "you"}


# ===========================================================================
# Media manipulation helpers
# ===========================================================================

def _ablate_frames(frames, ablation):
    """Apply a visual ablation to a list of PIL Images. Returns same-size list."""
    from PIL import Image, ImageFilter
    import numpy as np
    if not frames:
        return frames
    if ablation == "blank":
        w, h = frames[0].size
        return [Image.fromarray(np.zeros((h, w, 3), np.uint8)) for _ in frames]
    if ablation == "blur_heavy":
        return [f.filter(ImageFilter.GaussianBlur(radius=30)) for f in frames]
    if ablation == "blur_med":
        return [f.filter(ImageFilter.GaussianBlur(radius=10)) for f in frames]
    if ablation == "pixelate":
        result = []
        for f in frames:
            w, h = f.size
            tiny = f.resize((max(1, w // 20), max(1, h // 20)), Image.NEAREST)
            result.append(tiny.resize((w, h), Image.NEAREST))
        return result
    if ablation == "cropaway":
        result = []
        for f in frames:
            w, h = f.size
            # top-right corner (1/4 × 1/4) — usually background
            cropped = f.crop((w * 3 // 4, 0, w, h // 4))
            result.append(cropped.resize((w, h), Image.BILINEAR))
        return result
    return frames


def _lowpass_fir(wav, sr, cutoff=300):
    """Windowed-sinc FIR lowpass at cutoff Hz. No scipy required."""
    import numpy as np
    nyq = sr / 2.0
    norm_cut = cutoff / nyq
    n_taps = 101
    t = np.arange(n_taps) - n_taps // 2
    with np.errstate(divide="ignore", invalid="ignore"):
        h = np.where(t == 0, 2 * norm_cut, np.sin(2 * np.pi * norm_cut * t) / (np.pi * t))
    window = np.blackman(n_taps)
    kernel = (h * window).astype(np.float64)
    kernel /= kernel.sum()
    return np.convolve(wav.astype(np.float64), kernel, mode="same").astype(np.float32)


def _ablate_wav(wav_arr, sample_rate, ablation):
    """Apply an audio ablation. Returns (wav_array, sample_rate)."""
    import numpy as np
    if ablation == "mute":
        return np.zeros_like(wav_arr), sample_rate
    if ablation == "noise":
        rng = np.random.RandomState(42)
        rms = float(np.sqrt(np.mean(wav_arr ** 2))) or 0.01
        n = rng.randn(len(wav_arr)).astype(np.float32)
        n_rms = float(np.sqrt(np.mean(n ** 2))) or 1e-8
        return (n * (rms / n_rms)), sample_rate
    if ablation == "lowpass":
        return _lowpass_fir(wav_arr, sample_rate, cutoff=300), sample_rate
    if ablation == "clip_short":
        n = int(sample_rate * 0.25)
        short = wav_arr[:n] if len(wav_arr) >= n else wav_arr
        return short, sample_rate
    return wav_arr, sample_rate


# ===========================================================================
# Sampling
# ===========================================================================

def _read_tsv(path):
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def _chunks_for(cid):
    return [c[:-4] if c.endswith(".mp4") else c
            for c in V._get_chunks_for_claim(cid, MANIFEST)]


def _has_media(cid):
    chs = _chunks_for(cid)
    return bool(chs) and any(
        (MEDIA / "frames" / c).is_dir() or (MEDIA / "wav" / f"{c}.wav").exists()
        for c in chs
    )


def build_sample(n, seed):
    """Sample n concrete entity/event leaf units with available media; assign mismatch partners."""
    rng = random.Random(seed)
    rows = [r for r in _read_tsv(TREES_TSV)
            if r["node_type"] in ("entity", "event")
            and 1 <= len(r["unit_text"].split()) <= 4
            and r["unit_text"].replace(" ", "").isalpha()
            and r["unit_text"].lower() not in _PRON]
    rng.shuffle(rows)
    sample = []
    for r in rows:
        if _has_media(r["claim_id"]):
            sample.append({"claim_id": r["claim_id"], "unit_id": r["unit_id"],
                           "unit_text": r["unit_text"]})
        if len(sample) >= n:
            break
    # mismatch partner: a different claim (rotate by ≥n//2)
    for i, u in enumerate(sample):
        j = (i + max(1, n // 2)) % len(sample)
        while sample[j]["claim_id"] == u["claim_id"] and len(sample) > 1:
            j = (j + 1) % len(sample)
        u["mismatch_claim_id"] = sample[j]["claim_id"]
    return sample


# ===========================================================================
# Request construction
# ===========================================================================

def _q(modality, unit_text):
    if modality == "visual":
        return f'Is "{unit_text}" visible in the video clip?'
    return f'Is "{unit_text}" audible in the clip, or mentioned in speech?'


def make_requests(modality, sample, ablations, wording):
    """Build one request per (unit, ablation) combination."""
    reqs = []
    for u in sample:
        user = P.pass1_user(modality, "r5e", unit_text=u["unit_text"],
                            marked_context=u["unit_text"],
                            formulated=_q(modality, u["unit_text"]),
                            three_way=True, wording=wording)
        base = {"claim_id": u["claim_id"], "unit_id": u["unit_id"],
                "unit_text": u["unit_text"], "user_text": user}
        for abl in ablations:
            if abl == "normal":
                reqs.append({**base, "condition": "normal",
                             "media_cid": u["claim_id"], "ablation": None})
            elif abl == "mismatch":
                reqs.append({**base, "condition": "mismatch",
                             "media_cid": u["mismatch_claim_id"], "ablation": None})
            else:
                reqs.append({**base, "condition": abl,
                             "media_cid": u["claim_id"], "ablation": abl})
    return reqs


# ===========================================================================
# Summary / metrics
# ===========================================================================

def _cant_tell_rate(rates, wording):
    """Collapse C+D → cant_tell for W3; direct for W0-W2."""
    if wording == "w3":
        return rates.get("degraded", 0) + rates.get("off_screen", 0)
    return rates.get("cant_tell", 0)


def summarize(rows, wording):
    from collections import Counter, defaultdict
    verdicts, _ = P.get_3way_opts("visual", wording)[1:]  # same for both modalities
    by = defaultdict(Counter)
    for r in rows:
        by[r["condition"]][r["argmax"]] += 1

    per_cond = {}
    for cond, c in by.items():
        tot = sum(c.values())
        per_cond[cond] = {"n": tot, "rates": {v: round(c.get(v, 0) / tot, 4) for v in verdicts}}
        if wording == "w3":
            ct = _cant_tell_rate(per_cond[cond]["rates"], wording)
            per_cond[cond]["cant_tell_collapsed"] = round(ct, 4)

    def C(cond):
        if cond not in per_cond:
            return float("nan")
        return _cant_tell_rate(per_cond[cond]["rates"], wording)

    def B(cond):
        return per_cond.get(cond, {}).get("rates", {}).get("no", float("nan"))

    U = C("normal")
    R = round(B("mismatch") - C("mismatch"), 4) if "mismatch" in per_cond else float("nan")

    ablation_only = [c for c in per_cond if c not in ("normal", "mismatch")]
    baseline_C = max(C("normal"), C("mismatch")) if "mismatch" in per_cond else C("normal")
    per_abl = {}
    for abl in ablation_only:
        c_rate = C(abl)
        per_abl[abl] = {"C": round(c_rate, 4),
                        "S": round(c_rate - baseline_C, 4)}

    best_abl = max(per_abl, key=lambda k: per_abl[k]["S"]) if per_abl else None
    best_S = per_abl[best_abl]["S"] if best_abl else float("nan")

    stage_a_gate = None
    if per_abl:
        if best_S >= 0.5 and R > 0 and U <= 0.2:
            stage_a_gate = "PASS"
        elif best_S >= 0.5:
            stage_a_gate = f"PARTIAL (best_S={best_S:.3f} ≥ 0.5, but R={R:.3f} or U={U:.3f} fails)"
        else:
            stage_a_gate = f"FAIL (best_S={best_S:.3f} < 0.5)"

    summary = {
        "per_condition": per_cond,
        "metrics": {
            "R": R, "U": round(U, 4),
            "per_ablation": per_abl,
            "best_ablation": best_abl,
            "best_S": round(best_S, 4) if best_S == best_S else best_S,
        },
        "stage_a_gate": stage_a_gate,
    }

    lines = []
    for cond in sorted(per_cond, key=lambda c: (c not in ("normal", "mismatch"), c)):
        r = per_cond[cond]["rates"]
        ct = _cant_tell_rate(r, wording)
        lines.append(f"  {cond:12s} n={per_cond[cond]['n']:3d}  " +
                     "  ".join(f"{v}={r.get(v, 0):.2f}" for v in verdicts[:3]) +
                     (f"  cant_tell_tot={ct:.2f}" if wording == "w3" else ""))
    lines.append(f"\n  R={R:.3f}  U={U:.3f}  best_S={best_S:.3f} ({best_abl})  gate={stage_a_gate}")
    return summary, "\n".join(lines)


# ===========================================================================
# Main
# ===========================================================================

def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--modality",  required=True, choices=["visual", "audio"])
    ap.add_argument("--n",         type=int, default=40, dest="n_units",
                    help="Number of sample units (default 40)")
    ap.add_argument("--ablations", default=None,
                    help="Comma-sep ablation conditions. Default: all for modality. "
                         "Visual: " + ",".join(VISUAL_ABLATIONS_DEFAULT) + ". "
                         "Audio: " + ",".join(AUDIO_ABLATIONS_DEFAULT))
    ap.add_argument("--wording",   default="w0", choices=["w0", "w1", "w2", "w3"],
                    help="3-way option wording variant (w0=current v7, w1–w3=NEI-study variants)")
    ap.add_argument("--elicit",    default="forced", choices=["forced"],
                    help="Elicitation method (only 'forced' implemented)")
    ap.add_argument("--n-frames",      type=int, default=16)
    ap.add_argument("--max-model-len", type=int, default=16384,
                    help="vLLM max_model_len for visual (16 frames × 252 tok + text ≈ 4K; "
                         "default 16384 fits on A100-40gb). Ignored for audio (fixed 4096).")
    ap.add_argument("--seed",      type=int, default=20260715)
    ap.add_argument("--tp",        type=int, default=1)
    ap.add_argument("--dry-run",   action="store_true")
    args = ap.parse_args()

    if args.ablations:
        ablations = [a.strip() for a in args.ablations.split(",") if a.strip()]
    else:
        ablations = (VISUAL_ABLATIONS_DEFAULT if args.modality == "visual"
                     else AUDIO_ABLATIONS_DEFAULT)

    _, verdicts, letters = P.get_3way_opts(args.modality, args.wording)
    system = P.get_p1_system(args.modality, args.wording, explain=False)

    sample = build_sample(args.n_units, args.seed)
    reqs   = make_requests(args.modality, sample, ablations, args.wording)

    from collections import Counter
    print(f"[sample] {len(sample)} units × {len(ablations)} conditions = {len(reqs)} requests "
          f"({dict(Counter(r['condition'] for r in reqs))})", file=sys.stderr)

    if args.dry_run:
        ex = reqs[0]
        print(f"\n=== DRY RUN — {ex['claim_id']} {ex['unit_id']!r} cond={ex['condition']} ===")
        print(ex["user_text"])
        print(f"\nSystem ({args.wording}):\n{system}")
        print(f"\nVerdicts: {verdicts}  Letters: {letters}")
        print(f"\nAblations to run: {ablations}")
        print("\nsample units:", [u["unit_text"] for u in sample[:12]])
        print("mismatch ok (own≠partner):",
              all(u["claim_id"] != u["mismatch_claim_id"] for u in sample))
        return

    import torch, numpy as np
    from vllm import LLM, SamplingParams
    from PIL import Image

    tp = args.tp if args.tp > 0 else torch.cuda.device_count()
    if args.modality == "visual":
        from transformers import AutoTokenizer
        mp = V.VL_MODEL_PATH
        tok = AutoTokenizer.from_pretrained(mp, trust_remote_code=True)
        # Cap max_pixels to actual frame size so the ViT encoder profiling step
        # doesn't allocate for the default 16.7M-pixel worst case (OOM on 40gb).
        # Our frames are at most 672×384 = 258,048 pixels → 252 tokens each.
        llm = LLM(model=mp, trust_remote_code=True, gpu_memory_utilization=0.90,
                  tensor_parallel_size=tp, dtype="bfloat16", seed=42,
                  max_model_len=args.max_model_len,
                  limit_mm_per_prompt={"image": args.n_frames},
                  mm_processor_kwargs={"max_pixels": 672 * 384})
        tokenizer = tok
    else:
        from transformers import AutoProcessor
        mp = V.OMNI_MODEL_PATH
        tok = AutoProcessor.from_pretrained(mp, trust_remote_code=True)
        llm = LLM(model=mp, trust_remote_code=True, gpu_memory_utilization=0.90,
                  tensor_parallel_size=tp, dtype="bfloat16", seed=42, max_model_len=4096,
                  limit_mm_per_prompt={"audio": 1})
        tokenizer = getattr(tok, "tokenizer", tok)

    sp = SamplingParams(temperature=0.0, max_tokens=1, logprobs=20)

    prompts_mm = []
    for r in reqs:
        chs = _chunks_for(r["media_cid"])
        if args.modality == "visual":
            frames = []
            for c in chs:
                frames.extend(V._load_frames_safe(
                    MEDIA / "frames" / c,
                    args.n_frames // max(1, len(chs)), frame_size=(672, 378)))
            frames = frames[: args.n_frames] or [Image.fromarray(np.zeros((378, 672, 3), np.uint8))]
            if r["ablation"]:
                frames = _ablate_frames(frames, r["ablation"])
            prompts_mm.append({"prompt": V._build_vl_prompt(tok, system, r["user_text"], len(frames)),
                               "multi_modal_data": {"image": frames}})
        else:
            wav = None
            for c in chs:
                wp = MEDIA / "wav" / f"{c}.wav"
                if wp.exists():
                    wav = V._load_wav_safe(wp); break
            if wav is None:
                wav = (np.zeros(16000 * 4, dtype="float32"), 16000)
            wav_arr, sr = wav
            if r["ablation"]:
                wav_arr, sr = _ablate_wav(wav_arr, sr, r["ablation"])
            prompts_mm.append({"prompt": V._build_omni_prompt(tok, system, r["user_text"]),
                               "multi_modal_data": {"audio": [(wav_arr, sr)]}})

    outs = llm.generate(prompts_mm, sampling_params=sp)
    rows = []
    for r, o in zip(reqs, outs):
        lp   = V._verdict_logprobs(o, letters, tokenizer)
        dist = V.extract_option_distribution(lp, tokenizer, verdicts=verdicts, letters=letters)
        rows.append({k: r[k] for k in ("claim_id", "unit_id", "unit_text", "condition")} |
                    {"dist": dist, "argmax": max(dist, key=dist.get)})

    OUTDIR.mkdir(parents=True, exist_ok=True)
    stem = f"{args.modality}__{args.wording}__{args.elicit}"
    jsonl_path = OUTDIR / f"{stem}.jsonl"
    with open(jsonl_path, "w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")

    summary, table = summarize(rows, args.wording)
    summary["meta"] = {"modality": args.modality, "wording": args.wording,
                       "elicit": args.elicit, "n_units": len(sample),
                       "ablations": ablations, "seed": args.seed}
    summary_path = OUTDIR / f"{stem}__summary.json"
    summary_path.write_text(json.dumps(summary, indent=2))

    print(f"\n=== {stem} ===\n{table}")
    print(f"\n→ {jsonl_path}\n→ {summary_path}")


if __name__ == "__main__":
    main()
