"""Confirm that opt-in extensions leave the historical default byte-equivalent."""
import json,time
from pathlib import Path
from run_content_relations_census import compile_one
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/rewrite_all_20261112'


def main():
    source=ROOT/'exp/probabilistic_verification/content_relations_20261105'
    inputs=list(map(json.loads,(source/'inputs.jsonl').read_text().splitlines()))
    old=list(map(json.loads,(source/'results.jsonl').read_text().splitlines()));started=time.perf_counter();changed=[]
    for record,before in zip(inputs,old):
        after=json.loads(json.dumps(compile_one(record)))
        if after!=before:changed.append(record['claim_id'])
    proof=dict(records=len(inputs),changed=changed,exact_json_match=not changed,seconds=time.perf_counter()-started)
    (RUN/'historical_regression.json').write_text(json.dumps(proof,indent=2)+'\n');assert not changed,changed;print(proof)


if __name__=='__main__':main()
