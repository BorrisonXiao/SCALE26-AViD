#!/usr/bin/env python
"""Render a REAL AViD claim parse tree as a slide figure, with (synthetic)
per-unit source-modality colour coding.

- Structure is REAL: the UD dependency tree comes from
  exp/phase3/trees/trees_ud.jsonl (parser output, node_type / deprel / negation).
- Colours are ILLUSTRATIVE: each content unit is tinted by the channel that
  would ground it (visual / on-screen text / speech / other audio / not checkable),
  assigned by a small lexical heuristic (annotation is synthetic on purpose).

Functional/structural tokens (case, det, cc, punct, expl, ...) are contracted
away, matching the compositional tree the CRF actually runs on.

Usage:
    python scripts/generate_example_tree_figure.py [CLAIM_ID ...] \
        [--outdir DIR] [--formats png,svg,pdf]

Needs the system `dot` (graphviz); no python graphviz binding required.
"""
import argparse
import json
import os
import re
import subprocess
import sys
from html import escape

TREES = "exp/phase3/trees/trees_ud.jsonl"
DEFAULT_OUTDIR = "slides/figures"
DEFAULT_CLAIMS = ["Txf2EdqOg1SQ_2219"]  # "A woman with glasses speaks indoors."

# faint fills (reuse project palette) + a darker ink for the channel label
CH = {
    "visual_other": ("#BBDEFB", "#1565C0", "Visual"),
    "visual_ocr":   ("#B3E5FC", "#0277BD", "On-screen text"),
    "audio_speech": ("#C8E6C9", "#2E7D32", "Speech"),
    "audio_other":  ("#FFE0B2", "#E65100", "Other audio"),
    "na":           ("#ECEFF1", "#78909C", "Not checkable"),
}
CH_ORDER = ["visual_other", "visual_ocr", "audio_speech", "audio_other", "na"]

BORDER = "#9AA0A6"
EDGE = "#B0B6BD"
EDGE_LBL = "#8A9199"
NEG = "#C62828"

_SPEECH = re.compile(r"\b(speak\w*|spoke|say\w*|said|tell\w*|told|talk\w*|announc\w*|"
                     r"chant\w*|shout\w*|yell\w*|state[sd]?|address\w*|declar\w*|quote\w*|"
                     r"speaker|dialogue|conversation)\b", re.I)
_AUDIO = re.compile(r"\b(honk\w*|bark\w*|siren\w*|alarm\w*|music|melod\w*|applau\w*|cheer\w*|"
                    r"clap\w*|roar\w*|rev\w*|engine\w*|whistl\w*|drum\w*|horn\w*|noise|sound\w*|"
                    r"explos\w*|gunshot\w*|gunfire|laugh\w*|scream\w*|cry|cries|blast\w*|sing\w*|"
                    r"song\w*|band|beep\w*|ring\w*|thunder\w*|bang\w*|loud)\b", re.I)
_OCR = re.compile(r"\b(sign\w*|caption\w*|banner\w*|label\w*|logo\w*|subtitle\w*|headline\w*|"
                  r"scoreboard|watermark|timestamp|chyron|text|screen)\b", re.I)
_NA = re.compile(r"\b(because|therefore|cause[ds]?|reason\w*|intent\w*|purpose|want\w*|"
                 r"tr(?:y|ies|ied|ying)|allegedly|apparently|seem\w*|appear\w*|believ\w*|"
                 r"think\w*|thought|feel\w*|felt|in order)\b", re.I)


def classify(node, override):
    if node["node_id"] in override:
        return override[node["node_id"]]
    t = node["node_text"]
    if '"' in t or "'" in t or "“" in t:      # quoted words -> spoken
        return "audio_speech"
    if _SPEECH.search(t):
        return "audio_speech"
    if _AUDIO.search(t):
        return "audio_other"
    if _OCR.search(t):
        return "visual_ocr"
    if _NA.search(t) or node.get("node_type") in ("modal", "causal"):
        return "na"
    return "visual_other"


def load(claim_id):
    with open(TREES) as f:
        for line in f:
            r = json.loads(line)
            if r["claim_id"] == claim_id:
                return r
    raise SystemExit(f"claim_id {claim_id} not found in {TREES}")


def build_dot(rec, override):
    nd = {n["node_id"]: n for n in rec["nodes"]}
    used = set()
    lines = [
        "digraph T {",
        '  bgcolor="transparent";',
        "  rankdir=TB; nodesep=0.30; ranksep=0.46; pad=0.15;",
        '  graph [fontname="Helvetica", fontsize=13, labelloc="t", '
        f'label=<<FONT POINT-SIZE="13" COLOR="#333333"><I>&#8220;{escape(rec["claim_text"])}&#8221;</I></FONT>>];',
        f'  node [shape=box, style="rounded,filled", fontname="Helvetica", '
        f'color="{BORDER}", penwidth=1.0, margin="0.10,0.05"];',
        f'  edge [color="{EDGE}", penwidth=1.1, arrowsize=0.6, fontname="Helvetica", '
        f'fontsize=9, fontcolor="{EDGE_LBL}"];',
    ]

    def node_line(n):
        ch = classify(n, override)
        used.add(ch)
        fill, ink, name = CH[ch]
        word = escape(n["node_text"])
        pen = f'penwidth=1.0, color="{BORDER}"'
        neg = n.get("negated") or n.get("is_negation")
        if neg:
            pen = f'penwidth=2.0, color="{NEG}"'
            word = "&#172; " + word          # ¬ marks a negated unit
        lbl = (f'<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0"><TR><TD>'
               f'<FONT POINT-SIZE="15" COLOR="#212121"><B>{word}</B></FONT></TD></TR>'
               f'<TR><TD><FONT POINT-SIZE="9" COLOR="{ink}">{name.upper()}</FONT>'
               f'</TD></TR></TABLE>>')
        lines.append(f'  {n["node_id"]} [label={lbl}, fillcolor="{fill}", {pen}];')

    # traverse, contracting functional nodes onto their nearest content ancestor
    def walk(nid, disp_parent):
        n = nd[nid]
        if n.get("is_functional") or n.get("rel_class") == "structural":
            for c in n["children"]:
                walk(c, disp_parent)
            return
        node_line(n)
        if disp_parent is not None:
            rel = escape(n.get("deprel", ""))
            lines.append(f'  {disp_parent} -> {n["node_id"]} [label=" {rel}"];')
        for c in n["children"]:
            walk(c, n["node_id"])

    walk(rec["root_id"], None)

    # dynamic legend (only channels that appear), horizontal, pinned to bottom
    swatches = ""
    for ch in CH_ORDER:
        if ch in used:
            fill, ink, name = CH[ch]
            swatches += (f'<TD BGCOLOR="{fill}" WIDTH="16"> </TD>'
                         f'<TD ALIGN="LEFT"><FONT POINT-SIZE="10" COLOR="#333333">'
                         f'{name}</FONT></TD>')
    legend = (
        '<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="4" CELLPADDING="2">'
        '<TR><TD ALIGN="LEFT"><FONT POINT-SIZE="10" COLOR="#333333"><B>Grounding '
        'channel</B> <FONT COLOR="#999999">(illustrative)</FONT></FONT></TD></TR>'
        '<TR><TD><TABLE BORDER="0" CELLBORDER="1" CELLSPACING="4" CELLPADDING="3" '
        f'COLOR="#DDDDDD"><TR>{swatches}</TR></TABLE></TD></TR></TABLE>>')
    lines.append(f'  legend [shape=box, style="rounded", color="#DDDDDD", '
                 f'fillcolor="white", margin="0.12,0.07", label={legend}];')
    lines.append(f'  {rec["root_id"]} -> legend [style=invis];')
    lines.append("  { rank=sink; legend; }")
    lines.append("}")
    return "\n".join(lines)


def render(rec, override, outdir, formats):
    os.makedirs(outdir, exist_ok=True)
    dot = build_dot(rec, override)
    base = os.path.join(outdir, f"example_tree_{rec['claim_id']}")
    with open(base + ".dot", "w") as f:
        f.write(dot)
    for fmt in formats:
        args = ["dot", f"-T{fmt}"]
        if fmt == "png":
            args += ["-Gdpi=300"]
        args += [base + ".dot", "-o", f"{base}.{fmt}"]
        subprocess.run(args, check=True)
    print(f"[{rec['claim_id']}] {rec['claim_text']!r} -> {base}.{{{','.join(formats)}}}")
    return base


# per-claim label overrides (node_id -> channel) to keep the demo figure exact
OVERRIDES = {
    # "People are cheering because of the home run." : make the causal relation na
    "TLO3smKI67PM_541": {},
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("claim_ids", nargs="*", default=DEFAULT_CLAIMS)
    ap.add_argument("--outdir", default=DEFAULT_OUTDIR)
    ap.add_argument("--formats", default="png,svg,pdf")
    a = ap.parse_args()
    ids = a.claim_ids or DEFAULT_CLAIMS
    fmts = [x.strip() for x in a.formats.split(",") if x.strip()]
    for cid in ids:
        render(load(cid), OVERRIDES.get(cid, {}), a.outdir, fmts)


if __name__ == "__main__":
    main()
