"""
AViD Phase 3 — Tree-CRF inference (pure functions, no I/O).

States: [0=no, 1=A, 2=B]
  visual: A=ocr, B=other
  audio:  A=speech, B=other

Unary potential φ_v(s) from calibrated p, q_A, q_B:
  φ(0=no) = 1 − p
  φ(1=A)  = p · q_A
  φ(2=B)  = p · q_B
Negated node: flip p → (1-p), keeping q split.
Functional / unprobeable node: uniform φ = [1/3, 1/3, 1/3].

Edge potential ψ_{rel}(s_p, s_c) 3×3 matrix (rows=parent, cols=child):
  core-arg / coordination-and: exp(-λ) if sup(p) ∧ ¬sup(c), else 1
  coordination-or:              exp(-λ) if sup(head) ∧ all_conjuncts¬sup (approx as and)
  verif-mod:                    exp(-λ_soft) if sup(p) ∧ ¬sup(c); λ_soft ≪ λ → partial, not veto
  modifier / oblique / root:    all 1 (decoupled)
  structural:                   all 1 (contracted node; should not appear in CRF)

sup(s) := s != 0 (no).

Belief propagation on a fixed rooted tree (exact):
  UP   m_{c→p}(s_p) = Σ_{s_c} φ_c(s_c) · ψ(s_p,s_c) · Π_{k∈ch(c)} m_{k→c}(s_c)
  DOWN m_{p→c}(s_c) = Σ_{s_p} φ_p(s_p) · ψ(s_p,s_c) · m_{pa→p}(s_p) · Π_{c'≠c} m_{c'→p}(s_p)
  b_v(s) ∝ φ_v(s) · m_{pa→v}(s) · Π_c m_{c→v}(s)

max-product replaces Σ with max + backpointer for MAP.
"""

import math
from typing import Optional

import numpy as np

N_STATES = 3  # no, A, B
NO, A, B = 0, 1, 2
SUP = np.array([False, True, True])  # sup(s) = s != NO


# ---------------------------------------------------------------------------
# Unary potentials
# ---------------------------------------------------------------------------

def unary_uniform() -> np.ndarray:
    """Uniform potential — no evidence (na / unprobeable node)."""
    return np.ones(N_STATES) / N_STATES


def unary_from_probe(p: float, q_A: float, q_B: float,
                     negated: bool = False) -> np.ndarray:
    """Build φ from pass-1 support probability p and pass-2 subtype split q_A, q_B.

    If negated, flip the support polarity: p → 1−p (scope of a neg token).
    q_A + q_B should sum to ~1; re-normalized here if not (degenerate pass-2).
    """
    total_q = q_A + q_B
    if total_q < 1e-9:
        q_A = q_B = 0.5
    else:
        q_A /= total_q
        q_B /= total_q
    if negated:
        p = 1.0 - p
    phi = np.array([1.0 - p, p * q_A, p * q_B])
    # Numerical safety: clamp and renormalize
    phi = np.clip(phi, 1e-12, None)
    phi /= phi.sum()
    return phi


# ---------------------------------------------------------------------------
# Edge potentials
# ---------------------------------------------------------------------------

_PSI_UNIT = np.ones((N_STATES, N_STATES))  # identity (no constraint)


def edge_potential(rel_class: str, lam: float,
                   lam_soft: float = 0.0) -> np.ndarray:
    """3×3 ψ matrix (rows=parent state, cols=child state).

    rel_class may be the original rel_class string (core-arg, …) or the PN-2
    comp field (core, verif-mod, inert-mod, …) — both are handled.

    lam_soft: λ for verif-mod edges (soft-gate; should satisfy λ_soft ≪ λ).
              Defaults to lam/3 when 0 is passed.
    """
    if rel_class in ("core-arg", "core", "coordination-and", "coord",
                     "coordination-or"):
        psi = np.ones((N_STATES, N_STATES))
        penalty = math.exp(-lam)
        for sp in range(N_STATES):
            if SUP[sp]:
                psi[sp, NO] = penalty
        return psi
    if rel_class == "verif-mod":
        # Soft-gate: verified-false → partial, not veto (λ_soft ≪ λ_core)
        psi = np.ones((N_STATES, N_STATES))
        ls = lam_soft if lam_soft > 0.0 else lam / 3.0
        penalty = math.exp(-ls)
        for sp in range(N_STATES):
            if SUP[sp]:
                psi[sp, NO] = penalty
        return psi
    # modifier, inert-mod, oblique, root, drop, neg, structural, unknown
    return _PSI_UNIT


# ---------------------------------------------------------------------------
# Belief propagation helpers
# ---------------------------------------------------------------------------

def _postorder(root: str, children: dict[str, list[str]]) -> list[str]:
    """Return nodes in post-order (leaves first, root last).

    Cycle-safe: each node is appended at most once.
    """
    order = []
    seen: set[str] = set()
    stack = [(root, False)]
    while stack:
        nid, visited = stack.pop()
        if visited:
            if nid not in seen:
                seen.add(nid)
                order.append(nid)
        else:
            if nid in seen:
                continue
            stack.append((nid, True))
            for c in reversed(children.get(nid, [])):
                if c not in seen:
                    stack.append((c, False))
    return order


# ---------------------------------------------------------------------------
# Sum-product (marginal) inference
# ---------------------------------------------------------------------------

def sum_product(
    root_id: str,
    node_ids: list[str],
    children: dict[str, list[str]],
    parent: dict[str, Optional[str]],
    rel_class_of: dict[str, str],
    unaries: dict[str, np.ndarray],
    lam: float,
    lam_soft: float = 0.0,
) -> dict[str, np.ndarray]:
    """Run sum-product BP; return per-node belief vectors (unnormalized marginals).

    Args:
        root_id:      ID of the root node.
        node_ids:     IDs of all CRF variables (non-functional nodes).
        children:     node_id → list of child node_ids.
        parent:       node_id → parent node_id or None for root.
        rel_class_of: node_id → rel_class / comp of the edge to its parent.
        unaries:      node_id → φ array (length N_STATES).
        lam:          necessity strength λ (core-arg / coord edges).
        lam_soft:     soft-gate λ for verif-mod edges (0 → lam/3).

    Returns:
        beliefs: node_id → normalized probability array over N_STATES.
    """
    # Up-messages m_{c→p}  (length N_STATES each)
    up: dict[str, np.ndarray] = {}
    order = _postorder(root_id, children)

    for nid in order:
        phi = unaries[nid]
        # Incoming up-messages from children (skip any child not yet computed
        # — can happen if the tree structure has a cycle; treat as uninformative)
        child_msgs = np.ones(N_STATES)
        for c in children.get(nid, []):
            if c in up:
                child_msgs *= up[c]
        # Product of φ and child messages
        local = phi * child_msgs  # shape (N_STATES,)

        pid = parent.get(nid)
        if pid is None:
            # Root: up-message is unused externally but we store for completeness
            up[nid] = local
        else:
            psi = edge_potential(rel_class_of[nid], lam, lam_soft)
            # m_{nid→pid}(s_p) = Σ_{s_c} psi[s_p, s_c] · local[s_c]
            msg = psi @ local  # (N_STATES, N_STATES) @ (N_STATES,) = (N_STATES,)
            up[nid] = msg

    # Down-messages m_{p→c}
    down: dict[str, np.ndarray] = {root_id: np.ones(N_STATES)}
    for nid in reversed(order):  # pre-order = reversed post-order
        phi = unaries[nid]
        children_list = children.get(nid, [])
        if not children_list:
            continue

        # Product of all incoming signals at nid
        parent_msg = down[nid]  # m_{pa→nid} (or ones for root)
        child_msgs_all = {c: up[c] for c in children_list}

        all_up = np.ones(N_STATES)
        for c in children_list:
            all_up *= child_msgs_all[c]

        for c in children_list:
            # exclude c from all_up
            up_excluding_c = all_up / np.clip(child_msgs_all[c], 1e-12, None)
            # local factor at parent excluding the c→parent message
            local_excl = phi * parent_msg * up_excluding_c
            psi = edge_potential(rel_class_of[c], lam, lam_soft)
            # m_{nid→c}(s_c) = Σ_{s_p} psi[s_p, s_c] · local_excl[s_p]
            # = local_excl @ psi  (transpose: psi.T[s_c, s_p] = psi[s_p, s_c])
            msg = local_excl @ psi  # (N_STATES,) @ (N_STATES, N_STATES) = (N_STATES,)
            down[c] = msg

    # Beliefs
    beliefs: dict[str, np.ndarray] = {}
    for nid in node_ids:
        if nid not in up:
            # Node not reached in traversal (isolated cycle); use uniform
            beliefs[nid] = unary_uniform()
            continue
        phi = unaries[nid]
        parent_msg = down.get(nid, np.ones(N_STATES))
        child_prod = np.ones(N_STATES)
        for c in children.get(nid, []):
            if c in up:
                child_prod *= up[c]
        b = phi * parent_msg * child_prod
        s = b.sum()
        beliefs[nid] = b / s if s > 1e-12 else np.full(N_STATES, 1.0 / N_STATES)
    return beliefs


# ---------------------------------------------------------------------------
# Max-product (MAP) inference
# ---------------------------------------------------------------------------

def max_product(
    root_id: str,
    node_ids: list[str],
    children: dict[str, list[str]],
    parent: dict[str, Optional[str]],
    rel_class_of: dict[str, str],
    unaries: dict[str, np.ndarray],
    lam: float,
    lam_soft: float = 0.0,
) -> dict[str, int]:
    """Run max-product BP (log domain for stability); return MAP label dict.

    Returns:
        map_labels: node_id → argmax state index (0=no, 1=A, 2=B).
    """
    log_unaries = {nid: np.log(np.clip(unaries[nid], 1e-12, None))
                   for nid in node_ids}

    # Up-messages in log domain
    log_up: dict[str, np.ndarray] = {}
    order = _postorder(root_id, children)

    for nid in order:
        log_phi = log_unaries[nid]
        log_child_sum = np.zeros(N_STATES)
        for c in children.get(nid, []):
            if c in log_up:
                log_child_sum += log_up[c]
        local_log = log_phi + log_child_sum

        pid = parent.get(nid)
        if pid is None:
            log_up[nid] = local_log
        else:
            psi = edge_potential(rel_class_of[nid], lam, lam_soft)
            log_psi = np.log(np.clip(psi, 1e-12, None))
            # m_{nid→pid}(s_p) = max_{s_c} psi[s_p, s_c] · local[s_c]
            # log: max_{s_c} (log_psi[s_p, s_c] + local_log[s_c])
            msg_log = np.array([
                (log_psi[sp, :] + local_log).max()
                for sp in range(N_STATES)
            ])
            log_up[nid] = msg_log

    # Down-messages in log domain
    log_down: dict[str, np.ndarray] = {root_id: np.zeros(N_STATES)}
    # Backpointers: (nid, parent_state) → child_state
    back: dict[tuple[str, int], dict[str, int]] = {}

    for nid in reversed(order):
        log_phi = log_unaries[nid]
        children_list = children.get(nid, [])
        if not children_list:
            continue
        parent_log = log_down[nid]
        child_log_all = {c: log_up[c] for c in children_list if c in log_up}
        all_up_log = np.zeros(N_STATES)
        for c, lv in child_log_all.items():
            all_up_log += lv

        for c in children_list:
            c_log = child_log_all.get(c, np.zeros(N_STATES))
            up_excl_log = all_up_log - c_log
            local_excl_log = log_phi + parent_log + up_excl_log
            psi = edge_potential(rel_class_of[c], lam, lam_soft)
            log_psi = np.log(np.clip(psi, 1e-12, None))
            # m_{nid→c}(s_c) = max_{s_p} psi[s_p, s_c] · local_excl[s_p]
            msg_log = np.zeros(N_STATES)
            bp_row: dict[int, int] = {}
            for sc in range(N_STATES):
                scores = log_psi[:, sc] + local_excl_log
                best_sp = int(scores.argmax())
                msg_log[sc] = scores[best_sp]
                bp_row[sc] = best_sp
            log_down[c] = msg_log
            back[(nid, sc)] = bp_row  # store for each sc

    # Find root MAP state
    log_phi = log_unaries[root_id]
    log_child_sum = np.zeros(N_STATES)
    for c in children.get(root_id, []):
        if c in log_up:
            log_child_sum += log_up[c]
    root_scores = log_phi + log_down.get(root_id, np.zeros(N_STATES)) + log_child_sum
    map_labels: dict[str, int] = {root_id: int(root_scores.argmax())}

    # Backtrack top-down
    for nid in order[:-1]:  # all except root (last in post-order)
        pid = parent[nid]
        if pid not in map_labels:
            continue
        sp = map_labels[pid]
        psi = edge_potential(rel_class_of[nid], lam, lam_soft)
        log_psi = np.log(np.clip(psi, 1e-12, None))
        log_phi_c = log_unaries[nid]
        log_child_c = np.zeros(N_STATES)
        for c in children.get(nid, []):
            if c in log_up:
                log_child_c += log_up[c]
        log_down_c = log_down.get(nid, np.zeros(N_STATES))
        scores_c = log_psi[sp, :] + log_phi_c + log_down_c + log_child_c
        map_labels[nid] = int(scores_c.argmax())

    # Any node not reached by traversal (isolated cycle) → assign 0 (no)
    for nid in node_ids:
        if nid not in map_labels:
            map_labels[nid] = NO
    return map_labels


# ---------------------------------------------------------------------------
# Utility: evidence gap diagnostic
# ---------------------------------------------------------------------------

def evidence_gap(belief_marginal: np.ndarray, unary: np.ndarray) -> float:
    """e_v − s_v: unary-implied support minus marginal support.

    Positive = structure pulled support down; negative = structure propped it up.
    """
    e_v = float(unary[A] + unary[B])   # unary-implied support (before BP)
    s_v = float(belief_marginal[A] + belief_marginal[B])  # posterior support
    return e_v - s_v
