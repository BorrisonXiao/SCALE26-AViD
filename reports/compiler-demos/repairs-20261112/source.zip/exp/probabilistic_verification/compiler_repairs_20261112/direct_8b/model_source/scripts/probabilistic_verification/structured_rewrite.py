"""Simple sentences plus an explicit AND/OR syntax tree; no generated predicates."""
import copy,json,jsonschema
from .claim_split import FORMULA
SCHEMA=dict(type='object',properties=dict(action=dict(type='string',enum=['rewrite','keep','refuse']),sentences=dict(type='array',maxItems=8,items=dict(type='string')),formula=dict(anyOf=[{'$ref':'#/$defs/formula'},dict(type='null')])),required=['action','sentences','formula'],additionalProperties=False,**{'$defs':dict(formula=FORMULA)})
SYSTEM='''Simplify the claim without changing its meaning. Return the fewest complete sentences, preferably one. Keep the original names, modifiers, counts, tense, uncertainty, negation, quotations and source (depiction/speech/written text). Keep qualifications with everything they qualify. Do not turn goals or possibilities into events that happened. Do not invent entities or event descriptions just to split a sentence. Each sentence must be self-contained and grammatical. Preserve shared participants and events. Do not duplicate a sentence.
Return JSON: action=rewrite, sentences, and formula. A formula leaf is a 1-based sentence number; internal nodes are {"op":"and" or "or","children":[...]}. Use every sentence once. For one sentence, formula=1. Do not add OR or copy a count to another alternative unless the original says so. If simplification is impossible, action=refuse, sentences=[], formula=null. The supplied parses may be wrong; the original claim controls the meaning.'''
REVISED_SYSTEM='''The original claim FAILED compilation. Rewrite its sentence structure to avoid the supplied error. Do not return the rejected wording unchanged. Usually use 2–4 short clauses, keeping names, modifiers, counts, tense, negation, uncertainty, exact quotations and source. Keep a qualification with the full statement it qualifies. Do not assert a goal, possibility or quoted claim as an actual event.
Return JSON: action=rewrite, sentences, formula. A formula leaf is a 1-based sentence number; internal nodes use op=and/or and children. Use every sentence exactly once. Preserve OR and the original scope of each count. Shared people/events must remain identifiable. For one genuinely simpler sentence, formula=1. Refuse rather than invent missing information.
Examples:
"Cars were parked in Boston on Monday." -> sentences=["Cars were parked.","The parking was in Boston.","The parking occurred on Monday."], formula={"op":"and","children":[1,2,3]}.
"Six knocks were heard or an alarm sounded." -> sentences=["Six knocks were heard.","An alarm sounded."], formula={"op":"or","children":[1,2]}.
"Flooding likely in the town." -> sentences=["Flooding is likely in the town."], formula=1.
The original controls the meaning; the supplied parses may be wrong. After feedback, change the rejected structure instead of repeating it.'''

def validate(data):
    jsonschema.validate(data,SCHEMA)
    if data['action']!='rewrite':
        if data['sentences']or data['formula']is not None:raise ValueError('Keep/refuse must not add sentences or formula.')
        return
    if not data['sentences']or data['formula']is None:raise ValueError('Rewrite needs sentences and a formula.')
    if len(set(data['sentences']))!=len(data['sentences']):raise ValueError('Duplicate sentences are not a simplification.')
    leaves=[]
    def visit(n):
        if isinstance(n,int):leaves.append(n)
        else:
            for c in n['children']:visit(c)
    visit(data['formula'])
    if sorted(leaves)!=list(range(1,len(data['sentences'])+1)):raise ValueError('Formula must use each sentence exactly once.')

def proposal(data):
    validate(data)
    return dict(action='split'if len(data['sentences'])>1 else'rewrite'if data['sentences']else data['action'],clauses=[dict(id='c'+str(i+1),text=t)for i,t in enumerate(data['sentences'])],formula=data['formula'])

def request(record,amr=None):
    return dict(claim=record['text'],syntax=[{k:t.get(k)for k in ['id','text','lemma','upos','head','deprel','feats']}for t in record['tokens']],srl=record.get('srl',{}).get('frames',[]),amr=amr)
