"""One frozen local model; exact prompts and raw outputs are saved."""
import argparse,hashlib,importlib.metadata,json,os,time
from pathlib import Path
from probabilistic_verification.claim_rewrite import messages,SCHEMA,SYSTEM,prepare_rewrite_inputs
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--system-prompt',type=Path);p.add_argument('--diagnostics',type=Path);p.add_argument('--plan-only',action='store_true',help='Record compile-first routing without loading or calling a language model.');a=p.parse_args()
 records=list(map(json.loads,a.input.read_text().splitlines()));assert not a.output.exists(),'Use a separate output for every condition.'
 from run_content_relations_census import compile_one
 records,routes=prepare_rewrite_inputs(records,compile_one)
 a.output.parent.mkdir(parents=True,exist_ok=True)
 routing=dict(input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),total=len(routes),planned_rewrite_requests=len(records),direct_passes_skipped=len(routes)-len(records),model_called=False,routes=routes)
 a.output.with_suffix('.routing.json').write_text(json.dumps(routing,ensure_ascii=False,indent=2)+'\n')
 print('Direct compilation:',len(records),'failures eligible;',len(routes)-len(records),'passes skipped.',flush=True)
 if a.plan_only or not records:return
 from vllm import LLM,SamplingParams
 from vllm.sampling_params import StructuredOutputsParams
 import torch
 model=Path('/exp/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507')
 config=dict(model=str(model),dtype='float16',temperature=0,seed=42,max_tokens=768,
   vllm=importlib.metadata.version('vllm'),transformers=importlib.metadata.version('transformers'),
   slurm_job_id=os.getenv('SLURM_JOB_ID'),gpu_names=[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())],
   input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
   source_sha256={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path(__file__),ROOT/'scripts/probabilistic_verification/claim_rewrite.py']},
   model_sha256={n:hashlib.sha256((model/n).read_bytes()).hexdigest() for n in ['config.json','tokenizer_config.json','generation_config.json']})
 a.output.parent.mkdir(parents=True,exist_ok=True)
 system=a.system_prompt.read_text() if a.system_prompt else SYSTEM
 diagnostics=json.loads(a.diagnostics.read_text()) if a.diagnostics else {}
 config.update(system_prompt=system,diagnostics_sha256=hashlib.sha256(a.diagnostics.read_bytes()).hexdigest() if a.diagnostics else None)
 a.output.with_suffix('.config.json').write_text(json.dumps(config,indent=2)+'\n')
 llm=LLM(model=str(model),dtype='float16',tensor_parallel_size=1,max_model_len=8192,
   gpu_memory_utilization=.90,max_num_seqs=16,enforce_eager=True,enable_prefix_caching=True,seed=42)
 tok=llm.get_tokenizer();params=SamplingParams(temperature=0,seed=42,max_tokens=768,structured_outputs=StructuredOutputsParams(json=SCHEMA))
 for start in range(0,len(records),32):
  batch=records[start:start+32];requests=[messages(r,system=system,diagnostic=diagnostics.get(r['claim_id'])) for r in batch]
  prompts=[tok.apply_chat_template(m,tokenize=False,add_generation_prompt=True) for m in requests]
  routing['model_called']=True
  a.output.with_suffix('.routing.json').write_text(json.dumps(routing,ensure_ascii=False,indent=2)+'\n')
  begin=time.perf_counter();outputs=llm.generate(prompts,params,use_tqdm=False);elapsed=time.perf_counter()-begin
  with a.output.open('a') as f:
   for r,m,out in zip(batch,requests,outputs):
    result=out.outputs[0]
    f.write(json.dumps(dict(claim_id=r['claim_id'],messages=m,raw=result.text,finish_reason=result.finish_reason,
      input_tokens=len(out.prompt_token_ids),output_tokens=len(result.token_ids),batch_seconds=elapsed,batch_size=len(batch)),ensure_ascii=False)+'\n')
  print('Saved',min(start+32,len(records)),'/',len(records),'seconds',round(elapsed,2),flush=True)
if __name__=='__main__':main()
