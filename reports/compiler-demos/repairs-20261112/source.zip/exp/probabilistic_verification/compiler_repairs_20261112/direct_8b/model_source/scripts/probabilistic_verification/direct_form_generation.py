"""Diagnostic LLM-to-logical-form interface, separate from the deployed path."""
import copy
from dataclasses import replace
from .logical_form_schema_v2 import SCHEMA as BASE
from .logical_form_v2 import ScopedCompiler
from .semantic_components import normalize_values,valid_alignment,semantic_alerts
from .scope_coverage import audit_content_coverage
SCHEMA=copy.deepcopy(BASE)
SCHEMA['properties'].pop('version');SCHEMA['required'].remove('version')
SCHEMA['properties']['action']=dict(type='string',enum=['parse','refuse']);SCHEMA['required'].append('action')
SCHEMA['properties']['formula']=dict(anyOf=[SCHEMA['properties']['formula'],dict(type='null')])
SYSTEM='''Translate the original claim into the specified logical form. The supplied syntax, semantic roles and AMR are aids; they may be wrong. Keep every participant, modifier, count, tense, negation, uncertainty, quotation and evidence source. Reuse an entity ID for coreferent mentions. Represent AND/OR and scoped qualifications explicitly; do not assert goals, possibilities or quoted propositions as actual events. Events use source predicates/anchors, with role-to-entity-ID or typed-literal arguments. Propositions represent embedded content with its source route. Return action=parse and the logical form, or action=refuse, entities=[], formula=null. Do not invent missing information.'''
def evaluate(record,data):
 from run_scope_coverage_census import compile_one
 if data['action']!='parse':return dict(status='unsupported',code='model_refuse',reason='Model declined a logical form.')
 form={k:v for k,v in data.items()if k!='action'};form['version']='logical-form-v2'
 def compile(r,strict=False):
  notes=[];alignments=[];normalize_values(r,form,notes,alignments)
  claim=ScopedCompiler().compile(r['claim_id'],r['text'],r['tokens'],form)
  f=claim.metadata['logical_form'];alignments=[a for a in alignments if valid_alignment(f,a)];coverage=audit_content_coverage(r,f)
  credited={t['id']for a in alignments for t in r['tokens']if a['start']<=t['start_char']and t['end_char']<=a['end']}
  coverage['missing']=[t for t in coverage['missing']if t['id']not in credited];coverage['complete']=not coverage['missing']
  return replace(claim,metadata=dict(claim.metadata,content_coverage=coverage,structural_alerts=semantic_alerts(r,f,alignments))),notes
 return compile_one(record,compiler=compile)
