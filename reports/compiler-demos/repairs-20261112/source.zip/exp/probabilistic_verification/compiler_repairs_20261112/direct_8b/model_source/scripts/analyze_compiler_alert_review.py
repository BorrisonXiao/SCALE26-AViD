"""Recount fixed historical metrics and validate the diagnostic review inventory."""
import hashlib,json
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/compiler_alert_review_20261111'
BASE=ROOT/'exp/probabilistic_verification/content_relations_20261105'

def read(name):return json.loads((RUN/name).read_text())
def rows(path):return {r['claim_id']:r for r in map(json.loads,path.read_text().splitlines())}
def dump(name,value):(RUN/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def main():
    for name,h in read('inputs_sha256.json').items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,name
    frozen=json.loads((BASE/'frozen_manifest.json').read_text())
    for name,h in frozen['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,name
    assert hashlib.sha256((RUN/'passing_control_readings.json').read_bytes()).hexdigest()==read('readings_freeze.json')['sha256']
    history=[];all_rows={}
    stages=[('compiler_revision_20261105','Schema/syntax checks; no content audit'),('scope_coverage_20261105','Schema/syntax plus word coverage'),
            ('content_recovery_20261105','Word coverage plus clause/list checks'),('content_relations_20261105','Word coverage plus clause/list checks')]
    for name,checks in stages:
        rs=rows(ROOT/'exp/probabilistic_verification'/name/'results.jsonl');assert len(rs)==2375;all_rows[name]=rs
        history.append(dict(run=name,generated=sum('program'in r for r in rs.values()),recorded_status_pass=sum(r['status']=='compiled'for r in rs.values()),
            content_check_pass=None if name=='compiler_revision_20261105'else sum(r['status']=='compiled'for r in rs.values()),checks=checks,
            note='Recorded checks changed between stages; this column is not semantic accuracy.'))
    current=all_rows[stages[-1][0]];old=all_rows[stages[0][0]]
    generated={c for c,r in current.items()if 'program'in r};old_generated={c for c,r in old.items()if 'program'in r}
    assert old_generated<=generated
    annotations=read('review_annotations.json');manifest=read('sample_manifest.json')
    for field,ids in [('alerts',manifest['alerts']),('refusals',manifest['refusal_sample']),('passing_controls',manifest['accepted_controls'])]:
        seen=[r['claim_id']for r in annotations[field]];assert len(seen)==len(set(seen))and set(seen)==set(ids),field
        for r in annotations[field]:assert r['text']==current[r['claim_id']]['text'],r['claim_id']
    assert set(manifest['alerts'])=={c for c,r in current.items()if 'program'in r and r['status']!='compiled'}
    assert len(annotations['alerts'])==179 and len(annotations['passing_controls'])==23
    assert len({c.rsplit('_',1)[0]for c in manifest['accepted_controls']})==23
    suspect=read('passing_clause_review.json')['cases'];assert len(suspect)==22
    for r in suspect:assert current[r['claim_id']]['status']=='compiled'
    summary=dict(total=2375,generated=len(generated),pass_current_content_checks=sum(r['status']=='compiled'for r in current.values()),
        candidate_alerts=179,no_program=2375-len(generated),strict_refusals=451,strict_refusal_percent=round(451/2375*100,1),
        original_2099_still_generated=len(old_generated&generated),added_candidates=sorted(generated-old_generated),
        old_candidate_current_outcomes=dict(sorted(Counter('passes_current_checks'if current[c]['status']=='compiled'else current[c]['code']for c in old_generated).items())),
        alert_review=dict(sorted(Counter(r['verdict']for r in annotations['alerts']).items())),
        alert_families=dict(sorted(Counter(r['family']for r in annotations['alerts']).items())),
        refusal_sample=dict(total=len(annotations['refusals']),recommendations=dict(sorted(Counter(r['recommendation']for r in annotations['refusals']).items()))),
        passing_controls=dict(total=23,ratings=dict(sorted(Counter(r['rating']for r in annotations['passing_controls']).items()))),
        passing_clause_search=dict(total=22,ratings=dict(sorted(Counter(r['verdict']for r in suspect).items()))),
        compiler_source_files_unchanged=len(frozen['source_sha256']),new_compiler_runs=0,new_models_or_gpu_jobs=0,
        automatic_status_changes=0,rewrite_implemented=False,
        limitations=['Assistant diagnostic judgments, not independent human gold','Refusal sample and targeted clause search do not estimate corpus rates','Passing controls cover23 original-video groups, not an independent held-out test','No rewrite-success or training/inference gain has been measured'])
    dump('history.json',history);dump('summary.json',summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
