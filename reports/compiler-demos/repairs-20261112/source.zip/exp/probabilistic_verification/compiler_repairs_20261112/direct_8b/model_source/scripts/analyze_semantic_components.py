"""Measured comparisons, explicit fidelity reviews, and compact report cases."""
import hashlib,json
from collections import Counter
from pathlib import Path
from run_semantic_components import CONDITIONS,compile_condition,form,read,write
from build_reviewed_compilation_report import slim

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/semantic_components_20261112'
OLD=ROOT/'exp/probabilistic_verification/rewrite_all_20261112'
NEW_REVIEWS={
'Tg0UxWYuPeJ0_417':(True,'Four remains the robot count;100m remains the dash measurement. Only canonical measurement serialization changes.'),
'T8u81WMIyj18_755':(True,'The same parking event retains its car, explicit01:53 clock time and August19,2025 date. The original SRL ARG2 label is retained for the typed clock value; no date or time zone is invented.'),
'TjHepwuhkYFA_1035':(True,'Magnitude7.7 remains a typed scalar owned by the earthquake; raw source text moves to alignment metadata.'),
'T2G_ACMxR_I4_1441':(True,'The braking burn, Blue Ghost velocity and40m/s endpoint remain bound as before; canonical measurement serialization only.'),
'TFgw4IaR9R8s_1521':(True,'April2,2025 is a typed date of the reported screen content, inside OCR assertion scope; top-left location remains attached to the text.'),
'TgR_u37mCoQ4_1900':(False,'Dates normalize, but the rewrite still invents explicit start/end conditions and leaves4hours long as text. It does not establish the intended interval/duration relationship.'),
'Txf2EdqOg1SQ_2324':(True,'The visible timestamp belongs to the same dashcam footage and preserves the complete2025-07-20T09:54:00 value. No offset or time zone is guessed.'),
'Txf2EdqOg1SQ_2344':(False,'90kg canonicalizes, but unresolved he and the scope of the struggle remain. Quantity normalization does not repair these references.'),
'Txf2EdqOg1SQ_2350':(True,'Wipha movement still has northwest direction and a20–25km/h speed range; original spelling moves to alignment metadata.')}
WITHDRAWALS={
'TgR_u37mCoQ4_1831':'Fire spread and its two temporal endpoints remain an opaque entity phrase. There is no explicit spread event or linked interval.',
'TgR_u37mCoQ4_1908':'Fire growth and January8,2025 remain inside one opaque entity phrase; the date is not linked to a growth event.',
'TgR_u37mCoQ4_1924':'The update title and January12,2025 remain inside one opaque entity phrase; the date has no explicit link to the update.'}

def digest(row):return hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def main():
    old={r['claim_id']:r for r in read(OLD/'pipeline.jsonl')};prior_reviews={r['claim_id']:r for r in json.loads((OLD/'semantic_review.json').read_text())['cases']}
    pipelines={'previous':list(old.values())}
    for c in CONDITIONS:
        if c!='previous':pipelines[c]=read(RUN/('pipeline_'+c+'.jsonl'))
    new={r['claim_id']:r for r in pipelines['checked']};reviews=[];approved={};new_ids=[]
    for cid,row in new.items():
        output=row['output'];kind='pipeline_failure';faithful=False;reason=output.get('reason','No program.')
        if output['status']=='compiled':
            if cid in NEW_REVIEWS:
                faithful,reason=NEW_REVIEWS[cid];kind='newly_inspected_program'
            else:
                assert output.get('program')==old[cid]['output'].get('program')and form(output)==form(old[cid]['output']),cid
                faithful=prior_reviews[cid]['faithful'];reason=prior_reviews[cid]['reason'];kind='unchanged_program_and_form_review_reused'
            if faithful:approved[cid]=row
            if old[cid]['output']['status']!='compiled':new_ids.append(cid)
        reviews.append(dict(claim_id=cid,faithful=faithful,review_type=kind,reason=reason,artifact_sha256=digest(row)))
    assert set(new_ids)=={cid for cid,(ok,_)in NEW_REVIEWS.items()if ok and old[cid]['output']['status']!='compiled'}
    direct=read(RUN/'direct_all.jsonl');before=read(RUN/'previous_direct_all.jsonl');old_direct={r['claim_id']:r for r in before};current_direct={r['claim_id']:r for r in direct}
    gains=[r for r in direct if r['status']=='compiled'and old_direct[r['claim_id']]['status']!='compiled']
    losses=[r for r in direct if r['status']!='compiled'and old_direct[r['claim_id']]['status']=='compiled']
    assert {r['claim_id']for r in losses}==set(WITHDRAWALS)
    pool=[]
    for r in read(OLD/'corpus_reviewed.jsonl'):
        cid=r['claim_id']
        if cid in WITHDRAWALS:
            r=dict(r,status='unsupported',code='unlinked_temporal_value',reason=WITHDRAWALS[cid],acceptance='Withdrawn after compiler-author structural review; diagnostic candidate retained.')
        elif cid in approved:r=dict(approved[cid]['output'],claim_id=cid,text=r['text'],acceptance='Fixed checked condition; compiler-author fidelity judgment, not independent gold.')
        pool.append(r)
    write(RUN/'corpus_reviewed.jsonl',pool)
    (RUN/'semantic_review.json').write_text(json.dumps(dict(provenance='Compiler-author development review. Nine changed/new programs inspected;78 unchanged programs reuse their exact prior program/form judgments. Three newly flagged old passes inspected and withdrawn.',cases=reviews,withdrawals=[dict(claim_id=cid,reason=reason,artifact_sha256=digest(current_direct[cid]))for cid,reason in WITHDRAWALS.items()]),ensure_ascii=False,indent=2)+'\n')
    # Count the same1437 cached clauses in each condition. Sentences bypassed
    # by a new direct pass are diagnostic only, never used as fallback outputs.
    parsed={r['claim_id']:r for r in read(OLD/'parsed.jsonl')};component_stats={}
    for c,rows in pipelines.items():
        allparts=[]
        for row in rows:
            parts=row['components']
            if row['claim_id']in parsed and not parts and parsed[row['claim_id']]['proposal']['action']not in{'refuse','keep'}:
                source=parsed[row['claim_id']]
                parts=[dict(id=p['id'],result=compile_condition(p['record'],c)if 'record'in p else dict(status='unsupported',code='sentence_parse'))for p in source['clauses']]
            allparts.extend(p['result']for p in parts)
        assert len(allparts)==1437
        component_stats[c]=dict(total=len(allparts),passing=sum(r['status']=='compiled'for r in allparts),coverage_failures=sum(r.get('code')=='coverage_omission'for r in allparts),codes=dict(Counter(r.get('code')for r in allparts if r['status']!='compiled')))
    probes=read(RUN/'probe_results.jsonl')
    summary=dict(probes={c:dict(total=36,compiled=sum(r['compiled']for r in probes if r['condition']==c),target_checks=sum(r['target_ok']for r in probes if r['condition']==c))for c in CONDITIONS},cohort={c:dict(total=449,programs=sum(r['output']['status']=='compiled'for r in rows),direct_passes=sum(r['stage']=='direct_pass'for r in rows),stages=dict(Counter(r['stage']for r in rows)))for c,rows in pipelines.items()},components=component_stats,
        original_direct=dict(total=2375,before=sum(r['status']=='compiled'for r in before),after=sum(r['status']=='compiled'for r in direct),new_passes=[r['claim_id']for r in gains],new_refusals=[r['claim_id']for r in losses],changed_programs=sum(r.get('program')!=old_direct[r['claim_id']].get('program')for r in direct)),
        fidelity=dict(previous_approved=27,approved=len(approved),new_approved=len(new_ids),newly_inspected_programs=len(NEW_REVIEWS),reused_program_reviews=sum(r['review_type']=='unchanged_program_and_form_review_reused'for r in reviews),withdrawn_old_passes=len(WITHDRAWALS)),
        corpus=dict(total=2375,previous_accepted=1953,new_accepted=sum(r['status']=='compiled'for r in pool),rate=sum(r['status']=='compiled'for r in pool)/2375,remaining=sum(r['status']!='compiled'for r in pool)),new_model_requests=0,
        limits=['Construction probes and nine changed-program reviews are compiler-author diagnostics, not independent held-out accuracy.','Three new date recoveries are balanced by three newly reviewed exclusions; no net accepted-count gain.','Original direct counts and reviewed combined-corpus counts have different membership despite both being1953.','Temporal values may be retained raw when normalization is unavailable. Bare time codes retain an unspecified scale; no video offsets/time zones are guessed.'])
    assert summary['fidelity']['approved']==30 and summary['corpus']['new_accepted']==1953
    (RUN/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    changed=[dict(claim_id=r['claim_id'],text=r['text'],before=slim(old_direct[r['claim_id']]),after=slim(r))for r in gains+losses]
    (RUN/'direct_changes.json').write_text(json.dumps(changed,ensure_ascii=False,indent=2)+'\n')
    cases=[];spec={r['claim_id']:r for r in json.loads((RUN/'probes.json').read_text())};pmap={(r['condition'],r['claim_id']):r for r in probes}
    for cid,item in spec.items():
        a=pmap['previous',cid];b=pmap['checked',cid]
        cases.append(dict(id=cid,title='Construction probe: '+cid.replace('_',' '),text=item['text'],before=slim(a['output']),after=slim(b['output']),checks=b['checks'],note='Targeted value/relation checks; not a complete meaning label.',alignments=b['output'].get('compilation',{}).get('metadata',{}).get('source_alignments',[])))
    focal='TjHepwuhkYFA_1016';by_review={r['claim_id']:r for r in reviews}
    for cid in new_ids+list(WITHDRAWALS)+['T2EE72iNELEs_188','T8u81WMIyj18_754']:
        a=old_direct[cid];b=current_direct[cid]
        cases.append(dict(id=cid,title='Real claim: '+cid,text=b['text'],before=slim(a),after=slim(b),checks={},note=WITHDRAWALS.get(cid,by_review.get(cid,{}).get('reason','Typed temporal values are preserved; no independent whole-claim label.')),alignments=b.get('compilation',{}).get('metadata',{}).get('source_alignments',[])))
    for part in ['c1','c3','c5']:
        a=next(c for c in old[focal]['components']if c['id']==part);b=next(c for c in new[focal]['components']if c['id']==part)
        cases.append(dict(id=focal+'__'+part,title='Terrain example: '+part,text=b['text'],before=slim(a['result']),after=slim(b['result']),checks={},note='Whole original still refuses: '+new[focal]['output']['reason'],alignments=b['result'].get('compilation',{}).get('metadata',{}).get('source_alignments',[])))
    (RUN/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
