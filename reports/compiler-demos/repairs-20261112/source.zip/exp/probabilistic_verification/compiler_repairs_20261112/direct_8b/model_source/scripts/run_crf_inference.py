#!/usr/bin/env python3
"""
AViD Phase 3 — M0 Step 3: Run tree-CRF inference.

Loads exp/phase3/trees/trees_ud.jsonl + unary potentials (either from a
calibrated unaries file [M3+] or mapped directly from cached r5e scores
[M0 POC via --unaries-from-r5e]), runs sum-product and max-product BP
for both visual and audio modalities, and writes decomp_ud.jsonl.

Usage (M0 POC):
    python scripts/run_crf_inference.py \\
        --backbone ud --lambda 3.0 --unaries-from-r5e \\
        [--trees PATH] [--verify-visual PATH] [--verify-audio PATH] \\
        [--output PATH]

Usage (M3+):
    python scripts/run_crf_inference.py \\
        --backbone ud --lambda 3.0 \\
        --unaries exp/phase3/nodes/unaries_ud.jsonl \\
        [--trees PATH] [--output PATH]
"""

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from tree_crf import (
    N_STATES, NO, A, B,
    unary_uniform, unary_from_probe,
    sum_product, max_product, evidence_gap,
)

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

TREES_UD = "/exp/cxiao/scale26/avid/exp/phase3/trees/trees_ud.jsonl"
VERIFY_VIS = "/exp/cxiao/scale26/avid/exp/phase2/prompt_ablation/r5e/verify_visual.jsonl"
VERIFY_AUD = "/exp/cxiao/scale26/avid/exp/phase2/prompt_ablation/r5e/verify_audio.jsonl"
UNARIES_UD = "/exp/cxiao/scale26/avid/exp/phase3/nodes/unaries_ud.jsonl"
DECOMP_UD = "/exp/cxiao/scale26/avid/exp/phase3/crf/decomp_ud.jsonl"

# Verdict thresholds on root support marginal (1 − P(no)):
#   ≥ THRESH_SUPPORTED → supported
#   ≥ THRESH_PARTIAL   → partially_supported
#   <  THRESH_PARTIAL  → unsupported
THRESH_SUPPORTED = 0.65
THRESH_PARTIAL = 0.35

# State labels per modality
VIS_LABELS = {NO: "no", A: "ocr", B: "other"}
AUD_LABELS = {NO: "no", A: "speech", B: "other"}


# ---------------------------------------------------------------------------
# Load r5e scores → unary lookup
# ---------------------------------------------------------------------------

def load_r5e_unaries(vis_path: str, aud_path: str) -> dict:
    """Load verify_visual.jsonl + verify_audio.jsonl into a nested dict.

    Returns {claim_id: {unit_id: {"vis": phi_array, "aud": phi_array}}}.
    phi_array is a 3-element np.ndarray [φ(no), φ(A), φ(B)].
    """
    def _load_one(path: str, modality: str) -> dict:
        out: dict[str, dict[str, np.ndarray]] = {}
        with open(path, encoding="utf-8") as f:
            for line in f:
                rec = json.loads(line)
                cid = rec["claim_id"]
                uid = rec["unit_id"]
                p1 = rec.get("pass1_dist", {})
                p_yes = float(p1.get("yes", 0.5))
                if modality == "vis":
                    q_A = float(rec.get("visual_ocr_dist", {}).get("yes", 0.5))
                    q_B = float(rec.get("visual_other_dist", {}).get("yes", 0.5))
                else:
                    q_A = float(rec.get("audio_speech_dist", {}).get("yes", 0.5))
                    q_B = float(rec.get("audio_other_dist", {}).get("yes", 0.5))
                phi = unary_from_probe(p_yes, q_A, q_B)
                out.setdefault(cid, {})[uid] = phi
        return out

    vis_map = _load_one(vis_path, "vis")
    aud_map = _load_one(aud_path, "aud")

    combined: dict[str, dict[str, dict]] = {}
    all_cids = set(vis_map) | set(aud_map)
    for cid in all_cids:
        combined[cid] = {}
        all_uids = set(vis_map.get(cid, {})) | set(aud_map.get(cid, {}))
        for uid in all_uids:
            combined[cid][uid] = {
                "vis": vis_map.get(cid, {}).get(uid, None),
                "aud": aud_map.get(cid, {}).get(uid, None),
            }
    return combined


def load_calibrated_unaries(path: str) -> dict:
    """Load calibrated unaries_*.jsonl → {claim_id: {node_id: {"vis":φ,"aud":φ}}}.

    Handles two schemas:
    - Legacy: {claim_id, node_id, visual:{no,ocr,other}, audio:{no,speech,other}}
    - M2/T*:  {claim_id, unit_id, visual:{no,ocr,other}, audio:{no,speech,other}}
              (unit_id is used as the node_id key; visual/audio are already in CRF format)
    """
    out: dict[str, dict[str, dict]] = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            cid = rec["claim_id"]
            nid = rec.get("node_id") or rec.get("unit_id", "")
            if not nid:
                continue
            vis_d = rec.get("visual") or {}
            aud_d = rec.get("audio") or {}
            phi_vis = np.array([
                vis_d.get("no", 1/3), vis_d.get("ocr", 1/3), vis_d.get("other", 1/3)
            ])
            phi_aud = np.array([
                aud_d.get("no", 1/3), aud_d.get("speech", 1/3), aud_d.get("other", 1/3)
            ])
            out.setdefault(cid, {})[nid] = {"vis": phi_vis, "aud": phi_aud}
    return out


# ---------------------------------------------------------------------------
# Map unary to a tree node (r5e POC mode)
# ---------------------------------------------------------------------------

_UNIT_ID_VARIANTS = [
    lambda nid: nid,          # bare node id (e.g. "n2")
    lambda nid: f"pu_{nid}",  # phrase-entity form (e.g. "pu_n0")
]


def get_node_unary(
    claim_id: str,
    node: dict,
    unary_lookup: dict,
    negated: bool,
) -> tuple:
    """Return (phi_vis, phi_aud) for a tree node.

    Tries all unit_id variants; falls back to uniform if no r5e data.
    Applies negation flip if negated=True.
    """
    nid = node["node_id"]
    cid_map = unary_lookup.get(claim_id, {})
    for variant in _UNIT_ID_VARIANTS:
        uid = variant(nid)
        if uid in cid_map:
            entry = cid_map[uid]
            phi_vis = entry.get("vis")
            phi_aud = entry.get("aud")
            if phi_vis is not None and phi_aud is not None:
                if negated:
                    # Flip: rebuild from complement of pass1
                    def _flip(phi):
                        p = 1.0 - phi[NO]          # original p_yes
                        q_A = phi[A] / (phi[A] + phi[B]) if (phi[A] + phi[B]) > 1e-9 else 0.5
                        q_B = 1.0 - q_A
                        return unary_from_probe(p, q_A, q_B, negated=True)
                    phi_vis = _flip(phi_vis)
                    phi_aud = _flip(phi_aud)
                return phi_vis, phi_aud
    return unary_uniform(), unary_uniform()


# ---------------------------------------------------------------------------
# Run CRF for one claim
# ---------------------------------------------------------------------------

VERDICT_LABELS = {
    "vis": {NO: "no", A: "ocr", B: "other"},
    "aud": {NO: "no", A: "speech", B: "other"},
}


def run_claim(tree: dict, unary_lookup: dict, lam: float,
              lam_soft: float = 0.0) -> dict:
    """Run both modality CRFs for one claim; return decomp record."""
    claim_id = tree["claim_id"]
    root_id = tree["root_id"]
    nodes = tree["nodes"]

    if root_id is None or not nodes:
        return {
            "claim_id": claim_id,
            "root_support": None,
            "root_verdict": "unsupported",
            "per_node": [],
            "map_labels": {},
        }

    # Build CRF-variable lists (non-functional nodes only)
    crf_nodes = [n for n in nodes if not n["is_functional"]]
    if not crf_nodes:
        return {
            "claim_id": claim_id,
            "root_support": None,
            "root_verdict": "unsupported",
            "per_node": [],
            "map_labels": {},
        }

    crf_ids = {n["node_id"] for n in crf_nodes}

    # Check root is in CRF
    if root_id not in crf_ids:
        # Root is functional (rare); find its first non-functional descendant
        cand = [n["node_id"] for n in crf_nodes]
        root_id = cand[0] if cand else None
        if root_id is None:
            return {
                "claim_id": claim_id,
                "root_support": None,
                "root_verdict": "unsupported",
                "per_node": [],
                "map_labels": {},
            }

    # Build structure dicts for tree_crf (restricted to CRF variables)
    children: dict[str, list] = {n["node_id"]: [] for n in crf_nodes}
    parent: dict[str, str | None] = {}
    rel_class_of: dict[str, str] = {}

    nmap = {n["node_id"]: n for n in nodes}

    def _resolve_parent(nid: str) -> str | None:
        """Walk up through functional nodes to find CRF-variable parent."""
        n = nmap[nid]
        pid = n.get("parent_id")
        if pid is None:
            return None
        if pid in crf_ids:
            return pid
        # Parent is functional; climb further
        visited = {nid}
        cur = pid
        while cur is not None and cur not in crf_ids:
            if cur in visited:
                break
            visited.add(cur)
            cur = nmap.get(cur, {}).get("parent_id")
        return cur if cur in crf_ids else None

    for n in crf_nodes:
        nid = n["node_id"]
        pid = _resolve_parent(nid)
        parent[nid] = pid
        # Use 'comp' from T* if present (PN-1/PN-2 normalized); else fall back to rel_class.
        # 'comp' values: root/drop/core/coord/verif-mod/inert-mod/neg — all recognized by
        # edge_potential. Keeps the CRF backward-compatible with pre-PN trees.
        rel_class_of[nid] = n.get("comp") or n.get("rel_class", "modifier")
        if pid is not None and pid in crf_ids:
            children[pid].append(nid)

    # Connect any orphaned CRF roots (other than root_id) to root_id with
    # modifier edges so the graph stays connected for BP. Modifier edges are
    # ψ=1 (unconstrained), so they don't affect root_id's belief — they just
    # ensure the whole CRF is a single tree and every node gets a valid belief.
    crf_roots = [nid for nid, p in parent.items() if p is None and nid != root_id]
    for orphan in crf_roots:
        parent[orphan] = root_id
        rel_class_of[orphan] = "modifier"
        children[root_id].append(orphan)

    node_ids = [n["node_id"] for n in crf_nodes]

    # Build unaries for both modalities
    unaries_vis: dict[str, np.ndarray] = {}
    unaries_aud: dict[str, np.ndarray] = {}
    for n in crf_nodes:
        nid = n["node_id"]
        negated = n.get("negated", False)
        if not n["probed"]:
            unaries_vis[nid] = unary_uniform()
            unaries_aud[nid] = unary_uniform()
        else:
            phi_vis, phi_aud = get_node_unary(claim_id, n, unary_lookup, negated)
            unaries_vis[nid] = phi_vis
            unaries_aud[nid] = phi_aud

    # Run sum-product
    beliefs_vis = sum_product(root_id, node_ids, children, parent, rel_class_of,
                              unaries_vis, lam, lam_soft)
    beliefs_aud = sum_product(root_id, node_ids, children, parent, rel_class_of,
                              unaries_aud, lam, lam_soft)

    # Run max-product
    map_vis = max_product(root_id, node_ids, children, parent, rel_class_of,
                          unaries_vis, lam, lam_soft)
    map_aud = max_product(root_id, node_ids, children, parent, rel_class_of,
                          unaries_aud, lam, lam_soft)

    # Root verdict: use max of both modalities' support marginals
    bv = beliefs_vis.get(root_id, np.full(N_STATES, 1/3))
    ba = beliefs_aud.get(root_id, np.full(N_STATES, 1/3))
    root_support_vis = float(bv[A] + bv[B])
    root_support_aud = float(ba[A] + ba[B])
    root_support = max(root_support_vis, root_support_aud)

    if root_support >= THRESH_SUPPORTED:
        root_verdict = "supported"
    elif root_support >= THRESH_PARTIAL:
        root_verdict = "partially_supported"
    else:
        root_verdict = "unsupported"

    # Per-node output
    per_node = []
    for n in crf_nodes:
        nid = n["node_id"]
        bv_n = beliefs_vis.get(nid, np.full(N_STATES, 1/3))
        ba_n = beliefs_aud.get(nid, np.full(N_STATES, 1/3))
        sup_vis = float(bv_n[A] + bv_n[B])
        sup_aud = float(ba_n[A] + ba_n[B])
        sup_both = max(sup_vis, sup_aud)

        if sup_vis >= sup_aud and sup_vis > float(bv_n[NO]):
            argmax_ch = f"v_{VIS_LABELS[int(bv_n.argmax())]}"
        elif sup_aud > sup_vis and sup_aud > float(ba_n[NO]):
            argmax_ch = f"a_{AUD_LABELS[int(ba_n.argmax())]}"
        else:
            argmax_ch = "no"

        phi_vis = unaries_vis[nid]
        gap_vis = evidence_gap(bv_n, phi_vis)

        per_node.append({
            "node_id": nid,
            "visual_marginal": {
                "no": float(bv_n[NO]), "ocr": float(bv_n[A]), "other": float(bv_n[B]),
            },
            "audio_marginal": {
                "no": float(ba_n[NO]), "speech": float(ba_n[A]), "other": float(ba_n[B]),
            },
            "support_marginal": sup_both,
            "argmax_channel": argmax_ch,
            "e_minus_s_gap": gap_vis,
        })

    map_labels_out = {}
    for nid in node_ids:
        map_labels_out[nid] = {
            "visual": VIS_LABELS.get(map_vis.get(nid, NO), "no"),
            "audio": AUD_LABELS.get(map_aud.get(nid, NO), "no"),
        }

    return {
        "claim_id": claim_id,
        "root_support": root_support,
        "root_verdict": root_verdict,
        "per_node": per_node,
        "map_labels": map_labels_out,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--backbone", choices=["ud", "const"], default="ud")
    ap.add_argument("--lambda", dest="lam", type=float, default=3.0,
                    help="Necessity strength λ for core-arg / coord edges.")
    ap.add_argument("--lambda-soft", dest="lam_soft", type=float, default=0.0,
                    help="Soft-gate λ for verif-mod edges (0 → lam/3).")
    ap.add_argument("--unaries-from-r5e", action="store_true",
                    help="POC mode: map cached r5e scores to tree nodes.")
    ap.add_argument("--unaries", default=UNARIES_UD,
                    help="Path to calibrated unaries_*.jsonl (M3+ mode).")
    ap.add_argument("--verify-visual", default=VERIFY_VIS)
    ap.add_argument("--verify-audio", default=VERIFY_AUD)
    ap.add_argument("--trees", default=TREES_UD)
    ap.add_argument("--output", default=DECOMP_UD)
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    # Select output path by backbone
    out_path = args.output
    if out_path == DECOMP_UD and args.backbone == "const":
        out_path = out_path.replace("_ud.jsonl", "_const.jsonl")

    # Load unary potentials
    print("Loading unary potentials...", file=sys.stderr)
    if args.unaries_from_r5e:
        unary_lookup = load_r5e_unaries(args.verify_visual, args.verify_audio)
        print(f"  r5e mode: {sum(len(v) for v in unary_lookup.values())} (claim,unit) pairs",
              file=sys.stderr)
    else:
        unary_lookup = load_calibrated_unaries(args.unaries)
        print(f"  calibrated mode: {sum(len(v) for v in unary_lookup.values())} (claim,node) pairs",
              file=sys.stderr)

    # Load trees
    trees_path = args.trees
    if trees_path == TREES_UD and args.backbone == "const":
        trees_path = trees_path.replace("_ud.jsonl", "_const.jsonl")

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)

    n_claims = 0
    verdicts = {"supported": 0, "partially_supported": 0, "unsupported": 0}

    sys.path.insert(0, str(Path(__file__).parent))  # ensure tree_crf importable

    with open(trees_path, encoding="utf-8") as fin, \
         open(out_path, "w", encoding="utf-8") as fout:

        for line in fin:
            if args.limit and n_claims >= args.limit:
                break
            tree = json.loads(line)
            decomp = run_claim(tree, unary_lookup, args.lam, args.lam_soft)
            fout.write(json.dumps(decomp, ensure_ascii=False) + "\n")
            v = decomp.get("root_verdict", "unsupported")
            verdicts[v] = verdicts.get(v, 0) + 1
            n_claims += 1
            if n_claims % 500 == 0:
                print(f"  {n_claims} claims...", file=sys.stderr)

    total = max(1, n_claims)
    print(f"\nDone: {n_claims} claims → {out_path}", file=sys.stderr)
    print(f"  supported:          {verdicts['supported']} ({100*verdicts['supported']/total:.1f}%)",
          file=sys.stderr)
    print(f"  partially_supported:{verdicts['partially_supported']} ({100*verdicts['partially_supported']/total:.1f}%)",
          file=sys.stderr)
    print(f"  unsupported:        {verdicts['unsupported']} ({100*verdicts['unsupported']/total:.1f}%)",
          file=sys.stderr)


if __name__ == "__main__":
    main()
