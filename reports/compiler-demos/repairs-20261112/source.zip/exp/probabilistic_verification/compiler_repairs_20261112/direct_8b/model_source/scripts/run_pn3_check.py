#!/usr/bin/env python3
"""
AViD Phase 3 — Parse Normalization PN-3: LLM F₃ checkability / na residue.

This is the design's PN_llm stage (parse_normalization_design.md §3, §6; ADR-016):
the residue pass that decides, for a still-pending probeable content node, whether
its unit has an AUDIO-VISUAL TRUTH VALUE (CHECKABLE → keep probeable) or is a
normative / subjective / purely-abstract judgment (NA → role=na, probed=False).
Canonical witness: "correct" in "…to the correct position by hand".

Reads T* v1 (trees_ud_star.jsonl, post PN-2). For each RESOLVE-ONCE target — a
probed content node still at its PN-1 provisional state (pn_stage=="pn1",
role=="probeable") — calls Qwen3-30B with the frozen CHECKABLE prompt
(prompts_phase2.py). Never overrides a confident PN-1/PN-2 decision (na / verif-mod
/ core stay); refining a *provisional* probeable → na is the intended residue
resolution, not an override.

Apply rule:
  NA        → role=na, comp=inert-mod, probed=False, pn_stage=pn3
  CHECKABLE → no change (stays probeable); logged for the audit trail
  (malformed/invalid reply → fall back to CHECKABLE, the safe default)

Emits:
  trees_ud_star.jsonl  (T* v2, overwrites in-place by default)
  pn3_checks.jsonl     — per-node label + reason + metadata (audit log)
  tree_units_ud.tsv    — regenerated probe TSV (na nodes now dropped)

Cache key: claim_id|node_id|CHECKABLE_PROMPT_VERSION  (resumable)

Usage (vllm-omni env, A100-80gb GPU node — Qwen3-30B-A3B OOMs on 40gb):
    python scripts/run_pn3_check.py \\
        --input-trees  exp/phase3/trees/trees_ud_star.jsonl \\
        --output-trees exp/phase3/trees/trees_ud_star.jsonl \\
        --output-checks exp/phase3/trees/pn3_checks.jsonl \\
        --output-tsv   exp/phase3/nodes/tree_units_ud.tsv \\
        --cache        exp/phase3/trees/pn3_cache.jsonl \\
        --batch-size 64
"""

import argparse
import copy
import csv
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("VLLM_USE_V1", "0")

_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_IN_TREES = str(_AVID / "exp/phase3/trees/trees_ud_star.jsonl")
DEFAULT_OUT_TREES = str(_AVID / "exp/phase3/trees/trees_ud_star.jsonl")
DEFAULT_CHECKS = str(_AVID / "exp/phase3/trees/pn3_checks.jsonl")
DEFAULT_TSV = str(_AVID / "exp/phase3/nodes/tree_units_ud.tsv")
DEFAULT_CACHE = str(_AVID / "exp/phase3/trees/pn3_cache.jsonl")
MODEL_PATH = "/home/hltcoe/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507"

TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted", "gold_channels", "notes",
]

sys.path.insert(0, str(Path(__file__).parent))
from prompts_phase2 import (
    CHECKABLE_SYSTEM,
    CHECKABLE_PROMPT_VERSION,
    CHECKABLE_LABELS,
    checkable_user,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FALLBACK_LABEL = "CHECKABLE"   # safe default: keep the node probeable


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def cache_key(claim_id: str, node_id: str) -> str:
    return f"{claim_id}|{node_id}|{CHECKABLE_PROMPT_VERSION}"


def load_cache(path: str) -> dict[str, dict]:
    cache: dict[str, dict] = {}
    p = Path(path)
    if not p.exists():
        return cache
    for line in open(p, encoding="utf-8"):
        try:
            rec = json.loads(line)
            k = rec.get("_cache_key", "")
            if k:
                cache[k] = rec
        except json.JSONDecodeError:
            pass
    return cache


def parse_label(text: str) -> tuple[str, str]:
    """Parse JSON {"label": "NA", "reason": "..."} → (label, reason).

    Falls back to (FALLBACK_LABEL, "") on any parse/validation failure.
    """
    text = (text or "").strip()
    try:
        obj = json.loads(text)
        label = (obj.get("label") or "").strip().upper()
        reason = (obj.get("reason") or "").strip()
        if label in CHECKABLE_LABELS:
            return label, reason
    except (json.JSONDecodeError, AttributeError):
        pass
    # Loose fallback: look for a bare label token in the raw text
    up = text.upper()
    if '"NA"' in up or "'NA'" in up or up == "NA":
        return "NA", ""
    if "CHECKABLE" in up:
        return "CHECKABLE", ""
    return FALLBACK_LABEL, ""


def highlight_span(claim_text: str, s: int, e: int) -> str:
    if s < 0 or e <= s:
        return claim_text
    s = max(0, s)
    e = min(len(claim_text), e)
    return claim_text[:s] + "**" + claim_text[s:e] + "**" + claim_text[e:]


def unit_text_of(node: dict) -> str:
    return (node.get("pn_unit_text")
            or node.get("content_subtree_text")
            or node.get("node_text", ""))


# ---------------------------------------------------------------------------
# PN-3 target extraction (RESOLVE-ONCE: only PN-1 provisional probeable content)
# ---------------------------------------------------------------------------

# Ablation (2026-07-23): optionally also vet verif-mod (pn2) nodes for checkability,
# to measure the effect of closing the PN-3 precedence gap. Default False = FINAL behavior.
ALSO_VERIF_MOD = False

def is_pn3_target(node: dict) -> bool:
    if not (node.get("probed")
            and not node.get("is_functional")
            and node.get("role") == "probeable"):
        return False
    if node.get("pn_stage") == "pn1":          # PN-1 provisional (FINAL behavior)
        return True
    if ALSO_VERIF_MOD and node.get("pn_stage") == "pn2" and node.get("comp") == "verif-mod":
        return True                            # ablation: also vet manner/instrument units
    return False


def collect_pn3_targets(trees: list[dict]) -> list[dict]:
    jobs = []
    for tree in trees:
        cid = tree["claim_id"]
        claim_text = tree["claim_text"]
        for node in tree["nodes"]:
            if not is_pn3_target(node):
                continue
            unit_span = (node.get("pn_unit_span")
                         or node.get("content_subtree_span")
                         or node.get("span", [-1, -1]))
            jobs.append({
                "claim_id": cid,
                "node_id": node["node_id"],
                "claim_text": claim_text,
                "unit_text": unit_text_of(node),
                "node_type": node.get("node_type", ""),
                "unit_span": unit_span,
            })
    return jobs


# ---------------------------------------------------------------------------
# Apply label → edit
# ---------------------------------------------------------------------------

def apply_check_edits(trees: list[dict],
                      label_map: dict[str, str]) -> tuple[list[dict], list[dict]]:
    """Apply CHECKABLE/NA labels to trees; return (updated_trees, check_records)."""
    updated_trees = []
    check_records = []
    stats = {"CHECKABLE": 0, "NA": 0, "MISS": 0}
    na_by_type: dict[str, int] = {}

    for tree in trees:
        t = copy.deepcopy(tree)
        cid = t["claim_id"]
        for node in t["nodes"]:
            if not is_pn3_target(node):
                continue
            ck = cache_key(cid, node["node_id"])
            if ck not in label_map:
                stats["MISS"] += 1
                continue

            label = label_map[ck]
            stats[label] = stats.get(label, 0) + 1

            role_before = node["role"]
            comp_before = node.get("comp")
            probed_before = node.get("probed", True)

            if label == "NA":
                node["role"] = "na"
                node["comp"] = "inert-mod"
                node["probed"] = False
                node["pn_stage"] = "pn3"
                nt = node.get("node_type", "")
                na_by_type[nt] = na_by_type.get(nt, 0) + 1

            check_records.append({
                "claim_id": cid,
                "node_id": node["node_id"],
                "node_type": node.get("node_type", ""),
                "deprel": node.get("deprel", ""),
                "unit_text": unit_text_of(node),
                "label": label,
                "role_before": role_before,
                "role_after": node["role"],
                "comp_before": comp_before,
                "comp_after": node.get("comp"),
                "probed_before": probed_before,
                "probed_after": node.get("probed"),
            })

        updated_trees.append(t)

    print(f"  Check edits: {stats}", file=sys.stderr)
    print(f"  NA by node_type: {na_by_type}", file=sys.stderr)
    return updated_trees, check_records


# ---------------------------------------------------------------------------
# TSV emission
# ---------------------------------------------------------------------------

def write_tsv(trees: list[dict], tsv_path: str) -> int:
    probed_total = 0
    with open(tsv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=TSV_COLS, delimiter="\t")
        writer.writeheader()
        for tree in trees:
            cid = tree["claim_id"]
            claim_text = tree["claim_text"]
            for node in tree["nodes"]:
                if not node.get("probed"):
                    continue
                unit_text = unit_text_of(node)
                unit_span = (node.get("pn_unit_span")
                             or node.get("content_subtree_span")
                             or node.get("span", [-1, -1]))
                s, e = unit_span[0], unit_span[1]
                claim_hl = highlight_span(claim_text, s, e)
                writer.writerow({
                    "claim_id": cid,
                    "unit_id": node["node_id"],
                    "unit_type": "tree_node",
                    "node_type": node.get("node_type", ""),
                    "claim_text": claim_text,
                    "unit_text": unit_text,
                    "claim_highlighted": claim_hl,
                    "gold_channels": "",
                    "notes": "",
                })
                probed_total += 1
    return probed_total


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input-trees", default=DEFAULT_IN_TREES)
    ap.add_argument("--output-trees", default=DEFAULT_OUT_TREES,
                    help="T* v2 output (overwrites input by default).")
    ap.add_argument("--output-checks", default=DEFAULT_CHECKS)
    ap.add_argument("--output-tsv", default=DEFAULT_TSV)
    ap.add_argument("--cache", default=DEFAULT_CACHE,
                    help="Resumable LLM check cache (JSONL, append mode).")
    ap.add_argument("--model", default=MODEL_PATH)
    ap.add_argument("--tp", type=int, default=0,
                    help="Tensor-parallel size (0 = auto-detect from CUDA device count).")
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--max-tokens", type=int, default=48,
                    help="Max tokens per check call (short JSON + reason).")
    ap.add_argument("--limit", type=int, default=None,
                    help="Process only the first N claims (smoke test).")
    ap.add_argument("--dry-run", action="store_true",
                    help="Only report the target count; do not load the model.")
    ap.add_argument("--also-verif-mod", action="store_true",
                    help="ABLATION: also vet verif-mod (pn2 manner/instrument) nodes "
                         "for checkability (closes the PN-3 precedence gap).")
    args = ap.parse_args()

    global ALSO_VERIF_MOD
    ALSO_VERIF_MOD = args.also_verif_mod
    if ALSO_VERIF_MOD:
        print("  [ablation] also vetting verif-mod nodes for checkability", file=sys.stderr)

    # ---- Load trees ----
    print("Loading T* v1 trees …", file=sys.stderr)
    trees: list[dict] = []
    with open(args.input_trees, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if args.limit is not None and i >= args.limit:
                break
            trees.append(json.loads(line))
    print(f"  {len(trees)} claims loaded.", file=sys.stderr)

    # ---- Collect PN-3 targets ----
    jobs = collect_pn3_targets(trees)
    print(f"  PN-3 targets: {len(jobs)} PN-1-provisional probeable content nodes.",
          file=sys.stderr)
    # Target breakdown by node_type
    by_type: dict[str, int] = {}
    for j in jobs:
        by_type[j["node_type"]] = by_type.get(j["node_type"], 0) + 1
    print(f"  Targets by node_type: {by_type}", file=sys.stderr)

    if args.dry_run:
        print("  --dry-run: not loading the model.", file=sys.stderr)
        return

    # ---- Load cache ----
    cache = load_cache(args.cache)
    print(f"  Cache entries: {len(cache)}", file=sys.stderr)

    pending = [j for j in jobs if cache_key(j["claim_id"], j["node_id"]) not in cache]
    print(f"  To run: {len(pending)} (cached: {len(jobs) - len(pending)})", file=sys.stderr)

    # ---- vLLM inference ----
    if pending:
        import torch
        from vllm import LLM, SamplingParams
        from transformers import AutoTokenizer

        tp = args.tp if args.tp > 0 else torch.cuda.device_count()
        print(f"  Loading {args.model} (tp={tp}) …", file=sys.stderr)
        tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
        llm = LLM(
            model=args.model,
            trust_remote_code=True,
            gpu_memory_utilization=0.90,
            tensor_parallel_size=tp,
            dtype="bfloat16",
            seed=42,
            max_model_len=2048,
            disable_log_stats=True,
        )
        sp = SamplingParams(temperature=0.0, max_tokens=args.max_tokens)

        def make_prompt(j: dict) -> str:
            user = checkable_user(
                claim_text=j["claim_text"],
                unit_text=j["unit_text"],
                node_type=j["node_type"],
                unit_span=j.get("unit_span"),
            )
            msgs = [
                {"role": "system", "content": CHECKABLE_SYSTEM},
                {"role": "user",   "content": user},
            ]
            return tok.apply_chat_template(
                msgs, tokenize=False, add_generation_prompt=True,
                enable_thinking=False,
            )

        bs = args.batch_size
        n_batches = (len(pending) + bs - 1) // bs
        cache_path = Path(args.cache)
        cache_path.parent.mkdir(parents=True, exist_ok=True)

        with open(cache_path, "a", encoding="utf-8") as cf:
            for b_idx in range(n_batches):
                batch = pending[b_idx * bs: (b_idx + 1) * bs]
                prompts = [make_prompt(j) for j in batch]
                print(f"  [CHECK] batch {b_idx + 1}/{n_batches}: {len(batch)} …",
                      file=sys.stderr, flush=True)
                outputs = llm.generate(prompts, sampling_params=sp)
                for j, out in zip(batch, outputs):
                    raw = out.outputs[0].text.strip() if out.outputs else ""
                    label, reason = parse_label(raw)
                    ck = cache_key(j["claim_id"], j["node_id"])
                    entry = {
                        "_cache_key": ck,
                        "claim_id": j["claim_id"],
                        "node_id": j["node_id"],
                        "node_type": j["node_type"],
                        "unit_text": j["unit_text"],
                        "label": label,
                        "reason": reason,
                        "raw": raw,
                    }
                    cf.write(json.dumps(entry, ensure_ascii=False) + "\n")
                    cache[ck] = entry

        print(f"  LLM inference done. {len(pending)} checks generated.", file=sys.stderr)
    else:
        print("  All checks already cached; skipping LLM.", file=sys.stderr)

    # ---- Build label_map {cache_key: label} ----
    label_map: dict[str, str] = {
        k: v["label"] for k, v in cache.items() if "label" in v
    }

    # ---- Apply check edits to T* v1 → T* v2 ----
    print("Applying PN-3 check edits …", file=sys.stderr)
    probed_before = sum(1 for t in trees for n in t["nodes"] if n.get("probed"))
    updated_trees, check_records = apply_check_edits(trees, label_map)
    probed_after = sum(1 for t in updated_trees for n in t["nodes"] if n.get("probed"))

    # ---- Write outputs ----
    for path in [args.output_trees, args.output_checks, args.output_tsv]:
        Path(path).parent.mkdir(parents=True, exist_ok=True)

    with open(args.output_trees, "w", encoding="utf-8") as f:
        for t in updated_trees:
            f.write(json.dumps(t, ensure_ascii=False) + "\n")
    print(f"  T* v2 → {args.output_trees}", file=sys.stderr)

    with open(args.output_checks, "w", encoding="utf-8") as f:
        for rec in check_records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    n_na = sum(1 for r in check_records if r["label"] == "NA")
    print(f"  Checks log → {args.output_checks} "
          f"({len(check_records)} nodes, {n_na} → na)", file=sys.stderr)

    probed_count = write_tsv(updated_trees, args.output_tsv)
    print(f"  TSV → {args.output_tsv} ({probed_count} probed rows)", file=sys.stderr)

    # ---- Summary ----
    print(f"\nPN-3 complete: {len(updated_trees)} claims, {len(jobs)} targets",
          file=sys.stderr)
    print(f"  Probed nodes: {probed_before} → {probed_after} "
          f"(Δ {probed_after - probed_before:+d} → na)", file=sys.stderr)
    na_frac = 100.0 * n_na / max(len(jobs), 1)
    print(f"  na flip rate: {n_na}/{len(jobs)} targets ({na_frac:.1f}%)", file=sys.stderr)


if __name__ == "__main__":
    main()
