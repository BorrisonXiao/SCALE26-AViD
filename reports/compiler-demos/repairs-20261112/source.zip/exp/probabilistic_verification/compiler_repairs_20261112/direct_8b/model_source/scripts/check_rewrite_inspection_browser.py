"""Inspect all 80 exact requests, failure filters, skipped probes and deep links."""
import functools,http.server,json,threading
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/rewrite_inspection_20261112'
def main():
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'site')));threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
    data=json.loads((RUN/'inspection.json').read_text())
    with sync_playwright()as p:
        browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(base+'/reports/compiler-demos.html#rewrite-pilot',wait_until='networkidle');page.wait_for_selector('#rewrite-case option',state='attached')
        assert page.locator('#rewrite-group').input_value()=='eligible' and page.locator('#rewrite-case option').count()==31
        for group,count in [('rejected',28),('diagnostic',9),('accepted',3),('target',24),('control',8),('guard',8),('all',40)]:
            page.select_option('#rewrite-group',group);assert page.locator('#rewrite-case option').count()==count,(group,count)
        checked=0
        for cid,row in data['cases'].items():
            page.select_option('#rewrite-case',cid)
            route=page.locator('#rewrite-route').inner_text()
            assert ('Direct compilation failed'in route)==row['route']['rewrite_eligible']
            for condition,request in row['conditions'].items():
                page.select_option('#rewrite-prompt-condition',condition)
                assert page.locator('#rewrite-system-prompt').text_content()==request['messages'][0]['content']
                assert page.locator('#rewrite-user-prompt').text_content()==request['messages'][1]['content']
                assert page.locator('#rewrite-raw-response').text_content()==request['raw_response']
                assert page.locator('#rewrite-prompt-stage').text_content()==request['failure_stage']
                assert page.locator('#rewrite-prompt-review').text_content()==request['review_reason']
                config=page.locator('#rewrite-model-config').inner_text();assert 'Qwen3-30B-A3B-Instruct-2507'in config and '768'in config
                for selector in ['#rewrite-system-prompt','#rewrite-user-prompt','#rewrite-raw-response']:
                    assert page.locator(selector).evaluate('(e)=>e.closest("details")===null')
                checked+=1
        example_links=page.locator('#rewrite-failed-examples a').evaluate_all('(links)=>links.map(a=>a.getAttribute("href"))')
        for href in example_links:
            cid=href.split('rewrite=')[1].split('#')[0]
            page.goto(base+'/reports/'+href,wait_until='networkidle');page.wait_for_function('(cid)=>document.querySelector("#rewrite-case").value===cid',arg=cid)
            assert 'Direct compilation failed'in page.locator('#rewrite-route').inner_text()
            assert page.locator('#rewrite-system-prompt').text_content()
        page.goto(base+'/reports/compiler-demos.html?rewrite=TFgw4IaR9R8s_1587&rewrite_prompt=revised#rewrite-case-inspector',wait_until='networkidle');page.wait_for_function('document.querySelector("#rewrite-case").value==="TFgw4IaR9R8s_1587"')
        assert 'which he signed'in page.locator('#rewrite-raw-response').inner_text()
        page.evaluate('document.documentElement.style.scrollBehavior="auto";document.querySelector("#rewrite-case-inspector").scrollIntoView({behavior:"instant",block:"start"})');page.screenshot(path=str(RUN/'failure_desktop.png'))
        page.evaluate('document.querySelector("#rewrite-exact-request").scrollIntoView({behavior:"instant",block:"start"})');page.screenshot(path=str(RUN/'prompt_desktop.png'))
        page.set_viewport_size({'width':390,'height':844});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.emulate_media(color_scheme='dark');page.screenshot(path=str(RUN/'prompt_mobile_dark.png'))
        page.goto(base+'/reports/compiler-demos.html?rewrite=TInVWzp25aIM_18&rewrite_prompt=initial#rewrite-case-inspector',wait_until='networkidle');page.wait_for_function('document.querySelector("#rewrite-group").value==="diagnostic"');assert 'do not call the rewriter'in page.locator('#rewrite-route').inner_text()
        page.click('[data-tab="daily-progress"]');assert page.locator('.progress-day time').first.inner_text()=='2026-11-12';page.locator('#day-2026-11-12 a[href="#rewrite-routing"]').click();page.wait_for_selector('#rewrite-pilot',state='visible')
        assert page.locator('#rewrite-failed-examples article').count()==5
        page.click('[data-tab="walkthroughs"]');assert page.locator('#demo-select option').count()==41
        page.click('[data-tab="results"]');assert page.locator('#results table').first.locator('tbody tr').count()==4
        assert not errors,errors
        proof=dict(exact_requests_checked=checked,default_failures=31,rejected_filter=28,skipped_passes=9,example_links_checked=len(example_links),unfolded_prompts=True,deep_links=True,old_demos_preserved=True,mobile_overflow=False,page_errors=errors)
        (RUN/'browser_checks.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof);browser.close()
    server.shutdown()
if __name__=='__main__':main()
