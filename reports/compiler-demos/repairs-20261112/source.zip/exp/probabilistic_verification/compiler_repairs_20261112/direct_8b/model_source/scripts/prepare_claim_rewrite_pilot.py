"""Freeze development membership and original-claim readings before generation."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'exp/probabilistic_verification/content_relations_20261105'
RUN=ROOT/'exp/probabilistic_verification/claim_rewrite_20261111'

TARGETS={
'Txf2EdqOg1SQ_2185':'Highest rainfall of the day is in Meishan Township, Chiayi; that township received149.0mm. Preserve the superlative, location and amount.',
'Txf2EdqOg1SQ_2257':'Shown content: severe indoor flooding in Zhongshan, with tools submerged in a blue basket. Do not assert an independent unseen event.',
'TgR_u37mCoQ4_1860':'In the second shot an emergency vehicle is visible at the road side and its emergency lights are flashing.',
'TgR_u37mCoQ4_1877':"Video stills depict Pete's Seafood, a restaurant at Topanga Beach; the restaurant has survived many fires. Preserve scope/antecedent.",
'TFgw4IaR9R8s_1586':'An image depicts Trump signing something; executive orders are only a likely identification.',
'TFgw4IaR9R8s_1587':'An image depicts Trump holding up a document that is signed. Preserve the particle up and the signed modifier.',
'TMrQshDs8aH0_750':'Multiple additional police officers near the police van help and clear space. Preserve immediate vicinity and both activities.',
'TFgw4IaR9R8s_1636':'A court ruling places with Congress authority to set tariffs or delegate tariff control to the President in specific situations. Preserve alternative scope.',
'TgR_u37mCoQ4_1927':'A logo for the County of Los Angeles is on screen at the beginning of the video.',
'T2G_ACMxR_I4_1354':'Extracting information from samples is a goal of the lunar planet vac, not an accomplished extraction.',
'T2G_ACMxR_I4_1263':"Elytra will remain in lunar orbit for long-haul communications relay and RF calibration support for NASA telescope systems. Preserve future and purpose.",
'TW4OYA3RN-Hw_1826':'Two boys arrange for someone to photograph the boys on a bridge; fire and smoke are visible in the background. Do not resolve any further reference.',
'T2EE72iNELEs_192':'The video beginning has velocity17828mph. Preserve beginning and quantity; no named vehicle is supplied.',
'TzF9M4kZ3Pys_223':'The physical integrity of the power lines seems intact; preserve apparent rather than certain condition.',
'Tg0UxWYuPeJ0_379':'A robot race is inside a running track. Keep both race and location.',
'Tg0UxWYuPeJ0_378':'The robot on lane three comes second. Bind lane and rank to that robot, not another participant.',
'Tg0UxWYuPeJ0_433':'Robot1 performs a sweep kick on Robot2; identifiers and direction must survive.',
'TjHepwuhkYFA_1035':'Earthquake magnitude is7.7; preserve value and quantity owner.',
'T2G_ACMxR_I4_1148':'Blue Ghost had three and a half elliptical orbits around Earth. Preserve3.5 concept and past tense.',
'T2G_ACMxR_I4_1441':"The braking burn reduced Blue Ghost's orbital velocity to40meters/second. Preserve resulting velocity and rate unit.",
'TFgw4IaR9R8s_1612':'The court consists of a panel of three judges. Preserve cardinality and panel relation.',
'TW4OYA3RN-Hw_1766':'The building housing Kantipur Publications in Kathmandu is on fire. Keep occupants, location and fire state.',
'Txf2EdqOg1SQ_2350':'Wipha is moving northwest at20–25km/h; preserve range, rate, direction and progressive.',
'Txf2EdqOg1SQ_2343':'Depiction of a reporter in Zhuhai, Guangdong wearing a white raincoat. Preserve place apposition and depicted content.'}
CONTROLS=['T1JQ-aG78Zuc_789','T2G_ACMxR_I4_1366','T3HTSBW42QaY_782','TFgw4IaR9R8s_1690','TInVWzp25aIM_18','TW4OYA3RN-Hw_1805','TjHepwuhkYFA_1079','TgR_u37mCoQ4_1955']
GUARDS={
'TgR_u37mCoQ4_1916':'No narration is quantified absence; do not turn it into a positive entity with a negated property.',
'TgR_u37mCoQ4_1901':'No audio is quantified absence; do not turn it into a positive audio entity.',
'TQEmEycTI0RQ_921':'Preserve looked certain and would; do not assert a replacement or remove uncertainty.',
'TQEmEycTI0RQ_820':'Preserve insufficient gains and failure to sufficiently weaken, and their prevention relation.',
'TgPh_fzHTCm4_1498':'Preserve not much, spin and until the third; do not supply an unspecified event or date.',
'TQEmEycTI0RQ_823':'Preserve comparison and not-as-much-red scope in the map description.',
'TQEmEycTI0RQ_803':'Do not choose whether host or David Aiken explains. Both possible controllers must remain unresolved.',
'TFOEIehBwT8Q_504':'The full sign quotation is exact text, including would and without; do not interpret it as world assertions.'}

def main():
 RUN.mkdir(exist_ok=True);assert not (RUN/'pilot_manifest.json').exists(),'Do not overwrite frozen selection.'
 inputs={r['claim_id']:r for r in map(json.loads,(BASE/'inputs.jsonl').read_text().splitlines())}
 baseline={r['claim_id']:r for r in map(json.loads,(BASE/'results.jsonl').read_text().splitlines())}
 prior=json.loads((ROOT/'exp/probabilistic_verification/compiler_alert_review_20261111/review_annotations.json').read_text())
 readings={r['claim_id']:r['reason'] for r in prior['passing_controls']}
 cases=[]
 for group,mapping in [('target',TARGETS),('control',{c:readings[c] for c in CONTROLS}),('guard',GUARDS)]:
  for cid,reading in mapping.items():
   assert (baseline[cid]['status']=='compiled')==(group=='control' or cid.endswith('_803')),(cid,group)
   cases.append(dict(claim_id=cid,group=group,text=inputs[cid]['text'],reading=reading,
       original_status=baseline[cid]['status'],original_code=baseline[cid].get('code')))
 assert len(cases)==40 and len({r['claim_id'] for r in cases})==40
 source_groups=sorted({r['claim_id'].rsplit('_',1)[0] for r in cases})
 untouched=sorted({cid.rsplit('_',1)[0] for cid in inputs}-set(source_groups))
 manifest=dict(cases=cases,source_groups=source_groups,reserved_original_video_groups=untouched,
   protocol='Purposively selected development set from earlier inspected claims; not independent gold or an unseen test. Readings frozen before model generation. Reserved groups get no prompt tuning.',
   gates=dict(minimum_faithful_recoveries=12,targets=24,control_regressions=0,accepted_critical_changes=0),
   baseline_sha256={n:hashlib.sha256((BASE/n).read_bytes()).hexdigest() for n in ['inputs.jsonl','results.jsonl','frozen_manifest.json']})
 (RUN/'pilot_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 (RUN/'pilot_inputs.jsonl').write_text(''.join(json.dumps(inputs[r['claim_id']],ensure_ascii=False)+'\n' for r in cases))
 shutil.copy2(BASE/'frozen_manifest.json',RUN/'compiler_freeze.json')
 print('Frozen40 cases; reserved groups:',untouched)
if __name__=='__main__':main()
