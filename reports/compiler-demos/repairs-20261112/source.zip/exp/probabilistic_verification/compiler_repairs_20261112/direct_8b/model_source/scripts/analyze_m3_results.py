#!/usr/bin/env python3
"""AViD Phase-3 M2/M3 analysis report (natural set, final T*).

Reads the valid post-ADR-019 outputs and emits charts + tables + examples into
exp/phase3/reports/m3_analysis/ for human analysis.

Inputs:
  exp/phase3/crf/decomp_m3.jsonl              (claim verdicts + per_node marginals)
  exp/phase3/nodes/verify_visual_star.jsonl   (per-unit 3-way visual verdict)
  exp/phase3/nodes/verify_audio_star.jsonl    (per-unit 3-way audio verdict)
  exp/phase3/nodes/tree_units_ud.tsv          (node_type / unit_text / claim_text)
"""
import json, csv, collections, html
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

AVID = Path("/exp/cxiao/scale26/avid")
OUT  = AVID / "exp/phase3/reports/m3_analysis"
OUT.mkdir(parents=True, exist_ok=True)

# palette (colorblind-safe blue/orange pair)
C = {"visual": "#4C78A8", "audio": "#F58518", "both": "#54A24B", "neither": "#BAB0AC",
     "supported": "#54A24B", "partially_supported": "#EECA3B", "unsupported": "#E45756",
     "yes": "#54A24B", "no": "#E45756", "cant_tell": "#BAB0AC"}
plt.rcParams.update({"font.size": 11, "axes.grid": True,
                     "axes.axisbelow": True, "grid.alpha": 0.25, "figure.dpi": 130})

def load_jsonl(p): return [json.loads(l) for l in open(p)]

# ---------- load ----------
decomp = load_jsonl(AVID / "exp/phase3/crf/decomp_m3.jsonl")
vis = {(r["claim_id"], r["unit_id"]): r["pass1_verdict"]
       for r in load_jsonl(AVID / "exp/phase3/nodes/verify_visual_star.jsonl")}
aud = {(r["claim_id"], r["unit_id"]): r["pass1_verdict"]
       for r in load_jsonl(AVID / "exp/phase3/nodes/verify_audio_star.jsonl")}
meta = {}
with open(AVID / "exp/phase3/nodes/tree_units_ud.tsv") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        meta[(r["claim_id"], r["unit_id"])] = r

keys = set(vis) & set(aud)
N = len(keys)

# ---------- compute ----------
verdict_ct = collections.Counter(r["root_verdict"] for r in decomp)
vis_ct = collections.Counter(vis[k] for k in keys)
aud_ct = collections.Counter(aud[k] for k in keys)

grounding = collections.Counter()
by_type = collections.defaultdict(lambda: collections.Counter())
for k in keys:
    v, a = vis[k] == "yes", aud[k] == "yes"
    g = "both" if (v and a) else "visual" if v else "audio" if a else "neither"
    grounding[g] += 1
    nt = meta.get(k, {}).get("node_type", "?")
    by_type[nt][g] += 1

audio_unique_unit = grounding["audio"] / N            # audio-only at UNIT level
PILOT_AUDIO_CLAIM = 0.009                              # <1% at whole-CLAIM level (proposal pilot)

def pct(x, t): return f"{x} ({x/t:.1%})" if t else "0"

# ---------- charts ----------
def bar(fname, cats, vals, colors, title, ylabel="units", pcttot=None, rot=0):
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    b = ax.bar(cats, vals, color=colors, edgecolor="white", linewidth=0.6)
    for r, v in zip(b, vals):
        lab = f"{v}\n{v/pcttot:.1%}" if pcttot else str(v)
        ax.text(r.get_x()+r.get_width()/2, v, lab, ha="center", va="bottom", fontsize=9)
    ax.set_title(title, fontweight="bold"); ax.set_ylabel(ylabel)
    ax.set_ylim(0, max(vals)*1.18); plt.xticks(rotation=rot)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout(); fig.savefig(OUT / fname); plt.close(fig)

# 1. claim verdict
vk = ["supported", "partially_supported", "unsupported"]
bar("fig_verdict_dist.png", ["supported", "partial", "unsupported"],
    [verdict_ct[x] for x in vk], [C[x] for x in vk],
    f"Claim verdict (M3 CRF, n={len(decomp)})", "claims", pcttot=len(decomp))

# 2. per-unit grounding
gk = ["visual", "audio", "both", "neither"]
bar("fig_grounding.png", ["visual\nonly", "audio\nonly", "both", "neither"],
    [grounding[x] for x in gk], [C[x] for x in gk],
    f"Per-unit grounding (n={N})", "units", pcttot=N)

# 3. per-modality verdicts (grouped)
fig, ax = plt.subplots(figsize=(5.4, 3.6))
labels = ["yes", "no", "cant_tell"]; import numpy as np
x = np.arange(len(labels)); w = 0.38
ax.bar(x-w/2, [vis_ct[l] for l in labels], w, label="visual", color=C["visual"], edgecolor="white")
ax.bar(x+w/2, [aud_ct[l] for l in labels], w, label="audio", color=C["audio"], edgecolor="white")
ax.set_xticks(x); ax.set_xticklabels(["yes", "no", "can't-tell"]); ax.set_ylabel("units")
ax.set_title(f"Per-unit verdict by modality (n={N})", fontweight="bold")
ax.legend(frameon=False); ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout(); fig.savefig(OUT / "fig_modality_verdicts.png"); plt.close(fig)

# 4. grounding by node_type (stacked, normalized)
types = ["entity", "event", "attribute", "cardinality"]
fig, ax = plt.subplots(figsize=(5.6, 3.6))
bottom = np.zeros(len(types))
for g in gk:
    vals = [by_type[t][g]/max(1, sum(by_type[t].values())) for t in types]
    ax.bar(types, vals, bottom=bottom, label=g if g != "visual" else "visual only",
           color=C[g], edgecolor="white", linewidth=0.5)
    bottom += vals
ax.set_ylabel("share of units"); ax.set_ylim(0, 1)
ax.set_title("Grounding channel by unit type", fontweight="bold")
ax.legend(frameon=False, fontsize=8, ncol=2); ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout(); fig.savefig(OUT / "fig_grounding_by_nodetype.png"); plt.close(fig)

# 5. headline contrast: audio unique @ claim vs unit level
fig, ax = plt.subplots(figsize=(4.6, 3.6))
b = ax.bar(["whole-claim\n(pilot)", "sub-claim unit\n(AViD)"],
           [PILOT_AUDIO_CLAIM, audio_unique_unit], color=[C["neither"], C["audio"]],
           edgecolor="white")
for r, v in zip(b, [PILOT_AUDIO_CLAIM, audio_unique_unit]):
    ax.text(r.get_x()+r.get_width()/2, v, f"{v:.1%}", ha="center", va="bottom", fontweight="bold")
ax.set_ylabel("fraction where audio is uniquely needed")
ax.set_title("Audio's unique contribution\nemerges below the claim", fontweight="bold")
ax.set_ylim(0, audio_unique_unit*1.25); ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout(); fig.savefig(OUT / "fig_audio_contrast.png"); plt.close(fig)

# ---------- examples (per-node modality attribution) ----------
# group units by claim
byclaim = collections.defaultdict(list)
for k in keys:
    byclaim[k[0]].append(k)
verdict_of = {r["claim_id"]: r["root_verdict"] for r in decomp}

def claim_units(cid):
    out = []
    for k in sorted(byclaim[cid], key=lambda x: x[1]):
        m = meta.get(k, {})
        out.append((m.get("unit_text", k[1]), vis[k], aud[k], m.get("node_type", "")))
    return out

# pick showcase claims: ones with an audio-only unit (cross-modal interest)
audio_only_claims = [cid for cid in byclaim
                     if any((vis[k] != "yes" and aud[k] == "yes") for k in byclaim[cid])]
examples = []
seen_txt = set()
for cid in audio_only_claims:
    ct = meta.get((cid, byclaim[cid][0][1]), {}).get("claim_text", "")
    if ct and ct not in seen_txt and len(claim_units(cid)) <= 8:
        seen_txt.add(ct); examples.append(cid)
    if len(examples) >= 8:
        break

# ---------- write summary.md ----------
with open(OUT / "summary.md", "w") as f:
    f.write("# AViD M2/M3 analysis — natural set (final T*)\n\n")
    f.write(f"- Claims: **{len(decomp)}**  ·  probed units: **{N}**\n\n")
    f.write("## Claim verdict (M3 CRF)\n\n| verdict | count | share |\n|---|--:|--:|\n")
    for x in vk:
        f.write(f"| {x} | {verdict_ct[x]} | {verdict_ct[x]/len(decomp):.1%} |\n")
    f.write("\n## Per-unit grounding\n\n| channel | count | share |\n|---|--:|--:|\n")
    for x in gk:
        lab = {"visual": "visual only", "audio": "audio only"}.get(x, x)
        f.write(f"| {lab} | {grounding[x]} | {grounding[x]/N:.1%} |\n")
    f.write(f"\n**Audio uniquely grounds {audio_unique_unit:.1%} of units** "
            f"vs <1% of whole claims in the pilot.\n")
    f.write("\n## Per-unit verdict by modality\n\n| | yes | no | can't-tell |\n|---|--:|--:|--:|\n")
    f.write(f"| visual | {vis_ct['yes']/N:.1%} | {vis_ct['no']/N:.1%} | {vis_ct['cant_tell']/N:.1%} |\n")
    f.write(f"| audio | {aud_ct['yes']/N:.1%} | {aud_ct['no']/N:.1%} | {aud_ct['cant_tell']/N:.1%} |\n")
    f.write("\n## Grounding by unit type\n\n| type | n | visual-only | audio-only | both | neither |\n|---|--:|--:|--:|--:|--:|\n")
    for t in types:
        tot = sum(by_type[t].values())
        f.write(f"| {t} | {tot} | {by_type[t]['visual']/max(1,tot):.0%} | {by_type[t]['audio']/max(1,tot):.0%} "
                f"| {by_type[t]['both']/max(1,tot):.0%} | {by_type[t]['neither']/max(1,tot):.0%} |\n")

# ---------- write index.html ----------
def esc(s): return html.escape(str(s))
figs = [("fig_verdict_dist.png", "Claim verdict distribution (M3 CRF)"),
        ("fig_grounding.png", "Per-unit grounding channel"),
        ("fig_audio_contrast.png", "Audio's unique contribution: claim vs unit level"),
        ("fig_modality_verdicts.png", "Per-unit verdict by modality"),
        ("fig_grounding_by_nodetype.png", "Grounding channel by unit type")]
rows_html = ""
for cid in examples:
    ct = meta.get((cid, byclaim[cid][0][1]), {}).get("claim_text", "")
    vd = verdict_of.get(cid, "?")
    units = ""
    for txt, v, a, nt in claim_units(cid):
        tag = "both" if (v == "yes" and a == "yes") else "visual" if v == "yes" else "audio" if a == "yes" else "neither"
        units += (f'<span class="u {tag}" title="visual={v}, audio={a}">{esc(txt)}'
                  f'<sub>{esc(nt[:3])}</sub></span> ')
    rows_html += (f'<tr><td class="cl">{esc(ct)}</td><td><span class="vd {vd}">{vd.replace("_"," ")}</span></td>'
                  f'<td class="units">{units}</td></tr>\n')

HTML = f"""<!doctype html><meta charset=utf-8><title>AViD M2/M3 analysis</title>
<style>
body{{font:14px/1.5 system-ui,sans-serif;max-width:1100px;margin:24px auto;padding:0 16px;color:#1a1a1a}}
h1{{font-size:22px}} h2{{font-size:17px;margin-top:28px;border-bottom:1px solid #eee;padding-bottom:4px}}
.grid{{display:flex;flex-wrap:wrap;gap:20px}} .grid figure{{margin:0;max-width:430px}}
img{{max-width:100%;border:1px solid #eee;border-radius:6px}} figcaption{{font-size:12px;color:#555;margin-top:4px}}
table{{border-collapse:collapse;width:100%;font-size:13px}} td,th{{border:1px solid #e5e5e5;padding:5px 8px;text-align:left}}
.cl{{max-width:320px}} .units{{line-height:2.1}}
.u{{padding:2px 6px;border-radius:4px;white-space:nowrap;font-size:13px;color:#fff}}
.u sub{{opacity:.7;font-size:9px}}
.visual{{background:{C['visual']}}} .audio{{background:{C['audio']}}} .both{{background:{C['both']}}}
.neither{{background:{C['neither']};color:#333}}
.vd{{padding:2px 8px;border-radius:10px;font-size:12px;color:#fff}}
.supported{{background:{C['supported']}}} .partially_supported{{background:{C['partially_supported']};color:#333}} .unsupported{{background:{C['unsupported']}}}
.legend span{{margin-right:14px}}
</style>
<h1>AViD Phase-3 — M2/M3 analysis (natural set, final T*)</h1>
<p><b>{len(decomp)}</b> claims · <b>{N}</b> probed units. Headline:
<b>audio uniquely grounds {audio_unique_unit:.1%} of units</b> vs &lt;1% of whole claims (pilot) —
the redundancy is a whole-claim artifact; per-channel structure lives below the claim.</p>
<div class="legend"><b>unit color =</b>
<span class="u visual">visual only</span><span class="u audio">audio only</span>
<span class="u both">both</span><span class="u neither">neither</span></div>
<h2>Distributions</h2>
<div class="grid">
{''.join(f'<figure><img src="{fn}"><figcaption>{esc(cap)}</figcaption></figure>' for fn, cap in figs)}
</div>
<h2>Example claims — per-unit modality attribution</h2>
<p style="font-size:12px;color:#666">Claims that contain at least one audio-only unit (the cross-modal cases). Subscript = unit type.</p>
<table><tr><th>claim</th><th>verdict</th><th>units (colored by grounding channel)</th></tr>
{rows_html}</table>
<p style="color:#888;font-size:12px">Generated by scripts/analyze_m3_results.py · source: decomp_m3.jsonl + verify_*_star.jsonl</p>
"""
open(OUT / "index.html", "w").write(HTML)

print(f"Wrote report → {OUT}/index.html")
print(f"  claims={len(decomp)}  units={N}  audio-only={audio_unique_unit:.1%}")
print(f"  figures: {len(figs)}  examples: {len(examples)}")
