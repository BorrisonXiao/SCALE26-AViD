"""
make_perturbations.py — M1

Generates three perturbation types from trees_ud.jsonl:
  negation : insert "not" at root predicate; root marked negated in tree
  binding  : swap a core-arg entity with one from a different video
  removal  : replace a core-arg entity with a generic placeholder

Design note on probing:
  Negation injection does NOT add rows to perturbed_units.tsv — it reuses
  the original probe scores and applies the CRF unary flip structurally.
  This isolates and tests the CRF's compositional negation handling.
  Binding and removal decoys DO appear in perturbed_units.tsv because the
  entity text changes and needs a fresh probe call.

Outputs (all in exp/phase3/perturb/):
  perturbed_claims.jsonl  — claim-level metadata for all perturbations
  perturbed_trees.jsonl   — modified tree records (for run_crf_inference.py)
  perturbed_units.tsv     — annotation-units schema for decoy probe calls (M2)
  gold.jsonl              — claim-level + node-level programmatic gold
  sanity_sample.tsv       — 20-row human-readable sample for gate check
"""
import json
import re
import random
import copy
import csv
import argparse
from pathlib import Path
from collections import defaultdict

TREES_PATH = Path("exp/phase3/trees/trees_ud.jsonl")
PERTURB_DIR = Path("exp/phase3/perturb")

TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted",
    "gold_channels", "notes",
]

SEED = 42


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def video_id(claim_id: str) -> str:
    """Everything before the last _N suffix (AViD video ID)."""
    return claim_id.rsplit("_", 1)[0]


def make_highlighted(claim_text: str, unit_text: str) -> str:
    """Surround first verbatim occurrence of unit_text with **...**."""
    if not unit_text:
        return claim_text
    try:
        escaped = re.escape(unit_text)
        return re.sub(escaped, f"**{unit_text}**", claim_text, count=1)
    except re.error:
        return claim_text


# Map head_upos to a generic placeholder for removal decoy
UPOS_PLACEHOLDER = {
    "PROPN": "[unidentified person/place]",
    "NOUN":  "[unspecified object]",
    "VERB":  "[unverifiable action]",
    "ADJ":   "[unspecified quality]",
    "NUM":   "[unspecified number]",
}
PLACEHOLDER_DEFAULT = "[unverifiable entity]"


# ---------------------------------------------------------------------------
# Negation injection
# ---------------------------------------------------------------------------

AUX_RE = re.compile(
    r"\b(is|are|was|were|will|would|can|could|should|may|might|must|"
    r"has|have|had|does|do|did|be|been|being)\b",
    re.IGNORECASE,
)


def inject_negation(claim_text: str, root_node: dict) -> str | None:
    """Return claim_text with 'not' inserted at the root verb, or None if infeasible."""
    verb = root_node["node_text"]
    m = re.search(re.escape(verb), claim_text, re.IGNORECASE)
    if not m:
        return None
    verb_start = m.start()
    prefix = claim_text[:verb_start]
    aux_matches = list(AUX_RE.finditer(prefix))
    if aux_matches:
        ins = aux_matches[-1].end()
        return claim_text[:ins] + " not" + claim_text[ins:]
    return claim_text[:verb_start] + "not " + claim_text[verb_start:]


# ---------------------------------------------------------------------------
# Entity pool for binding decoys
# ---------------------------------------------------------------------------

def build_entity_pool(trees: dict) -> dict[str, list[str]]:
    """
    Returns {video_id: [entity_text, ...]} for all probed core-arg entity nodes.
    Used to sample cross-video replacement entities for binding decoys.
    """
    pool: dict[str, list[str]] = defaultdict(list)
    for cid, tree in trees.items():
        vid = video_id(cid)
        for node in tree["nodes"]:
            if (node["rel_class"] == "core-arg"
                    and not node["is_functional"]
                    and node["probed"]
                    and node["node_type"] == "entity"):
                pool[vid].append(node["content_subtree_text"])
    return dict(pool)


def sample_replacement(pool: dict, source_vid: str, rng: random.Random,
                       exclude: str) -> str | None:
    """Pick a random entity text from a different video, not equal to exclude."""
    other_vids = [v for v in pool if v != source_vid]
    if not other_vids:
        return None
    rng.shuffle(other_vids)
    for vid in other_vids:
        candidates = [t for t in pool[vid] if t != exclude and len(t) > 1]
        if candidates:
            return rng.choice(candidates)
    return None


# ---------------------------------------------------------------------------
# Core-arg entity candidate selection
# ---------------------------------------------------------------------------

def core_arg_entity_candidates(tree: dict) -> list[dict]:
    """Return probed core-arg entity nodes that are direct children of the root."""
    root_id = tree["root_id"]
    nodes = {n["node_id"]: n for n in tree["nodes"]}
    root_children = nodes[root_id].get("children", [])
    return [
        nodes[nid] for nid in root_children
        if (nodes[nid]["rel_class"] == "core-arg"
            and not nodes[nid]["is_functional"]
            and nodes[nid]["probed"]
            and nodes[nid]["node_type"] == "entity")
    ]


def best_candidate(candidates: list[dict]) -> dict:
    """Prefer named entities (PROPN), then longest span."""
    return max(candidates,
               key=lambda n: (n["head_upos"] == "PROPN",
                              len(n["content_subtree_text"])))


# ---------------------------------------------------------------------------
# Text/span propagation for entity replacements
# ---------------------------------------------------------------------------

TEXT_FIELDS = ("node_text", "subtree_text", "content_subtree_text", "pn_unit_text")
SPAN_FIELDS = ("span", "subtree_span", "content_subtree_span", "pn_unit_span")


def _remap_span(span, start: int, old_end: int, new_end: int) -> list[int]:
    """Remap one [start, end] character span after a single text replacement."""
    if not isinstance(span, (list, tuple)) or len(span) != 2:
        return span
    s, e = span
    if not isinstance(s, int) or not isinstance(e, int) or s < 0 or e < 0:
        return list(span)
    delta = new_end - old_end

    # Entirely before the replacement.
    if e <= start:
        return [s, e]
    # Entirely after the replacement.
    if s >= old_end:
        return [s + delta, e + delta]
    # The span contains or overlaps the replaced text.
    new_s = s if s <= start else start
    new_e = e + delta if e >= old_end else new_end
    return [new_s, new_e]


def replace_target_in_tree(tree: dict, target_node_id: str,
                           replacement: str) -> tuple[str, dict, str]:
    """Replace a target unit and propagate the edit through its composed context.

    The old implementation updated only the target node.  Ancestor/root
    ``*_text`` fields therefore still contained the natural claim, and the M2
    probe (which consumes ``unit_text``) verified stale text.  This helper keeps
    the existing tree topology/node IDs but updates:

      * the full claim text,
      * the target node,
      * every ancestor text field that contains the target, and
      * every character span affected by the length change.

    Returns ``(perturbed_claim_text, new_tree, original_target_text)``.
    """
    nodes = {n["node_id"]: n for n in tree["nodes"]}
    target = nodes[target_node_id]
    old_text = target["content_subtree_text"]
    claim_text = tree["claim_text"]

    # Prefer the parser-anchored target span; fall back to exact text search.
    target_span = target.get("content_subtree_span")
    start = -1
    if (isinstance(target_span, (list, tuple)) and len(target_span) == 2
            and all(isinstance(x, int) for x in target_span)):
        s, e = target_span
        if 0 <= s < e <= len(claim_text) and claim_text[s:e] == old_text:
            start = s
    if start < 0:
        start = claim_text.find(old_text)
    if start < 0:
        raise ValueError(
            f"target text {old_text!r} not found in claim {tree['claim_id']!r}")

    old_end = start + len(old_text)
    new_end = start + len(replacement)
    new_claim = claim_text[:start] + replacement + claim_text[old_end:]
    new_tree = copy.deepcopy(tree)
    new_nodes = {n["node_id"]: n for n in new_tree["nodes"]}

    # Target + all ancestors semantically contain the replacement.
    ancestor_ids = {target_node_id}
    cur = new_nodes[target_node_id].get("parent_id")
    seen = set()
    while cur is not None and cur not in seen:
        seen.add(cur)
        ancestor_ids.add(cur)
        cur = new_nodes.get(cur, {}).get("parent_id")

    for node in new_tree["nodes"]:
        nid = node["node_id"]
        for field in SPAN_FIELDS:
            if field in node:
                node[field] = _remap_span(
                    node[field], start, old_end, new_end)

        if nid in ancestor_ids:
            for field in TEXT_FIELDS:
                value = node.get(field)
                if isinstance(value, str) and old_text in value:
                    node[field] = value.replace(old_text, replacement, 1)

    # The selected unit is the replacement itself, matching the prior behavior,
    # but now all textual views and spans agree.
    new_target = new_nodes[target_node_id]
    for field in TEXT_FIELDS:
        if field in new_target:
            new_target[field] = replacement
    for field in SPAN_FIELDS:
        if field in new_target:
            new_target[field] = [start, new_end]

    new_tree["claim_text"] = new_claim
    return new_claim, new_tree, old_text


# ---------------------------------------------------------------------------
# Perturbation constructors
# ---------------------------------------------------------------------------

def make_negation(tree: dict) -> dict | None:
    """Return perturbation record for negation injection, or None."""
    root_id = tree["root_id"]
    nodes = {n["node_id"]: n for n in tree["nodes"]}
    root = nodes[root_id]
    if root.get("is_functional"):
        return None
    # Only inject negation on clearly verbal roots; merged noun+verb nodes
    # produce grammatically incorrect insertions (e.g., "A not woman comments").
    if root["head_upos"] not in ("VERB", "AUX"):
        return None
    new_claim = inject_negation(tree["claim_text"], root)
    if not new_claim or new_claim == tree["claim_text"]:
        return None
    new_tree = copy.deepcopy(tree)
    new_root = next(n for n in new_tree["nodes"] if n["node_id"] == root_id)
    new_root["negated"] = True
    return {
        "perturb_type": "negation",
        "original_claim_id": tree["claim_id"],
        "original_claim_text": tree["claim_text"],
        "perturbed_claim_text": new_claim,
        "target_node_id": root_id,
        "reuse_original_probes": True,
        "tree": new_tree,
    }


def make_binding(tree: dict, pool: dict, rng: random.Random) -> dict | None:
    """Return perturbation record for binding decoy (cross-video entity swap), or None."""
    candidates = core_arg_entity_candidates(tree)
    if not candidates:
        return None
    target = best_candidate(candidates)
    old_text = target["content_subtree_text"]
    replacement = sample_replacement(pool, video_id(tree["claim_id"]), rng, old_text)
    if not replacement:
        return None
    new_claim, new_tree, old_text = replace_target_in_tree(
        tree, target["node_id"], replacement)
    if new_claim == tree["claim_text"]:
        return None
    return {
        "perturb_type": "binding",
        "original_claim_id": tree["claim_id"],
        "original_claim_text": tree["claim_text"],
        "perturbed_claim_text": new_claim,
        "target_node_id": target["node_id"],
        "original_entity_text": old_text,
        "replacement_entity_text": replacement,
        "reuse_original_probes": False,
        "tree": new_tree,
    }


def make_removal(tree: dict, rng: random.Random) -> dict | None:
    """Return perturbation record for removal decoy (entity placeholder), or None."""
    candidates = core_arg_entity_candidates(tree)
    if not candidates:
        return None
    target = rng.choice(candidates)
    old_text = target["content_subtree_text"]
    placeholder = UPOS_PLACEHOLDER.get(target["head_upos"], PLACEHOLDER_DEFAULT)
    new_claim, new_tree, old_text = replace_target_in_tree(
        tree, target["node_id"], placeholder)
    if new_claim == tree["claim_text"]:
        return None
    return {
        "perturb_type": "removal",
        "original_claim_id": tree["claim_id"],
        "original_claim_text": tree["claim_text"],
        "perturbed_claim_text": new_claim,
        "target_node_id": target["node_id"],
        "original_entity_text": old_text,
        "placeholder_text": placeholder,
        "reuse_original_probes": False,
        "tree": new_tree,
    }


# ---------------------------------------------------------------------------
# TSV rows for decoy perturbations
# ---------------------------------------------------------------------------

def perturb_to_tsv_rows(perturb_id: str, p: dict) -> list[dict]:
    """
    Emit annotation-units TSV rows for decoy perturbations.
    Negation perturbations are excluded (they reuse original probes).
    """
    if p["reuse_original_probes"]:
        return []  # negation: no new probe calls needed
    claim_text = p["perturbed_claim_text"]
    rows = []
    for node in p["tree"]["nodes"]:
        if node["is_functional"] or not node["probed"]:
            continue
        unit_text = node["content_subtree_text"]
        highlighted = make_highlighted(claim_text, unit_text)
        is_target = node["node_id"] == p["target_node_id"]
        notes = f"perturbation:{p['perturb_type']}"
        if is_target:
            notes += ",target"
        rows.append({
            "claim_id": perturb_id,
            "unit_id": node["node_id"],
            "unit_type": "tree_node",
            "node_type": node["node_type"],
            "claim_text": claim_text,
            "unit_text": unit_text,
            "claim_highlighted": highlighted,
            "gold_channels": "",
            "notes": notes,
        })
    return rows


# ---------------------------------------------------------------------------
# Gold labels
# ---------------------------------------------------------------------------

def make_gold(perturb_id: str, p: dict) -> dict:
    """
    Programmatic (distant) gold labels.

    negation : root flips to unsupported; non-root nodes stay supported
    binding  : target entity → unsupported; others stay supported
    removal  : target entity → unsupported; others stay supported

    Root is always unsupported by construction (that's the point of the perturbation).
    Node-level gold for non-target nodes is 'supported' (distant label from captioning).
    """
    node_gold: dict[str, dict] = {}
    root_id = p["tree"]["root_id"]
    target_nid = p["target_node_id"]

    for node in p["tree"]["nodes"]:
        if node["is_functional"] or not node["probed"]:
            continue
        nid = node["node_id"]
        if p["perturb_type"] == "negation":
            if nid == target_nid:
                verdict, reason = "unsupported", "negation_flip"
            else:
                verdict, reason = "supported", "unchanged"
        else:  # binding or removal
            if nid == target_nid:
                verdict, reason = "unsupported", "entity_absent"
            elif nid == root_id:
                verdict, reason = "unsupported", "core_arg_veto"
            else:
                verdict, reason = "supported", "unchanged"
        node_gold[nid] = {"verdict": verdict, "reason": reason}

    return {
        "perturb_id": perturb_id,
        "original_claim_id": p["original_claim_id"],
        "perturb_type": p["perturb_type"],
        "claim_verdict": "unsupported",
        "node_gold": node_gold,
        "distant_label": True,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Generate M1 perturbations.")
    parser.add_argument("--trees", default=str(TREES_PATH),
                        help="Path to trees_ud.jsonl")
    parser.add_argument("--out-dir", default=str(PERTURB_DIR),
                        help="Output directory")
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--max-per-type", type=int, default=None,
                        help="Cap perturbations per type (dev/testing only)")
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)

    print("Loading trees …")
    trees: dict[str, dict] = {}
    with open(args.trees) as f:
        for line in f:
            r = json.loads(line)
            trees[r["claim_id"]] = r
    print(f"  {len(trees):,} trees loaded")

    print("Building entity pool for binding decoys …")
    pool = build_entity_pool(trees)
    total_ents = sum(len(v) for v in pool.values())
    print(f"  {total_ents:,} entities across {len(pool):,} video IDs")

    # ------------------------------------------------------------------
    all_meta: list[dict] = []      # perturbed_claims.jsonl (no tree)
    all_trees: list[dict] = []     # perturbed_trees.jsonl  (full tree)
    all_tsv: list[dict] = []       # perturbed_units.tsv    (decoys only)
    all_gold: list[dict] = []      # gold.jsonl
    # ------------------------------------------------------------------

    for claim_id, tree in trees.items():
        for builder, suffix in [
            (lambda t: make_negation(t),                   "__neg"),
            (lambda t: make_binding(t, pool, rng),         "__bind"),
            (lambda t: make_removal(t, rng),               "__rem"),
        ]:
            p = builder(tree)
            if p is None:
                continue
            pid = claim_id + suffix

            # Meta record (no full tree — keep file small)
            meta = {k: v for k, v in p.items() if k != "tree"}
            meta["perturb_id"] = pid
            all_meta.append(meta)

            # Full perturbed tree (for run_crf_inference.py)
            ptree = p["tree"].copy()
            ptree["claim_id"] = pid
            ptree["claim_text"] = p["perturbed_claim_text"]
            ptree["original_claim_id"] = claim_id
            ptree["perturb_type"] = p["perturb_type"]
            ptree["target_node_id"] = p["target_node_id"]
            ptree["reuse_original_probes"] = p["reuse_original_probes"]
            all_trees.append(ptree)

            all_tsv.extend(perturb_to_tsv_rows(pid, p))
            all_gold.append(make_gold(pid, p))

    # Apply per-type cap (for fast iteration / testing)
    if args.max_per_type is not None:
        by_type: dict[str, list] = defaultdict(list)
        for m in all_meta:
            by_type[m["perturb_type"]].append(m)
        keep_pids: set[str] = set()
        for ps in by_type.values():
            keep_pids.update(m["perturb_id"] for m in ps[:args.max_per_type])
        all_meta  = [m for m in all_meta  if m["perturb_id"] in keep_pids]
        all_trees = [t for t in all_trees if t["claim_id"] in keep_pids]
        all_tsv   = [r for r in all_tsv   if r["claim_id"] in keep_pids]
        all_gold  = [g for g in all_gold  if g["perturb_id"] in keep_pids]

    # ------------------------------------------------------------------
    # Write outputs
    # ------------------------------------------------------------------

    claims_path = out_dir / "perturbed_claims.jsonl"
    with open(claims_path, "w") as f:
        for m in all_meta:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")
    print(f"Wrote {len(all_meta):,} records → {claims_path}")

    trees_path = out_dir / "perturbed_trees.jsonl"
    with open(trees_path, "w") as f:
        for t in all_trees:
            f.write(json.dumps(t, ensure_ascii=False) + "\n")
    print(f"Wrote {len(all_trees):,} trees → {trees_path}")

    tsv_path = out_dir / "perturbed_units.tsv"
    with open(tsv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=TSV_COLS, delimiter="\t")
        writer.writeheader()
        writer.writerows(all_tsv)
    print(f"Wrote {len(all_tsv):,} TSV rows → {tsv_path}")

    gold_path = out_dir / "gold.jsonl"
    with open(gold_path, "w") as f:
        for g in all_gold:
            f.write(json.dumps(g, ensure_ascii=False) + "\n")
    print(f"Wrote {len(all_gold):,} gold records → {gold_path}")

    # Sanity sample: up to 7 records per type
    sanity_rows: list[dict] = []
    by_type: dict[str, list] = defaultdict(list)
    for m in all_meta:
        by_type[m["perturb_type"]].append(m)
    for ptype in ("negation", "binding", "removal"):
        for m in by_type.get(ptype, [])[:7]:
            gold_rec = next((g for g in all_gold if g["perturb_id"] == m["perturb_id"]), {})
            sanity_rows.append({
                "perturb_id":            m["perturb_id"],
                "perturb_type":          m["perturb_type"],
                "original_claim_text":   m["original_claim_text"],
                "perturbed_claim_text":  m["perturbed_claim_text"],
                "target_node_id":        m["target_node_id"],
                "claim_verdict_gold":    gold_rec.get("claim_verdict", ""),
                "target_node_verdict":   gold_rec.get("node_gold", {}).get(
                                             m["target_node_id"], {}).get("verdict", ""),
            })

    sanity_path = out_dir / "sanity_sample.tsv"
    sanity_cols = ["perturb_id", "perturb_type", "original_claim_text",
                   "perturbed_claim_text", "target_node_id",
                   "claim_verdict_gold", "target_node_verdict"]
    with open(sanity_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=sanity_cols, delimiter="\t")
        writer.writeheader()
        writer.writerows(sanity_rows)
    print(f"Wrote {len(sanity_rows)}-row sanity sample → {sanity_path}")

    # Summary
    print("\nPerturbation counts:")
    for ptype in ("negation", "binding", "removal"):
        n = len(by_type.get(ptype, []))
        print(f"  {ptype:12s}: {n:,}")
    print(f"  {'total':12s}: {len(all_meta):,}")
    print(f"  Decoy probe units: {len(all_tsv):,}")


if __name__ == "__main__":
    main()
