#!/usr/bin/env python3
"""Quick modality-tree PREVIEWS (PNG via graphviz) for candidate featured claims.
Colors each probeable unit by the REAL model channel (verify_*_star pass1_verdict).
Usage: python scripts/preview_modality_trees.py <claim_id> [<claim_id> ...]
"""
import json, subprocess, sys, html
from pathlib import Path

AVID = Path("/exp/cxiao/scale26/avid")
trees = {json.loads(l)["claim_id"]: json.loads(l)
         for l in open(AVID / "exp/phase3/trees/trees_ud_star.jsonl")}
def load(p):
    return {(json.loads(l)["claim_id"], json.loads(l)["unit_id"]): json.loads(l)["pass1_verdict"]
            for l in open(p)}
vis = load(AVID / "exp/phase3/nodes/verify_visual_star.jsonl")
aud = load(AVID / "exp/phase3/nodes/verify_audio_star.jsonl")
COLOR = {"visual": "#4C78A8", "audio": "#F58518", "both": "#54A24B", "neither": "#BAB0AC", "na": "#BAB0AC"}
OPS = {"relation-op", "coord-op", "coordination-op", "logical-op", "functional"}

def channel(cid, uid, probed):
    if not probed:
        return "na"
    v, a = vis.get((cid, uid)), aud.get((cid, uid))
    vy, ay = v == "yes", a == "yes"
    return "both" if vy and ay else "visual" if vy else "audio" if ay else "neither"

def esc(s): return s.replace('"', "'").replace("\n", " ")

def render(cid, outdir):
    r = trees[cid]; nodes = r["nodes"]
    keep = [n for n in nodes if n.get("node_type") not in OPS]
    L = ['digraph{rankdir=TB;bgcolor=white;',
         'node[shape=box,style="rounded,filled",fontname="Helvetica",fontsize=12,margin="0.12,0.06"];',
         'edge[color="#999999",fontname="Helvetica",fontsize=9,fontcolor="#777777"];',
         f'labelloc=t;fontsize=15;fontname="Helvetica-Bold";label="{esc(r["claim_text"])}";']
    ids = {n["node_id"] for n in keep}
    for n in keep:
        ch = channel(cid, n["node_id"], n.get("probed"))
        txt = esc((n.get("pn_unit_text") or n.get("node_text") or "")[:26])
        fc = "#333333" if ch in ("na", "neither") else "white"
        L.append(f'"{n["node_id"]}" [label="{txt}\\n{ch.upper()}",fillcolor="{COLOR[ch]}",fontcolor="{fc}"];')
    for n in keep:
        p = n.get("parent_id")
        if p in ids:
            L.append(f'"{p}"->"{n["node_id"]}" [label="{esc(n.get("deprel",""))}"];')
    L.append("}")
    dot = "\n".join(L)
    base = outdir / f"cand_{cid}"
    base.with_suffix(".dot").write_text(dot)
    subprocess.run(["dot", "-Tpng", "-o", str(base.with_suffix(".png")), str(base.with_suffix(".dot"))], check=True)
    # report channels
    chans = [(esc((n.get("pn_unit_text") or n.get("node_text") or "")), channel(cid, n["node_id"], n.get("probed")))
             for n in keep]
    print(f"{cid}: {r['claim_text']}")
    for t, c in chans: print(f"    {c:8s} {t}")
    return str(base.with_suffix(".png"))

if __name__ == "__main__":
    outdir = AVID / "slides/figures/candidates"; outdir.mkdir(parents=True, exist_ok=True)
    for cid in sys.argv[1:]:
        try: render(cid, outdir)
        except Exception as e: print(f"{cid}: ERR {e}")
