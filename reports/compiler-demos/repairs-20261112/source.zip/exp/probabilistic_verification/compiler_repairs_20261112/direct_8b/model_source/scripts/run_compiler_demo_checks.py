#!/usr/bin/env python3
"""Execute the demo's three OCR/speech controls using stipulated observations."""
import json
from pathlib import Path
from probabilistic_verification.balanced_logic import BalancedVerifier
from probabilistic_verification.content_recovery import compile_content_recovery
from probabilistic_verification.logic import Evidence,Observation,canonical_key
from probabilistic_verification.multimodal import ground_two_sources

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_recovery_20261105'


def main():
    record=next(r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())if r['claim_id']=='TFgw4IaR9R8s_1596')
    claim,_=compile_content_recovery(record);domains={v.name:[v.name.lower()]for v in claim.variables};assignment={v:xs[0]for v,xs in domains.items()}
    target=next(a for a in claim.atoms if a.predicate=='show');cases=[]
    for state in ['supported','refuted','unknown']:
        evidence=[]
        for route in ['ocr_assertion','speech_assertion']:
            observations={}
            for atom in claim.atoms:
                label=state if route=='ocr_assertion'and atom.id==target.id else 'supported'
                key=canonical_key('compiler-demo',atom,assignment,route)
                observations[key]=Observation(key,tuple(float(s==label)for s in ['supported','refuted','unknown']),False,atom.text,{'source':'stipulated demo evidence, not perception'})
            evidence.append(Evidence('compiler-demo',domains,{v:True for v in domains},observations,route=route))
        _,speech,combined,_=ground_two_sources(claim,*evidence,allowed={a:set(v)for a,v in claim.metadata['allowed_routes'].items()})
        result=BalancedVerifier([speech,combined],learned=False).predict()
        assert result[0]['distribution']['unknown']>1-1e-9 and result[1]['distribution'][state]>1-1e-9
        cases.append(dict(ocr_state=state,speech_state='supported',speech_only=result[0]['distribution'],combined=result[1]['distribution']))
    (RUN/'native_demo.json').write_text(json.dumps(dict(claim_id=record['claim_id'],provenance='Actual DeepProbLog inference on constructed evidence. No media model or relation training was run.',cases=cases),indent=2)+'\n')
    print('All3 native demo controls match the declared OCR policy.')


if __name__=='__main__':main()
