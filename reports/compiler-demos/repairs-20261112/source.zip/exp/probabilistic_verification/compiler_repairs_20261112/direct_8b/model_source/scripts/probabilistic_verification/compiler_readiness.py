"""General annotation repairs before the existing semantic compiler."""
import copy,json,re
from .scoped_srl import SourceSyntax,quoted_spans
from .semantic_components import compile_components
from .content_recovery import tid
from .compilation_followup import walk_events
from .semantic_values import DATE_TIME,temporal_literal

SCOPE_ADVERBS={'not','never','hardly','barely','scarcely','almost','nearly','only','even','otherwise','again','often','always','sometimes','usually','rarely','more','less','most','least','approximately','roughly','about','around','then','already','still','yet','previously','formerly','recently','now','later','earlier','likely','presumably','probably','possibly','certainly','apparently','allegedly','simply','practically','so','all','currently','first','last','just','perhaps','maybe'}
NONFACTUAL={'prevent','avoid','plan','prepare','want','hope','expect','predict','fear','threaten','imagine','deny','seek','consider','discuss','propose','schedule'}

def interval_from_text(text):
    matches=list(DATE_TIME.finditer(text))
    if len(matches)!=2 or not(re.search(r'\b(?:from|between)\b',text,re.I)or re.search(r'\bbegin\w*\b',text,re.I)and re.search(r'\bend\w*\b',text,re.I)):return None
    from .logical_form import LogicalFormError
    try:return temporal_literal('from '+matches[0][0]+' to '+matches[1][0])
    except LogicalFormError:return None

def temporal_references(record,form,notes,alignments):
    source=record.get('compiler_context',{}).get('original_text')
    interval=interval_from_text(source)if source else None
    if not interval:return
    for event in walk_events(form):
        for role,value in list(event.get('arguments',{}).items()):
            if not isinstance(value,dict):continue
            raw=str(value.get('value',''))
            if not re.fullmatch(r'(?:during|in)\s+(?:this|that|the same)\s+(?:time|period|interval)',raw,re.I):continue
            matches=list(re.finditer(re.escape(raw),record['text'],re.I))
            if len(matches)!=1:continue
            event['arguments'][role]=copy.deepcopy(interval);m=matches[0]
            alignments.append(dict(start=m.start(),end=m.end(),text=m[0],target=event['id']+'/'+role,kind=interval['kind'],value=copy.deepcopy(interval),reference_resolution=True,origin_text=source))
            notes.append(dict(kind='temporal_reference',event=event['id'],source=m[0],interval=copy.deepcopy(interval)))

def linked_modifiers(record,form,notes):
    s=SourceSyntax(record);events=list(walk_events(form));owners={tid(e['id'],'e'):e for e in events}
    for event in events:
        token=s.by_id.get(tid(event['id'],'e'))
        if token and token['deprel']=='cop':owners[token['head']]=event
    entities={tid(e['id'],'x'):e for e in form['entities']}
    for token in s.tokens:
        if token['upos']!='ADV'or token['deprel']!='advmod'or token['lemma'].lower()in SCOPE_ADVERBS:continue
        if any(lo<=token['start_char']<hi for lo,hi,_ in quoted_spans(record['text'])):continue
        owner=owners.get(token['head'])or entities.get(token['head'])
        if not owner:continue
        # Do not duplicate an already translated role value or modifier.
        values=' '.join(str(p.get('value',''))for p in owner.get('properties',[]))+' '+json.dumps(owner.get('arguments',{}),ensure_ascii=False)
        if re.search(r'\b'+re.escape(token['text'])+r'\b',values,re.I):continue
        owner.setdefault('properties',[]).append(dict(role='advmod',value=token['text']))
        notes.append(dict(kind='linked_adverb',owner=owner['id'],word=token['text'],basis='explicit dependency attachment; scope/frequency operators excluded'))

def nominal_events(record,form,notes,alignments):
    from nltk.corpus import wordnet as wn
    s=SourceSyntax(record);by_id=s.by_id
    for entity in form['entities']:
        head=by_id.get(tid(entity['id'],'x'))
        if not head or head['upos']!='NOUN'or any(lo<=head['start_char']<hi for lo,hi,_ in quoted_spans(record['text'])):continue
        if entity.get('quantity')or entity.get('type')=='group':continue
        senses=wn.synsets(head['lemma'],pos=wn.NOUN)
        event_senses=[sense for sense in senses if sense.lexname()in{'noun.event','noun.process','noun.act'}]
        if not event_senses:continue
        if head['lemma'].lower()in{'image','photo','photograph','video','audio','recording'}:continue
        if any(t['lemma'].lower()in{'plan','potential','possible','predict','future','expect','prevent','allege','threaten'}
               or t['text'].lower()in{'planned','potential','possible','predicted','future','expected','prevented','alleged','threatened'}
               for t in s.children[head['id']]):continue
        # A lexical event class alone is insufficient. Require explicit nominal
        # arguments or occurrence/time context, and do not assert planned events.
        parent=by_id.get(head['head']);parent_lemma=parent['lemma'].lower()if parent else''
        if parent_lemma in NONFACTUAL:continue
        if senses[0]not in event_senses:
            # A less frequent action sense of an ordinary object (e.g. road)
            # does not make that object an event. State/event alternations need
            # a strong occurrence/causal context and the appropriate argument.
            if senses[0].lexname()!='noun.state':continue
            if not(head['deprel'].startswith('nsubj')and parent_lemma in{'occur','happen','cause','block'}
                   or head['deprel']=='obj'and parent_lemma=='cause'):continue
        cue=any(r['role']in{'of','by'}for r in entity.get('relations',[]))or parent_lemma in{'occur','happen','begin','start','end','last','cause','block','follow','show','depict'}
        if not cue:continue
        entity['type']='event';notes.append(dict(kind='nominal_event',entity=entity['id'],predicate=head['lemma'],basis='WordNet event/process/action class and explicit argument/context'))

def remove_auxiliary_frames(record):
    """An auxiliary does not introduce another event when its lexical head exists."""
    prepared=copy.deepcopy(record);s=SourceSyntax(prepared);frames=prepared.get('srl',{}).get('frames',[])
    heads=[s.frame_head(f)for f in frames];present={h['id']for h in heads if h}
    removed=[];kept=[]
    for frame,head in zip(frames,heads):
        if head and head['deprel']in{'aux','aux:pass'}and head['lemma'].lower()in{'be','have','do'}and head['head']in present:
            removed.append(dict(kind='auxiliary_frame',token=head['text'],parent=head['head']))
        else:kept.append(frame)
    if prepared.get('srl'):prepared['srl']['frames']=kept
    return prepared,removed

def compile_ready(record,*,strict=True,auxiliary=True,nominals=False,modifiers=True,references=True,transform_form=None,**options):
    prepared,notes=remove_auxiliary_frames(record)if auxiliary else(copy.deepcopy(record),[])
    def transform(r,form,changes,alignments):
        if nominals:nominal_events(r,form,changes,alignments)
        if modifiers:linked_modifiers(r,form,changes)
        if references:temporal_references(r,form,changes,alignments)
        if transform_form:transform_form(r,form,changes,alignments)
    claim,changes=compile_components(prepared,strict=strict,transform_form=transform,**options)
    return claim,notes+changes

def compile_one(record,**options):
    from run_scope_coverage_census import compile_one as compile_record
    row=compile_record(record,compiler=lambda r,strict:compile_ready(r,strict=strict,**options))
    if row.get('structural_alerts')and row.get('code')in{'missing_event','unlinked_temporal_value','unresolved_time_reference'}:row['reason']=row['structural_alerts'][0].get('reason',row['reason'])
    return row
