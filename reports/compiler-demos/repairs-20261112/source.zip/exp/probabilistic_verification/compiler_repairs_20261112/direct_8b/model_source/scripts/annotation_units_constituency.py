"""
AViD Phase 1 Parsing Ablation — Annotation Unit Construction (Constituency).

Pure functions over a single constituency record (from constituency.jsonl); no I/O.

Unit selection:
  NP brackets → phrase_entity / entity
      Drop NPs whose tokens are all PTB-EX ("there").
      Bare pronoun NPs → keep but flag notes="pronoun".
  S / SBAR / SINV / SQ / FRAG → factor / clause  (embedded)
                               → factor / full_claim  (maximal, widest span)
  --verb-units: lexical head verb of each clause → node / event
      Skip copular "be" (lemma check). Mirrors dep copula demotion.
  --maximal-np: emit only maximal NPs (no nested brackets).
      Default: emit all brackets; maximal status computed at analysis time.
  Dedup by (start_char, end_char); phrase_entity beats factor for same span.

Mirrors the interface of annotation_units.py:
    make_annotation_units_constituency(rec, verb_units, maximal_np)
        → (rows: list[dict], stats: dict)
    where rows use the identical 9-column schema as annotation_units.tsv.
"""

from __future__ import annotations

# ── Constants ─────────────────────────────────────────────────────────────────

_CLAUSE_LABELS = frozenset({"S", "SBAR", "SINV", "SQ", "FRAG"})

# PTB fine-grained tags for existential "there"
_EX_TAGS = frozenset({"EX"})

# Copular lemma — skip when emitting verb units (mirrors dep _COPULA_LEMMAS)
_COPULA_LEMMAS = frozenset({"be"})

# Auxiliary dep relations — skip when searching for lexical head verb
_AUX_DEPS = frozenset({"aux", "aux:pass", "auxpass", "cop"})

# Bare pronouns to flag (lowercase); bare = single-token pronoun NPs
_PRONOUN_TEXTS = frozenset({
    "i", "me", "my", "myself",
    "you", "your", "yourself",
    "he", "him", "his", "himself",
    "she", "her", "hers", "herself",
    "it", "its", "itself",
    "we", "us", "our", "ourselves",
    "they", "them", "their", "themselves",
    "this", "that", "these", "those",
})


# ── Helpers ───────────────────────────────────────────────────────────────────

def _highlight(text: str, start: int, end: int) -> str:
    return text[:start] + "**" + text[start:end] + "**" + text[end:]


def _is_ex_np(constituent: dict) -> bool:
    """True if every token in this NP has PTB tag EX (existential 'there')."""
    toks = constituent["tokens"]
    return bool(toks) and all(t["tag"] in _EX_TAGS for t in toks)


def _is_pronoun_np(constituent: dict) -> bool:
    """True if every token is a bare pronoun (lower-cased lookup)."""
    toks = constituent["tokens"]
    return bool(toks) and all(t["text"].lower() in _PRONOUN_TEXTS for t in toks)


def _clause_head_verb(constituent: dict) -> dict | None:
    """Return the token dict for the lexical head verb of a clause constituent.

    Strategy:
      1. Filter to VERB tokens with dep not in aux/cop set and lemma not 'be'.
      2. Prefer a ROOT-dep token; else prefer one whose syntactic head is outside
         the constituent's token set; else take the first candidate.

    Returns None if no eligible verb found.
    """
    toks     = constituent["tokens"]
    span_is  = {t["i"] for t in toks}

    candidates = [
        t for t in toks
        if t["pos"] == "VERB"
        and t["dep"] not in _AUX_DEPS
        and t["lemma"].lower() not in _COPULA_LEMMAS
    ]
    if not candidates:
        return None

    # Prefer ROOT-labeled verb (main clause)
    root_cands = [t for t in candidates if t["dep"].upper() == "ROOT"]
    if root_cands:
        return root_cands[0]

    # Prefer verb whose syntactic head is outside the span (clause "head" in dep terms)
    head_outside = [t for t in candidates if t["head_i"] not in span_is]
    if head_outside:
        return head_outside[0]

    return candidates[0]


# ── Main entry point ──────────────────────────────────────────────────────────

TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted",
    "gold_channels", "notes",
]


def make_annotation_units_constituency(
    rec: dict,
    verb_units: bool = False,
    maximal_np: bool = False,
) -> tuple[list[dict], dict]:
    """Build annotation unit rows for one constituency record.

    Args:
        rec        : one record from constituency.jsonl
        verb_units : emit clause-head verbs as event units (behind flag)
        maximal_np : emit only maximal (non-nested) NPs (behind flag)

    Returns:
        rows  — list of 9-col row dicts (same schema as annotation_units.tsv)
        stats — counters dict
    """
    claim_id     = rec["claim_id"]
    claim_text   = rec["claim_text"]
    constituents = rec["constituents"]

    # ── Partition constituents ────────────────────────────────────────────────
    np_spans     = [c for c in constituents if c["label"] == "NP"]
    clause_spans = [c for c in constituents if c["label"] in _CLAUSE_LABELS]

    # ── NP filtering: drop EX, flag pronouns ─────────────────────────────────
    dropped_ex      = 0
    pronoun_flagged = 0
    kept_nps: list[dict] = []

    for np in np_spans:
        if _is_ex_np(np):
            dropped_ex += 1
            continue
        np = dict(np)  # shallow copy so we can attach metadata
        np["_pronoun"] = _is_pronoun_np(np)
        if np["_pronoun"]:
            pronoun_flagged += 1
        kept_nps.append(np)

    # ── Optional maximal-NP filter ────────────────────────────────────────────
    nested_np_count = 0
    if maximal_np:
        maximal: list[dict] = []
        for np in kept_nps:
            s, e = np["start_char"], np["end_char"]
            is_nested = any(
                other["start_char"] <= s and e <= other["end_char"]
                and (other["start_char"] < s or e < other["end_char"])
                for other in kept_nps
            )
            if is_nested:
                nested_np_count += 1
            else:
                maximal.append(np)
        kept_nps = maximal

    # ── Full-claim span: widest clause constituent ────────────────────────────
    full_claim_span: dict | None = None
    if clause_spans:
        full_claim_span = max(clause_spans, key=lambda c: c["end_char"] - c["start_char"])

    # ── Dedup registry: (start_char, end_char) → row dict ────────────────────
    # phrase_entity beats factor for the same span.
    seen: dict[tuple[int, int], dict] = {}

    def _add(row: dict) -> None:
        key = (row["_s"], row["_e"])
        if key not in seen:
            seen[key] = row
        elif seen[key]["unit_type"] == "factor" and row["unit_type"] == "phrase_entity":
            seen[key] = row

    # ── (a) NP → phrase_entity / entity ──────────────────────────────────────
    for i, np in enumerate(kept_nps):
        s, e  = np["start_char"], np["end_char"]
        text  = claim_text[s:e]
        notes = "NP;pronoun" if np.get("_pronoun") else "NP"
        _add({
            "claim_id":          claim_id,
            "unit_id":           f"cnp_{i}",
            "unit_type":         "phrase_entity",
            "node_type":         "entity",
            "claim_text":        claim_text,
            "unit_text":         text,
            "claim_highlighted": _highlight(claim_text, s, e),
            "gold_channels":     "",
            "notes":             notes,
            "_s": s, "_e": e,
        })

    # ── (b) Clauses → factor / clause or full_claim ───────────────────────────
    for clause in clause_spans:
        s, e  = clause["start_char"], clause["end_char"]
        text  = claim_text[s:e]
        is_full = (
            full_claim_span is not None
            and s == full_claim_span["start_char"]
            and e == full_claim_span["end_char"]
        )
        node_type = "full_claim" if is_full else "clause"
        _add({
            "claim_id":          claim_id,
            "unit_id":           f"cs_{s}_{e}",
            "unit_type":         "factor",
            "node_type":         node_type,
            "claim_text":        claim_text,
            "unit_text":         text,
            "claim_highlighted": _highlight(claim_text, s, e),
            "gold_channels":     "",
            "notes":             clause["label"],
            "_s": s, "_e": e,
        })

    # ── (c) Verb units (--verb-units) ─────────────────────────────────────────
    verb_unit_count = 0
    if verb_units:
        seen_verb_positions: set[int] = set()  # dedup same verb across nested clauses
        for clause in clause_spans:
            vtok = _clause_head_verb(clause)
            if vtok is None:
                continue
            vs = vtok["start_char"]
            ve = vtok["end_char"]
            if vs in seen_verb_positions:
                continue
            seen_verb_positions.add(vs)
            verb_unit_count += 1
            _add({
                "claim_id":          claim_id,
                "unit_id":           f"cv_{vs}_{ve}",
                "unit_type":         "node",
                "node_type":         "event",
                "claim_text":        claim_text,
                "unit_text":         claim_text[vs:ve],
                "claim_highlighted": _highlight(claim_text, vs, ve),
                "gold_channels":     "",
                "notes":             f"head-of:{clause['label']}",
                "_s": vs, "_e": ve,
            })

    # ── Sort by position, strip internal fields ───────────────────────────────
    rows_raw = sorted(seen.values(), key=lambda r: (r["_s"], r["_e"]))
    rows = [{col: r[col] for col in TSV_COLS} for r in rows_raw]

    stats = {
        "np_total":       len(np_spans),
        "np_dropped_ex":  dropped_ex,
        "np_pronoun":     pronoun_flagged,
        "np_nested":      nested_np_count,
        "np_emitted":     sum(1 for r in rows if r["node_type"] == "entity"),
        "clause_total":   len(clause_spans),
        "clause_emitted": sum(1 for r in rows if r["node_type"] == "clause"),
        "full_claim":     sum(1 for r in rows if r["node_type"] == "full_claim"),
        "verb_units":     verb_unit_count,
        "rows_out":       len(rows),
    }

    return rows, stats
