"""Replay every current and preceding record, including diagnostics and metadata."""
import hashlib,json,time
from pathlib import Path
from run_content_relations_census import compile_one as current
from run_content_recovery_census import compile_one as previous
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_relations_20261105'
def main():
    for p,h in json.loads((RUN/'frozen_manifest.json').read_text())['source_sha256'].items():
        assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
    inputs=list(map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines()));proof={}
    for label,filename,compile in [('current','results.jsonl',current),('previous','baseline.jsonl',previous)]:
        expected={r['claim_id']:r for r in map(json.loads,(RUN/filename).read_text().splitlines())};start=time.perf_counter()
        for r in inputs:assert json.loads(json.dumps(compile(r)))==expected[r['claim_id']],(label,r['claim_id'])
        proof[label]=dict(exact_records=len(inputs),seconds=time.perf_counter()-start);print(label,len(inputs),'exact records',flush=True)
    (RUN/'replay_verification.json').write_text(json.dumps(proof,indent=2)+'\n')
if __name__=='__main__':main()
