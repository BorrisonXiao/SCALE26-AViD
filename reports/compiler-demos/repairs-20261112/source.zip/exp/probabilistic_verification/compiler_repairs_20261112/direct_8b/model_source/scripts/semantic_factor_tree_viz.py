#!/usr/bin/env python3
"""Render one semantic factor graph as a clickable, top-down inline SVG tree.

The compiler output is already a connected bipartite tree.  This renderer roots
that undirected graph at the latent claim verdict, alternates variable and factor
boxes, and visually mutes machine-only composition/fixed operators.  It does not
change or flatten the executable graph.
"""

from __future__ import annotations

from html import escape
from typing import Any


Y_SPACING = 82
NODE_H = 42
CHAR_W = 6.7
PAD_X = 17
MIN_W = 82
MAX_W = 210
COL_GAP = 34
MARGIN_X = 24
MARGIN_Y = 18


def _clean(text: str) -> str:
    return " ".join((text or "").split())


def _truncate(text: str, limit: int = 27) -> str:
    text = _clean(text)
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def _width(label: str) -> float:
    return max(MIN_W, min(MAX_W, len(label) * CHAR_W + 2 * PAD_X))


def _layout(root: str, children: dict[str, list[str]]) -> tuple[dict[str, int], dict[str, float], int]:
    depth: dict[str, int] = {}
    queue = [(root, 0)]
    while queue:
        node, level = queue.pop(0)
        if node in depth:
            continue
        depth[node] = level
        queue.extend((child, level + 1) for child in children.get(node, []))

    x_index: dict[str, float] = {}
    leaf = [0]

    def visit(node: str) -> None:
        kids = [child for child in children.get(node, []) if child in depth]
        if not kids:
            x_index[node] = leaf[0]
            leaf[0] += 1
            return
        for child in kids:
            visit(child)
        x_index[node] = sum(x_index[child] for child in kids) / len(kids)

    visit(root)
    return depth, x_index, max(1, leaf[0])


def build_factor_tree_svg(record: dict[str, Any], visible_targets: set[str] | None = None) -> str:
    """Return an inline SVG for one ``semantic-factor-tree-v1`` record."""
    visible_targets = visible_targets or set()
    entries: dict[str, dict[str, Any]] = {}
    adjacency: dict[str, set[str]] = {}

    for variable in record.get("variables", []):
        vid = variable["id"]
        _vrole = variable.get("evidence_role", "")
        _vsub = ("internal output" if vid == "y:claim"
                 else "na" if _vrole in {"abstain", "na"}
                 else variable.get("semantic_type", "unit"))
        entries[vid] = {
            "kind": "variable", "label": variable.get("display_text") or variable["unit_text"],
            "subtitle": _vsub,
            "role": _vrole, "span": variable.get("span", [-1, -1]),
        }
        adjacency[vid] = set()

    for factor in record.get("factors", []):
        fid = factor["id"]
        internal = factor.get("evidence_role") in {"fixed_factor", "contract"} or factor.get("factor_scope") == "root"
        label = "composition" if fid == "compose:root" else (
            factor.get("display_text") or factor.get("unit_text") or factor.get("semantic_relation", "factor")
        )
        subtitle = "internal · not annotated" if internal else factor.get("semantic_relation", "factor").replace("_", " ")
        entries[fid] = {
            "kind": "factor", "label": label, "subtitle": subtitle,
            "role": factor.get("evidence_role", ""), "internal": internal,
            "span": factor.get("span", [-1, -1]),
        }
        adjacency[fid] = set()
        for argument in factor.get("argument_ids", []):
            if argument not in adjacency:
                continue
            adjacency[fid].add(argument)
            adjacency[argument].add(fid)

    root = "y:claim"
    if root not in entries:
        return '<svg xmlns="http://www.w3.org/2000/svg" width="180" height="28"><text x="4" y="18" fill="#99a3b6" font-size="12">no factor tree</text></svg>'

    # Root the undirected factor graph and order siblings by their source span.
    children: dict[str, list[str]] = {key: [] for key in entries}
    queue = [root]
    parent = {root: ""}
    while queue:
        node = queue.pop(0)
        neighbors = sorted(
            adjacency.get(node, set()),
            key=lambda key: (
                entries[key].get("span", [-1, -1])[0],
                0 if entries[key]["kind"] == "factor" else 1,
                key,
            ),
        )
        for neighbor in neighbors:
            if neighbor in parent:
                continue
            parent[neighbor] = node
            children[node].append(neighbor)
            queue.append(neighbor)

    depth, x_index, leaves = _layout(root, children)
    labels = {key: _truncate(entries[key]["label"]) for key in depth}
    widths = {key: _width(labels[key]) for key in depth}
    pitch = max(widths.values(), default=MIN_W) + COL_GAP
    cx = {key: MARGIN_X + x_index[key] * pitch + pitch / 2 for key in depth}
    cy = {key: MARGIN_Y + level * Y_SPACING + NODE_H / 2 for key, level in depth.items()}
    svg_w = int(2 * MARGIN_X + leaves * pitch)
    svg_h = int(2 * MARGIN_Y + max(depth.values(), default=0) * Y_SPACING + NODE_H)

    cid = escape(str(record.get("claim_id", "")), quote=True)
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{svg_w}" height="{svg_h}" '
        f'viewBox="0 0 {svg_w} {svg_h}" class="factor-tree" role="img" '
        f'aria-label="Semantic factor tree for {escape(record.get("claim_text", ""), quote=True)}" '
        f'font-family="system-ui,sans-serif">'
    ]

    for node, kids in children.items():
        for child in kids:
            x1, y1 = cx[node], cy[node] + NODE_H / 2
            x2, y2 = cx[child], cy[child] - NODE_H / 2
            mid = (y1 + y2) / 2
            parts.append(
                f'<path d="M{x1:.0f},{y1:.0f} C{x1:.0f},{mid:.0f} {x2:.0f},{mid:.0f} {x2:.0f},{y2:.0f}" '
                'fill="none" stroke="#596579" stroke-width="1.7"/>'
            )

    for key in depth:
        entry = entries[key]
        w = widths[key]
        x, y = cx[key] - w / 2, cy[key] - NODE_H / 2
        annotatable = key in visible_targets
        internal = key == root or bool(entry.get("internal"))
        abstained = entry.get("role") in {"abstain", "na"}
        if key == root:
            fill, border, text, dash = "#17352d", "#59d0aa", "#dffaf1", ""
        elif internal:
            fill, border, text, dash = "#1b202a", "#667085", "#a9b2c2", ' stroke-dasharray="4 3"'
        elif abstained:  # pipeline dropped this unit as not independently checkable (na)
            fill, border, text, dash = "#2a2320", "#b08a4a", "#d8c39a", ' stroke-dasharray="5 3"'
        elif entry["kind"] == "factor":
            fill, border, text, dash = "#302443", "#c99cff", "#f0e5ff", ""
        else:
            fill, border, text, dash = "#1c2d49", "#72a7ff", "#e6efff", ""
        css = "factor-node annotatable" if (annotatable and not abstained) else "factor-node internal-node"
        cursor = " pointer" if annotatable else ""
        parts.append(
            f'<g class="{css}" data-target="{escape(key, quote=True)}" style="cursor:{cursor or "default"}">'
            f'<title>{escape(_clean(entry["label"]))} — {escape(entry["subtitle"])}</title>'
            f'<rect x="{x:.0f}" y="{y:.0f}" width="{w:.0f}" height="{NODE_H}" rx="{19 if entry["kind"] == "factor" else 8}" '
            f'fill="{fill}" stroke="{border}" stroke-width="1.6"{dash}/>'
            f'<text x="{cx[key]:.0f}" y="{cy[key]-3:.0f}" text-anchor="middle" font-size="12" '
            f'font-weight="650" fill="{text}">{escape(labels[key])}</text>'
            f'<text x="{cx[key]:.0f}" y="{cy[key]+11:.0f}" text-anchor="middle" font-size="9.5" '
            f'fill="#99a3b6">{escape(entry["subtitle"])}</text>'
            '</g>'
        )

    parts.append("</svg>")
    return "".join(parts)

