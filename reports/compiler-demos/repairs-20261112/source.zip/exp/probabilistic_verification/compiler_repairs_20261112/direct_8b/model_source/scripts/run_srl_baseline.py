#!/usr/bin/env python3
"""Trained PropBank SRL baseline (AllenNLP BERT-SRL) over AViD claims → normalized frames.

Env: envs/srl-eval (allennlp 2.10.1, CPU torch). Output:
  exp/phase3/srl_baseline/srl_frames.jsonl  — per claim: {claim_id, words, frames:[{verb, verb_span, args:[{role,start,end,text}]}]}
Resumable (skips claim_ids already written). See docs/plans/avid_phase3_srl_validation_v1.md.
"""
import json, argparse
from pathlib import Path

AVID  = Path("/exp/cxiao/scale26/avid")
TREES = AVID / "exp/phase3/trees/trees_ud_star.jsonl"
OUT   = AVID / "exp/phase3/srl_baseline/srl_frames.jsonl"
MODEL = "https://storage.googleapis.com/allennlp-public-models/structured-prediction-srl-bert.2020.12.15.tar.gz"


def bio_to_spans(tags):
    """BIO tag list → [[role, start, end(inclusive)], ...]."""
    spans, cur = [], None
    for i, t in enumerate(tags):
        if t == "O":
            if cur: spans.append(cur); cur = None
            continue
        role = t.split("-", 1)[1]
        if t.startswith("B-") or cur is None or cur[0] != role:
            if cur: spans.append(cur)
            cur = [role, i, i]
        else:
            cur[2] = i
    if cur: spans.append(cur)
    return spans


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--out", default=str(OUT))
    ap.add_argument("--cuda-device", type=int, default=-1,
                    help="GPU id (0) or -1 for CPU")
    args = ap.parse_args()

    from allennlp.predictors.predictor import Predictor
    import torch
    dev = args.cuda_device if (args.cuda_device >= 0 and torch.cuda.is_available()) else -1
    print(f"Loading SRL model (cuda_device={dev}, torch {torch.__version__}, "
          f"cuda={torch.cuda.is_available()})…", flush=True)
    predictor = Predictor.from_path(MODEL, cuda_device=dev)
    print("Model loaded.", flush=True)

    claims = [json.loads(l) for l in open(TREES)]
    if args.limit:
        claims = claims[:args.limit]

    outp = Path(args.out); outp.parent.mkdir(parents=True, exist_ok=True)
    done = set()
    if outp.exists():
        for l in open(outp):
            try: done.add(json.loads(l)["claim_id"])
            except Exception: pass
    todo = [c for c in claims if c["claim_id"] not in done]
    print(f"{len(claims)} claims | {len(todo)} to do | {len(done)} cached", flush=True)

    with open(outp, "a", encoding="utf-8") as f:
        for i in range(0, len(todo), args.batch_size):
            batch = todo[i:i + args.batch_size]
            reqs = [{"sentence": c["claim_text"]} for c in batch]
            try:
                res = predictor.predict_batch_json(reqs)
            except Exception as e:
                print(f"  batch fallback ({e})", flush=True)
                res = []
                for r in reqs:
                    try: res.append(predictor.predict_json(r))
                    except Exception: res.append({"words": [], "verbs": []})
            for c, r in zip(batch, res):
                words = r.get("words", [])
                frames = []
                for v in r.get("verbs", []):
                    spans = bio_to_spans(v.get("tags", []))
                    a_out = [{"role": role, "start": s, "end": e,
                              "text": " ".join(words[s:e + 1])} for role, s, e in spans]
                    vsp = [a for a in a_out if a["role"] == "V"]
                    frames.append({"verb": v.get("verb"),
                                   "verb_span": ([vsp[0]["start"], vsp[0]["end"]] if vsp else None),
                                   "args": [a for a in a_out if a["role"] != "V"]})
                f.write(json.dumps({"claim_id": c["claim_id"], "words": words,
                                    "frames": frames}, ensure_ascii=False) + "\n")
            f.flush()
            print(f"  {min(i + args.batch_size, len(todo))}/{len(todo)}", flush=True)
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
