#!/usr/bin/env python3
"""Prepare and merge the minimal GPU rerun for perturbation ancestor-text fixes.

``prepare`` compares the original and corrected perturbation surfaces.  It emits
only per-node rows whose actual M2 prompt text changed, plus whole-claim baseline
rows whose perturbed claim text changed because span-anchored replacement fixed
an earlier first-occurrence error.

``merge`` combines the delta GPU predictions with the previous complete outputs,
preserving corrected-surface order and validating every reused unit text.
"""

import argparse
import csv
import json
from pathlib import Path


TSV_COLS = [
    "claim_id", "unit_id", "unit_type", "node_type",
    "claim_text", "unit_text", "claim_highlighted",
    "gold_channels", "notes",
]


def read_tsv(path: str) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def write_tsv(path: str, rows: list[dict]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=TSV_COLS, delimiter="\t")
        w.writeheader()
        w.writerows(rows)


def load_jsonl(path: str, key: str) -> tuple[list[dict], dict]:
    rows = []
    mapping = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)
            rows.append(row)
            mapping[row[key]] = row
    return rows, mapping


def probe_key(row: dict) -> tuple[str, str]:
    return row["claim_id"], row["unit_id"]


def baseline_id(row: dict) -> str:
    return row["claim_id"] if row["unit_id"] == "full" else row["unit_id"]


def prepare(args) -> None:
    old_rows = read_tsv(args.old_tsv)
    new_rows = read_tsv(args.new_tsv)
    old_map = {probe_key(r): r for r in old_rows}
    new_map = {probe_key(r): r for r in new_rows}
    if old_map.keys() != new_map.keys():
        raise RuntimeError(
            "old/new perturbation probe keys differ; delta reuse is unsafe")

    changed_node_keys = [
        probe_key(r) for r in new_rows
        if old_map[probe_key(r)]["unit_text"] != r["unit_text"]
    ]
    delta_rows = [new_map[k] for k in changed_node_keys]

    _, old_trees = load_jsonl(args.old_trees, "claim_id")
    _, new_trees = load_jsonl(args.new_trees, "claim_id")
    if old_trees.keys() != new_trees.keys():
        raise RuntimeError("old/new perturbation tree IDs differ")

    changed_baseline_ids = [
        pid for pid in old_trees
        if old_trees[pid]["claim_text"] != new_trees[pid]["claim_text"]
    ]
    baseline_delta_keys = []
    for pid in changed_baseline_ids:
        tree = new_trees[pid]
        orig = tree["original_claim_id"]
        text = tree["claim_text"]
        row = {
            "claim_id": orig,
            "unit_id": pid,
            "unit_type": "whole_claim",
            "node_type": "full_claim",
            "claim_text": text,
            "unit_text": text,
            "claim_highlighted": text,
            "gold_channels": "",
            "notes": "baseline:parentfix",
        }
        delta_rows.append(row)
        baseline_delta_keys.append(probe_key(row))

    all_keys = [probe_key(r) for r in delta_rows]
    if len(all_keys) != len(set(all_keys)):
        raise RuntimeError("duplicate keys in combined delta surface")

    write_tsv(args.delta_tsv, delta_rows)
    manifest = {
        "changed_node_keys": [list(k) for k in changed_node_keys],
        "changed_baseline_ids": changed_baseline_ids,
        "baseline_delta_keys": [list(k) for k in baseline_delta_keys],
        "counts": {
            "corrected_surface_rows": len(new_rows),
            "reused_node_rows": len(new_rows) - len(changed_node_keys),
            "reprobed_node_rows": len(changed_node_keys),
            "reprobed_baseline_rows": len(changed_baseline_ids),
            "total_gpu_delta_rows": len(delta_rows),
        },
    }
    Path(args.manifest).parent.mkdir(parents=True, exist_ok=True)
    with open(args.manifest, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
        f.write("\n")

    print(json.dumps(manifest["counts"], indent=2))
    print(f"delta TSV: {args.delta_tsv}")
    print(f"manifest:  {args.manifest}")


def load_probe_rows(path: str) -> tuple[list[dict], dict]:
    rows = []
    mapping = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)
            rows.append(row)
            key = probe_key(row)
            if key in mapping:
                raise RuntimeError(f"duplicate probe output key {key} in {path}")
            mapping[key] = row
    return rows, mapping


def write_jsonl(path: str, rows: list[dict]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def merge(args) -> None:
    with open(args.manifest, encoding="utf-8") as f:
        manifest = json.load(f)
    changed_node_keys = {
        tuple(k) for k in manifest["changed_node_keys"]
    }
    changed_baseline_ids = set(manifest["changed_baseline_ids"])
    baseline_delta_keys = {
        tuple(k) for k in manifest["baseline_delta_keys"]
    }

    new_surface = read_tsv(args.new_tsv)
    _, old_perturb = load_probe_rows(args.old_perturb)
    _, delta = load_probe_rows(args.delta_output)

    merged_perturb = []
    for unit in new_surface:
        key = probe_key(unit)
        source = delta if key in changed_node_keys else old_perturb
        row = source.get(key)
        if row is None:
            raise RuntimeError(f"missing perturbation probe row {key}")
        if row.get("unit_text") != unit["unit_text"]:
            raise RuntimeError(
                f"unit text mismatch for {key}: "
                f"{row.get('unit_text')!r} != {unit['unit_text']!r}")
        merged_perturb.append(row)
    write_jsonl(args.merged_perturb, merged_perturb)

    old_baseline_rows, _ = load_probe_rows(args.old_baseline)
    merged_baseline = []
    replaced = set()
    for old_row in old_baseline_rows:
        pid = baseline_id(old_row)
        if pid not in changed_baseline_ids:
            merged_baseline.append(old_row)
            continue
        key = probe_key(old_row)
        if key not in baseline_delta_keys:
            raise RuntimeError(f"missing baseline delta manifest key {key}")
        row = delta.get(key)
        if row is None:
            raise RuntimeError(f"missing baseline delta output {key}")
        merged_baseline.append(row)
        replaced.add(pid)
    if replaced != changed_baseline_ids:
        raise RuntimeError(
            f"baseline replacements incomplete: "
            f"{sorted(changed_baseline_ids - replaced)}")
    write_jsonl(args.merged_baseline, merged_baseline)

    print(f"merged perturbation probes: {len(merged_perturb)}")
    print(f"merged baseline probes:     {len(merged_baseline)}")
    print(f"replaced baseline rows:     {len(replaced)}")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="command", required=True)

    pp = sub.add_parser("prepare")
    pp.add_argument("--old-tsv", required=True)
    pp.add_argument("--new-tsv", required=True)
    pp.add_argument("--old-trees", required=True)
    pp.add_argument("--new-trees", required=True)
    pp.add_argument("--delta-tsv", required=True)
    pp.add_argument("--manifest", required=True)
    pp.set_defaults(func=prepare)

    mp = sub.add_parser("merge")
    mp.add_argument("--manifest", required=True)
    mp.add_argument("--new-tsv", required=True)
    mp.add_argument("--old-perturb", required=True)
    mp.add_argument("--old-baseline", required=True)
    mp.add_argument("--delta-output", required=True)
    mp.add_argument("--merged-perturb", required=True)
    mp.add_argument("--merged-baseline", required=True)
    mp.set_defaults(func=merge)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
