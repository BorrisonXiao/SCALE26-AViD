#!/usr/bin/env python3
"""Run M2 pass-2 evidence-source classification for semantic probe targets.

Pass 1 determines whether a target is supported by a modality.  This script
runs only on pass-1 ``yes`` targets and applies the established Phase-2 source
taxonomy:

* visual: OCR/on-screen text vs other visual evidence
* audio: speech vs other audio evidence

The output contains every requested target so consumers can distinguish a
source prediction from a pass-1 no/cannot-tell target where source is NA.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("VLLM_USE_V1", "0")

sys.path.insert(0, str(Path(__file__).parent))
import verify_support as V
from prompts_phase2 import (
    P2_LTRS,
    PROMPT_VERSION,
    pass2_user,
)
from run_m2_probe import (
    MANIFEST,
    MEDIA_DIR,
    OMNI_MODEL,
    VL_MODEL,
    _media_cid,
    load_units,
    formulated_question,
)


ROOT = Path("/exp/cxiao/scale26/avid")
DEFAULT_TSV = ROOT / "exp/phase3/gold_v3/probe_targets.tsv"
DEFAULT_DIR = ROOT / "exp/phase3/semantic_v1/m2"
SOURCE_PROMPT_VERSION = f"{PROMPT_VERSION}-m2-source-r5-v3"  # v3: dual-route visual question (ADR-022); v2: natural-question context
SOURCE_LABELS = {
    "visual": ["ocr", "other_visual"],
    "audio": ["speech", "other_audio"],
}


def read_jsonl(path: str | Path) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    with p.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def source_cache_key(unit: dict, pass1: dict) -> str:
    text_hash = hashlib.sha1(unit["unit_text"].encode("utf-8")).hexdigest()[:16]
    pass1_version = pass1.get("prompt_version", "unknown")
    return (
        f"{unit['claim_id']}|{unit['unit_id']}|{SOURCE_PROMPT_VERSION}|"
        f"text={text_hash}|pass1={pass1_version}"
    )


def load_cache(path: str | Path) -> dict[str, dict]:
    return {
        row["_cache_key"]: row
        for row in read_jsonl(path)
        if row.get("_cache_key")
    }


def build_requests(
    units: list[dict],
    modality: str,
    pass1_index: dict[tuple[str, str], dict],
    cache: dict[str, dict],
) -> list[dict]:
    pending = []
    for unit in units:
        key = (unit["claim_id"], unit["unit_id"])
        pass1 = pass1_index.get(key)
        if not pass1 or pass1.get("pass1_verdict") != "yes":
            continue
        cache_key = source_cache_key(unit, pass1)
        if cache_key in cache:
            continue
        user_text = pass2_user(
            unit_text=unit["unit_text"],
            marked_context=unit["unit_text"],
            modality=modality,
            variant="r5",
            formulated=formulated_question(modality, unit),
        )
        pending.append({**unit, "user_text": user_text, "_cache_key": cache_key})
    return pending

def build_multimodal_prompt(
    req: dict,
    modality: str,
    tokenizer,
    system: str,
    media_dir: Path,
    manifest_path: str,
    args,
) -> dict:
    chunks = V._get_chunks_for_claim(_media_cid(req["claim_id"]), manifest_path)
    if modality == "visual":
        frames = []
        for chunk_id in chunks:
            frame_dir = media_dir / "frames" / chunk_id
            frames.extend(V._load_frames_safe(
                frame_dir,
                args.n_frames // max(1, len(chunks)),
                frame_size=args.frame_size,
            ))
        frames = frames[: args.n_frames]
        if not frames:
            import numpy as np
            from PIL import Image

            frames = [Image.fromarray(np.zeros((64, 64, 3), dtype=np.uint8))]
        prompt = V._build_vl_prompt(tokenizer, system, req["user_text"], len(frames))
        return {"prompt": prompt, "multi_modal_data": {"image": frames}}

    wav_data = None
    for chunk_id in chunks:
        wav_path = media_dir / "wav" / f"{chunk_id}.wav"
        if wav_path.exists():
            wav_data = V._load_wav_safe(wav_path)
            break
    if wav_data is None:
        import numpy as np

        wav_data = (np.zeros(16000, dtype=np.float32), 16000)
    prompt = V._build_omni_prompt(tokenizer, system, req["user_text"])
    return {"prompt": prompt, "multi_modal_data": {"audio": [wav_data]}}


def run_source_pass(
    pending: list[dict],
    modality: str,
    llm,
    tokenizer,
    sampling_params,
    cache: dict[str, dict],
    cache_path: Path,
    media_dir: Path,
    manifest_path: str,
    args,
) -> None:
    if not pending:
        return
    source_labels = SOURCE_LABELS[modality]
    system = V._get_system(modality, "pass2", explain=False)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    n_batches = (len(pending) + args.batch_size - 1) // args.batch_size
    with cache_path.open("a", encoding="utf-8") as cache_file:
        for batch_index in range(n_batches):
            batch = pending[
                batch_index * args.batch_size:(batch_index + 1) * args.batch_size
            ]
            requests = [
                build_multimodal_prompt(
                    req, modality, tokenizer, system, media_dir, manifest_path, args
                )
                for req in batch
            ]
            print(
                f"  [source] batch {batch_index + 1}/{n_batches}: {len(batch)}",
                flush=True,
            )
            outputs = llm.generate(requests, sampling_params=sampling_params)
            for req, output in zip(batch, outputs):
                try:
                    logprobs = V._verdict_logprobs(output, P2_LTRS, tokenizer)
                    distribution = V.extract_option_distribution(
                        logprobs, tokenizer, source_labels, P2_LTRS
                    )
                except Exception as exc:
                    print(
                        f"WARNING source logprobs {req['claim_id']}|{req['unit_id']}: {exc}",
                        file=sys.stderr,
                    )
                    distribution = {label: 0.5 for label in source_labels}
                entry = {
                    "_cache_key": req["_cache_key"],
                    "claim_id": req["claim_id"],
                    "unit_id": req["unit_id"],
                    "unit_text": req["unit_text"],
                    "source_pred": V.argmax_dist(distribution),
                    "source_dist": distribution,
                    "prompt_version": SOURCE_PROMPT_VERSION,
                }
                cache_file.write(json.dumps(entry, ensure_ascii=False) + "\n")
                cache[req["_cache_key"]] = entry
            cache_file.flush()


def write_output(
    units: list[dict],
    pass1_index: dict[tuple[str, str], dict],
    cache: dict[str, dict],
    output_path: Path,
) -> dict[str, int]:
    counts: dict[str, int] = {}
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as output_file:
        for unit in units:
            key = (unit["claim_id"], unit["unit_id"])
            pass1 = pass1_index.get(key)
            pass1_verdict = (pass1 or {}).get("pass1_verdict", "")
            source_entry = cache.get(source_cache_key(unit, pass1)) if pass1 else None
            if pass1_verdict == "yes" and source_entry:
                source_pred = source_entry["source_pred"]
                source_dist = source_entry["source_dist"]
                status = "predicted"
            elif pass1_verdict in {"no", "cant_tell"}:
                source_pred, source_dist = "", {}
                status = f"not_applicable_pass1_{pass1_verdict}"
            elif pass1_verdict == "yes":
                source_pred, source_dist, status = "", {}, "missing_source_prediction"
            else:
                source_pred, source_dist, status = "", {}, "missing_pass1_prediction"
            row = {
                "claim_id": unit["claim_id"],
                "unit_id": unit["unit_id"],
                "unit_text": unit["unit_text"],
                "pass1_verdict": pass1_verdict,
                "source_pred": source_pred,
                "source_dist": source_dist,
                "source_status": status,
                "prompt_version": SOURCE_PROMPT_VERSION,
            }
            output_file.write(json.dumps(row, ensure_ascii=False) + "\n")
            counts[status] = counts.get(status, 0) + 1
    return counts


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--modality", required=True, choices=["visual", "audio"])
    parser.add_argument("--tsv", default=str(DEFAULT_TSV))
    parser.add_argument("--pass1", default="")
    parser.add_argument("--manifest", default=MANIFEST)
    parser.add_argument("--media-dir", default=MEDIA_DIR)
    parser.add_argument("--output", default="")
    parser.add_argument("--cache", default="")
    parser.add_argument("--vl-model", default=VL_MODEL)
    parser.add_argument("--omni-model", default=OMNI_MODEL)
    parser.add_argument("--tp", type=int, default=0)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--logprob-n", type=int, default=20)
    parser.add_argument("--n-frames", type=int, default=250)
    parser.add_argument("--frame-size", default="672x378")
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()

    modality = args.modality
    pass1_path = Path(args.pass1 or DEFAULT_DIR / f"verify_{modality}.jsonl")
    output_path = Path(args.output or DEFAULT_DIR / f"verify_{modality}_source.jsonl")
    cache_path = Path(args.cache or DEFAULT_DIR / f"cache_{modality}_source.jsonl")
    try:
        width, height = args.frame_size.lower().split("x")
        args.frame_size = (int(width), int(height))
    except ValueError:
        args.frame_size = None

    units = load_units(args.tsv)
    if args.limit:
        units = units[:args.limit]
    pass1_index = {
        (row["claim_id"], row["unit_id"]): row for row in read_jsonl(pass1_path)
    }
    cache = load_cache(cache_path)
    pending = build_requests(units, modality, pass1_index, cache)
    yes_count = sum(
        pass1_index.get((u["claim_id"], u["unit_id"]), {}).get("pass1_verdict") == "yes"
        for u in units
    )
    print(f"modality={modality} targets={len(units)} pass1_yes={yes_count}")
    print(f"cached={yes_count - len(pending)} pending={len(pending)}")

    if pending:
        import torch
        from vllm import LLM, SamplingParams

        tensor_parallel = args.tp or torch.cuda.device_count()
        if tensor_parallel == 0:
            raise SystemExit("No GPU found")
        if modality == "visual":
            from transformers import AutoTokenizer

            model_path = args.vl_model
            tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
            llm = LLM(
                model=model_path,
                trust_remote_code=True,
                gpu_memory_utilization=0.90,
                tensor_parallel_size=tensor_parallel,
                dtype="bfloat16",
                seed=42,
                max_model_len=65536,
                limit_mm_per_prompt={"image": args.n_frames},
            )
        else:
            from transformers import AutoProcessor

            model_path = args.omni_model
            tokenizer = AutoProcessor.from_pretrained(model_path, trust_remote_code=True)
            llm = LLM(
                model=model_path,
                trust_remote_code=True,
                gpu_memory_utilization=0.90,
                tensor_parallel_size=tensor_parallel,
                dtype="bfloat16",
                seed=42,
                max_model_len=4096,
                limit_mm_per_prompt={"audio": 1},
                # The shared A100/H100 TorchInductor cache can contain an
                # incompatible compiled artifact.  Eager mode avoids that
                # machine-dependent cache without changing model semantics.
                enforce_eager=True,
            )
        sampling_params = SamplingParams(
            temperature=0.0, max_tokens=1, logprobs=args.logprob_n
        )
        run_source_pass(
            pending,
            modality,
            llm,
            tokenizer,
            sampling_params,
            cache,
            cache_path,
            Path(args.media_dir),
            args.manifest,
            args,
        )

    counts = write_output(units, pass1_index, cache, output_path)
    print(f"wrote {len(units)} rows to {output_path}")
    print("status counts:", json.dumps(counts, sort_keys=True))


if __name__ == "__main__":
    main()
