#!/usr/bin/env python3
"""Count recovered programs separately from audit decisions and semantic review."""
import hashlib,json
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_recovery_20261105'


def main():
    rows=lambda n:{r['claim_id']:r for r in map(json.loads,(RUN/n).read_text().splitlines())}
    before,after=rows('baseline.jsonl'),rows('results.jsonl');assert set(before)==set(after) and len(after)==2375
    old_candidates={c for c,r in before.items() if 'program'in r};new_candidates={c for c,r in after.items() if 'program'in r}
    assert old_candidates<=new_candidates
    changed=[dict(claim_id=c,text=r['text'],before=before[c]['status'],after=r['status'],code=r.get('code'))
             for c,r in after.items() if r.get('program_sha256')!=before[c].get('program_sha256')]
    recovered=[c for c,r in after.items() if r['status']=='compiled' and before[c]['status']!='compiled']
    new_flags=[c for c,r in after.items() if r['status']!='compiled' and before[c]['status']=='compiled']
    frozen=json.loads((RUN/'frozen_manifest.json').read_text())
    for name,digest in frozen['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    sample=json.loads((RUN/'sample_manifest.json').read_text())
    for name,digest in sample['frozen_files_sha256'].items():assert hashlib.sha256((RUN/name).read_bytes()).hexdigest()==digest,name
    reading=json.loads((RUN/'fresh_readings_freeze.json').read_text());assert hashlib.sha256((RUN/'fresh_readings.json').read_bytes()).hexdigest()==reading['sha256']
    fresh=[c['claim_id']for c in sample['cases']]
    assert all(before[c]['status']==after[c]['status']and before[c].get('program_sha256')==after[c].get('program_sha256')for c in fresh)
    human=json.loads((ROOT/'exp/probabilistic_verification/review_followup_20261104/human_analysis/analysis.json').read_text())
    faithful=[r['claim_id']for r in human['cases']if r['by_condition']['revised']['rating']=='faithful']
    assert len(faithful)==11 and all(after[c]['status']=='compiled'and after[c]['program_sha256']==before[c]['program_sha256']for c in faithful)
    summary=dict(total=2375,before_accepted=sum(r['status']=='compiled'for r in before.values()),accepted=sum(r['status']=='compiled'for r in after.values()),
        before_executable=len(old_candidates),executable=len(new_candidates),new_executable=sorted(new_candidates-old_candidates),lost_executable=0,
        recovered=len(recovered),new_review_flags=len(new_flags),changed_programs=len(changed),
        refusal_reasons=dict(Counter(r['code']for r in after.values()if r['status']!='compiled')),
        kinds=dict(Counter(r['compilation']['metadata']['kind']for r in after.values()if r['status']=='compiled')),
        previous_alert_outcomes=dict(Counter('accepted'if after[c]['status']=='compiled'else after[c]['code']for c,r in before.items()if r.get('code')=='coverage_omission')),
        unchanged_user_faithful=11,fresh_changed=0,fresh_review=json.loads((RUN/'fresh_review.json').read_text())['counts'],
        fresh_review_excluding_prior_diagnostic=json.loads((RUN/'fresh_review.json').read_text())['counts_excluding_known_diagnostic'],
        new_notes=dict(Counter(n['kind']for c,r in after.items()for n in r.get('changes',[])if n not in before[c].get('changes',[]))),
        unexpected_errors=[c for c,r in after.items()if r.get('code','')[:1].isupper()],
        interpretation='Passing compilation checks is distinct from semantic correctness. Recovered and changed outputs have no new human ratings.')
    (RUN/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
    (RUN/'changed_cases.json').write_text(json.dumps(changed,indent=2,ensure_ascii=False)+'\n')
    (RUN/'recovered_cases.json').write_text(json.dumps([dict(claim_id=c,text=after[c]['text'],before_code=before[c].get('code'))for c in recovered],indent=2,ensure_ascii=False)+'\n')
    (RUN/'new_review_flags.json').write_text(json.dumps([dict(claim_id=c,text=after[c]['text'],code=after[c]['code'],alerts=after[c].get('structural_alerts'))for c in new_flags],indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
