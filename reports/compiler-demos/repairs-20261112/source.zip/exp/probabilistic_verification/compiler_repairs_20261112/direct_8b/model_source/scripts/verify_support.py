#!/usr/bin/env python3
"""
AViD Phase 2 — Step 2: per-unit, per-channel support verification via vLLM.

Reads annotation_units.tsv (filtered to verifiable units) and the media_cache
produced by extract_media.py.  For each unit, performs a two-pass multimodal
query (visual or audio) — blind to the affordance prior.

  Pass-1 : yes/no/unknown — supported in this modality at all? (union question)
  Pass-2 : BINARY symmetric forced-choice (A/B), run only when pass-1 = yes:
             visual → A=visual_ocr  | B=visual_other
             audio  → A=audio_speech | B=audio_other
           The two subtypes are mutually exclusive (replaces the v2 two-probe
           multi-label design that over-fired "both" — see ADR-006).

Prompt-stem ablation: --prompt-variant {base,r1,r2,r4,r5,r5e} (comma-separated;
r3 is deprecated — see ADR-008). The model is loaded ONCE and every requested
variant is run in sequence; each variant writes to its own output/cache under
--output-dir/<variant>/.

r5e (ADR-010) is r5 + answer-first explanation: same formulated question, but the
model emits the verdict LETTER FIRST then a short reason (--explain-max-tokens).
Verdicts/dists still come from logprobs[0] (unchanged mechanism); the reason is
captured as pass1_explanation / pass2_explanation for human analysis only.

Output per-unit JSONL (one file per variant per modality):
  {claim_id, unit_id, unit_type, no_video,
   pass1_verdict, pass1_dist,
   <channel_a>_verdict, <channel_a>_dist,    # visual_ocr / audio_speech
   <channel_b>_verdict, <channel_b>_dist,    # visual_other / audio_other
   pass1_explanation, pass2_explanation}     # r5e only (when explain=True)

Cache: {claim_id}|{unit_id}|{pass} → entry (resumable, per variant).

Usage (vllm-omni env, GPU node):
    python scripts/verify_support.py --modality visual \\
        --prompt-variant base,r1,r2,r4,r5 \\
        --output-dir exp/phase2/prompt_ablation \\
        --formulated exp/phase2/prompt_ablation/formulated_questions.jsonl \\
        --media-dir exp/phase2/media_cache_1fps --n-frames 250 --frame-size 672x378 --tp 1
"""

import argparse
import csv
import json
import math
import os
import re
import sys
from pathlib import Path

os.environ.setdefault("VLLM_USE_V1", "0")

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_ANN_UNITS  = str(_AVID / "exp/phase1/reports/annotation_units.tsv")
DEFAULT_MANIFEST   = "/exp/cxiao/scale26/probing/exp/step1/manifests/manifest.jsonl"
DEFAULT_MEDIA_DIR  = str(_AVID / "exp/phase2/media_cache_1fps")
DEFAULT_NA_LIST    = str(_AVID / "exp/phase2/na_unit_ids.txt")
DEFAULT_HYPERGRAPH = str(_AVID / "exp/phase1/hypergraph.jsonl")
DEFAULT_OUTPUT_DIR = str(_AVID / "exp/phase2/prompt_ablation")

VL_MODEL_PATH    = "/home/hltcoe/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct"
OMNI_MODEL_PATH  = "/home/hltcoe/cxiao/calm/downloads/models/qwen3-omni/30B-A3B-Instruct"

# ---------------------------------------------------------------------------
# Prompts  (imported from prompts_phase2.py — edit prompts there)
# ---------------------------------------------------------------------------
from prompts_phase2 import (  # noqa: E402
    VERDICTS, VRD_LTRS, P2_LTRS, P2_VIS_CHANNELS, P2_AUD_CHANNELS,
    VIS_P1_SYSTEM, AUD_P1_SYSTEM, VIS_P2_SYSTEM, AUD_P2_SYSTEM,
    VIS_P1_SYSTEM_EXPLAIN, AUD_P1_SYSTEM_EXPLAIN,
    VIS_P2_SYSTEM_EXPLAIN, AUD_P2_SYSTEM_EXPLAIN,
    pass1_user, pass2_user,
    PROMPT_VERSION, PROMPT_VARIANTS, ACTIVE_VARIANTS, EXPLAIN_VARIANTS,
)
from unit_filters import filter_units, format_stats  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_marked_context(claim_text: str, unit_text: str) -> str:
    idx = claim_text.lower().find(unit_text.lower())
    if idx == -1:
        return claim_text
    return (
        claim_text[:idx]
        + "**" + claim_text[idx: idx + len(unit_text)] + "**"
        + claim_text[idx + len(unit_text):]
    )


def load_manifest(path: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            cid = f"{r['topic_id']}_{r['claim_index']}"
            out[cid] = r
    return out


def load_na_set(na_list_path: str, ann_units_path: str,
                affordance_tsv: str) -> set[str]:
    """Load or build the set of na-unit keys (claim_id|unit_id)."""
    na_path = Path(na_list_path)
    if na_path.exists():
        na_keys: set[str] = set()
        with open(na_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    na_keys.add(line)
        return na_keys

    aff_path = Path(affordance_tsv)
    if aff_path.exists():
        na_keys = set()
        with open(aff_path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f, delimiter="\t"):
                cid = (row.get("claim_id") or "").strip()
                uid = (row.get("unit_id") or "").strip()
                if cid and uid and (row.get("pred_llm") or "").strip() == "na":
                    na_keys.add(f"{cid}|{uid}")
        na_path.parent.mkdir(parents=True, exist_ok=True)
        with open(na_path, "w", encoding="utf-8") as f:
            for k in sorted(na_keys):
                f.write(k + "\n")
        print(f"    Built na list ({len(na_keys)} units) → {na_path}")
        return na_keys

    print("    WARNING: no na list found; no units will be filtered as na.",
          file=sys.stderr)
    return set()


def load_verbalized(path: str) -> dict[str, str]:
    """Load verbalized referents → {claim_id|unit_id: text} (for r3, deprecated)."""
    out: dict[str, str] = {}
    p = Path(path)
    if not path or not p.exists():
        return out
    with open(p, encoding="utf-8") as f:
        for line in f:
            o = json.loads(line)
            cid = (o.get("claim_id") or "").strip()
            uid = (o.get("unit_id") or "").strip()
            vb = (o.get("verbalized") or "").strip()
            if cid and uid and vb:
                out[f"{cid}|{uid}"] = vb
    return out


def load_formulated(path: str) -> dict[str, dict]:
    """Load formulated questions → {claim_id|unit_id: {visual_question, audio_question}}.

    Produced by formulate_questions.py (r5 pre-pass).
    """
    out: dict[str, dict] = {}
    p = Path(path)
    if not path or not p.exists():
        return out
    with open(p, encoding="utf-8") as f:
        for line in f:
            o = json.loads(line)
            cid = (o.get("claim_id") or "").strip()
            uid = (o.get("unit_id") or "").strip()
            if cid and uid:
                out[f"{cid}|{uid}"] = {
                    "visual_question": (o.get("visual_question") or "").strip(),
                    "audio_question":  (o.get("audio_question")  or "").strip(),
                }
    return out


def load_cache(cache_path: str) -> dict[str, dict]:
    """Load existing cache: {claim_id|unit_id|pass_tag -> result}."""
    cache: dict[str, dict] = {}
    p = Path(cache_path)
    if not p.exists():
        return cache
    with open(p, encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            key = obj.get("_cache_key", "")
            if key:
                cache[key] = obj
    return cache


def extract_option_distribution(
    logprobs_dict: dict,
    tokenizer,
    verdicts: list[str] = VERDICTS,
    letters: list[str] = VRD_LTRS,
) -> dict[str, float]:
    """Extract and renormalize logprob distribution over verdict letters."""
    option_logprob = {L: float("-inf") for L in letters}
    for tok_id, logprob_obj in logprobs_dict.items():
        decoded = (
            logprob_obj.decoded_token
            if hasattr(logprob_obj, "decoded_token")
            else tokenizer.decode([tok_id])
        ) or ""
        cleaned = decoded.strip().upper().rstrip(":).")
        if cleaned in option_logprob:
            lp = logprob_obj.logprob if hasattr(logprob_obj, "logprob") else logprob_obj
            cur = option_logprob[cleaned]
            option_logprob[cleaned] = (
                lp if cur == float("-inf")
                else cur + math.log1p(math.exp(lp - cur))
            )
    valid = {L: lp for L, lp in option_logprob.items() if lp != float("-inf")}
    if not valid:
        return {v: 1.0 / len(verdicts) for v in verdicts}
    max_lp = max(valid.values())
    exp_v = {L: math.exp(lp - max_lp) for L, lp in valid.items()}
    total = sum(exp_v.values())
    probs = {L: v / total for L, v in exp_v.items()}
    return {verdicts[i]: probs.get(L, 0.0) for i, L in enumerate(letters)}


def _verdict_logprobs(out, letters, tokenizer, max_scan: int = 10):
    """Per-token logprob dict at the FIRST generated position whose argmax decodes
    to an option letter, falling back to position 0.

    In explain mode (r5e) some models emit a short preamble before the verdict
    letter (e.g. Qwen3-Omni: "Assistant: B) no — ..."), which displaces the letter
    from position 0; reading logprobs[0] there gives the distribution over the
    preamble token, not the verdict. Scanning for the letter position recovers the
    calibrated verdict distribution. For the 1-token path (non-explain) and for
    models that answer letter-first (Qwen3-VL), this returns position 0 unchanged.
    """
    lps = getattr(out.outputs[0], "logprobs", None) or []
    lset = {l.upper() for l in letters}
    for d in lps[:max_scan]:
        if not d:
            continue
        tid = max(d, key=lambda t: (d[t].logprob if hasattr(d[t], "logprob") else d[t]))
        lo = d[tid]
        dec = (lo.decoded_token if hasattr(lo, "decoded_token")
               else tokenizer.decode([tid])) or ""
        if dec.strip().upper().rstrip(":).") in lset:
            return d
    return lps[0] if lps else {}


def argmax_dist(dist: dict[str, float]) -> str:
    return max(dist, key=dist.get)


def _load_wav(wav_path: Path):
    """Load WAV → (numpy array, sample_rate)."""
    import soundfile as sf
    data, sr = sf.read(str(wav_path), dtype="float32", always_2d=False)
    if data.ndim > 1:
        data = data.mean(axis=1)
    return data, sr


# ---------------------------------------------------------------------------
# Prompt builders (chat template wrappers)
# ---------------------------------------------------------------------------

def _build_vl_prompt(tokenizer, system: str, user_text: str, n_images: int) -> str:
    content = [{"type": "image"} for _ in range(n_images)]
    content.append({"type": "text", "text": user_text})
    messages = [
        {"role": "system", "content": system},
        {"role": "user",   "content": content},
    ]
    return tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True,
        enable_thinking=False,
    )


def _build_omni_prompt(processor, system: str, user_text: str) -> str:
    content = [
        {"type": "audio"},
        {"type": "text", "text": user_text},
    ]
    messages = [
        {"role": "system", "content": system},
        {"role": "user",   "content": content},
    ]
    return processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True,
        enable_thinking=False,
    )


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------

def setup_parser():
    p = argparse.ArgumentParser(
        description="AViD Phase 2 — Step 2: multimodal per-unit support verification"
    )
    p.add_argument("--modality",         required=True, choices=["visual", "audio"])
    p.add_argument("--prompt-variant",   default="base,r1,r2,r4,r5",
                   help="Comma-separated subset of active variants: base,r1,r2,r4,r5 "
                        "(r3 deprecated — ADR-008). Model loaded once, each variant "
                        "run in sequence.")
    p.add_argument("--annotation-units", default=DEFAULT_ANN_UNITS)
    p.add_argument("--manifest",         default=DEFAULT_MANIFEST)
    p.add_argument("--media-dir",        default=DEFAULT_MEDIA_DIR)
    p.add_argument("--na-list",          default=DEFAULT_NA_LIST)
    p.add_argument("--hypergraph",       default=DEFAULT_HYPERGRAPH)
    p.add_argument("--affordance-tsv",
                   default=str(_AVID / "exp/phase1/affordance_v2/affordance_annotation.tsv"))
    p.add_argument("--verbalized",       default="",
                   help="Path to verbalized_units.jsonl (r3 only, deprecated).")
    p.add_argument("--formulated",       default="",
                   help="Path to formulated_questions.jsonl (required for variant r5).")
    p.add_argument("--output-dir",       default=DEFAULT_OUTPUT_DIR,
                   help="Per-variant outputs land in <output-dir>/<variant>/.")
    p.add_argument("--vl-model",         default=VL_MODEL_PATH)
    p.add_argument("--omni-model",       default=OMNI_MODEL_PATH)
    p.add_argument("--tp",               type=int, default=0)
    p.add_argument("--batch-size",       type=int, default=16)
    p.add_argument("--logprob-n",        type=int, default=20)
    p.add_argument("--explain-max-tokens", type=int, default=48,
                   help="max_tokens for explain variants (r5e: letter + short "
                        "reason). Ignored for non-explain variants (max_tokens=1).")
    p.add_argument("--n-frames",         type=int, default=250)
    p.add_argument("--frame-size",       default="672x378")
    p.add_argument("--limit-claims",     type=int, default=0)
    return p


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    args = setup_parser().parse_args()
    modality = args.modality

    variants = [v.strip() for v in args.prompt_variant.split(",") if v.strip()]
    for v in variants:
        if v not in PROMPT_VARIANTS:
            print(f"ERROR: unknown --prompt-variant {v!r}; choose from {PROMPT_VARIANTS}",
                  file=sys.stderr)
            sys.exit(1)

    if args.frame_size:
        try:
            fw, fh = args.frame_size.lower().split("x")
            args.frame_size = (int(fw), int(fh))
        except ValueError:
            print(f"ERROR: --frame-size must be WxH, got: {args.frame_size!r}",
                  file=sys.stderr)
            sys.exit(1)
    else:
        args.frame_size = None

    out_root = Path(args.output_dir)
    media_dir = Path(args.media_dir)

    print("=" * 60)
    print(f"AViD Phase 2 — verify_support.py  (modality={modality})")
    print(f"  Prompt version:   {PROMPT_VERSION}")
    print(f"  Variants:         {variants}")
    print(f"  Annotation units: {args.annotation_units}")
    print(f"  Media dir:        {media_dir}")
    print(f"  Output root:      {out_root}")
    print(f"  Frame size:       {args.frame_size or '(native)'}")
    print("=" * 60)

    # 1. Supporting data ----------------------------------------------------
    print(f"\n[1] Loading manifest, na list, verbalized/formulated referents ...")
    na_keys    = load_na_set(args.na_list, args.annotation_units, args.affordance_tsv)
    verbalized = load_verbalized(args.verbalized)
    formulated = load_formulated(args.formulated)
    print(f"    Na units:          {len(na_keys)}")
    print(f"    Verbalized rows:   {len(verbalized)}  (r3, deprecated)")
    print(f"    Formulated rows:   {len(formulated)}  (r5)")
    if "r3" in variants and not verbalized:
        print("    WARNING: r3 requested but no verbalized referents loaded; "
              "r3 will fall back to marked_context.", file=sys.stderr)
    if "r5" in variants and not formulated:
        print("    WARNING: r5 requested but no formulated questions loaded; "
              "run formulate_questions.py first.", file=sys.stderr)

    manifest = load_manifest(args.manifest)
    claim_to_chunks: dict[str, list[str]] = {}
    for cid, rec in manifest.items():
        claim_to_chunks[cid] = [c.removesuffix(".mp4") for c in rec.get("chunks", [])]

    # 2. Load + filter annotation units (shared across variants) ------------
    print(f"\n[2] Loading + filtering annotation units ...")
    raw_units: list[dict] = []
    with open(args.annotation_units, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            cid = (row.get("claim_id") or "").strip()
            uid = (row.get("unit_id") or "").strip()
            if not cid or not uid:
                continue
            raw_units.append({
                "claim_id":          cid,
                "unit_id":           uid,
                "unit_type":         (row.get("unit_type") or "").strip(),
                "node_type":         (row.get("node_type") or "").strip(),
                "unit_text":         (row.get("unit_text") or "").strip(),
                "claim_text":        (row.get("claim_text") or "").strip(),
                "claim_highlighted": (row.get("claim_highlighted") or "").strip(),
            })

    units, drop_stats = filter_units(raw_units, args.hypergraph, na_keys)
    print(format_stats(drop_stats))

    if args.limit_claims > 0:
        seen_claims: set[str] = set()
        limited: list[dict] = []
        for u in units:
            seen_claims.add(u["claim_id"])
            if len(seen_claims) > args.limit_claims:
                break
            limited.append(u)
        units = limited
        print(f"    (limit-claims={args.limit_claims}) → {len(units)} units")

    # Precompute no_video, marked context, and per-variant referents per unit.
    for u in units:
        u["no_video"] = u["claim_id"] not in claim_to_chunks
        u["marked"] = u["claim_highlighted"] or make_marked_context(
            u["claim_text"], u["unit_text"])
        key = f"{u['claim_id']}|{u['unit_id']}"
        u["verbalized"] = verbalized.get(key, "") or u["marked"]   # r3 (deprecated)
        fq = formulated.get(key, {})
        u["formulated_visual"] = fq.get("visual_question", "")     # r5 visual stem
        u["formulated_audio"]  = fq.get("audio_question",  "")     # r5 audio stem

    # 3. Load model ONCE ----------------------------------------------------
    print(f"\n[3] Loading model ...")
    import torch
    from vllm import LLM, SamplingParams

    tp_size = args.tp if args.tp > 0 else torch.cuda.device_count()
    if tp_size == 0:
        print("ERROR: No GPUs found.", file=sys.stderr)
        sys.exit(1)

    if modality == "visual":
        from transformers import AutoTokenizer
        model_path = args.vl_model
        tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        llm = LLM(
            model=model_path, trust_remote_code=True,
            gpu_memory_utilization=0.90, tensor_parallel_size=tp_size,
            dtype="bfloat16", seed=42, max_model_len=65536,
            limit_mm_per_prompt={"image": args.n_frames},
        )
    else:
        from transformers import AutoProcessor
        model_path = args.omni_model
        tokenizer = AutoProcessor.from_pretrained(model_path, trust_remote_code=True)
        llm = LLM(
            model=model_path, trust_remote_code=True,
            gpu_memory_utilization=0.90, tensor_parallel_size=tp_size,
            dtype="bfloat16", seed=42, max_model_len=4096,
            limit_mm_per_prompt={"audio": 1},
        )
    print(f"    Model loaded: {model_path}")

    # 4. Run each variant ---------------------------------------------------
    for variant in variants:
        explain = variant in EXPLAIN_VARIANTS
        max_toks = args.explain_max_tokens if explain else 1
        sampling_params = SamplingParams(temperature=0.0, max_tokens=max_toks,
                                         logprobs=args.logprob_n)
        out_path   = out_root / variant / f"verify_{modality}.jsonl"
        # Cache dir is scoped by PROMPT_VERSION: the cache key is only
        # {claim_id}|{unit_id}|{pass}, so a prompt change at the same key would
        # otherwise be served stale. Bumping PROMPT_VERSION (e.g. v4→v5, ADR-013)
        # routes to a fresh cache dir, forcing recomputation; old caches are kept.
        cache_path = (out_root / variant / "cache" / PROMPT_VERSION
                      / f"verify_{modality}_cache.jsonl")
        print("\n" + "#" * 60)
        print(f"# VARIANT: {variant}  (explain={explain}, max_tokens={max_toks})"
              f"  →  {out_path}")
        print("#" * 60)
        run_variant(llm, tokenizer, sampling_params, units, modality, variant,
                    out_path, cache_path, media_dir, args, explain=explain)

    print("\nDone (all variants).")


def run_variant(llm, tokenizer, sampling_params, units, modality, variant,
                out_path: Path, cache_path: Path, media_dir: Path, args,
                explain: bool = False):
    """Run pass-1 + binary pass-2 for one prompt variant; write per-unit JSONL.

    explain : r5e mode — verdict letter first then a short reason. Verdicts/dists
              still come from logprobs[0]; the reason text is captured alongside.
    """
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache = load_cache(str(cache_path))
    print(f"    Cache entries: {len(cache)}")

    def _write_cache(f_cache, entry: dict, cache_key: str):
        entry["_cache_key"] = cache_key
        f_cache.write(json.dumps(entry, ensure_ascii=False) + "\n")
        cache[cache_key] = entry

    # --- PASS 1 ---
    p1_requests = []
    for u in units:
        key = f"{u['claim_id']}|{u['unit_id']}|pass1"
        if key in cache:
            continue
        formulated_q = u.get(f"formulated_{modality}", "")   # r5/r5e: modality stem
        if variant in ("r5", "r5e") and not formulated_q:
            continue   # na / unformulated unit (ADR-011): no question — skip, don't verify
        user_text = pass1_user(
            modality, variant,
            unit_text=u["unit_text"], marked_context=u["marked"],
            node_type=u["node_type"], unit_type=u["unit_type"],
            verbalized=u["verbalized"],
            formulated=formulated_q,
            explain=explain,
        )
        p1_requests.append({**u, "user_text": user_text, "pass_tag": "pass1"})

    n_cached = len(units) - len(p1_requests)
    print(f"    Pass-1 requests: {len(p1_requests)} (cached: {n_cached})")
    with open(cache_path, "a", encoding="utf-8") as cf:
        _run_pass(llm, tokenizer, sampling_params, p1_requests, modality, "pass1",
                  media_dir, args, cache, cf, _write_cache,
                  letters=VRD_LTRS, verdicts=VERDICTS, explain=explain)

    # --- PASS 2 (binary, only for pass-1 = yes) ---
    p2_requests = []
    for u in units:
        p1 = cache.get(f"{u['claim_id']}|{u['unit_id']}|pass1")
        if p1 is None or p1.get("verdict") != "yes":
            continue
        if f"{u['claim_id']}|{u['unit_id']}|pass2" in cache:
            continue
        user_text = pass2_user(
            modality, variant,
            unit_text=u["unit_text"], marked_context=u["marked"],
            verbalized=u["verbalized"],
            explain=explain,
        )
        p2_requests.append({**u, "user_text": user_text, "pass_tag": "pass2"})

    print(f"    Pass-2 requests: {len(p2_requests)}")
    with open(cache_path, "a", encoding="utf-8") as cf:
        _run_pass(llm, tokenizer, sampling_params, p2_requests, modality, "pass2",
                  media_dir, args, cache, cf, _write_cache,
                  letters=P2_LTRS, verdicts=P2_LTRS, explain=explain)

    # --- WRITE OUTPUT ---
    channels = P2_VIS_CHANNELS if modality == "visual" else P2_AUD_CHANNELS
    ch_a, ch_b = channels  # A=ocr/speech, B=other
    n_written = 0
    with open(out_path, "w", encoding="utf-8") as out_f:
        for u in units:
            cid, uid = u["claim_id"], u["unit_id"]
            p1 = cache.get(f"{cid}|{uid}|pass1")
            if p1 is None:
                continue
            p1v = p1.get("verdict", "unknown")
            p2 = cache.get(f"{cid}|{uid}|pass2")

            if p1v == "no":
                a_verdict, a_dist = "no", {"yes": 0.0, "no": 1.0, "unknown": 0.0}
                b_verdict, b_dist = "no", {"yes": 0.0, "no": 1.0, "unknown": 0.0}
            elif p1v == "yes" and p2 is not None:
                ab = p2.get("dist", {"A": 0.5, "B": 0.5})
                pa, pb = ab.get("A", 0.0), ab.get("B", 0.0)
                if pa >= pb:
                    a_verdict, b_verdict = "yes", "no"
                else:
                    a_verdict, b_verdict = "no", "yes"
                a_dist = {"yes": pa, "no": pb, "unknown": 0.0}
                b_dist = {"yes": pb, "no": pa, "unknown": 0.0}
            else:  # yes-but-no-pass2 (cache inconsistency; shouldn't happen)
                a_verdict, a_dist = "unknown", {v: 1.0/3 for v in VERDICTS}
                b_verdict, b_dist = "unknown", {v: 1.0/3 for v in VERDICTS}

            row = {
                "claim_id":      cid,
                "unit_id":       uid,
                "unit_type":     u["unit_type"],
                "no_video":      p1.get("no_video", u["no_video"]),
                "pass1_verdict": p1v,
                "pass1_dist":    p1.get("dist", {v: 1.0/3 for v in VERDICTS}),
                f"{ch_a}_verdict": a_verdict, f"{ch_a}_dist": a_dist,
                f"{ch_b}_verdict": b_verdict, f"{ch_b}_dist": b_dist,
            }
            if p1.get("explanation"):
                row["pass1_explanation"] = p1["explanation"]
            if p2 is not None and p2.get("explanation"):
                row["pass2_explanation"] = p2["explanation"]
            out_f.write(json.dumps(row, ensure_ascii=False) + "\n")
            n_written += 1
    print(f"    Rows written: {n_written} → {out_path}")


# ---------------------------------------------------------------------------
# Batched inference runner
# ---------------------------------------------------------------------------

def _run_pass(llm, tokenizer, sampling_params, requests, modality, pass_tag,
              media_dir: Path, args, cache, cache_f, write_cache_fn,
              letters=VRD_LTRS, verdicts=VERDICTS, explain: bool = False):
    """Run one pass of inference over requests; write results to cache."""
    if not requests:
        return

    batch_size = args.batch_size
    n_batches  = (len(requests) + batch_size - 1) // batch_size
    frames_root = media_dir / "frames"
    wav_root    = media_dir / "wav"

    for b_idx in range(n_batches):
        batch = requests[b_idx * batch_size: (b_idx + 1) * batch_size]
        prompts_mm = []

        for req in batch:
            cid = req["claim_id"]
            no_video = req.get("no_video", False)
            system = _get_system(modality, pass_tag, explain)

            if modality == "visual":
                chunks = _get_chunks_for_claim(cid, args.manifest)
                frames = []
                if not no_video and chunks:
                    for chunk_id in chunks:
                        fd = frames_root / chunk_id
                        frames.extend(_load_frames_safe(
                            fd, args.n_frames // max(1, len(chunks)),
                            frame_size=args.frame_size))
                    frames = frames[: args.n_frames]
                if not frames:
                    from PIL import Image
                    import numpy as np
                    frames = [Image.fromarray(np.zeros((64, 64, 3), dtype=np.uint8))]
                prompt = _build_vl_prompt(tokenizer, system, req["user_text"], len(frames))
                prompts_mm.append({"prompt": prompt,
                                   "multi_modal_data": {"image": frames}})
            else:
                chunks = _get_chunks_for_claim(cid, args.manifest)
                wav_data = None
                if not no_video and chunks:
                    for chunk_id in chunks:
                        wp = wav_root / f"{chunk_id}.wav"
                        if wp.exists():
                            wav_data = _load_wav_safe(wp)
                            break
                if wav_data is None:
                    import numpy as np
                    wav_data = (np.zeros(16000, dtype=np.float32), 16000)
                prompt = _build_omni_prompt(tokenizer, system, req["user_text"])
                prompts_mm.append({"prompt": prompt,
                                   "multi_modal_data": {"audio": [wav_data]}})

        print(f"  [{pass_tag}] Batch {b_idx + 1}/{n_batches}: {len(batch)} ...",
              flush=True)
        outputs = llm.generate(prompts_mm, sampling_params=sampling_params)

        for req, out in zip(batch, outputs):
            try:
                lp_dict = _verdict_logprobs(out, letters, tokenizer)
                dist = extract_option_distribution(lp_dict, tokenizer, verdicts, letters)
            except Exception as e:
                print(f"  WARNING logprob: {req['claim_id']}|{req['unit_id']}: {e}",
                      file=sys.stderr)
                dist = {v: 1.0 / len(verdicts) for v in verdicts}
            entry = {
                "claim_id":  req["claim_id"],
                "unit_id":   req["unit_id"],
                "pass_tag":  pass_tag,
                "verdict":   argmax_dist(dist),
                "dist":      dist,
                "no_video":  req.get("no_video", False),
            }
            if explain:
                try:
                    raw = out.outputs[0].text or ""
                    expl = _clean_reason(raw)
                    # Fall back when model omits the reason (outputs only the letter
                    # or nothing): write a minimal placeholder so pass1_explanation
                    # is always present in the JSONL and never silently absent.
                    entry["explanation"] = expl or f"{entry['verdict']} — (no reason)"
                except Exception:
                    entry["explanation"] = f"{entry['verdict']} — (no reason)"
            write_cache_fn(cache_f, entry, f"{req['claim_id']}|{req['unit_id']}|{pass_tag}")


# Module-level manifest cache (avoid re-loading per batch)
_MANIFEST_CACHE: dict[str, dict] | None = None
_MANIFEST_PATH_LOADED = ""


def _get_chunks_for_claim(cid: str, manifest_path: str) -> list[str]:
    global _MANIFEST_CACHE, _MANIFEST_PATH_LOADED
    if _MANIFEST_CACHE is None or _MANIFEST_PATH_LOADED != manifest_path:
        _MANIFEST_CACHE = load_manifest(manifest_path)
        _MANIFEST_PATH_LOADED = manifest_path
    rec = _MANIFEST_CACHE.get(cid)
    if rec is None:
        return []
    return [c.removesuffix(".mp4") for c in rec.get("chunks", [])]


def _load_frames_safe(frames_dir: Path, n_max: int, frame_size=None):
    try:
        return _load_frames(frames_dir, n_max, frame_size=frame_size)
    except Exception as e:
        print(f"  WARNING frames {frames_dir}: {e}", file=sys.stderr)
        return []


def _load_frames(frames_dir: Path, n_max: int = 12, frame_size=None):
    """Load up to n_max JPEG frames as PIL Images, optionally thumbnail-resized."""
    from PIL import Image
    jpgs = sorted(frames_dir.glob("frame_*.jpg"))[:n_max]
    imgs = [Image.open(p).convert("RGB") for p in jpgs]
    if frame_size is not None:
        for img in imgs:
            img.thumbnail(frame_size, Image.LANCZOS)
    return imgs


def _load_wav_safe(wav_path: Path):
    try:
        return _load_wav(wav_path)
    except Exception as e:
        import numpy as np
        print(f"  WARNING wav {wav_path}: {e}", file=sys.stderr)
        return (np.zeros(16000, dtype=np.float32), 16000)


def _get_system(modality: str, pass_tag: str, explain: bool = False) -> str:
    if modality == "visual":
        if explain:
            return VIS_P1_SYSTEM_EXPLAIN if pass_tag == "pass1" else VIS_P2_SYSTEM_EXPLAIN
        return VIS_P1_SYSTEM if pass_tag == "pass1" else VIS_P2_SYSTEM
    if explain:
        return AUD_P1_SYSTEM_EXPLAIN if pass_tag == "pass1" else AUD_P2_SYSTEM_EXPLAIN
    return AUD_P1_SYSTEM if pass_tag == "pass1" else AUD_P2_SYSTEM


# Strip a leading role echo (some models emit "Assistant:") then a leading verdict
# letter, e.g. "Assistant: B) no — ..." → "no — ..."; "A) yes — ..." → "yes — ...".
_LEADING_ROLE_RE = re.compile(r'^\s*(assistant|system|user)\s*[:>\-—]*\s*', re.I)
_LEADING_LETTER_RE = re.compile(r'^\s*[A-Da-d][)\:\.\-—]*\s+')


def _clean_reason(text: str) -> str:
    """Tidy a generated explanation into one TSV-safe line (role echo + verdict
    letter dropped)."""
    t = (text or "").strip().replace("\n", " ").replace("\t", " ")
    t = _LEADING_ROLE_RE.sub("", t, count=1)
    t = _LEADING_LETTER_RE.sub("", t, count=1)
    return t.strip()


if __name__ == "__main__":
    main()
