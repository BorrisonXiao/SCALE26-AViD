#!/usr/bin/env python3
"""Local-LLM check-worthiness gate (Qwen3-30B via vLLM) — comparison to the codex gate.

For each still-probeable ENTITY unit in the gold claims, ask whether it is an
independently checkable audio-visual referent. Same prompt and same unit set as the
codex (gpt-5.6-sol) gate, so the two are directly comparable. Local + frozen →
reproducible and privacy-preserving (no external API), matching ADR-016.

Output: exp/phase3/semantic_v1/checkworthiness_qwen.jsonl
        {claim_id, target_id, unit_text, checkable: yes|no, reason, raw}
"""
from __future__ import annotations
import argparse, csv, json, re
from pathlib import Path

ROOT = Path("/exp/cxiao/scale26/avid")
DEFAULT_TREES = ROOT / "exp/phase3/semantic_v1/semantic_factor_trees.jsonl"
DEFAULT_CLAIMS = ROOT / "exp/phase3/gold_v2/claims.tsv"
DEFAULT_OUTPUT = ROOT / "exp/phase3/semantic_v1/checkworthiness_qwen.jsonl"
DEFAULT_MODEL = "/home/hltcoe/cxiao/calm/downloads/models/qwen3/30B-A3B-Instruct-2507"

SYSTEM = (
    "You decide whether a PHRASE from a claim is an INDEPENDENTLY CHECKABLE audio-visual "
    "unit: something a viewer could point to in a video, read as on-screen text, or hear in "
    "audio, ON ITS OWN. NOT checkable: abstract/relational nouns (position, conditions, role, "
    "way, type, amount(s), sight, recovery operation, stage-as-process-step, order-as-directive, "
    "state-as-metaphor), bare time nouns (day, moment), pronouns, manner/means adverbials. "
    "Checkable: concrete objects, people, places, vehicles, animals, named on-screen sources, "
    "physical locations, named events. Judge in the claim's context. "
    'Output ONLY JSON: {"checkable":"yes|no","reason":"<=7 words"}'
)

def user_prompt(claim: str, phrase: str) -> str:
    return f'Claim: "{claim}"\nPhrase: "{phrase}"\nIs the phrase independently checkable on its own?'

def parse(raw: str) -> str:
    try:
        s, e = raw.find("{"), raw.rfind("}")
        if s >= 0 and e > s:
            v = json.loads(raw[s:e + 1]).get("checkable", "")
            if isinstance(v, str) and v.strip().lower() in {"yes", "no"}:
                return v.strip().lower()
    except (json.JSONDecodeError, AttributeError):
        pass
    m = re.search(r'"?checkable"?\s*[:=]\s*"?(yes|no)"?', raw, re.I)
    if m:
        return m.group(1).lower()
    return "yes"  # safe default: keep the unit probeable (matches codex fallback)

def collect(trees_path: Path, claims_path: Path):
    gold = {r["claim_id"] for r in csv.DictReader(open(claims_path), delimiter="\t")}
    jobs = []
    for line in open(trees_path, encoding="utf-8"):
        r = json.loads(line)
        if r["claim_id"] not in gold:
            continue
        for v in r["variables"]:
            if v.get("semantic_type") == "entity" and v.get("evidence_role") == "unary_probe":
                jobs.append({"claim_id": r["claim_id"], "target_id": v["id"],
                             "claim_text": r["claim_text"], "unit_text": v["unit_text"]})
    return jobs

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--trees", default=str(DEFAULT_TREES))
    ap.add_argument("--claims", default=str(DEFAULT_CLAIMS))
    ap.add_argument("--output", default=str(DEFAULT_OUTPUT))
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--tp", type=int, default=0)
    ap.add_argument("--max-tokens", type=int, default=48)
    args = ap.parse_args()

    jobs = collect(Path(args.trees), Path(args.claims))
    print(f"check-worthiness (Qwen): {len(jobs)} entity units", flush=True)

    import torch
    from vllm import LLM, SamplingParams
    from transformers import AutoTokenizer
    tp = args.tp if args.tp > 0 else torch.cuda.device_count()
    tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    llm = LLM(model=args.model, trust_remote_code=True, gpu_memory_utilization=0.90,
              tensor_parallel_size=tp, dtype="bfloat16", seed=42, max_model_len=2048,
              disable_log_stats=True, enforce_eager=True)  # eager: avoid torch.compile FXGraph cache fail
    sp = SamplingParams(temperature=0.0, max_tokens=args.max_tokens)

    def prompt(j):
        msgs = [{"role": "system", "content": SYSTEM},
                {"role": "user", "content": user_prompt(j["claim_text"], j["unit_text"])}]
        return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True,
                                       enable_thinking=False)

    outs = llm.generate([prompt(j) for j in jobs], sampling_params=sp)
    n_no = 0
    with open(args.output, "w", encoding="utf-8") as f:
        for j, o in zip(jobs, outs):
            raw = o.outputs[0].text.strip() if o.outputs else ""
            ck = parse(raw)
            n_no += (ck == "no")
            f.write(json.dumps({**{k: j[k] for k in ("claim_id", "target_id", "unit_text")},
                                "checkable": ck, "raw": raw[:200]}, ensure_ascii=False) + "\n")
    print(f"done: {len(jobs)} judged | {n_no} abstained (no) | {len(jobs) - n_no} kept -> {args.output}",
          flush=True)

if __name__ == "__main__":
    main()
