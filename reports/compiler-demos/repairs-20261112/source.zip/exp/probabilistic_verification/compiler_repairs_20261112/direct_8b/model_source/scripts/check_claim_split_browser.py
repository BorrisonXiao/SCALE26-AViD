"""Check all split examples, provenance, context graphs and existing report views."""
import functools
import http.server
import json
import threading
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/claim_split_20261112'


def main():
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *args):
            pass

    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0),
        functools.partial(Handler, directory=str(ROOT / 'site')))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f'http://127.0.0.1:{server.server_port}'
    cases = json.loads((RUN / 'cases.json').read_text())
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto(base + '/reports/compiler-demos.html#sentence-splitting', wait_until='networkidle')
        page.wait_for_selector('#split-case option', state='attached')
        assert page.locator('#split-condition').input_value() == 'supervised'
        assert page.locator('[role="tab"]').count() == 8
        for tab in page.locator('[data-tab]').all():
            tab.click()
            assert page.locator('#' + tab.get_attribute('data-tab')).is_visible()
        page.click('[data-tab="sentence-splitting"]')
        checked = 0
        for condition, count in [('supervised', 8), ('qwen', 31)]:
            page.select_option('#split-condition', condition)
            assert page.locator('#split-case option').count() == count
            for row in [r for r in cases if r['condition'] == condition]:
                page.select_option('#split-case', row['claim_id'])
                assert page.locator('#split-original').text_content() == row['original_text'], row['claim_id']
                assert page.locator('#split-review').text_content() == row['review']['reason'], row['claim_id']
                for clause in row['proposal']['clauses']:
                    assert clause['text'] in page.locator('#split-clauses').text_content()
                if condition == 'qwen':
                    for selector, value in [('#split-system', row['request']['messages'][0]['content']),
                                            ('#split-user', row['request']['messages'][1]['content']),
                                            ('#split-response', row['request']['raw'])]:
                        assert page.locator(selector).text_content() == value
                        assert page.locator(selector).evaluate('(e)=>e.closest("details")===null')
                else:
                    assert page.locator('#split-request').is_hidden()
                    assert 'not a model-generated success' in page.locator('#split-provenance').inner_text()
                for side in ['flat', 'linked']:
                    if row['outputs'][side]['status'] == 'compiled':
                        assert row['outputs'][side]['view']['predicates'], row['claim_id']
                checked += 1
        for condition in ['supervised', 'qwen']:
            page.goto(base + '/reports/compiler-demos.html?split=TFgw4IaR9R8s_1587&split_condition=' + condition + '#split-example', wait_until='networkidle')
            assert page.locator('#split-condition').input_value() == condition
            assert page.locator('#split-case').input_value() == 'TFgw4IaR9R8s_1587'
            assert page.locator('#sentence-splitting').is_visible()
            page.evaluate('document.documentElement.style.scrollBehavior="auto";document.querySelector("#split-example").scrollIntoView({behavior:"instant",block:"start"})')
            page.screenshot(path=str(RUN / (condition + '_example_desktop.png')))
            if condition == 'supervised':
                assert 'An image depicts Trump.' in page.locator('#split-clauses').inner_text()
                assert page.locator('#split-graphs .cv-figure').count() == 2
                page.locator('#split-graphs').scroll_into_view_if_needed()
                page.screenshot(path=str(RUN / 'context_graphs_desktop.png'))
            else:
                page.locator('#split-request').scroll_into_view_if_needed()
                page.screenshot(path=str(RUN / 'exact_prompt_desktop.png'))
        page.set_viewport_size({'width': 390, 'height': 844})
        page.emulate_media(color_scheme='dark')
        page.wait_for_timeout(200)
        overflow = page.evaluate('Array.from(document.querySelectorAll("body *")).filter(e=>e.getBoundingClientRect().right>innerWidth+1 && e.getBoundingClientRect().width>0).map(e=>({tag:e.tagName,id:e.id,cls:e.className,width:e.getBoundingClientRect().width,right:e.getBoundingClientRect().right})).slice(0,30)')
        dimensions = page.evaluate('({content:document.documentElement.scrollWidth,viewport:innerWidth})')
        assert dimensions['content'] <= dimensions['viewport'] + 1, (dimensions, overflow)
        page.evaluate('document.querySelector("#split-request").scrollIntoView({behavior:"instant",block:"start"})')
        page.screenshot(path=str(RUN / 'prompt_mobile_dark.png'))
        page.goto(base + '/reports/compiler-demos.html#daily-progress', wait_until='networkidle')
        page.locator('#day-2026-11-12 a[href="#sentence-splitting"]').click()
        page.wait_for_selector('#sentence-splitting', state='visible')
        assert page.locator('#sentence-splitting').is_visible()
        page.click('[data-tab="walkthroughs"]')
        assert page.locator('#demo-select option').count() == 41
        page.click('[data-tab="outputs"]')
        assert '2375' in page.locator('#all-count').inner_text()
        page.goto(base + '/reports/compiler-demos.html?rewrite=TFgw4IaR9R8s_1587&rewrite_prompt=revised#rewrite-case-inspector', wait_until='networkidle')
        assert 'which he signed' in page.locator('#rewrite-raw-response').inner_text()
        for name in ['summary.json', 'cases.json', 'raw.jsonl', 'model_config.json', 'README.md', 'source.zip']:
            response = page.request.get(base + '/reports/compiler-demos/split-20261112/' + name)
            assert response.ok, name
        assert not errors, errors
        proof = dict(cases_checked=checked, exact_requests_checked=31, tabs=8,
                     manual_provenance=True, context_graphs=True, deep_links=True,
                     old_demos=41, original_claims=2375, mobile_overflow=False, page_errors=errors)
        (RUN / 'browser_checks.json').write_text(json.dumps(proof, indent=2) + '\n')
        print(proof)
        browser.close()
    server.shutdown()


if __name__ == '__main__':
    main()
