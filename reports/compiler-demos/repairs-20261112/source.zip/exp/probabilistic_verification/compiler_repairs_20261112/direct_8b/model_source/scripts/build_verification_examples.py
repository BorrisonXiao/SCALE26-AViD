#!/usr/bin/env python3
"""Render selected, saved model outputs for the paper-design page."""
from __future__ import annotations

import base64
from html import escape
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PILOT = ROOT / "exp/probabilistic_verification/pilot_20261015"
FRAME_ROOT = ROOT / "exp/phase2/media_cache_1fps/frames"


def index(path: Path, key: str) -> dict:
    return {row[key]: row for row in map(json.loads, path.read_text().splitlines())}


def sample_anchor(config: str, sample_id: str) -> str:
    return "sample-" + config.replace("/", "-") + "-" + sample_id.replace(":", "-")


def sample(config: str, sample_id: str) -> dict:
    folder = PILOT / config
    claims = index(folder / "claims.jsonl", "sample_id")
    claim = claims[sample_id]
    return {
        "claim": claim,
        "seed": claims[claim["seed_id"] + ":seed"],
        "review": index(folder / "assistant_reviews.jsonl", "sample_id")[sample_id],
        "prediction": index(folder / "whole_claim_raw.jsonl", "request_id")[sample_id],
        "seed_prediction": index(folder / "whole_claim_raw.jsonl", "request_id")[claim["seed_id"] + ":seed"],
        "url": "../reports/verification-pilot.html#" + sample_anchor(config, sample_id),
    }


def figure(number: int, frames: list[tuple[str, str]], caption: str) -> str:
    images = []
    for path, alt in frames:
        uri = "data:image/jpeg;base64," + base64.b64encode((FRAME_ROOT / path).read_bytes()).decode()
        images.append('<img loading="lazy" src="' + uri + '" alt="' + escape(alt, quote=True) + '">')
    return (
        '<figure><div class="generated-evidence' + (' two-frames' if len(frames) == 2 else '') + '">'
        + "".join(images) + '</div><figcaption>Figure ' + str(number) + '. '
        + escape(caption) + '</figcaption></figure>'
    )


def claims_text(item: dict) -> str:
    return (
        '<p class="example-label">Seed claim</p><blockquote>'
        + escape(item["seed"]["claim_text"]) + '</blockquote>'
        '<p class="example-label">Generated claim</p><blockquote>'
        + escape(item["claim"]["claim_text"]) + '</blockquote>'
    )


def source_link(item: dict, config: str) -> str:
    return (
        '<p class="reference-note">Saved run: <code>' + escape(config) + '</code>; sample '
        '<code>' + escape(item["claim"]["sample_id"]) + '</code>. '
        '<a href="' + escape(item["url"], quote=True) + '">Open the complete record and review</a>.</p>'
    )


def generated_examples() -> str:
    clothing = sample("guided/v3", "TLO3smKI67PM_586:variant:0")
    vehicles = sample("guided/v3", "TInVWzp25aIM_92:variant:0")
    paraphrase = sample("guided/v3", "TLO3smKI67PM_586:variant:1")
    reordering = sample("smoke/v1", "TLO3smKI67PM_586:variant:0")
    groups = sample("smoke/v3", "Tsuk2uoYj-kc_611:variant:2")
    body = [
        '<p>These are actual generated sentences from the local-model pilot. The first two use specified '
        'attribute swaps: the model received the intended assignments and wrote them as fluent text. '
        'The remaining examples show a positive control and failures from free-form generation. '
        'Labels below are assistant reviews of visible evidence, not independent human gold. '
        'The examples concern depiction in sampled frames; they do not certify events in the world.</p>',
        '<p>Figures 3–5 show selected source frames used during inspection. The model received eight '
        'sampled frames per clip, resized to at most 384 pixels on the long side. These larger images '
        'are provided for inspection. Frame numbers are cache identifiers, not certified timestamps.</p>',
        '<div class="generated-examples">',
    ]
    for key, title, item, number, images, caption, explanation in [
        (
            "generated-clothing", "Accepted negative: exchange the outer-shirt colors", clothing, 3,
            [("eHObCbLbueu90y1g_0000/frame_010.jpg", "Short-haired woman in a white outer shirt with a red hood, beside a man in red")],
            "Clothing evidence from frame_010.jpg. The woman's outer shirt is white, her hood is red, and the nearby man's shirt is red.",
            "The generated claim gives the woman a red outer shirt and the man a white shirt. "
            "The red hood stays fixed. This changes the color assignments while retaining both people "
            "and both observed colors. The assistant review is refuted.",
        ),
        (
            "generated-vehicles", "Accepted negative: exchange the vehicle colors", vehicles, 4,
            [("zlD_zgNiYJkRV1PS_0000/frame_000.jpg", "A gray aircraft"),
             ("zlD_zgNiYJkRV1PS_0000/frame_005.jpg", "A yellow school bus in another shot")],
            "Vehicle evidence from frame_000.jpg and frame_005.jpg. The gray aircraft and yellow bus appear in different shots.",
            "The generated claim attaches yellow to the aircraft and gray to the buses. "
            "It preserves the different-shot context. The assistant review is refuted: the depicted "
            "colors contradict both edited assignments.",
        ),
    ]:
        # Text is taken from saved records; explanatory prose is kept separate.
        body.append('<article id="' + key + '" class="generated-case"><h3>' + title + '</h3>')
        body.append(figure(number, images, caption))
        body.append(claims_text(item))
        body.append('<p>' + escape(explanation) + '</p>')
        original = item["seed_prediction"]["distribution"]["supported"]
        edited = item["prediction"]["distribution"]["supported"]
        body.append('<p><strong>Whole-claim verifier:</strong> seed support ' + f'{original:.5f}'
                    + '; edited-claim support ' + f'{edited:.6f}' + '. The edited verdict is <strong>'
                    + escape(item["prediction"]["prediction"]) + '</strong>. These are uncalibrated '
                    'model scores. Low support does not by itself establish refutation.</p>')
        body.append(source_link(item, "guided/v3") + '</article>')
    body.extend([
        '<article id="generated-paraphrase" class="generated-case"><h3>Accepted positive: preserve the assignments</h3>',
        claims_text(paraphrase),
        '<p>This keeps the woman–white shirt, woman–red hood, and man–red shirt assignments. '
        'It is a positive control using the same evidence as Figure 3. The assistant review and '
        'whole-claim verifier both return supported.</p>',
        source_link(paraphrase, "guided/v3"), '</article>',
        '<article id="generated-reordering" class="generated-case"><h3>Rejected edit: clause order changed</h3>',
        claims_text(reordering),
        '<p>The generator tagged this as <code>role_swap</code>, but the woman still wears white '
        'and the man still wears red. The sentence remains supported. It is rejected as a binding '
        'edit because no assignment changed; compare Figure 3.</p>',
        source_link(reordering, "smoke/v1"), '</article>',
        '<article id="generated-groups" class="generated-case generated-wide"><h3>Rejected negative: another assignment still supports it</h3>',
        figure(5, [("cC0HR-woTQtlhHa0_0000/frame_006.jpg", "People wearing white robes and people wearing reflective vests")],
               "People in white robes and people in reflective vests are visible. The descriptions do not uniquely identify two disjoint groups."),
        claims_text(groups),
        '<p>The generator proposed refuted. The assistant review is supported: men in white robes '
        'and other people in reflective vests are also present. Changing an intended matching does '
        'not make the sentence false when another matching supports it. This is why participant '
        'identity and alternative evidence assignments matter.</p>',
        source_link(groups, "smoke/v3"), '</article></div>',
        '<p><a href="../reports/verification-pilot.html">Browse all generated samples, rejected edits, '
        'unknown cases, corrected seeds, model reviews, and evidence images.</a></p>',
    ])
    return "\n".join(body)
