"""Hash-bound compiler-author judgments, corpus accounting and failure ledger."""
import hashlib,json
from collections import Counter
from pathlib import Path
from build_reviewed_compilation_report import slim
from run_compiler_readiness import ROOT,RUN,OLD,read,write
from analyze_semantic_components import form
# Each changed complete program is inspected against its unchanged source claim.
JUDGMENTS={
'TInVWzp25aIM_54':(True,'The possible/future reading, place, power, back modifier and following-weekend restriction remain linked. Relative time still requires the caller context.'),
'TInVWzp25aIM_61':(False,'The duplicate auxiliary is fixed, but their remains an independent pronoun rather than the people group that owns the homes.'),
'TInVWzp25aIM_63':(True,'Nearly completely is retained as the extent argument of the same submerge relation, with the home and water. It is not deleted or replaced by a fully-submerged claim.'),
'TInVWzp25aIM_75':(True,'The boats remain the submerged group and the heavy storm waters remain their complement. The auxiliary no longer creates another clause.'),
'TInVWzp25aIM_77':(True,'Both damage and flooding refer to the same homes and retain the storm-time condition. This replaces an already accepted split, not a new corpus recovery.'),
'TzF9M4kZ3Pys_234':(True,'The in modifier is bound to the close event with the massive dust storm as participant. Interpreting the phrasal verb still requires the lexical evidence function; no separate location object is invented.'),
'TzF9M4kZ3Pys_239':(True,'The people group is covered in the same dust. Only the redundant auxiliary frame is removed.'),
'TzF9M4kZ3Pys_271':(True,'On remains attached to the come event, the street lights remain its participant, and darkness from the dust storm remains the cause. Due and due to are redundant retained markers.'),
'Tg0UxWYuPeJ0_337':(True,'Robot 3 and Robot 2 retain distinct identifiers; back modifies the kick, at links Robot 2, and the same Robot 3 stumbles. But has conjunction truth conditions here.'),
'Tg0UxWYuPeJ0_360':(False,'Upright is recovered, but itself is still a separate referent rather than the robot. Do not certify the full binding.'),
'Tg0UxWYuPeJ0_444':(True,'The fragment remains a game description with over attached to that game. It is not treated as a new subject or discarded word. This is a description, not an invented finite event.'),
'Tsuk2uoYj-kc_609':(False,'The passive is fixed, but Most is still a generic modifier rather than a majority condition over the people group.'),
'Tsuk2uoYj-kc_631':(True,'The fragment retains some people, their walking description, the road and below as a road modifier. No extra event or explicit reference object is invented.'),
'TQKCK6-tRaoE_660':(True,'The original now compiles directly and retains while as a temporal clause linking sailing and fireworks going off in the background. The earlier split lost while.'),
'T1JQ-aG78Zuc_800':(False,'Down is recovered, but it is not linked to the tram. The entire claim still lacks the intended shared participant.'),
'T1JQ-aG78Zuc_801':(False,'Away is recovered, but him is not linked to the man and as remains a generic complement rather than an explicit temporal relation.'),
'TjHepwuhkYFA_1051':(False,'Beneath is attached, but producing is represented as nonprojected complement content rather than the asserted consequence; the desired spatial reference is also implicit.'),
'TjHepwuhkYFA_1062':(False,'Slightly attaches to the be event rather than explicitly qualifying the northeast direction/distance relationship.'),
'T2G_ACMxR_I4_1225':(False,'Fully is recovered, but this lacks its antecedent and the because/coordination scope is still incomplete.'),
'T2G_ACMxR_I4_1402':(False,'Up is recovered, but Hundreds remains an ordinary noun linked to people, not an explicit cardinality condition.'),
'TgPh_fzHTCm4_1500':(False,'North is recovered, but itself remains unlinked and two then literals do not encode the event order.'),
'TgR_u37mCoQ4_1945':(False,'Very is recovered as a generic modifier, but the full expanded proper name Very Large Air Tankers is not preserved as a single name.'),
'TgR_u37mCoQ4_2002':(False,'Speech scope is retained, but the SRL roles of passive/stative obsessed remain uncertain. Removing an auxiliary alone does not certify that predicate sense or role reading.'),
'Txf2EdqOg1SQ_2258':(False,'Up is recovered, but its is not linked to the truck and the flooding is still an entity description rather than a linked event.'),
'Txf2EdqOg1SQ_2377':(True,'Below remains attached to the housing estate; collapsed scaffolding, vehicles and crushing are retained. This replaces an already accepted split, not a new corpus recovery.')}
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def main():
    current=read(RUN/'cached_pipeline.jsonl');previous={r['claim_id']:r for r in read(OLD/'pipeline_checked.jsonl')};prior_reviews={r['claim_id']:r for r in json.loads((OLD/'semantic_review.json').read_text())['cases']}
    reviews=[];approved={};changed=[];cases=[]
    for r in current:
        cid=r['claim_id'];a=r['output'];b=previous[cid]['output'];ok=False;reason=a.get('reason','No complete program.');kind='pipeline_failure'
        if a['status']=='compiled':
            different=a.get('program')!=b.get('program')or form(a)!=form(b)
            if different:
                ok,reason=JUDGMENTS[cid];kind='newly_inspected';changed.append(cid)
                cases.append(dict(id=cid,title='Real claim: '+cid,text=r['original'],before=slim(b),after=slim(a),note=reason,approved=ok,stage=r['stage'],alignments=a.get('compilation',{}).get('metadata',{}).get('source_alignments',[])))
            else:ok=prior_reviews[cid]['faithful'];reason=prior_reviews[cid]['reason'];kind='exact_program_and_form_review_reused'
            if ok:approved[cid]=r
        reviews.append(dict(claim_id=cid,faithful=ok,reason=reason,review_type=kind,artifact_sha256=digest(r)))
    assert set(changed)==set(JUDGMENTS),(set(changed)^set(JUDGMENTS))
    pool=[];additions=[];prior=read(OLD/'corpus_reviewed.jsonl')
    pipeline_by_id={r['claim_id']:r for r in current}
    review_by_id={r['claim_id']:r for r in reviews}
    for r in prior:
        cid=r['claim_id']
        if cid in approved:
            if r['status']!='compiled':additions.append(cid)
            r=dict(approved[cid]['output'],claim_id=cid,text=r['text'],acceptance='Compiler-author development review; not independent gold or a media truth label.')
        elif r['status']!='compiled'and cid in pipeline_by_id:
            output=pipeline_by_id[cid]['output'];review=review_by_id[cid]
            r=dict(output,claim_id=cid,text=r['text'],status='unsupported')
            if output['status']=='compiled':r.update(code='meaning_review',reason=review['reason'])
        pool.append(r)
    write(RUN/'corpus_reviewed.jsonl',pool)
    (RUN/'semantic_review.json').write_text(json.dumps(dict(provenance='Compiler-author development review: all25 changed complete programs inspected;83 exact program/form judgments reused. The prior retained pool is not fully re-reviewed.',cases=reviews),indent=2)+'\n')
    ledger=[];by_pipeline={r['claim_id']:r for r in current};direct={r['claim_id']:r for r in read(RUN/'direct_all.jsonl')}
    for r in pool:
        if r['status']=='compiled':continue
        cid=r['claim_id'];pipeline=by_pipeline.get(cid);out=pipeline['output']if pipeline else direct[cid];review=next((v for v in reviews if v['claim_id']==cid),None)
        ledger.append(dict(claim_id=cid,text=r['text'],stage='meaning_review'if out['status']=='compiled'else pipeline['stage']if pipeline else'direct_refusal_without_cached_rewrite',code='meaning_review'if out['status']=='compiled'else out.get('code'),reason=review['reason']if out['status']=='compiled'else out.get('reason'),diagnostic_output=slim(out)))
    (RUN/'remaining_cases.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
    for c in json.loads((RUN/'construction_checks.json').read_text()):
        nominal=c['id']in{'ready_collapse','ready_planned','ready_prevent','ready_prevent_adj','ready_negative'}
        note='Authored construction check, not independent gold. '+('Experimental nominal typing is enabled only in this example; off by default in corpus runs.'if nominal else'Actual frozen parser predictions; parent interval supplied only for the context-reference example.')
        cases.append(dict(id=c['id'],title='Construction: '+c['id'],text=c['text'],before=slim(c['without']),after=slim(c['nominal_prototype']if nominal else c['after']),note=note,approved=None,stage='construction_check',alignments=(c['nominal_prototype']if nominal else c['after']).get('compilation',{}).get('metadata',{}).get('source_alignments',[])))
    for c in json.loads((RUN/'nominal_ambiguity.json').read_text()):cases.append(dict(id=c['id']+'__nominal',title='Why nominal typing stays off: '+c['id'],text=c['text'],before=slim(c['without']),after=slim(c['nominal_prototype']),note='Experimental lexical typing is wrong for this noun sense (electoral riding or camera shot). This output is excluded from the final corpus condition.',approved=False,stage='excluded_nominal_diagnostic',alignments=[]))
    (RUN/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
    stats=dict(corpus=dict(total=len(pool),previous_accepted=1953,accepted=sum(r['status']=='compiled'for r in pool),rate=sum(r['status']=='compiled'for r in pool)/len(pool),remaining=len(ledger),new_approved=len(additions),new_ids=additions),direct=dict(before=1953,auxiliary_only=1960,final=sum(r['status']=='compiled'for r in direct.values()),total=len(direct),failures=dict(Counter(r.get('code')for r in direct.values()if r['status']!='compiled'))),cached=dict(total=len(current),before_programs=87,programs=sum(r['output']['status']=='compiled'for r in current),stages=dict(Counter(r['stage']for r in current)),approved=len(approved),newly_reviewed=len(changed),reused_reviews=sum(r['review_type']=='exact_program_and_form_review_reused'for r in reviews)),remaining=dict(stages=dict(Counter(r['stage']for r in ledger)),codes=dict(Counter(r['code']for r in ledger))),cases=len(cases),new_model_requests=0,nominal_typing_default=False,training='Four-case native frozen-feature engineering smoke only; not empirical binding evaluation or full-corpus training.')
    (RUN/'summary.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
