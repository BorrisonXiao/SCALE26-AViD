"""Compile rewritten candidates and replay all original claims without mutation."""
import argparse,hashlib,json,time
from pathlib import Path
from run_content_relations_census import compile_one
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'exp/probabilistic_verification/content_relations_20261105'
RUN=ROOT/'exp/probabilistic_verification/claim_rewrite_20261111'
def read(p):return list(map(json.loads,p.read_text().splitlines()))
def write(p,rows):p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
def verify_freeze():
 freeze=json.loads((RUN/'compiler_freeze.json').read_text())
 for name,digest in freeze['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
 manifest=json.loads((RUN/'pilot_manifest.json').read_text())
 for name,digest in manifest['baseline_sha256'].items():assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==digest,name
 return len(freeze['source_sha256'])
def main():
 global RUN
 p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group();g.add_argument('--census',action='store_true');g.add_argument('--reviewed-census',action='store_true');p.add_argument('--run',type=Path,default=RUN);a=p.parse_args();RUN=a.run;n=verify_freeze();started=time.perf_counter()
 if a.reviewed_census:
  from probabilistic_verification.claim_rewrite import reviewed_acceptance
  original=read(BASE/'inputs.jsonl');parsed={r['claim_id']:r for r in read(RUN/'parsed_proposals.jsonl')};pilot={r['claim_id']:r for r in read(RUN/'pilot_compilation.jsonl')};reviews={r['claim_id']:r for r in json.loads((RUN/'semantic_review.json').read_text())['cases']};expected=read(RUN/'reviewed_corpus.jsonl');rows=[];changed=[]
  for old in original:
   cid=old['claim_id'];p=pilot.get(cid);use=bool(p and p['original']['status']!='compiled'and reviewed_acceptance(old,p['proposal'],p['rewritten'],reviews[cid]))
   record=parsed[cid]['record'] if use else old
   row=json.loads(json.dumps(compile_one(record)));row.update(original_text=old['text'],rewrite_reviewed=use);rows.append(row)
   if use:changed.append(cid)
  assert rows==expected,'Reviewed pipeline replay differs'
  write(RUN/'reviewed_corpus.jsonl',rows)
  proof=dict(total=len(rows),generated=sum('program'in r for r in rows),pass_content_checks=sum(r['status']=='compiled'for r in rows),reviewed_replacement_ids=changed,exact_records_match=True,compiler_source_files_unchanged=n,elapsed_seconds=time.perf_counter()-started)
  (RUN/'reviewed_corpus_replay.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
 elif a.census:
  original=read(BASE/'inputs.jsonl');rows=[json.loads(json.dumps(compile_one(r))) for r in original];expected=read(BASE/'results.jsonl')
  write(RUN/'baseline_replay.jsonl',rows)
  assert rows==expected,'Baseline changed'
  proof=dict(total=len(rows),generated=sum('program' in r for r in rows),pass_content_checks=sum(r['status']=='compiled' for r in rows),exact_records_match=True,compiler_source_files_unchanged=n,elapsed_seconds=time.perf_counter()-started)
  (RUN/'baseline_replay.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
 else:
  old={r['claim_id']:r for r in read(BASE/'results.jsonl')};rows=[]
  for proposal in read(RUN/'parsed_proposals.jsonl'):
   after=compile_one(proposal['record']) if 'record'in proposal else dict(claim_id=proposal['claim_id'],text=proposal['text'],status='unsupported',code='rewrite_parse',reason=proposal['parse_error'])
   rows.append(dict(claim_id=proposal['claim_id'],original=old[proposal['claim_id']],rewritten=after,proposal=proposal['proposal'],surface_issues=proposal['surface_issues']))
  write(RUN/'pilot_compilation.jsonl',rows);print('Compiled',len(rows),'diagnostic proposals; no review-based acceptance yet.')
if __name__=='__main__':main()
