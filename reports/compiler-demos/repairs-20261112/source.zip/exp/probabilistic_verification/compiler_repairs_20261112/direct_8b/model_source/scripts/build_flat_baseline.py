#!/usr/bin/env python3
"""
AViD Phase 3 — Flat whole-claim baseline verdicts (compositional faithfulness).

For every claim (natural + perturbed), combine the visual + audio *whole-claim*
3-way probe (pass1_verdict) into a single binary verdict:

    supported   iff (visual == yes) OR (audio == yes)
    unsupported otherwise

This is the "no-decomposition" control: the MLLM is asked about the entire
claim sentence at once, with no parse tree, no per-unit probes, and no
compositional negation/veto logic.

Keying of exp/phase3/baseline/verify_{visual,audio}_wholeclaim.jsonl:
  - natural rows:   unit_id == "full", claim_id == natural id  -> key = claim_id
  - perturbed rows: unit_id == perturbed id (X__neg/…),
                    claim_id == original id                    -> key = unit_id

Output: exp/phase3/baseline/flat_verdicts.jsonl
        one row per claim, keyed by `id` (natural claim_id or perturb_id),
        so it joins directly against decomp_m3.jsonl (natural) and
        decomp_m3_perturb.jsonl / gold.jsonl (perturbed).

Usage:
    python scripts/build_flat_baseline.py
"""

import argparse
import json
from collections import Counter
from pathlib import Path

_AVID = Path("/exp/cxiao/scale26/avid")

VIS_IN = str(_AVID / "exp/phase3/baseline/verify_visual_wholeclaim.jsonl")
AUD_IN = str(_AVID / "exp/phase3/baseline/verify_audio_wholeclaim.jsonl")
OUT    = str(_AVID / "exp/phase3/baseline/flat_verdicts.jsonl")


def load_wholeclaim(path: str) -> dict:
    """{id: {verdict, unit_id, row_claim_id, is_perturbed, text}}."""
    out = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            uid = d["unit_id"]
            cid = d["claim_id"]
            if uid == "full":
                ident, is_pert = cid, False
            else:
                ident, is_pert = uid, True          # perturbed id lives in unit_id
            out[ident] = {
                "verdict": d.get("pass1_verdict"),
                "unit_id": uid,
                "row_claim_id": cid,
                "is_perturbed": is_pert,
                "text": d.get("unit_text"),
            }
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--vis-in", default=VIS_IN)
    ap.add_argument("--aud-in", default=AUD_IN)
    ap.add_argument("--output", default=OUT)
    args = ap.parse_args()

    vis = load_wholeclaim(args.vis_in)
    aud = load_wholeclaim(args.aud_in)
    print(f"visual wholeclaim rows: {len(vis)}")
    print(f"audio  wholeclaim rows: {len(aud)}")

    ids = set(vis) | set(aud)
    only_vis = len(set(vis) - set(aud))
    only_aud = len(set(aud) - set(vis))
    print(f"union ids: {len(ids)}  (vis-only={only_vis}, aud-only={only_aud})")

    dist = Counter()          # flat_verdict overall
    dist_nat = Counter()
    dist_pert = Counter()
    n_nat = n_pert = 0

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        for ident in sorted(ids):
            v = vis.get(ident)
            a = aud.get(ident)
            vv = v["verdict"] if v else None
            av = a["verdict"] if a else None
            supported = (vv == "yes") or (av == "yes")
            flat = "supported" if supported else "unsupported"
            is_pert = (v or a)["is_perturbed"]
            row = {
                "id": ident,
                "claim_id": ident,
                "is_perturbed": is_pert,
                "visual_verdict": vv,
                "audio_verdict": av,
                "flat_verdict": flat,
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            dist[flat] += 1
            if is_pert:
                n_pert += 1
                dist_pert[flat] += 1
            else:
                n_nat += 1
                dist_nat[flat] += 1

    print(f"\nWrote {len(ids)} rows → {args.output}")
    print(f"  natural:   {n_nat}   {dict(dist_nat)}")
    print(f"  perturbed: {n_pert}   {dict(dist_pert)}")
    print(f"  overall:   {dict(dist)}")


if __name__ == "__main__":
    main()
