#!/usr/bin/env python3
"""Evaluate saved pilot observations, keeping label sources explicit."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import json
import math
from pathlib import Path

from run_verification_pilot import LABELS, read, write


def valid_dist(d):
    return (isinstance(d, dict) and set(d) == set(LABELS)
            and all(isinstance(v, (int,float)) and math.isfinite(v) and 0 <= v <= 1 for v in d.values())
            and abs(sum(d.values())-1) < 1e-6)


def aggregate(distributions, method):
    if not distributions or not all(valid_dist(d) for d in distributions):
        return None
    if method == 'mean':
        return {s:sum(d[s] for d in distributions)/len(distributions) for s in LABELS}
    if method == 'minimum':
        s = min(d['supported'] for d in distributions)
        r = max(d['refuted'] for d in distributions)
    elif method == 'conjunction':
        # Independent categorical facts; explicit unknown is preserved.
        s = math.prod(d['supported'] for d in distributions)
        r = 1-math.prod(1-d['refuted'] for d in distributions)
    else:
        raise ValueError(method)
    return dict(supported=s, refuted=r, unknown=max(0., 1-s-r))


def metrics(rows, labels):
    selected = [(r,labels[r['sample_id']]) for r in rows
                if r['sample_id'] in labels and valid_dist(r.get('distribution'))]
    if not selected:
        return dict(n_labeled_predictions=0)
    confusion = {s:{t:0 for t in LABELS} for s in LABELS}
    for r,gold in selected:
        pred = max(r['distribution'],key=r['distribution'].get)
        confusion[gold][pred] += 1
    f1 = []
    for s in LABELS:
        tp = confusion[s][s]
        denom = sum(confusion[s].values())+sum(confusion[t][s] for t in LABELS)
        f1.append(2*tp/denom if denom else 0.)
    n = len(selected)
    return dict(n_labeled_predictions=n,
                agreement=sum(confusion[s][s] for s in LABELS)/n,
                macro_f1=sum(f1)/3,
                brier=sum(sum((r['distribution'][s]-int(s==gold))**2 for s in LABELS) for r,gold in selected)/n,
                negative_log_likelihood=-sum(math.log(max(1e-12,r['distribution'][gold])) for r,gold in selected)/n,
                confusion=confusion)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('run_dir', type=Path)
    args = ap.parse_args()
    root = args.run_dir
    claims = read(root/'claims.jsonl')
    observations = {name:read(root/f'{name}_raw.jsonl') for name in ('whole_claim','text_only','parts')}
    predictions = []
    for name in ('whole_claim','text_only'):
        predictions.extend(dict(sample_id=r['request_id'], method=name, distribution=r.get('distribution'),
                                status=r['status']) for r in observations[name])
    parts = {r['request_id']:r for r in observations['parts']}
    groups = defaultdict(list)
    for row in read(root/'part_mapping.jsonl'):
        groups[row['sample_id'],row['kind']].append(row)
    for (cid,kind),rows in groups.items():
        # Repeated identical questions are not independent evidence.
        ids = list(dict.fromkeys(r['request_id'] for r in rows if 'request_id' in r))
        ds = [parts[i].get('distribution') for i in ids if i in parts]
        complete = len(ds)==len(ids) and bool(ids) and not any('error' in r for r in rows)
        for method in (('conjunction',) if kind=='relations' else ('mean','minimum','conjunction')):
            dist = aggregate(ds,method) if complete else None
            predictions.append(dict(sample_id=cid,method=kind+'_'+method,distribution=dist,
                                    status='ok' if dist is not None else 'incomplete',
                                    n_unique_parts=len(ids)))
    write(root/'predictions.jsonl',predictions)
    manual_path = root/'assistant_reviews.jsonl'
    manual = read(manual_path) if manual_path.exists() else []
    labels = {r['sample_id']:r['label'] for r in manual
              if r.get('label') in LABELS and r.get('eligible_for_metrics')}
    summary = dict(n_claims=len(claims), n_source_videos=len({c['video_id'] for c in claims}),
                   proposed_labels=dict(Counter(c['proposed_label'] for c in claims)),
                   edit_types=dict(Counter(c['edit_type'] for c in claims)),
                   independent_human_gold_count=0,
                   label_policy='Assistant-reviewed sampled-frame development labels only; not independent human gold or paper accuracy.',
                   assistant_label_counts=dict(Counter(labels.values())), methods={}, cost={})
    by_claim = {c['sample_id']:c for c in claims}
    by_manual = {r['sample_id']:r for r in manual}
    summary['candidate_quality_counts'] = dict(Counter(r.get('quality','unreviewed')
        for r in manual if by_claim.get(r['sample_id'],{}).get('edit_type')!='seed'))
    summary['eligible_binding_negatives'] = sum(r.get('quality')=='usable' and r.get('label')=='refuted'
        and r.get('usage')=='binding_negative' for r in manual)
    for method in sorted({r['method'] for r in predictions}):
        rs = [r for r in predictions if r['method']==method]
        summary['methods'][method] = dict(n_predictions=len(rs),
            n_valid_distributions=sum(valid_dist(r.get('distribution')) for r in rs),
            **metrics(rs,{} if method=='text_only' else labels))
        if method=='text_only':
            good = [r for r in rs if valid_dist(r.get('distribution'))]
            summary['methods'][method]['expected_unknown_rate'] = (
                sum(max(r['distribution'],key=r['distribution'].get)=='unknown' for r in good)/len(good)
                if good else None)
            summary['methods'][method]['evaluation_policy'] = 'No media supplied: expected unknown; do not compare against full-media labels.'
            continue
        byid = {r['sample_id']:r for r in rs if valid_dist(r.get('distribution'))}
        verified_pairs = []
        for c in claims:
            cid = c['sample_id'];base = c['seed_id']+':seed';ann=by_manual.get(cid,{})
            if ann.get('quality')=='usable' and ann.get('usage')=='binding_negative' and labels.get(base)=='supported':
                if cid in byid and base in byid:
                    a,b = byid[base]['distribution'],byid[cid]['distribution']
                    verified_pairs.append(dict(seed_id=c['seed_id'],variant_id=cid,
                        seed_support=a['supported'],negative_support=b['supported'],
                        support_margin=a['supported']-b['supported'],
                        seed_prediction=max(a,key=a.get),negative_prediction=max(b,key=b.get)))
        summary['methods'][method]['eligible_binding_pair_diagnostics'] = verified_pairs
        summary['methods'][method]['per_edit'] = {
            edit:metrics([r for r in rs if by_claim[r['sample_id']]['edit_type']==edit],labels)
            for edit in sorted({c['edit_type'] for c in claims})}
        pairs = []
        for c in claims:
            base = c['seed_id']+':seed'
            if c['sample_id']==base or c['sample_id'] not in labels or base not in labels:
                continue
            if c['sample_id'] not in byid or base not in byid:
                continue
            a,b = byid[base]['distribution'],byid[c['sample_id']]['distribution']
            pairs.append((max(a,key=a.get)==labels[base] and max(b,key=b.get)==labels[c['sample_id']],
                          a['supported']-b['supported'],c['edit_type']))
        negatives = [p for p in pairs if p[2]!='paraphrase']
        summary['methods'][method]['reviewed_pairs'] = len(pairs)
        summary['methods'][method]['strict_pair_agreement'] = sum(p[0] for p in pairs)/len(pairs) if pairs else None
        summary['methods'][method]['mean_seed_minus_edit_support'] = sum(p[1] for p in negatives)/len(negatives) if negatives else None
    all_observations = dict(observations)
    for name in ('generation','decomposition','review'):
        p = root/f'{name}_raw.jsonl'
        if p.exists():
            all_observations[name] = read(p)
    for name,rs in all_observations.items():
        # Batch timing is repeated in each record, so allocate a fraction per row.
        summary['cost'][name] = dict(n_calls=len(rs),
            prompt_tokens=sum(r['prompt_tokens'] for r in rs),
            generated_tokens=sum(r['generated_tokens'] for r in rs),
            model_batch_seconds=sum(r['batch_elapsed_seconds']/r['batch_size'] for r in rs),
            images=sum(len(r['request']['task'].get('frame_paths',[])) for r in rs))
    (root/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
