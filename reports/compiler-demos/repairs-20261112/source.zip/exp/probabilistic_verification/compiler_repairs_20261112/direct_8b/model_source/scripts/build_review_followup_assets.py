#!/usr/bin/env python3
"""Publish preparation records without generating or importing human judgments."""
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/review_followup_20261104'


def main():
    target = ROOT / 'site/reports/verification-pipeline/review-followup'
    target.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / 'docs/review_followup.md', target / 'README.md')
    for name in ('sample_manifest.json', 'status.json', 'validation.json'):
        shutil.copy2(RUN / name, target / name)
    files = [ROOT / p for p in ('scripts/prepare_review_followup.py', 'scripts/analyze_claim_review.py',
        'scripts/import_claim_review.py', 'scripts/build_review_followup_assets.py',
        'scripts/build_av_feature_sections.py',
        'exp/probabilistic_verification/av_features_20261022/checklist.json',
        'tests/test_review_followup.py', 'docs/review_followup.md',
        'exp/probabilistic_verification/scope_compilation_20261101/human_review_packet.json',
        'exp/probabilistic_verification/scope_compilation_20261101/human_review_blinding.json',
        'exp/probabilistic_verification/agent_review_20261101/agent_draft.json')]
    files += [RUN / p for p in ('sample_manifest.json', 'fresh_inputs.jsonl', 'fresh_baseline.jsonl',
                               'status.json', 'validation.json', 'historical_archives.json')]
    with zipfile.ZipFile(target / 'source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            info = zipfile.ZipInfo(str(path.relative_to(ROOT)), date_time=(2026, 11, 4, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    print('Published preparation records; no human answers or compiler results created.')


if __name__ == '__main__':
    main()
