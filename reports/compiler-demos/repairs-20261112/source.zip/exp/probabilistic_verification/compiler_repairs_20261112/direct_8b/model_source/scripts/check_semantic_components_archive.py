"""Replay the experiment after extracting its nine published source overlays."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/semantic_components_20261112'

def main():
    target=Path(tempfile.mkdtemp(prefix='avid-semantic-components-'))
    bundles=['source.zip','alert-review-20261111/source.zip','rewrite-20261111/source.zip','rewrite-inspection-20261112/source.zip','split-20261112/source.zip','alignment-20261112/source.zip','maintenance-20261112/source.zip','full-rewrite-20261112/source.zip','components-20261112/source.zip']
    for n in bundles:
        with zipfile.ZipFile(ROOT/'site/reports/compiler-demos'/n)as archive:archive.extractall(target)
    for line in(target/'SEMANTIC_COMPONENTS_SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1);assert hashlib.sha256((target/n).read_bytes()).hexdigest()==h,n
    env=dict(os.environ,PYTHONPATH=str(target/'scripts'),PYTHONDONTWRITEBYTECODE='1');run=target/RUN.relative_to(ROOT)
    times={n:(run/n).read_bytes()for n in ['direct_summary.json','historical_regression.json']}
    commands=[['scripts/check_semantic_default.py'],['scripts/run_semantic_components.py','probes'],['scripts/run_semantic_components.py','replay'],['scripts/run_semantic_components.py','corpus'],['scripts/analyze_semantic_components.py'],['scripts/build_compiler_demos.py'],['scripts/package_semantic_components.py','--allow-missing-history']]
    for args in commands:
        r=subprocess.run([sys.executable]+args,cwd=target,env=env,text=True,capture_output=True)
        if r.returncode:raise RuntimeError(str(args)+'\n'+r.stdout+'\n'+r.stderr)
        if args[0].endswith('check_semantic_default.py'):
            check=json.loads((run/'historical_regression.json').read_text());assert check['exact_json_match']and check['records']==2375
            (run/'historical_regression.json').write_bytes(times['historical_regression.json'])
        if args[-1]=='corpus':(run/'direct_summary.json').write_bytes(times['direct_summary.json'])
        print('Replayed',' '.join(args),flush=True)
    files=['site/reports/compiler-demos.html','site/reports/compiler-demos/daily_log.json','site/reports/verification-pipeline.html','site/reports/verification-pipeline/av/checklist.json']
    files +=[str(p.relative_to(ROOT))for p in(ROOT/'site/reports/compiler-demos/components-20261112').iterdir()if p.is_file()]
    files +=[str((RUN/n).relative_to(ROOT))for n in ['summary.json','probe_results.jsonl','pipeline_checked.jsonl','direct_all.jsonl','semantic_review.json','corpus_reviewed.jsonl','cases.json']]
    for n in files:assert (ROOT/n).read_bytes()==(target/n).read_bytes(),n
    proof=dict(extraction=str(target),bundles=bundles,sha256_inventory=True,historical_exact=2375,originals=2375,cohort=449,probes=36,cached_clauses=1437,byte_identical_artifacts=len(files),files=files)
    (RUN/'archive_verification.json').write_text(json.dumps(proof,indent=2)+'\n');print('Verified',len(files),'byte-identical artifacts including source.zip',flush=True)

if __name__=='__main__':main()
