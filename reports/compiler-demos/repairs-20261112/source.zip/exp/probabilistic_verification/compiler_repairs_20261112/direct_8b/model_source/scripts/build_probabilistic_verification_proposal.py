#!/usr/bin/env python3
"""Build the accepted paper-direction page without running any model."""

from html import escape
from pathlib import Path
from build_verification_examples import generated_examples

from prompts_phase2 import (
    VERIFICATION_PREPARATION_PROMPT_VERSION,
    VERIFICATION_DATA_GENERATE_SYSTEM,
    VERIFICATION_DATA_REVIEW_SYSTEM,
    VERIFICATION_BASELINE_SYSTEM,
    VERIFICATION_PREPARATION_V2_PROMPT_VERSION,
    VERIFICATION_DATA_GENERATE_V2_SYSTEM,
    VERIFICATION_DATA_REVIEW_V2_SYSTEM,
    VERIFICATION_DECOMPOSE_V2_SYSTEM,
    VERIFICATION_DATA_GENERATE_V3_SYSTEM,
    VERIFICATION_REALIZE_SYSTEM,
)

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "site/proposals/probabilistic-verification.html"
DATE = "22 October 2026"
TABLE_NUMBER = 0


def equation(tex):
    return '<div class="equation">\\[' + escape(tex) + '\\]</div>'


def table(title, headers, rows, caption):
    global TABLE_NUMBER
    TABLE_NUMBER += 1
    head = "".join(f'<th scope="col">{h}</th>' for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{v}</td>" for v in row) + "</tr>" for row in rows)
    return f'<div class="table-wrap"><table><caption>Table {TABLE_NUMBER}. {title} {caption}</caption><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def section(identifier, title, body):
    return f'<section id="{identifier}" class="paper-section"><h2>{title}</h2>{body}</section>'


def prompt_preview(title, prompt):
    return (
        '<details><summary>' + escape(title) + '</summary>'
        '<pre><code>' + escape(prompt) + '</code></pre></details>'
    )


parts = []
parts.append(section("direction", "1. Paper direction and scope", r'''
<div class="callout"><strong>Chosen paper direction</strong><p>Compile a claim into a probabilistic logic program, connect its predicates to visual, audio, speech, and on-screen-text evidence, and infer whether the claim is supported. Binding functions can use predefined rules or learned conditional distributions. The inference and learning backend may be DeepProbLog or a comparable existing system.</p></div>
<p>The paper is a methods paper about a common representation and learning procedure for multimodal claim verification. When claims come from model-generated text, the same verifier can identify unsupported or contradicted claims. The paper direction is accepted; the implementation and empirical claims still require validation.</p>
<p><strong>Binding</strong> means whether the participants, attributes, actions, and sources are related as the claim says—for example, who did what to whom. Recognizing all the mentioned parts somewhere in the media is insufficient.</p>
<p>Keep the first implementation small: one to three event clauses, semantic roles such as agent and object, local attributes, conjunction, and scoped negation. Add temporal relations as an extension. Keep the visual and audio models frozen. Train only small relation classifiers and calibration parameters initially. A large new training corpus and multimodal language-model fine-tuning are outside the initial plan.</p>
<p>Use “probabilistic parsing” to describe compiling semantic structure and inferring alternative evidence assignments. We are not claiming a new general-purpose syntactic parser or probabilistic inference engine. Shared-variable logic and differentiable probabilistic inference are established tools; the paper must demonstrate the value of our claim representation, evidence interface, and binding-learning procedure.</p>
'''))

parts.append(section("overview", "2. From a claim to a probability", r'''
<p>Figure 1 separates language analysis, perception, relation classification, and inference. This separation lets us replace a component without rewriting the entire verifier.</p>
<figure class="pipeline-figure">
  <ol class="pipeline">
    <li><strong>Parse the claim</strong><span>Dependency parsing and semantic role labeling identify predicates, arguments, and scope.</span></li>
    <li><strong>Compile a logic program</strong><span>Rules preserve argument roles, shared variables, and logical operators.</span></li>
    <li><strong>Collect candidate evidence</strong><span>Frozen models propose events, participants, intervals, and local observations.</span></li>
    <li><strong>Score the relations</strong><span>Fixed functions or small learned classifiers produce probability distributions.</span></li>
    <li><strong>Run probabilistic inference</strong><span>Combine the evidence over alternative assignments and return a verdict distribution.</span></li>
  </ol>
  <figcaption>Figure 1. Proposed processing stages. During training, the claim-level loss can update the small relation classifiers through inference. The parser and media models remain frozen in the initial design.</figcaption>
</figure>
<p>A dependency parse supplies syntax, not a complete logical form. Semantic role labeling identifies who acts and what is affected; additional rules preserve negation, conjunction, reference, and assertion scope. We retain links from each predicate to the original claim span so omitted or mistranslated content can be audited.</p>
'''))

parts.append(section("compilation", "3. Claim compilation and shared variables", r'''
<p>For “Alice hugs Dave,” a simplified rule is:</p>
<pre><code>supports(hugs(A, B)) :-
    event(E),
    action(E, hug),
    agent(E, A),
    theme(E, B).</code></pre>
<p>The variable <code>E</code> is shared: the agent and object must belong to the same event. Here <code>theme</code> is the semantic role of the participant receiving or undergoing the action. The words Alice and Dave are schematic names for identifiable participants; real examples may use descriptions such as “the person in red.”</p>
<p>This rule specifies the meaning of the claim, while the predicates can have uncertain, learnable outputs. For the first implementation, a complete predicate–argument tuple can be scored jointly. This avoids treating several overlapping observations from the same model as independent facts.</p>
<pre><code>% Schematic neural-predicate interface, not a complete runnable program.
nn(binding_net, [E, R, A, B], Z,
   [supported, refuted, unknown]) :: binding_status(E, R, A, B, Z).

supports(hugs(A, B)) :-
    event(E),
    binding_status(E, hug, A, B, supported).</code></pre>
<p><code>binding_net</code> looks up cached features for the specified event and ordered arguments. Event identifiers are lookup keys, not learned features. The example shows the support query only; separate rules compute refutation and insufficient evidence. Negation is implemented through those explicit states, not by treating failure to prove support as refutation.</p>
<p>A decoder-only language model may help translate an ambiguous construction into a constrained logical form. It is a frozen fallback, with syntax checking, span coverage checks, and a restricted output vocabulary. It does not get to omit a difficult part of the claim. Manually checked logical forms are an evaluation diagnostic, not the input assumed by the final system.</p>
<p>Candidate retrieval must not assume the complete claim is true. Retrieve possible actions and participants, retain a few plausible events, and then test their bindings. Otherwise a false claim can disappear before it is verified.</p>
'''))

parts.append(section("evidence", "4. Evidence, modality, and candidate assignments", r'''
<p>The user selected typed support from visual depiction, non-speech sound, speech, and optical character recognition (OCR). These are evidence routes, not mutually exclusive truth labels. A claim can use more than one route.</p>
<p>Keep “the video shows the event” separate from “the narrator says the event happened.” An assertion supports an assertion proposition; it does not automatically establish the event in the world. Verification is relative to the supplied media and the declared evidence policy.</p>
''' + table("Component outputs.", ["Component", "Output", "Initial treatment"], [
    ("Claim parser", "Predicates, semantic roles, logical scope, and original text spans.", "Reuse the current parser and normalization code where correct; add a restricted compiler."),
    ("Visual model", "Candidate events/participants, complete-relation scores, available visual evidence, and proposed intervals.", "Frozen; cache outputs. A time window is not itself an event identity."),
    ("Audio model", "Sound events, speech/source observations, relation scores, and available evidence.", "Frozen; retain original timestamps and distinguish speech from non-speech sound."),
    ("Text encoder, if needed", "A vector representation of a claim part or an evidence description.", "Frozen in the first experiment; optional for numeric-score inputs."),
    ("Relation classifier", "Supported/refuted/unknown probabilities for an event and an ordered argument tuple.", "A small trainable classifier, shared across examples."),
    ("Inference backend", "Claim verdict probabilities and likely evidence assignments.", "Existing probabilistic logic inference; no new engine is required.")
], "All outputs are proposed interfaces, not completed implementation results.") + r'''
<p>Each observation should record the predicate and arguments, source media, interval or region if available, evidence route, model/prompt version, scores, and availability. A score-only module is allowed; the interface must not pretend that it also provides reliable tracking or timestamps.</p>
<p><strong>Alternative assignments:</strong> retain a bounded set of candidate events and participants, plus an unavailable option. The program considers compatible assignments rather than committing to the first plausible match. Use full-tuple observations when separate role observations cannot be aligned reliably. An existing tracker can supply candidates if available, but building a new general tracking system is not part of this plan.</p>
'''))

parts.append(section("architecture", "5. What neural network should parameterize a binding function?", r'''
<div class="callout"><strong>Initial choice: a small classifier over cached evidence features.</strong><p>Start with logistic regression as the control and a multilayer perceptron (MLP) with one hidden layer as the main learned relation classifier. Use a BERT-style encoder only when text representations add useful information. Keep decoder-only models frozen for parsing and media understanding.</p></div>
<p>The input determines the architecture. Numeric scores need a classifier; text descriptions can benefit from a text encoder; raw video and audio still require their own perception models. A text-only BERT model cannot independently inspect the media.</p>
''' + table("Architecture choices.", ["Choice", "What it receives", "What is trained", "Role in this project"], [
    ("Logistic regression", "Cached scores, availability, relation type, and source/time compatibility.", "A small linear classification layer.", "First learned baseline; tests whether calibration alone explains gains."),
    ("MLP: one hidden layer", "The same numeric features; optional frozen text features.", "The hidden and output layers, with regularization.", "Initial main relation classifier; captures interactions among the evidence features."),
    ("Frozen BERT-style encoder + classifier", "Claim/event descriptions with explicit argument order; numeric evidence features remain separate.", "Only the classifier initially.", "Optional text-aware variant. Sentence-BERT-style representations permit caching."),
    ("BERT cross-encoder", "Claim part and evidence description encoded jointly.", "Classification head first; encoder fine-tuning only if justified by data.", "A stronger text-relation baseline when evidence descriptions are informative; more expensive than cached separate encodings."),
    ("Decoder-only language model", "Claim text, constrained parsing instructions, or media inputs if the model supports them.", "No decoder weights in the initial plan.", "Frozen parsing/evidence module and a direct-verification baseline. No autoregressive generation is needed inside the small relation classifier.")
], "These are design choices and comparisons; no architecture has yet been shown superior on this task.") + r'''
<p><a href="https://aclanthology.org/N19-1423/">BERT</a> provides bidirectional text representations; <a href="https://aclanthology.org/D19-1410/">Sentence-BERT</a> provides sentence representations suitable for separate encoding. A concrete lightweight optional baseline is the frozen <a href="https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2">all-MiniLM-L6-v2</a> sentence encoder, whose model card specifies 384-dimensional outputs. This is a reproducible small baseline, not a claim that it is the best current encoder. Sentence similarity alone is not sufficient for role binding.</p>
<h3>Classifier inputs and parameter count</h3>
''' + table("Features for the relation classifier.", ["Feature group", "Examples", "Reason"], [
    ("Complete-relation evidence", "Frozen-model scores for Alice–hug–Dave in a specific candidate event.", "Provides binding-sensitive information beyond constituent presence."),
    ("Local scores and uncertainty", "Action/participant scores, score margins, supported/refuted/unknown outputs when available.", "Lets the classifier learn when local evidence is informative; confidence is not assumed calibrated."),
    ("Evidence availability", "Missing audio, occlusion, unreadable text, or no candidate evidence.", "Distinguishes unavailable evidence from refutation."),
    ("Source and time compatibility", "Same candidate event, original time difference, interval overlap, source identity, route indicators.", "Tests whether observations can refer to the same relation; overlap alone is insufficient."),
    ("Semantic relation and argument order", "Agent versus object; attribute attachment; ordered participant descriptions.", "Preserves asymmetric roles and permits parameter sharing by relation type."),
    ("Optional text representations", "Frozen encodings of the claim tuple and the evidence description, with explicit role labels.", "Tests generalization across wording; cannot replace visual/audio evidence.")
], "Do not use raw video IDs, gold edit types, the paired true claim, or arbitrary participant IDs as predictive features.") + r'''
<p>Let \(x\) be the feature vector for one candidate relation, \(r\) its relation type, and \(z\) its evidence status. The output has three entries: supported, refuted, and unknown. A one-hidden-layer classifier can be written as:</p>
''' + equation(r"p_\theta(z\mid x,r)=\operatorname{softmax}\!\left(W_2\,\operatorname{ReLU}(W_1[x;e_r]+b_1)+b_2\right)_z") + r'''
<p>Here \(e_r\) is a small learned relation embedding, the bracket means concatenation, and \(W_1,W_2,b_1,b_2\) are trainable weights and biases. Use 64 hidden units initially. As an illustrative size calculation, 48 total input features and three outputs give 3,331 classifier parameters, excluding any relation-embedding table. The actual input dimension will follow the feature specification; this is not a measured model size.</p>
<p>Share one classifier across examples and use relation-type features or embeddings, rather than training a separate network for every event label. Begin with standardized numeric features, weight decay, early stopping on development videos, and a fixed small architecture. If text features are added, freeze their encoder and use strong regularization. More parameters are an experimental choice, not a necessary part of the framework.</p>
<h3>Learning an ambiguous evidence assignment</h3>
<p>When one claim mention could refer to several observed participants or events, a second small scoring head can choose among those candidates. Let \(g_j\) be candidate assignment \(j\), \(x_j\) its cached features, \(s_\eta\) a scalar scoring function with parameters \(\eta\), and \(K\) the number of retained alternatives, including an unavailable option:</p>
''' + equation(r"\alpha_\eta(g_j)=\frac{\exp s_\eta(x_j)}{\sum_{k=1}^{K}\exp s_\eta(x_k)}") + r'''
<p>Start with a linear scorer or a 64-unit MLP using the same kinds of features as the relation classifier. Encode the normalized alternatives as one categorical neural predicate; gradients from the final claim loss can update this scorer too. Repeated references to the same claim variable share that categorical choice. A fixed proposal distribution is the control.</p>
<p>Only competing interpretations of one mention are mutually exclusive. Two genuinely different events can both occur; their existence must not be forced into one categorical choice. Keep the program's existential event rules separate from ambiguity about which observed instance a mention refers to. Candidate coverage and identifiability remain empirical limitations.</p>
<p><strong>Information limit:</strong> if a correct claim and a swapped claim produce identical classifier inputs, no classifier architecture can reliably separate them from those inputs. The first audit must check whether full-tuple scores or candidate-specific observations actually contain binding information.</p>
'''))

parts.append(section("probability", "6. Fixed functions, learned functions, and inference", r'''
<p>A predefined composition rule is a conditional distribution with all its mass on one output. Let \(f_r\) be the rule for relation/operator \(r\), \(\mathbf z\) the child evidence states, \(\mathbf g\) the candidate assignments, and \(z_p\) the parent state:</p>
''' + equation(r"Q_r^{\mathrm{rule}}(z_p\mid\mathbf z,\mathbf g)=\mathbf 1[z_p=f_r(\mathbf z,\mathbf g)]") + r'''
<p>The indicator is one when the output matches the rule and zero otherwise. A learned \(Q_r\) has the same inputs and a normalized output distribution. A nonnegative unnormalized function is a factor potential instead; its normalization must be specified. “Interchangeable” means that the domains and meanings match, not that every replacement preserves accuracy or calibration.</p>
<p>Keep logical operators deterministic in the first implementation, while learning the media-relation predicates. For conjunction: all required parts supported gives supported; an explicitly refuted required part gives refuted; otherwise the result is unknown. Negation exchanges supported and refuted while preserving unknown. Learned composition distributions can be compared later under the same interface. They need enough observations to distinguish composition errors from perception errors.</p>
<p>DeepProbLog-style inference computes a query probability by summing the probabilities of possible worlds that satisfy it. Let \(q\) be a query, \(E\) the media observations, \(\theta\) the learned parameters, and \(\omega\) an assignment of the modeled uncertain variables:</p>
''' + equation(r"P_\theta(q\mid E)=\sum_{\omega:\,\omega\models q}P_\theta(\omega\mid E)") + r'''
<p>This is not arbitrary multiplication of every probe score. Repeated uses of a canonical fact refer to the same random variable. Distinct probabilistic facts are independent by default unless dependence is explicitly modeled. To reduce an obvious source of error, feed overlapping primitive scores into one joint relation classifier instead of also multiplying them as independent evidence.</p>
<p>Mutually exclusive alternatives can be represented by an <em>annotated disjunction</em>: one categorical choice with probabilities for supported, refuted, and unknown. The compiler must ensure that the root-state queries partition the modeled outcomes. Unknown is an explicit category; it is not the logical negation of supported. <a href="https://problog.readthedocs.io/en/latest/modeling_basic.html">ProbLog's model documentation</a> explains probabilistic facts and categorical choices.</p>
<p>One supporting event can support an existential claim. Failure to retrieve such an event does not establish refutation when candidate coverage is incomplete. Refutation requires explicit contrary evidence or a defensible coverage condition. Multiple overlapping windows must not be treated as independent confirmations of the same event.</p>
<p>Use a bounded candidate set and a restricted claim language first. Exact inference may become expensive as alternatives and shared variables grow. A dependency tree does not guarantee that the resulting probabilistic program has tree structure. Benchmark query grounding, compilation, inference time, and memory; use existing inference before considering a custom implementation.</p>
'''))

parts.append(section("example", "7. Example: two true events do not support a false combination", r'''
<p>Figure 2 shows why shared event variables matter. The evidence contains two events. Changing the proposed participants tests the relation, while the coverage option illustrates the difference between refutation and insufficient evidence.</p>
<figure class="example-figure">
  <div class="example-events"><div><strong>Event 1</strong><p>Alice hugs Bob.</p></div><div><strong>Event 2</strong><p>Carol hugs Dave.</p></div></div>
  <div class="example-controls">
    <label>Proposed agent<select id="example-agent"><option>Alice</option><option>Carol</option></select></label>
    <label>Proposed object<select id="example-theme"><option>Dave</option><option>Bob</option></select></label>
  </div>
  <label class="coverage-control"><input id="example-complete" type="checkbox"> Assume these are all the relevant events in this toy example.</label>
  <output id="example-result" aria-live="polite">Unknown: no listed event supports Alice hugging Dave, and coverage is incomplete.</output>
  <noscript><p>Alice–Bob and Carol–Dave are supported. Alice–Dave and Carol–Bob have no listed supporting event; they are unknown without complete coverage and refuted under the toy example's explicit complete-coverage assumption.</p></noscript>
  <figcaption>Figure 2. A deterministic illustration, not model output or an experimental result. The complete-coverage assumption is valid only for this explicitly enumerated toy example; it is not automatically valid for a real clip.</figcaption>
</figure>
<p>The learned version estimates how strongly media evidence supports each candidate relation. Shared variables retain the event association; the neural predicate estimates the uncertain relation. These are complementary jobs.</p>
'''))

parts.append(section("learning", "8. Learning from claim labels with frozen media models", r'''
<p>Compiling fixed scores into a program performs inference only. To learn, make the relation probabilities or selected composition parameters trainable and optimize the final claim predictions. <a href="https://proceedings.neurips.cc/paper/2018/hash/dc5d637ed5e62c36ecb73b654b05ba2a-Abstract.html">DeepProbLog</a> provides differentiable probabilistic inference; we can reuse this capability.</p>
<ol><li>Run the frozen media models once and cache their outputs for each candidate relation.</li><li>Use the small classifier to produce local evidence-state distributions.</li><li>Run inference to obtain the root distribution for the compiled claim.</li><li>Compute the loss against verified claim labels and update the small classifier through inference.</li></ol>
<p>Let \(N\) be the number of training claims, \(c_i\) claim \(i\), \(E_i\) its media evidence, and \(y_i\) its supported/refuted/unknown label. Let \(z_{\mathrm{root}}\) be the inferred root state. With optional local relation labels \(\mathcal A\), use:</p>
''' + equation(r"\begin{aligned}\mathcal L_{\mathrm{claim}}&=-\frac{1}{N}\sum_{i=1}^{N}\log P_\theta(z_{\mathrm{root}}=y_i\mid c_i,E_i),\\\mathcal L&=\mathcal L_{\mathrm{claim}}+\lambda\mathcal L_{\mathrm{local}},\quad\lambda\geq 0.\end{aligned}") + r'''
<p>\(\mathcal L_{\mathrm{local}}\) is cross-entropy on the small set \(\mathcal A\) of annotated local relations, and \(\lambda\) controls its weight. Set \(\lambda=0\) when only claim labels are available. Weight decay is applied by the optimizer. All media-model parameters stay frozen; gradients update the relation classifier and any explicitly selected probabilistic parameters.</p>
<p>Final claim labels do not uniquely determine every intermediate relation. Validated role swaps and event reassignments help because the parts remain present while the binding changes. A small amount of local relation supervision can help further. Binary support labels alone cannot fully identify the distinction between refuted and unknown; include explicit unknown examples and availability rules.</p>
<p>Separate three training targets: <strong>relation prediction</strong> learns who participates in an event; <strong>composition/calibration</strong> learns how local evidence relates to final support; <strong>structure learning</strong> discovers program structure. The first two are in scope. Unrestricted discovery of arbitrary rules is not part of the initial plan.</p>
'''))

parts.append(section("time", "9. Temporal constraints as an extension", r'''
<p>Attach original intervals to event candidates and add fixed or learned temporal compatibility functions. This changes the available assignments, not the overall verification task.</p>
<p>The proposed union of parent and child intervals is a useful candidate-window baseline. It is not evidence that they form one event: a set union can retain disconnected events, and its enclosing interval can span a long unrelated section. For local agent/object bindings, compare shared-event candidates with full-tuple verification. For before/after, keep ordered intervals that may be disjoint. For audio/visual attachment, retain synchronization tolerance and source identity.</p>
<p>Compare full clip, parent/child union, oracle event window, and automatic candidate windows. Give whole-claim verification the same selected windows. Count localization calls and control frame density; a crop should not receive uncounted extra visual information. The <a href="https://arxiv.org/abs/2608.08315">FV-Action preprint</a> is a relevant frozen temporal-grounding baseline.</p>
'''))

parts.append(section("data", "10. Small, validated training and test sets", r'''
<p>Use real media with synthetic claim edits. We do not need to generate a large synthetic video corpus. The original statement and the edited statement both need evidence-based checking; grammatical edits do not guarantee a changed truth value.</p>
''' + table("Data construction.", ["Example family", "Purpose", "Validity requirement"], [
    ("Subject/object swap", "Test asymmetric semantic roles.", "Both participants are present; the reversed relation is false throughout the relevant evidence."),
    ("Within-video event reassignment", "Test whether the right action is attached to the right participant/event.", "All constituents remain present; there is no alternative occurrence supporting the edited relation."),
    ("Attribute attachment", "Test which object carries an observed property.", "Object identities and attributes are unambiguous."),
    ("Speech/visual source attachment", "Test a genuinely cross-modal binding.", "Source identity is independently checkable; temporal co-occurrence alone is insufficient."),
    ("Supported paraphrase", "Test invariance to harmless wording changes.", "The claim meaning remains equivalent."),
    ("Insufficient evidence", "Test abstention and unknown-preserving negation.", "The required observation is unavailable or does not establish support/refutation under the declared policy.")
], "Synthetic edits propose examples; validation establishes labels.") + r'''
<p><strong>Pilot:</strong> 40–60 verified pairs, with additional paraphrase, unknown, and duplicate controls. <strong>Small training set if needed:</strong> about 100–300 validated seed assertions with eligible variants. <strong>Final test:</strong> approximately 200–300 independently checked claims plus controls, from separate source videos. These are planning targets, not achieved dataset counts or a statistical power calculation.</p>
<p>Split by original video before generating variants. Keep all edits from one seed/video together. Hold out an edit family or source domain where feasible. A method verifies each claim independently; it must not see the gold paired claim, edit type, or an assumption that exactly one candidate is true. Include naturally erroneous generated claims if available; otherwise limit empirical claims to controlled perturbations.</p>
'''))

parts.append(section("experiments", "11. Experiments that establish the method's value", r'''
<p>The primary research question is whether the compiled representation and learned binding probabilities improve verification, generalization, or evidence use under a controlled budget. No particular inference engine or neural architecture is presumed to win.</p>
''' + table("Required comparisons.", ["Comparison", "What it tests"], [
    ("Whole-claim model; whole-claim calibrator", "Whether extra structure adds value beyond direct verification and simple calibration using the same labels."),
    ("Complete-relation QA; dependency-gated QA", "Whether simpler relation questions already solve the binding problem."),
    ("Fixed rules; linear classifier; small MLP", "What is gained by learned relation probabilities and nonlinear feature interactions."),
    ("Numeric features; frozen text encoder; optional cross-encoder", "Whether text representations contribute beyond cached media scores."),
    ("Fixed first grounding; alternative candidate assignments", "Whether retaining and marginalizing alternative evidence alignments matters."),
    ("Current tree-CRF; BTProp-style comparison", "How the new representation compares with prior project and probabilistic-tree approaches; label approximations honestly."),
    ("Same cached observations; equal total query budget", "Separate composition effects from better questions, more calls, or stronger models."),
    ("One perception-module replacement", "Test the interface, recalibration needs, and transfer; replacement is not assumed harmless."),
    ("Automatic versus checked parse/window", "Separate language-analysis, perception, candidate-coverage, and inference errors.")
], "Begin with the smallest decisive subset; add variants only to answer a specific unresolved question.") + r'''
<p>Report claim accuracy and macro-F1, strict-pair accuracy on supported/false-binding pairs, unknown-state behavior, negative log-likelihood or Brier score, and cost per claim. Estimate uncertainty by resampling source videos rather than treating related edits as independent. Test language-only shortcuts, positive paraphrases, argument-order sensitivity, repeated-evidence invariance, and an audiovisual subset that genuinely needs both channels.</p>
<p>For the initial milestone, a small unambiguous set is more useful than a full-corpus rerun. If full-tuple observations fail even with correct event windows, inspect the perception inputs before enlarging the classifier. If a simple method ties the structured method, retain the simpler implementation and revise the empirical claim. These are implementation decisions within the chosen paper direction, not an automatic reopening of the direction.</p>
'''))

parts.append(section("prior", "12. Prior work and the intended contribution", r'''
''' + table("Closest prior work.", ["Work", "What we reuse or compare", "What our paper must establish"], [
    ('<a href="https://proceedings.neurips.cc/paper/2018/hash/dc5d637ed5e62c36ecb73b654b05ba2a-Abstract.html">DeepProbLog</a>; <a href="https://arxiv.org/abs/2304.04812">Scallop</a>', "Probabilistic/neural logic and shared-variable reasoning.", "A useful multimodal claim compiler, evidence interface, or binding-learning formulation; backend reuse is legitimate."),
    ('<a href="https://arxiv.org/abs/2310.18235">DSG</a>', "Dependency-aware visual checks, including relations.", "A benefit beyond asking atomic/dependency-aware questions."),
    ('<a href="https://aclanthology.org/2025.naacl-long.158/">BTProp</a>; <a href="https://ojs.aaai.org/index.php/AAAI/article/view/40569">Bonsai</a>', "Probabilistic claim trees and multimodal grounded reasoning.", "The value of shared evidence assignments, typed routes, or learned binding functions—not tree propagation alone."),
    ('<a href="https://arxiv.org/abs/2609.11244">OmniHallu</a>; <a href="https://arxiv.org/abs/2606.03614">OmniHalluc-L</a>', "Unified cross-modal detection and frozen-model binding/calibration methods.", "A precise formal/learning contribution and fair transfer tests beyond the broad task name."),
    ('<a href="https://arxiv.org/abs/2606.11838">SG-PVR</a>', "Spatiotemporal relational verification.", "An efficient frozen-module formulation with explicit probability and learning behavior.")
], "Recent arXiv works are identified in the dated literature review; identity verification does not certify our novelty.") + r'''
<p>The intended contributions are: (1) a parser-based translation into a common probabilistic representation; (2) interchangeable fixed and learned relation functions with inference over alternative evidence assignments; and (3) controlled evidence that this design is useful with frozen perception modules. General claims that any verifier is an exact special case require explicit mappings and assumptions. A shared software interface alone is weaker than faithful algorithmic recovery.</p>
<p>Claim verification and hallucination detection share the evidence-support operation. They are not automatically mathematical duals: a definition of hallucination as lack of support includes unknown cases, while a definition as contradiction includes only refuted cases. Keep the evaluation label convention explicit.</p>
'''))

parts.append(section("preparation", "13. First implementation and preparation tasks", r'''
<p><strong>Start three pieces of work together:</strong> a clean claim-level pilot, a common baseline/evaluation interface, and a small CPU example that learns through probabilistic inference. Table 7 lists the deliverables. The aim is one small end-to-end comparison during the first week.</p>
<p>The 14 October inventory found 2,375 structured claims from 189 source videos. Existing gold-sample packages select 239 distinct claims from 102 videos; many have not been annotated. Provisionally reserving those videos leaves 87 existing videos for new development candidates. Saved gold-v3 annotations cover only 4 claims and 44 targets. These are inventory counts, not a completed new split or a training dataset.</p>
''' + table("First-week preparation.", ["Work", "Initial output", "Completion check"], [
    ("Data inventory and split", "A manifest with original claim, variant group, source video, clip, evidence route, and label/review status.", "All crops and variants of one source video stay together; existing evaluation material is preserved."),
    ("Small data pilot", "40–60 valid supported/false-binding pairs, positive paraphrases, unknown cases, and a small audiovisual subset where feasible.", "The seed and changed relation have evidence; a grammatical edit is not assumed false."),
    ("Common baseline interface", "One runner format for direct, relation-question, and program-based methods, with raw three-way scores and input/cost metadata.", "The same evaluator accepts every method; missing/unknown outputs are not silently counted as refutation."),
    ("Probabilistic-learning example", "A few synthetic logical examples with shared events and categorical evidence states.", "Root distributions normalize; unknown and reused facts behave correctly; the claim loss updates the small classifier."),
    ("First model calls and comparison", "10–20 timing calls, cached whole-claim/full-relation observations, then fixed and learned comparisons.", "Frame/audio/query budgets are explicit; development results are separate from the final test.")
], "These are proposed tasks, not completed dataset preparation or experiments.") + r'''
<p>Reuse the current media/probe runner, parser outputs, and annotation viewer components. Write new three-way evaluation and calibration against independent labels: the older flat postprocessor collapses unknown into unsupported, the old binding edits mainly replace entities from another video, and the old calibrator uses CRF-generated labels.</p>
<p>Record the actual model version, prompt, media interval, sampling, decoding settings, availability, and query cost. A new cache directory per configuration is the initial safeguard against mixing crops or model replacements. Defer full-corpus probing, large synthetic datasets, text-encoder sweeps, and custom inference machinery.</p>
'''))

parts.append(section("llm-data", "14. LLM-assisted data preparation under assistant supervision", r'''
<div class="callout"><strong>Yes: automate candidate construction and much of the training-data review.</strong><p>A local text model can propose fluent edits, logical forms, and targeted questions. Visual/audio models can review each candidate against supplied media. I can maintain prompts, run and inspect batches, check data/code consistency, and revise the process from development errors. Automatically produced labels remain separate from independently checked test labels.</p></div>
<p>Table 8 separates the jobs. Use the existing local Qwen3 text model for candidate generation, Qwen3-VL for visual review, and Qwen3-Omni for audio review. Their documented model directories were checked on 15 October; no new model download is needed for this proposed setup. These are available starting points, not a claim that they are the strongest current models.</p>
''' + table("What the models and assistant do.", ["Step", "Automated work", "Evidence or review needed"], [
    ("Select and describe seed evidence", "A media model proposes event/participant observations, sources, and intervals; code groups them by source video.", "An existing caption or generated description is not automatically a supported seed. Keep its review status."),
    ("Generate claim variants", "The text model proposes one relation edit and a meaning-preserving paraphrase, with the changed relation and supporting observation IDs.", "No new unobserved entities/actions; check symmetry, repeated events, and unchanged content."),
    ("Check the candidate against media", "A visual/audio model receives one shuffled standalone claim and the actual available evidence.", "Do not show the gold pair, edit type, or proposed answer. Missing coverage gives unknown, not an invented negative."),
    ("Filter and organize records", "Code validates JSON, IDs, duplicates, permitted edits, source-video partitions, and provenance; the assistant inspects sampled failures.", "Model agreement is a filter, not proof. Retain disagreements for review rather than making the test artificially easy."),
    ("Build training and test sets", "Automatically labeled examples can form a training pool; the assistant tracks label source and organizes review.", "Audit a stratified training sample and independently check final test labels against media. Human-reviewed labels stay distinguishable from automatic labels.")
], "Model-produced evidence and labels remain automatic annotations until independently checked.") + r'''
<h3>Start with a small prompt-development batch</h3>
<ol>
<li>Choose 10 seed claims with checked evidence and explicit participant/event references. If a seed is only model-proposed, mark that and review it before treating its variants as labeled examples.</li>
<li>Generate at most three variants per seed: an eligible role/event/attribute edit, a supported paraphrase, and optionally a second eligible binding edit. Returning no candidate is allowed.</li>
<li>Run deterministic checks for valid records, duplicates, one intended semantic change, and permitted vocabulary. Then review claims individually against media, without revealing their proposed labels or partners.</li>
<li>I inspect accepted/rejected examples and disagreements, examine accessible evidence and logs, revise prompts on development data, and rerun the affected records. If I have only a model description, my review does not independently certify the underlying event.</li>
<li>Measure how many candidates are usable, their failure types, and label accuracy on an independently reviewed sample before expanding to the 40–60-pair pilot.</li>
</ol>
<p>For each record, keep the source video, seed/variant group, edit type, evidence route, proposed label, reviewer output, final label source, review status, model/prompt versions, and evidence references. Only the intended claim/evidence features enter the classifier; construction metadata and the gold partner do not.</p>
<h3>Training labels and test labels have different requirements</h3>
<p><strong>Training:</strong> automatically labeled examples can provide inexpensive supervision. These are often called <em>silver labels</em>: labels not fully checked by a person. Audit a random sample stratified by edit type, modality, label, and reviewer agreement; inspect difficult disagreements too. Report automatic versus independently reviewed counts separately.</p>
<p><strong>Evaluation:</strong> keep a small independently checked test set. Otherwise a system can score well by reproducing the model that supplied its labels. Freeze prompts and thresholds before the final test; do not retain only examples on which a baseline already agrees with the proposed answer. A second model can reduce some shared errors, but agreement between models is not a correctness guarantee.</p>
<p>Minimal text edits can still introduce language-only clues. Include positive paraphrases, fluent negatives, and a text-only baseline. <a href="https://arxiv.org/abs/2306.14610">SugarCrepe</a> uses language models to construct fluent negatives and addresses benchmark shortcuts. <a href="https://aclanthology.org/2023.acl-long.754/">Self-Instruct</a> establishes a generation/filtering approach for instruction data; it does not establish that generated multimodal claims are true. <a href="https://arxiv.org/abs/2306.05685">LLM-as-a-judge research</a> documents judge biases. Our media-specific review and independent-label policy are design recommendations, not results inherited from those papers.</p>
<h3>Versioned prompt drafts</h3>
<p>The canonical opt-in prompts live in <code>scripts/prompts_phase2.py</code>. Three free-form prompt versions are preserved. Development inspection found that explicit fact assignments followed by <strong>surface realization</strong>—writing those facts as fluent text—was more reliable on the two checked examples than asking the model to invent an edit. This is the current preparation recommendation, with a small pilot rather than a validated general yield. The exact instructions are below. Generation is text-only; media review separately receives the frames/audio. See the pilot section for execution status; earlier inference defaults remain separate.</p>
''' + prompt_preview("Recommended: realize a specified attribute swap", VERIFICATION_REALIZE_SYSTEM)
    + prompt_preview("Free-form candidate-generation prompt (v3, development comparison)", VERIFICATION_DATA_GENERATE_V3_SYSTEM)
    + prompt_preview("Earlier candidate-generation prompt (v2)", VERIFICATION_DATA_GENERATE_V2_SYSTEM)
    + prompt_preview("Revised standalone media-review prompt (v2)", VERIFICATION_DATA_REVIEW_V2_SYSTEM)
    + prompt_preview("Revised baseline-decomposition prompt (v2)", VERIFICATION_DECOMPOSE_V2_SYSTEM)
    + prompt_preview("Initial candidate-generation prompt (v1, preserved)", VERIFICATION_DATA_GENERATE_SYSTEM) + r'''
<p>The user-prompt builders serialize a seed/evidence record or a single claim with media metadata. The standalone review builder deliberately has no argument for a gold label, edit type, or paired claim. This helps avoid accidental hints, while input validation and review are still required.</p>
'''))

parts.append(section("baseline-automation", "15. What can be automated for baselines?", r'''
<p><strong>LLMs can supply predictions and assist implementation; code computes the evaluation.</strong> I can write adapters, launch the local-model calls, validate output records, inspect errors, and implement the evaluator. Split assignment, cache keys, probability checks, metric calculations, and uncertainty estimates should be deterministic code, not an LLM's judgment of its own quality.</p>
<p>Begin with the configurations in Table 9. Reuse cached model observations where inputs match exactly. Keep direct-versus-decomposed query comparisons separate from comparisons that hold the observations fixed.</p>
''' + table("Initial baseline configurations.", ["Configuration", "Model work", "Code work"], [
    ("Whole claim", "A frozen model checks one standalone claim against the supplied evidence.", "Preserve supported/refuted/unknown scores and actual input/cost metadata."),
    ("Whole claim with calibration", "Reuse the same observations.", "Fit temperature scaling or a small classifier on training/development labels, never final test labels."),
    ("Atomic questions", "Ask about individual components with a fixed question budget.", "Apply declared mean/minimum/product score baselines; do not silently interpret every score as a calibrated probability."),
    ("Complete-relation questions", "Check each full predicate–argument tuple, including argument order.", "Use explicit fixed logical composition; this tests whether simpler questions already suffice."),
    ("Probabilistic program", "Reuse the same observations; keep alternative evidence assignments where supplied.", "Run inference with fixed probabilities, then compare a learned linear/MLP relation function under identical data.")
], "Do not present an LLM-derived label as independent gold for the same model's baseline.") + r'''
<p>For direct classification, read class probabilities from the inference backend's output-token scores where available. If scores are unavailable, report hard-label metrics; do not ask the model to invent a confidence distribution. Reserve final test labels from the data-generation/review loop. If models or prompts change, record the configuration and recalibrate only on development data.</p>
''' + prompt_preview("Direct-verification baseline prompt", VERIFICATION_BASELINE_SYSTEM) + r'''
<p>Automate the repeated work, keep a small independently checked evaluation set, and use the first batch to estimate actual label yield and runtime. No fixed percentage of human effort saved or label accuracy is assumed. The pilot below distinguishes completed outputs from submitted jobs.</p>
'''))

parts.append(section("plan", "16. Implementation order and remaining decisions", r'''
<ol>
<li><strong>First three days:</strong> specify the restricted logical forms, observation schema, candidate identifiers, and 40–60-pair pilot. Verify whether cached observations contain binding signal.</li>
<li><strong>Rest of week one:</strong> compile a small set into an existing probabilistic backend; implement explicit supported/refuted/unknown rules; run direct, fixed-rule, and linear-classifier controls.</li>
<li><strong>Week two:</strong> train the small relation classifier through claim-level inference; compare alternative candidate assignments and one module replacement. Add frozen text features only if the numeric input audit gives a reason.</li>
<li><strong>Week three:</strong> evaluate sealed source-video splits, unknown/paraphrase controls, a genuinely audiovisual subset, and temporal constraints. Draft around observed behavior and limitations.</li>
</ol>
<p>Plan roughly 15–35 annotation hours for the scoped pilot/test and 20–100 GPU-hours for frozen-model inference, subject to measured latency and query count. Classifier training should be much cheaper than media inference. These are estimates, not allocated jobs or measured costs. Reuse existing media and cache observations rather than launching a large data-generation campaign.</p>
<details><summary>Decisions still needed during implementation</summary><ul>
<li>Which candidate observations can be matched to stable event/participant identities without building a new tracking system?</li>
<li>Which numeric features distinguish the correct tuple from its role swap?</li>
<li>Do explicit unknown labels and candidate-coverage rules provide enough supervision for refuted versus unavailable evidence?</li>
<li>Does a text encoder improve relation prediction after controlling media observations and training labels?</li>
<li>Which fixed-rule and learned-function configurations can be recovered exactly under the same program semantics?</li>
<li>How much calibration must be refitted after a perception module is replaced?</li>
</ul></details>
<p><strong>Terminology:</strong> use familiar terms such as semantic parsing, logical form, semantic role, grounding, relation classifier, neural predicate, conditional distribution, probabilistic inference, and calibration. Define them when first used. Do not invent names for ordinary components or use a new acronym to make the method sound novel.</p>
<p>The accepted project decision is recorded in ADR-023. The earlier tree-CRF and temporal-only recommendations remain historical comparisons; they do not override the chosen paper direction. This page is a design draft, not a report of completed training or validated gains.</p>
'''))

pilot_note = ROOT / "exp/probabilistic_verification/pilot_20261015/page_update.html"
if pilot_note.exists():
    parts.append(section("pilot", "17. First local-model pilot: 15 October 2026", pilot_note.read_text()))
    parts.append(section("generated-examples", "18. Generated examples and what the review found", generated_examples()))

toc = [
    ("direction", "Paper direction"), ("overview", "Processing stages"),
    ("compilation", "Claim compilation"), ("evidence", "Evidence and candidates"),
    ("architecture", "Neural network choices"), ("probability", "Probability and inference"),
    ("example", "Interactive example"), ("learning", "Learning"),
    ("time", "Temporal constraints"), ("data", "Data"),
    ("experiments", "Experiments"), ("prior", "Prior work"),
    ("preparation", "First preparation tasks"), ("llm-data", "LLM-assisted data"),
    ("baseline-automation", "Baseline automation"), ("plan", "Implementation plan")
]
if pilot_note.exists():
    toc.append(("pilot", "Initial pilot"))
    toc.append(("generated-examples", "Generated examples"))
toc_html = "".join(f'<a href="#{key}">{label}</a>' for key, label in toc)

STYLE = r'''
.container { max-width:1100px; }
.verification-tabs { display:flex; gap:10px; flex-wrap:wrap; margin:22px 0; }
.verification-tabs a { padding:9px 14px; border:1px solid var(--border); border-radius:8px; text-decoration:none; }
.verification-tabs a[aria-current=page] { background:var(--accent-soft); font-weight:700; }
.hero h1 { font-size:clamp(34px,5vw,58px); }
.paper-section { margin:0 0 48px; padding-top:8px; scroll-margin-top:88px; }
.paper-section h2 { font-size:clamp(25px,3vw,34px); }
caption { padding:14px 16px; text-align:left; color:var(--muted); font-size:14px; line-height:1.5; background:var(--surface-2); }
th,td { vertical-align:top; overflow-wrap:break-word; }
pre { overflow-x:auto; padding:18px; border:1px solid var(--border); border-radius:10px; background:var(--surface-2); font-size:13px; line-height:1.6; }
.pipeline { list-style:none; display:grid; grid-template-columns:1fr 1fr; gap:12px; padding:0 !important; counter-reset:stage; }
.pipeline li { padding:16px; border:1px solid var(--border); border-radius:10px; background:var(--surface); margin:0 !important; counter-increment:stage; }
.pipeline li:before { content:counter(stage); display:block; color:var(--accent); font-size:13px; margin-bottom:6px; }
.pipeline strong,.pipeline span { display:block; }
.pipeline span { color:var(--muted); font-size:14px; margin-top:8px; }
figure { margin:24px 0; }
.example-figure { padding:18px; border:1px solid var(--border); border-radius:12px; background:var(--surface); }
.example-events,.example-controls { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:16px; }
.example-events>div { padding:12px; background:var(--surface-2); border-radius:8px; }
.example-events p { margin:6px 0 0; }
.example-controls label { display:flex; flex-direction:column; gap:6px; font-size:14px; }
select { width:100%; color:var(--text); background:var(--surface); padding:10px; border:1px solid var(--border); border-radius:6px; font:inherit; }
.coverage-control { display:flex; gap:9px; align-items:flex-start; font-size:14px; }
input[type=checkbox] { margin-top:6px; }
output { display:block; margin:16px 0; padding:14px; border-left:3px solid var(--accent); background:var(--accent-soft); }
.equation { font-size:16px; }
.reference-note { margin-top:12px; color:var(--muted); font-size:14px; }
.generated-examples { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:20px; }
.generated-case { min-width:0; padding:20px; border:1px solid var(--border); border-radius:12px; background:var(--surface); scroll-margin-top:96px; }
.generated-case h3 { margin-top:0; font-size:23px; }
.generated-case blockquote { margin:8px 0 16px; padding:12px 14px; border-left:3px solid var(--accent); background:var(--surface-2); overflow-wrap:break-word; }
.generated-case .example-label { margin-bottom:4px; font-weight:650; font-size:14px; }
.generated-evidence { display:flex; justify-content:center; gap:12px; padding:8px; background:var(--surface-2); }
.generated-evidence img { max-height:300px; max-width:100%; object-fit:contain; }
.generated-evidence.two-frames img { width:calc(50% - 6px); }
.generated-wide { grid-column:1 / -1; }
@media(max-width:760px) { .generated-examples { grid-template-columns:1fr; } }
@media(max-width:620px) { .pipeline,.example-events,.example-controls { grid-template-columns:1fr; } .table-wrap { max-width:100%; } table { min-width:610px; } }
'''

INTERACTION = r'''
const agentSelect = document.getElementById('example-agent');
const themeSelect = document.getElementById('example-theme');
const completeSelect = document.getElementById('example-complete');
const resultOutput = document.getElementById('example-result');
function evaluateExample(agent, theme, complete) {
  const match = (agent === 'Alice' && theme === 'Bob') || (agent === 'Carol' && theme === 'Dave');
  const claim = `${agent} hugging ${theme}`;
  if (match) return `Supported: one listed event supports ${claim} with both roles attached to that event.`;
  if (complete) return `Refuted in this complete toy example: neither of its two events supports ${claim}.`;
  return `Unknown: no listed event supports ${claim}, and coverage is incomplete.`;
}
function updateExample() {
  resultOutput.textContent = evaluateExample(agentSelect.value, themeSelect.value, completeSelect.checked);
}
[agentSelect, themeSelect, completeSelect].forEach(control => control.addEventListener('change', updateExample));
updateExample();
'''

document = r'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Accepted paper direction and design draft: semantic parsing into probabilistic logic, frozen multimodal evidence, and small learned relation classifiers for binding verification.">
  <title>Probabilistic parsing for multimodal claim verification · AViD</title>
  <link rel="stylesheet" href="../assets/site.css">
  <style>STYLE_CONTENT</style>
  <script>window.MathJax = { tex: { inlineMath: [['\\(', '\\)']], displayMath: [['\\[', '\\]']] }, svg: { fontCache: 'global' } };</script>
  <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
</head>
<body>
  <nav class="site-nav" aria-label="Primary navigation"><div class="nav-inner"><a class="brand" href="../index.html">SCALE 2026 · AViD</a><div class="nav-links"><a href="../index.html">Home</a><a href="../reports/tree-crf.html">Tree-CRF verifier</a><a href="./" aria-current="page">Proposals</a></div></div></nav>
  <main>
    <header class="hero"><div class="container">
      <p class="eyebrow">Paper direction adopted · 14 October 2026</p>
      <h1>Probabilistic parsing for multimodal claim verification</h1>
      <p class="lede">Compile claims into probabilistic logic, use frozen media models for evidence, and learn small relation classifiers to check who did what to whom.</p>
      <div class="button-row"><a class="button primary" href="#preparation">First preparation tasks</a><a class="button" href="#llm-data">LLM-assisted data</a><a class="button" href="#architecture">Model design</a><a class="button" href="./">All proposals</a></div>
      <nav class="verification-tabs" aria-label="Verification project"><a href="probabilistic-verification.html" aria-current="page">Paper design</a><a href="#generated-examples">Generated examples</a><a href="../reports/verification-pipeline.html">Implementation</a></nav>
      <p class="meta">Chosen paper direction; implementation design draft. The Implementation tab shows an executed compiler, DeepProbLog inference, and sample training on two development claims. Held-out method gains remain unmeasured.</p>
    </div></header>
    <section class="section"><div class="container split"><aside class="toc" aria-label="On this page"><strong>On this page</strong>TOC_CONTENT</aside><article class="prose">BODY_CONTENT</article></div></section>
  </main>
  <footer class="site-footer"><div class="container">SCALE 2026 · AViD · Updated DATE_CONTENT · Generated by <code>scripts/build_probabilistic_verification_proposal.py</code>. Equations use MathJax from a CDN.</div></footer>
  <script>INTERACTION_CONTENT</script>
</body>
</html>
'''
for marker, value in [("STYLE_CONTENT", STYLE), ("DATE_CONTENT", DATE), ("TOC_CONTENT", toc_html), ("BODY_CONTENT", "\n".join(parts)), ("INTERACTION_CONTENT", INTERACTION)]:
    document = document.replace(marker, value)
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
OUTPUT.write_text(document, encoding="utf-8")
print(f"Wrote {OUTPUT}: {len(document.encode('utf-8')):,} bytes; {TABLE_NUMBER} tables")
