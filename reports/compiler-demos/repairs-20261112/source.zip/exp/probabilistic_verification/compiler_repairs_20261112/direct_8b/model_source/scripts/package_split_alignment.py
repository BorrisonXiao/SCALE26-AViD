"""Package a dated experiment overlay without replacing historical bundles."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/split_alignment_20261112'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--allow-missing-history', action='store_true')
    args = parser.parse_args()
    names = ['scripts/prompts_phase2.py', 'scripts/probabilistic_verification/sentence_simplification.py', 'scripts/probabilistic_verification/split_alignment.py', 'scripts/run_claim_split_model.py', 'scripts/run_split_alignment_census.py', 'scripts/evaluate_split_alignment.py', 'scripts/analyze_split_alignment.py', 'scripts/split_alignment_report.py', 'scripts/package_split_alignment.py', 'scripts/check_split_alignment_browser.py', 'scripts/build_compiler_demos.py', 'scripts/build_verification_pipeline_report.py', 'scripts/claim_split_report.py', 'scripts/report_assets/split_alignment.js', 'scripts/report_assets/compiler_demos.css', 'tests/test_split_alignment.py', 'docs/split_alignment_20261112.md', 'docs/project_notes/daily_log.json', 'AGENTS.md', 'CLAUDE.md', 'docs/project_notes/key_facts.md', 'docs/project_notes/decisions.md', 'docs/project_notes/issues.md', 'docs/project_notes/terminology.md', 'site/reports/index.html', 'exp/probabilistic_verification/av_features_20261022/checklist.json']
    data = {n: (ROOT / n).read_bytes() for n in names}
    excluded = {'publication.json', 'browser_checks.json', 'archive_verification.json',
                'final_source_sha256.json', 'WORK_STATUS.md'}
    for path in sorted(RUN.rglob('*')):
        if path.is_file() and path.suffix in {'.json', '.jsonl', '.xml', '.py', '.out', '.err'} and path.name not in excluded:
            data[str(path.relative_to(ROOT))] = path.read_bytes()
    freeze = {n: hashlib.sha256(body).hexdigest() for n, body in data.items()}
    (RUN / 'final_source_sha256.json').write_text(json.dumps(freeze, indent=2) + '\n')
    data[str((RUN / 'final_source_sha256.json').relative_to(ROOT))] = (RUN / 'final_source_sha256.json').read_bytes()
    data['README_SPLIT_ALIGNMENT.md'] = (ROOT / 'docs/split_alignment_20261112.md').read_bytes()
    data['SPLIT_ALIGNMENT_SHA256SUMS'] = ''.join(
        hashlib.sha256(body).hexdigest() + '  ' + name + '\n'
        for name, body in sorted(data.items())).encode()
    target = ROOT / 'site/reports/compiler-demos/alignment-20261112/source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, body in sorted(data.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, body)
    missing = []
    for name, digest in json.loads((RUN / 'preserved_archives.json').read_text()).items():
        path = ROOT / name
        if path.exists():
            assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
        else:
            missing.append(name)
    assert args.allow_missing_history or not missing, missing
    for name, digest in json.loads((RUN / 'compiler_freeze.json').read_text())['source_sha256'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    for name, digest in json.loads((ROOT / 'exp/probabilistic_verification/claim_rewrite_20261111/viewer_sha256.json').read_text()).items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    print('Packaged', len(data), 'files;', round(target.stat().st_size / 1048576, 2),
          'MiB. Frozen compiler, historical archives and original viewer data preserved.')


if __name__ == '__main__':
    main()
