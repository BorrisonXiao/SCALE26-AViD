#!/usr/bin/env python3
"""
AViD Phase 2 — render a compact, human-readable view of support_annotation.tsv.

The full support_annotation.tsv (build_support_annotation.py) is the machine
surface: per-channel verdicts, per-channel probabilities, ids, types, raw +
highlighted claim text. This script distills it to a glance-able TSV for manual
review/analysis.

Reductions:
  - Drop id/type metadata (unit_id, unit_type, node_type) and the unmarked
    claim_text (claim_highlighted already shows the unit, marked with **).
  - Drop all probability columns.
  - Collapse the 4 channel-verdict columns into 2 per-modality cells. This is
    lossless given the pipeline's mutually-exclusive design (ADR-006): within a
    modality pass-1=yes implies exactly one subtype fires, pass-1=no implies
    both 'no', pass-1=unknown (or no_video) implies both 'unknown'. So each
    modality reduces to ONE categorical outcome:
        visual ∈ {text, other, no, unknown, no_video}   (text = on-screen OCR)
        audio  ∈ {speech, other, no, unknown, no_video}
    The no_video data-condition is folded into the cell value (it is the reason
    a prediction is missing), so no separate column is needed.
  - For r5, join the LLM-formulated per-modality questions (the pass-1 stems
    actually shown to the verifier) so they sit next to the prediction.
  - For r5e (explain variant), additionally pass --verify-visual/--verify-audio
    to add visual_why/audio_why columns (the verifier's pass-1 reason).

Column order is chosen so the narrow, essential columns (the predictions) are
all on the left — visible without horizontal scrolling and never pushed right by
a long unit/claim cell — and the wide text columns are last:

    claim_id | status | visual | audio | unit | claim | visual_q | audio_q

Usage:
    python scripts/make_readable_support.py            # r5 defaults
    # r5e (with model reasons):
    python scripts/make_readable_support.py \\
        --support exp/phase2/prompt_ablation/r5e/support_annotation.tsv \\
        --formulated exp/phase2/prompt_ablation/formulated_questions.tsv \\
        --verify-visual exp/phase2/prompt_ablation/r5e/verify_visual.jsonl \\
        --verify-audio  exp/phase2/prompt_ablation/r5e/verify_audio.jsonl \\
        --output exp/phase2/prompt_ablation/r5e/support_readable.tsv
"""

import argparse
import csv
import json
from pathlib import Path

_AVID = Path("/exp/cxiao/scale26/avid")
DEFAULT_SUPPORT    = str(_AVID / "exp/phase2/prompt_ablation/r5/support_annotation.tsv")
DEFAULT_FORMULATED = str(_AVID / "exp/phase2/prompt_ablation/formulated_questions.tsv")
DEFAULT_OUTPUT     = str(_AVID / "exp/phase2/prompt_ablation/r5/support_readable.tsv")


def collapse(verdict_a: str, verdict_b: str, label_a: str, label_b: str,
             no_video: bool) -> str:
    """Collapse a modality's two mutually-exclusive subtype verdicts to one cell."""
    if no_video:
        return "no_video"
    if verdict_a == "yes":
        return label_a
    if verdict_b == "yes":
        return label_b
    if verdict_a == "no" and verdict_b == "no":
        return "no"
    return "unknown"


def load_formulated(path: str) -> dict[tuple[str, str], dict]:
    out: dict[tuple[str, str], dict] = {}
    p = Path(path)
    if not path or not p.exists():
        return out
    with open(p, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            key = (row.get("claim_id", "").strip(), row.get("unit_id", "").strip())
            out[key] = {
                "visual_q": (row.get("visual_question") or "").strip(),
                "audio_q":  (row.get("audio_question")  or "").strip(),
            }
    return out


def load_explanations(path: str) -> dict[tuple[str, str], str]:
    """Pass-1 reasons from a verify_{modality}.jsonl (r5e run) → {(cid,uid): why}.

    When pass1_explanation is absent (model emitted only the verdict letter or
    nothing — both collapse to an empty string after _clean_reason), falls back
    to "{verdict} — (no reason)" so the why column is never silently blank.
    """
    out: dict[tuple[str, str], str] = {}
    p = Path(path)
    if not path or not p.exists():
        return out
    with open(p, encoding="utf-8") as f:
        for line in f:
            o = json.loads(line)
            key = (str(o.get("claim_id", "")).strip(),
                   str(o.get("unit_id", "")).strip())
            why = (o.get("pass1_explanation") or "").strip()
            if not why:
                v = (o.get("pass1_verdict") or "").strip()
                if v:
                    why = f"{v} — (no reason)"
            if key[0] and key[1] and why:
                out[key] = why
    return out


def main():
    ap = argparse.ArgumentParser(description="Render a readable support TSV view.")
    ap.add_argument("--support",    default=DEFAULT_SUPPORT)
    ap.add_argument("--formulated", default=DEFAULT_FORMULATED,
                    help="formulated_questions.tsv (r5); omit/empty to drop the "
                         "question columns for non-r5 variants.")
    ap.add_argument("--verify-visual", default="",
                    help="verify_visual.jsonl from an explain run (r5e); adds a "
                         "visual_why column with the model's pass-1 reason.")
    ap.add_argument("--verify-audio", default="",
                    help="verify_audio.jsonl from an explain run (r5e); adds an "
                         "audio_why column with the model's pass-1 reason.")
    ap.add_argument("--output",     default=DEFAULT_OUTPUT)
    args = ap.parse_args()

    formulated = load_formulated(args.formulated)
    vis_why = load_explanations(args.verify_visual)
    aud_why = load_explanations(args.verify_audio)
    has_questions = bool(formulated)
    has_why = bool(vis_why or aud_why)

    fields = ["claim_id", "status", "visual", "audio", "unit", "claim"]
    if has_questions and has_why:
        fields += ["visual_q", "visual_why", "audio_q", "audio_why"]
    elif has_questions:
        fields += ["visual_q", "audio_q"]
    elif has_why:
        fields += ["visual_why", "audio_why"]

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    n = 0
    with open(args.support, newline="", encoding="utf-8") as fin, \
         open(out_path, "w", newline="", encoding="utf-8") as fout:
        reader = csv.DictReader(fin, delimiter="\t")
        writer = csv.DictWriter(fout, fieldnames=fields, delimiter="\t",
                                lineterminator="\n", quoting=csv.QUOTE_MINIMAL)
        writer.writeheader()
        for r in reader:
            no_video = (r.get("no_video", "").strip().lower() == "true")
            visual = collapse(r["support_visual_ocr"], r["support_visual_other"],
                              "text", "other", no_video)
            audio  = collapse(r["support_audio_speech"], r["support_audio_other"],
                              "speech", "other", no_video)
            out = {
                "claim_id": r["claim_id"],
                "unit":     r["unit_text"],
                "status":   r["status"],
                "visual":   visual,
                "audio":    audio,
                "claim":    r["claim_highlighted"],
            }
            key = (r["claim_id"], r["unit_id"])
            if has_questions:
                fq = formulated.get(key, {})
                out["visual_q"] = fq.get("visual_q", "")
                out["audio_q"]  = fq.get("audio_q", "")
            if has_why:
                out["visual_why"] = vis_why.get(key, "")
                out["audio_why"]  = aud_why.get(key, "")
            writer.writerow(out)
            n += 1

    print(f"Wrote {n} rows → {out_path}")
    print(f"Columns: {fields}")


if __name__ == "__main__":
    main()
