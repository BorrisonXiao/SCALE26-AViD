"""Inspect all62 comparisons, full-corpus rates, exact requests and navigation."""
import functools,http.server,json,threading
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/split_alignment_20261112'


def main():
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'site')))
    threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
    cases=json.loads((RUN/'cases.json').read_text())
    with sync_playwright()as p:
        browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1000})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(base+'/reports/compiler-demos.html#split-alignment',wait_until='networkidle');page.wait_for_selector('#alignment-case option',state='attached')
        assert page.locator('[role="tab"]').count()==8
        assert '81.09%'in page.locator('#split-alignment table').first.inner_text()
        checked=0
        for condition in ['sentences','old_sentences']:
            page.select_option('#alignment-condition',condition)
            assert page.locator('#alignment-case option').count()==31
            for row in [r for r in cases if r['condition']==condition]:
                page.select_option('#alignment-case',row['claim_id'])
                assert page.locator('#alignment-original').text_content()==row['original']
                assert row['review']['reason']in page.locator('#alignment-review').text_content()
                for selector,text in [('#alignment-system',row['request']['messages'][0]['content']),('#alignment-user',row['request']['messages'][1]['content']),('#alignment-response',row['request']['raw'])]:
                    assert page.locator(selector).text_content()==text
                    assert page.locator(selector).evaluate('(e)=>e.closest("details")===null')
                if row['output']['status']=='compiled':assert page.locator('#alignment-graph .cv-node').count()>0
                checked+=1
        for cid in ['TFgw4IaR9R8s_1587','TMrQshDs8aH0_750','TgR_u37mCoQ4_1860','TgR_u37mCoQ4_1916','TW4OYA3RN-Hw_1766']:
            page.goto(base+'/reports/compiler-demos.html?alignment='+cid+'&alignment_condition=sentences#alignment-example',wait_until='networkidle')
            assert page.locator('#alignment-case').input_value()==cid
            assert page.locator('#sentence-splitting').is_visible()
        page.goto(base+'/reports/compiler-demos.html?alignment=TFgw4IaR9R8s_1587&alignment_condition=sentences#alignment-example',wait_until='networkidle')
        page.evaluate('document.documentElement.style.scrollBehavior="auto";document.querySelector("#alignment-example").scrollIntoView({behavior:"instant",block:"start"})')
        page.screenshot(path=str(RUN/'example_desktop.png'))
        assert 'visual depiction'in page.locator('#alignment-graph').inner_text().lower()
        page.evaluate('document.querySelector("#alignment-graph").scrollIntoView({behavior:"instant",block:"start"})');page.screenshot(path=str(RUN/'graph_desktop.png'))
        page.set_viewport_size({'width':390,'height':844});page.emulate_media(color_scheme='dark');page.wait_for_timeout(200)
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
        page.evaluate('document.querySelector("#alignment-system").scrollIntoView({behavior:"instant",block:"start"})');page.screenshot(path=str(RUN/'prompt_mobile_dark.png'))
        page.goto(base+'/reports/compiler-demos.html#daily-progress',wait_until='networkidle')
        page.locator('#day-2026-11-12 a[href="#current-corpus-rate"]').click();page.wait_for_selector('#sentence-splitting',state='visible')
        page.click('[data-tab="walkthroughs"]');assert page.locator('#demo-select option').count()==41
        page.click('[data-tab="outputs"]');assert '2375'in page.locator('#all-count').inner_text()
        page.goto(base+'/reports/compiler-demos.html#split-example',wait_until='networkidle');assert page.locator('#split-case option').count()==8
        for name in ['summary.json','corpus_summary.json','cases.json','raw.jsonl','recoveries.json','README.md','source.zip']:
            assert page.request.get(base+'/reports/compiler-demos/alignment-20261112/'+name).ok,name
        assert not errors,errors
        proof=dict(cases_checked=checked,exact_requests_checked=62,tabs=8,example_links=5,old_demos=41,original_claims=2375,old_manual_cases=8,mobile_overflow=False,page_errors=errors)
        (RUN/'browser_checks.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof);browser.close()
    server.shutdown()


if __name__=='__main__':main()
