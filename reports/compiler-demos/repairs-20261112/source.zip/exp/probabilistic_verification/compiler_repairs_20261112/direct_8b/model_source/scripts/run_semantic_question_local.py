#!/usr/bin/env python3
"""Copy-edit semantic probe questions with an already-cached local Qwen model.

This is the privacy-preserving fallback for environments where the production
GPU scheduler is unavailable and AViD claim text may not be sent to an external
service.  It changes wording only; graph structure and normalization remain
frozen.  Every model result is schema-validated and missing/malformed records
continue to use the deterministic compiler wording.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from prompts_phase2 import SEMANTIC_QUESTION_PROMPT_VERSION, SEMANTIC_QUESTION_SYSTEM
from run_semantic_text_pass import make_question_items, valid_questions
from semantic_factor_tree import read_jsonl, write_jsonl


ROOT = Path("/exp/cxiao/scale26/avid")
DEFAULT_INPUT = ROOT / "exp/phase3/semantic_v1/semantic_factor_trees.jsonl"
DEFAULT_OUTPUT = ROOT / "exp/phase3/semantic_v1/questions_local_qwen3_06b.jsonl"
DEFAULT_MODEL = Path(
    "/exp/cxiao/.cache/huggingface/hub/models--Qwen--Qwen3-0.6B/"
    "snapshots/c1899de289a04d12100db370d81485cdf75e47ca"
)


def extract_json(text: str) -> dict[str, Any]:
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start:end + 1])
        raise


def item_prompt(item: dict[str, Any]) -> str:
    record = {
        "claim": item["claim_reference_only"],
        "target_kind": item["target_kind"],
        "semantic_type": item["semantic_type"],
        "target_text": item["target_text"],
        "allowed_arguments": item["allowed_endpoints"],
    }
    return (
        f"{SEMANTIC_QUESTION_SYSTEM}\n\n"
        "Rewrite this one record. Preserve its meaning. Return exactly one JSON object "
        "with display_text, visual_question, and audio_question; no markdown.\n"
        f"{json.dumps(record, ensure_ascii=False)}"
    )


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    ap.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    ap.add_argument("--model", type=Path, default=DEFAULT_MODEL)
    ap.add_argument("--batch-size", type=int, default=6)
    ap.add_argument("--max-new-tokens", type=int, default=144)
    ap.add_argument("--limit-items", type=int)
    ap.add_argument("--claim-id", action="append", default=[])
    ap.add_argument("--threads", type=int, default=16)
    args = ap.parse_args()

    records = read_jsonl(args.input)
    if args.claim_id:
        wanted = set(args.claim_id)
        records = [r for r in records if r["claim_id"] in wanted]
    items = [i for i in make_question_items(records) if i["target_id"] != "compose:root"]
    if args.limit_items is not None:
        items = items[:args.limit_items]

    torch.set_num_threads(max(1, args.threads))
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    model = AutoModelForCausalLM.from_pretrained(
        args.model, local_files_only=True, torch_dtype=torch.bfloat16,
    ).eval()

    raw_rows: list[dict[str, Any]] = []
    failures: list[dict[str, str]] = []
    for start in range(0, len(items), args.batch_size):
        batch = items[start:start + args.batch_size]
        chats = [
            tokenizer.apply_chat_template(
                [{"role": "user", "content": item_prompt(item)}],
                tokenize=False, add_generation_prompt=True, enable_thinking=False,
            )
            for item in batch
        ]
        encoded = tokenizer(chats, return_tensors="pt", padding=True)
        with torch.inference_mode():
            output = model.generate(
                **encoded, max_new_tokens=args.max_new_tokens, do_sample=False,
                eos_token_id=tokenizer.eos_token_id, pad_token_id=tokenizer.pad_token_id,
            )
        generated = output[:, encoded["input_ids"].shape[1]:]
        texts = tokenizer.batch_decode(generated, skip_special_tokens=True)
        for item, text in zip(batch, texts):
            try:
                row = extract_json(text)
                row.update({"claim_id": item["claim_id"], "target_id": item["target_id"]})
                raw_rows.append(row)
            except (json.JSONDecodeError, TypeError, ValueError) as exc:
                failures.append({
                    "claim_id": item["claim_id"], "target_id": item["target_id"],
                    "reason": f"{type(exc).__name__}: {text[:240]}",
                })
        print(f"local questions: {min(start + len(batch), len(items))}/{len(items)}")

    valid = valid_questions(raw_rows)
    valid_keys = {(r["claim_id"], r["target_id"]) for r in valid}
    for row in raw_rows:
        key = (row["claim_id"], row["target_id"])
        if key not in valid_keys:
            failures.append({"claim_id": key[0], "target_id": key[1], "reason": "schema_rejected"})
    for row in valid:
        row["source"] = f"local-qwen3-0.6b:{SEMANTIC_QUESTION_PROMPT_VERSION}"

    args.output.parent.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.output, valid)
    write_jsonl(args.output.with_suffix(".failures.jsonl"), failures)
    manifest = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "backend": "local-transformers", "model": str(args.model),
        "prompt_version": SEMANTIC_QUESTION_PROMPT_VERSION,
        "input_items": len(items), "valid_items": len(valid), "failures": len(failures),
        "external_claim_transmission": False,
    }
    args.output.with_suffix(".manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
