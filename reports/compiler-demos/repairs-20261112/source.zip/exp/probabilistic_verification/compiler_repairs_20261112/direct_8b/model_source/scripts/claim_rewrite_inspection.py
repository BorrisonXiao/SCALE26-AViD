"""Expose saved rewrite requests and compile-first routing without new model calls."""
import json,shutil
from html import escape as esc
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PILOT=ROOT/'exp/probabilistic_verification/claim_rewrite_20261111'
RUN=ROOT/'exp/probabilistic_verification/rewrite_inspection_20261112'
def read(path):return list(map(json.loads,path.read_text().splitlines()))
def load(path):return json.loads(path.read_text())

def build():
    plan=load(RUN/'plan_raw.routing.json');routes={r['claim_id']:r for r in plan['routes']}
    conditions={}
    for key,folder in [('initial','initial_prompt'),('revised','diagnostic_prompt')]:
        directory=PILOT/folder
        conditions[key]=dict(raw={r['claim_id']:r for r in read(directory/'pilot_raw.jsonl')},
            config=load(directory/'pilot_raw.config.json'),
            results={r['claim_id']:r for r in read(directory/'pilot_compilation.jsonl')},
            reviews={r['claim_id']:r for r in load(directory/'semantic_review.json')['cases']})
    cases={};summary=dict(total=40,strict_failures=31,direct_passes_skipped=9,conditions={})
    for cid,route in routes.items():
        cases[cid]=dict(route=route,conditions={})
        for key,condition in conditions.items():
            raw=condition['raw'][cid];result=condition['results'][cid];review=condition['reviews'][cid]
            if not route['rewrite_eligible']:stage='Historical diagnostic probe; direct compilation already passed'
            elif review['accepted']:stage='Reviewed recovery'
            elif result['proposal']['action']=='rewrite' and result['proposal']['text']==result['original']['text']:stage='No text edit was made'
            elif review['rewrite_faithful'] is False:stage='The rewrite changes the claim'
            elif result['rewritten']['status']!='compiled':stage='The rewritten text still fails compilation'
            elif review['compiled_faithful'] is False:stage='The rewritten text compiles with the wrong meaning'
            else:stage='The compiled structure still needs a semantic contract or review'
            cases[cid]['conditions'][key]=dict(messages=raw['messages'],raw_response=raw['raw'],
                input_tokens=raw['input_tokens'],output_tokens=raw['output_tokens'],finish_reason=raw['finish_reason'],
                failure_stage=stage,review_reason=review['reason'],accepted=review['accepted'],
                rewritten_status=result['rewritten']['status'],rewritten_code=result['rewritten'].get('code'),
                rewritten_reason=result['rewritten'].get('reason'))
    for key,condition in conditions.items():
        eligible=[cid for cid,r in routes.items()if r['rewrite_eligible']]
        summary['conditions'][key]=dict(eligible=31,reviewed_recoveries=sum(condition['reviews'][cid]['accepted']for cid in eligible),
            rejected= sum(not condition['reviews'][cid]['accepted']for cid in eligible),
            critical_proposals=sum(condition['reviews'][cid]['critical_change']for cid in eligible),
            proposed_diagnostic_changes=sum(condition['results'][cid]['proposal']['text']!=condition['results'][cid]['original']['text']for cid in routes if not routes[cid]['rewrite_eligible']))
    assert len(cases)==40 and sum(r['route']['rewrite_eligible']for r in cases.values())==31
    assert summary['conditions']['revised']['reviewed_recoveries']==3
    data=dict(model_configs={k:c['config']for k,c in conditions.items()},cases=cases,routing_summary=summary,
        provenance='Exact historical messages and responses, not reconstructed prompts. Routing recalculated with the unchanged direct compiler. No new model call.')
    (RUN/'inspection.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    (RUN/'routing_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    return data


def routing_html():
    return '''<section id="rewrite-routing"><h3>12 November: rewrite only after direct compilation fails</h3><p><b>Direct compilation first → keep a passing result unchanged → request a rewrite only for a strict compilation failure → compile the rewrite → review against the original claim.</b> A saved diagnostic candidate can exist while its content check fails; that still counts as a direct compilation failure. A claim that passes these checks is not sent to the rewriter, even when a separate semantic review finds it imperfect.</p><p>The generation runner now enforces this before loading the language model. A CPU routing check of the original 40 pilot cases selects <b>31 failures</b> and skips <b>nine direct passes</b>. No new model request was made. The earlier full-corpus replacement run already kept directly compiled claims unchanged.</p><p>The historical pilot deliberately queried eight passing controls and one ambiguous passing guard as diagnostic probes. Their outputs remain inspectable, but those nine cases are <b>outside the requested fallback path</b>. The reported two proposed control regressions were never applied to the full corpus.</p><p>Within the 31 genuine fallback cases, the initial prompt has one reviewed recovery and 30 rejections; the revised prompt has three recoveries and 28 rejections. The revised three are the two target recoveries and the exact-quotation guard. These are the same saved results under a clearer routing definition, not a new experiment or accuracy estimate.</p><p><a href="compiler-demos/rewrite-inspection-20261112/routing_summary.json">Failure-only counts</a> · <a href="compiler-demos/rewrite-inspection-20261112/inspection.json">All exact requests and diagnoses</a> · <a href="compiler-demos/rewrite-inspection-20261112/source.zip">Routing/report source update</a> · <a href="compiler-demos/rewrite-inspection-20261112/README.md">Reproduction</a></p></section>'''


def examples_html():
    examples=[
        ('TFgw4IaR9R8s_1587','Invented participant','Image of Trump holding up a signed document.','Image of Trump holding up a signed document, which he signed.','A signed document does not tell us who signed it. The rewrite assigns that action to Trump; compilation also still rejects the media modifier.'),
        ('Tg0UxWYuPeJ0_433','Wrong actor after compilation','Robot 1 sweep kicks Robot 2','Robot 1 sweep kicks Robot 2.','Adding a period retains Robot 2, but the compiler makes sweep the actor of kick, with Robot 1 as its modifier. The text edit is faithful; the compiled binding is wrong.'),
        ('Txf2EdqOg1SQ_2350','A speed range becomes an object count','Wipha is moving northwest at a speed of 20-25 km/h.','Wipha is moving northwest at a speed of 20 to 25 km/h.','The rewritten English preserves the speed range. The compiler treats km/h as an entity with count bounds 20 and 25, rather than a velocity interval. The conservative numeric-string check also flags the formatting change.'),
        ('Txf2EdqOg1SQ_2185','No rewrite despite the model’s explanation',None,None,'The model describes how to fix a duplicated semantic role but returns exactly the original sentence. The same duplicate-role failure remains.'),
        ('TgR_u37mCoQ4_1901','Equivalent English, wrong negation scope','The video has no audio.','The video does not have any audio.','The paraphrase is faithful. The compiler introduces an audio entity outside the negation, then negates having that entity. It does not express the absence of any audio.')]
    h='<section id="rewrite-failed-examples"><h3>Five failures to inspect</h3><p>All five original claims fail strict direct compilation. The examples distinguish a bad rewrite from a faithful rewrite that the compiler still handles incorrectly. Diagnoses are the compiler-author assistant’s judgments.</p>'
    for cid,title,original,new,reason in examples:
        h+='<article class="remaining-case"><h4>'+esc(title)+'</h4>'
        if original:h+='<p><b>Original:</b> '+esc(original)+'</p><p><b>Revised-prompt output:</b> '+esc(new)+'</p>'
        h+='<p>'+esc(reason)+'</p><p><a href="compiler-demos.html?rewrite='+cid+'#rewrite-case-inspector">Inspect this case, exact prompt and response</a></p></article>'
    return h+'</section>'


def prompt_html():
    return '''<section id="rewrite-exact-request"><h3>Exact prompt and model for the selected case</h3><p>These messages come directly from the saved request. The system instruction is shown in full; the user message contains the original claim, dependency links and semantic-role spans. The revised prompt also includes the original compiler diagnostic. No truth label, media observation or intended-reading annotation is included.</p><label for="rewrite-prompt-condition">Inspect saved request from</label><select id="rewrite-prompt-condition"><option value="revised">Revised prompt with compiler diagnostic</option><option value="initial">Initial clarity prompt</option></select><p id="rewrite-model-config"></p><p id="rewrite-prompt-stage" class="note"></p><p id="rewrite-prompt-review"></p><h4>System instruction — exact text</h4><p id="rewrite-system-prompt" style="white-space:pre-wrap"></p><h4>User message — exact text</h4><pre id="rewrite-user-prompt"></pre><h4>Model response — exact text</h4><pre id="rewrite-raw-response"></pre><p><a id="rewrite-share-case" href="#rewrite-case-inspector">Link to this case and prompt</a></p></section>'''


def write_downloads():
    build();folder=ROOT/'site/reports/compiler-demos/rewrite-inspection-20261112';folder.mkdir(parents=True,exist_ok=True)
    for name in ['inspection.json','routing_summary.json','plan_raw.routing.json','tests.xml']:
        shutil.copy2(RUN/name,folder/name)
    shutil.copy2(ROOT/'docs/rewrite_inspection_20261112.md',folder/'README.md')
