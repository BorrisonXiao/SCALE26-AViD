"""Run the full fixed cohort through direct compilation, rewrite and alignment."""
import copy,json,time
from pathlib import Path
from probabilistic_verification.compiler_extensions import compile_one,OPTIONS
from probabilistic_verification.split_alignment import compose_aligned
from probabilistic_verification.claim_rewrite import surface_checks
from compile_claim_splits import serialize

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/rewrite_all_20261112'


def main():
    original={r['claim_id']:r for r in map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines())}
    direct={r['claim_id']:r for r in map(json.loads,(RUN/'direct.jsonl').read_text().splitlines())}
    parsed={r['claim_id']:r for r in map(json.loads,(RUN/'parsed.jsonl').read_text().splitlines())}
    raw={r['claim_id']:r for r in map(json.loads,(RUN/'raw.jsonl').read_text().splitlines())}
    assert set(parsed)==set(raw)=={cid for cid,r in direct.items()if r['status']!='compiled'}
    rows=[];started=time.perf_counter()
    for cid,record in original.items():
        row=dict(claim_id=cid,original=record['text'],direct=direct[cid],components=[])
        if direct[cid]['status']=='compiled':
            row.update(stage='direct_pass',output=direct[cid],proposal=None)
        else:
            source=parsed[cid];proposal=source['proposal'];row['proposal']=proposal
            row['output']=dict(status='unsupported',code='model_'+proposal['action'],reason=proposal.get('reason','Model did not propose a rewrite.'))
            if source.get('validation_error'):
                row.update(stage='invalid_model_output');row['output'].update(code='invalid_model_output',reason=source['validation_error'])
            elif proposal['action'] in {'keep','refuse'}:row['stage']='model_'+proposal['action']
            else:
                texts=' '.join(c['text']for c in source['clauses'])
                # Flags are diagnostic, not proof that a rewrite changed meaning.
                try:row['surface_checks']=surface_checks(record,dict(action='rewrite',text=texts,reason='Diagnostic joined subclaims.'))
                except Exception as error:row['surface_check_error']=str(error)
                for clause in source['clauses']:
                    if 'record'in clause:
                        part=copy.deepcopy(clause['record'])
                        if len(source['clauses'])==1:part['claim_id']=cid
                        result=compile_one(part)
                    else:result=dict(status='unsupported',code='sentence_parse',reason=clause['parse_error'])
                    row['components'].append(dict(id=clause['id'],text=clause['text'],result=result))
                failed=[c for c in row['components']if c['result']['status']!='compiled']
                if failed:
                    row['stage']='component_compilation';row['output']=dict(status='unsupported',code=failed[0]['result'].get('code','component_refusal'),reason=failed[0]['id']+': '+failed[0]['result']['reason'])
                elif len(row['components'])==1:
                    row.update(stage='compiled_single',output=row['components'][0]['result'])
                else:
                    try:
                        prepared=copy.deepcopy(record);prepared['compiler_options']=dict(OPTIONS)
                        claim,proposal,trace=compose_aligned(cid,prepared,source['clauses'],{c['id']:c['result']for c in row['components']},max_clauses=12)
                        row.update(stage='compiled_composed',proposal=proposal,alignment=trace,output=serialize(claim))
                    except Exception as error:
                        code=getattr(error,'code',type(error).__name__)
                        row['stage']='alignment'if code in {'entity_alignment','mention_alignment','event_alignment','event_time_alignment','description_alignment','source_alignment'}else'composition'
                        row['output']=dict(status='unsupported',code=code,reason=str(error))
        rows.append(row)
    (RUN/'pipeline.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rows))
    print('Evaluated',len(rows),'cases;',sum(r['output']['status']=='compiled'for r in rows),'automatic programs;',round(time.perf_counter()-started,2),'seconds')


if __name__=='__main__':main()
