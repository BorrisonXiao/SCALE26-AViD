"""Recompute compilation/fidelity counts separately for automatic and supervised splits."""
import hashlib,json
from collections import Counter
from pathlib import Path
from build_reviewed_compilation_report import slim
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/claim_split_20261112'
def read(p):return list(map(json.loads,p.read_text().splitlines()))
def main():
 original={r['claim_id']:r for r in read(RUN/'inputs.jsonl')};all_cases=[];summary={}
 raw={r['claim_id']:r for r in read(RUN/'raw.jsonl')}
 for condition,folder in [('qwen',RUN),('supervised',RUN/'supervised')]:
  rows=read(folder/'results.jsonl');reviews={r['claim_id']:r for r in json.loads((folder/'semantic_review.json').read_text())['cases']}
  assert set(reviews)=={r['claim_id']for r in rows}
  for row in rows:
   review=reviews[row['claim_id']];assert review['artifact_sha256']==hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
   for side in ['flat','linked']:assert not review[side+'_faithful']or row[side]['status']=='compiled'
   output={}
   for side in ['flat','linked']:
    r=row[side];output[side]=dict(status=r['status'],code=r.get('code'),reason=r.get('reason'),view=slim(r))
   all_cases.append(dict(condition=condition,claim_id=row['claim_id'],original_text=original[row['claim_id']]['text'],
      original_error=row['original'].get('reason'),proposal=row['proposal'],validation_error=row.get('validation_error'),
      components=[dict(id=c['id'],text=c['text'],status=c['result']['status'],code=c['result'].get('code'),reason=c['result'].get('reason'),view=slim(c['result']))for c in row['components']],
      review=review,outputs=output,request=raw[row['claim_id']]if condition=='qwen'else None))
  parts=[c for r in rows for c in r['components']]
  summary[condition]=dict(cases=len(rows),attempted_splits=sum(len(r['proposal']['clauses'])>=2 for r in rows),
   components=len(parts),component_passes=sum(c['result']['status']=='compiled'for c in parts),
   all_components_pass=sum(len(r['components'])>=2 and all(c['result']['status']=='compiled'for c in r['components'])for r in rows),
   proposal_validation_pass=sum(not r.get('validation_error')for r in rows),
   flat_programs=sum(r['flat']['status']=='compiled'for r in rows),linked_programs=sum(r['linked']['status']=='compiled'for r in rows),
   reviewed_flat_recoveries=sum(r['flat_faithful']for r in reviews.values()),reviewed_linked_recoveries=sum(r['linked_faithful']for r in reviews.values()),
   multi_clause_text_faithful=sum(reviews[r['claim_id']]['text_faithful']is True and len(r['proposal']['clauses'])>=2 for r in rows),
   actions=dict(Counter(r['proposal']['action']for r in rows)),
   remaining_reasons=dict(Counter(r.get('validation_error')or r['linked'].get('code','review_needed')for r in rows if not reviews[r['claim_id']]['linked_faithful'])))
 for name,digest in json.loads((RUN/'compiler_freeze.json').read_text())['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
 summary['limits']=['Compiler-author assistant review, not independent human gold','Supervised8 are purposive development diagnostics written after Qwen proposal inspection, not automatic generation gains','No whole-corpus or unseen-test gain; no new media/DeepProbLog training/inference experiment']
 (RUN/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(RUN/'cases.json').write_text(json.dumps(all_cases,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
