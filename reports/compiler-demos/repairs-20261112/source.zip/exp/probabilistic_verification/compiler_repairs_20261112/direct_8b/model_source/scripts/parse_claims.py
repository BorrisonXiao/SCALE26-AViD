#!/usr/bin/env python
"""
AViD Phase 1 — Step 1+2: Parse claims → lexical dependency hypergraph.

Loads 761 unique English claims from the step1 manifest, builds a spacy-stanza
UD pipeline, extracts per-token lexical nodes + typed composition factors, and
serializes per-claim hypergraph records to avid/exp/phase1/hypergraph.jsonl.

Usage (after activating avid-phase1 env and setting STANZA_RESOURCES_DIR):
    python parse_claims.py
    python parse_claims.py --displacy-dir <dir>  # render ~10 random displaCy trees
    python parse_claims.py --limit 10            # quick test on first 10 claims

Output fields per JSONL record:
    claim_id, topic_id, claim_index, claim_text, modalities,
    parse (UD tokens), nodes (lexical units), factors (composition)
"""
import argparse
import json
import os
import random
import sys
from pathlib import Path
from typing import Optional

# Stanza 1.6 model files require weights_only=False in torch.load (PyTorch
# 2.6+ changed the default to True).  Patch torch.load before stanza imports.
try:
    import torch as _torch
    _orig_torch_load = _torch.load
    def _patched_torch_load(*args, **kwargs):
        kwargs.setdefault("weights_only", False)
        return _orig_torch_load(*args, **kwargs)
    _torch.load = _patched_torch_load
except Exception:
    pass

# -- Default paths -----------------------------------------------------------
MANIFEST_PATH = "/exp/cxiao/scale26/probing/exp/step1/manifests/manifest.jsonl"
OUTPUT_PATH   = "/exp/cxiao/scale26/avid/exp/phase1/hypergraph.jsonl"
STANZA_DIR    = os.environ.get("STANZA_RESOURCES_DIR",
                               "/exp/cxiao/.cache/stanza")
DISPLACY_DIR  = "/exp/cxiao/scale26/avid/exp/phase1/displacy"


# -- Constants ---------------------------------------------------------------

# UPOS → AViD node type
UPOS_TO_NODE_TYPE: dict[str, str] = {
    "NOUN":  "entity",
    "PROPN": "entity",
    "PRON":  "entity",
    "VERB":  "event",
    "ADJ":   "attribute",
    "ADV":   "attribute",
    "ADP":   "relation-op",
    "CCONJ": "coord-op",
    "NUM":   "cardinality",
}

NEG_LEMMAS = frozenset({
    "not", "never", "no", "n't", "neither", "nor", "without", "hardly",
})

# Deps that trigger token-group merging (compound nouns, flat names, appositions)
MERGE_DEPS = frozenset({
    "compound", "flat", "flat:name", "flat:foreign", "appos",
})

# Deps that are arguments of a verb predicate
ARG_DEPS = frozenset({
    "nsubj", "obj", "iobj", "obl", "nsubj:pass", "csubj", "csubj:pass",
    "obl:agent", "xcomp",
})

# Temporal connective lemmas
TEMPORAL_MARKERS = frozenset({
    "before", "after", "while", "during", "when", "since", "until", "as",
    "once", "whenever", "simultaneously", "meanwhile", "prior", "following",
})


# -- Loading helpers ---------------------------------------------------------

def load_unique_claims(manifest_path: str) -> list[dict]:
    """
    Load the manifest and deduplicate to one record per (topic_id, claim_text).
    Modalities are unioned across all supporting-video pairs for a claim.
    Returns list of dicts with: claim_id, topic_id, claim_index, claim_text, modalities.
    """
    seen: dict[tuple, dict] = {}   # (topic_id, claim_text) -> record
    with open(manifest_path, encoding="utf-8") as f:
        for line in f:
            entry = json.loads(line)
            key = (entry["topic_id"], entry["claim_text"])
            if key not in seen:
                seen[key] = {
                    "claim_id":    f"{entry['topic_id']}_{entry['claim_index']}",
                    "topic_id":    entry["topic_id"],
                    "claim_index": entry["claim_index"],
                    "claim_text":  entry["claim_text"],
                    "modalities":  set(entry["modalities"]),
                }
            else:
                seen[key]["modalities"].update(entry["modalities"])

    claims = list(seen.values())
    for c in claims:
        c["modalities"] = sorted(c["modalities"])
    return claims


# -- NLP pipeline ------------------------------------------------------------

def build_nlp(stanza_dir: str):
    """Build and return a spacy-stanza UD pipeline for English."""
    import spacy_stanza

    print(f"  Stanza resources dir: {stanza_dir}", flush=True)
    # spacy-stanza 1.0.4: pass dir/processors directly; it builds the stanza
    # Pipeline internally.  The torch.load patch must already be in effect.
    return spacy_stanza.load_pipeline(
        "en",
        dir=stanza_dir,
        processors="tokenize,mwt,pos,lemma,depparse,ner",
        use_gpu=False,
        verbose=False,
    )


# -- Merge groups (NER + compound/flat/appos) --------------------------------

def build_merged_groups(doc) -> tuple[dict[int, set[int]], dict[int, int]]:
    """
    Merge NER spans and compound/flat/appos chains into single nodes.
    Returns:
        groups      : rep_token_i → set of token_i in the group
        token_to_rep: token_i → rep_token_i (representative = syntactic head)
    Uses union-find with path compression.
    """
    parent: dict[int, int] = {t.i: t.i for t in doc}

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]  # path halving
            x = parent[x]
        return x

    def union(x: int, y: int) -> None:
        rx, ry = find(x), find(y)
        if rx != ry:
            parent[rx] = ry  # arbitrary root choice; we fix representative below

    # 1. NER spans: merge consecutive tokens within each span
    for ent in doc.ents:
        ent_tokens = list(ent)
        for k in range(len(ent_tokens) - 1):
            union(ent_tokens[k].i, ent_tokens[k + 1].i)

    # 2. compound / flat / appos chains
    for token in doc:
        if token.dep_ in MERGE_DEPS:
            union(token.i, token.head.i)

    # 3. Collect groups and choose representative = syntactic head of the group
    raw_groups: dict[int, set[int]] = {}
    for token in doc:
        r = find(token.i)
        raw_groups.setdefault(r, set()).add(token.i)

    final_groups: dict[int, set[int]] = {}
    token_to_rep: dict[int, int] = {}
    for _, member_set in raw_groups.items():
        # Representative: leftmost token whose syntactic head is outside the group
        rep = None
        for idx in sorted(member_set):
            if doc[idx].head.i not in member_set or doc[idx].dep_ == "root":
                rep = idx
                break
        if rep is None:
            rep = min(member_set)
        final_groups[rep] = member_set
        for idx in member_set:
            token_to_rep[idx] = rep

    return final_groups, token_to_rep


# -- Node construction -------------------------------------------------------

def get_node_type(token) -> Optional[str]:
    """Return AViD node type for a token, or None if it is a functional token."""
    # Negation overrides UPOS
    if token.lemma_.lower() in NEG_LEMMAS:
        if token.dep_ in ("advmod", "det", "neg"):
            return "logical-op"
    return UPOS_TO_NODE_TYPE.get(token.pos_)


def build_nodes(
    doc,
    groups: dict[int, set[int]],
    token_to_rep: dict[int, int],
) -> tuple[list[dict], dict[int, Optional[str]]]:
    """
    Build lexical node objects from merged groups.
    Returns:
        nodes          : list of node dicts (only content-POS groups)
        rep_to_node_id : rep_token_i → node id string (None for functional groups)
    """
    nodes: list[dict] = []
    rep_to_node_id: dict[int, Optional[str]] = {}
    nid = 0

    for rep_i in sorted(groups.keys()):
        rep_token = doc[rep_i]
        member_indices = sorted(groups[rep_i])
        member_tokens  = [doc[i] for i in member_indices]

        node_type = get_node_type(rep_token)
        if node_type is None:
            rep_to_node_id[rep_i] = None
            continue

        # Character span covering all member tokens
        span_start = min(t.idx for t in member_tokens)
        span_end   = max(t.idx + len(t.text) for t in member_tokens)
        surface    = doc.text[span_start:span_end]

        node = {
            "id":           f"n{nid}",
            "text":         surface,
            "lemma":        rep_token.lemma_,
            "upos":         rep_token.pos_,
            "node_type":    node_type,
            "span_start":   span_start,
            "span_end":     span_end,
            "token_indices": member_indices,  # doc-level
            "is_merged":    len(member_indices) > 1,
        }
        nodes.append(node)
        rep_to_node_id[rep_i] = f"n{nid}"
        nid += 1

    return nodes, rep_to_node_id


# -- Factor construction -----------------------------------------------------

def _span_text(doc, token_indices: list[int]) -> str:
    """Minimal character span covering the given token indices."""
    if not token_indices:
        return ""
    toks = [doc[i] for i in token_indices]
    start = min(t.idx for t in toks)
    end   = max(t.idx + len(t.text) for t in toks)
    return doc.text[start:end]


def build_factors(
    doc,
    token_to_rep: dict[int, int],
    rep_to_node_id: dict[int, Optional[str]],
) -> list[dict]:
    """
    Build composition factors via UD dependency rules (post-order compatible).
    Returns list of factor dicts.
    """
    factors: list[dict] = []
    fid_box = [0]

    def get_nid(token_i: int) -> Optional[str]:
        rep = token_to_rep.get(token_i)
        return rep_to_node_id.get(rep) if rep is not None else None

    def emit(ftype: str, head_tok_i: int, arg_tok_is: list[int],
             span_indices: list[int]) -> None:
        head_nid = get_nid(head_tok_i)
        if head_nid is None:
            return
        arg_nids = [a for ti in arg_tok_is if (a := get_nid(ti)) is not None]
        factors.append({
            "id":           f"f{fid_box[0]}",
            "factor_type":  ftype,
            "head":         head_nid,
            "args":         arg_nids,
            "surface_span": _span_text(doc, sorted(set(span_indices))),
        })
        fid_box[0] += 1

    def subtree_is(token) -> list[int]:
        return [t.i for t in token.subtree]

    root_token = None

    for token in doc:
        # -- 1. Predicate-argument (active + passive) --
        if token.pos_ == "VERB":
            args = [c.i for c in token.children if c.dep_ in ARG_DEPS]
            if args:
                span = sorted(set(subtree_is(token)))
                emit("predicate_argument", token.i, args, span)
            if token.dep_ == "root":   # UD uses lowercase "root"
                root_token = token

        # -- 2a. Entity-attribute via amod --
        if token.dep_ == "amod" and token.pos_ in ("ADJ", "ADV"):
            emit("entity_attribute", token.i, [token.head.i],
                 [token.i, token.head.i])

        # -- 2b. Entity-attribute via copular (cop) --
        if token.dep_ == "cop":
            pred = token.head  # the predicate adj/noun
            subj = next(
                (c for c in pred.children if c.dep_ in ("nsubj", "nsubj:pass")),
                None,
            )
            if subj and pred.pos_ in ("ADJ", "NOUN", "PROPN", "ADV"):
                span = sorted(set(subtree_is(pred)) | {subj.i})
                emit("entity_attribute", pred.i, [subj.i], span)

        # -- 3. Prepositional relation (obl/nmod with case child) --
        if token.dep_ in ("obl", "nmod") or token.dep_.startswith("obl:"):
            case_child = next(
                (c for c in token.children if c.dep_ == "case"),
                None,
            )
            if case_child:
                span = sorted(set([token.head.i] + subtree_is(token)))
                emit("prepositional_relation",
                     case_child.i,             # prep as head
                     [token.head.i, token.i],  # governing word + governed NP
                     span)

        # -- 4. Temporal relation (advcl/obl with temporal marker) --
        if token.dep_ in ("advcl", "obl") or token.dep_.startswith("obl:"):
            temp_marker = next(
                (c for c in token.children
                 if c.dep_ in ("mark", "case")
                 and c.lemma_.lower() in TEMPORAL_MARKERS),
                None,
            )
            if temp_marker:
                mark_nid = get_nid(temp_marker.i)
                head_tok  = token.head.i
                span = sorted(set(subtree_is(token.head) + subtree_is(token)))
                emit("temporal_relation",
                     temp_marker.i if mark_nid else head_tok,
                     [head_tok, token.i],
                     span)

        # -- 5. Coordination (conj + cc) --
        if token.dep_ == "conj":
            cc = next(
                (c for c in token.head.children if c.dep_ == "cc"),
                None,
            )
            span = sorted(
                set(subtree_is(token.head)) | set(subtree_is(token))
            )
            coordinator = cc.i if cc else token.head.i
            emit("coordination", coordinator,
                 [token.head.i, token.i], span)

        # -- 6. Negation --
        if token.dep_ in ("advmod", "det", "neg") and token.lemma_.lower() in NEG_LEMMAS:
            emit("negation", token.i, [token.head.i],
                 [token.i, token.head.i])

        # -- 7. Relative clause (acl:relcl) --
        if token.dep_ == "acl:relcl":
            span = sorted(set(subtree_is(token.head)) | set(subtree_is(token)))
            emit("relative_clause", token.i, [token.head.i], span)

        # -- 9. Cardinality / measurement (nummod) --
        if token.dep_ == "nummod":
            emit("cardinality", token.i, [token.head.i],
                 [token.i, token.head.i])

    # -- 8. Full-claim factor (root) --
    # If no VERB root was found (e.g. copular ADJ/NOUN root), find it now.
    if root_token is None:
        for token in doc:
            if token.dep_ == "root":
                root_token = token
                break

    if root_token is not None:
        direct_args = [c.i for c in root_token.children if c.dep_ in ARG_DEPS]

        # If root is a functional token (AUX, DET, …) with no node type,
        # find the nearest semantic head: nsubj or first content-POS child.
        head_for_full = root_token.i
        if get_node_type(root_token) is None:
            # Try nsubj first, then any content-POS child
            semantic = next(
                (c.i for c in root_token.children
                 if c.dep_ in ("nsubj", "nsubj:pass") and get_node_type(c) is not None),
                None,
            )
            if semantic is None:
                semantic = next(
                    (c.i for c in root_token.children
                     if get_node_type(c) is not None),
                    None,
                )
            if semantic is not None:
                head_for_full = semantic

        emit("full_claim", head_for_full, direct_args,
             list(range(len(doc))))

    return factors


# -- UD token list -----------------------------------------------------------

def extract_ud_tokens(doc) -> list[dict]:
    return [
        {
            "i":       t.i,
            "text":    t.text,
            "lemma":   t.lemma_,
            "upos":    t.pos_,
            "head":    t.head.i,
            "deprel":  t.dep_,
            "ent_type": t.ent_type_,
        }
        for t in doc
    ]


# -- displaCy rendering ------------------------------------------------------

def render_displacy(doc, path: Path) -> None:
    from spacy import displacy
    html = displacy.render(doc, style="dep", page=True, jupyter=False,
                           options={"compact": True, "distance": 90})
    path.write_text(html, encoding="utf-8")


# -- Main --------------------------------------------------------------------

def setup_parser():
    p = argparse.ArgumentParser(
        description="Parse claims → lexical dependency hypergraph (AViD Phase 1)"
    )
    p.add_argument("--manifest",    default=MANIFEST_PATH,
                   help="Path to step1 manifest.jsonl")
    p.add_argument("--output",      default=OUTPUT_PATH,
                   help="Output hypergraph.jsonl path")
    p.add_argument("--stanza-dir",  default=STANZA_DIR,
                   help="Stanza resources directory")
    p.add_argument("--displacy-dir", default=None,
                   help="If set, render displaCy HTML trees here for a sample")
    p.add_argument("--displacy-n",  type=int, default=10,
                   help="Number of random displaCy renders (default: 10)")
    p.add_argument("--seed",        type=int, default=42)
    p.add_argument("--limit",       type=int, default=0,
                   help="Process only first N unique claims (0 = all; for testing)")
    return p


def main():
    args = setup_parser().parse_args()
    random.seed(args.seed)

    print("=" * 60)
    print("AViD Phase 1 — parse_claims.py")
    print("=" * 60)

    # 1. Load and deduplicate claims
    print(f"\n[1] Loading manifest: {args.manifest}")
    claims = load_unique_claims(args.manifest)
    print(f"  Unique claims: {len(claims)}")
    if args.limit > 0:
        claims = claims[: args.limit]
        print(f"  (Limited to {args.limit} for testing)")

    # 2. Build NLP pipeline
    print(f"\n[2] Building spacy-stanza UD pipeline ...")
    nlp = build_nlp(args.stanza_dir)
    print("  Pipeline ready.")

    # 3. Process claims
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    displacy_dir = Path(args.displacy_dir) if args.displacy_dir else None
    if displacy_dir:
        displacy_dir.mkdir(parents=True, exist_ok=True)

    # Choose random sample for displaCy
    displacy_indices = set(
        random.sample(range(len(claims)), min(args.displacy_n, len(claims)))
    )

    stats = {
        "total_claims": len(claims),
        "multi_sentence_claims": 0,
        "total_nodes": 0,
        "total_factors": 0,
        "factor_type_counts": {},
        "node_type_counts": {},
    }

    print(f"\n[3] Parsing {len(claims)} claims ...")
    with open(out_path, "w", encoding="utf-8") as out_f:
        for idx, claim in enumerate(claims):
            if idx % 100 == 0:
                print(f"  {idx}/{len(claims)} ...", flush=True)

            doc = nlp(claim["claim_text"])

            # Count sentences
            n_sents = sum(1 for _ in doc.sents)
            if n_sents > 1:
                stats["multi_sentence_claims"] += 1

            # Build parse
            groups, token_to_rep = build_merged_groups(doc)
            nodes, rep_to_node_id = build_nodes(doc, groups, token_to_rep)
            factors = build_factors(doc, token_to_rep, rep_to_node_id)
            ud_tokens = extract_ud_tokens(doc)

            # Accumulate stats
            stats["total_nodes"]   += len(nodes)
            stats["total_factors"] += len(factors)
            for n in nodes:
                nt = n["node_type"]
                stats["node_type_counts"][nt] = stats["node_type_counts"].get(nt, 0) + 1
            for f in factors:
                ft = f["factor_type"]
                stats["factor_type_counts"][ft] = \
                    stats["factor_type_counts"].get(ft, 0) + 1

            record = {
                "claim_id":    claim["claim_id"],
                "topic_id":    claim["topic_id"],
                "claim_index": claim["claim_index"],
                "claim_text":  claim["claim_text"],
                "modalities":  claim["modalities"],
                "n_sentences": n_sents,
                "parse":       ud_tokens,
                "nodes":       nodes,
                "factors":     factors,
            }
            out_f.write(json.dumps(record, ensure_ascii=False) + "\n")

            # displaCy render
            if idx in displacy_indices and displacy_dir:
                cid = claim["claim_id"].replace("/", "_")
                html_path = displacy_dir / f"{idx:04d}_{cid}.html"
                render_displacy(doc, html_path)

    # 4. Verify: every claim must have a full_claim factor
    print("\n[4] Verifying output ...")
    n_missing_root = 0
    n_no_nodes = 0
    with open(out_path, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            if not any(fa["factor_type"] == "full_claim" for fa in rec["factors"]):
                n_missing_root += 1
                print(f"  WARNING: no full_claim factor in {rec['claim_id']!r}: "
                      f"{rec['claim_text']!r}", file=sys.stderr)
            if not rec["nodes"]:
                n_no_nodes += 1
                print(f"  WARNING: no nodes in {rec['claim_id']!r}: "
                      f"{rec['claim_text']!r}", file=sys.stderr)

    # 5. Print summary
    print("\n" + "=" * 60)
    print("PARSE SUMMARY")
    print("=" * 60)
    print(f"  Claims parsed:            {stats['total_claims']}")
    print(f"  Multi-sentence claims:    {stats['multi_sentence_claims']}")
    print(f"  Total nodes:              {stats['total_nodes']} "
          f"(avg {stats['total_nodes']/max(1,stats['total_claims']):.1f}/claim)")
    print(f"  Total factors:            {stats['total_factors']} "
          f"(avg {stats['total_factors']/max(1,stats['total_claims']):.1f}/claim)")
    print(f"\n  Node type distribution:")
    for k, v in sorted(stats["node_type_counts"].items(), key=lambda x: -x[1]):
        print(f"    {k:<20} {v:>6}")
    print(f"\n  Factor type distribution:")
    for k, v in sorted(stats["factor_type_counts"].items(), key=lambda x: -x[1]):
        print(f"    {k:<25} {v:>6}")
    if n_missing_root:
        print(f"\n  ERROR: {n_missing_root} claims missing full_claim factor!", file=sys.stderr)
    if n_no_nodes:
        print(f"\n  WARNING: {n_no_nodes} claims have no nodes!", file=sys.stderr)
    print(f"\n  Output: {out_path}")
    if displacy_dir:
        print(f"  displaCy HTML: {displacy_dir}")
    print("\nDone.")


if __name__ == "__main__":
    main()
