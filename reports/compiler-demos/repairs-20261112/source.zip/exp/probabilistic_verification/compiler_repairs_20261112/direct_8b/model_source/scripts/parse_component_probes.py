"""Cache actual dependency/SRL predictions for authored construction probes."""
import argparse,hashlib,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/semantic_components_20261112'

def main():
    p=argparse.ArgumentParser();p.add_argument('--srl',action='store_true');a=p.parse_args();start=time.perf_counter()
    if not a.srl:
        from probabilistic_verification.parsing import DependencyParser
        parser=DependencyParser();rows=[]
        for item in json.loads((RUN/'probes.json').read_text()):
            row={k:item[k]for k in ['claim_id','text']}
            try:row.update(tokens=parser.parse(row['text']),srl=None)
            except ValueError as error:row['parse_error']=str(error)
            rows.append(row)
        (RUN/'probe_dependencies.jsonl').write_text(''.join(json.dumps(r)+'\n'for r in rows))
        provenance=parser.provenance
    else:
        import torch
        from allennlp.predictors.predictor import Predictor
        from run_srl_baseline import bio_to_spans
        torch.set_num_threads(2)
        meta=next(json.loads(p.read_text())for p in Path('/home/hltcoe/cxiao/.allennlp/cache').glob('*.json')if 'structured-prediction-srl-bert'in p.read_text())
        model=Path(meta['cached_path']);predictor=Predictor.from_path(str(model),cuda_device=-1)
        rows=list(map(json.loads,(RUN/'probe_dependencies.jsonl').read_text().splitlines()));pending=[r for r in rows if 'tokens'in r]
        for first in range(0,len(pending),8):
            batch=pending[first:first+8]
            for row,out in zip(batch,predictor.predict_batch_json([dict(sentence=r['text'])for r in batch])):
                frames=[]
                for v in out['verbs']:
                    spans=bio_to_spans(v['tags']);verb=next(([s,e]for role,s,e in spans if role=='V'),None)
                    frames.append(dict(verb=v['verb'],verb_span=verb,args=[dict(role=role,start=s,end=e,text=' '.join(out['words'][s:e+1]))for role,s,e in spans if role!='V']))
                row['srl']=dict(words=out['words'],frames=frames)
        (RUN/'probe_parsed.jsonl').write_text(''.join(json.dumps(r)+'\n'for r in rows))
        provenance=dict(device='cpu',model=meta,sha256=hashlib.sha256(model.read_bytes()).hexdigest())
    provenance.update(elapsed_seconds=time.perf_counter()-start,authored_probes=True,no_language_model_generation=True)
    (RUN/('probe_srl_provenance.json'if a.srl else'probe_dependency_provenance.json')).write_text(json.dumps(provenance,indent=2)+'\n')
    print('Parsed',len(rows),'probes; srl=',a.srl,flush=True)

if __name__=='__main__':main()
