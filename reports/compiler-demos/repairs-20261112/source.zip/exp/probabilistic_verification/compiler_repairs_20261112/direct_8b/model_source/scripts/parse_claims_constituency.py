#!/usr/bin/env python3
"""
AViD Phase 1 Parsing Ablation — parse claims with benepar (constituency).

Reads  : exp/phase1/hypergraph.jsonl  (claim_id + claim_text)
Writes : exp/phase1/parsing_ablation/constituency.jsonl
         exp/phase1/parsing_ablation/constituency_trees/  (sample trees)

Each output record:
    claim_id, claim_text,
    tree         — parenthesized benepar parse string
    constituents — list of {label, text, start_char, end_char, tokens}
      where each token is {i, text, pos, tag, dep, head_i, lemma, start_char, end_char}

Usage (activate or conda run with calm-probe env that has benepar installed):
    python parse_claims_constituency.py
    python parse_claims_constituency.py --limit 5   # quick smoke-test
    python parse_claims_constituency.py --trees-n 0 # skip tree renders
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

# ── Defaults ──────────────────────────────────────────────────────────────────

_ROOT = Path(__file__).parent.parent / "exp" / "phase1"
_ABL  = _ROOT / "parsing_ablation"

DEFAULT_HG    = str(_ROOT / "hypergraph.jsonl")
DEFAULT_OUT   = str(_ABL / "constituency.jsonl")
DEFAULT_TREES = str(_ABL / "constituency_trees")

CLAUSE_LABELS = frozenset({"S", "SBAR", "SINV", "SQ", "FRAG"})


# benepar model stored under /exp/cxiao/.cache/benepar (not /home/nltk_data)
BENEPAR_CACHE = "/exp/cxiao/.cache/benepar"


# ── NLP pipeline ──────────────────────────────────────────────────────────────

def _build_nlp():
    import nltk
    import spacy
    import benepar  # noqa: F401 — registers the pipe

    # Ensure benepar can find its model from the non-home cache location.
    if BENEPAR_CACHE not in nltk.data.path:
        nltk.data.path.insert(0, BENEPAR_CACHE)

    # en_core_web_sm supplies tok2vec/tagger/parser (POS, dep, senter).
    # Exclude ner — not needed and saves time.
    nlp = spacy.load("en_core_web_sm", exclude=["ner"])
    if "benepar" not in nlp.pipe_names:
        nlp.add_pipe("benepar", config={"model": "benepar_en3"})
    return nlp


# ── Constituent extraction ────────────────────────────────────────────────────

def _tokens_from_span(span) -> list[dict]:
    """Build token dicts for a spaCy span, including char offsets and dep info."""
    return [
        {
            "i":          tok.i,          # doc-level token index
            "text":       tok.text,
            "pos":        tok.pos_,
            "tag":        tok.tag_,
            "dep":        tok.dep_,
            "head_i":     tok.head.i,     # doc-level head token index
            "lemma":      tok.lemma_,
            "start_char": tok.idx,
            "end_char":   tok.idx + len(tok.text),
        }
        for tok in span
    ]


def _constituents_from_sent(sent) -> list[dict]:
    """Return flat list of constituent dicts from a benepar-annotated sentence."""
    result: list[dict] = []
    for span in sent._.constituents:
        labels = span._.labels
        if not labels:
            continue
        result.append({
            "label":      labels[0],
            "text":       span.text,
            "start_char": span.start_char,
            "end_char":   span.end_char,
            "tokens":     _tokens_from_span(span),
        })
    return result


# ── Tree rendering ─────────────────────────────────────────────────────────────

def _render_tree(sent, claim_id: str, out_dir: Path) -> None:
    """Write the parenthesized parse string to a text file (one claim per file)."""
    fname = claim_id.replace("/", "_") + ".txt"
    (out_dir / fname).write_text(sent._.parse_string + "\n", encoding="utf-8")


# ── CLI ───────────────────────────────────────────────────────────────────────

def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Parse claims → constituency.jsonl (benepar, Phase 1 ablation)"
    )
    p.add_argument("--hypergraph", default=DEFAULT_HG,
                   help="Input hypergraph.jsonl (claim_id + claim_text used)")
    p.add_argument("--output",     default=DEFAULT_OUT,
                   help="Output constituency.jsonl")
    p.add_argument("--trees-dir",  default=DEFAULT_TREES,
                   help="Directory for sample tree text files")
    p.add_argument("--trees-n",    type=int, default=10,
                   help="Number of sample tree renders (0 = skip)")
    p.add_argument("--seed",       type=int, default=42)
    p.add_argument("--limit",      type=int, default=0,
                   help="Process only first N claims (0 = all; for testing)")
    return p


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    args = _parser().parse_args()
    random.seed(args.seed)

    print("=" * 60)
    print("AViD Phase 1 — parse_claims_constituency.py")
    print("=" * 60)

    # 1. Load claim_id + claim_text from hypergraph.jsonl
    print(f"\n[1] Loading claims: {args.hypergraph}")
    claims: list[dict] = []
    with open(args.hypergraph, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            claims.append({"claim_id": rec["claim_id"], "claim_text": rec["claim_text"]})
    if args.limit > 0:
        claims = claims[: args.limit]
        print(f"    Limited to {args.limit} claims")
    print(f"    Claims loaded: {len(claims)}")

    # 2. Build pipeline
    print("\n[2] Loading benepar pipeline (en_core_web_sm + benepar_en3) ...")
    nlp = _build_nlp()
    print(f"    Pipes: {nlp.pipe_names}")

    # 3. Prepare output paths
    out_path  = Path(args.output)
    trees_dir = Path(args.trees_dir)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Choose sample indices for tree rendering
    tree_indices: set[int] = set()
    if args.trees_n > 0:
        trees_dir.mkdir(parents=True, exist_ok=True)
        trigger_idx = next(
            (i for i, c in enumerate(claims) if c["claim_id"] == "TInVWzp25aIM_15"),
            None,
        )
        pool = [i for i in range(len(claims)) if i != trigger_idx]
        random.shuffle(pool)
        n_fill = min(args.trees_n - (1 if trigger_idx is not None else 0), len(pool))
        tree_indices = set(pool[:n_fill])
        if trigger_idx is not None:
            tree_indices.add(trigger_idx)

    # 4. Parse
    print(f"\n[3] Parsing {len(claims)} claims ...")
    n_multi_sent    = 0
    n_np_total      = 0
    n_clause_total  = 0
    n_trees_written = 0
    n_errors        = 0
    error_ids: list[str] = []

    with open(out_path, "w", encoding="utf-8") as out_f:
        for idx, claim in enumerate(claims):
            if idx % 100 == 0:
                print(f"    {idx}/{len(claims)} ...", flush=True)

            try:
                doc   = nlp(claim["claim_text"])
                sents = list(doc.sents)
                if len(sents) > 1:
                    n_multi_sent += 1

                # Use first sentence (claims are nearly always single-sentence)
                sent         = sents[0]
                tree_str     = sent._.parse_string
                constituents = _constituents_from_sent(sent)

                if idx in tree_indices:
                    _render_tree(sent, claim["claim_id"], trees_dir)
                    n_trees_written += 1

            except Exception as e:
                # Benepar retokenization can fail on unusual tokens (e.g., embedded
                # quotes, unmatched brackets, long sentences). Skip and record.
                n_errors += 1
                error_ids.append(claim["claim_id"])
                print(f"  SKIP {claim['claim_id']!r}: {e}", flush=True)
                tree_str     = ""
                constituents = []

            n_np_total     += sum(1 for c in constituents if c["label"] == "NP")
            n_clause_total += sum(1 for c in constituents if c["label"] in CLAUSE_LABELS)

            out_f.write(json.dumps({
                "claim_id":     claim["claim_id"],
                "claim_text":   claim["claim_text"],
                "tree":         tree_str,
                "constituents": constituents,
                "parse_error":  tree_str == "",
            }, ensure_ascii=False) + "\n")

    # 5. Smoke-test: locate trigger claim in output
    trigger_tree = None
    with open(out_path, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            if rec["claim_id"] == "TInVWzp25aIM_15":
                trigger_tree = rec["tree"]
                break

    print(f"\n{'=' * 60}")
    print("SUMMARY")
    print(f"{'=' * 60}")
    n_ok = len(claims) - n_errors
    print(f"  Claims processed : {len(claims)}")
    print(f"  Parse OK         : {n_ok}")
    print(f"  Parse errors     : {n_errors}" + (f"  ({', '.join(error_ids[:5])}{'…' if len(error_ids)>5 else ''})" if n_errors else ""))
    print(f"  Multi-sentence   : {n_multi_sent}")
    print(f"  NP constituents  : {n_np_total}  (avg {n_np_total/max(1,n_ok):.1f}/ok-claim)")
    print(f"  Clause (S/SBAR…) : {n_clause_total}  (avg {n_clause_total/max(1,n_ok):.1f}/ok-claim)")
    print(f"  Tree renders     : {n_trees_written} → {trees_dir}")
    print(f"  Output           : {out_path}")

    if trigger_tree:
        print(f"\n  Trigger case TInVWzp25aIM_15 tree:")
        print(f"    {trigger_tree}")

    print("\nDone.")


if __name__ == "__main__":
    main()
