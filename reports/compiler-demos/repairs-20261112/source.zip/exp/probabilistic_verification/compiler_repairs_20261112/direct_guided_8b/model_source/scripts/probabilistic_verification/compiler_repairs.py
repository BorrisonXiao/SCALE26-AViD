"""Repair source-licensed modifiers, local reflexives, and simple scope.

The frozen parsers are unchanged. Repairs operate on copied annotations/forms;
unsupported scope stays a refusal. No sentence generation occurs here.
"""
import copy,re
from .compiler_readiness import compile_ready
from .scoped_srl import SourceSyntax,quoted_spans
from .content_recovery import _add_nominal,tid
from .compiler_extensions import negative_existentials
from .compilation_followup import walk_events
from .split_composition import nodes
from .logical_form import LogicalFormError


def prepare_existential(record):
    s=SourceSyntax(record)
    if not any(t['lemma'].lower()=='no'and t['deprel']=='det'for t in s.tokens):return
    roots=[t for t in s.tokens if t['head']==0 and t['lemma'].lower()=='be']
    if len(roots)!=1:return
    root=roots[0]
    if not any(t['deprel']=='expl'and t['lemma'].lower()=='there'for t in s.children[root['id']]):return
    subjects=[t for t in s.children[root['id']]if t['deprel'].startswith('nsubj')and t['upos']=='NOUN']
    if len(subjects)!=1:return
    subject=subjects[0];places=[]
    for t in s.children[root['id']]+s.children[subject['id']]:
        if t['deprel']not in{'obl','nmod'}or t['upos']not in{'NOUN','PROPN'}:continue
        markers=[c for c in s.children[t['id']]if c['deprel']=='case']
        if len(markers)==1 and markers[0]['lemma'].lower()in{'in','at','on','inside','under'}:places.append(t)
    if len(places)!=1:return
    frames=[f for f in record['srl']['frames']if s.frame_head(f)and s.frame_head(f)['id']==root['id']]
    if len(frames)!=1 or any(a['role']not in{'ARG1','ARGM-MNR','ARGM-EXT'}for a in frames[0]['args']):return
    place=places[0];ids=s.subtree(subject['id'])-s.subtree(place['id'])
    # Separate the existing grammatical subject and PP; no new words or events.
    frames[0]['args']=[a for a in frames[0]['args']if a['role']!='ARG1']+[
        s.argument('ARG1',ids),s.argument('ARG2',s.subtree(place['id']))]


def prepare_quoted_locations(record):
    s=SourceSyntax(record)
    if not quoted_spans(record['text']):return
    for frame in record['srl']['frames']:
        head=s.frame_head(frame)
        if not head or head['lemma'].lower()not in{'write','print','inscribe','engrave'}:continue
        args=[]
        for arg in frame['args']:
            selected={t['id']for t in s.alignment.selected(arg['start'],arg['end'])}
            heads=[t for t in s.children[head['id']]if t['id']in selected and t['deprel']=='obl'and t['upos']in{'NOUN','PROPN'}and any(c['deprel']=='case'for c in s.children[t['id']])]
            groups=[s.subtree(t['id'])for t in heads]
            if arg['role']=='ARGM-LOC'and len(groups)>1 and set.union(*groups)==selected:
                args.extend(s.argument(arg['role'],ids)for ids in groups)
            else:args.append(arg)
        frame['args']=args


def replace_reference(value,old,new):
    if isinstance(value,list):
        for item in value:replace_reference(item,old,new)
    elif isinstance(value,dict):
        for key,item in list(value.items()):
            if key in {'id','text','anchor','predicate','value'}:continue
            if item==old:value[key]=new
            else:replace_reference(item,old,new)


def expand_nominal_spans(record,form,notes):
    s=SourceSyntax(record)
    for entity in list(form['entities']):
        match=re.fullmatch(r'span(\d+)_(\d+)',entity['id'])
        if not match:continue
        selected=s.alignment.selected(*map(int,match.groups()));ids={t['id']for t in selected}
        if any(t['upos']in{'VERB','AUX','CCONJ'}for t in selected):continue
        heads=[t for t in selected if t['head']not in ids and t['upos']in{'NOUN','PROPN','PRON'}]
        if len(heads)!=1:continue
        head=heads[0]
        governor=s.by_id.get(head['head'])
        if not governor:continue
        writing=(governor['lemma'].lower()in{'write','print','read','inscribe','engrave'}
                 and any(e['id']=='e'+str(governor['id'])and any(isinstance(v,dict)and v.get('kind')=='verbatim_text'for v in e['arguments'].values())for e in walk_events(form)))
        existential=(governor['lemma'].lower()=='be'and any(t['deprel']=='expl'and t['lemma'].lower()=='there'for t in s.children[governor['id']]))
        if not writing and not existential:continue
        outside=[t for t in selected if t['head']not in ids and t['id']!=head['id']]
        if writing:
            from .content_recovery import _nominal_ids
            if outside or any(t['upos']in{'ADV','NUM'}for t in selected)or not _nominal_ids(s,head['id'])<=ids:continue
        elif not outside or any(t['upos']!='ADV'or t['deprel']!='advmod'or t['head']!=head['head']or s.children[t['id']]for t in outside):continue
        new=_add_nominal(s,form,head['id']);replace_reference(form,entity['id'],new);form['entities'].remove(entity)
        notes.append(dict(kind='nominal_span',old=entity['id'],entity=new,source=entity['text']))


def noun_modifiers(record,form,notes):
    s=SourceSyntax(record)
    from .scope_coverage import audit_content_coverage
    missing={t['id']for t in audit_content_coverage(record,form)['missing']}
    for entity in form['entities']:
        head=tid(entity['id'],'x')
        if head not in s.by_id:continue
        for token in s.children[head]:
            if token['deprel']!='amod'or token['upos']!='ADJ':continue
            if token['id']not in missing:continue
            if re.search(r'\b'+re.escape(token['text'])+r'\b',entity['text'],re.I):continue
            if any(lo<=token['start_char']<hi for lo,hi,_ in quoted_spans(record['text'])):continue
            if token['lemma'].lower()in{'former','alleged','possible','potential','likely','supposed','purported'}:continue
            prop=dict(role='mod',value=token['text'])
            if prop not in entity.setdefault('properties',[]):
                entity['properties'].append(prop);notes.append(dict(kind='noun_modifier',entity=entity['id'],word=token['text'],basis='UD amod attachment'))


def existential_location(record,form,notes):
    s=SourceSyntax(record)
    if not any(t["lemma"].lower()=="no"and t["deprel"]=="det"for t in s.tokens):return
    event=form['formula']
    if event.get('op')!='event'or event.get('predicate')!='be'or 'ARG2'in event['arguments']:return
    head=tid(event['id'],'e')
    if not any(t['deprel']=='expl'and t['lemma'].lower()=='there'for t in s.children.get(head,[])):return
    eid=event['arguments'].get('ARG1');entity=next((e for e in form['entities']if e['id']==eid),None)
    relations=entity.get('relations',[])if entity else[]
    if len(relations)!=1 or relations[0]['role']not in{'in','at','on','inside','under'}:return
    relation=relations[0];event['arguments']['ARG2']=relation['target']
    event.setdefault('properties',[]).append(dict(role='preposition:ARG2',value=relation['role']))
    entity['relations'].remove(relation)
    notes.append(dict(kind='existential_location',event=event['id'],entity=eid,location=relation['target'],preposition=relation['role']))


def local_reflexives(record,form,notes):
    s=SourceSyntax(record)
    for token in s.tokens:
        if token['upos']!='PRON'or 'Reflex=Yes'not in(token.get('feats')or''):continue
        entities={e['id']:e for e in form['entities']};source='x'+str(token['id']);head=s.by_id.get(token['head'])
        if source not in entities or not head:continue
        # Adjacent emphatic NP: "the homes themselves". Do not use this rule
        # when the alleged noun has an unresolved compound predicate/subject.
        emphasis=(token['deprel']=='nmod:npmod'and head['upos']in{'NOUN','PROPN'}
                  and not any(t['upos']=='NOUN'and t['deprel']=='compound'for t in s.children[head['id']])
                  and not record['text'][head['end_char']:token['start_char']].strip())
        if emphasis and 'x'+str(head['id'])in entities:
            target='x'+str(head['id']);replace_reference(form,source,target)
            entities[target]['relations']=[r for r in entities[target].get('relations',[])if not(r['target']==target and r['role']=='nmod')]
            form['entities']=[e for e in form['entities']if e['id']!=source]
            notes.append(dict(kind='reflexive_reference',mention=token['text'],source=source,target=target,basis='Adjacent emphatic nominal'))
            continue
        if token['deprel']not in{'obj','iobj','obl','nmod'}:continue
        governor=head;seen=set()
        while governor and governor['upos']in{'NOUN','PROPN'}and governor['id']not in seen:
            seen.add(governor['id'])
            if any(t['deprel']=='nmod:poss'for t in s.children[governor['id']]):governor=None;break
            governor=s.by_id.get(governor['head'])
        if not governor or governor['upos']not in{'VERB','AUX'}:continue
        owner=governor['id']
        def reachable(eid,visited=None):
            visited=set()if visited is None else visited
            if eid in visited:return visited
            visited.add(eid)
            for rel in entities.get(eid,{}).get('relations',[]):reachable(rel['target'],visited)
            return visited
        related=[e for e in walk_events(form)if tid(e['id'],'e')==owner and any(source in reachable(v)for v in e.get('arguments',{}).values()if isinstance(v,str))]
        if len(related)!=1:continue
        seen=set();subjects=[]
        while governor and governor['id']not in seen:
            seen.add(governor['id']);subjects=[t for t in s.children[governor['id']]if t['deprel'].startswith('nsubj')]
            subjects=[t for t in subjects if 'x'+str(t['id'])in related[0]['arguments'].values()]
            if len(subjects)>1:
                roles=related[0]['arguments'];licensed={roles.get(k)for k in ['ARG0','nsubj','nsubj:pass']if isinstance(roles.get(k),str)}
                subjects=[t for t in subjects if 'x'+str(t['id'])in licensed]
            if subjects or governor['deprel']!='conj':break
            governor=s.by_id.get(governor['head'])
        if len(subjects)!=1:continue
        target='x'+str(subjects[0]['id'])
        if target not in entities:continue
        replace_reference(form,source,target);form['entities']=[e for e in form['entities']if e['id']!=source]
        notes.append(dict(kind='reflexive_reference',mention=token['text'],source=source,target=target,basis='Reflex=Yes, local UD subject and matching compiled participant'))
    unresolved={e['id']for e in form['entities']if e.get('type')=='pronoun'}
    for token in s.tokens:
        if 'Reflex=Yes'in(token.get('feats')or'')and 'x'+str(token['id'])in unresolved:
            if not any(lo<=token['start_char']<hi for lo,hi,_ in quoted_spans(record['text'])):
                raise LogicalFormError('unresolved_reflexive','Cannot license a local antecedent for '+token['text']+' with the supplied predicate structure.')


def likelihood_scope(record,form,notes):
    s=SourceSyntax(record);q=[t for t in s.tokens if t['lemma'].lower()in{'likely','probably'}and not any(lo<=t['start_char']<hi for lo,hi,_ in quoted_spans(record['text']))]
    if len(q)!=1:return
    if any(n.get('op')=='qualified'and n.get('operator')=='likely'for n in nodes(form['formula'])):return
    token=q[0];body=form['formula'];root=next((t for t in s.tokens if t['head']==0),None)
    if body.get('op')=='entity'and root and token['head']==root['id']:
        pass
    elif body.get('op')=='event'and not body.get('propositions')and root and body['predicate']=='be'and(token['id']==root['id']or token['head']==root['id']):
        for role,value in list(body['arguments'].items()):
            if isinstance(value,dict)and str(value.get('value','')).lower()in{'likely','probably'}:del body['arguments'][role]
    else:return
    for entity in form['entities']:
        entity['properties']=[p for p in entity.get('properties',[])if str(p['value']).lower()not in{'likely','probably'}]
    form['formula']=dict(op='qualified',operator='likely',body=body);form['kind']='claim'
    notes.append(dict(kind='qualification_scope',operator='likely',basis='Single root/copular proposition; no scope projected across coordination'))


def quoted_nominal(record,form,notes):
    if form['formula'].get('op')!='entity':return
    entity=next((e for e in form['entities']if e['id']==form['formula']['ref']),None)
    if not entity or entity.get('relations')or len(entity.get('propositions',[]))!=1:return
    body=entity['propositions'][0]['body']
    if body.get('op')!='event'or body['predicate']not in{'write','print','read','inscribe','engrave'}:return
    quotes=[v['value']for v in body.get('arguments',{}).values()if isinstance(v,dict)and v.get('kind')=='verbatim_text']
    if len(quotes)!=1 or entity['text'].lower()not in quotes[0].lower():return
    if any(str(p['value']).lower()not in quotes[0].lower()for p in entity.get('properties',[])):return
    form['formula']=body;form['kind']='claim'
    notes.append(dict(kind='quoted_text_subject',entity=entity['id'],event=body['id'],text=quotes[0],basis='Quoted nominal is the writing content, not an ordinary referent'))


def compile_repaired(record,*,strict=True):
    prepared=copy.deepcopy(record)
    syntax=SourceSyntax(prepared)
    prepared.setdefault('compiler_options',{})['speech_predicates']=sorted({t['lemma'].lower()for t in syntax.tokens if t['lemma'].lower()in{'exclaim','whisper','mutter','yell','utter'}and quoted_spans(prepared['text'])})
    prepared['compiler_options']['quoted_predicate_routes']={p:'ocr_assertion'for p in ['write','print','inscribe','engrave']}
    prepare_existential(prepared)
    prepare_quoted_locations(prepared)
    def transform(r,form,notes,alignments):
        expand_nominal_spans(r,form,notes);noun_modifiers(r,form,notes);local_reflexives(r,form,notes);likelihood_scope(r,form,notes);existential_location(r,form,notes);quoted_nominal(r,form,notes)
        if not any(n.get('op')=='not_exists'for n in nodes(form['formula'])):
            negative_existentials(r,form,notes)
    return compile_ready(prepared,strict=strict,transform_form=transform)


def compile_one(record):
    from run_scope_coverage_census import compile_one as run
    return run(record,compiler=compile_repaired)
