"""Account for one fixed corpus condition; keep model pilots separate."""
import json,hashlib
from collections import Counter
from run_compiler_repairs import ROOT,RUN,OLD,read,write
from analyze_semantic_components import form
from build_reviewed_compilation_report import slim
JUDGMENTS={
'TInVWzp25aIM_87':(True,'The destination and date refer to the same evacuate event; evacuation is an event reference, not a second unrelated object.'),
'TInVWzp25aIM_106':(True,'Small is restored on the vehicles. Motorized and able to survey retain their existing predicate/complement structure; actual surveying is not asserted.'),
'TbJqMFkNxARY_160':(True,'NOT EXISTS contains the full be-in-water condition including fully. A partly submerged container does not contradict this claim.'),
'TbJqMFkNxARY_161':(False,'Implication, uncertainty and the antecedent of this are not adequately represented. A complete program is insufficient.'),
'TzF9M4kZ3Pys_308':(True,'Likely scopes over the complete outage proposition, including the residential-area restriction. Outages are not asserted as certain.'),
'Tg0UxWYuPeJ0_343':(True,'One exclaim event binds the man and the exact quoted words under speech support.'),
'Tg0UxWYuPeJ0_360':(True,'Reposition has the robot as both subject and object. Upright and backwards remain attached to their events; start retains its walking complement.'),
'TFOEIehBwT8Q_453':(True,'The quoted words are writing content, not a government entity. Graffiti, barricades and the surrounding relation remain explicit.'),
'TFOEIehBwT8Q_532':(True,'The two alternatives are joined by OR. Six qualifies shots only; no explosion count is invented.'),
'TFOEIehBwT8Q_536':(True,'The exact quoted words remain OCR content. Graffiti and barricades are separate explicit surfaces of the writing event.'),
'TQEmEycTI0RQ_955':(False,'The declining subject is linked to result rather than NDP and begin is introduced. Reflexive/lexical repairs do not resolve that event reading.'),
'TgPh_fzHTCm4_1500':(False,'Itself now shares the circulation referent, but repeated then modifiers do not explicitly order the events.'),
'Txf2EdqOg1SQ_2290':(False,'The two alternative locations still become an AND reading in this cached rewrite. Explicit generated formulas need evaluation on this case.')}
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def different(a,b):return a.get('program')!=b.get('program')or form(a)!=form(b)
def main():
 current=read(RUN/'cached_pipeline.jsonl');prev={r['claim_id']:r for r in read(OLD/'cached_pipeline.jsonl')};prior_reviews={r['claim_id']:r for r in json.loads((OLD/'semantic_review.json').read_text())['cases']};direct={r['claim_id']:r for r in read(RUN/'direct_all.jsonl')};old_direct={r['claim_id']:r for r in read(OLD/'direct_all.jsonl')};reviews=[];approved={};cases=[];changed=[]
 for r in current:
  cid=r['claim_id'];a=r['output'];ok=False;reason=a.get('reason','No complete program.');kind='pipeline_failure'
  if a['status']=='compiled':
   if different(a,prev[cid]['output']):
    ok,reason=JUDGMENTS[cid];kind='newly_inspected';changed.append(cid);cases.append(dict(id=cid,title=cid,text=r['original'],before=slim(prev[cid]['output']),after=slim(a),approved=ok,note=reason,stage=r['stage']))
   else:ok=prior_reviews[cid]['faithful'];reason=prior_reviews[cid]['reason'];kind='exact_program_and_form_review_reused'
   if ok:approved[cid]=r
  reviews.append(dict(claim_id=cid,faithful=ok,reason=reason,review_type=kind,artifact_sha256=digest(r)))
 assert set(changed)==set(JUDGMENTS),set(changed)^set(JUDGMENTS)
 pool=[];additions=[];retained_changes=[];by_current={r['claim_id']:r for r in current};by_review={r['claim_id']:r for r in reviews}
 for old in read(OLD/'corpus_reviewed.jsonl'):
  cid=old['claim_id'];r=old
  if cid in approved:
   if old['status']!='compiled':additions.append(cid)
   r=dict(approved[cid]['output'],claim_id=cid,text=old['text'],acceptance='Compiler-author development review; not independent gold or a media truth label.')
  elif old['status']!='compiled'and cid in by_current:
   out=by_current[cid]['output'];r=dict(out,claim_id=cid,text=old['text'],status='unsupported')
   if out['status']=='compiled':r.update(code='meaning_review',reason=by_review[cid]['reason'])
  elif old['status']=='compiled'and cid not in by_current and different(direct[cid],old_direct[cid]):
   assert direct[cid]['status']=='compiled',cid
   # Review the repair against the old form; this is not a fresh full-program gold judgment.
   note='Targeted change review: '+('reflexive now shares its local subject; other earlier conditions retain their previous status.'if any(t in old['text'].lower()for t in ['themselves','himself'])else 'the source route or simple likelihood scope now follows the original grammatical context; earlier conditions retain their previous status.')
   retained_changes.append(dict(claim_id=cid,text=old['text'],before=slim(old_direct[cid]),after=slim(direct[cid]),note=note,artifact_sha256=digest(direct[cid])))
   r=dict(direct[cid],acceptance='Earlier development acceptance with targeted review of the current repair; not a fresh independent full-program judgment.')
  pool.append(r)
 write(RUN/'corpus_reviewed.jsonl',pool)
 (RUN/'semantic_review.json').write_text(json.dumps(dict(provenance='All changed complete programs in the fixed449 cohort inspected by the compiler author; unchanged programs reuse exact program/form judgments. Most older retained claims are not fully re-reviewed.',cases=reviews,targeted_retained_changes=retained_changes),ensure_ascii=False,indent=2)+'\n')
 ledger=[]
 for r in pool:
  if r['status']=='compiled':continue
  cid=r['claim_id'];p=by_current.get(cid);out=p['output']if p else direct[cid];review=by_review.get(cid)
  ledger.append(dict(claim_id=cid,text=r['text'],stage='meaning_review'if out['status']=='compiled'else p['stage']if p else'direct_refusal_without_cached_rewrite',code='meaning_review'if out['status']=='compiled'else out.get('code'),reason=review['reason']if out['status']=='compiled'else out.get('reason'),diagnostic_output=slim(out)))
 for name,data in [('remaining_cases.json',ledger),('cases.json',cases),('retained_changes.json',retained_changes)]: (RUN/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 stats=dict(corpus=dict(total=len(pool),previous_accepted=1963,accepted=sum(r['status']=='compiled'for r in pool),remaining=len(ledger),new_approved=len(additions),new_ids=additions,rate=sum(r['status']=='compiled'for r in pool)/len(pool)),direct=dict(before=1978,final=sum(r['status']=='compiled'for r in direct.values()),lost_passes=[cid for cid,r in direct.items()if r['status']!='compiled'and old_direct[cid]['status']=='compiled'],failures=dict(Counter(r.get('code')for r in direct.values()if r['status']!='compiled'))),cached=dict(total=len(current),before_programs=108,programs=sum(r['output']['status']=='compiled'for r in current),stages=dict(Counter(r['stage']for r in current)),approved=len(approved),changed_reviewed=len(changed),exact_reviews_reused=sum(r['review_type']=='exact_program_and_form_review_reused'for r in reviews)),remaining=dict(stages=dict(Counter(r['stage']for r in ledger)),codes=dict(Counter(r['code']for r in ledger))),targeted_retained_changes=len(retained_changes),training='Deferred; compiler remains the priority. Model pilots are not pooled into corpus coverage.')
 (RUN/'summary.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
