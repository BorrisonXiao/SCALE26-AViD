"""Check that exact inference respects categorical and repeated evidence."""
import pytest

from evaluate_visual_assignments import comparison, constructed_controls
from probabilistic_verification.logic import enumerate_probability


def test_two_assignments_with_exclusive_region_identities_add_their_mass():
    ambiguous = {'distribution':[.5,.5,0.]}
    regions = [dict(identity=ambiguous,value=ambiguous) for _ in range(2)]
    program, masses = comparison(dict(pair_id='frame'),'original',regions,False)
    assert masses == [.0625,.0625]
    assert enumerate_probability(program)['supported']==.125


def test_repeated_observations_do_not_act_as_independent_votes():
    probabilities = [enumerate_probability(p)['supported'] for p,_,_ in constructed_controls()]
    assert probabilities==pytest.approx([.6636,.6636,.546,.42])
