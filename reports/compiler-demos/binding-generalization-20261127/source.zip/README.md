# Implicit speech alternatives and competing visual assignments

## Speech without explicit “or”

The test uses 12 recordings from eight AMI meeting series outside the earlier experiments. Eight original excerpts contain a choice or a contrast between alternatives. Four natural negatives present one option or add several features without presenting them as alternatives. Each positive also has a changed option, a request for the wrong speaker, and a version with the second part assigned to a different speaker. This gives eight positive and 28 negative queries. The chosen words and case readings were checked by the implementing assistant and frozen before model scoring. They remain development judgments. The report spans have annotated speaker labels and timestamps, and some use multiple nearby segments from the same speaker. Span grouping comes from the review. [AMI corpus](https://groups.inf.ed.ac.uk/ami/download/)

The frozen DeBERTa encoder scores content against each span. Three exact programs use identical scores and metadata. The first can use different spans for the matching speaker/time and the supported content. The second requires the same span. The third also requires the previously defined wording pattern, which recognizes explicit “or” or phrases such as “another option.” We reuse the earlier calibration fit and retain the 0.5 support threshold. There is no new fit on this set. [DeBERTa checkpoint](https://huggingface.co/cross-encoder/nli-deberta-v3-small)

With raw scores, the separate-span program supports seven of eight valid reports and ten of 28 negative queries. Same-span binding keeps those seven valid reports and reduces false support to three. All six wrong-speaker errors and the one split-speaker error disappear. The three remaining errors are one changed option and two additive reports treated as alternatives. For example, the model supports a claim that only one of the audio and screen submenus should be implemented, where the speaker actually proposed both and also a channel submenu.

With the previous calibration, same-span binding reduces false support from four to zero. Both methods support four of eight valid reports. The wording-check condition supports zero of eight valid reports at either score scale. It misses cases like “another way,” “can also,” and “instead of.” Several of the negatives also use “can also,” so adding the phrase as a required word pattern would confuse options with additions. The next speech comparison should score that distinction explicitly while holding speaker and span fixed. The test verifies 216 native support probabilities against the direct calculation. AMI transcript excerpts are © the University of Edinburgh and partners, under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

## Visual and OCR assignments

We use the five previously reviewed visual and OCR frame pairs, with the observed and swapped claim for each source. For visual cases, frozen Qwen3-VL chooses among two identities or values and an unclear option for each region crop. We average the two orders of the first two answer choices. The probabilities are normalized over those three letters. For OCR, crop coordinates supply the left/right identity and the model scores the two candidate strings. The crops and prompts are fixed before inference. We use original crops and a version downsampled to fit 64 by 40 pixels and resized back to the same input dimensions. The GPU job used one L40S for 3 minutes 25 seconds. Frames and model weights are available separately. [Five reviewed media pairs](https://borrisonxiao.github.io/SCALE26-AViD/reports/compiler-demos.html#binding-contrasts)

An assignment links both named referents to distinct regions and checks both reported values. For each crop we represent the two proposed identities as mutually exclusive outcomes, with an unknown state. We do the same for values. Each assignment's support combines the two identity and two value scores. This pilot assumes observations about identity and value are independent. The filtered baseline takes the highest complete assignment score. DeepProbLog computes the probability that either assignment succeeds. The two assignments are disjoint because a region has one identity in each possible world. We check their sum and independently enumerate the possible worlds to verify every native distribution.

Both methods get nine of ten decisions on original crops and seven of ten on reduced-resolution crops. They agree on all 20 decisions. The scores differ by more than 0.0000000001 on two queries, both below the decision threshold. The largest difference is about 0.000000023. The original miss comes from low confidence in the blue tie. With reduced resolution, the gray aircraft paint and the right-panel date also receive low confidence. Combining assignments cannot supply the missing visual information in these examples.

Four separate controls use stipulated observations to show when probability matters. Each assignment alone has support 0.42. With two independent assignments, exact support rises to 0.6636. It crosses the decision threshold for both a supported control and a control where both readings are wrong. Reusing an uncertain title across two proofs gives 0.546. Repeating the exact same reading leaves support at 0.42. These arithmetic checks show both the potential benefit and the risk of aggregating uncertain evidence. The fixed-frame experiment gives no measured decision gain from aggregation.

## Next steps

- Compare a learned or frozen score for “presented as alternatives” against a lexical check using independently reviewed reports and additions. Goal is to recover valid implicit choices while preserving the speaker and span constraint.
- Add a small set of real scenes with several similar candidate objects or OCR regions. Goal is to test probability aggregation where competing complete assignments have meaningful scores. Keep the best-assignment calculation as a baseline.

## Replay

Use Python 3.12 with the bundled requirements, NumPy 2.2.6, and SciPy 1.17.1. The archive has frozen speech spans with AMI segment and word IDs, raw predictions, the calibration fit, crop coordinates and source hashes, and exact logic programs. Replay uses the cached scorer outputs.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
python scripts/evaluate_ami_implicit_binding.py evaluate
python scripts/evaluate_visual_assignments.py
python scripts/binding_generalization_report.py
python -m pytest -q tests/test_visual_assignments.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/binding_generalization_20261127')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```
