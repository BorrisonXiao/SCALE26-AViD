% Exact categorical evidence; internal unknown = neither supported nor refuted.
0.99989136390345834::status(o_05630961776f937d63c8,supported); 2.3827075617277055e-05::status(o_05630961776f937d63c8,refuted); 8.4809020924476433e-05::status(o_05630961776f937d63c8,unknown).
0.99997712104162439::status(o_066985fca05462e6b33f,supported); 2.8082328927861833e-06::status(o_066985fca05462e6b33f,refuted); 2.0070725482894102e-05::status(o_066985fca05462e6b33f,unknown).
0::status(o_06a8722dfd863a54deb7,supported); 1::status(o_06a8722dfd863a54deb7,refuted); 0::status(o_06a8722dfd863a54deb7,unknown).
4.3157255361158319e-05::status(o_06b8a15c947bd1f0ec36,supported); 0.99984070224380506::status(o_06b8a15c947bd1f0ec36,refuted); 0.00011614050083377908::status(o_06b8a15c947bd1f0ec36,unknown).
0.99442912353116109::status(o_06fa7836deda953197b9,supported); 7.574234262181195e-06::status(o_06fa7836deda953197b9,refuted); 0.005563302234576681::status(o_06fa7836deda953197b9,unknown).
1::status(o_09a62b19793132727adc,supported); 0::status(o_09a62b19793132727adc,refuted); 0::status(o_09a62b19793132727adc,unknown).
0::status(o_0a89564c9218baa3cb30,supported); 1::status(o_0a89564c9218baa3cb30,refuted); 0::status(o_0a89564c9218baa3cb30,unknown).
0.69999999999999996::status(o_0d4cf78bcd4d3b9e7ba2,supported); 0::status(o_0d4cf78bcd4d3b9e7ba2,refuted); 0.30000000000000004::status(o_0d4cf78bcd4d3b9e7ba2,unknown).
0.99229112104589912::status(o_13f107a09bdf215603f8,supported); 9.356087290780228e-05::status(o_13f107a09bdf215603f8,refuted); 0.0076153180811930577::status(o_13f107a09bdf215603f8,unknown).
0.14139053998292522::status(o_16c8c9ec15372a6e0485,supported); 2.495055885517396e-05::status(o_16c8c9ec15372a6e0485,refuted); 0.85858450945821962::status(o_16c8c9ec15372a6e0485,unknown).
0.00011654847067529568::status(o_1adc6e11187be36aedf8,supported); 0.0011611766798381991::status(o_1adc6e11187be36aedf8,refuted); 0.99872227484948661::status(o_1adc6e11187be36aedf8,unknown).
1::status(o_2f0fe09f3326649bc4ec,supported); 0::status(o_2f0fe09f3326649bc4ec,refuted); 0::status(o_2f0fe09f3326649bc4ec,unknown).
0.59999999999999998::status(o_30242701a0c8d92f807d,supported); 0::status(o_30242701a0c8d92f807d,refuted); 0.40000000000000002::status(o_30242701a0c8d92f807d,unknown).
4.2099744511301047e-07::status(o_3049f359889b8ba41e1b,supported); 0.99999922508755779::status(o_3049f359889b8ba41e1b,refuted); 3.5391499691602959e-07::status(o_3049f359889b8ba41e1b,unknown).
3.2684140769800168e-06::status(o_3e5b62075b939aa2e237,supported); 0.99998487901588695::status(o_3e5b62075b939aa2e237,refuted); 1.1852570036156754e-05::status(o_3e5b62075b939aa2e237,unknown).
0.0014706059963120802::status(o_51e2ac077b7fa43639a4,supported); 0.52769870080218706::status(o_51e2ac077b7fa43639a4,refuted); 0.47083069320150084::status(o_51e2ac077b7fa43639a4,unknown).
1.5660452311358157e-05::status(o_5ef6d80999e3af0ff693,supported); 0.96969796747067027::status(o_5ef6d80999e3af0ff693,refuted); 0.030286372077018259::status(o_5ef6d80999e3af0ff693,unknown).
5.9594529309001788e-06::status(o_733cd00b54646f34bf1c,supported); 0.99977302509496635::status(o_733cd00b54646f34bf1c,refuted); 0.00022101545210286328::status(o_733cd00b54646f34bf1c,unknown).
3.0340878594780739e-06::status(o_742c84b8958207e62ca2,supported); 0.99982326706730362::status(o_742c84b8958207e62ca2,refuted); 0.0001736988448369737::status(o_742c84b8958207e62ca2,unknown).
0.59999999999999998::status(o_7605add03db93cd33516,supported); 0::status(o_7605add03db93cd33516,refuted); 0.40000000000000002::status(o_7605add03db93cd33516,unknown).
1::status(o_771dad9b4d87cb7d8d95,supported); 0::status(o_771dad9b4d87cb7d8d95,refuted); 0::status(o_771dad9b4d87cb7d8d95,unknown).
0.97882434890650638::status(o_77e33c00081ee4a38b89,supported); 0.01890327628341475::status(o_77e33c00081ee4a38b89,refuted); 0.0022723748100789334::status(o_77e33c00081ee4a38b89,unknown).
0.99058674009530323::status(o_97f77cce66292766d577,supported); 1.8389979324139361e-05::status(o_97f77cce66292766d577,refuted); 0.0093948699253726987::status(o_97f77cce66292766d577,unknown).
1.3997478742537075e-06::status(o_9e4532d5d6f57aea1030,supported); 0.99999313305079862::status(o_9e4532d5d6f57aea1030,refuted); 5.4672013271142531e-06::status(o_9e4532d5d6f57aea1030,unknown).
1::status(o_a18eec4339f760117291,supported); 0::status(o_a18eec4339f760117291,refuted); 0::status(o_a18eec4339f760117291,unknown).
0.37923205300338114::status(o_a270833b6efdb217d2a2,supported); 0.00026320632707587061::status(o_a270833b6efdb217d2a2,refuted); 0.62050474066954298::status(o_a270833b6efdb217d2a2,unknown).
3.2684398724583826e-06::status(o_a6a3c2cc4af3c5b6ce74,supported); 0.99998877688043009::status(o_a6a3c2cc4af3c5b6ce74,refuted); 7.9546796973367326e-06::status(o_a6a3c2cc4af3c5b6ce74,unknown).
0.0038625254394711083::status(o_adbafde3d84668363672,supported); 6.0986032926827831e-06::status(o_adbafde3d84668363672,refuted); 0.99613137595723633::status(o_adbafde3d84668363672,unknown).
0::status(o_b0064988593e45befcc8,supported); 1::status(o_b0064988593e45befcc8,refuted); 0::status(o_b0064988593e45befcc8,unknown).
0.98958833182634498::status(o_bbc476277e836c588ef0,supported); 1.8383844891719565e-05::status(o_bbc476277e836c588ef0,refuted); 0.0103932843287633::status(o_bbc476277e836c588ef0,unknown).
0.002374301364711149::status(o_c26caeeb6d72d737c8bc,supported); 0.99329554995721592::status(o_c26caeeb6d72d737c8bc,refuted); 0.0043301486780730133::status(o_c26caeeb6d72d737c8bc,unknown).
0::status(o_cd5431c587e8bc5922d1,supported); 1::status(o_cd5431c587e8bc5922d1,refuted); 0::status(o_cd5431c587e8bc5922d1,unknown).
0.99998700639749227::status(o_d7febcf42d77cd6b89d6,supported); 5.5360887786938826e-06::status(o_d7febcf42d77cd6b89d6,refuted); 7.4575137290996817e-06::status(o_d7febcf42d77cd6b89d6,unknown).
0.69999999999999996::status(o_d879f9b42b5ee9a7c9e6,supported); 0::status(o_d879f9b42b5ee9a7c9e6,refuted); 0.30000000000000004::status(o_d879f9b42b5ee9a7c9e6,unknown).
0.99999733936499091::status(o_d8c423120f1c90211fac,supported); 6.9219625237329915e-07::status(o_d8c423120f1c90211fac,refuted); 1.9684387566763868e-06::status(o_d8c423120f1c90211fac,unknown).
1.0459647310567031e-05::status(o_dc07e242e3c0329c63c4,supported); 0.99996017184310526::status(o_dc07e242e3c0329c63c4,refuted); 2.9368509584212291e-05::status(o_dc07e242e3c0329c63c4,unknown).
2.1296388385098041e-06::status(o_e7aa10056f847a9ee236,supported); 0.99998673216823064::status(o_e7aa10056f847a9ee236,refuted); 1.113819293084749e-05::status(o_e7aa10056f847a9ee236,unknown).
0.95227748144542512::status(o_ea96ebca60b26c62564c,supported); 2.0598447799620655e-05::status(o_ea96ebca60b26c62564c,refuted); 0.04770192010677534::status(o_ea96ebca60b26c62564c,unknown).
8.289538509062903e-06::status(o_f2231448dca25f000b7b,supported); 0.99295427334611142::status(o_f2231448dca25f000b7b,refuted); 0.0070374371153796413::status(o_f2231448dca25f000b7b,unknown).
0.99975710502328052::status(o_f3bd28f64fbb37de4170,supported); 5.1538808218811342e-06::status(o_f3bd28f64fbb37de4170,refuted); 0.00023774109589759485::status(o_f3bd28f64fbb37de4170,unknown).
1.9560139718330069e-06::status(o_f3f087a45856846c2e97,supported); 0.99997494012783095::status(o_f3f087a45856846c2e97,refuted); 2.3103858197248304e-05::status(o_f3f087a45856846c2e97,unknown).
0.31011585764813948::status(o_f53eadd21d36a1d4587f,supported); 3.9989888801368007e-05::status(o_f53eadd21d36a1d4587f,refuted); 0.68984415246305919::status(o_f53eadd21d36a1d4587f,unknown).
0.0027105037140113817::status(o_f5f95ed09d824fa37d5f,supported); 0.99701770074021445::status(o_f5f95ed09d824fa37d5f,refuted); 0.00027179554577420764::status(o_f5f95ed09d824fa37d5f,unknown).
0.99966146514238008::status(o_f8fc3c50d44c0d92a279,supported); 1.5914975861419491e-05::status(o_f8fc3c50d44c0d92a279,refuted); 0.00032261988175845668::status(o_f8fc3c50d44c0d92a279,unknown).
node(n2,supported) :- status(o_f8fc3c50d44c0d92a279,supported).
node(n2,refuted) :- status(o_f8fc3c50d44c0d92a279,refuted).
node(n2,unknown) :- status(o_f8fc3c50d44c0d92a279,unknown).
node(n4,supported) :- status(o_f5f95ed09d824fa37d5f,supported).
node(n4,refuted) :- status(o_f5f95ed09d824fa37d5f,refuted).
node(n4,unknown) :- status(o_f5f95ed09d824fa37d5f,unknown).
node(n3,supported) :- node(n4,refuted).
node(n3,refuted) :- node(n4,supported).
node(n3,unknown) :- \+ node(n3,supported), \+ node(n3,refuted).
node(n5,supported) :- status(o_f3bd28f64fbb37de4170,supported).
node(n5,refuted) :- status(o_f3bd28f64fbb37de4170,refuted).
node(n5,unknown) :- status(o_f3bd28f64fbb37de4170,unknown).
node(n7,supported) :- status(o_a6a3c2cc4af3c5b6ce74,supported).
node(n7,refuted) :- status(o_a6a3c2cc4af3c5b6ce74,refuted).
node(n7,unknown) :- status(o_a6a3c2cc4af3c5b6ce74,unknown).
node(n6,supported) :- node(n7,refuted).
node(n6,refuted) :- node(n7,supported).
node(n6,unknown) :- \+ node(n6,supported), \+ node(n6,refuted).
node(n1,supported) :- node(n2,supported), node(n3,supported), node(n5,supported), node(n6,supported).
node(n1,refuted) :- node(n2,refuted).
node(n1,refuted) :- node(n3,refuted).
node(n1,refuted) :- node(n5,refuted).
node(n1,refuted) :- node(n6,refuted).
node(n1,unknown) :- \+ node(n1,supported), \+ node(n1,refuted).
node(n9,supported) :- node(n2,refuted).
node(n9,refuted) :- node(n2,supported).
node(n9,unknown) :- \+ node(n9,supported), \+ node(n9,refuted).
node(n10,supported) :- node(n5,refuted).
node(n10,refuted) :- node(n5,supported).
node(n10,unknown) :- \+ node(n10,supported), \+ node(n10,refuted).
node(n8,supported) :- node(n4,supported), node(n9,supported), node(n7,supported), node(n10,supported).
node(n8,refuted) :- node(n4,refuted).
node(n8,refuted) :- node(n9,refuted).
node(n8,refuted) :- node(n7,refuted).
node(n8,refuted) :- node(n10,refuted).
node(n8,unknown) :- \+ node(n8,supported), \+ node(n8,refuted).
node(n0,refuted) :- node(n1,refuted), node(n8,refuted).
node(n0,supported) :- node(n1,supported).
node(n0,supported) :- node(n8,supported).
node(n0,unknown) :- \+ node(n0,supported), \+ node(n0,refuted).
verdict(c_770a81df115b3c51,supported) :- node(n0,supported).
query(verdict(c_770a81df115b3c51,supported)).
verdict(c_770a81df115b3c51,refuted) :- node(n0,refuted).
query(verdict(c_770a81df115b3c51,refuted)).
verdict(c_770a81df115b3c51,unknown) :- node(n0,unknown).
query(verdict(c_770a81df115b3c51,unknown)).
node(n12,supported) :- node(n2,supported), node(n3,supported), node(n10,supported), node(n7,supported).
node(n12,refuted) :- node(n2,refuted).
node(n12,refuted) :- node(n3,refuted).
node(n12,refuted) :- node(n10,refuted).
node(n12,refuted) :- node(n7,refuted).
node(n12,unknown) :- \+ node(n12,supported), \+ node(n12,refuted).
node(n13,supported) :- node(n4,supported), node(n9,supported), node(n6,supported), node(n5,supported).
node(n13,refuted) :- node(n4,refuted).
node(n13,refuted) :- node(n9,refuted).
node(n13,refuted) :- node(n6,refuted).
node(n13,refuted) :- node(n5,refuted).
node(n13,unknown) :- \+ node(n13,supported), \+ node(n13,refuted).
node(n11,refuted) :- node(n12,refuted), node(n13,refuted).
node(n11,supported) :- node(n12,supported).
node(n11,supported) :- node(n13,supported).
node(n11,unknown) :- \+ node(n11,supported), \+ node(n11,refuted).
verdict(c_1fc7e68516af0ac6,supported) :- node(n11,supported).
query(verdict(c_1fc7e68516af0ac6,supported)).
verdict(c_1fc7e68516af0ac6,refuted) :- node(n11,refuted).
query(verdict(c_1fc7e68516af0ac6,refuted)).
verdict(c_1fc7e68516af0ac6,unknown) :- node(n11,unknown).
query(verdict(c_1fc7e68516af0ac6,unknown)).
node(n16,supported) :- status(o_06fa7836deda953197b9,supported).
node(n16,refuted) :- status(o_06fa7836deda953197b9,refuted).
node(n16,unknown) :- status(o_06fa7836deda953197b9,unknown).
node(n18,supported) :- status(o_f3f087a45856846c2e97,supported).
node(n18,refuted) :- status(o_f3f087a45856846c2e97,refuted).
node(n18,unknown) :- status(o_f3f087a45856846c2e97,unknown).
node(n17,supported) :- node(n18,refuted).
node(n17,refuted) :- node(n18,supported).
node(n17,unknown) :- \+ node(n17,supported), \+ node(n17,refuted).
node(n19,supported) :- status(o_16c8c9ec15372a6e0485,supported).
node(n19,refuted) :- status(o_16c8c9ec15372a6e0485,refuted).
node(n19,unknown) :- status(o_16c8c9ec15372a6e0485,unknown).
node(n21,supported) :- status(o_742c84b8958207e62ca2,supported).
node(n21,refuted) :- status(o_742c84b8958207e62ca2,refuted).
node(n21,unknown) :- status(o_742c84b8958207e62ca2,unknown).
node(n20,supported) :- node(n21,refuted).
node(n20,refuted) :- node(n21,supported).
node(n20,unknown) :- \+ node(n20,supported), \+ node(n20,refuted).
node(n15,supported) :- node(n16,supported), node(n17,supported), node(n19,supported), node(n20,supported).
node(n15,refuted) :- node(n16,refuted).
node(n15,refuted) :- node(n17,refuted).
node(n15,refuted) :- node(n19,refuted).
node(n15,refuted) :- node(n20,refuted).
node(n15,unknown) :- \+ node(n15,supported), \+ node(n15,refuted).
node(n23,supported) :- node(n16,refuted).
node(n23,refuted) :- node(n16,supported).
node(n23,unknown) :- \+ node(n23,supported), \+ node(n23,refuted).
node(n24,supported) :- node(n19,refuted).
node(n24,refuted) :- node(n19,supported).
node(n24,unknown) :- \+ node(n24,supported), \+ node(n24,refuted).
node(n22,supported) :- node(n18,supported), node(n23,supported), node(n21,supported), node(n24,supported).
node(n22,refuted) :- node(n18,refuted).
node(n22,refuted) :- node(n23,refuted).
node(n22,refuted) :- node(n21,refuted).
node(n22,refuted) :- node(n24,refuted).
node(n22,unknown) :- \+ node(n22,supported), \+ node(n22,refuted).
node(n14,refuted) :- node(n15,refuted), node(n22,refuted).
node(n14,supported) :- node(n15,supported).
node(n14,supported) :- node(n22,supported).
node(n14,unknown) :- \+ node(n14,supported), \+ node(n14,refuted).
verdict(c_aa005a38f1dbffff,supported) :- node(n14,supported).
query(verdict(c_aa005a38f1dbffff,supported)).
verdict(c_aa005a38f1dbffff,refuted) :- node(n14,refuted).
query(verdict(c_aa005a38f1dbffff,refuted)).
verdict(c_aa005a38f1dbffff,unknown) :- node(n14,unknown).
query(verdict(c_aa005a38f1dbffff,unknown)).
node(n26,supported) :- node(n16,supported), node(n17,supported), node(n24,supported), node(n21,supported).
node(n26,refuted) :- node(n16,refuted).
node(n26,refuted) :- node(n17,refuted).
node(n26,refuted) :- node(n24,refuted).
node(n26,refuted) :- node(n21,refuted).
node(n26,unknown) :- \+ node(n26,supported), \+ node(n26,refuted).
node(n27,supported) :- node(n18,supported), node(n23,supported), node(n20,supported), node(n19,supported).
node(n27,refuted) :- node(n18,refuted).
node(n27,refuted) :- node(n23,refuted).
node(n27,refuted) :- node(n20,refuted).
node(n27,refuted) :- node(n19,refuted).
node(n27,unknown) :- \+ node(n27,supported), \+ node(n27,refuted).
node(n25,refuted) :- node(n26,refuted), node(n27,refuted).
node(n25,supported) :- node(n26,supported).
node(n25,supported) :- node(n27,supported).
node(n25,unknown) :- \+ node(n25,supported), \+ node(n25,refuted).
verdict(c_a58486968260335f,supported) :- node(n25,supported).
query(verdict(c_a58486968260335f,supported)).
verdict(c_a58486968260335f,refuted) :- node(n25,refuted).
query(verdict(c_a58486968260335f,refuted)).
verdict(c_a58486968260335f,unknown) :- node(n25,unknown).
query(verdict(c_a58486968260335f,unknown)).
node(n30,supported) :- status(o_2f0fe09f3326649bc4ec,supported).
node(n30,refuted) :- status(o_2f0fe09f3326649bc4ec,refuted).
node(n30,unknown) :- status(o_2f0fe09f3326649bc4ec,unknown).
node(n32,supported) :- status(o_cd5431c587e8bc5922d1,supported).
node(n32,refuted) :- status(o_cd5431c587e8bc5922d1,refuted).
node(n32,unknown) :- status(o_cd5431c587e8bc5922d1,unknown).
node(n31,supported) :- node(n32,refuted).
node(n31,refuted) :- node(n32,supported).
node(n31,unknown) :- \+ node(n31,supported), \+ node(n31,refuted).
node(n33,supported) :- status(o_d8c423120f1c90211fac,supported).
node(n33,refuted) :- status(o_d8c423120f1c90211fac,refuted).
node(n33,unknown) :- status(o_d8c423120f1c90211fac,unknown).
node(n35,supported) :- status(o_3049f359889b8ba41e1b,supported).
node(n35,refuted) :- status(o_3049f359889b8ba41e1b,refuted).
node(n35,unknown) :- status(o_3049f359889b8ba41e1b,unknown).
node(n34,supported) :- node(n35,refuted).
node(n34,refuted) :- node(n35,supported).
node(n34,unknown) :- \+ node(n34,supported), \+ node(n34,refuted).
node(n29,supported) :- node(n30,supported), node(n31,supported), node(n33,supported), node(n34,supported).
node(n29,refuted) :- node(n30,refuted).
node(n29,refuted) :- node(n31,refuted).
node(n29,refuted) :- node(n33,refuted).
node(n29,refuted) :- node(n34,refuted).
node(n29,unknown) :- \+ node(n29,supported), \+ node(n29,refuted).
node(n37,supported) :- node(n30,refuted).
node(n37,refuted) :- node(n30,supported).
node(n37,unknown) :- \+ node(n37,supported), \+ node(n37,refuted).
node(n38,supported) :- node(n33,refuted).
node(n38,refuted) :- node(n33,supported).
node(n38,unknown) :- \+ node(n38,supported), \+ node(n38,refuted).
node(n36,supported) :- node(n32,supported), node(n37,supported), node(n35,supported), node(n38,supported).
node(n36,refuted) :- node(n32,refuted).
node(n36,refuted) :- node(n37,refuted).
node(n36,refuted) :- node(n35,refuted).
node(n36,refuted) :- node(n38,refuted).
node(n36,unknown) :- \+ node(n36,supported), \+ node(n36,refuted).
node(n28,refuted) :- node(n29,refuted), node(n36,refuted).
node(n28,supported) :- node(n29,supported).
node(n28,supported) :- node(n36,supported).
node(n28,unknown) :- \+ node(n28,supported), \+ node(n28,refuted).
verdict(c_b3ddb53653f28fb9,supported) :- node(n28,supported).
query(verdict(c_b3ddb53653f28fb9,supported)).
verdict(c_b3ddb53653f28fb9,refuted) :- node(n28,refuted).
query(verdict(c_b3ddb53653f28fb9,refuted)).
verdict(c_b3ddb53653f28fb9,unknown) :- node(n28,unknown).
query(verdict(c_b3ddb53653f28fb9,unknown)).
node(n40,supported) :- node(n30,supported), node(n31,supported), node(n38,supported), node(n35,supported).
node(n40,refuted) :- node(n30,refuted).
node(n40,refuted) :- node(n31,refuted).
node(n40,refuted) :- node(n38,refuted).
node(n40,refuted) :- node(n35,refuted).
node(n40,unknown) :- \+ node(n40,supported), \+ node(n40,refuted).
node(n41,supported) :- node(n32,supported), node(n37,supported), node(n34,supported), node(n33,supported).
node(n41,refuted) :- node(n32,refuted).
node(n41,refuted) :- node(n37,refuted).
node(n41,refuted) :- node(n34,refuted).
node(n41,refuted) :- node(n33,refuted).
node(n41,unknown) :- \+ node(n41,supported), \+ node(n41,refuted).
node(n39,refuted) :- node(n40,refuted), node(n41,refuted).
node(n39,supported) :- node(n40,supported).
node(n39,supported) :- node(n41,supported).
node(n39,unknown) :- \+ node(n39,supported), \+ node(n39,refuted).
verdict(c_628dac4801f859c6,supported) :- node(n39,supported).
query(verdict(c_628dac4801f859c6,supported)).
verdict(c_628dac4801f859c6,refuted) :- node(n39,refuted).
query(verdict(c_628dac4801f859c6,refuted)).
verdict(c_628dac4801f859c6,unknown) :- node(n39,unknown).
query(verdict(c_628dac4801f859c6,unknown)).
node(n44,supported) :- status(o_09a62b19793132727adc,supported).
node(n44,refuted) :- status(o_09a62b19793132727adc,refuted).
node(n44,unknown) :- status(o_09a62b19793132727adc,unknown).
node(n46,supported) :- status(o_0a89564c9218baa3cb30,supported).
node(n46,refuted) :- status(o_0a89564c9218baa3cb30,refuted).
node(n46,unknown) :- status(o_0a89564c9218baa3cb30,unknown).
node(n45,supported) :- node(n46,refuted).
node(n45,refuted) :- node(n46,supported).
node(n45,unknown) :- \+ node(n45,supported), \+ node(n45,refuted).
node(n47,supported) :- status(o_ea96ebca60b26c62564c,supported).
node(n47,refuted) :- status(o_ea96ebca60b26c62564c,refuted).
node(n47,unknown) :- status(o_ea96ebca60b26c62564c,unknown).
node(n49,supported) :- status(o_1adc6e11187be36aedf8,supported).
node(n49,refuted) :- status(o_1adc6e11187be36aedf8,refuted).
node(n49,unknown) :- status(o_1adc6e11187be36aedf8,unknown).
node(n48,supported) :- node(n49,refuted).
node(n48,refuted) :- node(n49,supported).
node(n48,unknown) :- \+ node(n48,supported), \+ node(n48,refuted).
node(n43,supported) :- node(n44,supported), node(n45,supported), node(n47,supported), node(n48,supported).
node(n43,refuted) :- node(n44,refuted).
node(n43,refuted) :- node(n45,refuted).
node(n43,refuted) :- node(n47,refuted).
node(n43,refuted) :- node(n48,refuted).
node(n43,unknown) :- \+ node(n43,supported), \+ node(n43,refuted).
node(n51,supported) :- node(n44,refuted).
node(n51,refuted) :- node(n44,supported).
node(n51,unknown) :- \+ node(n51,supported), \+ node(n51,refuted).
node(n52,supported) :- node(n47,refuted).
node(n52,refuted) :- node(n47,supported).
node(n52,unknown) :- \+ node(n52,supported), \+ node(n52,refuted).
node(n50,supported) :- node(n46,supported), node(n51,supported), node(n49,supported), node(n52,supported).
node(n50,refuted) :- node(n46,refuted).
node(n50,refuted) :- node(n51,refuted).
node(n50,refuted) :- node(n49,refuted).
node(n50,refuted) :- node(n52,refuted).
node(n50,unknown) :- \+ node(n50,supported), \+ node(n50,refuted).
node(n42,refuted) :- node(n43,refuted), node(n50,refuted).
node(n42,supported) :- node(n43,supported).
node(n42,supported) :- node(n50,supported).
node(n42,unknown) :- \+ node(n42,supported), \+ node(n42,refuted).
verdict(c_0a1ea26c24856470,supported) :- node(n42,supported).
query(verdict(c_0a1ea26c24856470,supported)).
verdict(c_0a1ea26c24856470,refuted) :- node(n42,refuted).
query(verdict(c_0a1ea26c24856470,refuted)).
verdict(c_0a1ea26c24856470,unknown) :- node(n42,unknown).
query(verdict(c_0a1ea26c24856470,unknown)).
node(n54,supported) :- node(n44,supported), node(n45,supported), node(n52,supported), node(n49,supported).
node(n54,refuted) :- node(n44,refuted).
node(n54,refuted) :- node(n45,refuted).
node(n54,refuted) :- node(n52,refuted).
node(n54,refuted) :- node(n49,refuted).
node(n54,unknown) :- \+ node(n54,supported), \+ node(n54,refuted).
node(n55,supported) :- node(n46,supported), node(n51,supported), node(n48,supported), node(n47,supported).
node(n55,refuted) :- node(n46,refuted).
node(n55,refuted) :- node(n51,refuted).
node(n55,refuted) :- node(n48,refuted).
node(n55,refuted) :- node(n47,refuted).
node(n55,unknown) :- \+ node(n55,supported), \+ node(n55,refuted).
node(n53,refuted) :- node(n54,refuted), node(n55,refuted).
node(n53,supported) :- node(n54,supported).
node(n53,supported) :- node(n55,supported).
node(n53,unknown) :- \+ node(n53,supported), \+ node(n53,refuted).
verdict(c_46f5831ae4e13969,supported) :- node(n53,supported).
query(verdict(c_46f5831ae4e13969,supported)).
verdict(c_46f5831ae4e13969,refuted) :- node(n53,refuted).
query(verdict(c_46f5831ae4e13969,refuted)).
verdict(c_46f5831ae4e13969,unknown) :- node(n53,unknown).
query(verdict(c_46f5831ae4e13969,unknown)).
node(n58,supported) :- status(o_066985fca05462e6b33f,supported).
node(n58,refuted) :- status(o_066985fca05462e6b33f,refuted).
node(n58,unknown) :- status(o_066985fca05462e6b33f,unknown).
node(n60,supported) :- status(o_06b8a15c947bd1f0ec36,supported).
node(n60,refuted) :- status(o_06b8a15c947bd1f0ec36,refuted).
node(n60,unknown) :- status(o_06b8a15c947bd1f0ec36,unknown).
node(n59,supported) :- node(n60,refuted).
node(n59,refuted) :- node(n60,supported).
node(n59,unknown) :- \+ node(n59,supported), \+ node(n59,refuted).
node(n61,supported) :- status(o_77e33c00081ee4a38b89,supported).
node(n61,refuted) :- status(o_77e33c00081ee4a38b89,refuted).
node(n61,unknown) :- status(o_77e33c00081ee4a38b89,unknown).
node(n63,supported) :- status(o_dc07e242e3c0329c63c4,supported).
node(n63,refuted) :- status(o_dc07e242e3c0329c63c4,refuted).
node(n63,unknown) :- status(o_dc07e242e3c0329c63c4,unknown).
node(n62,supported) :- node(n63,refuted).
node(n62,refuted) :- node(n63,supported).
node(n62,unknown) :- \+ node(n62,supported), \+ node(n62,refuted).
node(n57,supported) :- node(n58,supported), node(n59,supported), node(n61,supported), node(n62,supported).
node(n57,refuted) :- node(n58,refuted).
node(n57,refuted) :- node(n59,refuted).
node(n57,refuted) :- node(n61,refuted).
node(n57,refuted) :- node(n62,refuted).
node(n57,unknown) :- \+ node(n57,supported), \+ node(n57,refuted).
node(n65,supported) :- node(n58,refuted).
node(n65,refuted) :- node(n58,supported).
node(n65,unknown) :- \+ node(n65,supported), \+ node(n65,refuted).
node(n66,supported) :- node(n61,refuted).
node(n66,refuted) :- node(n61,supported).
node(n66,unknown) :- \+ node(n66,supported), \+ node(n66,refuted).
node(n64,supported) :- node(n60,supported), node(n65,supported), node(n63,supported), node(n66,supported).
node(n64,refuted) :- node(n60,refuted).
node(n64,refuted) :- node(n65,refuted).
node(n64,refuted) :- node(n63,refuted).
node(n64,refuted) :- node(n66,refuted).
node(n64,unknown) :- \+ node(n64,supported), \+ node(n64,refuted).
node(n56,refuted) :- node(n57,refuted), node(n64,refuted).
node(n56,supported) :- node(n57,supported).
node(n56,supported) :- node(n64,supported).
node(n56,unknown) :- \+ node(n56,supported), \+ node(n56,refuted).
verdict(c_56946c00cef9733a,supported) :- node(n56,supported).
query(verdict(c_56946c00cef9733a,supported)).
verdict(c_56946c00cef9733a,refuted) :- node(n56,refuted).
query(verdict(c_56946c00cef9733a,refuted)).
verdict(c_56946c00cef9733a,unknown) :- node(n56,unknown).
query(verdict(c_56946c00cef9733a,unknown)).
node(n68,supported) :- node(n58,supported), node(n59,supported), node(n66,supported), node(n63,supported).
node(n68,refuted) :- node(n58,refuted).
node(n68,refuted) :- node(n59,refuted).
node(n68,refuted) :- node(n66,refuted).
node(n68,refuted) :- node(n63,refuted).
node(n68,unknown) :- \+ node(n68,supported), \+ node(n68,refuted).
node(n69,supported) :- node(n60,supported), node(n65,supported), node(n62,supported), node(n61,supported).
node(n69,refuted) :- node(n60,refuted).
node(n69,refuted) :- node(n65,refuted).
node(n69,refuted) :- node(n62,refuted).
node(n69,refuted) :- node(n61,refuted).
node(n69,unknown) :- \+ node(n69,supported), \+ node(n69,refuted).
node(n67,refuted) :- node(n68,refuted), node(n69,refuted).
node(n67,supported) :- node(n68,supported).
node(n67,supported) :- node(n69,supported).
node(n67,unknown) :- \+ node(n67,supported), \+ node(n67,refuted).
verdict(c_b6c4f8751e451f8b,supported) :- node(n67,supported).
query(verdict(c_b6c4f8751e451f8b,supported)).
verdict(c_b6c4f8751e451f8b,refuted) :- node(n67,refuted).
query(verdict(c_b6c4f8751e451f8b,refuted)).
verdict(c_b6c4f8751e451f8b,unknown) :- node(n67,unknown).
query(verdict(c_b6c4f8751e451f8b,unknown)).
node(n72,supported) :- status(o_97f77cce66292766d577,supported).
node(n72,refuted) :- status(o_97f77cce66292766d577,refuted).
node(n72,unknown) :- status(o_97f77cce66292766d577,unknown).
node(n74,supported) :- status(o_c26caeeb6d72d737c8bc,supported).
node(n74,refuted) :- status(o_c26caeeb6d72d737c8bc,refuted).
node(n74,unknown) :- status(o_c26caeeb6d72d737c8bc,unknown).
node(n73,supported) :- node(n74,refuted).
node(n73,refuted) :- node(n74,supported).
node(n73,unknown) :- \+ node(n73,supported), \+ node(n73,refuted).
node(n75,supported) :- status(o_13f107a09bdf215603f8,supported).
node(n75,refuted) :- status(o_13f107a09bdf215603f8,refuted).
node(n75,unknown) :- status(o_13f107a09bdf215603f8,unknown).
node(n77,supported) :- status(o_51e2ac077b7fa43639a4,supported).
node(n77,refuted) :- status(o_51e2ac077b7fa43639a4,refuted).
node(n77,unknown) :- status(o_51e2ac077b7fa43639a4,unknown).
node(n76,supported) :- node(n77,refuted).
node(n76,refuted) :- node(n77,supported).
node(n76,unknown) :- \+ node(n76,supported), \+ node(n76,refuted).
node(n71,supported) :- node(n72,supported), node(n73,supported), node(n75,supported), node(n76,supported).
node(n71,refuted) :- node(n72,refuted).
node(n71,refuted) :- node(n73,refuted).
node(n71,refuted) :- node(n75,refuted).
node(n71,refuted) :- node(n76,refuted).
node(n71,unknown) :- \+ node(n71,supported), \+ node(n71,refuted).
node(n79,supported) :- node(n72,refuted).
node(n79,refuted) :- node(n72,supported).
node(n79,unknown) :- \+ node(n79,supported), \+ node(n79,refuted).
node(n80,supported) :- node(n75,refuted).
node(n80,refuted) :- node(n75,supported).
node(n80,unknown) :- \+ node(n80,supported), \+ node(n80,refuted).
node(n78,supported) :- node(n74,supported), node(n79,supported), node(n77,supported), node(n80,supported).
node(n78,refuted) :- node(n74,refuted).
node(n78,refuted) :- node(n79,refuted).
node(n78,refuted) :- node(n77,refuted).
node(n78,refuted) :- node(n80,refuted).
node(n78,unknown) :- \+ node(n78,supported), \+ node(n78,refuted).
node(n70,refuted) :- node(n71,refuted), node(n78,refuted).
node(n70,supported) :- node(n71,supported).
node(n70,supported) :- node(n78,supported).
node(n70,unknown) :- \+ node(n70,supported), \+ node(n70,refuted).
verdict(c_53c11553d7a82f80,supported) :- node(n70,supported).
query(verdict(c_53c11553d7a82f80,supported)).
verdict(c_53c11553d7a82f80,refuted) :- node(n70,refuted).
query(verdict(c_53c11553d7a82f80,refuted)).
verdict(c_53c11553d7a82f80,unknown) :- node(n70,unknown).
query(verdict(c_53c11553d7a82f80,unknown)).
node(n82,supported) :- node(n72,supported), node(n73,supported), node(n80,supported), node(n77,supported).
node(n82,refuted) :- node(n72,refuted).
node(n82,refuted) :- node(n73,refuted).
node(n82,refuted) :- node(n80,refuted).
node(n82,refuted) :- node(n77,refuted).
node(n82,unknown) :- \+ node(n82,supported), \+ node(n82,refuted).
node(n83,supported) :- node(n74,supported), node(n79,supported), node(n76,supported), node(n75,supported).
node(n83,refuted) :- node(n74,refuted).
node(n83,refuted) :- node(n79,refuted).
node(n83,refuted) :- node(n76,refuted).
node(n83,refuted) :- node(n75,refuted).
node(n83,unknown) :- \+ node(n83,supported), \+ node(n83,refuted).
node(n81,refuted) :- node(n82,refuted), node(n83,refuted).
node(n81,supported) :- node(n82,supported).
node(n81,supported) :- node(n83,supported).
node(n81,unknown) :- \+ node(n81,supported), \+ node(n81,refuted).
verdict(c_ead46ed05497e5b6,supported) :- node(n81,supported).
query(verdict(c_ead46ed05497e5b6,supported)).
verdict(c_ead46ed05497e5b6,refuted) :- node(n81,refuted).
query(verdict(c_ead46ed05497e5b6,refuted)).
verdict(c_ead46ed05497e5b6,unknown) :- node(n81,unknown).
query(verdict(c_ead46ed05497e5b6,unknown)).
node(n86,supported) :- status(o_bbc476277e836c588ef0,supported).
node(n86,refuted) :- status(o_bbc476277e836c588ef0,refuted).
node(n86,unknown) :- status(o_bbc476277e836c588ef0,unknown).
node(n88,supported) :- status(o_9e4532d5d6f57aea1030,supported).
node(n88,refuted) :- status(o_9e4532d5d6f57aea1030,refuted).
node(n88,unknown) :- status(o_9e4532d5d6f57aea1030,unknown).
node(n87,supported) :- node(n88,refuted).
node(n87,refuted) :- node(n88,supported).
node(n87,unknown) :- \+ node(n87,supported), \+ node(n87,refuted).
node(n89,supported) :- status(o_f53eadd21d36a1d4587f,supported).
node(n89,refuted) :- status(o_f53eadd21d36a1d4587f,refuted).
node(n89,unknown) :- status(o_f53eadd21d36a1d4587f,unknown).
node(n91,supported) :- status(o_3e5b62075b939aa2e237,supported).
node(n91,refuted) :- status(o_3e5b62075b939aa2e237,refuted).
node(n91,unknown) :- status(o_3e5b62075b939aa2e237,unknown).
node(n90,supported) :- node(n91,refuted).
node(n90,refuted) :- node(n91,supported).
node(n90,unknown) :- \+ node(n90,supported), \+ node(n90,refuted).
node(n85,supported) :- node(n86,supported), node(n87,supported), node(n89,supported), node(n90,supported).
node(n85,refuted) :- node(n86,refuted).
node(n85,refuted) :- node(n87,refuted).
node(n85,refuted) :- node(n89,refuted).
node(n85,refuted) :- node(n90,refuted).
node(n85,unknown) :- \+ node(n85,supported), \+ node(n85,refuted).
node(n93,supported) :- node(n86,refuted).
node(n93,refuted) :- node(n86,supported).
node(n93,unknown) :- \+ node(n93,supported), \+ node(n93,refuted).
node(n94,supported) :- node(n89,refuted).
node(n94,refuted) :- node(n89,supported).
node(n94,unknown) :- \+ node(n94,supported), \+ node(n94,refuted).
node(n92,supported) :- node(n88,supported), node(n93,supported), node(n91,supported), node(n94,supported).
node(n92,refuted) :- node(n88,refuted).
node(n92,refuted) :- node(n93,refuted).
node(n92,refuted) :- node(n91,refuted).
node(n92,refuted) :- node(n94,refuted).
node(n92,unknown) :- \+ node(n92,supported), \+ node(n92,refuted).
node(n84,refuted) :- node(n85,refuted), node(n92,refuted).
node(n84,supported) :- node(n85,supported).
node(n84,supported) :- node(n92,supported).
node(n84,unknown) :- \+ node(n84,supported), \+ node(n84,refuted).
verdict(c_8a2e25639e2859ab,supported) :- node(n84,supported).
query(verdict(c_8a2e25639e2859ab,supported)).
verdict(c_8a2e25639e2859ab,refuted) :- node(n84,refuted).
query(verdict(c_8a2e25639e2859ab,refuted)).
verdict(c_8a2e25639e2859ab,unknown) :- node(n84,unknown).
query(verdict(c_8a2e25639e2859ab,unknown)).
node(n96,supported) :- node(n86,supported), node(n87,supported), node(n94,supported), node(n91,supported).
node(n96,refuted) :- node(n86,refuted).
node(n96,refuted) :- node(n87,refuted).
node(n96,refuted) :- node(n94,refuted).
node(n96,refuted) :- node(n91,refuted).
node(n96,unknown) :- \+ node(n96,supported), \+ node(n96,refuted).
node(n97,supported) :- node(n88,supported), node(n93,supported), node(n90,supported), node(n89,supported).
node(n97,refuted) :- node(n88,refuted).
node(n97,refuted) :- node(n93,refuted).
node(n97,refuted) :- node(n90,refuted).
node(n97,refuted) :- node(n89,refuted).
node(n97,unknown) :- \+ node(n97,supported), \+ node(n97,refuted).
node(n95,refuted) :- node(n96,refuted), node(n97,refuted).
node(n95,supported) :- node(n96,supported).
node(n95,supported) :- node(n97,supported).
node(n95,unknown) :- \+ node(n95,supported), \+ node(n95,refuted).
verdict(c_fa4ee3d51fe713ca,supported) :- node(n95,supported).
query(verdict(c_fa4ee3d51fe713ca,supported)).
verdict(c_fa4ee3d51fe713ca,refuted) :- node(n95,refuted).
query(verdict(c_fa4ee3d51fe713ca,refuted)).
verdict(c_fa4ee3d51fe713ca,unknown) :- node(n95,unknown).
query(verdict(c_fa4ee3d51fe713ca,unknown)).
node(n100,supported) :- status(o_a270833b6efdb217d2a2,supported).
node(n100,refuted) :- status(o_a270833b6efdb217d2a2,refuted).
node(n100,unknown) :- status(o_a270833b6efdb217d2a2,unknown).
node(n102,supported) :- status(o_733cd00b54646f34bf1c,supported).
node(n102,refuted) :- status(o_733cd00b54646f34bf1c,refuted).
node(n102,unknown) :- status(o_733cd00b54646f34bf1c,unknown).
node(n101,supported) :- node(n102,refuted).
node(n101,refuted) :- node(n102,supported).
node(n101,unknown) :- \+ node(n101,supported), \+ node(n101,refuted).
node(n103,supported) :- status(o_adbafde3d84668363672,supported).
node(n103,refuted) :- status(o_adbafde3d84668363672,refuted).
node(n103,unknown) :- status(o_adbafde3d84668363672,unknown).
node(n105,supported) :- status(o_5ef6d80999e3af0ff693,supported).
node(n105,refuted) :- status(o_5ef6d80999e3af0ff693,refuted).
node(n105,unknown) :- status(o_5ef6d80999e3af0ff693,unknown).
node(n104,supported) :- node(n105,refuted).
node(n104,refuted) :- node(n105,supported).
node(n104,unknown) :- \+ node(n104,supported), \+ node(n104,refuted).
node(n99,supported) :- node(n100,supported), node(n101,supported), node(n103,supported), node(n104,supported).
node(n99,refuted) :- node(n100,refuted).
node(n99,refuted) :- node(n101,refuted).
node(n99,refuted) :- node(n103,refuted).
node(n99,refuted) :- node(n104,refuted).
node(n99,unknown) :- \+ node(n99,supported), \+ node(n99,refuted).
node(n107,supported) :- node(n100,refuted).
node(n107,refuted) :- node(n100,supported).
node(n107,unknown) :- \+ node(n107,supported), \+ node(n107,refuted).
node(n108,supported) :- node(n103,refuted).
node(n108,refuted) :- node(n103,supported).
node(n108,unknown) :- \+ node(n108,supported), \+ node(n108,refuted).
node(n106,supported) :- node(n102,supported), node(n107,supported), node(n105,supported), node(n108,supported).
node(n106,refuted) :- node(n102,refuted).
node(n106,refuted) :- node(n107,refuted).
node(n106,refuted) :- node(n105,refuted).
node(n106,refuted) :- node(n108,refuted).
node(n106,unknown) :- \+ node(n106,supported), \+ node(n106,refuted).
node(n98,refuted) :- node(n99,refuted), node(n106,refuted).
node(n98,supported) :- node(n99,supported).
node(n98,supported) :- node(n106,supported).
node(n98,unknown) :- \+ node(n98,supported), \+ node(n98,refuted).
verdict(c_ebf243d68dc64031,supported) :- node(n98,supported).
query(verdict(c_ebf243d68dc64031,supported)).
verdict(c_ebf243d68dc64031,refuted) :- node(n98,refuted).
query(verdict(c_ebf243d68dc64031,refuted)).
verdict(c_ebf243d68dc64031,unknown) :- node(n98,unknown).
query(verdict(c_ebf243d68dc64031,unknown)).
node(n110,supported) :- node(n100,supported), node(n101,supported), node(n108,supported), node(n105,supported).
node(n110,refuted) :- node(n100,refuted).
node(n110,refuted) :- node(n101,refuted).
node(n110,refuted) :- node(n108,refuted).
node(n110,refuted) :- node(n105,refuted).
node(n110,unknown) :- \+ node(n110,supported), \+ node(n110,refuted).
node(n111,supported) :- node(n102,supported), node(n107,supported), node(n104,supported), node(n103,supported).
node(n111,refuted) :- node(n102,refuted).
node(n111,refuted) :- node(n107,refuted).
node(n111,refuted) :- node(n104,refuted).
node(n111,refuted) :- node(n103,refuted).
node(n111,unknown) :- \+ node(n111,supported), \+ node(n111,refuted).
node(n109,refuted) :- node(n110,refuted), node(n111,refuted).
node(n109,supported) :- node(n110,supported).
node(n109,supported) :- node(n111,supported).
node(n109,unknown) :- \+ node(n109,supported), \+ node(n109,refuted).
verdict(c_93bc8864ef69c007,supported) :- node(n109,supported).
query(verdict(c_93bc8864ef69c007,supported)).
verdict(c_93bc8864ef69c007,refuted) :- node(n109,refuted).
query(verdict(c_93bc8864ef69c007,refuted)).
verdict(c_93bc8864ef69c007,unknown) :- node(n109,unknown).
query(verdict(c_93bc8864ef69c007,unknown)).
node(n114,supported) :- status(o_771dad9b4d87cb7d8d95,supported).
node(n114,refuted) :- status(o_771dad9b4d87cb7d8d95,refuted).
node(n114,unknown) :- status(o_771dad9b4d87cb7d8d95,unknown).
node(n116,supported) :- status(o_06a8722dfd863a54deb7,supported).
node(n116,refuted) :- status(o_06a8722dfd863a54deb7,refuted).
node(n116,unknown) :- status(o_06a8722dfd863a54deb7,unknown).
node(n115,supported) :- node(n116,refuted).
node(n115,refuted) :- node(n116,supported).
node(n115,unknown) :- \+ node(n115,supported), \+ node(n115,refuted).
node(n117,supported) :- status(o_d7febcf42d77cd6b89d6,supported).
node(n117,refuted) :- status(o_d7febcf42d77cd6b89d6,refuted).
node(n117,unknown) :- status(o_d7febcf42d77cd6b89d6,unknown).
node(n119,supported) :- status(o_e7aa10056f847a9ee236,supported).
node(n119,refuted) :- status(o_e7aa10056f847a9ee236,refuted).
node(n119,unknown) :- status(o_e7aa10056f847a9ee236,unknown).
node(n118,supported) :- node(n119,refuted).
node(n118,refuted) :- node(n119,supported).
node(n118,unknown) :- \+ node(n118,supported), \+ node(n118,refuted).
node(n113,supported) :- node(n114,supported), node(n115,supported), node(n117,supported), node(n118,supported).
node(n113,refuted) :- node(n114,refuted).
node(n113,refuted) :- node(n115,refuted).
node(n113,refuted) :- node(n117,refuted).
node(n113,refuted) :- node(n118,refuted).
node(n113,unknown) :- \+ node(n113,supported), \+ node(n113,refuted).
node(n121,supported) :- node(n114,refuted).
node(n121,refuted) :- node(n114,supported).
node(n121,unknown) :- \+ node(n121,supported), \+ node(n121,refuted).
node(n122,supported) :- node(n117,refuted).
node(n122,refuted) :- node(n117,supported).
node(n122,unknown) :- \+ node(n122,supported), \+ node(n122,refuted).
node(n120,supported) :- node(n116,supported), node(n121,supported), node(n119,supported), node(n122,supported).
node(n120,refuted) :- node(n116,refuted).
node(n120,refuted) :- node(n121,refuted).
node(n120,refuted) :- node(n119,refuted).
node(n120,refuted) :- node(n122,refuted).
node(n120,unknown) :- \+ node(n120,supported), \+ node(n120,refuted).
node(n112,refuted) :- node(n113,refuted), node(n120,refuted).
node(n112,supported) :- node(n113,supported).
node(n112,supported) :- node(n120,supported).
node(n112,unknown) :- \+ node(n112,supported), \+ node(n112,refuted).
verdict(c_977b5a9f22966755,supported) :- node(n112,supported).
query(verdict(c_977b5a9f22966755,supported)).
verdict(c_977b5a9f22966755,refuted) :- node(n112,refuted).
query(verdict(c_977b5a9f22966755,refuted)).
verdict(c_977b5a9f22966755,unknown) :- node(n112,unknown).
query(verdict(c_977b5a9f22966755,unknown)).
node(n124,supported) :- node(n114,supported), node(n115,supported), node(n122,supported), node(n119,supported).
node(n124,refuted) :- node(n114,refuted).
node(n124,refuted) :- node(n115,refuted).
node(n124,refuted) :- node(n122,refuted).
node(n124,refuted) :- node(n119,refuted).
node(n124,unknown) :- \+ node(n124,supported), \+ node(n124,refuted).
node(n125,supported) :- node(n116,supported), node(n121,supported), node(n118,supported), node(n117,supported).
node(n125,refuted) :- node(n116,refuted).
node(n125,refuted) :- node(n121,refuted).
node(n125,refuted) :- node(n118,refuted).
node(n125,refuted) :- node(n117,refuted).
node(n125,unknown) :- \+ node(n125,supported), \+ node(n125,refuted).
node(n123,refuted) :- node(n124,refuted), node(n125,refuted).
node(n123,supported) :- node(n124,supported).
node(n123,supported) :- node(n125,supported).
node(n123,unknown) :- \+ node(n123,supported), \+ node(n123,refuted).
verdict(c_180eeab179c127ba,supported) :- node(n123,supported).
query(verdict(c_180eeab179c127ba,supported)).
verdict(c_180eeab179c127ba,refuted) :- node(n123,refuted).
query(verdict(c_180eeab179c127ba,refuted)).
verdict(c_180eeab179c127ba,unknown) :- node(n123,unknown).
query(verdict(c_180eeab179c127ba,unknown)).
node(n128,supported) :- status(o_a18eec4339f760117291,supported).
node(n128,refuted) :- status(o_a18eec4339f760117291,refuted).
node(n128,unknown) :- status(o_a18eec4339f760117291,unknown).
node(n130,supported) :- status(o_b0064988593e45befcc8,supported).
node(n130,refuted) :- status(o_b0064988593e45befcc8,refuted).
node(n130,unknown) :- status(o_b0064988593e45befcc8,unknown).
node(n129,supported) :- node(n130,refuted).
node(n129,refuted) :- node(n130,supported).
node(n129,unknown) :- \+ node(n129,supported), \+ node(n129,refuted).
node(n131,supported) :- status(o_05630961776f937d63c8,supported).
node(n131,refuted) :- status(o_05630961776f937d63c8,refuted).
node(n131,unknown) :- status(o_05630961776f937d63c8,unknown).
node(n133,supported) :- status(o_f2231448dca25f000b7b,supported).
node(n133,refuted) :- status(o_f2231448dca25f000b7b,refuted).
node(n133,unknown) :- status(o_f2231448dca25f000b7b,unknown).
node(n132,supported) :- node(n133,refuted).
node(n132,refuted) :- node(n133,supported).
node(n132,unknown) :- \+ node(n132,supported), \+ node(n132,refuted).
node(n127,supported) :- node(n128,supported), node(n129,supported), node(n131,supported), node(n132,supported).
node(n127,refuted) :- node(n128,refuted).
node(n127,refuted) :- node(n129,refuted).
node(n127,refuted) :- node(n131,refuted).
node(n127,refuted) :- node(n132,refuted).
node(n127,unknown) :- \+ node(n127,supported), \+ node(n127,refuted).
node(n135,supported) :- node(n128,refuted).
node(n135,refuted) :- node(n128,supported).
node(n135,unknown) :- \+ node(n135,supported), \+ node(n135,refuted).
node(n136,supported) :- node(n131,refuted).
node(n136,refuted) :- node(n131,supported).
node(n136,unknown) :- \+ node(n136,supported), \+ node(n136,refuted).
node(n134,supported) :- node(n130,supported), node(n135,supported), node(n133,supported), node(n136,supported).
node(n134,refuted) :- node(n130,refuted).
node(n134,refuted) :- node(n135,refuted).
node(n134,refuted) :- node(n133,refuted).
node(n134,refuted) :- node(n136,refuted).
node(n134,unknown) :- \+ node(n134,supported), \+ node(n134,refuted).
node(n126,refuted) :- node(n127,refuted), node(n134,refuted).
node(n126,supported) :- node(n127,supported).
node(n126,supported) :- node(n134,supported).
node(n126,unknown) :- \+ node(n126,supported), \+ node(n126,refuted).
verdict(c_3fd21ac3be58ae2e,supported) :- node(n126,supported).
query(verdict(c_3fd21ac3be58ae2e,supported)).
verdict(c_3fd21ac3be58ae2e,refuted) :- node(n126,refuted).
query(verdict(c_3fd21ac3be58ae2e,refuted)).
verdict(c_3fd21ac3be58ae2e,unknown) :- node(n126,unknown).
query(verdict(c_3fd21ac3be58ae2e,unknown)).
node(n138,supported) :- node(n128,supported), node(n129,supported), node(n136,supported), node(n133,supported).
node(n138,refuted) :- node(n128,refuted).
node(n138,refuted) :- node(n129,refuted).
node(n138,refuted) :- node(n136,refuted).
node(n138,refuted) :- node(n133,refuted).
node(n138,unknown) :- \+ node(n138,supported), \+ node(n138,refuted).
node(n139,supported) :- node(n130,supported), node(n135,supported), node(n132,supported), node(n131,supported).
node(n139,refuted) :- node(n130,refuted).
node(n139,refuted) :- node(n135,refuted).
node(n139,refuted) :- node(n132,refuted).
node(n139,refuted) :- node(n131,refuted).
node(n139,unknown) :- \+ node(n139,supported), \+ node(n139,refuted).
node(n137,refuted) :- node(n138,refuted), node(n139,refuted).
node(n137,supported) :- node(n138,supported).
node(n137,supported) :- node(n139,supported).
node(n137,unknown) :- \+ node(n137,supported), \+ node(n137,refuted).
verdict(c_42d141c17169bc34,supported) :- node(n137,supported).
query(verdict(c_42d141c17169bc34,supported)).
verdict(c_42d141c17169bc34,refuted) :- node(n137,refuted).
query(verdict(c_42d141c17169bc34,refuted)).
verdict(c_42d141c17169bc34,unknown) :- node(n137,unknown).
query(verdict(c_42d141c17169bc34,unknown)).
node(n142,supported) :- status(o_7605add03db93cd33516,supported).
node(n142,refuted) :- status(o_7605add03db93cd33516,refuted).
node(n142,unknown) :- status(o_7605add03db93cd33516,unknown).
node(n143,supported) :- status(o_0d4cf78bcd4d3b9e7ba2,supported).
node(n143,refuted) :- status(o_0d4cf78bcd4d3b9e7ba2,refuted).
node(n143,unknown) :- status(o_0d4cf78bcd4d3b9e7ba2,unknown).
node(n141,supported) :- node(n142,supported), node(n143,supported).
node(n141,refuted) :- node(n142,refuted).
node(n141,refuted) :- node(n143,refuted).
node(n141,unknown) :- \+ node(n141,supported), \+ node(n141,refuted).
node(n145,supported) :- status(o_30242701a0c8d92f807d,supported).
node(n145,refuted) :- status(o_30242701a0c8d92f807d,refuted).
node(n145,unknown) :- status(o_30242701a0c8d92f807d,unknown).
node(n146,supported) :- status(o_d879f9b42b5ee9a7c9e6,supported).
node(n146,refuted) :- status(o_d879f9b42b5ee9a7c9e6,refuted).
node(n146,unknown) :- status(o_d879f9b42b5ee9a7c9e6,unknown).
node(n144,supported) :- node(n145,supported), node(n146,supported).
node(n144,refuted) :- node(n145,refuted).
node(n144,refuted) :- node(n146,refuted).
node(n144,unknown) :- \+ node(n144,supported), \+ node(n144,refuted).
node(n140,refuted) :- node(n141,refuted), node(n144,refuted).
node(n140,supported) :- node(n141,supported).
node(n140,supported) :- node(n144,supported).
node(n140,unknown) :- \+ node(n140,supported), \+ node(n140,refuted).
verdict(c_01a176e85a8c7fde,supported) :- node(n140,supported).
query(verdict(c_01a176e85a8c7fde,supported)).
verdict(c_01a176e85a8c7fde,refuted) :- node(n140,refuted).
query(verdict(c_01a176e85a8c7fde,refuted)).
verdict(c_01a176e85a8c7fde,unknown) :- node(n140,unknown).
query(verdict(c_01a176e85a8c7fde,unknown)).
verdict(c_6998e9dafc427188,supported) :- node(n140,supported).
query(verdict(c_6998e9dafc427188,supported)).
verdict(c_6998e9dafc427188,refuted) :- node(n140,refuted).
query(verdict(c_6998e9dafc427188,refuted)).
verdict(c_6998e9dafc427188,unknown) :- node(n140,unknown).
query(verdict(c_6998e9dafc427188,unknown)).
node(n148,supported) :- node(n142,supported), node(n146,supported).
node(n148,refuted) :- node(n142,refuted).
node(n148,refuted) :- node(n146,refuted).
node(n148,unknown) :- \+ node(n148,supported), \+ node(n148,refuted).
node(n147,refuted) :- node(n141,refuted), node(n148,refuted).
node(n147,supported) :- node(n141,supported).
node(n147,supported) :- node(n148,supported).
node(n147,unknown) :- \+ node(n147,supported), \+ node(n147,refuted).
verdict(c_06f1dd2dca9605dd,supported) :- node(n147,supported).
query(verdict(c_06f1dd2dca9605dd,supported)).
verdict(c_06f1dd2dca9605dd,refuted) :- node(n147,refuted).
query(verdict(c_06f1dd2dca9605dd,refuted)).
verdict(c_06f1dd2dca9605dd,unknown) :- node(n147,unknown).
query(verdict(c_06f1dd2dca9605dd,unknown)).
verdict(c_c7f980201d641115,supported) :- node(n141,supported).
query(verdict(c_c7f980201d641115,supported)).
verdict(c_c7f980201d641115,refuted) :- node(n141,refuted).
query(verdict(c_c7f980201d641115,refuted)).
verdict(c_c7f980201d641115,unknown) :- node(n141,unknown).
query(verdict(c_c7f980201d641115,unknown)).
