"""Freeze a second source-page-disjoint AVeriTeC sample."""
from hashlib import sha256
from prepare_or_source_evaluation import ROOT,RUN as PRIOR,read,source_key,text_key,OR
from prepare_compiler_fallback import dump,rows
from sample_logical_form_review import INPUTS
from probabilistic_verification.amr_source_alignment import quote_spans


def main():
    run=ROOT/'exp/probabilistic_verification/or_followup_20261119'
    earlier=read(ROOT/'exp/probabilistic_verification/amr_contexts_20261118/external_claims.json')
    earlier+=read(PRIOR/'fresh/claims.json')
    pages={source_key(r[k]) for r in earlier for k in ('source_url','fact_checking_article') if r.get(k)}
    texts={text_key(r['text']) for r in [*earlier,*rows(INPUTS)]}
    candidates=[]
    for split in ('dev','train'):
     source=PRIOR/'source'/f'averitec-{split}.json'
     for index,row in enumerate(read(source)):
      text=row['claim']
      if not 6<=len(text.split())<=49:continue
      quoted=quote_spans(text)
      if not any(not any(q['start']<=m.start()<q['end'] for q in quoted) for m in OR.finditer(text)):continue
      url,article=row.get('original_claim_url'),row.get('fact_checking_article')
      if any(not isinstance(v,str) or not source_key(v)[0] for v in (url,article)):continue
      candidates.append(dict(claim_id=f'or_averitec_{split}_{index}',text=text,source_url=url,fact_checking_article=article,split=split,record_index=index))
    selected=[]
    for row in sorted(candidates,key=lambda r:sha256(('or-followup-20261119:'+r['claim_id']).encode()).hexdigest()):
     urls={source_key(row[k]) for k in ('source_url','fact_checking_article')}
     key=text_key(row['text'])
     if urls&pages or key in texts:continue
     selected.append(row);pages.update(urls);texts.add(key)
     if len(selected)==12:break
    assert len(selected)==12
    dump(run/'fresh/claims.json',selected)
    for row in selected: print(row['claim_id'],row['text'])


if __name__ == "__main__":
    main()
