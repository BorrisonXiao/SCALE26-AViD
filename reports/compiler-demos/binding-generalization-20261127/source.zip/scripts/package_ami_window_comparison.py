"""Package selected labels, cached predictions, and the replay scripts."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from ami_window_comparison_report import URL
from prepare_ami_window_comparison import RUN
from prepare_or_source_evaluation import ROOT

REPLAY = ('calibration_evaluation.json', 'window_inputs.json', 'window_evaluation.json', 'evaluation.json')


def main():
    files = [ROOT/name for name in ('requirements-compilation.txt','requirements-verification.txt',
                                    'tests/test_ami_window_comparison.py')]
    files.extend(RUN/name for name in (*REPLAY,'speech_cases.json','speech_cases.sha256','diarization.json',
                                      'report_edits.json','source.json','claim_scores.json','window_scores.json',
                                      'tests.xml','audio/manifest.json'))
    files.extend(path for path in (RUN/'initial_labels').iterdir() if path.is_file())
    prior = ROOT/'site/reports/compiler-demos/ami-speech-verification-20261126/source.zip'
    with ZipFile(prior) as archive:
        files.extend(ROOT/name for name in archive.namelist() if name.startswith('scripts/'))
    files.extend(ROOT/'scripts'/(p+'.py') for p in (
        'prepare_ami_window_comparison','run_ami_window_audio','calibrate_ami_speech_scores',
        'evaluate_ami_window_comparison','ami_window_comparison_report','package_ami_window_comparison',
    ))
    data = {str(path.relative_to(ROOT)):path.read_bytes() for path in files}
    data['README.md'] = (ROOT/'docs/ami_window_comparison_20261126.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({
        name:sha256((RUN/name).read_bytes()).hexdigest() for name in REPLAY
    }, indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(target, 'w') as archive:
        for name,payload in sorted(data.items()):
            member = ZipInfo(name, date_time=(2026,11,26,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, payload)
    print(f'Archived {len(data)} files for offline replay.')


if __name__ == '__main__':
    main()
