"""Package the cached speech scoring and attribution comparison for replay."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from ami_speech_verification_report import URL
from prepare_ami_speech_verification import BINDING_RUN, RUN
from prepare_or_source_evaluation import ROOT

REPLAY = ('cases.json', 'compiled.json', 'scoring_evaluation.json', 'attribution_evaluation.json', 'evaluation.json')


def main():
    files = [ROOT / name for name in ('requirements-compilation.txt', 'requirements-verification.txt')]
    files.extend(RUN / name for name in (*REPLAY, 'cases.sha256', 'minilm_scores.json', 'deberta_scores.json', 'tests.xml'))
    files.extend(path for path in (RUN/'compiler').iterdir() if path.is_file())
    files.extend(BINDING_RUN / name for name in ('binding_cases.json','reverb.json','alignment_evaluation.json',
                                                'alignment_scores.json'))
    prior_bundle = ROOT/'site/reports/compiler-demos/ami-speaker-binding-20261126/source.zip'
    with ZipFile(prior_bundle) as archive:
        files.extend(ROOT/name for name in archive.namelist() if name.startswith('scripts/') or
                     name.endswith(('/speech_cases.json','/speech_cases.sha256','/diarization.json')))
    files.extend(ROOT/'scripts'/(p+'.py') for p in (
        'prepare_ami_speech_verification','evaluate_ami_speech_scoring','audit_ami_speaker_attribution',
        'ami_speech_verification_report','package_ami_speech_verification',
    ))
    data = {str(path.relative_to(ROOT)):path.read_bytes() for path in files}
    data['README.md'] = (ROOT/'docs/ami_speech_verification_20261126.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({
        name:sha256((RUN/name).read_bytes()).hexdigest() for name in REPLAY
    }, indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(target, 'w') as archive:
        for name,payload in sorted(data.items()):
            member = ZipInfo(name, date_time=(2026,11,26,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, payload)
    print(f'Archived {len(data)} files for offline replay.')


if __name__ == '__main__':
    main()
