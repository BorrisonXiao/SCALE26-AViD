"""Compare the best complete assignment with exact probability over assignments."""
from collections import Counter
from math import isclose, prod

from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import GroundProgram, Observation, enumerate_probability
from probabilistic_verification.ordered_circuit import OrderedSolver
from probabilistic_verification.representation import Expression as E
from score_visual_assignments import RUN


def comparison(scene, quality, records, swapped):
    case = f'{scene["pair_id"]}:{quality}:{int(swapped)}'
    observations = {}
    terms = {}
    for region, record in enumerate(records):
        for field in ('identity','value'):
            p = tuple(record[field]['distribution'])
            observation = Observation(f'{scene["pair_id"]}:{quality}:{region}:{field}',p,False,field)
            observations[observation.id] = observation
            literal = E.atom(observation.id)
            terms[region,field,0] = (literal,p[0])
            terms[region,field,1] = (E.negate(literal),p[1])
    # Each claim uses two regions once. The two bindings are disjoint because a
    # region's identity has just one categorical outcome in a possible world.
    branches = []
    masses = []
    for a,b in ((0,1),(1,0)):
        required = [terms[a,'identity',0],terms[b,'identity',1],
                    terms[a,'value',int(swapped)],terms[b,'value',1-int(swapped)]]
        branches.append(E.combine('and',(literal for literal,_ in required)))
        masses.append(prod(p for _,p in required))
    program = GroundProgram(case,E.combine('or',branches),observations,[],[])
    return program,masses


def constructed_controls():
    """Check probability pooling and repeated evidence with stipulated inputs."""
    facts = {f'fact{i}':Observation(f'control:{i}',(p,0.,1-p),False,f'Condition {i}')
             for i,p in enumerate((.6,.7,.6,.7))}
    a,b,c,d = [E.atom(v.id) for v in facts.values()]
    independent = E.combine('or',(E.combine('and',(a,b)),E.combine('and',(c,d))))
    shared_title = E.combine('or',(E.combine('and',(a,b)),E.combine('and',(a,d))))
    same_reading = E.combine('or',(E.combine('and',(a,b)),E.combine('and',(a,b))))
    cases = (
        ('independent_supported',independent,True,'Two independent panels each offer one complete possible reading.'),
        ('independent_unsupported',independent,False,'The same confidences can come from two mistaken readings of the requested text.'),
        ('shared_reading',shared_title,True,'Two candidate assignments reuse the same uncertain title reading.'),
        ('duplicate_reading',same_reading,False,'Two proposed assignments use the same title and date reading.'),
    )
    observations = {v.id:v for v in facts.values()}
    return [(GroundProgram(cid,expression,observations,[],[]),yes,description)
            for cid,expression,yes,description in cases]


def main():
    inputs = read(RUN/'visual_inputs.json')
    model = read(RUN/'visual_scores.json')
    scores = {r['pair_id']:r['conditions'] for r in model['records']}
    assert len(scores)==len(inputs)
    programs = []
    experiments = []
    for scene in inputs:
        rows = []
        for quality, records in scores[scene['pair_id']].items():
            for swapped in (False,True):
                program, masses = comparison(scene,quality,records,swapped)
                programs.append(program)
                rows.append(dict(id=program.claim_id,quality=quality,claim=scene['claims'][int(swapped)],
                                 expected_support=not swapped,assignment_scores=masses,max=max(masses)))
        experiments.append(dict(scene,scores=scores[scene['pair_id']],results=rows))

    controls = constructed_controls()
    programs.extend(p for p,_,_ in controls)
    verifier = DirectVerifier(programs,learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver)
    distributions = {r['claim_id']:r['distribution'] for r in verifier.predict()}
    for p in programs:
        oracle = enumerate_probability(p)
        assert all(isclose(oracle[k],v,abs_tol=1e-10) for k,v in distributions[p.claim_id].items())

    summary = {k:Counter() for k in ('original','reduced_resolution')}
    for row in experiments:
        for r in row['results']:
            exact = distributions[r['id']]
            p = exact['supported']
            assert isclose(p,sum(r['assignment_scores']),abs_tol=1e-10)
            r['distribution'] = exact
            expected = r['expected_support']
            n = summary[r['quality']]
            n['total'] += 1
            n['max_correct'] += (r['max']>=0.5)==expected
            n['exact_correct'] += (p>=0.5)==expected
            n['different_probabilities'] += not isclose(p,r['max'],abs_tol=1e-10)
            n['different_decisions'] += (p>=0.5)!=(r['max']>=0.5)
    checks = [dict(id=p.claim_id,description=desc,expected_support=expected,best_assignment=.42,
                   distribution=distributions[p.claim_id]) for p,expected,desc in controls]
    dump(RUN/'visual_evaluation.json',dict(source={k:v for k,v in model.items() if k!='records'},
                                           summary=summary,scenes=experiments,controls=checks))
    (RUN/'visual_program.pl').write_text(verifier.program)
    print(summary,checks,flush=True)


if __name__=='__main__':
    main()
