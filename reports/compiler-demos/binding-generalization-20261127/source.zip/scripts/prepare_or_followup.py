"""Prepare frozen follow-up cases with existing parser utilities."""
import argparse
from hashlib import sha256

import prepare_or_source_evaluation as source
from prepare_compiler_fallback import ROOT, dump

RUN = ROOT / 'exp/probabilistic_verification/or_followup_20261119'
PRIOR = source.RUN

# Each reading is supplied before model runs. Different-polarity clauses
# and modifiers attached to just one branch serve as negative controls.
CONTROLS = [
    ('neg_1', 'The worker did not lift the box or move the crate.', 'The worker did neither action.'),
    ('neg_2', 'At noon, the driver did not sound the horn or flash the lights.', 'The driver did neither action at noon.'),
    ('neg_3', 'The manager has not signed or submitted the form.', 'The manager did neither action to the same form.'),
    ('neg_4', 'The person did not call or text Sam.', 'The person did neither action with Sam as recipient.'),
    ('neg_5', 'The writer did not sign the form or the letter.', 'The writer signed neither document.'),
    ('neg_6', 'The building does not have a porch or a balcony.', 'The building has neither feature.'),
    ('local_neg_1', 'The worker did not lift the box, or the driver moved the crate.', 'Only the first clause is negated, and the two clauses are alternatives.'),
    ('local_neg_2', 'The worker did not lift the box or did not move the crate.', 'Each alternative has separate negation.'),
    ('local_neg_3', 'The driver did not stop at the light or the car broke down.', 'The two clauses are alternatives and have separate subjects.'),
    ('shared_place_1', 'The patient has been moved or is due to be moved to the main ward.', 'Both alternatives share the same patient and destination; the move has happened or is scheduled.'),
    ('shared_place_2', 'The parcel has arrived or will arrive at the depot.', 'The depot is the destination of both an actual and a future arrival.'),
    ('shared_place_3', 'The workers will walk or drive to the station.', 'The shared destination is the station and either movement is future.'),
    ('local_place', 'The team reached Boston or will fly to Denver.', 'Boston belongs to reaching; Denver belongs to flying.'),
    ('shared_noun_1', 'The patient died in a public or private hospital.', 'Both alternatives are hospitals, with alternative public and private modifiers.'),
    ('shared_noun_2', 'The sign bans red hats or shirts.', 'The ban names two clothing items. Whether red modifies shirts is ambiguous.'),
    ('shared_noun_3', 'The machine accepts glass or plastic bottles.', 'Glass and plastic specify the material of bottles. The text can also allow glass as a separate item.'),
    ('local_noun', 'The vehicle was parked at a pier or a private terminal.', 'Only the terminal is described as private.'),
    ('excluded', 'The person pushed or pulled the door, but not both.', 'Exactly one of the two actions happened to the same door.'),
]


def freeze():
    group = RUN / 'controlled'
    examples = [dict(claim_id=cid, text=text) for cid, text, _ in CONTROLS]
    dump(group / 'claims.json', examples)
    dump(group / 'references.json', {cid: reading for cid, _, reading in CONTROLS})


def prepare(group):
    from probabilistic_verification.parsing import DependencyParser

    folder = RUN / group
    claims = folder / 'claims.json'
    examples = source.read(claims)
    source.write_rows(folder / 'amr_inputs.jsonl', (dict(claim_id=r['claim_id'], text=r['text']) for r in examples))
    parser = DependencyParser()
    output = []
    for row in examples:
        text, cid = row['text'], row['claim_id']
        clause = dict(id='c1', text=text)
        try:
            clause['record'] = dict(claim_id=cid, text=text, tokens=parser.parse(text), srl=None)
        except ValueError as error:
            clause['parse_error'] = str(error)
        output.append(dict(claim_id=cid, clauses=[clause]))
    source.write_rows(folder / 'dependencies.jsonl', output)
    dump(folder / 'dependency_provenance.json', dict(parser.provenance, claims_sha256=sha256(claims.read_bytes()).hexdigest()))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('group', choices=('controlled', 'fresh'))
    group = parser.parse_args().group
    if group == 'controlled':
        freeze()
    prepare(group)


if __name__ == '__main__':
    main()
