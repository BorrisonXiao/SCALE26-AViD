"""Run the same parser outputs through the current compiler or a frozen copy."""
import argparse
from hashlib import sha256
from pathlib import Path

from prepare_compiler_fallback import dump, rows
from prepare_or_source_evaluation import read
from probabilistic_verification.compiler_fallback import check_output, compile_claim
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.fallback_amr import compile_fallback_amr, prepare_fallback
from run_amr_types import inspect


def evaluate(folder, graph_path):
    inputs = folder / 'claims.json'
    claims = read(inputs)
    assert sha256(inputs.read_bytes()).hexdigest() == read(
        folder / 'dependency_provenance.json')['claims_sha256']
    parsed = {r['claim_id']: r['clauses'][0] for r in rows(folder / 'parsed.jsonl')}
    graphs = {r['request']['task']['claim_id']: r['raw'] for r in rows(graph_path)}
    assert parsed.keys() == {r['claim_id'] for r in claims} <= graphs.keys()
    results = []
    for claim in claims:
        cid = claim['claim_id']
        part = parsed[cid]
        if 'record' not in part:
            seen = dict(status='unsupported', code='sentence_parse', reason=part['parse_error'])
            fixed = compile_claim(claim, srl=lambda _: seen, amr=lambda _: seen)
            results.append(dict(claim, srl=seen, amr=seen, fixed=fixed))
            continue
        record = part['record']
        assert record['text'] == claim['text']
        srl = check_output(record, compile_one(record))
        amr = check_output(record, inspect(record, graphs[cid], compiler=compile_fallback_amr,
                                           prepare=prepare_fallback))
        fixed = compile_claim(record, srl=lambda _: srl, amr=lambda _: amr)
        results.append(dict(claim, srl=srl, amr=amr, fixed=fixed))
    return results


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('input', type=Path)
    p.add_argument('graphs', type=Path)
    p.add_argument('output', type=Path)
    args = p.parse_args()
    result = evaluate(args.input, args.graphs)
    dump(args.output, result)
    print(args.output, sum(bool(r['fixed']['output']) for r in result), len(result))
