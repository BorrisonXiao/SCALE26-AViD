"""Find speaker-aligned AMI excerpts with lexical markers of alternatives."""
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from collect_ami_or_candidates import NITE_ID, aligned_words, detokenize
from prepare_compiler_fallback import dump
from prepare_or_followup import RUN, PRIOR

MARKERS = re.compile(r'\balternatively\b|\banother (?:option|possibility|way|alternative)\b|'
                     r'\bthe other (?:option|possibility|way|alternative)\b|'
                     r'\b(?:one|first|second|two) (?:option|possibility|alternative)s?\b', re.I)


def main():
    candidates = []
    with ZipFile(PRIOR / 'source/ami_public_manual_1.6.2.zip') as archive:
        names = set(archive.namelist())
        for path in sorted(p for p in names if p.startswith('segments/') and p.endswith('.segments.xml')):
            meeting, speaker, *_ = path.rsplit('/',1)[1].split('.')
            word_path = f'words/{meeting}.{speaker}.words.xml'
            if word_path not in names:
                continue
            tokens = list(ET.fromstring(archive.read(word_path)))
            positions = {token.get(NITE_ID): i for i, token in enumerate(tokens)}
            earlier = []
            for segment in ET.fromstring(archive.read(path)):
                words = aligned_words(segment,tokens,positions)
                if not words:
                    continue
                text = detokenize(words)
                row = dict(segment_id=segment.get(NITE_ID), words=words, text=text)
                if MARKERS.search(text):
                    candidates.append(dict(meeting=meeting,speaker=speaker,
                                           segments=[*earlier[-3:],row]))
                earlier.append(row)
    dump(RUN / 'transcripts/implicit_candidates.json',candidates)
    for r in candidates:
        s=r['segments']
        if re.search(r'\bor\b',s[-1]['text'],re.I):continue
        print(r['meeting'],r['speaker'],s[-1]['segment_id'], ' | '.join(t['text'] for t in s[-3:]))


if __name__ == '__main__':
    main()
