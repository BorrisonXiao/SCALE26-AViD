"""Freeze scope controls and annotated AMI examples for the alignment pilot."""
import argparse
import json
import math
from pathlib import Path
import re
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from hashlib import sha256

from collect_ami_or_candidates import NITE_ID, aligned_words
from prepare_compiler_fallback import dump
from prepare_or_followup import PRIOR, prepare as prepare_parser
import prepare_or_followup as followup
from prepare_or_source_evaluation import ROOT, read, source_key

RUN = ROOT / 'exp/probabilistic_verification/scope_and_alignment_20261119'
AUDIO = 'https://groups.inf.ed.ac.uk/ami/AMICorpusMirror/amicorpus'
AUDIO_CASES = [
    'IS1006a.sync.654', 'ES2014c.sync.700', 'ES2008d.sync.1353', 'TS3003c.sync.741',
    'ES2016a.sync.328', 'EN2002d.sync.1,486', 'IN1001.sync.1,469', 'IS1003c.sync.979',
]
CONTROLS = [
    ('absence_1', 'The worker left without a coat or an umbrella.', 'The worker left and carried neither item.'),
    ('absence_2', 'The visitor entered without a badge or a ticket.', 'The visitor entered with neither a badge nor a ticket.'),
    ('absence_3', 'The camera works without a battery or a charger.', 'The camera works with neither component present.'),
    ('absence_4', 'The driver crossed the bridge without headlights or brake lights.', 'The driver crossed without either lighting feature.'),
    ('absence_5', 'Workers arrived without masks, gloves or goggles.', 'The same arrival lacks all three items.'),
    ('absence_6', 'The visitor left without taking notes or making a call.', 'The visitor left, and did neither of the two actions.'),
    ('absence_7', 'The child walked past the booth without a ticket or went back to the car.', 'One option is walking without a ticket and the other is going back.'),
    ('absence_8', 'The person left without a coat or with a borrowed umbrella.', 'The first alternative lacks a coat. The other uses an umbrella.'),
    ('absence_local', 'The worker carried a notebook or a camera without a lens.', 'Only a camera branch has the lens qualification.'),
    ('with_control', 'The visitor entered with a badge or a ticket.', 'At least one item accompanied entry.'),
    ('rule_1', 'The visitor must show a ticket or face a fine.', 'Showing a ticket is required. The fine is the consequence of failing to show it.'),
    ('rule_2', 'The tenant must pay the rent or lose the deposit.', 'Payment is required. Loss of the deposit is the consequence of nonpayment.'),
    ('rule_3', 'The applicant must renew the permit or it will expire.', 'Renewal is required to prevent expiration.'),
    ('rule_4', 'The shopper must pay now or else the clerk will cancel the order.', 'Payment is required. Cancellation follows failure to pay.'),
    ('rule_5', 'The tenant must pay by Friday or they will face an eviction notice.', 'The payment deadline is Friday, and the notice is conditional on missing it.'),
    ('rule_6', 'The form states that the visitor must register or face a fine.', 'Written content states a requirement and a consequence.'),
    ('rule_7', 'The visitor must show a badge or a ticket.', 'Either item satisfies the requirement.'),
    ('rule_8', 'The worker must call the office or send an email.', 'Either action satisfies an obligation.'),
    ('rule_9', 'The visitor must show the badge or stay in the lobby.', 'A requirement offers two options, with no definite sanction beyond those words.'),
    ('rule_10', 'They must decide whether to stay or leave.', 'The obligation is to decide.'),
    ('rule_11', 'The chair must approve or reject the request.', 'The chair is required to choose one of two actions.'),
    ('rule_12', 'The manager said “You must renew the permit or else.”', 'The speaker explicitly warns of an unspecified consequence.'),
]

SOURCE_READINGS = [
    ('train',597,'Both missing supplies modify the deployment or training. The number and destination stay part of the claim.'),
    ('train',1685,'The final without-clause denies permission to call witnesses and to have subpoena power. The other two missing parts remain distinct.'),
    ('train',3036,'The stated breath-holding condition excludes all four listed symptoms. The claim alleges what that test would establish.'),
    ('dev',46,'Waiting to cut the cord is the stated recommendation. The possibility of inadequate blood is conditional on cutting earlier.'),
    ('train',2491,'The quoted speakers demand menus without pork and threaten to leave the US if that demand is unmet. This is quoted content.'),
    ('train',1388,'An apology is demanded. The quoted “or else” announces a consequence without specifying it.'),
    ('train',94,'The announced advice denies both kinds of behavior. Neither travel nor purchase is stated as an alternative way to comply.'),
    ('train',694,'The first negation concerns what the agency said. The embedded recommendation concerns use outside either named setting.'),
    ('train',1131,'Work and emergencies are exceptions to one stay-home rule. They are not sanctions.'),
    ('train',1197,'The test asserts an absence of both discomfort and coughing.'),
    ('train',2288,'The stated land requirement is conditional on allocation. Failure to develop by the deadline has a stated reversion consequence.'),
]


def freeze_claims():
    root = RUN / 'compiler'
    root.mkdir(parents=True, exist_ok=True)
    sources = {split: read(PRIOR/'source'/f'averitec-{split}.json') for split in ('train','dev')}
    rows = [dict(claim_id=cid, text=text, reference=ref, group='controlled')
            for cid,text,ref in CONTROLS]
    for split,index,reference in SOURCE_READINGS:
        data = sources[split][index]
        rows.append(dict(claim_id=f'averitec_{split}_{index}', text=data['claim'], reference=reference,
                         group='prior' if index in {1197,2288} else 'fresh',
                         source_url=data.get('original_claim_url'), article=data.get('fact_checking_article')))
    selected = root/'claims.json'
    dump(selected, rows)
    (root/'claim_sha256.txt').write_text(sha256(selected.read_bytes()).hexdigest()+'\n')


def timed_words(archive, meeting):
    prefix = f'segments/{meeting}.'
    output = []
    for name in archive.namelist():
        if not name.startswith(prefix) or not name.endswith('.segments.xml'):
            continue
        speaker = name[len(prefix):].split('.')[0]
        tokens = list(ET.fromstring(archive.read(f'words/{meeting}.{speaker}.words.xml')))
        positions = {t.get(NITE_ID): i for i,t in enumerate(tokens)}
        for segment in ET.fromstring(archive.read(name)):
            words = aligned_words(segment, tokens, positions)
            output.extend(dict(w, speaker=speaker) for w in words)
    unique = {w['word_id']: w for w in output}
    return sorted(unique.values(),key=lambda w:(w['start'],w['end'],w['word_id']))


def freeze_speech():
    saved = {r['segment_id']:r for r in read(PRIOR/'transcripts/candidates.json')}
    excerpts = []
    with ZipFile(PRIOR/'source/ami_public_manual_1.6.2.zip') as archive:
        for cid in AUDIO_CASES:
            row = saved[cid]
            meeting = row['meeting']
            start, end = row['words'][0]['start'],row['words'][-1]['end']
            at = math.floor(start/30)*30
            clip_start, clip_end = max(0,at-40), at+35
            assert clip_start < at <= start < end <= clip_end
            words = [w for w in timed_words(archive, meeting)
                     if w['end'] >= clip_start and w['start'] <= clip_end]
            excerpts.append(dict(row, start=start,end=end, query_start=at,query_end=clip_end,
                                 clip_start=clip_start,clip_end=clip_end,
                                 audio_url=f'{AUDIO}/{meeting}/audio/{meeting}.Array1-01.wav',clip_words=words))
    path = RUN/'speech_cases.json'
    dump(path,excerpts)
    (RUN/'speech_cases.sha256').write_text(sha256(path.read_bytes()).hexdigest()+'\n')
    print(f'Froze {len(excerpts)} excerpt labels from independent AMI annotations.')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage', choices=('claims','parse','speech'))
    stage = p.parse_args().stage
    if stage=='parse':
        followup.RUN=RUN
        prepare_parser('compiler')
    else:
        {'claims':freeze_claims, 'speech':freeze_speech}[stage]()
