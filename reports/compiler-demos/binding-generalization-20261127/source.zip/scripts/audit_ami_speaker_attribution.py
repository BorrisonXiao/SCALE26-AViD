"""Locate speaker attribution failures with the previous diarization boundaries."""
from collections import Counter
from hashlib import sha256

from evaluate_ami_alignment import match_speakers
from evaluate_ami_speaker_binding import load_turns, ranked_windows
from prepare_ami_speaker_binding import PRIOR_RUN, RUN as BINDING_RUN
from prepare_ami_speech_verification import RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from probabilistic_verification.transcript_or import judge

TURNS = {'pyannote':PRIOR_RUN/'diarization.json', 'reverb':BINDING_RUN/'reverb.json'}
STAGES = ('speech_activity', 'one_turn', 'any_window', 'earlier_labels', 'target_labels')


def target_word_ids(case):
    return {w['word_id'] for w in case['words'] if w['text'] not in {',','.','?','!'}}


def activity_counts(case, turns):
    """Count reference words whose midpoint falls in an estimated turn."""
    target_ids = target_word_ids(case)
    activity = []
    for turn in turns:
        # Use the same word midpoint as the candidate constructors.
        activity.append({w['word_id'] for w in case['words'] if w['word_id'] in target_ids
                         and turn['start'] <= (w['start']+w['end'])/2 < turn['end']})
    return dict(speech_activity=len(set().union(*activity)), one_turn=max(map(len, activity), default=0))


def rerank(method, query, claim, names):
    windows = {kind:[dict(w,speaker=names.get(w['cluster'])) for w in method[kind]]
               for kind in ('strict','overlap')}
    return ranked_windows(windows, query, claim)


def coverage(windows, target_ids):
    return max((len(set(w['word_ids']) & target_ids) for w in windows), default=0)


def run():
    source = PRIOR_RUN/'speech_cases.json'
    assert sha256(source.read_bytes()).hexdigest() == (PRIOR_RUN/'speech_cases.sha256').read_text().strip()
    reference = {r['meeting']:r for r in read(source)}
    turns = {model:load_turns(path) for model,path in TURNS.items()}
    original = read(BINDING_RUN/'alignment_evaluation.json')
    cache = {(r['premise'],r['hypothesis']):r['probabilities']
             for r in read(BINDING_RUN/'alignment_scores.json')['scores']}

    def entail(a,b):
        return cache[a,b]['entailment']

    def contradict(a,b):
        return cache[a,b]['contradiction']

    totals = {model:{stage:Counter() for stage in STAGES} for model in TURNS}
    verdicts = {model:{mapping:Counter() for mapping in ('earlier_labels','target_labels')} for model in TURNS}
    comparisons = []
    for row in original['rows']:
        case = reference[row['meeting']]
        target_ids = target_word_ids(case)
        annotated = {w['word_id']:w['speaker'] for w in case['clip_words']}
        nwords = len(target_ids)
        analyses = {}
        for model, tracks in turns.items():
            method = row['methods'][model]
            track = tracks[row['meeting']]
            early, evidence = match_speakers(case, track)
            assert early == {int(k):v for k,v in method['speaker_map'].items()}
            current, target_evidence = match_speakers(case, track, interval=(case['query_start'],case['query_end']))
            earlier = dict((int(k),v) for k,v in method['speaker_map'].items())
            example = row['variants'][0]
            q = example['query']
            anon = rerank(method, dict(q,speaker=None), row['target'], {})
            counts = dict(activity_counts(case,track), any_window=coverage(anon,target_ids),
                          earlier_labels=coverage(rerank(method,q,row['target'],earlier),target_ids),
                          target_labels=coverage(rerank(method,q,row['target'],current),target_ids))
            assert counts['one_turn'] <= counts['speech_activity'] <= nwords
            assert max(counts['target_labels'],counts['earlier_labels']) <= counts['any_window'] <= counts['one_turn']
            for stage,n in counts.items():
                totals[model][stage]['any'] += n>0
                totals[model][stage]['all'] += n==nwords
            predictions = {mapping:{} for mapping in ('earlier_labels','target_labels')}
            for mapping,names in (('earlier_labels',earlier),('target_labels',current)):
                # Target speaker labels are available only in the target slot. For
                # this comparison inspect positive and wrong-speaker queries there.
                for example in row['variants'][:2]:
                    variant, query = example['variant'], example['query']
                    candidates = rerank(method,query,row['target'],names)[:3]
                    matching = [w for w in candidates if judge(
                        query,dict(w,target=row['target']),entail,allow_implicit=True,
                        contradiction=contradict)=='supported']
                    if mapping=='earlier_labels':
                        expected = example['predictions'][f'{model}_ranked_3']['matching']
                        assert [w['word_ids'] for w in matching]==[w['word_ids'] for w in expected]
                    named = [dict(w,annotated_word_speakers=Counter(annotated[i] for i in w['word_ids']))
                             for w in matching]
                    if named:
                        verdicts[model][mapping][variant] += 1
                    clean = any(w['annotated_word_speakers'].keys()=={query['speaker']} for w in named)
                    if clean:
                        verdicts[model][mapping][f'{variant}_clean'] += 1
                    predictions[mapping][variant] = dict(windows=len(candidates), matching=named)
            analyses[model] = dict(word_counts=counts, earlier_names=early, target_names=current,
                                  earlier_evidence=evidence, target_evidence=target_evidence,
                                  predictions=predictions)
        comparisons.append(dict(meeting=row['meeting'], target=row['target'], speaker=case['speaker'],
                                word_count=nwords, models=analyses))
    for model in TURNS:
        for mapping in verdicts[model].values():
            for variant in ('correct_speaker','different_speaker','correct_speaker_clean','different_speaker_clean'):
                mapping.setdefault(variant,0)
    report = dict(total=len(comparisons), word_coverage=totals, support=verdicts, rows=comparisons)
    dump(RUN/'attribution_evaluation.json', report)
    print({k:report[k] for k in ('total','word_coverage','support')}, flush=True)


if __name__ == '__main__':
    run()
