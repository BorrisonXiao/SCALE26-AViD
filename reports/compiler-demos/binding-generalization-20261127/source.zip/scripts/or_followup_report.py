"""Summarize the targeted OR repairs and their evidence tests."""
from collections import Counter
from html import escape
from shutil import copy2
import xml.etree.ElementTree as ET

from compiler_fallback_report import table
from or_source_evaluation_report import LABELS, attempt_details
from prepare_compiler_fallback import dump, rows
from prepare_or_followup import PRIOR, ROOT, RUN
from prepare_or_source_evaluation import read

URL = 'compiler-demos/or-followup-20261119/'
SELECTED = ('or_averitec_train_4', 'or_averitec_train_1752', 'shared_noun_1')
EXPLANATIONS = {
    'or_averitec_train_4': 'The old program could accept the claim if just one action was absent. The new program requires both to be absent.',
    'or_averitec_train_1752': 'The completed flight and the flight that is due are alternatives. Both carry the same person and UK destination.',
    'shared_noun_1': 'The two descriptions apply to one hospital candidate. The noun and location role are shared.',
}
SPEECH_CASES = {
    'complete': 'Complete real excerpt',
    'early_crop': 'Earlier crop',
    'late_crop': 'Later crop',
    'wrong_speaker': 'Different speaker assigned',
    'later_time': 'Disjoint time assigned',
    'changed_alternative': 'One alternative in the claim changed',
}


def inventory(path):
    return {r['claim_id']: (r['selected_stage'], r['output']['program_sha256'] if r['output'] else None)
            for r in rows(path)}


def digest(output):
    return output['program_sha256'] if output else None


def cases(group, before_path, after_path):
    before = {r['claim_id']: r['fixed'] for r in read(before_path)}
    after = read(after_path)
    references = read(RUN / group / 'references.json') if group else {}
    reviews = read(RUN / group / 'reviews.json') if group else {}
    result = []
    for row in after:
        cid = row['claim_id']
        old, new = before[cid], row['fixed']
        verdict, finding = reviews.get(cid, ('', EXPLANATIONS.get(cid, '')))
        if group == 'fresh':
            assert (verdict != 'no_program') == bool(new['output'])
        exact = digest(old['output']) == digest(new['output'])
        keep = ('claim_id','text','fact_checking_article')
        result.append(dict({k:row[k] for k in keep if k in row},
                           reference=references.get(cid), verdict=verdict, finding=finding, program_unchanged=exact,
                           before=old['output'], after=new['output'], stage=new['selected_stage'],
                           attempts=[{k:a[k] for k in ('stage','status','code','reason') if k in a} for a in new['attempts']]))
    return result


def summarize():
    controlled = cases('controlled', RUN/'controlled_before.json', RUN/'controlled_after.json')
    fresh = cases('fresh', RUN/'fresh_before.json', RUN/'fresh_after.json')
    prior = cases(None, PRIOR/'fresh/compiled.json', RUN/'prior_after.json')
    prior = [r for r in prior if r['claim_id'] in SELECTED]
    native = read(RUN/'native.json')
    speech = read(RUN/'transcripts/evaluation.json')
    previous_path = PRIOR.with_name('disjunction_scope_20261119') / 'corpus.jsonl'
    before, after = inventory(previous_path), inventory(RUN/'full-final/corpus.jsonl')
    assert before.keys() == after.keys()
    corpus = dict(total=len(before), before=sum(h is not None for _,h in before.values()),
                  after=sum(h is not None for _,h in after.values()),
                  identical=sum(before[c]==after[c] and after[c][1] is not None for c in after),
                  changed=[c for c in after if before[c]!=after[c]])
    dump(RUN/'corpus_program_hashes.json', dict(before=before, after=after))
    inferred = read(RUN/'transcripts/inference.json')
    measures = [case for row in inferred for case in row['cases']]
    transcript_native = dict(inputs=len(inferred), programs=sum(bool(r['cases']) for r in inferred),
                             checks=len(measures), matches=sum(c['distribution'][c['expected']]>1-1e-10 for c in measures))
    test_suite = ET.parse(RUN/'tests.xml').find('testsuite')
    tests = int(test_suite.get('tests'))
    assert all(int(test_suite.get(k, 0)) == 0 for k in ('failures','errors','skipped'))
    classifications = dict(Counter(r['verdict'] for r in fresh))
    control_labels = dict(Counter(r['verdict'] for r in controlled))
    gates = dict(
        targets=len(prior) == 2 and all(r['after'] and not r['program_unchanged'] for r in prior),
        controlled=control_labels == {'correct':16, 'context_needed':2},
        census=not corpus['changed'] and corpus['after'] == corpus['before'],
        fresh_review=len(fresh)==12 and sum(classifications.values())==12,
        genuine_speech=speech['summary']['new']['complete_supported'] >= 4,
        speech_alignment=speech['summary']['new']['alignment_false_support']==0,
        prior_speech=speech['summary']['prior']['regressions']==0)
    summary = dict(corpus=corpus, native=len(native), transcript_native=transcript_native, tests=tests,
                   controlled=control_labels, fresh=classifications, fresh_passes=sum(r['after'] is not None for r in fresh),
                   changed_fresh=sum(not r['program_unchanged'] for r in fresh), gates=gates)
    dump(RUN/'evaluation.json', dict(summary=summary, controlled=controlled, fresh=fresh, prior=prior,
                                     native=native, speech=speech, transcript_inference=inferred))
    assert all(gates.values()), gates
    print(summary)


def status_html():
    s = read(RUN/'evaluation.json')['summary']
    return (f'<b>Both original OR errors are repaired.</b> '
            f'All {s["corpus"]["identical"]:,} earlier corpus programs replay exactly. '
            f'The new transcript check recovers all five examples with alternatives phrased without “or.”')


def overview_html():
    r = read(RUN/'evaluation.json')
    s, t = r['summary'], r['speech']['summary']
    c, v = s['corpus'], s['transcript_native']
    return (
        '<h2 id="remaining-failures">Negation, shared words, and alternatives in speech</h2>'
        '<p>The repaired compiler keeps negation over both coordinated actions. It also retains shared '
        'destinations and properties when the source links them to both alternatives.</p>'
        f'<p>Both original errors are repaired. All {s["controlled"]["correct"]} unambiguous authored controls '
        'have the intended scope. Two further controls allow different readings of a shared modifier. '
        f'The full rerun keeps {c["identical"]:,} earlier programs byte-identical and {c["total"]-c["after"]} abstentions.</p>'
        '<h3>Fresh claims</h3>'
        f'<p>The fixed compiler passes {s["fresh_passes"]} of 12 new claims from AVeriTeC, with one full reading match. '
        'One program changes by separating two modifiers for the same weapons. Remaining errors '
        'include “without” over alternatives, giver and recipient roles, and rules that express a consequence. '
        'The run uses saved dependency parses, SRL and AMR without rewriting.</p>'
        + table('Readings of claims from 12 new source pages.', ['Outcome','Claims'],
                [(label, s['fresh'].get(key,0)) for key,label in LABELS.items() if s['fresh'].get(key)])
        + '<h3>Reported speech</h3>'
        '<p>We compare two spans when a speaker introduces a further option, for example with “alternatively.” '
        'The transcript can contain more detail than the claim. The new check tests whether each span entails '
        'the claimed alternative, and checks for contradiction in the reverse direction.</p>'
        + table('Expected transcript judgments matched.', ['Cases','Previous','Revised','Comparisons'],
                [(label, t[key]['before_matches'],t[key]['after_matches'],t[key]['comparisons'])
                 for key,label in [('prior','Earlier examples'),('new','New excerpts and contrasts')]])
        + f'<p>The revised method finds all {t["new"]["complete_supported"]} genuine excerpts with implicit wording. '
        'It returns unknown for every tested speaker and time mismatch and every changed alternative. '
        'We used this small sample during development. Speaker IDs and transcript windows come from AMI annotations.</p>'
        f'<p>One more earlier claim keeps both choices inside the same report. Four of eight transcript-derived claims '
        f'now have a usable speech condition. Exact DeepProbLog matches {v["matches"]} of {v["checks"]} comparisons '
        f'on those programs, with other predicates fixed, and {s["native"]} additional controls on the repaired OR forms. '
        f'All {s["tests"]} project tests pass.</p>'
        '<p>The stopping criteria for this repair round are met. The fresh claims show that broader semantic '
        'compilation still needs targeted evaluation.</p>'
        '<p><a href="#or-followup-compilation">Before and after examples</a> · '
        '<a href="#implicit-speech-cases">Speech excerpts</a> · '
        '<a href="#or-followup-fresh">All fresh claims</a> · '
        '<a href="#earlier-or-sources">Earlier transcript audit</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}evaluation.json">Exact outputs</a> · <a href="{URL}source.zip">Source and replay</a> · '
        f'<a href="{URL}tests.xml">Tests</a></p>')


def program_details(r):
    parts = []
    for label,key in [('Before','before'),('After','after')]:
        if r[key]:
            parts.append(f'<h4>{label}</h4><pre>{escape(r[key]["compilation"]["logical_form"])}</pre>')
    parts.append(attempt_details(r['attempts']))
    if r['after']:
        parts.append(f'<h4>DeepProbLog program</h4><pre>{escape(r["after"]["program"])}</pre>')
    return '<details><summary>Logical forms and compilation attempts</summary>' + ''.join(parts) + '</details>'


def examples_html():
    result = read(RUN/'evaluation.json')
    all_examples = {r['claim_id']: r for r in result['prior'] + result['controlled']}
    repairs = ['<section id="or-followup-compilation"><h2>Three changes to the logical form</h2>']
    for cid in SELECTED:
        r = all_examples[cid]
        repairs.append(f'<article class="box benchmark-case" id="followup-{escape(cid)}">'
                       f'<blockquote>{escape(r["text"])}</blockquote><p>{escape(EXPLANATIONS[cid])}</p>'
                       + program_details(r) + '</article>')
    repairs.append('<details><summary>All 18 controlled readings</summary>'
                   + table('Readings of source formulations before any media inference.',
                           ['Claim','Reading','Finding'],
                           [(escape(r['text']),escape(r['reference']),escape(r['finding'])) for r in result['controlled']])
                   + '</details></section>')
    speech = ['<section id="implicit-speech-cases"><h2>Alternatives in speaker-aligned transcripts</h2>'
              '<p>Each excerpt retains original words. Shorter rows are real crops. Assigning the same text '
              'to a different speaker or time tests the alignment check. The changed-alternative rows edit '
              'the claim wording.</p>']
    for i,s in enumerate(result['speech']['cases']['new'],1):
        comparisons = []
        for case in s['cases']:
            v = case['variant']
            detail = (f'<p><b>Edited claim.</b> {escape(case["target"])}</p>' if v == 'changed_alternative'
                      else f'<blockquote>{escape(case["text"])}</blockquote>' if v in {'early_crop','late_crop'} else '')
            comparisons.append(f'<li><h4>{SPEECH_CASES[v]}</h4>'
                               f'<p>Speaker {case["speaker"]} · {case["start"]:.2f}–{case["end"]:.2f} s</p>'
                               f'{detail}<p><b>Expected</b> {case["expected"]} · <b>Previous</b> {case["before"]} · '
                               f'<b>Revised</b> {case["after"]}</p></li>')
        original = s['cases'][0]
        speech.append(f'<article class="box benchmark-case" id="implicit-speech-{i}"><h3>{escape(s["meeting"])}</h3>'
                      f'<blockquote>{escape(s["text"])}</blockquote>'
                      f'<p><b>Claim.</b> {escape(original["target"])}</p>'
                      f'<p><b>Expected</b> {original["expected"]} · <b>Previous</b> {original["before"]} · '
                      f'<b>Revised</b> {original["after"]}</p>'
                      '<details><summary>Speaker, time, and contrast results</summary><ul class="transcript-comparisons">'
                      + ''.join(comparisons) + '</ul></details></article>')
    speech.append('<p>AMI manual transcript excerpts, © University of Edinburgh and partners under CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a>.</p></section>')
    fresh = ['<section id="or-followup-fresh"><h2>All 12 new claims</h2>'
             '<p>Each entry gives the source wording, the intended reading, and the program review. '
             'The judgments concern wording and structure.</p>']
    for row in result['fresh']:
        fresh.append(f'<article class="box benchmark-case"><h3>{LABELS[row["verdict"]]}</h3>'
                     f'<blockquote>{escape(row["text"])}</blockquote>'
                     f'<p><b>Reference reading.</b> {escape(row["reference"])}</p>'
                     f'<p><b>Finding.</b> {escape(row["finding"])}</p>'
                     + program_details(row)
                     + f'<p><a href="{escape(row["fact_checking_article"], quote=True)}">AVeriTeC source article</a></p></article>')
    return ''.join(repairs + speech + fresh) + '</section>'


def write_downloads():
    target = ROOT / 'site/reports' / URL
    target.mkdir(parents=True,exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,target/name)


if __name__ == '__main__':
    summarize()
