"""Build the report for negative scope and audio speaker windows."""
from collections import Counter
from hashlib import sha256
from html import escape
from shutil import copy2
import xml.etree.ElementTree as ET

from compiler_fallback_report import table
from or_followup_report import inventory, program_details
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from prepare_scope_alignment import ROOT, RUN

URL='compiler-demos/scope-and-alignment-20261119/'
OLD=RUN.with_name('or_followup_20261119')/'full-final/corpus.jsonl'
CUR=RUN/'full-final/corpus.jsonl'
LABELS={'preserved':'Scope preserved','incorrect':'Scope or content error','abstained':'No program'}
TARGETS=('absence_1','rule_1','averitec_train_1197','averitec_train_2288')


def compare():
    frozen=RUN/'compiler/claims.json'
    assert sha256(frozen.read_bytes()).hexdigest()==(RUN/'compiler/claim_sha256.txt').read_text().strip()
    before={r['claim_id']:r['fixed'] for r in read(RUN/'before.json')}
    after={r['claim_id']:r['fixed'] for r in read(RUN/'after.json')}
    reviews=read(RUN/'interpretation.json')
    claims=read(frozen)
    assert before.keys()==after.keys()==reviews.keys()=={r['claim_id'] for r in claims}
    all_cases=[]
    counters={g:Counter() for g in ('controlled','fresh','prior')}
    for claim in claims:
        cid=claim['claim_id']
        previous,current=before[cid]['output'],after[cid]['output']
        counter=counters[claim['group']]
        verdict,finding=reviews[cid]
        assert bool(current)==(verdict!='abstained'),cid
        unchanged=(previous or {}).get('program_sha256')==(current or {}).get('program_sha256')
        counter['inputs']+=1
        counter['before']+=bool(previous)
        counter['after']+=bool(current)
        counter['changed']+=not unchanged
        counter[verdict]+=1
        all_cases.append(dict(claim, before=previous, after=current, verdict=verdict, finding=finding,
                             attempts=[{k:a[k] for k in ('stage','status','code','reason') if k in a}
                                       for a in after[cid]['attempts']]))
    return all_cases,counters


def summarize():
    cases,compilation=compare()
    before,after=inventory(OLD),inventory(CUR)
    assert before.keys()==after.keys()
    changed=[cid for cid in before if before[cid]!=after[cid]]
    same=sum(before[cid]==after[cid] and bool(after[cid][1]) for cid in after)
    corpus=dict(total=len(before),identical=same,changed=changed,
                before=sum(bool(item[1]) for item in before.values()),
                after=sum(bool(item[1]) for item in after.values()))
    assert not changed,changed
    dump(RUN/'corpus_hashes.json',dict(before=before,after=after))
    speech=[read(RUN/f'speech_evaluation{suffix}.json') for suffix in ('','_roster')]
    native=read(RUN/'native.json')
    suite=ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(k,0))==0 for k in ('failures','errors','skipped'))
    summary=dict(compilation=compilation,corpus=corpus,tests=int(suite.get('tests')),
                 native=len(native),speech=[s['counts'] for s in speech])
    dump(RUN/'evaluation.json',dict(summary=summary,examples=cases,speech=speech,native=native))
    print(summary)


def status_html():
    return ('<b>The compiler preserves both targeted scope relations.</b> '
            'On the eight new AMI excerpts, annotated windows support all eight claims and audio-proposed '
            'speaker windows support one.')


def overview_html():
    result=read(RUN/'evaluation.json')
    s=result['summary']
    report=(
        '<h2 id="remaining-failures">Negative scope and speaker alignment</h2>'
        '<p>“Without A or B” requires one event without either item. “Must do A or face B” '
        'can express a requirement with a consequence of noncompliance. Ordinary choices and '
        'separate clauses retain their own scope.</p>'
        + table('Automatic compilation and review of the selected construction.',
                ['Inputs','Before passes','After passes','Scope preserved','Scope or content error','No program'],
                [(label,s['compilation'][k]['before'],s['compilation'][k]['after'],
                  *(s['compilation'][k].get(a,0) for a in LABELS))
                  for k,label in [('controlled','22 authored controls'),('fresh','9 new dataset claims'),
                                  ('prior','2 earlier false passes')]])
        + f'<p>The compiler keeps both earlier claims’ targeted scope. Two new false passes now abstain. '
        f'All {s["corpus"]["identical"]:,} accepted programs are byte-identical in the {s["corpus"]["total"]:,}-claim rerun. '
        f'{s["native"]} exact inference controls show how the new forms behave with supplied evidence. '
        f'All {s["tests"]} project tests passed.</p>'
        '<h3>Automatic speaker windows</h3>'
        '<p>We use a distant microphone and frozen speaker diarization, which estimates when each speaker is active. '
        'The experiment keeps the manually transcribed words and word times in every condition. '
        'For the automatic conditions, each word is selected by its time alone. Anonymous speaker labels are matched '
        'to participant IDs using a separate earlier span. The verifier searches a 35-second interval, with '
        'speaker and time controls.</p>')
    transcription=[]
    result_0,result_1=s['speech']
    comparisons=(('Annotated windows',result_0,'reference'),
                 ('Proposed windows, speaker ignored',result_0,'windows'),
                 ('Proposed speaker windows',result_0,'speakers'),
                 ('Proposed speaker windows, known participant count',result_1,'speakers'))
    for name,counts,key in comparisons:
        transcription.append((name,*(f'{counts[c][key]}/{counts[c]["total"]}'
                                    for c in ('correct_speaker','different_speaker','disjoint_query'))))
    return (report+table('Expected verdicts matched for the three test conditions.',
                         ['Window source','Correct speaker','Wrong speaker','Earlier time'],transcription)
            + '<p>The known participant count reduces fragmented speaker labels and yields the same verdict counts. '
              'The annotated transcript and its exact wording provide a controlled comparison. The new audio test '
              'still uses human transcripts and earlier labeled speech for matching speaker IDs.</p>'
              '<p><a href="#negative-scope-cases">Compiler examples</a> · '
              '<a href="#automatic-speaker-windows">Speaker windows and evidence</a> · '
              '<a href="#earlier-or-followup">Earlier OR follow-up</a> · '
              '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
              f'<p><a href="{URL}evaluation.json">Exact results</a> · <a href="{URL}source.zip">Source and replay</a> · '
              f'<a href="{URL}tests.xml">Tests</a></p>')


def timeline(row):
    query=row['variants'][0]['query']
    lo,hi=query['start'],query['end']
    who=row['gold']['speaker']
    names=row['names']
    all_turns=row['turns']
    named=[t for t in all_turns if names.get(str(t['cluster']))==who]
    styles=lambda t:(100*(max(lo,t['start'])-lo)/(hi-lo),100*(min(hi,t['end'])-max(lo,t['start']))/(hi-lo))
    groups=(('Annotated utterance',[row['gold']]),('Any proposed speaker',all_turns),
            ('Requested speaker',named))
    parts=['<figure class="speaker-window-figure"><figcaption>Figure 1. '
           f'{row["meeting"]} from {lo:g} to {hi:g} seconds. The claim names speaker {who}.</figcaption>']
    for label,turns in groups:
        bars=[]
        for t in turns:
            if t['end']<=lo or t['start']>=hi:
                continue
            a,b=styles(t)
            bars.append(f'<span style="left:{a:.3f}%;width:{b:.3f}%" title="{t["start"]:.2f} to {t["end"]:.2f} seconds"></span>')
        parts.append(f'<div class="speaker-window-track"><strong>{label}</strong>'
                     '<div>'+''.join(bars)+'</div></div>')
    return ''.join(parts)+'<p class="muted">Each row uses the same time scale.</p></figure>'


def examples_html():
    result=read(RUN/'evaluation.json')
    examples={r['claim_id']:r for r in result['examples']}
    blocks=['<section id="negative-scope-cases"><h2>Absence and consequences</h2>']
    for cid in TARGETS:
        row=examples[cid]
        blocks.extend((f'<article class="box benchmark-case" id="scope-alignment-{cid}">'
                       f'<blockquote>{escape(row["text"])}</blockquote><p>{escape(row["finding"])}</p>',
                       program_details(row),'</article>'))
    blocks.append('<details><summary>All 33 reviewed scope cases</summary>'+
        table('Frozen readings with the observed result.', ['Claim','Reference reading','Compiler review'],
              [(escape(r['text']),escape(r['reference']),escape(r['finding'])) for r in examples.values()])+
        '</details></section>')
    blocks.append('<section id="automatic-speaker-windows"><h2>Eight speaker and time comparisons</h2>'
                  '<p>The upper strip shows the annotated utterance. The others show which parts of the '
                  'query interval the diarizer associated with any speaker or with the requested speaker. '
                  'The per-case details show the proposed text and the three comparisons.</p>')
    for i,(row,roster) in enumerate(zip(result['speech'][0]['rows'],result['speech'][1]['rows']),1):
        controls=[]
        for earlier,later in zip(row['variants'],roster['variants']):
            controls.append((earlier['variant'].replace('_',' ').capitalize(),earlier['expected'],
                             *earlier['predictions'].values(), later['predictions']['speakers']))
        ranked=sorted(row['proposals'],key=lambda p: p['start'])
        speech_rows=[(f'{p["start"]:.2f}–{p["end"]:.2f}',p['speaker'] or 'Unmapped', escape(p['text']))
                     for p in ranked if p['end']>row['variants'][0]['query']['start']]
        chosen=row['variants'][0]['matched_windows']
        witness=(f'<p><b>Supported candidate text.</b> {escape(chosen[0]["text"])}</p>' if chosen
                 else '<p>The proposed windows did not produce a matching text span.</p>')
        blocks.extend((f'<article class="box benchmark-case" id="automatic-speaker-{i}"><h3>{row["meeting"]}</h3>'
                       f'<blockquote>{escape(row["target"])}</blockquote>{timeline(row)}{witness}',
                       f'<p>Best window retains {row["max_word_coverage"]:.0%} of the utterance’s words. '
                       f'Best window assigned to the requested speaker retains {row["named_word_coverage"]:.0%}.</p>'
                       '<details><summary>All judgments and proposed text</summary>',
                       table('Each condition uses the same claim wording.',
                             ['Query','Expected','Annotated','Window only','Speaker window','With count'],controls),
                       table('Word selection from the automatically labeled windows in the query interval.',
                             ['Seconds','Speaker','Text'],speech_rows) if speech_rows else '',
                       '</details></article>'))
    blocks.append('<p>Audio and transcribed excerpts from the AMI Meeting Corpus, © University of Edinburgh '
                  'and partners, CC BY 4.0. <a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a>.</p></section>')
    return ''.join(blocks)


def write_downloads():
    target=ROOT/'site/reports'/URL
    target.mkdir(parents=True,exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,target/name)


if __name__=='__main__':
    summarize()
