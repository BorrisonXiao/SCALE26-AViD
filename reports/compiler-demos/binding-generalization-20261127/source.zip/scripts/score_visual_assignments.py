"""Score candidate identities and values on the five previously reviewed clips."""
import argparse
from hashlib import sha256
import importlib.metadata
from pathlib import Path

from prepare_compiler_fallback import ROOT, dump
from prepare_or_source_evaluation import read

PRIOR = ROOT/'exp/probabilistic_verification/compiler_scope_20261118'
RUN = PRIOR.with_name('binding_generalization_20261127')
MODEL = Path('/exp/cxiao/calm/downloads/models/qwen3-vl/8B-Instruct')

# Fixed before scoring. Each scene has two distinct candidate regions.
# The date and logo sides are supplied by the crop coordinates.
REGIONS = {
    'vehicle_colors': ((0,.28,1,.69),(0,.2,1,.67),('gray','yellow'),
                       'main vehicle', 'What color is the main vehicle’s exterior?'),
    'tie_colors': ((.15,0,.72,.99),(.24,0,.99,1),('blue','red'),
                   'person', 'What color is the man’s tie?'),
    'sails_and_caption': ((.13,.40,.94,.83),(.15,.875,.93,1),('red','white'),
                          'displayed item','What color is the highlighted object or lettering in this crop?'),
    'road_dates': ((.18,.1,.46,.198),(.55,.1,.88,.198),('APRIL 21, 2020','JANUARY 23, 2025'),
                   None,'Which date is printed in this crop?'),
    'corner_logos': ((0,.105,.24,.235),(.73,.105,1,.235),('7 NEWS .com.au','sunrise'),
                     None,'Which text is printed in the logo?'),
}


def freeze():
    RUN.mkdir(parents=True,exist_ok=True)
    scenes = []
    for pair in read(PRIOR/'binding_contrasts.json')['pairs']:
        a,b,values,subject,question = REGIONS[pair['pair_id']]
        identities = {'tie_colors':['Mark Carney','Donald Trump'],
                      'sails_and_caption':['sails','username text']}.get(pair['pair_id'],pair['candidates'])
        scene = {k:pair[k] for k in ('pair_id','source_video','split','media_route','review')}
        scene.update(subject=subject,question=question,identities=identities,values=values,
                     claims=[r['claim'] for r in pair['examples']],
                     regions=[dict(frame=f,box=box) for f,box in zip(pair['frames'],(a,b),strict=True)])
        scenes.append(scene)
    dump(RUN/'visual_inputs.json',scenes)


def score():
    import torch
    from PIL import Image
    from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

    torch.set_num_threads(4)
    processor = AutoProcessor.from_pretrained(MODEL,local_files_only=True)
    model = Qwen3VLForConditionalGeneration.from_pretrained(MODEL,dtype=torch.bfloat16,device_map='cuda:0',
                attn_implementation='sdpa',local_files_only=True).eval().requires_grad_(False)
    tokens = [processor.tokenizer.encode(s,add_special_tokens=False) for s in 'ABC']
    assert all(len(t)==1 for t in tokens),tokens
    labels = torch.tensor([t[0] for t in tokens],device='cuda:0')
    records = []
    for scene in read(RUN/'visual_inputs.json'):
        scene_records = {}
        for quality in ('original','reduced_resolution'):
            scene_records[quality] = []
            for index,region in enumerate(scene['regions']):
                path = PRIOR/'media'/region['frame']['image']
                assert sha256(path.read_bytes()).hexdigest()==region['frame']['image_sha256']
                with Image.open(path) as source:
                    w,h = source.size
                    l,t,r,b = region['box']
                    image = source.convert('RGB').crop((round(l*w),round(t*h),round(r*w),round(b*h)))
                image.thumbnail((574,392),Image.Resampling.LANCZOS)
                if quality=='reduced_resolution':
                    small = image.copy()
                    small.thumbnail((64,40),Image.Resampling.LANCZOS)
                    image = small.resize(image.size,Image.Resampling.BILINEAR)
                details = {}
                for kind,choices,question in (
                    ('identity',scene['identities'],f'Which {scene["subject"]} is most prominent in the crop?'),
                    ('value',scene['values'],scene['question']),
                ):
                    if kind=='identity' and scene['subject'] is None:
                        p = [float(index==0),float(index==1),0.]
                        details[kind] = dict(distribution=p,source='crop coordinates')
                        continue
                    orderings = []
                    for a,b in ((0,1),(1,0)):
                        text = (f'{question}\nA. {choices[a]}\nB. {choices[b]}\nC. Neither or unclear.\n'
                                'Answer with exactly one letter.')
                        messages = [{'role':'user','content':[{'type':'image','image':'attached'},{'type':'text','text':text}]}]
                        prompt = processor.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
                        batch = processor(text=[prompt],images=[image],return_tensors='pt').to('cuda:0',dtype=torch.bfloat16)
                        with torch.inference_mode():
                            outputs = model.model(**batch,use_cache=False)
                            logits = model.lm_head(outputs.last_hidden_state[:,-1:,:])[0,-1].double()
                            restricted = logits.index_select(0,labels).softmax(-1).tolist()
                            mass = float(logits.softmax(-1).index_select(0,labels).sum())
                        orderings.append(dict(prompt=text,distribution=restricted if a==0 else
                                               [restricted[1],restricted[0],restricted[2]],choice_mass=mass))
                    details[kind] = dict(distribution=[sum(r['distribution'][i] for r in orderings)/2 for i in range(3)],
                                         orderings=orderings,source='frozen Qwen letter scores')
                scene_records[quality].append(details)
        records.append(dict(pair_id=scene['pair_id'],conditions=scene_records))
        print(scene['pair_id'],'scored',flush=True)
    dump(RUN/'visual_scores.json',dict(model='Qwen3-VL-8B-Instruct',config_sha256=sha256((MODEL/'config.json').read_bytes()).hexdigest(),
               versions={p:importlib.metadata.version(p) for p in ('torch','transformers')},records=records))


if __name__=='__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage',choices=('freeze','score'))
    {'freeze':freeze,'score':score}[p.parse_args().stage]()
