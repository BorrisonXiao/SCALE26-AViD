"""Freeze written claim variants before their transcript scores are computed."""
import argparse
from hashlib import sha256

from prepare_ami_speaker_binding import REPORTS, RUN as BINDING_RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from probabilistic_verification.transcript_or import splits

RUN = BINDING_RUN.with_name('ami_speech_verification_20261126')
VARIANTS = ('original', 'paraphrase', 'changed_option', 'changed_context')

# Each set changes only the claim. The evidence is the same annotated utterance.
# The changed options and shared context are defined before running either scorer.
PARAPHRASES = {
    'IS1006a': ('when changing channels, you can advance to the next channel or go straight to channel twenty-five',
                ('twenty-five', 'twenty-six'), ('changing channels', 'changing inputs')),
    'ES2014c': ('you can make the design curved or give it a double curve',
                ('curved or', 'straight or'), ('can make', 'must make')),
    'ES2008d': ('you still cannot see it when it is under blankets or inside a couch',
                ('a couch', 'a drawer'), ('cannot see', 'can see')),
    'TS3003c': ('the remote would have to look fancy with a wooden cover or a plastic cover',
                ('plastic cover', 'metal cover'), ('look fancy', 'look plain')),
    'ES2016a': ('the device would beep if you whistled or made a sound',
                ('whistled', 'waved'), ('would beep', 'would flash')),
    'EN2002d': ('the document could easily run to five pages or six pages',
                ('six pages', 'seven pages'), ('could easily run to', 'had already reached')),
    'IN1001': ('they would ask you or somebody else',
               ('somebody else', 'your supervisor'), ('would ask', 'had already asked')),
    'IS1003c': ('they could not see how speech recognition or gesture recognition would make the remote look more like Google',
                ('gesture recognition', 'face recognition'), ('could not see how', 'understood how')),
}


def freeze():
    source = BINDING_RUN / 'binding_cases.json'
    records, claims = [], []
    for row in read(source):
        meeting = row['meeting']
        paraphrase, *edits = PARAPHRASES[meeting]
        hypotheses = [REPORTS[meeting], paraphrase]
        for old, new in edits:
            assert paraphrase.count(old) == 1
            hypotheses.append(paraphrase.replace(old, new))
        assert all(len(list(splits(text, 'or'))) == 1 for text in hypotheses)
        reference = next(case for case in row['cases'] if case['name'] == 'annotated')
        variants = []
        for i, (variant, content) in enumerate(zip(VARIANTS, hypotheses)):
            cid = f'ami_{meeting}_{variant}'
            text = f'Participant {row["speaker"]} said that {content}.'
            variants.append(dict(claim_id=cid, variant=variant, content=content, text=text,
                                 expected_support=i < 2))
            claims.append(dict(claim_id=cid, content=content, text=text))
        records.append(dict(meeting=meeting, evidence=reference['windows'][0], query=reference['query'],
                            variants=variants))
    (RUN/'compiler').mkdir(parents=True, exist_ok=True)
    dump(RUN/'compiler/claims.json', claims)
    dump(RUN/'cases.json', dict(source_sha256=sha256(source.read_bytes()).hexdigest(), rows=records))
    (RUN/'cases.sha256').write_text(sha256((RUN/'cases.json').read_bytes()).hexdigest()+'\n')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage', choices=('freeze','dependency'))
    if p.parse_args().stage == 'freeze':
        freeze()
    else:
        import prepare_or_followup

        prepare_or_followup.RUN = RUN
        prepare_or_followup.prepare('compiler')
