"""Freeze AMI speech-binding claims and candidate assignments."""
from hashlib import sha256

from collect_ami_or_candidates import detokenize
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from prepare_scope_alignment import RUN as PRIOR_RUN
from probabilistic_verification.transcript_or import splits

RUN = PRIOR_RUN.with_name('ami_speaker_binding_20261126')

# Remove introductory disfluencies and preserve both alternatives. First-person
# reports are converted to indirect speech in the compiler input only.
REPORTS = {
    'IS1006a': 'you can just go to the next one or go to channel twenty five',
    'ES2014c': 'you can make them curved or double-curved',
    'ES2008d': "if it's like under covers or like in a couch you still can't see it",
    'TS3003c': 'it would have to be fancy with either the wood cover or the plastic one',
    'ES2016a': "you could whistle or make a noise and it'd beep",
    'EN2002d': 'that could easily be five or six pages',
    'IN1001': 'they will ask you or someone else',
    'IS1003c': "they don't see how adding speech or gesture recognition would make the remote control look more like Google",
}


def freeze():

    source = PRIOR_RUN / 'speech_cases.json'
    assert sha256(source.read_bytes()).hexdigest() == (PRIOR_RUN / 'speech_cases.sha256').read_text().strip()
    controls = {r['meeting']: r['variants'] for r in read(PRIOR_RUN / 'speech_inputs.json')}
    cases = []
    claims = []
    for case in read(source):
        meeting = case['meeting']
        speaker = case['speaker']
        wrong = controls[meeting][1]['query']['speaker']
        query = controls[meeting][0]['query']
        earlier = controls[meeting][2]['query']
        assert wrong != speaker and earlier['end'] < query['start']
        words = case['words']
        index, = [i for i, w in enumerate(words) if w['text'].casefold() == 'or']
        left_words, right_words = words[:index], words[index + 1:]
        left, right = list(splits(case['text'], 'or'))[0]
        whole = dict(text=case['text'], start=case['start'], end=case['end'], speaker=speaker,
                     turn=f'{meeting}:annotated', complete=True)
        left_part = dict(text=detokenize(left_words), start=left_words[0]['start'],
                         end=left_words[-1]['end'], speaker=speaker, complete=False,
                         turn=f'{meeting}:part1', branch='left')
        right_part = dict(text=detokenize(right_words), start=right_words[0]['start'],
                          end=right_words[-1]['end'], speaker=speaker, complete=False,
                          turn=f'{meeting}:part2', branch='right')
        variants = [
            dict(name='annotated', query=query, windows=[whole], expected='supported'),
            dict(name='wrong_speaker', query=query, windows=[dict(whole, speaker=wrong)], expected='unknown'),
            dict(name='earlier_time', query=earlier, windows=[whole], expected='unknown'),
            dict(name='split_speakers', query=query, windows=[left_part, dict(right_part, speaker=wrong)],
                 expected='unknown'),
            dict(name='split_utterances', query=query, windows=[left_part, right_part], expected='unknown'),
        ]
        cid = f'ami_{meeting}'
        cases.append(dict(claim_id=cid, meeting=meeting, speaker=speaker, source_segment=case['segment_id'],
                          text=case['text'], start=case['start'], end=case['end'], alternatives=[left,right],
                          cases=variants))
        claims.append(dict(claim_id=cid, content=REPORTS[meeting],
                           text=f'Participant {speaker} said that {REPORTS[meeting]}.'))
    folder = RUN / 'compiler'
    folder.mkdir(parents=True, exist_ok=True)
    dump(RUN/'binding_cases.json', cases)
    dump(folder/'claims.json', claims)
    return folder


if __name__ == '__main__':
    import prepare_or_followup as parser

    freeze()
    parser.RUN = RUN
    parser.prepare('compiler')
