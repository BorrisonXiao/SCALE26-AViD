"""Freeze annotated AMI candidate utterances and controlled changes."""
import argparse
from hashlib import sha256
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from collect_ami_or_candidates import NITE_ID, aligned_words, detokenize
from prepare_ami_window_comparison import RUN as PRIOR, frozen_cases
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import RUN as SOURCE, read

RUN = PRIOR.with_name('ami_probabilistic_binding_20261126')


def claim_id(meeting, variant):
    return f'ami_{meeting}_{variant}'


def freeze_claims():
    path = RUN/'compiler/claims.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    claims = []
    for row in frozen_cases():
        if row['split']!='test':
            continue
        for case in row['variants']:
            content = case['content']
            quote = content if content.endswith(('.', '?', '!')) else content+'.'
            claims.append(dict(claim_id=claim_id(row['meeting'],case['variant']),content=content,
                               text=f'Participant {row["speaker"]} said, “{quote}”',speaker=row['speaker']))
    dump(path,claims)


def source_utterances(archive, row):
    """Read real utterance boundaries rather than joining unrelated turns."""
    prefix = f'segments/{row["meeting"]}.'
    for path in sorted(p for p in archive.namelist() if p.startswith(prefix) and p.endswith('.segments.xml')):
        speaker = path[len(prefix):].split('.')[0]
        tokens = list(ET.fromstring(archive.read(f'words/{row["meeting"]}.{speaker}.words.xml')))
        positions = {token.get(NITE_ID):i for i,token in enumerate(tokens)}
        for segment in ET.fromstring(archive.read(path)):
            words = aligned_words(segment,tokens,positions)
            if not words or words[0]['start']<row['clip_start'] or words[-1]['end']>row['clip_end']:
                continue
            yield utterance(words,speaker,segment.get(NITE_ID))


def utterance(words, speaker, identifier):
    return dict(id=identifier,speaker=speaker,start=words[0]['start'],end=words[-1]['end'],
                text=detokenize(words),word_ids=[w['word_id'] for w in words])


def overlaps(candidate, query):
    return candidate['start']<query['end'] and candidate['end']>query['start']


def choose_distractors(row, candidates, query, earlier):
    candidates = [w for w in candidates if w['id']!=row['segment_id'] and
                  6<=len(w['word_ids'])<=38 and w['end']>w['start']]
    selections = []
    for speaker, interval in ((row['speaker'],query),(row['wrong_speaker'],query),(row['speaker'],earlier)):
        nearby = [w for w in candidates if w['speaker']==speaker and overlaps(w,interval)]
        if nearby:
            # Prefer naturally occurring distractors with an alternative marker,
            # independent of the hypothesis and model decisions.
            selections.append(min(nearby,key=lambda w:(' or ' not in w['text'].casefold(),
                                                         abs(w['start']-row['start']),w['id'])))
    return list({w['id']:w for w in selections}.values())


def cases():
    path = RUN/'cases.json'
    assert sha256(path.read_bytes()).hexdigest()==(RUN/'cases.sha256').read_text().strip()
    return read(path)


def freeze_cases():
    source = SOURCE/'source/ami_public_manual_1.6.2.zip'
    meetings = []
    with ZipFile(source) as archive:
        for row in frozen_cases():
            if row['split']!='test':
                continue
            meeting, speaker = row['meeting'], row['speaker']
            query = dict(speaker=speaker,start=row['query_start'],end=row['query_end'])
            earlier = dict(speaker=speaker,start=row['clip_start'],end=row['query_start']-5)
            candidates = list(source_utterances(archive,row))
            gold, = (w for w in candidates if w['id']==row['segment_id'] and w['speaker']==speaker)
            assert gold['text']==row['text']
            distractors = choose_distractors(row,candidates,query,earlier)
            window_set = sorted([gold,*distractors],key=lambda w:(w['start'],w['id']))
            variants = [dict(c,id=claim_id(meeting,c['variant']),query=query,windows=window_set) for c in row['variants']]
            paraphrase, = (c['content'] for c in row['variants'] if c['variant']=='paraphrase')
            cut, = (i for i,w in enumerate(row['words']) if w['text'].casefold()=='or')
            left = utterance(row['words'][:cut],speaker,gold['id']+':first')
            right = utterance(row['words'][cut+1:],speaker,gold['id']+':second')
            split = [left,right,*distractors]
            separate_speakers = [left,dict(right,speaker=row['wrong_speaker']),*distractors]
            for name, q, wins in (
                ('wrong_speaker',dict(query,speaker=row['wrong_speaker']),window_set),
                ('wrong_time',earlier,window_set),
                ('split_utterances',query,split),
                ('split_speakers',query,separate_speakers),
            ):
                variants.append(dict(id=claim_id(meeting,name),variant=name,content=paraphrase,query=q,
                                     expected_support=False,windows=sorted(wins,key=lambda w:(w['start'],w['id']))))
            meetings.append(dict(meeting=meeting,source=gold['id'],gold=gold['text'],cases=variants))
    path = RUN/'cases.json'
    dump(path,meetings)
    (RUN/'cases.sha256').write_text(sha256(path.read_bytes()).hexdigest()+'\n')
    print('Froze',sum(len(r['cases']) for r in meetings),'queries from',len(meetings),'test meetings.',flush=True)


if __name__=='__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage',choices=('claims','cases','dependencies'))
    stage = p.parse_args().stage
    if stage=='dependencies':
        import prepare_or_followup

        prepare_or_followup.RUN = RUN
        prepare_or_followup.prepare('compiler')
    else:
        {'claims':freeze_claims,'cases':freeze_cases}[stage]()
