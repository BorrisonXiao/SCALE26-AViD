"""Freeze time-aligned excerpts and paraphrased claims before model scoring."""
from hashlib import sha256

from collect_ami_or_candidates import detokenize
from prepare_compiler_fallback import dump
from prepare_or_followup import RUN
from prepare_or_source_evaluation import read

# Segment ID, word interval, and cut after the first complete alternative.
# The crops contain the original words and carry their original times.
READINGS = [
    ('EN2001d.sync.289', [(1, 4, 23), (0, 0, 21)], 19,
     'We can leave those I_ frames and arrange them, or we can already have everything running during the presentation and arrange it manually.'),
    ('EN2004a.sync.508', [(1, 37, 117), (0, 8, 31)], 80,
     'Check the exact speech boundaries from the transcription tier, or listen to the speech segments again and check those.'),
    ('ES2004c.sync.663', [(1, 38, 71), (0, 0, 24)], 47,
     'Use a bare circuit board that connects when you touch it, or use rubber buttons.'),
    ('ES2013c.sync.15', [(0, 0, 45)], 24,
     'The target market would be adults aged fifteen to thirty-five who make decisions, or a manufacturer could include it with the television.'),
    ('IS1008c.sync.407', [(0, 51, 117)], 57,
     'We could use a simple design on the board or use the advanced chip on print.'),
]
NEGATIVES = [
    ('TS3006d.sync.43', [(0, 3, 35)], 'Use a doubly curved shape or remove the digit buttons.'),
    ('ES2004c.sync.663', [(0, 14, 42)], 'Use a double-sided remote or offer rubber buttons.'),
]

CONTRASTS = {
    'EN2001d.sync.289': 'We can leave those I_ frames and arrange them or have everything running for the rehearsal and arrange it automatically.',
    'EN2004a.sync.508': 'Check the exact speech boundaries from the transcription tier or read the transcripts silently.',
    'ES2004c.sync.663': 'Use a bare circuit board that connects when you touch it or use a button made of metal.',
    'ES2013c.sync.15': 'The target market would be adults aged fifty to sixty-five who make decisions or a manufacturer could include it with the television.',
    'IS1008c.sync.407': 'We could use a simple design on the board or use the regular chip on print.',
}


def main():
    folder = RUN / 'transcripts'
    candidates = {r['segments'][-1]['segment_id']: r for r in read(folder / 'implicit_candidates.json')}
    segments = []
    for cid, intervals, *rest in READINGS + NEGATIVES:
        raw = candidates[cid]
        source = [raw['segments'][-offset-1] for offset, _, _ in intervals]
        words = [w for s, (_, a, b) in zip(source, intervals) for w in s['words'][a:b]]
        speaker = raw['speaker']
        start, end = words[0]['start'], words[-1]['end']
        text = detokenize(words)
        target = rest[-1]
        positive = len(rest) == 2
        examples = [(text, start, end, speaker, True, 'complete', 'supported' if positive else 'unknown')]
        if positive:
            cut = rest[0]
            examples += [
                (detokenize(words[:cut]), start, words[cut-1]['end'], speaker, False, 'early_crop', 'unknown'),
                (detokenize(words[cut:]), words[cut]['start'], end, speaker, False, 'late_crop', 'unknown'),
                (text, start, end, 'B' if speaker == 'A' else 'A', True, 'wrong_speaker', 'unknown'),
                (text, end + 1, end + (end-start) + 1, speaker, True, 'later_time', 'unknown'),
            ]
        cases = [dict(text=t, target=target, start=a, end=b, speaker=s, complete=full, variant=v, expected=label)
                 for t, a, b, s, full, v, label in examples]
        if positive:
            cases.append(dict(cases[0], variant='changed_alternative', target=CONTRASTS[cid], expected='unknown'))
        segments.append(dict(meeting=raw['meeting'], speaker=speaker, source_segments=[s['segment_id'] for s in source],
                             start=start, end=end, text=text, words=words, cases=cases))
    dump(folder / 'segments.json', segments)
    (folder / 'segments.sha256').write_text(sha256((folder / 'segments.json').read_bytes()).hexdigest()+'\n')
    for row in segments:
        print(row['source_segments'], row['text'])
        print(row['cases'][0]['target'])


if __name__ == '__main__':
    main()
