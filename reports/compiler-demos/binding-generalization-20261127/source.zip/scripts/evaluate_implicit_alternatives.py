"""Check real alternatives without “or” under controlled transcript alignment."""
import argparse
from collections import Counter
from hashlib import sha256
from itertools import chain, product

from evaluate_reported_or_transcripts import score_pairs
from prepare_compiler_fallback import dump
from prepare_or_followup import PRIOR, RUN
from prepare_or_source_evaluation import read
from probabilistic_verification.transcript_or import implicit_splits, judge, normalize, splits

FOLDER = RUN / 'transcripts'


def inputs():
    file = FOLDER / 'segments.json'
    assert sha256(file.read_bytes()).hexdigest() == (FOLDER / 'segments.sha256').read_text().strip()
    return dict(new=read(file), prior=read(PRIOR / 'transcripts/evaluation.json')['segments'])


def new_pairs(groups):
    pairs = set()
    for group in groups.values():
        for segment in group:
            for case in segment['cases']:
                if (case['speaker'] != segment['speaker'] or case['end'] <= segment['start']
                        or case['start'] >= segment['end']):
                    continue
                text, target = case['text'], case['target']
                alternatives = list(splits(target, 'or'))
                if len(alternatives) != 1:
                    continue
                candidates = {text}
                for pair in chain(splits(text, 'or'), splits(text, 'and'), implicit_splits(text)):
                    candidates.update(pair)
                for a, b in product(candidates, alternatives[0]):
                    if normalize(a) != normalize(b):
                        pairs.update(((a,b),(b,a)))
    return pairs


def stored_scores(path):
    return {(s['premise'],s['hypothesis']): s['probabilities']
            for s in read(path)['scores']}


def score():
    prior = stored_scores(PRIOR / 'transcripts/nli_scores.json')
    pairs = new_pairs(inputs()) - prior.keys()
    result = score_pairs(pairs, PRIOR / 'source/minilm-nli')
    dump(FOLDER / 'scores.json', result)
    print('New NLI pairs', len(result['scores']))


def evaluate():
    scores = stored_scores(PRIOR / 'transcripts/nli_scores.json') | stored_scores(FOLDER / 'scores.json')
    def entailment(a,b):
        return scores[a,b]['entailment']

    def contradiction(a,b):
        return scores[a,b]['contradiction']
    totals = {}
    groups = inputs()
    for name, segments in groups.items():
        count = Counter()
        for segment in segments:
            for case in segment['cases']:
                before = judge(segment, case, entailment)
                after = judge(segment, case, entailment, allow_implicit=True, contradiction=contradiction)
                case['before'], case['after'] = before, after
                expected = case['expected']
                count['comparisons'] += 1
                count['before_matches'] += before == expected
                count['after_matches'] += after == expected
                count['regressions'] += before == expected and after != expected
                count['new_false_support'] += before != 'supported' and after == 'supported' and expected != 'supported'
                if expected == 'supported' and case['variant'] == 'complete':
                    count['complete_positive'] += 1
                    count['complete_supported'] += after == 'supported'
                if case['variant'] in {'wrong_speaker','later_time'}:
                    count['alignment_controls'] += 1
                    count['alignment_false_support'] += after == 'supported'
        totals[name] = dict(count)
    dump(FOLDER / 'evaluation.json', dict(summary=totals, cases=groups))
    print(totals)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage', choices=('score','evaluate'))
    {'score': score, 'evaluate': evaluate}[p.parse_args().stage]()
