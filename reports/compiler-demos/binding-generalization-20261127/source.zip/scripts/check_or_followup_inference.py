"""Check exact inference on actual programs produced by the compiler."""
from evaluate_reported_or_transcripts import inference
from prepare_compiler_fallback import dump
from prepare_or_followup import PRIOR, RUN
from prepare_or_source_evaluation import read
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.compiler_fallback import restore
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.representation import STATES


def evaluate():
    programs = {r['claim_id']: r['fixed']['output']['compilation']
                for path in ('controlled_after.json', 'prior_after.json')
                for r in read(RUN / path) if r['fixed']['output']}
    results = []

    def check(cid, case, expected, decide):
        claim = restore(programs[cid])
        bindings = {v.name: 'candidate:' + v.name for v in claim.variables}
        domains = {v: [value] for v, value in bindings.items()}
        observations = {}
        for atom in claim.atoms:
            key = canonical_key('or-followup', atom, bindings, 'visual_depiction')
            state = decide(atom)
            observations[key] = Observation(key, tuple(float(s == state) for s in STATES), False, atom.text)
        program = ground(claim, Evidence('or-followup', domains, dict.fromkeys(domains, True), observations))
        result = DirectVerifier([program], learned=False, program_builder=compact_prolog_program).predict()[0]
        assert result['distribution'][expected] > 1 - 1e-10, (cid, case, result)
        results.append(dict(claim_id=cid, case=case, expected=expected, distribution=result['distribution']))

    for a, b, expected in (
        ('refuted', 'refuted', 'supported'), ('supported', 'refuted', 'refuted'),
        ('refuted', 'supported', 'refuted'), ('refuted', 'unknown', 'unknown'),
    ):
        for cid, names in (('neg_1', ('lift','move')), ('or_averitec_train_4', ('call','encourage'))):
            observations = dict(zip(names,(a,b)))
            check(cid, f'Events {a}, {b}', expected, lambda atom: observations.get(atom.predicate, 'supported'))

    for actual, due, expected in (
        ('supported','refuted','supported'), ('refuted','supported','supported'),
        ('refuted','refuted','refuted'), ('refuted','unknown','unknown'),
    ):
        def predict(atom):
            if atom.predicate != 'fly':
                return 'supported'
            assert 'back to the UK' in atom.arguments[4]
            return actual if atom.arguments[atom.arguments.index('scope')+1] == 'world' else due

        check('or_averitec_train_1752', f'Completed {actual}, due {due}', expected, predict)

    hospital = restore(programs['shared_noun_1'])
    modifiers = [a for a in hospital.atoms if a.predicate == 'property'
                 and a.arguments[2] in {'public','private'}]
    assert len(modifiers) == 2 and modifiers[0].arguments[0] == modifiers[1].arguments[0]
    for a, b, expected in (('supported','refuted','supported'),('refuted','supported','supported'),
                           ('refuted','refuted','refuted'),('unknown','refuted','unknown')):
        states = {'public':a,'private':b}
        check('shared_noun_1', f'Public {a}, private {b}', expected,
              lambda atom: states.get(atom.arguments[2], 'supported') if atom.predicate=='property' else 'supported')

    dump(RUN / 'native.json', results)
    print(f'{len(results)} exact comparisons on the repaired programs.')


if __name__ == '__main__':
    evaluate()
    evaluated = read(RUN/'transcripts/evaluation.json')['cases']['prior']
    for segment in evaluated:
        for case in segment['cases']:
            case['predictions']['directional_nli'] = case['after']
    inference(folder=PRIOR/'transcripts', compiled=RUN/'transcript_prior_after.json',
              output_path=RUN/'transcripts/inference.json', evaluated=evaluated, method='directional_nli')
