"""Bundle both sets of annotations, exact output traces, and current source."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from or_followup_report import URL
from prepare_or_followup import PRIOR, ROOT, RUN
from prepare_or_source_evaluation import read

REPLAY = ('controlled_after.json', 'fresh_after.json', 'prior_after.json', 'transcript_prior_after.json',
          'native.json', 'transcripts/evaluation.json', 'transcripts/inference.json', 'evaluation.json')


def main():
    paths = [ROOT / name for name in ('requirements-compilation.txt','requirements-verification.txt',
                                     'tests/test_coordination.py','tests/test_transcript_or.py')]
    paths.extend(RUN / name for name in ('amr.jsonl','amr_inputs.jsonl','stopping_criteria.json',
                                         'controlled_before.json','fresh_before.json','tests.xml',*REPLAY))
    for group in ('controlled','fresh'):
        paths.extend(p for p in (RUN / group).iterdir() if p.is_file() and p.name!='baseline_srl.json')
    paths.extend(RUN / 'transcripts' / name for name in ('segments.json','segments.sha256','scores.json'))
    paths.extend(PRIOR / name for name in ('source/minilm-nli/snapshot.json','fresh/compiled.json',
                                           'transcripts/evaluation.json','transcripts/nli_scores.json'))
    for group in ('fresh','transcripts'):
        paths.extend(PRIOR / group / name for name in ('amr.jsonl','parsed.jsonl','claims.json','dependency_provenance.json'))
    old_bundle = ROOT / 'site/reports/compiler-demos/or-source-evaluation-20261119/source.zip'
    with ZipFile(old_bundle) as earlier:
        paths.extend(ROOT / name for name in earlier.namelist() if name.startswith('scripts/'))
    for name in ('prepare_or_followup','select_fresh_or_followup','evaluate_or_followup_compilation',
                 'check_or_followup_inference','collect_ami_implicit_alternatives','freeze_implicit_alternative_cases',
                 'evaluate_implicit_alternatives','or_followup_report','package_or_followup','probabilistic_verification/coordination'):
        paths.append(ROOT/'scripts'/(name+'.py'))

    data = {str(p.relative_to(ROOT)): p.read_bytes() for p in paths}
    hashes = read(RUN/'corpus_program_hashes.json')
    for name, folder in (('before',PRIOR.with_name('disjunction_scope_20261119')),('after',RUN/'full-final')):
        records = (dict(claim_id=cid, selected_stage=stage, output=dict(program_sha256=digest) if digest else None)
                   for cid,(stage,digest) in hashes[name].items())
        key = str((folder/'corpus.jsonl').relative_to(ROOT))
        data[key] = ''.join(json.dumps(r)+'\n' for r in records).encode()

    data['README.md'] = (ROOT/'docs/or_followup_20261119.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({name:sha256((RUN/name).read_bytes()).hexdigest()
                                             for name in REPLAY},indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(target,'w',compression=ZIP_DEFLATED) as archive:
        for name,contents in sorted(data.items()):
            member = ZipInfo(name,date_time=(2026,11,19,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member,contents)
    print(f'Bundled {len(data)} files for offline replay.')


if __name__ == '__main__':
    main()
