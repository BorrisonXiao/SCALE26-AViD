"""Assemble the annotated binding and automatic-window results."""
from collections import Counter
from html import escape
from shutil import copy2
import xml.etree.ElementTree as ET

from compiler_fallback_report import table
from prepare_ami_speaker_binding import PRIOR_RUN, RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import ROOT, read

URL = 'compiler-demos/ami-speaker-binding-20261126/'
BINDING = {'pool':'Pool alternatives across speakers', 'speaker':'Pool alternatives for one speaker',
           'utterance':'Check one speaker and one utterance'}
CONTROLS = {'annotated':'Original speaker and utterance','wrong_speaker':'Change the speaker label',
            'earlier_time':'Query an earlier interval','split_speakers':'Split the alternatives across speakers',
            'split_utterances':'Split the alternatives across utterances'}
AUDIO = {
    'pyannote_strict_all':'Pyannote with the original word assignment',
    'pyannote_ranked_1':'Pyannote with up to one candidate',
    'pyannote_ranked_3':'Pyannote with up to three candidates',
    'reverb_strict_all':'Reverb with the original word assignment',
    'reverb_ranked_1':'Reverb with up to one candidate',
    'reverb_ranked_3':'Reverb with up to three candidates',
}
STATUS = {'evaluated':'Scope and speaker role preserved', 'parse_abstention':'No compiled program',
          'speech_scope_missing':'Program missing the full reported disjunction',
          'speaker_role_missing':'Program missing the reporting speaker role'}


def summarize():
    binding = read(RUN/'binding_evaluation.json')
    inference = read(RUN/'binding_inference.json')
    audio = read(RUN/'alignment_evaluation.json')
    counts = Counter(r['status'] for r in inference)
    count = len(binding['cases'])
    assert len(inference)==len(audio['rows'])==count
    assert audio['counts']['pyannote_strict_all']['correct_speaker_support']==read(
        PRIOR_RUN/'speech_evaluation.json')['counts']['correct_speaker']['speakers']
    source = {r['meeting']:{w['word_id']:w['speaker'] for w in r['clip_words']}
              for r in read(PRIOR_RUN/'speech_cases.json')}
    # Attribute competing words only for the audit, after all predictions
    # have been made using word times and the earlier enrollment span.
    for row in audio['rows']:
        transcript_speakers = source[row['meeting']]
        for control in row['variants']:
            for prediction in control['predictions'].values():
                for window in prediction['matching']:
                    actual = Counter(transcript_speakers[w] for w in window['word_ids'])
                    window['annotated_word_speakers'] = dict(actual)
    comparison_count = sum(len(r['cases']) for r in binding['cases'])
    suite = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(k,0))==0 for k in ('failures','errors','skipped'))
    tests = int(suite.get('tests'))
    coverage = {}
    for model in ('pyannote', 'reverb'):
        fractions = [r['methods'][model]['max_named_window_coverage'] for r in audio['rows']]
        coverage[model] = dict(no_words=fractions.count(0), all_words=fractions.count(1))
    summary = dict(meetings=count, binding_comparisons=comparison_count,
                   binding=binding['counts'], compiler=counts,
                   inference_checks=sum(len(r['results']) for r in inference),
                   audio=audio['counts'], window_coverage=coverage, tests=tests)
    dump(RUN/'evaluation.json',dict(summary=summary,binding=binding['cases'],
                                    inference=inference,audio=audio['rows']))
    print(summary)


def status_html():
    return ('<b>Annotated speaker and utterance binding passes all 40 comparisons.</b> '
            'The automatic window comparison recovers two of eight correct-speaker queries '
            'with up to three Pyannote candidates, and one of eight with Reverb.')


def overview_html():
    summary = read(RUN/'evaluation.json')['summary']
    binding, audio, coverage = summary['binding'], summary['audio'], summary['window_coverage']
    denominator = summary['binding_comparisons']-summary['meetings']
    return (
        '<h2 id="remaining-failures">Speaker binding and multiple candidate windows</h2>'
        '<p>Both alternatives in a reported disjunction must belong to the requested speaker and '
        'the same utterance. The eight original AMI utterances and 32 controls use the same words. '
        'The controls change the speaker label, the query time, or which speaker or utterance supplies each alternative.</p>'
        +table('Verdicts on eight annotated utterances and 32 controls.',
               ['Evidence check','Correct-speaker support','False support','Expected verdicts matched'],
               [(label,f'{binding[k]["support"]}/8',f'{binding[k]["false_support"]}/{denominator}',
                  f'{binding[k]["correct"]}/{summary["binding_comparisons"]}') for k,label in BINDING.items()])
        +'<p>Binding both alternatives to one speaker still permits pooling over separate utterances. '
        'Requiring one utterance resolves that control. Of the eight indirect claims, three '
        'compile to programs that bind the speaker and the full report. Four have no program, and '
        'one program leaves the alternatives inside an opaque phrase. '
        f'The three usable programs pass {summary["inference_checks"]} exact DeepProbLog checks with '
        f'the remaining observations fixed. All {summary["tests"]} project tests passed.</p>'
        '<h3>Automatic speaker windows</h3>'
        '<p>The same distant microphone and manually transcribed word times are used for both '
        'diarizers. For overlapping predictions, a candidate needs a content word from each alternative '
        'that belongs to a single estimated speaker. The candidate text is checked as one utterance.</p>'
        +table('Support counts on the same eight meetings. Wrong-speaker and earlier-time queries should stay unknown.',
               ['Window source','Correct speaker','Wrong speaker','Earlier time','Windows checked'],
               [(label,*(f'{audio[k][field]}/8' for field in ('correct_speaker_support','wrong_speaker_support','earlier_time_support')),
                 audio[k]['windows_checked']) for k,label in AUDIO.items()])
        +'<p>The additional Pyannote match has words from overlapping speakers. Reverb recovered no additional '
        f'cases. Before checking text, {coverage["pyannote"]["no_words"]} of eight Pyannote queries and '
        f'{coverage["reverb"]["no_words"]} of eight Reverb queries had no target words in any window '
        'assigned to the requested speaker. Supplying the participant count and allowing several clusters to match one enrolled '
        'speaker yielded the same support counts. The new comparison uses a small annotated diagnostic '
        'with earlier labeled speech to name the anonymous clusters.</p>'
        '<p><a href="#ami-binding-controls">Annotated binding controls and compiled programs</a> · '
        '<a href="#ami-candidate-windows">Candidate windows and competing words</a> · '
        '<a href="#earlier-scope-alignment">Earlier speaker alignment</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}evaluation.json">Exact results</a> · <a href="{URL}source.zip">Source and replay</a> · '
        f'<a href="{URL}tests.xml">Tests</a></p>'
    )


def examples_html():
    result = read(RUN/'evaluation.json')
    native = {r['claim_id']:r for r in result['inference']}
    output = ['<section id="ami-binding-controls"><h2>Binding with annotated speaker windows</h2>']
    for row in result['binding']:
        c = native[row['claim_id']]
        details = table('Each control uses the same words, with a recorded speaker and utterance assignment.',
                        ['Control','Expected',*BINDING.values()],
                        [(CONTROLS[e['name']],e['expected'],*(e['verdicts'][k] for k in BINDING))
                         for e in row['cases']])
        if c['status']=='evaluated':
            details += (f'<h4>Speaker role</h4><pre>{escape(c["speaker_predicate"])}</pre>'
                        f'<h4>Full reported content</h4><pre>{escape(c["report_predicate"])}</pre>'
                        f'<h4>Logical form</h4><pre>{escape(c["logical_form"])}</pre>')
            details += table('Exact inference with the reporting speaker and utterance candidates.',
                             ['Control','Speaker candidates','Utterance candidates','Verdict'],
                             [(CONTROLS[e['case']],escape(', '.join(e['speaker_candidates'])),
                               len(e['utterance_candidates']),max(e['distribution'],key=e['distribution'].get))
                              for e in c['results']])
        else:
            details += '<ul>'+''.join(
                f'<li>{escape(a["stage"])} · {escape(a["status"])}'
                +(f' · {escape(a["reason"])}' if a.get('reason') else '')+'</li>'
                for a in c['attempts'])+'</ul>'
        output.extend((f'<article class="box benchmark-case" id="binding-control-{escape(row["meeting"])}">'
                       f'<h3>{escape(row["meeting"])}</h3><blockquote>{escape(row["text"])}</blockquote>'
                       f'<p>{escape(c["text"])} <strong>{STATUS[c["status"]]}</strong></p>',
                       '<details><summary>Controls and compiler evidence</summary>',details,'</details></article>'))
    output.append('</section><section id="ami-candidate-windows"><h2>Automatic candidate windows</h2>'
                  '<p>Each case shows the recorded utterance and the highest-ranked windows. '
                  'Word-level annotations are used to show contamination after scoring.</p>')
    for row in result['audio']:
        output.append(f'<article class="box benchmark-case" id="ami-window-{escape(row["meeting"])}">'
                      f'<h3>{escape(row["meeting"])}</h3><blockquote>{escape(row["target"])}</blockquote>')
        control = row['variants'][0]
        coverage = [row['methods'][model]['max_named_window_coverage'] for model in ('pyannote','reverb')]
        output.append('<p>Target transcript words in the best window assigned to the requested speaker. '
                      f'Pyannote {coverage[0]:.0%}. Reverb {coverage[1]:.0%}.</p>')
        listings = []
        for key in ('pyannote_ranked_3','reverb_ranked_3'):
            prediction = control['predictions'][key]
            hit = {tuple(w['word_ids']):w for w in prediction['matching']}
            for i,w in enumerate(prediction['candidates'],1):
                match = hit.get(tuple(w['word_ids']))
                actual = ', '.join(f'{s} {n}' for s,n in sorted(match['annotated_word_speakers'].items())) if match else '—'
                listings.append((AUDIO[key].split(' with')[0],i,f'{w["start"]:.2f}–{w["end"]:.2f}',
                                 escape(w['text']), 'Supported' if match else 'Unknown',actual))
        output.append('<p>No ranked windows were assigned to the requested speaker.</p>' if not listings else
                      table('Candidate text and source-speaker word counts for matching windows.',
                            ['Diarizer','Rank','Seconds','Text','Verdict','Annotated speaker word counts'],listings))
        output.append('</article>')
    output.append('<p>AMI audio and transcript excerpts, © University of Edinburgh and partners under CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a> · '
                  '<a href="https://arxiv.org/abs/2410.03930">Reverb research paper</a>.</p></section>')
    return ''.join(output)


def write_downloads():
    target = ROOT/'site/reports'/URL
    target.mkdir(parents=True,exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,target/name)


if __name__=='__main__':
    summarize()
