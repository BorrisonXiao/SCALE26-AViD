"""Calibrate a frozen NLI score using only separate AMI meeting series."""
import argparse
from collections import Counter

import numpy as np
from scipy.optimize import minimize
from scipy.special import expit, logit

from evaluate_ami_speech_scoring import MODELS
from evaluate_reported_or_transcripts import score_pairs
from prepare_ami_window_comparison import RUN, frozen_cases
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read


def probabilities(path):
    return {(r['premise'],r['hypothesis']):r['probabilities'] for r in read(path)['scores']}


def score():
    pairs = {(row['text'],c['content']) for row in frozen_cases() for c in row['variants']}
    dump(RUN/'claim_scores.json',score_pairs(pairs,MODELS['deberta']))
    print('Scored',len(pairs),'annotated transcript and claim pairs.',flush=True)


def log_odds(probability):
    # Frozen softmax outputs may round to zero or one.
    return logit(np.clip(probability,1e-12,1-1e-12))


def fit(examples):
    """Fit a logistic map of the entailment log-odds, with nonnegative slope."""
    x = log_odds([c['scores']['entailment'] for c in examples])
    y = np.array([c['expected_support'] for c in examples], dtype=float)

    def objective(parameters):
        slope, intercept = parameters
        z = slope*x + intercept
        residual = expit(z)-y
        return (np.sum(np.logaddexp(0,z)-y*z)+0.5*slope**2,
                np.array([np.dot(residual,x)+slope, np.sum(residual)]))

    result = minimize(objective,(1.0,0.0),jac=True,bounds=[(0,None),(None,None)],method='L-BFGS-B')
    assert result.success and np.all(np.isfinite(result.x)), result.message
    slope, intercept = map(float,result.x)
    return dict(slope=slope,intercept=intercept,l2_slope_penalty=1.0)


def calibrated(score, model):
    return float(expit(model['slope'] * log_odds(score) + model['intercept']))


def evaluate():
    scores = probabilities(RUN/'claim_scores.json')
    rows = frozen_cases()
    splits = {s:{r['series'] for r in rows if r['split']==s} for s in ('calibration','test')}
    assert splits['calibration'].isdisjoint(splits['test'])
    for row in rows:
        for c in row['variants']:
            c['scores'] = scores[row['text'],c['content']]
    model = fit([c for row in rows if row['split']=='calibration' for c in row['variants']])
    methods = ('original_argmax','raw_half','calibrated_half')
    summary = {s:{m:Counter() for m in methods} for s in splits}
    ranking = {s:Counter() for s in splits}
    for row in rows:
        pos = next(c['scores']['entailment'] for c in row['variants'] if c['variant']=='paraphrase')
        for c in row['variants']:
            p = c['scores']['entailment']
            c['calibrated'] = calibrated(p,model)
            c['decisions'] = dict(zip(methods,(max(c['scores'],key=c['scores'].get)=='entailment',p>=0.5,
                                               c['calibrated']>=0.5)))
            yes = c['expected_support']
            if not yes:
                ranking[row['split']]['matches'] += pos>p
                ranking[row['split']]['total'] += 1
            for m, pred in c['decisions'].items():
                counter = summary[row['split']][m]
                probability = c['calibrated'] if m=='calibrated_half' else p
                counter['total'] += 1
                counter['correct'] += yes==pred
                counter['false_support'] += pred and not yes
                counter['missed_support'] += yes and not pred
                counter['supported_total'] += yes
                counter['unsupported_total'] += not yes
                counter['squared_error'] += (probability-yes)**2
    for group in summary.values():
        for result in group.values():
            result['brier'] = result.pop('squared_error') / result['total']
    for row in rows:
        row.pop('clip_words')
        row.pop('words')
    result = dict(model=model,summary=summary,ranking=ranking,rows=rows)
    dump(RUN/'calibration_evaluation.json',result)
    print(model,summary,ranking,flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage', choices=('score','evaluate'))
    {'score':score,'evaluate':evaluate}[p.parse_args().stage]()
