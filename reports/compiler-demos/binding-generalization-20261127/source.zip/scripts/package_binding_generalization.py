"""Package the cached implicit speech and visual assignment experiments."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from binding_generalization_report import URL
from prepare_ami_window_comparison import RUN as CALIBRATION
from prepare_compiler_fallback import ROOT
from score_visual_assignments import RUN

REPLAY = ('speech_evaluation.json','visual_evaluation.json','visual_program.pl','evaluation.json')


def main():
    paths = [ROOT/name for name in ('requirements-compilation.txt','requirements-verification.txt','tests/test_visual_assignments.py')]
    paths.extend(RUN/name for name in (*REPLAY,'implicit_cases.json','implicit_scores.json',
                                      'visual_inputs.json','visual_scores.json','tests.xml'))
    paths.append(CALIBRATION/'calibration_evaluation.json')
    with ZipFile(ROOT/'site/reports/compiler-demos/ami-probabilistic-binding-20261126/source.zip') as prior:
        paths.extend(ROOT/name for name in prior.namelist() if name.startswith('scripts/'))
    paths.extend(ROOT/'scripts'/(name+'.py') for name in (
        'evaluate_ami_implicit_binding','score_visual_assignments','evaluate_visual_assignments',
        'binding_generalization_report','package_binding_generalization'))
    data = {str(path.relative_to(ROOT)):path.read_bytes() for path in paths}
    data['README.md'] = (ROOT/'docs/binding_generalization_20261127.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({
        name:sha256((RUN/name).read_bytes()).hexdigest() for name in REPLAY
    }, indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(target,'w') as archive:
        for name, contents in sorted(data.items()):
            member = ZipInfo(name,date_time=(2026,11,27,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member,contents)
    print(f'Archived {len(data)} files for offline replay.')


if __name__=='__main__':
    main()
