"""Compare frozen transcript scorers on the same annotated speaker windows."""
import argparse
from collections import Counter
from hashlib import sha256
from itertools import chain, product

from check_ami_speaker_binding import reporter
from evaluate_reported_or_transcripts import score_pairs
from prepare_ami_speech_verification import RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import RUN as NLI_RUN, read
from probabilistic_verification.compiler_fallback import restore
from probabilistic_verification.transcript_or import implicit_splits, judge, normalize, splits

MODELS = {'minilm': NLI_RUN / 'source/minilm-nli', 'deberta': RUN / 'models/deberta'}
METHODS = ('exact', 'minilm_whole', 'minilm_branches', 'deberta_whole', 'deberta_branches')


def cases():
    path = RUN/'cases.json'
    assert sha256(path.read_bytes()).hexdigest() == (RUN/'cases.sha256').read_text().strip()
    return read(path)['rows']


def score():
    pairs = set()
    for row in cases():
        evidence = row['evidence']['text']
        spans = {evidence}
        for pair in chain(splits(evidence, 'or'), splits(evidence, 'and'), implicit_splits(evidence)):
            spans.update(pair)
        for case in row['variants']:
            target = case['content']
            alternatives, = splits(target, 'or')
            pairs.add((evidence, target))
            for a, b in product(spans, alternatives):
                if normalize(a) != normalize(b):
                    pairs.update(((a,b), (b,a)))
    for name, folder in MODELS.items():
        dump(RUN/f'{name}_scores.json', score_pairs(pairs, folder))
        print(name, len(pairs), 'text pairs', flush=True)


def compilation(row, speaker):
    fixed = row['fixed']
    result = dict(stage=fixed['selected_stage'], statuses=[
        {k:v for k,v in attempt.items() if k in {'stage','status','reason'}} for attempt in fixed['attempts']])
    if not fixed['output']:
        return dict(result, state='abstained')
    compiled = restore(fixed['output']['compilation'])
    reports = [a for a in compiled.atoms if a.predicate=='reported_disjunction'
               and normalize(a.arguments[2]).removeprefix('that ')==normalize(row['content'])]
    if len(reports) != 1:
        return dict(result, state='missing_report', form=fixed['output']['compilation']['logical_form'])
    report, = reports
    identity = {('referent', normalize(f'Participant {speaker}')), ('name', normalize(speaker))}
    speaker_ids = {a.arguments[0] for a in compiled.atoms if len(a.arguments)>=2 and
                   (a.predicate,normalize(a.arguments[1])) in identity}
    speakers = [a for a in compiled.atoms if reporter(a, report.arguments[0]) in speaker_ids]
    if len(speakers) != 1:
        return dict(result, state='missing_speaker', form=fixed['output']['compilation']['logical_form'])
    return dict(result, state='usable', report=report.display(), speaker=speakers[0].display(),
                form=fixed['output']['compilation']['logical_form'])


def evaluate():
    scores = {name: {(r['premise'], r['hypothesis']): r['probabilities']
                     for r in read(RUN/f'{name}_scores.json')['scores']} for name in MODELS}
    compiled = {r['claim_id']: r for r in read(RUN/'compiled.json')}
    records = cases()
    totals = {method: Counter() for method in METHODS}
    by_variant = {method: Counter() for method in METHODS}
    for row in records:
        evidence, query = row['evidence'], row['query']
        assert evidence['speaker']==query['speaker'] and evidence['start']>=query['start']
        assert evidence['end']<=query['end']
        for case in row['variants']:
            target = case['content']
            window = dict(evidence, target=target)
            result = {'exact':judge(query, window)=='supported'}
            whole_scores = {}
            for model, cache in scores.items():
                probs = cache[evidence['text'], target]
                whole_scores[model] = probs
                result[f'{model}_whole'] = max(probs, key=probs.get)=='entailment'

                def entail(a, b):
                    return cache[a, b]['entailment']

                def contradict(a, b):
                    return cache[a, b]['contradiction']

                result[f'{model}_branches'] = judge(query, window, entail, allow_implicit=True,
                                                    contradiction=contradict)=='supported'
            for method, supported in result.items():
                expected = case['expected_support']
                totals[method]['matches'] += supported==expected
                totals[method]['false_support'] += supported and not expected
                totals[method]['missed_support'] += expected and not supported
                by_variant[method][case['variant']] += supported==expected
            case.update(predictions=result, whole_scores=whole_scores,
                        compiler=compilation(compiled[case['claim_id']], query['speaker']))
    scored = [c for row in records for c in row['variants']]
    assert compiled.keys() == {c['claim_id'] for c in scored}
    ranking = {m:Counter() for m in MODELS}
    for row in records:
        paraphrase, = (c for c in row['variants'] if c['variant']=='paraphrase')
        for case in row['variants']:
            if case['expected_support']:
                continue
            for model in MODELS:
                ranking[model][case['variant']] += (
                    paraphrase['whole_scores'][model]['entailment'] > case['whole_scores'][model]['entailment'])
    summary = dict(total=len(scored), compiler=Counter(c['compiler']['state'] for c in scored),
                   results=totals, by_variant=by_variant, paired_ranking=ranking)
    dump(RUN/'scoring_evaluation.json', dict(summary=summary, rows=records))
    print(summary, flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage', choices=('score', 'evaluate'))
    {'score':score, 'evaluate':evaluate}[p.parse_args().stage]()
