"""Download short AMI audio clips and run the existing CPU diarizer."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import time

from prepare_ami_window_comparison import RUN, frozen_cases
from prepare_compiler_fallback import dump
import run_ami_diarization as audio


def download(case):
    for attempt in range(4):
        try:
            result = audio.download(case)
        except (OSError, ValueError) as error:
            if attempt==3:
                raise
            print(case['meeting'], 'audio retry', error, flush=True)
            time.sleep(2**attempt)
        else:
            print(case['meeting'], 'audio available', flush=True)
            return result


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage', choices=('download','diarize'))
    audio.RUN = RUN
    cases = frozen_cases()
    if p.parse_args().stage=='download':
        (RUN/'audio').mkdir(parents=True, exist_ok=True)
        with ThreadPoolExecutor(max_workers=6) as pool:
            dump(RUN/'audio/manifest.json',list(pool.map(download,cases)))
    else:
        audio.diarize(cases)
