"""Evaluate alternative reports without the word “or” in the focal evidence."""
import argparse
from collections import Counter
from hashlib import sha256
from math import isclose
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from calibrate_ami_speech_scores import calibrated, probabilities
from collect_ami_or_candidates import NITE_ID, aligned_words
from evaluate_ami_probabilistic_binding import grounded_case, has_alternatives, expected_support_probability, SCALES
from evaluate_ami_speech_scoring import MODELS
from evaluate_reported_or_transcripts import score_pairs
from prepare_ami_probabilistic_binding import utterance, overlaps
from prepare_ami_window_comparison import RUN as CALIBRATION, series
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import RUN as SOURCE, read
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.ordered_circuit import OrderedSolver
from score_visual_assignments import RUN

METHODS = ('separate_without_cue','shared_without_cue','shared_witness')
# Segment IDs and case reference readings were fixed before scoring. The cut
# identifies the second alternative in the original words for a speaker-swap control.
CHOICES = (
    (['IS1002c.sync.463','IS1002c.sync.465','IS1002c.sync.467'], None, 'Yeah. Well',
     'The scroll wheel is another way to do the same things as the buttons.', ('scroll wheel','voice recognition')),
    (['TS3009d.sync.293'], None, 'We can also',
     'A single curve was one design and making it flat is another option.', ('making it flat','making it hexagonal')),
    (['TS3009c.sync.621','TS3009c.sync.622'], None, 'um we can also',
     'We could show screen width and general settings on the LCD instead of adding more buttons.', ('on the LCD','on a paper insert')),
    (['IS1004c.sync.516','IS1004c.sync.518','IS1004c.sync.520'], None, 'And I mean you could also',
     'We could use grainy varnished wood or use a thin wood veneer for the outside.', ('wood veneer','metal veneer')),
    (['TS3005d.sync.118'], None, 'but you can also',
     'We had considered solid colors and a wood-like finish is another possibility.', ('wood-like','marble-like')),
    (['IN1016.sync.350'], 'Some of them', 'And then there are',
     'One approach extracts features within a single meeting, and another uses the corpus to find connections across meetings.',
     ('connections across meetings','changes within the same room')),
    (['IN1008.sync.1,527'], None, 'You can also do microphone arrays',
     'We could consider a directional microphone aimed in one direction or an array of directional microphones.',
     ('an array of directional microphones','a single omnidirectional microphone')),
    (['TS3010d.sync.937','TS3010d.sync.939'], None, 'Uh, maybe it',
     'Using a smaller monitor and a normal mouse might be easier than having the laptops in front of us.',
     ('a normal mouse','a touchscreen')),
)
NEGATIVES = (
    (['TS3005b.sync.1383'],'We can implement either audio or screen settings as submenus, but we should implement only one.'),
    (['TS3010b.sync.458','TS3010b.sync.459'],'We can use plastic or add a TV menu button, but we should choose only one.'),
    (['IB4003.sync.424'],'To give people privacy, we could split a two-person room or convert an unused meeting room into an office.'),
    (['TS3005a.sync.38'],'For the exercise we can change either the pen color or the line width, but we cannot change both.'),
)


def segments(archive,meeting):
    rows = {}
    for name in sorted(n for n in archive.namelist() if n.startswith(f'segments/{meeting}.') and n.endswith('.segments.xml')):
        speaker = name.split('.')[1]
        tokens = list(ET.fromstring(archive.read(f'words/{meeting}.{speaker}.words.xml')))
        positions = {token.get(NITE_ID):i for i,token in enumerate(tokens)}
        for seg in ET.fromstring(archive.read(name)):
            words = aligned_words(seg,tokens,positions)
            if words:
                rows[seg.get(NITE_ID)] = (speaker,words)
    return rows


def phrase_index(words, phrase):
    texts = [w['text'].casefold() for w in words]
    tokens = re.findall(r'\w+|[^\w\s]',phrase.casefold())
    idx, = (i for i,t in enumerate(texts) if texts[i:i+len(tokens)]==tokens)
    return idx


def freeze():
    known = read(CALIBRATION/'source.json')
    used = set(known['prior_series']+known['calibration']+known['test'])
    source = SOURCE/'source/ami_public_manual_1.6.2.zip'
    rows = []
    with ZipFile(source) as archive:
        for entry in CHOICES+NEGATIVES:
            ids = entry[0]
            meeting = ids[0].split('.')[0]
            assert all(i.split('.')[0]==meeting for i in ids) and series(meeting) not in used
            s = segments(archive,meeting)
            speaker = s[ids[0]][0]
            assert all(s[i][0]==speaker for i in ids)
            words = [w for i in ids for w in s[i][1]]
            positive = len(entry)>2
            if positive:
                _,start,cut,target,(old,new) = entry
                if start:
                    words = words[phrase_index(words,start):]
            else:
                target = entry[1]
            assert all(w['text'].casefold()!='or' for w in words), ids
            identifier = ids[-1]
            focal = utterance(words,speaker,identifier)
            q = dict(speaker=speaker,start=focal['start']-2,end=focal['end']+2)
            others = [utterance(w,who,k) for k,(who,w) in s.items() if who!=speaker and len(w)>=5]
            close = [w for w in others if overlaps(w,q)]
            best = min(close or others,key=lambda w:abs(w['start']-focal['start']))
            distractors = [best] if close else []
            windows = sorted([focal,*distractors],key=lambda w:(w['start'],w['id']))
            variants = [('faithful' if positive else 'additive_or_one_option',target,q,windows,positive)]
            if positive:
                boundary = phrase_index(words,cut)
                assert target.count(old)==1 and 0<boundary<len(words)
                split = [utterance(words[:boundary],speaker,identifier+':first'),
                         utterance(words[boundary:],best['speaker'],identifier+':second'),*distractors]
                variants.extend((('changed_option',target.replace(old,new),q,windows,False),
                                 ('wrong_speaker',target,dict(q,speaker=best['speaker']),windows,False),
                                 ('split_speakers',target,q,sorted(split,key=lambda w:(w['start'],w['id'])),False)))
            cases = [dict(id=f'{identifier}:{v}',variant=v,content=text,query=query,windows=w,expected_support=yes)
                     for v,text,query,w,yes in variants]
            rows.append(dict(meeting=meeting,source=ids,focal=focal,cases=cases))
    dump(RUN/'implicit_cases.json',dict(annotation_sha256=sha256(source.read_bytes()).hexdigest(),rows=rows))
    print(len(rows),'new reports and controls from',len({r['meeting'] for r in rows}),'meetings',flush=True)


def score():
    pairs = {(w['text'],c['content']) for r in read(RUN/'implicit_cases.json')['rows'] for c in r['cases'] for w in c['windows']}
    dump(RUN/'implicit_scores.json',score_pairs(pairs,MODELS['deberta']))


def evaluate():
    source = read(RUN/'implicit_cases.json')
    cached = probabilities(RUN/'implicit_scores.json')
    model = read(CALIBRATION/'calibration_evaluation.json')['model']
    results = {s:{m:Counter() for m in METHODS} for s in SCALES}
    programs = []
    all_cases = [c for row in source['rows'] for c in row['cases']]
    for case in all_cases:
        query = case['query']
        for w in case['windows']:
            p = cached[w['text'],case['content']]['entailment']
            w['probability'] = dict(raw=p,calibrated=calibrated(p,model))
            w['checks'] = dict(speaker=w['speaker']==query['speaker'],time=overlaps(w,query),cue=has_alternatives(w['text']))
        for s in SCALES:
            programs.extend(grounded_case(case,m,s) for m in METHODS)
    exact = DirectVerifier(programs,learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver)
    distributions = {r['claim_id']:r['distribution'] for r in exact.predict()}
    for case in all_cases:
        case['results'] = {}
        for s in SCALES:
            outcomes = {}
            for m in METHODS:
                d = distributions[f'{case["id"]}:{s}:{m}']
                assert isclose(d['supported'],expected_support_probability(case['windows'],m,s),abs_tol=1e-10)
                yes = d['supported']>=0.5
                n = results[s][m]
                n['correct'] += yes==case['expected_support']
                n['supported'] += yes and case['expected_support']
                n['false_support'] += yes and not case['expected_support']
                n[case['variant']+'_errors'] += yes!=case['expected_support']
                outcomes[m] = d['supported']
            case['results'][s] = outcomes
    dump(RUN/'speech_evaluation.json',dict(source,summary=results,total=len(all_cases),native=len(distributions)))
    print(results,flush=True)


if __name__=='__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage',choices=('freeze','score','evaluate'))
    {'freeze':freeze,'score':score,'evaluate':evaluate}[p.parse_args().stage]()
