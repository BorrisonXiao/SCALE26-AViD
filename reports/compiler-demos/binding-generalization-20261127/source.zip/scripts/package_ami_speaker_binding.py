"""Package the cached AMI speaker binding experiment for offline replay."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from ami_speaker_binding_report import URL
from prepare_ami_speaker_binding import PRIOR_RUN, RUN
from prepare_or_source_evaluation import ROOT

REPLAY = (
    'compiled.json', 'binding_evaluation.json', 'alignment_inputs.json',
    'alignment_evaluation.json', 'binding_inference.json', 'evaluation.json',
)


def main():
    paths = [ROOT / name for name in (
        'requirements-compilation.txt', 'requirements-verification.txt',
        'tests/test_ami_speaker_binding.py',
    )]
    paths.extend(RUN / name for name in (
        'binding_cases.json', 'reverb.json', 'reverb_roster.json',
        'alignment_scores.json', 'tests.xml', *REPLAY,
    ))
    paths.extend(p for p in (RUN / 'compiler').iterdir() if p.is_file())
    paths.extend(PRIOR_RUN / name for name in (
        'speech_cases.json', 'speech_cases.sha256', 'speech_inputs.json',
        'speech_evaluation.json', 'diarization.json', 'diarization_roster.json',
        'roster.json', 'audio/manifest.json',
    ))
    with ZipFile(ROOT / 'site/reports/compiler-demos/scope-and-alignment-20261119/source.zip') as prior:
        paths.extend(ROOT / name for name in prior.namelist() if name.startswith('scripts/'))
    paths.extend(ROOT / 'scripts' / (name + '.py') for name in (
        'prepare_ami_speaker_binding', 'evaluate_ami_speaker_binding',
        'check_ami_speaker_binding', 'ami_speaker_binding_report', 'package_ami_speaker_binding',
    ))
    data = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    data['README.md'] = (ROOT / 'docs/ami_speaker_binding_20261126.md').read_bytes()
    data['REPLAY_SHA256.json'] = json.dumps({
        name: sha256((RUN / name).read_bytes()).hexdigest() for name in REPLAY
    }, indent=2).encode()
    target = ROOT / 'site/reports' / URL / 'source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(target, 'w') as archive:
        for name, payload in sorted(data.items()):
            member = ZipInfo(name, date_time=(2026, 11, 26, 0, 0, 0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, payload)
    print(f'Archived {len(data)} files for offline replay.')


if __name__ == '__main__':
    main()
