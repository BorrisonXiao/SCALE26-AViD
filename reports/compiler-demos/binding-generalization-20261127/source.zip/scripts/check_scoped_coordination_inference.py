"""Exercise the repaired scope under controlled evidence with exact inference."""
import itertools

from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from prepare_scope_alignment import RUN
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.compiler_fallback import restore
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.ordered_circuit import OrderedSolver
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.representation import STATES


def main():
    compiled={r['claim_id']:r['fixed']['output'] for r in read(RUN/'after.json')}
    results=[]

    def run(cid, description, expected, choose, missing=False):
        claim=restore(compiled[cid]['compilation'])
        domains={v.name:[f'candidate:{v.name}'] for v in claim.variables}
        complete=dict.fromkeys(domains,True)
        relevant={a.arguments[2] for a in claim.atoms if a.predicate=='adjunct' and a.arguments[3]=='with'}
        if missing:
            for target in relevant:
                domains[target]=[]
                complete[target]=False
        evidence=Evidence('scope-control',domains,complete,{})
        assignment={v:values[0] for v,values in domains.items() if values}
        for atom in claim.atoms:
            key=canonical_key(evidence.media_id,atom,assignment,evidence.route)
            state=choose(atom)
            evidence.observations[key]=Observation(key,tuple(float(s==state) for s in STATES),False,atom.text)
        grounded=ground(claim,evidence)
        exact=DirectVerifier([grounded],learned=False,program_builder=compact_prolog_program,solver_class=OrderedSolver).predict()[0]
        distribution=exact['distribution']
        assert distribution[expected]>1-1e-10,(cid,description,distribution)
        results.append(dict(claim_id=cid,description=description,expected=expected,distribution=distribution))

    cid='absence_1'
    claim=restore(compiled[cid]['compilation'])
    refs={a.arguments[0]:a.arguments[1] for a in claim.atoms if a.predicate=='referent'}
    for coat,umbrella in itertools.product(('supported','refuted'),repeat=2):
        values={'coat':coat,'umbrella':umbrella}
        state='supported' if coat==umbrella=='refuted' else 'refuted'
        run(cid,f'Coat relation {coat} and umbrella relation {umbrella}',state,
            lambda atom: values[refs[atom.arguments[2]]] if atom.predicate=='adjunct' else 'supported')
    run(cid,'Incomplete item inventory','unknown',lambda atom:'supported',missing=True)
    run(cid,'Leaving is refuted','refuted',
        lambda atom:'refuted' if atom.predicate in {'leave','adjunct'} else 'supported')

    for cid in ('rule_1','rule_4','averitec_train_2288'):
        run(cid,'Requirement and consequence both supported','supported',lambda atom:'supported')
        run(cid,'Only the consequence supported','refuted',
            lambda atom:'refuted' if atom.predicate=='qualification' and atom.arguments[0]=='obligation' else 'supported')
        run(cid,'The conditional consequence is unknown','unknown',
            lambda atom:'unknown' if atom.predicate=='proposition' and atom.arguments[1]=='noncompliance' else 'supported')
    dump(RUN/'native.json',results)
    print('Exact compiled-program checks',len(results))


if __name__=='__main__':
    main()
