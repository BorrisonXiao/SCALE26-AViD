"""Archive the annotations and cached results needed to replay the comparison."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from prepare_or_source_evaluation import read
from prepare_scope_alignment import PRIOR, ROOT, RUN
from scope_alignment_report import CUR, OLD, URL

REPLAY=('after.json','speech_inputs.json','speech_inputs_roster.json','speech_evaluation.json',
        'speech_evaluation_roster.json','native.json','evaluation.json')


def main():
    paths=[ROOT/p for p in ('requirements-compilation.txt','requirements-verification.txt',
                            'tests/test_negative_coordination.py')]
    paths.extend(RUN/name for name in (
        'before.json','interpretation.json','tests.xml','diarization.json','diarization_roster.json',
        'speech_cases.json','speech_cases.sha256','speech_scores.json','speech_scores_roster.json',
        'roster.json','audio/manifest.json',*REPLAY))
    paths.extend(p for p in (RUN/'compiler').iterdir() if p.is_file() and p.name!='baseline_srl.json')
    paths.append(PRIOR/'source/minilm-nli/snapshot.json')
    with ZipFile(ROOT/'site/reports/compiler-demos/or-followup-20261119/source.zip') as prior:
        paths.extend(ROOT/name for name in prior.namelist() if name.startswith('scripts/'))
    paths.extend(ROOT/'scripts'/(name+'.py') for name in (
        'probabilistic_verification/negative_coordination','prepare_scope_alignment','evaluate_ami_alignment',
        'run_ami_diarization','check_scoped_coordination_inference','scope_alignment_report','package_scope_alignment'))
    data={str(p.relative_to(ROOT)):p.read_bytes() for p in paths}
    hashes=read(RUN/'corpus_hashes.json')
    for name,path in (('before',OLD),('after',CUR)):
        rows=(dict(claim_id=cid,selected_stage=stage,output={'program_sha256':digest} if digest else None)
              for cid,(stage,digest) in hashes[name].items())
        data[str(path.relative_to(ROOT))]=''.join(json.dumps(r)+'\n' for r in rows).encode()
    data['README.md']=(ROOT/'docs/scope_and_alignment_20261119.md').read_bytes()
    data['REPLAY_SHA256.json']=json.dumps({p:sha256((RUN/p).read_bytes()).hexdigest()
                                         for p in REPLAY},indent=2).encode()
    target=ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(target,'w',compression=ZIP_DEFLATED) as z:
        for name,payload in sorted(data.items()):
            member=ZipInfo(name,date_time=(2026,11,19,0,0,0))
            member.compress_type=ZIP_DEFLATED
            z.writestr(member,payload)
    print(f'Archived {len(data)} files for offline replay.')


if __name__=='__main__':
    main()
