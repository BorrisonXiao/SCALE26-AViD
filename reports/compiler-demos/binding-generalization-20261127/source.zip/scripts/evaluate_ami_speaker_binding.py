"""Evaluate speaker and utterance binding on fixed AMI transcripts."""
import argparse
from collections import Counter, defaultdict
from hashlib import sha256
from itertools import chain, product

from collect_ami_or_candidates import detokenize
from evaluate_ami_alignment import match_speakers, proposed_windows
from evaluate_reported_or_transcripts import score_pairs
from prepare_ami_speaker_binding import RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from prepare_scope_alignment import PRIOR, RUN as PRIOR_RUN
from probabilistic_verification.transcript_or import implicit_splits, judge, normalize, splits

STOPWORDS = set('a an the or and for i it its to was is of in that this you they we yeah but so oh can be'.split())


def within(window, query):
    return window['end'] > query['start'] and window['start'] < query['end']


def evaluate_binding():
    cases = read(RUN / 'binding_cases.json')
    for row in cases:
        desired = {normalize(x) for x in row['alternatives']}
        for example in row['cases']:
            q = example['query']
            windows = [w for w in example['windows'] if within(w, q)]
            speaker_windows = [w for w in windows if w['speaker'] == q['speaker']]

            def pool(items):
                spans = chain.from_iterable((w['text'], *chain.from_iterable(splits(w['text'], 'or')))
                                            for w in items)
                return 'supported' if desired <= {normalize(s) for s in spans} else 'unknown'

            verdicts = dict(pool=pool(windows), speaker=pool(speaker_windows), utterance='unknown')
            if any(judge(q, dict(w, target=row['text'])) == 'supported' for w in speaker_windows):
                verdicts['utterance'] = 'supported'
            example['verdicts'] = verdicts
    groups = defaultdict(Counter)
    for row in cases:
        for example in row['cases']:
            for method, result in example['verdicts'].items():
                counts = groups[method]
                counts['correct'] += result == example['expected']
                counts['support'] += result == 'supported' and example['expected'] == 'supported'
                counts['false_support'] += result == 'supported' and example['expected'] == 'unknown'
    dump(RUN/'binding_evaluation.json', dict(cases=cases, counts=groups))


def overlap_windows(example, turns, names, start, end):
    """Retain words with several possible owners, with branch-specific anchors."""
    active = [t for t in turns if t['end']>start and t['start']<end]
    assigned = defaultdict(list)
    for word in example['clip_words']:
        mid = (word['start']+word['end'])/2
        if not start<=mid<end:
            continue
        buckets = [i for i, t in enumerate(active) if t['start']<=mid<t['end']]
        unique_cluster = len({active[i]['cluster'] for i in buckets}) == 1
        for i in buckets:
            assigned[i].append((word, unique_cluster))

    for i, decorated in assigned.items():
        last = 0
        lengths = [j for j, (w, _) in enumerate(decorated, 1) if w['text'] in {'.','?','!'}]
        if not lengths or lengths[-1] != len(decorated):
            lengths.append(len(decorated))
        for limit in lengths:
            group = decorated[last:limit]
            last = limit
            words = [w for w, _ in group]
            marked = [j for j,w in enumerate(words) if w['text'].casefold()=='or']
            if len(marked)!=1 or len(words)<3:
                continue
            anchor = []
            for branch in (group[:marked[0]], group[marked[0]+1:]):
                anchor.append(sorted({p for w, unique in branch if unique
                                      for p in normalize(w['text']).split() if p not in STOPWORDS}))
            if not all(anchor):
                continue
            cluster = active[i]['cluster']
            yield dict(text=detokenize(words), start=max(start,words[0]['start']),
                       end=min(end,max(w['end'] for w in words)),speaker=names.get(cluster),
                       cluster=cluster, complete=False, anchors=anchor,
                       word_ids=[w['word_id'] for w in words],
                       overlapping_words=sum(not unique for _,unique in group))


def load_turns(path):
    return {row['meeting']:row['turns'] for row in read(path)['meetings']}


def match_fragments(enrollment):
    """Allow separately supported clusters to name the same enrolled speaker."""
    names = {}
    for cluster, support in zip(enrollment['clusters'],enrollment['match_seconds']):
        if not support:
            continue
        index = max(range(len(support)), key=support.__getitem__)
        if support[index] >= 1 and support[index] >= 0.55*sum(support):
            names[cluster] = enrollment['annotated_speakers'][index]
    return names


def prepare_alignment():
    source = PRIOR_RUN/'speech_cases.json'
    assert sha256(source.read_bytes()).hexdigest() == (PRIOR_RUN/'speech_cases.sha256').read_text().strip()
    previous = {r['meeting']:r for r in read(PRIOR_RUN/'speech_inputs.json')}
    conditions = {
        'pyannote':load_turns(PRIOR_RUN/'diarization.json'),
        'reverb':load_turns(RUN/'reverb.json'),
        'pyannote_roster':load_turns(PRIOR_RUN/'diarization_roster.json'),
        'reverb_roster':load_turns(RUN/'reverb_roster.json'),
    }
    conditions['pyannote_fragments'] = conditions['pyannote']
    conditions['reverb_fragments'] = conditions['reverb']
    records = []
    for case in read(source):
        prior = previous[case['meeting']]
        methods = {}
        for label, run in conditions.items():
            turns = run[case['meeting']]
            names, enrollment = match_speakers(case, turns)
            if label.endswith('_fragments'):
                names = match_fragments(enrollment)
            strict, candidates = [],[]
            for start,end in ((case['query_start'],case['query_end']), (case['clip_start'],case['query_start']-5)):
                strict.extend(proposed_windows(case,turns,names,start,end))
                candidates.extend(overlap_windows(case,turns,names,start,end))
            audio_words = {w['word_id'] for w in case['words'] if w['text'] not in {',','.','?','!'}}
            positive_query = prior['variants'][0]['query']
            available = {wid for w in strict+candidates
                         if w['speaker']==positive_query['speaker'] and within(w,positive_query)
                         for wid in w['word_ids']}
            methods[label] = dict(strict=strict, overlap=candidates, speaker_map=names,
                                  query_word_coverage=len(audio_words & available)/len(audio_words),
                                  max_named_window_coverage=max((
                                      len(audio_words & set(w['word_ids']))/len(audio_words)
                                      for w in strict+candidates if w['speaker']==positive_query['speaker']
                                      and within(w,positive_query)),default=0),
                                  turn_count=len(turns), cluster_count=len({t['cluster'] for t in turns}),
                                  enrollment=enrollment)
        records.append(dict(meeting=prior['meeting'], target=case['text'], source_segment=case['segment_id'],
                            gold=prior['gold'], variants=prior['variants'], methods=methods))
    dump(RUN/'alignment_inputs.json', records)


def score_alignment():
    pairs = set()
    for row in read(RUN/'alignment_inputs.json'):
        target, = splits(row['target'], 'or')
        for method in row['methods'].values():
            for c in method['strict']+method['overlap']:
                spans = {c['text']}
                for pair in chain(splits(c['text'],'or'),splits(c['text'],'and'),implicit_splits(c['text'])):
                    spans.update(pair)
                for a,b in product(spans,target):
                    if normalize(a)!=normalize(b):
                        pairs.update(((a,b),(b,a)))
    scores = score_pairs(pairs, PRIOR/'source/minilm-nli')
    dump(RUN/'alignment_scores.json', scores)
    print('Scored',len(scores['scores']),'unique text pairs.')


def ranked_windows(method, query, target):
    target_branches = [set(normalize(s).split())-STOPWORDS for s in next(splits(target,'or'))]
    windows = {}
    for w in method['strict']+method['overlap']:
        if w['speaker']!=query['speaker'] or not within(w,query):
            continue
        if 'anchors' in w:
            anchors = [set(s) for s in w['anchors']]
            if not (all(a & b for a,b in zip(anchors,target_branches))
                    or all(a & b for a,b in zip(anchors,reversed(target_branches)))):
                continue
        windows.setdefault(tuple(w['word_ids']),w)
    target_words = Counter(normalize(target).split())
    def rank(window):
        words = Counter(normalize(window['text']).split())
        overlap = sum((words & target_words).values())
        return -2*overlap/(sum(words.values())+sum(target_words.values())),window['start'],window['text']
    return sorted(windows.values(),key=rank)


def evaluate_alignment():
    stored = {(r['premise'],r['hypothesis']):r['probabilities'] for r in read(RUN/'alignment_scores.json')['scores']}
    def entail(a,b):
        return stored[a,b]['entailment']
    def contradict(a,b):
        return stored[a,b]['contradiction']

    results = read(RUN/'alignment_inputs.json')
    totals = defaultdict(Counter)
    for row in results:
        for variant in row['variants']:
            query = variant['query']
            variant['predictions'] = {}
            for label,windows in row['methods'].items():
                ordered = ranked_windows(windows,query,row['target'])
                comparisons = {
                    'strict_all':[w for w in windows['strict'] if w['speaker']==query['speaker'] and within(w,query)],
                    'ranked_1':ordered[:1],
                    'ranked_3':ordered[:3],
                }
                for name,candidates in comparisons.items():
                    hits = [w for w in candidates if judge(query,dict(w,target=row['target']),entail,
                                                            allow_implicit=True,contradiction=contradict)=='supported']
                    verdict = 'supported' if hits else 'unknown'
                    key = f'{label}_{name}'
                    count = totals[key]
                    count['correct_speaker_support']+=variant['variant']=='correct_speaker' and bool(hits)
                    count['wrong_speaker_support']+=variant['variant']=='different_speaker' and bool(hits)
                    count['earlier_time_support']+=variant['variant']=='disjoint_query' and bool(hits)
                    count['windows_checked']+=len(candidates)
                    variant['predictions'][key]=dict(verdict=verdict,candidates=candidates,matching=hits)
    dump(RUN/'alignment_evaluation.json',dict(rows=results,counts=totals))
    print(dict(totals))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('stage',choices=('binding','prepare','score','evaluate'))
    {'binding':evaluate_binding,'prepare':prepare_alignment,'score':score_alignment,'evaluate':evaluate_alignment}[p.parse_args().stage]()
