"""Render the paired speech binding comparison on the existing report."""
from html import escape
from shutil import copy2
from xml.etree import ElementTree as ET

from compiler_fallback_report import table
from evaluate_ami_probabilistic_binding import CONTENT, METHODS, SCALES
from prepare_ami_probabilistic_binding import RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import ROOT, read

URL = 'compiler-demos/ami-probabilistic-binding-20261126/'
METHOD_LABEL = dict(zip(METHODS,('Whole-claim DeBERTa','Separate utterances allowed','Same utterance, no cue check',
                                 'Same utterance and cue','Filter and take the highest score')))
VARIANT_LABEL = {'original':'Original report','paraphrase':'Paraphrase','changed_option':'Changed alternative',
                 'changed_context':'Changed surrounding context','wrong_speaker':'Wrong speaker',
                 'wrong_time':'Wrong time','split_utterances':'Alternatives in separate utterances',
                 'split_speakers':'Alternatives from different speakers'}
COMPILER_LABEL = {'usable':'Explicit report and named speaker preserved',
                  'verbatim_quote':'Quoted words and named speaker preserved', 'abstained':'No program',
                  'missing_report':'Full reported alternatives missing','missing_speaker':'Speaker role missing'}
FORM = ('At least one candidate utterance U must satisfy all four conditions\n'
        '    the speaker of U matches the requested speaker,\n'
        '    U overlaps the requested time interval,\n'
        '    U has evidence of alternatives, and\n'
        '    the text in U supports the full claimed report.')


def summarize():
    result = read(RUN/'binding_evaluation.json')
    result['compiler'] = read(RUN/'compiler_evaluation.json')
    tests = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(tests.get(k,0))==0 for k in ('failures','errors','skipped'))
    result['tests'] = int(tests.get('tests'))
    dump(RUN/'evaluation.json',result)


def status_html():
    result = read(RUN/'evaluation.json')
    scored = result['summary']['calibrated']
    shared = scored['shared_witness']['all']['correct']
    separate = scored['separate_witnesses']['all']['correct']
    return (f'<b>Requiring one utterance improves calibrated decisions from {separate}/{result["total"]} '
            f'to {shared}/{result["total"]}.</b> The simple filter gives the same decisions as DeepProbLog.')


def overview_html():
    result = read(RUN/'evaluation.json')
    n = len(result['meetings'])
    summary = result['summary']
    compiler = result['compiler']['counts']
    records = []
    for scale in SCALES:
        for method in METHODS:
            s = summary[scale][method]
            split = s['split_utterances']['false_support']+s['split_speakers']['false_support']
            records.append((scale.title(),METHOD_LABEL[method],f'{s["all"]["correct"]}/{result["total"]}',
                            f'{s["wrong_speaker"]["false_support"]}/{n}',f'{s["wrong_time"]["false_support"]}/{n}',
                            f'{split}/{2*n}',f'{s["content"]["false_support"]}/{2*n}',f'{s["all"]["missed_support"]}/{2*n}'))
    return (
        '<h2 id="remaining-failures">What explicit binding adds to speech verification</h2>'
        f'<p>We test {result["total"]} queries from {n} previously reserved AMI meetings. They '
        'cover valid reports and paraphrases, small content edits, wrong speakers, wrong times, and '
        'alternatives split across two utterances. Every method sees the same candidate transcripts '
        'with annotated speakers and timestamps. These cases test whether the specified person made '
        'the report in the specified context.</p>'
        '<p>Whole-claim DeBERTa reads the transcript block and its speaker and time labels in one '
        'input. The three DeepProbLog variants use the same per-utterance DeBERTa scores and vary '
        'which conditions must belong to one utterance. The simple filter uses the full condition, '
        'then takes the highest score. An alternative cue is an explicit “or” or wording such as '
        '“another option.” Every method uses 0.5 as its final support threshold.</p>'
        f'<pre>{escape(FORM)}</pre>'
        '<div class="or-variant-table">'
        +table('Support decisions with the same transcript candidates. The four false-support columns count errors.',
               ['Scores','Method','Correct','Wrong speaker','Wrong time','Split alternatives','Changed content','Missed valid'],
               records)
        +f'</div><p>The full rule and the filtered maximum agree on '
        f'{result["equal_decisions_with_filtered_max"]["raw"]}/{result["total"]} raw decisions and '
        f'{result["equal_decisions_with_filtered_max"]["calibrated"]}/{result["total"]} calibrated decisions. '
        'The exact program can combine probability across several eligible utterances. The filter uses '
        'the highest eligible score. The comparison checks these differences directly.</p>'
        f'<p>Reference logical forms let every case enter inference. In the separate automatic compiler audit, '
        f'{compiler.get("verbatim_quote",0)} of {len(result["compiler"]["cases"])} claims preserve the speaker '
        f'and quoted text in a verbatim speech predicate. {compiler.get("usable",0)} emit the explicit '
        f'reported-alternatives predicate used here. There are {compiler.get("abstained",0)} abstentions. '
        f'We verified {result["exact_comparisons"]} DeepProbLog distributions against a direct calculation. '
        f'All {result["tests"]} project tests passed.</p>'
        '<p><a href="#ami-probabilistic-binding-examples">Candidate and inference examples</a> · '
        '<a href="#ami-probabilistic-compiler-audit">Automatic compilation</a> · '
        '<a href="#earlier-ami-window-comparison">Earlier window comparison</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}evaluation.json">All scores and cases</a> · '
        f'<a href="{URL}source.zip">Source, logic program, and replay</a> · <a href="{URL}tests.xml">Tests</a></p>'
    )


def examples_html():
    result = read(RUN/'evaluation.json')
    rows = [dict(c,meeting=r['meeting']) for r in result['meetings'] for c in r['cases']]
    examples = {}
    for variant, failing in (('wrong_speaker','separate_witnesses'),('wrong_time','separate_witnesses'),
                             ('split_utterances','shared_without_cue'),('split_speakers','shared_without_cue'),
                             ('paraphrase','whole_claim'),('changed_option','shared_witness')):
        candidates = [c for c in rows if c['variant']==variant]
        if variant=='wrong_time':
            corrected = [c for c in candidates if c['results']['calibrated'][failing]['support'] and
                         not c['results']['calibrated']['shared_witness']['support']]
            candidates = corrected or candidates
        case = max(candidates,key=lambda c:(c['results']['raw'][failing]['support']!=c['expected_support'],
                                            c['results']['raw'][failing]['distribution']['supported']))
        examples[case['id']] = case
    residual = next((c for c in rows if c['variant']=='wrong_time' and
                     c['results']['calibrated']['shared_witness']['support']),None)
    if residual:
        examples[residual['id']] = residual
    output = ['<section id="ami-probabilistic-binding-examples"><h2>Binding decisions on exact transcript candidates</h2>']
    for cid, c in examples.items():
        name, q = c['meeting'],c['query']
        expected = 'Support' if c['expected_support'] else 'No support'
        output.append(f'<article class="box benchmark-case" id="{escape(cid)}">'
                      f'<h3>{escape(name)} · {VARIANT_LABEL[c["variant"]]}</h3>'
                      f'<p>Claim about speaker {escape(q["speaker"])} between {q["start"]:g} and {q["end"]:g} seconds</p>'
                      f'<blockquote>{escape(c["content"])}</blockquote><p><strong>Expected</strong> {expected}</p>'
                      '<ul class="transcript-comparisons">')
        for w in c['windows']:
            checks = ' · '.join(('Speaker matches' if w['checks']['speaker'] else 'Different speaker',
                                 'In time' if w['checks']['time'] else 'Outside time',
                                 'Alternative cue' if w['checks']['cue'] else 'No alternative cue'))
            output.append(f'<li><h4>Speaker {escape(w["speaker"])} · {w["start"]:.2f}–{w["end"]:.2f} s</h4>'
                          f'<p>{escape(w["text"])}</p><p>{checks}</p>'
                          f'<p>Content support {w["probability"]["raw"]:.3f} raw, '
                          f'{w["probability"]["calibrated"]:.3f} calibrated</p></li>')
        output.append('</ul><div class="or-variant-table">'+table('Support probabilities from the same candidate inventory.',
            ['Method','Raw','Calibrated'],[(METHOD_LABEL[m],*(
                f'{c["results"][s][m]["distribution"]["supported"]:.3f} '
                f'({"support" if c["results"][s][m]["support"] else "no support"})' for s in SCALES)) for m in METHODS])+
            '</div></article>')
    output.append('</section><section id="ami-probabilistic-compiler-audit"><h2>Automatic compilation of quoted reports</h2>'
                  '<p>The comparison above uses reviewed forms for all queries. The current compiler was run on '
                  'the 48 original and edited reports as direct quotations. The verbatim speech predicate preserves '
                  'the quoted words. Semantic support for a paraphrased report requires its own relation.</p>')
    counts = result['compiler']['counts']
    output.append(table('Compiler outputs with the reporting predicates checked.', ['Outcome','Claims'],
                        [(COMPILER_LABEL[k],counts.get(k,0)) for k in COMPILER_LABEL]))
    for state in COMPILER_LABEL:
        case = next((c for c in result['compiler']['cases'] if c['state']==state),None)
        if not case:
            continue
        output.append(f'<article class="box benchmark-case"><h3>{COMPILER_LABEL[state]}</h3>'
                      f'<blockquote>{escape(case["text"])}</blockquote>')
        if 'form' in case:
            output.append(f'<pre>{escape(case["form"])}</pre>')
        else:
            output.extend(f'<p>{escape(a["stage"])} · {escape(a.get("reason") or a["status"])}</p>'
                          for a in case['statuses'])
        output.append('</article>')
    output.append('<p>AMI transcript excerpts © University of Edinburgh and partners under CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a> · '
                  '<a href="https://huggingface.co/cross-encoder/nli-deberta-v3-small">DeBERTa checkpoint</a>.</p></section>')
    return ''.join(output)


def write_downloads():
    target = ROOT/'site/reports'/URL
    target.mkdir(parents=True,exist_ok=True)
    for filename in ('evaluation.json','tests.xml'):
        copy2(RUN/filename,target/filename)


if __name__=='__main__':
    summarize()
