"""Show speech without explicit “or” and visual assignment results."""
from html import escape
from shutil import copy2
from xml.etree import ElementTree as ET

from compiler_fallback_report import table
from evaluate_ami_implicit_binding import METHODS, SCALES
from prepare_compiler_fallback import ROOT, dump
from prepare_or_source_evaluation import read
from prepare_ami_window_comparison import series
from score_visual_assignments import RUN

URL = 'compiler-demos/binding-generalization-20261127/'
LABELS = dict(zip(METHODS,('Speaker and content can use separate spans','Same span, without the wording check',
                           'Same span, with the wording check')))
QUALITY = {'original':'Original crops','reduced_resolution':'Reduced resolution'}


def summarize():
    speech, visual = (read(RUN/p) for p in ('speech_evaluation.json','visual_evaluation.json'))
    suite = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(k,0))==0 for k in ('failures','errors','skipped'))
    dump(RUN/'evaluation.json',dict(speech=speech,visual=visual,tests=int(suite.get('tests'))))


def status_html():
    result = read(RUN/'evaluation.json')
    speech = result['speech']['summary']['raw']
    n = speech['shared_witness']['supported']+speech['shared_witness']['faithful_errors']
    visual = result['visual']['summary']
    agreeing = sum(s['total']-s['different_decisions'] for s in visual.values())
    return (f'<b>The wording check supports {speech["shared_witness"]["supported"]}/{n} valid reports '
            'without “or.”</b> Exact inference and the best-assignment baseline agree on '
            f'{agreeing}/{sum(s["total"] for s in visual.values())} visual and OCR decisions.')


def overview_html():
    result = read(RUN/'evaluation.json')
    speech, visual = result['speech'],result['visual']
    n = speech['summary']['raw']['shared_witness']['faithful_errors']+speech['summary']['raw']['shared_witness']['supported']
    other = speech['total']-n
    nseries = len({series(row['meeting']) for row in speech['rows']})
    rows = []
    for scale in SCALES:
        for m in METHODS:
            s = speech['summary'][scale][m]
            rows.append((scale.title(),LABELS[m],f'{s["supported"]}/{n}',f'{s["false_support"]}/{other}',
                         f'{s["wrong_speaker_errors"]}/{n}',f'{s["split_speakers_errors"]}/{n}'))
    return (
        '<h2 id="remaining-failures">Speech without “or” and competing visual assignments</h2>'
        f'<p>We selected {n} genuine alternative reports and {len(speech["rows"])-n} naturally spoken '
        f'controls from {len(speech["rows"])} new recordings across {nseries} AMI meeting series outside the earlier '
        'tests. The focal excerpts contain no spoken “or.” Some reports span multiple annotated segments '
        'from the same speaker. We also changed one option, queried another speaker, and assigned the '
        'second part to another speaker. The cases use reviewed report spans, speaker labels, and word times.</p>'
        '<p>All conditions use the same frozen DeBERTa scores. Requiring one span connects content, speaker, '
        'and time. The wording check additionally looks for patterns such as “another option.” '
        'We reuse the earlier calibration without fitting any parameters on these cases.</p>'
        '<div class="or-variant-table">'
        +table('Speech support at the same threshold of 0.5. The last three columns count false support.',
               ['Scores','Method','Valid reports supported','All controls','Wrong speaker','Split speakers'],rows)
        +'</div><p>The wording check misses both “another way” and contrasts expressed with “can also” in these reports. '
        '“Can also” appears in controls that add features, so the same phrase can express a different relation. '
        'The earlier calibration reduces false support and also removes support for some valid choices.</p>'
        '<h3>Competing visual and OCR assignments</h3>'
        '<p>Each claim has two regions, two identities, and two values such as colors or printed dates. '
        'We reuse five reviewed frame pairs and test the observed assignment and its swap. Frozen '
        'Qwen3-VL scores identities and values separately in the same crop. The left and right positions '
        'of OCR boxes come from the crop coordinates. Both methods require a complete assignment.</p>'
        '<p>The baseline takes the larger of the two complete-assignment scores. DeepProbLog sums the '
        'scores because each region can take only one identity at a time. It uses independent observations '
        'for identity and value, an assumption for this pilot. We compare the original crops with '
        'a fixed reduction in image resolution.</p>'
        '<div class="or-variant-table">'
        +table('Decisions on the five reviewed sources and their swapped claims.',
               ['Image condition','Best assignment correct','Exact inference correct','Different decisions'],
               [(QUALITY[k],f'{s["max_correct"]}/{s["total"]}',f'{s["exact_correct"]}/{s["total"]}',
                 f'{s["different_decisions"]}/{s["total"]}') for k,s in visual['summary'].items()])
        +f'</div><p>Exact inference agrees with the best-assignment decisions in both image conditions. '
        'The constructed controls below show how several independent readings can raise support for a '
        'positive claim or give false support when the readings are mistaken. Reusing the same observation '
        f'keeps it from counting twice. All {result["tests"]} project tests passed.</p>'
        '<p><a href="#ami-implicit-binding-examples">Implicit speech examples</a> · '
        '<a href="#visual-assignment-examples">Visual and OCR examples</a> · '
        '<a href="#assignment-probability-controls">Probability controls</a> · '
        '<a href="#earlier-ami-probabilistic-binding">Earlier explicit speech comparison</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}evaluation.json">All examples and scores</a> · <a href="{URL}source.zip">Source and replay</a> · '
        f'<a href="{URL}tests.xml">Tests</a></p>'
    )


def speech_examples(speech):
    records = {row['meeting']:row for row in speech['rows']}
    examples = [('IS1002c','faithful'),('IS1002c','wrong_speaker'),('TS3009d','faithful'),
                ('IN1008','split_speakers'),('TS3005b','additive_or_one_option'),('TS3009c','faithful')]
    titles = {'faithful':'Valid report','wrong_speaker':'Wrong speaker','split_speakers':'Split across speakers',
              'additive_or_one_option':'Adding options together'}
    output = ['<section id="ami-implicit-binding-examples"><h2>Speech examples without an explicit “or”</h2>']
    for meeting,variant in examples:
        row = records[meeting]
        c, = (c for c in row['cases'] if c['variant']==variant)
        q = c['query']
        output.append(f'<article class="box benchmark-case" id="implicit-{escape(meeting)}-{variant}">'
                      f'<h3>{escape(meeting)} · {titles[variant]}</h3><p><strong>Claim about speaker '
                      f'{escape(q["speaker"])}</strong> {escape(c["content"])}</p><p><strong>Expected</strong> '
                      f'{"Support" if c["expected_support"] else "No support"}</p><ul class="transcript-comparisons">')
        for w in c['windows']:
            output.append(f'<li><h4>Speaker {escape(w["speaker"])}</h4><p>{escape(w["text"])}</p>'
                          f'<p>{"Wording check finds a cue" if w["checks"]["cue"] else "Wording check finds no cue"} · '
                          f'Raw support {w["probability"]["raw"]:.3f}</p></li>')
        output.append('</ul><div class="or-variant-table">'+table('Support probabilities for the same candidate spans.',
                     ['Method','Raw','Calibrated'],[(LABELS[m],*(f'{c["results"][s][m]:.3f}' for s in SCALES))
                                                 for m in METHODS])+'</div></article>')
    output.append('<p>AMI transcript excerpts © University of Edinburgh and partners under CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a>.</p></section>')
    return ''.join(output)


def visual_examples(visual):
    output = ['<section id="visual-assignment-examples"><h2>Visual and OCR assignments</h2>']
    for scene in visual['scenes']:
        title = scene['pair_id'].replace('_',' ').capitalize()
        output.append(f'<article class="box benchmark-case" id="assignment-{escape(scene["pair_id"])}">'
                      f'<h3>{escape(title)}</h3><p>{escape(scene["review"])}</p>'
                      f'<p><strong>Observed</strong> {escape(scene["claims"][0])}</p>'
                      f'<p><strong>Swapped</strong> {escape(scene["claims"][1])}</p><div class="or-variant-table">')
        output.append(table('Scores for the two assignments and the combined support.',
                     ['Image','Claim','First assignment','Second assignment','Exact support'],
                     [(QUALITY[r['quality']],'Observed' if r['expected_support'] else 'Swapped',
                       *(f'{p:.3g}' for p in r['assignment_scores']),f'{r["distribution"]["supported"]:.3g}')
                        for r in scene['results']]))
        output.append('</div></article>')
    output.append('<p><a href="#binding-contrasts">Reviewed source frames and earlier binding pairs</a>.</p></section>'
                  '<section id="assignment-probability-controls"><h2>When combining probabilities changes a decision</h2>'
                  '<p>These inputs are constructed controls. Each candidate path has a probability of 0.42 from '
                  'two conditions with probabilities 0.60 and 0.70. Exact inference counts independent paths '
                  'together and keeps shared observations tied to the same random variable.</p><div class="or-variant-table">')
    output.append(table('Constructed controls evaluated at a support threshold of 0.5.',
                  ['Evidence conditions','Expected','Best assignment','Exact support'],
                  [(escape(c['description']),'Support' if c['expected_support'] else 'No support',
                    f'{c["best_assignment"]:.3f}',f'{c["distribution"]["supported"]:.3f}')
                   for c in visual['controls']]))
    output.append('</div></section>')
    return ''.join(output)


def examples_html():
    r = read(RUN/'evaluation.json')
    return speech_examples(r['speech'])+visual_examples(r['visual'])


def write_downloads():
    target = ROOT/'site/reports'/URL
    target.mkdir(parents=True,exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,target/name)


if __name__=='__main__':
    summarize()
