"""Source checks and logical forms for explicit alternatives."""
from dataclasses import asdict, replace
import re

from .amr_source_alignment import quote_spans
from .logical_form import LogicalFormError
from .logical_form_v2 import ScopedClaim
from .representation import Atom, Expression as E, Variable
from .semantic import temporal_features


_EXACT = re.compile(r'\bexactly\s+one\b', re.I)
_NOT_BOTH = re.compile(r'\bbut\s+not\s+both\b', re.I)
_SUFFIX = re.compile(r'[,\s]+but\s+not\s+both\s*[.!]?\s*$', re.I)
_OR = re.compile(r'(?<![\w-])or(?![\w-])', re.I)
_REPORT = {'say', 'report', 'tell', 'state', 'explain', 'announce', 'claim', 'note', 'mention'}


def outside_quotes(text, pattern):
    quotes = quote_spans(text)
    return [m for m in pattern.finditer(text)
            if not any(q['start'] <= m.start() < q['end'] for q in quotes)]


def explicit_exclusion(text):
    # Appositive text and exact quantities alone need no exclusive operator.
    exact = [m for m in outside_quotes(text, _EXACT)
             if re.match(r'\s+of\b', text[m.end():], re.I)]
    suffix = outside_quotes(text, _SUFFIX)
    if exact:
        return 'exactly one', exact[0]
    if suffix and outside_quotes(text[:suffix[0].start()], _OR):
        return 'but not both', suffix[0]
    for match in outside_quotes(text, _NOT_BOTH):
        if outside_quotes(text[:match.start()], _OR):
            return 'embedded exclusion', match
    return None


def exclusive(left, right):
    return E.combine('and', [E.combine('or', [left, right]),
                             E.negate(E.combine('and', [left, right]))])


def named_pair(record):
    """Compile exactly one of two explicitly contrasted descriptions of a noun."""
    tokens = [t for t in record['tokens'] if t['upos'] != 'PUNCT']
    if len(tokens) != 10:
        return None
    exact, one, of, the, left, and_word, right, group, copula, state = tokens
    if [t['lemma'].lower() for t in (exact, one, of, the, and_word, copula)] != [
        'exactly', 'one', 'of', 'the', 'and', 'be'
    ]:
        return None
    if (left['upos'] != right['upos'] or left['upos'] not in {'ADJ', 'NOUN'}
            or group['upos'] != 'NOUN' or 'Number=Plur' not in (group.get('feats') or '')
            or state['upos'] not in {'ADJ', 'VERB'}
            or state['deprel'] != 'root' or copula['deprel'] != 'cop'
            or not (left['head'] == group['id'] and right['head'] == left['id']
                    and right['deprel'] == 'conj' and and_word['head'] == right['id']
                    and group['head'] == one['id'] and one['head'] == state['id']
                    and copula['head'] == state['id'])
            or left['lemma'].casefold() == right['lemma'].casefold()):
        return None
    tense = temporal_features(tokens, state['id'])['tense']
    if tense not in {'pres', 'past'}:
        return None
    variables = [Variable(f'X{i}', 'entity', f"{t['text']} {group['lemma']}", (t['id'], group['id']))
                 for i, t in enumerate((left, right), 1)]
    variables.append(Variable('T0', 'context', 'Shared reference time', (copula['id'],)))
    atoms = []

    def add(pred, args, kind, *source_ids):
        atom_id = 'a' + str(len(atoms) + 1)
        atoms.append(Atom(atom_id, pred, (*args, 'scope', 'world', 'route', 'unspecified'),
                          kind, (), pred, source_ids, False))
        return E.atom(atom_id)

    descriptions = [add('distinct_entities', ('X1', 'X2'), 'reference')]
    states = []
    for var, descriptor in zip(variables, (left, right)):
        descriptions.extend([
            add('referent', (var.name, group['lemma']), 'entity', group['id']),
            add('property', (var.name, 'mod', descriptor['text']), 'property', descriptor['id']),
        ])
        states.append(add('state_at', (var.name, state['text'], tense, 'T0'), 'relation', state['id']))
    expression = E.exists([v.name for v in variables],
                          E.combine('and', [*descriptions, exclusive(*states)]))
    return ScopedClaim(record['claim_id'], record['text'], tuple(record['tokens']), tuple(variables),
                       tuple(atoms), expression, (), metadata={
                           'scopes': {}, 'exclusion': 'exactly one',
                           'runtime_requirements': ['shared reference time and two distinct entity candidates'],
                           'allowed_routes': {a.id: ['visual_depiction', 'speech_assertion', 'ocr_assertion']
                                              for a in atoms},
                       })


def inclusive_prefix(record, match):
    """Trim a terminal exclusion marker from copied parser annotations."""
    from .scoped_srl import SourceSyntax

    syntax = SourceSyntax(record)
    prefix = [t for t in record['tokens'] if t['end_char'] <= match.start()]
    ids = {t['id'] for t in prefix}
    markers = [t for t in prefix if t['lemma'].casefold() == 'or' and t['deprel'] == 'cc']
    if (len(markers) != 1 or not outside_quotes(record['text'][:match.start()],_OR)
            or any(t['head'] not in ids | {0} for t in prefix)
            or any(t['deprel'] in {'ccomp', 'xcomp', 'advcl'} or t['lemma'].casefold() in
                   {'not', 'never', 'may', 'might', 'could', 'would', 'likely', 'whether'} | _REPORT for t in prefix)):
        return None
    word_end = syntax.alignment.word_index(prefix[-1])
    frames = []
    for frame in record['srl']['frames']:
        span = frame['verb_span']
        if span is None or span[1] > word_end:
            continue
        arguments = []
        for arg in frame['args']:
            if arg['start'] <= word_end:
                end = min(arg['end'], word_end)
                arguments.append(dict(arg, end=end, text=' '.join(syntax.alignment.words[arg['start']:end+1])))
        frames.append(dict(frame, args=arguments))
    return dict(record, text=record['text'][:match.start()], tokens=prefix,
                srl=dict(record['srl'], words=syntax.alignment.words[:word_end+1], frames=frames))


def mark_exclusive(claim, original):
    """Replace one unembedded two-way OR after its shared variables are bound."""
    expr = claim.expression
    while expr.op == 'exists':
        expr = expr.children[0]
    if expr.op != 'or' or len(expr.children) != 2 or claim.metadata.get('scopes'):
        return None
    def replace_choice(node):
        if node is expr:
            return exclusive(*node.children)
        return replace(node, children=tuple(replace_choice(c) for c in node.children))
    return replace(claim, text=original['text'], tokens=tuple(original['tokens']),
                   expression=replace_choice(claim.expression),
                   metadata=dict(claim.metadata, exclusion='but not both'))


def reported_disjunctions(record, claim):
    """Require evidence for the full utterance wherever an OR is inside a report."""
    if claim.metadata.get('reported_disjunctions') or not outside_quotes(record['text'], _OR):
        return claim
    scopes = claim.metadata.get('scopes', {})
    atoms = {a.id: a for a in claim.atoms}

    def assertion_contexts(atom_id):
        args = atoms[atom_id].arguments
        scope = args[max(i for i, value in enumerate(args) if value == 'scope') + 1] if 'scope' in args else 'world'
        result = set()
        while scope in scopes:
            data = scopes[scope]
            if data.get('kind') == 'assertion':
                result.add(scope)
            scope = data.get('parent')
        return result

    selected = set()
    common_scopes = {}
    def visit(expr):
        if expr.op == 'atom':
            common_scopes[expr] = assertion_contexts(expr.atom_id)
            return common_scopes[expr]
        if not expr.children:
            return set()
        common = set.intersection(*(visit(x) for x in expr.children))
        common_scopes[expr] = common
        if expr.op == 'or':
            # The deepest common assertion is the one that contains this OR.
            selected.update(scope for scope in common if not any(scopes[s].get('parent') == scope for s in common))
        return common
    visit(claim.expression)
    if not selected:
        return claim
    metadata = dict(claim.metadata)
    routes = dict(metadata.get('allowed_routes', {}))
    checks = []
    additions = {}
    node_vars = metadata.get('node_variables', {})
    for atom in claim.atoms:
        if atom.predicate != 'proposition' or len(atom.arguments) < 4:
            continue
        owner, _, _, scope_id = atom.arguments[:4]
        if scope_id not in selected:
            continue
        scope = scopes[scope_id]
        event = metadata.get('events', {}).get(owner, {})
        concept = metadata.get('concepts', {}).get(scope.get('owner'), '')
        lemma = event.get('predicate', '') or re.sub(r'-\d\d$', '', concept)
        if lemma not in _REPORT:
            continue
        route = scope.get('route', 'unspecified')
        if route not in {'speech_assertion', 'unspecified'}:
            continue
        roots = [t for t in record['tokens'] if t.get('lemma', '').casefold() == lemma]
        if route == 'unspecified' and lemma not in {'say', 'tell', 'announce'}:
            continue
        if any(t.get('deprel') == 'nsubj' and t.get('head') in {u['id'] for u in roots}
               and t.get('lemma', '').casefold() in
               {'sign', 'caption', 'post', 'text', 'article', 'document', 'headline', 'email'}
               for t in record['tokens']):
            continue
        span = record['text']
        if len(roots) == 1:
            body = [t for t in record['tokens'] if t['head'] == roots[0]['id'] and t['deprel'] == 'ccomp']
            if len(body) == 1:
                ids = {body[0]['id']}
                while True:
                    children = {t['id'] for t in record['tokens'] if t['head'] in ids} - ids
                    if not children:
                        break
                    ids.update(children)
                matched = [t for t in record['tokens'] if t['id'] in ids]
                candidate = span[min(t['start_char'] for t in matched):max(t['end_char'] for t in matched)]
                if not outside_quotes(candidate, _OR):
                    # A coordinated continuation may attach to the reporting verb
                    # in the source parse. Include it only if its event belongs to
                    # the compiled assertion, and there is one such continuation.
                    reported_events = {
                        int(event['id'][1:]) for variable, event in metadata.get('events', {}).items()
                        if re.fullmatch(r'e\d+',event.get('id','')) and any(
                            a.arguments and a.arguments[0] == variable and scope_id in assertion_contexts(a.id)
                            for a in atoms.values())}
                    tails = [t for t in record['tokens'] if t['head'] == roots[0]['id']
                             and t['deprel'] == 'conj' and t['id'] in reported_events]
                    if len(tails) == 1:
                        tail_ids = {tails[0]['id']}
                        while True:
                            grown = tail_ids | {t['id'] for t in record['tokens'] if t['head'] in tail_ids}
                            if grown == tail_ids:
                                break
                            tail_ids = grown
                        end = max(t['end_char'] for t in record['tokens'] if t['id'] in tail_ids)
                        candidate = span[min(t['start_char'] for t in matched):end]
                if outside_quotes(candidate, _OR):
                    span = candidate
        identifier = f'a{len(claim.atoms) + len(checks) + 1}'
        check = Atom(identifier, 'reported_disjunction',
                     (node_vars.get(owner, owner), scope_id, span, 'scope', scope.get('parent','world'),
                      'route', 'speech_assertion'),
                     'scope', (), 'Utterance expresses the full disjunction', (), False)
        checks.append(check)
        additions[atom.id] = check.id
        routes[identifier] = ['speech_assertion']
    if not checks:
        return claim

    # The reported clauses describe the utterance content. Checking their
    # individual truth states would let one branch stand in for that content.
    protected_scopes = {a.arguments[1] for a in checks}
    by_id = {**atoms, **{a.id: a for a in checks}}
    bodies = {scope: [] for scope in protected_scopes}

    def protect(expr):
        if expr.op == 'atom' and expr.atom_id in additions:
            new = additions[expr.atom_id]
            return E.atom(new), set(by_id[new].arguments)
        body_scopes = common_scopes.get(expr, set()) & protected_scopes
        if body_scopes:
            for scope_id in sorted(body_scopes):
                bodies[scope_id].append(asdict(expr))
            return E.constant('supported'), set()
        if expr.op == 'atom':
            return expr, set(atoms[expr.atom_id].arguments)
        if not expr.children:
            return expr, set()
        children, used = zip(*(protect(child) for child in expr.children))
        uses = set().union(*used)
        if expr.op == 'and':
            return E.combine('and', [c for c in children if c != E.constant('supported')]), uses
        if expr.op == 'exists':
            return E.exists([v for v in expr.variables if v in uses], children[0]), uses
        return replace(expr, children=children), uses

    expression, used = protect(claim.expression)
    def atom_ids(expr):
        if expr.op == 'atom':
            return {expr.atom_id}
        return set().union(*(atom_ids(c) for c in expr.children))

    active = atom_ids(expression)
    metadata['allowed_routes'] = {key: value for key, value in routes.items() if key in active}
    metadata['reported_disjunctions'] = [
        dict(atom_id=a.id, scope=a.arguments[1], content=a.arguments[2], logical_form=bodies[a.arguments[1]],
             compiled_conditions=[asdict(b) for b in claim.atoms if a.arguments[1] in assertion_contexts(b.id)])
        for a in checks
    ]
    return replace(claim, atoms=tuple(a for a in (*claim.atoms, *checks) if a.id in active),
                   variables=tuple(v for v in claim.variables if v.name in used),
                   expression=expression, metadata=metadata)



def coordinated_display(record, marker):
    """Compile two literal display values in one explicitly delimited observation."""
    from .logical_form_v2 import ScopedCompiler

    prefix = [t for t in record['tokens'] if t['end_char'] <= marker.start() and t['upos'] != 'PUNCT']
    if len(prefix) != 10:
        return None
    in_word, article, single, context, the, subject, verb, left, or_word, right = prefix
    if [t['lemma'].casefold() for t in (in_word, article, single, the, or_word)] != ['in', 'a', 'single', 'the', 'or']:
        return None
    if (verb['lemma'].casefold() not in {'show', 'display'} or verb['deprel'] != 'root'
            or context['upos'] != 'NOUN' or context['head'] != verb['id'] or context['deprel'] != 'obl'
            or subject['upos'] not in {'NOUN', 'PROPN'} or subject['deprel'] != 'nsubj'
            or subject['head'] != verb['id'] or left['head'] != verb['id'] or left['deprel'] != 'obj'
            or right['head'] != left['id'] or right['deprel'] != 'conj' or or_word['head'] != right['id']
            or left['upos'] != right['upos'] or left['upos'] != 'ADJ'
            or left['lemma'].casefold() == right['lemma'].casefold()):
        return None
    subject_id, context_id = ('x'+str(t['id']) for t in (subject, context))
    entities = [dict(id=subject_id, text=subject['text']),
                dict(id=context_id, text=context['text'], properties=[dict(role='mod', value=single['text'])])]
    events = [
        dict(op='event', id=f"e{verb['id']}_{i}", predicate=verb['lemma'], anchor=verb['text'],
             arguments={'ARG0': subject_id, 'ARG1': dict(kind='text', value=t['text']), 'ARGM-TMP': context_id},
             properties=[dict(role='preposition:ARGM-TMP', value=in_word['text'])])
        for i, t in enumerate((left, right), 1)
    ]
    form = dict(version='logical-form-v2', kind='claim', entities=entities, formula=dict(op='or', children=events))
    # The trailing negative fragment is compiled below. The inclusive form is
    # checked against the source prefix so the check cannot treat it as a negation.
    text = record['text'][:marker.start()]
    tokens = [t for t in record['tokens'] if t['end_char'] <= marker.start()]
    claim = ScopedCompiler().compile(record['claim_id'], text, tokens, form)
    return mark_exclusive(claim, record)
