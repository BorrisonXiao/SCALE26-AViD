"""Check the content of one speaker-aligned transcript segment."""
import re

from .amr_source_alignment import quote_spans

ENTAILMENT_THRESHOLD = 0.55


def normalize(text):
    return ' '.join(re.findall(r"\w+(?:['’]\w+)*", text.casefold()))


def splits(text, word):
    quoted = quote_spans(text)
    for match in re.finditer(rf'(?<![\w-]){word}(?![\w-])', text, re.I):
        if any(q['start'] <= match.start() < q['end'] for q in quoted):
            continue
        left, right = text[:match.start()].strip(' ,.;'), text[match.end():].strip(' ,.;')
        if left and right:
            yield left, right


_PREFIX_OPTION = re.compile(
    r'\b(?:alternatively|(?:(?:the\s+)?(?:second|other)|another)\s+(?:option|possibility|alternative)'
    r'\s*(?:(?:is|was|would be|could be|I saw was)\b)?)\s*[,.:]?\s*', re.I)
_SUFFIX_OPTION = re.compile(
    r"\s+(?:is|was|would be)\s+(?:one|the other|another|the (?:first|second))\s+"
    r"(?:option|possibility|alternative)\s*$", re.I)
_SUFFIX_FURTHER_OPTION = re.compile(
    r'\b(?:the other|another|the second)\s+(?:option|possibility|alternative)[.!?]?$', re.I)
_SENTENCE = re.compile(r'(?<=[.!?;])\s+')
_FILLER = re.compile(r'^(?:(?:so|well|but|and|yeah|um|uh|er)\b[ ,]*)+', re.I)


def clean_option(text):
    return _FILLER.sub('', _SUFFIX_OPTION.sub('', text.strip(' ,.;:!?'))).strip()


def implicit_splits(text):
    """Propose two spans when a speaker explicitly presents a further option."""
    quoted = quote_spans(text)
    sentences = _SENTENCE.split(text)
    for marker in _PREFIX_OPTION.finditer(text):
        if any(q['start'] <= marker.start() < q['end'] for q in quoted):
            continue
        before = _SENTENCE.split(text[:marker.start()])
        after = re.split(r'[.!?;]|,\s+but\b', text[marker.end():], maxsplit=1)[0]
        right = clean_option(after)
        for phrase in before[-4:]:
            left = clean_option(phrase)
            if len(normalize(left).split()) >= 2 and len(normalize(right).split()) >= 2:
                yield left, right
    cursor = 0
    for i, sentence in enumerate(sentences):
        start = text.index(sentence, cursor)
        cursor = start + len(sentence)
        marker = _SUFFIX_FURTHER_OPTION.search(sentence)
        if not marker or any(q['start'] <= start + marker.start() < q['end'] for q in quoted):
            continue
        for earlier in sentences[max(0, i-2):i]:
            left, right = clean_option(earlier), clean_option(sentence)
            if left and right:
                yield left, right
                # Keep "is one option" when a bare noun does not express
                # enough of the utterance for the entailment model.
                yield earlier.strip(' .'), sentence.strip(' .')


def judge(segment, case, score=None, *, allow_implicit=False, contradiction=None):
    """Compare the two alternatives within one observed utterance.

    The segment supplies the hypothesized speaker and time window. Candidate
    completeness is supplied by the caller and only counts for a full window.
    """
    if (case['speaker'] != segment['speaker']
            or case['end'] <= segment['start'] or case['start'] >= segment['end']):
        return 'unknown'
    complete = (case['complete'] and case['start'] <= segment['start']
                and case['end'] >= segment['end'])
    alternatives = list(splits(case['target'], 'or'))
    if len(alternatives) != 1:
        return 'unknown'
    first, second = alternatives[0]

    def equivalent(a, b):
        if normalize(a) == normalize(b):
            return True
        return score is not None and min(score(a, b), score(b, a)) >= ENTAILMENT_THRESHOLD

    def entails(a, b):
        if normalize(a) == normalize(b):
            return True
        return (score is not None and score(a, b) >= ENTAILMENT_THRESHOLD
                and (contradiction is None or contradiction(b, a) < 0.5))

    def matches(left, right, compare):
        direct = (compare(left, first), compare(right, second))
        reverse = (compare(left, second), compare(right, first))
        return all(direct) or all(reverse)

    evidence = case['text']
    observed = list(splits(evidence, 'or'))
    if len(observed) == 1 and matches(*observed[0], equivalent):
        return 'supported'
    if allow_implicit and any(matches(*pair, entails) for pair in implicit_splits(evidence)):
        return 'supported'
    if not complete or observed:
        return 'unknown'
    conjunction = any([matches(a, b, equivalent) for a, b in splits(evidence, 'and')])
    single = (equivalent(evidence, first), equivalent(evidence, second))
    return 'refuted' if conjunction or any(single) else 'unknown'
