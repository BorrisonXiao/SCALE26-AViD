"""Source checks shared by the SRL and AMR fallback paths.

These checks are necessary, not an equivalence proof. A source modal remains
an explicit qualification; unresolved quantification requests abstention.
"""
import copy
from dataclasses import replace
import re
from .representation import Atom, Expression as E
from .amr_source_alignment import quote_spans,normal


def atom_scope(atom):
    args=atom.arguments
    return args[max(i for i,x in enumerate(args)if x=='scope')+1]if 'scope'in args else 'world'


def written_quotes(record):
    text=record['text'];result=[]
    for q in quote_spans(text):
        before=text[:q['start']].lower();after=text[q['end']:].lower()
        carriers=list(re.finditer(r'\b(?:sign|overlay|caption|graffiti|banner|poster|placard|inscription)\b',before))
        if carriers:
            tail=before[carriers[-1].end():].strip(' \t\n\"\'“”:,')
            if not tail or (len(tail)<180 and re.search(r'\b(?:reads?|reading|says?|saying|written|printed|displaying|showing|labelled|labeled)\b',tail)):
                result.append(q);continue
        if re.search(r'\b(?:written|printed|inscribed)\b',after[:80])and re.search(r'\b(?:sign|overlay|caption|graffiti|banner|poster|placard|inscription)\b',after[:120]):result.append(q)
    return result


def source_triggers(record):
    tokens=record.get('tokens',[]);quotes=written_quotes(record)
    def outside(t):return not any(q['start']<=t.get('start_char',-1)<q['end']for q in quotes)
    modals=[t for t in tokens if normal(t['text'])=='would'and outside(t)]
    # Two explicitly marked comparative clauses express a generic dependency,
    # rather than merely one object having a higher property value.
    comparative=[t for t in tokens if outside(t)and(t.get('feats')or'').find('Degree=Cmp')>=0
                 and any(u.get('head')==t['id']and normal(u['text'])=='the'for u in tokens)]
    generic=bool(len(comparative)>=2 and any(t.get('deprel')=='advcl'for t in comparative))
    # Explicit near-universal language is not licensed by one existential group.
    universals=[t for t in tokens if outside(t)and normal(t.get('lemma',t['text']))in{'everyone','everything','everybody','whoever','whenever'}]
    conditional=[t for t in tokens if outside(t)and(normal(t.get('lemma',t['text']))in{'imply','unless'}or(normal(t.get('lemma',t['text']))=='if'and t.get('deprel')=='mark'))]
    return dict(would=modals,comparative_generic=generic,comparative_tokens=comparative,universal_tokens=universals,conditional_tokens=conditional)


def literal_values(claim):
    import json
    result=[]
    for atom in claim.atoms:
        if atom.predicate=='written_text':result.append(atom.arguments[1])
        for arg in atom.arguments:
            try:value=json.loads(arg)
            except (ValueError,TypeError):continue
            if isinstance(value,dict)and value.get('kind')=='verbatim_text':result.append(value.get('value',''))
    return result


def in_literal(record,claim,token):
    values=literal_values(claim)
    return any(q['start']<=token.get('start_char',-1)<q['end']and any(normal(q['text'])==normal(v)for v in values)for q in quote_spans(record['text']))


def qualify_root_modal(claim,record):
    triggers=source_triggers(record);modals=[t for t in triggers['would']if not in_literal(record,claim,t)]
    if not modals:return claim,[]
    # Main-clause would is preserved lexically. No guess between conditional,
    # future-in-the-past and habitual readings is made from the auxiliary alone.
    modal=modals[0];by={t['id']:t for t in record.get('tokens',[])};head=by.get(modal.get('head'))
    if len(modals)!=1 or not head or head.get('head')!=0:
        return claim,[dict(code='modal_scope',reason='Would is embedded or multiply scoped; its clause must be resolved before compilation can be accepted.')]
    metadata=copy.deepcopy(claim.metadata)
    if any(s.get('kind')=='modal'and s.get('operator')=='would'for s in metadata.get('scopes',{}).values()):return claim,[]
    scope='modal_would::'+claim.claim_id;scopes=metadata.setdefault('scopes',{})
    if scope in scopes:raise ValueError('Reserved modal scope already exists.')
    for s in scopes.values():
        if s.get('parent')=='world':s['parent']=scope
    scopes[scope]=dict(parent='world',kind='modal',operator='would',route='unspecified',owner=None,source_token=modal['id'],reading='unspecified')
    atoms=[]
    for a in claim.atoms:
        args=list(a.arguments)
        if 'scope'in args:
            index=max(i for i,x in enumerate(args)if x=='scope')
            if args[index+1]=='world':args[index+1]=scope
        atoms.append(replace(a,arguments=tuple(args)))
    identifier='modal_qualification'
    if any(a.id==identifier for a in atoms):raise ValueError('Modal atom ID collision.')
    q=Atom(identifier,'qualification',('would',scope,'scope','world','route','unspecified'),'scope',(),'Source auxiliary would',tuple([modal['id']]),False)
    atoms.append(q);metadata.setdefault('allowed_routes',{})[identifier]=['unspecified']
    for feature in metadata.get('source_features',[]):
        if feature.get('scope')=='world':feature['scope']=scope
    for node,context in list(metadata.get('node_scopes',{}).items()):
        if context=='world':metadata['node_scopes'][node]=scope
    metadata.setdefault('source_semantics',[]).append(dict(kind='modal',word='would',source_token=modal['id'],head_token=head['id'],scope=scope,reading='Not disambiguated; no actual-world event is asserted by the embedded formula.'))
    # Existential bindings remain outside this qualification; only evidence
    # contexts change. The new atom refers to a scope label, not a variable.
    expression=E.combine('and',[E.atom(identifier),claim.expression])
    return replace(claim,atoms=tuple(atoms),expression=expression,metadata=metadata),[]


def shared_checks(record,claim):
    triggers=source_triggers(record);issues=[]
    conditions=[t for t in triggers['conditional_tokens']if not in_literal(record,claim,t)]
    scopes=claim.metadata.get('scopes',{}).values()
    if conditions and not any(s.get('kind')in{'condition','question'}or s.get('operator')=='condition'for s in scopes):
        issues.append(dict(code='conditional_scope',reason='The source contains an explicit conditional or implication, but the complete program has no corresponding condition/question context.'))
    if triggers['comparative_generic']and any(not in_literal(record,claim,t)for t in triggers['comparative_tokens']):
        issues.append(dict(code='generic_scope',reason='A comparative generic statement needs a dependency over cases; an existential event/group formula does not express that generalization.'))
    universals=[t for t in triggers['universal_tokens']if not in_literal(record,claim,t)]
    if universals:
        issues.append(dict(code='universal_scope',reason='An explicit universal or near-universal expression needs quantified scope; one existential candidate is insufficient.',source_words=' '.join(t['text']for t in universals)))
    # Quoted material has to stay in an explicit literal/content context when
    # there is a written carrier. Whole-claim quotation marks alone are ignored.
    quotes=written_quotes(record)
    if quotes:
        protected=literal_values(claim)
        for q in quotes:
            if not any(normal(q['text'])==normal(p)for p in protected):
                issues.append(dict(code='written_quote_scope',reason='A written quotation is not preserved as an exact string bound to its carrier.',text=q['text']))
    return issues


def apply_shared_semantics(record,claim):
    from .disjunction_semantics import explicit_exclusion, reported_disjunctions

    revised,issues=qualify_root_modal(claim,record)
    if explicit_exclusion(record['text']) and not revised.metadata.get('exclusion'):
        issues.append(dict(code='exclusion_scope', reason='The source requires exactly one alternative.'))
    from .negative_coordination import scope_issues
    issues.extend(scope_issues(record,revised))
    revised=reported_disjunctions(record,revised)
    return revised,issues+shared_checks(record,revised)
