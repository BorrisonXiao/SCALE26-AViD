"""Normalize coordination where the source dependencies identify shared scope."""
from copy import deepcopy
import re

from .content_recovery import tid
from .scoped_srl import SourceSyntax, quoted_spans
from .split_composition import nodes

NEGATION = {'not', "n't"}
DESTINATION_ROLES = {'ARGM-DIR', 'ARGM-GOL', 'ARGM-LOC', 'ARG2', 'ARG4'}
DESTINATION_PREPOSITIONS = {'to', 'into', 'onto', 'at'}


def branch_event(branch):
    while branch['op'] in {'not', 'qualified'}:
        branch = branch['child'] if branch['op'] == 'not' else branch['body']
    return branch if branch['op'] == 'event' else None


def negate_event(branch):
    if branch['op'] == 'qualified':
        branch['body'] = negate_event(branch['body'])
        return branch
    return branch if branch['op'] == 'not' else dict(op='not', child=branch)


def shared_negation(syntax, left, right):
    negatives = [t for t in syntax.children[left['id']] if t['text'].casefold() in NEGATION]
    if len(negatives) != 1 or any(t['text'].casefold() == 'only' for t in syntax.children[left['id']]):
        return False
    between = [t for t in syntax.tokens if left['id'] < t['id'] < right['id']]
    return (not any(t['upos'] == 'PUNCT' and t['text'] in {',', ';', ':'} for t in between)
            and not any(t['deprel'].split(':')[0] in {'nsubj', 'csubj', 'aux', 'cop'}
                        or t['text'].casefold() in NEGATION for t in syntax.children[right['id']]))


def shared_destination(syntax, left, right, left_token, right_token):
    if left_token['lemma'] != right_token['lemma']:
        return
    if not any(left['arguments'].get(role) and left['arguments'][role] == right['arguments'].get(role)
               for role in ('ARG0', 'ARG1', 'nsubj', 'nsubj:pass')):
        return
    if any(t['deprel'].startswith(('nsubj', 'csubj')) for t in syntax.children[right_token['id']]):
        return
    head = right_token['id']
    # Stanza may attach a destination to a direction particle such as back.
    local = {head, *(t['id'] for t in syntax.children[head] if t['deprel'] == 'advmod')}
    targets = [t for t in syntax.tokens if t['head'] in local and t['deprel'] == 'obl'
               and t['id'] > head and any(c['deprel'] == 'case' and
                                         c['lemma'] in DESTINATION_PREPOSITIONS
                                         for c in syntax.children[t['id']])]
    if len(targets) != 1:
        return
    target = targets[0]
    span = syntax.surface(syntax.subtree(target['id'])).casefold()
    options = []
    for role, value in right['arguments'].items():
        if role not in DESTINATION_ROLES:
            continue
        if value == f'x{target["id"]}' or (isinstance(value, dict) and span in str(value.get('value', '')).casefold()):
            options.append((role, value))
    if len(options) != 1:
        return
    role, value = options[0]
    existing = left['arguments'].get(role)
    if existing is not None:
        if not (isinstance(existing, dict) and isinstance(value, dict)
                and str(value.get('value', '')).startswith(str(existing.get('value')) + ' ')):
            return
    elif any(k in left['arguments'] for k in {'ARGM-DIR','ARGM-LOC','ARGM-GOL'}):
        return
    # An existing source-attached destination on the first verb is local.
    if any(t['deprel'] == 'obl' and any(c['deprel'] == 'case' and
           c['lemma'] in DESTINATION_PREPOSITIONS for c in syntax.children[t['id']])
           for t in syntax.children[left_token['id']]):
        return
    left['arguments'][role] = deepcopy(value)
    for p in right.get('properties', []):
        if p['role'] == 'preposition:' + role and p not in left.get('properties', []):
            left.setdefault('properties', []).append(deepcopy(p))
    for event, token in ((left, left_token), (right, right_token)):
        event['anchor_token_id'] = token['id']
    return dict(kind='shared_destination', events=[left['id'], right['id']], source=span)


def due_alternative(syntax, left, right, left_token, due):
    if due['lemma'] != 'due' or due['deprel'] != 'conj' or due['head'] != left_token['id']:
        return
    if right['predicate'] != 'be' or not any(t['id'] == tid(right['id'], 'e') and t['deprel'] == 'cop'
                                            for t in syntax.children[due['id']]):
        return
    if set(right['arguments']) != {'ARG1', 'ARG2'} or right['arguments']['ARG1'] != left['arguments'].get('ARG1'):
        return
    contents = right.get('propositions', [])
    if len(contents) != 1 or contents[0]['role'] != 'ARG2' or contents[0]['body']['op'] != 'event':
        return
    embedded = contents[0]['body']
    embedded_token = syntax.by_id.get(tid(embedded['id'], 'e'))
    if (not embedded_token or embedded_token['head'] != due['id']
            or embedded_token['deprel'] != 'xcomp' or embedded_token['lemma'] != left_token['lemma']
            or embedded['arguments'].get('ARG1') != right['arguments']['ARG1']):
        return
    if not any(t['lemma'] == 'to' and t['deprel'] == 'mark' for t in syntax.children[embedded_token['id']]):
        return
    for event, token in ((left, left_token), (embedded, embedded_token)):
        event['anchor_token_id'] = token['id']
    return embedded, embedded_token


def reported_alternative(syntax, group, report, branch, left, right):
    """Keep a repeated clause with the explicit that-complement of its reporter."""
    if group['op'] != 'or' or report is not group['children'][0] or left['lemma'] not in {'say', 'tell', 'state', 'report'}:
        return False
    contents = [p for p in report.get('propositions', [])
                if p['kind'] == 'assertion' and p['route'] == 'speech_assertion']
    if len(contents) != 1:
        return False
    content = contents[0]
    first, second = branch_event(content['body']), branch_event(branch)
    if not first or not second or tid(second['id'], 'e') != right['id']:
        return False
    first_token = syntax.by_id.get(tid(first['id'], 'e'))
    if (not first_token or first_token['deprel'] != 'ccomp' or first_token['head'] != left['id']
            or first_token['lemma'] != right['lemma']):
        return False
    first_children = syntax.children[first_token['id']]
    if not any(t['lemma'] == 'that' and t['deprel'] == 'mark' for t in first_children):
        return False
    def subjects(token_id):
        return [t['text'].casefold() for t in syntax.children[token_id] if t['deprel'].startswith('nsubj')]
    def auxiliaries(token_id):
        return [t['text'].casefold() for t in syntax.children[token_id] if t['deprel'].startswith('aux')]
    if (not subjects(first_token['id']) or subjects(first_token['id']) != subjects(right['id'])
            or auxiliaries(first_token['id']) != auxiliaries(right['id'])):
        return False
    content['body'] = dict(op='or', children=[content['body'], branch])
    group.clear()
    group.update(report)
    return True


def nominal_properties(syntax, form, notes, left, right):
    if left['deprel'] not in {'amod', 'compound'} or right['upos'] != 'ADJ':
        return
    head = syntax.by_id.get(left['head'])
    if not head or head['upos'] != 'NOUN' or not left['id'] < right['id'] < head['id']:
        return
    entity = next((e for e in form['entities'] if e['id'] == f'x{head["id"]}'), None)
    if not entity:
        return
    phrase = syntax.record['text'][left['start_char']:right['end_char']]
    prop = dict(role='mod', value=phrase)
    if prop not in entity.get('properties', []):
        return
    entity['properties'].remove(prop)
    entity.setdefault('alternative_properties', []).append(
        [dict(role='mod', value=left['text']), dict(role='mod', value=right['text'])])
    notes.append(dict(kind='alternative_modifiers', entity=entity['id'], source=phrase))


def repair_coordination(record, form, notes):
    syntax = SourceSyntax(record)
    quotes = quoted_spans(record['text'])
    if re.search(r'\bbut\s+not\s+both\b|\bexactly\s+one\s+of\b', record['text'], re.I):
        return
    alternatives = [t for t in syntax.tokens if t['deprel'] == 'cc' and t['lemma'] == 'or'
                    and not any(a <= t['start_char'] < b for a, b, _ in quotes)]
    for marker in alternatives:
        right = syntax.by_id[marker['head']]
        left = syntax.by_id.get(right['head'])
        if right['deprel'] != 'conj' or not left:
            continue
        nominal_properties(syntax, form, notes, left, right)
        if left['upos'] != 'VERB':
            continue
        for group in list(nodes(form)):
            if group.get('op') not in {'and', 'or'} or len(group['children']) != 2:
                continue
            first_branch, second_branch = group['children']
            first, second = branch_event(first_branch), branch_event(second_branch)
            if not first or not second or tid(first['id'], 'e') != left['id']:
                continue
            if reported_alternative(syntax, group, first, second_branch, left, right):
                notes.append(dict(kind='reported_alternative', report=first['id'], event=second['id']))
                continue
            if group['op'] == 'and' and second is second_branch:
                due = due_alternative(syntax, first, second, left, right)
                if not due:
                    continue
                second, embedded_token = due
                group.update(op='or', children=[first_branch, dict(op='qualified', operator='due', body=second)])
                notes.append(dict(kind='due_alternative', events=[first['id'],second['id']]))
                right_token = embedded_token
            elif group['op'] == 'or' and tid(second['id'], 'e') == right['id']:
                right_token = right
                if shared_negation(syntax, left, right):
                    group.update(op='and', children=[negate_event(first_branch), negate_event(second_branch)])
                    notes.append(dict(kind='shared_negation', events=[first['id'],second['id']]))
            else:
                continue
            shared = shared_destination(syntax, first, second, left, right_token)
            if shared:
                notes.append(shared)
