"""Preserve a shared absence or a stated consequence of noncompliance."""
from copy import deepcopy
import re

from .compilation_followup import walk_events
from .split_composition import nodes

OBLIGATION = {'must', 'should', 'shall'}
SANCTIONS = {
    'face': {'fine','penalty','eviction','arrest','sanction','jail','prison','notice','suspension'},
    'lose': {'deposit','permit','license','licence','privilege','access','credit','benefit'},
}
RESULTS = {'expire','revert','forfeit'}
DOCUMENTS = {'law','statute','regulation','form','contract','document','rule','policy','notice'}


def dangling_else(text):
    return re.search(r'\bor\s+else$', text.rstrip(" \"'”’.!?)"), re.I) is not None


def outside_quotations(tokens, text):
    from .scoped_srl import quoted_spans
    quotes = quoted_spans(text)
    return [t for t in tokens if not any(lo<=t['start_char']<hi for lo,hi,_ in quotes)]


def direct_or(children, parent):
    members = [t for t in children.get(parent,()) if t['deprel']=='conj']
    # A coordinated list can have comma-separated early members and a final OR.
    coordinators = [c['lemma'].casefold() for t in members for c in children.get(t['id'],())
                    if c['deprel']=='cc']
    return members if coordinators==['or'] else []


def absence_cues(record):
    if not {'without','or'} <= {t['lemma'].casefold() for t in record['tokens']}:
        return []
    tokens = outside_quotations(record['tokens'],record['text'])
    children = {t['id']:[c for c in tokens if c['head']==t['id']] for t in tokens}
    return [(t,direct_or(children,t['head'])) for t in tokens if
            t['lemma'].casefold()=='without' and t['deprel'] in {'case','mark'}
            and direct_or(children,t['head'])]


def add_absent_adjunct(event, role, refs, cue):
    event.setdefault('adjuncts',[]).extend(dict(role=role,target=ref,preposition='without',source=cue)
                                          for ref in refs)


def remove_marker(event,role):
    if 'properties' in event:
        event['properties'] = [p for p in event['properties'] if p != dict(role='preposition:'+role,value='without')]


def nominal_absence(record, form, notes, group, members, event, role):
    """Handle nominal OR before the ordinary positive branches are duplicated."""
    if len(members)<2 or not role.startswith('ARGM-'):
        return False
    head_id = int(group[1:])
    cue, tails = next(((c,m) for c,m in absence_cues(record)
                       if c['head']==head_id and c['deprel']=='case'),(None,[]))
    if cue is None:
        return False
    if {f"x{t['id']}" for t in tails}|{f'x{head_id}'} != set(members):
        return False
    by_id = {e['id']:e for e in form['entities']}
    if any(by_id[member].get('quantity') for member in members):
        return False
    marker = dict(role='preposition:'+role,value='without')
    if marker not in event.get('properties',[]):
        return False
    tokens=record['tokens']
    separate = {t['id']: [c['lemma'].casefold() for c in tokens if c['head']==t['id'] and c['deprel']=='case']
                for t in tails}
    if any(case for case in separate.values()):
        # The second phrase can have its own polarity. Use the explicit
        # preposition and keep the two events as separate alternatives.
        if len(tails)!=1 or list(separate.values())!=[['with']]:
            return False
        positive = deepcopy(event)
        negative = deepcopy(event)
        remove_marker(positive,role)
        remove_marker(negative,role)
        before, after = f'x{head_id}', f'x{tails[0]["id"]}'
        negative['arguments'].pop(role)
        add_absent_adjunct(negative,role,[before],cue['id'])
        positive['arguments'][role] = after
        positive.setdefault('properties',[]).append(dict(role='preposition:'+role,value='with'))
        for i, branch in enumerate((negative,positive),1):
            for embedded in walk_events(branch):
                embedded['id'] += f'_alternative{i}'
        event.clear()
        event.update(op='or',children=[negative,positive])
    else:
        event['arguments'].pop(role)
        remove_marker(event,role)
        add_absent_adjunct(event,role,members,cue['id'])
    notes.append(dict(kind='without_nominal',source_token=cue['id'],targets=members))
    return True


def local_absence(record, form, notes):
    raw=record['tokens']
    if not {'without','or'} <= {t['lemma'].casefold() for t in raw}:
        return
    tokens=outside_quotations(raw,record['text'])
    by_id={t['id']:t for t in tokens}
    children={t['id']:[c for c in tokens if c['head']==t['id']] for t in tokens}
    entities={e['id']:e for e in form['entities']}
    events=list(walk_events(form))
    for cue in tokens:
        if cue['lemma'].casefold()!='without' or cue['deprel']!='case':
            continue
        noun=by_id.get(cue['head'])
        if not noun or noun['upos']!='NOUN' or any(t['deprel']=='conj' for t in children[noun['id']]):
            continue
        parent=by_id.get(noun['head'])
        if not parent or not direct_or(children,parent['id']):
            continue
        eid=f'x{noun["id"]}'
        if eid not in entities or entities[eid].get('quantity'):
            continue
        for e in events:
            if e['id']!=f'e{parent["id"]}':
                continue
            for role,target in list(e['arguments'].items()):
                if target==eid and role.startswith('ARGM-') and dict(role='preposition:'+role,value='without') in e.get('properties',[]):
                    e['arguments'].pop(role)
                    remove_marker(e,role)
                    add_absent_adjunct(e,role,[eid],cue['id'])
                    notes.append(dict(kind='without_local',source_token=cue['id'],target=eid))


def clausal_absence(record, form, notes):
    for cue,members in absence_cues(record):
        if cue['deprel']!='mark':
            continue
        expected = {f'e{cue["head"]}',*(f'e{t["id"]}' for t in members)}
        for parent in walk_events(form):
            for scope in parent.get('propositions',[]):
                body = scope['body']
                if (body.get('op')!='or' or {e['id'] for e in walk_events(body)}!=expected
                        or dict(role='clause_marker:'+scope['role'],value='without')
                        not in parent.get('properties',[])):
                    continue
                scope['body']=dict(op='not',child=body)
                scope['kind']='manner'
                scope['source']=cue['id']
                notes.append(dict(kind='without_clausal',source_token=cue['id'],events=sorted(expected)))


def consequence_cues(record):
    lemmas={t['lemma'].casefold() for t in record['tokens']}
    if 'or' not in lemmas or not OBLIGATION & lemmas:
        return
    tokens=outside_quotations(record['tokens'],record['text'])
    children={t['id']:[c for c in tokens if c['head']==t['id']] for t in tokens}
    for modal in tokens:
        if modal['lemma'].casefold() not in OBLIGATION or modal['deprel']!='aux':
            continue
        tails=direct_or(children,modal['head'])
        if len(tails)!=1 or tails[0]['upos']!='VERB':
            continue
        tail=tails[0]
        dependents=children[tail['id']]
        marker=next((t for t in dependents if t['deprel']=='cc' and t['lemma'].casefold()=='or'),None)
        if any(t['lemma'].casefold()=='else' for t in dependents):
            yield modal,tail,marker
            continue
        if tail['lemma'] in RESULTS:
            yield modal,tail,marker
            continue
        accepted=SANCTIONS.get(tail['lemma'],set())
        # Later objects can attach to the first conjunct in basic dependencies.
        objects=[t for t in dependents+children[modal['head']] if t['id']>tail['id']
                 and t['deprel'] in {'obj','obl'}]
        labels={t['lemma'].casefold() for t in objects}
        labels.update(c['lemma'].casefold() for t in objects for c in children[t['id']])
        if accepted & labels:
            yield modal,tail,marker


def preserve_consequences(record,form,notes):
    changes=[]
    for modal, tail, marker in consequence_cues(record):
        for group in list(nodes(form['formula'])):
            if group.get('op')!='or' or len(group['children'])!=2:
                continue
            left,right=group['children']
            if left.get('op')!='qualified' or left['operator']!='obligation':
                continue
            first=left['body']
            second=right['body'] if right.get('op')=='qualified' else right
            if (first.get('op')!='event' or first['id']!=f'e{modal["head"]}'
                    or second.get('op')!='event' or second['id']!=f'e{tail["id"]}'):
                continue
            # SRL often copies the first modal to the consequence even though it
            # appears only before the required action.
            if right.get('op')=='qualified' and right['operator']=='obligation':
                if any(t['head']==tail['id'] and t['lemma'].casefold() in OBLIGATION for t in record['tokens']):
                    continue
                right=second
            first.setdefault('propositions',[]).append(
                dict(kind='consequence',role='noncompliance',route='unspecified',body=right,source=marker['id']))
            group.clear()
            group.update(left)
            changes.append(dict(kind='noncompliance',source_token=marker['id'],event=first['id'],event_result=second['id']))
    if not changes:
        return
    notes.extend(changes)
    by_id={e['id']:e for e in form['entities']}
    # A source can describe a rule through writing. Keep the route when the
    # assertion's grammatical subject is a document, rather than a speaker.
    for event in walk_events(form):
        if event['predicate'] not in {'say','state','read'}:
            continue
        actor=event['arguments'].get('ARG0')
        if not isinstance(actor,str) or by_id.get(actor,{}).get('text','').casefold() not in DOCUMENTS:
            continue
        for proposition in event.get('propositions',[]):
            if proposition['kind']=='assertion' and any(n.get('kind')=='consequence' for n in nodes(proposition['body'])):
                proposition['route']='ocr_assertion'


def scope_issues(record,claim):
    """Expose unresolved constructions before either parser can pass them."""
    negatives=absence_cues(record)
    consequences=list(consequence_cues(record))
    if dangling_else(record['text']) and OBLIGATION & {t['lemma'].casefold() for t in record['tokens']}:
        from .fallback_semantics import literal_values
        if not any(dangling_else(text) for text in literal_values(claim)):
            yield dict(code='consequence_scope',reason='The source warns of an unspecified consequence with “or else.”')
    if not negatives and not consequences:
        return
    source=claim.metadata.get('logical_form',{})
    absence_tokens=set()
    consequence_tokens=set()
    for node in nodes(source):
        if node.get('preposition')=='without' or node.get('kind')=='manner':
            absence_tokens.add(node.get('source'))
        if node.get('kind')=='consequence':
            consequence_tokens.add(node.get('source'))
    for cue,_ in negatives:
        if cue['id'] not in absence_tokens:
            yield dict(code='without_scope',reason='The program has no scoped absence for the alternatives after “without.”')
    for _,_,marker in consequences:
        if marker['id'] not in consequence_tokens:
            yield dict(code='consequence_scope',reason='The program has no consequence attached to failure of the stated requirement.')
