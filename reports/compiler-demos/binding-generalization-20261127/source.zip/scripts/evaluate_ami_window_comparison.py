"""Compare lexical window proposals with fixed-duration windows from speaker turns."""
import argparse
from collections import Counter

from audit_ami_speaker_attribution import activity_counts, coverage, target_word_ids
from calibrate_ami_speech_scores import probabilities
from collect_ami_or_candidates import detokenize
from evaluate_ami_alignment import match_speakers, proposed_windows
from evaluate_ami_speaker_binding import load_turns, overlap_windows, ranked_windows
from evaluate_ami_speech_scoring import MODELS
from evaluate_reported_or_transcripts import score_pairs
from prepare_ami_window_comparison import RUN, frozen_cases
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read

WINDOW_SECONDS = 12
WINDOW_STRIDE = 4
BUDGET = 3
METHODS = ('alternatives', 'turn_exclusive', 'turn_overlap')


def direct_windows(case, turns, names, *, include_overlap):
    """Take transcript words from a turn without checking its wording."""
    start, end = case['query_start'],case['query_end']
    turns = [t for t in turns if t['end']>start and t['start']<end]
    track_words = [[] for _ in turns]
    for word in case['clip_words']:
        mid = (word['start']+word['end'])/2
        if not start<=mid<end:
            continue
        active = [i for i,t in enumerate(turns) if t['start']<=mid<t['end']]
        if include_overlap or len(active)==1:
            for i in active:
                track_words[i].append((mid,word))
    for turn, assigned in zip(turns,track_words):
        lower, end_turn = max(start,turn['start']),min(end,turn['end'])
        upper = min(lower+WINDOW_SECONDS,end_turn)
        while lower<upper:
            words = [word for mid,word in assigned if lower<=mid<upper]
            if len(words)>=3:
                yield dict(text=detokenize(words),start=max(lower,words[0]['start']),
                           end=min(upper,max(w['end'] for w in words)),cluster=turn['cluster'],
                           speaker=names.get(turn['cluster']),word_ids=[w['word_id'] for w in words])
            if upper==end_turn:
                break
            lower += WINDOW_STRIDE
            upper = min(lower+WINDOW_SECONDS,end_turn)


def prepare():
    turns = load_turns(RUN/'diarization.json')
    records = []
    for case in frozen_cases():
        track = turns[case['meeting']]
        names, enrollment = match_speakers(case, track)
        start, end = case['query_start'],case['query_end']
        content = next(c['content'] for c in case['variants'] if c['variant']=='original')
        alternatives = dict(strict=proposed_windows(case,track,names,start,end),
                            overlap=list(overlap_windows(case,track,names,start,end)))
        windows = {'alternatives':alternatives}
        for method, include in zip(METHODS[1:],(False,True)):
            windows[method] = dict(strict=list(direct_windows(case,track,names,include_overlap=include)),overlap=[])
        reference_names, _ = match_speakers(case,track,interval=(start,end))
        gold = target_word_ids(case)
        attribution = {}
        query = dict(speaker=case['speaker'],start=start,end=end)
        for method, candidates in windows.items():
            unnamed = {kind:[dict(w,speaker=None) for w in group] for kind,group in candidates.items()}
            renamed = {kind:[dict(w,speaker=reference_names.get(w['cluster'])) for w in group]
                       for kind,group in candidates.items()}
            attribution[method] = dict(
                unnamed=coverage(ranked_windows(unnamed,dict(query,speaker=None),content),gold),
                target_labels=coverage(ranked_windows(renamed,query,content)[:BUDGET],gold),
            )
        queries = {}
        for variant, speaker in (('correct_speaker',case['speaker']),('wrong_speaker',case['wrong_speaker'])):
            query = dict(speaker=speaker,start=start,end=end)
            queries[variant] = {method:ranked_windows(w,query,content) for method,w in windows.items()}
        records.append(dict(meeting=case['meeting'], split=case['split'], target=content, speaker=case['speaker'],
                            wrong_speaker=case['wrong_speaker'],mapping=names,enrollment=enrollment,queries=queries,
                            activity=activity_counts(case,track),attribution=attribution))
    config = dict(top_k=BUDGET, turn_window_seconds=WINDOW_SECONDS, turn_window_stride=WINDOW_STRIDE)
    dump(RUN/'window_inputs.json',dict(config=config,rows=records))


def score():
    data = read(RUN/'window_inputs.json')
    pairs = {(w['text'],r['target']) for r in data['rows'] for methods in r['queries'].values()
             for windows in methods.values() for w in windows[:BUDGET]}
    dump(RUN/'window_scores.json',score_pairs(pairs,MODELS['deberta']))
    print('Scored',len(pairs),'distinct windows and hypotheses.',flush=True)


def measure():
    data = read(RUN/'window_inputs.json')
    cases = {r['meeting']:r for r in frozen_cases()}
    scores = probabilities(RUN/'window_scores.json')
    totals = {m:Counter() for m in METHODS}
    activity = Counter()
    for row in data['rows']:
        case = cases[row['meeting']]
        words = {w['word_id']:w['speaker'] for w in case['clip_words']}
        gold = target_word_ids(case)
        row['gold'] = case['text']
        row['target_words'] = len(gold)
        for key,n in row['activity'].items():
            activity[key] += n==len(gold)
        for variant, methods in row['queries'].items():
            speaker = row['wrong_speaker'] if variant=='wrong_speaker' else row['speaker']
            for method, windows in methods.items():
                sizes = [len(gold.intersection(w['word_ids'])) for w in windows]
                top = []
                for window, n in zip(windows[:BUDGET], sizes):
                    p = scores[window['text'],row['target']]
                    supported = max(p,key=p.get)=='entailment'
                    seen = Counter(words[i] for i in window['word_ids'])
                    clean = seen.keys()=={speaker}
                    top.append(dict(window,matched_words=n,word_speakers=seen,clean=clean,
                                    scores=p,supported=supported))
                support = any(w['supported'] for w in top)
                counter = totals[method]
                counter[f'{variant}_support'] += support
                counter[f'{variant}_scored'] += len(top)
                if variant=='correct_speaker':
                    counter['with_window'] += bool(windows)
                    counter['any_target_top'] += any(sizes[:BUDGET])
                    counter['full_target_all'] += len(gold) in sizes
                    counter['full_target_top'] += len(gold) in sizes[:BUDGET]
                    counter['full_target_unnamed'] += row['attribution'][method]['unnamed']==len(gold)
                    counter['full_target_reference_names'] += row['attribution'][method]['target_labels']==len(gold)
                    counter['clean_full_top'] += any(w['clean'] and w['matched_words']==len(gold) for w in top)
                    counter['clean_support'] += any(w['clean'] and w['supported'] for w in top)
                    counter['clean_full_support'] += any(w['clean'] and w['supported'] and w['matched_words']==len(gold)
                                                         for w in top)
                    counter['mixed_support'] += support and not any(w['clean'] and w['supported'] for w in top)
                methods[method] = dict(candidates=len(windows), max_words_before_ranking=max(sizes,default=0),
                                       max_words_in_top=max(sizes[:BUDGET],default=0), windows=top)
    data['summary'] = totals
    data['activity'] = activity
    dump(RUN/'window_evaluation.json',data)
    print(totals,activity,flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('stage', choices=('prepare','score','evaluate'))
    {'prepare':prepare,'score':score,'evaluate':measure}[p.parse_args().stage]()
