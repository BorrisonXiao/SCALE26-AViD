"""Freeze the new AMI meetings and a source-disjoint set of speech claims."""
from collections import Counter
from hashlib import sha256
import math
import re
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from collect_ami_or_candidates import NITE_ID, detokenize
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import RUN as SOURCE_RUN, read
from prepare_scope_alignment import AUDIO, RUN as ALIGNMENT_RUN, timed_words

RUN = ALIGNMENT_RUN.with_name('ami_window_comparison_20261126')
VARIANTS = ('original', 'paraphrase', 'changed_option', 'changed_context')


def series(meeting):
    return re.sub(r'(?<=\d)[a-z]$', '', meeting)


def frozen_cases():
    path = RUN/'speech_cases.json'
    assert sha256(path.read_bytes()).hexdigest() == (RUN/'speech_cases.sha256').read_text().strip()
    return read(path)


def freeze():
    from collect_ami_or_candidates import aligned_words

    previously_used = [*read(ALIGNMENT_RUN/'speech_cases.json'),
                       *read(SOURCE_RUN/'transcripts/cases.json')['cases'],
                       *read(ALIGNMENT_RUN.with_name('or_followup_20261119')/'transcripts/segments.json')]
    excluded = {series(r['meeting']) for r in previously_used}
    edits = read(RUN/'report_edits.json')
    groups = {series(cid.split('.')[0]) for cid in edits}
    assert len(groups)==len(edits) and len(groups)%2==0 and groups.isdisjoint(excluded)
    ordered = sorted(groups, key=lambda s:sha256(('ami-calibration-26:'+s).encode()).digest())
    calibration = set(ordered[:len(ordered)//2])
    source = SOURCE_RUN/'source/ami_public_manual_1.6.2.zip'
    records = []
    with ZipFile(source) as archive:
        for cid, edit in sorted(edits.items()):
            meeting = cid.split('.')[0]
            found = []
            for path in archive.namelist():
                if not path.startswith(f'segments/{meeting}.') or not path.endswith('.segments.xml'):
                    continue
                speaker = Path(path).name.split('.')[1]
                segment = next((s for s in ET.fromstring(archive.read(path)) if s.get(NITE_ID)==cid), None)
                if segment is not None:
                    tokens = list(ET.fromstring(archive.read(f'words/{meeting}.{speaker}.words.xml')))
                    positions = {token.get(NITE_ID):i for i,token in enumerate(tokens)}
                    found.append((speaker,aligned_words(segment,tokens,positions)))
            (speaker, words), = found
            start,end = words[0]['start'],words[-1]['end']
            query_start = max(math.floor(start/30)*30, math.ceil(end)-35)
            clip_start, clip_end = query_start-40, query_start+35
            assert 0 <= clip_start < query_start <= start < end <= clip_end
            clip_words = [w for w in timed_words(archive,meeting)
                          if w['end']>=clip_start and w['start']<=clip_end]
            other = [w for w in clip_words if w['speaker']!=speaker]
            query_others = Counter(w['speaker'] for w in other if query_start<=w['start']<clip_end)
            wrong = (query_others or Counter(w['speaker'] for w in other)).most_common(1)[0][0]
            original, paraphrase, *changes = edit
            hypotheses = [original,paraphrase]
            for old,new in changes:
                assert paraphrase.count(old)==1, (cid,old)
                hypotheses.append(paraphrase.replace(old,new))
            variants = [dict(variant=v,content=s,expected_support=i<2)
                        for i,(v,s) in enumerate(zip(VARIANTS,hypotheses,strict=True))]
            records.append(dict(meeting=meeting, series=series(meeting), segment_id=cid, speaker=speaker,
                                wrong_speaker=wrong, split='calibration' if series(meeting) in calibration else 'test',
                                text=detokenize(words), words=words, clip_words=clip_words, start=start,end=end,
                                query_start=query_start,query_end=clip_end,clip_start=clip_start,clip_end=clip_end,
                                audio_url=f'{AUDIO}/{meeting}/audio/{meeting}.Array1-01.wav', variants=variants))
    path = RUN/'speech_cases.json'
    dump(path,records)
    (RUN/'speech_cases.sha256').write_text(sha256(path.read_bytes()).hexdigest()+'\n')
    dump(RUN/'source.json',dict(annotation_sha256=sha256(source.read_bytes()).hexdigest(),
                                prior_series=sorted(excluded), calibration=sorted(calibration),
                                test=sorted(groups-calibration)))
    print('Froze',len(records),'previously unused meeting series.',flush=True)


if __name__ == '__main__':
    freeze()
