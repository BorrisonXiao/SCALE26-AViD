"""Archive the cached speech binding comparisons and replay tools."""
from hashlib import sha256
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from ami_probabilistic_binding_report import URL
from prepare_ami_probabilistic_binding import PRIOR, RUN
from prepare_or_source_evaluation import ROOT

REPLAY = ('compiled.json','compiler_evaluation.json','binding_evaluation.json','program.pl','evaluation.json')


def main():
    paths = [ROOT/name for name in ('requirements-compilation.txt','requirements-verification.txt',
                                    'tests/test_ami_probabilistic_binding.py')]
    paths.extend(RUN/name for name in (*REPLAY,'cases.json','cases.sha256','nli_scores.json','tests.xml'))
    paths.extend(p for p in (RUN/'compiler').iterdir() if p.is_file())
    paths.extend(PRIOR/name for name in ('calibration_evaluation.json','source.json'))
    with ZipFile(ROOT/'site/reports/compiler-demos/ami-window-comparison-20261126/source.zip') as archive:
        paths.extend(ROOT/name for name in archive.namelist() if name.startswith('scripts/'))
    paths.extend(ROOT/'scripts'/(name+'.py') for name in (
        'prepare_ami_probabilistic_binding','evaluate_ami_probabilistic_binding',
        'ami_probabilistic_binding_report','package_ami_probabilistic_binding'))
    files = {str(p.relative_to(ROOT)):p.read_bytes() for p in paths}
    files['README.md'] = (ROOT/'docs/ami_probabilistic_binding_20261126.md').read_bytes()
    files['REPLAY_SHA256.json'] = json.dumps({
        name:sha256((RUN/name).read_bytes()).hexdigest() for name in REPLAY
    }, indent=2).encode()
    target = ROOT/'site/reports'/URL/'source.zip'
    target.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(target,'w') as archive:
        for name,data in sorted(files.items()):
            member = ZipInfo(name,date_time=(2026,11,26,0,0,0))
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member,data)
    print(f'Archived {len(files)} files for offline replay.')


if __name__=='__main__':
    main()
