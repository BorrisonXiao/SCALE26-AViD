"""Check shared speaker and utterance assignments in the compiled speech programs."""
from itertools import product

from prepare_ami_speaker_binding import RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import read
from probabilistic_verification.compact_backend import compact_prolog_program
from probabilistic_verification.compiler_fallback import restore
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.ordered_circuit import OrderedSolver
from probabilistic_verification.representation import STATES
from probabilistic_verification.transcript_or import judge, normalize


def reporter(atom, event):
    if not atom.arguments or atom.arguments[0]!=event:
        return None
    leader = atom.arguments[1:3]
    if atom.predicate=='role' and leader[:1]==('ARG0',):
        return leader[1]
    if atom.predicate=='say' and 'ARG0' in atom.arguments:
        return atom.arguments[atom.arguments.index('ARG0')+1]
    return None


def verify_case(compiled, report, actor_atom, referent, example, target):
    event = report.arguments[0]
    draft = {v.name:[f'fixed:{v.name}'] for v in compiled.variables}
    assert event in draft and referent in draft
    windows = {w['turn']:w for w in example['windows']}
    query = example['query']
    draft[event] = list(windows)
    draft[referent] = sorted({query['speaker'],*(w['speaker'] for w in windows.values())})
    observations = {}
    for atom in compiled.atoms:
        names = sorted(set(atom.arguments) & draft.keys())
        for values in product(*(draft[n] for n in names)):
            assignment = dict(zip(names,values))
            state = 'supported'
            if atom.id==report.id:
                window = windows[assignment[event]]
                # This observation describes content only. The reporting role
                # checks the speaker on the same candidate event.
                state = judge(dict(query,speaker=window['speaker']),dict(window,target=target))
            elif atom.id==actor_atom.id:
                window = windows[assignment[event]]
                state = ('supported' if assignment[referent]==window['speaker']
                         and window['end']>query['start'] and window['start']<query['end'] else 'unknown')
            elif referent in assignment and event not in assignment:
                state = 'supported' if assignment[referent]==query['speaker'] else 'refuted'
            key = canonical_key(compiled.claim_id,atom,assignment,'speech_assertion')
            observations[key] = Observation(key,tuple(float(s==state) for s in STATES),False,atom.text,
                                            dict(candidate_assignment=assignment))
    evidence = Evidence(compiled.claim_id,draft,dict.fromkeys(draft,True),observations,route='speech_assertion')
    grounded = ground(compiled,evidence)
    result = DirectVerifier([grounded],learned=False,program_builder=compact_prolog_program,
                            solver_class=OrderedSolver).predict()[0]['distribution']
    assert result[example['expected']]>1-1e-10,(compiled.claim_id, example['name'], result)
    return dict(case=example['name'],expected=example['expected'],distribution=result,
                speaker_candidates=draft[referent],utterance_candidates=draft[event],
                used_observations=[obs.to_dict() for obs in grounded.observations.values()])


def main():
    cases = {r['claim_id']:r for r in read(RUN/'binding_evaluation.json')['cases']}
    results = []
    for candidate in read(RUN/'compiled.json'):
        row = cases[candidate['claim_id']]
        fixed = candidate['fixed']
        entry = dict(claim_id=candidate['claim_id'], text=candidate['text'], stage=fixed['selected_stage'],
                     attempts=[{k:v for k,v in a.items() if k in {'stage','status','code','reason'}}
                               for a in fixed['attempts']],program=None, results=[])
        results.append(entry)
        if not fixed['output']:
            entry['status'] = 'parse_abstention'
            continue
        compiled = restore(fixed['output']['compilation'])
        selected = [a for a in compiled.atoms if a.predicate=='reported_disjunction'
                    and normalize(a.arguments[2]).removeprefix('that ')==normalize(candidate['content'])]
        if len(selected)!=1:
            entry['status'] = 'speech_scope_missing'
            continue
        report, = selected
        binding = [(a,ref) for a in compiled.atoms if (ref:=reporter(a,report.arguments[0]))]
        if len(binding)!=1:
            entry['status'] = 'speaker_role_missing'
            continue
        actor, ref = binding[0]
        entry.update(status='evaluated', program=fixed['output']['program'],
                     logical_form=fixed['output']['compilation']['logical_form'],
                     report_predicate=report.display(),speaker_predicate=actor.display())
        entry['results'] = [verify_case(compiled,report,actor,ref,e,row['text']) for e in row['cases']]
    dump(RUN/'binding_inference.json', results)
    print('Compiled speech programs:',sum(r['status']=='evaluated' for r in results),
          'exact checks:',sum(len(r['results']) for r in results))


if __name__=='__main__':
    main()
