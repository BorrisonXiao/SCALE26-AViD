"""Render the transcript scoring and speaker attribution experiments."""
from html import escape
from shutil import copy2
import xml.etree.ElementTree as ET

from audit_ami_speaker_attribution import STAGES
from compiler_fallback_report import table
from evaluate_ami_speech_scoring import METHODS
from prepare_ami_speech_verification import RUN, VARIANTS
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import ROOT, read

URL = 'compiler-demos/ami-speech-verification-20261126/'
METHOD_NAMES = dict(zip(METHODS, ('Match exact alternative phrases', 'MiniLM on the whole utterance',
                                 'MiniLM on each alternative', 'DeBERTa on the whole utterance',
                                 'DeBERTa on each alternative')))
VARIANT_NAMES = dict(zip(VARIANTS, ('Original report', 'Paraphrase', 'Changed alternative', 'Changed context')))
STAGE_NAMES = dict(zip(STAGES, ('Words inside any estimated speech turn', 'Words inside one estimated turn',
                              'Best window before naming the speaker', 'Best window using earlier labels',
                              'Best window using target-interval labels')))
COMPILATION = {'usable':'Speaker and report preserved', 'abstained':'No compiled program',
               'missing_report':'Full reported alternatives missing', 'missing_speaker':'Speaker role missing'}
DIARIZERS = {'pyannote':'Pyannote', 'reverb':'Reverb'}


def summarize():
    scoring = read(RUN/'scoring_evaluation.json')
    attribution = read(RUN/'attribution_evaluation.json')
    assert [r['meeting'] for r in scoring['rows']] == [r['meeting'] for r in attribution['rows']]
    suite = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(suite.get(k,0))==0 for k in ('failures','errors','skipped'))
    dump(RUN/'evaluation.json',dict(scoring=scoring,attribution=attribution,tests=int(suite.get('tests'))))


def status_html():
    result = read(RUN/'evaluation.json')
    summary, a = result['scoring']['summary'], result['attribution']
    best = summary['results']['deberta_whole']
    return (f'<b>Whole-utterance DeBERTa matches {best["matches"]} of {summary["total"]} judgments '
            f'and accepts {best["false_support"]} edited claims.</b> Naming clusters with reference labels '
            f'gives {a["support"]["pyannote"]["target_labels"]["correct_speaker_clean"]} clean speaker match for each diarizer.')


def overview_html():
    result = read(RUN/'evaluation.json')
    scoring, a = result['scoring']['summary'], result['attribution']
    n = a['total']
    compiled = scoring['compiler']
    return (
        '<h2 id="remaining-failures">Speech scoring and speaker attribution</h2>'
        '<p>Each of the eight annotated AMI utterances is paired with the original claim, a paraphrase, '
        'a change to one alternative, and a change to shared context such as time, possibility, or visibility. '
        'The words, speaker, and time of the evidence stay fixed across all four. Support here means the '
        'speaker presented the specified alternatives. Spoken words can report a possibility without establishing that it happened.</p>'
        '<p>Whole-utterance natural language inference compares the transcript with the full reported claim. '
        'The alternative comparison checks both span matches in either order. A match uses exact words or '
        'entailment in both directions at the existing 0.55 threshold. The encoder weights are frozen.</p>'
        '<div class="or-variant-table">'
        +table('Expected judgments matched on the same annotated transcript windows.',
               ['Method','Original','Paraphrase','Changed alternative','Changed context','False support','Total correct'],
               [(METHOD_NAMES[m],*(f'{scoring["by_variant"][m][v]}/{n}' for v in VARIANTS),
                 f'{scoring["results"][m]["false_support"]}/{2*n}',
                 f'{scoring["results"][m]["matches"]}/{scoring["total"]}') for m in METHODS])
        +f'</div><p>DeBERTa scores the matched paraphrase above the edited claim in '
        f'{sum(scoring["paired_ranking"]["deberta"].values())} of {2*n} pairs. MiniLM does so in '
        f'{sum(scoring["paired_ranking"]["minilm"].values())}. This ranking supplies two claims at once. '
        'The support decisions above judge one claim at a time.</p>'
        +f'<p>The compiler preserves the reporting speaker and the alternatives in {compiled.get("usable",0)} of '
        f'{scoring["total"]} claims. It abstains on {compiled.get("abstained",0)} and leaves '
        f'{sum(compiled.get(k,0) for k in ("missing_report","missing_speaker"))} programs without the needed '
        'report or speaker predicate. The transcript comparison includes every claim using the written content.</p>'
        '<h3>Where automatic windows lose words</h3>'
        '<p>We reused the same diarization turns, generated windows, and word times. We named clusters '
        'first from labeled speech before the target slot and then from labels in the slot itself. '
        'The second condition uses reference labels for diagnosis. Each cell counts utterances with '
        'at least one target transcript word or with all target words. Each window count uses one window.</p>'
        '<div class="or-variant-table">'
        +table('Word coverage before and after naming the speaker. Punctuation is excluded.',
               ['Stage','Pyannote any','Pyannote all','Reverb any','Reverb all'],
               [(STAGE_NAMES[k],*(f'{a["word_coverage"][m][k][part]}/{n}' for m in DIARIZERS
                                  for part in ('any','all'))) for k in STAGES])
        +'</div><p>Pyannote has one estimated turn over every target word for all eight utterances. '
        'Window construction retains every word for only two before names are applied. Reverb also '
        'retains every word for two. This loss occurs before the text scorer sees a candidate.</p>'
        '<div class="or-variant-table">'
        +table('Correct-speaker matches and mixed-speaker text among the top three windows.',
               ['Diarizer','Labels used for naming','Supported','Support from one speaker only','Wrong-speaker support'],
               [(label,description,*(f'{a["support"][m][k][key]}/{n}' for key in (
                   'correct_speaker','correct_speaker_clean','different_speaker')))
                for m,label in DIARIZERS.items() for k,description in (
                    ('earlier_labels','Earlier labels'),('target_labels','Target-interval labels'))])
        +f'</div><p>All {result["tests"]} project tests passed. The comparison reused eight meetings and '
        'their manual transcripts. The paraphrases and edits assess specific failures and were written for this diagnostic.</p>'
        '<p><a href="#ami-speech-scorer-cases">Scorer and compiler examples</a> · '
        '<a href="#ami-speaker-attribution-cases">Window and speaker examples</a> · '
        '<a href="#earlier-ami-speaker-binding">Earlier speech binding</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}evaluation.json">Exact results</a> · '
        f'<a href="{URL}source.zip">Source and replay</a> · <a href="{URL}tests.xml">Tests</a></p>'
    )


def examples_html():
    result = read(RUN/'evaluation.json')
    output = ['<section id="ami-speech-scorer-cases"><h2>Scorers on annotated utterances</h2>'
              '<p>Every claim in each example refers to the speaker shown. “No support” combines '
              'contradiction and insufficient evidence for this comparison.</p>']
    label = {True:'Support', False:'No support'}
    for row in result['scoring']['rows']:
        name = escape(row['meeting'])
        output.append(f'<article class="box benchmark-case" id="ami-speech-scorer-{name}"><h3>{name}, '
                      f'Speaker {escape(row["query"]["speaker"])}</h3>'
                      f'<blockquote>{escape(row["evidence"]["text"])}</blockquote>')
        output.append('<ul class="transcript-comparisons">')
        for c in row['variants']:
            output.append(f'<li><h4>{VARIANT_NAMES[c["variant"]]}</h4><p>{escape(c["content"])}</p>'
                          f'<p><strong>Expected</strong> {label[c["expected_support"]]} · '
                          f'{COMPILATION[c["compiler"]["state"]]}</p>')
            for model, model_name in (('minilm','MiniLM'),('deberta','DeBERTa')):
                whole = label[c['predictions'][f'{model}_whole']]
                branches = label[c['predictions'][f'{model}_branches']]
                probability = c['whole_scores'][model]['entailment']
                output.append(f'<p><strong>{model_name}</strong> Whole utterance {whole.lower()} '
                              f'({probability:.3f} entailment) · Alternatives {branches.lower()}</p>')
            output.append('</li>')
        output.append('</ul>')
        output.append('<details><summary>Compiler outputs and reasons</summary>')
        for c in row['variants']:
            details = c['compiler']
            output.append(f'<h4>{VARIANT_NAMES[c["variant"]]}</h4><p>{escape(c["text"])}</p>')
            if 'form' in details:
                output.append(f'<pre>{escape(details["form"])}</pre>')
            else:
                output.extend(f'<p>{escape(a["stage"])} · {escape(a.get("reason") or a["status"])}</p>'
                              for a in details['statuses'])
        output.append('</details></article>')
    output.append('</section><section id="ami-speaker-attribution-cases"><h2>Where each window loses words</h2>'
                  '<p>Word coverage comes from the AMI annotation. Speaker counts on matching windows include punctuation.</p>')
    for row in result['attribution']['rows']:
        name, n = escape(row['meeting']), row['word_count']
        output.append(f'<article class="box benchmark-case" id="ami-speaker-attribution-{name}"><h3>{name}, '
                      f'Speaker {escape(row["speaker"])}</h3><blockquote>{escape(row["target"])}</blockquote>')
        output.append(table('Target words recovered at each step.', ['Stage',*DIARIZERS.values()],
                            [(STAGE_NAMES[k],*(f'{row["models"][m]["word_counts"][k]}/{n}' for m in DIARIZERS))
                             for k in STAGES]))
        matches = []
        for m, model in row['models'].items():
            for k, mapping in model['predictions'].items():
                for w in mapping['correct_speaker']['matching']:
                    counts = ', '.join(f'{speaker}: {count}' for speaker,count in
                                       sorted(w['annotated_word_speakers'].items()))
                    matches.append((DIARIZERS[m], 'Earlier' if k=='earlier_labels' else 'Target interval',
                                    escape(w['text']), escape(counts)))
        if matches:
            output.append('<div class="or-variant-table">'+table(
                'Text given support and the words assigned to each speaker in AMI.',
                ['Diarizer','Labels used for naming','Matching transcript window','AMI speaker word counts'],
                matches)+'</div>')
        output.append('</article>')
    output.append('<p>AMI transcripts © University of Edinburgh and partners under CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a> · '
                  '<a href="https://huggingface.co/cross-encoder/nli-MiniLM2-L6-H768">MiniLM model</a> · '
                  '<a href="https://huggingface.co/cross-encoder/nli-deberta-v3-small">DeBERTa model</a></p></section>')
    return ''.join(output)


def write_downloads():
    target = ROOT/'site/reports'/URL
    target.mkdir(parents=True,exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,target/name)


if __name__ == '__main__':
    summarize()
