"""Render the fresh-meeting window comparison and score calibration."""
from html import escape
from shutil import copy2
from xml.etree import ElementTree as ET

from compiler_fallback_report import table
from prepare_ami_window_comparison import RUN
from prepare_compiler_fallback import dump
from prepare_or_source_evaluation import ROOT, read

URL = 'compiler-demos/ami-window-comparison-20261126/'
METHODS = {'alternatives':'Require alternatives in the window',
           'turn_exclusive':'Use speaker turns, drop overlapping speech',
           'turn_overlap':'Use speaker turns, retain overlapping speech'}
CALIBRATION = {'original_argmax':'Frozen DeBERTa', 'calibrated_half':'Calibrated DeBERTa'}
VARIANTS = {'original':'Original report', 'paraphrase':'Paraphrase',
            'changed_option':'Changed alternative', 'changed_context':'Changed context'}


def summarize():
    calibration = read(RUN/'calibration_evaluation.json')
    windows = read(RUN/'window_evaluation.json')
    assert [r['meeting'] for r in windows['rows']]==[r['meeting'] for r in calibration['rows']]
    test = ET.parse(RUN/'tests.xml').find('testsuite')
    assert all(int(test.get(k,0))==0 for k in ('failures','errors','skipped'))
    initial = read(RUN/'initial_labels/calibration_evaluation.json')['summary']
    dump(RUN/'evaluation.json',dict(calibration=calibration,windows=windows,source=read(RUN/'source.json'),
                                    initial_calibration=initial,tests=int(test.get('tests'))))


def status_html():
    result = read(RUN/'evaluation.json')
    scores = result['initial_calibration']['test']
    raw, cal = scores['original_argmax'], scores['calibrated_half']
    windows = result['windows']['summary']['turn_overlap']
    return (f'<b>Calibrating the speech score raises test accuracy from {raw["correct"]}/{raw["total"]} '
            f'to {cal["correct"]}/{cal["total"]}.</b> The broader windows contain complete utterances '
            f'in {windows["full_target_unnamed"]} cases before speaker naming and '
            f'{windows["full_target_top"]} with the estimated names.')


def overview_html():
    result = read(RUN/'evaluation.json')
    experiment, windows = result['calibration'], result['windows']
    n = len(windows['rows'])
    test = experiment['summary']['test']
    initial = result['initial_calibration']['test']
    model = experiment['model']
    return (
        '<h2 id="remaining-failures">Speaker-turn windows and speech score calibration</h2>'
        f'<p>We selected one naturally spoken disjunction from each of {n} AMI meeting series outside '
        'the earlier studies. The same transcript supports an original report and a paraphrase. '
        'Two edits change an alternative or a surrounding condition. Twelve meeting series fit the '
        'score calibration and twelve different series test it.</p>'
        '<h3>Scoring with annotated transcripts</h3>'
        '<p>Frozen DeBERTa predicts entailment, contradiction, or neither from the transcript and '
        'the reported content. We fit a two-parameter logistic function on the entailment score. '
        'A calibrated probability of 0.5 or higher gives support. The Brier score is the mean squared '
        'difference between the probability and the expected binary label. Lower is better.</p>'
        '<div class="or-variant-table">'
        +table('Decisions and probability error on the 48 test claims after the wording audit.',
               ['Scorer','Correct','False support','Missed support','Brier score'],
               [(label,f'{test[k]["correct"]}/{test[k]["total"]}',
                 f'{test[k]["false_support"]}/{test[k]["unsupported_total"]}',
                 f'{test[k]["missed_support"]}/{test[k]["supported_total"]}',f'{test[k]["brier"]:.3f}')
                for k,label in CALIBRATION.items()])
        +f'</div><p>The fit uses 48 labeled claims, with slope {model["slope"]:.3f} and intercept '
        f'{model["intercept"]:.3f} on entailment log-odds. The uncalibrated score ranks the faithful '
        f'paraphrase above its edited version in {experiment["ranking"]["test"]["matches"]} of '
        f'{experiment["ranking"]["test"]["total"]} test pairs. Calibration preserves that ordering. '
        f'On the initial wording, calibration raises accuracy from {initial["original_argmax"]["correct"]} to '
        f'{initial["calibrated_half"]["correct"]} of 48. We corrected five paraphrase or edit phrasings, '
        'including one grammatical error noticed after inspecting the test decisions. The download retains the initial wording and results.</p>'
        '<h3>Windows from estimated speaker turns</h3>'
        '<p>All three methods share the same Pyannote turns and the same transcript word times. '
        'Speaker names come from earlier labeled speech. The new methods take up to 12 seconds of words '
        'from a turn every four seconds. They differ in whether they keep words during overlapping '
        'speech. All methods use the same word-overlap ranking and the same frozen DeBERTa decision on '
        'at most three windows. A clean match contains only the requested speaker’s words according to AMI.</p>'
        '<div class="or-variant-table">'
        +table('Utterances with all target words in a single window, using different speaker names.',
               ['Window method','Any window before naming','Top three with reference names','Top three with estimated names'],
               [(label,*(f'{windows["summary"][k][m]}/{n}' for m in (
                   'full_target_unnamed','full_target_reference_names','full_target_top')))
                for k,label in METHODS.items()])
        +f'</div><p>Pyannote had one estimated turn spanning every target word in '
        f'{windows["activity"]["one_turn"]} of {n} meetings. The reference-name column uses annotated '
        'speakers in the target interval. The automatic condition gets speaker names from earlier speech only.</p>'
        '<div class="or-variant-table">'
        +table('Frozen scorer decisions using names assigned from earlier speech.',
               ['Window method','Correct-speaker support','Support from one speaker only',
                'Support only from mixed windows','Wrong-speaker support'],
               [(label,*(f'{windows["summary"][k][m]}/{n}' for m in (
                   'correct_speaker_support','clean_support','mixed_support','wrong_speaker_support')))
                for k,label in METHODS.items()])
        +f'</div><p>All {result["tests"]} project tests passed. This comparison uses reference transcript word '
        'times and draft labels for the written claims. The calibration measures content support on '
        'annotated utterances. The window experiment measures retrieval and attribution separately.</p>'
        '<p><a href="#ami-turn-window-cases">Candidate window examples</a> · '
        '<a href="#ami-calibrated-speech-cases">Held-out speech examples</a> · '
        '<a href="#earlier-ami-speech-verification">Earlier scorer comparison</a> · '
        '<a href="verification-pipeline.html#next-steps">Checklist</a></p>'
        f'<p><a href="{URL}evaluation.json">All results and claims</a> · '
        f'<a href="{URL}source.zip">Source and replay</a> · <a href="{URL}tests.xml">Tests</a></p>'
    )


def window_examples(data):
    rows = data['rows']

    recovered = [r for r in rows if r['attribution']['turn_overlap']['target_labels']==r['target_words']
                 and r['attribution']['alternatives']['target_labels']<r['target_words']]
    misattributed = [r for r in rows if any(w['supported'] for query in r['queries']['wrong_speaker'].values()
                                           for w in query['windows'])]
    unsupported = [r for r in rows if all(not v['windows'] for v in r['queries']['correct_speaker'].values())]
    supported = [r for r in rows if any(w['supported'] for w in r['queries']['correct_speaker']['turn_exclusive']['windows'])]
    examples = {r['meeting']:r for r in supported[:1]+misattributed[:2]+recovered[:1]+unsupported[:1]}
    output = ['<section id="ami-turn-window-cases"><h2>Windows from estimated speaker turns</h2>']
    for name,row in examples.items():
        n = row['target_words']
        output.append(f'<article class="box benchmark-case" id="ami-turn-window-{escape(name)}">'
                      f'<h3>{escape(name)}, speaker {escape(row["speaker"])}</h3>'
                      f'<blockquote>{escape(row["gold"])}</blockquote>')
        coverage = row['attribution']['turn_overlap']
        output.append(f'<p>In windows that retain overlap, the best candidate has {coverage["unnamed"]}/{n} '
                      f'target words before naming and {coverage["target_labels"]}/{n} with reference names.</p>')
        for variant, speaker in (('correct_speaker',row['speaker']),('wrong_speaker',row['wrong_speaker'])):
            decisions = row['queries'][variant]
            output.append(f'<h4>{"Correct" if variant=="correct_speaker" else "Wrong"} speaker {escape(speaker)}</h4>')
            for method,label in METHODS.items():
                details = decisions[method]
                output.append(f'<p><strong>{label}</strong> · {details["max_words_in_top"]}/{n} target words '
                              f'in the best of {len(details["windows"])} scored windows</p>')
                if details['windows']:
                    output.append('<ul class="transcript-comparisons">')
                    for w in details['windows']:
                        counts = ', '.join(f'{speaker} {count}' for speaker,count in sorted(w['word_speakers'].items()))
                        output.append(f'<li><p>{escape(w["text"])}</p><p>{"Support" if w["supported"] else "No support"} '
                                      f'· {w["matched_words"]}/{n} target words · AMI speaker counts {escape(counts)}</p></li>')
                    output.append('</ul>')
        output.append('</article>')
    output.append('</section>')
    return ''.join(output)


def calibration_examples(data):
    label = {True:'Support', False:'No support'}
    output = ['<section id="ami-calibrated-speech-cases"><h2>Held-out claims with annotated speech</h2>']
    for row in data['rows']:
        if row['split']!='test':
            continue
        name = escape(row['meeting'])
        output.append(f'<article class="box benchmark-case" id="ami-calibrated-{name}"><h3>{name}</h3>'
                      f'<blockquote>{escape(row["text"])}</blockquote><ul class="transcript-comparisons">')
        for c in row['variants']:
            expected = label[c['expected_support']]
            raw, calibrated = (label[c['decisions'][k]] for k in CALIBRATION)
            output.append(f'<li><h4>{VARIANTS[c["variant"]]}</h4><p>{escape(c["content"])}</p>'
                          f'<p><strong>Expected</strong> {expected} · '
                          f'<strong>Frozen</strong> {raw.lower()} ({c["scores"]["entailment"]:.3f}) · '
                          f'<strong>Calibrated</strong> {calibrated.lower()} ({c["calibrated"]:.3f})</p></li>')
        output.append('</ul></article>')
    output.append('<p>AMI transcript excerpts © University of Edinburgh and partners, CC BY 4.0. '
                  '<a href="https://groups.inf.ed.ac.uk/ami/download/">AMI corpus</a> · '
                  '<a href="https://creativecommons.org/licenses/by/4.0/">License</a> · '
                  '<a href="https://huggingface.co/cross-encoder/nli-deberta-v3-small">DeBERTa model</a>.</p></section>')
    return ''.join(output)


def examples_html():
    result = read(RUN/'evaluation.json')
    return window_examples(result['windows']) + calibration_examples(result['calibration'])


def write_downloads():
    folder = ROOT/'site/reports'/URL
    folder.mkdir(parents=True, exist_ok=True)
    for name in ('evaluation.json','tests.xml'):
        copy2(RUN/name,folder/name)


if __name__ == '__main__':
    summarize()
