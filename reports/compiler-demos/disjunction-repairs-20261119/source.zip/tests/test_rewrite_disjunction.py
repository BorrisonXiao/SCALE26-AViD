import re

import pytest

from probabilistic_verification.split_composition import CompositionError
from probabilistic_verification.structured_rewrite import checked_rewrite_formula


OR = dict(op='or', children=[1, 2])


def parsed(text, analyses):
    matches = re.finditer(r"\w+|[^\w\s]", text)
    return dict(text=text, tokens=[
        dict(id=i, text=m[0], lemma='take' if m[0]=='takes' else m[0].lower(),
             upos=pos, deprel=relation, head=head, start_char=m.start(), end_char=m.end())
        for i, (m, (pos, relation, head)) in enumerate(zip(matches, analyses, strict=True), 1)
    ])


def inputs():
    prefix = [('DET','det',2),('NOUN','nsubj',3),('VERB','root',0),
              ('NOUN','obj',3),('ADP','case',10),('DET','det',10)]
    pier = [('ADJ','amod',10),('ADJ','amod',10),('VERB','amod',10),('NOUN','obl',3)]
    tail = [('CCONJ','cc',13),('NOUN','compound',13),('NOUN','conj',10)]
    end = [('PUNCT','punct',3)]
    record = parsed('The video takes place on a large open paved pier or terminal area.',
                    prefix + pier + tail + end)
    first = parsed('The video takes place on a large open paved pier.', prefix + pier + end)
    right_prefix = [(pos, rel, 8 if head==10 else head) for pos,rel,head in prefix]
    second = parsed('The video takes place on a terminal area.', right_prefix +
                    [('NOUN','compound',8),('NOUN','obl',3)] + end)
    return record, [dict(record=first),dict(record=second)]


def test_accepts_two_source_aligned_alternatives_in_either_order():
    record, clauses = inputs()
    assert checked_rewrite_formula(record, clauses, OR) == OR
    assert checked_rewrite_formula(record, list(reversed(clauses)), OR) == OR


def test_does_not_treat_parallel_location_arguments_as_and():
    record, clauses = inputs()
    with pytest.raises(CompositionError) as error:
        checked_rewrite_formula(record, clauses, {'op':'and', 'children':[1,2]})
    assert error.value.code == 'rewrite_or_required'


@pytest.mark.parametrize('error_kind',['modifier','subject','preposition'])
def test_rejects_a_branch_with_changed_modifier_participant_or_preposition(error_kind):
    record, clauses = inputs()
    second = clauses[1]['record']['tokens']
    if error_kind == 'modifier':
        second.append(dict(id=10,text='large',lemma='large',upos='ADJ',deprel='amod',head=8))
    elif error_kind == 'subject':
        second[1]['deprel'] = 'obj'
    else:
        second[4].update(text='under',lemma='under')
    with pytest.raises(CompositionError) as error:
        checked_rewrite_formula(record, clauses, OR)
    assert error.value.code == 'rewrite_or_alignment'


@pytest.mark.parametrize('text',['Blue Ghost completed on-orbit commissioning.', 'The sign says “On or Off.”',
                                'The charge applies to imported goods valued at $800 or less.'])
def test_rejects_or_introduced_from_a_hyphenated_word_quote_or_numeric_bound(text):
    record = dict(text=text, tokens=[])
    assert checked_rewrite_formula(record, [], None) is None
    with pytest.raises(CompositionError) as error:
        checked_rewrite_formula(record, [], OR)
    assert error.value.code == 'rewrite_or_source'
