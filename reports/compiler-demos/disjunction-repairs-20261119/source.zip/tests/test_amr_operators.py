import pytest
from probabilistic_verification.amr_composition import AMRCompiler
from probabilistic_verification.amr_scope import ScopePolicy
from probabilistic_verification.predicate_compilation import PredicateError
def compile(g,tokens=()):return AMRCompiler(coordination=True,scope_policy=ScopePolicy(dict(tokens=tokens))).compile('x','Development sentence.',g,tokens)

def test_and_participants_form_a_group_without_separate_event_assumption():
 c=compile('(l / lift-01 :ARG0 (a / and :op1 (p / person :name (n / name :op1 "Alice")) :op2 (q / person :name (n2 / name :op1 "Bob"))) :ARG1 (i / piano))')
 assert sum(v.kind=='group'for v in c.variables)==1
 assert sum(a.predicate=='member'for a in c.atoms)==2
 assert sum(a.predicate=='concept'and a.arguments[1]=='lift-01'for a in c.atoms)==1

def test_or_participants_choose_one_witness_and_do_not_require_both():
 c=compile('(e / eat-01 :ARG0 (p / person) :ARG1 (o / or :op1 (a / apple) :op2 (b / banana)))')
 v=c.metadata['node_variables'];assert v['o']==v['a']==v['b']
 def find(n):return n.op=='or'or any(find(x)for x in n.children)
 assert find(c.expression)

def test_shared_named_participant_description_is_present_in_each_or_branch():
 c=compile('(o / or :op1 (s / sing-01 :ARG0 (p / person :name (n / name :op1 "Alice"))) :op2 (d / dance-01 :ARG0 p))')
 by={a.id:a for a in c.atoms}
 def ids(e):return{e.atom_id}if e.op=='atom'else set().union(*(ids(x)for x in e.children))
 def visit(e):
  if e.op=='or':assert all(any(by[i].predicate=='name'and by[i].arguments[1]=='Alice'for i in ids(x))for x in e.children)
  for x in e.children:visit(x)
 visit(c.expression)

def test_external_or_operand_reference_refuses_ambiguous_identity():
 with pytest.raises(PredicateError)as e:
  compile('(e / eat-01 :ARG0 (p / person :topic (a / apple)) :ARG1 (o / or :op1 a :op2 (b / banana)))')
 assert e.value.code=='coordination_reentry'

def test_urge_keeps_the_requested_stop_inside_a_directive():
 c=compile('(u / urge-01 :ARG1 (p / person) :ARG2 (s / stop-01 :ARG0 p :ARG1 (r / run-01 :ARG0 p)))')
 assert[s['kind']for s in c.metadata['scopes'].values()]==['directive','cessation']
 assert c.metadata['node_scopes']['s']!='world'and c.metadata['node_scopes']['r']!='world'

def test_need_and_cancel_do_not_assert_their_inner_actions():
 for frame,kind in [('need-01','requirement'),('cancel-01','cancellation')]:
  c=compile(f'(x / {frame} :ARG0 (p / person) :ARG1 (r / run-01 :ARG0 p))')
  assert next(iter(c.metadata['scopes'].values()))['kind']==kind

def test_degree_operator_accepts_a_bare_predicate_value():
 ts=[dict(id=1,text='higher',lemma='high',upos='ADJ',head=0,deprel='root',feats=None)]
 c=compile('(h / have-degree-91 :ARG1 (w / water) :ARG2 (v / high-02))',ts)
 assert any(a.predicate=='role'and a.arguments[2]=='predicate:high-02'for a in c.atoms)

def test_unknown_nonfactive_complement_still_refuses():
 with pytest.raises(PredicateError,match='No scope policy'):compile('(x / unknown-01 :ARG1 (r / run-01))')

def native(c,predicate):
 from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground
 from probabilistic_verification.direct_backend import DirectVerifier
 from probabilistic_verification.compact_backend import compact_prolog_program
 assignment={v.name:'candidate:'+v.name for v in c.variables};obs={}
 for a in c.atoms:
  key=canonical_key('synthetic',a,assignment,'visual_depiction');state=predicate(a);obs[key]=Observation(key,tuple(float(i==state)for i in['supported','refuted','unknown']),False,a.text)
 e=Evidence('synthetic',{v:[x]for v,x in assignment.items()},{v:True for v in assignment},obs)
 return DirectVerifier([ground(c,e)],learned=False,program_builder=compact_prolog_program).predict()[0]['distribution']

def test_native_or_cannot_drop_the_shared_alice_name_in_its_second_branch():
 c=compile('(o / or :op1 (s / sing-01 :ARG0 (p / person :name (n / name :op1 "Alice"))) :op2 (d / dance-01 :ARG0 p))')
 actual=native(c,lambda a:'refuted'if a.predicate=='name'else'supported')
 assert actual['refuted']==pytest.approx(1)

def test_native_and_group_requires_both_members():
 c=compile('(l / lift-01 :ARG0 (a / and :op1 (p / person) :op2 (q / person)))');members=[a.id for a in c.atoms if a.predicate=='member']
 actual=native(c,lambda a:'refuted'if a.id==members[-1]else'supported')
 assert actual['refuted']==pytest.approx(1)

def test_native_or_participant_can_match_the_second_alternative_alone():
 c=compile('(e / eat-01 :ARG0 (p / person) :ARG1 (o / or :op1 (a / apple) :op2 (b / banana)))')
 actual=native(c,lambda a:'refuted'if a.predicate=='concept'and a.arguments[1]=='apple'else'supported')
 assert actual['supported']==pytest.approx(1)


def test_argument_or_keeps_inverse_modifiers_inside_their_own_branch():
 graph = ('(v / be-located-at-91 :ARG1 (m / video) :ARG2 (o / or'
          ' :op1 (p / pier :ARG1-of (p2 / pave-01)) :op2 (a / area :mod (t / terminal))))')
 claim = AMRCompiler(coordination=True, local_or_modifiers=True).compile('pier', 'Pier or terminal.', graph)
 atoms = {atom.id: atom for atom in claim.atoms}
 def disjunction(expr):
  if expr.op == 'or':
   return expr
  return next((item for child in expr.children if (item := disjunction(child))), None)
 def concepts(expr):
  if expr.op == 'atom':
   atom = atoms[expr.atom_id]
   return {atom.arguments[1]} if atom.predicate == 'concept' else set()
  return set().union(*(concepts(child) for child in expr.children))
 assert [concepts(child) for child in disjunction(claim.expression).children] == [
     {'pier','pave-01'}, {'area','terminal'}]


def test_argument_or_rejects_an_external_reference_to_its_inverse_modifier():
 graph = ('(v / be-located-at-91 :ARG1 (m / video :topic p2) :ARG2 (o / or'
          ' :op1 (p / pier :ARG1-of (p2 / pave-01)) :op2 (a / area)))')
 with pytest.raises(PredicateError) as error:
  AMRCompiler(coordination=True, local_or_modifiers=True).compile('pier', 'Pier or terminal.', graph)
 assert error.value.code == 'coordination_reentry'
