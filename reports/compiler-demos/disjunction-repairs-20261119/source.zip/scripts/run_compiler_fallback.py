"""Run the fixed fallback on all originals, using saved parser/rewrite outputs."""
import argparse,copy,json,logging,time
from pathlib import Path
from collections import Counter
from prepare_compiler_fallback import ROOT,RUN,BASE,rows,dump
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.compiler_extensions import OPTIONS
from probabilistic_verification.split_alignment import compose_aligned
from probabilistic_verification.structured_rewrite import checked_rewrite_formula
from probabilistic_verification.compiler_fallback import compile_claim,serialize,check_output
from probabilistic_verification.fallback_amr import compile_fallback_amr,prepare_fallback
from run_amr_types import inspect


def cached_rewrite(record,source):
    if source is None:return dict(status='unsupported',code='rewrite_uncached',reason='No response exists under the single frozen rewrite condition; no alternate prompt is selected.')
    proposal=source['proposal'];parts=[]
    if source.get('validation_error'):return dict(status='unsupported',code='invalid_model_output',reason=source['validation_error'],proposal=proposal)
    if proposal['action']in{'keep','refuse'}:return dict(status='unsupported',code='model_'+proposal['action'],reason='The frozen model supplied no simpler claim.',proposal=proposal)
    for clause in source['clauses']:
        part=copy.deepcopy(clause.get('record'))
        if not part:return dict(status='unsupported',code='sentence_parse',reason=clause.get('parse_error','No parsed component.'),proposal=proposal)
        part['compiler_context']=dict(original_text=record['text'])
        if len(source['clauses'])==1:part['claim_id']=record['claim_id']
        output=check_output(part,compile_one(part));parts.append(dict(id=clause['id'],text=clause['text'],result=output))
        if output['status']!='compiled':return dict(status='unsupported',code='rewrite_component',reason=clause['id']+': '+output.get('reason','Component refused.'),components=parts,proposal=proposal)
    formula=checked_rewrite_formula(record,source['clauses'],proposal.get('formula'))
    if len(parts)==1:
        result=copy.deepcopy(parts[0]['result']);result['components']=parts;result['proposal']=proposal;return result
    original=copy.deepcopy(record);original['compiler_options']=dict(OPTIONS,event_coreference=True,logical_operators=True)
    claim,proposal,trace=compose_aligned(record['claim_id'],original,source['clauses'],
        {c['id']:c['result']for c in parts},max_clauses=12,formula=formula)
    return dict(status='compiled',**serialize(claim),components=parts,proposal=proposal,alignment=trace)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True,help='New run directory for the comparison.')
    args=parser.parse_args()
    output_run=args.output.resolve()
    if output_run==RUN:
        parser.error('The frozen experiment is reserved. Supply a new output directory.')
    output_run.mkdir(parents=True,exist_ok=True)
    logging.getLogger('penman').setLevel(logging.ERROR)
    inputs=rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')
    old_amr={r['claim_id']:r for r in rows(BASE/'corpus.jsonl')}
    rewrites={r['claim_id']:r for r in rows(ROOT/'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl')}
    fresh=RUN/'missing_rewrites/parsed.jsonl'
    if fresh.exists():
        additions={r['claim_id']:r for r in rows(fresh)}
        planned={r['claim_id']for r in json.loads((RUN/'missing_rewrites/routing.json').read_text())}
        assert additions.keys()==planned and not(additions.keys()&rewrites.keys())
        rewrites.update(additions)
    # Output every claim exactly once. AMR and rewrite calls are lazy, after
    # preceding failures, even though their annotations are already cached.
    start=time.perf_counter();outputs=[];amr_outputs=[]
    def amr(record):
        out=inspect(record,old_amr[record['claim_id']]['raw'],compiler=compile_fallback_amr,prepare=prepare_fallback)
        amr_outputs.append(out);return out
    for record in inputs:
        outputs.append(compile_claim(record,srl=compile_one,amr=amr,rewrite=lambda r,attempts:cached_rewrite(r,rewrites.get(r['claim_id']))))
    for name,data in [('corpus.jsonl',outputs),('amr_attempts.jsonl',amr_outputs)]:
        (output_run/name).write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n'for r in data))
    selected=Counter(r['selected_stage']or'abstained'for r in outputs);failures=[r for r in outputs if r['parsing_status']!='compiled']
    summary=dict(total=len(outputs),selected=dict(selected),automatic_compiled=sum(r['parsing_status']=='compiled'for r in outputs),parsing_abstentions=len(failures),srl_attempts=2375,amr_attempts=len(amr_outputs),rewrite_attempts=sum(any(a['stage']=='rewrite'for a in r['attempts'])for r in outputs),
        final_stops=dict(Counter(r['attempts'][-1].get('code')for r in failures)),seconds=time.perf_counter()-start,models_called=0,fresh_rewrite_responses=len(rows(RUN/'missing_rewrites/raw.jsonl'))if(RUN/'missing_rewrites/raw.jsonl').exists()else 0,retained_pool=1981,promotions=0,policy='Fixed automatic SRL -> AMR -> one cached rewrite. No meaning-review, media or claim-label routing. Parse abstention is not evidence unknown.')
    dump(output_run/'summary.json',summary);dump(output_run/'remaining.json',[dict(claim_id=r['claim_id'],text=r['text'],attempts=[{k:a.get(k)for k in ['stage','status','code','reason','shared_checks']}for a in r['attempts']])for r in failures]);print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
