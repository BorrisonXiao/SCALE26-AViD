#!/usr/bin/env python3
"""Build the current compiler demos, full outputs and linked daily progress."""
import json,shutil,re
from html import escape as esc
from pathlib import Path
from string import Template
from build_reviewed_compilation_report import slim

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_relations_20261105'
ASSETS=ROOT/'scripts/report_assets'

def read(name):return json.loads((RUN/name).read_text())
def rows(path):return {r['claim_id']:r for r in map(json.loads,path.read_text().splitlines())}
def view(row):return slim(dict(row,status='compiled')if 'program'in row else row)
def link(href,label):return '<a href="'+esc(href,quote=True)+'">'+esc(label)+'</a>'
def demo_link(cid,label):return link('compiler-demos.html?claim='+cid+'#walkthroughs',label)
def table(n,title,headers,data):
    return '<div class="table-wrap"><table><caption>Table '+str(n)+'. '+esc(title)+'</caption><thead><tr>'+''.join('<th>'+esc(h)+'</th>'for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(v)+'</td>'for v in row)+'</tr>'for row in data)+'</tbody></table></div>'

def latest_work(summary):
    h='<h2>5 November: completed compiler repairs</h2><p>The compiler still follows one semantic-role/dependency path over the unchanged original sentences. This round adds bounded repairs using explicit source words and grammatical links.</p>'
    h+='<div class="metric-row"><div class="box"><strong>'+format(summary['executable'],',')+'</strong><p>Programs generated<br>Schema and syntax checked</p></div><div class="box"><strong>'+format(summary['accepted'],',')+'</strong><p>Pass current content checks<br>Words and clause/list structure</p></div><div class="box"><strong>179</strong><p>Candidates flagged for review<br>173 word alerts and 6 clause alerts</p></div></div><p>The last compiler revision recovered 58 content-check passes, from 1,866 to 1,924. The frozen compiler has 291 passing regression tests; these tests do not measure dataset semantic accuracy.</p>' 
    h+='<h3 id="step-omissions">1. Numbers and appositions</h3><ul>'
    for cid,text in [('Tg0UxWYuPeJ0_385','Keep Robot1 and Robot2 distinct using their identifiers.'),('TbJqMFkNxARY_165','Keep both bounds in between67 and75 boxes.'),('TjHepwuhkYFA_1042','Keep the complete1.2 million resident count.'),('T2G_ACMxR_I4_1145','Keep roughly2.8 million miles as an approximate distance.'),('T2G_ACMxR_I4_1220','Keep volcanic cone after the full name Mons Littrow.'),('TW4OYA3RN-Hw_1769','Retain a publisher description and both publications under it.')]:
        text=text.replace('Robot1','Robot 1').replace('Robot2','Robot 2').replace('between67','between 67').replace('and75','and 75').replace('complete1.2','complete 1.2').replace('roughly2.8','roughly 2.8')
        h+='<li>'+demo_link(cid,text)+'</li>'
    h+='</ul><p>Postposed numbers are retained only for declared label nouns or joined names such as IM-1. The broader first rule incorrectly treated dates and tallies as identifiers; it was restricted before the final run. A number attached to the wrong noun, as in the remaining lane-three case, stays flagged. Newly recovered nominal coordination is restricted to AND; OR alternatives stay unresolved.</p>'
    h+='<h3 id="step-clauses">2. Lists and embedded clauses</h3><ul>'
    for cid,text in [('TQEmEycTI0RQ_863','Build all six named people, with party descriptions and the co-leader subgroup.'),('TjHepwuhkYFA_1053','Represent the plates meeting at the Sagaing Fault, rather than a where-clause string.'),('TgR_u37mCoQ4_1868','Keep the changed event inside describes how, rather than asserting it separately.')]:h+='<li>'+demo_link(cid,text)+'</li>'
    h+='</ul><p>Both duplicated leader-list claims now pass the structural checks. Two of the eight prior hidden-clause alerts pass. The describes-how example still has imperfect noun-phrase attachments; the list pronouns remain unresolved.</p><h3 id="remaining-clauses">Six clause cases remain flagged</h3><p>These candidates are saved for inspection and are refused by strict compilation. The diagnoses below are assistant interpretations of their saved parses.</p>'
    for r in read('clause_review.json')['remaining']:
        h+='<article class="remaining-case"><p class="muted">'+esc(r['claim_id'])+'</p><blockquote>'+esc(r['text'])+'</blockquote><p>'+esc(r['reason'])+'</p>'+link('compiler-demos.html?claim='+r['claim_id']+'#outputs','Inspect the saved candidate')+'</article>'
    h+='<h3>Next-stage comparison</h3><ol><li>Freeze the current compiler for a small original-versus-rewrite comparison—measure faithful recoveries under the same compiler.</li><li>Review original, rewrite and predicates together—preserve information before new relation learning or DeepProbLog experiments.</li></ol><p>'+link('#stopping-point','Read the stopping decision and 40-case pilot proposal')+'. Reference resolution and larger-program profiling remain pending. That earlier audit ran no model or rewrite experiment; the subsequent rewrite pilot is reported in its own tab.</p>' 
    return h

def results(summary):
    reasons=summary['refusal_reasons']
    from compiler_alert_review_report import history_html
    h='<h2>Measured results and limits</h2>'+history_html()
    h+=table(2,'5 November repair comparison on all 2,375 cached claims. These are compilation outcomes, not accuracy.',['Outcome','Before 5 November repairs','Current compiler'],[
        ('Pass current content checks',summary['before_accepted'],summary['accepted']),('Programs generated',summary['before_executable'],summary['executable']),
        ('Lexical coverage alerts',227,reasons['coverage_omission']),('Hidden-clause alerts',8,reasons['opaque_clause']),('Incomplete-list alerts',2,reasons.get('incomplete_enumeration',0)),('Parser/compiler refusals',272,2375-summary['executable'])])
    h+='<p><b>'+str(summary['recovered'])+' newly pass; no earlier pass or executable candidate is lost.</b> '+str(summary['changed_programs'])+' program hashes change. All 11 programs previously rated faithful by the user remain byte-identical and pass the checks. No unexpected exceptions occurred.</p>'
    h+=table(3,'Remaining refusal and review reasons. Lexical/structural alerts retain diagnostic candidates.',['Reason','Claims'],[(esc(k.replace('_',' ')),v)for k,v in sorted(reasons.items(),key=lambda p:-p[1])])
    h+='<p>Among the 173 lexical alerts, 49 contain missing proper-name tokens and 45 contain missing numbers; categories overlap. These include typed dates/values, malformed labels, omitted clauses and complex coordination. The failure ledger retains every missing token.</p>'
    review=read('targeted_review.json')
    h+=table(4,'5 November post-freeze review of 12 seeded recoveries. Only the local repair is judged.',['Claim','Target retained','Remaining issue or limitation'],[(link('compiler-demos.html?claim='+r['claim_id']+'#outputs',r['claim_id']),'Yes',esc(r['remaining_limit']))for r in review['cases']])
    h+='<p>All twelve inspected targets are retained. This compiler-author review is not independent human gold or a whole-claim accuracy estimate. All corpus texts were processed previously. Remaining defects include a transition treated as a noun, an opaque back-up phrase and nominal suspicion semantics. No held-out semantic gain is claimed.</p>'
    h+='<p><b>291 regression checks pass</b>, including native DeepProbLog tests of both range bounds and the earlier OCR/speech policy. The new range tests supply group counts of 70,80 or unavailable: they return supported, refuted or insufficient evidence. They do not count objects in media. Minimum/maximum count properties, quantities and appositive relations still require matching evidence functions.</p>'
    h+='<p>The final cached census took 30.96 seconds, excluding upstream parsing and input loading. This is not inference/training cost profiling. The initial source freeze preceded the 12-case review. A later code audit restricted recovered nominal coordination to AND, leaving OR alternatives unresolved. The final guard changes no saved corpus output; the earlier freeze is preserved. Original inputs and the earlier exploratory outputs are retained. Historical source archives remain available.</p><h3>Downloads and reproduction</h3><p>'
    downloads=[('README.md','Implementation'),('source.zip','Source and exact replay'),('analysis.json','Statistics'),('targeted_review.json','Targeted review'),('remaining_cases.json','All remaining failures'),('clause_review.json','Clause diagnoses'),('daily_log.json','Daily log records'),('tests.xml','Tests')]
    h+=' · '.join(link('compiler-demos/'+p,label)for p,label in downloads)
    h+='</p><p>'+link('compiler-demos/history/content-recovery-20261105-source.zip','Previous round’s original source archive')+' · '+link('verification-pipeline.html#next-steps','Current checklist')+'</p>'
    return h

def daily_log(data):
    h='<h2>Daily log</h2><p>'+esc(data['note'])+'</p>'
    for day in data['days']:
        h+='<section class="progress-day" id="day-'+day['date']+'"><h3><time datetime="'+day['date']+'">'+day['date']+'</time></h3><ul>'
        for item in day['items']:h+='<li>'+esc(item['text'])+' '+link(item['href'],item['label'])+'</li>'
        h+='</ul></section>'
    return h+'<p>Dates use America/New_York. Future work remains listed separately from completed entries. Log format follows '+link('https://borrisonxiao.github.io/ai2ai-duplex-report/daily-log.html','the supplied daily-log example')+'.</p>'

def main():
    from compiler_alert_review_report import latest_review_html,review_html,write_downloads
    import claim_rewrite_report as rewrite
    import claim_split_report as split
    import split_alignment_report as alignment
    import compiler_report_summary as overview
    import full_rewrite_report as full
    import semantic_components_report as components
    import compiler_readiness_report as readiness
    import compiler_repairs_report as repairs
    import compiler_feedback_report as feedback
    import compiler_structural_report as structural
    import amr_composition_report as amr
    import amr_refinement_report as refinement
    import amr_correction_report as correction
    import amr_types_report as typed
    import amr_contexts_report as contexts
    import compiler_fallback_report as fallback
    import compiler_coverage_report as coverage
    import compiler_scope_report as scopes
    import logical_form_review_report as benchmark
    import disjunction_repairs_report as disjunction
    summary=read('analysis.json');current=rows(RUN/'results.jsonl');previous=rows(RUN/'baseline.jsonl');inputs=rows(RUN/'inputs.jsonl')
    folder=ROOT/'site/reports/compiler-demos';folder.mkdir(parents=True,exist_ok=True)
    demos=[];baselines={}
    for c in read('demo_explanations.json')['cases']:
        cid=c['claim_id'];path=c['baseline_path']
        if path not in baselines:baselines[path]=rows(ROOT/path)
        old=baselines[path][cid];after=current[cid];assert inputs[cid]['text']==old['text']==after['text']and after['status']=='compiled',cid
        tokens=inputs[cid]['tokens'];selected=[t for t in tokens if t['id']in c['token_ids']]
        demos.append(dict(c,text=after['text'],old_label=c['baseline_label'],old_status=old['status'],old_code=old.get('code'),before_output=view(old),current_output=view(after),
            parser_links=[dict(word=t['text'],pos=t['upos'],relation=t['deprel'],parent=next((u['text']for u in tokens if u['id']==t['head']),'root'))for t in selected]))
    dump=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')
    dump(folder/'examples.json',demos);index=[];chunks=[]
    for i,(cid,row)in enumerate(current.items()):
        old=previous[cid];changed=row.get('program_sha256')!=old.get('program_sha256');name='cases-'+str(i//100).zfill(2)+'.json'
        index.append(dict(claim_id=cid,text=row['text'],accepted=row['status']=='compiled',review='program'in row and row['status']!='compiled',refused='program'not in row,changed=changed,recovered=row['status']=='compiled'and old['status']!='compiled',chunk=name))
        if i%100==0:chunks.append([])
        before,after=view(old),view(row)
        chunks[-1].append(dict(claim_id=cid,before=before,after=after if after!=before else None,status=row['status'],code=row.get('code'),reason=row.get('reason'),structural_alerts=row.get('structural_alerts',[]),coverage=row.get('coverage'),program_unchanged=not changed))
    dump(folder/'index.json',index)
    for i,chunk in enumerate(chunks):dump(folder/('cases-'+str(i).zfill(2)+'.json'),chunk)
    for name in ['analysis.json','changed_cases.json','recovered_cases.json','new_review_flags.json','targeted_review.json','remaining_cases.json','clause_review.json','daily_log.json','native_demo.json','frozen_manifest.json','tests.xml']:
        shutil.copy2(RUN/name,folder/name)
    shutil.copy2(ROOT/'docs/content_relations_compilation.md',folder/'README.md')
    write_downloads()
    rewrite.write_downloads()
    split.write_downloads()
    alignment.write_downloads()
    overview.write_downloads()
    full.write_downloads()
    components.write_downloads()
    readiness.write_downloads()
    repairs.write_downloads()
    feedback.write_downloads()
    structural.write_downloads()
    amr.write_downloads()
    refinement.write_downloads()
    correction.write_downloads()
    typed.write_downloads()
    contexts.write_downloads()
    fallback.write_downloads()
    coverage.write_downloads()
    scopes.write_downloads()
    benchmark.write_downloads()
    disjunction.write_downloads()
    log=json.loads((ROOT/'docs/project_notes/daily_log.json').read_text())
    (folder/'daily_log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2)+'\n')
    tabs=[('current-work','Overview'),('walkthroughs','Examples'),('outputs','All claims'),('daily-progress','Daily log'),('history','History')]
    tab_html='<div class="tabs" role="tablist" aria-label="Report views">'+''.join('<button role="tab" id="tab-'+key+'" aria-selected="'+str(key=='current-work').lower()+'" aria-controls="'+key+'" data-tab="'+key+'">'+label+'</button>'for key,label in tabs)+'</div>'
    page=Template((ASSETS/'compiler_demos_template.html').read_text()).substitute(style=(ASSETS/'claim_output_view.css').read_text()+(ASSETS/'compiler_demos.css').read_text(),
        demo_count=len(demos),accepted=format(summary['accepted'],','),previous=format(summary['before_accepted'],','),executable=format(summary['executable'],','),tabs=tab_html,status_header=disjunction.status_html(),latest_work=disjunction.overview_html(),pipeline_outputs=coverage.inspector_html()+fallback.inspector_html(),pool_description=contexts.status_html()+' The All claims view remains the previous retained compiler pool. AMR comparison outputs are separate and are not pooled into it.',history_links=overview.history_links(),historical_status=benchmark.overview_html().replace('id="remaining-failures"','id="earlier-benchmark-review"')+scopes.overview_html().replace('id="remaining-failures"','id="earlier-scope-repair"')+coverage.overview_html().replace('id="remaining-failures"','id="earlier-coverage"')+coverage.examples_html()+fallback.overview_html().replace('id="remaining-failures"','id="strict-fallback-overview"')+'<h2>Earlier context/noun experiment and count audit</h2>'+contexts.overview_html().replace('id="remaining-failures"','id="amr-contexts-status"')+contexts.examples_html()+'<h2>Earlier source-based predicate typing</h2>'+typed.overview_html().replace('id="remaining-failures"','id="amr-types-status"')+typed.examples_html()+'<h2>Earlier bounded AMR corrections and inference fix</h2>'+correction.overview_html().replace('id="remaining-failures"','id="amr-correction-status"')+correction.examples_html()+'<h2>Earlier source-preserving AMR comparison</h2>'+refinement.overview_html().replace('id="remaining-failures"','id="source-amr-status"')+refinement.examples_html()+'<h2>Initial AMR comparison (before source preservation)</h2>'+amr.overview_html().replace('id="remaining-failures"','id="initial-amr-status"')+amr.examples_html()+'<h2>Earlier partial-parse and structural correction experiment</h2>'+structural.overview_html().replace('id="remaining-failures"','id="partial-before-amr"')+structural.examples_html()+'<h2>Earlier typed field-edit experiment</h2>'+feedback.overview_html().replace('id="remaining-failures"','id="feedback-before-structural"')+'<h2>Earlier compiler repairs and rewrite pilots</h2>'+repairs.overview_html().replace('id="remaining-failures"','id="repairs-before-feedback"')+repairs.examples_html()+'<h2>Earlier compiler stopping-point proposal (superseded)</h2><p>Compiler work remains the current priority. Earlier recommendations below are historical.</p>'+readiness.overview_html().replace('id="remaining-failures"','id="readiness-history"')+readiness.examples_html()+'<h2>Earlier value and phrase experiments</h2>'+components.examples_html()+'<h2>Earlier frozen-model run on449 failures</h2><p>The inspector below preserves the earlier model requests and compilation outputs. Current shared-component results are above; no new model responses were generated.</p>'+full.examples_html()+components.overview_html().replace('id="remaining-failures"','id="components-before-readiness"')+full.overview_html().replace('id="remaining-failures"','id="full-rewrite-before-components"')+'<h2>Earlier 31-case comparison and pre-sweep diagnosis</h2><p>Historical results below precede the complete449-case experiment. See Overview for current numbers.</p>'+overview.overview_html().replace('id="remaining-failures"','id="remaining-failures-before-full-run"')+alignment.html()+split.latest_html()+rewrite.latest_html()+latest_review_html()+latest_work(summary),results=results(summary),alert_review=review_html(),rewrite_pilot=rewrite.html(),sentence_splitting=disjunction.examples_html()+benchmark.examples_html()+scopes.examples_html()+fallback.demos_html(),initial_splitting=split.html(),daily_log=daily_log(log),
        output_script=(ASSETS/'claim_output_view.js').read_text(),demo_script=(ASSETS/'compiler_demos.js').read_text()+'\n'+(ASSETS/'compiler_alert_review.js').read_text()+'\n'+(ASSETS/'claim_rewrite.js').read_text()+'\n'+(ASSETS/'claim_split.js').read_text()+'\n'+(ASSETS/'split_alignment.js').read_text()+'\n'+(ASSETS/'full_rewrite.js').read_text()+'\n'+(ASSETS/'semantic_components.js').read_text()+'\n'+(ASSETS/'compiler_readiness.js').read_text()+'\n'+(ASSETS/'compiler_repairs.js').read_text()+'\n'+(ASSETS/'compiler_feedback.js').read_text()+'\n'+(ASSETS/'compiler_investigation.js').read_text()+'\n'+(ASSETS/'amr_composition.js').read_text()+'\n'+(ASSETS/'amr_refinement.js').read_text()+'\n'+(ASSETS/'amr_correction.js').read_text()+'\n'+(ASSETS/'amr_types.js').read_text()+'\n'+(ASSETS/'amr_contexts.js').read_text()+'\n'+(ASSETS/'compiler_fallback.js').read_text()+'\n'+(ASSETS/'compiler_coverage.js').read_text())
    # Number the static assets in document order after consolidating sections.
    for tag,label in [('caption','Table'),('figcaption','Figure')]:
        count=[0]
        def number(match):
            count[0]+=1
            return "<"+tag+">"+label+" "+str(count[0])+"."
        page=re.sub(r"<"+tag+r">"+label+r" \d+\.",number,page)
    (ROOT/'site/reports/compiler-demos.html').write_text(page)
    print('Built',len(demos),'demos,2375 saved outputs and',len(log['days']),'daily entries.')

if __name__=='__main__':main()
