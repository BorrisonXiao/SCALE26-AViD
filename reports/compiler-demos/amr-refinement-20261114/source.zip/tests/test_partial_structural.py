import copy,json
from pathlib import Path
import jsonschema,pytest
from probabilistic_verification.compiler_repairs import compile_one
from probabilistic_verification.compiler_feedback import current_form,schema
from probabilistic_verification.logical_form_edits import clean
from probabilistic_verification.partial_parse import capture
from probabilistic_verification.structural_edits import proposal_schema,apply_edits,additional_issues,request
ROOT=Path(__file__).resolve().parents[1]
RECORDS={r['claim_id']:r for r in map(json.loads,(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl').read_text().splitlines())}

def test_partial_capture_does_not_change_refusal_or_source_annotations():
 r=RECORDS['TInVWzp25aIM_68'];original=copy.deepcopy(r);before=compile_one(r);assert before['status']=='unsupported'and not current_form(before)
 partial=capture(r);assert partial['partial_form'];assert partial['partial_details']['requires_repair'];assert r==original;assert compile_one(r)==before

def test_unfinished_embedded_events_are_not_new_world_roots():
 r=RECORDS['TInVWzp25aIM_68'];p=capture(r);f=p['partial_form'];assert f['formula']['op']=='event';assert f['formula']['predicate']!='livestream';assert p['partial_details']['error']

def test_missing_srl_does_not_invent_a_draft():
 r=copy.deepcopy(RECORDS['TInVWzp25aIM_68']);r['srl']['frames']=[];r['tokens'][0]['head']=0;r['tokens'][0]['upos']='PUNCT'
 p=capture(r);assert p['partial_details']['requires_repair'];assert p['partial_details']['error'];assert p['partial_form']is None

def toy():
 f=dict(kind='claim',entities=[dict(id='x1',text='Boats',type='group')],formula=dict(op='entity',ref='x1'))
 r=dict(text='Boats float.',tokens=[dict(id=1,text='Boats',lemma='boat',upos='NOUN'),dict(id=2,text='float',lemma='float',upos='VERB')])
 return r,f

def test_subtree_replacement_is_typed_and_preserves_entity_declarations():
 r,f=toy();node=dict(op='event',id='e2',predicate='float',anchor='float',arguments={'ARG0':'x1'});data=dict(action='edit',edits=[dict(op='replace',path='/formula',value=node)])
 jsonschema.Draft202012Validator(proposal_schema(f,schema(r,f))).validate(data);out=apply_edits(f,data['edits']);assert out['formula']==node and out['entities']==f['entities'];assert f['formula']['op']=='entity'

def test_subtree_decoder_rejects_unknown_predicates_and_unbounded_edits():
 r,f=toy();s=proposal_schema(f,schema(r,f));bad=dict(action='edit',edits=[dict(op='replace',path='/formula',value=dict(op='event',id='e2',predicate='invented',anchor='float',arguments={'ARG0':'x1'}))])
 with pytest.raises(jsonschema.ValidationError):jsonschema.Draft202012Validator(s).validate(bad)
 bad=dict(action='edit',edits=[dict(op='replace',path='/kind',value='claim')]*5)
 with pytest.raises(jsonschema.ValidationError):jsonschema.Draft202012Validator(s).validate(bad)

def test_numeric_modifier_cannot_target_a_robot():
 r=RECORDS['Tg0UxWYuPeJ0_378'];f=clean(current_form(compile_one(r)));entities={e['text']:e for e in f['entities']};lane=entities['lane'];robot=entities['Robot'];lane.setdefault('relations',[]).append(dict(role='nummod',target=robot['id']));hard,_=additional_issues(r,f);assert any(x['code']=='numeric_modifier_type'for x in hard)

def test_purpose_requires_the_actual_car_not_the_other_car_or_group():
 r=RECORDS['TMrQshDs8aH0_745'];f=clean(current_form(compile_one(r)));hard,_=additional_issues(r,f);assert any(x['code']=='shared_subject'for x in hard)
 child=f['formula']['propositions'][0]['body'];child['arguments']['ARG0']='x2';hard,_=additional_issues(r,f);assert not any(x['code']=='shared_subject'for x in hard)

def test_explicit_purpose_subject_can_differ_from_parent_subject():
 r=RECORDS['Tg0UxWYuPeJ0_342'];f=clean(current_form(compile_one(r)));hard,_=additional_issues(r,f);assert not any(x['code']=='shared_subject'for x in hard)

def test_a_dependency_only_subject_is_advisory():
 r=RECORDS['Tg0UxWYuPeJ0_433'];f=clean(current_form(compile_one(r)));f['entities'].append(dict(id='x1',text='Robot 1',type='entity'));f['formula']['arguments']['nsubj']='x1';hard,advice=additional_issues(r,f);assert not any(x['code']=='subject_binding'for x in hard);assert any(x['code']=='subject_binding'for x in advice)

def test_original_error_is_identical_in_both_retry_branches():
 r=RECORDS['TMrQshDs8aH0_745'];d=compile_one(r);f=clean(current_form(d));old=dict(current_form=f,feedback=[dict(code='shared_subject',message='bind car')],direct_compiler_error={k:d.get(k)for k in['code','reason']})
 guided,_=request(r,old,schema(r,f),True);generic,_=request(r,old,schema(r,f),False);assert guided['direct_compiler_error']==generic['direct_compiler_error'];assert 'compiler_feedback'in guided and'compiler_feedback'not in generic;assert 'root'not in guided['logical_form_format']

def test_text_literals_reject_measurement_metadata_but_measurements_keep_it():
 from probabilistic_verification.strict_literal_types import typed_schema
 r,f=toy();s=typed_schema(r,f);node=dict(op='event',id='e2',predicate='float',anchor='float',arguments={'ARG0':'x1','ARGM-EXT':dict(kind='text',value='high',unit='boats')});data=dict(f,action='repair',formula=node)
 with pytest.raises(jsonschema.ValidationError):jsonschema.Draft202012Validator(s).validate(data)
 node['arguments']['ARGM-EXT']=dict(kind='measurement',value='2',unit='m',attribute='height');jsonschema.Draft202012Validator(s).validate(data)

def test_argument_roles_use_standard_vocabulary_and_literal_kind_discrimination():
 from probabilistic_verification.strict_literal_types import typed_schema
 r,f=toy();f['formula']=dict(op='event',id='e2',predicate='float',anchor='float',arguments={'ARG0':'x1','ARGM-TMP':dict(kind='time',value='today')});s=typed_schema(r,f);p=proposal_schema(f,s)
 patch=dict(action='edit',edits=[dict(op='replace',path='/formula/arguments/ARGM-TMP/kind',value='time')]);jsonschema.Draft202012Validator(p).validate(patch)
 f['formula']['arguments']['ARGM-目的']='x1'
 with pytest.raises(jsonschema.ValidationError):jsonschema.Draft202012Validator(s).validate(dict(f,action='repair'))

def test_text_clause_is_not_a_substitute_for_an_embedded_event():
 from probabilistic_verification.structural_edits import literal_clause_issues
 r=RECORDS['Txf2EdqOg1SQ_2176'];bad=dict(kind='text',value='sufficient to force adults to crawl');assert literal_clause_issues(r,bad)
 assert not literal_clause_issues(r,dict(kind='text',value='wind speed'))
 assert not literal_clause_issues(r,dict(kind='verbatim_text',value='sufficient to force adults to crawl'))

def test_neural_faithfulness_input_does_not_include_review_labels_or_reasons():
 from neural_faithfulness_diagnostic import messages
 r=dict(text='A boat floats.',form={'kind':'claim'},gold=True,review='PRIVATE_GOLD_REASON',artifact_sha256='LABEL_LEAK_TEST')
 sent=messages(r);user=json.loads(sent[1]['content']);assert set(user)=={'claim','logical_form'};assert 'PRIVATE_GOLD_REASON'not in str(sent)and'LABEL_LEAK_TEST'not in str(sent)
