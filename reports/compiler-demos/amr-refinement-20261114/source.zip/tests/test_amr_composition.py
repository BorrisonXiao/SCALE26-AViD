"""Semantic invariants of the fixed AMR conversion, independent of real labels."""
import pytest
from probabilistic_verification.amr_composition import AMRCompiler
from probabilistic_verification.predicate_compilation import PredicateError
from probabilistic_verification.logic import Evidence,ground,prolog_program

def compile(graph,text='A development sentence.',tokens=()):return AMRCompiler().compile('example',text,graph,tokens)
def triples(c):return[(a.predicate,a.arguments[:a.arguments.index('context_owner')]if'context_owner'in a.arguments else a.arguments[:-4])for a in c.atoms]

def test_inverse_modifier_keeps_patient_not_agent():
 c=compile('(d / document :ARG1-of (s / sign-01 :ARG0 (p / person :name (n / name :op1 "Trump"))))')
 v=c.metadata['node_variables'];assert('role',(v['s'],'ARG1',v['d']))in triples(c)
 assert('role',(v['s'],'ARG0',v['p']))in triples(c)
 assert('name',(v['p'],'Trump'))in triples(c)
 assert len(c.metadata['translations'])==8

def test_reentrant_person_is_one_variable_and_one_concept():
 c=compile('(a / and :op1 (s / sing-01 :ARG0 (p / person)) :op2 (d / dance-01 :ARG0 p))')
 v=c.metadata['node_variables'];roles=[a for a in c.atoms if a.predicate=='role']
 assert len({a.arguments[2]for a in roles})==1
 assert sum(a.predicate=='concept'and a.arguments[0]==v['p']for a in c.atoms)==1
 assert c.expression.op in{'and','exists'}

def test_quoted_speaker_does_not_imply_audio_or_world_content():
 c=compile('(s / say-01 :ARG0 (p / person :name (n / name :op1 "Alice")) :ARG1 (l / leave-01 :ARG0 p))')
 assert c.metadata['node_scopes']['l']=='c1'
 assert c.metadata['scopes']['c1']['route']=='unspecified'
 assert all(a.arguments[-3]!='world'for a in c.atoms if a.predicate=='concept'and a.arguments[1]=='leave-01')

def test_purpose_keeps_actor_identity_without_world_action():
 c=compile('(d / drive-01 :ARG0 (p / person) :purpose (l / learn-01 :ARG0 p))')
 assert c.metadata['node_scopes']['l']=='c1'
 v=c.metadata['node_variables'];assert('role',(v['l'],'ARG0',v['p']))in triples(c)

def test_scoped_conditions_depend_on_all_source_owner_assignments():
 c=compile('(s / say-01 :ARG0 (p / person) :ARG1 (w / want-01 :ARG0 p :ARG1 (l / leave-01 :ARG0 p)))')
 v=c.metadata['node_variables'];a=next(a for a in c.atoms if a.predicate=='concept'and a.arguments[1]=='leave-01')
 assert a.arguments[2:-4]==('context_owner',v['w'],'context_owner',v['s'])

def test_a_reentrant_whole_content_entity_keeps_an_executable_reference():
 c=compile('(s / say-01 :ARG0 (p / person :name (n / name :op1 "Alice")) :ARG1 p)')
 v=c.metadata['node_variables'];a=next(a for a in c.atoms if a.predicate=='reference')
 assert a.arguments[:3]==(v['p'],'context_owner',v['s'])

def test_inverse_negative_predicate_keeps_its_actor_role_under_not():
 c=compile('(w / weather :ARG0-of (h / have-03 :polarity - :ARG1 (c / cloud)))')
 by_id={a.id:a for a in c.atoms};h=c.metadata['node_variables']['h'];locations=[]
 def walk(e,negative=False):
  if e.op=='atom'and by_id[e.atom_id].predicate=='role'and by_id[e.atom_id].arguments[0]==h:locations.append(negative)
  for x in e.children:walk(x,negative or e.op=='not')
 walk(c.expression);assert locations==[True,True]

def test_inverse_modal_head_cannot_bypass_its_scope_policy():
 with pytest.raises(PredicateError,match='two contexts'):
  compile('(l / leave-01 :ARG0 (p / person) :ARG1-of (w / want-01 :ARG0 p))')

def test_declaration_position_does_not_move_the_speaker_inside_its_quote():
 a=compile('(s / say-01 :ARG0 (p / person) :ARG1 (l / leave-01 :ARG0 p))')
 b=compile('(s / say-01 :ARG1 (l / leave-01 :ARG0 (p / person :ARG0-of s)))')
 assert a.metadata['node_scopes']==b.metadata['node_scopes']

def test_map_content_has_depiction_scope_and_preserves_time_role():
 c=compile('(s / show-01 :ARG0 (m / map) :ARG1 (f / spread-01 :time (d / date-entity :year 2025)))')
 assert c.metadata['scopes']['c1']['kind']=='depiction'
 assert c.metadata['node_scopes']['d']=='c1'

def test_noun_phrase_or_refuses_instead_of_asserting_both_objects():
 with pytest.raises(PredicateError,match='group/distributive'):
  compile('(e / eat-01 :ARG0 (p / person) :ARG1 (o / or :op1 (a / apple) :op2 (b / banana)))')

def test_clause_or_preserved():
 c=compile('(o / or :op1 (r / rain-01) :op2 (s / snow-01))')
 def has(e):return e.op=='or'or any(has(x)for x in e.children)
 assert has(c.expression)

def test_unknown_event_complement_never_flattened():
 with pytest.raises(PredicateError,match='No scope policy'):
  compile('(x / unfamiliar-01 :ARG1 (l / leave-01))')

def test_predicate_suffix_does_not_turn_a_source_noun_into_a_clause():
 tokens=[dict(id=1,text='movement',lemma='movement',upos='NOUN',head=0,deprel='root',feats=None)]
 c=compile('(p / promote-02 :ARG1 (m / movement-07))','movement',tokens)
 assert c.metadata['node_scopes']['m']=='world'

def test_shared_name_literal_does_not_merge_different_people():
 c=compile('(a / and :op1 (r / run-01 :ARG0 (p / person :name (n / name :op1 "Alex"))) :op2 (w / walk-01 :ARG0 (p2 / person :name n)))')
 v=c.metadata['node_variables'];assert v['p']!=v['p2']
 assert len([a for a in c.atoms if a.predicate=='name'])==2

def test_generalized_quantifier_not_accepted_as_plain_property():
 with pytest.raises(PredicateError,match='quantifier'):
  compile('(p / person :quant all)')

def test_scope_policy_preserves_wind_causer_and_crawl_actor():
 c=compile('(a / appear-02 :ARG1 (s / suffice-01 :ARG0 (w / wind) :ARG1 (f / force-01 :ARG0 w :ARG1 (p / person) :ARG2 (c / crawl-01 :ARG0 p))))')
 assert[c.metadata['scopes'][s]['kind']for s in['c1','c2','c3']]==['appearance','sufficiency','result']
 v=c.metadata['node_variables'];assert('role',(v['f'],'ARG0',v['w']))in triples(c)
 assert('role',(v['c'],'ARG0',v['p']))in triples(c)

def test_explicit_depiction_boundary():
 c=compile('(s / show-01 :ARG0 (v / video) :ARG1 (r / run-01 :ARG0 (p / person)))')
 assert c.metadata['scopes']['c1']['kind']=='depiction'
 assert c.metadata['scopes']['c1']['route']=='visual_depiction'

def test_unsupported_literal_source_refuses():
 with pytest.raises(PredicateError,match='opaque text'):
  compile('(s / say-01 :ARG0 (p / person) :ARG1 "Alice left")')

def test_tense_from_source_separates_landed_and_is_landing():
 graph='(l / land-01 :ARG1 (a / spacecraft))'
 past=[dict(id=1,text='landed',lemma='land',upos='VERB',head=0,deprel='root',feats='Tense=Past|VerbForm=Fin')]
 ongoing=[dict(id=1,text='is',lemma='be',upos='AUX',head=2,deprel='aux',feats='Tense=Pres|VerbForm=Fin'),dict(id=2,text='landing',lemma='land',upos='VERB',head=0,deprel='root',feats='Tense=Pres|VerbForm=Part')]
 a=compile(graph,'landed',past);b=compile(graph,'is landing',ongoing)
 assert a.metadata['temporal']!=b.metadata['temporal']
 assert next(x for x in b.atoms if x.predicate=='temporal').arguments[2]=='progressive'

def test_native_backend_no_evidence_returns_unknown():
 from deepproblog.model import Model
 from deepproblog.engines import ExactEngine
 from deepproblog.query import Query
 from problog.logic import Term
 c=compile('(r / rain-01)')
 evidence=Evidence('constructed',{v.name:['candidate:'+v.name]for v in c.variables},{v.name:True for v in c.variables},{})
 gp=ground(c,evidence);program,names=prolog_program([gp],learned=False)
 model=Model(program,[],load=False);model.set_engine(ExactEngine(model));result=model.solve([Query(Term('verdict',Term(names['example']),Term('unknown')))])[0]
 assert sum(float(v)for v in result.result.values())==pytest.approx(1)
