import copy,re
from probabilistic_verification.amr_source_alignment import prepare_source,source_checks,add_source_conditions
from probabilistic_verification.amr_composition import AMRCompiler

def record(text,lemmas=None,plurals=()):
 ts=[];lemmas=lemmas or{}
 for i,m in enumerate(re.finditer(r'\w+(?:[-.]\w+)*|[^\w\s]',text),1):
  word=m[0];lemma=lemmas.get(word,word.lower());ts.append(dict(id=i,text=word,lemma=lemma,upos='NOUN',head=0,deprel='root',start_char=m.start(),end_char=m.end(),feats='Number=Plur'if word in plurals else None))
 return dict(claim_id='x',text=text,tokens=ts)
def parse(r,g):
 raw,info,a=prepare_source(r,g);c=AMRCompiler(coordination=True,source_alignment=a).compile('x',r['text'],raw,r['tokens']);return raw,info,add_source_conditions(c,r,info,a)

def test_written_quote_stays_bound_and_does_not_assert_its_inner_events():
 r=record('A sign reads "No robots arrive in 25 minutes".',{'reads':'read','robots':'robot'})
 g='(r / read-01 :ARG0 (s / sign) :ARG1 (a / arrive-01 :polarity - :ARG1 (p / robot)))'
 before=copy.deepcopy(r);raw,info,c=parse(r,g)
 assert r==before and 'arrive-01'not in c.metadata['concepts'].values()
 q=next(a for a in c.atoms if a.predicate=='written_text');assert q.arguments[1]=='No robots arrive in 25 minutes'and q.arguments[-1]=='ocr_assertion'
 assert not source_checks(r,raw,info)

def test_a_human_reading_action_is_not_deleted():
 r=record('A man reads a sign "News".',{'reads':'read'})
 raw,info,c=parse(r,'(r / read-01 :ARG0 (m / man) :ARG1 (s / sign))')
 assert'read-01'in c.metadata['concepts'].values()
 assert any(a.predicate=='written_text'for a in c.atoms)

def test_ordinary_quoted_speech_is_not_coerced_to_ocr():
 r=record('Alice says "Bob left".',{'says':'say'})
 raw,info,c=parse(r,'(s / say-01 :ARG0 (p / person :name (n / name :op1 "Alice")) :ARG1 (l / leave-01 :ARG0 (b / person :name (n2 / name :op1 "Bob"))))')
 assert not info['inscriptions']and not any(a.predicate=='written_text'for a in c.atoms)

def test_quotation_repair_refuses_to_discard_unquoted_location():
 r=record('A sign reads "News" beside a wall.',{'reads':'read'})
 raw,info,a=prepare_source(r,'(r / read-01 :ARG0 (s / sign) :ARG1 (n / news) :location (w / wall))')
 assert any(x['code']=='quote_extra_content'for x in info['issues'])
 assert'wall'in raw

def test_am_pm_and_elapsed_are_preserved_without_guessing_field_units():
 r=record('Starts at 12:00am.');raw,info,a=prepare_source(r,'(d / date-entity :time "12:00")')
 assert'00:00:00'in raw and info['normalisations'][0]['kind']=='clock_meridiem'
 r=record('Video begins at T+ 57:24.');raw,info,a=prepare_source(r,'(d / date-entity :time "00:57:24")')
 assert'T+ 57:24'in raw and info['normalisations'][0]['kind']=='elapsed_code'

def test_two_matching_source_clocks_are_not_assigned_arbitrarily():
 r=record('From 12:00am to 12:00pm.');raw,info,a=prepare_source(r,'(d / date-entity :time "12:00")')
 assert any(x['code']=='clock_alignment'for x in info['issues'])and'12:00'in raw

def test_generated_name_and_million_instead_of_metres_are_flagged():
 r=record('Phillies lineup at 100m.');raw,info,a=prepare_source(r,'(l / lineup :quant 100000000 :poss (p / person :name (n / name :op1 "Phillipines")))')
 codes={i['code']for i in source_checks(r,raw,info)}
 assert{'name_source_mismatch','numeric_source_mismatch','measurement_binding'}<=codes

def test_complete_mass_and_percentage_values_pass_necessary_checks():
 for text,g in [('100kg payload.','(p / payload :quant (m / mass-quantity :quant 100 :unit (k / kilogram)))'),('25 percent tariff.','(t / tariff :mod (p / percentage-entity :value 25))')]:
  r=record(text);raw,info,a=prepare_source(r,g);assert not source_checks(r,raw,info)

def test_plural_feature_is_inside_the_existing_source_context():
 r=record('Video shows people.',{'shows':'show'},plurals=['people'])
 raw,info,c=parse(r,'(s / show-01 :ARG0 (v / video) :ARG1 (p / person))')
 a=next(a for a in c.atoms if a.predicate=='grammatical_number');assert a.arguments[-3]=='c1'and'context_owner'in a.arguments

def test_no_clouds_keeps_single_witness_absence_without_a_plural_size_requirement():
 r=record('Weather has no clouds.',{'clouds':'cloud'},plurals=['clouds']);cloud=next(t for t in r['tokens']if t['text']=='clouds');next(t for t in r['tokens']if t['text']=='no')['head']=cloud['id']
 raw,info,c=parse(r,'(w / weather :ARG0-of (h / have-03 :polarity - :ARG1 (c / cloud)))')
 assert not any(a.predicate=='grammatical_number'for a in c.atoms)
 assert any(f.get('executable')is False for f in c.metadata['source_features'])

def test_timezone_label_is_credited_to_its_executable_literal():
 r=record('At 11:20 UTC.');next(t for t in r['tokens']if t['text']=='UTC')['upos']='PROPN'
 raw,info,a=prepare_source(r,'(d / date-entity :time "11:20" :timezone "UTC")')
 assert not source_checks(r,raw,info)

def test_noun_tag_on_lands_does_not_make_the_landing_event_plural():
 r=record('Rocket lands.',{'lands':'land'},plurals=['lands'])
 raw,info,c=parse(r,'(l / land-01 :ARG1 (r / rocket))')
 assert not any(a.predicate=='grammatical_number'for a in c.atoms)

def test_plural_years_are_encoded_by_quantity_without_pluralising_the_unit():
 r=record('Four years.',{'years':'year'},plurals=['years'])
 raw,info,c=parse(r,'(t / temporal-quantity :quant 4 :unit (y / year))')
 assert not any(a.predicate=='grammatical_number'for a in c.atoms)
