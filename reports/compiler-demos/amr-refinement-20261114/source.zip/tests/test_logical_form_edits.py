import pytest
from probabilistic_verification.logical_form_edits import apply,allowed_paths

def draft():return {'kind':'claim','entities':[{'id':'x1','text':'boats','type':'group'}],'formula':{'op':'entity','ref':'x1'}}
def test_add_modifier_does_not_change_the_existing_parse():
 f=draft();out=apply(f,[{'op':'add','path':'/entities/0/properties','value':[{'role':'mod','value':'Small'}]}]);assert f==draft();assert out['formula']==f['formula'];assert out['entities'][0]['properties'][0]['value']=='Small'
def test_whole_form_replacement_is_not_allowed():
 with pytest.raises(ValueError):apply(draft(),[{'op':'replace','path':'/formula','value':{}}])
def test_paths_include_missing_entity_fields_and_append():
 paths=allowed_paths(draft());assert '/entities/0/properties'in paths and '/entities/-'in paths and '/formula'not in paths
def test_replace_requires_an_existing_field():
 with pytest.raises(KeyError):apply(draft(),[{'op':'replace','path':'/entities/0/quantity','value':{}}])
def test_pointer_escaping_and_sequential_edits():
 f={'kind':'claim','entities':[],'formula':{'a/b':'old'}};assert apply(f,[{'op':'replace','path':'/formula/a~1b','value':'new'}])['formula']['a/b']=='new'

def test_three_edits_restore_the_wind_subject_and_cause_without_rebuilding():
 import json
 from pathlib import Path
 from probabilistic_verification.compiler_feedback import current_form,schema
 from probabilistic_verification.logical_form_edits import clean,evaluate
 root=Path(__file__).resolve().parents[1];run=root/'exp/probabilistic_verification/compiler_feedback_20261112'
 read=lambda p:list(map(json.loads,p.read_text().splitlines()))
 r=next(r for r in read(run/'pilot_inputs.jsonl')if r['claim_id']=='Txf2EdqOg1SQ_2176');d=next(x for x in read(run/'direct_all.jsonl')if x['claim_id']==r['claim_id'])
 f=clean(current_form(d));patch=dict(action='edit',edits=[dict(op='add',path='/entities/-',value=dict(id='x3',text='wind speed',type='entity')),dict(op='add',path='/formula/arguments/ARG0',value='x3'),dict(op='add',path='/formula/propositions/0/body/arguments/ARG0',value='x3')])
 out,result,feedback=evaluate(r,f,patch,schema(r,current_form(d)));assert result['status']=='compiled',feedback;assert len(out['entities'])==2;assert out['formula']['arguments']['ARG0']==out['formula']['propositions'][0]['body']['arguments']['ARG0']=='x3'

def test_decoder_schema_checks_the_type_of_each_edit_value():
 import jsonschema
 from probabilistic_verification.compiler_feedback import schema
 from probabilistic_verification.logical_form_edits import edit_schema
 r={'text':'Boats float.','tokens':[{'id':1,'text':'Boats','lemma':'boat','upos':'NOUN'},{'id':2,'text':'float','lemma':'float','upos':'VERB'}]};s=edit_schema(draft(),schema(r));jsonschema.Draft202012Validator.check_schema(s)
 good={'action':'edit','edits':[{'op':'add','path':'/entities/0/properties','value':[{'role':'mod','value':'Small'}]}]};jsonschema.validate(good,s)
 bad={'action':'edit','edits':[{'op':'add','path':'/entities/0/properties','value':{'predicate':'invented','args':[]}}]}
 with pytest.raises(jsonschema.ValidationError):jsonschema.validate(bad,s)

def test_decoder_disallows_deleting_required_fields_or_replacing_absent_fields():
 import jsonschema
 from probabilistic_verification.compiler_feedback import schema
 from probabilistic_verification.logical_form_edits import edit_schema
 r={'text':'Boats float.','tokens':[{'id':1,'text':'Boats','lemma':'boat','upos':'NOUN'},{'id':2,'text':'float','lemma':'float','upos':'VERB'}]};s=edit_schema(draft(),schema(r))
 for op in [{'op':'remove','path':'/entities/0/id'},{'op':'replace','path':'/entities/0/properties','value':[]}]:
  with pytest.raises(jsonschema.ValidationError):jsonschema.validate({'action':'edit','edits':[op]},s)
