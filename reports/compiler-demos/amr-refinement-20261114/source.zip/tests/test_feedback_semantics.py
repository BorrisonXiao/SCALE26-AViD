"""Source-backed feedback for wrong scope and participant assignment."""
import copy,json
from pathlib import Path
from probabilistic_verification.feedback_semantics import issues
from probabilistic_verification.compiler_feedback import inspect,schema
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_feedback_20261112'
read=lambda p:list(map(json.loads,p.read_text().splitlines()))
RECORDS={r['claim_id']:r for r in read(RUN/'pilot_inputs.jsonl')+read(RUN/'extension_inputs.jsonl')}
CANDIDATES={r['claim_id']:r for r in read(RUN/'enriched/feedback_final.jsonl')+read(RUN/'extension/feedback_final.jsonl')}
def sample(cid):return copy.deepcopy(RECORDS[cid]),json.loads(CANDIDATES[cid]['raw'])
def test_actual_livestream_is_rejected_when_it_should_be_a_goal():
 r=RECORDS['TInVWzp25aIM_68'];f=json.loads(next(x for x in read(RUN/'compact/feedback_final.jsonl')if x['claim_id']==r['claim_id'])['raw']);assert any(x['code']=='purpose_scope'for x in issues(r,f))
def test_wind_speed_cannot_be_only_an_adverbial_adjunct():
 r,f=sample('Txf2EdqOg1SQ_2176');assert any(x['code']=='subject_binding'for x in issues(r,f))
def test_unquoted_text_does_not_hide_a_missing_negation():
 r,f=sample('TFOEIehBwT8Q_530');assert any(x['code']=='unquoted_verbatim'for x in issues(r,f))
def test_condition_cannot_be_copied_into_a_typed_time_literal():
 r,f=sample('TzzhcBIczf_M_2068');assert any(x['code']=='clause_as_value'for x in issues(r,f))
def test_invented_beijing_event_does_not_match_recently_anchor():
 r=RECORDS['Tg0UxWYuPeJ0_447'];f=json.loads(next(x for x in read(RUN/'compact/generic_final.jsonl')if x['claim_id']==r['claim_id'])['raw']);assert any(x['code']=='predicate_anchor'for x in issues(r,f))
def test_evacuation_subject_is_retained_in_its_core_role():
 r,f=sample('TInVWzp25aIM_87');assert not issues(r,f)
def test_simple_possible_power_loss_is_not_rejected():
 r,f=sample('TzF9M4kZ3Pys_314');assert not issues(r,f)
def test_real_quote_is_not_rejected_as_unquoted():
 r=next(r for r in read(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')if r['claim_id']=='Tg0UxWYuPeJ0_343')
 f=dict(entities=[dict(id='x1',text='man',type='entity')],formula=dict(op='event',id='e2',predicate='exclaim',anchor='exclaims',arguments={'ARG0':'x1','ARG1':{'kind':'verbatim_text','value':'just like that!'}}));assert not issues(r,f)


def test_generated_id_cannot_be_hidden_in_a_typed_value():
 r=RECORDS['TInVWzp25aIM_68'];f=dict(entities=[],formula=dict(op='event',id='e3',predicate='rely',anchor='relying',arguments={'ARG1':{'kind':'comparison','value':'e4'}}));assert any(x['code']=='id_as_literal'for x in issues(r,f))
