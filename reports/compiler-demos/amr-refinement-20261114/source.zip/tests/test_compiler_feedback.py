"""Logical-form correction validates source IDs and reports actionable failures."""
import copy,json
from pathlib import Path
import pytest,jsonschema
from probabilistic_verification.compiler_feedback import schema,inspect,reference_errors,request
ROOT=Path(__file__).resolve().parents[1]
ROWS={r['claim_id']:r for r in map(json.loads,(ROOT/'exp/probabilistic_verification/compiler_repairs_20261112/pilot_inputs.jsonl').read_text().splitlines())}
def simple():
 r=copy.deepcopy(ROWS['TInVWzp25aIM_68']);return r,dict(action='repair',kind='claim',entities=[dict(id='x1',text='Angupaul1',type='entity'),dict(id='x6',text='portable charger',type='entity')],formula=dict(op='event',id='e3',predicate='rely',anchor='relying',arguments=dict(ARG0='x1',ARG1='x6'),propositions=[dict(role='ARGM-PRP',kind='purpose',route='unspecified',body=dict(op='event',id='e8',predicate='livestream',anchor='livestream',arguments=dict(ARG0='x1')))]))
def test_source_specific_schema_is_valid_and_handles_backend_constructions():
 for r in ROWS.values():jsonschema.Draft202012Validator.check_schema(schema(r))
def test_valid_form_reaches_native_problog_compilation():
 r,f=simple();out,errors=inspect(r,f,schema(r));assert out['status']=='compiled',(out,errors);assert 'query('in out['program']
def test_references_identify_exact_argument_path():
 _,f=simple();f['entities']=f['entities'][:1];errors=reference_errors(f);assert errors[0]['path']=='$.formula.arguments.ARG1'and errors[0]['allowed']==['x1']
def test_bare_name_is_rejected_by_the_grammar_contract():
 r,f=simple();f['formula']['arguments']['ARG0']='Angupaul1';out,errors=inspect(r,f,schema(r));assert out['code']=='schema'and errors
@pytest.mark.parametrize('word',['invented_predicate','move'])
def test_predicate_inventory_cannot_copy_an_unrelated_example(word):
 r,f=simple();f['formula']['predicate']=word;assert inspect(r,f,schema(r))[0]['code']=='schema'
def test_missing_purpose_verb_is_not_covered_by_a_nominal_event():
 r,f=simple();f['formula'].pop('propositions');f['entities'].append(dict(id='x8',text='livestream',type='event'));f['formula']['arguments']['ARG2']='x8';out,errors=inspect(r,f,schema(r));assert out['status']=='unsupported'and any(e['code']=='missing_clause_event'for e in errors)
def test_request_carries_previous_form_and_actual_feedback():
 r,f=simple();d=request(r,dict(proposed_form=f,code='test',reason='example'),schema(r),previous='previous',feedback=[dict(path='$.formula')]);assert d['current_form']and d['previous_output']=='previous'and d['compiler_feedback'][0]['path']=='$.formula'
def test_refusal_stays_a_refusal():
 r,_=simple();out,feedback=inspect(r,dict(action='refuse',kind='claim',entities=[],formula=None),schema(r));assert out['code']=='model_refuse'and feedback==[]


def test_normalized_date_is_credited_only_to_its_matching_source_span():
 r=copy.deepcopy(ROWS['TInVWzp25aIM_87']);f=dict(action='repair',kind='claim',entities=[dict(id='x1',text='People',type='group'),dict(id='x8',text='Joint Base Elemendorf-Richardson, Alaska',type='entity')],formula=dict(op='event',id='e3',predicate='evacuate',anchor='evacuated',arguments={'ARG2':'x1','ARGM-DIR':'x8','ARGM-TMP':{'kind':'date','value':'2025-10-15'}},properties=[{'role':'preposition:ARGM-DIR','value':'to'},{'role':'preposition:ARGM-TMP','value':'on'}]))
 out,errors=inspect(r,f,schema(r));assert out['status']=='compiled',errors
 f['formula']['arguments']['ARGM-TMP']['value']='2025-10-16';out,errors=inspect(r,f,schema(r));assert out['status']=='unsupported'


def test_detailed_feedback_points_to_unused_declarations_without_changing_status():
 r,f=simple();f['entities'].append(dict(id='x7',text='portable',type='entity'))
 basic,_=inspect(r,f,schema(r));out,errors=inspect(r,f,schema(r),detailed=True)
 assert out==basic
 assert any(e['code']=='unused_entity'and e['path']=='$.entities[2]'for e in errors)
