import pytest
from probabilistic_verification.parse_mixture import infer

def test_interpretations_are_alternatives_not_an_or_over_meanings():
 r=infer({'a':0.6,'b':0.4},{'oa':[0.9,0.1,0],'ob':[0.1,0.9,0]},{'a':'oa','b':'ob'});assert r['distribution']['supported']==pytest.approx(.58);assert r['or_of_observations']==pytest.approx(.91);assert sum(r['distribution'].values())==pytest.approx(1)

def test_unparsed_mass_does_not_become_insufficient_media_evidence():
 r=infer({'a':.8},{'o':[.5,.25,.25]},{'a':'o'},unparsed=.2);assert r['distribution']==pytest.approx(dict(supported=.4,refuted=.2,unknown=.2,parsing_abstention=.2))

def test_shared_observation_is_not_copied_into_independent_facts():
 r=infer({'a':.5,'b':.5},{'shared':[.9,.1,0]},{'a':'shared','b':'shared'});assert r['distribution']['supported']==pytest.approx(.9);assert r['or_of_observations']==pytest.approx(.9);assert r['program'].count('::observation(o0,supported)')==1

def test_all_unparsed_is_a_valid_result_without_any_evidence():
 r=infer({}, {}, {}, unparsed=1.0);assert r['distribution']==pytest.approx(dict(supported=0,refuted=0,unknown=0,parsing_abstention=1))
