"""Contrasts for modifiers, reference identity, scope and coordination."""
import copy,itertools,json
from pathlib import Path
import pytest
from probabilistic_verification.compiler_repairs import compile_repaired,compile_one
from probabilistic_verification.split_composition import nodes
from probabilistic_verification.compilation_followup import walk_events
from probabilistic_verification.claim_split import validate_split
from probabilistic_verification.structured_rewrite import validate
from probabilistic_verification.split_alignment import compose_aligned
from probabilistic_verification.compiler_extensions import OPTIONS
from probabilistic_verification.logical_form_v2 import ScopedCompiler
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_repairs_20261112'
PROBES={r['claim_id'].removeprefix('repair_'):r for r in map(json.loads,(RUN/'probe_parsed.jsonl').read_text().splitlines())}
ORIGINALS={r['claim_id']:r for r in map(json.loads,(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl').read_text().splitlines())}
def claim(name):return compile_repaired(copy.deepcopy(PROBES[name]))[0]
def source(cid):return copy.deepcopy(ORIGINALS[cid])
def test_existing_dependency_modifier_survives_a_shorter_first_srl_argument():
 c=claim('small');entities=c.metadata['logical_form']['entities'];vehicle=next(e for e in entities if e['text']=='vehicles')
 assert dict(role='mod',value='Small')in vehicle['properties']
 assert any(e['predicate']=='survey'for e in walk_events(c.metadata['logical_form']))
@pytest.mark.parametrize('name',['reflexive','plural'])
def test_reflexive_subject_and_object_are_one_referent(name):
 c=claim(name);f=c.metadata['logical_form'];assert not any(e['text'].lower()in{'itself','themselves'}for e in f['entities'])
 reposition=next(e for e in walk_events(f)if e['predicate']=='reposition');values=[v for v in reposition['arguments'].values()if isinstance(v,str)]
 assert len(values)>=2 and len(set(values))==1
 assert not any(a.predicate=='resolve_reference'for a in c.atoms)
def test_other_robot_is_not_collapsed_into_subject():
 f=claim('other').metadata['logical_form'];e=next(walk_events(f));values=[v for v in e['arguments'].values()if isinstance(v,str)];assert len(set(values))==2
def test_wrong_pos_embedded_reflexive_is_not_guessed_as_matrix_subject():
 r=compile_one(copy.deepcopy(PROBES['embedded']));assert r['status']=='unsupported'and r['code']=='unresolved_reflexive'
def test_srl_subject_disambiguates_a_spurious_second_ud_subject():
 c,_=compile_repaired(source('TzzhcBIczf_M_2093'));event=next(e for e in walk_events(c.metadata['logical_form'])if e['predicate']=='propel')
 assert event['arguments']['ARG0']==event['arguments']['ARG1']
@pytest.mark.parametrize('name',['likely','likely_past'])
def test_likelihood_keeps_the_location_inside_its_context(name):
 c=claim(name);f=c.metadata['logical_form'];assert f['formula']['op']=='qualified'and f['formula']['operator']=='likely'
 assert any(a.predicate in{'entity_relation','be'}and any(x.startswith('q1::')for x in a.arguments)for a in c.atoms)
 assert not any(a.predicate=='entity_relation'and 'world'in a.arguments for a in c.atoms)
 if name=='likely_past':assert any(v['tense']=='past'for v in c.metadata['temporal'].values())
def test_quoted_likelihood_does_not_qualify_the_narrating_claim():
 c=claim('quote_likely');assert c.metadata['logical_form']['formula']['op']=='event'
 assert any('Outages are likely.'in x for a in c.atoms for x in a.arguments)
def test_quote_is_the_content_of_the_exclamation():
 c=claim('exclaim');f=c.metadata['logical_form'];assert f['formula']['predicate']=='exclaim'
 assert f['formula']['arguments']['ARG1']==dict(kind='verbatim_text',value='just like that!')
 assert len(c.metadata['events'])==1 and next(iter(c.metadata['events'].values()))['route']=='speech_assertion'
def test_quoted_or_does_not_create_claim_disjunction():
 c=claim('or_quote');assert c.metadata['logical_form']['formula']['op']=='event'
 assert not any(n.get('op')=='or'for n in nodes(c.metadata['logical_form']['formula']))
def test_ocr_quote_is_not_a_government_entity():
 c,_=compile_repaired(source('TFOEIehBwT8Q_453'));f=c.metadata['logical_form'];assert f['formula']['predicate']=='write'
 assert not any(e['text']=='government'for e in f['entities'])
 assert any(v.get('kind')=='verbatim_text'and v['value']=='Narco government'for v in f['formula']['arguments'].values()if isinstance(v,dict))
 assert next(e for e in c.metadata['events'].values()if e['predicate']=='write')['route']=='ocr_assertion'
@pytest.mark.parametrize('formula',[dict(op='or',children=[1,1]),dict(op='and',children=[1,3]),1])
def test_rewrite_formula_cannot_omit_or_duplicate_sentences(formula):
 with pytest.raises(ValueError):validate(dict(action='rewrite',sentences=['A boat moves.','A car stops.'],formula=formula))
def test_nested_and_or_formula_is_valid_and_explicit():
 validate(dict(action='rewrite',sentences=['A.','B.','C.'],formula=dict(op='or',children=[1,dict(op='and',children=[2,3])])))
def combined_shots(operator):
 parts={k:compile_one(copy.deepcopy(PROBES[name]))for k,name in [('c1','shots'),('c2','explosions')]};original=source('TFOEIehBwT8Q_532');original['compiler_options']=dict(OPTIONS,event_coreference=True,logical_operators=True)
 clauses=[dict(id=k,text=parts[k]['text'])for k in parts]
 return compose_aligned('shots_test',original,clauses,parts,formula=dict(op=operator,children=[1,2]))[0]
def native(c,decide,domains=None,complete=True):
 from probabilistic_verification.logic import Evidence,Observation,canonical_key,ground
 from probabilistic_verification.direct_backend import DirectVerifier
 domains=domains or{v.name:[v.name.lower()]for v in c.variables};e=Evidence('constructed',domains,{v.name:complete for v in c.variables},{})
 for atom in c.atoms:
  names=[v.name for v in c.variables if v.name in atom.arguments]
  for values in itertools.product(*(domains[n]for n in names)):
   assignment=dict(zip(names,values));state=decide(atom,assignment);key=canonical_key(e.media_id,atom,assignment,e.route)
   e.observations[key]=Observation(key,{'supported':(1.,0.,0.),'refuted':(0.,1.,0.),'unknown':(0.,0.,1.)}[state],False,'Constructed truth assignment, not media evidence')
 return DirectVerifier([ground(c,e,max_expansions=10000)],learned=False).predict()[0]['distribution']
@pytest.mark.parametrize('operator,expected',[('or','supported'),('and','refuted')])
def test_native_or_requires_one_alternative_and_does_not_add_an_explosion_count(operator,expected):
 c=combined_shots(operator);assert c.metadata['logical_form']['formula']['op']==operator
 groups=[e for e in c.metadata['logical_form']['entities']if e.get('quantity')];assert len(groups)==1 and groups[0]['text']=='shots'
 result=native(c,lambda a,s:'refuted'if a.predicate=='fire'else'supported');assert result[expected]==pytest.approx(1.)
@pytest.mark.parametrize('contents,expected',[('partial','supported'),('full','refuted'),('unknown','unknown')])
def test_native_qualified_absence_checks_fully_in_water(contents,expected):
 c=claim('none_fully');assert any(n.get('op')=='not_exists'for n in nodes(c.metadata['logical_form']['formula']))
 be=next(e for e in c.metadata['events'].values()if e['predicate']=='be');assert 'ARG2'in be['arguments']
 def state(a,s):
  if a.predicate=='property'and a.arguments[1:3]==('advmod','fully'):return {'partial':'refuted','full':'supported','unknown':'unknown'}[contents]
  return 'supported'
 result=native(c,state);assert result[expected]==pytest.approx(1.)
def test_plain_absence_does_not_allow_a_partly_submerged_container():
 assert native(claim('none'),lambda a,s:'supported')['refuted']==pytest.approx(1.)
def evacuation():
 parsed=next(r for r in map(json.loads,(ROOT/'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl').read_text().splitlines())if r['claim_id']=='TInVWzp25aIM_87')
 parts={c['id']:compile_one(copy.deepcopy(c['record']))for c in parsed['clauses']};r=source(parsed['claim_id']);r['compiler_options']=dict(OPTIONS,event_coreference=True)
 return compose_aligned('evacuation',r,parsed['clauses'],parts)[0]
@pytest.mark.parametrize('destination,expected',[('same','supported'),('different','refuted')])
def test_native_nominal_reference_uses_the_original_evacuation_event(destination,expected):
 c=evacuation();refs=c.metadata['event_references'];assert refs and len({r['variable']for r in refs})==1
 event=refs[0]['variable'];domains={v.name:['evacA','evacB']if v.name==event else[v.name.lower()]for v in c.variables}
 def state(a,s):
  args=[s.get(x,x)for x in a.arguments]
  if a.predicate=='evacuate':return 'supported'if args[0]=='evacA'else'refuted'
  if a.predicate=='be':return 'supported'if args[args.index('ARG1')+1]==('evacA'if destination=='same'else'evacB')else'refuted'
  return 'supported'
 assert native(c,state,domains)[expected]==pytest.approx(1.)
def test_event_reference_cannot_escape_a_modal_context():
 c=evacuation();f=copy.deepcopy(c.metadata['logical_form']);children=f['formula']['children'];children[0]=dict(op='qualified',operator='possible',body=children[0])
 with pytest.raises(Exception,match='earlier event in the same context'):ScopedCompiler().compile('modal_evacuate',c.text+' may',list(c.tokens),f)


def test_relative_clause_after_yelling_is_not_speech_content():
 c,_=compile_repaired(source('Txf2EdqOg1SQ_2272'))
 assert not any(n.get('kind')=='assertion'for n in nodes(c.metadata['logical_form']['formula']))


def test_quoted_writing_keeps_each_explicit_surface():
 c,_=compile_repaired(source('TFOEIehBwT8Q_536'))
 assert {'graffiti','barricades'}<={e['text']for e in c.metadata['logical_form']['entities']}
 assert not any(e['id'].startswith('span')for e in c.metadata['logical_form']['entities'])
