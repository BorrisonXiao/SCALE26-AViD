import pytest
from probabilistic_verification.representation import Expression as E
from probabilistic_verification.logic import Observation,GroundProgram,enumerate_probability
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.compact_backend import compact_prolog_program

@pytest.mark.parametrize('op',['and','or','evidence'])
def test_exact_states_and_sharing_match_exhaustive_worlds(op):
 a=Observation('a',(.3,.2,.5),False,'a');b=Observation('b',(.6,.1,.3),False,'b');x,y=E.atom(a.id),E.atom(b.id)
 p=GroundProgram('check',E.combine('or',[E.combine('and',[E(op,(x,y)),x]),E.negate(y)]),{a.id:a,b.id:b},[],[])
 actual=DirectVerifier([p],learned=False,program_builder=compact_prolog_program).predict()[0]['distribution']
 assert actual==pytest.approx(enumerate_probability(p),abs=1e-10)

@pytest.mark.parametrize('state',['supported','refuted','unknown'])
def test_constant_states_and_negation_are_total(state):
 p=GroundProgram('constant',E.negate(E.constant(state)),{},[],[])
 result=DirectVerifier([p],learned=False,program_builder=compact_prolog_program).predict()[0]['distribution']
 assert sum(result.values())==pytest.approx(1)
 assert result[{'supported':'refuted','refuted':'supported','unknown':'unknown'}[state]]==pytest.approx(1)

def test_unknown_gradient_matches_the_previous_exact_encoding():
 import torch
 a=Observation('learned-a',(.4,.3,.3),True,'a');b=Observation('learned-b',(.5,.2,.3),True,'b')
 p=GroundProgram('gradient',E.combine('and',[E.atom(a.id),E.atom(b.id)]),{a.id:a,b.id:b},[],[])
 grads=[];probs=[]
 for builder in [None,compact_prolog_program]:
  v=DirectVerifier([p],learned=True,**({'program_builder':builder}if builder else{}));q=v.query('gradient','unknown');z=v.model.solve([q])[0].result[q.query];(-z.log()).backward();grads.append(v.classifier.layers[-1].weight.grad.detach().clone());probs.append(float(z.detach()))
 assert probs[0]==pytest.approx(probs[1],abs=1e-10)
 assert torch.allclose(grads[0],grads[1],atol=1e-10)and grads[1].norm()>0

def test_no_neural_outcome_is_pruned_at_zero_or_one():
 a=Observation('edge',(0.,0.,1.),True,'edge');p=GroundProgram('x',E.combine('and',[E.atom(a.id),E.constant('supported')]),{a.id:a},[],[])
 code,_=compact_prolog_program([p],learned=True)
 assert 'nn(relation_net'in code and 'status('+a.id+',Z) :- learned_status'in code

def test_long_conjunction_preserves_small_probability_mass():
 obs=[Observation('dense'+str(i),(.9,.05,.05),False,'dense')for i in range(16)]
 p=GroundProgram('dense',E.combine('and',[E.atom(o.id)for o in obs]),{o.id:o for o in obs},[],[])
 result=DirectVerifier([p],learned=False,program_builder=compact_prolog_program).predict()[0]['distribution']
 assert result==pytest.approx(dict(supported=.9**16,refuted=1-.95**16,unknown=.95**16-.9**16),abs=1e-10)
 assert sum(result.values())==pytest.approx(1,abs=1e-10)
