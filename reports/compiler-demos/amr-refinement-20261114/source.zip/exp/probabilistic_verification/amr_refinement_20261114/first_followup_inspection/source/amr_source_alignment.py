"""Source spans for AMR, bounded normalisation, and necessary content checks.

These checks do not prove semantic equivalence. They preserve explicit source
information and flag unsupported names/values without changing neural roles.
"""
import copy,json,re,unicodedata
from dataclasses import replace
from decimal import Decimal,InvalidOperation
from .predicate_compilation import literal
from .semantic_values import MONTHS,temporal_literal
from .typed_literals import PATTERN as MEASUREMENT,UNITS
from .representation import Atom,Expression as E

ALIASES={'person':{'people'},'we':{'our','us'},'i':{'my','me'},'he':{'his','him'},'she':{'her'},'they':{'their','them'}}
ARTIFACTS={'text','sign','overlay','caption','headline','label','banner','poster','placard','subtitle','notice','inscription'}
QUOTES=re.compile(r'["“]([^"”]+)["”]|(?<!\w)\x27([^\x27\n]+)\x27(?!\w)')
CLOCK=re.compile(r'(?<![\w:])(?:T\+\s*)?\d{1,2}:\d{2}(?::\d{2})?(?:\s*[ap]\.?m\.?)?(?:\s*(?:UTC|GMT|BJT|ET))?(?![\w:])',re.I)
NUM=re.compile(r'(?<![\w.])\d+(?:,\d{3})*(?:\.\d+)?(?:st|nd|rd|th)?(?!\w)',re.I)
WORDS=dict(zip('zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty thirty forty fifty sixty seventy eighty ninety'.split(),list(range(20))+list(range(20,100,10))))
ORDINALS=dict(first=1,second=2,third=3,fourth=4,fifth=5,sixth=6,seventh=7,eighth=8,ninth=9,tenth=10)

def normal(s):return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(s)).replace('’',"'").casefold()).strip()
def compact(s):return re.sub(r'[^\w]','',normal(s))
def numeric(s):
 try:return str(Decimal(str(s).replace(',','')).normalize())
 except InvalidOperation:return None
def quote_spans(text):return[dict(start=m.start(1)if m[1]is not None else m.start(2),end=m.end(1)if m[1]is not None else m.end(2),text=m[1]if m[1]is not None else m[2])for m in QUOTES.finditer(text)]

class SourceAlignment:
 def __init__(self,record,concepts):
  self.record=record;self.concepts=concepts;self.tokens=record.get('tokens',[]);self.by_id={t['id']:t for t in self.tokens};self.anchors={}
  for n,c in concepts.items():
   stem=re.sub(r'-\d\d$','',c).replace('_','-');words={stem}|ALIASES.get(stem,set())
   self.anchors[n]=[t for t in self.tokens if normal(t.get('lemma',t['text']))in words or normal(t['text'])in words]
   if not self.anchors[n]and'-'in stem:
    parts=stem.split('-')
    self.anchors[n]=[t for t in self.tokens if normal(t.get('lemma',t['text']))==parts[0]and set(parts[1:])<={normal(u.get('lemma',u['text']))for u in self.tokens if u['head']==t['id']and u.get('deprel','').startswith(('compound:prt','compound','advmod'))}]
 def matches(self,n):return self.anchors.get(n,[])
 def unique(self,n):
  xs=self.matches(n);return xs[0]if len(xs)==1 else None

def prepare_source(record,raw):
 import penman
 from penman.models.amr import model
 graph=penman.decode(raw,model=model);triples=list(graph.triples);concepts={s:t for s,r,t in triples if r==':instance'};alignment=SourceAlignment(record,concepts)
 info=dict(normalisations=[],issues=[],inscriptions=[],clocks=[],source_alignments={n:[dict(token_id=t['id'],start=t.get('start_char'),end=t.get('end_char'),text=t['text'])for t in alignment.matches(n)]for n in concepts})
 # Source quotes become literals only for a uniquely bound written artifact.
 # Human reading actions and ordinary reported speech remain structured.
 for q in quote_spans(record['text']):
  preceding=[t for t in record.get('tokens',[])if t.get('end_char',0)<=q['start']and normal(t.get('lemma',t['text']))in ARTIFACTS]
  if not preceding:continue
  head=max(preceding,key=lambda t:t['end_char']);between=record['text'][head['end_char']:q['start']].strip(' \t\r\n\"\x27“‘,:')
  if between and not re.fullmatch(r'(?:reads?|reading|says?|saying|states?|stating|displaying|showing)(?:\s+the\s+(?:text|words))?',between,re.I):continue
  carriers=[n for n,c in concepts.items()if normal(c)==normal(head.get('lemma',head['text']))]
  if len(carriers)!=1:
   info['issues'].append(dict(code='quote_source_alignment',text=q['text'],reason='A written quotation has no unique AMR artifact.'));continue
  carrier=carriers[0];edges={n:[]for n in concepts}
  for s,r,t in triples:
   if r!=':instance':edges[s].append((r,t))
  cuts=[]
  for n,c in concepts.items():
   if c=='read-01'and(':ARG0',carrier)in edges[n]:cuts.append((n,None))
  for r,t in edges[carrier]:
   ts=alignment.matches(t)
   if r in{':mod',':topic',':ARG1'}and ts and all(q['start']<=x.get('start_char',-1)<q['end']for x in ts):cuts.append((t,(carrier,r,t)))
  removed=[]
  for start,cut in cuts:
   deletion=set();todo=[start]
   while todo:
    n=todo.pop()
    if n==carrier or n in deletion:continue
    deletion.add(n);todo +=[t for _,t in edges.get(n,[])if t in concepts]
   keep={t for s,r,t in triples if r!=':instance'and t in deletion and s not in deletion and(s,r,t)!=cut}
   todo=list(keep)
   while todo:
    n=todo.pop()
    for _,t in edges.get(n,[]):
     if t in deletion and t not in keep:keep.add(t);todo.append(t)
   deletion-=keep
   if start not in deletion:
    info['issues'].append(dict(code='shared_quote_graph',text=q['text'],reason='Quoted semantics share an unresolved external graph attachment.'));continue
   extra=[n for n in deletion if n!=start and any(not(q['start']<=u.get('start_char',-1)<q['end'])for u in alignment.matches(n))]
   if extra:
    info['issues'].append(dict(code='quote_extra_content',nodes=extra,reason='Removing the inscription parse would also drop source content outside the quote.'));continue
   gone=[x for x in triples if x[0]in deletion or(x[1]!=':instance'and x[2]in deletion)];triples=[x for x in triples if x not in gone];removed+=gone
   if graph.top in deletion:graph.top=carrier
  info['inscriptions'].append(dict(q,carrier=carrier,carrier_token=head['id']))
  if removed:info['normalisations'].append(dict(kind='written_quotation',carrier=carrier,source=q,removed_triples=removed))
  elif between and any(c=='read-01'for c in concepts.values()):info['issues'].append(dict(code='written_reading_frame',text=q['text'],reason='The stative inscription still has an unresolved reading-event analysis.'))
 protected=info['inscriptions']
 for m in CLOCK.finditer(record['text']):
  if any(q['start']<=m.start()<q['end']for q in protected):continue
  raw_clock=m[0];is_elapsed=bool(re.match(r'T\+',raw_clock,re.I));ampm=bool(re.search(r'[ap]\.?m\.?',raw_clock,re.I))
  if is_elapsed:value=dict(value=raw_clock,attribute='elapsed')
  else:
   cleaned=re.sub(r'([ap])\.m\.?',r'\1m',raw_clock,flags=re.I)
   try:value=temporal_literal(cleaned)or dict(value=raw_clock)
   except ValueError:value=dict(value=raw_clock)
  info['clocks'].append(dict(start=m.start(),end=m.end(),text=raw_clock,value=value,ampm=ampm,elapsed=is_elapsed))
 for i,(s,r,t)in enumerate(triples):
  if r!=':time'or t in concepts:continue
  raw_value=literal(t);digits=re.match(r'(\d{1,2}):(\d{2})(?::(\d{2}))?',raw_value)
  if not digits:continue
  candidates=[]
  for c in info['clocks']:
   src=re.search(r'(\d{1,2}):(\d{2})(?::(\d{2}))?',c['text'])
   canonical=str(c['value']['value'])
   if c['elapsed']:
    parts=lambda v:tuple(int(x)for x in v.split(':'))
    a=list(parts(raw_value));b=list(parts(src[0]))if src else[]
    while len(a)>1 and a[0]==0:a.pop(0)
    while len(b)>1 and b[0]==0:b.pop(0)
    if a==b:candidates.append(c)
    continue
   if(src and tuple(map(int,src.groups(default='0')))==tuple(map(int,digits.groups(default='0'))))or canonical.startswith(raw_value):candidates.append(c)
  if len(candidates)==1 and(candidates[0]['ampm']or candidates[0]['elapsed']):
   c=candidates[0];new=c['value']['value']
   triples[i]=(s,r,json.dumps(new));info['normalisations'].append(dict(kind='elapsed_code'if c['elapsed']else'clock_meridiem',node=s,old=raw_value,new=new,source=c))
  elif len(candidates)>1:info['issues'].append(dict(code='clock_alignment',value=raw_value,reason='Several source clocks could match this graph value.'))
 graph=penman.Graph(triples,top=graph.top);changed=penman.encode(graph)
 return changed,info,SourceAlignment(record,{s:t for s,r,t in triples if r==':instance'})

def add_source_conditions(claim,record,info,alignment):
 """Attach source-licensed conditions at the aligned concept, inside its scope."""
 metadata=copy.deepcopy(claim.metadata);atoms=list(claim.atoms);additions={};features=[];negative_atoms=set()
 def inventory(e,negative=False):
  if e.op=='atom'and negative:negative_atoms.add(e.atom_id)
  for c in e.children:inventory(c,negative or e.op=='not')
 inventory(claim.expression)
 def attach(n,predicate,values,*,route=None):
  v=metadata['node_variables'].get(n)
  if not v:return False
  original=next((a for a in atoms if a.predicate=='concept'and a.arguments[0]==v and a.arguments[1]==metadata['concepts'][n]),None)
  if original is None:return False
  context=list(original.arguments[2:])
  if route is not None:context[-1]=route
  a=Atom('a'+str(len(atoms)+1),predicate,tuple([v]+list(map(str,values))+context),'source',(),predicate,(),False);atoms.append(a);additions.setdefault(original.id,[]).append(E.atom(a.id));metadata['allowed_routes'][a.id]=[context[-1]]
  features.append(dict(node=n,predicate=predicate,values=values,atom_id=a.id,scope=context[-3]));return True
 for q in info['inscriptions']:
  if not attach(q['carrier'],'written_text',[q['text']],route='ocr_assertion'):info['issues'].append(dict(code='quote_attachment',reason='The exact quote could not be bound to an emitted artifact condition.'))
 for n in metadata['concepts']:
  t=alignment.unique(n)
  if t and t.get('upos')in{'NOUN','PRON'}and'Number=Plur'in(t.get('feats')or''):
   v=metadata['node_variables'].get(n);concept_atom=next((a for a in atoms if a.predicate=='concept'and a.arguments[0]==v),None)
   no_np=any(u.get('head')==t['id']and normal(u['text'])=='no'for u in record.get('tokens',[]))
   if no_np and concept_atom and concept_atom.id in negative_atoms:features.append(dict(node=n,grammatical_number='plural',executable=False,reason='No-NP absence forbids even one witness; do not require a plural-sized negative witness.'))
   else:attach(n,'grammatical_number',['plural'])
   # This records linguistic number, not a claim of a general count/mass solver.
 def transform(e):
  if e.op=='atom'and e.atom_id in additions:return E.combine('and',[e]+additions[e.atom_id])
  return replace(e,children=tuple(transform(x)for x in e.children))if e.children else e
 expression=transform(claim.expression);metadata['source_alignment']=copy.deepcopy(info);metadata['source_features']=features
 return replace(claim,atoms=tuple(atoms),expression=expression,metadata=metadata)

AMR_UNITS={'meter':'m','metre':'m','kilometer':'km','kilometre':'km','kilogram':'kg','gram':'g','mile-per-hour':'mph','mile':'mile','hour':'hour','second':'second','percent':'%'}
def source_checks(record,graph_text,info):
 """Necessary source checks; passing does not establish role/scope correctness."""
 import penman
 from penman.models.amr import model
 g=penman.decode(graph_text,model=model);concepts={s:t for s,r,t in g.instances()};edges={n:[]for n in concepts}
 for s,r,t in g.triples:
  if r!=':instance':edges[s].append((r,t))
 issues=list(info['issues']);protected=info['inscriptions'];text=record['text']
 def inside(start,end):return any(q['start']<=start and end<=q['end']for q in protected)
 # Exact identity strings get strict matching, without a fuzzy-prefix repair.
 names=[]
 for n,c in concepts.items():
  if c!='name':continue
  ops=sorted([(r,literal(t))for r,t in edges[n]if re.fullmatch(r':op\d+',r)],key=lambda x:int(x[0][3:]));name=' '.join(v for _,v in ops);names.append(name)
  if name and compact(name)not in compact(text):issues.append(dict(code='name_source_mismatch',node=n,value=name,reason='A generated name is absent from the original source.'))
 graph_values={numeric(literal(t))for s,r,t in g.triples if r!=':instance'and t not in concepts and numeric(literal(t))is not None}
 allowed=set();source_numbers=[];months=set()
 clock_ranges=[(c['start'],c['end'])for c in info['clocks']]
 scale_ranges=[]
 for m in re.finditer(r'(\d+(?:\.\d+)?)\s*(hundred|thousand|million|billion)\b',text,re.I):
  if inside(m.start(),m.end()):continue
  value=Decimal(m[1])*{'hundred':100,'thousand':1000,'million':1000000,'billion':1000000000}[m[2].lower()];allowed.add(numeric(value));source_numbers.append((m.start(),m.end(),numeric(value),m[0]));scale_ranges.append(m.span())
 for m in NUM.finditer(text):
  if inside(m.start(),m.end())or any(lo<=m.start()<hi for lo,hi in clock_ranges+scale_ranges):continue
  value=numeric(re.sub(r'(st|nd|rd|th)$','',m[0],flags=re.I));allowed.add(value);source_numbers.append((m.start(),m.end(),value,m[0]))
 for token in record.get('tokens',[]):
  if inside(token.get('start_char',-1),token.get('end_char',-1)):continue
  word=normal(token['text']);value=WORDS.get(word)
  if value is None and(word!='second'or token.get('upos')in{'NUM','ADJ'}or'NumType=Ord'in(token.get('feats')or'')):value=ORDINALS.get(word)
  if value is not None:allowed.add(numeric(value));source_numbers.append((token.get('start_char',0),token.get('end_char',0),numeric(value),token['text']))
  if word in{n.lower()for n in MONTHS}and token.get('upos')not in{'AUX','VERB'}and(token.get('upos')=='PROPN'or token['text'][0].isupper()):months.add(numeric(next(v for n,v in MONTHS.items()if n.lower()==word)))
 for m in re.finditer(r'\b\d{4}[-/](\d{2})[-/]\d{2}\b',text):months.add(numeric(m[1]))
 allowed |=months
 measures=[]
 for m in MEASUREMENT.finditer(text):
  if inside(m.start(),m.end())or(m.end()<len(text)and text[m.end()].isalnum()):continue
  unit=UNITS[m['unit'].lower()];value=numeric(m['value']);allowed.add(value);measures.append(dict(start=m.start(),end=m.end(),text=m[0],value=value,unit=unit))
  if value not in{v[2]for v in source_numbers}:source_numbers.append((m.start(),m.end(),value,m[0]))
 for s,r,t in g.triples:
  if r==':month'and t not in concepts:
   if numeric(t)not in months:issues.append(dict(code='month_source_mismatch',node=s,value=literal(t),reason='No explicit source month licenses this calendar value.'))
  elif r!=':instance'and t not in concepts and numeric(literal(t))is not None and numeric(literal(t))not in allowed:
   issues.append(dict(code='numeric_source_mismatch',node=s,role=r,value=literal(t),reason='A numeric graph value has no matching explicit source value.'))
 # A source number is credited only to emitted graph data or a bound quote.
 for lo,hi,value,raw in source_numbers:
  if value not in graph_values and not any(raw in n for n in names):issues.append(dict(code='source_number_omission',start=lo,end=hi,text=raw,reason='An explicit source amount/identifier is not represented in graph values.'))
 for m in measures:
  matched=False
  for n,c in concepts.items():
   quants=[numeric(literal(t))for r,t in edges[n]if r==':quant'and t not in concepts]
   units=[AMR_UNITS.get(concepts.get(t,''),concepts.get(t,''))for r,t in edges[n]if r==':unit']
   if c=='percentage-entity':quants +=[numeric(literal(t))for r,t in edges[n]if r==':value'];units+=['%']
   if m['value']in quants and m['unit']in units:matched=True
  if not matched:issues.append(dict(code='measurement_binding',text=m['text'],reason='The complete source amount and unit lack a linked quantity condition.'))
 for n,c in concepts.items():
  if c=='be-located-at-91'and any(r==':ARG2'and concepts.get(t)in{'date-entity','date-interval','temporal-quantity'}for r,t in edges[n]):issues.append(dict(code='location_value_type',node=n,reason='A calendar/time value is not a location.'))
 for c in info['clocks']:
  values=[literal(t)for s,r,t in g.triples if r==':time'and t not in concepts]
  def clock_parts(v):
   m=re.fullmatch(r'(\d{1,2}):(\d{2})(?::(\d{2}))?',v)
   return tuple(map(int,m.groups(default='0')))if m else None
  wanted=c['value']['value']
  matched=wanted in values or c['text']in values or(not c['elapsed']and clock_parts(wanted)is not None and any(clock_parts(v)==clock_parts(wanted)for v in values))
  if not matched:issues.append(dict(code='clock_omission',text=c['text'],reason='The complete source clock/timecode has no linked graph value.'))
  zone=c['value'].get('timezone')
  if zone and not any(r==':timezone'and normal(literal(t))==normal(zone)for s,r,t in g.triples):issues.append(dict(code='timezone_omission',text=c['text'],reason='The explicit source timezone label is missing.'))
 graph_words={compact(re.sub(r'-\d\d$','',v))for v in concepts.values()}|{compact(v)for v in names}
 graph_words|={compact(literal(v))for _,r,v in g.triples if r in{':timezone',':value',':era'}and v not in concepts}
 for t in record.get('tokens',[]):
  if t.get('upos')!='PROPN'or inside(t.get('start_char',-1),t.get('end_char',-1)):continue
  word=normal(t['text']);month=next((numeric(v)for n,v in MONTHS.items()if normal(n)==word),None)
  if month and any(r==':month'and numeric(v)==month for _,r,v in g.triples):continue
  if not any(compact(word)in v for v in graph_words if v):issues.append(dict(code='source_name_omission',token_id=t['id'],text=t['text'],reason='An explicit proper-name component is absent from emitted graph names/concepts.'))
 negatives=[t for t in record.get('tokens',[])if normal(t['text'])in{'not',"n't",'never'}or normal(t['text'])=='no'and t.get('upos')=='DET']
 negatives=[t for t in negatives if not inside(t.get('start_char',-1),t.get('end_char',-1))]
 if negatives and not any(r==':polarity'and v=='-'for _,r,v in g.triples)and not re.search(r'\bnot\s+only\b',text,re.I):issues.append(dict(code='polarity_omission',reason='Explicit source negation has no logical graph polarity.'))
 unique=[];seen=set()
 for i in issues:
  key=json.dumps(i,sort_keys=True)
  if key not in seen:seen.add(key);unique.append(i)
 return unique
