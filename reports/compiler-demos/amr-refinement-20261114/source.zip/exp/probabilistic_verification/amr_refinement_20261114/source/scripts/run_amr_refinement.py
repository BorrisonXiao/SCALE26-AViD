"""Fixed source/coordination/scope refinements on all cached2,375 AMRs."""
import hashlib,json,logging,time,shutil
from collections import Counter
from prepare_amr_refinement import ROOT,RUN,BASE,rows,dump
from probabilistic_verification.amr_source_alignment import prepare_source,source_checks
from probabilistic_verification.amr_refinement import compile_refined
from probabilistic_verification.logic import Evidence,ground
from probabilistic_verification.compact_backend import compact_prolog_program

def main():
 logging.getLogger('penman').setLevel(logging.ERROR)
 manifest=json.loads((RUN/'followup_reference_manifest.json').read_text());assert hashlib.sha256((RUN/'followup_references.json').read_bytes()).hexdigest()==manifest['sha256']
 oldrefs=json.loads((BASE/'references.json').read_text())['references'];newrefs=json.loads((RUN/'followup_references.json').read_text());refs={r['claim_id']:dict(r,cohort='development60')for r in oldrefs};refs.update({r['claim_id']:dict(r,cohort='new_videos32')for r in newrefs})
 inputs=rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl');amrs={r['request']['task']['claim_id']:r for i in range(4)for r in rows(ROOT/f'exp/probabilistic_verification/full_compilation_20261029/amr_{i}_raw.jsonl')};assert len(inputs)==len(amrs)==2375
 frozen=RUN/'source/scripts/probabilistic_verification';frozen.mkdir(parents=True,exist_ok=True)
 for p in(ROOT/'scripts/probabilistic_verification').glob('*.py'):shutil.copy2(p,frozen/p.name)
 for p in [ROOT/'scripts/run_amr_refinement.py',ROOT/'scripts/prepare_amr_refinement.py']:shutil.copy2(p,frozen.parent/p.name)
 started=time.perf_counter();out=[]
 for record in inputs:
  cid=record['claim_id'];a=amrs[cid];row=dict(claim_id=cid,text=record['text'],raw=a['raw'],request_hash=a['request_hash'],status='unsupported',source_checks=[])
  assert a['request']['task']['text']==record['text']
  try:
   prepared=prepare_source(record,a['raw']);row.update(normalised_amr=prepared[0],source_trace=prepared[1]);row['source_checks']=source_checks(record,prepared[0],prepared[1])
   c=compile_refined(record,a['raw'],strict=False,prepared=prepared)
   e=Evidence('compilation_only',{v.name:['placeholder:'+v.name]for v in c.variables},{v.name:True for v in c.variables},{})
   gp=ground(c,e,max_expansions=3000);program=compact_prolog_program([gp],learned=False)[0]
   from problog.program import PrologString
   list(PrologString(program));row.update(status='compiled',source_checks_pass=not row['source_checks'],compilation=c.to_dict(),program=program,program_sha256=hashlib.sha256(program.encode()).hexdigest())
  except Exception as e:row.update(code=getattr(e,'code',type(e).__name__),reason=str(e))
  if cid in refs:row['reference']=refs[cid]
  out.append(row)
 (RUN/'corpus.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n'for r in out))
 cases=[next(r for r in out if r['claim_id']==cid)for cid in refs];dump(RUN/'cases.json',cases)
 groups={}
 for group,xs in [('all',out),('development60',cases[:60]),('new_videos32',cases[60:])]:
  converted=[r for r in xs if r['status']=='compiled'];groups[group]=dict(total=len(xs),converted=len(converted),source_checks_pass=sum(r['source_checks_pass']for r in converted),source_flagged=sum(not r['source_checks_pass']for r in converted),refusals=dict(Counter(r['code']for r in xs if r['status']!='compiled')),source_issues=dict(Counter(i['code']for r in converted for i in r['source_checks'])))
 dump(RUN/'summary.json',dict(groups=groups,seconds=round(time.perf_counter()-started,3),method='One cached BART AMR, source span alignment/normalisation, shared coordination/scope classes, compact exact-state encoding. No parser selection/model calls/media training.',retained_pool=1981,excluded=394,promotions=0,review='Pending assistant review; conversion and source guards are not semantic accuracy.'))
 print(groups,flush=True)
if __name__=='__main__':main()
