"""Reserve a source-disjoint follow-up before changing the AMR frontend."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/amr_refinement_20261114'
BASE=ROOT/'exp/probabilistic_verification/amr_composition_20261114'
def rows(p):return list(map(json.loads,p.read_text().splitlines()))
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 RUN.mkdir(exist_ok=True,parents=True)
 records=rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl');refs=json.loads((BASE/'references.json').read_text())['references'];video=lambda x:x['claim_id'].rsplit('_',1)[0];used={video(r)for r in refs}
 by={}
 for r in records:
  if video(r)not in used:by.setdefault(video(r),[]).append(r)
 assert len(by)==4
 chosen=[]
 for vid,rs in sorted(by.items()):chosen+=sorted(rs,key=lambda r:hashlib.sha256(('amr-followup-20261114:'+r['claim_id']).encode()).hexdigest())[:8]
 assert len(chosen)==32
 (RUN/'followup_inputs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in chosen))
 dump(RUN/'followup_selection.json',dict(total=32,videos={k:len(v)for k,v in by.items()},per_video=8,source_disjoint_from_60=True,policy='Selected by fixed hash before changes; original texts only. Four videos are absent from the60AMR reference cases. Cached parser predictions and earlier project work already exist; this is not a never-seen project/model test set or independent gold.',sha256=hashlib.sha256((RUN/'followup_inputs.jsonl').read_bytes()).hexdigest()))
 dump(RUN/'preserved_archives.json',{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in(ROOT/'site').rglob('*.zip')})
 for i,r in enumerate(chosen):print(i,r['claim_id'],r['text'])
if __name__=='__main__':main()
