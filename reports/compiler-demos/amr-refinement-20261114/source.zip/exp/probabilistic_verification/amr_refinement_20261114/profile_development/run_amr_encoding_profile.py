"""Same grounded formulas, two existing serializers, bounded native inference."""
import argparse,dataclasses,hashlib,json,math,platform,subprocess,sys,time
from prepare_amr_refinement import ROOT,RUN,BASE,rows,dump
CASES=['Tg0UxWYuPeJ0_323','Txf2EdqOg1SQ_2176','T1JQ-aG78Zuc_796']
def worker(emitter,cid,mode):
 import faulthandler
 faulthandler.dump_traceback_later(4,repeat=False)
 started=time.perf_counter()
 from probabilistic_verification.amr_composition import AMRCompiler
 from probabilistic_verification.logic import Evidence,ground,prolog_program
 from probabilistic_verification.direct_backend import direct_prolog_program
 from probabilistic_verification.compact_backend import compact_prolog_program
 from deepproblog.model import Model
 from deepproblog.engines import ExactEngine
 from deepproblog.query import Query
 from problog.logic import Term,Var
 import torch
 torch.set_num_threads(2)
 def progress(phase):print(json.dumps(dict(kind='progress',phase=phase,seconds=time.perf_counter()-started)),flush=True)
 progress('imports_done')
 r=next(r for r in json.loads((BASE/'reviewed_cases.json').read_text())if r['claim_id']==cid)
 record=next(x for x in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')if x['claim_id']==cid)
 c=AMRCompiler().compile(cid,r['text'],r['raw'],record['tokens']);e=Evidence('compilation_only',{v.name:['placeholder:'+v.name]for v in c.variables},{v.name:True for v in c.variables},{})
 t=time.perf_counter();gp=ground(c,e,max_expansions=2000);ground_assignment_seconds=time.perf_counter()-t
 expected=None
 if mode=='mixed':
  gp.observations={k:dataclasses.replace(o,distribution=(.9,.05,.05),available=True)for k,o in gp.observations.items()}
  assert cid=='Txf2EdqOg1SQ_2176'
  def conjunction_only(n):return n.op in{'atom','constant'}or n.op=='and'and all(conjunction_only(x)for x in n.children)
  assert conjunction_only(gp.expression)
  n=len(gp.observations);expected=dict(supported=.9**n,refuted=1-.95**n,unknown=.95**n-.9**n)
 t=time.perf_counter();program,names={'explicit_states':direct_prolog_program,'generic':prolog_program,'compact':compact_prolog_program}[emitter]([gp],learned=False);emit_seconds=time.perf_counter()-t
 if mode=='unknown'and emitter=='generic':assert hashlib.sha256(program.encode()).hexdigest()==r['program_sha256']
 t=time.perf_counter();m=Model(program,[],load=False);m.set_engine(ExactEngine(m),cache=True);model_seconds=time.perf_counter()-t;progress('model_ready')
 q=Query(Term('verdict',Term(names[cid]),Var('State')));t=time.perf_counter();result=m.solve([q])[0];first_seconds=time.perf_counter()-t;progress('first_solve_done')
 scores={str(k.args[1]):float(v)for k,v in result.result.items()};scores={k:scores.get(k,0.)for k in ['supported','refuted','unknown']}
 if mode=='unknown':expected=dict(supported=0.,refuted=0.,unknown=1.)
 assert all(math.isclose(scores[k],expected[k],abs_tol=1e-9)for k in scores),(scores,expected)
 t=time.perf_counter();again=m.solve([q])[0];cached_seconds=time.perf_counter()-t
 faulthandler.cancel_dump_traceback_later()
 print(json.dumps(dict(kind='result',emitter=emitter,claim_id=cid,observations=len(gp.observations),mode=mode,assignment_grounding_seconds=ground_assignment_seconds,emit_seconds=emit_seconds,model_seconds=model_seconds,first_solve_seconds=first_seconds,cached_solve_seconds=cached_seconds,problog_ground_seconds=result.ground_time,circuit_compile_seconds=result.compile_time,circuit_evaluation_seconds=result.eval_time,distribution=scores,expected=expected,program_sha256=hashlib.sha256(program.encode()).hexdigest(),source='Constructed distributions; no media or trained model. Same shared observation identities in both serializers.')),flush=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--worker',choices=['generic','explicit_states','compact']);p.add_argument('--case');p.add_argument('--mode',default='unknown');p.add_argument('--compact-only',action='store_true');a=p.parse_args()
 if a.worker:worker(a.worker,a.case,a.mode);return
 out=[]
 for cid,mode in[(c,'unknown')for c in CASES]+[('Txf2EdqOg1SQ_2176','mixed')]:
  for emitter in (['compact']if a.compact_only else['generic','explicit_states']):
   started=time.monotonic()
   try:
    r=subprocess.run([sys.executable,__file__,'--worker',emitter,'--case',cid,'--mode',mode],capture_output=True,text=True,timeout=12)
    js=[json.loads(s)for s in r.stdout.splitlines()if s.startswith('{')];row=dict(status='completed'if r.returncode==0 else'error',returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,result=next((s for s in js if s['kind']=='result'),None))
   except subprocess.TimeoutExpired as e:row=dict(status='time_limit',limit_seconds=12,stdout=(e.stdout or b'').decode()if isinstance(e.stdout,bytes)else e.stdout,stderr=(e.stderr or b'').decode()if isinstance(e.stderr,bytes)else e.stderr)
   row.update(claim_id=cid,emitter=emitter,mode=mode,process_seconds=time.monotonic()-started);out.append(row);dump(RUN/('encoding_profile_compact.json'if a.compact_only else'encoding_profile.json'),dict(rows=out,platform=platform.platform(),policy='CPU fresh process;12s including imports; two PyTorch threads; same formula/domains/evidence. All states queried, with a repeated query to check caching. Timings are diagnostic, not a controlled general benchmark.'));print(cid,mode,emitter,row['status'],row.get('result',{}).get('first_solve_seconds')if row.get('result')else'',flush=True)
if __name__=='__main__':main()
