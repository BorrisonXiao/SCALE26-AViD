"""Save implementing-assistant readings after inspecting all92 diagnostic outputs."""
import hashlib,json
from collections import Counter
from prepare_amr_refinement import ROOT,RUN,BASE,rows,dump
from review_amr_composition import MATCH as PREVIOUS_MATCH,INCORRECT as PREVIOUS_INCORRECT,CONTEXT as PREVIOUS_CONTEXT

MATCH=dict(PREVIOUS_MATCH)
MATCH.update({0:'The visible overlay now binds the exact source text news 76 through an OCR condition, inside perception.',11:'The report body is explicitly a topic, not an assertion that it is raining. Both rain and weather remain inside this topic.',19:'The same plural participant sings and dances; the description is repeated in both conjuncts with the same variable.',34:'The depicted interval now keeps06:00 and midnight00:00 attached to their respective January dates.',57:'The sign binds the entire original quotation. Its inner voice/Mexico events are not asserted as world events.'})
PARTIAL={5:'The nested OCR assertion/depiction reading survives, but the exact quoted label is not bound to a unique written artifact. The source alignment deliberately leaves this construction unchanged.',8:'The participants and location survive, but the explicitly reciprocal facing relation is still only one directional.',10:'The directive/cessation nesting and citizens survive. All water activities remains an ordinary all modifier, without explicit universal quantification; this is a scope improvement, not a complete quantifier treatment.',24:'The purpose and both coordinated obstacles survive, but drive-direction-up-curb does not explicitly share the car as the mover of up. The onto/trajectory interpretation is not established.',25:'Causer, crawl actor, plurality and nested appearance/sufficiency/result survive. The generic claim about adults is not represented by a general quantifier; keep this partial.',27:'Creation, both causes, basalt and the approximate three-billion-year time survive. Event-nominal plurality and exact attachment of the filled relative clause remain unresolved.',31:'The graph still makes footage part of a heatmap rather than footage depicting a heatmap.',33:'The group of scenes/images and the shared audio/text description survive. The graph still encodes the text appearance as a location and does not establish equivalent description content across the two channels.',37:'The car is shared by overturn and burn, and its plurality survives. A burned result state is still not distinguished from a burning event.',42:'Survival history is still inside depiction of the stills instead of handled as a projected relative-clause fact.',44:'Robot1 identity and up remain absent. Removing erroneous event plurality does not recover these details.',46:'Firefly is still typed as person, and the reported future/once condition is absent.'}
INCORRECT=dict(PREVIOUS_INCORRECT)
INCORRECT.update({4:'The explanatory or in a haboob, or an intense wall is treated as ordinary disjunction. The graph also substitutes gust for downdraft. Adding coordination does not repair these meanings.',36:'Tear gas is a gas-03 event with tear as an argument, and is grouped with a smoke-bomb object as what is fired. This does not preserve the substance binding.',40:'The mist/rain OR itself is represented, but the blowing event has no wind actor/causer link and sits outside perception. The shared binding described by blowing is lost.'})
CONTEXT=dict(PREVIOUS_CONTEXT)
FOLLOWUP={
60:('matches_reference','Smoke eruption and rocket landing remain separate events joined by time, without an invented causal link. The noun-tag plural on lands is removed by the shared event-type rule.'),
61:('partial','Earth atmosphere and beyond it survive, but both are group members under reach. The further-extent/trajectory reading is not explicit.'),
63:('partial','The elapsed code is restored exactly, but the original graph also leaves a second literal time T+. Begin(video) is put in an aspect context. This is not a clean single elapsed-time condition.'),
64:('partial','Launch, rocket and clear sky remain. The graph calls sky the launch location rather than explicitly making clear weather concurrent with launch.'),
65:('incorrect','The graph ends velocity modified by video and uses the speed as an end argument. It does not say velocity equals12005mph at the end of the video. Necessary amount/unit checks cannot catch this binding error.'),
66:('partial','Rocket, fall and over-ocean survive, but fall ARG4 is an endpoint, rather than a clear location of the falling trajectory. The claim does not state water impact.'),
68:('context_needed','The connection is preserved, but East distribution worker is decomposed into east location plus an actual worker/distributor. The original ambiguous compound does not license that commitment.'),
69:('matches_reference','The same cargo crane parks and obstructs the view of the port. The camera position, directly modifier and09:20:38am source clock survive without a date/timezone.'),
70:('matches_reference','The stationed crane is beside a boat and large modifies that boat.'),
71:('matches_reference','The wave douses the pier with water; large modifies the wave and the bare timestamp remains unexpanded. Its exact time scale is still caller context, not an invented timezone.'),
72:('matches_reference','The August20,2025 date is attached to taking the footage, not to an unrelated depicted event.'),
74:('incorrect','IPC is changed to IPCC, although ownership and broadcasting correctly share the camera. The source-name check refuses this candidate.'),
75:('context_needed','Maker and crane roles are correct, but the graph adds a person type to Tadano. The sentence alone does not establish this named referent type.'),
76:('matches_reference','The standing crowd contains plural people and is in front of a building; white modifies the building.'),
77:('partial','Police, wearing, plural vests and yellow survive. Reflective is represented as an actual reflect event rather than an explicit reflective property/capability.'),
78:('matches_reference','The same plural individuals wear a black thing and leave plural helicopters. Leave-11 ARG1 is the departure location, as in the official PropBank frame.'),
79:('partial','Both floor descriptions are group members, but the graph attaches building only to the bottom floor and uses one group location. The top floor of that same building and distribution of lights over both floors are not established.'),
80:('partial','Speech location nesting, plural people and large grouping survive, but the audience is a group-01 event rather than a clearly typed group entity. The group-size interpretation is incomplete.'),
81:('incorrect','Military personnel and civilians are coordinated, but the graph puts them at a video as a place. It does not represent their depiction by the video.'),
82:('matches_reference','Night is attached to recording the video, with no invented date or clock.'),
83:('partial','Slurs stay inside the said-content context and police are recipients. The ongoing being said aspect is missing.'),
84:('context_needed','The graph preserves God as sender, but invents a person type and has no patient or attribution context. This fragment still needs context; it is not evidence of a world event.'),
86:('partial','The eyes belong to the man, but the graph asserts a close action with the man as agent. It does not represent the present closed state.'),
87:('matches_reference','Bright is attached to sun, over links it to the man, and the man is the praying actor.'),
88:('matches_reference','The visible overlay now binds exactly Al-Wefaq News through an OCR condition inside perception, including the original hyphen.'),
89:('incorrect','The full association name is split into Hajj Services Association and Umrah Services Association. The source-name check refuses the changed name; adding an AND group cannot repair identity.'),
90:('matches_reference','Pilgrimage is located at the complete Mount Arafat name, without inventing a pilgrim or time.'),
91:('matches_reference','Sitting and praying share the man; the rock remains the sitting support/location.')}

def main():
 cases=json.loads((RUN/'cases.json').read_text());assert len(cases)==92
 reviews=[]
 for i,r in enumerate(cases):
  if r['status']!='compiled':label,reason='not_compiled',r['reason']
  elif i>=60:label,reason=FOLLOWUP[i]
  else:
   ds=[(k,d)for k,d in [('matches_reference',MATCH),('partial',PARTIAL),('incorrect',INCORRECT),('context_needed',CONTEXT)]if i in d];assert len(ds)==1,(i,r['text']);label,d=ds[0];reason=d[i]
  j=dict(index=i,claim_id=r['claim_id'],cohort=r['reference']['cohort'],reviewer='Implementing assistant; no GPT/model judge or new human approval.',whole_reading=label,reason=reason,source_checks_pass=r.get('source_checks_pass',False),program_sha256=r.get('program_sha256'),amr_sha256=hashlib.sha256(r['raw'].encode()).hexdigest())
  r['review']=j;reviews.append(j)
 dump(RUN/'reviews.json',reviews);dump(RUN/'reviewed_cases.json',cases)
 s=json.loads((RUN/'summary.json').read_text());s['review']='All92 inspected by implementing assistant.32 original-text readings were frozen first; their first output inspection informed the event/unit plurality fix, so final32 are development diagnostics, not held-out accuracy. No model judge/new human approvals.'
 s['review_counts']=dict(Counter(j['whole_reading']for j in reviews))
 for name,js in [('development60',reviews[:60]),('new_videos32',reviews[60:])]:
  s['groups'][name]['reviews']=dict(Counter(j['whole_reading']for j in js));s['groups'][name]['source_pass_but_incorrect']=sum(j['source_checks_pass']and j['whole_reading']=='incorrect'for j in js)
 corpus=rows(RUN/'corpus.jsonl');old={r['claim_id']:r for r in rows(BASE/'corpus.jsonl')}
 s['conversion_change']=dict(previous=sum(r['status']=='compiled'for r in old.values()),current=sum(r['status']=='compiled'for r in corpus),newly_converted=sum(r['status']=='compiled'and old[r['claim_id']]['status']!='compiled'for r in corpus),newly_refused=sum(r['status']!='compiled'and old[r['claim_id']]['status']=='compiled'for r in corpus))
 buckets={}
 for r in corpus:
  if r['status']=='compiled':continue
  b=buckets.setdefault(r['code'],dict(count=0,patterns=Counter(),examples=[]));b['count']+=1;b['patterns'][r['reason']]+=1
  if len(b['examples'])<3:b['examples'].append(dict(claim_id=r['claim_id'],text=r['text'],reason=r['reason']))
 dump(RUN/'failure_patterns.json',{k:dict(v,patterns=v['patterns'].most_common(12))for k,v in sorted(buckets.items(),key=lambda p:-p[1]['count'])})
 source={}
 for r in corpus:
  if r['status']!='compiled':continue
  for issue in r['source_checks']:
   b=source.setdefault(issue['code'],dict(count=0,examples=[]));b['count']+=1
   if len(b['examples'])<3:b['examples'].append(dict(claim_id=r['claim_id'],text=r['text'],issue=issue))
 dump(RUN/'source_issues.json',source);dump(RUN/'summary.json',s);print(json.dumps(s,indent=2))
if __name__=='__main__':main()
