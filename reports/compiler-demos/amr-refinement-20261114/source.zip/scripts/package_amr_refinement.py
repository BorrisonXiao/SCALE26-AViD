"""Publish a reproducible source/data overlay, keeping older archives immutable."""
import hashlib,json,zipfile
from prepare_amr_refinement import ROOT,RUN,BASE,dump
def main():
 names=set()
 for folder,pattern in [('scripts','*.py'),('scripts/probabilistic_verification','*.py'),('scripts/report_assets','*'),('tests','*.py'),('tests/fixtures','*.json'),('docs/project_notes','*')]:
  names.update(str(p.relative_to(ROOT))for p in(ROOT/folder).glob(pattern)if p.is_file())
 names.update(['AGENTS.md','CLAUDE.md','docs/amr_refinement_20261114.md','docs/amr_composition_20261114.md','exp/probabilistic_verification/av_features_20261022/checklist.json'])
 excluded={'source_manifest.json','archive_verification.json','browser_checks.json','publication.json'}
 for p in RUN.rglob('*'):
  if p.is_file()and'__pycache__'not in p.parts and'legacy_replay'not in p.parts and p.name not in excluded and p.suffix in{'.py','.json','.jsonl','.log','.md','.xml','.txt'}:names.add(str(p.relative_to(ROOT)))
 for n in ['references.json','corpus.jsonl','cases.json','reviewed_cases.json','input_manifest.json']:names.add(str((BASE/n).relative_to(ROOT)))
 for rel in ['content_relations_20261105/inputs.jsonl','rewrite_all_20261112/inputs.jsonl','rewrite_all_20261112/parsed.jsonl','compiler_structural_20261113/direct_all.jsonl','compiler_structural_20261113/cached_pipeline.jsonl']+[f'full_compilation_20261029/amr_{i}_raw.jsonl'for i in range(4)]:names.add('exp/probabilistic_verification/'+rel)
 old=json.loads((RUN/'preserved_archives.json').read_text());assert len(old)==32
 for p,h in old.items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 viewers=json.loads((ROOT/'exp/probabilistic_verification/claim_rewrite_20261111/viewer_sha256.json').read_text());assert len(viewers)==26
 for p,h in viewers.items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 data={n:(ROOT/n).read_bytes()for n in sorted(names)};dump(RUN/'source_manifest.json',{n:hashlib.sha256(b).hexdigest()for n,b in data.items()});data[str((RUN/'source_manifest.json').relative_to(ROOT))]=(RUN/'source_manifest.json').read_bytes();data['README_AMR_REFINEMENT.md']=(ROOT/'docs/amr_refinement_20261114.md').read_bytes();data['AMR_REFINEMENT_SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+n+'\n'for n,b in sorted(data.items())).encode()
 target=ROOT/'site/reports/compiler-demos/amr-refinement-20261114/source.zip';target.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in sorted(data.items()):
   info=zipfile.ZipInfo(n,date_time=(2026,11,14,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
 assert target.stat().st_size<100_000_000;print('Packaged',len(data),'files;',round(target.stat().st_size/1048576,2),'MiB;32older ZIPs/26viewers exact.')
if __name__=='__main__':main()
