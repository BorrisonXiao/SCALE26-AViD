"""Assistant readings from the reserved original texts, before new outputs."""
import hashlib
from prepare_amr_refinement import RUN,rows,dump
READINGS=[
('Smoke erupts while a rocket lands. Preserve both events and temporal overlap, without replacing overlap by causation.','No ambiguity identified.'),
('A rocket reaches the Earth atmosphere and goes beyond it. Beyond is a further extent/direction, not another named destination.','The exact boundary meant by beyond is unspecified.'),
('A rocket is launched, and the launch succeeds. The rocket is the launched object, not the launcher.','No ambiguity identified.'),
('The video begins at elapsed timecode T+57:24. Preserve the elapsed marker and full timecode; do not infer a wall clock or its field units.','The claim alone does not define whether the fields are minutes/seconds or another elapsed scale.'),
('A rocket launch takes place with clear skies. Keep sky conditions concurrent with the launch.','No ambiguity identified.'),
('At the end of the video, a velocity is12005 miles per hour. Preserve the amount, speed unit and end-of-video timing.','The moving referent is omitted; do not invent it.'),
('A rocket falls above/over the ocean. Falling does not by itself assert impact with the water.','Over may indicate the trajectory above the ocean; the text does not state impact.'),
('A rocket slows down and reaches a safe landing in the ocean. Preserve the rocket across deceleration and landing and retain safe.','No ambiguity identified.'),
('The cargo crane is connected to a container described as an East distribution worker container. Preserve the connection and full modifier phrase.','The internal interpretation of East distribution worker is unclear; do not silently invent an organisation or person.'),
('At9:20:38am a cargo crane parks directly in front of the camera and blocks the view of the port. The same crane performs both events.','No date or timezone is stated.'),
('A crane is stationed beside a large boat. Large modifies boat, and next to links crane and boat.','No ambiguity identified.'),
('A large wave douses the pier with water at8:58:09. Preserve the wave as cause/actor, pier as affected object and water as substance.','The bare timestamp does not define a clock timezone, am/pm or elapsed scale.'),
('The footage was recorded on August20,2025. This is the recording date, not an inferred date of an unrelated depicted event.','No ambiguity identified.'),
('A large boat carries a safety-first reminder. Preserve the reminder and its connection to the boat.','Written versus spoken form is not explicitly stated; do not invent exact lettering.'),
('IPC owns the camera that is broadcasting the livestream. Ownership and broadcasting must share the camera.','IPC is a supplied name; its organisational type is not certified by the claim alone.'),
('Tadano made the cargo crane. Keep maker and manufactured object distinct.','No ambiguity identified.'),
('A crowd of people stands in front of a white building. Keep plurality/crowd and the white modifier on the building.','No ambiguity identified.'),
('Police wear yellow reflective vests. Yellow and reflective modify the vests, not the police.','No ambiguity identified.'),
('Black-clad individuals leave helicopters. Keep clothing, people as movers, helicopters as departure sources and plurality.','No ambiguity identified.'),
('Lights are on at the building\'s bottom floor and at its very top floor. Both distinct floor locations are required.','No ambiguity identified.'),
('A speech is given in an open area within a city to a large group of people. Preserve audience, location nesting and group size.','The speaker is omitted; do not invent a named speaker.'),
('The video depicts military personnel and civilians. Both groups belong to the depicted content.','No ambiguity identified.'),
('The video was recorded at night. Keep the recording-time condition distinct from an arbitrary depicted event time.','No date or clock time is stated.'),
('Someone says slurs to the police. Preserve derogatory speech and police as recipients; do not invent exact words or a specific speaker.','The utterer and words are omitted.'),
('An unspecified person or thing is described as sent by God. Preserve God as the stated sender without inventing the patient or the missing source context.','This fragment needs a referent and evidential context; compilation does not certify a religious world claim.'),
('A visible video overlay contains exactly: Last year it took hours to get to the camp, now its only25 mins. Keep the original wording and25 mins inside the written overlay, not as independently true travel claims.','The printed wording uses its; do not correct the quotation.'),
('A man\'s own eyes are closed. Preserve the state and possession; do not substitute a past eye-closing action alone.','No ambiguity identified.'),
('Bright sunlight is above a man who is praying. Bright modifies the sun/light, and the man is the prayer actor.','No ambiguity identified.'),
('A visible video overlay contains exactly Al-Wefaq News. Preserve the hyphen and full label under written-text support.','No ambiguity identified.'),
('Hajj and Umrah Services Association and pilgrims hand drinks to the public. Preserve the full organisation name, the pilgrims, drinks and recipient public.','The wording is compatible with joint or distributed participation; do not require one unsupported distribution.'),
('A pilgrimage is at Mount Arafat. Preserve the named location without inventing a specific pilgrim or new event time.','No ambiguity identified.'),
('A man sits on a rock and prays. The sitting and praying share the man; rock is the sitting support/location.','No ambiguity identified.'),
]
def main():
 xs=rows(RUN/'followup_inputs.jsonl');assert len(xs)==len(READINGS)==32
 out=[]
 for r,(meaning,ambiguity)in zip(xs,READINGS):
  # Only typography outside the exact quotations is normalised below.
  meaning=meaning.replace('velocity is12005','velocity is 12005').replace('At9:20','At 9:20').replace('at8:58','at 8:58').replace('August20,2025','August 20,2025').replace('only25 mins','only 25 mins').replace('and25 mins','and 25 mins')
  out.append(dict(claim_id=r['claim_id'],text=r['text'],meaning=meaning,ambiguity=ambiguity,author='Implementing assistant reading from original text, frozen before extension outputs. Not independent gold.'))
 dump(RUN/'followup_references.json',out);dump(RUN/'followup_reference_manifest.json',dict(cases=32,sha256=hashlib.sha256((RUN/'followup_references.json').read_bytes()).hexdigest(),model_judge=False,exclusion='Four videos absent from the60AMR development references; earlier project and parser exposure remain disclosed.'))
 print('Frozen32 original-text reference readings.')
if __name__=='__main__':main()
