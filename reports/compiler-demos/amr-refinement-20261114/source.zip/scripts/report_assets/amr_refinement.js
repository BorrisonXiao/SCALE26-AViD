(()=>{
 const el=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 if(!el('refined-case'))return;let rows=[];
 function show(save=false){
  const r=rows.find(x=>x.claim_id===el('refined-case').value);if(!r)return;
  el('refined-text').textContent=r.text;el('refined-reference').textContent=r.reference.meaning;
  el('refined-cohort').textContent=(r.reference.cohort==='new_videos32'?'Follow-up from four other videos. Original-text reading frozen first; final outputs are development diagnostics.':'Original60 development references. Earlier human readings are not new approval of these programs.')+' Review: implementing assistant only.';
  el('refined-verdict').textContent='Meaning review: '+r.review.whole_reading.replaceAll('_',' ')+(r.status==='compiled'?' · graph converted · '+(r.source_checks_pass?'source checks pass':'source checks refuse'):' · graph not converted');
  el('refined-reason').textContent=r.review.reason;
  el('refined-raw-graph').innerHTML=r.raw_svg;el('refined-normal-graph').innerHTML=r.normal_svg;
  const info=r.source_trace||{};
  el('refined-source').innerHTML='<p><b>Changes:</b></p>'+(info.normalisations?.length?'<ul>'+info.normalisations.map(x=>'<li>'+esc(x.kind.replaceAll('_',' '))+': '+esc(x.source?.text||'')+(x.new?' → '+esc(x.new):'')+'</li>').join('')+'</ul>':'<p>No source normalisation applied.</p>')+'<p><b>Checks:</b></p>'+(r.source_checks.length?'<ul>'+r.source_checks.map(x=>'<li>'+esc(x.code.replaceAll('_',' '))+': '+esc(x.reason)+' '+esc(x.value||x.text||'')+'</li>').join('')+'</ul>':'<p>No source flag. This does not establish correct meaning.</p>');
  if(r.compilation){
   const c=r.compilation,m=c.metadata,by=Object.fromEntries(c.atoms.map(a=>[a.id,a])),describe=v=>{const d=c.variables.find(x=>x.name===v);return v+(d?' ('+d.description+')':'');};
   function sentence(a){const v=a.arguments,scope=v[v.length-3];let text;
    if(a.predicate==='concept')text=describe(v[0])+' must match '+v[1];
    else if(a.predicate==='role')text=describe(v[0])+' — '+v[1]+' → '+describe(v[2]);
    else if(a.predicate==='name')text=describe(v[0])+' must have name “'+v[1]+'”';
    else if(a.predicate==='written_text')text=describe(v[0])+' must contain exactly “'+v[1]+'” (written text)';
    else if(a.predicate==='grammatical_number')text=describe(v[0])+' has source grammatical number: '+v[1];
    else if(a.predicate==='group')text=describe(v[0])+' is an AND group';
    else if(a.predicate==='member')text=describe(v[1])+' is a member of '+describe(v[0]);
    else if(a.predicate==='reference')text='Use the same '+describe(v[0])+' in this context';
    else if(a.predicate==='proposition')text=describe(v[0])+' has '+v[1]+' in '+v[2]+' context '+v[3];
    else if(a.predicate==='temporal')text=describe(v[0])+': '+({pres:'present',past:'past'}[v[1]]||v[1])+' tense; '+v[2]+' aspect';
    else text=describe(v[0])+': '+v[1]+' = '+v[2];
    return '<p class="amr-condition">'+esc(text)+' <small>['+esc(scope)+'; '+esc(v[v.length-1])+(a.trainable?'; relation function':'')+']</small></p>';
   }
   function formula(e){
    if(e.op==='atom')return sentence(by[e.atom_id]);if(e.op==='constant')return '<p>'+esc(e.state)+'</p>';if(e.op==='exists')return formula(e.children[0]);
    if(e.op==='not')return '<div class="box amr-negative"><b>NOT: no matching assignment satisfies these conditions</b>'+formula(e.children[0])+'</div>';
    if(e.op==='or')return '<div class="box"><b>OR: at least one branch must hold</b>'+e.children.map((x,i)=>'<div class="box"><b>Branch '+(i+1)+'</b>'+formula(x)+'</div>').join('')+'</div>';
    return e.children.map(formula).join('');
   }
   const scopes=Object.entries(m.scopes).map(([id,s])=>'<li>'+esc(id+': '+s.kind+'; owner '+s.owner+' / '+m.concepts[s.owner]+'; parent '+s.parent+'; route '+s.route)+'</li>').join('');
   el('refined-conditions').innerHTML='<p>Same ID means the same candidate. All conditions are required together unless an OR/NOT box says otherwise. Candidates are existentially quantified; exact quantifier placement is below. Relation functions are future fixed or learned evidence checks; no classifier is trained here.</p><p><b>Contexts:</b> world = outer claim, not a certificate of world truth.</p>'+(scopes?'<ul>'+scopes+'</ul>':'<p>No embedded context.</p>')+formula(c.expression);
   el('refined-exact').textContent='CACHED AMR\n'+r.raw+'\n\nNORMALISED AMR\n'+r.normalised_amr+'\n\nLOGIC\n'+c.logical_form+'\n\nSOURCE TRACE\n'+JSON.stringify(info,null,2)+'\n\nPROBLOG (placeholder candidates; no media evidence)\n'+r.program;
  }else{el('refined-conditions').textContent='Refused: '+r.code+' — '+r.reason;el('refined-exact').textContent=r.raw+'\n\n'+r.normalised_amr+'\n\n'+r.code+': '+r.reason+'\n\n'+JSON.stringify(info,null,2);}
  const n=r.native;el('refined-native').textContent=!n?'Not measured on this case. A generated program is not a measured inference result.':n.status!=='completed'?'The refined compact program exceeded the12s fresh-process budget; no verdict. Placeholder candidates, no media predictions.':'With no media observations, unknown =1; first solve '+n.result.first_solve_seconds.toFixed(3)+'s. Placeholder candidates, not evidence support.';
  const u=new URL(location);u.searchParams.set('refined_claim',r.claim_id);u.hash='amr-refinement-example';el('refined-share').href=u.pathname+u.search+u.hash;
  if(save){history.replaceState(null,'',u);window.dispatchEvent(new Event('hashchange'));}
 }
 fetch('compiler-demos/amr-refinement-20261114/cases.json').then(r=>{if(!r.ok)throw Error('Could not load saved examples');return r.json();}).then(data=>{rows=data;for(const r of rows){const o=document.createElement('option');o.value=r.claim_id;o.textContent=(r.reference.cohort==='new_videos32'?'Follow-up · ':'Development · ')+r.review.whole_reading.replaceAll('_',' ')+' · '+r.text;el('refined-case').append(o);}const q=new URLSearchParams(location.search).get('refined_claim');el('refined-case').value=rows.some(r=>r.claim_id===q)?q:'Tsuk2uoYj-kc_645';show();window.dispatchEvent(new Event('hashchange'));}).catch(e=>el('refined-verdict').textContent=e.message);
 el('refined-case').addEventListener('change',()=>show(true));
})();
