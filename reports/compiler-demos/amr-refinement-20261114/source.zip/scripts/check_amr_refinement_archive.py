"""Isolated cached replay; no neural calls, GPU, full profiling or external review."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from prepare_amr_refinement import ROOT,RUN,dump
def main():
 archive=ROOT/'site/reports/compiler-demos/amr-refinement-20261114/source.zip';target=Path(tempfile.mkdtemp(prefix='avid-amr-refinement-'))
 with zipfile.ZipFile(archive)as z:z.extractall(target)
 for line in(target/'AMR_REFINEMENT_SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256((target/n).read_bytes()).hexdigest()==h,n
 env=dict(os.environ,PYTHONPATH=str(target/'scripts'),PYTHONDONTWRITEBYTECODE='1')
 for script in ['run_amr_refinement.py','review_amr_refinement.py','check_amr_refinement_regression.py']:
  r=subprocess.run([sys.executable,'scripts/'+script],cwd=target,env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr;print('Replayed',script,flush=True)
 names=['corpus.jsonl','cases.json','reviews.json','reviewed_cases.json','failure_patterns.json','source_issues.json','legacy_regression.json']
 for n in names:assert(RUN/n).read_bytes()==(target/RUN.relative_to(ROOT)/n).read_bytes(),n
 a=json.loads((RUN/'summary.json').read_text());b=json.loads((target/RUN.relative_to(ROOT)/'summary.json').read_text());a.pop('seconds');b.pop('seconds');assert a==b
 r=subprocess.run([sys.executable,'-m','pytest','tests/test_amr_source_alignment.py','tests/test_amr_operators.py','tests/test_compact_backend.py','-q'],cwd=target,env=env,capture_output=True,text=True,timeout=45);assert r.returncode==0,r.stdout+r.stderr;assert'33 passed'in r.stdout,r.stdout
 r=subprocess.run([sys.executable,'scripts/run_amr_encoding_profile.py','--worker','compact','--case','Tg0UxWYuPeJ0_323','--refined'],cwd=target,env=env,capture_output=True,text=True,timeout=12);assert r.returncode==0,r.stderr;result=next(json.loads(s)for s in r.stdout.splitlines()if s.startswith('{')and json.loads(s).get('kind')=='result');assert result['distribution']==dict(supported=0.,refuted=0.,unknown=1.)
 dump(RUN/'archive_verification.json',dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),sha256_inventory=True,byte_identical_artifacts=names,summary_equal_except_elapsed_seconds=True,originals=2375,reviewed_cases=92,legacy_amr_claims=2375,legacy_originals=2375,legacy_cached=449,focused_tests=33,workspace_full_tests=538,native_race_unknown=1.,model_calls=0,extraction=str(target)));print('Isolated replay exact;33 focused tests and native race passed.')
if __name__=='__main__':main()
