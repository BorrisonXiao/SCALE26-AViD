"""Re-run the published default AMR and older direct/rewrite paths unchanged."""
import hashlib,json
from prepare_amr_refinement import ROOT,RUN,BASE,rows,dump
from probabilistic_verification.amr_composition import AMRCompiler
from probabilistic_verification.logic import Evidence,ground,prolog_program
import run_compiler_repairs as legacy

def main():
 cached={r['request']['task']['claim_id']:r for i in range(4)for r in rows(ROOT/f'exp/probabilistic_verification/full_compilation_20261029/amr_{i}_raw.jsonl')}
 old={r['claim_id']:r for r in rows(BASE/'corpus.jsonl')};converted=0
 for r in rows(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl'):
  cid=r['claim_id'];b=old[cid]
  try:
   c=AMRCompiler().compile(cid,r['text'],cached[cid]['raw'],r['tokens'])
   assert json.loads(json.dumps(c.to_dict()))==b['compilation'],cid
   e=Evidence('compilation_only',{v.name:['placeholder:'+v.name]for v in c.variables},{v.name:True for v in c.variables},{})
   gp=ground(c,e,max_expansions=3000);p=prolog_program([gp],learned=False)[0]
   assert p==b['program'],cid;converted+=1
  except AssertionError:raise
  except Exception as err:
   assert b['status']!='compiled'and b['code']==getattr(err,'code',type(err).__name__)and b['reason']==str(err),(cid,b,str(err))
 assert converted==1425
 target=RUN/'legacy_replay';target.mkdir(exist_ok=True);legacy.RUN=target
 legacy.corpus();legacy.replay('cached_pipeline.jsonl',ROOT/'exp/probabilistic_verification/rewrite_all_20261112/parsed.jsonl',ROOT/'exp/probabilistic_verification/rewrite_all_20261112/inputs.jsonl')
 hashes={}
 for n in ['direct_all.jsonl','cached_pipeline.jsonl']:
  expected=ROOT/'exp/probabilistic_verification/compiler_structural_20261113'/n
  assert(target/n).read_bytes()==expected.read_bytes(),n;hashes[n]=hashlib.sha256((target/n).read_bytes()).hexdigest()
 dump(RUN/'legacy_regression.json',dict(default_amr_claims=2375,default_amr_converted=1425,compilations_and_programs_exact=True,originals=2375,cached=449,byte_identical=hashes,retained=1981,excluded=394))
 print('Default AMR2375 including1425 exact compilations/programs; legacy2375/449 byte-identical.')
if __name__=='__main__':main()
