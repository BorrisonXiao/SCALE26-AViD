"""Constructed ambiguity examples, not measured parser or media predictions."""
import json
from pathlib import Path
from probabilistic_verification.parse_mixture import infer
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_structural_20261113'
def main():
 observations={'alice_uses_telescope':[0.9,0.1,0.0],'bob_has_telescope':[0.1,0.9,0.0]};uses={'instrument_reading':'alice_uses_telescope','noun_attachment_reading':'bob_has_telescope'}
 a=infer(dict(instrument_reading=0.6,noun_attachment_reading=0.4),observations,uses)
 b=infer(dict(instrument_reading=0.54,noun_attachment_reading=0.36),observations,uses,unparsed=0.1)
 out=dict(claim='Alice saw Bob with a telescope.',interpretations=['Alice used a telescope to see Bob.','Alice saw Bob, who had a telescope.'],observations=observations,examples=[dict(title='Two alternative logical forms',**a),dict(title='Retain probability of no adequate parse',**b)],status='Constructed native DeepProbLog engineering check. All parse weights and evidence probabilities are stipulated. No parser confidence was estimated, no media was processed, and no empirical calibration or coverage gain is claimed.')
 (RUN/'parse_mixture_examples.json').write_text(json.dumps(out,indent=2)+'\n');print([(e['title'],e['distribution'],e['or_of_observations'])for e in out['examples']])
if __name__=='__main__':main()
