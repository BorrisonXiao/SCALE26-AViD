# AViD Phase 2 — Unit Filtering Rules
_Terminology follows docs/project_notes/terminology.md._

**Implemented in:** `scripts/unit_filters.py` (`filter_units`)
**Consumed by:** `scripts/verify_support.py` (input-loading step, before any model call)
**Inputs used:** `exp/phase1/reports/annotation_units.tsv`, `exp/phase1/hypergraph.jsonl`,
`exp/phase1/affordance_v2/affordance_annotation.tsv` (for the `na` set)

Before signal verification, annotation units are filtered down to those that are *meaningfully
verifiable against audio/video*. Every rule is **deterministic** — it uses only parser output
(UPOS, lemma, `node_type`, character spans) and the text-only modality-prior label (called affordance in the code and file names). No model calls, fully
reproducible.

> Upstream of this: the heuristics that *build* the units (parse → hypergraph → annotation units)
> are documented in [`parsing_and_unit_generation.md`](parsing_and_unit_generation.md).

---

## Pipeline position

```
annotation_units.tsv (4,919)
        │
        ▼   filter_units()   ← this document
verifiable units (4,369)
        │
        ▼
verify_support.py  →  Qwen3-VL / Qwen3-Omni
```

---

## Rule catalogue

Applied in this precedence order (first matching content rule wins; duplicate runs last):

| # | Rule | Basis | Action | Removed |
|---|---|---|---|---|
| 1 | `na` | modality-prior `pred_llm == "na"` | drop | 104 |
| 2 | `pronoun` | head node `upos == PRON` | drop | 154 |
| 3 | `empty` | `unit_text` empty/whitespace | drop | 135 |
| 4 | `uuid` | `unit_text` is **only** an anonymization UUID | drop | 13 |
| 5 | `negation` | `node_type` contains `negation`, **if subsumed** | drop | 20 |
| 6 | `light_verb` | event node, light/copular lemma, **if subsumed** | drop | 83 |
| 7 | `duplicate` | same claim, normalized text already kept | drop extras | 41 |

**Net: 4,919 → 4,369 units** (counts are precedence-resolved: e.g. a pronoun that is also `na`
counts under `na`). Pronouns already labelled `na` (21 of them) fall under rule 1; the 154 figure
is the remaining bare pronouns.

---

## Rule details (with real examples)

### 1. `na` — the modality-prior model said "not annotatable"

Units the modality-prior LLM flagged as relational/functional words or vague/underspecified referents
(see `key_facts.md §LLM Prompts`, pass-1 `na` definition). These have no pointable referent in any
channel.

| Dropped unit | Claim |
|---|---|
| `"the conditions"` | "A woman comments that **the conditions** are dangerous." |
| `"ask"` | "Commenters **ask** if anyone is missing…" |

*(`na` is the one model-derived rule; all others are purely structural.)*

### 2. `pronoun` — bare unresolved referent (`upos == PRON`)

A pronoun on its own ("it", "their", "anyone") has no fixed referent without discourse context, so
verifying it against a video is vacuous. Detected via the parser's UPOS tag on the unit's head node
— covers both `pu_n<X>` (phrase) and `f<N>` (factor head) forms, and catches demonstratives /
indefinites a word-list would miss.

| Dropped unit | Claim |
|---|---|
| `"anyone"` | "Commenters ask if **anyone** is missing…" |
| `"their"` | "People are stuck in **their** homes during a major storm…" |
| `"those"` | "Residents of Akiak, Alaska hope prayers can help **those**…" |

### 3. `empty` — empty / whitespace `unit_text`

Span-extraction failures (mostly from one pathological 187-node "claim" that is actually an embedded
protest-speech transcript). Nothing to verify. 135 units, all from `TFOEIehBwT8Q_486`.

### 4. `uuid` — unit is only an anonymization UUID

Source claims anonymize some named entities/usernames as UUIDs (e.g.
`83eda40e-5f26-4a46-9f55-49df64e290d4`). A unit whose text is *only* a UUID has no pointable
referent in any channel. Detected by `is_uuid_only()`: drop iff the text is empty once all
UUIDs and surrounding punctuation are stripped. Units that merely *contain* a UUID but carry
other content are **kept** (the rest is still verifiable). 13 units dropped.

| Dropped unit | Kept (UUID-containing but contentful) |
|---|---|
| `"83eda40e-5f26-4a46-9f55-49df64e290d4"` | `"83eda40e-… is the World Central Kitchen response director."` |

### 5. `negation` — negation factor, **subsumption-guarded**

A bare negation fragment ("n't move", "not had") is not independently verifiable, and the modality-prior
model mislabels them (mostly `audio_speech`). They are dropped **only when a larger surviving unit
contains the same span** — so the negated content is still verified, with its negation intact, inside
the predicate/full-claim unit.

| Dropped fragment | Covered by (kept) |
|---|---|
| `"not majorly affected"` | "Anchorage, Alaska was **not majorly affected** by Typhoon Halong" |
| `"not had"` | "Akiak, Alaska has **not had** electricity for 22 days…" |
| `"n't move"` | "The man lightly pushes Robot 1 away saying, \"Do**n't move**\"" |

### 6. `light_verb` — semantically-thin event node, **subsumption-guarded**

Standalone event nodes whose lemma is a light/copular verb carry near-zero standalone content; the
contentful claim lives in the factor that contains them. Dropped **only when subsumed** by a larger
surviving unit.

Lemma set: `be, do, go, have, get, make, take, come, become, seem, appear`.
**`say` is deliberately excluded** — it is a speech act, verifiable via audio.

| Dropped fragment | lemma | Covered by (kept) |
|---|---|---|
| `"taken"` | take | "Some of the footage was initially **taken** by @alaskanmann" |
| `"get"` | get | "Akiak, Alaska may **get** power back the following weekend." |
| `"had"` | have | "Akiak, Alaska has not **had** electricity for 22 days…" |

### 7. `duplicate` — intra-claim normalized-duplicate

Within a single claim, units whose `unit_text` is identical after normalization (lowercase; strip
leading/trailing quotes and terminal punctuation) are collapsed to one. The kept copy prefers
`full_claim`, then longest raw text, then lowest `unit_id`.

| Kept | Dropped (duplicate) |
|---|---|
| `"Aerial view of rocket launch."` | `"Aerial view of rocket launch"` |
| `"Successful liftoff of rocket."` | `"Successful liftoff of rocket"` |
| `"Burning of thrusters in the final descent."` | `"Burning of thrusters in the final descent"` |

---

## The subsumption guard (rules 4 & 5)

A negation/light unit is dropped **iff** some *meaningful* larger unit in the same claim strictly
contains its character span, where "meaningful" = not itself dropped by rules 1–3 and not a
negation/light candidate. Spans come from the hypergraph: node `span_start/span_end`, factor
`surface_span` located in `claim_text`.

This makes the rule self-justifying: we never delete content that isn't re-presented to the model
inside a larger, verifiable unit. **Empirically all 21 negation factors and all 83 light-verb nodes
are covered** (verified against `surface_span`), but the guard protects against degenerate parses —
an uncovered fragment is *kept*, not dropped.

---

## Reproduce / dry-run

```python
import csv, sys; sys.path.insert(0, "scripts")
from unit_filters import filter_units, format_stats

na = {f"{r['claim_id'].strip()}|{r['unit_id'].strip()}"
      for r in csv.DictReader(open("exp/phase1/affordance_v2/affordance_annotation.tsv"), delimiter="\t")
      if (r.get("pred_llm") or "").strip() == "na"}
raw = [{"claim_id": r["claim_id"].strip(), "unit_id": r["unit_id"].strip(),
        "unit_type": r["unit_type"].strip(), "node_type": r["node_type"].strip(),
        "unit_text": r["unit_text"].strip()}
       for r in csv.DictReader(open("exp/phase1/reports/annotation_units.tsv"), delimiter="\t")
       if r["claim_id"].strip() and r["unit_id"].strip()]

units, stats = filter_units(raw, "exp/phase1/hypergraph.jsonl", na)
print(format_stats(stats))
```

`verify_support.py` prints the same breakdown at startup (step `[2]`).

---

## Not filtered (deliberately)

- **Transcript-claims** `TFOEIehBwT8Q_483` / `_486` (153 / 151 units): per decision, kept (their
  empty units are still removed by rule 3, but their non-empty fragments remain).
- **`NUM`, `ADP`-headed factors, `ADV`**: kept — dates/times are OCR-verifiable, prepositional
  factors ("affected by the typhoon") are real relations, ADV-headed cases are full clauses.
