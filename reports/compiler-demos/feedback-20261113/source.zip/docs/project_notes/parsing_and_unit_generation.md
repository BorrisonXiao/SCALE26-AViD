# AViD Phase 1 — Parsing & Annotation-Unit Generation Heuristics
_Terminology follows docs/project_notes/terminology.md._

The deterministic rules that turn a raw dependency parse into the **hypergraph** and then into the
**annotation units** (`annotation_units.tsv`). These run *before* the Phase-2 verification filters
documented in [`unit_filtering.md`](unit_filtering.md).

**Implemented in:**
- Stage 1 (parse → hypergraph): `scripts/parse_claims.py`
- Stage 2 (hypergraph → units): `scripts/annotation_units.py` (logic; `make_annotation_units.py` is I/O only)

**Designed in (origin of these rules):**
- Stage 1: `docs/plans/avid_phase1_implementation_plan_v1.md` (Steps 1–2)
- Stage 2: `docs/plans/avid_phase1_complement_annotation_units_v1.md` (Operations 1–2)

This file is the consolidated *as-implemented* reference; the plan docs hold the original rationale,
locked decisions, and deferred items.

```
raw UD parse (spacy-stanza)
      │  ── Stage 1 heuristics (parse_claims.py) ──
      ▼
hypergraph.jsonl   (nodes + typed factors + spans)
      │  ── Stage 2 heuristics (annotation_units.py) ──
      ▼
annotation_units.tsv   (4,919 units, canonical annotation surface)
      │  ── Phase-2 deterministic filters (unit_filters.py) ──
      ▼
verifiable units (4,382) → verify_support.py
```

---

## Stage 1 — Parse → hypergraph (`parse_claims.py`)

### S1.1 Claim deduplication
One record per `(topic_id, claim_text)`; `modalities` unioned across supporting video pairs.
(`load_unique_claims`)

### S1.2 Node merging — NER + compound/flat/appos (union-find)
Consecutive tokens of a NER span, and `compound` / `flat` / `flat:name` / `flat:foreign` / `appos`
chains, are merged into one node. Representative = the group's syntactic head (leftmost token whose
head is outside the group). (`build_merged_groups`, `MERGE_DEPS`)

| Merged node | From |
|---|---|
| `"Simeon Uisok"` | flat:name ("…uploaded by **Simeon Uisok** via Storyful") |
| `"Kipnuk, Alaska"` | appos ("…impacting **Kipnuk, Alaska**.") |

### S1.3 UPOS → node_type, with functional-token drop
`UPOS_TO_NODE_TYPE`: NOUN/PROPN/PRON→`entity`, VERB→`event`, ADJ/ADV→`attribute`, ADP→`relation-op`,
CCONJ→`coord-op`, NUM→`cardinality`. Tokens with no mapping (DET, AUX, SCONJ, PART, PUNCT, …) get
**no node** — they survive only inside factor `surface_span`s. (`get_node_type`, `build_nodes`)

### S1.4 Negation override
A negation lemma (`not, never, no, n't, neither, nor, without, hardly`) with deprel `advmod`/`det`/
`neg` is retyped from its UPOS to `logical-op` (overrides S1.3). (`get_node_type`, `NEG_LEMMAS`)

| Node | UPOS → type |
|---|---|
| `"not"` | PART → logical-op ("…was **not** majorly affected…") |
| `"no"` | DET → logical-op ("There are **no** containers…") |

### S1.5 Composition-factor rules
Factors built from UD deprels (`build_factors`). Each = `{id, factor_type, head, args[], surface_span}`.

| factor_type | UD trigger |
|---|---|
| `predicate_argument` | VERB + args (nsubj/obj/iobj/obl/xcomp, incl. passive) |
| `entity_attribute` | `amod` (ADJ/ADV) or copular `cop` |
| `prepositional_relation` | `obl`/`nmod` with a `case` child (prep as head) |
| `temporal_relation` | `advcl`/`obl` with a temporal-marker `mark`/`case` |
| `coordination` | `conj` (+ `cc` coordinator) |
| `negation` | negation lemma w/ `advmod`/`det`/`neg` |
| `relative_clause` | `acl:relcl` |
| `cardinality` | `nummod` |
| `full_claim` | the `root` (always emitted) |

### S1.6 `full_claim` head fallback
If the `root` is a functional token (e.g. copular AUX), the `full_claim` head is reassigned to the
`nsubj` (or first content-POS child) so the whole-claim factor still anchors on a real node.
*Known gap:* 3 claims still lack a `full_claim` factor (`TzF9M4kZ3Pys_285`, `TFOEIehBwT8Q_522`,
`TKCfkoNUssZI_723`) — copular/existential roots with no recoverable semantic head.

---

## Stage 2 — Hypergraph → annotation units (`annotation_units.py`)

`make_annotation_units(rec)` runs six steps over each claim.

### S2.1 NP token-set construction (phrase-level entity units)
For every entity node, grow an NP from its head: **keep** premodifiers (`det`, `amod`, `nummod`,
`compound`, `flat`, `appos`) and **of-complements** (`nmod` whose `case` child lemma is `of`).
**Cut** everything else — other PPs (`obl`, non-`of` `nmod`), `acl:relcl`, `conj`, `cc`, `mark`,
`punct`. (`_np_token_set`, `_NP_EXPAND`)

| Phrase-entity unit (kept span) |
|---|
| `"a livestream of the typhoon"` (head + of-complement) |
| `"The eye of the typhoon"` |
| `"Large amounts of rain"` |

### S2.2 Expletive subject drop
Entity nodes whose head token has deprel `expl` — existential "there", pleonastic "it" (tagged
PRON→entity but contentless) — are dropped; no phrase unit is emitted. (`_is_expletive`)

| Token (deprel=expl) | Phrase unit emitted? |
|---|---|
| `"There"` ("**There** are no containers…") | no |
| `"it"` ("…missing, **it**'s unclear…") | no |

### S2.3 Absorption (keep maximal NPs)
Entity A is **absorbed** if all its token indices fall inside another entity B's NP token-set; only
the maximal (non-absorbed) NP becomes a phrase unit. E.g. "the typhoon" is absorbed into
"a livestream of the typhoon". (`absorbed_ids`)

### S2.4 Copular/existential "be" demotion
Event nodes with lemma `be` (is/are/was/were/been) are **not** emitted as standalone node units —
they are judged only via their factor + `full_claim`. Lexical `have`/`do` (possession,
"do a handstand") are **kept** (only `be` is matched). (`_is_copula_be`, `_COPULA_LEMMAS`)

| Event node | Standalone node unit emitted? |
|---|---|
| `"are"` ("There **are** no containers…") | no (demoted) |
| `"were"` ("There **were** no injuries…") | no (demoted) |

### S2.5 Categorematic (standalone-unit) filter (node-type export policy)
- `entity` (phrase-level) and `event` → **export**.
- `attribute`, `cardinality`, `coord-op`, `logical-op` → **demote** (emit only if orphaned, S2.8).
- `relation-op` (bare prepositions) → **dropped entirely**.

### S2.6 Factor subsumption
A factor whose `surface_span` lies entirely within a single phrase unit's span is dropped
(redundant). `full_claim` is **never** subsumed (covers the whole claim by definition).

### S2.7 Dedup by normalized span, with merge policy
Rows sharing a normalized surface (`.strip().lower()`) are deduped (`_add`):
- factor + factor → **merge** `node_type` labels → e.g. `predicate_argument|full_claim`.
- node/phrase_entity **beats** factor for the same span.
- a `full_claim` factor **always merges** into the existing row.

| Merged row |
|---|
| `[predicate_argument\|full_claim] "Emmonak, Alaska is being affected by the typhoon."` |

### S2.8 Orphan coverage check
Each demoted node (S2.5) must appear as a substring of some exported unit. If not covered, it is
emitted standalone with `notes="orphan:<type>"` so no content silently vanishes.

### S2.9 Sort
Rows sorted by first-occurrence character position in `claim_text`.

---

## Invariants (verified on `annotation_units.tsv`, 4,919 rows / 761 claims)

- No empty `unit_text` from this stage; no duplicate spans per claim; no `relation-op` rows.
- Every claim retains a `full_claim` factor **except** the 3 known copular/existential gaps (S1.6).
- Trigger case `TInVWzp25aIM_15` → exactly 4 rows (phrase "Large amounts of rain"; factor
  "…hit Kamchatka."; event "hit"; phrase "Kamchatka"). Checked by `make_annotation_units.py` step 5.

---

## Reproduce

```bash
# Stage 1 (GPU/CPU; spacy-stanza env):
python scripts/parse_claims.py
# Stage 2 (python3, no deps):
python scripts/make_annotation_units.py
#   → exp/phase1/reports/annotation_units.tsv  + annotation_units_diff.md
```
