# AViD Phase 3 — Parse Normalization: Formal Design (v1)
_Terminology follows docs/project_notes/terminology.md._

**Purpose.** Raw Universal Dependencies (UD) tokens are the wrong *units to verify*: the manner
adverbial "by hand" is split into a vacuous atom "hand"; light verbs ("gets out") become tree roots;
a main-content purpose clause ("to change the switch") is filed as an adverbial adjunct (`advcl`). This
document defines, rigorously, a **normalization map** — *parse normalization*, `PN` — that rewrites a UD
parse into a **verification structure** `T*` (a *checkable-unit tree*) whose units are semantically
checkable. The tree-CRF (see
`compositional_verification_design.md`) runs **unchanged** on `T*`; `PN` is a preprocessing step inserted
between the parser and the CRF.

**Origin.** Design discussion 2026-07-08 → 07-13. Governing decision: **ADR-016**. Prior art:
`research/LITERATURE.md` §"local interpretability & decomposition granularity" (2026-07-13) — PredPatt,
Direct Semantic Splitting/UCCA, SRL/PropBank (ARGM roles), AMR (empty-token normalization), ProoFVer
(typed-edit faithfulness), PARSEME (MWE-detection reliability caveat).

**One line.** `PN` is a **resolve-once, precision-ordered** pipeline of partial functions
`PN_det → PN_srl → PN_llm` — cheap deterministic rules first, then semantic role labelling (SRL), then a
language model — each editing only the sites its *information level* determines, over a closed
edit algebra, emitting a released static artifact `T*`.

---

## 1. Objects & notation

- Claim `c = (w₁,…,wₙ)`, token positions `[n] = {1,…,n}`. A **span** `s ⊆ [n]`.
- **UD parse** `T = ([n], hd, ℓ, u)`: head map `hd:[n]→[n]∪{0}` (edges `E = {(hd(i), i) : hd(i)≠0}`);
  dependency labels `ℓ : E → 𝓛` (`nsubj, obj, obl, case, advcl, amod, det, cc, …`); `u:[n]→UPOS×lemma`.
  `yld(i) ⊆ [n]` is the token set of the subtree rooted at `i`.
- **SRL analysis** `A = {F₁,…,F_m}`, frame `F_k = (p_k, {(s_{k,j}, r_{k,j})}_j)`: predicate anchor
  `p_k∈[n]`, argument span `s_{k,j}⊆[n]`, role `r_{k,j}∈𝓡`. Partition `𝓡 = 𝓡_core ⊔ 𝓡_adj`
  (`ARG0..5` vs `ARGM-MNR/INS/LOC/TMP/PRP/NEG/…`).

## 2. Combining SRL with UD → the enriched tree `T⁺`

SRL does **not** replace the tree; it **colors edges** of it. Align each SRL span to the UD node whose
subtree it matches, then transfer the role onto the connecting edge:

```
v̂(s)  = argmin_{v∈[n]} | yld(v) △ s |            (△ = symmetric difference)
        aligned  iff  yld(v̂(s)) = s   (or overlap ≥ θ);  else s is UNALIGNED
ρ : E ⇀ 𝓡   (partial edge-role map)
        for frame F_k, arg (s,r):  p = v̂(p_k), a = v̂(s);
        set ρ on the first edge of the UD path p ⇝ a to r   (clean case: a is a child of p, edge (p,a))
```

Result: the **enriched tree** `T⁺ = (T, ρ)` — the UD tree with SRL roles painted on the
predicate→argument edges it can align. Edges *inside* an argument (e.g. `the → switch`) stay uncolored;
**unalignable** spans (crossing brackets) leave their edges uncolored → they become residue for `PN_llm`.
This is the whole "combine SRL with UD": one tree, a subset of edges now carry a semantic role.

### 2.1 Why UD is the backbone (not SRL/AMR)

Under `PN`, UD's role is the **scaffold**, not the decomposition: it under-determines the *units* (that is
why `PN` exists), but it uniquely supplies what a verification backbone needs. Two separate questions:
- **UD as a decision oracle** (which units/roles?): **weak** — most decisions are not `F₀`-resolvable
  (§3); SRL (`φ₂`) and the LLM (`φ₃`) decide.
- **UD as a coordinate system / backbone**: **strong**, and unmatched by the alternatives.

**Pros (unique to UD).**
- **Tree** for *exact* belief propagation, BP (SRL = frame set; AMR = graph w/ reentrancies — neither a clean tree).
- **Full coverage** — every token accounted for → faithful-to-the-whole-claim decomposition (SRL leaves gaps).
- **Span-grounding (decisive for AViD)** — units must map to surface spans, because we annotate, **probe
  against the video**, and highlight spans. UD subtree yields *are* spans; AMR nodes are concepts (lossy),
  SRL frames incomplete. A verify-against-pixels/audio task cannot lose the span↔evidence link.
- **Stable substrate for the edit algebra** — `MERGE/REATTACH/…` need fixed node ids to edit *relative to*;
  SRL roles are painted onto UD (`ρ`), LLM edits reference UD nodes.
- **Cheap high-precision structural decisions** (`PN_det`) + relations SRL doesn't fully give (coordination
  scope, relative clauses, negation attachment).
- **Reproducibility anchor** — a frozen-parser artifact.

**Cons.** Under-determines units (the reason for `PN`); redundant with SRL on core-vs-adjunct; parse errors
propagate; syntactic not semantic → low decision-value (`φ₀`).

**Why not replace it.** SRL backbone → partial coverage + no clean tree; AMR backbone → graph-not-tree +
concepts-not-spans + less robust parsers; LLM-only → no external referent (rejected). Each is a better
*semantic signal* but a worse *backbone* → hence **UD backbone + SRL-as-signal + LLM-for-residue**.

**Implication for the backbone ablation (§8).** Once SRL supplies roles, the backbone's job narrows to
"complete, span-grounded tree," so UD-vs-constituency matters less for role typing and more for span
quality; an **SRL/PredPatt-derived backbone** arm measures how much UD-the-scaffold actually contributes.

## 3. Information levels & resolvability

For a **decision site** `x` (a node or an edge) define nested feature maps and their cumulative unions:

| level | `φ_k(x)` | source |
|---|---|---|
| `φ₀` | UD label, UPOS, tree position | UD parse |
| `φ₁` | lexicons: light-verb set, negation lemmas, closed-class prepositions | deterministic tables |
| `φ₂` | SRL role `ρ`, frame membership | SRL (via `T⁺`) |
| `φ₃` | "is `yld(x)` independently checkable / decontextualizable in `c`?" | LLM |

`F_k = (φ₀,…,φ_k)`, so `F₀ ⊆ F₁ ⊆ F₂ ⊆ F₃`.

**Definition (resolvability).** A decision `δ` is **`F_k`-resolvable** iff it is a function of `F_k`:
`∀ x,x′ : F_k(x)=F_k(x′) ⇒ δ(x)=δ(x′)`.

**Why syntax alone is insufficient (canonical witness).** The merge-vs-keep decision for a `case`+`obl`
prepositional phrase is **not `F₀`-resolvable** and **not `F₁`-resolvable**, but **is `F₂`-resolvable**:

| site | phrase | `φ₀` (syntax) | `φ₂` (SRL role) | decision `δ` |
|---|---|---|---|---|
| `x`  | "…change … **by hand**" | obl + case-child | `ARGM-MNR` | promote to a **manner unit**, probe the relation, soft-gate (§4) |
| `x′` | "…crash **into the shore**" | obl + case-child | `ARGM-DIR/LOC` | keep "shore" as a **probeable entity** |
| `x″` | "…**in the morning**" | obl + case-child | `ARGM-TMP` | temporal adjunct; low-salience / `na` |

Identical syntax, different decisions → no UD rule can separate them; a preposition lexicon is
ambiguous too ("by hand"=manner vs "by the river"=locative). The **SRL role** separates them, so a
*deterministic rule over the role* decides correctly. **Hence "deterministic" ≠ "syntactic":** the
deterministic rules are functions of `F₂` (UD + lexicon + SRL roles) and resolve every `F₂`-resolvable
decision — including semantic ones. What remains (`¬F₂`-resolvable, needs `φ₃`, i.e. context) is the
LLM's residue.

## 4. Decisions & the edit algebra

`PN` edits `T⁺` via a **closed edit algebra**
`𝓞 = { MERGE(i→j), REATTACH(i,j), TYPE(e, t), ROLE(i, ·), DROP(i) }`, producing per-site decisions:

- **node role** `role(i) ∈ { probeable, na, op }` — a probed node (the multimodal model's emission), a not-a-checkable-unit node with a uniform emission, or a contracted structural operator.
- **edge composition type** `comp(e) ∈ { core, verif-mod, inert-mod, neg, coord, drop }`.

**Composition types → CRF potential** (this refines `compositional_verification_design.md` §2 and
**supersedes** impl-plan §2.2's "all obl/advcl → ψ=1"):

| `comp(e)` | when | CRF edge potential | gate strength |
|---|---|---|---|
| **core** | core args (`nsubj/obj/ccomp/xcomp`; SRL `ARG0..5`); **main-content purpose clause** (`advcl:purpose` / SRL `ARGM-PRP` carrying the asserted predicate) | necessity `ψ = exp(−λ_core)` if parent supported ∧ child not | hard-ish (veto) |
| **verif-mod** | a **checkable** manner/instrument adjunct (SRL `ARGM-MNR/INS`, `φ₃`=checkable), e.g. "by hand" | soft necessity `ψ = exp(−λ_soft)`, `λ_soft ≪ λ_core`; **child unit is probed as a relation** | soft (→ partial, not veto) |
| **inert-mod** | genuinely optional / unverifiable adjunct (`ARGM-TMP/LOC-when-irrelevant`, unverifiable) | `ψ = 1` (decoupled) | none |
| **neg** | negation (§ negation in design doc) | unary flip on scope | logical |
| **coord** | coordination (`conj`+`cc`) | AND / OR factor | logical |
| **drop** | structural operators (`case/det/punct/cc/cop`) | contracted (no variable) | — |

**The `obl` refinement.** `obl` is **not** uniformly ignored. A manner/instrument adjunct
that asserts a *checkable relation* — "operated **by hand**" vs. automated — is **promoted** to one
manner unit (`MERGE(case→obl-noun)` so bare "hand" is not a standalone node), **`ROLE = probeable`**,
**probed as a relation** ("is the switch operated by hand?"; reuse the composed-span probe pipeline),
and attached by a **`verif-mod`** edge that **soft-gates**: verified-false → downgrade to
`partially_supported`; unverifiable → partial; verified-true → supports. Only *genuinely* optional or
unverifiable adjuncts get `inert-mod` (ψ=1). This supersedes the earlier "hand → na" and
"hand → probeable-existence" resolutions.

## 5. The staged normalizer — RESOLVE-ONCE (chosen 2026-07-13)

Every site carries a status `σ(x) ∈ {P, R}` (pending / resolved), initialized `P`. Each stage is a
**partial function with an explicit domain** `D_k` = sites where its decision is *defined and confident*:

```
D_det = { x : some rule in the closed set matches F₁(x) }            (a syntactic/lexical pattern fires)
D_srl = { x : the deciding edge/span is SRL-aligned with a role ρ }  (φ₂ present and confident)
D_llm = [n] ∪ E                                                      (catch-all; may abstain → safe default)
```

**Update rule (resolve-once):** stage `k` applies its ops only to `{ x : σ(x)=P ∧ x∈D_k }` and sets them
`R`. **No later stage overrides an earlier decision** — an `PN_llm` disagreement with an `PN_det`/`PN_srl`
decision is **logged for review, not applied** (auditability > marginal accuracy in v1). Pipeline,
precision-ordered:

```
PN = PN_llm ∘ PN_srl ∘ PN_det .
```

**"Unresolved after stage k" is decidable, not guessed:** `x ∉ ⋃_{j≤k} D_j` (no rule matched AND no
aligned SRL role) — a structural test the code computes. Distinguish:

- **deferral** — site outside a stage's domain → *detectable* (this is what routes it onward);
- **error** — site *inside* a domain but the rule/SRL/LLM is wrong → **not self-detectable**; caught only
  by the gold eval. The pipeline knows what it *didn't decide*, not what it decided *wrong*.

**Reproducibility.** `PN` is a fixed function once the SRL model and the LLM are **pinned snapshots**
(temperature 0), the LLM emits only the closed `𝓞` as validated JSON (illegal edit → reject → fall back
to raw parse), and the per-claim `T*` + edit logs are **released as a static, versioned artifact**. The
downstream CRF consumes that fixed file, so no learned component sits on the reproducibility-critical
path — "parser-grounded / reproducible" holds even if an API model later drifts. "Deterministic" here =
*reproducible-given-frozen-artifacts* (symbolic rules + two frozen models), not symbolic-only.

## 5.1 Implementation note — case-merge is *provisional at PN-1*, ratified-or-reverted *at PN-2* (ADR-019)

§5–§6 describe the resolve-once **semantics** (the SRL role decides whether a `case`+`obl/nmod` becomes one
manner unit or a bare entity). The **implementation** realizes this in two physical steps — worth spelling out,
because a code reader sees an intermediate state that the idealized narrative hides:

1. **PN-1 (`normalize_parse.py`) merges provisionally.** `MERGE(case→head)` fires on **every** bare `obl`/`nmod`
   with a `case`/`mark` child, setting `pn_unit_text` to the full PP. At this point "by hand", "into the shore",
   and "in the morning" are *all* merged — PN-1 has no role signal yet, so it makes the cheap syntactic guess.
2. **PN-2 (`run_pn2_srl.py`) keeps or reverts, gated on the SRL role** (ADR-019 fix, 2026-07-20; ~L288–296).
   The case marker survives **only for `MNR`/`INS`**; for every other role PN-2 rewrites `pn_unit_text` back to
   the bare NP (`content_subtree_text`, which excludes the case marker) and fixes `pn_unit_span`. So "by hand"
   (MNR) is **kept**; "into the shore" (DIR) → "shore"; "because of the typhoon" (CAU) → "typhoon"; "in the
   morning" (TMP) → `na`.

This is **observationally equivalent** to §6's idealized "the SRL stage decides the merge" — the released `T*`
is identical — but the merge *operation* lives at PN-1 and the keep/revert *decision* at PN-2. Consequently all
such nodes end up `pn_stage="pn2"` (PN-2 was the last editor), which is why the case-merge can *look* like a
PN-2 step even though PN-1 performed it.

**Ground truth** (`T1JQ-aG78Zuc_794`): n11 "by hand" (MNR) → **kept**; n4 "out of tram" (DIR) → "tram"; n9 "to
the correct position" (DIR) → "correct position". **Corpus:** MNR/INS keep the preposition (49/82 · 119/136);
LOC/DIR/CAU almost never do (3/1106 · 3/318 · 0/182). MNR+INS = 218/3253 ≈ **6.7%** of adjunct edges — the
case-keeping class is a small semantic minority (so "by hand" is the outlier, not the norm).

**Why keep for MNR/INS only.** For LOC/DIR/CAU the preposition is a *relation* already carried by the tree edge
(`LOC(event, shore)`), so the unit should be the bare probeable entity ("is the shore visible?"). For MNR/INS
the bare noun is *vacuous* ("hand" ≠ "by hand" ≈ *manually*), so the whole PP is the checkable unit (probed as a
soft-gated relation, §4 `verif-mod`). The decision is therefore **semantic** (driven by the role), with the
PN-1 merge as a syntactic scaffold that PN-2 confirms or undoes.

## 6. Worked example — "The tram driver gets out of the tram to change the switch to the correct position by hand."

- **PN_det (F₀+F₁).** `MERGE` `det`/`case` into heads ("the tram driver", "the switch"); `DROP` punct;
  flag "gets" via the light-verb lexicon; no negation. **Pending:** is "by hand" one unit? is the
  purpose clause binding? re-root off "gets"? (undecidable from UD+lexicon).
- **PN_srl (F₂).** SRL frame **change**: `ARG0`=tram driver, `ARG1`=switch, `ARG2/GOL`="to the correct
  position", `ARGM-MNR`="by hand"; **get-out** has `ARGM-PRP`="to change the switch". Now resolvable:
  `MERGE("by"→"hand")` into a manner unit (bare "hand" is no longer a node), `ROLE(by-hand, probeable)`,
  `TYPE(change→by-hand, verif-mod)`; `ARGM-PRP` ⇒ the purpose clause carries the asserted action ⇒
  `REATTACH`/re-root onto "change", `TYPE(gets→change, core)`, demote light-verb "gets". **Pending:** is
  "the correct position" fully checkable?
- **PN_llm (F₃).** SRL gave only the goal role; it cannot tell that "**correct**" is a normative judgment
  with no audio-visual truth value. LLM sets `ROLE("correct", na)`. Genuine residue: `¬F₂`-resolvable.

Every hand-off is principled: stage `k` touches a site **iff** its features determined the decision;
the next stage sees exactly the still-`P` sites.

## 7. Output `T*` → the CRF

`PN` yields `T* = (U, E*, comp, role)`: units `U` (merged spans), typed edges (§4 → ψ), roles
(`probeable`→the multimodal model's emission, `na`→uniform, `op`→contracted). `build_tree.py` is replaced/extended by a
`build_normalized_tree` step that consumes `T*`; the CRF (`tree_crf.py`, `run_crf_inference.py`) is
unchanged in form — it just gains the `verif-mod` edge potential (`λ_soft`).

## 8. Relation to the gold pilot & open items

- **The frozen 200-claim pilot (ADR-015) is PAUSED / superseded**: `PN` changes the *units*, so the
  node surface changes. Annotation waits until units are good; regenerate `tree_units_ud.tsv` + the
  pilot from `T*` after `PN` is built (still free — no annotation had started).
- **Eval upgrade (owed):** report **per-node label correctness on the *verifiable* subset** (`na`
  excluded from the denominator, VeriScore-style) and **faithfulness** (drop-a-node / corrupt-a-node
  sensitivity — does the verdict depend on the node labels), separately from claim-verdict accuracy.
- **To build:** `scripts/normalize_parse.py` (`PN`, resolve-once, edit-log + released `T*`); SRL model
  choice (TBD — English predicate-argument, must align to UD spans); the LLM edit schema (closed `𝓞`,
  JSON, validated against the parse); `λ_soft` for `verif-mod`.
- **Framing (paper).** Position between pure-rule parsing (brittle: the "hand"/light-verb pathologies)
  and pure-LLM decomposition (FactScore/DSG: no external referent). Contribution = *linguistically-
  informed normalization of a parse into checkable, modality-attributable verification units, inside a
  compositional AV tree-CRF* — an unoccupied conjunction (`research/LITERATURE.md` 2026-07-13).

---

*Cross-refs: ADR-016 (decisions.md); `compositional_verification_design.md` (the CRF `PN` feeds);
impl-plan §2.2 (composition potentials — superseded by §4 here), §4 (build step), §8/§8.1 (eval + paused
pilot); `research/LITERATURE.md` (2026-07-13 axis).*
