# AViD Phase 3 — Compositional Verification: Goal, Framing & Design Invariants
_Terminology follows docs/project_notes/terminology.md._

**Purpose.** The canonical design reference for the parse-tree (Phase 3) verifier: the goal, the
research question, and the invariants to keep in mind at *every* algorithm-design step. Full
feasibility analysis: `docs/plans/avid_phase3_compositional_tree_verification_v1.md`. Origin: user
design discussions 2026-06-30.

**Notation.** Per tree node `v`: **`e_v`** is the emission (the unary factor) — the node's own, direct
probe distribution from the multimodal model, per channel; **`s_v`** is the support marginal — the node's
support probability after the joint inference (belief propagation). Two distinct questions per node:
**existence** ("is the thing there at all, in any channel?") and **binding** ("are the present things
composed the way the claim says?"). Keep them separate — most past confusion came from conflating them.

---

## 0. Goal & research question

**Goal (simply).** Given a claim + a video-with-audio, produce a claim verdict (supported /
partially_supported / unsupported) **together with a faithful-by-construction, modality-attributed,
parse-tree explanation of it** — which parts are grounded, by which channel, and where composition
breaks. "Faithful" = the sub-unit verdicts actually **compose to** the claim verdict. The decomposition
is the contribution, not the raw verdict (proposal §1: full-claim verdicts are ~84% audio/visual
redundant, so a better yes/no is not the interesting result — the *structure* is).

**Research question.** *Does enforcing compositional + modality **consistency** between a claim's
parse-tree decomposition and its sub-unit/claim-level audio-visual verdicts yield more faithful and
more accurate verification — especially on negation, binding, and compositional-decoy cases — than
verifying units independently?*

---

## 1. The method in one idea: joint constrained inference (not a direction)

The real problem with independent verification is **inconsistency**: claim-level and sub-unit verdicts
don't agree. "Bottom-up" (compose parts up) and "top-down" (push parent down) are **not competing
philosophies to choose between** — they are the two halves of one computation. The object we want is:

> the single most-**consistent** assignment of (support, modality) to every node, reconciling the
> claim's evidence, the sub-units' evidence, and a set of compositional consistency rules *at once*.

On a tree this joint reconciliation is **exact and cheap** (max-product → the single most-consistent explanation;
sum-product → the modality marginals). The two passes ARE the algorithm; their individual "flaws" are
just what happens when you run only half of it. Concretely: a tree-structured CRF with **data
potentials** (`e_v`) + **consistency potentials** (the rules of §2). Inference = trade evidence against
consistency.

**Guardrail — consistency ≠ correctness.** Crank enforcement to infinity and you get a self-consistent
*wrong* answer (the model's bias made coherent). So enforcement strength is a **tunable knob and a
headline ablation**, and it must always be anchored by the evidence terms (and by gold / distant
labels, §6). How much structure may override noisy evidence depends on how *calibrated* the evidence is
— which is why de-saturating the verifier probs (75–78% sit at ≈1.00) is a prerequisite, not a
nice-to-have.

---

## 1b. Formalization: tree-tagging via CRF + belief propagation, and the multimodal-model mapping

**Yes — it is a tree-tagging problem.** We tag every node of the parse tree with a support-and-modality
label; the root's tag is the claim verdict. The first version (v1) runs **two independent per-modality CRFs**; below is one
modality, states `S = {no, A, B}` (visual: A=other, B=ocr; audio: A=speech, B=other). `sup(s) := [s≠no]`.

### The model (CRF)
Tree `T=(V,E)`, root `r`. Joint tag distribution given input `x`:
```
P(z | x) = (1/Z) · Π_{v∈V} φ_v(z_v) · Π_{(p,c)∈E} ψ_{rel(p,c)}(z_p, z_c)
Z        = Σ_z  Π_v φ_v(z_v) · Π_{(p,c)} ψ(z_p, z_c)
```
`φ` = emission (unary), `ψ` = transition (edge), `Z` = partition function. In HMM terms: emissions +
transitions, over a tree instead of a chain.

### Emission φ_v = the multimodal model's probe (interpretation confirmed)
For a node `v` we ask the multimodal model a **self-contained, unit-only** question (existing `formulate_questions.py`)
— **not** "given the claim…", because conditioning on the claim makes the model copy the whole-claim verdict onto
the part and ignore the unit itself (the documented claim-anchor collapse; ADR-011 anti-leak). Two passes give a
calibrated support probability `p = P(supported)` and a subtype split `q_A, q_B`:
```
φ_v(no) = 1−p ;   φ_v(A) = p·q_A ;   φ_v(B) = p·q_B        (uniform for na / un-probed; §1b.5)
```
**Unit-only is *right*, not a compromise:** in the CRF, claim context is meant to enter through the
**transitions**, not the emission. A local, unit-only emission is exactly the conditional independence a CRF
assumes (emissions independent given the tags), and the tree then reintroduces precisely the right
context through the transitions. **The anti-anchor decision and the CRF are the same idea.**

### Transition ψ = the structural/logical constraints (NOT the multimodal model)
`ψ_{rel}(z_p, z_c)` is set by the UD relation class (§2): deterministic with one strength knob `λ` (necessity) +
a negation flip (+ coordination), or a few learned scalars. **It is never a call to the multimodal model.** Division of labor:
> **the multimodal model does the perceiving (the emissions, at every granularity, including composed spans); the tree does
> the logic (the transitions: necessity, negation, coordination).**
This is deliberate: lean on the multimodal model's strength (concrete perceptual "is X there?" judgments), refuse its weakness (abstract
compositional reasoning). **Binding is still an emission** — the composed node's own probe — not a
transition.

### Inference = exact belief propagation (inside = upward, outside = downward)
```
UP:        m_{c→p}(z_p) = Σ_{z_c} φ_c(z_c) · ψ(z_p,z_c) · Π_{k∈ch(c)} m_{k→c}(z_c)
DOWN:      m_{p→c}(z_c) = Σ_{z_p} φ_p(z_p) · ψ(z_p,z_c) · m_{pa(p)→p}(z_p) · Π_{c'∈ch(p)\c} m_{c'→p}(z_p)
MARGINAL:  b_v(z_v)     ∝ φ_v(z_v) · m_{pa(v)→v}(z_v) · Π_{c∈ch(v)} m_{c→v}(z_v)
```
Sum-product → per-node marginals (support + modality posterior) and `Z` (= Σ over the root belief).
Replace `Σ` with `max` (+ backtrack) → the MAP consistent decomposition. On a fixed tree this is
**exact**: the upward pass is the *inside* recursion, the downward the *outside*; there is **no sum over
tree structures**, so this is belief propagation, not PCFG inside-outside (that only returns if the parse
is latent — impl-plan §10).

### 1b.5 na nodes: no emission, but yes transition (modelled properly)
A node marked *not a checkable unit* by a deterministic rule (`na` — the affordance-na, pronoun, empty, uuid, negation, light-verb, or duplicate rules) splits by
tree role:
- **Structural operators** (negation, copula `be`, `case`/`aux`/`det`/`punct`): **contract** — drop the
  variable, fold semantics into edges/unaries. Negation → a **unary flip** on its scope (§2.3); the rest
  are pass-through.
- **Unprobeable content** (pronoun, uuid, empty, vague-referent, light-verb): **keep the node, uniform
  emission (no call to the multimodal model), normal transitions.** Its tag is inferred from neighbors; with a uniform
  emission it carries **no evidence**, so — correctly — it **cannot veto** a parent (a necessity edge
  with an uninformative child does nothing), and the composed parent's own probe governs.

**So: emission — no** (uniform; probing "not" is nonsense and a probe call would be wasted);
**transition — yes, essential** (that is *how* an na node does its job — pass support through, or flip
it). Uniform ≠ absent: it means "no evidence," the honest state for an unprobeable node, and it stops na
nodes from spuriously vetoing or rescuing. The na node's marginal is still computed — driven by
structure, not by a (non-existent) emission.

---

### 1b.6 UPDATE (2026-07-15, ADR-017): support is 3-way {SUP, REF, NEI}; veto is label-driven

The binary support above (`φ_v(no)=1−p`) is replaced by a **3-way** per-modality emission — the pass-1
probe now answers **yes / no / can't-tell** (ADR-017, reversing the earlier v6 binary):
- **SUP** (yes): grounded; subtype split `q_A, q_B` as before.
- **REF** (no): verifiably absent — the scene/audio is available and the thing is not there. **Evidence
  against** → drives the necessity/veto edge.
- **NEI** (can't-tell): the view/audio is unavailable (off-screen/occluded/silent). **No evidence** →
  **abstain**: contributes nothing, cannot veto (→ partial) — like a uniform emission, but *labelled*.

This makes the child→parent **veto label-driven** (REF vetoes, NEI abstains), **replacing the
confidence-gated veto of §5**: the veto no longer depends on calibrating a saturated probability against a
threshold — it reads the label. Keep `na` (§1b.5 — not a checkable unit, decided upstream/text-only)
distinct from **NEI** (a probe outcome: checkable in principle, but not from *this* clip). Emission
calibration is now multi-class (3-way). Gated by the REF/NEI-separation study (issues.md 2026-07-15).

## 2. The consistency-rule family (the heart of the method)

| Rule | What it says | Hard / soft |
|---|---|---|
| **Negation / scope** | a `not` node flips the support polarity of its scope (§3) | **Hard** (logical) |
| **Coordination** | "A and B" needs both; "A or B" needs either | **Hard** (logical) |
| **Existence-necessity** | a binding cannot be supported if a **required** part is absent (§4, §5) | **Hard-ish** |
| **Modality traceability** | a node is not supported by modality *m* unless a constituent (or its own cross-modal binding) supplies *m*-evidence — "no modality from nowhere" | **Soft** (gestalt/holistic exceptions) |
| **Parent↔child agreement** | a node's marginal should agree with its own direct probe, traded off against neighbors (§5) | **Soft** |

Hard rules carve out the *feasible* labelings; soft rules shape the distribution within them. The
factor type / UD deprel supplies the parameters (which children are *required* vs *optional*; whether a
node is a negation/coordination/relation). This rule table is the auditable artifact that replaces the
old subtractive unit-filtering heuristics.

---

## 2b. What the tables mean, and where the numbers come from (plain language)

A transition ("table") is just a **compatibility score** between a parent node's label and a child
node's label — a small lookup: rows = parent label, cols = child label, each cell a number where `1.0`
= "normal combo, no opinion" and a small number = "fishy combo, discourage". The *only* thing a table
encodes is **which parent/child label-combos to frown on.**

Example — verb→object (`pushing`→`cart`), on YES/NO support (subtypes don't compose):

|            | child=NO | child=YES |
|------------|----------|-----------|
| parent=NO  | 1.0      | 1.0       |
| parent=YES | **0.05** | 1.0       |

Only "the composite is supported but the required child is absent" is discouraged (you can't push an
absent cart). An **optional** child (`amod` "red"→"car") gets an all-`1.0` table (nothing discouraged).
So a table ≈ "a short list of frowned-on combos + how hard", and the whole design is **one strictness
knob** `λ` (the `0.05`) applied to the *required* edges the parser already identifies.

**Where the numbers come from — three options (recommend deterministic v1):**
1. **Deterministic (v1):** hand-set `λ` (≈1–2 numbers total; required/optional comes from the parser).
   Auditable, reproducible, training-free. Correct for literal claims; misses lexical nuance
   ("a man is *reportedly* dancing").
2. **Learned (extension) — NOT a neural network.** The tables are a handful of numbers, so "learning" =
   **fit those few numbers to examples with known answers** (natural claims → root supported; perturbed
   → root unsupported). As simple as a **grid search over `λ`**, or gradient descent on the CRF
   likelihood (≈ logistic-regression scale, seconds). The large model (the multimodal model) stays separate — it only
   makes the emissions. Bonus: freely-learned tables should *recover* the rules (the `neg` table learns
   to flip) → validation figure.
3. **LLM-typed edges (nuance extension, not default):** a text-only LLM classifies each edge
   (`factual / hedged / modal / negated`), then a deterministic table maps class→`λ`. Keeps
   auditability (the LLM does linguistic typing, the table owns the number). Do **not** let the multimodal model output
   the transition value directly — it double-counts the multimodal model (the composed node's *emission* already
   asked it, with video) and injects noise into the part meant to be stable.

**Constituency backbone:** UD hands you the relation (deprel → required/optional for free); constituency
does **not** (edges are phrase→sub-constituent, unlabeled by function). To assign the same tables on a
constituency tree you need **head-finding rules** or a **constituency→dependency conversion** (which
recovers the deprels). Trade-off: UD → cleaner transitions; constituency → cleaner emission spans.
Complementary → the redundant-binding-probe lever (§7).

**Meta (anti-over-engineering):** the transition is a low-dimensional, largely universal prior —
deterministic is likely ~90% of the value. The real bottleneck is **emission calibration** (§1, the
saturated probs), not transition sophistication. Keep transitions simple; spend effort on calibration.

---

## 3. Negation invariant (the "structure is *necessary*" example)

Flat per-unit verification is **actively wrong** on negated claims (not merely less interpretable):
"not" is unprobeable, so it is dropped and the truth value silently flips.

> Claim "The dog is **not** barking." Video: a dog visibly/audibly barking.
> Flat: dog ✓ + barking ✓ → looks **supported**. Truth: **false**. Exactly inverted.

Tree fix: the negation is a **structural-`na`** node (no sensible direct probe) above "barking", with a
**flip** edge-potential. Upward: "barking supported" → flip → root unsupported. **Scope = the tree**
(the `not` only dominates "barking", so "...but running" is unaffected). Lead the paper's motivation
with this.

**Planned controlled experiment** (negations aren't in the natural data — claims are affirmative):
**inject negations** into affirmative claims and test that the tree flips while flat baselines invert.
Perturbation-set instance (proposal §10), paired with the binding decoys of §4.

---

## 4. A node's support = existence AND binding (two factors)

A binding-sensitive node `v`'s support decomposes into two factors, combined by **AND**:

```
s_v(supported)  ≈   [ required parts EXIST (reconciled, §5) ]   AND   [ BINDING holds (e_v says yes) ]
```

- **Binding is the composed node's own authority.** Part-existence NEVER confirms a binding; only `e_v`
  ("is a man dancing?") does. This is why we probe interior nodes directly.
- **Dancing decoy** (parts present, binding absent): Claim "a man is dancing"; video = a woman dancing +
  a man watching. "man" ✓, "dancing" ✓ (existence factor OK), but "is a man dancing?" → **no** (binding
  factor). `s = unsupported`. **Correct, and not "recovered" by part-existence.** The veto of §5 does
  not fire here (parts are present); the *binding factor* sinks it. Keep these two mechanisms separate.

---

## 5. The child→parent double-check (existence veto) — designed to not break other cases

**Intent (user, 2026-06-30):** a child that is strongly "not present" should adjust the claim's
confidence, or flip it. This is the legitimate bottom-up correction — but a *blanket* veto breaks
phrase-rescue, adjuncts, and cross-modal children. The safe design:

**The child→parent influence acts on the EXISTENCE factor only, and is a confidence-weighted
reconciliation, not a blanket veto.** Four gates:

1. **Requiredness-gated.** Only a **required** constituent (core arg / head noun — via UD deprel) can
   veto. A missing **optional** modifier (amod attribute, advmod, adjunct PP) → **downgrade to
   `partially_supported`**, never veto. ("red car" with unverifiable "red" → car ✓, redness unknown →
   partial, not unsupported.)
2. **All-channel absence.** The veto fires only if the child is absent in **every** channel (truly not
   there). A child present via speech but not video must **not** veto a visually-supported parent
   (e.g. "Emmonak" named but not shown). Channel accounting is the separate soft traceability rule.
3. **Calibrated-confidence-weighted.** A *confident, calibrated* child-absence competes with the
   parent's own evidence; the more-confident side wins. Weak child-absence does nothing
   (phrase-rescue-safe); strong child-absence + weak parent → flip; comparable confidence →
   **contested** → reduced confidence / partial, and **flagged** (an inconsistency worth surfacing).
4. **Rescue and veto are ONE mechanism.** Both are outcomes of the same confidence-weighted agreement
   potential between adjacent nodes on the existence question — a confident parent pulls a shaky child
   **up** (rescue); a confident absent child pulls a shaky parent **down** (veto). Direction is decided
   by which side is more confident, not by a fixed rule.

**Worked cases (the design must pass all):**
- *Legit veto:* "a man is pushing a cart", **no cart anywhere** (confident, all channels). Required part
  absent → existence fails → parent flips to unsupported (you can't push an absent cart). ✓
- *Dancing decoy:* parts present → veto does **not** fire; the binding factor (§4) sinks it. ✓
- *Phrase-rescue:* shaky "cart" atom under a confident "pushing a cart" → low-confidence child-absence
  loses to the confident phrase → no veto; the atom is rescued instead. ✓
- *Adjunct:* unverifiable "happily" in "dancing happily" → downgrade "dancing happily" to partial; core
  "a man is dancing" untouched. ✓
- *Cross-modal child:* "Emmonak" not visible but named in speech → present in audio → no veto of a
  speech-grounded parent. ✓

**This double-check IS the consistency objective, seen from the parent's side:** "parent says yes" +
"required child confidently says no" is exactly an *inconsistency*, which the joint inference (§1)
refuses to accept. It is a strong, asymmetric, requiredness-gated **edge potential** — not a new module.
Its reliability depends entirely on calibration (gate 3): with saturated probs every child looks
confident and the veto would over-fire. **Calibrate first.**

---

## 6. Consistency as evaluation and as supervision (two payoffs)

1. **Evaluation axis = novelty.** Flat decompositions are *unfaithful* (parts don't add up to the
   verdict); ours is faithful by construction. **Measure decomposition faithfulness** (do sub-unit
   labels compose to the claim label?) — unreported in AV verification, and exactly what "explain the
   claim result" demands.
2. **Gold-light supervision.** Natural claims are almost all true → **root = supported** is a free
   distant positive; **perturbations** (negation-injected, binding-decoy) are free negatives. A
   **cross-level consistency objective** (a parent's probe agrees with the composition of its
   children's) then calibrates the verifier and learns the soft rule weights **without hand gold**.
   Caveat: consistency self-supervision must stay anchored by these labels, or it reinforces bias.

---

## 7. Honest scope (what the method does and does NOT claim)

Multimodal models are bad at binding (Winoground/ARO/SugarCrepe) — that is the motivation, so `e_v` is itself
fallible and we cannot magically fix it. Pitch the method as: **correct aggregation** (never supported
just because parts exist), **preservation** (keep binding/negation failures flat methods erase),
**diagnosis** (`e_v − s_v` gap = binding-risk), and **robustness to *localized* noise** via same-target
redundancy (variance, not bias). Do **not** pitch it as "recovers the multimodal model's binding failures."

**Design lever:** build **redundant binding probes** (same binding via UD node *and* constituency node,
optionally a rephrasing) — the only principled way to fight binding noise — which gives the
UD-vs-constituency ablation real teeth.

---

## 8. Checklist for any aggregation/inference-rule proposal

- [ ] **Dancing decoy:** parts present, binding-no → **unsupported** (no part-existence recovery; §4).
- [ ] **Negation:** child supported under `not` → root **flips**; scope is local (§3).
- [ ] **Legit veto:** required part confidently absent (all channels) → parent flips (§5).
- [ ] **Phrase-rescue:** shaky atom under a confident enclosing same-target probe → atom rises, no veto (§5).
- [ ] **Adjunct:** unverifiable optional modifier → **partial**, not veto (§5).
- [ ] **Cross-modal child:** child present in one channel only → no veto of a parent grounded elsewhere (§5).
- [ ] **Unique wrong-"no" binding:** single binding probe confidently wrong-no, parts present → stays
      unsupported (unidentifiable from a true no; only redundant binding probes may move it; §7).
- [ ] **Consistency ≠ correctness:** enforcement strength is bounded by evidence/calibration (§1).
