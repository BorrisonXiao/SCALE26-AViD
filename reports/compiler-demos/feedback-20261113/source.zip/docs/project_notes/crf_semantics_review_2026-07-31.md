# AViD CRF node and potential semantics — review note

_Terminology follows docs/project_notes/terminology.md._

**Created:** 2026-07-31  
**Revised for readability:** 2026-08-04  
**Status:** Under review. Sections 1–9 describe the current final-T* implementation. Section 10
describes a proposed correction that has **not** yet been implemented.

## 1. Executive summary

The current model is **indexed by parse-derived nodes**, but its MLLM evidence is often computed from
a larger phrase or proposition. It is therefore more precise to call it:

> **a parse-indexed, span-conditioned tree CRF over overlapping proposition units**

Three objects must be kept separate:

1. the parse anchor, such as `crowd`;
2. the actual text queried against the source, such as
   `Huge crowd standing together chanting`;
3. the CRF state, which represents source support for that queried text.

The current implementation also has a mathematical state-space problem: two CRF states count as
support while only one counts as non-support. Consequently, the supposedly evidence-free unary
$(1/3,1/3,1/3)$ has aggregate support $2/3$, which exceeds the current supported threshold of $0.65$.

## 2. Running example: anchor versus queried proposition

For the poster claim:

> Huge crowd standing together chanting.

the tree visualization displays lexical anchors, but the verifier receives `pn_unit_text`:

| Parse anchor $a_v$ | Actual queried proposition $u_v$ | Node role |
|---|---|---|
| `crowd` | `Huge crowd standing together chanting` | probeable root |
| `standing` | `standing together` | probeable |
| `chanting` | `chanting` | probeable |
| `Huge` | no independent probe; included in the root proposition | `na` |
| `together` | no independent probe; included in `standing together` | `na` |

Thus, the CRF variable indexed by `crowd` describes support for the **full proposition anchored at
`crowd`**, not support for the single word *crowd*.

## 3. Notation

### 3.1 Inputs and tree structure

| Symbol | Definition | Concrete meaning / implementation |
|---|---|---|
| $c$ | Original claim text | For example, `Huge crowd standing together chanting.` |
| $m$ | Modality index | $m=V$ for visual; $m=A$ for audio |
| $x_m$ | Source evidence presented to the modality-specific MLLM | $x_V$: sampled video frames; $x_A$: the clip audio |
| $T^\ast$ | Normalized, parse-derived verification tree | Produced by parsing plus PN-1/PN-2/PN-3 normalization |
| $V_{\mathrm{crf}}$ | Non-functional nodes retained as CRF variables | Functional operators such as punctuation/case markers are contracted |
| $E_{\mathrm{crf}}$ | Directed parent–child edges between retained variables | Obtained from $T^\ast$ after functional-node contraction |
| $r$ | Root node | The node used for the claim-level readout |
| $v$ | A retained node | A generic current node |
| $p$ | Parent of node $v$ | The first retained ancestor of $v$ |
| $\operatorname{ch}(v)$ | Children of $v$ | Retained CRF children after contraction |

### 3.2 Node representation

| Symbol | Definition | Stored field |
|---|---|---|
| $a_v$ | Parse-derived lexical anchor for node $v$ | `node_text`, `span` |
| $u_v$ | Text surface actually queried against video/audio | `pn_unit_text`, `pn_unit_span` |
| $\rho_v$ | Node role: probeable, NA, or structural operator | `role` |
| $\kappa_v$ | Composition type of the incoming edge from $p$ to $v$ | `comp`, with raw relation class as fallback |

In general, $u_v \neq a_v$. Multiple $u_v$ surfaces may overlap; for example, a full-claim root probe
contains the text of several descendant probes.

### 3.3 CRF variables and potentials

| Symbol | Definition |
|---|---|
| $\mathcal S_m$ | State space for modality $m$ |
| $s$ | A generic state in $\mathcal S_m$ |
| $Z_v^{(m)}$ | Random CRF state assigned to queried proposition $u_v$ in modality $m$ |
| $z_v^{(m)}$ | One possible value of $Z_v^{(m)}$ |
| $\mathbf z^{(m)}$ | Complete state assignment $(z_v^{(m)})_{v\in V_{\mathrm{crf}}}$ |
| $P_m$ | Conditional distribution over all tree-state assignments for modality $m$ |
| $\phi_v^{(m)}(s)$ | Unary evidence potential for assigning state $s$ to node $v$ |
| $\psi_{\kappa_v}(s_p,s_v)$ | Pairwise compatibility potential for the parent and child states |
| $\lambda_{\kappa}$ | Penalty strength associated with edge type $\kappa$ |
| $\mathcal Z_m$ | Partition function that normalizes the CRF distribution |
| $b_v^{(m)}(s)$ | Posterior marginal probability of state $s$ at node $v$ after belief propagation |
| $M_{v\rightarrow p}^{(m)}(s_p)$ | Belief-propagation message from child $v$ to parent $p$ |
| $S_v^{(m)}$ | Aggregate support marginal at node $v$ in modality $m$ |

### 3.4 Probe and calibration symbols

| Symbol | Definition |
|---|---|
| $\boldsymbol\pi_v^{(m)}$ | Raw MLLM distribution over `YES`, `NO`, and `CAN'T_TELL` for $u_v$ |
| $\pi_{v,Y}^{(m)},\pi_{v,N}^{(m)},\pi_{v,C}^{(m)}$ | Raw probabilities of the three MLLM answers |
| $T_m$ | Temperature-scaling parameter for modality $m$ |
| $\widetilde\pi_{v,k}^{(m)}$ | Calibrated probability for answer $k\in\{Y,N,C\}$ |
| $A_m,B_m$ | The two current CRF states that both count as support in modality $m$ |

The term **emission probability** is informal. In a discriminative CRF, $\phi_v^{(m)}$ is a positive
unary potential, not necessarily a generative probability of observing $x_m$. Here it begins as a
normalized MLLM distribution and is then reconciled with the tree potentials.

## 4. Current joint model

Visual and audio inference run as two independent CRFs. For modality $m$:

$$
P_m\!\left(\mathbf z^{(m)} \mid x_m,c,T^\ast\right)
=
\frac{1}{\mathcal Z_m}
\prod_{v\in V_{\mathrm{crf}}}
\phi_v^{(m)}\!\left(z_v^{(m)};x_m,u_v\right)
\prod_{(p,v)\in E_{\mathrm{crf}}}
\psi_{\kappa_v}\!\left(z_p^{(m)},z_v^{(m)}\right).
$$

The normalizer is

$$
\mathcal Z_m
=
\sum_{\mathbf z^{(m)}}
\prod_{v\in V_{\mathrm{crf}}}
\phi_v^{(m)}\!\left(z_v^{(m)};x_m,u_v\right)
\prod_{(p,v)\in E_{\mathrm{crf}}}
\psi_{\kappa_v}\!\left(z_p^{(m)},z_v^{(m)}\right).
$$

Read the equation as follows:

| Component | Role |
|---|---|
| $\prod_v \phi_v^{(m)}$ | Collects the local MLLM evidence for every queried proposition |
| $\prod_{(p,v)}\psi_{\kappa_v}$ | Scores whether neighboring proposition labels are compositionally compatible |
| $\mathcal Z_m$ | Divides by the total score over all assignments so the result sums to one |

There are no visual-to-audio edges and no cross-modal belief-propagation messages.

## 5. Current unary potentials

### 5.1 Current CRF state spaces

The implemented state spaces are

$$
\mathcal S_V
=
\{\mathrm{NO},\mathrm{OCR},\text{V-OTHER}\},
$$

$$
\mathcal S_A
=
\{\mathrm{NO},\mathrm{SPEECH},\text{A-OTHER}\}.
$$

For compact notation, write the two supported subtype states as $A_m$ and $B_m$. Both are counted as
support:

$$
\operatorname{support}(s)=\mathbb 1[s\neq \mathrm{NO}].
$$

### 5.2 Raw MLLM distribution and calibration

For a probeable queried proposition $u_v$, the modality-specific MLLM returns

$$
\boldsymbol\pi_v^{(m)}
=
\left(
\pi_{v,Y}^{(m)},
\pi_{v,N}^{(m)},
\pi_{v,C}^{(m)}
\right),
$$

corresponding to `YES`, `NO`, and `CAN'T_TELL`. Temperature scaling gives

$$
\widetilde\pi_{v,k}^{(m)}
=
\frac{
\exp\!\left(\log \pi_{v,k}^{(m)}/T_m\right)
}{
\sum_{j\in\{Y,N,C\}}
\exp\!\left(\log \pi_{v,j}^{(m)}/T_m\right)
},
\qquad k\in\{Y,N,C\}.
$$

The final reported run uses $T_V=3.0$ and $T_A=2.0$.

### 5.3 Current mapping into CRF states

The implemented final-M2 mapping is

$$
\begin{aligned}
\phi_v^{(m)}(\mathrm{NO})
&= \widetilde\pi_{v,N}^{(m)}
 + \frac{1}{3}\widetilde\pi_{v,C}^{(m)},\\
\phi_v^{(m)}(A_m)
&= \frac{1}{2}\widetilde\pi_{v,Y}^{(m)}
 + \frac{1}{3}\widetilde\pi_{v,C}^{(m)},\\
\phi_v^{(m)}(B_m)
&= \frac{1}{2}\widetilde\pi_{v,Y}^{(m)}
 + \frac{1}{3}\widetilde\pi_{v,C}^{(m)}.
\end{aligned}
$$

Therefore the current M2 path does not independently estimate OCR versus visual-other or speech
versus audio-other. It initializes the two supported subtypes equally.

### 5.4 NA and missing-probe unaries

For $\rho_v=\mathrm{na}$, or when a source-probe lookup is missing, the implementation uses

$$
\phi_v^{(m)}
=
\left(\frac13,\frac13,\frac13\right).
$$

This is uniform over the three CRF states. It is not neutral with respect to the aggregate support
event because two states count as support.

### 5.5 Current negation operation

Let

$$
s_v^{(m)}
=
\phi_v^{(m)}(A_m)+\phi_v^{(m)}(B_m)
=
1-\phi_v^{(m)}(\mathrm{NO}).
$$

The current negation operation swaps aggregate support and non-support while preserving the ratio
between $A_m$ and $B_m$:

$$
\phi_{v,\neg}^{(m)}(\mathrm{NO})=s_v^{(m)},
\qquad
\phi_{v,\neg}^{(m)}(A_m)+\phi_{v,\neg}^{(m)}(B_m)
=
\phi_v^{(m)}(\mathrm{NO}).
$$

Negation is therefore an operation on the scoped unary, not a nontrivial pairwise `neg` matrix.

## 6. Current transition potentials

Define

$$
g(s)=\mathbb 1[s\neq\mathrm{NO}].
$$

For an incoming edge of type $\kappa_v$, the implementation uses

$$
\psi_{\kappa_v}(s_p,s_v)
=
\exp\!\left[
-\lambda_{\kappa_v}
g(s_p)\bigl(1-g(s_v)\bigr)
\right].
$$

Only one configuration is penalized: the parent is supported while the required child is `NO`.
With rows for the parent state and columns for the child state, ordered as
$(\mathrm{NO},A_m,B_m)$:

$$
\Psi_{\kappa}
=
\begin{bmatrix}
1 & 1 & 1\\
e^{-\lambda_{\kappa}} & 1 & 1\\
e^{-\lambda_{\kappa}} & 1 & 1
\end{bmatrix}.
$$

| Edge type $\kappa$ | $\lambda_{\kappa}$ | Penalized configuration |
|---|---:|---|
| `core`, `core-arg`, coordination | $3.0$ | supported parent + `NO` child; factor $e^{-3}\approx0.0498$ |
| `verif-mod` | $1.0$ | supported parent + `NO` child; factor $e^{-1}\approx0.3679$ |
| `inert-mod`, modifier, oblique, root, structural, unknown | $0$ | none; all-ones matrix |

Implementation caveats:

- `coordination-or` currently uses the same pairwise matrix as core/AND; it is not a true OR factor.
- The transition cannot distinguish $A_m$ from $B_m$.
- An all-ones edge sends a constant message and decouples the variables.

## 7. Exact belief propagation and current readout

To avoid confusing the modality symbol $m$ with a message, denote a BP message by $M$. The upward
message from child $v$ to parent $p$ is

$$
M_{v\rightarrow p}^{(m)}(s_p)
=
\sum_{s_v\in\mathcal S_m}
\phi_v^{(m)}(s_v)
\psi_{\kappa_v}(s_p,s_v)
\prod_{k\in\operatorname{ch}(v)}
M_{k\rightarrow v}^{(m)}(s_v).
$$

After upward and downward passes, the marginal is

$$
b_v^{(m)}(s_v)
\propto
\phi_v^{(m)}(s_v)
M_{p\rightarrow v}^{(m)}(s_v)
\prod_{k\in\operatorname{ch}(v)}
M_{k\rightarrow v}^{(m)}(s_v).
$$

Because $T^\ast$ is a fixed tree, sum-product returns exact marginals. Max-product returns the MAP
state assignment.

Current per-modality support is

$$
S_v^{(m)}
=
b_v^{(m)}(A_m)+b_v^{(m)}(B_m)
=
1-b_v^{(m)}(\mathrm{NO}).
$$

At the root:

$$
S_{\mathrm{root}}
=
\max\!\left(S_r^{(V)},S_r^{(A)}\right).
$$

The current thresholds are

$$
\operatorname{verdict}
=
\begin{cases}
\mathrm{supported}, & S_{\mathrm{root}}\ge0.65,\\
\mathrm{partially\ supported}, & 0.35\le S_{\mathrm{root}}<0.65,\\
\mathrm{unsupported}, & S_{\mathrm{root}}<0.35.
\end{cases}
$$

The maximum above is only a scalar verdict readout. `VIDEO`, `AUDIO`, `BOTH`, and `NEITHER` are
separate grounding attributions derived from the retained local modality decisions.

## 8. Mathematical problems in the current implementation

### 8.1 State-cardinality bias: evidence-free support equals $2/3$

For a pure `CAN'T_TELL` response,

$$
\left(
\widetilde\pi_Y,
\widetilde\pi_N,
\widetilde\pi_C
\right)
=(0,0,1),
$$

the mapping produces

$$
\phi_r^{(m)}
=
\left(\frac13,\frac13,\frac13\right).
$$

For an isolated root, $b_r^{(m)}=\phi_r^{(m)}$, so

$$
S_r^{(m)}
=
b_r^{(m)}(A_m)+b_r^{(m)}(B_m)
=
\frac23
\approx0.667.
$$

Since $0.667>0.65$, an evidence-free root is labeled supported. The same issue applies to an
unprobed NA root.

Observed in the current `decomp_m3.jsonl`:

- 485 roots are unprobed;
- 218 of those 485 receive a supported verdict;
- 94 unprobed roots have support exactly $2/3$ and are supported at the evidence-free baseline.

### 8.2 An unknown core child is not neutral

For a uniform leaf child connected through a core edge:

$$
M_{v\rightarrow p}^{(m)}(\mathrm{NO})=1,
$$

while for either supported parent state:

$$
M_{v\rightarrow p}^{(m)}(A_m)
=
M_{v\rightarrow p}^{(m)}(B_m)
=
\frac{2+e^{-\lambda}}{3}.
$$

With $\lambda=3$:

$$
\frac{2+e^{-3}}{3}\approx0.683.
$$

Thus the supposedly evidence-free child multiplies parent-support states by approximately $0.683$
while leaving the parent-`NO` state unchanged.

Suppose the parent unary is

$$
\phi_p=(0.2,0.4,0.4),
$$

so its initial support is $0.8$. After one uniform core child:

$$
\widetilde\phi_p
=
\left(0.2,\;0.4\times0.683,\;0.4\times0.683\right)
=
(0.2,0.273,0.273).
$$

After normalization, parent support falls to

$$
\frac{0.273+0.273}{0.2+0.273+0.273}
\approx0.732.
$$

With two identical unknown core children:

$$
\frac{0.8(0.683)^2}{0.2+0.8(0.683)^2}
\approx0.651,
$$

and with three it falls to approximately $0.560$. Unknown children can therefore move a parent from
supported to partial.

Final T* currently contains 425 `role=na, comp=core` nodes and 20 `role=na, comp=coord` nodes.

### 8.3 The current states cannot express neutral unknown

Let a child unary be

$$
q=(q_{\mathrm{NO}},q_A,q_B),
\qquad
q_{\mathrm{NO}}+q_A+q_B=1.
$$

Its message to a supported parent is

$$
M(\mathrm{supported\ parent})
=
e^{-\lambda}q_{\mathrm{NO}}+q_A+q_B
=
1-\left(1-e^{-\lambda}\right)q_{\mathrm{NO}}.
$$

The neutral value is $1$. For $\lambda>0$, neutrality is possible only if
$q_{\mathrm{NO}}=0$, meaning the child is certainly supported. Therefore no distribution over the
current states can mean both “unknown” and “structurally neutral.”

### 8.4 The subtype states are not identifiable

Current M2 initializes

$$
\phi_v^{(m)}(A_m)=\phi_v^{(m)}(B_m),
$$

and every implemented transition is invariant to swapping $A_m$ and $B_m$. Belief propagation
therefore preserves

$$
b_v^{(m)}(A_m)=b_v^{(m)}(B_m)
$$

at every node. OCR versus visual-other and speech versus audio-other are not identifiable; an argmax
subtype is determined only by tie-breaking order.

### 8.5 NA span loss

The 2026-07-31 audit found:

- 4,644 nodes with `role=na`;
- 3,486 (75.1%) covered inside at least one emitted queried surface;
- 1,158 (24.9%) absent from every emitted queried surface;
- 485 of 2,375 roots (20.4%) not source-probed.

Uniform potentials cannot recover semantic content that was never included in any source query.

### 8.6 Overlapping evidence factors

Parent and child query surfaces often overlap. The CRF multiplies their MLLM potentials, which can
double-count correlated evidence from the same frames or audio. This may be an intentional redundant
consistency signal, but it is not the conditional independence pattern suggested by ordinary
token-local tree tagging and should be evaluated explicitly.

## 9. How this differs from a conventional tree CRF

| Conventional parse-tree tagger | Current AViD model |
|---|---|
| The variable usually labels the token/constituent at node $v$ | The variable labels support for queried surface $u_v$ |
| Unary features are usually local to that token/constituent | $u_v$ may be a phrase, event proposition, or full claim |
| Parent and child observations are usually distinct | Parent and child query surfaces may overlap |
| Edges relate neighboring syntactic labels | Edges reconcile support labels for overlapping propositions |

The present graph is best viewed as a **tree-structured consistency model over parse-indexed
proposition factors**, not a word-level emission model.

## 10. Proposed corrected model — not yet implemented

### 10.1 Use semantically aligned states

For each modality, replace the current subtype states with

$$
\mathcal S_m^{\mathrm{new}}
=
\{\mathrm{SUP},\mathrm{REF},\mathrm{NEI}\}.
$$

Map the calibrated MLLM output directly:

$$
\begin{aligned}
\phi_v^{(m)}(\mathrm{SUP}) &= \widetilde\pi_{v,Y}^{(m)},\\
\phi_v^{(m)}(\mathrm{REF}) &= \widetilde\pi_{v,N}^{(m)},\\
\phi_v^{(m)}(\mathrm{NEI}) &= \widetilde\pi_{v,C}^{(m)}.
\end{aligned}
$$

This removes the duplicate support states and preserves `CAN'T_TELL` as an explicit outcome.

### 10.2 Make NEI structurally neutral

With rows and columns ordered as $(\mathrm{REF},\mathrm{SUP},\mathrm{NEI})$, use

$$
\Psi_{\mathrm{core}}^{\mathrm{new}}
=
\begin{bmatrix}
1 & 1 & 1\\
e^{-\lambda} & 1 & 1\\
1 & 1 & 1
\end{bmatrix}.
$$

Only a supported parent with a refuted required child is penalized. A pure-NEI child selects the
all-ones third column and therefore sends a constant message: it genuinely abstains. `verif-mod`
uses the same matrix with $\lambda_{\mathrm{soft}}$.

### 10.3 Handle NA without deleting semantics

If an NA node's text is already folded into an ancestor query, either contract the node or use

$$
\phi_v^{(m)}
=
(0,0,1)
$$

under the state order $(\mathrm{REF},\mathrm{SUP},\mathrm{NEI})$. The NEI-neutral transition then
prevents it from vetoing or rescuing its parent.

Required invariants:

1. every claim has a source-probed full normalized root proposition;
2. every non-structural content span occurs in at least one emitted query surface;
3. an NA node may omit an independent probe only when its meaning is retained in another surface.

### 10.4 Negation in the corrected state space

Negation swaps support and refutation while preserving NEI:

$$
\begin{aligned}
\phi_{v,\neg}^{(m)}(\mathrm{SUP}) &= \phi_v^{(m)}(\mathrm{REF}),\\
\phi_{v,\neg}^{(m)}(\mathrm{REF}) &= \phi_v^{(m)}(\mathrm{SUP}),\\
\phi_{v,\neg}^{(m)}(\mathrm{NEI}) &= \phi_v^{(m)}(\mathrm{NEI}).
\end{aligned}
$$

### 10.5 Multimodal root readout remains a design decision

One possible any-channel composition, assuming conditional independence of modalities, is

$$
P(\mathrm{SUP})
=
1-\bigl(1-s_V\bigr)\bigl(1-s_A\bigr),
$$

$$
P(\mathrm{REF})=r_Vr_A,
$$

$$
P(\mathrm{NEI})
=
\bigl(1-s_V\bigr)\bigl(1-s_A\bigr)-r_Vr_A,
$$

where $s_m=b_r^{(m)}(\mathrm{SUP})$ and $r_m=b_r^{(m)}(\mathrm{REF})$. This implements “support from
either channel is sufficient; refutation requires both channels.” The independence assumption and
alternative conservative readouts must be validated before adoption.

Most existing MLLM calls can be reused because the raw `{YES, NO, CAN'T_TELL}` distributions are
already stored. New source probes are needed only for previously omitted roots and newly constructed
coverage surfaces.

## 11. Review checklist before the next experiment freeze

1. Resolve the state-cardinality blocker before treating current root probabilities as calibrated.
2. Decide whether the CRF should use explicit `{SUP, REF, NEI}` states.
3. Enforce root-probe and semantic-span coverage invariants.
4. Decide whether overlapping root/interior probes require factor weights or another correction.
5. Implement a true OR coordination factor or explicitly document the current approximation.
6. Refit calibration and verdict thresholds on the human validation set rather than earlier CRF
   verdicts.
7. Rerun CRF inference, perturbation evaluation, and poster/deck numbers after the model is corrected.

## 12. Implementation anchors

- Probe surface and prompt: `scripts/run_m2_probe.py:102-110, 160-175`
- Temperature scaling and final-M2 unary mapping: `scripts/calibrate_m2.py:61-67, 334-349`
- Current state space and edge matrices: `scripts/tree_crf.py:1-96`
- Functional-node contraction, NA unary, two independent CRFs, and root readout:
  `scripts/run_crf_inference.py:227-313`
- Normalized anchor/surface fields: `scripts/build_tree.py:438-488`
