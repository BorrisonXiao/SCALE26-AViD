"""Recompute all2375 original outputs and the full cached449 condition offline."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_repairs_20261112'
def main():
 target=Path(tempfile.mkdtemp(prefix='avid-compiler-repairs-'))
 with zipfile.ZipFile(ROOT/'site/reports/compiler-demos/repairs-20261112/source.zip')as z:z.extractall(target)
 for line in(target/'COMPILER_REPAIRS_SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256((target/n).read_bytes()).hexdigest()==h,n
 env=dict(os.environ,PYTHONPATH=str(target/'scripts'),PYTHONDONTWRITEBYTECODE='1')
 for args in [('scripts/run_compiler_repairs.py','corpus'),('scripts/run_compiler_repairs.py','cached'),('scripts/analyze_compiler_repairs.py',)]:
  r=subprocess.run([sys.executable,*args],cwd=target,env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr;print('Replayed',args,flush=True)
 names=['direct_all.jsonl','cached_pipeline.jsonl','summary.json','corpus_reviewed.jsonl','semantic_review.json','remaining_cases.json','cases.json']
 for n in names:assert (RUN/n).read_bytes()==(target/RUN.relative_to(ROOT)/n).read_bytes(),n
 proof=dict(archive_sha256=hashlib.sha256((ROOT/'site/reports/compiler-demos/repairs-20261112/source.zip').read_bytes()).hexdigest(),extraction=str(target),sha256_inventory=True,originals=2375,cached_cohort=449,byte_identical_artifacts=names)
 (RUN/'archive_verification.json').write_text(json.dumps(proof,indent=2)+'\n');print('Verified seven byte-identical outputs.')
if __name__=='__main__':main()
