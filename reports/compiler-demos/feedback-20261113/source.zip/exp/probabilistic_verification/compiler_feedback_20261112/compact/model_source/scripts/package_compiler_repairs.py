"""Deterministic source/data overlay; preserve all historical archives."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_repairs_20261112'
def main():
 names=set()
 for folder,pattern in [('scripts','*.py'),('scripts/probabilistic_verification','*.py'),('scripts/report_assets','*'),('tests','*.py'),('tests/fixtures','*.json')]:
  names.update(str(p.relative_to(ROOT))for p in(ROOT/folder).glob(pattern)if p.is_file())
 names.update(['AGENTS.md','CLAUDE.md','docs/compiler_repairs_20261112.md','docs/project_notes/key_facts.md','docs/project_notes/decisions.md','docs/project_notes/issues.md','docs/project_notes/bugs.md','docs/project_notes/terminology.md','docs/project_notes/daily_log.json'])
 for folder,files in {
 'content_relations_20261105':['inputs.jsonl','results.jsonl'],
 'compiler_readiness_20261112':['cached_pipeline.jsonl','corpus_reviewed.jsonl','semantic_review.json','direct_all.jsonl'],
 'rewrite_all_20261112':['parsed.jsonl','inputs.jsonl'],
 'av_features_20261022':['visual_features.pt','visual_features.json','reviewed_claims.json','av_parses.json','checklist.json']}.items():
  names.update('exp/probabilistic_verification/'+folder+'/'+n for n in files)
 excluded={'archive_verification.json','browser_checks.json','publication.json','source_manifest.json'}
 names.update(str(p.relative_to(ROOT))for p in RUN.rglob('*')if p.is_file()and p.suffix in{'.json','.jsonl','.xml','.py','.pl','.pt'}and p.name not in excluded)
 data={n:(ROOT/n).read_bytes()for n in sorted(names)}
 for n,h in json.loads((RUN/'preserved_archives.json').read_text()).items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
 for n,h in json.loads((ROOT/'exp/probabilistic_verification/claim_rewrite_20261111/viewer_sha256.json').read_text()).items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
 manifest={n:hashlib.sha256(b).hexdigest()for n,b in data.items()};(RUN/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');data[str((RUN/'source_manifest.json').relative_to(ROOT))]=(RUN/'source_manifest.json').read_bytes()
 data['README_COMPILER_REPAIRS.md']=(ROOT/'docs/compiler_repairs_20261112.md').read_bytes()
 data['COMPILER_REPAIRS_SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+n+'\n'for n,b in sorted(data.items())).encode()
 target=ROOT/'site/reports/compiler-demos/repairs-20261112/source.zip';target.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in sorted(data.items()):
   info=zipfile.ZipInfo(n,date_time=(2026,11,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
 print('Packaged',len(data),'files;',round(target.stat().st_size/1048576,2),'MiB; all28olderarchives/26originalviewers unchanged.')
if __name__=='__main__':main()
