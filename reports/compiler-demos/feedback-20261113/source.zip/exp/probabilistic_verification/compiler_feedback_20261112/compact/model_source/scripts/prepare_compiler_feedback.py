"""Freeze the pilot, source snapshot and historical downloads before generation."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/compiler_feedback_20261112';OLD=ROOT/'exp/probabilistic_verification/compiler_repairs_20261112'
def freeze(target):
 source=target/'model_source/scripts';source.mkdir(parents=True,exist_ok=True)
 for p in(ROOT/'scripts').glob('*.py'):shutil.copy2(p,source/p.name)
 shutil.copytree(ROOT/'scripts/probabilistic_verification',source/'probabilistic_verification',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
 (target/'model_source/manifest.json').write_text(json.dumps({str(p.relative_to(target/'model_source')):hashlib.sha256(p.read_bytes()).hexdigest()for p in source.rglob('*.py')},indent=2)+'\n')
def main():
 RUN.mkdir(exist_ok=True,parents=True);shutil.copy2(OLD/'pilot_inputs.jsonl',RUN/'pilot_inputs.jsonl');shutil.copy2(OLD/'pilot_manifest.json',RUN/'pilot_manifest.json')
 (RUN/'preserved_archives.json').write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in(ROOT/'site').rglob('*.zip')},indent=2)+'\n')
 freeze(RUN)
 (RUN/'manifest.json').write_text(json.dumps(dict(baseline='compiler_repairs_20261112',baseline_site_commit='55e7ae6',corpus=2375,retained=1972,remaining=403,selection='Same24 earlier strict failures, fixed before generation; development only.',conditions=['Initial logical-form correction','At most two retries with actual compiler diagnostics','Same initial failures with generic retry instruction and no new diagnostic'],policy='Passing originals bypass the model. Stop after first compilation success; meaning review never triggers generation on a passing original. No per-claim condition selection; no training or media inference.'),indent=2)+'\n')
if __name__=='__main__':main()
