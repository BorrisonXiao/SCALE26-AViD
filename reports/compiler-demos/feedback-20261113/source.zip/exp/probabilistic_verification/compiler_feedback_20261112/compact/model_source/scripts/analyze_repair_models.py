"""Inspect fixed model conditions; do not promote pilot outputs to the corpus pool."""
import json
from pathlib import Path
from collections import Counter
from run_compiler_repairs import ROOT,RUN,read
from build_reviewed_compilation_report import slim
CONDITIONS=[('conservative30b',RUN,'Qwen3-30B-A3B: conservative prompt'),('revised8b',RUN/'revised_prompt_8b','Qwen3-VL-8B: revised structural prompt, text only')]
REASONS={'TbJqMFkNxARY_161':'Rejected: the compiled structure does not correctly preserve implication and uncertainty; this remains unresolved.', 'TgR_u37mCoQ4_1928':'Rejected: the rewrite says the video is for the Sheriff, changing the attachment from the logo.', 'TFOEIehBwT8Q_532':'Accepted development reading: shots OR heard explosion sound; six applies only to shots.'}
def main():
 conditions=[]
 for key,base,title in CONDITIONS:
  finals=read(base/'rewrite_final.jsonl');rounds={name:{r['claim_id']:r for r in read(base/name/'pipeline.jsonl')}for name in ['rewrite_first','rewrite_retry']};raw={name:{r['claim_id']:r for r in read(base/name/'raw.jsonl')}for name in rounds};cases=[]
  for row in finals:
   cid=row['claim_id'];stages=[]
   for name in rounds:
    if cid not in rounds[name]:continue
    p=rounds[name][cid];response=raw[name][cid];stages.append(dict(round=name,raw=response['raw'],messages=response['messages'],output=slim(p['output']),stage=p.get('stage'),finish_reason=response['finish_reason']))
   passing=row['output']['status']=='compiled';accepted=passing and cid=='TFOEIehBwT8Q_532'
   cases.append(dict(claim_id=cid,text=row['original'],attempt=row['attempt'],compiled=passing,accepted=accepted,review=REASONS[cid]if passing else'No complete program; see exact compiler feedback below.',rounds=stages))
  conditions.append(dict(id=key,title=title,config=json.loads((base/'model_config.json').read_text()),total=len(finals),first_compiled=sum(r['output']['status']=='compiled'for r in rounds['rewrite_first'].values()),retry_requests=len(rounds['rewrite_retry']),retry_compiled=sum(r['output']['status']=='compiled'for r in rounds['rewrite_retry'].values()),final_compiled=sum(c['compiled']for c in cases),approved=sum(c['accepted']for c in cases),failures=dict(Counter(r['output'].get('code')for r in finals if r['output']['status']!='compiled')),cases=cases))
 for folder,title in [('direct_8b','Direct forms: initial prompt missing format explanation'),('direct_guided_8b','Direct forms: explicit compact format guide')]:
  base=RUN/folder
  if not(base/'direct_forms/pipeline.jsonl').exists():continue
  rows=read(base/'direct_forms/pipeline.jsonl');raw={r['claim_id']:r for r in read(base/'direct_forms/raw.jsonl')};cases=[]
  for row in rows:
   passing=row['output']['status']=='compiled'
   cases.append(dict(claim_id=row['claim_id'],text=row['original'],compiled=passing,accepted=False,review=('Rejected: livestream is a free event entity instead of the intended purpose clause.'if row['claim_id']=='TInVWzp25aIM_68'else'Rejected: the acronym and expansion are bare undeclared strings; the stands-for relation and grounded participants need an explicit representation.')if passing else'No complete program.',rounds=[dict(round='direct form',raw=raw[row['claim_id']]['raw'],messages=raw[row['claim_id']]['messages'],output=slim(row['output']))]))
  conditions.append(dict(id=folder,title=title,config=json.loads((base/'model_config.json').read_text()),total=len(rows),final_compiled=sum(c['compiled']for c in cases),approved=0,failures=dict(Counter(r['output'].get('code')for r in rows if r['output']['status']!='compiled')),cases=cases))
 out=dict(note='24 deliberately selected strict failures; first12 fixed for direct forms. Conditions differ in prompt/model/compiler snapshot; not a causal prompt comparison. No outputs pooled into full-corpus counts.',conditions=conditions)
 (RUN/'model_comparison.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print([(c['id'],c['total'],c['final_compiled'],c['approved'])for c in conditions])
if __name__=='__main__':main()
