"""Verify the historical default without changing prior experiment artifacts."""
import json,time
from run_content_relations_census import compile_one
from run_compiler_repairs import ROOT,RUN,read
source=ROOT/'exp/probabilistic_verification/content_relations_20261105';started=time.perf_counter()
changed=[r['claim_id']for r,b in zip(read(source/'inputs.jsonl'),read(source/'results.jsonl'))if json.loads(json.dumps(compile_one(r)))!=b]
p=dict(records=2375,changed=changed,exact_json_match=not changed,seconds=time.perf_counter()-started)
(RUN/'historical_regression.json').write_text(json.dumps(p,indent=2)+'\n');assert not changed;print(p)
