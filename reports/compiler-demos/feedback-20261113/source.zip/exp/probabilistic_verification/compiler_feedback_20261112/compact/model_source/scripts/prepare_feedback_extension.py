"""Select an additional fixed failure sample without looking at new outputs."""
import json,collections
from pathlib import Path
from prepare_compiler_feedback import ROOT,RUN,OLD

def main():
 read=lambda p:list(map(json.loads,p.read_text().splitlines()))
 direct={r['claim_id']:r for r in read(OLD/'direct_all.jsonl')};originals={r['claim_id']:r for r in read(ROOT/'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')};pilot={r['claim_id']for r in read(RUN/'pilot_inputs.jsonl')}
 groups=collections.defaultdict(list)
 for r in json.loads((OLD/'remaining_cases.json').read_text()):
  if r['claim_id']not in pilot and direct[r['claim_id']]['status']!='compiled':groups[r['stage']+'/'+r['code']].append(r)
 totals={k:len(v)for k,v in groups.items()};chosen=[];counts=collections.Counter()
 while len(chosen)<72:
  key=min((k for k,v in groups.items()if v),key=lambda k:(counts[k]/totals[k],-totals[k],k));chosen.append(groups[key].pop(0));counts[key]+=1
 (RUN/'extension_inputs.jsonl').write_text(''.join(json.dumps(originals[r['claim_id']],ensure_ascii=False)+'\n'for r in chosen))
 (RUN/'extension_manifest.json').write_text(json.dumps(dict(total=len(chosen),claim_ids=[r['claim_id']for r in chosen],strata=dict(counts),eligible_remaining=376,excluded_prior_pilot=len(pilot),selection='Deterministic allocation by first-stop stage/code, proportional after visiting each available stratum. Source corpus order within each stratum. Fixed before new model outputs or judgments; development only.'),indent=2)+'\n')
 print(dict(counts))
if __name__=='__main__':main()
