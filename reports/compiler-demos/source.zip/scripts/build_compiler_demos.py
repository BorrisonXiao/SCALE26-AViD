#!/usr/bin/env python3
"""Build the current compiler demos, full outputs and linked daily progress."""
import json,shutil
from html import escape as esc
from pathlib import Path
from string import Template
from build_reviewed_compilation_report import slim

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/content_relations_20261105'
ASSETS=ROOT/'scripts/report_assets'

def read(name):return json.loads((RUN/name).read_text())
def rows(path):return {r['claim_id']:r for r in map(json.loads,path.read_text().splitlines())}
def view(row):return slim(dict(row,status='compiled')if 'program'in row else row)
def link(href,label):return '<a href="'+esc(href,quote=True)+'">'+esc(label)+'</a>'
def demo_link(cid,label):return link('compiler-demos.html?claim='+cid+'#walkthroughs',label)
def table(n,title,headers,data):
    return '<div class="table-wrap"><table><caption>Table '+str(n)+'. '+esc(title)+'</caption><thead><tr>'+''.join('<th>'+esc(h)+'</th>'for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(v)+'</td>'for v in row)+'</tr>'for row in data)+'</tbody></table></div>'

def latest_work(summary):
    h='<h2>Completed: numbers, appositions, lists and clauses</h2><p>The compiler still follows one semantic-role/dependency path over the unchanged original sentences. This round adds bounded repairs using explicit source words and grammatical links.</p>'
    h+='<div class="metric-row"><div class="box"><strong>'+format(summary['accepted'],',')+'</strong><p>Pass the current checks<br>Previously '+format(summary['before_accepted'],',')+'</p></div><div class="box"><strong>'+str(summary['recovered'])+'</strong><p>Newly pass<br>No earlier pass lost</p></div><div class="box"><strong>'+str(summary['tests'])+'</strong><p>Regression tests pass<br>Including native logic controls</p></div></div>'
    h+='<h3 id="step-omissions">1. Numbers and appositions</h3><ul>'
    for cid,text in [('Tg0UxWYuPeJ0_385','Keep Robot1 and Robot2 distinct using their identifiers.'),('TbJqMFkNxARY_165','Keep both bounds in between67 and75 boxes.'),('TjHepwuhkYFA_1042','Keep the complete1.2 million resident count.'),('T2G_ACMxR_I4_1145','Keep roughly2.8 million miles as an approximate distance.'),('T2G_ACMxR_I4_1220','Keep volcanic cone after the full name Mons Littrow.'),('TW4OYA3RN-Hw_1769','Retain a publisher description and both publications under it.')]:
        text=text.replace('Robot1','Robot 1').replace('Robot2','Robot 2').replace('between67','between 67').replace('and75','and 75').replace('complete1.2','complete 1.2').replace('roughly2.8','roughly 2.8')
        h+='<li>'+demo_link(cid,text)+'</li>'
    h+='</ul><p>Postposed numbers are retained only for declared label nouns or joined names such as IM-1. The broader first rule incorrectly treated dates and tallies as identifiers; it was restricted before the final run. A number attached to the wrong noun, as in the remaining lane-three case, stays flagged. Newly recovered nominal coordination is restricted to AND; OR alternatives stay unresolved.</p>'
    h+='<h3 id="step-clauses">2. Lists and embedded clauses</h3><ul>'
    for cid,text in [('TQEmEycTI0RQ_863','Build all six named people, with party descriptions and the co-leader subgroup.'),('TjHepwuhkYFA_1053','Represent the plates meeting at the Sagaing Fault, rather than a where-clause string.'),('TgR_u37mCoQ4_1868','Keep the changed event inside describes how, rather than asserting it separately.')]:h+='<li>'+demo_link(cid,text)+'</li>'
    h+='</ul><p>Both duplicated leader-list claims now pass the structural checks. Two of the eight prior hidden-clause alerts pass. The describes-how example still has imperfect noun-phrase attachments; the list pronouns remain unresolved.</p><h3 id="remaining-clauses">Six clause cases remain flagged</h3><p>These candidates are saved for inspection and are refused by strict compilation. The diagnoses below are assistant interpretations of their saved parses.</p>'
    for r in read('clause_review.json')['remaining']:
        h+='<article class="remaining-case"><p class="muted">'+esc(r['claim_id'])+'</p><blockquote>'+esc(r['text'])+'</blockquote><p>'+esc(r['reason'])+'</p>'+link('compiler-demos.html?claim='+r['claim_id']+'#outputs','Inspect the saved candidate')+'</article>'
    h+='<h3>Proposed next steps and goals</h3><ol><li>Review newly passing outputs with the user—check that recovered content has the intended relationships before further rule expansion.</li><li>Inspect remaining measurements and mixed noun/clause objects—choose a small set that can be represented faithfully, keeping explicit refusals for ambiguous cases.</li></ol><p>Reference resolution, larger-program profiling and sentence rewriting remain deferred. No new model call, media inference or relation-training experiment was run.</p>'
    return h

def results(summary):
    reasons=summary['refusal_reasons']
    h='<h2>Measured results and limits</h2>'
    h+=table(1,'All 2,375 original cached claims. These are compilation outcomes, not accuracy.',['Outcome','Before this round','Current'],[
        ('Pass the current checks',summary['before_accepted'],summary['accepted']),('Executable candidates',summary['before_executable'],summary['executable']),
        ('Lexical coverage alerts',227,reasons['coverage_omission']),('Hidden-clause alerts',8,reasons['opaque_clause']),('Incomplete-list alerts',2,reasons.get('incomplete_enumeration',0)),('Parser/compiler refusals',272,2375-summary['executable'])])
    h+='<p><b>'+str(summary['recovered'])+' newly pass; no earlier pass or executable candidate is lost.</b> '+str(summary['changed_programs'])+' program hashes change. All 11 programs previously rated faithful by the user remain byte-identical and pass the checks. No unexpected exceptions occurred.</p>'
    h+=table(2,'Remaining refusal and review reasons. Lexical/structural alerts retain diagnostic candidates.',['Reason','Claims'],[(esc(k.replace('_',' ')),v)for k,v in sorted(reasons.items(),key=lambda p:-p[1])])
    h+='<p>Among the 173 lexical alerts, 49 contain missing proper-name tokens and 45 contain missing numbers; categories overlap. These include typed dates/values, malformed labels, omitted clauses and complex coordination. The failure ledger retains every missing token.</p>'
    review=read('targeted_review.json')
    h+=table(3,'Post-freeze diagnostic review of 12 seeded recoveries. Only the local repair is judged.',['Claim','Target retained','Remaining issue or limitation'],[(link('compiler-demos.html?claim='+r['claim_id']+'#outputs',r['claim_id']),'Yes',esc(r['remaining_limit']))for r in review['cases']])
    h+='<p>All twelve inspected targets are retained. This compiler-author review is not independent human gold or a whole-claim accuracy estimate. All corpus texts were processed previously. Remaining defects include a transition treated as a noun, an opaque back-up phrase and nominal suspicion semantics. No held-out semantic gain is claimed.</p>'
    h+='<p><b>291 regression checks pass</b>, including native DeepProbLog tests of both range bounds and the earlier OCR/speech policy. The new range tests supply group counts of 70,80 or unavailable: they return supported, refuted or insufficient evidence. They do not count objects in media. Minimum/maximum count properties, quantities and appositive relations still require matching evidence functions.</p>'
    h+='<p>The final cached census took 30.96 seconds, excluding upstream parsing and input loading. This is not inference/training cost profiling. The initial source freeze preceded the 12-case review. A later code audit restricted recovered nominal coordination to AND, leaving OR alternatives unresolved. The final guard changes no saved corpus output; the earlier freeze is preserved. Original inputs and the earlier exploratory outputs are retained. Historical source archives remain available.</p><h3>Downloads and reproduction</h3><p>'
    downloads=[('README.md','Implementation'),('source.zip','Source and exact replay'),('analysis.json','Statistics'),('targeted_review.json','Targeted review'),('remaining_cases.json','All remaining failures'),('clause_review.json','Clause diagnoses'),('daily_log.json','Daily log records'),('tests.xml','Tests')]
    h+=' · '.join(link('compiler-demos/'+p,label)for p,label in downloads)
    h+='</p><p>'+link('compiler-demos/history/content-recovery-20261105-source.zip','Previous round’s original source archive')+' · '+link('verification-pipeline.html#next-steps','Current checklist')+'</p>'
    return h

def daily_log(data):
    h='<h2>Daily log</h2><p>'+esc(data['note'])+'</p>'
    for day in data['days']:
        h+='<section class="progress-day" id="day-'+day['date']+'"><h3><time datetime="'+day['date']+'">'+day['date']+'</time></h3><ul>'
        for item in day['items']:h+='<li>'+esc(item['text'])+' '+link(item['href'],item['label'])+'</li>'
        h+='</ul></section>'
    return h+'<p>Dates use America/New_York. Future work remains listed separately from completed entries. Log format follows '+link('https://borrisonxiao.github.io/ai2ai-duplex-report/daily-log.html','the supplied daily-log example')+'.</p>'

def main():
    summary=read('analysis.json');current=rows(RUN/'results.jsonl');previous=rows(RUN/'baseline.jsonl');inputs=rows(RUN/'inputs.jsonl')
    folder=ROOT/'site/reports/compiler-demos';folder.mkdir(parents=True,exist_ok=True)
    demos=[];baselines={}
    for c in read('demo_explanations.json')['cases']:
        cid=c['claim_id'];path=c['baseline_path']
        if path not in baselines:baselines[path]=rows(ROOT/path)
        old=baselines[path][cid];after=current[cid];assert inputs[cid]['text']==old['text']==after['text']and after['status']=='compiled',cid
        tokens=inputs[cid]['tokens'];selected=[t for t in tokens if t['id']in c['token_ids']]
        demos.append(dict(c,text=after['text'],old_label=c['baseline_label'],old_status=old['status'],old_code=old.get('code'),before_output=view(old),current_output=view(after),
            parser_links=[dict(word=t['text'],pos=t['upos'],relation=t['deprel'],parent=next((u['text']for u in tokens if u['id']==t['head']),'root'))for t in selected]))
    dump=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')
    dump(folder/'examples.json',demos);index=[];chunks=[]
    for i,(cid,row)in enumerate(current.items()):
        old=previous[cid];changed=row.get('program_sha256')!=old.get('program_sha256');name='cases-'+str(i//100).zfill(2)+'.json'
        index.append(dict(claim_id=cid,text=row['text'],accepted=row['status']=='compiled',review='program'in row and row['status']!='compiled',refused='program'not in row,changed=changed,recovered=row['status']=='compiled'and old['status']!='compiled',chunk=name))
        if i%100==0:chunks.append([])
        before,after=view(old),view(row)
        chunks[-1].append(dict(claim_id=cid,before=before,after=after if after!=before else None,status=row['status'],code=row.get('code'),reason=row.get('reason'),structural_alerts=row.get('structural_alerts',[]),coverage=row.get('coverage'),program_unchanged=not changed))
    dump(folder/'index.json',index)
    for i,chunk in enumerate(chunks):dump(folder/('cases-'+str(i).zfill(2)+'.json'),chunk)
    for name in ['analysis.json','changed_cases.json','recovered_cases.json','new_review_flags.json','targeted_review.json','remaining_cases.json','clause_review.json','daily_log.json','native_demo.json','frozen_manifest.json','tests.xml']:
        shutil.copy2(RUN/name,folder/name)
    shutil.copy2(ROOT/'docs/content_relations_compilation.md',folder/'README.md')
    tabs=[('current-work','Latest changes'),('walkthroughs','Simple demos'),('outputs','Full saved outputs'),('results','Results and limits'),('daily-progress','Daily log')]
    tab_html='<div class="tabs" role="tablist" aria-label="Report views">'+''.join('<button role="tab" id="tab-'+key+'" aria-selected="'+str(key=='current-work').lower()+'" aria-controls="'+key+'" data-tab="'+key+'">'+label+'</button>'for key,label in tabs)+'</div>'
    page=Template((ASSETS/'compiler_demos_template.html').read_text()).substitute(style=(ASSETS/'claim_output_view.css').read_text()+(ASSETS/'compiler_demos.css').read_text(),
        demo_count=len(demos),accepted=format(summary['accepted'],','),previous=format(summary['before_accepted'],','),executable=format(summary['executable'],','),tabs=tab_html,latest_work=latest_work(summary),results=results(summary),daily_log=daily_log(read('daily_log.json')),
        output_script=(ASSETS/'claim_output_view.js').read_text(),demo_script=(ASSETS/'compiler_demos.js').read_text())
    # Fix spacing in newly written narrative counts, leaving IDs and URLs intact.
    (ROOT/'site/reports/compiler-demos.html').write_text(page)
    print('Built',len(demos),'demos,2375 saved outputs and',len(read('daily_log.json')['days']),'daily entries.')

if __name__=='__main__':main()
