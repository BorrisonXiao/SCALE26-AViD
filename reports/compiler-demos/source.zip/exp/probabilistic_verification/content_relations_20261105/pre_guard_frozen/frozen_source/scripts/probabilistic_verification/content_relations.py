"""Retain explicit names, quantities, list members and embedded clauses.

One SRL/dependency translation. All repairs require source positions and grammar;
they neither rewrite the sentence nor choose between parsers. Apposition records
a grammatical relation, not inferred identity. Evidence functions remain needed.
"""
from __future__ import annotations

import copy
import re

from .compilation_followup import walk_events
from .content_recovery import compile_content_recovery, _add_nominal, tid, UNITS
from .reviewed_srl import _frames, _prune_entities, _replace_references
from .scoped_srl import SourceSyntax, quoted_spans
from .semantic_srl import inherit_routes
from .compilation_checks_v2 import words
from .scope_coverage import IDENTIFIER_NOUNS

SCALE = {'hundred','thousand','million','billion','trillion'}
CARDINAL = r'(?:\d[\d,.]*|one|two|three|four|five|six|seven|eight|nine|ten)'
LABEL_NOUNS = IDENTIFIER_NOUNS | {'robot','lane','mission','boat','ship','guard'}


def prepare_relations(record):
    r=copy.deepcopy(record);s=SourceSyntax(r);frames=_frames(s);notes=[]
    # An interrogative content clause can be attached through the word "how".
    # Relink its existing finite frame; do not infer a missing subject or event.
    for marker in s.tokens:
        owner=s.by_id.get(marker['head'])
        if (marker['lemma'].casefold()!='how' or marker['deprel'] not in {'obj','ccomp'}
                or not owner or owner['lemma'].casefold() not in {'describe','explain','investigate'}
                or owner['id'] not in frames):continue
        children=[t for t in s.children[marker['id']] if t['deprel']=='advcl:relcl'
                  and t['upos']=='VERB' and t['id'] in frames]
        if len(children)!=1 or not any(t['deprel'].startswith('nsubj') for t in s.children[children[0]['id']]):continue
        if any(lo<=marker['start_char']<hi for lo,hi,_ in quoted_spans(r['text'])):continue
        child=children[0];child.update(head=owner['id'],deprel='ccomp')
        marker.update(head=child['id'],deprel='advmod')
        notes.append(dict(kind='interrogative_content_attachment',event='e'+str(child['id']),parent='e'+str(owner['id']),marker='how'))

    # Within an explicit colon list, separate a common title from its coordinated
    # names, and attach "of PARTY" to the whole name rather than its last word.
    s=SourceSyntax(r)
    for first in s.tokens:
        owner=s.by_id.get(first['head'])
        if first['deprel']!='appos' or not owner or ':' not in r['text'][owner['end_char']:first['start_char']]:continue
        ids=s.subtree(first['id'])
        if any(s.by_id[i]['upos'] in {'VERB','AUX'} for i in ids):continue
        for i in sorted(ids):
            token=s.by_id[i]
            if token['upos']=='NOUN':
                names=[t for t in s.children[i] if t['upos']=='PROPN' and t['deprel']=='flat']
                if len(names)==1 and any(t['upos']=='PROPN' and t['deprel']=='conj' for t in s.children[names[0]['id']]):
                    names[0]['deprel']='appos'
            if token['upos']=='PROPN' and token['deprel'].startswith('flat'):
                top=token;seen=set()
                while top['deprel'].startswith('flat') and top['head'] in s.by_id and top['id'] not in seen:
                    seen.add(top['id']);top=s.by_id[top['head']]
                for child in s.children[i]:
                    if child['deprel']=='nmod' and any(t['deprel']=='case' for t in s.children[child['id']]):child['head']=top['id']
    return r,notes


def recover_identifiers(record,form,notes):
    s=SourceSyntax(record)
    for entity in form['entities']:
        head=s.by_id.get(tid(entity['id'],'x'))
        if not head or entity.get('quantity') or head['upos'] not in {'NOUN','PROPN'}:continue
        if head['upos']=='NOUN' and 'Number=Plur' in (head.get('feats') or ''):continue
        suffixes=[t for t in s.children[head['id']] if t['upos']=='NUM' and t['deprel'] in {'dep','nummod','appos'}
                  and t['start_char']>=head['end_char']
                  and re.fullmatch(r'\s*[-–]?\s*',record['text'][head['end_char']:t['start_char']])]
        if len(suffixes)!=1:continue
        token=suffixes[0]
        joined=bool(re.fullmatch(r'[-–]',record['text'][head['end_char']:token['start_char']]))
        if head['lemma'].casefold() not in LABEL_NOUNS and not joined:continue
        if set(words(token['text']))<=set(words(entity['text'])) or any(p.get('role')=='identifier' and p['value']==token['text'] for p in entity.get('properties',[])):continue
        entity.setdefault('properties',[]).append(dict(role='identifier',value=token['text']))
        notes.append(dict(kind='numeric_identifier',entity=entity['id'],value=token['text']))


def recover_quantities(record,form,notes):
    s=SourceSyntax(record)
    for entity in list(form['entities']):
        head=s.by_id.get(tid(entity['id'],'x'))
        if not head:continue
        modifiers=[t for t in s.children[head['id']] if t['deprel']=='nummod' and t['start_char']<head['start_char']]
        if len(modifiers)!=1:continue
        number=modifiers[0];value=None;bounds=None
        if number['lemma'].casefold() in SCALE:
            children=[t for t in s.children[number['id']] if t['upos']=='NUM' and t['deprel']=='compound']
            if len(children)==1 and re.fullmatch(CARDINAL,children[0]['text'],re.I):
                value=record['text'][children[0]['start_char']:number['end_char']]
                prefix=record['text'][max(0,children[0]['start_char']-24):children[0]['start_char']]
        else:
            prefix=record['text'][max(0,number['start_char']-24):number['start_char']]
            # Require both a grammatical numeric attachment and an explicit
            # between/and or to range. Ordinary "two and three boxes" is not one.
            tail=record['text'][number['start_char']:head['start_char']]
            m=re.fullmatch('('+CARDINAL+r')\s+(to)\s+('+CARDINAL+r')\s+(?:more\s+)?',tail,re.I)
            if not m and re.search(r'\bbetween\s*$',prefix,re.I):
                m=re.fullmatch('('+CARDINAL+r')\s+(and)\s+('+CARDINAL+r')\s+',tail,re.I)
            if m:bounds=(m[1],m[3]);value=m[1]+' '+m[2]+' '+m[3]
        if value is None:continue
        owners=[(e,role) for e in walk_events(form) for role,v in e['arguments'].items() if v==entity['id']]
        unit=head['lemma'].casefold();is_distance=unit in UNITS and len(owners)==1 and owners[0][0]['predicate'] in {'travel','fly','move','cover','last'}
        qualifier=re.search(r'\b(roughly|about|around|approximately|nearly|at least|at most|more than|less than)\s*$',prefix,re.I)
        operator={'at least':'at_least','at most':'at_most','more than':'more_than','less than':'less_than'}.get(qualifier[1].casefold(),'approx') if qualifier else 'exact'
        if is_distance:
            event,role=owners[0];kind='duration' if unit in {'day','hour','minute','second'} else 'measurement'
            event['arguments'][role]=dict(kind=kind,value=(qualifier[1]+' ' if qualifier else '')+value,unit=head['text'])
        elif bounds:
            entity.pop('quantity',None);entity['type']='group'
            entity.setdefault('properties',[]).extend([dict(role='minimum_count',value=bounds[0]),dict(role='maximum_count',value=bounds[1])])
        elif unit in {'rmb','usd','dollar','yuan','euro','pound'}:
            entity.pop('quantity',None);entity['type']='entity'
            entity.setdefault('properties',[]).append(dict(role='amount',value=value))
        else:
            entity.update(type='group',quantity=dict(operator=operator,value=value))
        notes.append(dict(kind='complete_quantity',entity=entity['id'],value=value,bounds=bounds,operator=operator))
    _prune_entities(form)


def recover_colon_lists(record,form,notes):
    s=SourceSyntax(record)
    for entity in list(form['entities']):
        head=s.by_id.get(tid(entity['id'],'x'))
        if not head:continue
        firsts=[t for t in s.children[head['id']] if t['deprel']=='appos' and t['upos']=='PROPN'
                and re.fullmatch(r'\s*:\s*',record['text'][head['end_char']:t['start_char']])]
        if len(firsts)!=1:continue
        first=firsts[0]
        # The preceding participant repair can attach a final common-noun title
        # to the outer list noun. Include that explicit nominal conjunct too.
        extra=[t for t in s.children[head['id']] if t['deprel']=='conj' and t['upos'] in {'NOUN','PROPN'}
               and t['start_char']>first['start_char']]
        local=copy.deepcopy(record)
        for token in local['tokens']:
            if token['id'] in {t['id'] for t in extra}:token['head']=first['id']
        local_s=SourceSyntax(local);ids=local_s.subtree(first['id'])
        if any(s.by_id[i]['upos'] in {'VERB','AUX'} for i in ids):continue
        group='g'+str(head['id'])
        if group not in {e['id'] for e in form['entities']}:continue
        # Rebuild this explicit nominal list only. The title is the group, not
        # an extra member alongside the people named after its colon.
        form['entities']=[e for e in form['entities'] if tid(e['id'],'x') not in ids and tid(e['id'],'g') not in ids]
        members=_add_nominal(local_s,form,first['id']);es={e['id']:e for e in form['entities']}
        if members not in es or not es[members].get('relations'):continue
        entity['relations']=[r for r in entity.get('relations',[]) if r['role']!='member']+copy.deepcopy(es[members]['relations'])
        _replace_references(form,{group:entity['id']})
        form['entities']=[e for e in form['entities'] if e['id']!=group]
        for title in list(form['entities']):
            token=s.by_id.get(tid(title['id'],'x'))
            if not token or token['id'] not in ids or token['upos']!='NOUN':continue
            names=[t for t in s.children[token['id']] if t['deprel']=='appos' and t['upos']=='PROPN']
            if len(names)==1:
                sub=_add_nominal(s,form,names[0]['id']);byid={e['id']:e for e in form['entities']}
                if sub.startswith('g'):
                    title['relations']=copy.deepcopy(byid[sub]['relations'])
                    title['type']='group'
        notes.append(dict(kind='explicit_list_members',entity=entity['id'],source_head=first['id']))
    _prune_entities(form)


def recover_nominal_descriptions(record,form,notes):
    s=SourceSyntax(record);pending=list(form['entities']);seen=set()
    while pending:
        entity=pending.pop(0)
        if entity['id'] in seen:continue
        seen.add(entity['id']);head=s.by_id.get(tid(entity['id'],'x'))
        if not head:continue
        matches=list(re.finditer(re.escape(entity['text']),record['text'],re.I))
        if len(matches)!=1:continue
        end=matches[0].end()
        for child in s.children[head['id']]:
            if child['deprel']!='appos' or child['upos'] not in {'NOUN','PROPN'}:continue
            ids=s.subtree(child['id']);content=[s.by_id[i] for i in ids if s.by_id[i]['upos']!='PUNCT']
            if not content or any(t['upos'] in {'VERB','AUX'} for t in content):continue
            lo=min(t['start_char'] for t in content);hi=max(t['end_char'] for t in content)
            boundary=record['text'][end:lo]
            comma=bool(re.fullmatch(r'\s*,\s*',boundary))
            paren=bool(re.fullmatch(r'\s*\(\s*',boundary) and re.match(r'\s*\)',record['text'][hi:]))
            if not (comma or paren):continue
            if any(lo<=a<hi for a,_,_ in quoted_spans(record['text'])):continue
            # Keep the earlier guard against a following relative/predicate
            # being misread as the name of a preceding noun.
            if any(t['deprel'] in {'acl','acl:relcl'} and t['start_char']>=hi
                   and not any(u['deprel'].startswith('nsubj') for u in s.children[t['id']]) for t in s.children[head['id']]):continue
            target=_add_nominal(s,form,child['id']);rel=dict(role='appos',target=target)
            if target==entity['id'] or rel in entity.get('relations',[]):continue
            entity.setdefault('relations',[]).append(rel)
            notes.append(dict(kind='bounded_nominal_apposition',entity=entity['id'],target=target,text=record['text'][lo:hi],boundary='parentheses' if paren else 'comma'))
            pending.extend(e for e in form['entities'] if e['id'] not in seen)


def recover_locative_clause(record,form,notes):
    # Present "X is where A and B meet" locates the explicit event at X.
    # Past/modal/negated copulas and unspecified clause arguments remain refused.
    s=SourceSyntax(record);node=form['formula']
    if node.get('op')!='event' or node.get('predicate')!='be' or node.get('anchor','').casefold()!='is':return
    value=node.get('arguments',{}).get('ARG2');place=node.get('arguments',{}).get('ARG1')
    if not isinstance(value,dict) or not str(value.get('value','')).startswith('where ') or not isinstance(place,str):return
    whs=[t for t in s.tokens if t['lemma'].casefold()=='where' and t['head']==0]
    if len(whs)!=1:return
    candidates=[t for t in s.children[whs[0]['id']] if t['upos']=='VERB' and t['deprel']=='advcl:relcl']
    if len(candidates)!=1:return
    verb=candidates[0];subjects=[t for t in s.children[verb['id']] if t['deprel']=='nsubj']
    if len(subjects)!=1 or any(t['deprel'] not in {'nsubj','punct'} for t in s.children[verb['id']]):return
    target=_add_nominal(s,form,subjects[0]['id'])
    form['formula']=dict(op='event',id='e'+str(verb['id']),predicate=verb['lemma'],anchor=verb['text'],
        arguments={'nsubj':target,'obl:at':place},properties=[dict(role='clause_marker',value='where')])
    notes.append(dict(kind='locative_content_clause',event='e'+str(verb['id']),location=place))
    _prune_entities(form)


def compile_content_relations(record,*,strict=True):
    prepared,extra=prepare_relations(record)
    def transform(r,form,notes):
        notes.extend(extra)
        recover_colon_lists(r,form,notes)
        recover_nominal_descriptions(r,form,notes)
        recover_identifiers(r,form,notes)
        recover_quantities(r,form,notes)
        recover_locative_clause(r,form,notes)
        _prune_entities(form);inherit_routes(form)
    return compile_content_recovery(prepared,strict=strict,transform_form=transform)
