# Evidence review — difficult-claim compilation

Reviewer: compiler-author assistant. No new human reference labels.

| Claim | Primary evidence | Assessment |
|---|---|---|
| All2375 original claims were rerun | inputs/results/baseline rows and exact replay | Confirmed |
| Useful compilation coverage increases | analysis.json:1839→1866 passing,2099→2103 executable | Confirmed at the stated checks, not semantic accuracy |
| All old candidates and user-faithful programs remain | Candidate-ID sets and11 hashes | Confirmed |
| Targeted omissions/source problems are represented |259 tests,28 saved-output demos, source-span traces | Confirmed for the declared constructions, not general parsing reliability |
| Every recovery is fully faithful |12 sampled diagnoses:10 faithful/2 partial | Not established; target omissions retained but other errors remain |
| Fresh semantics improves |20 unchanged programs/statuses,17/2/1 paired assistant judgments | No demonstrated fresh gain; one known prior diagnostic explicitly marked |
| The final source was untouched before review | First/final source and audit_followup.json | False: a later old-demo audit correction fixes2 false alerts; all programs/fresh statuses unchanged |
| Printed content requires the declared source | Actual3-state native controls with supported speech and varied OCR | Confirmed on constructed evidence; no media accuracy claim |
| Reference resolution/native cost/rewrite are completed | No such implementation/experiment | Deferred by user instruction |

Remaining failures:227 lexical alerts,8 opaque clauses,2 undecomposed lists and272
parser/compiler refusals. Coverage is not semantic equivalence. Names inside a
long string do not guarantee their relationships are represented. Apposition keeps
the grammatical qualifier without hard-coding identity or geographic interpretation.

Next proposals: select a bounded set of recurring numeric/apposition alerts; expose
remaining clause/list relationships or refuse explicitly. Keep references/cost and
any rewrite for later. The report shows partial and contextual cases openly.
