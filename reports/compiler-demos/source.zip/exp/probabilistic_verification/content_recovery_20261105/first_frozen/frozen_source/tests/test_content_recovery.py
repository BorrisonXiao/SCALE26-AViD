"""Real failure requirements plus controls for apposition, values and source scope."""
import copy
import json
from pathlib import Path

import pytest

from probabilistic_verification.balanced_logic import BalancedVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.multimodal import ground_two_sources
from probabilistic_verification.content_recovery import compile_content_recovery, opaque_clause_checks
from probabilistic_verification.scope_coverage import compile_scope_coverage
from test_scoped_srl import constructed_record

ROOT=Path(__file__).resolve().parents[1]
RECORDS={r['claim_id']:r for r in map(json.loads,(ROOT/'exp/probabilistic_verification/scope_coverage_20261105/inputs.jsonl').read_text().splitlines())}


def case(cid):return compile_content_recovery(RECORDS[cid])[0]


@pytest.mark.parametrize('cid,owner,description',[
    ('TInVWzp25aIM_6','Kipnuk','Alaska'),('TzF9M4kZ3Pys_268','Sky Harbor International Airport','Phoenix Arizona')])
def test_appositions_retain_both_mentions_without_equating_them(cid,owner,description):
    claim=case(cid);es={e['id']:e for e in claim.metadata['entities'].values()}
    head=next(e for e in es.values() if e['text']==owner)
    assert any(r['role']=='appos' and es[r['target']]['text']==description for r in head['relations'])
    assert not any(p['role']=='name' and p['value']==description for p in head.get('properties',[]))


def test_coordinated_participants_survive_a_name_apposition():
    claim=case('TLO3smKI67PM_569');es={e['id']:e for e in claim.metadata['entities'].values()}
    event=next(e for e in claim.metadata['events'].values() if e['predicate']=='argue')
    group=es[event['arguments']['ARG0']];members=[es[r['target']] for r in group['relations'] if r['role']=='member']
    assert len(members)==2
    assert any(dict(role='name',value='Karen') in m.get('properties',[]) for m in members)
    assert any(m['text']=='father' for m in members)


def test_range_endpoints_and_attached_location_remain_on_the_same_event():
    claim=case('TgPh_fzHTCm4_1471');event=next(e for e in claim.metadata['events'].values() if e['predicate']=='ramp')
    assert event['arguments']['ARGM-DIR']==dict(kind='measurement',value='10-20',unit='knots')
    assert event['arguments']['ARG5']==dict(kind='measurement',value='25-30',unit='knots')
    target=event['arguments']['obl:across'];es={e['id']:e for e in claim.metadata['entities'].values()}
    assert es[target]['text']=='Texas' and dict(role='mod',value='central') in es[target]['properties']
    assert not any(e.get('quantity') for e in es.values() if e['text']=='knots')


def test_approximate_distance_is_not_an_exact_group_count():
    claim=case('T2G_ACMxR_I4_1156');event=next(e for e in claim.metadata['events'].values() if e['predicate']=='be')
    assert event['arguments']['ARG2']==dict(kind='measurement',value='roughly 100',unit='km')
    assert 'obl:above' in event['arguments']
    assert not any(e.get('quantity') for e in claim.metadata['entities'].values())


def test_elliptical_lower_bound_and_subset_are_both_retained():
    claim=case('TFOEIehBwT8Q_490');es={e['id']:e for e in claim.metadata['entities'].values()}
    whole=next(e for e in es.values() if e.get('quantity',{}).get('operator')=='at_least')
    assert whole['quantity']['value']=='120'
    subset=es[next(r['target'] for r in whole['relations'] if r['role']=='including')]
    assert subset['quantity']==dict(operator='exact',value='100')
    assert not any(e['predicate']=='include' for e in claim.metadata['events'].values())


def test_numeric_poster_is_exact_ocr_content_without_guessed_column_meanings():
    claim=case('TFgw4IaR9R8s_1596');event=next(e for e in claim.metadata['events'].values() if e['predicate']=='show')
    assert event['arguments']['ARG1']==dict(kind='verbatim_text',value='Thailand 72% / 36%')
    assert event['route']=='ocr_assertion'
    assert not any(e['text']=='Thailand' for e in claim.metadata['entities'].values())
    assert 'printed row text; column meanings unspecified' in claim.metadata['runtime_requirements']


def test_finite_clause_is_recovered_from_a_time_string_without_adding_a_cause():
    claim=case('T2EE72iNELEs_209');events={e['predicate']:e for e in claim.metadata['events'].values()}
    assert set(events)=={'erupt','land'}
    scope=claim.metadata['scopes'][events['land']['scope']]
    assert scope['kind']=='temporal' and scope['role']=='as'
    assert not any(s['kind']=='reason' for s in claim.metadata['scopes'].values())


def test_timelapse_storm_is_depicted_content():
    claim=case('TzF9M4kZ3Pys_310');scope=next(s for s in claim.metadata['scopes'].values() if s['kind']=='depiction')
    assert scope['route']=='visual_depiction'
    assert not any(a.predicate=='entity_relation' and 'of' in a.arguments for a in claim.atoms)


def test_written_sign_content_uses_ocr_and_not_speech():
    claim=case('TKCfkoNUssZI_693')
    assertions=[s for s in claim.metadata['scopes'].values() if s['kind']=='assertion']
    assert assertions and all(s['route']=='ocr_assertion' for s in assertions)
    assert not any(e['route']=='speech_assertion' for e in claim.metadata['events'].values())


@pytest.mark.parametrize('cid,text',[
 ('TQKCK6-tRaoE_656','Together with the SSS, Russia'),('T2EE72iNELEs_189','Views by Starlink')])
def test_printed_fragments_retain_exact_text_under_ocr(cid,text):
    claim=case(cid)
    assert any(e['route']=='ocr_assertion' and dict(kind='verbatim_text',value=text) in e['arguments'].values() for e in claim.metadata['events'].values())


def test_personal_name_and_predicative_label_are_separate():
    claim=case('TLO3smKI67PM_595');event=next(e for e in claim.metadata['events'].values() if e['predicate']=='call')
    assert event['arguments']['ARG2']==dict(kind='text',value='Karen')
    target=next(e for e in claim.metadata['entities'].values() if e['id']==event['arguments']['ARG1'])
    assert dict(role='name',value='Karen') in target['properties']
    assert not any(e['text']=='Karen a Karen' for e in claim.metadata['entities'].values())


@pytest.mark.parametrize('cid',['TFgw4IaR9R8s_1677','Txf2EdqOg1SQ_2343','TFgw4IaR9R8s_1662'])
def test_previous_unsafe_name_controller_examples_do_not_gain_false_appositions(cid):
    claim,notes=compile_content_recovery(RECORDS[cid],strict=False)
    assert not any(n['kind']=='appositive_description' and n['text'] in {'Trump','Guangdong'} for n in notes)


def test_an_ordinary_count_stays_a_group_quantity():
    r=constructed_record('100 people walk.', [('100','100','NUM',2,'nummod'),('people','person','NOUN',3,'nsubj'),
        ('walk','walk','VERB',0,'root'),('.','.','PUNCT',3,'punct')],[(2,[('ARG0',0,1)])])
    c,_=compile_content_recovery(r)
    assert next(iter(c.metadata['entities'].values()))['quantity']==dict(operator='exact',value='100')


def test_clock_is_not_reinterpreted_as_an_approximate_group():
    record=RECORDS['TInVWzp25aIM_7'];old,_=compile_scope_coverage(record);new,_=compile_content_recovery(record)
    assert new.atoms==old.atoms and new.expression==old.expression


def test_body_parts_are_not_converted_to_a_distance():
    r=constructed_record('Two feet are visible.', [('Two','two','NUM',2,'nummod'),('feet','foot','NOUN',4,'nsubj'),
        ('are','be','AUX',4,'cop'),('visible','visible','ADJ',0,'root'),('.','.','PUNCT',4,'punct')],[])
    c,_=compile_content_recovery(r)
    assert any(str(e.get('quantity',{}).get('value')).casefold() in {'two','2'} for e in c.metadata['entities'].values())
    assert not any(v.get('kind')=='measurement' for e in c.metadata['events'].values() for v in e['arguments'].values() if isinstance(v,dict))


def test_parenthetical_label_keeps_the_closing_parenthesis():
    c=case('TgPh_fzHTCm4_1505')
    assert any(e['arguments'].get('ARG2')==dict(kind='text',value='MCV (mesoscale convective vortex)') for e in c.metadata['events'].values())


def test_list_words_do_not_substitute_for_linked_members():
    c,_=compile_content_recovery(RECORDS['TQEmEycTI0RQ_863'],strict=False)
    assert any(a['code']=='incomplete_enumeration' for a in c.metadata['structural_alerts'])


def test_negative_measurement_keeps_its_sign():
    r=constructed_record('A platform is -5 km below sea.', [('A','a','DET',2,'det'),('platform','platform','NOUN',6,'nsubj'),
        ('is','be','AUX',6,'cop'),('-','-','SYM',5,'case'),('5','5','NUM',6,'nummod'),
        ('km','kilometer','NOUN',0,'root'),('below','below','ADP',8,'case'),('sea','sea','NOUN',6,'nmod'),
        ('.','.','PUNCT',6,'punct')],[(2,[('ARG1',0,1),('ARG2',3,7)])])
    c,_=compile_content_recovery(r)
    assert any(dict(kind='measurement',value='-5',unit='km') in e['arguments'].values() for e in c.metadata['events'].values())


def test_explicit_until_clause_gets_an_event_instead_of_a_time_string():
    c=case('T2G_ACMxR_I4_1331')
    failure=next(e for e in c.metadata['events'].values() if e['predicate']=='fail')
    scope=c.metadata['scopes'][failure['scope']]
    assert scope['kind']=='temporal' and scope['role']=='until'


def test_person_speech_is_not_reclassified_as_ocr():
    r=constructed_record('Alice says Bob walks.', [('Alice','Alice','PROPN',2,'nsubj'),('says','say','VERB',0,'root'),
        ('Bob','Bob','PROPN',4,'nsubj'),('walks','walk','VERB',2,'ccomp'),('.','.','PUNCT',2,'punct')],
        [(1,[('ARG0',0,0),('ARG1',2,3)]),(3,[('ARG0',2,2)])])
    c,_=compile_content_recovery(r)
    assert any(e['predicate']=='walk' and e['route']=='speech_assertion' for e in c.metadata['events'].values())


def test_hidden_finite_clause_is_flagged_but_exact_text_is_allowed():
    r=RECORDS['T2EE72iNELEs_209'];r=copy.deepcopy(r);r['tokens'][4].update(upos='VERB',feats='VerbForm=Fin')
    form=dict(entities=[],formula=dict(op='event',id='e2',predicate='erupt',arguments={'time':dict(kind='time',value='as rocket lands')}))
    assert opaque_clause_checks(r,form)
    form['formula']['arguments']['time']['kind']='verbatim_text'
    assert not opaque_clause_checks(r,form)


def test_original_annotations_are_unchanged():
    r=copy.deepcopy(RECORDS['TLO3smKI67PM_595']);saved=copy.deepcopy(r)
    compile_content_recovery(r)
    assert r==saved


def test_earlier_scope_fixes_remain_nested():
    c=case('T2G_ACMxR_I4_1367');e=next(e for e in c.metadata['events'].values() if e['predicate']=='landing')
    assert c.metadata['scopes'][e['scope']]['kind']=='purpose' and e['route']=='visual_depiction'


@pytest.mark.parametrize('state',['supported','refuted','unknown'])
def test_native_printed_row_requires_ocr_evidence_even_if_speech_is_supported(state):
    claim=case('TFgw4IaR9R8s_1596');domains={v.name:[v.name.lower()] for v in claim.variables}
    assignment={k:v[0] for k,v in domains.items()};evidence=[]
    target=next(a for a in claim.atoms if a.predicate=='show')
    assert claim.metadata['allowed_routes'][target.id]==['ocr_assertion']
    for route in ['ocr_assertion','speech_assertion']:
        observations={}
        for atom in claim.atoms:
            label=state if route=='ocr_assertion' and atom.id==target.id else 'supported'
            key=canonical_key('printed-row-test',atom,assignment,route)
            observations[key]=Observation(key,tuple(float(s==label) for s in ('supported','refuted','unknown')),False,atom.text,{'source':'stipulated test'})
        evidence.append(Evidence('printed-row-test',domains,{v:True for v in domains},observations,route=route))
    ocr,speech,combined,_=ground_two_sources(claim,*evidence,allowed={a:set(v) for a,v in claim.metadata['allowed_routes'].items()})
    outcomes=BalancedVerifier([speech,combined],learned=False).predict()
    assert outcomes[0]['distribution']['unknown']>1-1e-9
    assert outcomes[1]['distribution'][state]>1-1e-9
