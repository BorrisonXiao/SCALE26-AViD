"""Recover explicit nominal/numeric content and preserve source boundaries.

One deterministic SRL/dependency path; no sentence rewrite, parser selection or
pronoun resolution. New repairs run before the existing coverage check. When
word retention hides a finite clause, a structural check requests review.
"""
from __future__ import annotations

import copy
import re
from dataclasses import replace

from .compilation_followup import walk_events
from .logical_form import LogicalFormError
from .reviewed_srl import _argument_head, _frames, _prune_entities
from .scope_coverage import compile_scope_coverage
from .scoped_srl import SourceSyntax, quoted_spans
from .semantic_srl import inherit_routes
from .srl_graph import srl_graph_form, SPEECH

OCR_SOURCES = {'text','caption','sign','banner','poster','label','screen','display'}
PRINT_SURFACES = OCR_SOURCES | {'vest','shirt','t-shirt','jacket'}
VISUAL_SOURCES = {'timelapse','time-lapse'}
NOMINAL = {'NOUN','PROPN','PRON','NUM'}
UNITS = {'km','kilometer','kilometre','m','meter','metre','mile','foot','feet','ft',
         'inch','cm','knot','mph','km/h','percent','%','degree','second','minute','hour','day'}
BOUND = r'at least|at most|more than|less than|over|under|about|around|approximately|roughly|nearly|almost'
NUMBER = r'\d+(?:[.,]\d+)*'
AMOUNT = re.compile(r'(?<![\w.+−-])(?:(?P<bound>'+BOUND+r')\s+)?(?P<value>[-−+]?'+NUMBER+r'(?:\s*[-–]\s*[-−+]?'+NUMBER+r')?)\s*$',re.I)


def tid(value, prefix):
    return int(value[len(prefix):]) if isinstance(value,str) and re.fullmatch(re.escape(prefix)+r'\d+',value) else None


def _nominal_ids(s, head):
    found,pending={head},[head]
    while pending:
        for child in s.children[pending.pop()]:
            if child['deprel'] in {'det','amod','compound','flat','flat:name','fixed','case','nummod','nmod','nmod:poss','advmod','appos','conj','cc','punct'} and child['upos'] not in {'VERB','AUX'}:
                if child['id'] not in found:found.add(child['id']);pending.append(child['id'])
    return found


def prepare_content(record):
    r=copy.deepcopy(record);s=SourceSyntax(r);frames=_frames(s);notes=[];literals=[]
    ranges=quoted_spans(r['text'])
    def quoted(t):return any(lo<=t['start_char']<hi for lo,hi,_ in ranges)

    # "fan Karen and ... father": a noun conjunct belongs to the common-noun
    # participant, rather than being swallowed by its proper-name apposition.
    for token in s.tokens:
        parent=s.by_id.get(token['head']);owner=s.by_id.get(parent['head']) if parent else None
        if (token['deprel']=='conj' and token['upos']=='NOUN' and parent and owner
                and parent['deprel']=='appos' and parent['upos']=='PROPN' and owner['upos']=='NOUN'
                and any(c['deprel']=='cc' and c['lemma'].casefold()=='and' for c in s.children[token['id']])
                and any(all(x in {t['id'] for t in s.alignment.selected(a['start'],a['end'])}
                            for x in (owner['id'],parent['id'],token['id']))
                        for f in frames.values() for a in f['args'] if a['role'] in {'ARG0','ARG1','nsubj'})):
            token['head']=owner['id']
            notes.append(dict(kind='appositive_coordination',token=token['id'],owner=owner['id']))

    # A subordinate finite verb can be mistagged as a plural noun: "as rocket
    # lands". Require an explicit temporal marker and adjacent singular subject.
    s=SourceSyntax(r)
    for token in s.tokens:
        if token['upos']!='NOUN' or token['deprel']!='obl' or quoted(token) or not token['text'].casefold().endswith('s'):continue
        parent=s.by_id.get(token['head'])
        markers=[c for c in s.children[token['id']] if c['deprel']=='case' and c['lemma'].casefold() in {'as','while','when','before','after'}]
        subjects=[c for c in s.children[token['id']] if c['deprel']=='compound' and c['upos'] in {'NOUN','PROPN'}
                  and 'Number=Sing' in (c.get('feats') or '') and c['end_char']<=token['start_char']
                  and not r['text'][c['end_char']:token['start_char']].strip()]
        if not parent or parent['upos']!='VERB' or len(markers)!=1 or len(subjects)!=1:continue
        from nltk.corpus import wordnet
        lemma=wordnet.morphy(token['text'].casefold(),wordnet.VERB)
        if not lemma or lemma==token['text'].casefold() or not wordnet.synsets(lemma,pos=wordnet.VERB):continue
        if any(c['deprel'] in {'det','nummod','nmod','nmod:poss'} for c in s.children[token['id']]):continue
        token.update(upos='VERB',lemma=lemma,deprel='advcl',feats='Mood=Ind|Number=Sing|Person=3|Tense=Pres|VerbForm=Fin')
        markers[0].update(upos='SCONJ',deprel='mark');subjects[0]['deprel']='nsubj'
        notes.append(dict(kind='finite_temporal_clause',event='e'+str(token['id']),marker=markers[0]['text'],subject=subjects[0]['id']))

    s=SourceSyntax(r);frames=_frames(s)
    # A finite clause inside an SRL time slot may be attached through a case
    # marker instead of advcl. Keep the supplied time role and explicit subject;
    # multi-clause/conditional readings remain unresolved rather than guessed.
    for fid,frame in list(frames.items()):
        for arg in frame['args']:
            if arg['role']!='ARGM-TMP':continue
            ts=s.alignment.selected(arg['start'],arg['end'])
            surface=s.surface({t['id'] for t in ts})
            marker=re.match(r'\s*(as|while|when|until|before|after|since)\b',surface,re.I)
            if not marker or re.match(r'\s*as\s+(long|soon|far)\s+as\b',surface,re.I):continue
            candidates=[t for t in ts if t['upos']=='VERB' and 'VerbForm=Fin' in (t.get('feats') or '')]
            if len(candidates)!=1:continue
            token=candidates[0]
            subjects=[t for t in s.children[token['id']] if t['deprel'].startswith('nsubj')]
            markers=[t for t in ts if t['text'].casefold()==marker[1].casefold() and t['start_char']<token['start_char']]
            if not subjects or len(markers)!=1:continue
            if token['head']==fid and token['deprel']=='advcl' and markers[0]['head']==token['id'] and markers[0]['deprel']=='mark':continue
            token.update(head=fid,deprel='advcl');markers[0].update(head=token['id'],deprel='mark',upos='SCONJ')
            notes.append(dict(kind='temporal_clause_attachment',event='e'+str(token['id']),parent='e'+str(fid),marker=marker[1]))

    s=SourceSyntax(r);frames=_frames(s)
    # Recover printed readings only on an explicit physical text-bearing noun.
    for token in s.tokens:
        owner=s.by_id.get(token['head'])
        if (token['lemma'].casefold()!='read' or token['deprel'] not in {'acl','acl:relcl'} or not owner
                or owner['lemma'].casefold() not in PRINT_SURFACES or token['id'] in frames):continue
        matches=[(lo,hi,text) for lo,hi,text in ranges if token['end_char']<=lo and
                 any(lo<=s.by_id[i]['start_char']<hi for i in s.subtree(token['id']))]
        if len(matches)!=1:continue
        lo,hi,text=matches[0];inside={t['id'] for t in s.tokens if lo<=t['start_char'] and t['end_char']<=hi}
        f=dict(verb=token['text'],verb_span=[s.alignment.word_index(token)]*2,
               args=[s.argument('ARG0',{owner['id']}),s.argument('ARG1',inside)])
        r['srl']['frames'].append(f);frames[token['id']]=f
        notes.append(dict(kind='printed_reading_frame',event='e'+str(token['id']),surface=owner['id'],text=text))

    # "Text on the screen: ..." is an on-screen text description, not an
    # imperative to send a message. The source noun becomes a nominal predicate.
    match=re.fullmatch(r'\s*Text\s+on\s+(?:the\s+)?screen\s*:\s*["“]([^"”]+)["”]\s*[.!]?\s*',r['text'],re.I)
    if match and not frames:
        root=next((t for t in s.tokens if t['head']==0 and t['text'].casefold()=='text'),None)
        screen=next((t for t in s.tokens if t['lemma'].casefold()=='screen'),None)
        if root and screen:
            lo,hi=match.span(1);inside={t['id'] for t in s.tokens if lo<=t['start_char'] and t['end_char']<=hi}
            root.update(upos='NOUN',lemma='text',feats='Number=Sing')
            f=dict(verb=root['text'],verb_span=[s.alignment.word_index(root)]*2,args=[s.argument('ARG0',{screen['id']}),s.argument('ARG1',inside)])
            r['srl']['frames'].append(f);frames[root['id']]=f
            literals.append(dict(event='e'+str(root['id']),role='ARG1',text=match[1],kind='verbatim_text',route='ocr_assertion'))
            notes.append(dict(kind='on_screen_text_fragment',event='e'+str(root['id']),text=match[1]))

    s=SourceSyntax(r);frames=_frames(s)
    for fid,frame in frames.items():
        token=s.by_id[fid]
        # Retain a printed numeric row without assigning unprovided column
        # meanings, e.g. Thailand72%/36%. It remains exact source text.
        sources=[_argument_head(s,a) for a in frame['args'] if a['role']=='ARG0']
        contents=[a for a in frame['args'] if a['role']=='ARG1']
        if (token['lemma'].casefold() in {'show','say','read','display'} and len(sources)==len(contents)==1
                and sources[0] and sources[0]['lemma'].casefold() in OCR_SOURCES):
            a=contents[0];ts=s.alignment.selected(a['start'],a['end'])
            if (':' in r['text'][token['end_char']:ts[0]['start_char']]
                    and any(t['upos']=='NUM' for t in ts) and not any(t['upos'] in {'VERB','AUX'} for t in ts)):
                text=r['text'][ts[0]['start_char']:ts[-1]['end_char']]
                literals.append(dict(event='e'+str(fid),role=a['role'],text=text,kind='verbatim_text',route='ocr_assertion'))
                notes.append(dict(kind='printed_numeric_row',event='e'+str(fid),text=text,
                                  limitation='Column meanings remain unspecified; only printed text is verified.'))
        # A predicative label follows its own article. Keep a personal name with
        # the target and the label as text, rather than "Karen a Karen" as an entity.
        if token['lemma'].casefold()=='call':
            target=next((a for a in frame['args'] if a['role']=='ARG1'),None)
            label=next((a for a in frame['args'] if a['role']=='ARG2'),None)
            if not target or not label:continue
            head=_argument_head(s,target);ts=s.alignment.selected(label['start'],label['end'])
            articles=[t for t in ts if t['deprel']=='det' and t['text'].casefold() in {'a','an'}]
            if not head or len(articles)!=1:continue
            article=articles[0];end=s.by_id.get(article['head'])
            if not end or end['upos'] not in {'NOUN','PROPN'} or end['head'] not in {head['id'],fid}:continue
            leading=[t for t in ts if t['end_char']<=article['start_char']]
            if any(t['upos']!='PROPN' or t['deprel']!='appos' or t['head']!=head['id'] for t in leading):continue
            if leading:
                target.update(s.argument('ARG1',{t['id'] for t in s.alignment.selected(target['start'],target['end'])}|{t['id'] for t in leading}))
            selected={t['id'] for t in ts if t['start_char']>article['start_char'] and t['upos']!='PUNCT'}
            if not selected or any(s.by_id[i]['upos'] in {'VERB','AUX'} for i in selected):continue
            label.update(s.argument('ARG2',{article['id']}|selected))
            text=r['text'][article['end_char']:ts[-1]['end_char']].strip().rstrip('.,;!?').rstrip()
            literals.append(dict(event='e'+str(fid),role='ARG2',text=text,kind='text',route=None))
            notes.append(dict(kind='predicative_label',event='e'+str(fid),text=text))
    # A case-marking including already has a nominal subset relation. A verbal
    # SRL frame here duplicates that relation as an unrelated main assertion.
    r['srl']['frames']=[f for f in r['srl']['frames'] if not (s.frame_head(f) and
        s.frame_head(f)['lemma'].casefold()=='include' and s.frame_head(f)['deprel']=='case')]
    return r,notes,literals


def _add_nominal(s,form,head):
    eid='x'+str(head)
    if any(e['id']==eid for e in form['entities']):return eid
    ids=_nominal_ids(s,head)
    if any(s.by_id[i]['upos'] in {'VERB','AUX'} for i in ids):
        raise LogicalFormError('nominal_content','Nominal recovery contains an unresolved clause.')
    mini=copy.deepcopy(s.record);mini['tokens']=[t for t in mini['tokens'] if t['id'] in ids]
    next(t for t in mini['tokens'] if t['id']==head).update(head=0,deprel='root')
    mini['srl']=dict(words=[t['text'] for t in mini['tokens']],frames=[])
    addition=srl_graph_form(mini,semantic_arguments=True)
    existing={e['id'] for e in form['entities']}
    form['entities'].extend(e for e in addition['entities'] if e['id'] not in existing)
    return addition['formula']['ref']


def recover_appositions(record,form,notes):
    s=SourceSyntax(record)
    for entity in list(form['entities']):
        head=s.by_id.get(tid(entity['id'],'x'))
        if not head:continue
        for child in s.children[head['id']]:
            if child['deprel']!='appos' or child['upos'] not in {'NOUN','PROPN'}:continue
            full=s.subtree(child['id'])
            # Only explicit comma apposition with a nominal description. The
            # earlier false-name/relative-subject counterexamples remain blocked.
            if any(s.by_id[i]['upos'] in {'VERB','AUX','CCONJ'} for i in full):continue
            content=[s.by_id[i] for i in full if s.by_id[i]['upos']!='PUNCT']
            if not content:continue
            first=min(t['start_char'] for t in content);last=max(t['end_char'] for t in content)
            between=record['text'][head['end_char']:first]
            if not re.fullmatch(r'\s*,\s*',between):continue
            if any(c['deprel'] in {'acl','acl:relcl'} and c['start_char']>=last
                   and not any(u['deprel'].startswith('nsubj') for u in s.children[c['id']])
                   for c in s.children[head['id']]):continue
            if any(lo<=first<hi for lo,hi,_ in quoted_spans(record['text'])):continue
            target=_add_nominal(s,form,child['id']);relation=dict(role='appos',target=target)
            if target!=entity['id'] and relation not in entity.setdefault('relations',[]):
                entity['relations'].append(relation)
                notes.append(dict(kind='appositive_description',entity=entity['id'],description=target,
                                  text=s.surface({t['id'] for t in content}),
                                  limitation='Grammatical apposition is retained; identity/location interpretation is not guessed.'))


def _amount(s,token):
    prefix=s.record['text'][max(0,token['start_char']-65):token['start_char']]
    return AMOUNT.search(prefix)


def recover_numbers(record,form,notes):
    s=SourceSyntax(record)
    # The earlier SRL argument builder can interpret "Two feet are visible" as
    # a distance literal. An explicit counted object in these non-measurement
    # predicates stays a group of objects instead.
    for event in list(walk_events(form)):
        if event['predicate'] not in {'be','see','show','tie','have','hold','count'}:continue
        head=s.by_id.get(tid(event['id'],'e'))
        governor=s.by_id.get(head['head']) if head and head['deprel']=='cop' else head
        for role,value in list(event['arguments'].items()):
            if role not in {'ARG0','ARG1'} or not isinstance(value,dict) or value.get('kind')!='measurement':continue
            candidates=[t for t in s.tokens if t['text'].casefold()==str(value.get('unit','')).casefold()
                        and t['lemma'].casefold() in {'foot','feet','knot','degree','meter','metre'}
                        and t['deprel'] in {'nsubj','obj'} and governor and t['head']==governor['id']]
            if len(candidates)==1:
                target=_add_nominal(s,form,candidates[0]['id']);event['arguments'][role]=target
                notes.append(dict(kind='counted_objects',event=event['id'],role=role,target=target))
    for entity in list(form['entities']):
        token=s.by_id.get(tid(entity['id'],'x'))
        if not token:continue
        # Elliptical group "at least120", retaining its subset relation without
        # guessing an omitted group noun or converting the bound to exact120.
        if token['upos']=='NUM' and re.fullmatch(r'\d[\d,]*',token['text']) and not entity.get('quantity'):
            prefix=record['text'][max(0,token['start_char']-24):token['start_char']]
            match=re.search(r'\b(at least|at most|more than|less than|about|around|approximately|roughly)\s*$',prefix,re.I)
            if match:
                op={'at least':'at_least','at most':'at_most','more than':'more_than','less than':'less_than'}.get(match[1].casefold(),'approx')
                entity.update(type='group',quantity=dict(operator=op,value=token['text']))
                notes.append(dict(kind='elliptical_group_bound',entity=entity['id'],operator=op,value=token['text']))
        unit=token['lemma'].casefold()
        if unit not in UNITS and token['text'].casefold() not in UNITS:continue
        match=_amount(s,token)
        if not match:continue
        value=((match['bound']+' ') if match['bound'] else '')+match['value']
        owners=[(e,role) for e in walk_events(form) for role,v in e['arguments'].items() if v==entity['id']]
        if len(owners)!=1 or entity.get('propositions') or entity.get('properties'):continue
        owner,role=owners[0]
        cases={c['lemma'].casefold() for c in s.children[token['id']] if c['deprel']=='case'}
        spatial={r['role'] for r in entity.get('relations',[])} & {'above','below','across','away','from','to'}
        if (role in {'ARG0','ARG1','nsubj','obj'} or
                not (spatial or cases & {'from','to','for','at','above','below'} or role=='ARGM-EXT')):
            continue  # Two feet/body parts or two tied knots remain counted groups.
        if any(r['role']=='member' for r in entity.get('relations',[])):continue
        # SRL may stop at the unit even though its dependency-linked location
        # continues, e.g. "25-30 knots across central Texas".
        for child in s.children[token['id']]:
            if child['deprel'] not in {'nmod','obl'} or child['upos'] not in {'NOUN','PROPN'}:continue
            markers=[c['text'] for c in s.children[child['id']] if c['deprel']=='case']
            if not markers:continue
            target=_add_nominal(s,form,child['id'])
            relation=dict(role=' '.join(markers),target=target)
            if relation not in entity.setdefault('relations',[]):entity['relations'].append(relation)
        for relation in entity.get('relations',[]):
            newrole='obl:'+relation['role'].replace(' ','_')
            if newrole in owner['arguments'] and owner['arguments'][newrole]!=relation['target']:
                raise LogicalFormError('measurement_attachment','Measurement relation has competing owners.')
            owner['arguments'][newrole]=relation['target']
        kind='duration' if unit in {'second','minute','hour','day'} else 'measurement'
        owner['arguments'][role]=dict(kind=kind,value=value,unit=token['text'])
        notes.append(dict(kind='numeric_measurement',event=owner['id'],role=role,value=value,unit=token['text'],
                          relations=copy.deepcopy(entity.get('relations',[]))))
    _prune_entities(form)


def preserve_sources(record,form,notes,literals):
    s=SourceSyntax(record);entities={e['id']:e for e in form['entities']}
    def source(event):
        for role in ('ARG0','nsubj'):
            value=event.get('arguments',{}).get(role);token=s.by_id.get(tid(value,'x'))
            if token:return token['lemma'].casefold()
        return None
    def route_inherited(node,old,new):
        if isinstance(node,dict):
            for prop in node.get('propositions',[]):
                explicit=node.get('op')=='event' and node.get('predicate') in SPEECH|{'read','show','depict','display'}
                if explicit:continue
                if prop.get('route')==old:prop['route']=new
                route_inherited(prop.get('body',{}),old,new)
            for key in ('child','body'):
                if key in node:route_inherited(node[key],old,new)
            for child in node.get('children',[]):route_inherited(child,old,new)
    for item in literals:
        event=next((e for e in walk_events(form) if e['id']==item['event']),None)
        if not event:raise LogicalFormError('source_content','Printed/label content lost its event.')
        event['arguments'][item['role']]=dict(kind=item['kind'],value=item['text'])
        event['propositions']=[p for p in event.get('propositions',[]) if p['role']!=item['role']]
        if item['route']:
            event.setdefault('properties',[])[:]=[p for p in event.get('properties',[]) if p['role']!='source_route']
            event['properties'].append(dict(role='source_route',value=item['route']))
    for event in list(walk_events(form)):
        if source(event) in OCR_SOURCES and event['predicate'] in SPEECH|{'read','show','display','text'}:
            for prop in event.get('propositions',[]):
                if prop['kind'] in {'assertion','complement','depiction'}:
                    old=prop.get('route','unspecified');prop.update(kind='assertion',route='ocr_assertion')
                    route_inherited(prop['body'],old,'ocr_assertion')
                    notes.append(dict(kind='printed_source_route',event=event['id'],role=prop['role']))
        for prop in event.get('propositions',[]):
            child=prop.get('body',{});token=s.by_id.get(tid(child.get('id'),'e'))
            if (prop['role']=='ARGM-TMP' and token and token['deprel']=='advcl'
                    and any(c['deprel']=='mark' and c['lemma'].casefold()=='as' for c in s.children[token['id']])):
                prop.update(kind='temporal',role='as')
                notes.append(dict(kind='explicit_temporal_as',event=event['id'],child=child['id']))
    for entity in form['entities']:
        token=s.by_id.get(tid(entity['id'],'x'))
        if token and token['lemma'].casefold() in VISUAL_SOURCES:
            for rel in list(entity.get('relations',[])):
                if rel['role'] in {'of','about'}:
                    entity['relations'].remove(rel)
                    entity.setdefault('propositions',[]).append(dict(role='content',kind='depiction',route='visual_depiction',body=dict(op='entity',ref=rel['target'])))
                    notes.append(dict(kind='visual_source_content',entity=entity['id'],content=rel['target']))
    _prune_entities(form);inherit_routes(form)


def opaque_clause_checks(record,form):
    """A finite clause is not a time/manner value or an ordinary entity name.

    Exact source text and explicitly coarse noun phrases remain intentional
    literals. This narrow check supplements lexical coverage, not semantic gold.
    """
    alerts=[]
    def inspect(value,kind,owner):
        spans=list(re.finditer(re.escape(value),record['text'],re.I)) if isinstance(value,str) else []
        if len(spans)!=1:return
        lo,hi=spans[0].span();tokens=[t for t in record['tokens'] if lo<=t['start_char'] and t['end_char']<=hi]
        clauses=[t['text'] for t in tokens if t['upos']=='VERB' and 'VerbForm=Fin' in (t.get('feats') or '')]
        if clauses and len(tokens)>1:alerts.append(dict(code='opaque_clause',owner=owner,kind=kind,value=value,predicates=clauses))
    for event in walk_events(form):
        for role,value in event['arguments'].items():
            if isinstance(value,dict) and value.get('kind') in {'time','manner','text'}:
                inspect(value.get('value'),'literal',event['id']+':'+role)
    for entity in form['entities']:
        inspect(entity['text'],'entity',entity['id'])
        # A colon list must not pass merely because its undecomposed group name
        # contains all the names. Check that those names reach member descriptions.
        if entity.get('type')=='group' and ':' in entity['text'] and entity.get('relations'):
            from .compilation_checks_v2 import words
            es={e['id']:e for e in form['entities']};seen=set();values=[]
            def members(eid):
                if eid in seen or eid not in es:return
                seen.add(eid);e=es[eid];values.append(e['text'])
                values.extend(str(p['value']) for p in e.get('properties',[]))
                for rel in e.get('relations',[]):members(rel['target'])
            for rel in entity['relations']:
                if rel['role']=='member':members(rel['target'])
            represented=set(words(' '.join(values)))
            spans=list(re.finditer(re.escape(entity['text']),record['text'],re.I))
            if len(spans)==1:
                lo,hi=spans[0].span()
                missing=[t['text'] for t in record['tokens'] if lo<=t['start_char'] and t['end_char']<=hi
                         and t['upos']=='PROPN' and not set(words(t['text']))<=represented]
                if missing:alerts.append(dict(code='incomplete_enumeration',owner=entity['id'],kind='group',value=entity['text'],names=missing))
    return alerts


def compile_content_recovery(record,*,strict=True):
    prepared,extra,literals=prepare_content(record)
    def transform(r,form,notes):
        notes.extend(extra)
        recover_appositions(r,form,notes)
        recover_numbers(r,form,notes)
        preserve_sources(r,form,notes,literals)
    claim,notes=compile_scope_coverage(prepared,strict=False,transform_form=transform)
    alerts=opaque_clause_checks(prepared,claim.metadata['logical_form'])
    coverage=copy.deepcopy(claim.metadata['content_coverage'])
    # Including is tagged VERB/case in this cache, but the translated subset
    # relation retains it. Credit that actual relation, not a warning/schema key.
    from .compilation_checks_v2 import words
    relations={tuple(words(rel['role'])) for e in claim.metadata['logical_form']['entities'] for rel in e.get('relations',[])}
    coverage['missing']=[t for t in coverage['missing'] if not (t['pos']=='VERB' and t['relation']=='case' and tuple(words(t['text'])) in relations)]
    # Source-anchored grammatical relation words also count: next in
    # obl:next_to belongs to this event. Generic role/ID names do not count.
    s=SourceSyntax(prepared);credited=set()
    for event in walk_events(claim.metadata['logical_form']):
        head=tid(event['id'],'e')
        roles={w for role in event['arguments'] if role.startswith('obl:') for w in words(role.split(':',1)[1])}
        for token in s.children.get(head,[]):
            if token['deprel'] in {'advmod','case'} and set(words(token['text']))<=roles:
                credited.add(token['id'])
    coverage['missing']=[t for t in coverage['missing'] if t['id'] not in credited]
    coverage['complete']=not coverage['missing']
    metadata=dict(claim.metadata,content_coverage=coverage,structural_alerts=alerts)
    if any(n['kind']=='printed_numeric_row' for n in notes):
        metadata['runtime_requirements']=sorted(set(metadata['runtime_requirements']+['printed row text; column meanings unspecified']))
        metadata['requires_context']=True
    claim=replace(claim,metadata=metadata)
    if strict and (not metadata['content_coverage']['complete'] or alerts):
        code='coverage_omission' if not metadata['content_coverage']['complete'] else alerts[0]['code']
        reason=('Unrepresented source content: '+', '.join(t['text'] for t in metadata['content_coverage']['missing'])
                if code=='coverage_omission' else 'A finite clause remains inside a literal/entity instead of a linked clause.')
        error=LogicalFormError(code,reason);error.candidate=claim;error.changes=notes;raise error
    return claim,notes
