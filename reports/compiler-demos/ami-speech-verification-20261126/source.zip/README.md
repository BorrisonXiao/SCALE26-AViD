# Speech scoring and speaker attribution in AMI

## Reported content with the evidence supplied

We used the same eight annotated speaker windows as the earlier binding experiment. For each window we test the original indirect report, a faithful paraphrase, a version of the paraphrase with one alternative changed, and a version with a shared condition changed. The edits and expected judgments were written before scoring. Each hypothesis is tested against the same speaker, words, and time. Support means that the speaker presented those alternatives. Contradiction and insufficient evidence both count as no support for this diagnostic.

We ran two frozen natural language inference encoders on CPU. Both the whole-utterance and per-alternative checks received the same inputs. The whole-utterance check takes the highest-scoring label. The per-alternative check uses exact text equality or matches each split span in both directions at the previous 0.55 entailment threshold. AMI disfluencies, incomplete clauses and shared context make the split spans hard to compare. Exact matching of the alternative phrases was a separate baseline. [MiniLM checkpoint](https://huggingface.co/cross-encoder/nli-MiniLM2-L6-H768) · [DeBERTa checkpoint](https://huggingface.co/cross-encoder/nli-deberta-v3-small)

- Whole-utterance MiniLM matches 23 of 32 judgments and accepts nine of 16 edited claims. Whole-utterance DeBERTa matches 26 of 32 and accepts six edits. Both support all 16 originals and paraphrases.
- Both per-alternative checks reject all 16 edits. MiniLM supports four of 16 valid reports and DeBERTa supports three. Each supports only one of the eight paraphrases. Exact alternative phrases accept zero valid reports because the indirect reports and paraphrases differ from the transcripts.
- Pairing each paraphrase with the corresponding edit, DeBERTa gives the faithful version a higher entailment score on 16 of 16 pairs and MiniLM on 15. Scores can still be high for both versions. In IS1006a, DeBERTa gives the paraphrase 0.998 and the wrong channel number 0.938. Using a pair gives the model comparison information that will often be unavailable at inference.
- The new run with the existing frozen parsers generates 17 of 32 programs. Sixteen preserve the full reported content and a speaker role tied to the named participant. Fifteen abstain and one leaves the disjunction inside a phrase. The content scores cover all 32 using the written hypothesis, including abstentions. This measures content scoring and compiler coverage separately. The earlier exact DeepProbLog checks used controlled inputs and are reported separately.

This is a contrast set for eight previously examined meetings. The edits and judgments come from the implementing assistant. The experiment uses frozen models and manual transcripts.

## Where automatic windows lose the speaker or words

We reused the same diarization boundaries, word times, and generated windows as the earlier study. Within the 35-second query slot we changed only the mapping from anonymous clusters to named speakers. The mapping uses the same one-to-one assignment, one-second minimum, and 0.55 share of annotated overlap as the earlier labeled segment. Reference labels from the target interval are available only for diagnosis. We rerank and reuse the previous frozen MiniLM scores after changing the names, keeping up to three candidate windows.

Pyannote has one estimated turn covering every target word in all eight cases. Its window builder retains all words in one candidate for two cases before applying a speaker name. Reverb detects speech at every target word in seven cases and covers all words in one turn in five. Its window builder also retains all words in two. Window construction includes restrictions on overlap and where an utterance or recognized alternative starts and ends. The per-case counts separate turn coverage, window construction, and speaker naming.

Naming clusters with the target labels raises support from two to three cases for Pyannote and from one to three for Reverb. Each gets one clean match, the same IS1003c utterance. The other matches include another speaker’s words. All wrong-speaker queries stay unknown. The changes show both a speaker naming problem and a loss before names become relevant.

The experiment includes AMI transcript excerpts, © University of Edinburgh and partners under CC BY 4.0. [AMI corpus](https://groups.inf.ed.ac.uk/ami/download/) · [License](https://creativecommons.org/licenses/by/4.0/)

## Replay

Use Python 3.12 and the bundled requirements. The archive includes reference word times, parser outputs, cached model scores, and estimated turns. The original audio and model weights are available separately. Each of the two speech scoring checkpoints was evaluated on 374 text pairs. Their saved score files include exact revisions and checkpoint hashes.

```sh
export PYTHONPATH=scripts
export PYTHONHASHSEED=0
run=exp/probabilistic_verification/ami_speech_verification_20261126
python scripts/prepare_ami_speech_verification.py freeze
python scripts/evaluate_or_followup_compilation.py "$run/compiler" "$run/compiler/amr.jsonl" "$run/compiled.json"
python scripts/evaluate_ami_speech_scoring.py evaluate
python scripts/audit_ami_speaker_attribution.py
python scripts/ami_speech_verification_report.py
python - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

run = Path('exp/probabilistic_verification/ami_speech_verification_20261126')
for name, expected in json.loads(Path('REPLAY_SHA256.json').read_text()).items():
    assert sha256((run / name).read_bytes()).hexdigest() == expected, name
    print(name, 'matches')
PY
```

## Next steps

- Compare bounded windows taken directly from estimated speaker turns with the current windows that require a detected disjunction. Check candidate coverage, mixed-speaker words, and wrong-speaker support on separate meetings.
- Keep whole-utterance DeBERTa as a baseline. Use a separate set of speech excerpts with changed alternatives, changed shared context, and faithful paraphrases to learn or calibrate speech relation scores. Reserve fresh source meetings to measure missed support and false support at the same decision threshold.
