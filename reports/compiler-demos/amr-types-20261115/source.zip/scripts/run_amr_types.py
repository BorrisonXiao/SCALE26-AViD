"""Rerun one source-typed AMR compiler on all cached original claims."""
import hashlib
import json
import logging
from pathlib import Path
import time
from collections import Counter

from probabilistic_verification.amr_types import compile_typed, prepare_typed
from probabilistic_verification.amr_source_alignment import prepare_source, source_checks
from probabilistic_verification.amr_semantic_checks import semantic_checks
from probabilistic_verification.logic import Evidence, ground
from probabilistic_verification.compact_backend import compact_prolog_program

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/amr_types_20261115'
BASE = ROOT / 'exp/probabilistic_verification/amr_correction_20261114'


def rows(path):
    return [json.loads(s) for s in path.read_text().splitlines()]


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def inspect(record, raw):
    result = dict(claim_id=record['claim_id'], text=record['text'], raw=raw, status='unsupported')
    errors = []
    try:
        prepared = prepare_typed(record, raw)
        result.update(normalised_amr=prepared[0], source_trace=prepared[1])
        errors = source_checks(record, prepared[0], prepared[1], normalization=prepared[3]) + semantic_checks(record, prepared[0], prepared[2])
        claim = compile_typed(record, raw, strict=False, prepared=prepared)
        errors = claim.metadata['source_checks'] + claim.metadata['semantic_checks']
        evidence = Evidence('compilation_only', {v.name: ['placeholder:' + v.name] for v in claim.variables},
                            {v.name: True for v in claim.variables}, {})
        grounded = ground(claim, evidence, max_expansions=3000)
        program = compact_prolog_program([grounded], learned=False)[0]
        from problog.program import PrologString
        list(PrologString(program))
        result.update(compilation=claim.to_dict(), program=program,
                      program_sha256=hashlib.sha256(program.encode()).hexdigest(),
                      status='compiled' if not errors else 'unsupported')
    except Exception as error:
        errors.append(dict(code=getattr(error, 'code', type(error).__name__), reason=str(error)))
    result['errors'] = errors
    if errors:
        result.update(code=errors[0]['code'], reason=errors[0]['reason'])
    return result


def canonical_meaning(compilation):
    """Compare meanings modulo variable/atom names; never compare truth labels."""
    reverse = {v: '@' + n for n, v in compilation['metadata']['node_variables'].items()}
    # OR alternatives can share a variable. Keep the full assignment relation.
    groups = {}
    for n, v in compilation['metadata']['node_variables'].items():
        groups.setdefault(v, []).append(n)
    reverse = {v: '@' + ','.join(sorted(ns)) for v, ns in groups.items()}
    def value(v):
        return reverse.get(v, v)
    atoms = {a['id']: (a['predicate'], tuple(value(x) for x in a['arguments'])) for a in compilation['atoms']}
    def expression(e):
        if e['op'] == 'atom':
            return ('atom', atoms[e['atom_id']])
        return (e['op'], tuple(sorted(value(v) for v in e['variables'])), e['state'], tuple(expression(c) for c in e['children']))
    return expression(compilation['expression'])


def main():
    logging.getLogger('penman').setLevel(logging.ERROR)
    records = rows(ROOT / 'exp/probabilistic_verification/content_relations_20261105/inputs.jsonl')
    previous = {r['claim_id']: r for r in rows(BASE / 'corpus.jsonl')}
    start = time.perf_counter()
    outputs = [inspect(r, previous[r['claim_id']]['raw']) for r in records]
    (RUN / 'corpus.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False, separators=(',', ':')) + '\n' for r in outputs))
    changed = []
    for result in outputs:
        old = previous[result['claim_id']]
        if result.get('program_sha256') != old.get('program_sha256') or result['status'] != old['status'] or result['errors'] != old['errors']:
            changed.append(dict(claim_id=result['claim_id'], text=result['text'], before=old['status'], after=result['status'],
                                before_errors=old['errors'], after_errors=result['errors'],
                                meaning_unchanged=('compilation' in result and 'compilation' in old and canonical_meaning(result['compilation']) == canonical_meaning(old['compilation']))))
    stats = dict(total=len(outputs), graphs_converted=sum('program' in r for r in outputs),
                 combined_check_pass=sum(r['status'] == 'compiled' for r in outputs),
                 before_graphs_converted=1589, before_check_pass=1397,
                 gained=[r['claim_id'] for r in outputs if r['status'] == 'compiled' and previous[r['claim_id']]['status'] != 'compiled'],
                 lost=[r['claim_id'] for r in outputs if r['status'] != 'compiled' and previous[r['claim_id']]['status'] == 'compiled'],
                 graph_refusals=dict(Counter(r['errors'][-1]['code'] for r in outputs if 'program' not in r)),
                 all_issue_counts=dict(Counter(e['code'] for r in outputs for e in r['errors'])),
                 changed_programs=sum(r.get('program_sha256') != previous[r['claim_id']].get('program_sha256') for r in outputs),
                 seconds=time.perf_counter() - start, retained_pool=1981, promotions=0,
                 policy='One fixed cached AMR frontend and compiler; automatic checks are not semantic accuracy. No pooling or new model calls.')
    dump(RUN / 'summary.json', stats)
    dump(RUN / 'changed.json', changed)
    print(json.dumps({k: v if not isinstance(v, list) else len(v) for k, v in stats.items()}, indent=2), flush=True)


if __name__ == '__main__':
    main()
