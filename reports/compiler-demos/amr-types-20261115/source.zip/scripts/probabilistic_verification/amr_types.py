"""Source-based predicate types and conservative normalization for AMR compilation.

Part of speech helps distinguish a property or an event noun from a clause. It
does not establish word sense, factuality, or the correctness of the AMR roles.
"""
from dataclasses import replace
from functools import lru_cache
import json
from pathlib import Path
import re

from .amr_composition import AMRCompiler, EVENT
from .amr_scope import ScopePolicy, RELATIONS
from .amr_source_alignment import (
    AMR_UNITS, SourceAlignment, add_source_conditions, compact, literal, normal,
    numeric, prepare_source, source_checks,
)
from .amr_semantic_checks import semantic_checks
from .predicate_compilation import PredicateError
from .typed_literals import PATTERN, UNITS

EVENT_NOUN_CLASSES = {'noun.act', 'noun.event', 'noun.process', 'noun.state', 'noun.phenomenon'}
STRUCTURAL_PREDICATES = RELATIONS | {'rate-entity-91'}
RATE_PATTERN = re.compile(PATTERN.pattern.replace('h|hr|hours?|s|sec|seconds?', 'hours?|hr|h|seconds?|sec|s') + r'(?!\w)', re.I)


@lru_cache(maxsize=4096)
def event_noun_verbs(lemma):
    """Derivational links from event senses; artifact/person nouns are excluded."""
    from nltk.corpus import wordnet
    return frozenset(
        v.name().replace('_', '-')
        for syn in wordnet.synsets(lemma, pos=wordnet.NOUN)
        if syn.lexname() in EVENT_NOUN_CLASSES
        for noun in syn.lemmas()
        for v in noun.derivationally_related_forms()
        if v.synset().pos() == 'v'
    )


class TypedAlignment(SourceAlignment):
    def __init__(self, record, concepts):
        super().__init__(record, concepts)
        self.derivations = {}
        for node, concept in concepts.items():
            if self.matches(node) or not EVENT.search(concept):
                continue
            stem = re.sub(r'-\d\d$', '', concept)
            candidates = [
                t for t in self.tokens
                if t.get('upos') == 'NOUN'
                and stem in event_noun_verbs(normal(t.get('lemma', t['text'])))
            ]
            # Repeated or ambiguous anchors do not create a unique alignment.
            if len(candidates) == 1:
                self.anchors[node] = candidates
                self.derivations[node] = candidates[0]['id']


class PredicateTypes:
    def __init__(self, concepts, alignment):
        self.concepts = concepts
        self.alignment = alignment
        self.types = {}
        for node, concept in concepts.items():
            terms = alignment.matches(node)
            if concept in STRUCTURAL_PREDICATES:
                kind = 'structural_relation'
            elif EVENT.search(concept) and terms and all(t.get('upos') in {'ADJ', 'ADV'} for t in terms):
                kind = 'property'
            elif EVENT.search(concept) and terms and all(t.get('upos') == 'NOUN' for t in terms):
                kind = 'nominal_event'
            else:
                kind = 'event' if EVENT.search(concept) else 'entity'
            self.types[node] = kind

    def is_property(self, node):
        return self.types[node] == 'property'

    def is_nominal(self, node):
        return self.types[node] == 'nominal_event'

    def variable_kind(self, node):
        return {'nominal_event': 'event', 'structural_relation': 'relation'}.get(self.types[node], self.types[node])

    def allows_argument(self, parent, role, target):
        if not re.fullmatch(r'ARG\d', role):
            return False
        # These relationships take entity/event values, not asserted clauses.
        if self.types[parent] == 'structural_relation':
            return True
        if self.types[target] in {'property', 'nominal_event', 'structural_relation'}:
            return True
        # An adjective can describe an event: a flight can be close/rapid.
        return (self.types[parent] == 'property' and role == 'ARG1'
                and any(t.get('deprel') == 'amod' for t in self.alignment.matches(parent)))

    def describe(self):
        return {
            n: dict(concept=self.concepts[n], kind=k,
                    token_ids=[t['id'] for t in self.alignment.matches(n)],
                    derivational=n in self.alignment.derivations)
            for n, k in self.types.items()
        }


class TypedScopePolicy(ScopePolicy):
    def kind(self, p, r, n, concepts, edges, matches):
        # The source of a sound is verified through sound evidence. Its content
        # remains inside this context, including when the sound is negated.
        if p == 'sound-01' and r == 'ARG1':
            return 'sound'
        if p == 'have-purpose-91' and r == 'ARG2':
            return 'purpose'
        return super().kind(p, r, n, concepts, edges, matches)

    def route(self, predicate, kind):
        return 'audio_event' if kind == 'sound' else None


def normalization_licenses(record, graph_text):
    """License only declared aliases and linked, equivalent unit structures."""
    import penman
    from penman.models.amr import model
    graph = penman.decode(graph_text, model=model)
    concepts = {s: t for s, _, t in graph.instances()}
    edges = {n: [] for n in concepts}
    for s, r, t in graph.triples:
        if r != ':instance':
            edges[s].append((r, t))
    result = dict(name_aliases={}, implicit_values=[], unit_token_ids=[],
                  rate_spans=[], rate_sources=[], trace=[])
    aliases = json.loads((Path(__file__).parent / 'resources/name_aliases.json').read_text())
    text = record['text']
    for node, concept in concepts.items():
        if concept != 'name':
            continue
        values = sorted(((r, literal(t)) for r, t in edges[node] if re.fullmatch(r':op\d+', r)), key=lambda x: int(x[0][3:]))
        name = ' '.join(t for _, t in values)
        owners = [concepts[s] for s, r, t in graph.triples if r == ':name' and t == node]
        for entry in aliases:
            if compact(name) not in {compact(s) for s in entry['names']} or len(owners) != 1 or owners[0] not in entry['types']:
                continue
            sources = [s for s in entry['names'] if re.search(r'(?<!\w)' + re.escape(s) + r'(?!\w)', text, 0 if s.isupper() else re.I)]
            if sources:
                result['name_aliases'][node] = dict(source=max(sources, key=len), graph=name, reference=entry['reference'])
    measures = list(RATE_PATTERN.finditer(text))
    def unit(node):
        return AMR_UNITS.get(concepts.get(node, ''), concepts.get(node, ''))
    def amount(node):
        values = [numeric(literal(t)) for r, t in edges.get(node, []) if r == ':quant' and t not in concepts]
        units = [unit(t) for r, t in edges.get(node, []) if r == ':unit']
        return (values[0], units[0]) if len(values) == len(units) == 1 else None
    for m in measures:
        if not m['denominator']:
            continue
        if m.end() < len(text) and text[m.end()].isalnum():
            continue
        source = dict(start=m.start(), end=m.end(), text=m[0])
        result['rate_sources'].append(source)
        denominator = 'hour' if m['denominator'].lower().startswith('h') else 'second'
        for n, c in concepts.items():
            if c != 'rate-entity-91':
                continue
            numerator = [t for r, t in edges[n] if r == ':ARG1']
            divisor = [t for r, t in edges[n] if r == ':ARG2']
            if len(numerator) != 1 or len(divisor) != 1 or m['upper']:
                continue
            if amount(numerator[0]) != (numeric(m['value']), UNITS[m['unit'].lower()]):
                continue
            if amount(divisor[0]) != (numeric('1'), denominator):
                continue
            result['implicit_values'].append((divisor[0], ':quant', '1'))
            result['rate_spans'].append((m.start(), m.end()))
            result['trace'].append(dict(kind='rate_denominator', node=n, source=m[0]))
            result['unit_token_ids'] += [t['id'] for t in record.get('tokens', []) if m.start() <= t.get('start_char', -1) < m.end() and normal(t.get('lemma', t['text'])) in {'second', 'hour'}]
    for n, c in concepts.items():
        if c != 'temporal-quantity' or amount(n) not in {(numeric('1'), 'second'), (numeric('1'), 'hour')}:
            continue
        parents = [(s, r) for s, r, t in graph.triples if t == n]
        if len(parents) != 1 or concepts.get(parents[0][0]) != 'multiple' or parents[0][1] != ':op1':
            continue
        source_unit = 'second' if amount(n)[1] == 'second' else 'hour'
        terms = [t for t in record.get('tokens', []) if normal(t.get('lemma', t['text'])) == source_unit and t.get('upos') == 'NOUN' and 'Number=Plur' in (t.get('feats') or '')]
        if len(terms) != 1 or any(t.get('head') == terms[0]['id'] and (t.get('deprel') == 'nummod' or t.get('upos') == 'NUM') for t in record.get('tokens', [])):
            continue
        result['implicit_values'].append((n, ':quant', '1'))
        result['trace'].append(dict(kind='unspecified_plural_unit', node=n, token_id=terms[0]['id']))
    return result


def prepare_typed(record, raw):
    changed, info, _ = prepare_source(record, raw)
    import penman
    concepts = {s: t for s, _, t in penman.decode(changed).instances()}
    alignment = TypedAlignment(record, concepts)
    return changed, info, alignment, normalization_licenses(record, changed)


def compile_typed(record, raw, *, strict=True, prepared=None):
    changed, info, alignment, licenses = prepared or prepare_typed(record, raw)
    types = PredicateTypes(alignment.concepts, alignment)
    claim = AMRCompiler(coordination=True, scope_policy=TypedScopePolicy(record),
                        source_alignment=alignment, predicate_types=types).compile(
                            record['claim_id'], record['text'], changed, record.get('tokens', []))
    claim = add_source_conditions(claim, record, info, alignment)
    checks = source_checks(record, changed, info, normalization=licenses)
    semantic = semantic_checks(record, changed, alignment)
    claim = replace(claim, metadata=dict(claim.metadata, source_checks=checks,
                    source_checks_pass=not checks, semantic_checks=semantic,
                    semantic_checks_pass=not semantic, normalization=licenses))
    if strict and checks + semantic:
        raise PredicateError((checks + semantic)[0]['code'], (checks + semantic)[0]['reason'])
    return claim
