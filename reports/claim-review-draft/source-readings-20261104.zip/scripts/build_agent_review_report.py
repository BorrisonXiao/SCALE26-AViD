#!/usr/bin/env python3
"""Publish an independent agent's frozen readings and anonymous comparisons."""
import hashlib
import json
import shutil
import zipfile
from html import escape
from pathlib import Path

from claim_output_view import style as output_style, scripts as output_scripts

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/agent_review_20261101'
PACKET = ROOT / 'exp/probabilistic_verification/scope_compilation_20261101/human_review_packet.json'
FIELDS = {
    'intended_meaning': 'Intended meaning',
    'participants_and_relations': 'Participants and relationships',
    'source_context': 'Source: depiction, sound, speech or on-screen text',
    'quantity_and_time': 'Quantity and time conditions',
    'ambiguity': 'Ambiguity or missing context',
}


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_data():
    packet = load(PACKET)
    readings = load(RUN / 'readings_phase1.json')
    comparisons = load(RUN / 'comparisons_phase2.json')
    freeze = load(RUN / 'readings_freeze.json')
    protocol = load(RUN / 'protocol.json')
    assert sha(RUN / 'readings_phase1.json') == freeze['sha256']
    assert sha(RUN / 'claims_only.json') == freeze['claims_only_sha256']
    assert packet['packet_id'] == protocol['packet_id']
    assert packet['compiler_freeze'] == protocol['compiler_freeze']
    ids = [c['claim_id'] for c in packet['cases']]
    assert len(ids) == len(set(ids)) == 20
    assert [c['claim_id'] for c in readings['cases']] == ids
    assert [c['claim_id'] for c in comparisons['cases']] == ids
    assert readings['reviewer_type'] == comparisons['reviewer_type'] == 'independent_agent_draft'
    cases = []
    for case, reading, comparison in zip(packet['cases'], readings['cases'], comparisons['cases']):
        assert all(isinstance(reading[f], str) and reading[f].strip() for f in FIELDS)
        assert len(reading['intended_meaning'].split()) <= 35
        for letter in ('A', 'B'):
            rating = comparison['outputs'][letter]
            assert len(rating['reason'].split()) <= 30
            if case['outputs'][letter]['status'] == 'compiled':
                assert rating['judgment'] in {'faithful', 'partial', 'incorrect', 'uncertain'}
                assert rating['refusal_appropriate'] == ''
            else:
                assert rating['judgment'] == ''
                assert rating['refusal_appropriate'] in {'yes', 'no', 'unsure'}
        cases.append(dict(**case, readings={f: reading[f] for f in FIELDS},
                          agent_assessments=comparison['outputs'],
                          reading_revision_note=comparison['reading_revision_note']))
    draft_id = hashlib.sha256((RUN / 'readings_phase1.json').read_bytes()
                              + (RUN / 'comparisons_phase2.json').read_bytes()
                              + PACKET.read_bytes()).hexdigest()[:20]
    return dict(reviewer_type='independent_agent_draft', draft_id=draft_id,
                packet_id=packet['packet_id'], compiler_freeze=packet['compiler_freeze'],
                model=protocol['model_requested'], reasoning_effort=protocol['reasoning_effort_requested'],
                provenance=dict(agent_task='/root/independent_claim_reviewer',
                    readings_sha256=freeze['sha256'],
                    comparisons_sha256=sha(RUN / 'comparisons_phase2.json'),
                    anonymous_outputs_sha256=sha(RUN / 'anonymous_outputs.json'),
                    readings_frozen_at=freeze['frozen_at'],
                    inputs='Claims only, then anonymous outputs; no previous reviews or method identities.',
                    human_status='Draft only; zero human confirmations are implied.'), cases=cases)


def main():
    data = build_data()
    (RUN / 'agent_draft.json').write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    markdown = ['# Independent agent draft — 20 claim reviews', '',
                'GPT-6 Astra, xhigh. Agent draft for user review; not human ground truth.', '',
                'Readings were frozen before anonymous A/B outputs were supplied. Neither method identities nor previous judgments were supplied.', '']
    for i, case in enumerate(data['cases'], 1):
        markdown += [f'## {i}. {case["claim_id"]}', '', f'> {case["text"]}', '']
        markdown += [f'- **{label}:** {case["readings"][f]}' for f, label in FIELDS.items()]
        for letter in ('A', 'B'):
            rating = case['agent_assessments'][letter]
            label = rating['judgment'] or ('Refusal appropriate: ' + rating['refusal_appropriate'])
            markdown.append(f'- **Output {letter} — {label}:** {rating["reason"]}')
        if case['reading_revision_note']:
            markdown.append('**Later reading concern:** ' + case['reading_revision_note'])
        markdown.append('')
    (RUN / 'agent_draft.md').write_text('\n'.join(markdown) + '\n')
    folder = ROOT / 'site/reports/claim-review-draft'
    folder.mkdir(parents=True, exist_ok=True)
    for name in ('agent_draft.json', 'agent_draft.md', 'protocol.json', 'claims_only.json',
                 'readings_phase1.json', 'readings_freeze.json', 'comparisons_phase2.json', 'anonymous_outputs.json'):
        shutil.copy2(RUN / name, folder / name)
    style = '''.container{max-width:1080px}section{margin:28px 0}label{display:block;font-weight:600;margin:14px 0}input,select,textarea,button{font:inherit;color:var(--text);background:var(--surface);border:1px solid var(--border);border-radius:7px;padding:10px;max-width:100%}textarea,select{display:block;width:100%;box-sizing:border-box}button{cursor:pointer;margin:10px 0}button:disabled{opacity:.5}.toolbar{display:flex;gap:18px;flex-wrap:wrap;align-items:center}.toolbar>label{max-width:100%;min-width:0}.output-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}.output{min-width:0;border:1px solid var(--border);border-radius:9px;padding:18px}pre{font:12px/1.7 ui-monospace,monospace;white-space:pre-wrap;overflow-wrap:anywhere;max-height:420px;overflow:auto}blockquote{padding:18px;margin:20px 0;border-left:4px solid var(--accent);background:var(--surface-2)}details{margin:18px 0}summary{cursor:pointer}#claim-id{overflow-wrap:anywhere}.note{border-left:4px solid var(--accent);padding:8px 18px;background:var(--surface-2)}[hidden]{display:none!important}@media(max-width:760px){.output-grid{grid-template-columns:1fr}.toolbar{gap:10px}}'''
    style += output_style()
    head = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Twenty concise independent agent readings and anonymous compiler assessments, editable for user review."><title>Independent agent draft · Claim review · AViD</title><link rel="stylesheet" href="../assets/site.css"><style>''' + style + '''</style></head><body><nav class="site-nav" aria-label="Primary navigation"><div class="nav-inner"><a class="brand" href="../index.html">SCALE 2026 · AViD</a><div class="nav-links"><a href="../index.html">Home</a><a href="./" aria-current="page">Reports</a><a href="../proposals/">Proposals</a></div></div></nav><header class="hero"><div class="container"><p class="eyebrow">Independent agent draft · 1 November 2026</p><h1>Draft answers for your review</h1><p class="lede">Twenty claims reviewed by GPT-6 Astra with xhigh reasoning. Read, edit and confirm the answers below.</p><p><a href="claim-review-draft/agent_draft.md">Read all draft answers</a> · <a href="claim-review-draft/agent_draft.json">Download original agent draft</a> · <a href="claim-review.html">Open the separate blank form</a> · <a href="./">All reports</a></p></div></header><main class="container prose">'''
    body = """<section><p class="note"><b>Agent draft awaiting your review.</b> Edit answers and confirm each case. Edits save in this browser; use “Download my review” to share confirmed answers.</p><p><b>A and B are two compiler versions.</b> Their order is randomized for each claim. Below, inspect what each version actually compiled, then judge whether it preserves the claim.</p><details><summary>Review instructions and agent independence</summary><p>The agent wrote its intended readings before receiving anonymous outputs, without compiler identities or previous judgments. The download retains the original agent answers alongside your edits.</p><p><b>Faithful:</b> meaning and principal relationships preserved. <b>Partial:</b> a detail or relationship is missing. <b>Incorrect:</b> an asserted meaning or relationship changes. <b>Unsure:</b> you cannot decide. For a refused compilation, assess the refusal separately. This review concerns translation, not media support.</p><p>Only explicitly confirmed cases enter the human-answer fields of your download. Original suggestions and unconfirmed work are retained separately. Nothing is sent to a server.</p></details></section><section><div class="toolbar"><label>Your name or reviewer ID<input id="reviewer" autocomplete="off"></label><button id="download">Download my review</button></div><p id="progress" role="status"></p><label>Claim<select id="case-select"></select></label><div class="toolbar"><button id="previous">Previous claim</button><button id="next">Next claim</button></div><h2 id="claim-id"></h2><blockquote id="claim-text"></blockquote><p id="revision-note" class="note" hidden></p>"""
    body += '<p><a href="#claim-reading">Reading</a> · <a href="#outputs">Compiler outputs A and B</a></p><div id="claim-reading">'
    for field, label in FIELDS.items():
        body += f'<label>{escape(label)}<textarea id="{field}" rows="2"></textarea></label>'
    body += """</div><h2>Compiler outputs</h2><p id="comparison-note" class="note"></p><p class="cv-legend">Read each event or state and follow its connected participants. Attached boxes show modifiers and nested content. “Participant 0/1/2” preserves the parser’s numbered semantic roles; their meanings depend on the verb. Location, cause and time use named roles. Time labels come from the saved compiled output. A long entity label stays a single entity unless the compiler explicitly decomposed it.</p><div id="outputs" class="output-grid"></div><button id="confirm">Mark this case reviewed</button><p id="confirmation" role="status"></p></section><section><h2>Next steps</h2><ol><li>Review and correct these draft answers — establish your intended readings and judgments.</li><li>Return the downloaded review — record confirmed human feedback separately from agent suggestions.</li><li>Use confirmed failures to choose the next compiler changes — target supported errors before another evaluation.</li></ol><details><summary>Review records and source</summary><p><a href="claim-review-draft/readings_phase1.json">Original readings</a> · <a href="claim-review-draft/readings_freeze.json">Reading freeze</a> · <a href="claim-review-draft/comparisons_phase2.json">Original comparisons</a> · <a href="claim-review-draft/protocol.json">Protocol</a> · <a href="claim-review-draft/source-readings-20261104.zip">Current report source and saved inputs</a> · <a href="claim-review-draft/source.zip">Original 1 November source</a></p></details></section>"""
    serialized = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026')
    page = head + body + '</main><footer class="site-footer"><div class="container">Agent draft and user confirmations are kept separate. Compiler and evaluation results are unchanged.</div></footer><script id="draft-data" type="application/json">' + serialized + '</script>' + output_scripts(data) + '<script>' + (ROOT / 'scripts/report_assets/agent_review.js').read_text() + '</script></body></html>'
    (ROOT / 'site/reports/claim-review-draft.html').write_text(page)
    files = [Path('scripts/build_agent_review_report.py'), Path('scripts/report_assets/agent_review.js'),
             Path('scripts/import_claim_review.py'), Path('docs/agent_claim_review.md'),
             Path('tests/test_agent_review_import.py'), Path('site/assets/site.css'),
             Path('scripts/claim_output_view.py'), Path('scripts/report_assets/claim_output_view.js'),
             Path('scripts/report_assets/claim_output_view.css'),
             Path('scripts/build_claim_review.py'), Path('scripts/report_assets/claim_review.js'),
             Path('exp/probabilistic_verification/review_display_20261104/output_metadata.json'),
             Path('exp/probabilistic_verification/review_display_20261104/frozen_inputs.json'),
             Path('exp/probabilistic_verification/review_form_20261104/frozen_inputs.json')]
    files += [p.relative_to(ROOT) for p in sorted(RUN.glob('*.json'))
              if p.name not in {'publication.json', 'browser_checks.json', 'archive_verification.json'}]
    files += [(RUN / 'agent_draft.md').relative_to(ROOT), PACKET.relative_to(ROOT)]
    with zipfile.ZipFile(folder / 'source-readings-20261104.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            info = zipfile.ZipInfo(str(path), date_time=(2026, 11, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, (ROOT / path).read_bytes())
    print(f'Published {len(data["cases"])} independent agent drafts; no human answers created.')


if __name__ == '__main__':
    main()
