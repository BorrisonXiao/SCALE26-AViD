"""Shared presentation assets and frozen metadata for the two review forms."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/review_display_20261104'


def style():
    return (ROOT / 'scripts/report_assets/claim_output_view.css').read_text()


def scripts(packet):
    data = json.loads((RUN / 'output_metadata.json').read_text())
    assert data['packet_id'] == packet['packet_id']
    assert data['compiler_freeze'] == packet['compiler_freeze']
    assert set(data['cases']) == {c['claim_id'] for c in packet['cases']}
    serialized = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026')
    return '<script id="output-metadata" type="application/json">' + serialized + '</script><script>' + (ROOT / 'scripts/report_assets/claim_output_view.js').read_text() + '</script>'
