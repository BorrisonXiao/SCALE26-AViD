#!/usr/bin/env python3
"""Validate returned reviewer data; never synthesize missing human answers."""
import argparse,hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/scope_compilation_20261101'

def validate_review(review,packet):
 if review.get('reviewer_type')=='independent_agent_draft':raise ValueError('Agent drafts are not human reviews.')
 assisted=review.get('reviewer_type')=='human_review_of_agent_draft'
 if assisted and (review.get('agent_assisted') is not True or not review.get('agent_draft_id')):raise ValueError('Assisted reviews must retain agent provenance.')
 if review.get('agent_assisted') and not assisted:raise ValueError('Use the assisted-review format for an agent draft.')
 if review.get('packet_id')!=packet['packet_id'] or review.get('compiler_freeze')!=packet['compiler_freeze']:raise ValueError('Review does not match the frozen packet.')
 if len(review.get('cases',[]))!=len(packet['cases']):raise ValueError('Review membership is incomplete.')
 for a,c in zip(review['cases'],packet['cases']):
  if a.get('claim_id')!=c['claim_id'] or a.get('claim_sha256')!=c['claim_sha256']:raise ValueError('Claim identity or text hash differs.')
  if a.get('readings_complete') and not a.get('intended_meaning','').strip():raise ValueError('A completed reference reading is empty.')
  if assisted and a.get('readings_complete') and a.get('human_confirmed') is not True:raise ValueError('An assisted reading requires explicit human confirmation.')
  for letter in ['A','B']:
   rating=a.get('outputs',{}).get(letter,{})
   if rating.get('judgment','') not in {'','faithful','partial','incorrect','uncertain'}:raise ValueError('Unknown semantic judgment.')
   if rating.get('refusal_appropriate','') not in {'','yes','no','unsure'}:raise ValueError('Unknown refusal assessment.')
   if rating.get('judgment') and c['outputs'][letter]['status']!='compiled':raise ValueError('A refused output must be assessed as a refusal, not a semantic verdict.')
   if rating.get('refusal_appropriate') and c['outputs'][letter]['status']=='compiled':raise ValueError('A compiled output is not a refusal.')
   if (rating.get('judgment') or rating.get('refusal_appropriate')) and not a.get('readings_complete'):raise ValueError('Output rated before a reference reading was recorded.')
 return review

def summarize(packet,paths):
 readings,comparisons=set(),set();reviewers=[]
 for path in paths:
  r=validate_review(json.loads(path.read_text()),packet);complete=0
  for a,c in zip(r['cases'],packet['cases']):
   if a.get('readings_complete'):readings.add(a['claim_id'])
   if a.get('readings_complete') and all(bool(a['outputs'][l].get('judgment')) if c['outputs'][l]['status']=='compiled' else bool(a['outputs'][l].get('refusal_appropriate')) for l in ['A','B']):comparisons.add(a['claim_id']);complete+=1
  reviewers.append(dict(reviewer=r.get('reviewer',''),reviewer_type=r.get('reviewer_type','human_review'),agent_assisted=r.get('agent_assisted',False),file=str(path.relative_to(ROOT)),comparisons=complete,readings=sum(bool(a.get('readings_complete')) for a in r['cases'])))
 return dict(status='human_review_received' if len(comparisons)==20 else 'partial_human_review' if paths else 'awaiting_human_review',reserved_claims=20,reference_readings_received=len(readings),comparisons_received=len(comparisons),response_files=[str(p.relative_to(ROOT)) for p in paths],reviewers=reviewers,packet_id=packet['packet_id'])

def main():
 parser=argparse.ArgumentParser();parser.add_argument('review_file',type=Path);args=parser.parse_args();packet=json.loads((RUN/'human_review_packet.json').read_text());source=args.review_file.read_bytes();review=validate_review(json.loads(source),packet)
 folder=RUN/'human_responses';folder.mkdir(exist_ok=True);digest=hashlib.sha256(source).hexdigest();target=folder/(digest[:20]+'.json');target.write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
 status=summarize(packet,sorted(folder.glob('*.json')));(RUN/'human_review_status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))
if __name__=='__main__':main()
