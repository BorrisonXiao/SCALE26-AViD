const DATA = JSON.parse(document.getElementById('draft-data').textContent);
const OUTPUT_METADATA = JSON.parse(document.getElementById('output-metadata').textContent).cases;
const $ = id => document.getElementById(id);
const esc = x => String(x ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const fields = ['intended_meaning','participants_and_relations','source_context','quantity_and_time','ambiguity'];
const key = 'avid-agent-assisted-review-' + DATA.draft_id;
let index = 0, saved;
try { saved = JSON.parse(localStorage.getItem(key) || 'null'); } catch { saved = null; }
let state = saved?.draft_id === DATA.draft_id && saved.cases?.length === DATA.cases.length ? saved : {
  draft_id: DATA.draft_id, reviewer: '', cases: DATA.cases.map(c => ({
    claim_id: c.claim_id, ...structuredClone(c.readings),
    outputs: structuredClone(c.agent_assessments), human_confirmed: false
  }))
};
function progress(){
  const count = state.cases.filter(a=>a.human_confirmed).length;
  $('progress').textContent = '20 agent drafts · ' + count + ' / 20 cases confirmed by you';
  $('case-select').innerHTML = DATA.cases.map((c,i)=>'<option value="'+i+'">'+(i+1)+' · '+esc(c.claim_id)+(state.cases[i].human_confirmed?' · reviewed':'')+'</option>').join('');
  $('case-select').value = String(index);
  $('confirmation').textContent = state.cases[index].human_confirmed ? 'You marked this case reviewed.' : 'Awaiting your review.';
}
function persist(){localStorage.setItem(key,JSON.stringify(state));progress();}
function changed(){state.cases[index].human_confirmed=false;delete state.cases[index].confirmed_at;persist();}
function outputCard(letter,c,a){
  const output=c.outputs[letter], rating=a.outputs[letter];
  let html='<section class="output"><h3>Output '+letter+'</h3>';
  html+=ClaimOutputView.render(output,OUTPUT_METADATA[c.claim_id]?.[letter],letter==='A'?1:2);
  if(output.status==='compiled'){
    html+='<label>Meaning preserved?<select data-judgment="'+letter+'"><option value="faithful">Faithful</option><option value="partial">Partial</option><option value="incorrect">Incorrect</option><option value="uncertain">Unsure</option></select></label>';
  }else{
    html+='<label>Refusal appropriate?<select data-refusal="'+letter+'"><option value="yes">Yes</option><option value="no">No</option><option value="unsure">Unsure</option></select></label>';
  }
  html+='<label>Reason<textarea data-reason="'+letter+'" rows="4">'+esc(rating.reason)+'</textarea></label>';
  if(output.status==='compiled'){
    html+='<details><summary>Exact predicates and logical form</summary><pre>'+esc(output.predicates.join('\n'))+'</pre><pre>'+esc(JSON.stringify(output.form,null,2))+'</pre>';
    if(output.runtime_requirements?.length)html+='<p>Context requirements: '+esc(output.runtime_requirements.join('; '))+'</p>';
    if(output.event_references?.length)html+='<pre>'+esc(JSON.stringify(output.event_references,null,2))+'</pre>';
    html+='</details>';
  }
  return html+'</section>';
}
function show(){
  const c=DATA.cases[index], a=state.cases[index];
  $('claim-id').textContent=c.claim_id;$('claim-text').textContent=c.text;
  $('comparison-note').textContent=ClaimOutputView.sameOutputs(c.outputs.A,c.outputs.B)?(c.outputs.A.status==='compiled'?'A and B have the same saved structure and conditions for this claim.':'Both versions refused compilation for this claim.'):'A and B differ. Compare their structures and conditions below.';
  for(const f of fields)$(f).value=a[f];
  $('revision-note').hidden=!c.reading_revision_note;
  $('revision-note').textContent='Agent’s later reading concern: '+c.reading_revision_note;
  $('outputs').innerHTML=['A','B'].map(l=>outputCard(l,c,a)).join('');
  for(const letter of ['A','B']){
    for(const [attr,field] of [['judgment','judgment'],['refusal','refusal_appropriate']]){
      const select=document.querySelector('[data-'+attr+'="'+letter+'"]');
      if(select){select.value=a.outputs[letter][field];select.addEventListener('change',()=>{a.outputs[letter][field]=select.value;changed();});}
    }
    document.querySelector('[data-reason="'+letter+'"]').addEventListener('input',e=>{a.outputs[letter].reason=e.target.value;changed();});
  }
  $('previous').disabled=index===0;$('next').disabled=index===DATA.cases.length-1;progress();
}
for(const field of fields)$(field).addEventListener('input',e=>{state.cases[index][field]=e.target.value;changed();});
$('reviewer').value=state.reviewer;
$('reviewer').addEventListener('input',e=>{state.reviewer=e.target.value;persist();});
$('previous').addEventListener('click',()=>{index--;show();});
$('next').addEventListener('click',()=>{index++;show();});
$('case-select').addEventListener('change',e=>{index=Number(e.target.value);show();});
$('confirm').addEventListener('click',()=>{
  const a=state.cases[index];
  if(!a.intended_meaning.trim()){$('confirmation').textContent='An intended reading is required.';return;}
  a.human_confirmed=true;a.confirmed_at=new Date().toISOString();persist();
});
function exportReview(){
  return {packet_id:DATA.packet_id,compiler_freeze:DATA.compiler_freeze,
    reviewer_type:'human_review_of_agent_draft',agent_assisted:true,
    agent_draft_id:DATA.draft_id,agent_provenance:DATA.provenance,
    reviewer:state.reviewer,updated_at:new Date().toISOString(),
    cases:DATA.cases.map((c,i)=>{
      const a=state.cases[i],confirmed=a.human_confirmed;
      return {claim_id:c.claim_id,claim:c.text,claim_sha256:c.claim_sha256,
        ...Object.fromEntries(fields.map(f=>[f,confirmed?a[f]:''])),
        readings_complete:confirmed,human_confirmed:confirmed,confirmed_at:a.confirmed_at||null,
        comparison_opened:true,reading_edited_after_comparison:fields.some(f=>a[f]!==c.readings[f]),
        outputs:confirmed?structuredClone(a.outputs):{A:{judgment:'',reason:'',refusal_appropriate:''},B:{judgment:'',reason:'',refusal_appropriate:''}},
        working_draft:structuredClone(a),
        original_agent_draft:{readings:c.readings,outputs:c.agent_assessments,reading_revision_note:c.reading_revision_note}}
    })};
}
$('download').addEventListener('click',()=>{
  persist();const url=URL.createObjectURL(new Blob([JSON.stringify(exportReview(),null,2)+'\n'],{type:'application/json'}));
  const link=document.createElement('a');link.href=url;link.download='human-review-of-agent-draft.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
show();
