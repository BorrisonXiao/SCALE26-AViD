# Independent agent draft for user review — 2026-11-01

The user requested a strong independent agent to draft the twenty reserved claim
reviews before their own review. GPT-6 Astra with xhigh reasoning received fresh
context and only the original claims. Its five intended-reading fields were saved
and hashed before anonymous A/B outputs were supplied. It then assessed each output
without method identities, prior judgments, project notes or compiler code.
Original phase-1 answers remain unchanged; a later concern about one initial
reading is explicitly recorded in phase 2. This is another model opinion, not
human gold or a compiler accuracy measurement.

Saved records: `exp/probabilistic_verification/agent_review_20261101/`.
Run `PYTHONPATH=scripts envs/probabilistic-verification/bin/python
scripts/build_agent_review_report.py` from the project root to rebuild
`site/reports/claim-review-draft.html`. The source archive contains saved inputs,
agent responses and the generator, without the A/B method mapping. No compiler
experiment is rerun. The separate blank form remains available.

The editable page starts with twenty agent drafts and zero user confirmations.
Each case needs an explicit user confirmation. Editing any answer clears that
case's confirmation. Local storage is separate from the blank form. Downloads
label these as `human_review_of_agent_draft`, with `agent_assisted: true`;
unconfirmed answers remain only under `working_draft`, with empty human fields.
Original agent answers and their hashes are retained. Nothing submits to a server.

`import_claim_review.py` rejects raw agent drafts and refuses credit for an
unconfirmed assisted answer. Only an actual returned user export may be imported.
Generating, viewing, testing or publishing this draft does not update human counts.
Human reviews assisted by this draft must be distinguished from unaided reviews.

Next: user corrects and confirms answers, returns an export, then supported errors
can guide compiler changes. No such compiler changes are part of this task.

Display update, 2026-11-04: both review forms show the actual compiled structure
before the rating. Event/state boxes connect to participants, literal text,
modifiers and nested source contexts. Numbered semantic roles retain their original
numbers rather than being guessed as agent/patient. Tense/aspect are copied from
frozen compiler metadata, matched by exact program hash and logical form. Long
entity labels remain single entities; missing claim details are not reconstructed.
The agent-assisted page states whether the two saved outputs differ, and keeps
extra reading fields in an expandable section so the outputs are easier to reach.
Raw predicates/JSON remain available underneath. Packet/draft IDs and saved edits
are unchanged. The original source ZIP is preserved; the new source archive is
`site/reports/claim-review-draft/source-20261104.zip`. Frozen display metadata and
validation records live in `exp/probabilistic_verification/review_display_20261104/`.

Reading form simplification, 2026-11-04: all five editable reading fields are
visible by default. Duplicate original-reading and original-assessment panels were
removed from the page. Original agent answers remain in exported review JSON and
the original draft download. Jump links connect the reading and compiler outputs.
The current source archive is `source-readings-20261104.zip`; earlier archives,
review IDs, saved edits and confirmations are preserved.
