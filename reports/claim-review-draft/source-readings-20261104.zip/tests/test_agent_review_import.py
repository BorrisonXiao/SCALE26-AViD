"""Keep generated suggestions from being counted as received human judgments."""
import copy
import json
import unittest
from pathlib import Path

from import_claim_review import validate_review

ROOT = Path(__file__).resolve().parents[1]


class AgentReviewImportTest(unittest.TestCase):
    def setUp(self):
        self.packet = json.loads((ROOT / 'exp/probabilistic_verification/scope_compilation_20261101/human_review_packet.json').read_text())
        self.review = dict(packet_id=self.packet['packet_id'], compiler_freeze=self.packet['compiler_freeze'],
                           reviewer_type='human_review_of_agent_draft', agent_assisted=True, agent_draft_id='synthetic-test', cases=[])
        for c in self.packet['cases']:
            self.review['cases'].append(dict(claim_id=c['claim_id'], claim_sha256=c['claim_sha256'],
                readings_complete=False, human_confirmed=False, intended_meaning='',
                outputs={l: dict(judgment='', reason='', refusal_appropriate='') for l in ('A', 'B')}))

    def test_raw_agent_draft_rejected(self):
        r = copy.deepcopy(self.review)
        r['reviewer_type'] = 'independent_agent_draft'
        with self.assertRaisesRegex(ValueError, 'not human reviews'):
            validate_review(r, self.packet)

    def test_unconfirmed_reading_rejected(self):
        c = self.review['cases'][0]
        c.update(readings_complete=True, intended_meaning='Synthetic test reading.')
        with self.assertRaisesRegex(ValueError, 'explicit human confirmation'):
            validate_review(self.review, self.packet)

    def test_explicit_confirmation_accepted(self):
        c = self.review['cases'][0]
        c.update(readings_complete=True, human_confirmed=True, intended_meaning='Synthetic test reading.')
        for l in ('A', 'B'):
            key = 'judgment' if self.packet['cases'][0]['outputs'][l]['status'] == 'compiled' else 'refusal_appropriate'
            c['outputs'][l][key] = 'uncertain' if key == 'judgment' else 'unsure'
        self.assertIs(validate_review(self.review, self.packet), self.review)

    def test_assisted_provenance_required(self):
        del self.review['agent_draft_id']
        with self.assertRaisesRegex(ValueError, 'retain agent provenance'):
            validate_review(self.review, self.packet)

    def test_empty_export_and_blank_form_still_accepted(self):
        validate_review(self.review, self.packet)
        for key in ('agent_assisted', 'reviewer_type', 'agent_draft_id'):
            del self.review[key]
        validate_review(self.review, self.packet)


if __name__ == '__main__':
    unittest.main()
