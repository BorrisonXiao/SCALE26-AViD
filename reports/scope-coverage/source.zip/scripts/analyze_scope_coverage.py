#!/usr/bin/env python3
"""Verify complete outputs and summarize repairs separately from audit refusals."""
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/scope_coverage_20261105'


def rows(name):
    return {r['claim_id']:r for r in map(json.loads,(RUN/name).read_text().splitlines())}


def main():
    before,after=rows('baseline.jsonl'),rows('results.jsonl')
    assert set(before)==set(after) and len(after)==2375
    previous={cid for cid,r in before.items() if r['status']=='compiled'}
    candidates={cid for cid,r in after.items() if 'program' in r}
    assert previous==candidates
    changed=[dict(claim_id=cid,text=r['text'],status=r['status']) for cid,r in after.items()
             if r.get('program_sha256')!=before[cid].get('program_sha256')]
    flags=[r for r in after.values() if r.get('code')=='coverage_omission']
    categories=Counter();terms=Counter()
    names={'PROPN':'names','NUM':'numbers','VERB':'predicates','NOUN':'nouns','ADJ':'modifiers','ADV':'modifiers'}
    for r in flags:
        categories.update({names[t['pos']] for t in r['coverage']['missing']})
        terms.update(t['text'] for t in r['coverage']['missing'])
    prior=ROOT/'exp/probabilistic_verification/review_followup_20261104/human_analysis/analysis.json'
    faithful=[r['claim_id'] for r in json.loads(prior.read_text())['cases'] if r['by_condition']['revised']['rating']=='faithful']
    assert len(faithful)==11
    assert all(after[c]['status']=='compiled' and after[c]['program_sha256']==before[c]['program_sha256'] for c in faithful)
    freeze=json.loads((RUN/'frozen_manifest.json').read_text())
    for name,digest in freeze['source_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    sample=json.loads((RUN/'sample_manifest.json').read_text())
    for name,digest in sample['frozen_files_sha256'].items():
        assert hashlib.sha256((RUN/name).read_bytes()).hexdigest()==digest,name
    reading=json.loads((RUN/'fresh_readings_freeze.json').read_text())
    assert hashlib.sha256((RUN/'fresh_readings.json').read_bytes()).hexdigest()==reading['sha256']
    fresh=[c['claim_id'] for c in sample['cases']]
    assert all(before[c]['status']==after[c]['status'] and before[c].get('program_sha256')==after[c].get('program_sha256') for c in fresh)
    summary=dict(total=2375,before_executable=len(previous),after_executable=len(candidates),
        accepted=sum(r['status']=='compiled' for r in after.values()),coverage_review_required=len(flags),
        earlier_refusals=2375-len(candidates),changed_programs=len(changed),unchanged_user_faithful=11,
        accepted_kinds=dict(Counter(r['compilation']['metadata']['kind'] for r in after.values() if r['status']=='compiled')),
        refusal_reasons=dict(Counter(r['code'] for r in after.values() if r['status']!='compiled')),
        flagged_claim_categories=dict(sorted(categories.items())),frequent_missing_terms=terms.most_common(20),
        fresh_count=20,fresh_changed_programs=0,fresh_changed_statuses=0,
        fresh_assistant_judgments=json.loads((RUN/'fresh_review.json').read_text())['counts'],
        unexpected_errors=[r['claim_id'] for r in after.values() if r.get('code','')[:1].isupper()],
        interpretation='Acceptance after the coverage gate is not semantic accuracy. Candidates with alerts remain available for diagnosis.')
    (RUN/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
    (RUN/'changed_cases.json').write_text(json.dumps(changed,indent=2,ensure_ascii=False)+'\n')
    (RUN/'coverage_alerts.json').write_text(json.dumps([dict(claim_id=r['claim_id'],text=r['text'],missing=r['coverage']['missing']) for r in flags],indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
