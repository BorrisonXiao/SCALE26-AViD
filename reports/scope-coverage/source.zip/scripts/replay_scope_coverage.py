#!/usr/bin/env python3
"""Replay all new and preceding records from the archived input parses."""
import hashlib
import json
import time
from pathlib import Path

from run_scope_coverage_census import compile_one as current
from run_reviewed_srl_census import compile_one as previous

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/scope_coverage_20261105'


def main():
    for name,digest in json.loads((RUN/'frozen_manifest.json').read_text())['source_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    records=list(map(json.loads,(RUN/'inputs.jsonl').read_text().splitlines()));proof={}
    for label,filename,compile_one in [('current','results.jsonl',current),('previous','baseline.jsonl',previous)]:
        expected={r['claim_id']:r for r in map(json.loads,(RUN/filename).read_text().splitlines())}
        start=time.perf_counter()
        for record in records:
            assert json.loads(json.dumps(compile_one(record)))==expected[record['claim_id']],(label,record['claim_id'])
        proof[label]=dict(exact_records=len(records),seconds=time.perf_counter()-start)
        print(label,len(records),'exact records, programs and diagnostics',flush=True)
    (RUN/'replay_verification.json').write_text(json.dumps(proof,indent=2)+'\n')


if __name__=='__main__':main()
