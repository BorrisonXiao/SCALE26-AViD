#!/usr/bin/env python3
"""Reproduce every outcome and program from cached original annotations."""
import hashlib,json
from run_scoped_srl_census import ROOT,RUN,read,compile_one

def signature(r):return tuple(r.get(k) for k in ['claim_id','status','code','program_sha256','diagnostics','changes'])
def main():
 f=json.loads((RUN/'frozen_manifest.json').read_text())
 for p,h in f['source_sha256'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 for name,key in [('sample_manifest.json','sample_sha256'),('inputs.jsonl','input_sha256'),('reference_readings_template.json','reference_template_sha256')]:assert hashlib.sha256((RUN/name).read_bytes()).hexdigest()==f[key],name
 actual=[compile_one(r) for r in read('inputs.jsonl')];expected=read('results.jsonl');assert [signature(r) for r in actual]==[signature(r) for r in expected]
 print('2375 outcomes, program hashes, diagnostics and compiler changes match frozen source.')
 print('Reserved human-review membership and empty reference template remain unchanged.')
if __name__=='__main__':main()
