#!/usr/bin/env python3
"""Recompute census changes and verify preservation of the reserved review outputs."""
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/compiler_revision_20261105'
PREP = ROOT / 'exp/probabilistic_verification/review_followup_20261104'


def rows(path):
    return {r['claim_id']: r for r in map(json.loads, path.read_text().splitlines())}


def main():
    before, after = rows(RUN / 'baseline.jsonl'), rows(RUN / 'results.jsonl')
    assert set(before) == set(after) and len(after) == 2375
    fresh = json.loads((PREP / 'sample_manifest.json').read_text())
    ids = [c['claim_id'] for c in fresh['cases']]
    first = rows(RUN / 'first_frozen/results.jsonl')
    pairs, changes, notes = Counter(), [], Counter()
    for cid, row in after.items():
        old = before[cid]
        key = ('both_compiled' if row['status'] == old['status'] == 'compiled' else
               'both_refused' if row['status'] != 'compiled' and old['status'] != 'compiled' else
               'newly_compiled' if row['status'] == 'compiled' else 'newly_refused')
        pairs[key] += 1
        if row.get('program_sha256') != old.get('program_sha256') or row['status'] != old['status']:
            changes.append(dict(claim_id=cid, text=row['text'], before=old['status'], after=row['status'], code=row.get('code')))
        old_notes = Counter(json.dumps(n, sort_keys=True) for n in old.get('changes', []))
        for note in row.get('changes', []):
            value = json.dumps(note, sort_keys=True)
            if old_notes[value]:
                old_notes[value] -= 1
            elif row['status'] == 'compiled':
                notes[note['kind']] += 1
    original_human = json.loads((PREP / 'human_analysis/analysis.json').read_text())
    faithful = [r['claim_id'] for r in original_human['cases'] if r['by_condition']['revised']['rating'] == 'faithful']
    assert len(faithful) == 11 and all(after[c].get('program_sha256') == before[c].get('program_sha256') for c in faithful)
    for cid in ids:
        assert after[cid]['status'] == before[cid]['status'] == first[cid]['status']
        assert after[cid].get('program_sha256') == before[cid].get('program_sha256') == first[cid].get('program_sha256')
    freeze = json.loads((RUN / 'frozen_manifest.json').read_text())
    for name, digest in freeze['source_sha256'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    reading_freeze = json.loads((RUN / 'fresh_readings_freeze.json').read_text())
    assert hashlib.sha256((RUN / 'fresh_readings.json').read_bytes()).hexdigest() == reading_freeze['sha256']
    summary = dict(total=2375, before_compiled=sum(r['status'] == 'compiled' for r in before.values()),
        after_compiled=sum(r['status'] == 'compiled' for r in after.values()), pairs=dict(pairs),
        changed_programs=len(changes), new_notes_in_accepted_outputs=dict(notes),
        kinds=dict(Counter(r['compilation']['metadata']['kind'] for r in after.values() if r['status'] == 'compiled')),
        refusal_reasons=dict(Counter(r.get('code') for r in after.values() if r['status'] != 'compiled')),
        fresh_claims=len(ids), fresh_changed=0, fresh_outputs_identical_to_first_freeze=True,
        unchanged_user_faithful_programs=len(faithful),
        unexpected_exceptions=[dict(claim_id=r['claim_id'], code=r.get('code'), reason=r.get('reason'))
                               for r in after.values() if r.get('code', '')[:1].isupper()])
    (RUN / 'census_analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
    (RUN / 'changed_cases.json').write_text(json.dumps(changes, indent=2, ensure_ascii=False) + '\n')
    proof = dict(final_compiler_sha256=freeze['source_sha256'], fresh_cases=[dict(claim_id=cid,
        before=before[cid].get('program_sha256'), first_frozen=first[cid].get('program_sha256'), final=after[cid].get('program_sha256'))
        for cid in ids], source_unchanged_since_final_freeze=True, claim_readings_unchanged=True,
        chronology='First freeze preceded fresh output inspection. Final safety restrictions used non-reserved changed cases; all20 fresh programs remain identical to both the first freeze and the Nov1 baseline.')
    (RUN / 'fresh_preservation.json').write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
