const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
let inventory=[],visible=[],current='',sequence=0;
const chunks=new Map();
function renderOutput(label,output,assessment,number){
  let html='<section class="output"><h3>'+label+'</h3>';
  if(assessment)html+='<p class="review-note">'+esc(assessment)+'</p>';
  html+=ClaimOutputView.render(output,output.metadata,number);
  if(output.status==='compiled')html+='<details><summary>Exact predicates and logical form</summary><pre>'+esc(output.predicates.join('\n'))+'</pre><pre>'+esc(JSON.stringify(output.form,null,2))+'</pre></details>';
  return html+'</section>';
}
async function show(cid){
  current=cid;const token=++sequence,meta=inventory.find(c=>c.claim_id===cid);if(!meta)return;
  $('claim-select').value=cid;$('claim-id').textContent=cid;$('claim-text').textContent=meta.text;
  $('outputs').innerHTML='<p>Loading the saved structures…</p>';
  if(!chunks.has(meta.chunk))chunks.set(meta.chunk,fetch('reviewed-compilation/'+meta.chunk).then(r=>{if(!r.ok)throw Error('Could not load saved outputs.');return r.json();}));
  try{
    const rows=await chunks.get(meta.chunk);if(token!==sequence)return;
    const row=rows.find(r=>r.claim_id===cid),after=row.after||row.before;
    $('reading').textContent=row.reading?row.reading_source+': '+row.reading:'No separate intended-reading annotation exists for this claim.';
    $('change-note').textContent=row.same?(after.status==='compiled'?'The saved compiled program is unchanged by this round.':'Both versions refused compilation for this claim.'):'The compiled output changed in this round.';
    let beforeNote='',afterNote='';
    if(row.human){
      beforeNote='User review of the 1 November output: '+(row.human.status==='compiled'?row.human.rating:'refusal appropriate: '+row.human.rating)+'. '+row.human.reason;
      afterNote=row.same?'Same program as the user-reviewed output.':'This changed program has no new human rating; inspect the retained conditions below.';
    }
    if(row.fresh){
      beforeNote='Assistant assessment: '+row.fresh.before.judgment+'. '+row.fresh.before.reason;
      afterNote='Assistant assessment: '+row.fresh.after.judgment+'. '+row.fresh.after.reason;
    }
    $('outputs').innerHTML=renderOutput('Before fixes · 1 November',row.before,beforeNote,1)+renderOutput('After fixes · 5 November',after,afterNote,2);
    $('notes').textContent=row.new_notes.length?'Changes recorded: '+row.new_notes.map(n=>n.kind.replaceAll('_',' ')).join('; ')+'.':'No new annotation change is recorded.';
    $('previous').disabled=visible.findIndex(c=>c.claim_id===cid)<=0;
    $('next').disabled=visible.findIndex(c=>c.claim_id===cid)>=visible.length-1;
  }catch(error){$('outputs').textContent=error.message;}
}
function filter(){
  const mode=$('filter').value,term=$('search').value.toLowerCase();
  visible=inventory.filter(c=>(!term||(c.claim_id+' '+c.text).toLowerCase().includes(term))&&(
    mode==='all'||mode==='compiled'&&c.after==='compiled'||mode==='refused'&&c.after!=='compiled'||
    mode==='new'&&c.before!=='compiled'&&c.after==='compiled'||mode==='changed'&&c.changed||
    mode==='human'&&c.human||mode==='fresh'&&c.fresh));
  $('match-count').textContent=visible.length+' of '+inventory.length+' claims';
  $('claim-select').innerHTML=visible.map(c=>'<option value="'+esc(c.claim_id)+'">'+esc(c.claim_id+' · '+c.text.slice(0,120))+'</option>').join('');
  if(visible.length)show(visible.some(c=>c.claim_id===current)?current:visible[0].claim_id);
  else{$('claim-id').textContent='No matching claims';$('claim-text').textContent='';$('outputs').innerHTML='';}
}
function pick(cid){$('filter').value='all';$('search').value='';current=cid;filter();}
$('filter').addEventListener('change',filter);let timer;
$('search').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(filter,150);});
$('claim-select').addEventListener('change',e=>show(e.target.value));
$('previous').addEventListener('click',()=>show(visible[visible.findIndex(c=>c.claim_id===current)-1].claim_id));
$('next').addEventListener('click',()=>show(visible[visible.findIndex(c=>c.claim_id===current)+1].claim_id));
document.querySelectorAll('[data-claim]').forEach(a=>a.addEventListener('click',()=>pick(a.dataset.claim)));
fetch('reviewed-compilation/index.json').then(r=>r.json()).then(data=>{inventory=data;pick(new URLSearchParams(location.search).get('claim')||'TLO3smKI67PM_554');}).catch(e=>{$('outputs').textContent=e.message;});
