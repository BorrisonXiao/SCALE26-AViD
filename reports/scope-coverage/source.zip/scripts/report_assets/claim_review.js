const DATA = JSON.parse(document.getElementById('review-data').textContent);
const key = 'avid-claim-review-' + DATA.packet_id;
const $ = id => document.getElementById(id);
const escapeHTML = x => String(x ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const fields = ['intended_meaning','participants_and_relations','source_context','quantity_and_time','ambiguity'];
const judgments = ['faithful','partial','incorrect','uncertain'];
let index = 0, comparing = false;
let saved;
try { saved = JSON.parse(localStorage.getItem(key) || 'null'); } catch { saved = null; }
let answers = saved?.packet_id === DATA.packet_id ? saved : {
  packet_id: DATA.packet_id, compiler_freeze: DATA.compiler_freeze, reviewer: '',
  cases: DATA.cases.map(c => ({claim_id:c.claim_id, claim:c.text, claim_sha256:c.claim_sha256,
    intended_meaning:'',participants_and_relations:'',source_context:'',quantity_and_time:'',ambiguity:'',
    readings_complete:false, comparison_opened:false, reading_edited_after_comparison:false,
    outputs:{A:{judgment:'',reason:'',refusal_appropriate:''},B:{judgment:'',reason:'',refusal_appropriate:''}}}))
};
function persist(){
  answers.updated_at = new Date().toISOString();
  localStorage.setItem(key, JSON.stringify(answers));
  updateProgress();
}
function completeComparison(a,c){
  return ['A','B'].every(letter=>c.outputs[letter].status==='compiled' ? judgments.includes(a.outputs[letter].judgment) : ['yes','no','unsure'].includes(a.outputs[letter].refusal_appropriate));
}
function updateProgress(){
  const readings = answers.cases.filter(a=>a.readings_complete).length;
  const ratings = answers.cases.filter((a,i)=>completeComparison(a,DATA.cases[i])).length;
  $('progress').textContent = readings+' / '+DATA.cases.length+' readings saved · '+ratings+' / '+DATA.cases.length+' comparisons completed';
  $('case-select').innerHTML = DATA.cases.map((c,i)=>'<option value="'+i+'">'+(i+1)+' · '+escapeHTML(c.claim_id)+(answers.cases[i].readings_complete?' · reading saved':'')+'</option>').join('');
  $('case-select').value = String(index);
}
function renderForm(form){
  const entities=Object.fromEntries((form?.entities||[]).map(e=>[e.id,e]));
  const shown=new Set();
  function entity(id){
    const e=entities[id];if(!e)return escapeHTML(id);
    let html='<b>'+escapeHTML(e.text)+'</b> <small>'+escapeHTML(id)+'</small>';
    if(shown.has(id))return html+' <small>(same referent)</small>';
    shown.add(id);
    for(const p of e.properties||[])html+='<div>'+escapeHTML(p.role)+': '+escapeHTML(p.value)+'</div>';
    if(e.quantity)html+='<div>Quantity: '+escapeHTML(e.quantity.operator+' '+e.quantity.value)+'</div>';
    for(const r of e.relations||[])html+='<div class="tree">'+escapeHTML(r.role)+': '+entity(r.target)+'</div>';
    for(const p of e.propositions||[])html+=proposition(p);
    return html;
  }
  const routes={visual_depiction:'visual depiction',audio_event:'sound',speech_assertion:'speech',ocr_assertion:'on-screen text',unspecified:'source not specified'};
  function proposition(p){return '<div class="tree"><b>'+escapeHTML(p.kind==='sufficiency'?'sufficient for this goal':p.kind)+'</b> · '+escapeHTML(routes[p.route]||p.route)+'<div>'+node(p.body)+'</div></div>';}
  function node(n){
    if(!n)return 'No logical form.';
    if(n.op==='entity')return entity(n.ref);
    if(n.op==='and'||n.op==='or')return '<b>'+n.op.toUpperCase()+'</b>'+n.children.map(x=>'<div class="tree">'+node(x)+'</div>').join('');
    if(n.op==='not')return '<b>NOT</b><div class="tree">'+node(n.child)+'</div>';
    if(n.op==='qualified')return '<b>'+escapeHTML(n.operator)+'</b><div class="tree">'+node(n.body)+'</div>';
    let html='<b>'+escapeHTML(n.predicate)+'</b> <small>'+escapeHTML(n.id)+'</small>';
    for(const [role,value] of Object.entries(n.arguments||{}))html+='<div class="tree"><span class="role">'+escapeHTML(role)+'</span> '+(typeof value==='string'?entity(value):escapeHTML(value.value??JSON.stringify(value)))+'</div>';
    for(const p of n.properties||[])html+='<div>'+escapeHTML(p.role)+': '+escapeHTML(p.value)+'</div>';
    for(const p of n.propositions||[])html+=proposition(p);
    return html;
  }
  return node(form?.formula);
}
function outputCard(letter,c,a){
  const r=c.outputs[letter],rating=a.outputs[letter];
  let html='<section class="output"><h3>Output '+letter+'</h3>';
  if(r.status!=='compiled'){
    html+='<p><b>No program compiled.</b></p><p>'+escapeHTML(r.reason||r.code)+'</p><label>Is this refusal appropriate?<select data-refusal="'+letter+'"><option value="">Not rated</option><option value="yes">Yes</option><option value="no">No</option><option value="unsure">Unsure</option></select></label>';
  } else {
    html+='<figure>'+renderForm(r.form);
    if(r.event_references?.length)html+='<p>'+r.event_references.map(x=>escapeHTML(x.mention+' and '+x.event+' share '+x.variable)).join('<br>')+'</p>';
    html+='<figcaption>Figure '+(letter==='A'?1:2)+'. Anonymous compiled structure '+letter+'. Node IDs identify shared references; source contexts are shown beside nested content.</figcaption></figure>';
    html+='<details><summary>Exact logical predicates</summary><pre>'+escapeHTML((r.predicates||[]).join('\n'))+'</pre></details>';
    if(r.runtime_requirements?.length)html+='<p><b>Recorded context requirements:</b> '+escapeHTML(r.runtime_requirements.join('; '))+'.</p>';
    html+='<label>Does this output preserve the intended reading?<select data-judgment="'+letter+'"><option value="">Not rated</option><option value="faithful">Faithful</option><option value="partial">Partial</option><option value="incorrect">Incorrect</option><option value="uncertain">Unsure</option></select></label>';
  }
  html+='<label>Reason or missing relationship<textarea data-reason="'+letter+'" rows="3">'+escapeHTML(rating.reason)+'</textarea></label></section>';
  return html;
}
function show(){
  const c=DATA.cases[index],a=answers.cases[index];
  $('claim-id').textContent=c.claim_id;$('claim-text').textContent=c.text;
  for(const f of fields)$(f).value=a[f]||'';
  $('reading-status').textContent=a.readings_complete?'Reading saved.':'';
  $('readings').hidden=comparing;$('comparison').hidden=!comparing;
  $('phase-label').textContent=comparing?'2. Compare anonymous outputs':'1. Write the intended reading';
  if(comparing){
    $('outputs').innerHTML=['A','B'].map(l=>outputCard(l,c,a)).join('');
    for(const l of ['A','B']){
      const j=document.querySelector('[data-judgment="'+l+'"]');if(j){j.value=a.outputs[l].judgment;j.addEventListener('change',()=>{a.outputs[l].judgment=j.value;persist();});}
      const r=document.querySelector('[data-refusal="'+l+'"]');if(r){r.value=a.outputs[l].refusal_appropriate;r.addEventListener('change',()=>{a.outputs[l].refusal_appropriate=r.value;persist();});}
      document.querySelector('[data-reason="'+l+'"]').addEventListener('input',e=>{a.outputs[l].reason=e.target.value;persist();});
    }
  }
  updateProgress();$('previous').disabled=index===0;$('next').disabled=index===DATA.cases.length-1;
}
$('reviewer').value=answers.reviewer;
$('reviewer').addEventListener('input',e=>{answers.reviewer=e.target.value;persist();});
for(const f of fields)$(f).addEventListener('input',e=>{const a=answers.cases[index];a[f]=e.target.value;if(a.comparison_opened)a.reading_edited_after_comparison=true;persist();});
$('save-reading').addEventListener('click',()=>{
  const a=answers.cases[index];if(!a.intended_meaning.trim()){$('reading-status').textContent='Write an intended reading before opening the outputs.';return;}
  a.readings_complete=true;a.reading_saved_at=new Date().toISOString();a.comparison_opened=true;comparing=true;persist();show();
});
$('back-reading').addEventListener('click',()=>{comparing=false;show();});
$('previous').addEventListener('click',()=>{index--;comparing=false;show();});$('next').addEventListener('click',()=>{index++;comparing=false;show();});
$('case-select').addEventListener('change',e=>{index=Number(e.target.value);comparing=false;show();});
$('download').addEventListener('click',()=>{
  persist();const blob=new Blob([JSON.stringify(answers,null,2)+'\n'],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='claim-compilation-review.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
$('import').addEventListener('change',async e=>{
  const file=e.target.files[0];if(!file)return;
  try{
    const incoming=JSON.parse(await file.text());if(incoming.packet_id!==DATA.packet_id||incoming.cases.length!==DATA.cases.length)throw Error('This review belongs to a different packet.');
    for(let i=0;i<DATA.cases.length;i++){
      const a=incoming.cases[i],c=DATA.cases[i];if(a.claim_id!==c.claim_id||a.claim_sha256!==c.claim_sha256)throw Error('Claim membership differs.');
      for(const l of ['A','B'])if(a.outputs[l].judgment&&!judgments.includes(a.outputs[l].judgment))throw Error('Unknown judgment.');
    }
    answers=incoming;persist();$('reviewer').value=answers.reviewer||'';comparing=false;show();$('import-status').textContent='Review restored.';
  }catch(error){$('import-status').textContent=error.message;}
});
show();
