const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
let inventory=[],visible=[],current='',sequence=0;
const chunks=new Map();
function output(label,data,review,n){
 let s='<section class="output"><h3>'+label+'</h3>';
 if(review)s+='<p class="review-note">'+esc(review)+'</p>';
 s+=ClaimOutputView.render(data,data.metadata,n);
 if(data.status==='compiled')s+='<details><summary>Exact predicates and logical form</summary><pre>'+esc(data.predicates.join('\n'))+'</pre><pre>'+esc(JSON.stringify(data.form,null,2))+'</pre></details>';
 return s+'</section>';
}
async function show(cid){
 current=cid;const ticket=++sequence,meta=inventory.find(c=>c.claim_id===cid);if(!meta)return;
 $('claim-select').value=cid;$('claim-id').textContent=cid;$('claim-text').textContent=meta.text;$('outputs').innerHTML='<p>Loading saved outputs…</p>';
 if(!chunks.has(meta.chunk))chunks.set(meta.chunk,fetch('scope-coverage/'+meta.chunk).then(r=>{if(!r.ok)throw Error('Could not load outputs.');return r.json();}));
 try{
  const rows=await chunks.get(meta.chunk);if(ticket!==sequence)return;
  const row=rows.find(r=>r.claim_id===cid),after=row.after||row.before;
  $('reading').textContent=row.reading?'Assistant intended reading, saved before output inspection: '+row.reading.intended_meaning:'';
  $('audit-note').textContent=row.code==='coverage_omission'?'Review required: '+row.reason+'. The diagnostic program is shown below; it is not accepted as complete.':row.accepted?'Accepted after the coverage check. This is not a semantic correctness certificate.':row.reason;
  $('diagnosis').textContent=row.diagnosis||(row.alert_review?'Assistant alert review: '+row.alert_review.reason:'');
  let before='',later='';
  if(row.fresh){before='Assistant judgment: '+row.fresh.before.judgment+'. '+row.fresh.before.reason;later='Assistant judgment: '+row.fresh.after.judgment+'. '+row.fresh.after.reason;}
  else if(!row.changed)later='The executable program is unchanged.';
  $('outputs').innerHTML=output('Previous compiler',row.before,before,1)+output(row.code==='coverage_omission'?'Current diagnostic candidate':'Scope/coverage revision',after,later,2);
  $('notes').textContent=row.notes.length?'Recorded repairs: '+row.notes.map(n=>n.kind.replaceAll('_',' ')).join('; ')+'.':'No structural repair is recorded for this case.';
  const i=visible.findIndex(c=>c.claim_id===cid);$('previous').disabled=i<=0;$('next').disabled=i>=visible.length-1;
 }catch(e){$('outputs').textContent=e.message;}
}
function filter(){
 const mode=$('filter').value,term=$('search').value.toLowerCase();
 visible=inventory.filter(c=>(!term||(c.claim_id+' '+c.text).toLowerCase().includes(term))&&(mode==='all'||c[mode]));
 $('match-count').textContent=visible.length+' of '+inventory.length+' claims';
 $('claim-select').innerHTML=visible.map(c=>'<option value="'+esc(c.claim_id)+'">'+esc(c.claim_id+' · '+c.text.slice(0,120))+'</option>').join('');
 if(visible.length)show(visible.some(c=>c.claim_id===current)?current:visible[0].claim_id);
 else{$('claim-id').textContent='No matching claims';$('claim-text').textContent='';$('outputs').innerHTML='';}
}
function pick(cid){$('filter').value='all';$('search').value='';current=cid;filter();}
$('filter').addEventListener('change',filter);let timer;
$('search').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(filter,150);});
$('claim-select').addEventListener('change',e=>show(e.target.value));
$('previous').addEventListener('click',()=>show(visible[visible.findIndex(c=>c.claim_id===current)-1].claim_id));
$('next').addEventListener('click',()=>show(visible[visible.findIndex(c=>c.claim_id===current)+1].claim_id));
document.querySelectorAll('[data-claim]').forEach(a=>a.addEventListener('click',()=>pick(a.dataset.claim)));
fetch('scope-coverage/index.json').then(r=>r.json()).then(data=>{inventory=data;pick(new URLSearchParams(location.search).get('claim')||'T2G_ACMxR_I4_1367');}).catch(e=>{$('outputs').textContent=e.message;});
