#!/usr/bin/env python3
"""Build the human-review/compiler report and an auditable full-corpus viewer."""
import hashlib
import json
import shutil
import zipfile
from collections import Counter
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/compiler_revision_20261105'
PREP = ROOT / 'exp/probabilistic_verification/review_followup_20261104'
SITE = ROOT / 'site'


def load(path):
    return json.loads(path.read_text())


def rows(path):
    return {r['claim_id']: r for r in map(json.loads, path.read_text().splitlines())}


def slim(row):
    metadata = row.get('compilation', {}).get('metadata', {})
    events = {k: {field: e.get(field) for field in ('id', 'predicate', 'scope', 'route', 'owner')}
              for k, e in metadata.get('events', {}).items()}
    return dict(status=row['status'], code=row.get('code'), reason=row.get('reason'),
        form=metadata.get('logical_form'), runtime_requirements=metadata.get('runtime_requirements', []),
        event_references=metadata.get('event_references', []),
        predicates=[a['predicate']+'('+', '.join(a['arguments'])+')' for a in row.get('compilation', {}).get('atoms', [])],
        metadata=dict(events=events, temporal=metadata.get('temporal', {})))


def main():
    summary = load(RUN / 'census_analysis.json')
    before, after = rows(RUN / 'baseline.jsonl'), rows(RUN / 'results.jsonl')
    human_analysis = load(PREP / 'human_analysis/analysis.json')
    receipt = load(PREP / 'received_review/receipt.json')
    human_export = load(ROOT / receipt['preserved_path'])
    human_answers = {c['claim_id']: c for c in human_export['cases']}
    human = {c['claim_id']: c for c in human_analysis['cases']}
    fresh_review = load(RUN / 'fresh_review.json')
    fresh = {c['claim_id']: c for c in fresh_review['cases']}
    fresh_readings = {c['claim_id']: c for c in load(RUN / 'fresh_readings.json')['cases']}
    native = load(RUN / 'native_profile.json')
    diagnosis = load(RUN / 'failure_diagnosis.json')
    folder = SITE / 'reports/reviewed-compilation'
    folder.mkdir(parents=True, exist_ok=True)
    index, chunks = [], []
    for i, (cid, row) in enumerate(after.items()):
        old = before[cid]
        same = row['status'] == old['status'] and row.get('program_sha256') == old.get('program_sha256') and row.get('code') == old.get('code')
        chunk = 'cases-'+str(i//100).zfill(2)+'.json'
        index.append(dict(claim_id=cid, text=row['text'], before=old['status'], after=row['status'],
                          changed=not same, human=cid in human, fresh=cid in fresh, chunk=chunk))
        oldnotes = Counter(json.dumps(n, sort_keys=True) for n in old.get('changes', []))
        newnotes = []
        for note in row.get('changes', []):
            key = json.dumps(note, sort_keys=True)
            if oldnotes[key]: oldnotes[key] -= 1
            else: newnotes.append(note)
        reading = (human_answers[cid]['intended_meaning'] if cid in human_answers else
                   fresh_readings[cid]['intended_meaning'] if cid in fresh_readings else '')
        item = dict(claim_id=cid, before=slim(old), after=None if same else slim(row), same=same,
                    new_notes=newnotes, reading=reading,
                    reading_source='Intended meaning from your review' if cid in human_answers else 'Assistant reading written before output inspection',
                    human=human[cid]['by_condition']['revised'] if cid in human else None,
                    fresh=fresh.get(cid))
        if i % 100 == 0: chunks.append([])
        chunks[-1].append(item)
    (folder / 'index.json').write_text(json.dumps(index, ensure_ascii=False, separators=(',', ':')) + '\n')
    for i, chunk in enumerate(chunks):
        (folder / ('cases-'+str(i).zfill(2)+'.json')).write_text(json.dumps(chunk, ensure_ascii=False, separators=(',', ':')) + '\n')
    for name in ('census_analysis.json', 'failure_diagnosis.json', 'fresh_review.json', 'fresh_readings.json',
                 'fresh_preservation.json', 'frozen_manifest.json', 'safety_restrictions.json', 'native_profile.json',
                 'changed_cases.json', 'previous_new_refusals.json', 'tests.xml'):
        shutil.copy2(RUN / name, folder / name)
    shutil.copy2(PREP / 'human_analysis/analysis.json', folder / 'human_review_analysis.json')
    shutil.copy2(ROOT / 'docs/reviewed_srl_compilation.md', folder / 'README.md')

    def table(number, caption, headers, data):
        return '<div class="table-wrap"><table><caption>Table '+str(number)+'. '+caption+'</caption><thead><tr>'+''.join('<th>'+escape(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(v)+'</td>' for v in row)+'</tr>' for row in data)+'</tbody></table></div>'
    def link(cid, label=None):
        return '<a href="#examples" data-claim="'+escape(cid)+'">'+escape(label or cid)+'</a>'
    body = '<section><h2>What your review established</h2><p>All 20 readings and comparisons were returned and validated. The original file was moved into the experiment records with its bytes unchanged. Your review was assisted by an agent draft; the six changed ratings remain recorded separately from the original suggestions.</p>'
    body += table(1, 'Your ratings of the two earlier compiler versions; refusals are assessed separately.', ['Version', 'Faithful', 'Partial', 'Incorrect', 'Refused', 'Refusals judged appropriate / not appropriate'],
                  [('30 October', 11, 6, 1, 2, '1 / 1'), ('1 November', 11, 4, 1, 4, '1 / 3')])
    body += '<p>The 16 cases compiled by both versions have tied ratings. Two partial outputs became refusals you judged unnecessary; the earlier revision did not demonstrate a meaning improvement on this review. You accepted the passive-progressive simplification for now and allowed a difficult noun phrase to remain one verification argument.</p></section>'
    body += '<section><h2>This revision: a small coverage increase and targeted structural fixes</h2>'
    body += table(2, 'Full inventory of original texts. Compilation acceptance is distinct from meaning preservation.', ['Condition', 'Compiled', 'Claim structures', 'Nominal descriptions', 'Refused'],
                  [('Before fixes · 1 November', 2095, 1924, 171, 280), ('After fixes · 5 November', summary['after_compiled'], summary['kinds']['claim'], summary['kinds']['mention'], 2375-summary['after_compiled'])])
    body += '<p><b>'+str(summary['pairs'].get('newly_compiled', 0))+' additions; no earlier accepts lost; '+str(summary['changed_programs'])+' programs changed.</b> All 11 current programs you rated faithful remain byte-identical. Three refusals you judged unnecessary now compile. Three of the 15 accepts lost in the previous revision are restored; the other 12 remain refused. None of these counts is a new human accuracy score.</p>'
    body += table(3, 'Three families of changes, checked against saved annotations and programs.', ['Family', 'Changes', 'Review examples'], [
        ('Argument and modifier retention', 'Complete quoted text; next-to targets and names; report topics attached to the report.', link('TgR_u37mCoQ4_1907','Quoted time')+' · '+link('TLO3smKI67PM_554','Karen and proximity')+' · '+link('TzF9M4kZ3Pys_240','Report topic')),
        ('Coordination and participant binding', 'Recover a participial conjunct with a shared subject; use explicit relative-clause controllers; retain a reciprocal target instead of an unrelated other entity.', link('TQKCK6-tRaoE_669','Singing and dancing')+' · '+link('TW4OYA3RN-Hw_1797','Attempted storming')+' · '+link('TFOEIehBwT8Q_473','Each other')),
        ('Nominal alternatives and apposition', 'Retain an unresolved noun phrase whole; interpret a descriptive comma-or gloss as apposition, with that reading explicitly recorded.', link('TgPh_fzHTCm4_1507','Ridge or anti-cyclone')+' · '+link('TzF9M4kZ3Pys_218','Haboob description'))])
    body += '<p><b>New argument meanings:</b> <code>reciprocal</code> tells the relation verifier to interpret “each other” over the supplied group within the same event. <code>noun_phrase</code> keeps the exact phrase as one argument; it does not expose the internal bindings. Neither is a newly trained media model. The appositive reading is a recorded interpretation requiring context, rather than a claim of a complete general grammar.</p></section>'
    body += '<section><h2>Fresh review: the important remaining limitation</h2><p>Twenty cases spanning 21 source videos were reserved before fixes, excluding 129 recorded review sources. All texts had been parsed earlier. The compiler-author assistant wrote intended readings before inspecting outputs, then reviewed the structures. These are qualitative assistant judgments, not independent human references or a uniform corpus accuracy estimate.</p>'
    body += table(4, 'The fresh programs are unchanged in this round, so the paired judgments are identical.', ['Condition', 'Faithful', 'Partial', 'Incorrect', 'Refused'], [('Before fixes',13,4,3,0),('After fixes',13,4,3,0)])
    body += '<p>One faithful rating tolerates the passive-progressive simplification you accepted. Counting that case as partial gives 12 faithful, 5 partial and 3 incorrect. The sample shows <b>no fresh semantic gain</b>. It exposes recurring errors in scope and missing content that this bounded revision did not address.</p>'
    fresh_rows=[]
    for c in fresh_review['cases']:
        text=after[c['claim_id']]['text']
        fresh_rows.append((link(c['claim_id'],text),escape(c['after']['judgment']),escape(c['after']['reason'])))
    body += table(5,'All twenty fresh judgments, with links to the actual structures.',['Original claim','Assistant judgment','Reason'],fresh_rows)
    body += '<p><b>Freeze chronology:</b> The first compiler freeze preceded fresh output inspection. An audit of other changed cases then exposed unsafe name/controller rules. Two safety restrictions were added and the first source/results retained. All 20 final fresh program hashes are unchanged from both the first freeze and the 1 November baseline; the readings and ratings were not rewritten. <a href="reviewed-compilation/fresh_preservation.json">Inspect the hash check</a>.</p></section>'
    body += '<section id="examples"><h2>Inspect the actual compiled outputs</h2><p>'+link('TLO3smKI67PM_554','Retained proximity')+' · '+link('TFOEIehBwT8Q_473','Reciprocal binding')+' · '+link('T2G_ACMxR_I4_1367','Remaining landing-scope error')+' · '+link('TMrQshDs8aH0_752','Missing sound event')+'</p><div class="toolbar"><label>Subset<select id="filter"><option value="all">All claims</option><option value="compiled">Compiled</option><option value="refused">Refused</option><option value="new">Newly compiled</option><option value="changed">Changed programs</option><option value="human">User-reviewed development cases</option><option value="fresh">Fresh review cases</option></select></label><label>Search<input id="search" type="search" placeholder="Claim text or ID"></label></div><p id="match-count" role="status">Loading inventory…</p><label>Claim<select id="claim-select"></select></label><div class="toolbar"><button id="previous">Previous</button><button id="next">Next</button></div><h3 id="claim-id"></h3><blockquote id="claim-text"></blockquote><p id="reading"></p><p id="change-note" class="note"></p><p class="cv-legend">Numbered participant roles retain the parser’s labels; their meanings depend on the verb. Named and grammatical relations keep their source labels. Nested boxes show source/content attachment. Time labels come from compiled metadata. The outputs are visible before optional raw predicates.</p><div id="outputs" class="output-grid"></div><p id="notes"></p></section>'
    reasons = summary['refusal_reasons']
    body += '<section><h2>Remaining refusals and native execution</h2>'
    body += table(6,'Compiler refusal reasons across all 276 uncompiled claims. A refusal does not establish that a claim is false.',['Reason','Claims'],[(escape(k.replace('_',' ')),v) for k,v in sorted(reasons.items(),key=lambda p:-p[1])])
    body += table(7,'Bounded native DeepProbLog checks on constructed unknown evidence. Process time includes loading.',['Case','Outcome','Process seconds','Limit'],[(link(r['claim_id']),escape(r['status']),f'{r["process_seconds"]:.2f}',str(r['limit_seconds'])+' s') for r in native])
    body += '<p>Four representative programs return unknown as intended; the long protest/controller example reaches the 25-second process limit. All 2,099 emitted programs parse as ProbLog, but whole-corpus native inference and training throughput are unmeasured. The 207 regression checks include reciprocal supported/refuted/unknown cases and existing probability/gradient checks. No GPU, media inference, sentence rewriting or new relation-training experiment was used.</p></section>'
    body += '<section><h2>Next steps and intended goals</h2><ol><li>Address nominal event and question-content scope — prevent preparation, allegations and dialogue content from becoming independent world assertions.</li><li>Check original predicate and identifier coverage — retain sound events such as creaking and label details such as 76 before accepting a program.</li><li>Bound and profile larger programs — establish an efficient inference/training loop before expanding media experiments.</li></ol><p>The compiler remains experimental. This round supports targeted repairs and a clearer failure analysis; it does not establish general compilation reliability or a verification-method gain.</p><p><a href="verification-pipeline.html#next-steps">Project checklist</a> · <a href="reviewed-compilation/README.md">Implementation and reproduction</a> · <a href="reviewed-compilation/source.zip">Source and saved inputs</a> · <a href="reviewed-compilation/human_review_analysis.json">Returned review analysis</a> · <a href="reviewed-compilation/fresh_review.json">Fresh assistant judgments</a> · <a href="reviewed-compilation/census_analysis.json">Full-corpus statistics</a> · <a href="reviewed-compilation/tests.xml">Tests</a></p></section>'
    style = (ROOT/'scripts/report_assets/claim_output_view.css').read_text()+'''.container{max-width:1100px}section{margin:32px 0}.table-wrap{overflow:auto;margin:24px 0}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:12px;text-align:left;vertical-align:top;border:1px solid var(--border);min-width:90px}caption{text-align:left;font-weight:600;margin:12px 0}label{display:block;font-weight:600;margin:12px 0}input,select,button{font:inherit;color:var(--text);background:var(--surface);border:1px solid var(--border);border-radius:7px;padding:10px;max-width:100%}select{display:block;width:100%;box-sizing:border-box}button{cursor:pointer}button:disabled{opacity:.5}.toolbar{display:flex;gap:18px;flex-wrap:wrap}.toolbar label{min-width:0}.output-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:22px}.output{min-width:0;border:1px solid var(--border);border-radius:9px;padding:16px}pre{font:12px/1.7 ui-monospace,monospace;white-space:pre-wrap;overflow-wrap:anywhere;max-height:450px;overflow:auto}blockquote,.note{padding:15px;border-left:4px solid var(--accent);background:var(--surface-2);margin:18px 0}.review-note{font-size:13px}#claim-id{overflow-wrap:anywhere}@media(max-width:760px){.output-grid{grid-template-columns:1fr}}'''
    head='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Returned human claim review, targeted compiler fixes, full 2375 census and fresh semantic failures."><title>Human review and compiler revision · AViD</title><link rel="stylesheet" href="../assets/site.css"><style>'+style+'</style></head><body><nav class="site-nav" aria-label="Primary navigation"><div class="nav-inner"><a class="brand" href="../index.html">SCALE 2026 · AViD</a><div class="nav-links"><a href="../index.html">Home</a><a href="./" aria-current="page">Reports</a><a href="../proposals/">Proposals</a></div></div></nav><header class="hero"><div class="container"><p class="eyebrow">Compiler revision · 5 November 2026</p><h1>Human review and compiler revision</h1><p class="lede">Targeted omissions and bindings improve. Coverage rises by four claims; the fresh sample still exposes scope and content failures.</p><p><a href="#examples">Inspect before/after structures</a> · <a href="verification-pipeline.html#next-steps">Checklist</a> · <a href="./">All reports</a></p></div></header><main class="container prose">'
    page=head+body+'</main><footer class="site-footer"><div class="container">Generated from frozen inputs, the returned review and saved outputs. No model inference runs while this report builds.</div></footer><script>'+(ROOT/'scripts/report_assets/claim_output_view.js').read_text()+'</script><script>'+(ROOT/'scripts/report_assets/reviewed_compilation.js').read_text()+'</script></body></html>'
    (SITE/'reports/reviewed-compilation.html').write_text(page)
    print('Wrote report,2375-case index and',len(chunks),'output chunks.')


if __name__ == '__main__':
    main()
