#!/usr/bin/env python3
"""Package current source/evidence without changing earlier published archives."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/scope_coverage_20261105'
BASE=ROOT/'site/reports/reviewed-compilation/source.zip'


def main():
    manifest=RUN/'package_manifest.json'
    if BASE.exists():
        with zipfile.ZipFile(BASE) as z:
            contents={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
        names=sorted(contents)
    else:
        names=json.loads(manifest.read_text())['base_paths']
        contents={n:(ROOT/n).read_bytes() for n in names}
    manifest.write_text(json.dumps(dict(base_paths=names,statement='Previous source bundle preserved; current source and new evidence overlaid.'),indent=2)+'\n')
    files=[ROOT/n for n in ('scripts/probabilistic_verification/reviewed_srl.py',
        'scripts/probabilistic_verification/scope_coverage.py','scripts/run_scope_coverage_census.py',
        'scripts/analyze_scope_coverage.py','scripts/replay_scope_coverage.py',
        'scripts/build_scope_coverage_report.py','scripts/package_scope_coverage.py',
        'scripts/report_assets/scope_coverage.js','tests/test_scope_coverage.py',
        'docs/scope_coverage_compilation.md')]
    excluded={'publication.json','browser_checks.json','archive_verification.json','replay_verification.json','WORK_STATUS.md'}
    files += [p for p in RUN.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.jsonl','.md','.xml'} and p.name not in excluded]
    for path in files:contents[str(path.relative_to(ROOT))]=path.read_bytes()
    contents['README_SCOPE_COVERAGE.md']=(ROOT/'docs/scope_coverage_compilation.md').read_bytes()
    contents['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n'
        for name,data in sorted(contents.items()) if name!='SHA256SUMS').encode()
    target=ROOT/'site/reports/scope-coverage/source.zip';target.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in sorted(contents.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,5,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
    print('Packaged',len(contents),'files;',round(target.stat().st_size/1048576,2),'MiB')


if __name__=='__main__':main()
