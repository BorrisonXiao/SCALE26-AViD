#!/usr/bin/env python3
"""Package current evidence on top of the preceding reproducible compiler archive."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/compiler_revision_20261105'
BASE = ROOT / 'site/reports/scope-compilation/source.zip'


def main():
    manifest_path = RUN / 'package_manifest.json'
    if BASE.exists():
        with zipfile.ZipFile(BASE) as archive:
            contents = {name: archive.read(name) for name in archive.namelist() if not name.endswith('/')}
        base_names = sorted(contents)
    else:
        base_names = json.loads(manifest_path.read_text())['base_paths']
        contents = {name: (ROOT / name).read_bytes() for name in base_names}
    manifest_path.write_text(json.dumps(dict(base_paths=base_names,
        statement='Base files come from the preserved Nov1 source archive. Current evidence and source are overlaid; original archives are not modified.'), indent=2) + '\n')
    files = [ROOT / p for p in ('scripts/probabilistic_verification/reviewed_srl.py',
        'scripts/run_reviewed_srl_census.py', 'scripts/analyze_reviewed_srl_results.py',
        'scripts/replay_reviewed_srl.py', 'scripts/profile_reviewed_srl.py',
        'scripts/build_reviewed_compilation_report.py', 'scripts/package_reviewed_srl.py',
        'scripts/report_assets/reviewed_compilation.js', 'scripts/report_assets/claim_output_view.js',
        'scripts/report_assets/claim_output_view.css', 'tests/test_reviewed_srl.py',
        'scripts/analyze_claim_review.py', 'scripts/import_claim_review.py',
        'exp/probabilistic_verification/scope_compilation_20261101/human_review_status.json',
        'docs/reviewed_srl_compilation.md', 'site/assets/site.css')]
    excluded = {'WORK_STATUS.md', 'publication.json', 'browser_checks.json', 'archive_verification.json', 'replay_verification.json'}
    files += [p for p in RUN.rglob('*') if p.is_file() and p.suffix in {'.json', '.jsonl', '.xml', '.md', '.py'}
              and p.name not in excluded]
    prep = ROOT / 'exp/probabilistic_verification/review_followup_20261104'
    files += [prep / p for p in ('sample_manifest.json', 'fresh_inputs.jsonl', 'fresh_baseline.jsonl',
                                 'human_analysis/analysis.json', 'received_review/receipt.json')]
    receipt = json.loads((prep / 'received_review/receipt.json').read_text())
    files += [ROOT / receipt['preserved_path']]
    status = json.loads((ROOT / 'exp/probabilistic_verification/scope_compilation_20261101/human_review_status.json').read_text())
    files += [ROOT / p for p in status['response_files']]
    for path in files:
        contents[str(path.relative_to(ROOT))] = path.read_bytes()
    contents['README_REVIEWED_COMPILATION.md'] = (ROOT / 'docs/reviewed_srl_compilation.md').read_bytes()
    contents['SHA256SUMS'] = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n'
        for name, data in sorted(contents.items()) if name != 'SHA256SUMS').encode()
    target = ROOT / 'site/reports/reviewed-compilation/source.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(contents.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 5, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    print('Packaged', len(contents), 'files;', round(target.stat().st_size/1048576, 2), 'MiB')


if __name__ == '__main__':
    main()
