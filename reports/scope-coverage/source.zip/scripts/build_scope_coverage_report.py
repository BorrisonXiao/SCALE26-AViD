#!/usr/bin/env python3
"""Generate the scope/coverage report and its complete saved-output viewer."""
import json
import shutil
from collections import Counter
from html import escape as esc
from pathlib import Path

from build_reviewed_compilation_report import slim

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'exp/probabilistic_verification/scope_coverage_20261105'
TARGETS={
 'T2G_ACMxR_I4_1367':'Landing is now goal content under preparation, within visual depiction. It is not an independent world landing.',
 'TzzhcBIczf_M_2108':'Violation is now content of the investigation, instead of a relative description asserting it of the person.',
 'TFOEIehBwT8Q_483':'The why clause is now question content owned by dialogue. The referent of they remains unresolved.',
 'TMrQshDs8aH0_752':'The small dolly, creaking and while relation are restored. It still requires reference resolution; this is not a complete coreference fix.',
 'TQKCK6-tRaoE_671':'76 is now an identifier property of news, rather than being dropped or treated as a count.',
 'TInVWzp25aIM_18':'The complete source name Bering Straight is retained. The original spelling is preserved.',
}


def load(name):return json.loads((RUN/name).read_text())


def main():
    summary=load('analysis.json')
    before={r['claim_id']:r for r in map(json.loads,(RUN/'baseline.jsonl').read_text().splitlines())}
    after={r['claim_id']:r for r in map(json.loads,(RUN/'results.jsonl').read_text().splitlines())}
    readings={r['claim_id']:r for r in load('fresh_readings.json')['cases']}
    fresh={r['claim_id']:r for r in load('fresh_review.json')['cases']}
    flagged={r['claim_id']:r for r in load('flagged_review.json')['cases']}
    folder=ROOT/'site/reports/scope-coverage';folder.mkdir(parents=True,exist_ok=True)
    index=[];chunks=[]
    for i,(cid,row) in enumerate(after.items()):
        old=before[cid]
        changed=row.get('program_sha256')!=old.get('program_sha256')
        name='cases-'+str(i//100).zfill(2)+'.json'
        index.append(dict(claim_id=cid,text=row['text'],accepted=row['status']=='compiled',
            review=row.get('code')=='coverage_omission',refused='program' not in row,changed=changed,
            target=cid in TARGETS,fresh=cid in fresh,alert_sample=cid in flagged,chunk=name))
        # A failed coverage audit keeps an executable diagnostic candidate.
        # Its actual acceptance status is separate from how the graph renders.
        candidate=dict(row,status='compiled') if 'program' in row else row
        oldnotes=Counter(json.dumps(n,sort_keys=True) for n in old.get('changes',[]));notes=[]
        for n in row.get('changes',[]):
            key=json.dumps(n,sort_keys=True)
            if oldnotes[key]:oldnotes[key]-=1
            else:notes.append(n)
        item=dict(claim_id=cid,before=slim(old),after=slim(candidate) if changed else None,
                  changed=changed,accepted=row['status']=='compiled',coverage=row.get('coverage'),
                  code=row.get('code'),reason=row.get('reason'),notes=notes,diagnosis=TARGETS.get(cid,''),
                  reading=readings.get(cid),fresh=fresh.get(cid),alert_review=flagged.get(cid))
        if i%100==0:chunks.append([])
        chunks[-1].append(item)
    (folder/'index.json').write_text(json.dumps(index,ensure_ascii=False,separators=(',',':'))+'\n')
    for i,chunk in enumerate(chunks):
        (folder/('cases-'+str(i).zfill(2)+'.json')).write_text(json.dumps(chunk,ensure_ascii=False,separators=(',',':'))+'\n')
    for name in ('analysis.json','changed_cases.json','coverage_alerts.json','fresh_review.json','fresh_readings.json',
                 'flagged_review.json','frozen_manifest.json','sample_manifest.json','default_path_preservation.json','tests.xml'):
        shutil.copy2(RUN/name,folder/name)
    shutil.copy2(ROOT/'docs/scope_coverage_compilation.md',folder/'README.md')

    def table(n,title,headers,data):
        return '<div class="table-wrap"><table><caption>Table '+str(n)+'. '+title+'</caption><thead><tr>'+''.join('<th>'+esc(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(v)+'</td>' for v in row)+'</tr>' for row in data)+'</tbody></table></div>'
    def link(cid,text):return '<a href="#examples" data-claim="'+cid+'">'+esc(text)+'</a>'
    body='<section><h2>What changed, and what the counts mean</h2><p>The compiler now keeps three reviewed embedded clauses in their intended contexts and restores selected missing content. <b>Eleven programs change.</b> All six discussed development cases meet their targeted scope/content checks; the dolly pronoun and the dialogue pronoun still need reference resolution.</p>'
    body+=table(1,'Full inventory of 2,375 original claims. The new audit changes acceptance, not whether a candidate can execute.', ['Outcome','Previous compiler','Scope/coverage revision'],[
        ('Executable candidate programs','2,099','2,099'),('Accepted after the current checks','2,099','1,839'),
        ('Coverage alerts requiring review','No new gate','260'),('Earlier parser/compiler refusals','276','276')])
    body+='<p>The same 2,099 claims have executable candidates. The new audit flags 260 because content words are unaccounted for; their saved programs remain visible for diagnosis. A flagged claim is neither false nor necessarily impossible to compile. The remaining 1,839 pass a <b>necessary lexical coverage check</b>, which does not certify correct meaning. All 11 programs previously rated faithful by the user remain unchanged and pass this check.</p></section>'
    body+='<section><h2>1. Keep an event in the context the sentence gives it</h2><p><b>Scope</b> means whether an event is independently asserted, depicted, planned, investigated or discussed. The existing logical form already supports nested propositions. The fix changes attachment before predicates are emitted; it does not change how DeepProbLog multiplies or sums probabilities.</p>'
    body+=table(2,'The three reviewed scope errors and their repairs. Links show the actual saved predicates and structures.', ['Original example','Earlier error','Current structure'],[
        (link('T2G_ACMxR_I4_1367','Video depicts Blue Ghost preparing for landing'),'Landing also appears outside depiction and preparation.','Video depicts → preparation → goal: landing on the moon.'),
        (link('TzzhcBIczf_M_2108','Investigation into Shi Yongxin violating religious precepts'),'Violation is a relative description of the person.','Investigation → investigated content: violation; the reported conclusion stays attributed to the results.'),
        (link('TFOEIehBwT8Q_483','Dialogue of why they are there'),'The presence clause becomes a separate world assertion.','Dialogue → question content: why they are there; no reason or pronoun referent is invented.')])
    body+='<p><b>How the code decides:</b> it uses the governing word, preposition and dependency path. For <em>prepare for</em>, an existing nominal event moves into a purpose proposition; without an event frame, the goal stays a noun phrase and no actor is invented. For <em>investigation into</em>, a subject-plus-gerund construction moves under the investigation. For a question under <em>dialogue/discussion/question</em>, the WH word follows that noun’s dependency path and stays inside question content.</p><p>The lexical entries are deliberately limited. Ordinary <em>prepare dinner</em> remains an argument, and ordinary relatives are not all reinterpreted as allegations. Nested negation and existing source routes remain attached to their event. This is a bounded repair, not a general solution to every embedded clause.</p></section>'
    body+='<section><h2>2. Retain content, then make remaining omissions explicit</h2><p>'+link('TMrQshDs8aH0_752','A small dolly creaks while a man uses it to move large stacks of chairs.')+' previously lost the dolly, its size and its sound. The parser called <em>creaks</em> a plural noun. The repair requires an adjacent singular nominal, a verb-lexicon match and a finite temporal clause; it then restores the grammatical subject and uses the existing frame builder. The sound and use are linked by <em>while</em>; movement remains a purpose. <b>It is still unresolved</b>, with that requirement visible in the output.</p><p>Connected proper-name spans repair '+link('TInVWzp25aIM_18','Bering Straight')+' and four <em>Sagaing Fault</em> cases. An identifier property retains '+link('TQKCK6-tRaoE_671','76 in news 76')+' and 120 in one highway-sign example. An existing complete name must never be shortened. A number already retained in <em>Apollo 11</em> gains no redundant constraint. Original spellings are preserved.</p><p><b>The audit</b> compares source nouns, names, predicates, modifiers and numbers with the values reachable in the final logical form. It allows ordinary inflection and existing numeric operators such as <em>at least</em>. Schema keys, warnings, unused entities and graph IDs cannot hide an omission. Failed cases keep a diagnostic candidate but are refused by the strict entry point with a list of missing tokens.</p>'
    body+=table(3,'Categories among 260 coverage-flagged claims. One claim can occur in several rows.', ['Missing content category','Flagged claims'],[(esc(k),v) for k,v in summary['flagged_claim_categories'].items()])
    body+='<p>Lexical coverage does not check all functional words, role assignments or internal relationships. It can pass a clause hidden inside an opaque string, and it may flag a legitimate paraphrase outside its normalization rules. It must not be reported as a semantic accuracy score.</p></section>'
    body+='<section><h2>Evaluation and limits</h2><p><b>228 regression checks pass.</b> These include all earlier checks, real-case requirements, complete-name and quantity controls, input immutability, and actual native DeepProbLog supported/refuted/unknown tests. The native goal test supplies an absent world landing while varying the scoped goal evidence: verification follows the goal evidence, without requiring an actual world landing. These are constructed evidence checks, not media measurements or training results.</p><p>The compiler was frozen before examining a newly reserved 20-case review. The compiler-author assistant saved intended readings before output inspection. Sampling excludes 150 recorded review sources; all corpus texts had been parsed previously. These are assistant judgments on a nonuniform fresh review sample, not human gold or corpus accuracy.</p>'
    body+=table(4,'All twenty fresh programs and acceptance statuses are unchanged; the new rules show no fresh semantic gain here.', ['Condition','Faithful','Partial','Incorrect','Refused'], [('Previous compiler',9,5,2,4),('Scope/coverage revision',9,5,2,4)])
    body+='<p>Remaining examples include '+link('TzF9M4kZ3Pys_310','timelapse content outside a depiction context')+', '+link('TLO3smKI67PM_595','a personal name mixed with a label')+', '+link('T2EE72iNELEs_209','rocket landing retained only inside a time string')+', and '+link('TInVWzp25aIM_82','storm aftermath classified as a location')+'. Passing lexical coverage does not catch these structural errors. The full program comparison also finds an identifier repair in a source group excluded from development; that street-sign case still has an earlier speech-versus-OCR route error.</p>'
    body+='<p>A separate seeded sample of twelve alerts was inspected after the freeze. Each has an actual omission in the assistant’s assessment (Table 5). This small diagnostic sample does not establish precision for all 260 alerts, and no compiler change followed these reviews.</p>'
    body+=table(5,'Twelve sampled alerts, with the assistant’s reasons and links to retained diagnostic candidates.', ['Claim','Observed omission'],[(link(c['claim_id'],after[c['claim_id']]['text']),esc(c['reason'])) for c in load('flagged_review.json')['cases']])
    body+=table(6,'The earlier 276 parser/compiler refusals remain. Coverage alerts are counted separately in Table 1.', ['Reason','Claims'],[(esc(k.replace('_',' ')),v) for k,v in sorted(summary['refusal_reasons'].items(),key=lambda p:-p[1]) if k!='coverage_omission'])
    body+='<p>The cached full loop took about 28 seconds, excluding upstream parsing and input loading. The default earlier path exactly reproduces all 2,375 saved records after adding the optional logical-form transformation hook. No model calls, GPUs, sentence rewriting, media inference or new relation-training experiment were used. Larger native inference cost remains open; the earlier long-protest timeout was not retested or solved in this round.</p></section>'
    body+='<section id="examples"><h2>Inspect the saved before/after outputs</h2><p>'+link('T2G_ACMxR_I4_1367','Preparation goal')+' · '+link('TzzhcBIczf_M_2108','Investigation content')+' · '+link('TMrQshDs8aH0_752','Restored sound')+' · '+link('TQKCK6-tRaoE_671','Identifier')+'</p><div class="toolbar"><label>Subset<select id="filter"><option value="all">All claims</option><option value="accepted">Accepted after coverage check</option><option value="review">Coverage alerts</option><option value="refused">Earlier parser/compiler refusals</option><option value="changed">Changed programs</option><option value="target">Six development examples</option><option value="fresh">Fresh twenty cases</option><option value="alert_sample">Twelve inspected alerts</option></select></label><label>Search<input id="search" type="search" placeholder="Claim text or ID"></label></div><p id="match-count" role="status">Loading inventory…</p><label>Claim<select id="claim-select"></select></label><div class="toolbar"><button id="previous">Previous</button><button id="next">Next</button></div><h3 id="claim-id"></h3><blockquote id="claim-text"></blockquote><p id="reading"></p><p id="audit-note" class="note"></p><p id="diagnosis"></p><div id="outputs" class="output-grid"></div><p id="notes"></p></section>'
    body+='<section><h2>Next steps and intended goals</h2><ol><li>Repair recurrent alert families such as appositions, numbers and nominal descriptions — recover useful coverage instead of accumulating refusals.</li><li>Handle opaque clauses and source/label boundaries — catch the structural errors that word coverage cannot detect; preserve the current examples as development evidence.</li><li>Resolve local pronouns and profile larger programs — preserve participant identity and establish practical inference cost before media training.</li></ol><p><a href="verification-pipeline.html#next-steps">Current checklist</a> · <a href="reviewed-compilation.html">Previous compiler report</a> · <a href="scope-coverage/README.md">Implementation details</a> · <a href="scope-coverage/source.zip">Source, saved inputs and exact replay</a> · <a href="scope-coverage/analysis.json">Statistics</a> · <a href="scope-coverage/coverage_alerts.json">All 260 alerts</a> · <a href="scope-coverage/fresh_review.json">Fresh judgments</a> · <a href="scope-coverage/tests.xml">Tests</a></p></section>'
    style=(ROOT/'scripts/report_assets/claim_output_view.css').read_text()+'''.container{max-width:1100px}section{margin:32px 0}.table-wrap{overflow:auto;margin:24px 0}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:12px;text-align:left;vertical-align:top;border:1px solid var(--border);min-width:90px}caption{text-align:left;font-weight:600;margin:12px 0}label{display:block;font-weight:600;margin:12px 0}input,select,button{font:inherit;color:var(--text);background:var(--surface);border:1px solid var(--border);border-radius:7px;padding:10px;max-width:100%}select{display:block;width:100%;box-sizing:border-box}button{cursor:pointer}button:disabled{opacity:.5}.toolbar{display:flex;gap:18px;flex-wrap:wrap}.toolbar label{min-width:0}.output-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:22px}.output{min-width:0;border:1px solid var(--border);border-radius:9px;padding:16px}pre{font:12px/1.7 ui-monospace,monospace;white-space:pre-wrap;overflow-wrap:anywhere;max-height:450px;overflow:auto}blockquote,.note{padding:15px;border-left:4px solid var(--accent);background:var(--surface-2);margin:18px 0}.review-note{font-size:13px}#claim-id{overflow-wrap:anywhere}@media(max-width:760px){.output-grid{grid-template-columns:1fr}}'''
    head='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="How the compiler preserves embedded claim scope and detects missing content, with a full2375 census and readable examples."><title>Claim scope and missing content · AViD</title><link rel="stylesheet" href="../assets/site.css"><style>'+style+'</style></head><body><nav class="site-nav" aria-label="Primary navigation"><div class="nav-inner"><a class="brand" href="../index.html">SCALE 2026 · AViD</a><div class="nav-links"><a href="../index.html">Home</a><a href="./" aria-current="page">Reports</a><a href="../proposals/">Proposals</a></div></div></nav><header class="hero"><div class="container"><p class="eyebrow">Compiler follow-up · 5 November 2026</p><h1>Claim scope and missing content</h1><p class="lede">Eleven programs change. The new coverage audit flags 260 candidates for review; passing it does not certify correct meaning.</p><p><a href="#examples">Inspect readable outputs</a> · <a href="verification-pipeline.html#next-steps">Checklist</a> · <a href="./">All reports</a></p></div></header><main class="container prose">'
    page=head+body+'</main><footer class="site-footer"><div class="container">Generated from frozen original inputs and saved outputs; no model inference runs while building this page.</div></footer><script>'+(ROOT/'scripts/report_assets/claim_output_view.js').read_text()+'</script><script>'+(ROOT/'scripts/report_assets/scope_coverage.js').read_text()+'</script></body></html>'
    (ROOT/'site/reports/scope-coverage.html').write_text(page)
    print('Built scope/coverage report and24 data chunks.')


if __name__=='__main__':main()
