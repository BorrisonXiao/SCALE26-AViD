#!/usr/bin/env python3
"""Analyze a returned review; preserve uncertainty and keep refusal ratings separate."""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

from import_claim_review import validate_review

ROOT = Path(__file__).resolve().parents[1]
PREVIOUS = ROOT / 'exp/probabilistic_verification/scope_compilation_20261101'
AGENT = ROOT / 'exp/probabilistic_verification/agent_review_20261101/agent_draft.json'
FIELDS = ['intended_meaning', 'participants_and_relations', 'source_context', 'quantity_and_time', 'ambiguity']
ORDER = {'incorrect': 0, 'partial': 1, 'faithful': 2}


def same_output(a, b):
    def normalized(o):
        form = {k: v for k, v in (o.get('form') or {}).items() if k not in {'version', 'warnings'}}
        return dict(status=o['status'], form=form, predicates=o.get('predicates', []),
                    runtime=o.get('runtime_requirements', []), references=o.get('event_references', []),
                    code=o.get('code'), reason=o.get('reason'))
    return normalized(a) == normalized(b)


def analyze(review, packet, blinding, agent=None):
    validate_review(review, packet)
    mapping = {r['claim_id']: r['conditions'] for r in blinding}
    ids = {c['claim_id'] for c in packet['cases']}
    if len(mapping) != len(blinding) or set(mapping) != ids:
        raise ValueError('A/B mapping membership differs from the packet.')
    if any(set(m) != {'A', 'B'} or set(m.values()) != {'baseline', 'revised'} for m in mapping.values()):
        raise ValueError('Each case needs one baseline and one revised output.')
    if review.get('agent_assisted') and agent and review.get('agent_draft_id') != agent['draft_id']:
        raise ValueError('The agent draft identity differs.')
    agent_cases = {c['claim_id']: c for c in (agent or {}).get('cases', [])}
    counts = {m: dict(compiled=Counter(), refusal=Counter(), unrated=0) for m in ('baseline', 'revised')}
    pairs, rows, failures, disagreements = Counter(), [], [], []
    readings_complete = comparisons_complete = 0
    for answer, case in zip(review['cases'], packet['cases']):
        cid = case['claim_id']
        reading_complete = bool(answer.get('readings_complete'))
        readings_complete += reading_complete
        previous_agent = agent_cases.get(cid)
        edited = [f for f in FIELDS if previous_agent and reading_complete
                  and answer.get(f, '') != previous_agent['readings'][f]]
        by_method = {}
        for letter in ('A', 'B'):
            method = mapping[cid][letter]
            output = case['outputs'][letter]
            rating = answer.get('outputs', {}).get(letter, {})
            key = 'judgment' if output['status'] == 'compiled' else 'refusal_appropriate'
            value = rating.get(key, '') if reading_complete else ''
            by_method[method] = dict(letter=letter, status=output['status'], rating=value,
                reason=rating.get('reason', '') if reading_complete else '', program_sha256=output.get('program_sha256'))
            if value:
                counts[method]['compiled' if key == 'judgment' else 'refusal'][value] += 1
            else:
                counts[method]['unrated'] += 1
            if value and previous_agent and value != previous_agent['agent_assessments'][letter].get(key, ''):
                disagreements.append(dict(claim_id=cid, letter=letter, condition=method,
                    agent=previous_agent['agent_assessments'][letter].get(key, ''), human=value,
                    human_reason=rating.get('reason', '')))
            if value in {'partial', 'incorrect', 'uncertain'} or (key == 'refusal_appropriate' and value in {'no', 'unsure'}):
                failures.append(dict(claim_id=cid, condition=method, letter=letter,
                    judgment_type=key, judgment=value, human_reason=rating.get('reason', ''),
                    intended_reading={f: answer.get(f, '') for f in FIELDS},
                    cause_stage='unassigned', failure_pattern='unassigned',
                    evidence='Inspect the frozen SRL/dependency input and compiled output before assigning a cause.'))
        a, b = by_method['baseline'], by_method['revised']
        both_rated = bool(a['rating'] and b['rating'])
        comparisons_complete += both_rated
        identical_conflict = both_rated and same_output(case['outputs']['A'], case['outputs']['B']) and a['rating'] != b['rating']
        if not both_rated:
            pair = 'incomplete'
        elif identical_conflict:
            pair = 'identical_outputs_disagreement'
        elif a['status'] == b['status'] == 'compiled':
            if a['rating'] not in ORDER or b['rating'] not in ORDER:
                pair = 'uncertain'
            else:
                delta = ORDER[b['rating']] - ORDER[a['rating']]
                pair = 'improved' if delta > 0 else 'regressed' if delta < 0 else 'tied'
        elif a['status'] != 'compiled' and b['status'] != 'compiled':
            pair = 'both_refused'
        else:
            pair = 'newly_compiled' if b['status'] == 'compiled' else 'newly_refused'
        pairs[pair] += 1
        rows.append(dict(claim_id=cid, text=case['text'], reading_complete=reading_complete,
                         edited_reading_fields=edited, by_condition=by_method, comparison=pair,
                         identical_output_rating_conflict=identical_conflict))
    return dict(packet_id=packet['packet_id'], compiler_freeze=packet['compiler_freeze'],
        reviewer_type=review.get('reviewer_type', 'human_review'), agent_assisted=review.get('agent_assisted', False),
        reserved_cases=len(rows), received_readings=readings_complete, complete_comparisons=comparisons_complete,
        counts_by_condition=counts, paired_outcomes=pairs,
        definite_both_compiled_comparisons=sum(pairs[k] for k in ('improved', 'regressed', 'tied')),
        interpretation='Descriptive review of reserved cases. Refusals and uncertainty are separate from definite semantic comparisons. Conflicting ratings of identical outputs require resolution. These cases become development data when used for fixes; no corpus accuracy estimate is implied.',
        cases=rows, human_agent_disagreements=disagreements, failure_ledger=failures)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('review_file', type=Path)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    raw = args.review_file.read_bytes()
    report = analyze(json.loads(raw), json.loads((PREVIOUS / 'human_review_packet.json').read_text()),
                     json.loads((PREVIOUS / 'human_review_blinding.json').read_text()), json.loads(AGENT.read_text()))
    report['review_file_sha256'] = hashlib.sha256(raw).hexdigest()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    target = args.output_dir / 'analysis.json'
    if target.exists() and json.loads(target.read_text()).get('review_file_sha256') != report['review_file_sha256']:
        raise ValueError('Use a separate output directory for a different returned review.')
    target.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    (args.output_dir / 'failure_ledger.json').write_text(json.dumps(report['failure_ledger'], indent=2, ensure_ascii=False) + '\n')
    summary = ['# Returned claim review', '',
        f'Readings received: {report["received_readings"]}/{report["reserved_cases"]}. Complete comparisons: {report["complete_comparisons"]}.', '',
        report['interpretation'], '', '## Counts by compiler version', '']
    for method, counts in report['counts_by_condition'].items():
        summary += [f'- {method}: compiled judgments {dict(counts["compiled"])}; refusal assessments {dict(counts["refusal"])}; unrated {counts["unrated"]}.']
    summary += ['', f'Paired outcomes: {dict(report["paired_outcomes"])}.',
                f'Definite comparisons with both versions compiled: {report["definite_both_compiled_comparisons"]}.', '',
                'Next: inspect the failure ledger, assign upstream parsing or compilation causes from saved evidence, and select at most three recurring patterns before changing code.']
    (args.output_dir / 'summary.md').write_text('\n'.join(summary) + '\n')
    print(json.dumps({k: report[k] for k in ('received_readings', 'complete_comparisons', 'paired_outcomes')}, indent=2))


if __name__ == '__main__':
    main()
