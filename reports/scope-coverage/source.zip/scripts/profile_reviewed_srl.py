#!/usr/bin/env python3
"""Bound native inference on representative cached programs with unknown evidence."""
import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/compiler_revision_20261105'
CASES = ['TgR_u37mCoQ4_1907', 'TFOEIehBwT8Q_473', 'TzF9M4kZ3Pys_218', 'TgPh_fzHTCm4_1507', 'TW4OYA3RN-Hw_1797']


def worker(cid):
    from probabilistic_verification.reviewed_srl import compile_reviewed_srl
    from probabilistic_verification.logic import Evidence, ground
    from probabilistic_verification.balanced_logic import BalancedVerifier
    record = next(r for r in map(json.loads, (RUN / 'inputs.jsonl').read_text().splitlines()) if r['claim_id'] == cid)
    start = time.perf_counter()
    claim, _ = compile_reviewed_srl(record)
    domains = {v.name: [v.name.lower()] for v in claim.variables}
    program = ground(claim, Evidence('native-'+cid, domains, {v: True for v in domains}, {}))
    print(json.dumps(dict(stage='input', seconds=time.perf_counter()-start, observations=len(program.observations))), flush=True)
    start = time.perf_counter()
    prediction = BalancedVerifier([program], learned=False).predict()[0]
    assert prediction['distribution']['unknown'] > 1-1e-9
    print(json.dumps(dict(stage='result', seconds=time.perf_counter()-start, distribution=prediction['distribution'])), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--worker')
    parser.add_argument('--limit', type=int, default=25)
    args = parser.parse_args()
    if args.worker:
        worker(args.worker)
        return
    results = []
    for cid in CASES:
        start = time.perf_counter()
        try:
            result = subprocess.run([sys.executable, __file__, '--worker', cid], cwd=ROOT,
                                    capture_output=True, text=True, timeout=args.limit)
            stdout, error = result.stdout, result.stderr[-1500:]
            status = 'passed' if result.returncode == 0 else 'error'
        except subprocess.TimeoutExpired as e:
            stdout = (e.stdout or b'').decode() if isinstance(e.stdout, bytes) else e.stdout or ''
            status, error = 'timeout', 'Explicit subprocess limit reached.'
        stages = [json.loads(s) for s in stdout.splitlines() if s.startswith('{')]
        results.append(dict(claim_id=cid, status=status, limit_seconds=args.limit,
                            process_seconds=time.perf_counter()-start, stages=stages, error=error))
        (RUN / 'native_profile.json').write_text(json.dumps(results, indent=2) + '\n')
        print(cid, status, flush=True)


if __name__ == '__main__':
    main()
