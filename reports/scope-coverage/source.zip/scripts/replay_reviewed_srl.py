#!/usr/bin/env python3
"""Replay every current and preceding compilation from cached original parses."""
import hashlib
import json
import time
from pathlib import Path

from run_reviewed_srl_census import compile_one as revised
from run_scoped_srl_census import compile_one as preceding

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/compiler_revision_20261105'


def main():
    freeze = json.loads((RUN / 'frozen_manifest.json').read_text())
    for name, digest in freeze['source_sha256'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    records = [json.loads(s) for s in (RUN / 'inputs.jsonl').read_text().splitlines()]
    proof = {}
    for label, filename, compile_one in [('current', 'results.jsonl', revised), ('preceding', 'baseline.jsonl', preceding)]:
        expected = {r['claim_id']: r for r in map(json.loads, (RUN / filename).read_text().splitlines())}
        start = time.perf_counter()
        for record in records:
            # Dataclass tuples are serialized as JSON arrays in the saved census.
            row = json.loads(json.dumps(compile_one(record)))
            assert row == expected[record['claim_id']], (label, record['claim_id'])
        proof[label] = dict(exact_records=len(records), seconds=time.perf_counter()-start)
        print(label, len(records), 'exact outcomes, programs and diagnostics', flush=True)
    (RUN / 'replay_verification.json').write_text(json.dumps(proof, indent=2) + '\n')


if __name__ == '__main__':
    main()
