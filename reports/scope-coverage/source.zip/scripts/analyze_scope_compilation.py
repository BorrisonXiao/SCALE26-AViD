#!/usr/bin/env python3
"""Recompute the full census without inventing human semantic judgments."""
import hashlib,json
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/scope_compilation_20261101'
def read(name):return [json.loads(s) for s in (RUN/name).read_text().splitlines() if s.strip()]
def main():
 frozen=json.loads((RUN/'frozen_manifest.json').read_text())
 for p,h in frozen['source_sha256'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 assert hashlib.sha256((RUN/'sample_manifest.json').read_bytes()).hexdigest()==frozen['sample_sha256']
 assert hashlib.sha256((RUN/'inputs.jsonl').read_bytes()).hexdigest()==frozen['input_sha256']
 assert hashlib.sha256((RUN/'reference_readings_template.json').read_bytes()).hexdigest()==frozen['reference_template_sha256']
 sample=json.loads((RUN/'sample_manifest.json').read_text());rows={m:{r['claim_id']:r for r in read(n)} for m,n in [('baseline','baseline.jsonl'),('revised','results.jsonl')]};conditions={}
 for method,values in rows.items():
  accepted=[r for r in values.values() if r['status']=='compiled'];conditions[method]=dict(total=len(values),compiled=len(accepted),refused=len(values)-len(accepted),kinds=Counter(r['compilation']['metadata']['kind'] for r in accepted),failures=Counter(r['code'] for r in values.values() if r['status']!='compiled'))
 assert all(v['total']==2375 for v in conditions.values())
 transitions=Counter();changed=[]
 for cid in rows['revised']:
  old,new=rows['baseline'][cid],rows['revised'][cid];a=old['status']=='compiled';b=new['status']=='compiled';transitions['both_compiled' if a and b else 'new_only' if b else 'previous_only' if a else 'both_refused']+=1
  if a!=b or old.get('code')!=new.get('code'):changed.append(dict(claim_id=cid,text=new['text'],prior_status=old['status'],status=new['status'],prior_reason=old.get('code'),reason=new.get('code')))
 changes=Counter(n['kind'] for r in rows['revised'].values() for n in r.get('changes',[]))
 unexpected=[dict(claim_id=r['claim_id'],code=r['code'],reason=r.get('reason')) for r in rows['revised'].values() if r.get('code') in {'TypeError','KeyError','ValueError','AttributeError','IndexError','RuntimeError','RecursionError'}]
 human=json.loads((RUN/'human_review_status.json').read_text()) if (RUN/'human_review_status.json').exists() else dict(status='awaiting_human_review',reserved_claims=20,reference_readings_received=0,comparisons_received=0)
 summary=dict(conditions=conditions,transitions=transitions,changes=changes,unexpected_exceptions=unexpected,human_review=human,review_protocol=sample['protocol'],elapsed_seconds=json.loads((RUN/'results.summary.json').read_text())['elapsed_seconds'],interpretation='Compilation counts and constructed logical checks are measured. Human semantic correctness is not measured until actual human readings/ratings are returned. No assistant or model judgments are substituted for that reference set.')
 (RUN/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');(RUN/'status_changes.json').write_text(json.dumps(changed,indent=2,ensure_ascii=False)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
