#!/usr/bin/env python3
"""Bounded native comparison of expression shape on the sufficiency example."""
import argparse,importlib.util,json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'exp/probabilistic_verification/scope_compilation_20261101'
def emit(stage,started,**data):print(json.dumps(dict(stage=stage,seconds=time.perf_counter()-started,**data)),flush=True)
def worker(mode):
 start=time.perf_counter();spec=importlib.util.spec_from_file_location('scope_tests',ROOT/'tests/test_scoped_srl.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 program=module.stipulated_program('TQEmEycTI0RQ_880',lambda a:'unknown' if a.predicate=='proposition' and 'sufficiency' in a.arguments else 'supported');emit('input',start,observations=len(program.observations))
 from probabilistic_verification.direct_backend import DirectVerifier
 from probabilistic_verification.balanced_logic import BalancedVerifier
 from deepproblog.arithmetic_circuit import ArithmeticCircuit
 from problog.formula import LogicFormula
 start=time.perf_counter();v=(BalancedVerifier if mode=='balanced' else DirectVerifier)([program],learned=False);emit('initialization',start)
 results={}
 for state in ['supported','refuted','unknown']:
  query=v.query(program.claim_id,state);start=time.perf_counter();g=v.model.solver.engine.ground(query,label=LogicFormula.LABEL_QUERY);emit(state+'_ground',start,nodes=len(g))
  start=time.perf_counter();ac=ArithmeticCircuit(g,v.model.solver.semiring);emit(state+'_compile',start)
  start=time.perf_counter();result=ac.evaluate(v.model,query.substitution);value=float(result.result.get(query.query,0.));results[state]=value;emit(state+'_evaluate',start,probability=value)
 assert results['unknown']>1-1e-9 and abs(sum(results.values())-1)<1e-9
 print(json.dumps(dict(stage='result',distribution=results)),flush=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--worker',choices=['balanced','previous']);p.add_argument('--limit',type=int,default=30);args=p.parse_args()
 if args.worker:worker(args.worker);return
 outputs=[]
 for mode in ['previous','balanced']:
  begun=time.perf_counter()
  try:
   r=subprocess.run([sys.executable,__file__,'--worker',mode],cwd=ROOT,capture_output=True,text=True,timeout=args.limit);stdout=r.stdout;status='passed' if r.returncode==0 else 'error';error=r.stderr[-2000:]
  except subprocess.TimeoutExpired as e:stdout=(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else e.stdout or '';status='timeout';error='Explicit subprocess limit reached.'
  stages=[json.loads(s) for s in stdout.splitlines() if s.startswith('{')];outputs.append(dict(mode=mode,status=status,limit_seconds=args.limit,wall_seconds=time.perf_counter()-begun,stages=stages,error=error))
  (RUN/'native_profile.json').write_text(json.dumps(outputs,indent=2)+'\n');print(mode,status,flush=True)
if __name__=='__main__':main()
