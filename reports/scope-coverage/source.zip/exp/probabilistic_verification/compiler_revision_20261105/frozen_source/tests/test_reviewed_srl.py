"""Human-reading requirements plus controls for scope and participant binding."""
import copy
import itertools
import json
from pathlib import Path

import pytest

from probabilistic_verification.balanced_logic import BalancedVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.logical_form import LogicalFormError
from probabilistic_verification.reviewed_srl import compile_reviewed_srl
from probabilistic_verification.scoped_srl import compile_scoped_srl
from test_scoped_srl import constructed_record

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / 'exp/probabilistic_verification/scope_compilation_20261101'
RECORDS = {r['claim_id']: r for r in map(json.loads, (OLD / 'inputs.jsonl').read_text().splitlines())}


def case(cid):
    return compile_reviewed_srl(RECORDS[cid])[0]


def test_whole_quote_retains_time_and_does_not_assert_a_fire_event():
    claim = case('TgR_u37mCoQ4_1907')
    show = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'show')
    assert show['arguments']['ARG1'] == dict(kind='verbatim_text', value='Actual fire spread, four hours after ignition')
    assert show['scope'] != 'world' and show['route'] == 'ocr_assertion'
    assert not any(e['predicate'] in {'spread', 'ignite'} for e in claim.metadata['events'].values())
    assert not any('four hours' in p['value'] for e in claim.metadata['entities'].values() for p in e.get('properties', []) if p['role'] == 'name')


def test_spatial_adjunct_retains_named_person_and_degree_on_the_landing():
    claim = case('TLO3smKI67PM_554')
    event = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'land')
    entities = {e['id']: e for e in claim.metadata['entities'].values()}
    target = entities[event['arguments']['obl:next_to']]
    assert target['text'] == 'fan'
    assert dict(role='name', value='Karen') in target['properties']
    assert dict(role='mod', value='Phillies') in target['properties']
    assert dict(role='degree:obl:next_to', value='right') in event['properties']
    assert any(e['text'] == 'stands' for e in entities.values())


def test_topic_is_on_report_and_background_remains_a_separate_relation():
    claim = case('TzF9M4kZ3Pys_240')
    entities = {e['id']: e for e in claim.metadata['entities'].values()}
    report = next(e for e in entities.values() if e['text'] == 'report')
    background = next(e for e in entities.values() if e['text'] == 'background')
    assert {r['role'] for r in report['relations']} >= {'in', 'about'}
    assert not any(r['role'] == 'about' for r in background.get('relations', []))
    assert not any(s.get('route') in {'audio_event', 'visual_depiction'} for s in claim.metadata['scopes'].values())


def test_both_coordinated_activities_share_the_explicit_participant():
    claim = case('TQKCK6-tRaoE_669')
    events = {e['predicate']: e for e in claim.metadata['events'].values()}
    assert set(events) == {'sing', 'dance'}
    assert events['sing']['arguments']['nsubj'] == events['dance']['arguments']['nsubj']
    assert all(t['aspect'] == 'progressive' for t in claim.metadata['temporal'].values())


def test_controller_is_protesters_and_attempt_is_not_actual_storming():
    claim = case('TW4OYA3RN-Hw_1797')
    events = {e['predicate']: e for e in claim.metadata['events'].values()}
    assert {'lift', 'intensify', 'fire', 'attempt', 'storm'} <= set(events)
    actor = events['attempt']['arguments']['ARG0']
    assert events['storm']['arguments']['nsubj'] == actor
    scope = events['storm']['scope']
    assert scope != 'world' and claim.metadata['scopes'][scope]['kind'] == 'purpose'
    assert any(e['text'] == 'parliament' for e in claim.metadata['entities'].values())


def test_reciprocal_is_an_argument_of_the_same_event_not_an_other_entity():
    claim = case('TFOEIehBwT8Q_473')
    event = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'face')
    assert event['arguments']['ARG1'] == dict(kind='reciprocal', value='each other')
    assert 'ARGM-MNR' not in event['arguments'] and 'obl:in' in event['arguments']
    assert not any(e['text'] == 'other' for e in claim.metadata['entities'].values())
    group = next(e for e in claim.metadata['entities'].values() if e['id'] == event['arguments']['ARG0'])
    assert group['type'] == 'group' and len(group['relations']) == 2


def test_nominal_gloss_has_one_described_entity_and_correct_creation_theme():
    claim = case('TzF9M4kZ3Pys_218')
    form = claim.metadata['logical_form']
    assert claim.metadata['kind'] == 'mention'
    entity = next(e for e in form['entities'] if e['id'] == form['formula']['ref'])
    assert entity['text'] == 'haboob'
    assert {p['value'] for p in entity['properties']} >= {'wall', 'intense', 'massive'}
    created = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'create')
    assert created['arguments']['ARG1'] == entity['id']
    assert not any(e['text'].startswith('A haboob, or') for e in form['entities'])
    assert 'explanatory appositive reading of comma-or nominal gloss' in claim.metadata['runtime_requirements']


def test_unresolved_nominal_or_remains_one_exact_noun_phrase_argument():
    claim = case('TgPh_fzHTCm4_1507')
    event = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'indicate')
    assert event['arguments']['ARG1'] == dict(kind='noun_phrase', value='a ridge or high-pressure anti-cyclone over the region')
    assert claim.metadata['uses_phrase_arguments']
    assert claim.metadata['logical_form']['formula']['op'] != 'or'


def test_nominal_activities_are_not_promoted_out_of_an_enjoyment_argument():
    record = constructed_record('People enjoy singing and dancing.', [
        ('People', 'person', 'NOUN', 2, 'nsubj'), ('enjoy', 'enjoy', 'VERB', 0, 'root'),
        ('singing', 'singing', 'NOUN', 2, 'obj'), ('and', 'and', 'CCONJ', 5, 'cc'),
        ('dancing', 'dancing', 'NOUN', 3, 'conj'), ('.', '.', 'PUNCT', 2, 'punct')], [])
    claim, _ = compile_reviewed_srl(record)
    assert {e['predicate'] for e in claim.metadata['events'].values()} == {'enjoy'}


def test_plain_binary_or_is_not_reinterpreted_as_an_apposition():
    record = RECORDS['Txf2EdqOg1SQ_2295']
    before, _ = compile_scoped_srl(record)
    after, notes = compile_reviewed_srl(record)
    assert after.expression == before.expression
    assert after.atoms == before.atoms
    assert not any(n['kind'] == 'nominal_apposition' for n in notes)


def test_original_record_is_immutable():
    record = copy.deepcopy(RECORDS['TQKCK6-tRaoE_669'])
    original = copy.deepcopy(record)
    compile_reviewed_srl(record)
    assert record == original


def test_proper_name_sequence_does_not_become_a_false_alias():
    record = RECORDS['TQEmEycTI0RQ_861']
    before, _ = compile_scoped_srl(record)
    after, _ = compile_reviewed_srl(record)
    assert after.atoms == before.atoms
    assert not any(p['role'] == 'name' and p['value'] == 'Canada'
                   for e in after.metadata['entities'].values() for p in e.get('properties', []))


def test_existing_spatial_literal_is_replaced_without_a_second_copy_of_the_relation():
    claim = case('T3HTSBW42QaY_783')
    event = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'station')
    assert isinstance(event['arguments']['ARG2'], str)
    assert 'obl:next_to' not in event['arguments']
    assert dict(role='preposition:ARG2', value='next to') in event['properties']


@pytest.mark.parametrize('cid', ['TFgw4IaR9R8s_1677', 'Txf2EdqOg1SQ_2343', 'TFgw4IaR9R8s_1662'])
def test_safety_guards_do_not_add_a_tool_actor_or_unlicensed_person_names(cid):
    before, _ = compile_scoped_srl(RECORDS[cid])
    after, _ = compile_reviewed_srl(RECORDS[cid])
    assert after.atoms == before.atoms
    assert after.expression == before.expression


@pytest.mark.parametrize('state', ['supported', 'refuted', 'unknown'])
def test_native_reciprocal_evidence_is_required_for_the_exact_event_group_tuple(state):
    claim = case('TFOEIehBwT8Q_473')
    domains = {v.name: [v.name.lower()] for v in claim.variables}
    observations = {}
    for values in itertools.product(*(domains[v.name] for v in claim.variables)):
        assignment = dict(zip(domains, values))
        for atom in claim.atoms:
            required = state if any('"kind":"reciprocal"' in a for a in atom.arguments) else 'supported'
            key = canonical_key('constructed-reciprocal', atom, assignment, 'visual_depiction')
            observations[key] = Observation(key, tuple(float(s == required) for s in ('supported', 'refuted', 'unknown')),
                                            False, atom.text, {'source': 'stipulated test, not perception output'})
    program = ground(claim, Evidence('constructed-reciprocal', domains, {v: True for v in domains}, observations))
    assert BalancedVerifier([program], learned=False).predict()[0]['distribution'][state] > 1-1e-9


def test_single_named_subject_does_not_silently_become_a_reciprocal_group():
    record = constructed_record('Alice faces each other.', [
        ('Alice', 'Alice', 'PROPN', 2, 'nsubj'), ('faces', 'face', 'VERB', 0, 'root'),
        ('each', 'each', 'DET', 2, 'obj'), ('other', 'other', 'ADJ', 3, 'fixed'),
        ('.', '.', 'PUNCT', 2, 'punct')], [(1, [('ARG0', 0, 0), ('ARG1', 2, 3)])])
    with pytest.raises(LogicalFormError, match='group'):
        compile_reviewed_srl(record)
