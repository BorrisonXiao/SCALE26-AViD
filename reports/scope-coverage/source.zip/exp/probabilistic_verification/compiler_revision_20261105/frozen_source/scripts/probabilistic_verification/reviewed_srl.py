"""One deterministic SRL/dependency pass, revised from the returned human review.

Keep the original sentence and annotations immutable. Refine a copy using explicit
syntax and a verb lexicon, then compile through the existing scoped compiler.
Numbered roles are inherited, not guessed. Difficult noun phrases may stay whole;
that choice is recorded rather than presented as an internal semantic analysis.
"""
from __future__ import annotations

import copy
import re
from dataclasses import replace
from functools import lru_cache

from .compilation_followup import walk_events
from .logical_form import LogicalFormError, bind_variables
from .logical_form_v2 import ScopedCompiler
from .representation import Atom, Expression as E
from .scoped_srl import EXTRA_KINDS, SourceSyntax, quoted_spans, scoped_srl_form
from .semantic_srl import SUBJECT_CONTROL, inherit_routes

NOMINAL = {'NOUN', 'PROPN', 'PRON'}
SOURCE_NOUNS = {'report', 'story', 'article', 'discussion', 'programme', 'program', 'broadcast', 'news', 'text'}
POSITION_NOUNS = {'background', 'foreground'}
QUOTE_PREDICATES = {'say', 'tell', 'state', 'report', 'read', 'show', 'display', 'depict', 'label', 'caption'}


@lru_cache(maxsize=2048)
def participle_lemma(word):
    from nltk.corpus import wordnet
    if not word.casefold().endswith('ing'):
        return None
    lemma = wordnet.morphy(word.casefold(), wordnet.VERB)
    return lemma if lemma and wordnet.synsets(lemma, pos=wordnet.VERB) else None


def _frames(syntax):
    return {syntax.frame_head(f)['id']: f for f in syntax.record['srl']['frames']
            if f.get('args') and syntax.frame_head(f)}


def _argument_head(syntax, arg):
    tokens = syntax.alignment.selected(arg['start'], arg['end'])
    ids = {t['id'] for t in tokens}
    heads = [t for t in tokens if t['head'] not in ids and t['upos'] not in {'ADP', 'DET', 'PUNCT', 'PART'}]
    return heads[0] if len(heads) == 1 else None


def refine_annotations(record):
    r = copy.deepcopy(record)
    s = SourceSyntax(r)
    notes, quotes, coarse, appositions = [], [], [], []
    frames = _frames(s)
    quote_ranges = quoted_spans(r['text'])
    def quoted(token):
        return any(lo <= token['start_char'] < hi for lo, hi, _ in quote_ranges)

    # A nominal POS error in a verbal coordination need not lose the second
    # activity. Require a verbal governor, one shared subject and a verb-lexicon
    # entry; ordinary coordinated objects and determiner-led nouns do not qualify.
    for token in s.tokens:
        if quoted(token):
            continue
        parent = s.by_id.get(token['head'])
        if token['upos'] != 'NOUN' or token['deprel'] != 'conj' or not parent or parent['upos'] != 'VERB':
            continue
        if not any(t['deprel'].startswith('nsubj') for t in s.children[parent['id']]):
            continue
        if any(t['deprel'] in {'det', 'amod', 'nummod', 'case'} for t in s.children[token['id']]):
            continue
        lemma = participle_lemma(token['text'])
        if lemma:
            token.update(upos='VERB', lemma=lemma)
            notes.append(dict(kind='verbal_coordination', token=token['id'], predicate=lemma,
                              basis='verbal governor, shared subject, participial form and verb lexicon'))

    # Subject control in a relative clause can be explicit in SRL even though
    # basic dependencies omit the subject of the parent participle.
    for token in s.tokens:
        if quoted(token):
            continue
        parent = s.by_id.get(token['head'])
        pf = frames.get(token['head'])
        if token['upos'] != 'VERB' or token['deprel'] != 'xcomp' or not parent or not pf:
            continue
        if parent['lemma'].lower() not in SUBJECT_CONTROL:
            continue
        if not (parent['text'].casefold().endswith('ing') or 'VerbForm=Part' in (parent.get('feats') or '')):
            continue  # An infinitival tool-purpose clause need not have the tool as its actor.
        if any(t['deprel'].startswith('nsubj') for t in s.children[token['id']]):
            continue
        f = frames.get(token['id'])
        if f and any(a['role'] in {'ARG0', 'nsubj', 'nsubj:pass'} for a in f['args']):
            continue
        actors = [a for a in pf['args'] if a['role'] == 'ARG0']
        if len(actors) != 1 or parent['deprel'] not in {'acl', 'acl:relcl'}:
            continue
        actor = _argument_head(s, actors[0])
        if not actor or actor['id'] != parent['head']:
            continue
        if f is None:
            f = dict(verb=token['text'], verb_span=[s.alignment.word_index(token)] * 2, args=[])
            for child in s.children[token['id']]:
                if child['deprel'] in {'obj', 'iobj', 'obl', 'obl:agent'}:
                    f['args'].append(s.argument(child['deprel'], s.subtree(child['id'])))
            r['srl']['frames'].append(f)
            frames[token['id']] = f
        f['args'].insert(0, dict(actors[0], role='nsubj'))
        notes.append(dict(kind='explicit_controller', event='e'+str(token['id']),
                          participant='x'+str(actor['id']), basis='relative owner and parent SRL actor agree'))

    # Keep the topic on the content noun when a background/foreground modifier
    # intervenes. Do not infer a visual or audio route from the word background.
    for token in s.tokens:
        if quoted(token):
            continue
        parent = s.by_id.get(token['head'])
        owner = s.by_id.get(parent['head']) if parent else None
        if (token['deprel'].startswith('nmod') and parent and owner
                and parent['lemma'].lower() in POSITION_NOUNS and parent['deprel'].startswith('nmod')
                and owner['lemma'].lower() in SOURCE_NOUNS
                and any(t['deprel'] == 'case' and t['lemma'].lower() == 'about' for t in s.children[token['id']])):
            token['head'] = owner['id']
            notes.append(dict(kind='topic_attachment', topic=token['id'], previous=parent['id'], owner=owner['id']))

    # An explanatory 'or' in a nominal gloss must not create a two-member AND
    # group. This is a declared appositive reading, limited to descriptive nominal
    # fragments with a comma and a modified common-noun gloss.
    for token in s.tokens:
        if quoted(token) or token['deprel'] != 'cc' or token['lemma'].lower() != 'or':
            continue
        member = s.by_id[token['head']]
        head = s.by_id.get(member['head'])
        comma = any(t['text'] == ',' and head and head['id'] < t['id'] < token['id'] for t in s.tokens)
        descriptive = any(t['deprel'] in {'amod', 'acl', 'acl:relcl'} for t in s.children[member['id']])
        if (head and head['head'] == 0 and head['upos'] == member['upos'] == 'NOUN'
                and member['deprel'] == 'conj' and comma and descriptive):
            token['deprel'] = 'discourse'
            appositions.append(dict(head='x'+str(head['id']), description='x'+str(member['id']), group='g'+str(head['id'])))
            notes.append(dict(kind='nominal_apposition', head=head['id'], description=member['id'],
                              reading='comma-or nominal gloss interpreted as an explanatory apposition'))

    # If syntax cannot give an OR phrase one nominal head, retain the complete
    # original phrase in its existing role. Do not turn its words into AND facts.
    for token in s.tokens:
        if quoted(token) or token['deprel'] != 'cc' or token['lemma'].lower() != 'or':
            continue
        member = s.by_id[token['head']]
        if member['upos'] not in NOMINAL:
            continue
        matches = []
        for fid, frame in frames.items():
            for arg in frame['args']:
                ts = s.alignment.selected(arg['start'], arg['end'])
                ids = {t['id'] for t in ts}
                if token['id'] in ids and not any(t['upos'] in {'VERB', 'AUX'} for t in ts) and _argument_head(s, arg) is None:
                    matches.append((fid, arg, ts))
        if len(matches) == 1:
            fid, arg, ts = matches[0]
            coarse.append(dict(event='e'+str(fid), role=arg['role'], text=s.surface({t['id'] for t in ts})))
            token['deprel'] = 'discourse'
            notes.append(dict(kind='coarse_noun_phrase', event='e'+str(fid), role=arg['role'],
                              text=coarse[-1]['text'], basis='unresolved nominal head; original phrase retained'))

    # Exact quotation arguments of display/source verbs retain the full quote,
    # including appositions and time expressions omitted by nominal construction.
    for lo, hi, words in quoted_spans(r['text']):
        inside = {t['id'] for t in s.tokens if lo <= t['start_char'] and t['end_char'] <= hi}
        owners = []
        for fid, frame in frames.items():
            if s.by_id[fid]['lemma'].lower() not in QUOTE_PREDICATES or fid in inside:
                continue
            for arg in frame['args']:
                ts = s.alignment.selected(arg['start'], arg['end'])
                if not any(t['id'] in inside for t in ts):
                    continue
                if any(t['id'] not in inside and t['upos'] != 'PUNCT' for t in ts):
                    continue
                owners.append((fid, arg['role']))
        if len(owners) != 1:
            continue
        fid, role = owners[0]
        route, current, visited = 'unspecified', fid, set()
        while current and current not in visited:
            visited.add(current)
            frame = frames.get(current)
            if frame:
                source = ' '.join(a['text'] for a in frame['args'] if a['role'] in {'ARG0', 'nsubj'})
                if re.search(r'\b(text|caption|sign|screen|banner)\b', source, re.I):
                    route = 'ocr_assertion'
                    break
                if s.by_id[current]['lemma'].lower() in {'say', 'tell', 'state', 'shout', 'chant'}:
                    route = 'speech_assertion'
                    break
            current = s.by_id[current]['head']
        quotes.append(dict(event='e'+str(fid), role=role, text=words, route=route))
        r['srl']['frames'] = [f for f in r['srl']['frames'] if not (s.frame_head(f) and s.frame_head(f)['id'] in inside)]
        for tid in inside:
            s.by_id[tid]['upos'] = 'PROPN'
        notes.append(dict(kind='exact_quotation', event='e'+str(fid), role=role, text=words, route=route))
    return r, notes, quotes, coarse, appositions


def _replace_references(value, aliases):
    if isinstance(value, dict):
        for key, item in list(value.items()):
            if key in {'id', 'text', 'value', 'anchor', 'predicate'}:
                continue
            if isinstance(item, str) and item in aliases:
                value[key] = aliases[item]
            else:
                _replace_references(item, aliases)
    elif isinstance(value, list):
        for item in value:
            _replace_references(item, aliases)


def _prune_entities(form):
    entities = {e['id']: e for e in form['entities']}
    used = set()
    def visit(value):
        if isinstance(value, str) and value in entities and value not in used:
            used.add(value)
            visit(entities[value])
        elif isinstance(value, dict):
            for key, item in value.items():
                if key not in {'id', 'text', 'value', 'anchor', 'predicate'}:
                    visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)
    visit(form['formula'])
    form['entities'] = [e for e in form['entities'] if e['id'] in used]


def reviewed_srl_form(record):
    r, notes, quotes, coarse, appositions = refine_annotations(record)
    form, previous = scoped_srl_form(r)
    notes = previous + notes
    syntax = SourceSyntax(r)
    entities = {e['id']: e for e in form['entities']}

    for apposition in appositions:
        head, description, group = (apposition[k] for k in ('head', 'description', 'group'))
        if not all(e in entities for e in (head, description, group)):
            raise LogicalFormError('apposition', 'The nominal gloss lost its explicit head or description.')
        target, source = entities[head], entities[description]
        target.setdefault('properties', []).append(dict(role='type', value=source['text']))
        for key in ('properties', 'relations', 'propositions'):
            target.setdefault(key, []).extend(copy.deepcopy(source.get(key, [])))
        _replace_references(form, {group: head, description: head})
        form['entities'] = [e for e in form['entities'] if e['id'] not in {group, description}]
        form['requires_context'] = True
    for item in quotes + coarse:
        event = next((e for e in walk_events(form) if e['id'] == item['event']), None)
        if event is None:
            raise LogicalFormError('argument_content', 'A retained phrase lost its governing event.')
        event['arguments'][item['role']] = dict(kind='verbatim_text' if item in quotes else 'noun_phrase', value=item['text'])
        event['propositions'] = [p for p in event.get('propositions', []) if p['role'] != item['role']]
        if item in quotes and item['route'] != 'unspecified':
            event['properties'] = [p for p in event.get('properties', []) if p['role'] != 'source_route']
            event['properties'].append(dict(role='source_route', value=item['route']))

    # Build a missing nonclausal nominal argument with the same graph builder,
    # retaining its original word offsets and adding simple proper-name apposition.
    def nominal(tid):
        eid = 'x'+str(tid)
        if eid in {e['id'] for e in form['entities']}:
            return eid
        ids = syntax.subtree(tid)
        if any(syntax.by_id[i]['upos'] in {'VERB', 'AUX'} for i in ids):
            raise LogicalFormError('modifier_scope', 'A recovered nominal modifier contains an unresolved clause.')
        mini = copy.deepcopy(r)
        mini['tokens'] = [t for t in mini['tokens'] if t['id'] in ids]
        next(t for t in mini['tokens'] if t['id'] == tid)['head'] = 0
        mini['srl'] = dict(words=[t['text'] for t in mini['tokens']], frames=[])
        from .srl_graph import srl_graph_form
        addition = srl_graph_form(mini, semantic_arguments=True)
        existing = {e['id'] for e in form['entities']}
        form['entities'].extend(e for e in addition['entities'] if e['id'] not in existing)
        return addition['formula']['ref']

    for event in list(walk_events(form)):
        token = syntax.by_id.get(int(event['id'][1:])) if re.fullmatch(r'e\d+', event['id']) else None
        if token is None:
            continue
        # Recover a syntactically explicit next-to adjunct as a relation to its
        # target, rather than inventing an entity for the word 'next'.
        for child in syntax.children[token['id']]:
            if child['lemma'].lower() != 'next' or child['deprel'] != 'advmod':
                continue
            targets = [t for t in syntax.children[child['id']] if t['deprel'].startswith('obl') and
                       any(u['deprel'] == 'case' and u['lemma'].lower() == 'to' for u in syntax.children[t['id']])]
            if len(targets) != 1 or targets[0]['upos'] not in NOMINAL:
                continue
            target = nominal(targets[0]['id'])
            phrase = ' '.join(syntax.surface(syntax.subtree(child['id'])).casefold().split())
            existing = [role for role, value in event['arguments'].items() if isinstance(value, dict)
                        and value.get('kind') in {'text', 'manner'}
                        and ' '.join(str(value.get('value', '')).casefold().split()) == phrase]
            role = existing[0] if len(existing) == 1 else 'obl:next_to'
            event['arguments'][role] = target
            if existing:
                event.setdefault('properties', []).append(dict(role='preposition:'+role, value='next to'))
            for modifier in syntax.children[child['id']]:
                if modifier['deprel'] == 'advmod':
                    event.setdefault('properties', []).append(dict(role='degree:'+role, value=modifier['text']))
            notes.append(dict(kind='spatial_adjunct', event=event['id'], role=role, target=targets[0]['id']))
        # Numbered reciprocity is a typed argument, interpreted with the group
        # supplied in the other role of this very same event. No free 'other'
        # entity is introduced, and two unrelated events cannot satisfy it.
        frame = _frames(syntax).get(token['id'])
        if frame:
            for argument in frame['args']:
                ts = syntax.alignment.selected(argument['start'], argument['end'])
                words = ' '.join(t['text'].casefold() for t in ts)
                if words not in {'each other', 'one another'}:
                    continue
                others = [e for e in form['entities'] if e['id'] in {
                    value for role, value in event['arguments'].items()
                    if role != argument['role'] and isinstance(value, str)}]
                if not any(e.get('type') in {'group', 'pronoun'} for e in others):
                    raise LogicalFormError('reciprocal_group', 'A reciprocal target needs a group or a contextual plural participant.')
                event['arguments'][argument['role']] = dict(kind='reciprocal', value=words)
                notes.append(dict(kind='reciprocal', event=event['id'], role=argument['role'], source=words))
            # Preserve a nominal prepositional adjunct without trusting an
            # unsupported manner classification; its grammatical relation stays.
            for argument in frame['args']:
                if argument['role'] != 'ARGM-MNR':
                    continue
                head = _argument_head(syntax, argument)
                if not head or head['upos'] != 'PROPN':
                    continue
                markers = [t for t in syntax.children[head['id']] if t['deprel'] == 'case']
                if not markers or 'ARGM-MNR' not in event['arguments']:
                    continue
                role = 'obl:'+('_'.join(t['text'].casefold() for t in markers))
                if role in event['arguments']:
                    continue
                event['arguments'][role] = event['arguments'].pop('ARGM-MNR')
                for prop in event.get('properties', []):
                    if prop['role'] == 'preposition:ARGM-MNR':
                        prop['role'] = 'preposition:'+role
                notes.append(dict(kind='grammatical_adjunct', event=event['id'], previous='ARGM-MNR', role=role))

    # A proper-name apposition supplies the name of the same nominal candidate.
    for entity in form['entities']:
        tid = int(entity['id'][1:]) if re.fullmatch(r'x\d+', entity['id']) else None
        if tid is None or syntax.by_id[tid]['upos'] != 'NOUN':
            continue
        for child in syntax.children.get(tid, []):
            if child['deprel'] != 'appos' or child['upos'] != 'PROPN':
                continue
            if any(lo <= child['start_char'] < hi for lo, hi, _ in quoted_spans(r['text'])):
                continue
            ids = syntax.subtree(child['id'])
            if not all(syntax.by_id[i]['upos'] in {'PROPN', 'PUNCT'} or syntax.by_id[i]['deprel'].startswith('flat') for i in ids):
                continue
            content = {i for i in ids if syntax.by_id[i]['upos'] != 'PUNCT'}
            if not content:
                continue
            first = min(syntax.by_id[i]['start_char'] for i in content)
            last = max(syntax.by_id[i]['end_char'] for i in content)
            between = [t for t in syntax.tokens if syntax.by_id[tid]['end_char'] <= t['start_char'] < first]
            if any(t['upos'] != 'PUNCT' or t['text'] == ':' for t in between):
                continue
            # A following subjectless relative can make this proper noun the
            # clause's actor, rather than an alternative name for the noun head.
            if any(t['deprel'] in {'acl', 'acl:relcl'} and t['start_char'] >= last
                   and not any(u['deprel'].startswith('nsubj') for u in syntax.children[t['id']])
                   for t in syntax.children.get(tid, [])):
                continue
            name = r['text'][first:last]
            prop = dict(role='name', value=name)
            if prop not in entity.setdefault('properties', []):
                entity['properties'].append(prop)
                notes.append(dict(kind='proper_name_apposition', entity=entity['id'], name=name))
    _prune_entities(form)
    inherit_routes(form)
    return r, form, notes


def compile_reviewed_srl(record):
    prepared, form, notes = reviewed_srl_form(record)
    claim = ScopedCompiler().compile(record['claim_id'], record['text'], prepared['tokens'], form,
                                     additional_proposition_kinds=EXTRA_KINDS)
    atoms, metadata, expression = list(claim.atoms), copy.deepcopy(claim.metadata), claim.expression
    additions = {}
    for note in notes:
        if note['kind'] != 'duration':
            continue
        for event_id, event in metadata['events'].items():
            if event['id'] != note['event'] and not event['id'].startswith(note['event']+'_alternative'):
                continue
            atom = next(a for a in atoms if a.predicate == event['predicate'] and a.arguments[0] == event_id)
            args = (event_id, note['role'], note['operator'], note['value'], note['unit'], note['reference'])
            extra = Atom('a'+str(len(atoms)+1), 'duration', args+atom.arguments[atom.arguments.index('scope'):],
                         'duration', (), note['source'], (), False)
            atoms.append(extra)
            metadata['allowed_routes'][extra.id] = metadata['allowed_routes'][atom.id]
            additions.setdefault(atom.id, []).append(E.atom(extra.id))
    def extend(expr):
        if expr.op == 'atom' and expr.atom_id in additions:
            return E.combine('and', [expr, *additions[expr.atom_id]])
        return replace(expr, children=tuple(extend(c) for c in expr.children))
    expression = extend(expression)
    aliases, links = {}, []
    for note in notes:
        if note['kind'] != 'event_reference':
            continue
        nominal = next((v for v, e in metadata['entities'].items() if e['id'] == note['mention']), None)
        events = [v for v, e in metadata['events'].items() if e['id'] == note['event']]
        if nominal and len(events) == 1:
            aliases[nominal] = events[0]
            links.append(dict(mention=note['mention'], event=note['event'], variable=events[0]))
    variables = claim.variables
    if aliases:
        affected = set(aliases) | set(aliases.values())
        atoms = [replace(a, arguments=tuple(aliases.get(x, x) for x in a.arguments)) for a in atoms]
        def unbind(expr):
            children = tuple(unbind(c) for c in expr.children)
            remaining = tuple(v for v in expr.variables if v not in affected)
            return children[0] if expr.op == 'exists' and not remaining else replace(expr, children=children, variables=remaining)
        variables = tuple(v for v in variables if v.name not in aliases)
        expression = bind_variables(unbind(expression), atoms, [v for v in variables if v.name in affected])
        for old, new in aliases.items():
            metadata['entities'][new] = metadata['entities'].pop(old)
    requirements = {'sufficiency': 'contextual sufficiency threshold and goal support',
                    'implicit_subject': 'implicit embedded subject',
                    'label_modifier': 'review the following label-modifier attachment',
                    'reciprocal': 'reciprocal argument interpreted over participants of the same event',
                    'nominal_apposition': 'explanatory appositive reading of comma-or nominal gloss'}
    for note in notes:
        if note['kind'] in requirements:
            metadata['runtime_requirements'].append(requirements[note['kind']])
    if any(n['kind'] == 'coarse_noun_phrase' for n in notes):
        metadata['uses_phrase_arguments'] = True
        metadata['limitations'].append('A complete noun phrase remains one argument; its internal relations are not separately exposed.')
    metadata.update(event_references=links, compiler_changes=notes)
    metadata['runtime_requirements'] = sorted(set(metadata['runtime_requirements']))
    return replace(claim, atoms=tuple(atoms), variables=variables, expression=expression, metadata=metadata), notes
