"""Preserve media/label scope, sufficiency and temporal conditions.

An opt-in extension over the frozen SRL/dependency compiler. It changes copied
annotations and logical forms, never the original sentence. Unsupported scope is
a compilation refusal, not a truth label. No model calls or sentence rewriting.
"""
from __future__ import annotations

import copy
import re
from dataclasses import replace

from .compilation_followup import followup_srl_form, walk_events
from .logical_form import LogicalFormError, bind_variables
from .logical_form_v2 import ScopedCompiler
from .representation import Atom, Expression as E
from .semantic_srl import inherit_routes
from .srl_revision import TokenAlignment

VISUAL_MEDIA = {'footage', 'video', 'clip', 'image', 'imagery', 'photo', 'photograph', 'picture', 'visual', 'screen'}
LABEL_VERBS = {'label', 'name', 'title', 'caption'}
EXTRA_KINDS = {'relative', 'complement', 'prediction', 'concession', 'sufficiency'}


class SourceSyntax:
    def __init__(self, record):
        self.record = record
        self.tokens = record['tokens']
        self.alignment = TokenAlignment(record)
        self.by_id = {t['id']: t for t in self.tokens}
        self.children = {t['id']: [] for t in self.tokens}
        for t in self.tokens:
            if t['head'] in self.children:
                self.children[t['head']].append(t)

    def subtree(self, tid):
        found, todo = {tid}, [tid]
        while todo:
            for token in self.children[todo.pop()]:
                if token['id'] not in found:
                    found.add(token['id'])
                    todo.append(token['id'])
        return found

    def surface(self, ids):
        tokens = [self.by_id[i] for i in ids]
        return self.record['text'][min(t['start_char'] for t in tokens):max(t['end_char'] for t in tokens)]

    def argument(self, role, ids):
        indices = [self.alignment.word_index(self.by_id[i]) for i in ids]
        return dict(role=role, start=min(indices), end=max(indices), text=self.alignment.surface(min(indices), max(indices)))

    def frame_head(self, frame):
        if not frame.get('verb_span'):
            return None
        tokens = self.alignment.selected(*frame['verb_span'])
        return tokens[0] if len(tokens) == 1 else None


def quoted_spans(text):
    spans = []
    for pattern in (r'"([^"\n]+)"', r'“([^”\n]+)”', r"(?<!\w)'([^'\n]+)'(?!\w)"):
        spans += [(m.start(1), m.end(1), m.group(1)) for m in re.finditer(pattern, text)]
    return sorted(spans)


def prepare_annotations(record):
    r = copy.deepcopy(record)
    syntax = SourceSyntax(r)
    notes, labels, thresholds = [], [], []
    frames = r['srl']['frames']
    # Protect label strings before any predicate/frame recovery takes place.
    for lo, hi, words in quoted_spans(r['text']):
        inside = {t['id'] for t in syntax.tokens if lo <= t['start_char'] and t['end_char'] <= hi}
        if not inside:
            continue
        candidates = []
        for frame in frames:
            token = syntax.frame_head(frame)
            if not token or token['id'] in inside or token['lemma'].lower() not in LABEL_VERBS:
                continue
            overlap = [a for a in frame['args'] if any(t['id'] in inside for t in syntax.alignment.selected(a['start'], a['end']))]
            if overlap:
                candidates.append((frame, token, overlap))
        if not candidates:
            continue  # Existing speech/OCR quotation handling remains separate.
        if len(candidates) != 1:
            raise LogicalFormError('label_scope', 'Quoted label has several possible labeling predicates.')
        frame, token, overlap = candidates[0]
        target_args = [a for a in frame['args'] if a['role'] == 'ARG1' and a not in overlap]
        if len(target_args) != 1 or len({a['role'] for a in overlap}) != 1:
            raise LogicalFormError('label_scope', 'Quoted label needs one described entity and one text argument.')
        value_role = overlap[0]['role']
        frame['args'] = [a for a in frame['args'] if a not in overlap] + [syntax.argument(value_role, inside)]
        removed = [f for f in frames if syntax.frame_head(f) and syntax.frame_head(f)['id'] in inside]
        frames[:] = [f for f in frames if f not in removed]
        # A lexical tagger can mistake VIS or another label word for a predicate.
        # POS suppression is confined to the explicitly quoted text span.
        for tid in inside:
            syntax.by_id[tid]['upos'] = 'PROPN'
        labels.append(dict(event='e'+str(token['id']), role=value_role, text=words,
                           target=target_args[0], token_ids=sorted(inside),
                           literal_kind='verbatim_text' if token['lemma'].lower() in {'label', 'caption'} else 'text'))
        # Preserve a following participial modifier on the described entity, with
        # an explicit warning: this attachment still needs semantic review.
        for other in frames:
            head = syntax.frame_head(other)
            if not head or head['start_char'] <= hi or head['head'] not in inside or head['deprel'] != 'acl':
                continue
            subject = [a for a in other['args'] if a['role'] == 'ARG1' and
                       all(t['id'] in inside for t in syntax.alignment.selected(a['start'], a['end']))]
            if len(subject) != 1:
                raise LogicalFormError('label_modifier', 'Post-label clause has unresolved attachment.')
            target_tokens = syntax.alignment.selected(target_args[0]['start'], target_args[0]['end'])
            target_ids = {t['id'] for t in target_tokens}
            roots = [t for t in target_tokens if t['head'] not in target_ids]
            if len(roots) != 1:
                raise LogicalFormError('label_modifier', 'Post-label modifier has no unique described head.')
            head['head'] = roots[0]['id']
            other['args'] = [a for a in other['args'] if a not in subject] + [dict(target_args[0], role='ARG1')]
            notes.append(dict(kind='label_modifier', event='e'+str(head['id']), target='x'+str(roots[0]['id']),
                              reading='following participial modifier describes the labeled entity'))
        notes.append(dict(kind='quoted_label', event='e'+str(token['id']), text=words,
                          removed_predicates=[f['verb'] for f in removed]))

    syntax = SourceSyntax(r)
    # Keep enough-NP and its goal together. Other degree/negation patterns remain
    # explicit refusals rather than dropping the quantity condition.
    for token in syntax.tokens:
        if token['lemma'].lower() != 'enough':
            continue
        if any(lo <= token['start_char'] < hi for lo, hi, _ in quoted_spans(r['text'])):
            continue
        noun = syntax.by_id.get(token['head'])
        if not noun or noun['upos'] != 'NOUN' or token['deprel'] not in {'amod', 'det'}:
            raise LogicalFormError('threshold_scope', 'Enough has no supported nominal threshold reading.')
        parent = syntax.by_id.get(noun['head'])
        if not parent:
            raise LogicalFormError('threshold_scope', 'Threshold noun has no governing predicate.')
        if any(t['text'].lower() in {'not', "n't", 'never', 'no'} for t in syntax.children[parent['id']] + syntax.children[noun['id']]):
            raise LogicalFormError('threshold_negation', 'Negated sufficiency needs a separate quantified interpretation.')
        goals = [t for t in syntax.children[parent['id']] if t['deprel'] == 'xcomp' and
                 any(u['lemma'].lower() == 'to' for u in syntax.children[t['id']])]
        governing = [f for f in frames if syntax.frame_head(f) and syntax.frame_head(f)['id'] == parent['id']]
        if len(goals) != 1 or len(governing) != 1:
            raise LogicalFormError('threshold_scope', 'Enough-NP needs one explicit infinitival sufficiency goal.')
        goal = goals[0]
        spans = [a for a in governing[0]['args'] if noun['id'] in
                 {t['id'] for t in syntax.alignment.selected(a['start'], a['end'])}]
        if len(spans) != 1:
            raise LogicalFormError('threshold_scope', 'Threshold argument does not have a unique SRL slot.')
        nominal = syntax.subtree(noun['id']) - syntax.subtree(goal['id'])
        governing[0]['args'] = [a for a in governing[0]['args'] if a is not spans[0]] + [syntax.argument(spans[0]['role'], nominal)]
        goal.update(head=noun['id'], deprel='acl')
        thresholds.append(dict(entity='x'+str(noun['id']), goal='e'+str(goal['id'])))
        notes.append(dict(kind='sufficiency', entity='x'+str(noun['id']), goal='e'+str(goal['id']), threshold='context required'))

    syntax = SourceSyntax(r)
    # Enable explicit-frame recovery for binary nominal OR. The logical-form
    # pass below must then expand that group as alternatives, or refuse it.
    known = {syntax.frame_head(f)['id'] for f in frames if syntax.frame_head(f) and f.get('args')}
    for token in syntax.tokens:
        if token['id'] in known or token['upos'] != 'VERB' or token['deprel'] not in {'root', 'conj'}:
            continue
        subjects = [t for t in syntax.children[token['id']] if t['deprel'].startswith('nsubj')]
        if len(subjects) != 1 or not any(t['lemma'].lower() == 'or' and t['deprel'] == 'cc'
                                       for t in syntax.tokens if t['id'] in syntax.subtree(subjects[0]['id'])):
            continue
        args = [syntax.argument(t['deprel'], syntax.subtree(t['id'])) for t in syntax.children[token['id']]
                if t['deprel'].startswith('nsubj') or t['deprel'] in {'obj', 'iobj', 'obl', 'obl:tmod'}]
        frames.append(dict(verb=token['text'], verb_span=[syntax.alignment.word_index(token)]*2, args=args))
        notes.append(dict(kind='nominal_or_frame', event='e'+str(token['id']), basis='explicit grammatical subject'))
    return r, notes, labels, thresholds


def preserve_media_scope(record, form, notes):
    syntax = SourceSyntax(record)
    entities = {e['id']: e for e in form['entities']}
    content_media = VISUAL_MEDIA-{'screen'}
    # Normalize explicit media-of relations before route inheritance. Otherwise
    # the later base normalization introduces a depiction whose nested clauses
    # have already inherited the wrong unspecified route.
    for entity in form['entities']:
        if not any(t['lemma'].lower() in content_media and t['text'].casefold() == entity['text'].casefold()
                   for t in syntax.tokens):
            continue
        retained = []
        for relation in entity.get('relations', []):
            if relation['role'] in {'of', 'about', 'content', 'depicts', 'depicting'}:
                entity.setdefault('propositions', []).append(dict(role='content', kind='depiction',
                    route='visual_depiction', body=dict(op='entity', ref=relation['target'])))
            else:
                retained.append(relation)
        if entity.get('relations') is not None:
            entity['relations'] = retained
    for event in walk_events(form):
        if event['predicate'] not in {'show', 'depict', 'display'}:
            continue
        subjects = [entities[a] for role, a in event['arguments'].items() if role in {'ARG0', 'nsubj'} and isinstance(a, str) and a in entities]
        if any(any(t['lemma'].lower() in VISUAL_MEDIA and t['text'].casefold() in e['text'].casefold()
                   for t in syntax.tokens) for e in subjects):
            for prop in event.get('propositions', []):
                if prop['kind'] in {'complement', 'depiction'}:
                    prop.update(kind='depiction', route='visual_depiction')
                    notes.append(dict(kind='depiction_route', event=event['id']))
    roots = [t for t in syntax.tokens if t['head'] == 0 and t['lemma'].lower() in content_media and t['upos'] == 'NOUN']
    if len(roots) != 1:
        return
    root = roots[0]
    if any(e['id'].startswith('e') and e['id'][1:].isdigit() and int(e['id'][1:]) < root['id']
           for e in walk_events(form['formula'])):
        return  # E.g. mistagged "Shows image of ..." is still a source predicate.
    content = [t for t in syntax.children[root['id']] if t['deprel'].startswith('nmod') and
               any(u['lemma'].lower() == 'of' and u['deprel'] == 'case' for u in syntax.children[t['id']])]
    if len(content) != 1:
        return
    content_ids = syntax.subtree(content[0]['id'])
    formula = form['formula']
    if formula.get('op') != 'entity':
        event_ids = [int(e['id'][1:]) for e in walk_events(formula) if e['id'].startswith('e') and e['id'][1:].isdigit()]
        if not event_ids or not all(i in content_ids for i in event_ids):
            raise LogicalFormError('media_scope', 'Nominal media description mixes unresolved content and other clauses.')
        eid = 'media'+str(root['id'])
        media = dict(id=eid, text=root['text'], type='entity', propositions=[
            dict(role='content', kind='depiction', route='visual_depiction', body=formula)])
        form['entities'].append(media)
        form['formula'] = dict(op='entity', ref=eid)
        form['kind'] = 'mention'
        notes.append(dict(kind='nominal_media_scope', entity=eid, content_events=[e['id'] for e in walk_events(formula)]))
    else:
        media = entities[formula['ref']]
    for child in syntax.children[root['id']]:
        if child['id'] in content_ids or child['deprel'] in {'det', 'punct'}:
            continue
        ids = syntax.subtree(child['id'])
        if any(syntax.by_id[i]['upos'] in {'VERB', 'AUX'} for i in ids):
            raise LogicalFormError('media_modifier', 'A media-description modifier contains an unresolved clause.')
        if child['deprel'] in {'amod', 'compound'}:
            role = 'mod'
        elif child['deprel'].startswith('nmod'):
            role = 'viewpoint' if child['lemma'].lower() in {'angle', 'perspective', 'viewpoint'} else 'description'
        else:
            continue
        prop = dict(role=role, value=syntax.surface(ids))
        if prop not in media.setdefault('properties', []):
            media['properties'].append(prop)


def preserve_shared_times(record, form, notes):
    syntax = SourceSyntax(record)
    events = {e['id']: e for e in walk_events(form)}
    for token in syntax.tokens:
        if token['deprel'] != 'conj' or token['upos'] != 'VERB':
            continue
        parent = events.get('e'+str(token['head']))
        child = events.get('e'+str(token['id']))
        if not parent or not child:
            continue
        time = parent['arguments'].get('ARGM-TMP')
        if not isinstance(time, dict) or time.get('kind') != 'time' or child['arguments'].get('ARGM-TMP'):
            continue
        starts = [m.start() for m in re.finditer(re.escape(time['value']), record['text'], re.I)]
        if len(starts) != 1 or starts[0] >= syntax.by_id[token['head']]['start_char']:
            continue
        subject_ids = {t['id'] for t in syntax.children[token['head']] if t['deprel'].startswith('nsubj')}
        if subject_ids and starts[0] > min(syntax.by_id[i]['start_char'] for i in subject_ids):
            continue  # A medial temporal modifier is not automatically shared.
        explicit = [t for t in syntax.children[token['id']] if t['deprel'].startswith('nsubj')]
        if explicit and not {t['id'] for t in explicit} <= subject_ids:
            raise LogicalFormError('temporal_scope', 'Fronted time with a different coordinated subject needs an explicit scope reading.')
        child['arguments']['ARGM-TMP'] = copy.deepcopy(time)
        notes.append(dict(kind='shared_time', source=parent['id'], event=child['id'], value=time['value']))
    # Preserve an exact clock time attached to a nominal participant, without
    # guessing that every event in the sentence shares that time.
    for entity in form['entities']:
        if not re.fullmatch(r'x\d+', entity['id']):
            continue
        tid = int(entity['id'][1:])
        for child in syntax.children.get(tid, []):
            if re.fullmatch(r'\d{1,2}:\d{2}(?::\d{2})?', child['text']):
                value = syntax.surface(syntax.subtree(child['id']))
                prop = dict(role='time', value=value)
                if prop not in entity.setdefault('properties', []):
                    entity['properties'].append(prop)
                    notes.append(dict(kind='nominal_clock_time', entity=entity['id'], value=value))


def expand_nominal_alternatives(record, form, notes):
    syntax = SourceSyntax(record)
    entities = {e['id']: e for e in form['entities']}
    groups = set()
    for token in syntax.tokens:
        if token['deprel'] != 'cc' or token['lemma'].lower() != 'or':
            continue
        if any(lo <= token['start_char'] < hi for lo, hi, _ in quoted_spans(record['text'])):
            continue
        member = syntax.by_id[token['head']]
        if member['upos'] not in {'NOUN', 'PROPN', 'PRON'} or member['deprel'] != 'conj':
            continue
        group = 'g'+str(member['head'])
        groups.add(group)
    for group in sorted(groups):
        data = entities.get(group)
        if not data:
            raise LogicalFormError('nominal_disjunction', 'Nominal OR has no explicit alternative group.')
        members = [r['target'] for r in data.get('relations', []) if r['role'] == 'member']
        if len(members) != 2 or data.get('quantity') or data.get('properties'):
            raise LogicalFormError('nominal_disjunction', 'Only two unquantified nominal alternatives are supported.')
        owner = int(group[1:])
        if any(t['deprel'] == 'cc' and t['lemma'].lower() == 'and'
               for t in syntax.tokens if t['id'] in syntax.subtree(owner)):
            raise LogicalFormError('nominal_disjunction', 'Mixed nominal AND/OR needs an explicit scope reading.')
        occurrences = []
        for event in walk_events(form):
            for role, value in event['arguments'].items():
                if value == group:
                    occurrences.append((event, role))
        if not occurrences:
            mentions = []
            def find_mentions(value):
                if isinstance(value, dict):
                    if value.get('op') == 'entity' and value.get('ref') == group:
                        mentions.append(value)
                    for item in value.values():
                        find_mentions(item)
                elif isinstance(value, list):
                    for item in value:
                        find_mentions(item)
            find_mentions(form)
            if len(mentions) != 1 or mentions[0] is form['formula']:
                raise LogicalFormError('nominal_disjunction', 'Nominal alternatives have unresolved reference scope.')
            mentions[0].clear()
            mentions[0].update(op='or', children=[dict(op='entity', ref=member) for member in members])
            form['entities'] = [e for e in form['entities'] if e['id'] != group]
            notes.append(dict(kind='nominal_or', entity=group, alternatives=members,
                              reading='inclusive alternatives inside a containing description'))
            continue
        if len(occurrences) != 1:
            raise LogicalFormError('nominal_disjunction', 'Nominal alternative must occupy one explicit event argument.')
        target, role = occurrences[0]
        branches = []
        for i, member in enumerate(members):
            branch = copy.deepcopy(target)
            branch['arguments'][role] = member
            for event in walk_events(branch):
                event['id'] += '_alternative'+str(i+1)
            branches.append(branch)
        original_id = target['id']
        target.clear()
        target.update(op='or', children=branches)
        form['entities'] = [e for e in form['entities'] if e['id'] != group]
        notes.append(dict(kind='nominal_or', event=original_id, role=role, alternatives=members,
                          reading='inclusive alternatives; original modifier attachments retained'))


def scoped_srl_form(record):
    prepared, notes, labels, thresholds = prepare_annotations(record)
    form, previous_notes = followup_srl_form(prepared)
    notes = previous_notes + notes
    for label in labels:
        event = next((e for e in walk_events(form) if e['id'] == label['event']), None)
        if not event:
            raise LogicalFormError('label_scope', 'Protected label lost its labeling event.')
        event['arguments'][label['role']] = dict(kind=label['literal_kind'], value=label['text'])
        event['propositions'] = [p for p in event.get('propositions', []) if p['role'] != label['role']]
        if label['literal_kind'] == 'verbatim_text':
            event.setdefault('properties', []).append(dict(role='source_route', value='ocr_assertion'))
    for threshold in thresholds:
        entity = next((e for e in form['entities'] if e['id'] == threshold['entity']), None)
        if not entity:
            raise LogicalFormError('threshold_scope', 'Threshold noun was omitted by the graph builder.')
        prop = next((p for p in entity.get('propositions', [])
                     if any(e['id'] == threshold['goal'] for e in walk_events(p['body']))), None)
        if not prop:
            raise LogicalFormError('threshold_scope', 'Sufficiency goal was omitted from its nominal argument.')
        prop.update(role='sufficient_for', kind='sufficiency')
        for p in entity.get('properties', []):
            if p['value'].lower() == 'enough':
                p['role'] = 'threshold'
        form['requires_context'] = True
    preserve_media_scope(record, form, notes)
    preserve_shared_times(record, form, notes)
    expand_nominal_alternatives(record, form, notes)
    inherit_routes(form)
    if any(n['kind'] == 'label_modifier' for n in notes):
        form['requires_context'] = True
    # Only quote declarations replaced by a complete literal may be removed.
    referenced = set()
    def collect(value):
        if isinstance(value, dict):
            if value.get('op') == 'entity':
                referenced.add(value['ref'])
            if value.get('op') == 'event':
                referenced.update(v for v in value['arguments'].values() if isinstance(v, str))
            for item in value.values():
                collect(item)
        elif isinstance(value, list):
            for item in value:
                collect(item)
    collect(form['formula'])
    entities = {e['id']: e for e in form['entities']}
    visited = set()
    while referenced-visited:
        pending = referenced-visited
        visited |= pending
        for eid in pending:
            entity = entities[eid]
            referenced.update(r['target'] for r in entity.get('relations', []))
            collect(entity.get('propositions', []))
    protected = [(lo, hi) for lo, hi, words in quoted_spans(record['text']) if any(label['text'] == words for label in labels)]
    def label_declaration(entity):
        matches = list(re.finditer(r'(?<!\w)'+re.escape(entity['text'])+r'(?!\w)', record['text'], re.I))
        return bool(matches) and all(any(lo <= m.start() and m.end() <= hi for lo, hi in protected) for m in matches)
    form['entities'] = [e for e in form['entities'] if e['id'] in referenced or not label_declaration(e)]
    return form, notes


def compile_scoped_srl(record):
    form, notes = scoped_srl_form(record)
    claim = ScopedCompiler().compile(record['claim_id'], record['text'], record['tokens'], form,
                                     additional_proposition_kinds=EXTRA_KINDS)
    # Preserve the earlier extension's executable annotations after re-compiling
    # the new scopes. Historical source files remain byte-identical.
    atoms, metadata, expression = list(claim.atoms), copy.deepcopy(claim.metadata), claim.expression
    additions = {}
    for note in notes:
        if note['kind'] != 'duration':
            continue
        for event_id, event in metadata['events'].items():
            if event['id'] != note['event'] and not event['id'].startswith(note['event']+'_alternative'):
                continue
            atom = next(a for a in atoms if a.predicate == event['predicate'] and a.arguments[0] == event_id)
            args = (event_id, note['role'], note['operator'], note['value'], note['unit'], note['reference'])
            extra = Atom('a'+str(len(atoms)+1), 'duration', args+atom.arguments[atom.arguments.index('scope'):],
                         'duration', (), note['source'], (), False)
            atoms.append(extra)
            metadata['allowed_routes'][extra.id] = metadata['allowed_routes'][atom.id]
            additions.setdefault(atom.id, []).append(E.atom(extra.id))
    def extend(expr):
        if expr.op == 'atom' and expr.atom_id in additions:
            return E.combine('and', [expr, *additions[expr.atom_id]])
        return replace(expr, children=tuple(extend(c) for c in expr.children))
    expression = extend(expression)
    aliases, links = {}, []
    for note in notes:
        if note['kind'] != 'event_reference':
            continue
        nominal = next((v for v, e in metadata['entities'].items() if e['id'] == note['mention']), None)
        events = [v for v, e in metadata['events'].items() if e['id'] == note['event']]
        if nominal and len(events) == 1:
            aliases[nominal] = events[0]
            links.append(dict(mention=note['mention'], event=note['event'], variable=events[0]))
    variables = claim.variables
    if aliases:
        affected = set(aliases) | set(aliases.values())
        atoms = [replace(a, arguments=tuple(aliases.get(x, x) for x in a.arguments)) for a in atoms]
        def unbind(expr):
            children = tuple(unbind(c) for c in expr.children)
            remaining = tuple(v for v in expr.variables if v not in affected)
            return children[0] if expr.op == 'exists' and not remaining else replace(expr, children=children, variables=remaining)
        variables = tuple(v for v in variables if v.name not in aliases)
        expression = bind_variables(unbind(expression), atoms, [v for v in variables if v.name in affected])
        for old, new in aliases.items():
            metadata['entities'][new] = metadata['entities'].pop(old)
    metadata.update(event_references=links, compiler_changes=notes)
    if any(n['kind'] == 'sufficiency' for n in notes):
        metadata['runtime_requirements'].append('contextual sufficiency threshold and goal support')
    if any(n['kind'] == 'implicit_subject' for n in notes):
        metadata['runtime_requirements'].append('implicit embedded subject')
    if any(n['kind'] == 'label_modifier' for n in notes):
        metadata['runtime_requirements'].append('review the following label-modifier attachment')
    return replace(claim, atoms=tuple(atoms), variables=variables, expression=expression, metadata=metadata), notes
