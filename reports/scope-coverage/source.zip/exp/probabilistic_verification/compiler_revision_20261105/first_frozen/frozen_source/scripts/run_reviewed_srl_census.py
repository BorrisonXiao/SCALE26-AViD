#!/usr/bin/env python3
"""Compile the original inventory with the human-review-driven SRL revision."""
import argparse
import hashlib
import json
import time
from collections import Counter
from pathlib import Path

from problog.program import PrologString
from probabilistic_verification.balanced_logic import balanced_prolog_program
from probabilistic_verification.compilation_checks_v2 import meaning_diagnostics
from probabilistic_verification.logic import Evidence, ground
from probabilistic_verification.reviewed_srl import compile_reviewed_srl

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/compiler_revision_20261105'


def compile_one(record):
    row = dict(claim_id=record['claim_id'], text=record['text'], status='unsupported')
    try:
        claim, notes = compile_reviewed_srl(record)
        row.update(changes=notes, proposed_form=claim.metadata['logical_form'])
        evidence = Evidence('compilation-check', {v.name: [v.name.lower()] for v in claim.variables},
                            {v.name: True for v in claim.variables}, {})
        program, _ = balanced_prolog_program([ground(claim, evidence, max_expansions=10000)], learned=False)
        assert list(PrologString(program))
        row.update(status='compiled', compilation=claim.to_dict(), program=program,
                   program_sha256=hashlib.sha256(program.encode()).hexdigest(),
                   diagnostics=meaning_diagnostics(record, claim.metadata['logical_form'], claim))
    except Exception as error:
        row.update(code=getattr(error, 'code', type(error).__name__), reason=str(error))
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--development', action='store_true')
    parser.add_argument('--output', type=Path, default=RUN / 'results.jsonl')
    args = parser.parse_args()
    records = [json.loads(s) for s in (RUN / 'inputs.jsonl').read_text().splitlines()]
    if args.development:
        old = json.loads((ROOT / 'exp/probabilistic_verification/scope_compilation_20261101/sample_manifest.json').read_text())
        ids = set(old['development_ids'] + old['human_review_ids'])
        records = [r for r in records if r['claim_id'] in ids]
    started = time.perf_counter()
    rows = [compile_one(r) for r in records]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in rows))
    summary = dict(total=len(rows), counts=Counter('compiled' if r['status'] == 'compiled' else r['code'] for r in rows),
                   kinds=Counter(r['compilation']['metadata']['kind'] for r in rows if r['status'] == 'compiled'),
                   elapsed_seconds=time.perf_counter() - started)
    args.output.with_suffix('.summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
