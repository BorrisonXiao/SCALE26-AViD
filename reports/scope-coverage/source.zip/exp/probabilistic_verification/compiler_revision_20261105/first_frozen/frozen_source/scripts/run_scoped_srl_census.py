#!/usr/bin/env python3
"""Run the scoped SRL revision on the original frozen inventory."""
import argparse
import hashlib
import json
import time
from collections import Counter
from pathlib import Path

from problog.program import PrologString
from probabilistic_verification.scoped_srl import compile_scoped_srl
from probabilistic_verification.compilation_checks_v2 import meaning_diagnostics
from probabilistic_verification.balanced_logic import balanced_prolog_program
from probabilistic_verification.logic import Evidence, ground

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT/'exp/probabilistic_verification/scope_compilation_20261101'


def read(name):
    return [json.loads(s) for s in (RUN/name).read_text().splitlines() if s.strip()]


def compile_one(record):
    row = dict(claim_id=record['claim_id'], text=record['text'], status='unsupported')
    try:
        claim, notes = compile_scoped_srl(record)
        row.update(changes=notes, proposed_form=claim.metadata['logical_form'])
        evidence = Evidence('compilation-check', {v.name: [v.name.lower()] for v in claim.variables},
                            {v.name: True for v in claim.variables}, {})
        program, _ = balanced_prolog_program([ground(claim, evidence, max_expansions=10000)], learned=False)
        assert list(PrologString(program))
        row.update(status='compiled', compilation=claim.to_dict(), program=program,
                   program_sha256=hashlib.sha256(program.encode()).hexdigest(),
                   diagnostics=meaning_diagnostics(record, claim.metadata['logical_form'], claim))
    except Exception as error:
        row.update(code=getattr(error, 'code', type(error).__name__), reason=str(error))
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--development', action='store_true')
    parser.add_argument('--output', type=Path, default=RUN/'results.jsonl')
    args = parser.parse_args()
    records = read('inputs.jsonl')
    if args.development:
        ids = json.loads((RUN/'sample_manifest.json').read_text())['development_ids']
        records = [r for r in records if r['claim_id'] in ids]
    started = time.perf_counter()
    rows = [compile_one(r) for r in records]
    args.output.write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in rows))
    summary = dict(total=len(rows), counts=Counter('compiled' if r['status']=='compiled' else r['code'] for r in rows),
                   kinds=Counter(r['compilation']['metadata']['kind'] for r in rows if r['status']=='compiled'),
                   elapsed_seconds=time.perf_counter()-started)
    args.output.with_suffix('.summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
