"""Meaning-based tests for scope, alternatives, sufficiency and shared times."""
import copy
import itertools
import json
from pathlib import Path

import pytest

from probabilistic_verification.balanced_logic import BalancedVerifier
from probabilistic_verification.direct_backend import DirectVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground, combine_states
from probabilistic_verification.scoped_srl import compile_scoped_srl, scoped_srl_form
from probabilistic_verification.logical_form import LogicalFormError

RUN = Path(__file__).resolve().parents[1]/'exp/probabilistic_verification/scope_compilation_20261101'
RECORDS = {r['claim_id']: r for r in map(json.loads, (RUN/'inputs.jsonl').read_text().splitlines())}


def compile_case(cid):
    return compile_scoped_srl(RECORDS[cid])[0]


def test_media_description_preserves_depiction_and_viewpoint():
    claim = compile_case('TW4OYA3RN-Hw_1810')
    burning = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'burning')
    assert burning['scope'] != 'world' and burning['route'] == 'visual_depiction'
    assert claim.metadata['kind'] == 'mention'
    assert any(a.predicate == 'property' and 'viewpoint' in a.arguments and
               'at different angles/perspectives' in a.arguments for a in claim.atoms)


def test_shows_image_is_not_misread_as_a_bare_media_description():
    claim = compile_case('TFgw4IaR9R8s_1720')
    assert any(e['predicate'] == 'show' for e in claim.metadata['events'].values())


def test_quoted_label_is_exact_text_and_not_a_predicate():
    claim = compile_case('Txf2EdqOg1SQ_2305')
    assert not any(e['predicate'] == 'VIS' for e in claim.metadata['events'].values())
    label = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'label')
    use = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'use')
    assert label['arguments']['ARG2'] == dict(kind='verbatim_text', value='HIMAWARI-9 Pseudo-VIS ROI-FLOATER')
    assert label['route'] == 'ocr_assertion' and use['route'] == 'visual_depiction'
    assert label['arguments']['ARG1'] == use['arguments']['ARG1']
    assert 'review the following label-modifier attachment' in claim.metadata['runtime_requirements']


def test_enough_seats_has_a_scoped_sufficiency_goal():
    claim = compile_case('TQEmEycTI0RQ_880')
    entities = claim.metadata['entities']
    seats = next(k for k, e in entities.items() if e['text'] == 'seats')
    denial = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'deny')
    goal = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'form')
    assert denial['arguments']['ARG1'] == entities[seats]['id']
    assert goal['scope'] != 'world' and claim.metadata['scopes'][goal['scope']]['kind'] == 'sufficiency'
    assert any(a.predicate == 'property' and 'threshold' in a.arguments and 'enough' in a.arguments for a in claim.atoms)
    assert 'contextual sufficiency threshold and goal support' in claim.metadata['runtime_requirements']
    assert not entities[seats].get('quantity')  # No fabricated seat count.


def test_nominal_or_is_two_alternative_events_not_a_two_member_group():
    form, _ = scoped_srl_form(RECORDS['Txf2EdqOg1SQ_2295'])
    assert form['formula']['op'] == 'or'
    assert len(form['formula']['children']) == 2
    assert not any(e['id'] == 'g5' for e in form['entities'])
    assert {e['arguments']['nsubj'] for e in form['formula']['children']} == {'x5', 'x8'}


def test_fronted_time_is_shared_and_exact_nominal_clock_is_retained():
    claim = compile_case('TgPh_fzHTCm4_1502')
    events = list(claim.metadata['events'].values())
    assert all(e['arguments']['ARGM-TMP']['value'] == 'On the 5th' for e in events)
    claim = compile_case('T3HTSBW42QaY_776')
    assert any(a.predicate == 'property' and 'time' in a.arguments and 'at 8:58:09' in a.arguments for a in claim.atoms)


def test_original_annotations_and_text_are_unchanged():
    for cid in ['Txf2EdqOg1SQ_2305', 'TQEmEycTI0RQ_880', 'TW4OYA3RN-Hw_1810']:
        before = copy.deepcopy(RECORDS[cid])
        compile_scoped_srl(RECORDS[cid])
        assert RECORDS[cid] == before


def stipulated_program(cid, policy):
    claim = compile_case(cid)
    domains = {v.name: [v.name.lower()] for v in claim.variables}
    observations = {}
    for values in itertools.product(*(domains[v.name] for v in claim.variables)):
        assignment = dict(zip([v.name for v in claim.variables], values))
        for atom in claim.atoms:
            state = policy(atom)
            key = canonical_key('constructed-'+cid, atom, assignment, 'visual_depiction')
            observations[key] = Observation(key, tuple(float(s == state) for s in ['supported', 'refuted', 'unknown']),
                                            False, atom.text, {'source': 'stipulated scope check'})
    program = ground(claim, Evidence('constructed-'+cid, domains, {v: True for v in domains}, observations), max_expansions=10000)
    return program


def logical_state(program):
    def evaluate(expr):
        if expr.op == 'constant':
            return expr.state
        if expr.op == 'atom':
            return ['supported', 'refuted', 'unknown'][program.observations[expr.atom_id].distribution.index(1.)]
        return combine_states(expr.op, [evaluate(c) for c in expr.children])
    return evaluate(program.expression)


@pytest.mark.parametrize('cloud,front,expected', [
    ('supported', 'refuted', 'supported'), ('refuted', 'refuted', 'refuted'), ('unknown', 'refuted', 'unknown')])
def test_native_disjunction_does_not_require_both_descriptions(cloud, front, expected):
    def policy(atom):
        if atom.predicate == 'referent' and atom.arguments[1] == 'cloud':
            return cloud
        if atom.predicate == 'referent' and atom.arguments[1] == 'front':
            return front
        return 'supported'
    program = stipulated_program('Txf2EdqOg1SQ_2295', policy)
    assert logical_state(program) == expected
    result = BalancedVerifier([program], learned=False).predict()[0]
    assert result['distribution'][expected] > 1-1e-9


@pytest.mark.parametrize('case', ['depiction', 'threshold', 'shared_time'])
def test_scope_and_time_require_the_declared_evidence(case):
    if case == 'depiction':
        cid = 'TW4OYA3RN-Hw_1810'
        policy = lambda a: 'refuted' if a.predicate == 'burning' and a.arguments[a.arguments.index('scope')+1] != 'world' else 'supported'
        expected = 'refuted'
    elif case == 'threshold':
        cid = 'TQEmEycTI0RQ_880'
        policy = lambda a: 'unknown' if a.predicate == 'proposition' and 'sufficiency' in a.arguments else 'supported'
        expected = 'unknown'
    else:
        cid = 'TgPh_fzHTCm4_1502'
        policy = lambda a: 'refuted' if a.predicate == 'dissipate' and any('On the 5th' in v for v in a.arguments) else 'supported'
        expected = 'refuted'
    program = stipulated_program(cid, policy)
    assert logical_state(program) == expected
    result = BalancedVerifier([program], learned=False).predict()[0]
    assert result['distribution'][expected] > 1-1e-9


def test_balanced_threshold_probabilities_match_the_independent_conjunction_formula():
    import math
    from dataclasses import replace
    program = stipulated_program('TQEmEycTI0RQ_880', lambda a: 'supported')
    def operators(expr):
        return {expr.op} | set().union(*(operators(c) for c in expr.children))
    assert operators(program.expression) <= {'and', 'atom', 'constant'}
    observations = {oid: replace(obs, distribution=(.7, .2, .1)) for oid, obs in program.observations.items()}
    program = replace(program, observations=observations)
    support = math.prod(o.distribution[0] for o in observations.values())
    refutation = 1-math.prod(1-o.distribution[1] for o in observations.values())
    expected = dict(supported=support, refuted=refutation, unknown=1-support-refutation)
    actual = BalancedVerifier([program], learned=False).predict()[0]['distribution']
    assert actual == pytest.approx(expected, abs=1e-10)


def test_balancing_preserves_neural_gradients_with_repeated_observations():
    import torch
    from probabilistic_verification.logic import GroundProgram
    from probabilistic_verification.representation import Expression as E
    a = Observation('gradient-a', (.4, .2, .4), True, 'a')
    b = Observation('gradient-b', (.6, .3, .1), True, 'b')
    expression = E.combine('or', [E.combine('and', [E.atom(a.id), E.atom(b.id)]), E.negate(E.atom(a.id))])
    program = GroundProgram('gradient-sharing', expression, {a.id: a, b.id: b}, [], [])
    gradients, probabilities = [], []
    for verifier in (DirectVerifier, BalancedVerifier):
        model = verifier([program], learned=True)
        query = model.query(program.claim_id, 'supported')
        probability = model.model.solve([query])[0].result[query.query]
        (-probability.log()).backward()
        probabilities.append(float(probability.detach()))
        gradients.append(model.classifier.layers[-1].weight.grad.detach().clone())
    assert probabilities[0] == pytest.approx(probabilities[1], abs=1e-10)
    assert torch.allclose(*gradients, atol=1e-10) and gradients[1].norm() > 0


def test_balancing_keeps_incomplete_inventory_unknown_and_evidence_conflicts():
    from dataclasses import replace
    from probabilistic_verification.logic import GroundProgram, enumerate_probability
    from probabilistic_verification.representation import Expression as E
    from probabilistic_verification.balanced_logic import balance_program
    a = Observation('incomplete-a', (.3, .4, .3), False, 'a')
    b = Observation('incomplete-b', (.2, .5, .3), False, 'b')
    incomplete = E.combine('or', [E.atom(a.id), E.constant('unknown')])
    expression = E('evidence', (incomplete, E.negate(E.atom(b.id))))
    p = GroundProgram('incomplete-and-conflict', expression, {a.id: a, b.id: b}, [], [])
    expected = enumerate_probability(p)
    assert enumerate_probability(balance_program(p)) == pytest.approx(expected, abs=1e-10)
    assert BalancedVerifier([p], learned=False).predict()[0]['distribution'] == pytest.approx(expected, abs=1e-10)


def constructed_record(text, specs, frames):
    """Explicitly constructed parser annotations, not additional model outputs."""
    tokens, words, position = [], [], 0
    for i, (word, lemma, upos, head, relation) in enumerate(specs, 1):
        start = text.index(word, position)
        tokens.append(dict(id=i, text=word, lemma=lemma, upos=upos, head=head, deprel=relation,
                           start_char=start, end_char=start+len(word), feats=''))
        words.append(word)
        position = start+len(word)
    output = []
    for index, arguments in frames:
        output.append(dict(verb=words[index], verb_span=[index, index], args=[
            dict(role=role, start=lo, end=hi, text=' '.join(words[lo:hi+1])) for role, lo, hi in arguments]))
    return dict(claim_id='constructed', text=text, tokens=tokens, srl=dict(words=words, frames=output))


def test_explicit_second_time_is_not_overwritten():
    r = constructed_record('On Monday Alice walks and on Tuesday rests.', [
        ('On','on','ADP',2,'case'), ('Monday','Monday','PROPN',4,'obl'),
        ('Alice','Alice','PROPN',4,'nsubj'), ('walks','walk','VERB',0,'root'),
        ('and','and','CCONJ',8,'cc'), ('on','on','ADP',7,'case'),
        ('Tuesday','Tuesday','PROPN',8,'obl'), ('rests','rest','VERB',4,'conj'), ('.','.','PUNCT',4,'punct')],
        [(3,[('ARG0',2,2),('ARGM-TMP',0,1)]), (7,[('ARG0',2,2),('ARGM-TMP',5,6)])])
    claim, _ = compile_scoped_srl(r)
    events = {e['predicate']: e for e in claim.metadata['events'].values()}
    assert events['walk']['arguments']['ARGM-TMP']['value'] == 'On Monday'
    assert events['rest']['arguments']['ARGM-TMP']['value'] == 'on Tuesday'


def test_adjectival_enough_is_explicitly_unsupported():
    r = constructed_record('The evidence is clear enough.', [
        ('The','the','DET',2,'det'), ('evidence','evidence','NOUN',4,'nsubj'),
        ('is','be','AUX',4,'cop'), ('clear','clear','ADJ',0,'root'),
        ('enough','enough','ADV',4,'advmod'), ('.','.','PUNCT',4,'punct')],
        [(2,[('ARG1',0,1),('ARG2',3,4)])])
    with pytest.raises(LogicalFormError, match='Enough has no supported nominal'):
        compile_scoped_srl(r)


def test_or_inside_a_label_is_protected_text():
    r = constructed_record("The sign is labeled 'STOP or GO'.", [
        ('The','the','DET',2,'det'), ('sign','sign','NOUN',4,'nsubj:pass'),
        ('is','be','AUX',4,'aux:pass'), ('labeled','label','VERB',0,'root'),
        ("'","'",'PUNCT',6,'punct'), ('STOP','stop','VERB',4,'xcomp'),
        ('or','or','CCONJ',8,'cc'), ('GO','go','NOUN',6,'conj'),
        ("'","'",'PUNCT',6,'punct'), ('.','.','PUNCT',4,'punct')],
        [(3,[('ARG1',0,1),('ARG2',4,8)]), (5,[('ARG1',7,7)])])
    claim, _ = compile_scoped_srl(r)
    label = next(iter(claim.metadata['events'].values()))
    assert label['arguments']['ARG2']['value'] == 'STOP or GO'
    assert len(claim.metadata['events']) == 1


def test_a_quoted_name_does_not_require_ocr():
    r = constructed_record("A boat is named 'Pioneer'.", [
        ('A','a','DET',2,'det'), ('boat','boat','NOUN',4,'nsubj:pass'),
        ('is','be','AUX',4,'aux:pass'), ('named','name','VERB',0,'root'),
        ("'","'",'PUNCT',6,'punct'), ('Pioneer','Pioneer','PROPN',4,'xcomp'),
        ("'","'",'PUNCT',6,'punct'), ('.','.','PUNCT',4,'punct')],
        [(3,[('ARG1',0,1),('ARG2',4,6)])])
    claim, _ = compile_scoped_srl(r)
    naming = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'name')
    assert naming['arguments']['ARG2']['value'] == 'Pioneer'
    assert naming['route'] != 'ocr_assertion'
