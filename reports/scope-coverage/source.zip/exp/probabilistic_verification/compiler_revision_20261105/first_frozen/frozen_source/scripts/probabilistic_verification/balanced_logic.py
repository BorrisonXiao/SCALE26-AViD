"""Balance associative AND/OR expressions while preserving categorical sharing."""
from dataclasses import replace

from .direct_backend import DirectVerifier, direct_prolog_program
from .representation import Expression as E


def balance_expression(expression):
    if expression.op not in {'and', 'or'}:
        return replace(expression, children=tuple(balance_expression(c) for c in expression.children))
    leaves = []

    def flatten(node):
        if node.op == expression.op:
            for child in node.children:
                flatten(child)
        else:
            leaves.append(balance_expression(node))

    flatten(expression)
    # Repeated observation nodes remain the same random variable. AND/OR are
    # idempotent; distinct observations are never merged by similar text.
    leaves = sorted(dict.fromkeys(leaves), key=lambda e: e.atom_id if e.op == 'atom' else repr(e))

    def tree(nodes):
        if len(nodes) == 1:
            return nodes[0]
        middle = len(nodes)//2
        return E(expression.op, (tree(nodes[:middle]), tree(nodes[middle:])))

    return tree(leaves) if leaves else E.constant('supported' if expression.op == 'and' else 'refuted')


def balance_program(program):
    return replace(program, expression=balance_expression(program.expression))


def balanced_prolog_program(programs, *, learned=True):
    return direct_prolog_program([balance_program(p) for p in programs], learned=learned)


class BalancedVerifier(DirectVerifier):
    def __init__(self, programs, **kwargs):
        super().__init__([balance_program(p) for p in programs], **kwargs)
