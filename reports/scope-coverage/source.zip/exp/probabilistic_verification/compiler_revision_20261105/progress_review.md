# Compiler revision evidence review

Date: 5 November 2026. Depth: standard. Reviewer: compiler-author assistant.

The bounded revision improves selected omissions and bindings, but the fresh sample
does not demonstrate a semantic gain. Compilation rises from 2,095 to 2,099; all
20 fresh programs are unchanged and retain important errors. General compilation
reliability and full inference throughput remain open.

## Scope and evidence

Primary evidence is the original returned review (SHA256 recorded in
human_review_audit.json), every before/after row in baseline.jsonl/results.jsonl,
the frozen input parses, tests.xml, fresh_readings.json/fresh_review.json and
native_profile.json. The source freezes preserve both candidates. New human
ratings of revised programs, media verification accuracy and new relation-training
results do not exist. Assistant qualitative judgments are labeled as such.

## Claims checked

| Claim | Verdict | Evidence and evidence status |
|---|---|---|
| All20 actual reviews were returned and confirmed | Confirmed | Evidence-backed: human_review_audit.json; preserved raw export cases[].human_confirmed and reading flags |
| The preceding Nov1 revision improved meaning on the reviewed paired accepts | Refuted for these16 cases | Evidence-backed: human_analysis/analysis.json paired_outcomes has16 ties,2 newly refused and2 both refused; both newly refused were judged inappropriate |
| Current coverage rises by4 with no earlier accepts lost | Confirmed | Evidence-backed: census_analysis.json and complete before/after program records |
| The named targeted omissions/bindings are represented | Confirmed at the stated structural level | Evidence-backed: tests.xml207 passes; per-example metadata for exact quotations, next-to/name, topic, coordination, controller and reciprocal literal. This is not a whole-corpus semantic-equivalence proof |
| The new revision demonstrates fresh semantic gain | Refuted for this sample | Evidence-backed: fresh_preservation.json has20 identical program hashes; fresh_review.json gives13/4/3 in both conditions, with no human gold implied |
| Every accepted program has demonstrated practical native inference | Refuted | Evidence-backed: native_profile.json has4 passes and1 timeout at25s; syntactic program parsing is a different check |
| Earlier compiler files and published archives are preserved | Confirmed by recorded hashes | Evidence-backed: frozen_manifest.json and historical_archives.json; final archive verification follows separately |

## Derived findings

- Evidence-backed: six of40 human ratings differ from the original agent draft;
  agreement is34/40. This assisted review is not an independent reliability study.
- Evidence-backed:29 compiled programs change; four were previously refused.
  The other25 changes mostly retain details or replace unsafe role descriptions.
  This count does not mean29 corrected programs.
- Evidence-backed: three of the previous15 lost accepts are restored;12 remain
  refused (8 nominal-disjunction,3 media-modifier,1 temporal-scope).
- Evidence-backed: all11 current programs rated faithful by the user remain
  byte-identical. No claim is made about every other earlier accepted program.
- Inferred: remaining fresh scope failures share a missing distinction between
  noun-attached content and independent assertions. Repeated local syntax patches
  will not by themselves establish general semantic parsing.
- Open question: can a compact constrained parse editor or a lexical scope model
  handle the remaining scope classes reliably? No new comparison was run here.

## Qualitative traces

| Case | Intended meaning | Before | After / evidence | Interpretation |
|---|---|---|---|---|
| TLO3smKI67PM_554 | Ball lands immediately beside Karen, a Phillies fan | Keeps stands; drops next-to target | Land has obl:next_to -> fan, with name Karen, modifier Phillies and right degree | Evidence-backed retention of a named relation; no new media score |
| TFOEIehBwT8Q_473 | Police and protesters mutually face one another | Creates unlinked other entity | Same face event has group subject and typed reciprocal target; no other entity | Evidence-backed structure; the reciprocal media-verifier contract remains untrained |
| TgR_u37mCoQ4_1907 | On-screen text supplies the full fire-spread label | Drops four-hour clause | Exact literal includes four hours after ignition under confirm/show context | Evidence-backed source-text retention |
| T2G_ACMxR_I4_1367 | Video depicts preparation for moon landing | Landing becomes a world event | Both frozen versions retain that error | Evidence-backed scope defect; requires separating nominal goal content from an asserted landing |
| TMrQshDs8aH0_752 | Dolly creaks while a man uses it | Creaks is tagged NOUN/root; SRL starts at uses | Both versions omit small dolly and creaking | Evidence-backed omission; upstream POS and incomplete root-predicate coverage are implicated |

## Failure synthesis and limits

The eight human-confirmed problem cases informed three development families.
The changes stay selective: only29 programs change across the full inventory.
Their wider semantic correctness is unmeasured. The fresh sample contains no
changed programs, so it checks remaining behavior rather than proving these rules
generalize. Three of its outputs have clear source/goal/question scope errors;
four are partial. One of13 faithful judgments accepts the user's current
passive-progressive simplification; treating it as partial gives12/5/3.

The first candidate also introduced unsafe bindings outside the reserved sample:
a tool became the actor of win, and a place/relative-clause actor became a person's
name. Those examples motivated two final restrictions. The entire first freeze
is preserved. All20 fresh programs remain identical after the restrictions; the
chronology is explicit rather than represented as an untouched final freeze.

The design limitation is a deterministic parser committing to incomplete or wrong
structure. The implementation fixes handle selected explicit constructions; they
do not convert parsing uncertainty into a calibrated probability or learn a
perception-conditioned binding model. Source/content boundaries and root coverage
are therefore higher-priority compiler work than further broad acceptance rules.

## Proposed next steps and intended goals

1. Model noun-attached event and question content explicitly, or refuse unresolved
   projection — prevent allegations, preparation goals and dialogue questions from
   being treated as independently supported world events.
2. Audit root predicates and identifiers against original text — retain omitted
   audio events and essential label/name material before accepting a program.
3. Bound/profile larger programs before media training — establish a practical
   inference/learning loop. The25-second timeout is an observed limit, not evidence
   about average corpus throughput.

The compiler remains experimental. The current evidence supports targeted repairs,
complete census reporting and clear limitations; it does not establish general
semantic accuracy or a verification-method improvement.
