# Evidence review: claim scope and missing content

Reviewer: compiler-author assistant. Evidence is not independent human gold.

The revision repairs targeted contexts/content, changes11 programs and makes260
omission alerts explicit. It leaves all2,099 executable candidates available. The
new acceptance total1,839 is not semantic accuracy. Fresh review shows no gain.

| Claim | Evidence | Assessment |
|---|---|---|
| Goal, investigation and question content remain nested | Source/output forms for the three named examples; regression tests | Confirmed for targeted cases, not a general scope theorem |
| Small dolly and creaking are retained | Recovered root/subject; while and purpose scopes; tests | Confirmed; it still needs reference resolution |
| Full names and identifiers improve | Eleven changed program records; complete-name/quantity controls | Targeted improvement; highway route error remains |
| All old executable candidates remain | Complete input/result sets and hashes | Exactly2,099 in both conditions;276 earlier refusals unchanged |
| Coverage rejects260 candidates | Per-token alerts; diagnostic programs retained | Confirmed; this is a lexical omission gate, not semantic correctness |
| Alerts identify actual problems | Seeded12-alert qualitative inspection | All12 have omissions; wider precision and false-alert rate unknown |
| Fresh meaning improves | New pre-reserved20-case review and program hashes | No: all outputs/statuses unchanged,9 faithful/5 partial/2 incorrect/4 refused |
| Default earlier behavior is preserved | Full2,375 complete-record comparison after callback addition | Confirmed; historical ZIPs and frozen source copies remain |
| Practical native cost is solved | Goal-context native regression tests only | Not established; earlier long-protest timeout remains outside this work |

The coverage gate catches missing dates, participants, range endpoints, locations,
names and outer attribution. It misses wrong roles and words retained inside
inadequately parsed strings. The fresh examples demonstrate those limits directly.
Passing coverage must not be used as automatic semantic gold or a training label.

No compiler changes followed fresh/alert review. Next proposals: recover coverage
on recurring alert families; improve opaque-clause/source boundaries; resolve local
pronouns and establish practical inference bounds. See README and saved evidence.
