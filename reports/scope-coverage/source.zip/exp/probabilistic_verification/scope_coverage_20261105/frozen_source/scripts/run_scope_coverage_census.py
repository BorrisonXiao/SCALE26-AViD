#!/usr/bin/env python3
"""Run one scope/coverage compiler and retain candidates that fail its audit."""
import argparse
import hashlib
import json
import time
from collections import Counter
from pathlib import Path

from problog.program import PrologString
from probabilistic_verification.balanced_logic import balanced_prolog_program
from probabilistic_verification.compilation_checks_v2 import meaning_diagnostics
from probabilistic_verification.logic import Evidence, ground
from probabilistic_verification.scope_coverage import compile_scope_coverage

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'exp/probabilistic_verification/scope_coverage_20261105'


def compile_one(record):
    row = dict(claim_id=record['claim_id'], text=record['text'], status='unsupported')
    try:
        claim, notes = compile_scope_coverage(record, strict=False)
        row.update(changes=notes, proposed_form=claim.metadata['logical_form'])
        evidence = Evidence('compilation-check', {v.name: [v.name.lower()] for v in claim.variables},
                            {v.name: True for v in claim.variables}, {})
        program, _ = balanced_prolog_program([ground(claim, evidence, max_expansions=10000)], learned=False)
        assert list(PrologString(program))
        row.update(status='compiled', compilation=claim.to_dict(), program=program,
                   program_sha256=hashlib.sha256(program.encode()).hexdigest(),
                   diagnostics=meaning_diagnostics(record, claim.metadata['logical_form'], claim),
                   coverage=claim.metadata['content_coverage'])
        if not row['coverage']['complete']:
            row.update(status='unsupported', code='coverage_omission',
                       reason='Unrepresented source content: '+', '.join(t['text'] for t in row['coverage']['missing']))
    except Exception as error:
        row.update(code=getattr(error, 'code', type(error).__name__), reason=str(error))
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--development', action='store_true', help='Exclude the newly reserved source videos.')
    parser.add_argument('--output', type=Path, default=RUN / 'results.jsonl')
    args = parser.parse_args()
    records = list(map(json.loads, (RUN / 'inputs.jsonl').read_text().splitlines()))
    if args.development:
        manifest = json.loads((RUN / 'sample_manifest.json').read_text())
        excluded = {s for c in manifest['cases'] for s in c['source_videos']}
        records = [r for r in records if not set(r['source_videos']) & excluded]
    started = time.perf_counter()
    rows = [compile_one(r) for r in records]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in rows))
    summary = dict(total=len(rows), accepted=sum(r['status'] == 'compiled' for r in rows),
                   executable_candidates=sum('program' in r for r in rows),
                   refusal_reasons=dict(Counter(r['code'] for r in rows if r['status'] != 'compiled')),
                   kinds=dict(Counter(r['compilation']['metadata']['kind'] for r in rows if r['status'] == 'compiled')),
                   elapsed_seconds=time.perf_counter()-started)
    args.output.with_suffix('.summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
