"""Check scope, source retention and conservative refusals with real cases/controls."""
import copy
import json
from pathlib import Path

import pytest

from probabilistic_verification.balanced_logic import BalancedVerifier
from probabilistic_verification.logic import Evidence, Observation, canonical_key, ground
from probabilistic_verification.logical_form import LogicalFormError
from probabilistic_verification.representation import Atom
from probabilistic_verification.reviewed_srl import compile_reviewed_srl
from probabilistic_verification.scope_coverage import (
    audit_content_coverage, compile_scope_coverage, prepare_root_predicate, preserve_content_scope,
)
from test_scoped_srl import constructed_record

ROOT = Path(__file__).resolve().parents[1]
RECORDS = {r['claim_id']: r for r in map(json.loads,
    (ROOT/'exp/probabilistic_verification/compiler_revision_20261105/inputs.jsonl').read_text().splitlines())}


def case(cid):
    return compile_scope_coverage(RECORDS[cid])[0]


def test_landing_is_only_the_preparation_goal_inside_visual_depiction():
    claim = case('T2G_ACMxR_I4_1367')
    landing = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'landing')
    scopes = claim.metadata['scopes']
    assert scopes[landing['scope']]['kind'] == 'purpose'
    assert scopes[scopes[landing['scope']]['parent']]['kind'] == 'depiction'
    assert landing['route'] == 'visual_depiction'
    assert not any(e['scope'] == 'world' and e['predicate'] == 'landing' for e in claim.metadata['events'].values())


def test_violation_belongs_to_investigation_not_a_person_relative_assertion():
    claim = case('TzzhcBIczf_M_2108')
    violation = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'violate')
    scope = claim.metadata['scopes'][violation['scope']]
    assert scope['kind'] == 'complement' and scope['role'] == 'into'
    assert claim.metadata['entities'][scope['owner']]['text'] == 'investigation'
    assert not next(e for e in claim.metadata['entities'].values() if e['text'] == 'Shi Yongxin').get('propositions')
    assert any(e['predicate'] == 'indicate' and e['scope'] == 'world' for e in claim.metadata['events'].values())


def test_question_is_content_of_dialogue_with_the_original_wh_word():
    claim = case('TFOEIehBwT8Q_483')
    event = next(e for e in claim.metadata['events'].values() if e['predicate'] == 'be')
    scope = claim.metadata['scopes'][event['scope']]
    assert scope['kind'] == 'question'
    assert claim.metadata['entities'][scope['owner']]['text'] == 'dialogue'
    assert 'ARGM-CAU' not in event['arguments']
    assert dict(role='question_word', value='why') in event['properties']
    assert 'reference resolution' in claim.metadata['runtime_requirements']


def test_dolly_sound_and_size_return_and_movement_remains_a_purpose():
    claim = case('TMrQshDs8aH0_752')
    events = {e['predicate']: e for e in claim.metadata['events'].values()}
    assert set(events) == {'creak', 'use', 'move'}
    entity = next(e for e in claim.metadata['entities'].values() if e['id'] == events['creak']['arguments']['nsubj'])
    assert entity['text'] == 'dolly' and dict(role='mod', value='small') in entity['properties']
    assert claim.metadata['scopes'][events['use']['scope']]['role'] == 'while'
    assert claim.metadata['scopes'][events['move']['scope']]['kind'] == 'purpose'
    # Coverage is not coreference resolution: retain this requirement explicitly.
    assert 'reference resolution' in claim.metadata['runtime_requirements']


@pytest.mark.parametrize('cid,expected', [('TInVWzp25aIM_18','Bering Straight')])
def test_source_name_is_complete_without_correcting_original_spelling(cid, expected):
    claim = case(cid)
    assert any(e['text'] == expected for e in claim.metadata['entities'].values())
    assert claim.metadata['content_coverage']['complete']


def test_postnominal_number_is_an_identifier_not_a_count():
    claim = case('TQKCK6-tRaoE_671')
    entity = next(iter(claim.metadata['entities'].values()))
    assert dict(role='identifier', value='76') in entity['properties']
    assert 'quantity' not in entity


@pytest.mark.parametrize('cid,name', [('T2G_ACMxR_I4_1090','Blue Ghost Mission 1'),
                                     ('TbJqMFkNxARY_156','LBHP Boat 1')])
def test_expanding_name_components_never_shortens_a_complete_existing_name(cid,name):
    assert any(e['text'] == name for e in case(cid).metadata['entities'].values())


def test_numeric_operator_counts_as_retained_comparison_language():
    claim = case('TInVWzp25aIM_22')
    assert any(e.get('quantity',{}).get('operator') == 'at_least' for e in claim.metadata['entities'].values())
    assert claim.metadata['content_coverage']['complete']


def test_complete_numeric_name_does_not_gain_a_redundant_identifier_constraint():
    record = RECORDS['T2G_ACMxR_I4_1111']
    old, _ = compile_reviewed_srl(record)
    new, _ = compile_scope_coverage(record)
    assert new.atoms == old.atoms and new.expression == old.expression


def test_preparing_dinner_without_for_keeps_the_original_argument():
    r = constructed_record('Alice prepares dinner.', [
        ('Alice','Alice','PROPN',2,'nsubj'), ('prepares','prepare','VERB',0,'root'),
        ('dinner','dinner','NOUN',2,'obj'), ('.','.','PUNCT',2,'punct')],
        [(1,[('ARG0',0,0),('ARG1',2,2)])])
    claim, notes = compile_scope_coverage(r)
    assert not any(n['kind'] == 'nominal_goal_scope' for n in notes)
    assert not claim.metadata['scopes']


def test_goal_noun_without_an_srl_event_is_not_given_an_invented_actor():
    r = constructed_record('Alice prepares for landing.', [
        ('Alice','Alice','PROPN',2,'nsubj'), ('prepares','prepare','VERB',0,'root'),
        ('for','for','ADP',4,'case'), ('landing','landing','NOUN',2,'obl'),
        ('.','.','PUNCT',2,'punct')], [(1,[('ARG0',0,0),('ARG2',2,3)])])
    claim, _ = compile_scope_coverage(r)
    assert {e['predicate'] for e in claim.metadata['events'].values()} == {'prepare'}
    assert any(s['kind'] == 'purpose' for s in claim.metadata['scopes'].values())


def test_count_before_a_noun_does_not_become_an_identifier():
    r = constructed_record('76 people walk.', [
        ('76','76','NUM',2,'nummod'), ('people','person','NOUN',3,'nsubj'),
        ('walk','walk','VERB',0,'root'), ('.','.','PUNCT',3,'punct')], [(2,[('ARG0',0,1)])])
    claim, _ = compile_scope_coverage(r)
    assert any(e.get('quantity',{}).get('value') == '76' for e in claim.metadata['entities'].values())
    assert not any(p['role'] == 'identifier' for e in claim.metadata['entities'].values() for p in e.get('properties', []))


def test_noun_phrase_without_a_finite_temporal_clause_is_not_retagged():
    r = constructed_record('Small dolly creaks.', [
        ('Small','small','ADJ',3,'amod'), ('dolly','dolly','NOUN',3,'compound'),
        ('creaks','creak','NOUN',0,'root'), ('.','.','PUNCT',3,'punct')], [])
    prepared, notes = prepare_root_predicate(r)
    assert prepared == r and not notes


def test_unlinked_declarations_and_warnings_do_not_hide_omissions():
    r = RECORDS['TQKCK6-tRaoE_671']
    form = dict(entities=[dict(id='x1',text='news'),dict(id='unused',text='76')],
                formula=dict(op='entity',ref='x1'),warnings=['76'])
    audit = audit_content_coverage(r, form)
    assert not audit['complete'] and [t['text'] for t in audit['missing']] == ['76']


def test_unrepaired_omission_refuses_compilation_and_retains_a_diagnostic_candidate():
    r = RECORDS['TInVWzp25aIM_11']  # online is omitted by the cached structure.
    with pytest.raises(LogicalFormError, match='online') as exc:
        compile_scope_coverage(r)
    assert exc.value.code == 'coverage_omission'
    assert not exc.value.candidate.metadata['content_coverage']['complete']


def test_coverage_accepts_inflection_but_does_not_certify_roles():
    r = constructed_record('Alice walks.', [('Alice','Alice','PROPN',2,'nsubj'),
        ('walks','walk','VERB',0,'root'), ('.','.','PUNCT',2,'punct')], [(1,[('ARG0',0,0)])])
    assert compile_scope_coverage(r)[0].metadata['content_coverage']['complete']


def test_input_annotations_remain_unchanged():
    record = copy.deepcopy(RECORDS['TMrQshDs8aH0_752']);saved = copy.deepcopy(record)
    compile_scope_coverage(record)
    assert record == saved


@pytest.mark.parametrize('state', ['supported','refuted','unknown'])
def test_native_goal_uses_scoped_evidence_and_ignores_a_world_landing(state):
    claim = case('T2G_ACMxR_I4_1367')
    domains = {v.name:[v.name.lower()] for v in claim.variables}
    assignment = {k:v[0] for k,v in domains.items()};observations={}
    target = next(a for a in claim.atoms if a.predicate == 'landing')
    assert target.arguments[target.arguments.index('scope')+1] != 'world'
    for atom in claim.atoms:
        label = state if atom.id == target.id else 'supported'
        route = claim.metadata['allowed_routes'][atom.id][0]
        key = canonical_key('scope-fixture',atom,assignment,route)
        observations[key]=Observation(key,tuple(float(s==label) for s in ('supported','refuted','unknown')),False,atom.text,{'source':'stipulated test'})
    args=list(target.arguments);args[args.index('scope')+1]='world'
    world = Atom('world-landing',target.predicate,tuple(args),target.kind,(),target.text,(),False)
    key=canonical_key('scope-fixture',world,assignment,'visual_depiction')
    observations[key]=Observation(key,(0.,1.,0.),False,'Actual landing absent',{'source':'stipulated test'})
    g=ground(claim,Evidence('scope-fixture',domains,{v:True for v in domains},observations))
    assert BalancedVerifier([g],learned=False).predict()[0]['distribution'][state] > 1-1e-9
